import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { createProcedural002, ProceduralCompanion } from '../utils/procedural002Model';
import { CameraPreset, LightingPreset, ModelMetadata } from '../types';
import { 
  Rotate3d, 
  ZoomIn, 
  Sun, 
  Sparkles, 
  Eye, 
  RefreshCw, 
  RotateCw,
  UploadCloud, 
  Play, 
  Pause,
  Maximize2
} from 'lucide-react';

interface ThreeCharacterViewerProps {
  onModelLoaded?: (meta: ModelMetadata) => void;
  interactiveControls?: boolean;
  className?: string;
  showModelUploadButton?: boolean;
  activeLightingPreset?: LightingPreset;
  activeCameraPreset?: CameraPreset;
  onCameraPresetChange?: (preset: CameraPreset) => void;
  externalGlbBuffer?: { buffer: ArrayBuffer; name: string } | null;
  onModelImported?: (buffer: ArrayBuffer, name: string) => void;
  onClearCustomModel?: () => void;
  idleEnabled?: boolean;
  onIdleToggle?: (enabled: boolean) => void;
  blinkEnabled?: boolean;
  onBlinkToggle?: (enabled: boolean) => void;
  headMovementEnabled?: boolean;
  onHeadMovementToggle?: (enabled: boolean) => void;
  onResetPose?: () => void;
}

export const ThreeCharacterViewer: React.FC<ThreeCharacterViewerProps> = ({
  onModelLoaded,
  interactiveControls = true,
  className = '',
  showModelUploadButton = true,
  activeLightingPreset = 'cyber-neon',
  activeCameraPreset = 'front',
  onCameraPresetChange,
  externalGlbBuffer = null,
  onModelImported,
  onClearCustomModel,
  idleEnabled: propIdleEnabled,
  onIdleToggle,
  blinkEnabled: propBlinkEnabled,
  onBlinkToggle,
  headMovementEnabled: propHeadMovementEnabled,
  onHeadMovementToggle,
  onResetPose,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // States
  const [loadingModel, setLoadingModel] = useState<boolean>(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [wireframe, setWireframe] = useState<boolean>(false);
  const [autoRotate, setAutoRotate] = useState<boolean>(false);
  const [currentModelSource, setCurrentModelSource] = useState<'procedural' | 'glb'>('procedural');
  const [modelName, setModelName] = useState<string>('002 Cyber Companion (Procedural)');
  
  // Animation states & controls
  const [localIdleEnabled, setLocalIdleEnabled] = useState<boolean>(true);
  const [localBlinkEnabled, setLocalBlinkEnabled] = useState<boolean>(true);
  const [localHeadMovementEnabled, setLocalHeadMovementEnabled] = useState<boolean>(true);

  const effectiveIdle = propIdleEnabled !== undefined ? propIdleEnabled : localIdleEnabled;
  const effectiveBlink = propBlinkEnabled !== undefined ? propBlinkEnabled : localBlinkEnabled;
  const effectiveHeadMovement = propHeadMovementEnabled !== undefined ? propHeadMovementEnabled : localHeadMovementEnabled;

  const idleEnabledRef = useRef(effectiveIdle);
  idleEnabledRef.current = effectiveIdle;

  const blinkEnabledRef = useRef(effectiveBlink);
  blinkEnabledRef.current = effectiveBlink;

  const headMovementEnabledRef = useRef(effectiveHeadMovement);
  headMovementEnabledRef.current = effectiveHeadMovement;

  // Rig and Morph Telemetry
  const [modelRigInfo, setModelRigInfo] = useState<{
    isRigged: boolean;
    boneCount: number;
    morphTargetCount: number;
    hasBlinkSupport: boolean;
    rigDetails: string;
  }>({
    isRigged: true,
    boneCount: 16,
    morphTargetCount: 2,
    hasBlinkSupport: true,
    rigDetails: 'Procedural Anime Avatar with Dynamic Eye & Breath Rigs',
  });

  // Animation states for imported GLB models
  const [hasAnimations, setHasAnimations] = useState<boolean>(false);
  const [isPlayingAnimation, setIsPlayingAnimation] = useState<boolean>(true);
  const [animationNames, setAnimationNames] = useState<string[]>([]);
  const [currentAnimIndex, setCurrentAnimIndex] = useState<number>(0);

  // Controls UI Collapsed state for mobile & clean viewing
  const [controlsCollapsed, setControlsCollapsed] = useState<boolean>(false);

  // Three.js References to keep lifecycle outside react state re-renders
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const currentCompanionRef = useRef<ProceduralCompanion | null>(null);
  const importedModelGroupRef = useRef<THREE.Group | null>(null);
  const mixerRef = useRef<THREE.AnimationMixer | null>(null);
  const animationActionsRef = useRef<THREE.AnimationAction[]>([]);
  const lightsGroupRef = useRef<THREE.Group | null>(null);

  // Skeletal & Morph Targets Refs for imported models
  const headBoneRef = useRef<THREE.Bone | null>(null);
  const restHeadQuatRef = useRef<THREE.Quaternion>(new THREE.Quaternion());
  const baseModelPosRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 0, 0));
  const blinkMorphTargetsRef = useRef<{ mesh: THREE.Mesh; index: number }[]>([]);
  const skinnedMeshesRef = useRef<THREE.SkinnedMesh[]>([]);
  const blinkStateRef = useRef<{
    nextBlinkTime: number;
    phase: 'open' | 'closing' | 'opening';
    progress: number;
  }>({
    nextBlinkTime: 2.5,
    phase: 'open',
    progress: 0,
  });

  // Target camera positions for smooth damping presets
  const cameraTargetRef = useRef<{
    pos: THREE.Vector3;
    lookAt: THREE.Vector3;
    transitioning: boolean;
  }>({
    pos: new THREE.Vector3(0, 1.6, 4.2),
    lookAt: new THREE.Vector3(0, 1.4, 0),
    transitioning: false,
  });

  // Callback refs to maintain stable callback hooks without re-triggering effects
  const onModelLoadedRef = useRef(onModelLoaded);
  onModelLoadedRef.current = onModelLoaded;

  const onCameraPresetChangeRef = useRef(onCameraPresetChange);
  onCameraPresetChangeRef.current = onCameraPresetChange;

  const onClearCustomModelRef = useRef(onClearCustomModel);
  onClearCustomModelRef.current = onClearCustomModel;

  const onModelImportedRef = useRef(onModelImported);
  onModelImportedRef.current = onModelImported;

  const onIdleToggleRef = useRef(onIdleToggle);
  onIdleToggleRef.current = onIdleToggle;

  const onBlinkToggleRef = useRef(onBlinkToggle);
  onBlinkToggleRef.current = onBlinkToggle;

  const onHeadMovementToggleRef = useRef(onHeadMovementToggle);
  onHeadMovementToggleRef.current = onHeadMovementToggle;

  const onResetPoseRef = useRef(onResetPose);
  onResetPoseRef.current = onResetPose;

  const externalGlbBufferRef = useRef(externalGlbBuffer);
  externalGlbBufferRef.current = externalGlbBuffer;

  const lastLoadedBufferRef = useRef<ArrayBuffer | null>(null);

  // Calculate and apply camera preset coordinates
  const applyCameraPreset = useCallback((preset: CameraPreset, notifyParent = false) => {
    if (!controlsRef.current || !cameraRef.current) return;
    
    let targetPos = new THREE.Vector3(0, 1.6, 4.2);
    let targetLook = new THREE.Vector3(0, 1.4, 0);

    switch (preset) {
      case 'portrait':
        targetPos = new THREE.Vector3(0, 2.3, 1.8);
        targetLook = new THREE.Vector3(0, 2.2, 0);
        break;
      case 'full':
        targetPos = new THREE.Vector3(0, 1.5, 5.0);
        targetLook = new THREE.Vector3(0, 1.2, 0);
        break;
      case 'isometric':
        targetPos = new THREE.Vector3(3.2, 2.8, 3.2);
        targetLook = new THREE.Vector3(0, 1.3, 0);
        break;
      case 'side':
        targetPos = new THREE.Vector3(3.8, 1.6, 0.2);
        targetLook = new THREE.Vector3(0, 1.4, 0);
        break;
      case 'front':
      default:
        targetPos = new THREE.Vector3(0, 1.6, 4.2);
        targetLook = new THREE.Vector3(0, 1.4, 0);
        break;
    }

    cameraTargetRef.current = {
      pos: targetPos,
      lookAt: targetLook,
      transitioning: true,
    };

    if (notifyParent) {
      onCameraPresetChangeRef.current?.(preset);
    }
  }, []);

  // Synchronize lighting presets
  const updateLightingPreset = useCallback((preset: LightingPreset) => {
    const lightsGroup = lightsGroupRef.current;
    if (!lightsGroup) return;

    lightsGroup.clear();

    const ambient = new THREE.AmbientLight(0xffffff, 0.4);
    lightsGroup.add(ambient);

    switch (preset) {
      case 'cyber-neon': {
        const keyLight = new THREE.DirectionalLight(0xff2d78, 2.2); // neon pink
        keyLight.position.set(2.5, 4, 3);
        keyLight.castShadow = true;
        lightsGroup.add(keyLight);

        const cyanFill = new THREE.DirectionalLight(0x06b6d4, 1.8); // cyber cyan
        cyanFill.position.set(-3, 2, 2);
        lightsGroup.add(cyanFill);

        const purpleRim = new THREE.PointLight(0xa855f7, 2.0, 10);
        purpleRim.position.set(0, 3, -3);
        lightsGroup.add(purpleRim);

        const hemiLight = new THREE.HemisphereLight(0xff2d78, 0x0f0f23, 0.6);
        lightsGroup.add(hemiLight);
        break;
      }
      case 'crimson-cockpit': {
        const crimsonKey = new THREE.DirectionalLight(0xe11d48, 2.8);
        crimsonKey.position.set(2, 3.5, 2.5);
        crimsonKey.castShadow = true;
        lightsGroup.add(crimsonKey);

        const amberFill = new THREE.PointLight(0xf59e0b, 1.4, 8);
        amberFill.position.set(-2, 1.5, 2);
        lightsGroup.add(amberFill);

        const hemiLight = new THREE.HemisphereLight(0xff0055, 0x1f0714, 0.7);
        lightsGroup.add(hemiLight);
        break;
      }
      case 'deep-space': {
        const starlight = new THREE.DirectionalLight(0x38bdf8, 1.5);
        starlight.position.set(3, 4, 2);
        lightsGroup.add(starlight);

        const blueFill = new THREE.DirectionalLight(0x6366f1, 1.2);
        blueFill.position.set(-2.5, 1, 1);
        lightsGroup.add(blueFill);

        const hemiLight = new THREE.HemisphereLight(0x38bdf8, 0x050510, 0.4);
        lightsGroup.add(hemiLight);
        break;
      }
      case 'studio':
      default: {
        const whiteKey = new THREE.DirectionalLight(0xffffff, 2.0);
        whiteKey.position.set(2, 4, 3);
        whiteKey.castShadow = true;
        lightsGroup.add(whiteKey);

        const softFill = new THREE.DirectionalLight(0x94a3b8, 1.0);
        softFill.position.set(-2, 2, 2);
        lightsGroup.add(softFill);

        const hemiLight = new THREE.HemisphereLight(0xffffff, 0x1e293b, 0.8);
        lightsGroup.add(hemiLight);
        break;
      }
    }
  }, []);

  // Reset to default procedural 002 character
  const resetToProcedural002 = useCallback(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    // Remove imported model if present
    if (importedModelGroupRef.current) {
      scene.remove(importedModelGroupRef.current);
      importedModelGroupRef.current.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) {
          const mesh = child as THREE.Mesh;
          mesh.geometry?.dispose();
          if (Array.isArray(mesh.material)) {
            mesh.material.forEach(m => m.dispose());
          } else {
            mesh.material?.dispose();
          }
        }
      });
      importedModelGroupRef.current = null;
    }

    if (mixerRef.current) {
      mixerRef.current.stopAllAction();
      mixerRef.current = null;
      animationActionsRef.current = [];
    }

    headBoneRef.current = null;
    blinkMorphTargetsRef.current = [];
    skinnedMeshesRef.current = [];

    // Recreate procedural companion if not present
    if (!currentCompanionRef.current) {
      const comp = createProcedural002();
      scene.add(comp.group);
      currentCompanionRef.current = comp;
    } else {
      currentCompanionRef.current.group.visible = true;
      currentCompanionRef.current.resetPose();
    }

    setCurrentModelSource('procedural');
    setModelName('002 Cyber Companion (Procedural)');
    setHasAnimations(false);
    setAnimationNames([]);
    setLoadError(null);
    lastLoadedBufferRef.current = null;

    const proceduralRig = {
      isRigged: true,
      boneCount: 16,
      morphTargetCount: 2,
      hasBlinkSupport: true,
      rigDetails: 'Procedural Anime Avatar with Dynamic Eye & Breath Rigs',
    };
    setModelRigInfo(proceduralRig);

    // Report metadata
    onModelLoadedRef.current?.({
      name: '002 Cyber Companion',
      source: 'procedural-002',
      meshCount: 22,
      vertexCount: 4200,
      triangleCount: 5800,
      animations: ['Idle Float', 'Breathing', 'Horn Glow Pulse', 'Eye Blink'],
      ...proceduralRig,
    });

    onClearCustomModelRef.current?.();
  }, []);

  // Load GLB file from ArrayBuffer
  const loadGlbFromArrayBuffer = useCallback((arrayBuffer: ArrayBuffer, fileName: string) => {
    const scene = sceneRef.current;
    if (!scene) return;

    setLoadingModel(true);
    setLoadError(null);

    const loader = new GLTFLoader();

    loader.parse(
      arrayBuffer,
      '',
      (gltf) => {
        try {
          // Hide procedural companion
          if (currentCompanionRef.current) {
            currentCompanionRef.current.group.visible = false;
          }

          // Clean up any previously imported model
          if (importedModelGroupRef.current) {
            scene.remove(importedModelGroupRef.current);
            importedModelGroupRef.current.traverse((child) => {
              if ((child as THREE.Mesh).isMesh) {
                const mesh = child as THREE.Mesh;
                mesh.geometry?.dispose();
                if (Array.isArray(mesh.material)) {
                  mesh.material.forEach(m => m.dispose());
                } else {
                  mesh.material?.dispose();
                }
              }
            });
          }

          const model = gltf.scene;
          model.visible = true;
          importedModelGroupRef.current = model;

          // Compute bounding box and normalize scale & position
          const box = new THREE.Box3().setFromObject(model);
          const size = new THREE.Vector3();
          box.getSize(size);
          const center = new THREE.Vector3();
          box.getCenter(center);

          // Find maximum dimension and scale to fit comfortable height (~2.6 units)
          const maxDim = Math.max(size.x, size.y, size.z);
          const targetHeight = 2.6;
          const scale = maxDim > 0 ? targetHeight / maxDim : 1;
          model.scale.setScalar(scale);

          // Re-compute after scale to place pivot flush at ground level Y=0
          const scaledBox = new THREE.Box3().setFromObject(model);
          model.position.x = -center.x * scale;
          model.position.y = -scaledBox.min.y; // Sit directly on pedestal
          model.position.z = -center.z * scale;
          baseModelPosRef.current.copy(model.position);

          // Rig Inspection & Telemetry Gathering
          let meshCount = 0;
          let vertexCount = 0;
          let triangleCount = 0;
          const skinnedMeshes: THREE.SkinnedMesh[] = [];
          const uniqueBones = new Set<THREE.Bone>();
          let detectedHeadBone: THREE.Bone | null = null;
          const blinkTargets: { mesh: THREE.Mesh; index: number }[] = [];
          let totalMorphCount = 0;

          model.traverse((child) => {
            if ((child as any).isBone) {
              uniqueBones.add(child as THREE.Bone);
            }
            if ((child as any).isSkinnedMesh) {
              const sm = child as THREE.SkinnedMesh;
              skinnedMeshes.push(sm);
              if (sm.skeleton && sm.skeleton.bones) {
                sm.skeleton.bones.forEach((b) => uniqueBones.add(b));
              }
            }
            if ((child as THREE.Mesh).isMesh) {
              const mesh = child as THREE.Mesh;
              meshCount++;
              mesh.castShadow = true;
              mesh.receiveShadow = true;
              if (mesh.geometry) {
                vertexCount += mesh.geometry.attributes.position?.count || 0;
                triangleCount += mesh.geometry.index ? mesh.geometry.index.count / 3 : (mesh.geometry.attributes.position?.count || 0) / 3;
              }

              // Scan for morph targets
              if (mesh.morphTargetDictionary && mesh.morphTargetInfluences) {
                const dict = mesh.morphTargetDictionary;
                totalMorphCount += Object.keys(dict).length;
                for (const [key, idx] of Object.entries(dict)) {
                  if (/blink|eye.*close|close.*eye|eyes_closed|fcl_eye_close/i.test(key)) {
                    blinkTargets.push({ mesh, index: idx });
                  }
                }
              }
            }
          });

          // Identify head or neck bone
          uniqueBones.forEach((b) => {
            if (!detectedHeadBone && /head|neck|face|cranium/i.test(b.name)) {
              detectedHeadBone = b;
            }
          });

          headBoneRef.current = detectedHeadBone;
          if (detectedHeadBone) {
            restHeadQuatRef.current.copy((detectedHeadBone as THREE.Bone).quaternion);
          }
          blinkMorphTargetsRef.current = blinkTargets;
          skinnedMeshesRef.current = skinnedMeshes;

          const boneCount = uniqueBones.size;
          const isRigged = boneCount > 0;
          const hasBlinkSupport = blinkTargets.length > 0;
          const headBoneName = detectedHeadBone ? (detectedHeadBone as THREE.Bone).name : '';
          const rigDetails = isRigged 
            ? `Rigged Model (${boneCount} bones${headBoneName ? `, head: ${headBoneName}` : ''}${hasBlinkSupport ? ', Eye Blink Morphs active' : ', No eye morphs'})`
            : 'Unrigged (Static 3D Mesh - Procedural idle breathing active)';

          const rigInfo = {
            isRigged,
            boneCount,
            morphTargetCount: totalMorphCount,
            hasBlinkSupport,
            rigDetails,
          };
          setModelRigInfo(rigInfo);

          // Animation Mixer setup
          if (gltf.animations && gltf.animations.length > 0) {
            const mixer = new THREE.AnimationMixer(model);
            mixerRef.current = mixer;
            animationActionsRef.current = [];

            const names = gltf.animations.map((clip, idx) => {
              const action = mixer.clipAction(clip);
              animationActionsRef.current.push(action);
              return clip.name || `Animation ${idx + 1}`;
            });

            setAnimationNames(names);
            setHasAnimations(true);
            setCurrentAnimIndex(0);
            setIsPlayingAnimation(true);

            // Play first animation
            if (animationActionsRef.current[0]) {
              animationActionsRef.current[0].play();
            }
          } else {
            mixerRef.current = null;
            animationActionsRef.current = [];
            setHasAnimations(false);
            setAnimationNames([]);
          }

          scene.add(model);
          setCurrentModelSource('glb');
          setModelName(fileName);
          setLoadingModel(false);

          onModelLoadedRef.current?.({
            name: fileName,
            source: 'imported-glb',
            fileSize: `${(arrayBuffer.byteLength / (1024 * 1024)).toFixed(2)} MB`,
            meshCount,
            vertexCount: Math.round(vertexCount),
            triangleCount: Math.round(triangleCount),
            animations: gltf.animations.map(a => a.name || 'Clip'),
            ...rigInfo,
          });
        } catch (err: any) {
          console.error('Error post-processing loaded GLTF:', err);
          setLoadError(`Failed to process model: ${err.message || 'Unknown error'}`);
          setLoadingModel(false);
          resetToProcedural002();
        }
      },
      (error: any) => {
        console.error('GLTFLoader error:', error);
        setLoadError('Failed to parse .glb model. Please ensure the file is a valid binary glTF (.glb) file.');
        setLoadingModel(false);
      }
    );
  }, [resetToProcedural002]);

  // Handle file input change
  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.glb') && !file.name.toLowerCase().endsWith('.gltf')) {
      setLoadError('Please select a valid .glb 3D model file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const buffer = event.target?.result as ArrayBuffer;
      if (buffer) {
        lastLoadedBufferRef.current = buffer;
        onModelImportedRef.current?.(buffer, file.name);
        loadGlbFromArrayBuffer(buffer, file.name);
      }
    };
    reader.onerror = () => {
      setLoadError('Could not read the selected file from disk.');
    };
    reader.readAsArrayBuffer(file);

    // Reset input so re-selecting same file triggers change
    e.target.value = '';
  };

  // External GLB buffer prop reaction
  useEffect(() => {
    if (externalGlbBuffer && externalGlbBuffer.buffer !== lastLoadedBufferRef.current) {
      lastLoadedBufferRef.current = externalGlbBuffer.buffer;
      loadGlbFromArrayBuffer(externalGlbBuffer.buffer, externalGlbBuffer.name);
    } else if (!externalGlbBuffer) {
      lastLoadedBufferRef.current = null;
    }
  }, [externalGlbBuffer, loadGlbFromArrayBuffer]);

  // Animation Controls Handlers
  const toggleIdle = () => {
    const next = !effectiveIdle;
    setLocalIdleEnabled(next);
    onIdleToggleRef.current?.(next);
  };

  const toggleBlink = () => {
    const next = !effectiveBlink;
    setLocalBlinkEnabled(next);
    onBlinkToggleRef.current?.(next);
  };

  const toggleHeadMovement = () => {
    const next = !effectiveHeadMovement;
    setLocalHeadMovementEnabled(next);
    onHeadMovementToggleRef.current?.(next);
  };

  const handleResetPose = useCallback(() => {
    // 1. Reset procedural companion if active
    if (currentCompanionRef.current) {
      currentCompanionRef.current.resetPose();
    }

    // 2. Reset imported GLTF model
    if (importedModelGroupRef.current) {
      importedModelGroupRef.current.position.copy(baseModelPosRef.current);
      importedModelGroupRef.current.rotation.set(0, 0, 0);

      skinnedMeshesRef.current.forEach((sm) => {
        sm.skeleton?.pose();
      });

      if (headBoneRef.current) {
        headBoneRef.current.quaternion.copy(restHeadQuatRef.current);
      }

      blinkMorphTargetsRef.current.forEach(({ mesh, index }) => {
        if (mesh.morphTargetInfluences) {
          mesh.morphTargetInfluences[index] = 0;
        }
      });

      if (mixerRef.current) {
        mixerRef.current.setTime(0);
      }
    }

    // 3. Smoothly restore front camera
    applyCameraPreset('front', true);

    // 4. Notify parent
    onResetPoseRef.current?.();
  }, [applyCameraPreset]);

  // Handle animation clip selection
  const switchAnimation = (index: number) => {
    if (!animationActionsRef.current.length || !mixerRef.current) return;
    
    // Stop other actions
    animationActionsRef.current.forEach((action, i) => {
      if (i === index) {
        action.reset().fadeIn(0.2).play();
      } else {
        action.fadeOut(0.2);
      }
    });
    setCurrentAnimIndex(index);
    setIsPlayingAnimation(true);
  };

  // Toggle animation playback
  const togglePlayAnimation = () => {
    if (!mixerRef.current || !animationActionsRef.current[currentAnimIndex]) return;
    const currentAction = animationActionsRef.current[currentAnimIndex];
    if (isPlayingAnimation) {
      currentAction.paused = true;
      setIsPlayingAnimation(false);
    } else {
      currentAction.paused = false;
      currentAction.play();
      setIsPlayingAnimation(true);
    }
  };

  // Toggle wireframe mode
  const handleToggleWireframe = () => {
    const nextState = !wireframe;
    setWireframe(nextState);

    if (currentCompanionRef.current) {
      currentCompanionRef.current.setWireframe(nextState);
    }

    if (importedModelGroupRef.current) {
      importedModelGroupRef.current.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) {
          const mesh = child as THREE.Mesh;
          if (Array.isArray(mesh.material)) {
            mesh.material.forEach((m: any) => {
              if ('wireframe' in m) m.wireframe = nextState;
            });
          } else if (mesh.material && 'wireframe' in mesh.material) {
            (mesh.material as any).wireframe = nextState;
          }
        }
      });
    }
  };

  // Initialize Three.js scene once on mount
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Software WebGL Guard (read from renderer string as per directives)
    const isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return false;
      }
    })();

    // 2. Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x07070e);
    scene.fog = new THREE.FogExp2(0x07070e, 0.05);

    // 3. Camera
    const aspect = container.clientWidth / (container.clientHeight || 1);
    const camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 100);
    camera.position.set(0, 1.6, 4.2);
    cameraRef.current = camera;

    // 4. WebGL Renderer
    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    rendererRef.current = renderer;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(renderer.domElement);

    // 5. Studio Environment Map (PMREMGenerator RoomEnvironment)
    try {
      const pmremGenerator = new THREE.PMREMGenerator(renderer);
      scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
      pmremGenerator.dispose();
    } catch (e) {
      console.warn('RoomEnvironment setup error:', e);
    }

    // 6. Orbit Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controlsRef.current = controls;
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.08;
    controls.target.set(0, 1.4, 0);
    controls.minDistance = 1.2;
    controls.maxDistance = 8.5;
    controls.maxPolarAngle = Math.PI / 2 + 0.05; // Don't go below pedestal floor
    controls.autoRotate = false;
    controls.autoRotateSpeed = 1.8;

    // 7. Ground Grid & Contact Shadow Plane
    const gridHelper = new THREE.GridHelper(10, 20, 0xff2d78, 0x1e1e38);
    gridHelper.position.y = 0.005;
    scene.add(gridHelper);

    // Contact shadow plane
    const shadowGeo = new THREE.PlaneGeometry(3.5, 3.5);
    const shadowMat = new THREE.MeshBasicMaterial({
      color: 0x000000,
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
    });
    const shadowPlane = new THREE.Mesh(shadowGeo, shadowMat);
    shadowPlane.rotation.x = -Math.PI / 2;
    shadowPlane.position.y = 0.01;
    scene.add(shadowPlane);

    // 8. Dynamic Lights Group
    const lightsGroup = new THREE.Group();
    lightsGroupRef.current = lightsGroup;
    scene.add(lightsGroup);
    updateLightingPreset(activeLightingPreset);

    // 9. Mount Default Procedural 002 Avatar
    const proceduralCompanion = createProcedural002();
    currentCompanionRef.current = proceduralCompanion;
    scene.add(proceduralCompanion.group);

    // If an external GLB buffer was already supplied, load it immediately
    if (externalGlbBufferRef.current) {
      lastLoadedBufferRef.current = externalGlbBufferRef.current.buffer;
      loadGlbFromArrayBuffer(externalGlbBufferRef.current.buffer, externalGlbBufferRef.current.name);
    }

    // 10. Animation Loop
    let frameId = 0;
    const clock = new THREE.Clock();

    function tick() {
      const delta = Math.min(clock.getDelta(), 0.1);
      const elapsedTime = clock.getElapsedTime();

      // Camera preset smooth damping transition
      if (cameraTargetRef.current.transitioning) {
        camera.position.lerp(cameraTargetRef.current.pos, 0.08);
        controls.target.lerp(cameraTargetRef.current.lookAt, 0.08);

        if (camera.position.distanceTo(cameraTargetRef.current.pos) < 0.02) {
          cameraTargetRef.current.transitioning = false;
        }
      }

      // Update controls
      controls.update();

      // Update procedural companion idle motion & blinking
      if (currentCompanionRef.current && currentCompanionRef.current.group.visible) {
        currentCompanionRef.current.update(elapsedTime, delta, {
          idleEnabled: idleEnabledRef.current,
          blinkEnabled: blinkEnabledRef.current,
          headMovementEnabled: headMovementEnabledRef.current,
        });
      }

      // Update imported GLTF animations, rigging, and morph targets
      if (importedModelGroupRef.current && importedModelGroupRef.current.visible) {
        // Animation mixer clips
        if (mixerRef.current && idleEnabledRef.current) {
          mixerRef.current.update(delta);
        }

        // Idle breathing on imported mesh
        if (idleEnabledRef.current) {
          const basePos = baseModelPosRef.current;
          const breathFloat = Math.sin(elapsedTime * 2.2) * 0.012;
          importedModelGroupRef.current.position.y = basePos.y + breathFloat;
        } else {
          // Return smoothly to base position without jumping
          importedModelGroupRef.current.position.y += (baseModelPosRef.current.y - importedModelGroupRef.current.position.y) * 0.1;
        }

        // Head movement if bone exists
        if (headBoneRef.current && headMovementEnabledRef.current) {
          const tiltY = Math.sin(elapsedTime * 0.8) * 0.06;
          const tiltZ = Math.sin(elapsedTime * 0.6) * 0.03;
          const tiltQuat = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, tiltY, tiltZ));
          headBoneRef.current.quaternion.copy(restHeadQuatRef.current).multiply(tiltQuat);
        } else if (headBoneRef.current && !headMovementEnabledRef.current) {
          headBoneRef.current.quaternion.slerp(restHeadQuatRef.current, 0.1);
        }

        // Eye blinking morph targets
        if (blinkMorphTargetsRef.current.length > 0) {
          const bState = blinkStateRef.current;
          if (blinkEnabledRef.current) {
            if (elapsedTime > bState.nextBlinkTime && bState.phase === 'open') {
              bState.phase = 'closing';
              bState.progress = 0;
            }

            if (bState.phase === 'closing') {
              bState.progress += delta * 14;
              if (bState.progress >= 1) {
                bState.progress = 1;
                bState.phase = 'opening';
              }
            } else if (bState.phase === 'opening') {
              bState.progress -= delta * 14;
              if (bState.progress <= 0) {
                bState.progress = 0;
                bState.phase = 'open';
                const isDouble = Math.random() < 0.25;
                bState.nextBlinkTime = elapsedTime + (isDouble ? 0.25 : 2.8 + Math.random() * 2.0);
              }
            }

            blinkMorphTargetsRef.current.forEach(({ mesh, index }) => {
              if (mesh.morphTargetInfluences) {
                mesh.morphTargetInfluences[index] = bState.progress;
              }
            });
          } else {
            bState.phase = 'open';
            bState.progress = 0;
            blinkMorphTargetsRef.current.forEach(({ mesh, index }) => {
              if (mesh.morphTargetInfluences) {
                mesh.morphTargetInfluences[index] = 0;
              }
            });
          }
        }
      }

      // Render
      renderer.render(scene, camera);

      frameId = requestAnimationFrame(tick);
    }

    frameId = requestAnimationFrame(tick);

    // 11. Resize Observer for fluid responsiveness on mobile & orientation changes
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        if (width > 0 && height > 0) {
          camera.aspect = width / height;
          camera.updateProjectionMatrix();
          renderer.setSize(width, height);
        }
      }
    });

    resizeObserver.observe(container);

    // Cleanup on unmount
    return () => {
      cancelAnimationFrame(frameId);
      resizeObserver.disconnect();

      if (controlsRef.current) {
        controlsRef.current.dispose();
      }

      if (rendererRef.current) {
        rendererRef.current.dispose();
        if (container.contains(rendererRef.current.domElement)) {
          container.removeChild(rendererRef.current.domElement);
        }
      }

      // Dispose scene objects
      scene.traverse((obj) => {
        if ((obj as THREE.Mesh).isMesh) {
          const mesh = obj as THREE.Mesh;
          mesh.geometry?.dispose();
          if (Array.isArray(mesh.material)) {
            mesh.material.forEach((m) => m.dispose());
          } else {
            mesh.material?.dispose();
          }
        }
      });
    };
  }, []); // Run once on mount

  // Sync auto rotate
  useEffect(() => {
    if (controlsRef.current) {
      controlsRef.current.autoRotate = autoRotate;
    }
  }, [autoRotate]);

  // Sync camera preset prop
  useEffect(() => {
    if (activeCameraPreset) {
      applyCameraPreset(activeCameraPreset, false);
    }
  }, [activeCameraPreset, applyCameraPreset]);

  // Sync lighting preset prop
  useEffect(() => {
    updateLightingPreset(activeLightingPreset);
  }, [activeLightingPreset, updateLightingPreset]);

  return (
    <div className={`relative w-full h-full overflow-hidden select-none bg-[#07070e] ${className}`}>
      {/* 3D Canvas Mount Point */}
      <div 
        ref={mountRef} 
        className="w-full h-full cursor-grab active:cursor-grabbing touch-none"
      />

      {/* Hidden file input for .glb models */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".glb,.gltf"
        onChange={handleFileInputChange}
        className="hidden"
        aria-label="Upload 3D GLB model"
      />

      {/* Top Status & Subject Pill (Non-intrusive) */}
      <div className="absolute top-4 left-4 right-4 flex items-center justify-between pointer-events-none z-10">
        <div className="bg-[#0f0f1d]/85 border border-[#ff2d78]/30 backdrop-blur-md px-3.5 py-1.5 rounded-full flex items-center gap-2 pointer-events-auto shadow-lg shadow-black/40">
          <span className="w-2.5 h-2.5 rounded-full bg-[#ff2d78] shadow-[0_0_8px_#ff2d78]" />
          <span className="text-xs font-cyber tracking-wider text-slate-200 uppercase font-semibold">
            {modelName.length > 24 ? `${modelName.slice(0, 24)}...` : modelName}
          </span>
          <span className="text-[10px] bg-[#ff2d78]/20 text-[#ff70a6] px-1.5 py-0.5 rounded font-mono-code uppercase">
            {currentModelSource === 'procedural' ? 'Procedural' : 'Custom GLB'}
          </span>
        </div>

        {/* Reset / Clear Button if custom model is uploaded */}
        {currentModelSource === 'glb' && (
          <button
            onClick={resetToProcedural002}
            className="bg-[#181829]/90 hover:bg-[#25253d] border border-slate-700/60 text-slate-200 text-xs px-3 py-1.5 rounded-full flex items-center gap-1.5 transition-all pointer-events-auto active:scale-95"
            title="Reset to 002 companion avatar"
          >
            <RefreshCw className="w-3.5 h-3.5 text-[#ff2d78]" />
            <span className="hidden sm:inline">Reset 002</span>
          </button>
        )}
      </div>

      {/* Loading Overlay */}
      {loadingModel && (
        <div className="absolute inset-0 bg-[#07070e]/85 backdrop-blur-sm flex flex-col items-center justify-center z-30">
          <div className="w-12 h-12 border-3 border-[#ff2d78]/20 border-t-[#ff2d78] rounded-full animate-spin mb-3" />
          <p className="font-cyber text-slate-200 text-sm tracking-widest uppercase">
            Synthesizing 3D Geometry...
          </p>
          <p className="text-xs text-slate-400 mt-1 font-mono-code">Parsing binary glTF buffers</p>
        </div>
      )}

      {/* Load Error Toast */}
      {loadError && (
        <div className="absolute top-16 left-4 right-4 bg-red-950/90 border border-red-500/50 text-red-200 px-4 py-2.5 rounded-xl text-xs z-30 flex items-center justify-between shadow-xl">
          <span>{loadError}</span>
          <button 
            onClick={() => setLoadError(null)}
            className="ml-2 font-bold text-red-300 hover:text-white px-1.5"
          >
            ✕
          </button>
        </div>
      )}

      {/* Bottom Unified Control Dock (Unobstructed Viewport Standard) */}
      {interactiveControls && (
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 w-[94%] max-w-lg z-20 pointer-events-auto transition-transform duration-300">
          {/* Collapse/Expand Toggle Tab */}
          <div className="flex justify-center -mb-2">
            <button
              onClick={() => setControlsCollapsed(!controlsCollapsed)}
              className="bg-[#10101d] border border-[#ff2d78]/30 hover:border-[#ff2d78]/60 text-slate-300 hover:text-white px-3 py-0.5 rounded-t-lg text-[11px] font-cyber tracking-widest uppercase flex items-center gap-1 shadow-md transition-colors"
            >
              {controlsCollapsed ? '▲ Show 3D Controls' : '▼ Hide Controls'}
            </button>
          </div>

          {!controlsCollapsed && (
            <div className="bg-[#0d0d1b]/90 border border-[#ff2d78]/25 backdrop-blur-md rounded-2xl p-2.5 shadow-2xl shadow-black/60">
              {/* Row 1: Quick Action Pills */}
              <div className="flex items-center justify-between gap-1 mb-2">
                {/* Camera Presets */}
                <div className="flex items-center gap-1 overflow-x-auto py-0.5">
                  <button
                    onClick={() => applyCameraPreset('front', true)}
                    className={`px-2 py-1 rounded-lg text-[11px] font-cyber transition-all ${
                      activeCameraPreset === 'front' 
                        ? 'bg-[#ff2d78] text-white shadow-[0_0_10px_#ff2d78]' 
                        : 'bg-[#181828] text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Front
                  </button>
                  <button
                    onClick={() => applyCameraPreset('portrait', true)}
                    className={`px-2 py-1 rounded-lg text-[11px] font-cyber transition-all ${
                      activeCameraPreset === 'portrait' 
                        ? 'bg-[#ff2d78] text-white shadow-[0_0_10px_#ff2d78]' 
                        : 'bg-[#181828] text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Portrait
                  </button>
                  <button
                    onClick={() => applyCameraPreset('isometric', true)}
                    className={`px-2 py-1 rounded-lg text-[11px] font-cyber transition-all ${
                      activeCameraPreset === 'isometric' 
                        ? 'bg-[#ff2d78] text-white shadow-[0_0_10px_#ff2d78]' 
                        : 'bg-[#181828] text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Iso
                  </button>
                  <button
                    onClick={() => applyCameraPreset('full', true)}
                    className={`px-2 py-1 rounded-lg text-[11px] font-cyber transition-all ${
                      activeCameraPreset === 'full' 
                        ? 'bg-[#ff2d78] text-white shadow-[0_0_10px_#ff2d78]' 
                        : 'bg-[#181828] text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Full
                  </button>
                </div>

                {/* Toggles: Auto Rotate & Wireframe */}
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setAutoRotate(!autoRotate)}
                    className={`p-1.5 rounded-lg text-xs transition-colors ${
                      autoRotate 
                        ? 'bg-[#9333ea] text-white shadow-[0_0_10px_#9333ea]' 
                        : 'bg-[#181828] text-slate-400 hover:text-slate-200'
                    }`}
                    title="Auto-Rotate View"
                  >
                    <Rotate3d className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={handleToggleWireframe}
                    className={`p-1.5 rounded-lg text-xs transition-colors ${
                      wireframe 
                        ? 'bg-[#06b6d4] text-white shadow-[0_0_10px_#06b6d4]' 
                        : 'bg-[#181828] text-slate-400 hover:text-slate-200'
                    }`}
                    title="Wireframe Mesh Mode"
                  >
                    <Eye className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Row 2: Character Animation Controls (Phase 1) */}
              <div className="flex items-center justify-between gap-1 border-t border-slate-800/80 pt-1.5 pb-1">
                <div className="flex items-center gap-1 overflow-x-auto py-0.5">
                  {/* Idle Animation Toggle */}
                  <button
                    onClick={toggleIdle}
                    className={`px-2 py-1 rounded-lg text-[10px] font-cyber flex items-center gap-1.5 transition-all ${
                      effectiveIdle
                        ? 'bg-[#ff2d78]/25 text-[#ff70a6] border border-[#ff2d78]/50 shadow-[0_0_8px_rgba(255,45,120,0.3)]'
                        : 'bg-[#141424] text-slate-500 border border-slate-800'
                    }`}
                    title="Toggle Natural Idle Animation & Breathing"
                  >
                    <span className={`w-1.5 h-1.5 rounded-full ${effectiveIdle ? 'bg-[#ff2d78] shadow-[0_0_6px_#ff2d78]' : 'bg-slate-600'}`} />
                    <span>Idle: {effectiveIdle ? 'ON' : 'OFF'}</span>
                  </button>

                  {/* Eye Blink Toggle */}
                  <button
                    onClick={toggleBlink}
                    className={`px-2 py-1 rounded-lg text-[10px] font-cyber flex items-center gap-1.5 transition-all ${
                      effectiveBlink && modelRigInfo.hasBlinkSupport
                        ? 'bg-[#06b6d4]/25 text-[#22d3ee] border border-[#06b6d4]/50 shadow-[0_0_8px_rgba(6,182,212,0.3)]'
                        : 'bg-[#141424] text-slate-500 border border-slate-800'
                    }`}
                    title={modelRigInfo.hasBlinkSupport ? "Toggle Automatic Eye Blinking" : "Current model has no eye morph targets"}
                  >
                    <span className={`w-1.5 h-1.5 rounded-full ${effectiveBlink && modelRigInfo.hasBlinkSupport ? 'bg-[#06b6d4] shadow-[0_0_6px_#06b6d4]' : 'bg-slate-600'}`} />
                    <span>Blink: {!modelRigInfo.hasBlinkSupport ? 'N/A' : effectiveBlink ? 'ON' : 'OFF'}</span>
                  </button>

                  {/* Head Movement Toggle */}
                  <button
                    onClick={toggleHeadMovement}
                    className={`px-2 py-1 rounded-lg text-[10px] font-cyber flex items-center gap-1.5 transition-all ${
                      effectiveHeadMovement
                        ? 'bg-[#9333ea]/25 text-[#c084fc] border border-[#9333ea]/50 shadow-[0_0_8px_rgba(147,51,234,0.3)]'
                        : 'bg-[#141424] text-slate-500 border border-slate-800'
                    }`}
                    title="Toggle Subtle Head Tilt"
                  >
                    <span className={`w-1.5 h-1.5 rounded-full ${effectiveHeadMovement ? 'bg-[#9333ea] shadow-[0_0_6px_#9333ea]' : 'bg-slate-600'}`} />
                    <span>Head: {effectiveHeadMovement ? 'ON' : 'OFF'}</span>
                  </button>
                </div>

                {/* Reset Pose Button */}
                <button
                  onClick={handleResetPose}
                  className="px-2 py-1 rounded-lg text-[10px] font-cyber bg-[#1a1a2e] hover:bg-[#252542] border border-slate-700/80 text-slate-200 hover:text-white flex items-center gap-1 transition-all active:scale-95 shadow-sm shrink-0"
                  title="Reset Character Transforms and Rest Pose"
                >
                  <RotateCw className="w-3 h-3 text-[#ff2d78]" />
                  <span>Reset Pose</span>
                </button>
              </div>

              {/* Row 3: GLB Upload Button & Animation Player (if present) */}
              <div className="flex items-center justify-between gap-2 border-t border-slate-800/80 pt-2">
                {showModelUploadButton && (
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="flex-1 bg-gradient-to-r from-[#ff2d78] to-[#9333ea] hover:brightness-110 text-white font-cyber text-xs py-1.5 px-3 rounded-xl flex items-center justify-center gap-1.5 transition-all shadow-md active:scale-98"
                  >
                    <UploadCloud className="w-3.5 h-3.5" />
                    <span>Import .glb Model</span>
                  </button>
                )}

                {/* If model has animations, show animation controls */}
                {hasAnimations && (
                  <div className="flex items-center gap-1 bg-[#151525] px-2 py-1 rounded-xl border border-slate-800">
                    <button
                      onClick={togglePlayAnimation}
                      className="text-[#ff2d78] hover:text-white p-1"
                      title={isPlayingAnimation ? 'Pause Animation' : 'Play Animation'}
                    >
                      {isPlayingAnimation ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                    </button>
                    {animationNames.length > 1 && (
                      <select
                        value={currentAnimIndex}
                        onChange={(e) => switchAnimation(Number(e.target.value))}
                        className="bg-transparent text-[10px] text-slate-300 font-mono-code focus:outline-none"
                      >
                        {animationNames.map((name, idx) => (
                          <option key={idx} value={idx} className="bg-[#10101d] text-slate-200">
                            {name}
                          </option>
                        ))}
                      </select>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
