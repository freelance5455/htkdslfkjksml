import React from 'react';
import {
  Factory,
  Wrench,
  ShieldAlert,
  PackageCheck,
  CheckCircle2,
  Briefcase,
  Layers,
  Cpu,
  Truck,
  HardHat,
  Cog,
  FileCheck
} from 'lucide-react';

interface Props {
  name: string;
  className?: string;
}

export const SectorIcon: React.FC<Props> = ({ name, className = 'w-4 h-4' }) => {
  switch (name) {
    case 'Factory':
      return <Factory className={className} />;
    case 'Wrench':
      return <Wrench className={className} />;
    case 'ShieldAlert':
      return <ShieldAlert className={className} />;
    case 'PackageCheck':
      return <PackageCheck className={className} />;
    case 'CheckCircle2':
      return <CheckCircle2 className={className} />;
    case 'Briefcase':
      return <Briefcase className={className} />;
    case 'Cpu':
      return <Cpu className={className} />;
    case 'Truck':
      return <Truck className={className} />;
    case 'HardHat':
      return <HardHat className={className} />;
    case 'Cog':
      return <Cog className={className} />;
    case 'FileCheck':
      return <FileCheck className={className} />;
    default:
      return <Layers className={className} />;
  }
};
