import React, { useState } from 'react';
import {
  Film,
  Sparkles,
  Plus,
  RefreshCw,
  Trash2,
  TrendingUp,
  Award,
  DollarSign,
  User,
  Sliders,
  Check,
} from 'lucide-react';
import { GENRE_REGISTRY } from '../data/initialData';
import { ProgramGenre, Talent, TVProgram } from '../types/game';
import { soundFx } from '../utils/audio';

interface ProductionsStudioProps {
  programs: TVProgram[];
  talents: Talent[];
  cash: number;
  onCreateProgram: (newProg: Omit<TVProgram, 'id' | 'episodesAired' | 'ratingAverage'>) => void;
  onUpgradeScript: (programId: string, cost: number) => void;
  onCancelProgram: (programId: string) => void;
  onRenewSeason: (programId: string) => void;
}

export const ProductionsStudio: React.FC<ProductionsStudioProps> = ({
  programs,
  talents,
  cash,
  onCreateProgram,
  onUpgradeScript,
  onCancelProgram,
  onRenewSeason,
}) => {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newGenre, setNewGenre] = useState<ProgramGenre>('novela');
  const [budgetTier, setBudgetTier] = useState<'low' | 'med' | 'high'>('med');
  const [selectedTalentId, setSelectedTalentId] = useState<string>('');

  const hiredTalents = talents.filter((t) => t.isHired);

  const budgetMultipliers = {
    low: { costMult: 0.7, qualBonus: -10, label: 'Produção Econômica' },
    med: { costMult: 1.0, qualBonus: 0, label: 'Produção Padrão' },
    high: { costMult: 1.6, qualBonus: 20, label: 'Superprodução de Ponta' },
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const base = GENRE_REGISTRY[newGenre];
    const budget = budgetMultipliers[budgetTier];
    const cost = Math.round(base.baseCost * budget.costMult);

    if (cash < cost) {
      return;
    }

    const assignedTalent = hiredTalents.find((t) => t.id === selectedTalentId);
    const talentCharismaBonus = assignedTalent ? Math.round(assignedTalent.charisma * 0.25) : 0;
    const initialQuality = Math.min(100, Math.max(30, base.basePotential * 3 + budget.qualBonus + talentCharismaBonus));

    soundFx.playVictory();
    onCreateProgram({
      title: newTitle.trim(),
      genre: newGenre,
      assignedSlot: null,
      assignedTalentId: selectedTalentId || null,
      quality: initialQuality,
      hype: 65,
      productionCost: cost,
      seasonTotal: newGenre === 'novela' ? 90 : newGenre === 'reality' ? 45 : 60,
      isLive: ['jornalismo', 'auditorio', 'esporte'].includes(newGenre),
      activeScriptLevel: budgetTier === 'high' ? 2 : 1,
    });

    setNewTitle('');
    setShowCreateModal(false);
  };

  return (
    <div className="w-full h-full flex flex-col gap-3 select-none overflow-y-auto pr-1">
      {/* Top Banner - Compact */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Film className="w-4 h-4 text-amber-400" />
            Central de Teledramaturgia & Estúdios
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Crie novos sucessos da TV, contrate roteiristas de peso e renove temporadas para manter os índices do IBOPE no topo.
          </p>
        </div>

        <button
          onClick={() => {
            soundFx.playClick();
            setShowCreateModal(true);
          }}
          className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wide transition-all shadow-md shadow-amber-950/40 flex items-center gap-1.5 cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Produzir Novo Programa</span>
        </button>
      </div>

      {/* Program Cards Catalog - Compact */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {programs.map((prog) => {
          const genreInfo = GENRE_REGISTRY[prog.genre];
          const talent = talents.find((t) => t.id === prog.assignedTalentId);
          const scriptUpgradeCost = prog.activeScriptLevel * 6000;
          const isSeasonCompleted = prog.episodesAired >= prog.seasonTotal;

          return (
            <div
              key={prog.id}
              className="rounded-2xl bg-slate-900/90 border border-slate-800 p-5 flex flex-col justify-between shadow-lg"
            >
              <div>
                {/* Header with Genre Pill & Status */}
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <span
                    className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded"
                    style={{ backgroundColor: `${genreInfo.color}20`, color: genreInfo.color }}
                  >
                    {genreInfo.name}
                  </span>
                  <span className="text-[11px] font-mono text-slate-400">
                    {prog.assignedSlot ? (
                      <span className="text-emerald-400 font-bold">
                        No ar ({prog.assignedSlot.toUpperCase()})
                      </span>
                    ) : (
                      <span className="text-slate-500">No Acervo</span>
                    )}
                  </span>
                </div>

                {/* Title */}
                <h3 className="text-base font-bold text-white mt-3 truncate">{prog.title}</h3>

                {/* Host / Talent Assignment */}
                <div className="flex items-center gap-2 mt-2 text-xs text-slate-300">
                  <div className="w-6 h-6 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-xs">
                    {talent?.avatarEmoji || '👤'}
                  </div>
                  <span className="font-medium truncate">
                    {talent ? talent.name : 'Sem elenco principal escalado'}
                  </span>
                </div>

                {/* Quality & Season Bars */}
                <div className="mt-4 space-y-2.5">
                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-slate-400">Índice de Qualidade:</span>
                      <span className="font-mono font-bold text-amber-400">{prog.quality}%</span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-amber-500 to-yellow-400"
                        style={{ width: `${prog.quality}%` }}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-slate-400">Episódios da Temporada:</span>
                      <span className="font-mono text-slate-300">
                        {prog.episodesAired} / {prog.seasonTotal}
                      </span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className="h-full bg-blue-500"
                        style={{ width: `${Math.min(100, (prog.episodesAired / prog.seasonTotal) * 100)}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-3 text-xs text-slate-400 flex items-center justify-between">
                  <span>Custo p/ Exibição:</span>
                  <span className="font-mono font-bold text-slate-200">
                    R$ {prog.productionCost.toLocaleString('pt-BR')}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-5 pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                {isSeasonCompleted ? (
                  <button
                    onClick={() => {
                      soundFx.playVictory();
                      onRenewSeason(prog.id);
                    }}
                    className="flex-1 py-1.5 px-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase transition-colors flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Renovar Nova Temporada</span>
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      if (cash >= scriptUpgradeCost) {
                        soundFx.playCash();
                        onUpgradeScript(prog.id, scriptUpgradeCost);
                      }
                    }}
                    disabled={cash < scriptUpgradeCost}
                    className={`flex-1 min-h-[44px] py-2 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 ${
                      cash >= scriptUpgradeCost
                        ? 'bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700'
                        : 'bg-slate-900 text-slate-500 cursor-not-allowed opacity-60'
                    }`}
                    title={`Aumenta qualidade em +8%. Custo: R$ ${scriptUpgradeCost.toLocaleString('pt-BR')}`}
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>{cash >= scriptUpgradeCost ? `Refinar Roteiro (R$ ${scriptUpgradeCost.toLocaleString('pt-BR')})` : 'Sem Caixa'}</span>
                  </button>
                )}

                <button
                  onClick={() => {
                    soundFx.playClick();
                    onCancelProgram(prog.id);
                  }}
                  className="min-h-[44px] min-w-[44px] p-2.5 rounded-xl bg-slate-950 hover:bg-red-950/50 border border-slate-800 hover:border-red-800 text-slate-400 hover:text-red-400 transition-all flex items-center justify-center cursor-pointer active:scale-95"
                  title="Cancelar e arquivar atração"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal: Produzir Novo Programa */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleCreateSubmit}
            className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl flex flex-col max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Film className="w-4 h-4 text-amber-400" />
                Lançar Nova Produção de TV
              </h3>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-white text-xs cursor-pointer"
              >
                Cancelar
              </button>
            </div>

            <div className="space-y-4 my-4">
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Título da Atração
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="Ex: A Grande Família do Brasil, Jornal da Noite..."
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                  Formato / Gênero Televisivo
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {Object.values(GENRE_REGISTRY).map((g) => (
                    <button
                      key={g.id}
                      type="button"
                      onClick={() => {
                        soundFx.playClick();
                        setNewGenre(g.id);
                      }}
                      className={`p-2.5 rounded-lg border text-xs font-medium text-left transition-all cursor-pointer ${
                        newGenre === g.id
                          ? 'border-amber-400 bg-amber-500/10 text-white'
                          : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <div className="font-bold text-white truncate">{g.name}</div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        Base: R$ {g.baseCost.toLocaleString('pt-BR')}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
                  Orçamento & Cenografia
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['low', 'med', 'high'] as const).map((tier) => {
                    const info = budgetMultipliers[tier];
                    return (
                      <button
                        key={tier}
                        type="button"
                        onClick={() => {
                          soundFx.playClick();
                          setBudgetTier(tier);
                        }}
                        className={`p-2.5 rounded-lg border text-xs text-left transition-all cursor-pointer ${
                          budgetTier === tier
                            ? 'border-amber-400 bg-amber-500/10 text-white'
                            : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                        }`}
                      >
                        <div className="font-bold text-white">{info.label}</div>
                        <div className="text-[10px] text-amber-400 mt-1">
                          {tier === 'low' ? 'Econômico' : tier === 'med' ? 'Equilibrado' : '+Qualidade'}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Escalar Estrela / Apresentador (Opcional)
                </label>
                <select
                  value={selectedTalentId}
                  onChange={(e) => setSelectedTalentId(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white text-sm focus:outline-none focus:border-amber-400"
                >
                  <option value="">Nenhum (Produção Autônoma)</option>
                  {hiredTalents.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} ({t.role} · Carisma {t.charisma}%)
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-slate-500 mt-1">
                  Estrelas contratadas aumentam o carisma e a fidelidade da atração no ar.
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
              <div className="text-xs">
                <span className="text-slate-400">Investimento Estimado: </span>
                <span className="font-mono font-bold text-amber-400 text-sm">
                  R$ {(GENRE_REGISTRY[newGenre].baseCost * budgetMultipliers[budgetTier].costMult).toLocaleString('pt-BR')}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 text-xs text-slate-300 hover:text-white cursor-pointer"
                >
                  Voltar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wide cursor-pointer shadow-md shadow-amber-950/50"
                >
                  Lançar nos Estúdios
                </button>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
