import { useState } from 'react';
import { useGame } from '../context/GameContext';
import { formatNumber } from '../utils/formatters';
import { Check, Gem } from 'lucide-react';
import fantasyTreasureVaultImg from '../assets/images/fantasy_treasure_vault_1791261393886.jpg';

export function UpgradesTab() {
  const { upgrades, buyUpgrade, gold, archons, numberFormat } = useGame();
  const [filter, setFilter] = useState<'ALL' | 'GOLD' | 'ARCHON'>('ALL');

  const filteredUpgrades = upgrades.filter((u) => {
    if (filter === 'ALL') return true;
    return u.currency === filter;
  });

  const unpurchasedCount = upgrades.filter((u) => !u.purchased).length;
  const purchasedCount = upgrades.filter((u) => u.purchased).length;

  return (
    <div className="space-y-6">
      {/* Visual Treasure Vault Header Banner */}
      <div className="relative rounded-3xl overflow-hidden border border-amber-900/40 shadow-xl bg-slate-900 max-h-48 md:max-h-56">
        <img
          src={fantasyTreasureVaultImg}
          alt="Fantasy Treasure Vault"
          className="w-full h-48 md:h-56 object-cover object-center opacity-45 hover:opacity-55 transition-opacity"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />
        <div className="absolute bottom-4 left-4 right-4 sm:bottom-6 sm:left-6 flex flex-col sm:flex-row items-start sm:items-end justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-amber-400 text-xs font-semibold uppercase tracking-wider mb-1">
              <Gem className="w-4 h-4" />
              <span>Royal Treasury Archives</span>
            </div>
            <h2 className="font-cinzel text-xl sm:text-2xl md:text-3xl font-extrabold text-amber-200">
              Grimoire & Relic Upgrades
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl mt-0.5">
              Acquire royal decrees, ancient artifacts, and celestial covenants to supercharge profits across your entire kingdom!
            </p>
          </div>

          {/* Filter segment tabs */}
          <div className="flex items-center gap-1 p-1 bg-slate-950/80 border border-slate-800 rounded-xl">
            <button
              onClick={() => setFilter('ALL')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                filter === 'ALL'
                  ? 'bg-amber-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All ({upgrades.length})
            </button>
            <button
              onClick={() => setFilter('GOLD')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                filter === 'GOLD'
                  ? 'bg-amber-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Gold Decrees
            </button>
            <button
              onClick={() => setFilter('ARCHON')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                filter === 'ARCHON'
                  ? 'bg-amber-500 text-slate-950 shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Celestial Relics
            </button>
          </div>
        </div>
      </div>

      {/* Upgrades Count Status */}
      <div className="flex items-center justify-between text-xs text-slate-400 px-1">
        <div>
          Showing {filteredUpgrades.length} upgrades (Purchased: {purchasedCount} / Remaining: {unpurchasedCount})
        </div>
      </div>

      {/* Upgrades Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredUpgrades.map((upg) => {
          const canAfford =
            upg.currency === 'GOLD' ? gold >= upg.cost : archons >= upg.cost;

          return (
            <div
              key={upg.id}
              className={`rounded-2xl border p-4 sm:p-5 transition-all flex flex-col justify-between ${
                upg.purchased
                  ? 'border-emerald-500/30 bg-emerald-950/15 opacity-85'
                  : upg.currency === 'ARCHON'
                  ? 'border-violet-500/30 bg-violet-950/20 hover:border-violet-500/50'
                  : 'border-slate-800 bg-slate-900/80 hover:bg-slate-900 hover:border-slate-700'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-cinzel text-base font-bold text-slate-100">
                        {upg.name}
                      </h3>
                      {upg.currency === 'ARCHON' && (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-violet-500/20 border border-violet-400/40 text-violet-300">
                          Celestial
                        </span>
                      )}
                    </div>
                    <span className="inline-block mt-0.5 text-xs font-semibold text-amber-400">
                      {upg.subtitle}
                    </span>
                  </div>

                  {upg.purchased && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 text-xs font-semibold border border-emerald-500/30 shrink-0">
                      <Check className="w-3.5 h-3.5" />
                      <span>Unlocked</span>
                    </span>
                  )}
                </div>

                <p className="text-xs text-slate-300 mt-2">
                  {upg.description}
                </p>

                <p className="text-[11px] text-slate-400 italic mt-2 border-l border-slate-700 pl-2">
                  "{upg.lore}"
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between gap-3">
                <div className="text-xs">
                  <div className="text-slate-500">
                    {upg.currency === 'GOLD' ? 'Required Gold' : 'Archon Sacrifice'}
                  </div>
                  <div
                    className={`font-semibold tabular-nums ${
                      upg.currency === 'GOLD' ? 'text-amber-300' : 'text-violet-300'
                    }`}
                  >
                    {formatNumber(upg.cost, numberFormat)}{' '}
                    {upg.currency === 'GOLD' ? 'Gold' : 'Archons'}
                  </div>
                </div>

                {upg.purchased ? (
                  <div className="text-xs text-emerald-400 font-medium flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" />
                    <span>Permanent Multiplier Active</span>
                  </div>
                ) : (
                  <button
                    onClick={() => buyUpgrade(upg.id)}
                    disabled={!canAfford}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      canAfford
                        ? upg.currency === 'ARCHON'
                          ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white shadow-md shadow-violet-950/40 active:scale-95'
                          : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-md shadow-amber-950/40 active:scale-95'
                        : 'bg-slate-800 text-slate-500 border border-slate-700/60 cursor-not-allowed opacity-75'
                    }`}
                  >
                    {canAfford ? 'Acquire Relic' : 'Not Enough Funds'}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
