import React, { useState } from 'react';
import { Check, CreditCard, Crown, ShieldCheck, Tag, X } from 'lucide-react';
import { apiRequest } from '../lib/api';
import type {
  MembershipInfo,
  PaymentProviderStatus,
  SubscriptionPlan,
  SystemLimitsRow,
} from '../types/studio';

interface PremiumViewProps {
  plans: SubscriptionPlan[];
  limits: SystemLimitsRow[];
  membership: MembershipInfo;
  paymentProvider: PaymentProviderStatus | null;
  upgradeNotice: string | null;
  onDismissNotice: () => void;
  onMembershipUpdated: () => Promise<void>;
}

interface CheckoutSession {
  id: string;
  planId: string;
  planName: string;
  originalAmountTry: number;
  discountTry: number;
  appliedPromoCode: string | null;
  amountTry: number;
  currency: string;
  provider: string;
  providerLabel: string;
  isTestMode: boolean;
  providerReference: string;
  signedPayload: string;
  checkoutSignature: string;
}

interface AppliedPromoPreview {
  code: string;
  discountPercent: number;
}

export const PremiumView: React.FC<PremiumViewProps> = ({
  plans,
  limits,
  membership,
  paymentProvider,
  upgradeNotice,
  onDismissNotice,
  onMembershipUpdated,
}) => {
  const [promoInput, setPromoInput] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<AppliedPromoPreview | null>(null);
  const [promoLoading, setPromoLoading] = useState(false);
  const [promoError, setPromoError] = useState<string | null>(null);

  const [checkoutSession, setCheckoutSession] = useState<CheckoutSession | null>(null);
  const [loadingPlanId, setLoadingPlanId] = useState<string | null>(null);
  const [verifying, setVerifying] = useState(false);
  const [resultMsg, setResultMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const freeLimit = limits.find((l) => l.tier === 'free');
  const premiumLimit = limits.find((l) => l.tier === 'premium');

  const handleApplyPromo = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = promoInput.trim().toUpperCase();
    if (!clean) return;
    const referencePlan = plans[0];
    if (!referencePlan) return;

    setPromoLoading(true);
    setPromoError(null);
    try {
      const res = await apiRequest<{
        ok: boolean;
        code: string;
        discountPercent: number;
      }>('/api/promo-codes/validate', {
        method: 'POST',
        body: JSON.stringify({ code: clean, planId: referencePlan.id }),
      });
      setAppliedPromo({ code: res.code, discountPercent: res.discountPercent });
      setPromoInput(res.code);
    } catch (err) {
      setAppliedPromo(null);
      setPromoError(err instanceof Error ? err.message : 'Promosyon kodu geçersiz.');
    } finally {
      setPromoLoading(false);
    }
  };

  const startCheckout = async (planId: string) => {
    setLoadingPlanId(planId);
    setResultMsg(null);
    try {
      const res = await apiRequest<{ payment: CheckoutSession }>('/api/payments/checkout', {
        method: 'POST',
        body: JSON.stringify({
          planId,
          promoCode: appliedPromo ? appliedPromo.code : undefined,
        }),
      });
      setCheckoutSession(res.payment);
    } catch (err) {
      setResultMsg({
        type: 'err',
        text: err instanceof Error ? err.message : 'Ödeme oturumu başlatılamadı.',
      });
    } finally {
      setLoadingPlanId(null);
    }
  };

  const completeWebhookVerification = async (outcome: 'success' | 'failed') => {
    if (!checkoutSession) return;
    setVerifying(true);
    try {
      const res = await apiRequest<{ ok: boolean; status: string; isTestMode: boolean }>(
        '/api/payments/webhook/verify',
        {
          method: 'POST',
          body: JSON.stringify({
            paymentId: checkoutSession.id,
            signedPayload: checkoutSession.signedPayload,
            signature: checkoutSession.checkoutSignature,
            outcome,
          }),
        }
      );

      setCheckoutSession(null);
      if (res.ok) {
        setAppliedPromo(null);
        setPromoInput('');
        await onMembershipUpdated();
        setResultMsg({
          type: 'ok',
          text: res.isTestMode
            ? 'Test / Demo ödeme doğrulandı ve Premium üyeliğiniz hesabınıza tanımlandı.'
            : 'Ödeme başarıyla doğrulandı! Premium üyeliğiniz aktif.',
        });
      } else {
        setResultMsg({
          type: 'err',
          text: 'Ödeme başarısız olarak işaretlendi; üyelik tanımlanmadı.',
        });
      }
    } catch (err) {
      setResultMsg({
        type: 'err',
        text: err instanceof Error ? err.message : 'Ödeme doğrulama hatası.',
      });
    } finally {
      setVerifying(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#CA8A04] dark:text-[#EAB308] mb-2">
            <Crown className="w-4 h-4" />
            <span>HTML TO APK STUDIO Premium</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-bold tracking-tight text-slate-900 dark:text-[#F8FAFC] [text-wrap:balance]">
            Profesyonel APK derleme limitleri ve öncelikli kuyruk erişimi
          </h1>
          <p className="mt-2 text-sm text-slate-600 dark:text-[#94A3B8] max-w-2xl">
            Sunucu tarafında doğrulanan fiyatlandırma ve güvenli ödeme akışı ile hesabınızı Aylık,
            Yıllık veya Kalıcı Premium seviyesine yükseltin.
          </p>
        </div>

        {membership.isPremium && (
          <div className="bg-white dark:bg-[#151D2E] border border-[#EAB308]/40 rounded-xl px-4 py-3 text-xs shrink-0">
            <span className="text-[#CA8A04] dark:text-[#EAB308] font-semibold">Aktif Üyelik: </span>
            <span className="text-slate-900 dark:text-[#F8FAFC] font-medium">
              {membership.planName}
            </span>
            <span className="text-slate-500 dark:text-[#94A3B8] ml-2">
              {membership.isLifetime ? 'Süresiz' : `${membership.remainingDays ?? 0} gün kaldı`}
            </span>
          </div>
        )}
      </div>

      {upgradeNotice && (
        <div className="px-5 py-3.5 rounded-xl bg-[#EAB308]/10 border border-[#EAB308]/35 text-xs text-amber-800 dark:text-[#FCE7A2] flex items-center justify-between gap-4">
          <span>{upgradeNotice}</span>
          <button
            type="button"
            onClick={onDismissNotice}
            className="text-[#CA8A04] dark:text-[#EAB308] font-semibold hover:underline"
          >
            Kapat
          </button>
        </div>
      )}

      {resultMsg && (
        <div
          className={`px-5 py-3.5 rounded-xl border text-xs ${
            resultMsg.type === 'ok'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-700 dark:text-[#22C55E]'
              : 'bg-red-500/10 border-red-500/30 text-red-600 dark:text-[#EF4444]'
          }`}
        >
          {resultMsg.text}
        </div>
      )}

      {/* Payment Provider Notice + Promo Code Bar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
        {paymentProvider && (
          <div className="lg:col-span-7 bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-xl px-5 py-3.5 flex items-center gap-3 text-xs">
            <ShieldCheck className="w-4 h-4 text-[#EAB308] shrink-0" />
            <span className="text-slate-600 dark:text-[#CBD5E1]">
              Ödeme Altyapısı:{' '}
              <strong className="text-slate-900 dark:text-[#F8FAFC]">
                {paymentProvider.label}
              </strong>
              {!paymentProvider.isLiveConfigured &&
                ' — Canlı PayTR / iyzico anahtarları tanımlı olmadığı için ödemeler Test / Demo webhook doğrulama modunda çalışır.'}
            </span>
          </div>
        )}

        <form
          onSubmit={handleApplyPromo}
          className={`${
            paymentProvider ? 'lg:col-span-5' : 'lg:col-span-12'
          } bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-xl px-4 py-3 flex flex-col justify-center gap-2`}
        >
          <div className="flex items-center gap-2">
            <Tag className="w-4 h-4 text-[#6366F1] shrink-0" />
            <input
              type="text"
              value={promoInput}
              onChange={(e) => setPromoInput(e.target.value.toUpperCase())}
              placeholder="Promosyon kodu (varsa)"
              className="flex-1 min-w-0 bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-lg px-3 py-1.5 text-xs font-mono text-slate-900 dark:text-[#F8FAFC] focus:outline-none focus:border-[#6366F1]"
            />
            <button
              type="submit"
              disabled={promoLoading}
              className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-[#6366F1] hover:bg-[#5558E3] disabled:opacity-50 text-white whitespace-nowrap shrink-0"
            >
              {promoLoading ? 'Kontrol...' : 'Kodu Uygula'}
            </button>
          </div>
          {appliedPromo && (
            <div className="flex items-center justify-between text-[11px] text-[#22C55E]">
              <span>
                {appliedPromo.code} uygulandı (%{appliedPromo.discountPercent} indirim)
              </span>
              <button
                type="button"
                onClick={() => {
                  setAppliedPromo(null);
                  setPromoInput('');
                }}
                className="text-slate-500 hover:underline"
              >
                Kaldır
              </button>
            </div>
          )}
          {promoError && <p className="text-[11px] text-[#EF4444]">{promoError}</p>}
        </form>
      </div>

      {/* 3 Plan Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch">
        {plans.map((plan) => {
          const highlighted = Boolean(plan.is_highlighted);
          const isCurrent = membership.isPremium && membership.planCode === plan.code;
          const discountedPrice = appliedPromo
            ? Math.max(1, Math.round((plan.price_try * (100 - appliedPromo.discountPercent)) / 100))
            : plan.price_try;

          return (
            <div
              key={plan.id}
              className={`rounded-2xl p-6 flex flex-col justify-between border ${
                highlighted
                  ? 'bg-white dark:bg-[#151D2E] border-[#EAB308] shadow-sm'
                  : 'bg-white dark:bg-[#151D2E] border-slate-200 dark:border-white/[0.08]'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <h2 className="text-lg font-bold text-slate-900 dark:text-[#F8FAFC] flex items-center gap-2">
                    <Crown
                      className={`w-4 h-4 ${
                        highlighted ? 'text-[#EAB308]' : 'text-[#6366F1]'
                      }`}
                    />
                    <span>{plan.name}</span>
                  </h2>
                  {highlighted && (
                    <span className="text-[11px] font-semibold text-[#CA8A04] dark:text-[#EAB308]">
                      Avantajlı Seçenek
                    </span>
                  )}
                </div>

                <p className="text-xs text-slate-600 dark:text-[#94A3B8] leading-relaxed min-h-[36px]">
                  {plan.description}
                </p>

                <div className="mt-5 pb-5 border-b border-slate-200 dark:border-white/[0.08]">
                  <div className="flex items-baseline gap-2">
                    {appliedPromo && (
                      <span className="text-sm font-mono line-through text-slate-400 tabular-nums">
                        {plan.price_try.toLocaleString('tr-TR')} TL
                      </span>
                    )}
                    <span className="text-3xl font-bold text-slate-900 dark:text-[#F8FAFC] tabular-nums">
                      {discountedPrice.toLocaleString('tr-TR')} TL
                    </span>
                    <span className="text-xs text-slate-500 dark:text-[#94A3B8]">
                      / {plan.is_lifetime ? 'Süresiz' : `${plan.duration_days} gün`}
                    </span>
                  </div>
                </div>

                <ul className="mt-5 space-y-2.5 text-xs text-slate-700 dark:text-[#CBD5E1]">
                  {plan.features.map((feat) => (
                    <li key={feat} className="flex items-start gap-2.5">
                      <Check
                        className={`w-4 h-4 shrink-0 mt-0.5 ${
                          highlighted ? 'text-[#EAB308]' : 'text-[#22C55E]'
                        }`}
                      />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <button
                type="button"
                disabled={loadingPlanId === plan.id || isCurrent}
                onClick={() => void startCheckout(plan.id)}
                className={`mt-7 w-full py-2.5 px-4 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap ${
                  isCurrent
                    ? 'bg-emerald-500/15 text-emerald-700 dark:text-[#22C55E] border border-emerald-500/30 cursor-default'
                    : highlighted
                    ? 'bg-[#EAB308] hover:bg-[#CA8A04] text-[#0B1020]'
                    : 'bg-[#6366F1] hover:bg-[#5558E3] text-white'
                }`}
              >
                {isCurrent
                  ? 'Mevcut Aktif Planınız'
                  : loadingPlanId === plan.id
                  ? 'Oturum Hazırlanıyor...'
                  : paymentProvider?.isLiveConfigured
                  ? 'Satın Al'
                  : 'Test / Demo ile Satın Al'}
              </button>
            </div>
          );
        })}
      </div>

      {/* Free vs Premium Limits Comparison Matrix */}
      {freeLimit && premiumLimit && (
        <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 dark:border-white/[0.08]">
            <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
              Ücretsiz ve Premium Karşılaştırması
            </h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-white/[0.06] text-slate-500 dark:text-[#94A3B8]">
                  <th className="py-3 px-6">Özellik / Kota</th>
                  <th className="py-3 px-6">Ücretsiz Hesap</th>
                  <th className="py-3 px-6 text-[#CA8A04] dark:text-[#EAB308]">Premium Üyelik</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-white/[0.06]">
                <tr>
                  <td className="py-3.5 px-6 text-slate-700 dark:text-[#CBD5E1]">
                    Kayıtlı Proje Limiti
                  </td>
                  <td className="py-3.5 px-6 font-mono tabular-nums text-slate-500 dark:text-[#94A3B8]">
                    {freeLimit.max_projects} proje
                  </td>
                  <td className="py-3.5 px-6 font-mono tabular-nums text-slate-900 dark:text-[#F8FAFC] font-semibold">
                    {premiumLimit.max_projects} proje
                  </td>
                </tr>
                <tr>
                  <td className="py-3.5 px-6 text-slate-700 dark:text-[#CBD5E1]">
                    Aylık APK Derleme Hakkı
                  </td>
                  <td className="py-3.5 px-6 font-mono tabular-nums text-slate-500 dark:text-[#94A3B8]">
                    {freeLimit.monthly_builds} derleme / ay
                  </td>
                  <td className="py-3.5 px-6 font-mono tabular-nums text-slate-900 dark:text-[#F8FAFC] font-semibold">
                    {premiumLimit.monthly_builds} derleme / ay
                  </td>
                </tr>
                <tr>
                  <td className="py-3.5 px-6 text-slate-700 dark:text-[#CBD5E1]">
                    Maksimum Yükleme Boyutu
                  </td>
                  <td className="py-3.5 px-6 font-mono tabular-nums text-slate-500 dark:text-[#94A3B8]">
                    {freeLimit.max_upload_mb} MB
                  </td>
                  <td className="py-3.5 px-6 font-mono tabular-nums text-slate-900 dark:text-[#F8FAFC] font-semibold">
                    {premiumLimit.max_upload_mb} MB
                  </td>
                </tr>
                <tr>
                  <td className="py-3.5 px-6 text-slate-700 dark:text-[#CBD5E1]">
                    Derleme Kuyruğu
                  </td>
                  <td className="py-3.5 px-6 text-slate-500 dark:text-[#94A3B8]">
                    Standart kuyruk
                  </td>
                  <td className="py-3.5 px-6 text-[#CA8A04] dark:text-[#EAB308] font-medium">
                    Öncelikli kuyruk
                  </td>
                </tr>
                <tr>
                  <td className="py-3.5 px-6 text-slate-700 dark:text-[#CBD5E1]">
                    Premium Uygulama İkonları
                  </td>
                  <td className="py-3.5 px-6 text-slate-500 dark:text-[#94A3B8]">
                    Standart ikonlar
                  </td>
                  <td className="py-3.5 px-6 text-[#22C55E] font-medium">Tam erişim</td>
                </tr>
                <tr>
                  <td className="py-3.5 px-6 text-slate-700 dark:text-[#CBD5E1]">
                    Reklam ve Kısıtlama Durumu
                  </td>
                  <td className="py-3.5 px-6 text-slate-500 dark:text-[#94A3B8]">Standart</td>
                  <td className="py-3.5 px-6 text-[#22C55E] font-medium">Reklamsız kullanım</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Signed Checkout Modal */}
      {checkoutSession && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white dark:bg-[#151D2E] border border-[#EAB308]/40 rounded-2xl overflow-hidden shadow-2xl">
            <div className="px-6 py-4 border-b border-slate-200 dark:border-white/[0.08] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-[#EAB308]" />
                <h3 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
                  {checkoutSession.isTestMode
                    ? 'Test / Demo Ödeme Doğrulama'
                    : 'Güvenli Ödeme Oturumu'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setCheckoutSession(null)}
                className="text-slate-500 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {checkoutSession.isTestMode && (
                <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/25 text-xs text-amber-800 dark:text-amber-200 leading-relaxed">
                  <strong>Test / Demo Modu:</strong> PayTR veya iyzico API anahtarları
                  yapılandırılmadığı için gerçek kart tahsilatı yapılmaz. Sunucu HMAC-SHA256 imzalı
                  test webhook doğrulaması gerçekleştirilir.
                </div>
              )}

              <div className="bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.08] rounded-xl p-4 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500 dark:text-[#94A3B8]">Paket</span>
                  <span className="font-semibold text-slate-900 dark:text-[#F8FAFC]">
                    {checkoutSession.planName}
                  </span>
                </div>
                {checkoutSession.discountTry > 0 && (
                  <>
                    <div className="flex justify-between">
                      <span className="text-slate-500 dark:text-[#94A3B8]">Normal Tutar</span>
                      <span className="font-mono text-slate-500 line-through tabular-nums">
                        {checkoutSession.originalAmountTry.toLocaleString('tr-TR')} TL
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500 dark:text-[#94A3B8]">
                        Promosyon ({checkoutSession.appliedPromoCode})
                      </span>
                      <span className="font-mono text-[#22C55E] tabular-nums">
                        -{checkoutSession.discountTry.toLocaleString('tr-TR')} TL
                      </span>
                    </div>
                  </>
                )}
                <div className="flex justify-between pt-1 border-t border-slate-200 dark:border-white/[0.06]">
                  <span className="text-slate-600 dark:text-[#94A3B8] font-medium">
                    Sunucu Onaylı Tutar
                  </span>
                  <span className="font-mono font-bold text-[#CA8A04] dark:text-[#EAB308] tabular-nums">
                    {checkoutSession.amountTry.toLocaleString('tr-TR')} TL
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500 dark:text-[#94A3B8]">Referans Kodu</span>
                  <span className="font-mono text-slate-700 dark:text-[#CBD5E1]">
                    {checkoutSession.providerReference}
                  </span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button
                  type="button"
                  disabled={verifying}
                  onClick={() => void completeWebhookVerification('failed')}
                  className="flex-1 py-2.5 px-4 text-xs font-medium rounded-xl border border-slate-200 dark:border-white/[0.12] text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white"
                >
                  Başarısız Simüle Et
                </button>
                <button
                  type="button"
                  disabled={verifying}
                  onClick={() => void completeWebhookVerification('success')}
                  className="flex-1 py-2.5 px-4 text-xs font-semibold rounded-xl bg-[#EAB308] hover:bg-[#CA8A04] text-[#0B1020]"
                >
                  {verifying
                    ? 'Doğrulanıyor...'
                    : checkoutSession.isTestMode
                    ? 'Test Ödemesini Onayla'
                    : 'Ödemeyi Tamamla'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
