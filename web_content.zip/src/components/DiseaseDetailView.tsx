import React, { useState } from 'react';
import {
  X,
  Bookmark,
  BookmarkCheck,
  Share2,
  Check,
  Globe,
  AlertTriangle,
  Stethoscope,
  Pill,
  Heart,
  Info,
  Shield,
  HelpCircle,
  FileText,
  ChevronDown,
  ChevronUp,
  Activity,
  HeartPulse,
  Wind,
  Bug,
  ShieldAlert,
  Thermometer,
  ShieldPlus,
  ThermometerSnowflake,
  Flame,
  Zap,
  Droplet
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { DiseaseItem, DiseaseLanguage } from '../types/disease';
import { ReadAloudButton } from './ReadAloudButton';

interface DiseaseDetailViewProps {
  disease: DiseaseItem;
  currentLanguage: DiseaseLanguage;
  onLanguageChange: (lang: DiseaseLanguage) => void;
  isBookmarked: boolean;
  onToggleBookmark: (diseaseId: string) => void;
  onClose: () => void;
}

export const DiseaseDetailView: React.FC<DiseaseDetailViewProps> = ({
  disease,
  currentLanguage,
  onLanguageChange,
  isBookmarked,
  onToggleBookmark,
  onClose,
}) => {
  const [copiedShare, setCopiedShare] = useState(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const langContent = disease.content[currentLanguage] || disease.content.English;

  // Icon map for disease headers
  const renderDiseaseIcon = (iconName: string) => {
    const props = { className: "w-8 h-8 text-white" };
    switch (iconName) {
      case 'Activity': return <Activity {...props} />;
      case 'HeartPulse': return <HeartPulse {...props} />;
      case 'Wind': return <Wind {...props} />;
      case 'Bug': return <Bug {...props} />;
      case 'ShieldAlert': return <ShieldAlert {...props} />;
      case 'Thermometer': return <Thermometer {...props} />;
      case 'Lungs': return <Wind {...props} />;
      case 'ShieldPlus': return <ShieldPlus {...props} />;
      case 'ThermometerSnowflake': return <ThermometerSnowflake {...props} />;
      case 'Flame': return <Flame {...props} />;
      case 'Zap': return <Zap {...props} />;
      case 'Droplet': return <Droplet {...props} />;
      case 'Heart': return <Heart {...props} />;
      default: return <Info {...props} />;
    }
  };

  const handleShare = async () => {
    const shareText = `🦠 ${langContent.name}\n\n${langContent.summary}\n\nRead full verified disease guide on Mediguide AI.`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: langContent.name,
          text: shareText,
          url: window.location.href,
        });
        return;
      } catch (err) {
        console.log('Share cancelled or failed:', err);
      }
    }
    try {
      await navigator.clipboard.writeText(shareText);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2500);
    } catch (err) {
      console.warn('Clipboard failed:', err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex justify-center items-end sm:items-center p-0 sm:p-4 overflow-y-auto">
      <motion.div
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 50, opacity: 0 }}
        className="bg-white w-full sm:max-w-2xl sm:rounded-3xl rounded-t-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden border border-slate-100"
      >
        {/* Header with gradient */}
        <div className={`bg-gradient-to-r ${disease.bgGradient} p-5 text-white relative shrink-0`}>
          {/* Top Actions */}
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-extrabold uppercase tracking-wider bg-white/20 backdrop-blur-md px-2.5 py-1 rounded-full text-white border border-white/20">
                {langContent.category}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <ReadAloudButton
                id="disease-detail-read-aloud"
                text={[
                  langContent.name,
                  langContent.summary,
                  langContent.symptoms?.length ? `Symptoms: ${langContent.symptoms.join(', ')}` : '',
                  langContent.causes?.length ? `Causes: ${langContent.causes.join(', ')}` : '',
                  langContent.prevention?.length ? `Prevention: ${langContent.prevention.join(', ')}` : '',
                  langContent.whenToSeeDoctor ? `When to see a doctor: ${langContent.whenToSeeDoctor}` : '',
                  langContent.disclaimer ? `Disclaimer: ${langContent.disclaimer}` : '',
                ].filter(Boolean).join('. ')}
                language={currentLanguage}
                variant="pill"
                className="bg-white/20 hover:bg-white/30 text-white border border-white/20 rounded-full"
              />

              <button
                onClick={() => onToggleBookmark(disease.id)}
                className={`p-2 rounded-full transition-all cursor-pointer ${
                  isBookmarked ? 'bg-amber-400 text-slate-900 shadow-md' : 'bg-white/20 hover:bg-white/30 text-white'
                }`}
                title="Bookmark Disease"
              >
                {isBookmarked ? <BookmarkCheck className="w-5 h-5 fill-slate-900" /> : <Bookmark className="w-5 h-5" />}
              </button>

              <button
                onClick={handleShare}
                className="p-2 rounded-full bg-white/20 hover:bg-white/30 text-white transition-all cursor-pointer relative"
                title="Share Disease"
              >
                {copiedShare ? <Check className="w-5 h-5 text-emerald-300" /> : <Share2 className="w-5 h-5" />}
              </button>

              <button
                onClick={onClose}
                className="p-2 rounded-full bg-white/20 hover:bg-white/30 text-white transition-all cursor-pointer"
                title="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Disease Title & Icon */}
          <div className="flex items-start gap-4 pt-1">
            <div className="p-3 bg-white/15 rounded-2xl backdrop-blur-md border border-white/20 shrink-0">
              {renderDiseaseIcon(disease.iconName)}
            </div>
            <div>
              <h2 className="text-2xl font-black tracking-tight leading-tight">{langContent.name}</h2>
              <p className="text-xs text-white/90 mt-1 line-clamp-2 leading-relaxed">{langContent.summary}</p>
            </div>
          </div>

          {/* Language Tabs Bar at top of disease page */}
          <div className="mt-4 pt-3 border-t border-white/20 flex items-center justify-between gap-2">
            <div className="flex items-center gap-1 text-[11px] font-extrabold text-white/90">
              <Globe className="w-3.5 h-3.5" />
              <span>English (हिन्दी / मराठी)</span>
            </div>

            <div className="flex bg-black/20 p-1 rounded-xl gap-1 border border-white/10">
              {(['English', 'Hindi', 'Marathi'] as DiseaseLanguage[]).map((lang) => (
                <button
                  key={lang}
                  onClick={() => onLanguageChange(lang)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    currentLanguage === lang
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-white/80 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {lang === 'English' ? 'English' : lang === 'Hindi' ? 'हिन्दी' : 'मराठी'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-5 overflow-y-auto space-y-6 text-slate-800 text-xs leading-relaxed">
          {/* Toast Notice if copied */}
          <AnimatePresence>
            {copiedShare && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="bg-emerald-600 text-white p-2.5 rounded-xl text-center font-bold text-xs shadow-md"
              >
                ✓ Summary copied to clipboard! Ready to share.
              </motion.div>
            )}
          </AnimatePresence>

          {/* 1. What is this Disease? */}
          <section className="bg-sky-50/70 p-4 rounded-2xl border border-sky-100 space-y-2">
            <div className="flex items-center gap-2 text-sky-800 font-extrabold text-sm">
              <Info className="w-4 h-4 text-sky-600" />
              <h3>What is this Disease?</h3>
            </div>
            <p className="text-slate-700 font-medium leading-relaxed">{langContent.whatIsIt}</p>
          </section>

          {/* 2. Causes */}
          <section className="space-y-2">
            <div className="flex items-center gap-2 text-slate-900 font-extrabold text-sm">
              <FileText className="w-4 h-4 text-indigo-600" />
              <h3>Causes</h3>
            </div>
            <ul className="space-y-1.5 pl-1">
              {langContent.causes.map((cause, idx) => (
                <li key={idx} className="flex items-start gap-2 text-slate-700">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 mt-1.5 shrink-0" />
                  <span>{cause}</span>
                </li>
              ))}
            </ul>
          </section>

          {/* 3. Symptoms */}
          <section className="space-y-2">
            <div className="flex items-center gap-2 text-slate-900 font-extrabold text-sm">
              <Activity className="w-4 h-4 text-rose-600" />
              <h3>Symptoms</h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {langContent.symptoms.map((symptom, idx) => (
                <div key={idx} className="p-2.5 bg-rose-50/50 rounded-xl border border-rose-100/80 flex items-start gap-2 text-rose-900 font-medium">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-1.5 shrink-0" />
                  <span>{symptom}</span>
                </div>
              ))}
            </div>
          </section>

          {/* 4. Risk Factors */}
          <section className="space-y-2">
            <div className="flex items-center gap-2 text-slate-900 font-extrabold text-sm">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <h3>Risk Factors</h3>
            </div>
            <ul className="space-y-1.5 pl-1">
              {langContent.riskFactors.map((risk, idx) => (
                <li key={idx} className="flex items-start gap-2 text-slate-700">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                  <span>{risk}</span>
                </li>
              ))}
            </ul>
          </section>

          {/* 5. Prevention */}
          <section className="space-y-2">
            <div className="flex items-center gap-2 text-slate-900 font-extrabold text-sm">
              <Shield className="w-4 h-4 text-emerald-600" />
              <h3>Prevention</h3>
            </div>
            <ul className="space-y-1.5 pl-1">
              {langContent.prevention.map((prev, idx) => (
                <li key={idx} className="flex items-start gap-2 text-slate-700">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                  <span>{prev}</span>
                </li>
              ))}
            </ul>
          </section>

          {/* 6. Diagnosis */}
          <section className="space-y-2">
            <div className="flex items-center gap-2 text-slate-900 font-extrabold text-sm">
              <Stethoscope className="w-4 h-4 text-purple-600" />
              <h3>Diagnosis</h3>
            </div>
            <ul className="space-y-1.5 pl-1">
              {langContent.diagnosis.map((diag, idx) => (
                <li key={idx} className="flex items-start gap-2 text-slate-700">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-500 mt-1.5 shrink-0" />
                  <span>{diag}</span>
                </li>
              ))}
            </ul>
          </section>

          {/* 7. Treatment Overview */}
          <section className="space-y-2">
            <div className="flex items-center gap-2 text-slate-900 font-extrabold text-sm">
              <Pill className="w-4 h-4 text-blue-600" />
              <h3>Treatment Overview</h3>
            </div>
            <ul className="space-y-1.5 pl-1">
              {langContent.treatmentOverview.map((treat, idx) => (
                <li key={idx} className="flex items-start gap-2 text-slate-700">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5 shrink-0" />
                  <span>{treat}</span>
                </li>
              ))}
            </ul>
          </section>

          {/* 8. Lifestyle Tips */}
          <section className="space-y-2">
            <div className="flex items-center gap-2 text-slate-900 font-extrabold text-sm">
              <Heart className="w-4 h-4 text-teal-600" />
              <h3>Lifestyle Tips</h3>
            </div>
            <ul className="space-y-1.5 pl-1">
              {langContent.lifestyleTips.map((tip, idx) => (
                <li key={idx} className="flex items-start gap-2 text-slate-700">
                  <span className="w-1.5 h-1.5 rounded-full bg-teal-500 mt-1.5 shrink-0" />
                  <span>{tip}</span>
                </li>
              ))}
            </ul>
          </section>

          {/* 9. When to Consult a Doctor */}
          <section className="bg-amber-50/80 p-4 rounded-2xl border border-amber-200/80 space-y-2">
            <div className="flex items-center gap-2 text-amber-900 font-extrabold text-sm">
              <Stethoscope className="w-4 h-4 text-amber-700" />
              <h3>When to Consult a Doctor</h3>
            </div>
            <ul className="space-y-1.5 pl-1">
              {langContent.whenToConsultDoctor.map((item, idx) => (
                <li key={idx} className="flex items-start gap-2 text-amber-950 font-medium">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-600 mt-1.5 shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </section>

          {/* 10. Emergency Warning Signs */}
          <section className="bg-red-50 p-4 rounded-2xl border border-red-200 space-y-2">
            <div className="flex items-center gap-2 text-red-700 font-extrabold text-sm">
              <AlertTriangle className="w-4.5 h-4.5 text-red-600 animate-pulse" />
              <h3>Emergency Warning Signs</h3>
            </div>
            <ul className="space-y-1.5 pl-1">
              {langContent.emergencyWarningSigns.map((warn, idx) => (
                <li key={idx} className="flex items-start gap-2 text-red-900 font-bold">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-600 mt-1.5 shrink-0" />
                  <span>{warn}</span>
                </li>
              ))}
            </ul>
          </section>

          {/* 11. Frequently Asked Questions */}
          <section className="space-y-3 pt-2">
            <div className="flex items-center gap-2 text-slate-900 font-extrabold text-sm">
              <HelpCircle className="w-4 h-4 text-sky-600" />
              <h3>Frequently Asked Questions</h3>
            </div>

            <div className="space-y-2">
              {langContent.faqs.map((faq, idx) => {
                const isOpen = openFaqIndex === idx;
                return (
                  <div key={idx} className="border border-slate-200 rounded-2xl overflow-hidden bg-slate-50/50">
                    <button
                      onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                      className="w-full p-3.5 text-left font-bold text-slate-900 flex items-center justify-between gap-2 hover:bg-slate-100/60 transition-colors cursor-pointer"
                    >
                      <span className="text-xs">{faq.question}</span>
                      {isOpen ? <ChevronUp className="w-4 h-4 text-slate-500 shrink-0" /> : <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" />}
                    </button>
                    {isOpen && (
                      <div className="px-3.5 pb-3.5 pt-1 text-slate-600 text-xs leading-relaxed border-t border-slate-200/60 bg-white font-medium">
                        {faq.answer}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        </div>

        {/* Footer info */}
        <div className="p-3 bg-slate-100 text-slate-500 text-[10px] text-center font-medium border-t border-slate-200 shrink-0">
          Medical information sourced from trusted public health authorities (WHO, ICMR, CDC). Educational reference only.
        </div>
      </motion.div>
    </div>
  );
};
