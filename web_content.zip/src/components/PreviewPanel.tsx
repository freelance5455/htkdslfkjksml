import React, { useState, useEffect, useRef } from 'react';
import {
  RotateCcw,
  Smartphone,
  Tablet,
  Monitor,
  Maximize2,
  Gamepad2,
  Terminal,
  Play,
  Volume2
} from 'lucide-react';
import { Project, ViewportMode } from '../types';
import { buildSandboxHtml, executePythonCode } from '../utils/bundler';
import { playSound } from '../utils/audio';

interface PreviewPanelProps {
  project: Project;
  onPostConsoleMessage: (type: 'log' | 'info' | 'warn' | 'error' | 'system', msg: string) => void;
  runTrigger: number;
}

export const PreviewPanel: React.FC<PreviewPanelProps> = ({
  project,
  onPostConsoleMessage,
  runTrigger,
}) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [viewport, setViewport] = useState<ViewportMode>('responsive');
  const [showVirtualPad, setShowVirtualPad] = useState(false);
  const [pythonLogs, setPythonLogs] = useState<Array<{ text: string; type: 'log' | 'error' }>>([]);
  const [isRunningPython, setIsRunningPython] = useState(false);

  const isPythonProject = project.category === 'python' || project.files.some(f => f.name.endsWith('.py'));
  const isGameProject = project.category === 'game';

  // Build sandbox HTML whenever project changes or runTrigger fires
  useEffect(() => {
    if (isPythonProject) {
      runPythonProject();
      return;
    }

    if (!iframeRef.current) return;
    const html = buildSandboxHtml(project);
    iframeRef.current.srcdoc = html;
    onPostConsoleMessage('system', `Rebuilt sandbox preview for [${project.name}]`);
  }, [project, runTrigger]);

  const runPythonProject = () => {
    setIsRunningPython(true);
    setPythonLogs([]);
    const mainPy = project.files.find(f => f.name === 'main.py') || project.files.find(f => f.name.endsWith('.py'));
    if (!mainPy) {
      setPythonLogs([{ text: 'No Python file found in project.', type: 'error' }]);
      setIsRunningPython(false);
      return;
    }

    executePythonCode(mainPy.content, (text, type) => {
      setPythonLogs(prev => [...prev, { text, type }]);
      onPostConsoleMessage(type === 'error' ? 'error' : 'log', `[Python] ${text}`);
    });
    setIsRunningPython(false);
  };

  // Dispatch virtual controller events into iframe
  const sendVirtualKey = (action: string, pressed: boolean) => {
    if (!iframeRef.current || !iframeRef.current.contentWindow) return;
    iframeRef.current.contentWindow.postMessage(
      {
        type: 'CODEVERSE_VIRTUAL_INPUT',
        action,
        pressed,
      },
      '*'
    );
  };

  const getViewportWidthClass = () => {
    switch (viewport) {
      case 'mobile': return 'w-[375px] max-w-full';
      case 'tablet': return 'w-[768px] max-w-full';
      case 'desktop': return 'w-[1024px] max-w-full';
      default: return 'w-full';
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-[#070a14] border-l border-slate-800 relative overflow-hidden h-full">
      {/* Top Preview Controls Toolbar */}
      <div className="h-10 bg-[#090d18] border-b border-slate-800 px-3 flex items-center justify-between select-none shrink-0">
        <div className="flex items-center gap-2">
          {/* Simulated browser address */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#050811] border border-slate-800 text-[11px] text-slate-400 font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" />
            <span className="hidden sm:inline">preview://codeverse/</span>
            <span className="text-slate-200">{project.name.toLowerCase().replace(/\s+/g, '-')}</span>
          </div>
        </div>

        {/* Viewport switchers & helpers */}
        <div className="flex items-center gap-1">
          {/* Virtual gamepad toggle for games */}
          {isGameProject && (
            <button
              onClick={() => setShowVirtualPad(!showVirtualPad)}
              title="Toggle On-Screen Virtual Gamepad"
              aria-label="Toggle Virtual Controller"
              className={`p-1.5 rounded text-xs flex items-center gap-1 transition-colors ${
                showVirtualPad
                  ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Gamepad2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline text-[10px]">Gamepad</span>
            </button>
          )}

          {!isPythonProject && (
            <div className="flex items-center bg-[#050811] rounded-lg p-0.5 border border-slate-800">
              <button
                onClick={() => setViewport('responsive')}
                title="Responsive Fill"
                aria-label="Responsive viewport"
                className={`p-1 rounded ${viewport === 'responsive' ? 'bg-cyan-500/20 text-cyan-300' : 'text-slate-400 hover:text-white'}`}
              >
                <Maximize2 className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setViewport('desktop')}
                title="Desktop View (1024px)"
                aria-label="Desktop viewport"
                className={`p-1 rounded ${viewport === 'desktop' ? 'bg-cyan-500/20 text-cyan-300' : 'text-slate-400 hover:text-white'}`}
              >
                <Monitor className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setViewport('tablet')}
                title="Tablet View (768px)"
                aria-label="Tablet viewport"
                className={`p-1 rounded ${viewport === 'tablet' ? 'bg-cyan-500/20 text-cyan-300' : 'text-slate-400 hover:text-white'}`}
              >
                <Tablet className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setViewport('mobile')}
                title="Mobile View (375px)"
                aria-label="Mobile viewport"
                className={`p-1 rounded ${viewport === 'mobile' ? 'bg-cyan-500/20 text-cyan-300' : 'text-slate-400 hover:text-white'}`}
              >
                <Smartphone className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Refresh / Re-run */}
          <button
            onClick={() => {
              if (isPythonProject) runPythonProject();
              else {
                if (iframeRef.current) {
                  iframeRef.current.srcdoc = buildSandboxHtml(project);
                  onPostConsoleMessage('system', 'Preview reloaded.');
                }
              }
            }}
            title="Reload sandbox preview"
            aria-label="Reload preview"
            className="p-1.5 rounded text-slate-400 hover:text-cyan-400 hover:bg-slate-800 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Preview Surface */}
      <div className="flex-1 bg-[#050811] flex items-center justify-center p-2 relative overflow-hidden">
        {isPythonProject ? (
          /* Python Execution Terminal Display */
          <div className="w-full h-full bg-[#090d18] border border-emerald-500/30 rounded-xl p-4 font-mono text-xs overflow-auto shadow-2xl flex flex-col">
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800 text-emerald-400 font-bold">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4" />
                <span>PYTHON RUNTIME OUTPUT (Browser Sandbox)</span>
              </div>
              <button
                onClick={runPythonProject}
                disabled={isRunningPython}
                className="px-2.5 py-1 rounded bg-emerald-500 text-slate-950 font-bold hover:bg-emerald-400 flex items-center gap-1 transition-all"
              >
                <Play className="w-3 h-3 fill-current" />
                <span>Re-run</span>
              </button>
            </div>
            <div className="flex-1 space-y-1 overflow-auto">
              {pythonLogs.map((log, idx) => (
                <div
                  key={idx}
                  className={`leading-relaxed whitespace-pre-wrap ${
                    log.type === 'error' ? 'text-rose-400 font-semibold' : 'text-slate-200'
                  }`}
                >
                  {log.text}
                </div>
              ))}
            </div>
          </div>
        ) : (
          /* HTML / Game Sandbox Iframe */
          <div
            className={`h-full transition-all duration-200 flex flex-col items-center justify-center relative ${getViewportWidthClass()}`}
          >
            <iframe
              ref={iframeRef}
              title="CODEVERSE Isolated Sandbox Preview"
              sandbox="allow-scripts allow-modals"
              className="w-full h-full bg-[#050811] rounded-lg border border-slate-800 shadow-xl"
            />
          </div>
        )}

        {/* Virtual Gamepad Touch Overlay (for games and mobile controls) */}
        {showVirtualPad && isGameProject && (
          <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between pointer-events-none z-30 select-none">
            {/* D-Pad Left */}
            <div className="pointer-events-auto bg-slate-900/90 border border-slate-700/80 rounded-2xl p-2 shadow-2xl backdrop-blur-xs flex flex-col items-center gap-1">
              <button
                onMouseDown={() => sendVirtualKey('up', true)}
                onMouseUp={() => sendVirtualKey('up', false)}
                onTouchStart={() => sendVirtualKey('up', true)}
                onTouchEnd={() => sendVirtualKey('up', false)}
                className="w-10 h-10 rounded-lg bg-slate-800 active:bg-cyan-500/40 text-cyan-300 font-bold flex items-center justify-center shadow-md active:scale-95"
              >
                ▲
              </button>
              <div className="flex gap-1">
                <button
                  onMouseDown={() => sendVirtualKey('left', true)}
                  onMouseUp={() => sendVirtualKey('left', false)}
                  onTouchStart={() => sendVirtualKey('left', true)}
                  onTouchEnd={() => sendVirtualKey('left', false)}
                  className="w-10 h-10 rounded-lg bg-slate-800 active:bg-cyan-500/40 text-cyan-300 font-bold flex items-center justify-center shadow-md active:scale-95"
                >
                  ◀
                </button>
                <button
                  onMouseDown={() => sendVirtualKey('down', true)}
                  onMouseUp={() => sendVirtualKey('down', false)}
                  onTouchStart={() => sendVirtualKey('down', true)}
                  onTouchEnd={() => sendVirtualKey('down', false)}
                  className="w-10 h-10 rounded-lg bg-slate-800 active:bg-cyan-500/40 text-cyan-300 font-bold flex items-center justify-center shadow-md active:scale-95"
                >
                  ▼
                </button>
                <button
                  onMouseDown={() => sendVirtualKey('right', true)}
                  onMouseUp={() => sendVirtualKey('right', false)}
                  onTouchStart={() => sendVirtualKey('right', true)}
                  onTouchEnd={() => sendVirtualKey('right', false)}
                  className="w-10 h-10 rounded-lg bg-slate-800 active:bg-cyan-500/40 text-cyan-300 font-bold flex items-center justify-center shadow-md active:scale-95"
                >
                  ▶
                </button>
              </div>
            </div>

            {/* Action Buttons Right */}
            <div className="pointer-events-auto bg-slate-900/90 border border-slate-700/80 rounded-2xl p-3 shadow-2xl backdrop-blur-xs flex gap-3 items-center">
              <button
                onMouseDown={() => sendVirtualKey('jump', true)}
                onMouseUp={() => sendVirtualKey('jump', false)}
                onTouchStart={() => sendVirtualKey('jump', true)}
                onTouchEnd={() => sendVirtualKey('jump', false)}
                className="w-12 h-12 rounded-full bg-purple-600 active:bg-purple-400 text-white font-extrabold flex items-center justify-center shadow-lg active:scale-90 text-sm"
              >
                JUMP
              </button>
              <button
                onMouseDown={() => sendVirtualKey('fire', true)}
                onMouseUp={() => sendVirtualKey('fire', false)}
                onTouchStart={() => sendVirtualKey('fire', true)}
                onTouchEnd={() => sendVirtualKey('fire', false)}
                className="w-14 h-14 rounded-full bg-cyan-500 active:bg-cyan-300 text-slate-950 font-black flex items-center justify-center shadow-lg active:scale-90 text-sm"
              >
                FIRE
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
