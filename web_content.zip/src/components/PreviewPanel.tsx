import { useCallback, useEffect, useRef, useState } from "react";
import { useStore } from "../lib/store";
import { compilePreview, type PreviewBuild } from "../lib/preview-compiler";
import runtime from "../generated/preview-runtime.js?raw";
import { uid } from "../lib/fs";
import { Button, Icon, IconButton } from "./ui";
import { cn } from "../utils/cn";

export default function PreviewPanel({
  compact = false,
  onClose,
}: {
  compact?: boolean;
  onClose?: () => void;
}) {
  const { s, set, showToast, exportWorkspace } = useStore();
  const [build, setBuild] = useState<PreviewBuild | null>(null);
  const [status, setStatus] = useState<"building" | "ready" | "error">(
    "building",
  );
  const [error, setError] = useState("");
  const [viewport, setViewport] = useState<"mobile" | "desktop">("mobile");
  const [logs, setLogs] = useState<{ kind: string; message: string }[]>([]);
  const [consoleOpen, setConsoleOpen] = useState(false);
  const iframe = useRef<HTMLIFrameElement>(null);
  const viewportRef = useRef<HTMLDivElement>(null);
  const [bounds, setBounds] = useState({ width: 375, height: 600 });
  const canvasWidth = viewport === "desktop" ? 1024 : 375;
  const scale = Math.min(1, bounds.width / canvasWidth);
  useEffect(() => {
    const el = viewportRef.current;
    if (!el) return;
    const update = () =>
      setBounds({
        width: el.clientWidth || 375,
        height: el.clientHeight || 600,
      });
    update();
    const observer = new ResizeObserver(update);
    observer.observe(el);
    return () => observer.disconnect();
  }, [build, viewport]);
  const run = useCallback(() => {
    setError("");
    setLogs([]);
    setStatus("building");
    if (!s.permissions.read) {
      setBuild(null);
      setError(
        "Read permission is off. Enable it before previewing workspace files.",
      );
      setStatus("error");
      return;
    }
    try {
      setBuild(compilePreview(s.fs, runtime, uid("preview")));
    } catch (e) {
      setBuild(null);
      setError(
        e instanceof Error ? e.message : "Could not compile this project.",
      );
      setStatus("error");
    }
  }, [s.fs, s.permissions.read]);
  useEffect(() => {
    if (!s.previewAutoRun && build) return;
    const timer = setTimeout(run, 350);
    return () => clearTimeout(timer);
  }, [run, s.previewAutoRun]);
  useEffect(() => {
    window.addEventListener("topecode:run-preview", run);
    return () => window.removeEventListener("topecode:run-preview", run);
  }, [run]);
  useEffect(() => {
    const receive = (event: MessageEvent) => {
      if (
        event.source !== iframe.current?.contentWindow ||
        event.data?.source !== "topecode-preview" ||
        event.data.session !== build?.session
      )
        return;
      const { kind, message } = event.data;
      if (kind === "ready")
        setStatus((current) => (current === "error" ? "error" : "ready"));
      else {
        setLogs((current) => [...current, { kind, message }].slice(-80));
        if (kind === "error") {
          setError(message);
          setStatus("error");
        }
      }
    };
    window.addEventListener("message", receive);
    return () => window.removeEventListener("message", receive);
  }, [build]);
  return (
    <section
      className={cn(
        "preview-panel flex h-full min-h-0 min-w-0 flex-col",
        compact && "preview-compact",
      )}
      aria-label="Live preview"
    >
      <header className="flex h-[58px] shrink-0 items-center gap-2.5 border-b border-line px-4">
        <span className="grid h-7 w-7 place-items-center rounded-lg bg-accentsoft text-accent">
          <Icon name="play" className="h-3.5 w-3.5" />
        </span>
        <h2 className="text-[12px] font-semibold">Live preview</h2>
        <span
          className={cn(
            "ml-auto flex items-center gap-1.5 text-[10px]",
            status === "error" ? "text-danger" : "text-muted",
          )}
        >
          <span
            className={cn(
              "h-1.5 w-1.5 rounded-full",
              status === "ready"
                ? "bg-ok"
                : status === "error"
                  ? "bg-danger"
                  : "bg-accent animate-pulse",
            )}
          />
          {status === "ready"
            ? "Running"
            : status === "error"
              ? "Needs attention"
              : "Compiling"}
        </span>
        {onClose && (
          <IconButton
            name="expand"
            label="Expand preview"
            onClick={() => set({ view: "preview" })}
            className="h-7 w-7"
          />
        )}
        {onClose && (
          <IconButton
            name="close"
            label="Hide preview panel"
            onClick={onClose}
            className="-mr-2 h-7 w-7"
          />
        )}
      </header>
      <div className="flex shrink-0 items-center justify-between gap-2 px-4 py-3">
        <div className="preview-device-switch flex items-center rounded-lg bg-surface2 p-0.5">
          {(["mobile", "desktop"] as const).map((device) => (
            <button
              key={device}
              onClick={() => setViewport(device)}
              aria-label={`${device} preview`}
              aria-pressed={viewport === device}
              className={cn(
                "grid h-7 w-9 place-items-center rounded-md transition-all",
                viewport === device
                  ? "tactile-control bg-surface text-accent"
                  : "text-muted",
              )}
            >
              <Icon
                name={device === "mobile" ? "phone" : "monitor"}
                className="h-3.5 w-3.5"
              />
            </button>
          ))}
        </div>
        <button
          onClick={() => set({ previewAutoRun: !s.previewAutoRun })}
          aria-pressed={s.previewAutoRun}
          className="flex items-center gap-1.5 text-[10px] text-muted"
        >
          <Icon
            name="zap"
            className={cn("h-3 w-3", s.previewAutoRun && "text-accent")}
          />
          Auto-run {s.previewAutoRun ? "on" : "off"}
        </button>
        <IconButton
          name="refresh"
          label="Reload preview"
          onClick={run}
          className="h-7 w-7"
        />
      </div>
      <div className="preview-stage relative flex min-h-0 flex-1 justify-center overflow-hidden px-3 pb-3 sm:px-4">
        <div
          className={cn(
            "preview-browser relative flex h-full min-h-0 w-full flex-col overflow-hidden",
            viewport === "mobile" ? "max-w-[390px]" : "max-w-none",
          )}
        >
          <div className="flex h-9 shrink-0 items-center gap-2 border-b border-line bg-surface/90 px-3">
            <div className="flex gap-1">
              <i className="h-1.5 w-1.5 rounded-full bg-[#efb0c0]" />
              <i className="h-1.5 w-1.5 rounded-full bg-[#e6cc8e]" />
              <i className="h-1.5 w-1.5 rounded-full bg-[#9dc8b2]" />
            </div>
            <span className="flex min-w-0 flex-1 items-center justify-center gap-1.5 truncate text-[9px] text-muted">
              <Icon name="lock" className="h-2.5 w-2.5" />
              {s.workspacePath}.local
            </span>
            <Icon name="globe" className="h-3 w-3 text-muted" />
          </div>
          {build && (
            <div
              ref={viewportRef}
              className="relative min-h-0 flex-1 overflow-hidden bg-white"
            >
              <iframe
                ref={iframe}
                key={build.session}
                title="Workspace browser preview"
                sandbox="allow-scripts"
                srcDoc={build.html}
                className="absolute left-0 top-0 origin-top-left border-0 bg-white"
                style={{
                  width: canvasWidth,
                  height: bounds.height / scale,
                  transform: `scale(${scale})`,
                }}
              />
            </div>
          )}
          {!build && (
            <div className="flex flex-1 flex-col items-center justify-center gap-3 px-5 text-center">
              <Icon
                name={status === "error" ? "code" : "loading"}
                className={cn(
                  "h-8 w-8 text-accent",
                  status === "building" && "animate-spin",
                )}
              />
              <p className="text-xs leading-relaxed text-muted">
                {error || "Compiling your workspace..."}
              </p>
              <Button
                size="sm"
                icon="refresh"
                variant="secondary"
                onClick={run}
              >
                Try again
              </Button>
            </div>
          )}
        </div>
      </div>
      {error && build && (
        <div
          role="alert"
          className="mx-4 mb-2 rounded-xl bg-dangersoft p-3 text-[11px] leading-relaxed text-danger"
        >
          {error}
          <button
            onClick={() => {
              set((state) => ({
                composerDrafts: {
                  ...state.composerDrafts,
                  [state.activeSessionId]: `Fix this browser preview error:\n${error}`,
                },
                view: "chat",
              }));
              showToast("Preview error added to your prompt.");
            }}
            className="mt-2 flex items-center gap-1 font-medium underline underline-offset-2"
          >
            Ask TopeCode to fix it
            <Icon name="arrowUpRight" className="h-3 w-3" />
          </button>
        </div>
      )}
      <button
        onClick={() => setConsoleOpen(!consoleOpen)}
        className="flex h-9 shrink-0 items-center gap-2 border-t border-line px-4 text-[10px] text-muted"
      >
        <Icon name="terminal" className="h-3.5 w-3.5" />
        Preview console
        {logs.length > 0 && <span className="text-accent">{logs.length}</span>}
        <Icon
          name={consoleOpen ? "chevronDown" : "chevronRight"}
          className="ml-auto h-3 w-3"
        />
      </button>
      {consoleOpen && (
        <div className="max-h-[130px] shrink-0 overflow-y-auto border-t border-line bg-surface2 px-4 py-2 font-mono text-[10px] leading-relaxed">
          {logs.length ? (
            logs.map((log, index) => (
              <div
                key={index}
                className={cn(
                  "break-words",
                  log.kind === "error" ? "text-danger" : "text-muted",
                )}
              >
                {log.kind}: {log.message}
              </div>
            ))
          ) : (
            <p className="text-muted">No console output.</p>
          )}
        </div>
      )}
      <footer className="flex h-10 shrink-0 items-center gap-1.5 border-t border-line px-4 text-[9px] text-muted">
        <Icon name="shield" className="h-3 w-3 text-accent" />
        <span>Runs locally. Sandboxed.</span>
        <button
          onClick={exportWorkspace}
          title="Export source files as ZIP"
          className="ml-auto flex items-center gap-1 hover:text-accent"
        >
          <Icon name="download" className="h-3 w-3" />
          Export
        </button>
      </footer>
    </section>
  );
}
