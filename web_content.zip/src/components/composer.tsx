import { useEffect, useState, type FormEvent } from "react";
import { ImagePlus, X } from "lucide-react";
import { createPost } from "@/lib/cutegirls/api";
import { compressImage } from "@/lib/cutegirls/images";
import { HOME_KINDS, POST_KINDS, type GroupCard, type PostKind } from "@/lib/cutegirls/model";
import { useSalon } from "@/lib/cutegirls/store";
import { fieldClass, primaryBtn, quietBtn } from "./bits";

export function Composer({ groups }: { groups: GroupCard[] }) {
  const compose = useSalon((s) => s.compose);
  const close = useSalon((s) => s.closeCompose);
  const bump = useSalon((s) => s.bump);
  const [kind, setKind] = useState<PostKind>("vent");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [link, setLink] = useState("");
  const [media, setMedia] = useState<string | null>(null);
  const [groupSlug, setGroupSlug] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  useEffect(() => {
    if (!compose.open) return;
    setKind(compose.kind ?? "vent");
    setGroupSlug(compose.group ?? "");
    setTitle("");
    setBody("");
    setLink("");
    setMedia(null);
    setError(null);
  }, [compose.open, compose.kind, compose.group]);

  if (!compose.open) return null;

  const kinds: PostKind[] = compose.kind === "reel" || compose.kind === "subliminal"
    ? [compose.kind]
    : [...HOME_KINDS];
  const needsTitle = kind === "contest" || kind === "news" || kind === "subliminal";
  const needsImage = kind === "reel" || kind === "subliminal";

  async function onFile(file: File | undefined) {
    if (!file) return;
    setError(null);
    try {
      const max = kind === "reel" ? 500_000 : 400_000;
      const data = await compressImage(file, kind === "reel" ? 1080 : 1400, max);
      setMedia(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر قراءة الصورة");
    }
  }

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setPending(true);
    setError(null);
    try {
      const result = await createPost({
        data: { kind, title, body, link, media, groupSlug: groupSlug || null },
      });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      close();
      bump();
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر النشر");
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 grid place-items-end bg-ink/40 p-3 md:place-items-center" role="presentation">
      <form
        onSubmit={onSubmit}
        className="max-h-dvh w-full max-w-lg overflow-y-auto rounded-3xl bg-paper p-5 shadow-lift"
        role="dialog"
        aria-labelledby="compose-title"
      >
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-xs tracking-widest text-rose">نشر</p>
            <h2 id="compose-title" className="font-display text-3xl">
              {POST_KINDS[kind].label}
            </h2>
            <p className="text-sm text-mute">{POST_KINDS[kind].hint}. يظهر للجميع.</p>
          </div>
          <button type="button" className="grid size-11 place-items-center rounded-full bg-ivory" onClick={close} aria-label="إغلاق">
            <X className="size-4" />
          </button>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {kinds.map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => setKind(item)}
              className={`min-h-11 rounded-full px-4 text-sm ${kind === item ? "bg-rose text-paper" : "bg-ivory text-ink"}`}
            >
              {POST_KINDS[item].label}
            </button>
          ))}
        </div>
        <div className="mt-4 space-y-3">
          {needsTitle ? (
            <input
              className={`${fieldClass} h-12`}
              placeholder={kind === "contest" ? "سؤال المسابقة" : "العنوان"}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          ) : null}
          <textarea
            className={`${fieldClass} min-h-32 py-3`}
            placeholder={kind === "subliminal" ? "وصف السيبلمنال" : kind === "reel" ? "تعليق اختياري على الميم" : "اكتب هنا"}
            value={body}
            onChange={(e) => setBody(e.target.value)}
          />
          {kind === "subliminal" ? (
            <input
              className={`${fieldClass} h-12`}
              dir="ltr"
              placeholder="https://youtube.com/watch?v=…"
              value={link}
              onChange={(e) => setLink(e.target.value)}
            />
          ) : null}
          {needsImage ? (
            <label className="flex min-h-24 cursor-pointer flex-col items-center justify-center gap-2 rounded-3xl bg-ivory text-sm text-mute">
              {media ? (
                <img src={media} alt="" className="max-h-56 w-full rounded-3xl object-cover" />
              ) : (
                <>
                  <ImagePlus className="size-5" />
                  {kind === "reel" ? "صورة الميم أو الريل" : "غلاف اختياري"}
                </>
              )}
              <input
                type="file"
                accept="image/*"
                className="sr-only"
                onChange={(e) => void onFile(e.target.files?.[0])}
              />
            </label>
          ) : null}
          {groups.length ? (
            <label className="block space-y-1.5 text-sm">
              <span className="text-mute">أين يُنشر</span>
              <select
                className={`${fieldClass} h-12`}
                value={groupSlug}
                onChange={(e) => setGroupSlug(e.target.value)}
              >
                <option value="">الساحة العامة</option>
                {groups.map((group) => (
                  <option key={group.slug} value={group.slug}>
                    {group.name}
                  </option>
                ))}
              </select>
            </label>
          ) : null}
          {error ? <p className="text-sm text-rose">{error}</p> : null}
          <div className="flex gap-2">
            <button className={primaryBtn} type="submit" disabled={pending}>
              {pending ? "يُنشر…" : "نشر"}
            </button>
            <button className={quietBtn} type="button" onClick={close}>
              إلغاء
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
