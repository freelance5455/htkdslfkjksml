import React from 'react';
import { AssetData } from '../types/market';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface MarketTickerTapeProps {
  assets: AssetData[];
  onSelectAsset: (asset: AssetData) => void;
}

export const MarketTickerTape: React.FC<MarketTickerTapeProps> = ({ assets, onSelectAsset }) => {
  if (assets.length === 0) return null;

  // Duplicate for seamless marquee effect
  const displayItems = [...assets, ...assets];

  return (
    <div className="w-full bg-slate-900/60 border-b border-slate-800/80 overflow-hidden py-2 select-none">
      <div className="flex w-max animate-[marquee_45s_linear_infinite] hover:[animation-play-state:paused] gap-6">
        {displayItems.map((asset, index) => {
          const isPositive = asset.change24h >= 0;
          return (
            <button
              key={`${asset.id}-${index}`}
              onClick={() => onSelectAsset(asset)}
              className="flex items-center gap-2.5 px-3 py-1 rounded-lg bg-slate-950/60 border border-slate-800/60 hover:border-amber-500/40 hover:bg-slate-900 transition-all cursor-pointer text-left"
            >
              <div className="flex items-center gap-1.5">
                <span className="font-mono font-bold text-xs text-white">{asset.symbol}</span>
                <span className="text-[10px] text-slate-400 uppercase">{asset.category}</span>
              </div>

              <span className={`font-mono font-semibold text-xs transition-colors duration-300 ${
                asset.tickDirection === 'up'
                  ? 'text-emerald-400'
                  : asset.tickDirection === 'down'
                  ? 'text-rose-400'
                  : 'text-slate-200'
              }`}>
                ${asset.price.toLocaleString(undefined, {
                  minimumFractionDigits: asset.price < 1 ? 4 : 2,
                  maximumFractionDigits: asset.price < 1 ? 4 : 2,
                })}
              </span>

              <div className={`flex items-center text-[11px] font-mono font-medium ${
                isPositive ? 'text-emerald-400' : 'text-rose-400'
              }`}>
                {isPositive ? (
                  <TrendingUp className="w-3 h-3 mr-0.5 inline" />
                ) : (
                  <TrendingDown className="w-3 h-3 mr-0.5 inline" />
                )}
                <span>{isPositive ? '+' : ''}{asset.change24h}%</span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
