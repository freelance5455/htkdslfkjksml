import React, { useEffect, useState } from 'react';
import {
  ChartNoAxesCombined,
  Download,
  Plus,
  RefreshCw,
  Shield,
  Tag,
  Trash2,
} from 'lucide-react';
import { apiRequest, downloadWithAuth, formatBytes, formatDateTr } from '../lib/api';
import type {
  ErrorLogRow,
  MembershipInfo,
  PaymentRecord,
  PromoCodeRow,
  SubscriptionPlan,
  SystemLimitsRow,
} from '../types/studio';

interface AdminUserRow {
  id: string;
  username: string;
  email: string;
  role: 'user' | 'admin';
  created_at: string;
  membership: MembershipInfo;
}

interface AdminBuildRow {
  id: string;
  project_id: string;
  project_name: string;
  app_name: string;
  package_name: string;
  version_name: string;
  owner_email: string;
  owner_username: string;
  status: string;
  artifact_filename: string | null;
  artifact_size_bytes: number;
  created_at: string;
}

interface AuditLogRow {
  id: string;
  actor_email: string | null;
  action: string;
  target_type: string;
  target_id: string | null;
  details_json: string;
  created_at: string;
}

interface AdminOverviewData {
  stats: {
    totalUsers: number;
    premiumUsers: number;
    totalProjects: number;
    totalBuilds: number;
    completedBuilds: number;
    failedBuilds: number;
    totalRevenueTry: number;
    monthlyRevenueTry: number;
    activePromoCodes: number;
  };
  revenueByPlan: Array<{ plan_name: string; sales_count: number; revenue_try: number }>;
  users: AdminUserRow[];
  builds: AdminBuildRow[];
  payments: PaymentRecord[];
  promoCodes: PromoCodeRow[];
  plans: SubscriptionPlan[];
  limits: SystemLimitsRow[];
  systemSettings: Record<string, string>;
  errorLogs: ErrorLogRow[];
  auditLogs: AuditLogRow[];
}

interface AdminViewProps {
  onMembershipUpdated: () => Promise<void>;
}

export const AdminView: React.FC<AdminViewProps> = ({ onMembershipUpdated }) => {
  const [data, setData] = useState<AdminOverviewData | null>(null);
  const [tab, setTab] = useState<'stats' | 'users' | 'builds' | 'promos' | 'plans' | 'logs'>(
    'stats'
  );
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [grantPlanMap, setGrantPlanMap] = useState<Record<string, string>>({});

  // New Promo Form State
  const [promoCode, setPromoCode] = useState('');
  const [promoDiscount, setPromoDiscount] = useState(20);
  const [promoMaxUses, setPromoMaxUses] = useState(100);
  const [promoExpires, setPromoExpires] = useState('');

  const loadOverview = async () => {
    setLoading(true);
    try {
      const res = await apiRequest<AdminOverviewData>('/api/admin/overview');
      setData(res);
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Yönetici verileri yüklenemedi.',
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadOverview();
  }, []);

  const handleGrantPremium = async (userId: string) => {
    const planId = grantPlanMap[userId] || 'plan_monthly';
    setFeedback(null);
    try {
      await apiRequest('/api/admin/subscriptions/grant', {
        method: 'POST',
        body: JSON.stringify({ userId, planId }),
      });
      setFeedback({ type: 'ok', text: 'Kullanıcıya manuel Premium üyelik tanımlandı.' });
      await loadOverview();
      await onMembershipUpdated();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'İşlem başarısız.' });
    }
  };

  const handleExtend = async (subscriptionId: string, days: number) => {
    setFeedback(null);
    try {
      await apiRequest(`/api/admin/subscriptions/${subscriptionId}/extend`, {
        method: 'POST',
        body: JSON.stringify({ days }),
      });
      setFeedback({ type: 'ok', text: `Üyelik süresi +${days} gün uzatıldı.` });
      await loadOverview();
      await onMembershipUpdated();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Uzatma başarısız.' });
    }
  };

  const handleCancelSub = async (subscriptionId: string) => {
    setFeedback(null);
    try {
      await apiRequest(`/api/admin/subscriptions/${subscriptionId}/cancel`, {
        method: 'POST',
      });
      setFeedback({ type: 'ok', text: 'Üyelik iptal edildi.' });
      await loadOverview();
      await onMembershipUpdated();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'İptal başarısız.' });
    }
  };

  const handleRoleToggle = async (u: AdminUserRow) => {
    const nextRole = u.role === 'admin' ? 'user' : 'admin';
    setFeedback(null);
    try {
      await apiRequest(`/api/admin/users/${u.id}/role`, {
        method: 'PUT',
        body: JSON.stringify({ role: nextRole }),
      });
      setFeedback({ type: 'ok', text: `${u.email} rolü "${nextRole}" olarak güncellendi.` });
      await loadOverview();
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Rol güncellenemedi.',
      });
    }
  };

  const handleCreatePromo = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    try {
      await apiRequest('/api/admin/promo-codes', {
        method: 'POST',
        body: JSON.stringify({
          code: promoCode,
          discountPercent: promoDiscount,
          maxUses: promoMaxUses,
          expiresAt: promoExpires || null,
        }),
      });
      setPromoCode('');
      setPromoExpires('');
      setFeedback({ type: 'ok', text: 'Promosyon kodu oluşturuldu.' });
      await loadOverview();
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Promosyon kodu oluşturulamadı.',
      });
    }
  };

  const handleTogglePromo = async (promo: PromoCodeRow) => {
    try {
      await apiRequest(`/api/admin/promo-codes/${promo.id}`, {
        method: 'PUT',
        body: JSON.stringify({ is_active: !promo.is_active }),
      });
      await loadOverview();
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Durum değiştirilemedi.',
      });
    }
  };

  const handleDeletePromo = async (id: string) => {
    try {
      await apiRequest(`/api/admin/promo-codes/${id}`, { method: 'DELETE' });
      await loadOverview();
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'Silinemedi.' });
    }
  };

  const handleUpdatePlan = async (plan: SubscriptionPlan) => {
    setFeedback(null);
    try {
      await apiRequest(`/api/admin/plans/${plan.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          price_try: plan.price_try,
          duration_days: plan.duration_days,
        }),
      });
      setFeedback({ type: 'ok', text: `"${plan.name}" paket fiyatı güncellendi.` });
      await loadOverview();
      await onMembershipUpdated();
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Paket güncellenemedi.',
      });
    }
  };

  const handleUpdateLimit = async (lim: SystemLimitsRow) => {
    setFeedback(null);
    try {
      await apiRequest(`/api/admin/limits/${lim.tier}`, {
        method: 'PUT',
        body: JSON.stringify(lim),
      });
      setFeedback({ type: 'ok', text: `"${lim.tier}" seviye limitleri güncellendi.` });
      await loadOverview();
      await onMembershipUpdated();
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Limit güncellenemedi.',
      });
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!data) return;
    setFeedback(null);
    try {
      await apiRequest('/api/admin/settings', {
        method: 'PUT',
        body: JSON.stringify(data.systemSettings),
      });
      setFeedback({ type: 'ok', text: 'Sistem ayarları kaydedildi.' });
      await loadOverview();
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Ayarlar kaydedilemedi.',
      });
    }
  };

  if (loading && !data) {
    return (
      <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-10 text-sm text-slate-500 dark:text-[#94A3B8]">
        Yönetim paneli yükleniyor...
      </div>
    );
  }

  if (!data) {
    return (
      <div className="bg-white dark:bg-[#151D2E] border border-red-500/20 rounded-2xl p-8 text-sm text-[#EF4444]">
        {feedback?.text || 'Yönetim paneline erişilemedi.'}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col xl:flex-row xl:items-end justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#CA8A04] dark:text-[#EAB308] mb-1">
            <Shield className="w-4 h-4" />
            <span>Yönetici Kontrol Merkezi</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-[#F8FAFC]">
            Platform Yönetimi & Analizler
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex flex-wrap p-1 bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-xl gap-1">
            {(
              [
                { id: 'stats', label: 'İstatistikler' },
                { id: 'users', label: `Kullanıcılar (${data.users.length})` },
                { id: 'builds', label: `Derlemeler (${data.builds.length})` },
                { id: 'promos', label: `Promosyon (${data.promoCodes.length})` },
                { id: 'plans', label: 'Paket & Ayarlar' },
                { id: 'logs', label: 'Ödeme & Loglar' },
              ] as const
            ).map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
                  tab === t.id
                    ? 'bg-[#6366F1] text-white'
                    : 'text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => void loadOverview()}
            className="p-2 rounded-xl bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] text-slate-500 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white"
            aria-label="Yenile"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {feedback && (
        <div
          className={`px-4 py-3 rounded-xl border text-xs ${
            feedback.type === 'ok'
              ? 'bg-emerald-500/10 border-emerald-500/25 text-emerald-700 dark:text-[#22C55E]'
              : 'bg-red-500/10 border-red-500/25 text-red-600 dark:text-[#EF4444]'
          }`}
        >
          {feedback.text}
        </div>
      )}

      {/* TAB 1: Statistics & Revenue Analytics */}
      {tab === 'stats' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-xl p-5">
              <p className="text-xs text-slate-500 dark:text-[#94A3B8]">Toplam Kullanıcı</p>
              <p className="mt-2 text-2xl font-bold tabular-nums text-slate-900 dark:text-[#F8FAFC]">
                {data.stats.totalUsers}{' '}
                <span className="text-xs font-normal text-[#EAB308]">
                  ({data.stats.premiumUsers} Premium)
                </span>
              </p>
            </div>
            <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-xl p-5">
              <p className="text-xs text-slate-500 dark:text-[#94A3B8]">APK Derleme Sayısı</p>
              <p className="mt-2 text-2xl font-bold tabular-nums text-slate-900 dark:text-[#F8FAFC]">
                {data.stats.completedBuilds}{' '}
                <span className="text-xs font-normal text-slate-400">
                  / {data.stats.totalBuilds} ({data.stats.failedBuilds} hata)
                </span>
              </p>
            </div>
            <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-xl p-5">
              <p className="text-xs text-slate-500 dark:text-[#94A3B8]">Toplam Gelir</p>
              <p className="mt-2 text-2xl font-bold tabular-nums text-[#22C55E]">
                {data.stats.totalRevenueTry.toLocaleString('tr-TR')} TL
              </p>
            </div>
            <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-xl p-5">
              <p className="text-xs text-slate-500 dark:text-[#94A3B8]">Son 30 Gün Gelir</p>
              <p className="mt-2 text-2xl font-bold tabular-nums text-slate-900 dark:text-[#F8FAFC]">
                {data.stats.monthlyRevenueTry.toLocaleString('tr-TR')} TL
              </p>
            </div>
          </div>

          <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-6 space-y-4">
            <div className="flex items-center gap-2">
              <ChartNoAxesCombined className="w-4 h-4 text-[#6366F1]" />
              <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
                Paket Bazlı Gelir Dağılımı
              </h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {data.revenueByPlan.map((row) => (
                <div
                  key={row.plan_name}
                  className="p-4 rounded-xl bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.06]"
                >
                  <div className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC]">
                    {row.plan_name}
                  </div>
                  <div className="mt-2 text-xl font-bold font-mono tabular-nums text-[#6366F1]">
                    {row.revenue_try.toLocaleString('tr-TR')} TL
                  </div>
                  <div className="mt-1 text-[11px] text-slate-500 dark:text-[#94A3B8] tabular-nums">
                    {row.sales_count} doğrulanmış satış
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Users & Premium Management */}
      {tab === 'users' && (
        <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-white/[0.08] text-slate-500 dark:text-[#94A3B8]">
                  <th className="py-3 px-5">Kullanıcı</th>
                  <th className="py-3 px-4">Rol</th>
                  <th className="py-3 px-4">Üyelik</th>
                  <th className="py-3 px-4">Kalan</th>
                  <th className="py-3 px-4">Kullanım</th>
                  <th className="py-3 px-5 text-right">Yönetici İşlemleri</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-white/[0.06]">
                {data.users.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50 dark:hover:bg-white/[0.02]">
                    <td className="py-3.5 px-5">
                      <div className="font-semibold text-slate-900 dark:text-[#F8FAFC]">
                        {u.username}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-[#94A3B8]">
                        {u.email}
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <button
                        type="button"
                        onClick={() => void handleRoleToggle(u)}
                        className={`px-2 py-0.5 rounded text-[11px] font-medium border ${
                          u.role === 'admin'
                            ? 'border-[#6366F1]/40 text-[#6366F1] bg-[#6366F1]/10'
                            : 'border-slate-200 dark:border-white/[0.1] text-slate-600 dark:text-[#94A3B8]'
                        }`}
                      >
                        {u.role}
                      </button>
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={
                          u.membership.isPremium
                            ? 'text-[#CA8A04] dark:text-[#EAB308] font-semibold'
                            : 'text-slate-500 dark:text-[#94A3B8]'
                        }
                      >
                        {u.membership.planName}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 tabular-nums text-slate-700 dark:text-[#CBD5E1]">
                      {!u.membership.isPremium
                        ? 'Ücretsiz'
                        : u.membership.isLifetime
                        ? 'Süresiz'
                        : `${u.membership.remainingDays ?? 0} gün`}
                    </td>
                    <td className="py-3.5 px-4 font-mono tabular-nums text-slate-500 dark:text-[#94A3B8]">
                      {u.membership.usage.projectCount} prj ·{' '}
                      {u.membership.usage.monthlyBuildsUsed} derleme
                    </td>
                    <td className="py-3.5 px-5 text-right">
                      <div className="inline-flex flex-wrap items-center justify-end gap-1.5">
                        <select
                          value={grantPlanMap[u.id] || 'plan_monthly'}
                          onChange={(e) =>
                            setGrantPlanMap({ ...grantPlanMap, [u.id]: e.target.value })
                          }
                          className="bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-lg px-2 py-1 text-[11px] text-slate-900 dark:text-[#F8FAFC]"
                        >
                          {data.plans.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.name}
                            </option>
                          ))}
                        </select>
                        <button
                          type="button"
                          onClick={() => void handleGrantPremium(u.id)}
                          className="px-2.5 py-1 rounded-lg bg-[#6366F1] hover:bg-[#5558E3] text-white text-[11px] font-medium whitespace-nowrap"
                        >
                          Tanımla
                        </button>
                        {u.membership.subscriptionId && !u.membership.isLifetime && (
                          <button
                            type="button"
                            onClick={() => void handleExtend(u.membership.subscriptionId!, 30)}
                            className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-white/[0.08] text-slate-800 dark:text-white text-[11px] whitespace-nowrap"
                          >
                            +30 Gün
                          </button>
                        )}
                        {u.membership.subscriptionId && (
                          <button
                            type="button"
                            onClick={() => void handleCancelSub(u.membership.subscriptionId!)}
                            className="px-2.5 py-1 rounded-lg border border-red-500/30 text-[#EF4444] text-[11px] whitespace-nowrap"
                          >
                            İptal
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: Cross-User APK Builds */}
      {tab === 'builds' && (
        <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-white/[0.08] text-slate-500 dark:text-[#94A3B8]">
                  <th className="py-3 px-5">Uygulama / Paket</th>
                  <th className="py-3 px-4">Sahip</th>
                  <th className="py-3 px-4">Sürüm</th>
                  <th className="py-3 px-4">Durum</th>
                  <th className="py-3 px-4 text-right">Boyut</th>
                  <th className="py-3 px-4 text-right">Tarih</th>
                  <th className="py-3 px-5 text-right">İndir</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-white/[0.06]">
                {data.builds.map((b) => {
                  const canDl =
                    Boolean(b.artifact_filename) &&
                    (b.status === 'completed_apk' || b.status === 'completed_bundle');
                  return (
                    <tr key={b.id} className="hover:bg-slate-50 dark:hover:bg-white/[0.02]">
                      <td className="py-3 px-5">
                        <div className="font-semibold text-slate-900 dark:text-[#F8FAFC]">
                          {b.app_name || b.project_name}
                        </div>
                        <div className="font-mono text-[11px] text-slate-500 dark:text-[#94A3B8]">
                          {b.package_name}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-600 dark:text-[#CBD5E1]">
                        {b.owner_email}
                      </td>
                      <td className="py-3 px-4 font-mono tabular-nums text-slate-600 dark:text-[#CBD5E1]">
                        v{b.version_name}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`font-medium ${
                            b.status === 'completed_apk'
                              ? 'text-[#22C55E]'
                              : b.status === 'completed_bundle'
                              ? 'text-[#3B82F6]'
                              : b.status === 'failed'
                              ? 'text-[#EF4444]'
                              : 'text-amber-500'
                          }`}
                        >
                          {b.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-600 dark:text-[#CBD5E1]">
                        {b.artifact_size_bytes ? formatBytes(b.artifact_size_bytes) : '—'}
                      </td>
                      <td className="py-3 px-4 text-right tabular-nums text-slate-500 dark:text-[#94A3B8] whitespace-nowrap">
                        {formatDateTr(b.created_at)}
                      </td>
                      <td className="py-3 px-5 text-right">
                        {canDl ? (
                          <button
                            type="button"
                            onClick={() =>
                              void downloadWithAuth(
                                `/api/admin/builds/${b.id}/download`,
                                b.artifact_filename || `${b.id}.apk`
                              )
                            }
                            className="inline-flex items-center gap-1 text-xs font-medium text-[#3B82F6] hover:underline"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>İndir</span>
                          </button>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: Promo Codes */}
      {tab === 'promos' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <form
            onSubmit={handleCreatePromo}
            className="lg:col-span-4 bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-6 space-y-4"
          >
            <div className="flex items-center gap-2">
              <Tag className="w-4 h-4 text-[#6366F1]" />
              <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
                Yeni Promosyon Kodu
              </h2>
            </div>

            <div>
              <label className="block text-xs text-slate-600 dark:text-[#94A3B8] mb-1">
                Kod (ör. LAUNCH25)
              </label>
              <input
                type="text"
                required
                minLength={3}
                maxLength={32}
                value={promoCode}
                onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
                className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3.5 py-2 text-xs font-mono text-slate-900 dark:text-[#F8FAFC]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-slate-600 dark:text-[#94A3B8] mb-1">
                  İndirim (%)
                </label>
                <input
                  type="number"
                  min={1}
                  max={95}
                  required
                  value={promoDiscount}
                  onChange={(e) => setPromoDiscount(Number(e.target.value) || 10)}
                  className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3 py-2 text-xs font-mono text-slate-900 dark:text-[#F8FAFC]"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-600 dark:text-[#94A3B8] mb-1">
                  Kullanım Limiti
                </label>
                <input
                  type="number"
                  min={1}
                  required
                  value={promoMaxUses}
                  onChange={(e) => setPromoMaxUses(Number(e.target.value) || 100)}
                  className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3 py-2 text-xs font-mono text-slate-900 dark:text-[#F8FAFC]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-600 dark:text-[#94A3B8] mb-1">
                Son Kullanma Tarihi (Opsiyonel)
              </label>
              <input
                type="date"
                value={promoExpires}
                onChange={(e) => setPromoExpires(e.target.value)}
                className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3.5 py-2 text-xs text-slate-900 dark:text-[#F8FAFC]"
              />
            </div>

            <button
              type="submit"
              className="w-full inline-flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-xl bg-[#6366F1] hover:bg-[#5558E3] text-white text-xs font-semibold"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Kodu Oluştur</span>
            </button>
          </form>

          <div className="lg:col-span-8 bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 dark:border-white/[0.08]">
              <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
                Kayıtlı Promosyon Kodları
              </h2>
            </div>
            {data.promoCodes.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500 dark:text-[#94A3B8]">
                Henüz promosyon kodu oluşturulmamış.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-white/[0.06] text-slate-500 dark:text-[#94A3B8]">
                      <th className="py-3 px-5">Kod</th>
                      <th className="py-3 px-4">İndirim</th>
                      <th className="py-3 px-4">Kullanım</th>
                      <th className="py-3 px-4">Bitiş</th>
                      <th className="py-3 px-4">Durum</th>
                      <th className="py-3 px-5 text-right">İşlem</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-white/[0.06]">
                    {data.promoCodes.map((pc) => (
                      <tr key={pc.id}>
                        <td className="py-3 px-5 font-mono font-bold text-slate-900 dark:text-[#F8FAFC]">
                          {pc.code}
                        </td>
                        <td className="py-3 px-4 font-mono text-[#22C55E]">
                          %{pc.discount_percent}
                        </td>
                        <td className="py-3 px-4 font-mono tabular-nums text-slate-600 dark:text-[#CBD5E1]">
                          {pc.current_uses} / {pc.max_uses}
                        </td>
                        <td className="py-3 px-4 tabular-nums text-slate-500 dark:text-[#94A3B8]">
                          {pc.expires_at ? formatDateTr(pc.expires_at) : 'Süresiz'}
                        </td>
                        <td className="py-3 px-4">
                          <button
                            type="button"
                            onClick={() => void handleTogglePromo(pc)}
                            className={`text-xs font-semibold ${
                              pc.is_active ? 'text-[#22C55E]' : 'text-slate-400'
                            }`}
                          >
                            {pc.is_active ? 'Aktif' : 'Pasif'}
                          </button>
                        </td>
                        <td className="py-3 px-5 text-right">
                          <button
                            type="button"
                            onClick={() => void handleDeletePromo(pc.id)}
                            className="text-slate-400 hover:text-[#EF4444]"
                            aria-label="Kodu Sil"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 5: Plans, Limits & System Settings */}
      {tab === 'plans' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-6 space-y-4">
              <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
                Üyelik Paket Fiyatları
              </h2>
              {data.plans.map((plan, idx) => (
                <div
                  key={plan.id}
                  className="p-4 rounded-xl bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.06] space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC]">
                      {plan.name}
                    </span>
                    <span className="text-[11px] text-slate-500 dark:text-[#94A3B8]">
                      {plan.is_lifetime ? 'Süresiz' : `${plan.duration_days} gün`}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] text-slate-500 dark:text-[#94A3B8] mb-1">
                        Fiyat (TL)
                      </label>
                      <input
                        type="number"
                        min={1}
                        value={plan.price_try}
                        onChange={(e) => {
                          const next = [...data.plans];
                          next[idx] = { ...plan, price_try: Number(e.target.value) };
                          setData({ ...data, plans: next });
                        }}
                        className="w-full bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-lg px-3 py-1.5 text-xs font-mono text-slate-900 dark:text-[#F8FAFC]"
                      />
                    </div>
                    {!plan.is_lifetime && (
                      <div>
                        <label className="block text-[11px] text-slate-500 dark:text-[#94A3B8] mb-1">
                          Süre (Gün)
                        </label>
                        <input
                          type="number"
                          min={1}
                          value={plan.duration_days || 30}
                          onChange={(e) => {
                            const next = [...data.plans];
                            next[idx] = { ...plan, duration_days: Number(e.target.value) };
                            setData({ ...data, plans: next });
                          }}
                          className="w-full bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-lg px-3 py-1.5 text-xs font-mono text-slate-900 dark:text-[#F8FAFC]"
                        />
                      </div>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => void handleUpdatePlan(plan)}
                    className="px-3 py-1.5 text-xs font-medium rounded-lg bg-[#6366F1] hover:bg-[#5558E3] text-white"
                  >
                    Paketi Güncelle
                  </button>
                </div>
              ))}
            </div>

            <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-6 space-y-4">
              <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
                Ücretsiz & Premium Limitleri
              </h2>
              {data.limits.map((lim, idx) => (
                <div
                  key={lim.tier}
                  className="p-4 rounded-xl bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.06] space-y-3"
                >
                  <div className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC]">
                    {lim.tier === 'premium' ? 'Premium Seviyesi' : 'Ücretsiz Seviye'}
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[11px] text-slate-500 dark:text-[#94A3B8] mb-1">
                        Maks. Proje
                      </label>
                      <input
                        type="number"
                        min={1}
                        value={lim.max_projects}
                        onChange={(e) => {
                          const next = [...data.limits];
                          next[idx] = { ...lim, max_projects: Number(e.target.value) };
                          setData({ ...data, limits: next });
                        }}
                        className="w-full bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-lg px-2.5 py-1.5 text-xs font-mono text-slate-900 dark:text-[#F8FAFC]"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-500 dark:text-[#94A3B8] mb-1">
                        Aylık Derleme
                      </label>
                      <input
                        type="number"
                        min={1}
                        value={lim.monthly_builds}
                        onChange={(e) => {
                          const next = [...data.limits];
                          next[idx] = { ...lim, monthly_builds: Number(e.target.value) };
                          setData({ ...data, limits: next });
                        }}
                        className="w-full bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-lg px-2.5 py-1.5 text-xs font-mono text-slate-900 dark:text-[#F8FAFC]"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-500 dark:text-[#94A3B8] mb-1">
                        Maks. MB
                      </label>
                      <input
                        type="number"
                        min={1}
                        value={lim.max_upload_mb}
                        onChange={(e) => {
                          const next = [...data.limits];
                          next[idx] = { ...lim, max_upload_mb: Number(e.target.value) };
                          setData({ ...data, limits: next });
                        }}
                        className="w-full bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-lg px-2.5 py-1.5 text-xs font-mono text-slate-900 dark:text-[#F8FAFC]"
                      />
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-4 text-xs text-slate-700 dark:text-[#CBD5E1]">
                    <label className="inline-flex items-center gap-1.5">
                      <input
                        type="checkbox"
                        checked={Boolean(lim.priority_queue)}
                        onChange={(e) => {
                          const next = [...data.limits];
                          next[idx] = { ...lim, priority_queue: e.target.checked ? 1 : 0 };
                          setData({ ...data, limits: next });
                        }}
                      />
                      <span>Öncelikli Kuyruk</span>
                    </label>
                    <label className="inline-flex items-center gap-1.5">
                      <input
                        type="checkbox"
                        checked={Boolean(lim.premium_icons)}
                        onChange={(e) => {
                          const next = [...data.limits];
                          next[idx] = { ...lim, premium_icons: e.target.checked ? 1 : 0 };
                          setData({ ...data, limits: next });
                        }}
                      />
                      <span>Premium İkonlar</span>
                    </label>
                  </div>
                  <button
                    type="button"
                    onClick={() => void handleUpdateLimit(lim)}
                    className="px-3 py-1.5 text-xs font-medium rounded-lg bg-[#3B82F6] hover:bg-[#2563EB] text-white"
                  >
                    Limitleri Kaydet
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* System Settings */}
          <form
            onSubmit={handleSaveSettings}
            className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-6 space-y-4"
          >
            <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
              Sistem Ayarları
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <label className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.06]">
                <span className="text-slate-700 dark:text-[#CBD5E1]">Yeni Üye Kaydı Açık</span>
                <input
                  type="checkbox"
                  checked={data.systemSettings.allow_registration !== 'false'}
                  onChange={(e) =>
                    setData({
                      ...data,
                      systemSettings: {
                        ...data.systemSettings,
                        allow_registration: e.target.checked ? 'true' : 'false',
                      },
                    })
                  }
                  className="accent-[#6366F1] w-4 h-4"
                />
              </label>

              <label className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.06]">
                <span className="text-slate-700 dark:text-[#CBD5E1]">Bakım Modu (Derleme Durur)</span>
                <input
                  type="checkbox"
                  checked={data.systemSettings.maintenance_mode === 'true'}
                  onChange={(e) =>
                    setData({
                      ...data,
                      systemSettings: {
                        ...data.systemSettings,
                        maintenance_mode: e.target.checked ? 'true' : 'false',
                      },
                    })
                  }
                  className="accent-[#6366F1] w-4 h-4"
                />
              </label>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.06]">
                <label className="block text-[11px] text-slate-500 dark:text-[#94A3B8] mb-1">
                  Derleme Zaman Aşımı (ms)
                </label>
                <input
                  type="number"
                  min={60000}
                  step={10000}
                  value={Number(data.systemSettings.default_build_timeout_ms || 300000)}
                  onChange={(e) =>
                    setData({
                      ...data,
                      systemSettings: {
                        ...data.systemSettings,
                        default_build_timeout_ms: String(Math.max(60000, Number(e.target.value))),
                      },
                    })
                  }
                  className="w-full bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-lg px-2.5 py-1 text-xs font-mono text-slate-900 dark:text-[#F8FAFC]"
                />
              </div>
            </div>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-[#6366F1] hover:bg-[#5558E3] text-white"
            >
              Sistem Ayarlarını Kaydet
            </button>
          </form>
        </div>
      )}

      {/* TAB 6: Payments, Error Logs & Audit Logs */}
      {tab === 'logs' && (
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 dark:border-white/[0.08]">
              <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
                Ödeme İşlemleri
              </h2>
            </div>
            <div className="divide-y divide-slate-100 dark:divide-white/[0.06] max-h-[460px] overflow-y-auto text-xs">
              {data.payments.length === 0 ? (
                <div className="p-6 text-slate-500 dark:text-[#94A3B8]">Henüz ödeme kaydı yok.</div>
              ) : (
                data.payments.map((p) => (
                  <div key={p.id} className="px-5 py-3 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="font-medium text-slate-900 dark:text-[#F8FAFC] truncate">
                        {p.user_email} · {p.plan_name}
                      </div>
                      <div className="text-[11px] font-mono text-slate-500 dark:text-[#94A3B8] truncate">
                        {p.provider_reference}
                        {p.promo_code ? ` · ${p.promo_code}` : ''}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="font-mono font-semibold text-slate-900 dark:text-[#F8FAFC] tabular-nums">
                        {p.amount_try} TL
                      </div>
                      <div
                        className={`text-[11px] ${
                          p.status === 'completed' ? 'text-[#22C55E]' : 'text-amber-500'
                        }`}
                      >
                        {p.status}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 dark:border-white/[0.08]">
              <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
                Hata Kayıtları ({data.errorLogs.length})
              </h2>
            </div>
            <div className="divide-y divide-slate-100 dark:divide-white/[0.06] max-h-[460px] overflow-y-auto text-xs">
              {data.errorLogs.length === 0 ? (
                <div className="p-6 text-slate-500 dark:text-[#94A3B8]">
                  Sistemde kayıtlı hata logu yok.
                </div>
              ) : (
                data.errorLogs.map((err) => (
                  <div key={err.id} className="px-5 py-3 space-y-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono font-semibold text-[#EF4444]">{err.source}</span>
                      <span className="text-[11px] text-slate-500 dark:text-[#94A3B8] tabular-nums">
                        {formatDateTr(err.created_at)}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-700 dark:text-[#CBD5E1] break-words">
                      {err.message}
                    </p>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 dark:border-white/[0.08]">
              <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
                Denetim Kayıtları (Audit)
              </h2>
            </div>
            <div className="divide-y divide-slate-100 dark:divide-white/[0.06] max-h-[460px] overflow-y-auto text-xs">
              {data.auditLogs.length === 0 ? (
                <div className="p-6 text-slate-500 dark:text-[#94A3B8]">
                  Kayıtlı denetim olayı yok.
                </div>
              ) : (
                data.auditLogs.map((log) => (
                  <div key={log.id} className="px-5 py-3 space-y-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono font-semibold text-slate-900 dark:text-[#F8FAFC]">
                        {log.action}
                      </span>
                      <span className="text-[11px] text-slate-500 dark:text-[#94A3B8] tabular-nums">
                        {formatDateTr(log.created_at)}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-600 dark:text-[#94A3B8]">
                      Aktör: {log.actor_email || 'Sistem'} · Hedef: {log.target_type} (
                      {log.target_id || '—'})
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
