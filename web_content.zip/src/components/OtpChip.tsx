import React, { useState } from 'react';
import { Copy, Check, ShieldCheck } from 'lucide-react';

interface OtpChipProps {
  code: string;
  label?: string;
  compact?: boolean;
}

export const OtpChip: React.FC<OtpChipProps> = ({ code, label = 'Verification Code', compact = false }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  if (compact) {
    return (
      <button
        onClick={handleCopy}
        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono font-bold bg-blue-50 text-blue-700 border border-blue-200 hover:bg-blue-100 transition-all shadow-sm active:scale-95 cursor-pointer"
        title="Tap to copy OTP"
      >
        <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
        <span>{code}</span>
        {copied ? <Check className="w-3 h-3 text-blue-800" /> : <Copy className="w-3 h-3 text-blue-500" />}
      </button>
    );
  }

  return (
    <div className="bg-gradient-to-r from-blue-50 via-sky-50 to-blue-50 border-2 border-blue-200 rounded-xl p-3.5 flex items-center justify-between gap-3 shadow-md shadow-blue-500/5 my-2">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-sm shadow-blue-600/30">
          <ShieldCheck className="w-5 h-5" />
        </div>
        <div>
          <div className="text-[11px] font-bold text-blue-800 uppercase tracking-wider">{label}</div>
          <div className="text-2xl font-mono font-extrabold tracking-widest text-blue-900">{code}</div>
        </div>
      </div>

      <button
        onClick={handleCopy}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all shadow-xs active:scale-95 cursor-pointer ${
          copied
            ? 'bg-blue-700 text-white'
            : 'bg-blue-600 hover:bg-blue-700 text-white shadow-xs'
        }`}
      >
        {copied ? (
          <>
            <Check className="w-3.5 h-3.5" />
            <span>Copied!</span>
          </>
        ) : (
          <>
            <Copy className="w-3.5 h-3.5" />
            <span>Copy Code</span>
          </>
        )}
      </button>
    </div>
  );
};
