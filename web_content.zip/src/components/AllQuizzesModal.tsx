import React, { useState } from 'react';
import { 
  X, 
  Trophy, 
  Clock, 
  Calendar, 
  Gift, 
  ChevronRight, 
  Sparkles, 
  Users, 
  HelpCircle,
  Flame,
  Award,
  CheckCircle2
} from 'lucide-react';
import { WeeklyQuiz, WeeklyQuizSubmission, UserProfile } from '../types';

interface AllQuizzesModalProps {
  language: string;
  isOpen: boolean;
  onClose: () => void;
  quizzes: WeeklyQuiz[];
  userProfile?: UserProfile;
  onSelectQuiz: (quiz: WeeklyQuiz) => void;
  onTakeQuiz: (quiz: WeeklyQuiz) => void;
  onViewLeaderboard: (quiz: WeeklyQuiz) => void;
}

export default function AllQuizzesModal({
  language,
  isOpen,
  onClose,
  quizzes,
  userProfile,
  onSelectQuiz,
  onTakeQuiz,
  onViewLeaderboard
}: AllQuizzesModalProps) {
  const [activeTab, setActiveTab] = useState<'all' | 'live' | 'upcoming' | 'ended'>('all');
  const isBn = language === 'bn';

  if (!isOpen) return null;

  const filteredQuizzes = quizzes.filter(q => {
    if (activeTab === 'live') return q.status === 'live';
    if (activeTab === 'upcoming') return q.status === 'scheduled';
    if (activeTab === 'ended') return q.status === 'ended';
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-4xl max-h-[90vh] flex flex-col bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden my-auto">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-indigo-950/60 via-purple-950/40 to-slate-900">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500/20 border border-amber-500/40 text-amber-400 rounded-2xl">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
                <span>{isBn ? 'সমস্ত কুইজ চ্যালেঞ্জ হাব' : 'All Quiz Challenges Hub'}</span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 font-bold">
                  {quizzes.length} {isBn ? 'টি কুইজ' : 'Quizzes'}
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                {isBn ? 'লাইভ ও আসন্ন প্রতিযোগিতায় অংশ নিয়ে আকর্ষণীয় পুরস্কার অর্জন করুন' : 'Participate in live & upcoming quiz events to win rewards'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-700 rounded-full transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Tabs */}
        <div className="px-5 py-3 border-b border-slate-800/80 bg-slate-950/50 flex items-center gap-2 overflow-x-auto no-scrollbar">
          {[
            { id: 'all', label: isBn ? 'সকল কুইজ' : 'All Quizzes', count: quizzes.length },
            { id: 'live', label: isBn ? '🟡 লাইভ' : '🟡 Live', count: quizzes.filter(q => q.status === 'live').length },
            { id: 'upcoming', label: isBn ? '📅 আসন্ন' : '📅 Upcoming', count: quizzes.filter(q => q.status === 'scheduled').length },
            { id: 'ended', label: isBn ? '🏆 সমাপ্ত / ফলাফল' : '🏆 Completed', count: quizzes.filter(q => q.status === 'ended').length },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
                activeTab === tab.id
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-900/40'
                  : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-700/60'
              }`}
            >
              <span>{tab.label}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-md ${
                activeTab === tab.id ? 'bg-purple-950/80 text-purple-200' : 'bg-slate-900 text-slate-400'
              }`}>
                {tab.count}
              </span>
            </button>
          ))}
        </div>

        {/* List of Quizzes */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-3.5 max-h-[60vh]">
          {filteredQuizzes.length === 0 ? (
            <div className="py-12 text-center text-slate-400 space-y-2">
              <Trophy className="w-10 h-10 mx-auto text-slate-600" />
              <p className="font-bold text-sm">{isBn ? 'এই বিভাগে কোনো কুইজ নেই' : 'No quizzes in this category'}</p>
            </div>
          ) : (
            filteredQuizzes.map((quiz) => {
              const isLive = quiz.status === 'live';
              const isScheduled = quiz.status === 'scheduled';
              const isEnded = quiz.status === 'ended';

              return (
                <div
                  key={quiz.id}
                  onClick={() => onSelectQuiz(quiz)}
                  className="bg-slate-950/80 hover:bg-slate-950 border border-slate-800 hover:border-indigo-500/40 rounded-2xl p-4 transition-all duration-200 cursor-pointer flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 group"
                >
                  {/* Left: Image & Info */}
                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3.5 flex-1 min-w-0">
                    <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden bg-slate-900 shrink-0 border border-slate-700 shadow-md self-center sm:self-auto">
                      {quiz.prizeImage ? (
                        <img 
                          src={quiz.prizeImage} 
                          alt={quiz.title} 
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-amber-400 bg-slate-900">
                          <Trophy className="w-8 h-8" />
                        </div>
                      )}
                      {isLive && (
                        <span className="absolute top-1.5 left-1.5 bg-emerald-500 text-slate-950 font-black text-[9px] px-2 py-0.5 rounded-full uppercase shadow-md flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-ping"></span>
                          <span>LIVE</span>
                        </span>
                      )}
                      {isScheduled && (
                        <span className="absolute top-1.5 left-1.5 bg-indigo-600 text-white font-bold text-[9px] px-2 py-0.5 rounded-full uppercase shadow-md">
                          UPCOMING
                        </span>
                      )}
                      {isEnded && (
                        <span className="absolute top-1.5 left-1.5 bg-slate-800 text-slate-300 font-bold text-[9px] px-2 py-0.5 rounded-full uppercase shadow-md border border-slate-700">
                          ENDED
                        </span>
                      )}
                    </div>

                    <div className="space-y-1.5 min-w-0 flex-1 w-full">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black text-indigo-400">
                          {isBn ? `সাপ্তাহিক কুইজ #${quiz.weekNumber || 1}` : `Weekly Quiz #${quiz.weekNumber || 1}`}
                        </span>
                        {quiz.prizeValue && (
                          <span className="text-[10px] font-extrabold text-emerald-400 bg-emerald-950/80 border border-emerald-500/30 px-2 py-0.5 rounded-md">
                            {quiz.prizeValue}
                          </span>
                        )}
                      </div>

                      <h3 className="text-sm sm:text-base font-black text-white truncate group-hover:text-amber-200 transition-colors">
                        {quiz.title}
                      </h3>

                      {quiz.prizeName && (
                        <div className="text-xs text-amber-300 font-bold flex items-center gap-1">
                          <span>🎁</span>
                          <span>{isBn ? '১ম পুরস্কার' : '1st Prize'}: <strong className="text-white font-extrabold">{quiz.prizeName}</strong></span>
                        </div>
                      )}

                      <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 pt-0.5">
                        <span className="flex items-center gap-1">
                          <HelpCircle className="w-3.5 h-3.5 text-slate-500" />
                          <span>{quiz.questionCount || quiz.questions?.length || 20} {isBn ? 'প্রশ্ন' : 'Qs'}</span>
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-amber-400" />
                          <span>{quiz.timeLimit || 15} {isBn ? 'মিনিট' : 'Mins'}</span>
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                          <span>{quiz.startDate} ({quiz.startTime || '09:00 AM'})</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right Action Button */}
                  <div className="shrink-0 flex items-center gap-2 w-full sm:w-auto justify-end">
                    {isLive ? (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onTakeQuiz(quiz);
                        }}
                        className="px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-black rounded-xl shadow-md cursor-pointer transition-all active:scale-95"
                      >
                        {isBn ? 'এখনই খেলুন →' : 'Play Now →'}
                      </button>
                    ) : isScheduled ? (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectQuiz(quiz);
                        }}
                        className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-indigo-300 text-xs font-bold rounded-xl border border-indigo-500/30 cursor-pointer transition-all"
                      >
                        {isBn ? 'বিস্তারিত দেখুন' : 'View Details'}
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onViewLeaderboard(quiz);
                        }}
                        className="px-4 py-2 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-bold rounded-xl border border-amber-500/40 cursor-pointer transition-all"
                      >
                        {isBn ? 'লিডারবোর্ড' : 'Leaderboard'}
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
