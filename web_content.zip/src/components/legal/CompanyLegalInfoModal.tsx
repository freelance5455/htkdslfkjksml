import React, { useState } from 'react';
import { 
  Building2, 
  ShieldCheck, 
  ExternalLink, 
  Copy, 
  Check, 
  X, 
  Upload, 
  FileText, 
  CheckCircle2, 
  AlertCircle,
  MapPin,
  Calendar,
  Award,
  Lock
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface CompanyLegalInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CompanyLegalInfoModal: React.FC<CompanyLegalInfoModalProps> = ({ isOpen, onClose }) => {
  const { companyInfo, updateCompanyInfo } = useApp();
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [isViewingCertificate, setIsViewingCertificate] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.includes('image/') && !file.type.includes('pdf')) {
      alert('Please upload a valid image or PDF document.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result as string;
      updateCompanyInfo({
        uploadedCertificateBase64: base64,
        lastVerifiedRecordTimestamp: new Date().toLocaleString('en-IN')
      });
      setUploadStatus('Official certificate uploaded and registered successfully!');
      setTimeout(() => setUploadStatus(null), 3000);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div 
        className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-teal-500/40 shadow-2xl shadow-teal-950/40 p-5 sm:p-7 space-y-6 relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Glow Accent */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-start justify-between gap-3 relative z-10 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-teal-500/15 border border-teal-500/30 flex items-center justify-center text-teal-400 shadow-inner">
              <Building2 className="w-6 h-6 text-teal-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black text-white">Company Legal & Registration</h2>
                <span className="px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 text-[10px] font-bold border border-teal-500/30">
                  Govt. Verified
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Ministry of Corporate Affairs (MCA) Registered Entity
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Corporate Legal Name & Verified Badge */}
        <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800/80 space-y-2 relative z-10">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Legal Entity Name</span>
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 text-xs font-bold border border-emerald-500/30">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              {companyInfo.mcaStatus}
            </span>
          </div>
          <h3 className="text-base sm:text-lg font-black text-white tracking-tight">
            {companyInfo.legalName}
          </h3>
          <div className="flex items-center gap-2 text-xs text-slate-300">
            <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
            <span>{companyInfo.registeredAddress}</span>
          </div>
        </div>

        {/* Registration Credentials Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 relative z-10 text-xs">
          
          {/* CIN */}
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-1.5">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
              Corporate Identification Number (CIN)
            </span>
            <div className="flex items-center justify-between">
              <span className="font-mono font-black text-teal-300 text-sm">{companyInfo.cinNumber}</span>
              <button
                onClick={() => handleCopy(companyInfo.cinNumber, 'cin')}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                title="Copy CIN"
              >
                {copiedKey === 'cin' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
            <span className="text-[10px] text-slate-500 block">Ministry of Corporate Affairs, Gov of India</span>
          </div>

          {/* GSTIN */}
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-1.5">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
              GST Registration (GSTIN)
            </span>
            <div className="flex items-center justify-between">
              <span className="font-mono font-black text-amber-300 text-sm">{companyInfo.gstinNumber || '07AABCT2026P1Z4'}</span>
              <button
                onClick={() => handleCopy(companyInfo.gstinNumber || '07AABCT2026P1Z4', 'gst')}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                title="Copy GSTIN"
              >
                {copiedKey === 'gst' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
            <span className="text-[10px] text-slate-500 block">Delhi Jurisdiction • Standard 3% Bullion GST</span>
          </div>

          {/* MSME / Udyam */}
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-1.5">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
              MSME / Udyam Registration
            </span>
            <div className="flex items-center justify-between">
              <span className="font-mono font-black text-purple-300 text-sm">{companyInfo.msmeNumber || 'UDYAM-DL-03-0098421'}</span>
              <button
                onClick={() => handleCopy(companyInfo.msmeNumber || 'UDYAM-DL-03-0098421', 'msme')}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                title="Copy MSME Number"
              >
                {copiedKey === 'msme' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
            <span className="text-[10px] text-slate-500 block">Ministry of Micro, Small & Medium Enterprises</span>
          </div>

          {/* RoC Office & Incorporation Date */}
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-1.5">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
              RoC Jurisdiction & Incorporation
            </span>
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 text-xs">{companyInfo.rocOffice}</span>
            </div>
            <span className="text-[10px] text-slate-400 block font-mono">Incorporated: {companyInfo.incorporationDate}</span>
          </div>
        </div>

        {/* Certificate View & Upload Option */}
        <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3 relative z-10">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-teal-400" />
              <span className="text-xs font-bold text-white">Incorporation Certificate Document</span>
            </div>
            <span className="text-[10px] text-emerald-400 font-mono">Verified Active</span>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            <button
              onClick={() => setIsViewingCertificate(true)}
              className="px-3.5 py-1.5 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-black text-xs transition-all shadow-md active:scale-95 cursor-pointer"
            >
              View Certificate Preview
            </button>

            <label className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 font-bold text-xs transition-all cursor-pointer flex items-center gap-1.5">
              <Upload className="w-3.5 h-3.5 text-slate-400" />
              <span>Upload New Certificate</span>
              <input 
                type="file" 
                accept="image/*,application/pdf" 
                onChange={handleFileUpload} 
                className="hidden" 
              />
            </label>
          </div>

          {uploadStatus && (
            <p className="text-xs text-emerald-400 font-bold animate-in fade-in flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>{uploadStatus}</span>
            </p>
          )}
        </div>

        {/* Official Verification Links */}
        <div className="space-y-2 relative z-10">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            Clickable Official Verification Portals (Government of India)
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
            <a
              href={companyInfo.mcaCheckUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-900 border border-teal-500/30 text-teal-300 font-bold flex items-center justify-between group transition-all"
            >
              <span>MCA Master Data</span>
              <ExternalLink className="w-3.5 h-3.5 text-teal-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </a>

            <a
              href={companyInfo.gstCheckUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-900 border border-amber-500/30 text-amber-300 font-bold flex items-center justify-between group transition-all"
            >
              <span>GST Portal Search</span>
              <ExternalLink className="w-3.5 h-3.5 text-amber-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </a>

            <a
              href={companyInfo.msmeCheckUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-900 border border-purple-500/30 text-purple-300 font-bold flex items-center justify-between group transition-all"
            >
              <span>Udyam Verification</span>
              <ExternalLink className="w-3.5 h-3.5 text-purple-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </a>
          </div>
        </div>

        {/* Security & Authenticity Notice */}
        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-400 flex items-start gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <span>
            Verified status is strictly confirmed against MCA & Ministry records. Official CIN & GSTIN are publicly verifiable on the Government of India portal 24/7.
          </span>
        </div>
      </div>

      {/* Certificate Viewer Modal */}
      {isViewingCertificate && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/90 backdrop-blur-lg">
          <div className="max-w-xl w-full bg-slate-900 border border-teal-500/50 rounded-3xl p-5 space-y-4 text-center">
            <div className="flex items-center justify-between">
              <h3 className="font-black text-white text-sm">Certificate of Incorporation</h3>
              <button 
                onClick={() => setIsViewingCertificate(false)}
                className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="max-h-[60vh] overflow-hidden rounded-2xl border border-slate-800">
              <img 
                src={companyInfo.uploadedCertificateBase64 || companyInfo.certificateImageUrl || "https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=1200&q=80"}
                alt="Registration Certificate"
                className="w-full h-auto object-contain max-h-[55vh]"
              />
            </div>

            <p className="text-[11px] text-slate-400">
              CIN: <strong className="text-teal-300 font-mono">{companyInfo.cinNumber}</strong> • Registered under MCA, Government of India
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
