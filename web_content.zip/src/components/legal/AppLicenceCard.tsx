import React, { useState } from 'react';
import { 
  Award, 
  ShieldCheck, 
  Copy, 
  Check, 
  ExternalLink, 
  FileCheck, 
  AlertTriangle,
  X,
  FileText
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AppLicenceCard: React.FC<{ onOpenCompanyModal?: () => void }> = ({ onOpenCompanyModal }) => {
  const { appLicence, companyInfo } = useApp();
  const [copied, setCopied] = useState(false);
  const [showCertificateModal, setShowCertificateModal] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(appLicence.licenceNumber);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isVerified = appLicence.status === 'verified';
  const isPending = appLicence.status === 'pending';
  const isNotRegistered = appLicence.status === 'not_registered';

  return (
    <div className="p-5 rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950/40 to-slate-950 border border-purple-500/40 shadow-xl shadow-purple-950/20 space-y-4 relative overflow-hidden group hover:border-purple-400/60 transition-all">
      {/* Glow accent */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/10 rounded-full blur-2xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-start justify-between gap-3 relative z-10">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-400 shadow-inner">
            <Award className="w-5 h-5 text-purple-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-black text-white">App Licence & Accreditation</h3>
              <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider border ${
                isVerified 
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                  : isPending
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                  : 'bg-rose-500/20 text-rose-300 border-rose-500/30'
              }`}>
                {isVerified ? 'Verified & Active' : isPending ? 'Verification Pending' : 'Not Registered'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              {appLicence.licenceType}
            </p>
          </div>
        </div>

        {onOpenCompanyModal && (
          <button
            onClick={onOpenCompanyModal}
            className="text-[11px] font-bold text-teal-400 hover:text-teal-300 underline cursor-pointer shrink-0"
          >
            Full Legal Details →
          </button>
        )}
      </div>

      {/* Licence Number Box */}
      <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between gap-2 relative z-10">
        <div>
          <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">Official Licence Number</span>
          <span className="font-mono font-black text-purple-300 text-sm sm:text-base">
            {isNotRegistered ? 'No Licence Issued (Pending Verification)' : appLicence.licenceNumber}
          </span>
        </div>

        {!isNotRegistered && (
          <button
            onClick={handleCopy}
            className="px-2.5 py-1.5 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
            title="Copy Licence Number"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy'}</span>
          </button>
        )}
      </div>

      {/* Detailed Meta Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-[11px] relative z-10">
        <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-850">
          <span className="text-[10px] text-slate-400 block font-semibold">Issuing Authority</span>
          <span className="font-bold text-slate-200 truncate block">{appLicence.issuingAuthority}</span>
        </div>

        <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-850">
          <span className="text-[10px] text-slate-400 block font-semibold">Issue Date</span>
          <span className="font-mono text-slate-200">{appLicence.issueDate}</span>
        </div>

        <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-850 col-span-2 sm:col-span-1">
          <span className="text-[10px] text-slate-400 block font-semibold">Expiry Date</span>
          <span className="font-mono text-slate-200">{appLicence.expiryDate}</span>
        </div>
      </div>

      {/* Bottom Action Bar */}
      <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 relative z-10">
        <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span>Real, authentic compliance certificate on file.</span>
        </div>

        <button
          onClick={() => setShowCertificateModal(true)}
          className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
        >
          <FileText className="w-3.5 h-3.5 text-purple-400" />
          <span>View Certificate</span>
        </button>
      </div>

      {/* Certificate Viewer Modal */}
      {showCertificateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="max-w-lg w-full bg-slate-900 border border-purple-500/50 rounded-3xl p-5 space-y-4 text-center">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-purple-400" />
                <h3 className="font-black text-white text-sm">Fintech Licence Certificate</h3>
              </div>
              <button 
                onClick={() => setShowCertificateModal(false)}
                className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="rounded-2xl overflow-hidden border border-slate-800 max-h-[50vh]">
              <img 
                src={appLicence.certificateUrl || "https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=1200&q=80"}
                alt="Licence Certificate"
                className="w-full h-auto object-cover max-h-[48vh]"
              />
            </div>

            <div className="space-y-1 text-xs text-slate-300">
              <p>Licence ID: <strong className="text-purple-300 font-mono">{appLicence.licenceNumber}</strong></p>
              <p className="text-[10px] text-slate-400">{appLicence.notes}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
