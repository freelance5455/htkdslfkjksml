import { useMemo, useState } from "react";
import type { DriverRecord } from "../data/game";
import { formatDateLabel, formatNumber } from "../data/game";
import { ArrowRight, Play, Trophy } from "./Icons";
import { Pill, Reveal, SectionIntro } from "./ui";
import { cn } from "../utils/cn";

type SortKey = "distance" | "score";

export function Circuit({
  records,
  personalBest,
  onStart,
}: {
  records: DriverRecord[];
  personalBest: number;
  onStart: () => void;
}) {
  const [sortKey, setSortKey] = useState<SortKey>("distance");

  const sorted = useMemo(
    () => [...records].sort((a, b) => b[sortKey] - a[sortKey] || b.distance - a.distance).slice(0, 9),
    [records, sortKey],
  );

  const bestLocal = useMemo(() => [...records].filter((record) => record.local).sort((a, b) => b.distance - a.distance)[0], [records]);
  const wall = records[0];
  const gap = wall && personalBest > 0 ? Math.max(0, wall.distance - personalBest) : 0;

  return (
    <section id="circuit" className="relative scroll-mt-24 border-t border-white/8 py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(60%_40%_at_50%_0%,rgba(201,250,60,0.045),transparent_70%)]" />
      <div className="mx-auto max-w-[1360px] px-4 sm:px-6 lg:px-10">
        <SectionIntro
          label="The circuit"
          title={
            <>
              The wall
              <br />
              <span className="font-serif font-normal italic text-volt">remembers.</span>
            </>
          }
          copy="Distances from the night shift. Ghost times are seeded by the house; every run of yours is saved locally the moment the shields hit zero."
          aside={
            <div className="flex flex-wrap items-center gap-2">
              <Pill>
                <span className="h-1 w-1 animate-pulse-dot rounded-full bg-volt" /> Local leaderboard
              </Pill>
              <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-moss-500">No sign-up · stored on this device</span>
            </div>
          }
        />

        <div className="mt-10 grid gap-4 sm:mt-12 lg:grid-cols-[minmax(0,1fr)_300px] xl:grid-cols-[minmax(0,1fr)_320px]">
          <Reveal>
            <div className="overflow-hidden rounded-2xl border border-white/10 bg-ink-900/70">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/8 px-4 py-3.5 sm:px-5">
                <div className="flex items-center gap-2.5">
                  <span className="flex h-8 w-8 items-center justify-center rounded-lg border border-volt/25 bg-volt/10 text-volt">
                    <Trophy className="h-4 w-4" />
                  </span>
                  <div>
                    <p className="text-[13px] font-medium text-bone">The Midnight Wall</p>
                    <p className="font-mono text-[8px] uppercase tracking-[0.14em] text-moss-500">Coastal circuit · all time</p>
                  </div>
                </div>
                <div className="flex items-center rounded-lg border border-white/10 bg-white/4 p-0.5">
                  {(["distance", "score"] as SortKey[]).map((key) => (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setSortKey(key)}
                      className={cn(
                        "rounded-md px-2.5 py-1.5 font-mono text-[8px] font-medium uppercase tracking-[0.12em] transition",
                        sortKey === key ? "bg-volt text-ink-950" : "text-moss-400 hover:text-bone",
                      )}
                      aria-pressed={sortKey === key}
                    >
                      By {key}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-[30px_minmax(0,1fr)_84px] items-center gap-2 border-b border-white/8 bg-white/3 px-3 py-2.5 font-mono text-[8px] uppercase tracking-[0.16em] text-moss-500 sm:grid-cols-[36px_minmax(0,1fr)_132px_110px_84px] sm:gap-3 sm:px-5">
                <span>Pos</span>
                <span>Driver</span>
                <span className="hidden sm:block">Machine</span>
                <span className="text-right">Distance</span>
                <span className="hidden text-right sm:block">Score</span>
              </div>

              <ul>
                {sorted.map((record, index) => {
                  const isTop = index === 0;
                  const isYou = Boolean(record.local);
                  return (
                    <li
                      key={record.id}
                      className={cn(
                        "group grid grid-cols-[30px_minmax(0,1fr)_84px] items-center gap-2 border-b border-white/5 px-3 py-3 transition last:border-0 sm:grid-cols-[36px_minmax(0,1fr)_132px_110px_84px] sm:gap-3 sm:px-5",
                        isYou ? "bg-volt/[0.055] hover:bg-volt/[0.09]" : "hover:bg-white/[0.035]",
                      )}
                    >
                      <span
                        className={cn(
                          "flex h-7 w-7 items-center justify-center rounded-md font-mono text-[10px] font-semibold tabular-nums",
                          isTop
                            ? "bg-volt text-ink-950"
                            : isYou
                              ? "border border-volt/35 bg-volt/10 text-volt"
                              : "border border-white/10 bg-white/4 text-moss-400",
                        )}
                      >
                        {String(index + 1).padStart(2, "0")}
                      </span>

                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className={cn("truncate text-[12.5px] font-medium", isYou ? "text-volt" : "text-bone")}>
                            {record.driver}
                          </span>
                          {isYou && (
                            <span className="shrink-0 rounded-full bg-volt px-1.5 py-0.5 font-mono text-[7px] font-semibold uppercase tracking-[0.1em] text-ink-950">
                              You
                            </span>
                          )}
                          {isTop && <span className="hidden font-mono text-[7px] uppercase tracking-[0.12em] text-moss-500 sm:inline">Wall record</span>}
                        </div>
                        <p className="mt-0.5 truncate font-mono text-[8px] uppercase tracking-[0.1em] text-moss-500">
                          {record.carName} <span className="sm:hidden">· {formatNumber(record.distance)} m</span>
                        </p>
                      </div>

                      <span className="hidden truncate font-mono text-[10px] text-moss-500 sm:block">
                        {record.carName}
                      </span>

                      <div className="text-right">
                        <span className="font-mono text-[12px] font-medium tabular-nums text-bone">{formatNumber(record.distance)}</span>
                        <span className="ml-1 font-mono text-[8px] text-moss-500">m</span>
                        <p className="mt-0.5 font-mono text-[7px] uppercase tracking-[0.08em] text-moss-500 sm:hidden">
                          {formatDateLabel(record.date)}
                        </p>
                      </div>

                      <span className="hidden text-right font-mono text-[11px] tabular-nums text-moss-300 sm:block">
                        {formatNumber(record.score)}
                      </span>

                      <div className="col-span-3 flex items-center gap-2 pt-2 sm:hidden">
                        <span className="h-1 flex-1 overflow-hidden rounded-full bg-white/8">
                          <span
                            className={cn("block h-full rounded-full", isYou ? "bg-volt" : "bg-moss-500/60")}
                            style={{ width: `${Math.min(100, (record.distance / Math.max(1, wall?.distance ?? 1)) * 100)}%` }}
                          />
                        </span>
                        <span className="font-mono text-[8px] tabular-nums text-moss-500">{record.topSpeed} km/h</span>
                      </div>
                    </li>
                  );
                })}
              </ul>

              <div className="flex flex-wrap items-center justify-between gap-3 border-t border-white/8 px-4 py-3 sm:px-5">
                <p className="font-mono text-[8px] uppercase leading-relaxed tracking-[0.1em] text-moss-500">
                  Ghost times seeded by the house · your runs stay on this device
                </p>
                <button
                  type="button"
                  onClick={onStart}
                  className="group inline-flex items-center gap-2 font-mono text-[9px] font-medium uppercase tracking-[0.14em] text-volt transition hover:text-volt-bright"
                >
                  Beat the wall <ArrowRight className="h-3.5 w-3.5 transition group-hover:translate-x-0.5" />
                </button>
              </div>
            </div>
          </Reveal>

          <div className="flex flex-col gap-4">
            <Reveal delay={80}>
              <div className="relative overflow-hidden rounded-2xl border border-volt/25 bg-gradient-to-br from-volt/12 via-ink-900 to-ink-900 p-5">
                <div className="pointer-events-none absolute -right-8 -top-8 h-28 w-28 rounded-full bg-volt/10 blur-2xl" />
                <div className="flex items-start justify-between">
                  <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-volt">Your line</p>
                  <Trophy className="h-4 w-4 text-volt" />
                </div>
                <p className="mt-3 font-mono text-[34px] font-semibold leading-none tabular-nums tracking-tight text-bone">
                  {personalBest > 0 ? formatNumber(personalBest) : "0"}
                  <span className="ml-1 font-mono text-[11px] font-normal uppercase tracking-[0.1em] text-moss-400">m</span>
                </p>
                <p className="mt-1.5 text-[11.5px] leading-relaxed text-moss-300">
                  {personalBest > 0
                    ? `${gap > 0 ? `${formatNumber(gap)} m behind the wall record.` : "You're holding the wall record."}`
                    : "No runs yet. Your first distance lands here the moment you crash."}
                </p>
                <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-white/10">
                  <div
                    className="h-full rounded-full bg-volt transition-[width] duration-700"
                    style={{ width: `${Math.min(100, Math.max(personalBest > 0 ? 3 : 0, (personalBest / 12480) * 100))}%` }}
                  />
                </div>
                <div className="mt-2 flex justify-between font-mono text-[7px] uppercase tracking-[0.1em] text-moss-500">
                  <span>Start line</span>
                  <span>Wall · {wall ? formatNumber(wall.distance) : "—"} m</span>
                </div>
                <button
                  type="button"
                  onClick={onStart}
                  className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-volt px-3 py-2.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-ink-950 transition hover:bg-volt-bright"
                >
                  <Play className="h-2.5 w-2.5" /> Take your line
                </button>
              </div>
            </Reveal>

            <Reveal delay={140}>
              <div className="rounded-2xl border border-white/10 bg-ink-900/60 p-5">
                <p className="kicker">Last run</p>
                {bestLocal ? (
                  <div className="mt-2.5">
                    <p className="font-mono text-lg font-semibold tabular-nums text-bone">{formatNumber(bestLocal.distance)} m</p>
                    <p className="mt-1 text-[11px] leading-relaxed text-moss-300">
                      {bestLocal.carName} · {formatDateLabel(bestLocal.date)}
                    </p>
                    <div className="mt-3 flex items-center justify-between border-t border-white/8 pt-2.5 font-mono text-[8px] uppercase tracking-[0.1em] text-moss-500">
                      <span>Top speed</span>
                      <span className="text-moss-300">{bestLocal.topSpeed} km/h</span>
                    </div>
                    <div className="mt-1.5 flex items-center justify-between font-mono text-[8px] uppercase tracking-[0.1em] text-moss-500">
                      <span>Score</span>
                      <span className="text-moss-300">{formatNumber(bestLocal.score)} pts</span>
                    </div>
                  </div>
                ) : (
                  <p className="mt-2 text-[11.5px] leading-relaxed text-moss-300">
                    Empty garage, empty wall. Take the Night Spec out and put a number up there.
                  </p>
                )}
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
