// Multi-Branch Inventory & Stock Movement Ledger View
import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { dbStore } from '../../server/services/dbStore';
import { MovementType, StockMovement } from '../../types';
import {
  Boxes,
  Building2,
  AlertTriangle,
  ArrowDownUp,
  History,
  PlusCircle,
  MinusCircle,
  ArrowRightLeft,
  X,
  CheckCircle2,
  AlertCircle,
  Search,
} from 'lucide-react';

export const InventoryView: React.FC = () => {
  const { currentBranch, allBranches, setCurrentBranch, can, currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState<'inventory' | 'movements'>('inventory');
  const [searchQuery, setSearchQuery] = useState('');
  const [showLowStockOnly, setShowLowStockOnly] = useState(false);
  const [inventoryList, setInventoryList] = useState(dbStore.getInventory(currentBranch.id));
  const [movementsList, setMovementsList] = useState<StockMovement[]>(dbStore.getStockMovements(100));

  // Adjustment Modal State
  const [isAdjustOpen, setIsAdjustOpen] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const [adjustQty, setAdjustQty] = useState<number>(1);
  const [adjustType, setAdjustType] = useState<MovementType>('ADJUSTMENT_IN');
  const [adjustNotes, setAdjustNotes] = useState<string>('');
  const [targetBranchId, setTargetBranchId] = useState<string>(allBranches[1]?.id || '');
  const [adjustError, setAdjustError] = useState<string | null>(null);

  const refreshData = () => {
    setInventoryList(dbStore.getInventory(currentBranch.id));
    setMovementsList(dbStore.getStockMovements(100));
  };

  const filteredInventory = inventoryList.filter((item) => {
    if (showLowStockOnly && item.quantity > item.product.reorderLevel) return false;
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase().trim();
    return (
      item.product.name.toLowerCase().includes(q) ||
      item.product.barcode.includes(q) ||
      item.product.sku.toLowerCase().includes(q)
    );
  });

  const handleAdjustSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAdjustError(null);
    if (!currentUser) return;

    try {
      if (adjustType === 'TRANSFER_OUT') {
        // Transfer logic: Deduct from current branch, Add to target branch
        if (!targetBranchId || targetBranchId === currentBranch.id) {
          throw new Error('Please select a different destination branch for transfer.');
        }

        dbStore.adjustStock(
          selectedProductId,
          currentBranch.id,
          -Math.abs(adjustQty),
          'TRANSFER_OUT',
          currentUser.id,
          currentUser.name,
          `Transfer out to branch ${targetBranchId}. ${adjustNotes}`
        );

        dbStore.adjustStock(
          selectedProductId,
          targetBranchId,
          Math.abs(adjustQty),
          'TRANSFER_IN',
          currentUser.id,
          currentUser.name,
          `Transfer in from branch ${currentBranch.name}. ${adjustNotes}`
        );
      } else {
        const delta =
          adjustType === 'ADJUSTMENT_OUT' || adjustType === 'DAMAGE' || adjustType === 'EXPIRY'
            ? -Math.abs(adjustQty)
            : Math.abs(adjustQty);

        dbStore.adjustStock(
          selectedProductId,
          currentBranch.id,
          delta,
          adjustType,
          currentUser.id,
          currentUser.name,
          adjustNotes
        );
      }

      refreshData();
      setIsAdjustOpen(false);
      setAdjustNotes('');
      setAdjustQty(1);
    } catch (err: any) {
      setAdjustError(err.message || 'Stock adjustment failed');
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Boxes className="w-5 h-5 text-emerald-400" />
            <h1 className="text-xl font-bold text-slate-100">Multi-Branch Inventory & Stock Ledger</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Track on-hand units, execute audited stock adjustments, and record branch transfers.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-800 border border-slate-700 px-3 py-1.5 rounded-lg text-xs">
            <Building2 className="w-3.5 h-3.5 text-emerald-400" />
            <select
              value={currentBranch.id}
              onChange={(e) => {
                const b = allBranches.find((br) => br.id === e.target.value);
                if (b) {
                  setCurrentBranch(b);
                  setInventoryList(dbStore.getInventory(b.id));
                }
              }}
              className="bg-transparent text-slate-200 font-semibold focus:outline-none cursor-pointer"
            >
              {allBranches.map((branch) => (
                <option key={branch.id} value={branch.id} className="bg-slate-900 text-white">
                  {branch.name}
                </option>
              ))}
            </select>
          </div>

          {can('INVENTORY_ADJUST') && (
            <button
              onClick={() => {
                setSelectedProductId(filteredInventory[0]?.product.id || '');
                setIsAdjustOpen(true);
              }}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold px-4 py-2 rounded-lg shadow-sm shadow-emerald-900/30 transition-colors"
            >
              <ArrowDownUp className="w-4 h-4" />
              Adjust Stock
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('inventory')}
            className={`px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'inventory'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Boxes className="w-4 h-4" />
            Branch Stock Balance ({filteredInventory.length})
          </button>
          <button
            onClick={() => setActiveTab('movements')}
            className={`px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors flex items-center gap-2 ${
              activeTab === 'movements'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <History className="w-4 h-4" />
            Audit Movement Ledger
          </button>
        </div>

        {activeTab === 'inventory' && (
          <div className="flex items-center gap-3 mb-2">
            <button
              onClick={() => setShowLowStockOnly(!showLowStockOnly)}
              className={`flex items-center gap-1.5 text-xs px-3 py-1 rounded-lg border transition-colors ${
                showLowStockOnly
                  ? 'bg-amber-950 text-amber-300 border-amber-800 font-bold'
                  : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              Low Stock Filter
            </button>
          </div>
        )}
      </div>

      {/* Tab Content */}
      {activeTab === 'inventory' ? (
        <div className="space-y-4">
          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search product inventory by name or barcode..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 font-semibold bg-slate-950/60">
                    <th className="py-3 px-4">Product Name</th>
                    <th className="py-3 px-4">Barcode / SKU</th>
                    <th className="py-3 px-4 text-right">Available Quantity</th>
                    <th className="py-3 px-4 text-center">Unit</th>
                    <th className="py-3 px-4 text-center">Reorder Threshold</th>
                    <th className="py-3 px-4 text-center">Stock Status</th>
                    <th className="py-3 px-4 text-center">Quick Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  {filteredInventory.map((item) => {
                    const isLow = item.quantity <= item.product.reorderLevel;
                    return (
                      <tr key={item.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-3 px-4 font-semibold text-slate-100">{item.product.name}</td>
                        <td className="py-3 px-4 font-mono text-slate-400">
                          <div>{item.product.barcode}</div>
                          <div className="text-[10px] text-slate-500">{item.product.sku}</div>
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-sm">
                          <span className={isLow ? 'text-amber-400' : 'text-emerald-400'}>
                            {item.quantity}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-center text-slate-400">{item.product.unit}</td>
                        <td className="py-3 px-4 text-center font-mono text-slate-400">
                          {item.product.reorderLevel}
                        </td>
                        <td className="py-3 px-4 text-center">
                          {isLow ? (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-950/80 text-amber-300 border border-amber-800/80">
                              Low Stock
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950/80 text-emerald-300 border border-emerald-800/80">
                              Optimal
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-center">
                          {can('INVENTORY_ADJUST') && (
                            <button
                              onClick={() => {
                                setSelectedProductId(item.product.id);
                                setIsAdjustOpen(true);
                              }}
                              className="text-emerald-400 hover:text-emerald-300 hover:underline text-xs font-semibold"
                            >
                              Adjust
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        /* Stock Movement Ledger */
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-semibold bg-slate-950/60">
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4">Item</th>
                  <th className="py-3 px-4">Movement Type</th>
                  <th className="py-3 px-4 text-center">Previous</th>
                  <th className="py-3 px-4 text-center">Delta Quantity</th>
                  <th className="py-3 px-4 text-center">New Balance</th>
                  <th className="py-3 px-4">Operator</th>
                  <th className="py-3 px-4">Notes / Ref</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {movementsList.map((m) => {
                  const prod = dbStore.getProductById(m.productId);
                  const isPositive = m.quantity > 0;
                  return (
                    <tr key={m.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4 font-mono text-slate-400 text-[11px]">
                        {new Date(m.createdAt).toLocaleString([], {
                          month: 'short',
                          day: '2-digit',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-200">{prod?.name || m.productId}</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded font-mono text-[10px] bg-slate-800 text-slate-300 border border-slate-700">
                          {m.movementType}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center font-mono text-slate-400">{m.previousQuantity}</td>
                      <td className="py-3 px-4 text-center font-mono font-bold">
                        <span className={isPositive ? 'text-emerald-400' : 'text-rose-400'}>
                          {isPositive ? `+${m.quantity}` : m.quantity}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center font-mono font-semibold text-slate-200">
                        {m.newQuantity}
                      </td>
                      <td className="py-3 px-4 text-slate-300">{m.performedByName}</td>
                      <td className="py-3 px-4 text-slate-400 text-[11px] truncate max-w-xs">{m.notes || '-'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Adjust Stock Modal */}
      {isAdjustOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl animate-in fade-in">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
              <div className="flex items-center gap-2">
                <ArrowDownUp className="w-4 h-4 text-emerald-400" />
                <h2 className="text-sm font-bold text-slate-100">Audited Inventory Adjustment</h2>
              </div>
              <button
                onClick={() => setIsAdjustOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAdjustSubmit} className="p-6 space-y-4">
              {adjustError && (
                <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-800 text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{adjustError}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Target Product</label>
                <select
                  value={selectedProductId}
                  onChange={(e) => setSelectedProductId(e.target.value)}
                  required
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                >
                  {inventoryList.map((item) => (
                    <option key={item.product.id} value={item.product.id}>
                      {item.product.name} (Current: {item.quantity} {item.product.unit})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Adjustment Action</label>
                <select
                  value={adjustType}
                  onChange={(e) => setAdjustType(e.target.value as MovementType)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                >
                  <option value="ADJUSTMENT_IN">Stock Increase (Adjustment In / Found Stock)</option>
                  <option value="ADJUSTMENT_OUT">Stock Decrease (Discrepancy / Shrinkage)</option>
                  <option value="DAMAGE">Damaged Goods Write-off</option>
                  <option value="EXPIRY">Expired Items Disposal</option>
                  <option value="TRANSFER_OUT">Inter-Branch Transfer</option>
                </select>
              </div>

              {adjustType === 'TRANSFER_OUT' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Destination Branch</label>
                  <select
                    value={targetBranchId}
                    onChange={(e) => setTargetBranchId(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                  >
                    {allBranches
                      .filter((b) => b.id !== currentBranch.id)
                      .map((b) => (
                        <option key={b.id} value={b.id}>
                          {b.name} ({b.code})
                        </option>
                      ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Units Quantity</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={adjustQty}
                  onChange={(e) => setAdjustQty(parseInt(e.target.value, 10) || 1)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Audit Reason / Notes</label>
                <textarea
                  rows={2}
                  required
                  value={adjustNotes}
                  onChange={(e) => setAdjustNotes(e.target.value)}
                  placeholder="e.g., Damaged during shelf stocking in aisle 3"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAdjustOpen(false)}
                  className="px-4 py-2 text-xs text-slate-300 hover:text-white rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg shadow-sm shadow-emerald-900/30"
                >
                  Confirm Adjustment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
