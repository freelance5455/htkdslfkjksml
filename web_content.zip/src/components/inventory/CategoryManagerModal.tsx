import React, { useState } from 'react';
import { 
  FolderPlus, 
  Edit2, 
  Trash2, 
  Check, 
  X, 
  Layers, 
  AlertCircle, 
  Package,
  Plus
} from 'lucide-react';
import { Product } from '../../types';

interface CategoryManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: string[];
  products: Product[];
  onAddCategory: (categoryName: string) => void;
  onRenameCategory: (oldName: string, newName: string) => void;
  onDeleteCategory: (categoryToDelete: string, targetCategory?: string) => void;
}

export const CategoryManagerModal: React.FC<CategoryManagerModalProps> = ({
  isOpen,
  onClose,
  categories,
  products,
  onAddCategory,
  onRenameCategory,
  onDeleteCategory,
}) => {
  const [newCategoryName, setNewCategoryName] = useState('');
  const [editingCategory, setEditingCategory] = useState<string | null>(null);
  const [editingValue, setEditingValue] = useState('');
  const [deleteConfirmCat, setDeleteConfirmCat] = useState<string | null>(null);
  const [transferTargetCat, setTransferTargetCat] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  // Count products per category
  const getProductCount = (cat: string) => {
    return products.filter((p) => p.category === cat).length;
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = newCategoryName.trim();
    if (!clean) return;
    if (categories.some((c) => c.toLowerCase() === clean.toLowerCase())) {
      setErrorMessage(`القسم "${clean}" موجود بالفعل.`);
      return;
    }
    setErrorMessage(null);
    onAddCategory(clean);
    setNewCategoryName('');
  };

  const startEditing = (cat: string) => {
    setEditingCategory(cat);
    setEditingValue(cat);
    setErrorMessage(null);
  };

  const saveRename = (oldCat: string) => {
    const clean = editingValue.trim();
    if (!clean || clean === oldCat) {
      setEditingCategory(null);
      return;
    }
    if (categories.some((c) => c !== oldCat && c.toLowerCase() === clean.toLowerCase())) {
      setErrorMessage(`يوجد قسم آخر بنفس الاسم "${clean}".`);
      return;
    }
    setErrorMessage(null);
    onRenameCategory(oldCat, clean);
    setEditingCategory(null);
  };

  const promptDelete = (cat: string) => {
    const count = getProductCount(cat);
    if (count === 0) {
      onDeleteCategory(cat);
    } else {
      setDeleteConfirmCat(cat);
      // Pick first alternative category as default target
      const other = categories.find((c) => c !== cat) || 'أخرى';
      setTransferTargetCat(other);
    }
  };

  const confirmDeleteWithTransfer = () => {
    if (deleteConfirmCat) {
      onDeleteCategory(deleteConfirmCat, transferTargetCat);
      setDeleteConfirmCat(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
      <div 
        className="w-full max-w-xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]"
        dir="rtl"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-blue-600/20 text-blue-400 border border-blue-500/30 rounded-xl">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                إدارة قائمة الأقسام والتصنيفات
                <span className="text-xs bg-slate-800 text-slate-300 font-mono px-2 py-0.5 rounded-full border border-slate-700">
                  {categories.length} قسم
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                إضافة أقسام جديدة، تغيير المسميات، أو إعادة ترتيب فئات المنتجات
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Add New Category Form */}
        <div className="p-4 bg-slate-850/60 border-b border-slate-800">
          <form onSubmit={handleAddSubmit} className="flex gap-2">
            <input
              type="text"
              value={newCategoryName}
              onChange={(e) => setNewCategoryName(e.target.value)}
              placeholder="اكتب اسم القسم الجديد (مثال: حلويات ومكسرات، عطور، أدوات مكتبية...)"
              className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
            />
            <button
              type="submit"
              disabled={!newCategoryName.trim()}
              className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition shadow-md shadow-blue-600/20"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة قسم</span>
            </button>
          </form>

          {errorMessage && (
            <div className="mt-2 text-xs text-red-400 flex items-center gap-1.5">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>{errorMessage}</span>
            </div>
          )}
        </div>

        {/* Categories List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {categories.length === 0 ? (
            <div className="text-center py-8 text-slate-500 text-xs">
              لا توجد أقسام مسجلة حالياً.
            </div>
          ) : (
            categories.map((cat) => {
              const count = getProductCount(cat);
              const isEditing = editingCategory === cat;

              return (
                <div
                  key={cat}
                  className="flex items-center justify-between p-3 bg-slate-950/70 border border-slate-800/90 rounded-xl hover:border-slate-700 transition"
                >
                  {isEditing ? (
                    <div className="flex items-center gap-2 flex-1 ml-2">
                      <input
                        type="text"
                        value={editingValue}
                        onChange={(e) => setEditingValue(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') saveRename(cat);
                          if (e.key === 'Escape') setEditingCategory(null);
                        }}
                        autoFocus
                        className="flex-1 bg-slate-900 border border-blue-500 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none font-medium"
                      />
                      <button
                        onClick={() => saveRename(cat)}
                        className="p-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition"
                        title="حفظ الاسم الجديد"
                      >
                        <Check className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setEditingCategory(null)}
                        className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition"
                        title="إلغاء"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full bg-blue-500" />
                      <span className="text-sm font-bold text-slate-200">{cat}</span>
                      <span className="text-[11px] font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded-full border border-slate-800 flex items-center gap-1">
                        <Package className="w-3 h-3 text-slate-500" />
                        {count} أصناف
                      </span>
                    </div>
                  )}

                  {!isEditing && (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => startEditing(cat)}
                        className="p-1.5 text-slate-400 hover:text-blue-400 hover:bg-slate-800/80 rounded-lg transition text-xs flex items-center gap-1"
                        title="تعديل اسم القسم"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline text-[11px]">تعديل</span>
                      </button>

                      <button
                        onClick={() => promptDelete(cat)}
                        className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800/80 rounded-lg transition text-xs flex items-center gap-1"
                        title="حذف القسم"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline text-[11px]">حذف</span>
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Delete with Transfer Confirmation Modal overlay */}
        {deleteConfirmCat && (
          <div className="p-4 bg-red-950/40 border-t border-red-500/30 space-y-3 animate-in fade-in">
            <div className="flex items-start gap-2.5 text-red-300 text-xs">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">تحذير:</span> القسم "<strong>{deleteConfirmCat}</strong>" يحتوي على <strong>{getProductCount(deleteConfirmCat)}</strong> أصناف.
                يرجى تحديد القسم البديل لنقل هذه المنتجات إليه قبل إتمام الحذف:
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-2 pt-1">
              <select
                value={transferTargetCat}
                onChange={(e) => setTransferTargetCat(e.target.value)}
                className="w-full sm:w-auto flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-red-500"
              >
                {categories
                  .filter((c) => c !== deleteConfirmCat)
                  .map((c) => (
                    <option key={c} value={c}>
                      نقل إلى: {c}
                    </option>
                  ))}
              </select>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  onClick={confirmDeleteWithTransfer}
                  className="flex-1 sm:flex-none px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded-xl transition shadow-md shadow-red-600/20"
                >
                  نقل المنتجات وحذف القسم
                </button>
                <button
                  onClick={() => setDeleteConfirmCat(null)}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-xl transition"
                >
                  إلغاء
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>* أي تعديل في اسم القسم يحدّث تلقائياً كافة المنتجات التابعة له وشاشات البيع.</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg font-medium transition"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
