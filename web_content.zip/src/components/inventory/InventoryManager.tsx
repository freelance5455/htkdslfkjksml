import React, { useState } from 'react';
import { 
  Package, Plus, Search, AlertTriangle, Edit, Trash2, 
  ArrowDownCircle, Printer, Download, Barcode, Check, X, 
  TrendingUp, Layers, DollarSign, FolderCog, Tag
} from 'lucide-react';
import { Product, StoreSettings } from '../../types';
import { CategoryManagerModal } from './CategoryManagerModal';

interface Props {
  products: Product[];
  categories?: string[];
  settings: StoreSettings;
  onAddProduct: (product: Omit<Product, 'id'>) => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  onAdjustStock: (productId: string, addedStock: number, reason: string) => void;
  onAddCategory?: (categoryName: string) => void;
  onRenameCategory?: (oldName: string, newName: string) => void;
  onDeleteCategory?: (categoryToDelete: string, targetCategory?: string) => void;
}

export const InventoryManager: React.FC<Props> = ({
  products,
  categories: propCategories = [],
  settings,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  onAdjustStock,
  onAddCategory,
  onRenameCategory,
  onDeleteCategory,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('الكل');
  const [showLowStockOnly, setShowLowStockOnly] = useState(false);

  // Category Manager Modal state
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [isCustomCategoryInput, setIsCustomCategoryInput] = useState(false);
  const [customCategoryName, setCustomCategoryName] = useState('');

  // Modals
  const [isAddEditModalOpen, setIsAddEditModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isStockAdjustModalOpen, setIsStockAdjustModalOpen] = useState(false);
  const [adjustingProduct, setAdjustingProduct] = useState<Product | null>(null);
  const [stockDelta, setStockDelta] = useState<number>(10);
  const [adjustReason, setAdjustReason] = useState('فاتورة شراء واردة');

  // Barcode Label Print Modal
  const [isBarcodePrintModalOpen, setIsBarcodePrintModalOpen] = useState(false);
  const [barcodePrintProduct, setBarcodePrintProduct] = useState<Product | null>(null);
  const [barcodeLabelCount, setBarcodeLabelCount] = useState<number>(4);

  // All unique categories derived from storage + products
  const allCategories = Array.from(
    new Set([...propCategories, ...products.map((p) => p.category)])
  ).filter(Boolean);

  const categories = ['الكل', ...allCategories];

  // Form states for Add/Edit
  const [formData, setFormData] = useState({
    barcode: '',
    name: '',
    nameEn: '',
    category: allCategories[0] || 'مواد غذائية',
    costPrice: 0,
    sellingPrice: 0,
    stock: 10,
    minStock: 5,
    unit: 'حبة',
  });

  // Calculations for stats
  const totalItemsCount = products.reduce((sum, p) => sum + p.stock, 0);
  const totalCostValue = products.reduce((sum, p) => sum + p.costPrice * p.stock, 0);
  const totalSellingValue = products.reduce((sum, p) => sum + p.sellingPrice * p.stock, 0);
  const lowStockCount = products.filter((p) => p.stock <= p.minStock).length;

  // Filtered products
  const filteredProducts = products.filter((p) => {
    const matchesCategory = selectedCategory === 'الكل' || p.category === selectedCategory;
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !q ||
      p.name.toLowerCase().includes(q) ||
      p.barcode.toLowerCase().includes(q) ||
      (p.nameEn && p.nameEn.toLowerCase().includes(q));
    const matchesLowStock = !showLowStockOnly || p.stock <= p.minStock;
    return matchesCategory && matchesSearch && matchesLowStock;
  });

  const openAddModal = () => {
    setEditingProduct(null);
    setIsCustomCategoryInput(false);
    setCustomCategoryName('');
    setFormData({
      barcode: `${Date.now().toString().slice(-9)}`,
      name: '',
      nameEn: '',
      category: allCategories[0] || 'مواد غذائية',
      costPrice: 10,
      sellingPrice: 15,
      stock: 20,
      minStock: 5,
      unit: 'حبة',
    });
    setIsAddEditModalOpen(true);
  };

  const openEditModal = (product: Product) => {
    setEditingProduct(product);
    setIsCustomCategoryInput(false);
    setCustomCategoryName('');
    setFormData({
      barcode: product.barcode,
      name: product.name,
      nameEn: product.nameEn || '',
      category: product.category,
      costPrice: product.costPrice,
      sellingPrice: product.sellingPrice,
      stock: product.stock,
      minStock: product.minStock,
      unit: product.unit,
    });
    setIsAddEditModalOpen(true);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.barcode.trim()) {
      alert('الرجاء إدخال اسم الصنف والباركود');
      return;
    }

    let finalCategory = formData.category;
    if (isCustomCategoryInput && customCategoryName.trim()) {
      finalCategory = customCategoryName.trim();
      if (onAddCategory) {
        onAddCategory(finalCategory);
      }
    }

    const payload = {
      ...formData,
      category: finalCategory,
    };

    if (editingProduct) {
      onUpdateProduct({
        ...editingProduct,
        ...payload,
      });
    } else {
      onAddProduct(payload);
    }
    setIsAddEditModalOpen(false);
  };

  const handleAdjustStockSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (adjustingProduct && stockDelta !== 0) {
      onAdjustStock(adjustingProduct.id, stockDelta, adjustReason);
      setIsStockAdjustModalOpen(false);
      setAdjustingProduct(null);
    }
  };

  // Export CSV
  const handleExportCSV = () => {
    const headers = ['الباركود', 'اسم الصنف', 'القسم', 'سعر التكلفة', 'سعر البيع', 'الكمية المتوفرة', 'حد الطلب', 'الوحدة'];
    const rows = products.map((p) => [
      `"${p.barcode}"`,
      `"${p.name}"`,
      `"${p.category}"`,
      p.costPrice,
      p.sellingPrice,
      p.stock,
      p.minStock,
      `"${p.unit}"`,
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `inventory_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 overflow-hidden">
      {/* Top Bar with KPIs & Actions */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Package className="w-5 h-5 text-blue-400" />
              إدارة المخزون والأصناف
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              متابعة الكميات، أسعار الشراء والبيع، تنبيهات النواقص وطباعة الباركود
            </p>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => setIsCategoryModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700 transition"
              title="إدارة وتعديل قائمة الأقسام والتصنيفات"
            >
              <Layers className="w-4 h-4 text-blue-400" />
              <span>إدارة الأقسام</span>
            </button>

            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700 transition"
              title="تصدير إلى Excel/CSV"
            >
              <Download className="w-4 h-4" />
              <span>تصدير CSV</span>
            </button>

            <button
              onClick={openAddModal}
              className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-blue-600/20 transition"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة صنف جديد</span>
            </button>
          </div>
        </div>

        {/* Valuation Metric Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-slate-400">إجمالي الأصناف</span>
              <div className="text-lg font-black font-mono text-white mt-0.5">
                {products.length}{' '}
                <small className="text-xs font-normal text-slate-500">
                  ({totalItemsCount} قطعة)
                </small>
              </div>
            </div>
            <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400">
              <Layers className="w-4 h-4" />
            </div>
          </div>

          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-slate-400">قيمة التكلفة الإجمالية</span>
              <div className="text-lg font-black font-mono text-slate-200 mt-0.5">
                {totalCostValue.toFixed(2)}{' '}
                <small className="text-xs font-normal text-slate-500">{settings.currency}</small>
              </div>
            </div>
            <div className="p-2 rounded-lg bg-slate-800 text-slate-400">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>

          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-slate-400">قيمة البيع المتوقعة</span>
              <div className="text-lg font-black font-mono text-emerald-400 mt-0.5">
                {totalSellingValue.toFixed(2)}{' '}
                <small className="text-xs font-normal text-slate-500">{settings.currency}</small>
              </div>
            </div>
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>

          <button
            onClick={() => setShowLowStockOnly(!showLowStockOnly)}
            className={`p-3 rounded-xl border text-right transition flex items-center justify-between ${
              showLowStockOnly
                ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                : 'bg-slate-950/70 border-slate-800 hover:border-amber-500/30'
            }`}
          >
            <div>
              <span className="text-[11px] text-slate-400">نواقص تحتاج طلب</span>
              <div className="text-lg font-black font-mono text-amber-400 mt-0.5">
                {lowStockCount} أصناف
              </div>
            </div>
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </button>
        </div>

        {/* Search & Category Filter Controls */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-1">
          <div className="relative w-full sm:w-80">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث بالاسم أو الباركود..."
              className="w-full bg-slate-950 border border-slate-700 rounded-xl pr-9 pl-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition ${
                  selectedCategory === cat
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}

            <button
              onClick={() => setIsCategoryModalOpen(true)}
              className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 whitespace-nowrap transition flex items-center gap-1 shrink-0"
              title="إضافة أو تعديل الأقسام"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>تعديل الأقسام</span>
            </button>
          </div>
        </div>
      </div>

      {/* Products Table */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-850 border-b border-slate-800 text-slate-400 font-semibold">
                <tr>
                  <th className="p-3.5">الباركود</th>
                  <th className="p-3.5">اسم الصنف</th>
                  <th className="p-3.5">القسم</th>
                  <th className="p-3.5 text-center">سعر الشراء</th>
                  <th className="p-3.5 text-center">سعر البيع</th>
                  <th className="p-3.5 text-center">الربح المتوقع</th>
                  <th className="p-3.5 text-center">المخزون الحالي</th>
                  <th className="p-3.5 text-center">الحالة</th>
                  <th className="p-3.5 text-left">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredProducts.map((product) => {
                  const isLow = product.stock <= product.minStock && product.stock > 0;
                  const isOut = product.stock <= 0;
                  const unitProfit = product.sellingPrice - product.costPrice;
                  const marginPct = ((unitProfit / product.sellingPrice) * 100).toFixed(0);

                  return (
                    <tr key={product.id} className="hover:bg-slate-850/40 transition">
                      <td className="p-3.5 font-mono text-slate-400">
                        <span className="bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                          {product.barcode}
                        </span>
                      </td>

                      <td className="p-3.5">
                        <div className="font-bold text-white text-sm">{product.name}</div>
                        {product.nameEn && (
                          <div className="text-[10px] text-slate-500">{product.nameEn}</div>
                        )}
                      </td>

                      <td className="p-3.5 text-slate-300">{product.category}</td>

                      <td className="p-3.5 text-center font-mono text-slate-300">
                        {product.costPrice.toFixed(2)} {settings.currency}
                      </td>

                      <td className="p-3.5 text-center font-mono font-bold text-emerald-400">
                        {product.sellingPrice.toFixed(2)} {settings.currency}
                      </td>

                      <td className="p-3.5 text-center font-mono text-blue-400">
                        +{unitProfit.toFixed(2)}{' '}
                        <span className="text-[10px] text-slate-500">({marginPct}%)</span>
                      </td>

                      <td className="p-3.5 text-center font-mono font-bold text-sm">
                        <span
                          className={
                            isOut
                              ? 'text-red-400'
                              : isLow
                              ? 'text-amber-400'
                              : 'text-slate-100'
                          }
                        >
                          {product.stock}
                        </span>{' '}
                        <small className="text-[10px] font-normal text-slate-400">
                          {product.unit}
                        </small>
                      </td>

                      <td className="p-3.5 text-center">
                        <span
                          className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            isOut
                              ? 'bg-red-500/10 text-red-400 border border-red-500/20'
                              : isLow
                              ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                              : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          }`}
                        >
                          {isOut ? 'منتهي' : isLow ? 'منخفض' : 'متوفر'}
                        </span>
                      </td>

                      <td className="p-3.5 text-left">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            onClick={() => {
                              setAdjustingProduct(product);
                              setStockDelta(10);
                              setIsStockAdjustModalOpen(true);
                            }}
                            className="p-1.5 bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 rounded-lg transition"
                            title="توريد بضاعة / تعديل الكمية"
                          >
                            <ArrowDownCircle className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => {
                              setBarcodePrintProduct(product);
                              setIsBarcodePrintModalOpen(true);
                            }}
                            className="p-1.5 bg-slate-800 text-slate-300 hover:text-white rounded-lg transition"
                            title="طباعة ملصق الباركود"
                          >
                            <Barcode className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => openEditModal(product)}
                            className="p-1.5 bg-slate-800 text-slate-300 hover:text-white rounded-lg transition"
                            title="تعديل الصنف"
                          >
                            <Edit className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => {
                              if (confirm(`هل أنت متأكد من رغبتك بحذف الصنف "${product.name}"؟`)) {
                                onDeleteProduct(product.id);
                              }
                            }}
                            className="p-1.5 bg-red-500/10 text-red-400 hover:bg-red-500/20 rounded-lg transition"
                            title="حذف الصنف"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {filteredProducts.length === 0 && (
            <div className="p-12 text-center text-slate-500">
              <Package className="w-12 h-12 mx-auto mb-2 opacity-40 stroke-1" />
              <p className="text-sm">لا توجد منتجات تطابق شروط البحث الحالية</p>
            </div>
          )}
        </div>
      </div>

      {/* Add / Edit Product Modal */}
      {isAddEditModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100 flex flex-col max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <h3 className="font-bold text-lg text-white">
                {editingProduct ? 'تعديل بيانات الصنف' : 'إضافة صنف جديد للمخزون'}
              </h3>
              <button
                onClick={() => setIsAddEditModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    رقم الباركود:
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.barcode}
                    onChange={(e) => setFormData({ ...formData, barcode: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-blue-500"
                    placeholder="امسح أو اكتب الباركود"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-medium text-slate-300">القسم / التصنيف:</label>
                    <button
                      type="button"
                      onClick={() => setIsCategoryModalOpen(true)}
                      className="text-[10px] text-blue-400 hover:text-blue-300 underline cursor-pointer"
                      title="إدارة الأقسام"
                    >
                      إدارة الأقسام
                    </button>
                  </div>
                  {!isCustomCategoryInput ? (
                    <select
                      value={formData.category}
                      onChange={(e) => {
                        if (e.target.value === '__NEW__') {
                          setIsCustomCategoryInput(true);
                          setCustomCategoryName('');
                        } else {
                          setFormData({ ...formData, category: e.target.value });
                        }
                      }}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                    >
                      {allCategories.map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                      <option value="__NEW__">+ إضافة قسم جديد...</option>
                    </select>
                  ) : (
                    <div className="flex gap-1.5">
                      <input
                        type="text"
                        value={customCategoryName}
                        onChange={(e) => setCustomCategoryName(e.target.value)}
                        placeholder="اسم القسم الجديد..."
                        autoFocus
                        className="flex-1 bg-slate-950 border border-blue-500 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (customCategoryName.trim()) {
                            const newCat = customCategoryName.trim();
                            if (onAddCategory) onAddCategory(newCat);
                            setFormData({ ...formData, category: newCat });
                            setIsCustomCategoryInput(false);
                          }
                        }}
                        className="px-2.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold"
                      >
                        تأكيد
                      </button>
                      <button
                        type="button"
                        onClick={() => setIsCustomCategoryInput(false)}
                        className="px-2 py-1.5 bg-slate-800 text-slate-400 hover:text-white rounded-lg text-xs"
                      >
                        إلغاء
                      </button>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  اسم الصنف (بالعربية):
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                  placeholder="مثال: شاي سيلاني فاخر 100 كيس"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  اسم الصنف (بالإنجليزية - اختياري):
                </label>
                <input
                  type="text"
                  value={formData.nameEn}
                  onChange={(e) => setFormData({ ...formData, nameEn: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                  placeholder="e.g. Ceylon Black Tea"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    سعر التكلفة (الشراء):
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={formData.costPrice}
                    onChange={(e) =>
                      setFormData({ ...formData, costPrice: parseFloat(e.target.value) || 0 })
                    }
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    سعر البيع للجمهور:
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    value={formData.sellingPrice}
                    onChange={(e) =>
                      setFormData({ ...formData, sellingPrice: parseFloat(e.target.value) || 0 })
                    }
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono font-bold text-emerald-400 focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    الكمية المتوفرة:
                  </label>
                  <input
                    type="number"
                    required
                    value={formData.stock}
                    onChange={(e) =>
                      setFormData({ ...formData, stock: parseInt(e.target.value, 10) || 0 })
                    }
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    حد الطلب الأدنى:
                  </label>
                  <input
                    type="number"
                    required
                    value={formData.minStock}
                    onChange={(e) =>
                      setFormData({ ...formData, minStock: parseInt(e.target.value, 10) || 0 })
                    }
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">الوحدة:</label>
                  <input
                    type="text"
                    value={formData.unit}
                    onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                    placeholder="حبة، كرتون..."
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddEditModalOpen(false)}
                  className="px-4 py-2 text-xs font-medium bg-slate-800 text-slate-300 rounded-xl hover:bg-slate-750 transition"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white rounded-xl shadow-lg shadow-blue-600/20 transition"
                >
                  حفظ الصنف
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Stock Adjustment Modal */}
      {isStockAdjustModalOpen && adjustingProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100">
            <h3 className="font-bold text-base text-white mb-1">توريد / تعديل مخزون الصنف</h3>
            <p className="text-xs text-slate-400 mb-4">{adjustingProduct.name}</p>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 mb-4 text-xs">
              <div className="flex justify-between mb-1 text-slate-400">
                <span>المخزون الحالي:</span>
                <span className="font-bold font-mono text-white">
                  {adjustingProduct.stock} {adjustingProduct.unit}
                </span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>المخزون بعد التعديل:</span>
                <span className="font-bold font-mono text-emerald-400">
                  {adjustingProduct.stock + stockDelta} {adjustingProduct.unit}
                </span>
              </div>
            </div>

            <form onSubmit={handleAdjustStockSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  الكمية المضافة (استخدم سالباً للنقص):
                </label>
                <input
                  type="number"
                  required
                  value={stockDelta}
                  onChange={(e) => setStockDelta(parseInt(e.target.value, 10) || 0)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm font-mono font-bold text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">سبب التعديل:</label>
                <input
                  type="text"
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="pt-3 flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsStockAdjustModalOpen(false)}
                  className="flex-1 py-2 text-xs font-medium bg-slate-800 text-slate-400 rounded-xl hover:text-white"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl shadow-md transition"
                >
                  تأكيد التوريد
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Barcode Label Print Modal */}
      {isBarcodePrintModalOpen && barcodePrintProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 text-slate-100">
            <div className="flex justify-between items-center pb-3 border-b border-slate-800 mb-4">
              <h3 className="font-bold text-base text-white">معاينة ملصقات باركود الرفوف</h3>
              <button
                onClick={() => setIsBarcodePrintModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center gap-2 mb-4 text-xs">
              <span className="text-slate-400">عدد الملصقات للطباعة:</span>
              <input
                type="number"
                min="1"
                max="24"
                value={barcodeLabelCount}
                onChange={(e) => setBarcodeLabelCount(parseInt(e.target.value, 10) || 1)}
                className="w-16 bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-center font-mono font-bold"
              />
            </div>

            {/* Printable Stickers Preview */}
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 max-h-60 overflow-y-auto">
              <div className="grid grid-cols-2 gap-3">
                {Array.from({ length: barcodeLabelCount }).map((_, i) => (
                  <div
                    key={i}
                    className="bg-white text-slate-900 p-2.5 rounded border border-slate-300 text-center font-mono select-text"
                    dir="rtl"
                  >
                    <div className="text-[10px] font-bold text-slate-700 truncate">
                      {settings.storeName}
                    </div>
                    <div className="text-xs font-black truncate my-0.5">
                      {barcodePrintProduct.name}
                    </div>
                    <div className="text-sm font-black text-emerald-800">
                      {barcodePrintProduct.sellingPrice.toFixed(2)} {settings.currency}
                    </div>
                    {/* Simulated barcode stripes */}
                    <div className="flex justify-center items-end h-7 my-1 gap-[1px]">
                      {Array.from({ length: 30 }).map((_, bIdx) => (
                        <div
                          key={bIdx}
                          className={`w-[2px] bg-slate-900 ${
                            bIdx % 3 === 0 ? 'h-full' : bIdx % 2 === 0 ? 'h-5' : 'h-6'
                          }`}
                        />
                      ))}
                    </div>
                    <div className="text-[9px] tracking-widest text-slate-600">
                      {barcodePrintProduct.barcode}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-5 flex gap-2">
              <button
                onClick={() => setIsBarcodePrintModalOpen(false)}
                className="flex-1 py-2 text-xs font-medium bg-slate-800 text-slate-300 rounded-xl hover:bg-slate-750"
              >
                إغلاق
              </button>
              <button
                onClick={() => window.print()}
                className="flex-1 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white rounded-xl shadow-lg transition flex items-center justify-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>طباعة الملصقات</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Category Manager Modal */}
      <CategoryManagerModal
        isOpen={isCategoryModalOpen}
        onClose={() => setIsCategoryModalOpen(false)}
        categories={allCategories}
        products={products}
        onAddCategory={(name) => {
          if (onAddCategory) onAddCategory(name);
        }}
        onRenameCategory={(oldName, newName) => {
          if (onRenameCategory) onRenameCategory(oldName, newName);
        }}
        onDeleteCategory={(delCat, targetCat) => {
          if (onDeleteCategory) onDeleteCategory(delCat, targetCat);
        }}
      />
    </div>
  );
};
