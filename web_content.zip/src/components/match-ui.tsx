"use client";

import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Innings, MatchState, MatchSetup, OverBall, Player } from "@/lib/types";
import {
  captainOf,
  findPlayer,
  keeperOf,
  computeAwards,
  matchStatistics,
  oversStr,
  playerPerformance,
  requiredInfo,
  runRate,
  squadOf,
  strikeRate,
  viceCaptainOf,
} from "@/lib/engine";
import Link from "next/link";
import {
  BallByBallIcon,
  BallIcon,
  BatIcon,
  CommentaryIcon,
  HistoryIcon,
  ScorecardIcon,
  PlayerAvatar,
  PlayerCard,
  RoleBadges,
  StumpsIcon,
  TeamLogo,
  TrophyIcon,
} from "./cricket";
import { ReplayButton, SpeakerIndicator, useVoice, VoiceToggleInline } from "./voice";
import { LanguageSelect, langClass, useLang, usePhrase } from "./lang";

/* ============ Player profile context ============ */

const ProfileCtx = createContext<(name: string) => void>(() => {});

export function PlayerProfileProvider({
  state,
  children,
}: {
  state: MatchState;
  children: ReactNode;
}) {
  const [open, setOpen] = useState<string | null>(null);
  return (
    <ProfileCtx.Provider value={setOpen}>
      {children}
      {open && <PlayerProfileModal state={state} name={open} onClose={() => setOpen(null)} />}
    </ProfileCtx.Provider>
  );
}

export function usePlayerProfile() {
  return useContext(ProfileCtx);
}

export function PlayerLink({
  name,
  className = "",
  children,
}: {
  name: string;
  className?: string;
  children?: ReactNode;
}) {
  const open = usePlayerProfile();
  return (
    <button
      onClick={() => open(name)}
      className={`text-left hover:text-emerald-400 hover:underline ${className}`}
    >
      {children ?? name}
    </button>
  );
}

/* ============ Small pieces ============ */

export function SectionTitle({ n, title, icon }: { n?: number; title: string; icon?: ReactNode }) {
  return (
    <div className="mb-2 flex items-center gap-2">
      {icon}
      {n !== undefined && (
        <span className="rounded bg-slate-800 px-1.5 py-0.5 text-[10px] font-black text-slate-400">
          {n}
        </span>
      )}
      <h2 className="text-sm font-black uppercase tracking-wider text-slate-200">{title}</h2>
    </div>
  );
}

export function LiveBadge({ status }: { status: MatchState["status"] }) {
  if (status === "completed")
    return (
      <span className="rounded-md bg-slate-700 px-2 py-1 text-[11px] font-black tracking-widest text-slate-200">
        COMPLETED
      </span>
    );
  if (status === "innings-break")
    return (
      <span className="rounded-md bg-amber-500/20 px-2 py-1 text-[11px] font-black tracking-widest text-amber-300">
        INNINGS BREAK
      </span>
    );
  return (
    <span className="flex items-center gap-1.5 rounded-md bg-red-500/15 px-2 py-1 text-[11px] font-black tracking-widest text-red-400">
      <span className="mc-live-dot h-2 w-2 rounded-full bg-red-500" /> LIVE
    </span>
  );
}

export function ballStyle(b: OverBall) {
  if (b.wicket) return "bg-red-500 text-white";
  if (!b.legal) return "bg-amber-500/20 text-amber-300 border border-amber-500/40";
  if (b.runs === 4) return "bg-sky-500 text-white";
  if (b.runs === 6) return "bg-violet-500 text-white";
  if (b.runs === 0) return "bg-slate-800 text-slate-400 border border-slate-700";
  return "bg-slate-700 text-slate-100";
}

export function BallChip({ b, onClick }: { b: OverBall; onClick?: () => void }) {
  return (
    <span
      onClick={onClick}
      title={b.commentary.en}
      className={`mc-pop inline-flex h-9 min-w-9 items-center justify-center rounded-full px-2 text-sm font-bold ${ballStyle(b)} ${onClick ? "cursor-pointer" : ""}`}
    >
      {b.label}
    </span>
  );
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div
      className={`rounded-xl border px-3 py-2 text-center ${
        accent ? "border-emerald-500/40 bg-emerald-500/10" : "border-slate-700 bg-slate-900/60"
      }`}
    >
      <p className="text-[10px] font-bold tracking-widest text-slate-400">{label}</p>
      <p className={`text-lg font-black ${accent ? "text-emerald-300" : "text-slate-100"}`}>
        {value}
      </p>
    </div>
  );
}

function StatLine({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="flex items-center justify-between gap-2 rounded-lg bg-slate-900/60 px-2.5 py-1.5 text-[13px]">
      <span className="truncate text-slate-400">{label}</span>
      <span className="shrink-0 font-bold text-slate-100">{value}</span>
    </div>
  );
}

/* ============ 1. MATCH HEADER ============ */

export function MatchHeader({ state }: { state: MatchState }) {
  const s = state.setup;
  const capA = captainOf(s.playersA);
  const capB = captainOf(s.playersB);
  const date = s.matchDate ? new Date(s.matchDate) : null;
  return (
    <div className="mc-card overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 px-4 py-2">
        <div className="flex items-center gap-2">
          <LiveBadge status={state.status} />
          <span className="rounded bg-slate-800 px-2 py-0.5 text-[11px] font-black tracking-wider text-emerald-300">
            {s.format}
          </span>
          <span className="text-[11px] font-semibold text-slate-400">{s.overs} overs</span>
        </div>
        <span className="text-[11px] text-slate-400">
          {s.venue ? `${s.venue} · ` : ""}
          {date ? date.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" }) : ""}
        </span>
      </div>
      <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2 px-4 py-4">
        <div className="flex items-center gap-3">
          <TeamLogo name={s.teamA} logo={s.logoA} size={38} />
          <div className="min-w-0">
            <p className="truncate text-base font-black uppercase">{s.teamA}</p>
            <p className="text-[11px] text-slate-400">{capA ? `${capA.name} (c)` : "—"}</p>
          </div>
        </div>
        <div className="flex flex-col items-center gap-1">
          <BallIcon className="mc-spin h-5 w-5" />
          <span className="text-[11px] font-black text-slate-500">VS</span>
        </div>
        <div className="flex items-center justify-end gap-3 text-right">
          <div className="min-w-0">
            <p className="truncate text-base font-black uppercase">{s.teamB}</p>
            <p className="text-[11px] text-slate-400">{capB ? `${capB.name} (c)` : "—"}</p>
          </div>
          <TeamLogo name={s.teamB} logo={s.logoB} size={38} />
        </div>
      </div>
      <p className="border-t border-slate-800 bg-slate-900/50 px-4 py-2 text-center text-xs text-slate-400">
        {s.tossWinner} won the toss and elected to {s.tossDecision}
      </p>
    </div>
  );
}

/* ============ 2. LIVE SCORE ============ */

function useEventFlash(state: MatchState) {
  const [flash, setFlash] = useState<{ text: string; cls: string } | null>(null);
  const inn = state.innings[state.currentInnings];
  const over = inn.overs[inn.overs.length - 1];
  const last = over?.balls[over.balls.length - 1];
  const key = `${state.currentInnings}-${inn.overs.length}-${over?.balls.length ?? 0}`;
  useEffect(() => {
    if (!last) return;
    let f: { text: string; cls: string } | null = null;
    if (last.wicket) f = { text: "OUT!", cls: "text-red-500" };
    else if (last.legal && last.runs === 6) f = { text: "SIX!", cls: "text-violet-400" };
    else if (last.legal && last.runs === 4) f = { text: "FOUR!", cls: "text-sky-400" };
    if (!f) return;
    setFlash(f);
    const t = setTimeout(() => setFlash(null), 1500);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  return flash;
}

export function ScoreHeader({ state }: { state: MatchState }) {
  const inn = state.innings[state.currentInnings];
  const other = state.innings[state.currentInnings === 0 ? 1 : 0];
  const chase = requiredInfo(state);
  const flash = useEventFlash(state);
  return (
    <div className="mc-card relative overflow-hidden">
      {flash && (
        <div className="mc-fx-layer absolute inset-0 z-10 flex items-center justify-center bg-slate-950/55">
          <span className={`mc-flash text-5xl font-black tracking-tight ${flash.cls}`}>
            {flash.text}
          </span>
        </div>
      )}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 px-4 py-2">
        <div className="flex items-center gap-2">
          <LiveBadge status={state.status} />
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            {state.setup.teamA} vs {state.setup.teamB}
          </span>
        </div>
        {inn.freeHit && (
          <span className="rounded-md bg-fuchsia-500 px-2 py-1 text-[11px] font-black tracking-widest text-white">
            FREE HIT
          </span>
        )}
      </div>

      <div className="grid gap-3 px-4 py-3.5 sm:grid-cols-[1fr_auto] sm:items-end">
        <div>
          <p className="text-sm font-bold uppercase tracking-widest text-emerald-400">
            {inn.battingTeam}
          </p>
          <div className="flex flex-wrap items-end gap-3">
            <p key={inn.runs} className="mc-count text-5xl font-black leading-none sm:text-6xl">
              {inn.runs}
              <span className="text-slate-500">/</span>
              {inn.wickets}
            </p>
            <p className="pb-1 text-lg font-semibold text-slate-400">
              ({oversStr(inn.legalBalls)}/{state.setup.overs} ov)
            </p>
          </div>
          {state.currentInnings === 1 && (
            <p className="mt-1 text-sm text-slate-400">
              {other.battingTeam} {other.runs}/{other.wickets} ({oversStr(other.legalBalls)})
            </p>
          )}
        </div>
        <div className="grid grid-cols-2 gap-2 sm:flex">
          <Stat label="CRR" value={runRate(inn.runs, inn.legalBalls).toFixed(2)} />
          {chase && <Stat label="RRR" value={chase.rrr.toFixed(2)} accent />}
          {chase && <Stat label="TARGET" value={String(chase.target)} />}
        </div>
      </div>

      {state.status === "completed" && state.result && (
        <div className="bg-emerald-500/10 px-4 py-3 text-center text-sm font-black uppercase tracking-widest text-emerald-300">
          🏆 {state.result}
        </div>
      )}
      {chase && state.status === "live" && (
        <div className="border-t border-slate-800 px-4 py-2 text-center text-sm font-semibold text-slate-300">
          {inn.battingTeam} need <span className="text-emerald-400">{chase.runsNeeded}</span> runs
          from <span className="text-emerald-400">{chase.ballsRemaining}</span> balls
        </div>
      )}
    </div>
  );
}

/* ============ 3+4. CURRENT BATTERS / BOWLER ============ */

export function CurrentPlayersPanel({ state }: { state: MatchState }) {
  const inn = state.innings[state.currentInnings];
  const bat = (name: string | null) => (name ? inn.batters.find((b) => b.name === name) : null);
  const striker = bat(inn.striker);
  const nonStriker = bat(inn.nonStriker);
  const bowler = inn.bowlers.find((b) => b.name === inn.bowler);
  return (
    <div className="grid gap-3 md:grid-cols-2">
      <div className="mc-card px-3.5 py-3">
        <div className="mb-2 flex items-center gap-2">
          <BatIcon className="h-4 w-4" />
          <p className="text-xs font-bold uppercase tracking-widest text-slate-400">
            Current batters
          </p>
        </div>
        <div className="space-y-2">
          {[
            { s: striker, on: true },
            { s: nonStriker, on: false },
          ].map(({ s, on }, i) =>
            s ? (
              <div key={s.name} className="flex items-center gap-3">
                <PlayerAvatar player={findPlayer(state.setup, s.name)} size={38} ring={on} />
                <div className="min-w-0 flex-1">
                  <PlayerLink name={s.name} className="block truncate text-sm font-bold">
                    {s.name}
                    {on && <span className="text-emerald-400"> *</span>}
                  </PlayerLink>
                  <p className="text-[11px] text-slate-400">
                    4s: {s.fours} · 6s: {s.sixes} · SR {strikeRate(s.runs, s.balls).toFixed(2)}
                  </p>
                </div>
                <p className="text-lg font-black">
                  {s.runs}
                  <span className="text-xs font-semibold text-slate-400"> ({s.balls})</span>
                </p>
              </div>
            ) : (
              <p
                key={i}
                className="rounded-lg border border-dashed border-amber-500/40 bg-amber-500/5 px-3 py-2 text-sm font-semibold text-amber-300"
              >
                Waiting for the next batter…
              </p>
            ),
          )}
          <div className="flex items-center justify-between border-t border-slate-800 pt-2 text-xs">
            <span className="text-slate-400">Partnership</span>
            <span className="font-bold text-emerald-300">
              {inn.partnership.runs} ({inn.partnership.balls})
            </span>
          </div>
        </div>
      </div>

      <div className="mc-card px-3.5 py-3">
        <div className="mb-2 flex items-center gap-2">
          <BallIcon className="h-4 w-4" />
          <p className="text-xs font-bold uppercase tracking-widest text-slate-400">
            Current bowler
          </p>
        </div>
        {bowler ? (
          <>
            <div className="flex items-center gap-3">
              <PlayerAvatar player={findPlayer(state.setup, bowler.name)} size={38} ring />
              <div className="min-w-0 flex-1">
                <PlayerLink name={bowler.name} className="block truncate text-sm font-bold">
                  {bowler.name}
                </PlayerLink>
                <p className="text-[11px] text-slate-400">
                  {oversStr(bowler.balls)} ov · {bowler.runs} runs · {bowler.wickets} wkts
                </p>
              </div>
              <p className="text-lg font-black text-emerald-400">
                {bowler.wickets}/{bowler.runs}
              </p>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2 text-[11px]">
              <StatLine label="Economy" value={runRate(bowler.runs, bowler.balls).toFixed(2)} />
              <StatLine label="Maidens" value={bowler.maidens} />
              <StatLine label="Dot balls" value={bowler.dots} />
              <StatLine label="Wd / Nb" value={`${bowler.wides} / ${bowler.noballs}`} />
            </div>
          </>
        ) : (
          <p className="text-sm text-slate-500">No bowler selected.</p>
        )}
      </div>
    </div>
  );
}

/* ============ 5. CURRENT OVER ============ */

export function CurrentOverStrip({ inn }: { inn: Innings }) {
  const over = inn.overs[inn.overs.length - 1];
  return (
    <div className="mc-card px-3.5 py-2.5">
      <div className="mb-2 flex items-center justify-between">
        <p className="text-[11px] font-bold uppercase tracking-widest text-slate-400">
          This over {over ? `· Over ${over.number}` : ""}
        </p>
        <p className="text-xs text-slate-500">{over?.bowler ?? "—"}</p>
      </div>
      <div className="flex flex-wrap gap-2">
        {over && over.balls.length > 0 ? (
          over.balls.map((b, i) => <BallChip key={i} b={b} />)
        ) : (
          <span className="text-sm text-slate-500">No balls bowled yet in this over.</span>
        )}
      </div>
    </div>
  );
}

/* ============ 6. SCORECARD ============ */

export function BattingTable({ inn, setup }: { inn: Innings; setup: MatchSetup }) {
  return (
    <div className="mc-card overflow-hidden">
      <div className="flex items-center justify-between border-b border-slate-800 px-4 py-2.5">
        <p className="text-sm font-black uppercase tracking-wider">{inn.battingTeam} — Batting</p>
        <p className="text-sm font-bold text-emerald-400">
          {inn.runs}/{inn.wickets} ({oversStr(inn.legalBalls)})
        </p>
      </div>
      <div className="mc-scroll overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-900/60 text-[11px] uppercase tracking-wider text-slate-400">
            <tr>
              <th className="px-4 py-2 text-left font-bold">Batter</th>
              <th className="px-2 py-2 text-right font-bold">R</th>
              <th className="px-2 py-2 text-right font-bold">B</th>
              <th className="px-2 py-2 text-right font-bold">4s</th>
              <th className="px-2 py-2 text-right font-bold">6s</th>
              <th className="px-4 py-2 text-right font-bold">SR</th>
            </tr>
          </thead>
          <tbody>
            {inn.batters.map((b) => {
              const onStrike = b.name === inn.striker;
              const p = findPlayer(setup, b.name);
              return (
                <tr key={b.name} className="border-t border-slate-800/70">
                  <td className="px-4 py-2">
                    <div className="flex items-center gap-2">
                      <PlayerAvatar player={p} size={28} ring={onStrike && !b.out} />
                      <div>
                        <PlayerLink name={b.name} className="text-sm font-semibold">
                          {b.name}
                          {onStrike && !b.out && <span className="text-emerald-400"> *</span>}
                        </PlayerLink>
                        <div className="text-[11px] text-slate-500">
                          {b.out
                            ? b.howOut
                            : b.name === inn.nonStriker || onStrike
                              ? "not out"
                              : "—"}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-2 py-2 text-right font-bold">{b.runs}</td>
                  <td className="px-2 py-2 text-right text-slate-300">{b.balls}</td>
                  <td className="px-2 py-2 text-right text-slate-300">{b.fours}</td>
                  <td className="px-2 py-2 text-right text-slate-300">{b.sixes}</td>
                  <td className="px-4 py-2 text-right text-slate-300">
                    {strikeRate(b.runs, b.balls).toFixed(2)}
                  </td>
                </tr>
              );
            })}
            {inn.batters.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-4 text-center text-slate-500">
                  Innings not started.
                </td>
              </tr>
            )}
          </tbody>
          <tfoot className="bg-slate-900/60 text-sm">
            <tr>
              <td className="px-4 py-2 font-semibold text-slate-400">
                Extras{" "}
                <span className="text-[11px] text-slate-500">
                  (wd {inn.extras.wides}, nb {inn.extras.noballs}, b {inn.extras.byes}, lb{" "}
                  {inn.extras.legbyes})
                </span>
              </td>
              <td colSpan={5} className="px-4 py-2 text-right font-bold">
                {inn.extras.total}
              </td>
            </tr>
            <tr className="border-t border-slate-800">
              <td className="px-4 py-2 font-black">TOTAL</td>
              <td colSpan={5} className="px-4 py-2 text-right font-black text-emerald-400">
                {inn.runs}/{inn.wickets} ({oversStr(inn.legalBalls)} ov, RR{" "}
                {runRate(inn.runs, inn.legalBalls).toFixed(2)})
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
      {inn.yetToBat.length > 0 && (
        <p className="border-t border-slate-800 px-4 py-2 text-xs text-slate-500">
          <span className="font-semibold text-slate-400">Yet to bat: </span>
          {inn.yetToBat.join(", ")}
        </p>
      )}
    </div>
  );
}

export function BowlingTable({ inn, setup }: { inn: Innings; setup: MatchSetup }) {
  return (
    <div className="mc-card overflow-hidden">
      <div className="border-b border-slate-800 px-4 py-2.5">
        <p className="text-sm font-black uppercase tracking-wider">{inn.bowlingTeam} — Bowling</p>
      </div>
      <div className="mc-scroll overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-900/60 text-[11px] uppercase tracking-wider text-slate-400">
            <tr>
              <th className="px-4 py-2 text-left font-bold">Bowler</th>
              <th className="px-2 py-2 text-right font-bold">O</th>
              <th className="px-2 py-2 text-right font-bold">M</th>
              <th className="px-2 py-2 text-right font-bold">R</th>
              <th className="px-2 py-2 text-right font-bold">W</th>
              <th className="px-2 py-2 text-right font-bold">Wd</th>
              <th className="px-2 py-2 text-right font-bold">Nb</th>
              <th className="px-4 py-2 text-right font-bold">ECO</th>
            </tr>
          </thead>
          <tbody>
            {inn.bowlers.map((b) => (
              <tr key={b.name} className="border-t border-slate-800/70">
                <td className="px-4 py-2">
                  <div className="flex items-center gap-2">
                    <PlayerAvatar player={findPlayer(setup, b.name)} size={26} />
                    <PlayerLink name={b.name} className="text-sm font-semibold">
                      {b.name}
                      {b.name === inn.bowler && <span className="text-emerald-400"> *</span>}
                    </PlayerLink>
                  </div>
                </td>
                <td className="px-2 py-2 text-right">{oversStr(b.balls)}</td>
                <td className="px-2 py-2 text-right">{b.maidens}</td>
                <td className="px-2 py-2 text-right">{b.runs}</td>
                <td className="px-2 py-2 text-right font-bold text-emerald-400">{b.wickets}</td>
                <td className="px-2 py-2 text-right text-slate-400">{b.wides}</td>
                <td className="px-2 py-2 text-right text-slate-400">{b.noballs}</td>
                <td className="px-4 py-2 text-right">{runRate(b.runs, b.balls).toFixed(2)}</td>
              </tr>
            ))}
            {inn.bowlers.length === 0 && (
              <tr>
                <td colSpan={8} className="px-4 py-4 text-center text-slate-500">
                  No bowling yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ============ EXTRAS ============ */

export function ExtrasCard({ inn }: { inn: Innings }) {
  const e = inn.extras;
  const rows: [string, number][] = [
    ["Wides", e.wides],
    ["No Balls", e.noballs],
    ["Byes", e.byes],
    ["Leg Byes", e.legbyes],
  ];
  return (
    <div className="mc-card overflow-hidden">
      <div className="border-b border-slate-800 px-4 py-2.5 text-sm font-black uppercase tracking-wider">
        Extras
      </div>
      <div className="grid grid-cols-2 gap-1.5 px-4 py-3 sm:grid-cols-4">
        {rows.map(([label, value]) => (
          <div key={label} className="rounded-lg bg-slate-900/60 px-3 py-2 text-center">
            <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
              {label}
            </p>
            <p className="text-lg font-black">{value}</p>
          </div>
        ))}
      </div>
      <div className="flex items-center justify-between border-t border-slate-800 px-4 py-2">
        <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
          Total Extras
        </span>
        <span className="text-lg font-black text-emerald-400">{e.total}</span>
      </div>
    </div>
  );
}

/* ============ 9. PARTNERSHIPS ============ */

export function PartnershipPanel({ inn }: { inn: Innings }) {
  const list = [...inn.partnerships].reverse();
  return (
    <div className="mc-card overflow-hidden">
      <div className="border-b border-slate-800 px-4 py-2.5 text-sm font-black uppercase tracking-wider">
        Partnerships
      </div>
      <div className="divide-y divide-slate-800/70">
        {list.map((p, i) => (
          <div key={i} className="px-4 py-2.5">
            <div className="flex items-center justify-between text-sm">
              <span className="font-semibold">
                {p.batters[0]} &amp; {p.batters[1]}
              </span>
              <span className="font-black text-emerald-400">
                {p.runs} <span className="text-xs font-semibold text-slate-400">({p.balls})</span>
              </span>
            </div>
            <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-slate-800">
              <div
                className="h-full rounded-full bg-emerald-500 transition-all"
                style={{
                  width: `${Math.min(100, (p.runs / Math.max(1, inn.runs || 1)) * 100)}%`,
                }}
              />
            </div>
            <p className="mt-1 text-[11px] text-slate-500">
              {p.open ? "Unbroken" : `${p.wicket}${ordinal(p.wicket)} wicket partnership`}
            </p>
          </div>
        ))}
        {list.length === 0 && <p className="px-4 py-4 text-sm text-slate-500">No partnerships.</p>}
      </div>
    </div>
  );
}

function ordinal(n: number) {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return s[(v - 20) % 10] ?? s[v] ?? s[0];
}

/* ============ 11. FALL OF WICKETS ============ */

export function FallOfWickets({ inn }: { inn: Innings }) {
  return (
    <div className="mc-card overflow-hidden">
      <div className="flex items-center gap-2 border-b border-slate-800 px-4 py-2.5">
        <StumpsIcon className="h-4 w-4" />
        <p className="text-sm font-black uppercase tracking-wider">Fall of wickets</p>
      </div>
      {inn.fow.length === 0 ? (
        <p className="px-4 py-4 text-sm text-slate-500">No wickets have fallen.</p>
      ) : (
        <div className="flex flex-wrap gap-2 px-4 py-3">
          {inn.fow.map((f) => (
            <div
              key={f.wicket}
              className="rounded-lg border border-slate-800 bg-slate-900/60 px-3 py-1.5 text-xs"
            >
              <span className="font-black text-red-400">
                {f.runs}-{f.wicket}
              </span>{" "}
              <PlayerLink name={f.batter} className="font-semibold text-slate-200">
                {f.batter}
              </PlayerLink>
              <span className="text-slate-500"> · {f.over} ov</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ============ 7. BALL BY BALL + 12. OVER ANALYSIS ============ */

export function OverAnalysis({ inn }: { inn: Innings }) {
  const { lang } = useLang();
  const t = usePhrase();
  const [open, setOpen] = useState<number | null>(inn.overs.length);
  const overs = [...inn.overs].reverse();
  return (
    <div className="mc-card overflow-hidden">
      <div className="border-b border-slate-800 px-4 py-2.5 text-sm font-black uppercase tracking-wider">
        Over analysis
      </div>
      <div className="divide-y divide-slate-800/70">
        {overs.map((o) => {
          const expanded = open === o.number;
          return (
            <div key={o.number}>
              <button
                onClick={() => setOpen(expanded ? null : o.number)}
                className="flex w-full flex-wrap items-center gap-2 px-4 py-3 text-left hover:bg-slate-800/40"
              >
                <span className="w-16 shrink-0 text-xs font-black uppercase text-slate-400">
                  Over {o.number}
                </span>
                <div className="flex flex-1 flex-wrap gap-1.5">
                  {o.balls.map((b, i) => (
                    <BallChip key={i} b={b} />
                  ))}
                  {o.balls.length === 0 && (
                    <span className="text-xs text-slate-500">Yet to be bowled</span>
                  )}
                </div>
                <span className="text-xs font-bold text-emerald-400">Total: {o.runs}</span>
                <span className="text-xs text-slate-500">{expanded ? "▲" : "▼"}</span>
              </button>
              {expanded && (
                <div className="bg-slate-950/40 px-4 pb-3">
                  <div className="grid grid-cols-2 gap-2 py-2 sm:grid-cols-6">
                    <StatLine label="Bowler" value={o.bowler} />
                    <StatLine label="Runs" value={o.runs} />
                    <StatLine label="Wickets" value={o.wickets} />
                    <StatLine label="Legal balls" value={o.legalBalls} />
                    <StatLine label="Extras" value={o.extras} />
                    <StatLine
                      label="Run rate"
                      value={
                        o.legalBalls > 0 ? ((o.runs * 6) / o.legalBalls).toFixed(2) : "0.00"
                      }
                    />
                  </div>
                  <ol className="space-y-2">
                    {o.balls.map((b, i) => (
                      <li key={i} className="flex items-start gap-3 text-xs">
                        <span className="w-10 shrink-0 pt-2 font-bold text-slate-500">
                          {b.ballNo}
                        </span>
                        <BallChip b={b} />
                        <span className="min-w-0 flex-1">
                          <span className={`${langClass(lang)} block text-[13px] text-slate-200`}>
                            {t(b.commentary)}
                          </span>
                        </span>
                        <ReplayButton text={t(b.commentary)} />
                      </li>
                    ))}
                  </ol>
                </div>
              )}
            </div>
          );
        })}
        {overs.length === 0 && (
          <p className="px-4 py-4 text-sm text-slate-500">No overs bowled yet.</p>
        )}
      </div>
    </div>
  );
}

export function OversList({ inn }: { inn: Innings }) {
  return <OverAnalysis inn={inn} />;
}

/* ============ 8. COMMENTARY ============ */

function kindColor(kind: string) {
  return kind === "wicket"
    ? "text-red-400"
    : kind === "boundary"
      ? "text-sky-300"
      : kind === "six"
        ? "text-violet-300"
        : kind === "extra"
          ? "text-amber-300"
          : kind === "info" || kind === "over" || kind === "milestone"
            ? "text-emerald-300"
            : "text-slate-200";
}

function sfxOf(kind: string) {
  return kind === "wicket"
    ? ("wicket" as const)
    : kind === "six"
      ? ("six" as const)
      : kind === "boundary"
        ? ("four" as const)
        : kind === "over"
          ? ("over" as const)
          : null;
}

export function CommentaryList({ state }: { state: MatchState }) {
  const { settings, voiceAvailable } = useVoice();
  const { lang } = useLang();
  const t = usePhrase();

  return (
    <div className="mc-card overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 px-3 py-2 sm:px-4">
        <div className="flex items-center gap-2">
          <p className="text-sm font-black uppercase tracking-wider">Commentary</p>
          <SpeakerIndicator />
        </div>
        <LanguageSelect compact />
      </div>

      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 px-3 py-2 sm:px-4">
        <VoiceToggleInline />
      </div>
      {!voiceAvailable && settings.voiceOn && (
        <p className="border-b border-slate-800 px-3 py-1.5 text-[11px] text-slate-500 sm:px-4">
          Voice unavailable on this device — text commentary continues below.
        </p>
      )}

      {!settings.textCommentary ? (
        <p className="px-4 py-6 text-center text-sm text-slate-500">
          Text commentary is switched off in Commentary Settings.
        </p>
      ) : (
        <div className="max-h-[560px] divide-y divide-slate-800/70 overflow-y-auto">
          {state.commentary.map((c) => (
            <div key={c.id} className="mc-pop flex items-start gap-2.5 px-3 py-2.5 sm:px-4">
              <span className="w-10 shrink-0 pt-1 text-xs font-black text-slate-500">
                {c.ballRef}
              </span>
              <div className="min-w-0 flex-1">
                <span
                  className={`inline-block rounded px-1.5 py-0.5 text-[10px] font-black tracking-wider ${
                    c.kind === "wicket"
                      ? "bg-red-500/20 text-red-300"
                      : c.kind === "boundary"
                        ? "bg-sky-500/20 text-sky-300"
                        : c.kind === "six"
                          ? "bg-violet-500/20 text-violet-300"
                          : c.kind === "extra"
                            ? "bg-amber-500/20 text-amber-300"
                            : "bg-slate-800 text-slate-400"
                  }`}
                >
                  {t(c.labels)}
                </span>
                <p className={`${langClass(lang)} mt-1 text-[15px] ${kindColor(c.kind)}`}>
                  {t(c.texts)}
                </p>
              </div>
              <ReplayButton text={t(c.texts)} kind={sfxOf(c.kind)} />
            </div>
          ))}
          {state.commentary.length === 0 && (
            <p className="px-4 py-4 text-sm text-slate-500">No commentary yet.</p>
          )}
        </div>
      )}
    </div>
  );
}

/* ============ 14. TEAM PLAYING XI ============ */

export function TeamPanel({ setup, team }: { setup: MatchSetup; team: "A" | "B" }) {
  const name = team === "A" ? setup.teamA : setup.teamB;
  const logo = team === "A" ? setup.logoA : setup.logoB;
  const players = team === "A" ? setup.playersA : setup.playersB;
  const open = usePlayerProfile();
  const cap = captainOf(players);
  const vc = viceCaptainOf(players);
  const wk = keeperOf(players);
  return (
    <div className="mc-card overflow-hidden">
      <div className="flex items-center gap-3 border-b border-slate-800 px-4 py-3">
        <TeamLogo name={name} logo={logo} size={34} />
        <div>
          <p className="text-base font-black uppercase">{name}</p>
          <p className="text-[11px] text-slate-400">
            C: {cap?.name ?? "—"} · VC: {vc?.name ?? "—"} · WK: {wk?.name ?? "—"}
          </p>
        </div>
      </div>
      <div className="space-y-2 p-3">
        {players.map((p, i) => (
          <PlayerCard key={p.id} player={p} index={i} onClick={() => open(p.name)} />
        ))}
      </div>
    </div>
  );
}

export function PlayersPanel({ setup }: { setup: MatchSetup }) {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <TeamPanel setup={setup} team="A" />
      <TeamPanel setup={setup} team="B" />
    </div>
  );
}

/* ============ 13. PLAYER PROFILE ============ */

export function PlayerProfileModal({
  state,
  name,
  onClose,
}: {
  state: MatchState;
  name: string;
  onClose: () => void;
}) {
  const p: Player | undefined = findPlayer(state.setup, name);
  const perf = playerPerformance(state, name);
  const bat = perf.batting;
  const bowl = perf.bowling;
  const field = perf.fielding;
  return (
    <div
      className="fixed inset-0 z-[60] flex items-end justify-center bg-black/75 p-3 sm:items-center"
      onClick={onClose}
    >
      <div
        className="mc-pop mc-card max-h-[88vh] w-full max-w-lg overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start gap-4 border-b border-slate-800 px-5 py-4">
          <PlayerAvatar player={p} size={52} />
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <h3 className="truncate text-lg font-black">{name}</h3>
              {p && <RoleBadges player={p} />}
            </div>
            <p className="text-sm text-emerald-400">{perf.team}</p>
            <p className="text-xs text-slate-400">
              {p?.role ?? "Player"}
              {p?.jersey ? ` · Jersey #${p.jersey}` : ""}
            </p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            ✕
          </button>
        </div>

        <div className="space-y-4 px-5 py-4">
          <div>
            <div className="mb-2 flex items-center gap-2">
              <BatIcon className="h-4 w-4" />
              <p className="text-xs font-black uppercase tracking-widest text-slate-400">
                Batting — this match
              </p>
            </div>
            {bat ? (
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                <StatLine label="Runs" value={bat.runs} />
                <StatLine label="Balls" value={bat.balls} />
                <StatLine label="Fours" value={bat.fours} />
                <StatLine label="Sixes" value={bat.sixes} />
                <StatLine label="Dot balls" value={bat.dots} />
                <StatLine label="Singles" value={bat.singles} />
                <StatLine label="Doubles" value={bat.doubles} />
                <StatLine label="Strike rate" value={strikeRate(bat.runs, bat.balls).toFixed(2)} />
                <StatLine label="Highest score" value={bat.runs} />
                <div className="col-span-2 sm:col-span-3">
                  <StatLine
                    label={bat.out ? "How dismissed" : "Status"}
                    value={bat.out ? (bat.howOut ?? "out") : "NOT OUT"}
                  />
                </div>
              </div>
            ) : (
              <p className="text-sm text-slate-500">Has not batted in this match.</p>
            )}
          </div>

          <div>
            <div className="mb-2 flex items-center gap-2">
              <BallIcon className="h-4 w-4" />
              <p className="text-xs font-black uppercase tracking-widest text-slate-400">
                Bowling — this match
              </p>
            </div>
            {bowl ? (
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                <StatLine label="Overs" value={oversStr(bowl.balls)} />
                <StatLine label="Legal balls" value={bowl.balls} />
                <StatLine label="Maidens" value={bowl.maidens} />
                <StatLine label="Runs" value={bowl.runs} />
                <StatLine label="Wickets" value={bowl.wickets} />
                <StatLine label="Economy" value={runRate(bowl.runs, bowl.balls).toFixed(2)} />
                <StatLine label="Dot balls" value={bowl.dots} />
                <StatLine label="Fours conceded" value={bowl.foursConceded} />
                <StatLine label="Sixes conceded" value={bowl.sixesConceded} />
                <StatLine label="Wides" value={bowl.wides} />
                <StatLine label="No-balls" value={bowl.noballs} />
              </div>
            ) : (
              <p className="text-sm text-slate-500">Has not bowled in this match.</p>
            )}
          </div>

          <div>
            <p className="mb-2 text-xs font-black uppercase tracking-widest text-slate-400">
              Fielding
            </p>
            <div className="grid grid-cols-3 gap-2">
              <StatLine label="Catches" value={field?.catches ?? 0} />
              <StatLine label="Run outs" value={field?.runOuts ?? 0} />
              <StatLine label="Stumpings" value={field?.stumpings ?? 0} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============ 16. MATCH RESULT (final score page) ============ */

/** Compact action button: ~36px tall, 18px icon, short label. */
function ActionButton({
  icon,
  label,
  onClick,
  href,
  primary,
}: {
  icon: ReactNode;
  label: string;
  onClick?: () => void;
  href?: string;
  primary?: boolean;
}) {
  const cls = `mc-btn inline-flex h-9 items-center gap-1.5 rounded-lg border px-3 text-xs font-bold transition ${
    primary
      ? "border-emerald-500/50 bg-emerald-500/15 text-emerald-300 hover:bg-emerald-500/25"
      : "border-slate-700 bg-slate-900/60 text-slate-300 hover:border-slate-600 hover:bg-slate-800"
  }`;
  if (href) {
    return (
      <Link href={href} className={cls}>
        {icon}
        {label}
      </Link>
    );
  }
  return (
    <button onClick={onClick} className={cls}>
      {icon}
      {label}
    </button>
  );
}

/** One team's final line. The score stays large — it is the visual focus. */
function FinalTeamLine({
  team,
  logo,
  runs,
  wickets,
  overs,
  winner,
}: {
  team: string;
  logo?: string;
  runs: number;
  wickets: number;
  overs: string;
  winner: boolean;
}) {
  return (
    <div className="flex items-center gap-3">
      <TeamLogo name={team} logo={logo} size={36} />
      <div className="min-w-0 flex-1">
        <p
          className={`truncate text-sm font-black uppercase tracking-wide ${
            winner ? "text-emerald-400" : "text-slate-300"
          }`}
        >
          {team}
          {winner && <span className="ml-1.5 text-[10px] align-middle">🏆</span>}
        </p>
        <p className="text-[11px] text-slate-500">{overs} Overs</p>
      </div>
      {/* Score deliberately kept large */}
      <p className="text-3xl font-black leading-none tracking-tight sm:text-4xl">
        {runs}
        <span className="text-slate-600">/</span>
        {wickets}
      </p>
    </div>
  );
}

export function MatchResultPanel({
  state,
  matchId,
  onOpenTab,
}: {
  state: MatchState;
  matchId?: string;
  onOpenTab?: (tab: "SCORECARD" | "BALL BY BALL" | "COMMENTARY") => void;
}) {
  if (state.status !== "completed") return null;

  // All three awards are derived from the recorded match data.
  const { playerOfMatch: pomAward, bestBatter, bestBowler } = computeAwards(state);
  const pom = pomAward?.name ?? null;
  const pomPlayer = pom ? findPlayer(state.setup, pom) : undefined;
  const setup = state.setup;

  return (
    <div className="mc-card overflow-hidden">
      {/* ---- Header: completed badge ---- */}
      <div className="flex items-center justify-between border-b border-slate-800 px-4 py-2">
        <span className="inline-flex items-center gap-1.5 rounded-md bg-emerald-500/15 px-2 py-1 text-[10px] font-black tracking-[0.18em] text-emerald-300">
          🏆 MATCH COMPLETED
        </span>
        <span className="text-[11px] font-semibold text-slate-500">
          {setup.format} · {setup.overs} ov
        </span>
      </div>

      {/* ---- Final scores (prominent) ---- */}
      <div className="space-y-3 px-4 py-4">
        {state.innings.map((i, idx) => (
          <div key={idx}>
            <FinalTeamLine
              team={i.battingTeam}
              logo={i.battingTeam === setup.teamA ? setup.logoA : setup.logoB}
              runs={i.runs}
              wickets={i.wickets}
              overs={oversStr(i.legalBalls)}
              winner={state.winner === i.battingTeam}
            />
            {idx === 0 && (
              <div className="my-2 flex items-center gap-3">
                <span className="h-px flex-1 bg-slate-800" />
                <span className="text-[10px] font-black tracking-widest text-slate-600">VS</span>
                <span className="h-px flex-1 bg-slate-800" />
              </div>
            )}
          </div>
        ))}
      </div>

      {/* ---- Result (prominent) ---- */}
      <div className="border-y border-emerald-500/20 bg-emerald-500/10 px-4 py-2.5 text-center">
        <p className="text-base font-black uppercase tracking-wide text-emerald-300 sm:text-lg">
          {state.result}
        </p>
      </div>

      {/* ---- Player of the Match: compact card ---- */}
      {pomAward && (
        <div className="flex items-center gap-3 border-b border-slate-800 bg-amber-500/5 px-4 py-2.5">
          <PlayerAvatar player={pomPlayer} size={34} />
          <div className="min-w-0 flex-1">
            <p className="text-[10px] font-black uppercase tracking-wider text-amber-400">
              🏆 Player of the Match
            </p>
            <p className="truncate text-sm font-black">
              {pomAward.name}{" "}
              <span className="text-[11px] font-semibold text-slate-400">
                ({pomAward.team})
              </span>
            </p>
            <p className="truncate text-[11px] text-slate-400">{pomAward.summary}</p>
          </div>
        </div>
      )}

      {/* ---- Best performers: compact rows ---- */}
      <div className="grid gap-px bg-slate-800 sm:grid-cols-2">
        <div className="flex items-center gap-2 bg-[#0f1622] px-4 py-2">
          <BatIcon className="h-4 w-4 shrink-0" />
          <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">
            Best Batter
          </span>
          <span className="ml-auto min-w-0 truncate text-right text-xs font-bold text-slate-200">
            {bestBatter ? `${bestBatter.name} · ${bestBatter.summary}` : "—"}
          </span>
        </div>
        <div className="flex items-center gap-2 bg-[#0f1622] px-4 py-2">
          <BallIcon className="h-4 w-4 shrink-0" />
          <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">
            Best Bowler
          </span>
          <span className="ml-auto min-w-0 truncate text-right text-xs font-bold text-slate-200">
            {bestBowler ? `${bestBowler.name} · ${bestBowler.summary}` : "—"}
          </span>
        </div>
      </div>

      {/* ---- Compact action bar ---- */}
      <div className="flex flex-wrap gap-2 px-4 py-3">
        {onOpenTab && (
          <>
            <ActionButton
              icon={<ScorecardIcon />}
              label="Scorecard"
              primary
              onClick={() => onOpenTab("SCORECARD")}
            />
            <ActionButton
              icon={<BallByBallIcon />}
              label="Ball by Ball"
              onClick={() => onOpenTab("BALL BY BALL")}
            />
            <ActionButton
              icon={<CommentaryIcon />}
              label="Commentary"
              onClick={() => onOpenTab("COMMENTARY")}
            />
          </>
        )}
        {!onOpenTab && matchId && (
          <ActionButton
            icon={<ScorecardIcon />}
            label="Scorecard"
            primary
            href={`/match?id=${matchId}`}
          />
        )}
        <ActionButton icon={<HistoryIcon />} label="Match History" href="/history" />
      </div>
    </div>
  );
}

/* ============ 15. MATCH AWARDS ============ */

export function MatchAwards({ state }: { state: MatchState }) {
  const awards = computeAwards(state);
  const prizes = state.awards.prizes ?? {};
  const hasPrizes = Object.values(prizes).some((v) => v && String(v).trim());
  const decided = state.status === "completed";

  // Nothing to show until the match has produced a result.
  if (!decided && !hasPrizes) return null;

  const rows: { label: string; prize?: string; winner: ReturnType<typeof computeAwards>["playerOfMatch"] }[] =
    [
      { label: "Player of the Match", winner: awards.playerOfMatch, prize: prizes.playerOfMatch },
      { label: "Best Batter", winner: awards.bestBatter, prize: prizes.bestBatter },
      { label: "Best Bowler", winner: awards.bestBowler, prize: prizes.bestBowler },
    ];

  return (
    <div className="mc-card overflow-hidden">
      <div className="flex items-center gap-2 border-b border-slate-800 bg-amber-500/5 px-4 py-2.5">
        <TrophyIcon className="h-4 w-4 text-amber-400" />
        <p className="text-sm font-black uppercase tracking-wider text-amber-300">Match awards</p>
        <span className="ml-auto rounded bg-slate-800 px-1.5 py-0.5 text-[10px] font-bold text-slate-400">
          AUTO
        </span>
      </div>

      {decided ? (
        <div className="divide-y divide-slate-800/70">
          {rows.map(({ label, winner, prize }) => (
            <div key={label} className="flex items-center gap-3 px-4 py-2.5">
              <PlayerAvatar
                player={winner ? findPlayer(state.setup, winner.name) : undefined}
                size={32}
              />
              <div className="min-w-0 flex-1">
                <p className="text-[10px] font-black uppercase tracking-wider text-amber-400">
                  {label}
                </p>
                <p className="truncate text-sm font-black">
                  {winner?.name ?? "—"}
                  {winner && (
                    <span className="ml-1.5 text-[11px] font-semibold text-slate-400">
                      ({winner.team})
                    </span>
                  )}
                </p>
                {winner && (
                  <p className="truncate text-[11px] text-slate-400">{winner.summary}</p>
                )}
              </div>
              {prize && (
                <span className="shrink-0 rounded-md bg-emerald-500/15 px-2 py-1 text-[11px] font-black text-emerald-300">
                  {prize}
                </span>
              )}
            </div>
          ))}
        </div>
      ) : (
        <p className="px-4 py-3 text-xs text-slate-500">
          Awards are selected automatically once the match is complete.
        </p>
      )}

      {prizes.winningTeam && (
        <div className="flex items-center justify-between border-t border-slate-800 px-4 py-2">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Winning Team Prize
          </span>
          <span className="rounded-md bg-emerald-500/15 px-2 py-1 text-[11px] font-black text-emerald-300">
            {prizes.winningTeam}
          </span>
        </div>
      )}
    </div>
  );
}

/* ============ MATCH STATISTICS + SUMMARY ============ */

export function MatchStatsPanel({ state }: { state: MatchState }) {
  const s = matchStatistics(state);
  const inn = state.innings[state.currentInnings];
  const chase = requiredInfo(state);
  return (
    <div className="mc-card overflow-hidden">
      <div className="border-b border-slate-800 px-4 py-2.5 text-sm font-black uppercase tracking-wider">
        Match statistics
      </div>
      <div className="grid gap-2 px-4 py-3 sm:grid-cols-2 lg:grid-cols-3">
        <StatLine label="Total runs" value={inn.runs} />
        <StatLine label="Wickets" value={inn.wickets} />
        <StatLine label="Overs" value={oversStr(inn.legalBalls)} />
        <StatLine label="Current run rate" value={runRate(inn.runs, inn.legalBalls).toFixed(2)} />
        <StatLine label="Required run rate" value={chase ? chase.rrr.toFixed(2) : "—"} />
        <StatLine label="Target" value={chase ? chase.target : "—"} />
        <StatLine label="Runs required" value={chase ? chase.runsNeeded : "—"} />
        <StatLine label="Balls remaining" value={chase ? chase.ballsRemaining : "—"} />
        <StatLine label="Partnership" value={`${inn.partnership.runs} (${inn.partnership.balls})`} />
        <StatLine label="Extras" value={inn.extras.total} />
        <StatLine
          label="Highest score"
          value={s.topScore ? `${s.topScore.name} ${s.topScore.runs} (${s.topScore.balls})` : "—"}
        />
        <StatLine
          label="Best bowling"
          value={
            s.bestBowling ? `${s.bestBowling.name} ${s.bestBowling.wickets}/${s.bestBowling.runs}` : "—"
          }
        />
        <StatLine label="Total boundaries" value={`${s.fours} × 4s, ${s.sixes} × 6s`} />
      </div>
    </div>
  );
}

export function SummaryPanel({ state }: { state: MatchState }) {
  const chase = requiredInfo(state);
  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        {state.innings.map((inn, i) => (
          <div key={i} className="mc-card px-4 py-4">
            <p className="text-xs font-bold uppercase tracking-widest text-slate-400">
              Innings {i + 1}
            </p>
            <p className="mt-1 text-lg font-black">{inn.battingTeam}</p>
            <p className="text-3xl font-black text-emerald-400">
              {inn.runs}/{inn.wickets}
            </p>
            <p className="text-sm text-slate-400">
              {oversStr(inn.legalBalls)} overs · RR {runRate(inn.runs, inn.legalBalls).toFixed(2)}
            </p>
          </div>
        ))}
      </div>
      {chase && state.status !== "completed" && (
        <div className="mc-card grid grid-cols-2 gap-3 px-4 py-4 sm:grid-cols-4">
          <Stat label="TARGET" value={String(chase.target)} />
          <Stat label="RUNS NEEDED" value={String(chase.runsNeeded)} accent />
          <Stat label="BALLS LEFT" value={String(chase.ballsRemaining)} />
          <Stat label="REQ. RATE" value={chase.rrr.toFixed(2)} />
        </div>
      )}
      <MatchAwards state={state} />
      <CurrentPlayersPanel state={state} />
      <CurrentOverStrip inn={state.innings[state.currentInnings]} />
      <MatchStatsPanel state={state} />
    </div>
  );
}

export function PartnershipCard({ inn }: { inn: Innings }) {
  return <PartnershipPanel inn={inn} />;
}

export function squadNames(setup: MatchSetup, teamName: string) {
  return squadOf(setup, teamName).map((p) => p.name);
}
