import React, { useState, useEffect, useRef } from 'react';
import { sendGiftFn, walletErrorMessage } from '../wallet';
import { UserProfile, GiftItem, DirectChatMessage, DirectChatConversation } from '../types';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  doc, 
  setDoc, 
  updateDoc, 
  deleteDoc,
  query, 
  where, 
  orderBy, 
  getDocs,
  limit,
  increment
} from 'firebase/firestore';
import { 
  Send, 
  Search, 
  Gift, 
  ArrowRight, 
  CheckCheck,
  User,
  X,
  Sparkles,
  Trash2,
  Coins
} from 'lucide-react';

import { AVAILABLE_GIFTS } from '../gifts';

interface ChatsViewProps {
  currentUser: UserProfile;
  onNavigateToRooms?: () => void;
}

interface TargetUser {
  uid: string;
  displayName: string;
  username?: string;
  photoURL?: string;
  bio?: string;
}

export const ChatsView: React.FC<ChatsViewProps> = ({ currentUser }) => {
  // Real Firestore state - NO FAKE DATA
  const [conversations, setConversations] = useState<DirectChatConversation[]>([]);
  const [selectedChatUser, setSelectedChatUser] = useState<TargetUser | null>(null);
  const [messages, setMessages] = useState<DirectChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<TargetUser[]>([]);
  const [allUsers, setAllUsers] = useState<TargetUser[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showGiftsModal, setShowGiftsModal] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [giftNotification, setGiftNotification] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Compute chatId between current user and target user
  const getChatId = (uid1: string, uid2: string) => {
    return [uid1, uid2].sort().join('_');
  };

  // 1. Fetch real active conversations from Firestore
  useEffect(() => {
    if (!currentUser?.uid) return;

    try {
      const chatsRef = collection(db, 'direct_chats');
      const q = query(chatsRef, where('participants', 'array-contains', currentUser.uid));

      const unsubscribe = onSnapshot(q, (snapshot) => {
        const chatsList: DirectChatConversation[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data();
          chatsList.push({
            id: docSnap.id,
            participants: data.participants || [],
            participantDetails: data.participantDetails || {},
            lastMessage: data.lastMessage || '',
            lastMessageSenderId: data.lastMessageSenderId || '',
            lastTime: data.lastTime || '',
            updatedAt: data.updatedAt || '',
            unreadCount: data.unreadCount || 0
          });
        });

        // Sort latest first
        chatsList.sort((a, b) => new Date(b.updatedAt || 0).getTime() - new Date(a.updatedAt || 0).getTime());
        setConversations(chatsList);
      }, (err) => {
        console.warn('Real chats listener error:', err);
      });

      return () => unsubscribe();
    } catch (err) {
      console.warn('Could not set up direct_chats listener:', err);
    }
  }, [currentUser?.uid]);

  // 2. Fetch real users from Firestore for the search feature
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const usersRef = collection(db, 'users');
        const q = query(usersRef, limit(30));
        const snap = await getDocs(q);
        const usersList: TargetUser[] = [];
        snap.forEach((docSnap) => {
          const data = docSnap.data();
          if (docSnap.id !== currentUser.uid) {
            usersList.push({
              uid: docSnap.id,
              displayName: data.displayName || 'مستخدم زهرة',
              username: data.username || '',
              photoURL: data.photoURL || '',
              bio: data.bio || ''
            });
          }
        });
        setAllUsers(usersList);
      } catch (err) {
        console.warn('Error fetching users:', err);
      }
    };

    fetchUsers();
  }, [currentUser.uid]);

  // Handle Search Input - Live search in real users and conversations
  useEffect(() => {
    const queryTrimmed = searchQuery.trim().toLowerCase();
    if (!queryTrimmed) {
      setSearchResults([]);
      setIsSearching(false);
      return;
    }

    setIsSearching(true);
    const matched = allUsers.filter(u => 
      u.displayName.toLowerCase().includes(queryTrimmed) || 
      (u.username && u.username.toLowerCase().includes(queryTrimmed)) ||
      u.uid.toLowerCase().includes(queryTrimmed)
    );
    setSearchResults(matched);
  }, [searchQuery, allUsers]);

  // 3. Real-time messages listener when a chat user is selected
  useEffect(() => {
    if (!currentUser?.uid || !selectedChatUser?.uid) {
      setMessages([]);
      return;
    }

    const chatId = getChatId(currentUser.uid, selectedChatUser.uid);
    const messagesRef = collection(db, 'direct_chats', chatId, 'messages');
    const q = query(messagesRef, orderBy('createdAt', 'asc'), limit(150));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs: DirectChatMessage[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        msgs.push({
          id: docSnap.id,
          chatId,
          senderId: data.senderId,
          senderName: data.senderName,
          senderAvatar: data.senderAvatar,
          text: data.text || '',
          type: data.type || 'text',
          gift: data.gift,
          createdAt: data.createdAt,
          timestamp: data.timestamp || ''
        });
      });
      setMessages(msgs);
    }, (err) => {
      console.warn('Real messages listener error:', err);
    });

    return () => unsubscribe();
  }, [currentUser?.uid, selectedChatUser?.uid]);

  // Send regular text message
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || !selectedChatUser || isSending) return;

    setIsSending(true);
    const chatId = getChatId(currentUser.uid, selectedChatUser.uid);
    const now = new Date();
    const timeFormatted = now.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
    const textToSend = inputMessage.trim();
    setInputMessage('');

    try {
      // 1. Ensure conversation document exists and is updated
      const chatDocRef = doc(db, 'direct_chats', chatId);
      await setDoc(chatDocRef, {
        id: chatId,
        participants: [currentUser.uid, selectedChatUser.uid],
        participantDetails: {
          [currentUser.uid]: {
            displayName: currentUser.displayName,
            photoURL: currentUser.photoURL || '',
            username: currentUser.username || ''
          },
          [selectedChatUser.uid]: {
            displayName: selectedChatUser.displayName,
            photoURL: selectedChatUser.photoURL || '',
            username: selectedChatUser.username || ''
          }
        },
        lastMessage: textToSend,
        lastMessageSenderId: currentUser.uid,
        lastTime: timeFormatted,
        updatedAt: now.toISOString()
      }, { merge: true });

      // 2. Add message to subcollection
      const messagesRef = collection(db, 'direct_chats', chatId, 'messages');
      await addDoc(messagesRef, {
        chatId,
        senderId: currentUser.uid,
        senderName: currentUser.displayName,
        senderAvatar: currentUser.photoURL || '',
        text: textToSend,
        type: 'text',
        createdAt: now.toISOString(),
        timestamp: timeFormatted
      });

    } catch (err) {
      console.error('Error sending message:', err);
      setInputMessage(textToSend);
      setGiftNotification('تعذر إرسال الرسالة، حاول مرة أخرى');
      setTimeout(() => setGiftNotification(null), 3000);
    } finally {
      setIsSending(false);
    }
  };

  // Send gift in direct message: the server checks the balance, charges coins,
  // credits the receiver and writes the chat message.
  const handleSendGift = async (gift: GiftItem) => {
    if (!selectedChatUser || isSending) return;
    const price = gift.costCoins || gift.cost * 5;
    if ((currentUser.coins || 0) < price) {
      setGiftNotification(`رصيد العملات (${currentUser.coins || 0}) غير كافٍ لإرسال ${gift.name} (${price})`);
      setTimeout(() => setGiftNotification(null), 3000);
      return;
    }
    setIsSending(true);
    try {
      await sendGiftFn({
        giftId: gift.id,
        currency: 'coins',
        context: { type: 'chat', targetUserId: selectedChatUser.uid }
      });
      setShowGiftsModal(false);
      setGiftNotification(`تم إرسال ${gift.icon} ${gift.name} بنجاح!`);
    } catch (err) {
      console.error('Error sending gift:', err);
      setGiftNotification(walletErrorMessage(err));
    } finally {
      setIsSending(false);
      setTimeout(() => setGiftNotification(null), 3000);
    }
  };

  // Delete own message
  const handleDeleteMessage = async (msgId: string) => {
    if (!selectedChatUser) return;
    const chatId = getChatId(currentUser.uid, selectedChatUser.uid);
    try {
      await deleteDoc(doc(db, 'direct_chats', chatId, 'messages', msgId));
    } catch (err) {
      console.error('Error deleting message:', err);
    }
  };

  // Helper to extract other user from conversation
  const getOtherParticipant = (conv: DirectChatConversation): TargetUser => {
    const otherUid = conv.participants.find(p => p !== currentUser.uid) || 'unknown';
    const details = conv.participantDetails?.[otherUid];
    return {
      uid: otherUid,
      displayName: details?.displayName || 'مستخدم زهرة',
      username: details?.username || '',
      photoURL: details?.photoURL || ''
    };
  };

  return (
    <div className="max-w-2xl mx-auto pb-24 px-2 sm:px-4">
      {/* Gift Notification Toast */}
      {giftNotification && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 bg-gradient-to-r from-amber-500 to-rose-500 text-white px-5 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 text-sm font-bold animate-bounce">
          <Sparkles className="w-4 h-4 text-yellow-200" />
          <span>{giftNotification}</span>
        </div>
      )}

      {/* ACTIVE REAL CHAT VIEW */}
      {selectedChatUser ? (
        <div className="rounded-3xl bg-white border border-pink-100 shadow-xl overflow-hidden flex flex-col h-[82vh]">
          {/* Header */}
          <div className="p-3 bg-white border-b border-pink-100 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setSelectedChatUser(null)}
                className="p-2 rounded-2xl bg-pink-50 hover:bg-pink-100 text-pink-700 transition-colors cursor-pointer"
                title="رجوع"
              >
                <ArrowRight className="w-5 h-5" />
              </button>

              <div className="relative">
                {selectedChatUser.photoURL ? (
                  <img
                    src={selectedChatUser.photoURL}
                    alt={selectedChatUser.displayName}
                    className="w-10 h-10 rounded-full object-cover border-2 border-pink-300"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-pink-400 to-rose-400 text-white flex items-center justify-center font-bold text-sm">
                    {selectedChatUser.displayName[0] || 'ز'}
                  </div>
                )}
                <span className="absolute bottom-0 left-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white" />
              </div>

              <div>
                <h3 className="text-sm font-black text-slate-900">
                  {selectedChatUser.displayName}
                </h3>
                {selectedChatUser.username && (
                  <span className="text-[11px] text-pink-600 dir-ltr block">
                    @{selectedChatUser.username}
                  </span>
                )}
              </div>
            </div>

            {/* Quick Gift Trigger in Header */}
            <button
              onClick={() => setShowGiftsModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-50 to-pink-50 hover:from-amber-100 hover:to-pink-100 border border-amber-200 text-amber-700 text-xs font-bold transition-all cursor-pointer shadow-xs"
              title="إرسال هدية للمحادثة"
            >
              <Gift className="w-4 h-4 text-amber-600 animate-pulse" />
              <span>إرسال هدية</span>
            </button>
          </div>

          {/* Messages Stream - 100% Real Firestore Live */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-white">
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
                <div className="w-16 h-16 rounded-full bg-pink-100/60 text-pink-500 flex items-center justify-center mb-3">
                  <Gift className="w-8 h-8" />
                </div>
                <h4 className="text-sm font-bold text-slate-700">محادثة حقيقية وجديدة</h4>
                <p className="text-xs text-slate-500 max-w-xs mt-1">
                  ابدأ المحادثة الآن بإرسال رسالة أو هدية لـ {selectedChatUser.displayName} 🌸
                </p>
              </div>
            ) : (
              messages.map((msg) => {
                const isMe = msg.senderId === currentUser.uid;

                if (msg.type === 'gift' && msg.gift) {
                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col group ${isMe ? 'items-start' : 'items-end'}`}
                    >
                      <div
                        className={`relative max-w-[85%] sm:max-w-[70%] p-3.5 rounded-3xl shadow-md border ${
                          isMe
                            ? 'bg-gradient-to-br from-amber-500 via-rose-500 to-pink-600 text-white border-amber-300 rounded-tr-none'
                            : 'bg-gradient-to-br from-amber-50 to-rose-50 text-slate-800 border-amber-200 rounded-tl-none'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-2xl shadow-inner animate-bounce">
                            {msg.gift.icon}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5 text-xs font-black">
                              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
                              <span>{isMe ? 'أرسلتَ هدية فاخرة' : `أرسل لك هدية`}</span>
                            </div>
                            <h4 className="text-sm font-extrabold mt-0.5">
                              {msg.gift.name}
                            </h4>
                            <span className="text-[10px] opacity-80">
                              {msg.gift.cost} كوينز 🪙
                            </span>
                          </div>
                        </div>

                        <div className="text-[9px] mt-2 flex items-center justify-between opacity-80">
                          <span>{msg.timestamp}</span>
                          {isMe && (
                            <button
                              onClick={() => handleDeleteMessage(msg.id)}
                              className="opacity-0 group-hover:opacity-100 hover:text-red-200 transition-opacity p-0.5"
                              title="حذف الهدية من المحادثة"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                }

                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col group ${isMe ? 'items-start' : 'items-end'}`}
                  >
                    <div
                      className={`relative max-w-[80%] px-4 py-2.5 rounded-2xl text-xs sm:text-sm leading-relaxed shadow-xs ${
                        isMe
                          ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white rounded-tr-none'
                          : 'bg-white text-slate-800 border border-pink-100 rounded-tl-none'
                      }`}
                    >
                      <p className="break-words font-['Cairo'] whitespace-pre-wrap">{msg.text}</p>
                      <div
                        className={`text-[9px] mt-1 flex items-center gap-1 ${
                          isMe ? 'text-pink-100 justify-end' : 'text-slate-400 justify-start'
                        }`}
                      >
                        <span>{msg.timestamp}</span>
                        {isMe && <CheckCheck className="w-3 h-3" />}
                        {isMe && (
                          <button
                            onClick={() => handleDeleteMessage(msg.id)}
                            className="opacity-0 group-hover:opacity-100 hover:text-red-300 transition-opacity p-0.5 mr-1"
                            title="حذف الرسالة"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* REAL CHAT INPUT BAR WITH GIFTS BUTTON NEXT TO MESSAGES */}
          <form
            onSubmit={handleSendMessage}
            className="p-3 bg-white border-t border-pink-100 flex items-center gap-2"
          >
            {/* 🎁 هدايا جنب رسايل - The Gifts Button right beside message input */}
            <button
              type="button"
              onClick={() => setShowGiftsModal(true)}
              className="flex items-center gap-1.5 px-3 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-600 hover:to-rose-600 text-white font-bold text-xs shadow-md active:scale-95 transition-all cursor-pointer shrink-0"
              title="إرسال هدية"
            >
              <Gift className="w-4 h-4 text-yellow-200" />
              <span>هدايا</span>
            </button>

            {/* Message Input Box */}
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder={`اكتب رسالتك لـ ${selectedChatUser.displayName}...`}
              className="flex-1 bg-slate-50 border border-slate-200 focus:border-pink-500 rounded-2xl px-4 py-2.5 text-xs sm:text-sm text-slate-900 focus:outline-none"
            />

            {/* Send Button */}
            <button
              type="submit"
              disabled={!inputMessage.trim() || isSending}
              className="p-2.5 rounded-2xl bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 disabled:opacity-40 text-white shadow-md active:scale-95 transition-all cursor-pointer shrink-0"
              title="إرسال"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      ) : (
        /* CONVERSATIONS SCREEN: PURE SEARCH AND REAL CHATS ONLY */
        <div className="space-y-4 pt-2">
          
          {/* ONLY THE SEARCH BAR - مش عايز غير البحث فقط */}
          <div className="relative">
            <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث عن أي مستخدم بالاسم لبدء محادثة حقيقية..."
              className="w-full bg-white border border-pink-200 focus:border-pink-500 rounded-3xl pr-12 pl-10 py-3.5 text-sm text-slate-900 focus:outline-none shadow-sm transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute left-3.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* SEARCH RESULTS VIEW */}
          {isSearching ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between px-2 text-xs font-bold text-slate-500">
                <span>نتائج البحث الحقيقية ({searchResults.length})</span>
                <span className="text-pink-600">انقر لبدء المحادثة</span>
              </div>

              {searchResults.length === 0 ? (
                <div className="p-8 text-center bg-white rounded-3xl border border-pink-100 shadow-xs">
                  <p className="text-sm font-bold text-slate-600">لا يوجد مستخدم بهذا الاسم</p>
                  <p className="text-xs text-slate-400 mt-1">تأكد من كتابة الاسم أو المعرف بشكل صحيح</p>
                </div>
              ) : (
                searchResults.map((user) => (
                  <div
                    key={user.uid}
                    onClick={() => {
                      setSelectedChatUser(user);
                      setSearchQuery('');
                    }}
                    className="p-3.5 rounded-2xl bg-white border border-pink-100 shadow-xs hover:shadow-md hover:border-pink-300 transition-all cursor-pointer flex items-center justify-between group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        {user.photoURL ? (
                          <img
                            src={user.photoURL}
                            alt={user.displayName}
                            className="w-12 h-12 rounded-full object-cover border-2 border-pink-200 group-hover:scale-105 transition-transform"
                          />
                        ) : (
                          <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-pink-400 to-rose-400 text-white flex items-center justify-center font-bold text-base">
                            {user.displayName[0] || 'ز'}
                          </div>
                        )}
                        <span className="absolute bottom-0 left-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white" />
                      </div>

                      <div>
                        <h3 className="text-sm font-bold text-slate-900 group-hover:text-pink-600 transition-colors">
                          {user.displayName}
                        </h3>
                        {user.username && (
                          <span className="text-[11px] text-pink-600 dir-ltr block">
                            @{user.username}
                          </span>
                        )}
                        {user.bio && (
                          <p className="text-xs text-slate-400 line-clamp-1 mt-0.5">
                            {user.bio}
                          </p>
                        )}
                      </div>
                    </div>

                    <button className="px-3.5 py-1.5 rounded-xl bg-pink-50 group-hover:bg-pink-600 group-hover:text-white text-pink-600 text-xs font-bold transition-colors">
                      مراسلة 💬
                    </button>
                  </div>
                ))
              )}
            </div>
          ) : (
            /* REAL ONGOING CONVERSATIONS LIST */
            <div className="space-y-3">
              {conversations.length === 0 ? (
                <div className="space-y-4">
                  <div className="p-8 text-center bg-white rounded-3xl border border-pink-100 shadow-xs">
                    <div className="w-14 h-14 mx-auto rounded-full bg-pink-50 text-pink-500 flex items-center justify-center mb-3">
                      <Search className="w-7 h-7" />
                    </div>
                    <h3 className="text-sm font-bold text-slate-800">لا توجد محادثات سابقة</h3>
                    <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                      ابحث في الأعلى بالاسم لبدء محادثة حقيقية وإرسال الهدايا والرسائل 🌸
                    </p>
                  </div>

                  {/* List of real registered users to chat with */}
                  {allUsers.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="text-xs font-black text-slate-600 px-2">
                        مستخدمون متاحون للتواصل المباشر:
                      </h4>
                      {allUsers.slice(0, 5).map((user) => (
                        <div
                          key={user.uid}
                          onClick={() => setSelectedChatUser(user)}
                          className="p-3.5 rounded-2xl bg-white border border-pink-100/80 shadow-xs hover:shadow-md hover:border-pink-300 transition-all cursor-pointer flex items-center justify-between group"
                        >
                          <div className="flex items-center gap-3">
                            <div className="relative">
                              {user.photoURL ? (
                                <img
                                  src={user.photoURL}
                                  alt={user.displayName}
                                  className="w-11 h-11 rounded-full object-cover border-2 border-pink-200"
                                />
                              ) : (
                                <div className="w-11 h-11 rounded-full bg-pink-500 text-white flex items-center justify-center font-bold text-sm">
                                  {user.displayName[0] || 'ز'}
                                </div>
                              )}
                              <span className="absolute bottom-0 left-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-white" />
                            </div>
                            <div>
                              <h4 className="text-sm font-bold text-slate-900 group-hover:text-pink-600 transition-colors">
                                {user.displayName}
                              </h4>
                              {user.bio ? (
                                <p className="text-xs text-slate-400 line-clamp-1">{user.bio}</p>
                              ) : (
                                <span className="text-[11px] text-pink-500">انقر لبدء المحادثة وإرسال الهدايا</span>
                              )}
                            </div>
                          </div>
                          <span className="text-xs font-bold text-pink-600 bg-pink-50 px-3 py-1 rounded-xl group-hover:bg-pink-600 group-hover:text-white transition-colors">
                            محادثة 🌸
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="px-2 text-xs font-bold text-slate-500">المحادثات الحالية</div>
                  {conversations.map((conv) => {
                    const otherUser = getOtherParticipant(conv);
                    return (
                      <div
                        key={conv.id}
                        onClick={() => setSelectedChatUser(otherUser)}
                        className="p-3.5 rounded-2xl bg-white border border-pink-100 shadow-xs hover:shadow-md hover:border-pink-300 transition-all cursor-pointer flex items-center justify-between group"
                      >
                        <div className="flex items-center gap-3">
                          <div className="relative">
                            {otherUser.photoURL ? (
                              <img
                                src={otherUser.photoURL}
                                alt={otherUser.displayName}
                                className="w-12 h-12 rounded-full object-cover border-2 border-pink-200 group-hover:scale-105 transition-transform"
                              />
                            ) : (
                              <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-pink-400 to-rose-400 text-white flex items-center justify-center font-bold text-base">
                                {otherUser.displayName[0] || 'ز'}
                              </div>
                            )}
                            <span className="absolute bottom-0 left-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white" />
                          </div>

                          <div>
                            <h3 className="text-sm font-bold text-slate-900 group-hover:text-pink-600 transition-colors">
                              {otherUser.displayName}
                            </h3>
                            <p className="text-xs text-slate-500 line-clamp-1 mt-0.5 font-['Cairo']">
                              {conv.lastMessage || 'بدء محادثة حقيقية'}
                            </p>
                          </div>
                        </div>

                        <div className="flex flex-col items-end gap-1 text-[11px] text-slate-400">
                          <span>{conv.lastTime || 'الآن'}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

        </div>
      )}

      {/* LUXURY GIFTS MODAL / DRAWER */}
      {showGiftsModal && selectedChatUser && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-white rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-pink-100 space-y-4 max-h-[85vh] overflow-y-auto">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-pink-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center shadow-inner">
                  <Gift className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900">
                    إرسال هدية فاخرة
                  </h3>
                  <span className="text-[11px] text-slate-500">
                    إلى {selectedChatUser.displayName}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-xl text-amber-800 text-xs font-bold">
                  <Coins className="w-3.5 h-3.5 text-amber-600" />
                  <span>{currentUser.coins || 0}</span>
                </div>
                <button
                  onClick={() => setShowGiftsModal(false)}
                  className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Gifts Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {AVAILABLE_GIFTS.map((gift) => (
                <button
                  key={gift.id}
                  onClick={() => handleSendGift(gift)}
                  disabled={isSending}
                  className="p-3 rounded-2xl border border-pink-100 hover:border-amber-400 bg-gradient-to-b from-white to-pink-50/40 hover:from-amber-50/30 hover:to-pink-100/50 shadow-xs hover:shadow-md transition-all flex flex-col items-center text-center group cursor-pointer active:scale-95 disabled:opacity-50"
                >
                  <div className="w-12 h-12 rounded-2xl bg-white shadow-xs flex items-center justify-center text-2xl group-hover:scale-110 transition-transform mb-1.5">
                    {gift.icon}
                  </div>
                  <span className="text-xs font-bold text-slate-800 line-clamp-1">
                    {gift.name}
                  </span>
                  <span className="text-[11px] font-extrabold text-amber-600 mt-1 flex items-center gap-1">
                    <span>{gift.costCoins || gift.cost * 5}</span>
                    <span>🪙</span>
                  </span>
                </button>
              ))}
            </div>

            <p className="text-[11px] text-center text-slate-400 pt-1">
              تظهر الهدية في المحادثة مباشرة مع تأثيرات لامعة لصديقك 🌸
            </p>
          </div>
        </div>
      )}

    </div>
  );
};
