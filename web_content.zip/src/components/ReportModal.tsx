import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  AlertTriangle, 
  ShieldAlert, 
  CheckCircle2, 
  Lock 
} from 'lucide-react';

const REPORT_REASONS = [
  'Harassment or Personal Attacks',
  'Doxxing or Sharing Real Names/Phone Numbers',
  'Hate Speech, Slurs or Violence',
  'Explicit Sexual Content',
  'Fake News, Defamation or Impersonation',
  'Spam or Commercial Promotion',
];

export const ReportModal: React.FC = () => {
  const { 
    isReportModalOpen, 
    setIsReportModalOpen, 
    reportTargetConfession, 
    reportConfession 
  } = useApp();

  const [selectedReason, setSelectedReason] = useState(REPORT_REASONS[0]);
  const [submitted, setSubmitted] = useState(false);

  if (!isReportModalOpen || !reportTargetConfession) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    reportConfession(reportTargetConfession.id, selectedReason);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setIsReportModalOpen(false);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div 
        className="w-full max-w-md bg-[#0e111d] border border-rose-500/40 rounded-3xl p-5 shadow-2xl shadow-rose-950/40 relative"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2 text-rose-400">
            <ShieldAlert className="w-5 h-5" />
            <h3 className="font-display font-bold text-base text-slate-100">
              Report Whisper
            </h3>
          </div>
          <button
            onClick={() => setIsReportModalOpen(false)}
            className="p-1.5 rounded-full bg-slate-800/60 hover:bg-slate-700 text-slate-400 hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {submitted ? (
          <div className="py-8 text-center space-y-2">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto animate-bounce" />
            <p className="text-sm font-semibold text-slate-100">
              Report Submitted
            </p>
            <p className="text-xs text-slate-400 max-w-xs mx-auto">
              Our auto-moderation algorithm has recorded this report. If threshold is met, the confession is purged and the author hash receives a system strike.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 my-3">
            <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-slate-300">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1">
                Reported Content
              </span>
              <p className="italic text-slate-300 line-clamp-2">
                "{reportTargetConfession.content}"
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2">
                Why are you reporting this confession?
              </label>
              <div className="space-y-1.5">
                {REPORT_REASONS.map(reason => (
                  <label
                    key={reason}
                    className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-xs cursor-pointer transition-all ${
                      selectedReason === reason 
                        ? 'bg-rose-500/15 border-rose-500/50 text-rose-200' 
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <input
                      type="radio"
                      name="reportReason"
                      value={reason}
                      checked={selectedReason === reason}
                      onChange={() => setSelectedReason(reason)}
                      className="accent-rose-500"
                    />
                    <span>{reason}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsReportModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-slate-200"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition-all shadow-md shadow-rose-900/30 active:scale-95"
              >
                Submit Report
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
