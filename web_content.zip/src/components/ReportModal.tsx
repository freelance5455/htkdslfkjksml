import React, { useState } from 'react';
import { Flag, X, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { api } from '../services/api.ts';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  reporterId: string;
  reportedUserId: string;
  reportedUsername: string;
  messageId?: string;
  evidenceSnippet?: string;
}

const REPORT_REASONS = [
  'Toxic behavior or abuse',
  'Aimbot / Hacks / Cheating in scrims',
  'Spam or advertising scams',
  'Impersonating clan officials',
  'Harassment in private DM',
  'Other esports violation',
];

export const ReportModal: React.FC<ReportModalProps> = ({
  isOpen,
  onClose,
  reporterId,
  reportedUserId,
  reportedUsername,
  messageId,
  evidenceSnippet,
}) => {
  const [selectedReason, setSelectedReason] = useState(REPORT_REASONS[0]);
  const [customDetails, setCustomDetails] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const fullReason = customDetails.trim()
        ? `${selectedReason} - ${customDetails.trim()}`
        : selectedReason;

      await api.submitReport({
        reporterId,
        reportedUserId,
        messageId,
        reason: fullReason,
        evidenceSnippet,
      });

      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        onClose();
      }, 1500);
    } catch {
      alert('Failed to submit report');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
      <div className="w-full max-w-sm rounded-2xl bg-[#0a0f18] border border-red-500/40 p-5 space-y-4 text-xs text-slate-200">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2 text-red-400 font-bold text-sm">
            <Flag size={16} />
            <span>Report @{reportedUsername}</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X size={16} />
          </button>
        </div>

        {submitted ? (
          <div className="py-6 text-center space-y-2">
            <CheckCircle2 size={36} className="mx-auto text-emerald-400" />
            <div className="font-bold text-white text-sm">Report Submitted</div>
            <p className="text-slate-400 text-xs">
              Thank you. The Unknown Gamer admin team will review this report.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3.5">
            {evidenceSnippet && (
              <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-[11px] font-mono text-slate-300">
                <span className="text-slate-500 block mb-0.5">Reported Message:</span>
                "{evidenceSnippet}"
              </div>
            )}

            <div>
              <label className="block text-slate-300 font-medium mb-1">Violation Category</label>
              <select
                value={selectedReason}
                onChange={(e) => setSelectedReason(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#0c121e] border border-slate-700 text-white outline-none focus:border-red-400 text-xs"
              >
                {REPORT_REASONS.map(r => (
                  <option key={r} value={r}>{r}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">Additional Context (Optional)</label>
              <textarea
                rows={2}
                value={customDetails}
                onChange={(e) => setCustomDetails(e.target.value)}
                placeholder="Describe what occurred in the match or chat..."
                className="w-full px-3 py-2 rounded-xl bg-[#0c121e] border border-slate-700 text-white outline-none focus:border-red-400 text-xs resize-none"
              />
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold"
              >
                {loading ? 'Submitting...' : 'Send to Admin'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
