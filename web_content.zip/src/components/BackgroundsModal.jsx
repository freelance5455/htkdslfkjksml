import React, { useRef, useState } from 'react';
import { Check, ImagePlus, Sparkles, Trash2, Upload, X } from 'lucide-react';
import { getAssetSrc } from '../utils/gameAssets';
import { sound } from '../utils/sound';
export const BUILTIN_BACKGROUNDS = [
    {
        id: 'sky-kingdom',
        src: 'assets/flapora/FLAPORA_background.webp',
        labelAr: 'مملكة السماء',
        labelEn: 'Sky Kingdom',
    },
    {
        id: 'sunset-citadel',
        src: 'assets/flapora/FLAPORA_bg_sunset.webp',
        labelAr: 'غروب القلعة',
        labelEn: 'Sunset Citadel',
    },
    {
        id: 'starlight-keep',
        src: 'assets/flapora/FLAPORA_bg_night.webp',
        labelAr: 'ليلة النجوم',
        labelEn: 'Starlight Keep',
    },
    {
        id: 'sakura-island',
        src: 'assets/flapora/FLAPORA_bg_sakura.webp',
        labelAr: 'جزيرة الكرز',
        labelEn: 'Sakura Island',
    },
];
async function compressImageToPortraitDataUrl(file) {
    const objectUrl = URL.createObjectURL(file);
    try {
        const img = await new Promise((resolve, reject) => {
            const el = new Image();
            el.onload = () => resolve(el);
            el.onerror = () => reject(new Error('Invalid image'));
            el.src = objectUrl;
        });
        const targetW = 720;
        const targetH = 1280;
        const canvas = document.createElement('canvas');
        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext('2d');
        if (!ctx)
            throw new Error('Canvas unavailable');
        // Center-crop ("cover") to 9:16 portrait stage so any phone photo fits neatly
        const srcRatio = img.naturalWidth / img.naturalHeight;
        const dstRatio = targetW / targetH;
        let sx = 0;
        let sy = 0;
        let sw = img.naturalWidth;
        let sh = img.naturalHeight;
        if (srcRatio > dstRatio) {
            sw = Math.round(img.naturalHeight * dstRatio);
            sx = Math.round((img.naturalWidth - sw) / 2);
        }
        else if (srcRatio < dstRatio) {
            sh = Math.round(img.naturalWidth / dstRatio);
            sy = Math.round((img.naturalHeight - sh) / 2);
        }
        ctx.drawImage(img, sx, sy, sw, sh, 0, 0, targetW, targetH);
        const webpUrl = canvas.toDataURL('image/webp', 0.8);
        if (webpUrl.startsWith('data:image/webp')) {
            return webpUrl;
        }
        return canvas.toDataURL('image/jpeg', 0.82);
    }
    finally {
        URL.revokeObjectURL(objectUrl);
    }
}
export const BackgroundsModal = ({ open, language, selectedId, customBackgrounds, storageError, onSelect, onAddCustom, onRemoveCustom, onClose, }) => {
    const fileInputRef = useRef(null);
    const [isProcessing, setIsProcessing] = useState(false);
    const [uploadError, setUploadError] = useState(null);
    if (!open)
        return null;
    const isAr = language === 'ar';
    const handleFileChange = async (e) => {
        const file = e.target.files?.[0];
        e.target.value = '';
        if (!file)
            return;
        if (!file.type.startsWith('image/')) {
            setUploadError(isAr ? 'الرجاء اختيار ملف صورة صالح' : 'Please choose a valid image file');
            return;
        }
        setUploadError(null);
        setIsProcessing(true);
        try {
            const dataUrl = await compressImageToPortraitDataUrl(file);
            const nextIndex = customBackgrounds.length + 1;
            const newBg = {
                id: `custom-${Date.now()}`,
                src: dataUrl,
                labelAr: `خلفيتي ${nextIndex}`,
                labelEn: `My Photo ${nextIndex}`,
                isCustom: true,
            };
            const saved = onAddCustom(newBg);
            if (saved) {
                sound.playClick();
            }
        }
        catch {
            setUploadError(isAr
                ? 'تعذر قراءة الصورة، جرّب صورة أخرى'
                : 'Could not load this image, please try another');
        }
        finally {
            setIsProcessing(false);
        }
    };
    const renderCard = (bg) => {
        const isSelected = bg.id === selectedId;
        const label = isAr ? bg.labelAr : bg.labelEn;
        return (<div key={bg.id} role="button" tabIndex={0} aria-pressed={isSelected} aria-label={label} onClick={() => {
                sound.playClick();
                onSelect(bg.id);
            }} onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    sound.playClick();
                    onSelect(bg.id);
                }
            }} className={`group relative aspect-[9/14] rounded-2xl overflow-hidden cursor-pointer transition-all duration-150 select-none focus-visible:outline-2 focus-visible:outline-yellow-300 ${isSelected
                ? 'ring-[3.5px] ring-emerald-400 border-[2.5px] border-amber-950 shadow-[0_6px_14px_rgba(16,185,129,0.4)] scale-[1.01]'
                : 'border-[2.5px] border-amber-900/35 hover:border-amber-700 hover:scale-[1.02] active:scale-[0.98] shadow-sm'}`}>
        <img src={getAssetSrc(bg.src)} alt={label} referrerPolicy="no-referrer" loading="eager" decoding="sync" className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"/>

        {/* Subtle glossy highlight on top edge */}
        <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 top-0 h-8 bg-gradient-to-b from-white/25 to-transparent"/>

        {/* Selected Badge */}
        {isSelected && (<div className={`absolute top-2 ${isAr ? 'right-2' : 'left-2'} w-7 h-7 rounded-full bg-gradient-to-b from-emerald-400 to-emerald-600 border-2 border-amber-950 shadow-md flex items-center justify-center text-white`}>
            <Check className="w-4 h-4 stroke-[3.2]"/>
          </div>)}

        {/* Delete Button for Custom Mobile Backgrounds */}
        {bg.isCustom && (<button type="button" aria-label={isAr ? 'حذف الخلفية' : 'Delete background'} onClick={(e) => {
                    e.stopPropagation();
                    sound.playClick();
                    onRemoveCustom(bg.id);
                }} className={`absolute top-1.5 ${isAr ? 'left-1.5' : 'right-1.5'} w-8 h-8 rounded-full bg-rose-500/95 hover:bg-rose-600 border-2 border-amber-950 shadow-md flex items-center justify-center text-white cursor-pointer transition-transform duration-150 hover:scale-110 active:scale-95`}>
            <Trash2 className="w-3.5 h-3.5"/>
          </button>)}

        {/* Title Footer */}
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/90 via-slate-950/55 to-transparent px-2.5 pt-6 pb-2 flex items-center justify-between gap-1">
          <span className="text-xs font-extrabold text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] truncate">
            {label}
          </span>
          {isSelected && (<span className="text-[10px] font-extrabold text-emerald-300 shrink-0">
              {isAr ? 'مفعّلة' : 'Active'}
            </span>)}
        </div>
      </div>);
    };
    return (<div className="absolute inset-0 z-30 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4" onClick={(e) => {
            if (e.target === e.currentTarget) {
                sound.playClick();
                onClose();
            }
        }}>
      <div dir={isAr ? 'rtl' : 'ltr'} role="dialog" aria-modal="true" aria-label={isAr ? 'معرض الخلفيات' : 'Backgrounds Gallery'} className={`relative w-full max-w-[345px] pt-5 ${isAr ? 'font-arabic' : ''}`}>
        {/* Overlapping Top Ribbon Banner */}
        <div className="absolute top-0 inset-x-0 flex justify-center z-10 pointer-events-none">
          <div className="px-7 py-2 rounded-2xl bg-gradient-to-b from-sky-400 via-sky-500 to-blue-600 border-[3px] border-amber-950 shadow-[0_4px_0_#451A03] text-white font-display font-bold text-xl tracking-wide drop-shadow-[0_2px_0_rgba(23,37,84,0.9)]">
            {isAr ? 'الخلفيات' : 'Backgrounds'}
          </div>
        </div>

        {/* Close Button */}
        <button type="button" onClick={() => {
            sound.playClick();
            onClose();
        }} aria-label={isAr ? 'إغلاق' : 'Close'} className={`absolute top-2 ${isAr ? 'left-1' : 'right-1'} z-20 w-11 h-11 rounded-full bg-gradient-to-b from-rose-400 to-rose-600 hover:brightness-105 border-[3px] border-amber-950 shadow-[0_3px_0_#451A03] text-white flex items-center justify-center cursor-pointer transition-transform duration-150 hover:scale-105 active:scale-95 focus-visible:outline-2 focus-visible:outline-yellow-300`}>
          <X className="w-5 h-5 stroke-[3]"/>
        </button>

        {/* Cartoon Wood & Cream Parchment Frame */}
        <div className="rounded-[28px] bg-gradient-to-b from-amber-500 via-amber-600 to-amber-800 border-[3px] border-amber-950 p-2 shadow-[0_10px_0_#451A03,0_24px_50px_rgba(0,0,0,0.55)]">
          <div className="rounded-[20px] bg-gradient-to-b from-amber-50 to-amber-100 border-2 border-amber-800/30 px-3.5 pt-8 pb-4 text-amber-950 flex flex-col gap-3">
            {/* Hidden Mobile Photo Input */}
            <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileChange} className="hidden"/>

            {/* Upload from Mobile Action Button */}
            <button type="button" disabled={isProcessing} onClick={() => {
            sound.playClick();
            fileInputRef.current?.click();
        }} className="w-full min-h-[48px] rounded-2xl bg-gradient-to-b from-amber-300 via-orange-400 to-orange-500 hover:brightness-105 disabled:opacity-70 border-[2.5px] border-amber-950 shadow-[0_4px_0_#451A03] px-4 py-2 text-white font-extrabold text-sm flex items-center justify-center gap-2.5 cursor-pointer transition-transform duration-150 active:translate-y-0.5 active:shadow-[0_2px_0_#451A03] focus-visible:outline-2 focus-visible:outline-yellow-300">
              {isProcessing ? (<Upload className="w-5 h-5 animate-bounce shrink-0"/>) : (<ImagePlus className="w-5 h-5 shrink-0"/>)}
              <span className="drop-shadow-[0_1.5px_0_rgba(69,26,3,0.75)]">
                {isProcessing
            ? isAr
                ? 'جاري تجهيز الخلفية...'
                : 'Preparing image...'
            : isAr
                ? 'إضافة خلفية من الموبايل'
                : 'Add Background from Phone'}
              </span>
            </button>

            {(uploadError || storageError) && (<div className="rounded-xl bg-rose-100 border border-rose-400 px-3 py-2 text-xs font-bold text-rose-800 text-center">
                {uploadError || storageError}
              </div>)}

            {/* Organized Scrollable Backgrounds Grid */}
            <div className="max-h-[46dvh] overflow-y-auto px-0.5 py-1 space-y-4">
              {/* Custom User Photos Section */}
              {customBackgrounds.length > 0 && (<div className="space-y-2">
                  <div className="flex items-center justify-between px-1">
                    <span className="text-xs font-extrabold text-amber-900 flex items-center gap-1.5">
                      <ImagePlus className="w-3.5 h-3.5 text-orange-600"/>
                      {isAr ? 'خلفياتي المضافة' : 'My Custom Photos'}
                    </span>
                    <span className="text-[11px] font-bold text-amber-800/80 tabular-nums">
                      {customBackgrounds.length}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2.5">
                    {customBackgrounds.map(renderCard)}
                  </div>
                </div>)}

              {/* Built-in Sky Worlds Section */}
              <div className="space-y-2">
                <div className="flex items-center justify-between px-1">
                  <span className="text-xs font-extrabold text-amber-900 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-sky-600"/>
                    {isAr ? 'عوالم اللعبة' : 'Game Worlds'}
                  </span>
                  <span className="text-[11px] font-bold text-amber-800/80 tabular-nums">
                    {BUILTIN_BACKGROUNDS.length}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2.5">
                  {BUILTIN_BACKGROUNDS.map(renderCard)}
                </div>
              </div>
            </div>

            {/* Done Button */}
            <button type="button" onClick={() => {
            sound.playClick();
            onClose();
        }} className="w-full min-h-[46px] rounded-2xl bg-gradient-to-b from-emerald-400 via-emerald-500 to-emerald-600 hover:brightness-105 border-[3px] border-amber-950 shadow-[0_4px_0_#451A03] text-white font-extrabold text-base tracking-wide cursor-pointer transition-transform duration-150 active:translate-y-0.5 active:shadow-[0_2px_0_#451A03] focus-visible:outline-2 focus-visible:outline-yellow-300">
              {isAr ? 'تم' : 'Done'}
            </button>
          </div>
        </div>
      </div>
    </div>);
};
