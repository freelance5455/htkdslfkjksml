import React, { useState } from 'react';
import { AppSettings, Alarm } from '../types/alarm';
import {
  Volume2,
  Clock,
  Zap,
  Moon,
  Sun,
  ShieldCheck,
  ShieldAlert,
  Play,
  Download,
  Upload,
  Info,
  CheckCircle,
  Smartphone,
  Check,
} from 'lucide-react';
import { requestNotificationPermission } from '../utils/alarmEngine';

interface SettingsTabProps {
  settings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  onTriggerTestAlarm: () => void;
  alarms: Alarm[];
  onImportAlarms: (alarms: Alarm[]) => void;
}

export const SettingsTab: React.FC<SettingsTabProps> = ({
  settings,
  onUpdateSettings,
  onTriggerTestAlarm,
  alarms,
  onImportAlarms,
}) => {
  const [notificationStatus, setNotificationStatus] = useState<string>(
    'Notification' in window ? Notification.permission : 'not-supported'
  );
  const [isTestPending, setIsTestPending] = useState(false);
  const [importMessage, setImportMessage] = useState<string | null>(null);

  const handleRequestNotif = async () => {
    const perm = await requestNotificationPermission();
    setNotificationStatus(perm);
  };

  const handleTestIn5Seconds = () => {
    setIsTestPending(true);
    setTimeout(() => {
      setIsTestPending(false);
      onTriggerTestAlarm();
    }, 5000);
  };

  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(alarms, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `wakeup_alarms_backup_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const fileReader = new FileReader();
    fileReader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (Array.isArray(parsed)) {
          onImportAlarms(parsed);
          setImportMessage(`Successfully imported ${parsed.length} alarms!`);
        } else {
          setImportMessage('Invalid JSON format for alarm backup.');
        }
      } catch (err) {
        setImportMessage('Error reading JSON file.');
      }
    };
    fileReader.readAsText(files[0]);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200 max-w-4xl mx-auto">
      {/* Title */}
      <div>
        <h2 className="text-xl font-extrabold text-slate-900 dark:text-white font-sans">
          App Settings & Android System Rules
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">
          Configure default behaviors, exact alarm permissions, and backup data.
        </p>
      </div>

      {/* Test Alarm Immediate Sandbox Banner */}
      <div className="p-5 rounded-3xl bg-slate-900 dark:bg-slate-950 text-white shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Zap className="w-5 h-5 text-amber-400" />
            <h3 className="text-sm font-bold uppercase tracking-wider text-white">
              5-Second Test Alarm Trigger
            </h3>
          </div>
          <p className="text-xs text-slate-300">
            Test full-screen video/music ringing, volume ramp, and notification alerts.
          </p>
        </div>

        <button
          onClick={handleTestIn5Seconds}
          disabled={isTestPending}
          className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-white text-slate-900 hover:bg-slate-100 font-extrabold text-xs shadow-md transition-all shrink-0 cursor-pointer"
        >
          <Play className="w-4 h-4 fill-slate-900" />
          <span>{isTestPending ? 'Ringing in 5s...' : 'Fire Test Alarm'}</span>
        </button>
      </div>

      {/* Android Permissions Dashboard Card */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-slate-900 dark:text-white" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Android System Permissions Dashboard
            </h3>
          </div>
          <span className="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950 px-2.5 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-800">
            Active
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Notification Permission */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-slate-900 dark:text-white">
                Full-Screen Notifications
              </div>
              <div className="text-[11px] text-slate-500">
                Status: {notificationStatus.toUpperCase()}
              </div>
            </div>

            {notificationStatus === 'granted' ? (
              <CheckCircle className="w-5 h-5 text-emerald-600" />
            ) : (
              <button
                onClick={handleRequestNotif}
                className="px-3 py-1.5 text-xs font-bold bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-xl cursor-pointer"
              >
                Grant
              </button>
            )}
          </div>

          {/* Exact Alarm Permission */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-slate-900 dark:text-white">
                AlarmManager Exact Alarms
              </div>
              <div className="text-[11px] text-slate-500">
                SCHEDULE_EXACT_ALARM Enabled
              </div>
            </div>
            <CheckCircle className="w-5 h-5 text-emerald-600" />
          </div>

          {/* ExoPlayer Background Media */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-slate-900 dark:text-white">
                Media3 Foreground Service
              </div>
              <div className="text-[11px] text-slate-500">
                Persistent URI Storage
              </div>
            </div>
            <CheckCircle className="w-5 h-5 text-emerald-600" />
          </div>

          {/* Wake Lock */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-slate-900 dark:text-white">
                Screen Wake Lock API
              </div>
              <div className="text-[11px] text-slate-500">
                Keeps screen active when ringing
              </div>
            </div>
            <CheckCircle className="w-5 h-5 text-emerald-600" />
          </div>
        </div>
      </div>

      {/* Defaults & Preference Toggles */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-3">
          Alarm Defaults & Theme
        </h3>

        {/* Default Volume */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-slate-800 dark:text-slate-200">
            <span>Default Alarm Volume</span>
            <span>{settings.defaultVolume}%</span>
          </div>
          <input
            type="range"
            min="10"
            max="100"
            value={settings.defaultVolume}
            onChange={(e) =>
              onUpdateSettings({ ...settings, defaultVolume: parseInt(e.target.value, 10) })
            }
            className="w-full accent-slate-900 dark:accent-white cursor-pointer"
          />
        </div>

        {/* Time Format Toggle */}
        <div className="flex items-center justify-between pt-2">
          <div>
            <span className="text-xs font-bold text-slate-900 dark:text-white block">
              Time Display Format
            </span>
            <span className="text-[11px] text-slate-500">
              Choose 12-hour (AM/PM) or 24-hour military format
            </span>
          </div>

          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
            <button
              onClick={() => onUpdateSettings({ ...settings, timeFormat: '12h' })}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                settings.timeFormat === '12h'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-500'
              }`}
            >
              12 Hour
            </button>
            <button
              onClick={() => onUpdateSettings({ ...settings, timeFormat: '24h' })}
              className={`px-3 py-1 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                settings.timeFormat === '24h'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-500'
              }`}
            >
              24 Hour
            </button>
          </div>
        </div>

        {/* Gradual Volume Toggle */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
          <div>
            <span className="text-xs font-bold text-slate-900 dark:text-white block">
              Default Gradual Volume
            </span>
            <span className="text-[11px] text-slate-500">
              New alarms start at 5% volume and ramp over 30s
            </span>
          </div>
          <input
            type="checkbox"
            checked={settings.gradualVolume}
            onChange={(e) => onUpdateSettings({ ...settings, gradualVolume: e.target.checked })}
            className="w-5 h-5 accent-slate-900 dark:accent-white rounded cursor-pointer"
          />
        </div>

        {/* Vibration Toggle */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
          <div>
            <span className="text-xs font-bold text-slate-900 dark:text-white block">
              Device Haptic Vibration
            </span>
            <span className="text-[11px] text-slate-500">
              Enable haptic motor vibration when ringing
            </span>
          </div>
          <input
            type="checkbox"
            checked={settings.vibration}
            onChange={(e) => onUpdateSettings({ ...settings, vibration: e.target.checked })}
            className="w-5 h-5 accent-slate-900 dark:accent-white rounded cursor-pointer"
          />
        </div>
      </div>

      {/* Import / Export Backup Data */}
      <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-3">
          Alarm Backup & Sync
        </h3>

        {importMessage && (
          <div className="p-3 text-xs font-semibold bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300 rounded-xl">
            {importMessage}
          </div>
        )}

        <div className="flex flex-col sm:flex-row items-center gap-3">
          <button
            onClick={handleExportJSON}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-white font-bold text-xs transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Export Backup (.JSON)</span>
          </button>

          <label className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-white font-bold text-xs transition-colors cursor-pointer">
            <Upload className="w-4 h-4" />
            <span>Import Backup</span>
            <input type="file" accept=".json" onChange={handleImportJSON} className="hidden" />
          </label>
        </div>
      </div>

      {/* About & Privacy */}
      <div className="p-5 rounded-3xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400 space-y-3">
        <div className="flex items-center gap-3">
          <img
            src="/assets/aistudio/file_00000000ef4c8211bafeca7fec614b22_95cdb1d5.png"
            alt="WakeUp Logo"
            className="w-10 h-10 rounded-xl shadow-xs border border-slate-200 dark:border-slate-800 object-cover"
          />
          <div>
            <div className="font-extrabold text-slate-900 dark:text-white text-sm">
              WakeUp – Video & Music Alarm Clock v2.4
            </div>
            <div className="text-[11px] text-slate-500 font-medium">
              Your mornings, your music.
            </div>
          </div>
        </div>
        <p>
          WakeUp is designed using MVVM + Clean Android Architecture principles with Room Database, AlarmManager exact scheduling, and Android Media3 ExoPlayer audio playback engine.
        </p>
        <p className="text-[11px] text-slate-500 pt-1 border-t border-slate-200 dark:border-slate-800">
          Privacy Guarantee: All video files, audio tracks, and alarm parameters are saved 100% locally on your device. No telemetry or external server tracking.
        </p>
      </div>
    </div>
  );
};
