import React, { useState } from 'react';
import {
  Settings,
  Shield,
  Trash2,
  Bell,
  Mic,
  Battery,
  Lock,
  Globe,
  CheckCircle,
  AlertTriangle,
  Smartphone,
  Download,
} from 'lucide-react';
import { SupportedLanguage } from '../types';

interface SettingsTabProps {
  language: SupportedLanguage;
  onLanguageChange: (lang: SupportedLanguage) => void;
  isForegroundActive: boolean;
  onToggleForeground: () => void;
  onOpenAPKModal?: () => void;
}

export const SettingsTab: React.FC<SettingsTabProps> = ({
  language,
  onLanguageChange,
  isForegroundActive,
  onToggleForeground,
  onOpenAPKModal,
}) => {
  const [micPermissionGranted, setMicPermissionGranted] = useState(true);
  const [smsConfirmationEnforced, setSmsConfirmationEnforced] = useState(true);
  const [dataWipedMessage, setDataWipedMessage] = useState(false);

  const handleWipeData = () => {
    if (confirm('Are you sure you want to wipe local memory, notes, and demo trade history?')) {
      localStorage.removeItem('dost_notes');
      localStorage.removeItem('dost_paper_trades');
      localStorage.removeItem('dost_demo_balance');
      setDataWipedMessage(true);
      setTimeout(() => setDataWipedMessage(false), 3000);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 overflow-y-auto p-4 space-y-4">
      <div>
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <Settings className="w-5 h-5 text-cyan-400" />
          <span>DOST AI Settings & Security</span>
        </h2>
        <p className="text-xs text-slate-400">
          Manage language, Android permissions, foreground service, and privacy.
        </p>
      </div>

      {/* LANGUAGE PREFERENCES */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
        <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
          <Globe className="w-4 h-4 text-cyan-400" />
          <span>Language & Dialect</span>
        </h3>

        <div className="grid grid-cols-3 gap-2 text-xs">
          <button
            onClick={() => onLanguageChange('roman_urdu')}
            className={`p-3 rounded-xl border text-center transition-all ${
              language === 'roman_urdu'
                ? 'border-cyan-500 bg-cyan-950/40 text-cyan-300 font-bold'
                : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-white'
            }`}
          >
            <span className="block text-sm mb-0.5">🇵🇰</span>
            <span>Roman Urdu</span>
          </button>

          <button
            onClick={() => onLanguageChange('urdu')}
            className={`p-3 rounded-xl border text-center transition-all ${
              language === 'urdu'
                ? 'border-cyan-500 bg-cyan-950/40 text-cyan-300 font-bold'
                : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-white'
            }`}
          >
            <span className="block text-sm mb-0.5">✍️</span>
            <span className="font-arabic">اردو (Urdu)</span>
          </button>

          <button
            onClick={() => onLanguageChange('english')}
            className={`p-3 rounded-xl border text-center transition-all ${
              language === 'english'
                ? 'border-cyan-500 bg-cyan-950/40 text-cyan-300 font-bold'
                : 'border-slate-800 bg-slate-950 text-slate-400 hover:text-white'
            }`}
          >
            <span className="block text-sm mb-0.5">🌐</span>
            <span>English</span>
          </button>
        </div>
      </div>

      {/* BACKGROUND AVAILABILITY & FOREGROUND SERVICE */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold text-slate-200">Foreground Service & Notification</h3>
          </div>
          <button
            onClick={onToggleForeground}
            className={`w-11 h-6 rounded-full transition-colors relative ${
              isForegroundActive ? 'bg-cyan-500' : 'bg-slate-800'
            }`}
          >
            <div
              className={`w-4 h-4 rounded-full bg-slate-950 transition-transform absolute top-1 ${
                isForegroundActive ? 'left-6' : 'left-1'
              }`}
            />
          </button>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed">
          In native Android, a foreground service displays a persistent notification with quick buttons (Talk, Crypto Scan) to prevent the OS from killing DOST AI during background sleep or low-memory conditions.
        </p>

        <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5 text-xs text-slate-300">
          <div className="flex items-center gap-1.5 text-cyan-400 font-semibold">
            <Battery className="w-3.5 h-3.5" />
            <span>Battery Optimization Bypass</span>
          </div>
          <p className="text-[11px] text-slate-400">
            Native Intent: <code className="text-slate-300">Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS</code> ensures DOST stays responsive on Samsung, Xiaomi, and OnePlus devices.
          </p>
        </div>
      </div>

      {/* SECURITY AUDIT & STRICT ALLOWLIST */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
        <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
          <Shield className="w-4 h-4 text-emerald-400" />
          <span>Security & Intent Allowlist Verification</span>
        </h3>

        <div className="space-y-2 text-xs">
          <div className="flex items-center justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>Strict Local Intent Allowlist</span>
            </div>
            <span className="text-[10px] text-emerald-400 font-mono font-bold">ENFORCED</span>
          </div>

          <div className="flex items-center justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>Sensitive Action User Confirmation (SMS/Calls)</span>
            </div>
            <span className="text-[10px] text-emerald-400 font-mono font-bold">REQUIRED</span>
          </div>

          <div className="flex items-center justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>No Stored Exchange API Keys or Passwords</span>
            </div>
            <span className="text-[10px] text-emerald-400 font-mono font-bold">ZERO CREDENTIALS</span>
          </div>

          <div className="flex items-center justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span>Accessibility Service Security Boundary</span>
            </div>
            <span className="text-[10px] text-emerald-400 font-mono font-bold">NO LOCKSCREEN BYPASS</span>
          </div>
        </div>
      </div>

      {/* MOBILE APP & APK INSTALLATION */}
      <div className="bg-slate-900 border border-cyan-500/30 rounded-2xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold text-slate-200">Mobile Installation & APK</h3>
          </div>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
            PWA & WebAPK
          </span>
        </div>
        <p className="text-xs text-slate-400">
          Install DOST AI directly on your Android device as a native WebAPK, download offline mobile launcher, or generate signed .apk via PWABuilder.
        </p>
        <button
          onClick={onOpenAPKModal}
          className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-400 hover:from-cyan-400 hover:to-emerald-300 text-slate-950 text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 transition-all"
        >
          <Download className="w-4 h-4" />
          <span>Open Mobile APK & Install Center</span>
        </button>
      </div>

      {/* PRIVACY & DATA WIPE */}
      <div className="bg-slate-900 border border-red-900/40 rounded-2xl p-4 space-y-3">
        <h3 className="text-sm font-semibold text-red-400 flex items-center gap-2">
          <Lock className="w-4 h-4" />
          <span>Privacy & Data Wipe</span>
        </h3>

        <p className="text-xs text-slate-400">
          DOST AI minimizes data collection. All notes, trade simulations, and local history are kept strictly on-device in local storage.
        </p>

        <button
          onClick={handleWipeData}
          className="w-full py-2.5 rounded-xl bg-red-950/60 hover:bg-red-900 text-red-300 border border-red-800 text-xs font-bold flex items-center justify-center gap-2 transition-colors"
        >
          <Trash2 className="w-4 h-4" />
          <span>Wipe All Local Data & History</span>
        </button>

        {dataWipedMessage && (
          <p className="text-xs text-emerald-400 text-center animate-in fade-in">
            Local memory and trade history wiped successfully.
          </p>
        )}
      </div>
    </div>
  );
};
