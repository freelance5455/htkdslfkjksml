"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { SURAHS, type SurahMeta } from "@/data/surahs";
import { toArabicDigits } from "@/lib/site";

/** Normalises Arabic text for search: strips diacritics and unifies letter forms. */
function normalize(text: string): string {
  return text
    .replace(/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640]/g, "")
    .replace(/[أإآٱ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه")
    .toLowerCase()
    .trim();
}

export function SurahSearch() {
  const [query, setQuery] = useState("");

  const results = useMemo(() => {
    const q = normalize(query);
    if (!q) return SURAHS;
    return SURAHS.filter((s) => {
      const numeric = /^\d+$/.test(q) ? Number(q) === s.number : false;
      return (
        numeric || normalize(s.name).includes(q) || s.english.toLowerCase().includes(q)
      );
    });
  }, [query]);

  return (
    <div>
      <label htmlFor="surah-search" className="sr-only">
        ابحث عن سورة
      </label>
      <div className="relative mx-auto mb-12 max-w-xl">
        <Search className="pointer-events-none absolute start-5 top-1/2 size-5 -translate-y-1/2 text-gold" aria-hidden="true" />
        <input
          id="surah-search"
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="ابحث باسم السورة أو رقمها… (مثال: الفاتحة، 36)"
          className="w-full rounded-full border border-border bg-card py-4 ps-14 pe-6 text-base text-navy shadow-[0_20px_40px_-30px_rgba(23,36,58,0.5)] placeholder:text-navy/40 focus:border-gold focus:ring-2 focus:ring-gold/30 focus:outline-none"
        />
      </div>

      {results.length === 0 ? (
        <p className="text-center text-navy/60">لا توجد سورة مطابقة لبحثك.</p>
      ) : (
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {results.map((s) => (
            <SurahCard key={s.number} surah={s} />
          ))}
        </ul>
      )}
    </div>
  );
}

function SurahCard({ surah }: { surah: SurahMeta }) {
  return (
    <li>
      <Link
        href={`/quran/${surah.number}`}
        className="group relative flex h-full items-center gap-5 overflow-hidden rounded-3xl border border-border bg-card p-6 shadow-[0_25px_50px_-40px_rgba(23,36,58,0.6)] transition-all duration-300 hover:-translate-y-1 hover:border-gold/60"
      >
        <span className="grid size-16 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-royal to-navy font-serif text-2xl font-bold text-gold-light shadow-inner">
          {toArabicDigits(surah.number)}
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate font-serif text-2xl font-bold text-navy">{`سورة ${surah.name}`}</span>
          <span className="mt-1 block text-sm text-navy/60">{surah.english}</span>
          <span className="mt-3 flex items-center gap-3 text-xs text-gold">
            <span>{toArabicDigits(surah.ayahs)} آية</span>
            <span className="size-1 rounded-full bg-gold/50" />
            <span>{surah.revelation === "M" ? "مكية" : "مدنية"}</span>
          </span>
        </span>
        <span className="font-serif text-lg text-gold opacity-0 transition-all group-hover:opacity-100" aria-hidden="true">
          ←
        </span>
      </Link>
    </li>
  );
}
