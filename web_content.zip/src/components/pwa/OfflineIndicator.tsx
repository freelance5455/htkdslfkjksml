import React from 'react';
import { useOnlineStatus } from '../../hooks/useOnlineStatus';
import { WifiOff, ShieldCheck } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed top-16 left-0 right-0 z-50 bg-gradient-to-r from-red-600 to-amber-600 text-slate-950 font-bold px-4 py-2 text-xs flex items-center justify-between shadow-lg shadow-black/50 animate-in slide-in-from-top duration-200">
      <div className="flex items-center gap-2 max-w-7xl mx-auto w-full">
        <WifiOff className="w-4 h-4 shrink-0 text-slate-950" />
        <span className="truncate">
          Modo Offline Activo — A abrir sem internet com dados guardados em cache local no seu dispositivo.
        </span>
      </div>
    </div>
  );
};
