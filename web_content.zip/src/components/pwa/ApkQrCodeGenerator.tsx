import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import { 
  QrCode, 
  Smartphone, 
  Download, 
  Copy, 
  Check, 
  Share2, 
  Sparkles, 
  ExternalLink, 
  RefreshCw, 
  ShieldCheck,
  Camera,
  Layers
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface ApkQrCodeGeneratorProps {
  apkUrl?: string;
  className?: string;
}

export const ApkQrCodeGenerator: React.FC<ApkQrCodeGeneratorProps> = ({
  apkUrl = '/downloads/Task-Earn-Pro-2.apk',
  className = '',
}) => {
  const [dataUrl, setDataUrl] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState<boolean>(true);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [qrTheme, setQrTheme] = useState<'classic' | 'emerald' | 'cyber'>('classic');
  const [targetType, setTargetType] = useState<'direct_apk' | 'download_page'>('direct_apk');

  // Compute full origin URLs
  const origin = typeof window !== 'undefined' ? window.location.origin : 'https://tsskpro.shop';
  const directApkFullUrl = `${origin}${apkUrl}`;
  const downloadPageFullUrl = `${origin}`;

  const currentScanUrl = targetType === 'direct_apk' ? directApkFullUrl : downloadPageFullUrl;

  const generateQRCode = async () => {
    setIsGenerating(true);
    try {
      let darkColor = '#090d16'; // Classic
      if (qrTheme === 'emerald') darkColor = '#064e3b';
      if (qrTheme === 'cyber') darkColor = '#1e1b4b';

      const url = await QRCode.toDataURL(currentScanUrl, {
        width: 400,
        margin: 2,
        color: {
          dark: darkColor,
          light: '#ffffff',
        },
        errorCorrectionLevel: 'H',
      });
      setDataUrl(url);
    } catch (err) {
      console.error('Failed to generate QR Code:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  useEffect(() => {
    generateQRCode();
  }, [currentScanUrl, qrTheme]);

  const handleCopy = () => {
    navigator.clipboard.writeText(currentScanUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleDownloadQrImage = () => {
    if (!dataUrl) return;
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = `Task-Earn-Pro-2-APK-QRCode-${targetType}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.7 },
    });
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Task Earn Pro 2 APK Download QR',
        text: 'Scan this QR code to download the official Task Earn Pro 2 Android APK!',
        url: currentScanUrl,
      }).catch(() => {});
    } else {
      handleCopy();
    }
  };

  return (
    <div className={`p-5 sm:p-6 rounded-3xl bg-[#10182b] border border-slate-800 text-white shadow-2xl relative overflow-hidden space-y-5 ${className}`}>
      
      {/* Decorative gradient glow */}
      <div className="absolute top-0 right-10 w-48 h-48 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-sky-500 to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-sky-500/20 shrink-0">
            <QrCode className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm sm:text-base font-black text-white">
                Scan QR to Download APK
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                Mobile Scanner Ready
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Point your smartphone camera to download instantly without typing URLs
            </p>
          </div>
        </div>

        {/* QR Target Switcher */}
        <div className="flex bg-slate-900/90 p-1 rounded-xl border border-slate-800 text-xs shrink-0 self-start sm:self-center">
          <button
            type="button"
            onClick={() => setTargetType('direct_apk')}
            className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
              targetType === 'direct_apk'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Direct APK (.apk)
          </button>
          <button
            type="button"
            onClick={() => setTargetType('download_page')}
            className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${
              targetType === 'download_page'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Web App Hub
          </button>
        </div>
      </div>

      {/* Main QR Display & Scanning Guide */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 items-center relative z-10">
        
        {/* QR Code Container */}
        <div className="flex flex-col items-center justify-center p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-3">
          
          <div className="relative p-3.5 bg-white rounded-2xl shadow-xl border-4 border-slate-200 flex items-center justify-center group">
            {isGenerating ? (
              <div className="w-52 h-52 flex flex-col items-center justify-center text-slate-400 gap-2">
                <RefreshCw className="w-6 h-6 animate-spin text-sky-500" />
                <span className="text-[11px] font-mono">Generating QR...</span>
              </div>
            ) : dataUrl ? (
              <div className="relative">
                <img
                  src={dataUrl}
                  alt="Task Earn Pro 2 APK Download QR Code"
                  className="w-52 h-52 object-contain rounded-lg"
                />
                
                {/* Center Badge Overlay */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="w-11 h-11 rounded-xl bg-slate-900 border-2 border-white shadow-lg flex items-center justify-center text-white text-lg">
                    📱
                  </div>
                </div>
              </div>
            ) : null}
          </div>

          {/* Theme Palette Buttons */}
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-400">
            <span>Color Style:</span>
            <button
              type="button"
              onClick={() => setQrTheme('classic')}
              className={`w-5 h-5 rounded-full bg-slate-900 border-2 transition-all cursor-pointer ${
                qrTheme === 'classic' ? 'border-sky-400 scale-110' : 'border-slate-700'
              }`}
              title="Classic Black"
            />
            <button
              type="button"
              onClick={() => setQrTheme('emerald')}
              className={`w-5 h-5 rounded-full bg-emerald-700 border-2 transition-all cursor-pointer ${
                qrTheme === 'emerald' ? 'border-emerald-400 scale-110' : 'border-slate-700'
              }`}
              title="Emerald Green"
            />
            <button
              type="button"
              onClick={() => setQrTheme('cyber')}
              className={`w-5 h-5 rounded-full bg-indigo-900 border-2 transition-all cursor-pointer ${
                qrTheme === 'cyber' ? 'border-indigo-400 scale-110' : 'border-slate-700'
              }`}
              title="Cyber Indigo"
            />
          </div>

          <div className="text-[10px] text-slate-400 font-mono text-center flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>High-density error correction (ECC Level H)</span>
          </div>
        </div>

        {/* Instructions & Actions */}
        <div className="space-y-3.5 text-xs text-slate-300">
          
          <div className="space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-sky-400 block">
              Quick Scan Instructions
            </span>
            <h4 className="font-bold text-white text-sm">
              How to scan and download with your phone:
            </h4>
          </div>

          <div className="space-y-2 text-[11px]">
            <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-900/80 border border-slate-800">
              <div className="w-5 h-5 rounded-lg bg-sky-500/20 text-sky-400 font-bold flex items-center justify-center shrink-0 mt-0.5">
                1
              </div>
              <p className="text-slate-300">
                Open your smartphone's built-in <strong>Camera app</strong> or Google Lens.
              </p>
            </div>

            <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-900/80 border border-slate-800">
              <div className="w-5 h-5 rounded-lg bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center shrink-0 mt-0.5">
                2
              </div>
              <p className="text-slate-300">
                Point the lens directly at the QR code. Tap the notification banner that appears.
              </p>
            </div>

            <div className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-900/80 border border-slate-800">
              <div className="w-5 h-5 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center shrink-0 mt-0.5">
                3
              </div>
              <p className="text-slate-300">
                Tap <strong>Download</strong> and open <code className="text-emerald-300 bg-slate-950 px-1 rounded">Task-Earn-Pro-2.apk</code> to install!
              </p>
            </div>
          </div>

          {/* Direct URL Preview */}
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1 text-[11px]">
            <span className="text-slate-400 text-[10px] block font-medium">Encoded URL in this QR:</span>
            <div className="font-mono text-emerald-400 truncate text-[10px] select-all bg-slate-900/60 p-1.5 rounded-lg border border-slate-800">
              {currentScanUrl}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-3 gap-2 pt-1">
            <button
              type="button"
              onClick={handleDownloadQrImage}
              className="py-2.5 px-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20 active:scale-95 transition-all cursor-pointer text-center"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Save PNG</span>
            </button>

            <button
              type="button"
              onClick={handleCopy}
              className="py-2.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] border border-slate-700 flex items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer text-center"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedLink ? 'Copied!' : 'Copy URL'}</span>
            </button>

            <button
              type="button"
              onClick={handleShare}
              className="py-2.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] border border-slate-700 flex items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer text-center"
            >
              <Share2 className="w-3.5 h-3.5 text-sky-400" />
              <span>Share</span>
            </button>
          </div>

        </div>

      </div>

    </div>
  );
};
