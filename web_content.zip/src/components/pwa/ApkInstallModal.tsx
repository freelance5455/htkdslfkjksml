import React, { useState } from 'react';
import { 
  X, 
  Smartphone, 
  ShieldCheck, 
  CheckCircle2, 
  Share2,
  Copy,
  Check,
  AlertCircle,
  HelpCircle,
  FileCheck2,
  HardDrive,
  Download,
  ExternalLink,
  Archive
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { useApp } from '../../context/AppContext';
import { AppShareModal } from './AppShareModal';

interface ApkInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkInstallModal: React.FC<ApkInstallModalProps> = ({ isOpen, onClose }) => {
  const { systemSettings } = useApp();
  const { isInstallable, isInstalled, install } = usePWAInstall();
  
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [installStatus, setInstallStatus] = useState<string | null>(null);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [activeGuideTab, setActiveGuideTab] = useState<'chrome' | 'samsung' | 'safari'>('chrome');

  if (!isOpen) return null;

  const currentUrl = typeof window !== 'undefined' ? window.location.origin : 'https://taskearn.pro';

  // Real APK Configuration Check (Only show actual metadata if a real APK URL is configured)
  const isApkEnabled = systemSettings?.enableApkDownload !== false;
  const rawApkUrl = systemSettings?.apkDownloadUrl?.trim() || '/downloads/Task-Earn-Pro-2.apk';
  const hasRealApk = Boolean(
    isApkEnabled &&
    rawApkUrl.length > 0 &&
    (rawApkUrl.startsWith('http://') || rawApkUrl.startsWith('https://') || rawApkUrl.startsWith('/downloads/')) &&
    !rawApkUrl.includes('placeholder') &&
    !rawApkUrl.includes('example.com')
  );

  const apkVersion = systemSettings?.apkVersion?.trim() || '2.0.0';
  const apkFileSize = systemSettings?.apkFileSizeMb?.trim() || '8.28 MB';
  const apkChecksum = (systemSettings as any)?.apkChecksum?.trim() || '';
  const apkReleaseNotes = systemSettings?.apkReleaseNotes?.trim() || 'Official release of Task Earn Pro 2 APK for Android devices with instant task sync.';

  const handleInstallPWA = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (accepted) {
        setInstallStatus('Installed successfully! You can find Task Earn Pro on your Android home screen and app launcher.');
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.65 }
        });
      }
    } else {
      setInstallStatus('Tap browser menu (⋮ on Chrome or Share on Safari) and select "Install App" or "Add to Home Screen".');
    }
  };

  const handleCopyAppUrl = () => {
    navigator.clipboard.writeText(currentUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2500);
  };

  const handleDownloadRealApk = () => {
    const downloadUrl = rawApkUrl || '/downloads/Task-Earn-Pro-2.apk';
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.setAttribute('download', 'Task-Earn-Pro-2.apk');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    confetti({
      particleCount: 75,
      spread: 60,
      origin: { y: 0.7 }
    });
  };

  const handleDownloadProjectZip = () => {
    const link = document.createElement('a');
    link.href = '/task-earn-pro-android-studio-project.zip';
    link.setAttribute('download', 'task-earn-pro-android-studio-project.zip');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
        <div 
          className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl relative max-h-[92vh] flex flex-col overflow-y-auto space-y-4 text-slate-100"
          role="dialog"
        >
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer z-10"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Header with App Icon */}
          <div className="flex items-center gap-3.5 pr-6">
            <img
              src="/pwa-192x192.png"
              alt="Task Earn Pro Logo"
              className="w-14 h-14 rounded-2xl object-cover border border-emerald-500/40 shadow-lg shadow-emerald-500/20 shrink-0"
            />
            <div className="space-y-0.5 min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  Android App & PWA
                </span>
                <span className="text-[10px] text-slate-400 font-mono">com.subhodip.taskearnpro</span>
              </div>
              <h2 className="text-base font-black text-white truncate">
                Task Earn Pro Installation
              </h2>
              <p className="text-[11px] text-slate-400">
                Official mobile app & installation center
              </p>
            </div>
          </div>

          {/* App Status & Quick Action Buttons */}
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={handleCopyAppUrl}
              className="py-2.5 px-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95"
            >
              {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
              <span>{copiedUrl ? 'Copied Link!' : 'Copy App Link'}</span>
            </button>

            <button
              type="button"
              onClick={() => setIsShareModalOpen(true)}
              className="py-2.5 px-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95"
            >
              <Share2 className="w-3.5 h-3.5 text-sky-400" />
              <span>Share App</span>
            </button>
          </div>

          {/* CONDITIONAL RENDER: Real APK vs "Not Built Yet" */}
          {hasRealApk ? (
            /* 1. REAL CONFIGURED APK AVAILABLE */
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Verified Signed Android APK</span>
                </span>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                  Ready
                </span>
              </div>

              <div className="space-y-3 pt-1">
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-2">
                    <FileCheck2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <div>
                      <span className="text-[10px] text-slate-400 block">APK Version</span>
                      <span className="font-bold text-slate-200 font-mono text-[11px]">{apkVersion || 'v2.4.0'}</span>
                    </div>
                  </div>

                  <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-2">
                    <HardDrive className="w-4 h-4 text-sky-400 shrink-0" />
                    <div>
                      <span className="text-[10px] text-slate-400 block">File Size</span>
                      <span className="font-bold text-slate-200 font-mono text-[11px]">{apkFileSize || '8.28 MB'}</span>
                    </div>
                  </div>
                </div>

                {apkChecksum && (
                  <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-[10px] font-mono text-slate-300 break-all">
                    <span className="text-slate-400 block text-[9px] mb-0.5">SHA-256 Checksum:</span>
                    {apkChecksum}
                  </div>
                )}

                {apkReleaseNotes && (
                  <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800/80 text-[11px] space-y-1">
                    <span className="font-bold text-slate-300 block">Release Notes:</span>
                    <p className="text-slate-400 leading-relaxed text-[11px]">
                      {apkReleaseNotes}
                    </p>
                  </div>
                )}

                <button
                  type="button"
                  onClick={handleDownloadRealApk}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-600 hover:opacity-95 text-white font-black text-xs shadow-md shadow-emerald-600/25 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download APK Binary ({apkFileSize || '8.28 MB'})</span>
                </button>

                <a
                  href="/downloads/TaskEarnPro.zip"
                  download="TaskEarnPro-App.zip"
                  className="w-full py-2.5 rounded-xl bg-slate-900 border border-blue-500/40 hover:border-blue-400/70 text-blue-300 font-bold text-xs active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Archive className="w-4 h-4 text-blue-400" />
                  <span>Download Complete App ZIP (50 MB)</span>
                </a>

                {/* 'App not installed' Troubleshooting Callout */}
                <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-[10px] space-y-1">
                  <div className="font-bold flex items-center gap-1 text-amber-300">
                    <span>⚠️</span>
                    <span>"App not installed" আসলে সমাধান:</span>
                  </div>
                  <p className="text-slate-300 leading-relaxed">
                    ১. ফোনে আগে "Task WebView Test" থাকলে Settings &gt; Apps থেকে সেটি <strong>Uninstall</strong> করে নিন।<br />
                    ২. অথবা Chrome-এর উপরে (⋮) মেনু থেকে <strong>"Install app"</strong> বাটনে ক্লিক করে সরাসরি হোমস্ক্রিনে অ্যাপ ইনস্টল করে নিন।
                  </p>
                </div>
              </div>
            </div>
          ) : (
            /* 2. NOT BUILT YET (NO FAKE APK CLAIMS) */
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                  <span>Android APK Build Status</span>
                </span>
                <span className="text-[10px] font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">
                  Not Built Yet
                </span>
              </div>

              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs space-y-1.5">
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  Production APK has not been generated yet. This web environment cannot compile and sign the Android APK.
                </p>
              </div>

              {/* Two Options */}
              <div className="space-y-2.5 pt-1">
                {/* Option 1: Install as PWA */}
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                      <Smartphone className="w-3.5 h-3.5 text-sky-400" />
                      <span>1. Install as PWA (WebAPK)</span>
                    </span>
                    <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded font-bold">
                      Instant
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Instantly installs Task Earn Pro with a home screen app icon and offline support.
                  </p>
                  {isInstalled ? (
                    <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-300 text-xs font-bold text-center flex items-center justify-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>App Installed on Device!</span>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={handleInstallPWA}
                      className="w-full py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs transition-all cursor-pointer shadow-sm"
                    >
                      Install App to Home Screen
                    </button>
                  )}
                </div>

                {/* Option 2: Build Real APK */}
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                      <ExternalLink className="w-3.5 h-3.5 text-emerald-400" />
                      <span>2. Build Real APK</span>
                    </span>
                    <span className="text-[10px] text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded font-bold">
                      Android Studio
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Export the Android project, open it in Android Studio, then generate a signed release APK.
                  </p>
                  <button
                    type="button"
                    onClick={handleDownloadProjectZip}
                    className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold text-xs transition-all cursor-pointer border border-slate-700 flex items-center justify-center gap-2"
                  >
                    <span>Build APK in Android Studio</span>
                  </button>
                </div>
              </div>

              {installStatus && (
                <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs text-center font-medium">
                  {installStatus}
                </div>
              )}
            </div>
          )}

          {/* Professional Installation Guide for Android */}
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2.5 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-300 flex items-center gap-1.5">
                <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
                <span>Step-by-Step Android Installation Guide</span>
              </span>
            </div>

            {/* Guide Tabs */}
            <div className="flex gap-1 bg-slate-900 p-1 rounded-xl">
              <button
                type="button"
                onClick={() => setActiveGuideTab('chrome')}
                className={`flex-1 py-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                  activeGuideTab === 'chrome'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Chrome
              </button>
              <button
                type="button"
                onClick={() => setActiveGuideTab('samsung')}
                className={`flex-1 py-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                  activeGuideTab === 'samsung'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Samsung
              </button>
              <button
                type="button"
                onClick={() => setActiveGuideTab('safari')}
                className={`flex-1 py-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                  activeGuideTab === 'safari'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                iOS / Safari
              </button>
            </div>

            {/* Guide Details */}
            {activeGuideTab === 'chrome' && (
              <div className="space-y-1.5 text-[11px] text-slate-400 leading-relaxed">
                <p>1. Tap the three dots (⋮) in the top-right corner of Google Chrome.</p>
                <p>2. Tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</p>
                <p>3. Confirm <strong>"Install"</strong> when prompted. The official icon will appear on your phone!</p>
              </div>
            )}

            {activeGuideTab === 'samsung' && (
              <div className="space-y-1.5 text-[11px] text-slate-400 leading-relaxed">
                <p>1. In Samsung Internet, tap the menu (☰) at the bottom right.</p>
                <p>2. Tap <strong>"Add page to"</strong> &rarr; <strong>"Home screen"</strong>.</p>
                <p>3. Tap <strong>"Install"</strong> to add the standalone application.</p>
              </div>
            )}

            {activeGuideTab === 'safari' && (
              <div className="space-y-1.5 text-[11px] text-slate-400 leading-relaxed">
                <p>1. Tap the <strong>Share</strong> button (box with upward arrow) at the bottom.</p>
                <p>2. Scroll down and tap <strong>"Add to Home Screen"</strong>.</p>
                <p>3. Tap <strong>"Add"</strong> in the top right. Task Earn Pro is ready!</p>
              </div>
            )}
          </div>

          {/* Security & Verification Guarantee */}
          <div className="p-3 rounded-2xl bg-emerald-950/20 border border-emerald-900/40 text-[11px] text-emerald-400/90 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>Zero malware, secure official web and mobile architecture.</span>
          </div>

        </div>
      </div>

      {/* Share Modal */}
      {isShareModalOpen && (
        <AppShareModal
          isOpen={isShareModalOpen}
          onClose={() => setIsShareModalOpen(false)}
        />
      )}
    </>
  );
};
