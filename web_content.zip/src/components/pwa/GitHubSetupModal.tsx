import React, { useState } from 'react';
import {
  X,
  Github,
  AlertTriangle,
  CheckCircle2,
  ExternalLink,
  Download,
  Copy,
  Check,
  Play,
  Terminal,
  Share2,
  MessageSquare,
  Sparkles,
  HelpCircle,
  FileCode2
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface GitHubSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  directApkUrl: string;
}

export const GitHubSetupModal: React.FC<GitHubSetupModalProps> = ({
  isOpen,
  onClose,
  directApkUrl,
}) => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'quick' | 'git' | 'direct'>('quick');

  if (!isOpen) return null;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(id);
    setTimeout(() => setCopiedCode(null), 2500);
  };

  const createRepoUrl =
    'https://github.com/new?name=TaskEarnPro&description=TaskEarnPro+Official+Android+App+Build';
  const actionsUrl = 'https://github.com/subhodipgarai7654-collab/TaskEarnPro/actions';
  const repoUrl = 'https://github.com/subhodipgarai7654-collab/TaskEarnPro';
  const sourceZipUrl = '/downloads/TaskEarnPro-source.zip';

  const gitCommands = `git remote add origin https://github.com/subhodipgarai7654-collab/TaskEarnPro.git\ngit branch -M main\ngit push -u origin main`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl max-w-xl w-full p-5 sm:p-6 shadow-2xl relative space-y-5 my-auto max-h-[92vh] overflow-y-auto">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-start gap-3.5 pr-8">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shrink-0">
            <Github className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-lg sm:text-xl font-black text-white">
                GitHub 404 Problem সমাধান ও Flowrun গাইড
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                Fix 404 Error
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 font-mono">
              subhodipgarai7654-collab / <span className="text-sky-400 font-bold">TaskEarnPro</span>
            </p>
          </div>
        </div>

        {/* 404 Problem Explanation Box */}
        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/25 space-y-2 text-xs">
          <div className="flex items-center gap-2 font-bold text-amber-300">
            <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
            <span>কেন GitHub লিংকে 404 Error আসছে?</span>
          </div>
          <p className="text-slate-300 leading-relaxed text-[11px] sm:text-xs">
            GitHub-এ আপনার প্রোফাইল <strong>subhodipgarai7654-collab</strong>-এ এখনও <strong>TaskEarnPro</strong> নামের Repository-টি Create (তৈরি) করা হয়নি। GitHub-এ রিপোজিটরি তৈরি না থাকলে <code className="bg-slate-900 px-1 py-0.5 rounded text-amber-300 font-mono">/actions</code> বা <code className="bg-slate-900 px-1 py-0.5 rounded text-amber-300 font-mono">/releases</code> লিংকে গেলে <strong>404 Problem (Page not found)</strong> আসে।
          </p>
        </div>

        {/* Direct Solution Highlight */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/60 to-teal-950/60 border border-emerald-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="space-y-0.5">
            <span className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>সহজ সমাধান: GitHub ছাড়াই APK ডাউনলোড করুন!</span>
            </span>
            <span className="text-[11px] text-slate-300 block">
              ভেরিফায়েড APK ইতিমধ্যে তৈরি আছে। আপনি ও আপনার বন্ধুরা এখনই সরাসরি ডাউনলোড করতে পারেন।
            </span>
          </div>
          <a
            href={directApkUrl}
            download="Task-Earn-Pro-v2.5.0.apk"
            onClick={() => confetti({ particleCount: 50, spread: 60 })}
            className="w-full sm:w-auto px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center justify-center gap-2 transition-all shrink-0 shadow-lg shadow-emerald-500/20"
          >
            <Download className="w-3.5 h-3.5" />
            <span>সরাসরি APK ডাউনলোড</span>
          </a>
        </div>

        {/* Tab Selector */}
        <div className="flex rounded-xl bg-slate-950 p-1 border border-slate-800 text-xs font-bold">
          <button
            type="button"
            onClick={() => setActiveTab('quick')}
            className={`flex-1 py-2 px-3 rounded-lg transition-all text-center cursor-pointer ${
              activeTab === 'quick'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            ১. GitHub Repo তৈরি (30 সেকেন্ড)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('git')}
            className={`flex-1 py-2 px-3 rounded-lg transition-all text-center cursor-pointer ${
              activeTab === 'git'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            ২. Flowrun CI/CD কমান্ড
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('direct')}
            className={`flex-1 py-2 px-3 rounded-lg transition-all text-center cursor-pointer ${
              activeTab === 'direct'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            ৩. বন্ধুদের সাথে শেয়ার
          </button>
        </div>

        {/* Tab Content: Quick 1-Click Create Repo */}
        {activeTab === 'quick' && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div className="space-y-3 text-xs text-slate-300">
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                <span className="w-5 h-5 rounded-full bg-sky-500/20 text-sky-400 font-bold flex items-center justify-center shrink-0 text-xs">
                  1
                </span>
                <div className="space-y-1">
                  <span className="font-bold text-white block">
                    GitHub-এ TaskEarnPro রিপোজিটরি তৈরি করুন:
                  </span>
                  <p className="text-[11px] text-slate-400">
                    নিচের বাটনে ক্লিক করলে রিপোজিটরির নাম <code className="text-sky-300">TaskEarnPro</code> দিয়ে অটোমেটিক পেজ খুলে যাবে। শুধু সবুজ <strong>"Create repository"</strong> বাটনে ক্লিক করুন।
                  </p>
                  <a
                    href={createRepoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs mt-1 transition-all shadow-md"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>১-ক্লিকে GitHub Repo খুলুন (Create Repo)</span>
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center shrink-0 text-xs">
                  2
                </span>
                <div className="space-y-1">
                  <span className="font-bold text-white block">
                    প্রজেক্ট কোডের সম্পূর্ণ ZIP ফাইল ডাউনলোড করুন:
                  </span>
                  <p className="text-[11px] text-slate-400">
                    এই ZIP ফাইলের মধ্যে সব কোড এবং <code className="text-amber-300 font-mono">.github/workflows/build-apk.yml</code> ফাইল অন্তর্ভুক্ত আছে।
                  </p>
                  <a
                    href={sourceZipUrl}
                    download="TaskEarnPro-source.zip"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs mt-1 transition-all border border-slate-700"
                  >
                    <FileCode2 className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Download TaskEarnPro-source.zip (5.1 MB)</span>
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-950/70 border border-slate-800">
                <span className="w-5 h-5 rounded-full bg-teal-500/20 text-teal-400 font-bold flex items-center justify-center shrink-0 text-xs">
                  3
                </span>
                <div className="space-y-1">
                  <span className="font-bold text-white block">
                    GitHub Actions (Flowrun) স্বয়ংক্রিয়ভাবে চালু হবে:
                  </span>
                  <p className="text-[11px] text-slate-400">
                    রিপোজিটরি তৈরি করার পর আর কোনো 404 দেখাবে না। Actions ট্যাবে Flowrun রান করলে সম্পূর্ণ নতুন APK বিল্ড হয়ে যাবে।
                  </p>
                  <a
                    href={actionsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-900/60 hover:bg-teal-800 text-teal-300 font-bold text-xs mt-1 transition-all border border-teal-700/60"
                  >
                    <Play className="w-3 h-3 fill-current text-teal-400" />
                    <span>View Actions (Flowrun)</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab Content: Git Push & Flowrun Commands */}
        {activeTab === 'git' && (
          <div className="space-y-3 animate-in fade-in duration-150">
            <p className="text-xs text-slate-300">
              আপনি যদি Git Bash, Terminal বা VS Code দিয়ে সরাসরি কোড পুশ করতে চান, নিচের কমান্ডগুলি কপি করে রান করুন:
            </p>

            <div className="relative rounded-2xl bg-slate-950 p-4 border border-slate-800 font-mono text-xs text-emerald-400 space-y-1 select-all">
              <button
                type="button"
                onClick={() => handleCopy(gitCommands, 'git-cmds')}
                className="absolute top-2.5 right-2.5 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-sans font-bold flex items-center gap-1 transition-all border border-slate-700 cursor-pointer"
              >
                {copiedCode === 'git-cmds' ? (
                  <Check className="w-3 h-3 text-emerald-400" />
                ) : (
                  <Copy className="w-3 h-3" />
                )}
                <span>{copiedCode === 'git-cmds' ? 'Copied!' : 'Copy Commands'}</span>
              </button>

              <p className="text-slate-500"># 1. Connect remote to subhodipgarai7654-collab</p>
              <p>git remote add origin https://github.com/subhodipgarai7654-collab/TaskEarnPro.git</p>
              <p className="text-slate-500 pt-1"># 2. Set default branch to main</p>
              <p>git branch -M main</p>
              <p className="text-slate-500 pt-1"># 3. Push and trigger CI/CD Flowrun</p>
              <p>git push -u origin main</p>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-[11px] text-slate-400 space-y-1">
              <span className="font-bold text-slate-200 block">💡 Flowrun অটোমেশন:</span>
              <p>
                কোড পুশ হওয়ার সাথে সাথে GitHub Actions-এ <code className="text-amber-300 font-mono">.github/workflows/build-apk.yml</code> অ্যাকশন সক্রিয় হবে এবং অটোমেটিক APK তৈরি করে Releases-এ যুক্ত করবে।
              </p>
            </div>
          </div>
        )}

        {/* Tab Content: Direct Share with Friends */}
        {activeTab === 'direct' && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div className="p-3.5 rounded-2xl bg-indigo-950/40 border border-indigo-800/40 text-xs space-y-2">
              <span className="font-bold text-white block">
                বন্ধুদের সাথে APK শেয়ার করার সবচেয়ে দ্রুত উপায়:
              </span>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                আপনার বন্ধুদের কোনো GitHub অ্যাকাউন্টের দরকার নেই। নিচের বাটনে ক্লিক করে WhatsApp বা Telegram-এ এক ক্লিকে শেয়ার করে দিন, তারা সরাসরি লিংকে ক্লিক করে ফোনে APK ইনস্টল করে নিতে পারবে!
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <a
                href={`https://api.whatsapp.com/send?text=${encodeURIComponent(
                  `Task Earn Pro Official Android APK ডাউনলোড করুন এবং প্রতিদিন রিয়েল কয়েন আয় করুন: ${directApkUrl}`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md"
              >
                <MessageSquare className="w-4 h-4" />
                <span>WhatsApp-এ বন্ধুদের পাঠান</span>
              </a>

              <a
                href={`https://t.me/share/url?url=${encodeURIComponent(
                  directApkUrl
                )}&text=${encodeURIComponent(
                  'Task Earn Pro Official Android App APK Download'
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md"
              >
                <Share2 className="w-4 h-4" />
                <span>Telegram-এ বন্ধুদের পাঠান</span>
              </a>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2 text-xs">
              <div className="min-w-0">
                <span className="text-[10px] text-slate-400 block font-medium">ডাউনলোড লিংক কপি করুন:</span>
                <span className="font-mono text-emerald-400 text-[11px] truncate block select-all">
                  {directApkUrl}
                </span>
              </div>
              <button
                type="button"
                onClick={() => handleCopy(directApkUrl, 'direct-url')}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1 transition-all border border-slate-700 shrink-0 cursor-pointer"
              >
                {copiedCode === 'direct-url' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-amber-400" />}
                <span>{copiedCode === 'direct-url' ? 'Copied!' : 'Copy'}</span>
              </button>
            </div>
          </div>
        )}

        {/* Modal Footer */}
        <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between gap-3 text-xs">
          <span className="text-slate-400 text-[11px]">
            APK Version: <strong>v2.5.0</strong> (Android 5.0 - 16)
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-colors cursor-pointer"
          >
            বন্ধ করুন (Close)
          </button>
        </div>
      </div>
    </div>
  );
};
