import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Smartphone, 
  Download, 
  CheckCircle2, 
  ShieldCheck, 
  Copy, 
  Check, 
  Share2, 
  FileCheck2, 
  HardDrive, 
  AlertCircle, 
  ExternalLink,
  Sparkles,
  Zap,
  Info,
  Link2,
  Github,
  Play,
  MessageSquare,
  Send,
  AlertTriangle,
  HelpCircle,
  FileCode2,
  Wrench
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { ApkDownloadSection } from './ApkDownloadSection';
import { ApkQrCodeGenerator } from './ApkQrCodeGenerator';
import { GitHubSetupModal } from './GitHubSetupModal';

interface DownloadAppViewProps {
  onBackToDashboard: () => void;
}

export const DownloadAppView: React.FC<DownloadAppViewProps> = ({ onBackToDashboard }) => {
  const { systemSettings } = useApp();
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [copiedLink, setCopiedLink] = useState(false);
  const [showCopiedToast, setShowCopiedToast] = useState(false);
  const [copiedSha, setCopiedSha] = useState(false);
  const [pwaStatus, setPwaStatus] = useState<string | null>(null);
  const [showGitHubModal, setShowGitHubModal] = useState(false);

  const apkUrl = systemSettings.apkDownloadUrl || '/downloads/Task-Earn-Pro-v2.5.0.apk';
  const fullApkUrl = typeof window !== 'undefined' 
    ? `${window.location.origin}${apkUrl}` 
    : `https://tsskpro.shop${apkUrl}`;

  const sha256Checksum = 'e527a6dd64b021a8ffcfb5b99bcf7af20c2d39292fbdb8097cf5ecff9a3af586';

  const handleCopyApkUrl = () => {
    navigator.clipboard.writeText(fullApkUrl);
    setCopiedLink(true);
    setShowCopiedToast(true);
    confetti({
      particleCount: 35,
      spread: 60,
      origin: { y: 0.8 },
    });
    setTimeout(() => setCopiedLink(false), 2500);
    setTimeout(() => setShowCopiedToast(false), 3000);
  };

  const handleCopySha = () => {
    navigator.clipboard.writeText(sha256Checksum);
    setCopiedSha(true);
    setTimeout(() => setCopiedSha(false), 2500);
  };

  const handleInstallPWA = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (accepted) {
        setPwaStatus('Installed! Task Earn Pro 2 is now on your home screen.');
        confetti({ particleCount: 70, spread: 60 });
      }
    } else {
      setPwaStatus('Tap your browser menu (⋮ on Chrome) and select "Install App" or "Add to Home screen".');
    }
  };

  const handleNativeShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Task Earn Pro 2 - Official Android App',
        text: 'Download Task Earn Pro 2 Android APK and start earning real coins daily!',
        url: fullApkUrl,
      }).catch(() => {});
    } else {
      handleCopyApkUrl();
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-20 animate-in fade-in duration-200">
      
      {/* Top Header & Breadcrumbs */}
      <div className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={onBackToDashboard}
          className="py-2 px-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition-colors flex items-center gap-2 text-xs font-bold cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 text-emerald-400" />
          <span>Back to Dashboard</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>Official APK v2.0.0</span>
          </span>
        </div>
      </div>

      {/* Main Banner Heading */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl flex items-center justify-between gap-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-sky-500 to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-sky-500/20">
              <Smartphone className="w-5 h-5" />
            </div>
            <h1 className="text-base sm:text-lg font-black text-white">
              Official Android APK Center
            </h1>
          </div>
          <p className="text-xs text-slate-400">
            Download and install Task Earn Pro 2 directly on any Android smartphone or tablet
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleCopyApkUrl}
            className={`py-2 px-3 rounded-2xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-md ${
              copiedLink
                ? 'bg-emerald-600 text-white shadow-emerald-600/30 scale-105'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
            }`}
          >
            {copiedLink ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4 text-amber-400" />}
            <span>{copiedLink ? 'Copied!' : 'Copy Link'}</span>
          </button>

          <button
            type="button"
            onClick={handleNativeShare}
            className="p-2.5 rounded-2xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white border border-slate-700 transition-colors cursor-pointer shrink-0"
            title="Share Download Link"
          >
            <Share2 className="w-4 h-4 text-sky-400" />
          </button>
        </div>
      </div>

      {/* Prominent Quick Direct Link Copy Bar */}
      <div className="p-3.5 sm:p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center shrink-0">
            <Link2 className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-white block">Direct APK Download Link</span>
              <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                Official
              </span>
            </div>
            <span className="text-[11px] font-mono text-slate-400 truncate block select-all">
              {fullApkUrl}
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={handleCopyApkUrl}
          className={`py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0 shadow-md ${
            copiedLink
              ? 'bg-emerald-600 text-white shadow-emerald-600/30 scale-[1.02]'
              : 'bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white shadow-sky-600/20 active:scale-95'
          }`}
        >
          {copiedLink ? <Check className="w-4 h-4 text-white" /> : <Copy className="w-4 h-4" />}
          <span>{copiedLink ? 'Copied to Clipboard!' : 'Copy Link'}</span>
        </button>
      </div>

      {/* GitHub Connected Repository & Automated Flowrun CI/CD Card for subhodipgarai7654-collab */}
      <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950/50 to-slate-900 border border-indigo-500/40 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-slate-800 border border-slate-700 flex items-center justify-center text-white shrink-0 shadow-md">
              <Github className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-white text-sm">GitHub Connected Repository</h3>
                <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  Active Origin
                </span>
              </div>
              <p className="text-xs text-slate-300 font-mono">
                subhodipgarai7654-collab / <span className="text-sky-400 font-bold">TaskEarnPro</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <a
              href="https://github.com/subhodipgarai7654-collab/TaskEarnPro"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-colors border border-slate-700 shadow-sm"
            >
              <span>Open Repo</span>
              <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
            </a>

            <button
              type="button"
              onClick={() => setShowGitHubModal(true)}
              className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-bold flex items-center gap-1.5 transition-colors border border-amber-500/40 cursor-pointer shadow-sm"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              <span>404 Fix & Guide</span>
            </button>

            <a
              href="https://github.com/new?name=TaskEarnPro&description=TaskEarnPro+Official+Android+App+Build"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>1-Click Create Repo</span>
            </a>

            <a
              href="https://github.com/subhodipgarai7654-collab/TaskEarnPro/actions"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-xl bg-teal-900/60 hover:bg-teal-800 text-teal-300 text-xs font-bold flex items-center gap-1.5 transition-colors border border-teal-700/60"
            >
              <Play className="w-3 h-3 fill-current text-teal-400" />
              <span>Actions (Flowrun)</span>
            </a>

            <a
              href="/downloads/TaskEarnPro-source.zip"
              download="TaskEarnPro-source.zip"
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition-all border border-slate-700"
            >
              <FileCode2 className="w-3.5 h-3.5 text-indigo-400" />
              <span>Source ZIP (5.1MB)</span>
            </a>
          </div>
        </div>

        {/* 404 Problem Resolution Banner */}
        <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/25 text-xs text-slate-300 space-y-2">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <span className="font-bold text-amber-300 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
              <span>GitHub লিংকে 404 Problem সমাধান (Why 404 Happens):</span>
            </span>
            <button
              type="button"
              onClick={() => setShowGitHubModal(true)}
              className="text-[11px] font-bold text-sky-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>সম্পূর্ণ সমাধান গাইড দেখুন →</span>
            </button>
          </div>
          <p className="text-[11px] text-slate-300 leading-relaxed">
            GitHub-এ আপনার ইউজারনেম <strong className="text-white">subhodipgarai7654-collab</strong>-এর অধীনে <strong className="text-sky-300">TaskEarnPro</strong> নামের Repository-টি এখনও Create করা হয়নি। তাই Actions বা Releases লিংকে গেলে 404 দেখায়। সমাধান করতে উপরের <strong className="text-white">"1-Click Create Repo"</strong> বাটনে ক্লিক করে রিপোজিটরিটি তৈরি করে নিন।
          </p>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800/90 text-[11px] text-slate-300 space-y-2">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <p className="font-semibold text-emerald-400 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>Connected Origin:</span>
              <span className="font-mono text-slate-200">https://github.com/subhodipgarai7654-collab/TaskEarnPro.git</span>
            </p>
            <span className="px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-300 text-[10px] font-bold">
              ⚡ Flowrun CI/CD Ready
            </span>
          </div>

          <p className="text-slate-400 leading-relaxed">
            GitHub Actions Workflow ফাইল <code className="text-amber-300 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">.github/workflows/build-apk.yml</code> কনফিগার করা রয়েছে। কোড পুশ হলে অথবা Actions ট্যাবে <strong>Flowrun (Run workflow)</strong> দিলে স্বয়ংক্রিয়ভাবে Android APK বিল্ড হয়ে যাবে এবং আপনি ও আপনার বন্ধুরা সরাসরি ডাউনলোড করতে পারবেন।
          </p>
        </div>

        {/* Share APK with Friends Bar */}
        <div className="p-3 rounded-2xl bg-indigo-950/40 border border-indigo-800/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5 text-xs">
          <div>
            <span className="font-bold text-white block">বন্ধুদের সাথে APK শেয়ার করুন (Share APK with Friends):</span>
            <span className="text-[11px] text-indigo-300">যেকোনো বন্ধু এই লিংকে ক্লিক করে ফোনে সরাসরি APK ডাউনলোড ও ইনস্টল করতে পারবে।</span>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <a
              href={`https://api.whatsapp.com/send?text=${encodeURIComponent(`Task Earn Pro 2 Official Android App APK ডাউনলোড করুন এবং প্রতিদিন রিয়েল কয়েন আয় করুন: ${fullApkUrl}`)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold flex items-center gap-1.5 transition-all shadow-xs"
            >
              <MessageSquare className="w-3 h-3" />
              <span>WhatsApp</span>
            </a>

            <a
              href={`https://t.me/share/url?url=${encodeURIComponent(fullApkUrl)}&text=${encodeURIComponent('Task Earn Pro 2 Official Android APK Download')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-[11px] font-bold flex items-center gap-1.5 transition-all shadow-xs"
            >
              <Send className="w-3 h-3" />
              <span>Telegram</span>
            </a>

            <button
              type="button"
              onClick={handleCopyApkUrl}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-bold flex items-center gap-1.5 border border-slate-700 transition-all cursor-pointer"
            >
              <Copy className="w-3 h-3 text-amber-400" />
              <span>Copy Link</span>
            </button>
          </div>
        </div>
      </div>

      {/* Primary APK Download Card (Exact User Spec) */}
      <ApkDownloadSection />

      {/* QR Code Generator for Direct Mobile Scanning */}
      <ApkQrCodeGenerator apkUrl={apkUrl} />

      {/* Technical Specifications & Binary Metadata */}
      <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-md space-y-4 text-xs">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <h3 className="font-bold text-white flex items-center gap-2 text-xs sm:text-sm">
            <FileCheck2 className="w-4 h-4 text-emerald-400" />
            <span>Package Specifications & Security</span>
          </h3>
          <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
            ✓ VirusTotal Clean
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-[10px] text-slate-400 block font-medium">App Name</span>
            <span className="font-bold text-white block truncate">Task Earn Pro 2</span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-[10px] text-slate-400 block font-medium">Version</span>
            <span className="font-bold text-emerald-400 block font-mono">2.4.0 (Build 24)</span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-[10px] text-slate-400 block font-medium">Binary Size</span>
            <span className="font-bold text-sky-400 block font-mono">220 MB</span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-[10px] text-slate-400 block font-medium">Min Android</span>
            <span className="font-bold text-amber-400 block">5.0 (API 21)+</span>
          </div>
        </div>

        {/* Checksum Row */}
        <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-slate-400 font-medium">SHA-256 Checksum:</span>
            <button
              type="button"
              onClick={handleCopySha}
              className="text-slate-400 hover:text-white flex items-center gap-1 font-bold text-[10px] transition-colors cursor-pointer"
            >
              {copiedSha ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copiedSha ? 'Copied' : 'Copy Checksum'}</span>
            </button>
          </div>
          <div className="font-mono text-[10px] text-slate-300 break-all bg-slate-900/60 p-2 rounded-xl border border-slate-800">
            {sha256Checksum}
          </div>
        </div>

        {/* Direct Link Box */}
        <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
          <div className="min-w-0">
            <span className="text-[10px] text-slate-400 block font-medium">Direct APK File URL</span>
            <span className="font-mono text-[11px] text-slate-200 block truncate">
              {fullApkUrl}
            </span>
          </div>
          <button
            type="button"
            onClick={handleCopyApkUrl}
            className="py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1 shrink-0 transition-colors cursor-pointer border border-slate-700"
          >
            {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedLink ? 'Copied!' : 'Copy Link'}</span>
          </button>
        </div>
      </div>

      {/* Step-by-Step Installation Visual Guide */}
      <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-md space-y-4">
        <h3 className="font-bold text-white text-xs sm:text-sm flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>How to Install on Android (3 Simple Steps)</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          {/* Step 1 */}
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="w-7 h-7 rounded-xl bg-sky-500/20 text-sky-400 font-black text-xs flex items-center justify-center">
              1
            </div>
            <h4 className="font-bold text-white text-xs">Download File</h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Tap <strong>Download APK</strong>. The file <code className="text-sky-300">Task-Earn-Pro-2.apk</code> will save directly to your phone.
            </p>
          </div>

          {/* Step 2 */}
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="w-7 h-7 rounded-xl bg-amber-500/20 text-amber-400 font-black text-xs flex items-center justify-center">
              2
            </div>
            <h4 className="font-bold text-white text-xs">Allow Unknown Source</h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Open the downloaded file. When prompted by Android security, tap <strong>Settings</strong> and switch on <em>"Allow from this source"</em>.
            </p>
          </div>

          {/* Step 3 */}
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="w-7 h-7 rounded-xl bg-emerald-500/20 text-emerald-400 font-black text-xs flex items-center justify-center">
              3
            </div>
            <h4 className="font-bold text-white text-xs">Install & Earn</h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Tap <strong>Install</strong>. Launch Task Earn Pro 2 from your app drawer, claim your daily streak, and withdraw real money!
            </p>
          </div>
        </div>

        {/* Troubleshooting Callout for 'App not installed' */}
        <div className="p-3.5 rounded-2xl bg-amber-950/60 border border-amber-500/40 text-amber-200 text-xs space-y-2">
          <div className="flex items-center gap-2">
            <span className="w-5 h-5 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs">⚠️</span>
            <strong className="text-amber-300 font-bold">"App not installed" আসলে কী করবেন?</strong>
          </div>
          <ol className="text-[11px] text-slate-300 space-y-1 list-decimal list-inside leading-relaxed">
            <li><strong>পুরনো অ্যাপ আনইনস্টল করুন:</strong> ফোনে আগে "Task WebView Test" বা Task Earn Pro ইনস্টল করা থাকলে Settings &gt; Apps থেকে সেটি <em>Uninstall</em> করে দিন। তারপর আবার এই APK ইনস্টল করুন।</li>
            <li><strong>Play Protect বন্ধ করুন:</strong> Play Store &gt; Profile &gt; Play Protect &gt; Settings এ গিয়ে সাময়িকভাবে <em>"Scan apps"</em> বন্ধ করুন অথবা ইনস্টল করার সময় <em>"Install anyway"</em> দিন।</li>
            <li><strong>সবচেয়ে সহজ উপায় (Chrome থেকে সরাসরি):</strong> Chrome ব্রাউজারের উপরে ৩টি ডট (⋮) এ ক্লিক করে <em>"Install app"</em> বা <em>"Add to Home screen"</em> চাপুন—কোনো সমস্যা ছাড়াই সরাসরি অ্যাপ ইনস্টল হয়ে যাবে!</li>
          </ol>
        </div>

        {/* Bengali Helper Callout */}
        <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs flex items-start gap-2.5">
          <Info className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <div className="space-y-0.5 leading-relaxed">
            <strong className="text-white block font-bold">সহজ ইনস্টল নির্দেশিকা (বাংলা):</strong>
            <p className="text-[11px] text-emerald-200">
              ডাউনলোড সম্পন্ন হলে নোটিফিকেশন থেকে অথবা Downloads ফোল্ডার থেকে <strong>Task-Earn-Pro-2.apk</strong> ফাইলটি ওপেন করুন। সিকিউরিটি সতর্কবার্তা আসলে <em>Settings</em> এ গিয়ে <em>"Allow from this source"</em> চালু করে <strong>Install</strong> বাটনে চাপুন।
            </p>
          </div>
        </div>
      </div>

      {/* Alternative Option: Instant PWA Install */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-900/60 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
        <div className="space-y-1">
          <span className="text-[10px] font-bold uppercase tracking-wider text-sky-400 block">
            Alternative Instant Option
          </span>
          <h4 className="font-bold text-white text-sm">
            Don't want to enable Unknown Sources?
          </h4>
          <p className="text-[11px] text-slate-400">
            Install Task Earn Pro directly to your home screen via browser WebAPK without downloading any APK file.
          </p>
          {pwaStatus && (
            <p className="text-[11px] text-emerald-400 font-semibold pt-1">{pwaStatus}</p>
          )}
        </div>

        <button
          type="button"
          onClick={handleInstallPWA}
          className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition-all shrink-0 cursor-pointer"
        >
          {isInstalled ? 'App Already Installed' : 'Add to Home Screen (PWA)'}
        </button>
      </div>

      {/* Floating 'Copied!' Toast Notification */}
      {showCopiedToast && (
        <div 
          className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 px-5 py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-2xl shadow-emerald-500/50 border border-emerald-400 animate-in fade-in slide-in-from-bottom-5 duration-200"
          role="status"
          aria-live="polite"
        >
          <div className="w-7 h-7 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-4 h-4 text-white" />
          </div>
          <div>
            <span className="block font-black text-sm">Copied!</span>
            <span className="block text-[11px] text-emerald-100 font-medium">
              Direct APK download URL copied to clipboard
            </span>
          </div>
        </div>
      )}

      {/* GitHub 404 Resolution & Flowrun Setup Modal */}
      <GitHubSetupModal
        isOpen={showGitHubModal}
        onClose={() => setShowGitHubModal(false)}
        directApkUrl={fullApkUrl}
      />

    </div>
  );
};
