import React, { useState } from 'react';
import { 
  X, 
  Share2, 
  Copy, 
  Check, 
  Send, 
  ExternalLink, 
  Sparkles,
  MessageCircle,
  Globe
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';

interface AppShareModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AppShareModal: React.FC<AppShareModalProps> = ({ isOpen, onClose }) => {
  const { currentUser } = useApp();
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentOrigin = typeof window !== 'undefined' ? window.location.origin : 'https://taskearn.pro';
  const refCode = currentUser?.referralCode || 'EARN100';
  const shareUrl = `${currentOrigin}?ref=${refCode}`;
  const shareMessage = `🔥 Join Task Earn Pro! Complete easy daily tasks, watch videos, follow social channels, and withdraw real money directly to UPI / Bank! Use my code: ${refCode}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    confetti({
      particleCount: 50,
      spread: 50,
      origin: { y: 0.7 }
    });
    setTimeout(() => setCopied(false), 2500);
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Task Earn Pro — Earn Money Online',
          text: shareMessage,
          url: shareUrl,
        });
      } catch (err) {
        // user cancelled or share failed
      }
    } else {
      handleCopyLink();
    }
  };

  const shareChannels = [
    {
      name: 'WhatsApp',
      icon: <MessageCircle className="w-5 h-5 text-emerald-400" />,
      bg: 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/25',
      url: `https://api.whatsapp.com/send?text=${encodeURIComponent(`${shareMessage} ${shareUrl}`)}`
    },
    {
      name: 'Telegram',
      icon: <Send className="w-5 h-5 text-sky-400" />,
      bg: 'bg-sky-500/15 border-sky-500/30 text-sky-300 hover:bg-sky-500/25',
      url: `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareMessage)}`
    },
    {
      name: 'Twitter / X',
      icon: <Globe className="w-5 h-5 text-slate-200" />,
      bg: 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700',
      url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareMessage)}&url=${encodeURIComponent(shareUrl)}`
    },
    {
      name: 'Facebook',
      icon: <Share2 className="w-5 h-5 text-blue-400" />,
      bg: 'bg-blue-600/15 border-blue-600/30 text-blue-300 hover:bg-blue-600/25',
      url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl relative max-h-[92vh] flex flex-col overflow-y-auto space-y-4"
        role="dialog"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="space-y-1 pr-6">
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center gap-1">
              <Share2 className="w-3 h-3" />
              <span>Share & Invite</span>
            </span>
            <span className="text-xs font-black text-amber-400">
              Earn +50 Coins / Friend
            </span>
          </div>

          <h2 className="text-base font-black text-white">
            Share Task Earn Pro
          </h2>
          <p className="text-xs text-slate-400">
            Share the application link with friends and followers to earn referral bonuses.
          </p>
        </div>

        {/* Copy Link Box */}
        <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
          <span className="text-[11px] font-bold text-slate-400 block">
            Your Official App Share Link
          </span>
          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={shareUrl}
              className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-200 text-xs font-mono select-all focus:outline-none"
            />
            <button
              type="button"
              onClick={handleCopyLink}
              className={`px-3.5 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                copied
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
              }`}
            >
              {copied ? <Check className="w-4 h-4 text-white" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Copied!' : 'Copy'}</span>
            </button>
          </div>
        </div>

        {/* Direct Social Channels */}
        <div className="space-y-2">
          <span className="text-[11px] font-bold text-slate-400 block">
            Share Directly Via:
          </span>

          <div className="grid grid-cols-2 gap-2">
            {shareChannels.map((channel) => (
              <a
                key={channel.name}
                href={channel.url}
                target="_blank"
                rel="noopener noreferrer"
                className={`p-3 rounded-2xl border transition-all flex items-center gap-2.5 cursor-pointer ${channel.bg}`}
              >
                {channel.icon}
                <span className="text-xs font-bold">{channel.name}</span>
              </a>
            ))}
          </div>
        </div>

        {/* Native OS Share Button */}
        {typeof navigator !== 'undefined' && 'share' in navigator && (
          <button
            type="button"
            onClick={handleNativeShare}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-sky-600 hover:opacity-95 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer active:scale-95 transition-all"
          >
            <Share2 className="w-4 h-4" />
            <span>Open System Share Menu</span>
          </button>
        )}

        <button
          type="button"
          onClick={onClose}
          className="w-full py-2.5 rounded-xl border border-slate-800 text-slate-400 hover:text-white font-bold text-xs transition-colors cursor-pointer"
        >
          Close
        </button>

      </div>
    </div>
  );
};
