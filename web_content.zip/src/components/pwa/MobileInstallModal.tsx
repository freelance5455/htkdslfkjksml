import React, { useState } from 'react';
import { 
  Smartphone, 
  X, 
  Check, 
  Copy, 
  Share2, 
  Download, 
  CheckCircle2, 
  ExternalLink,
  QrCode,
  Flame,
  Package,
  Layers,
  Sparkles,
  ArrowDownCircle
} from 'lucide-react';

interface MobileInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  isInstallable: boolean;
  isInstalled: boolean;
  isIOS: boolean;
  onInstallPWA: () => Promise<boolean>;
}

export const MobileInstallModal: React.FC<MobileInstallModalProps> = ({
  isOpen,
  onClose,
  isInstallable,
  isInstalled,
  isIOS,
  onInstallPWA,
}) => {
  // Default to Android unless explicitly on iOS
  const [activeOS, setActiveOS] = useState<'android' | 'apk' | 'ios'>(isIOS ? 'ios' : 'android');
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [installSuccess, setInstallSuccess] = useState(false);

  if (!isOpen) return null;

  // Real URL to install or open on mobile
  const appUrl = typeof window !== 'undefined' ? window.location.href.split('#')[0] : '';

  // Direct QR Code image from a fast, reliable SVG QR API
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=260x260&data=${encodeURIComponent(
    appUrl
  )}&bgcolor=020617&color=ea580c&margin=1`;

  const handleCopy = () => {
    if (navigator.clipboard && appUrl) {
      navigator.clipboard.writeText(appUrl);
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2500);
    }
  };

  const handleWhatsAppShare = () => {
    const text = `تطبيق حساب أقطار أنابيب الغاز الطبيعي والعدادات لأندرويد (GasCalc): ${appUrl}`;
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleInstallClick = async () => {
    const success = await onInstallPWA();
    if (success) {
      setInstallSuccess(true);
    }
  };

  const openPwaBuilder = () => {
    window.open(`https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(appUrl)}`, '_blank');
  };

  const handleDownloadOfflineFile = () => {
    const link = document.createElement('a');
    link.href = '/gas-calc-mobile.html';
    link.download = 'GasCalc_Offline_Android.html';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div 
        className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden my-4"
        dir="rtl"
      >
        
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500/20 to-orange-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
              <Smartphone className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <span>تحميل البرنامج لنظام أندرويد (Android)</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold">
                  Android App / APK
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                يعمل البرنامج كتطبيق هاتف أندرويد كامل بملء الشاشة وبدون الحاجة لإنترنت
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 text-sm">
          
          {/* Direct Offline HTML Download Section - Works 100% on any Phone without Link issues */}
          <div className="p-4 bg-gradient-to-r from-cyan-950/60 via-slate-900 to-indigo-950/60 border border-cyan-500/40 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg">
            <div>
              <div className="font-bold text-white text-sm flex items-center gap-1.5">
                <ArrowDownCircle className="w-4 h-4 text-cyan-400" />
                <span>تنزيل البرنامج كملف فوري يعمل على الهاتف مباشرة:</span>
              </div>
              <div className="text-xs text-slate-300 mt-0.5">
                ملف خفيف ومستقل، يعمل على أي هاتف (أندرويد أو آيفون) بدون إنترنت وبدون الحاجة لروابط أو اشتراكات!
              </div>
            </div>

            <button
              type="button"
              onClick={handleDownloadOfflineFile}
              className="w-full sm:w-auto px-4 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-600/30 transition-all shrink-0 cursor-pointer active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>تحميل نسخة الهاتف (HTML)</span>
            </button>
          </div>

          {/* Status Alert if Already Installed */}
          {(isInstalled || installSuccess) && (
            <div className="p-3.5 bg-emerald-950/40 border border-emerald-500/40 rounded-xl flex items-center gap-3 text-emerald-300 text-xs">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <strong className="block text-emerald-200 text-sm">تم تثبيت البرنامج بنجاح على هاتفك الأندرويد!</strong>
                يمكنك فتحه في أي وقت مباشرة من شاشة التطبيقات (App Drawer)، وإجراء جميع حسابات الغاز في الورشة والميدان بدون إنترنت.
              </div>
            </div>
          )}

          {/* Direct One-Click Install Button (When on mobile browser) */}
          {isInstallable && !isInstalled && !installSuccess && (
            <div className="p-4 bg-gradient-to-r from-emerald-950/60 via-slate-900 to-orange-950/60 border border-emerald-500/40 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg">
              <div>
                <div className="font-bold text-white text-sm flex items-center gap-1.5">
                  <Flame className="w-4 h-4 text-emerald-400" />
                  <span>تثبيت تطبيق أندرويد بنقرة واحدة (WebAPK):</span>
                </div>
                <div className="text-xs text-slate-300 mt-0.5">
                  اضغط الزر لإضافة GasCalc إلى تطبيقات هاتفك الأندرويد فوراً.
                </div>
              </div>

              <button
                type="button"
                onClick={handleInstallClick}
                className="w-full sm:w-auto px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 transition-all shrink-0 cursor-pointer active:scale-95"
              >
                <Download className="w-4 h-4" />
                <span>تثبيت على أندرويد الآن</span>
              </button>
            </div>
          )}

          {/* QR Code & Phone Access Section */}
          <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-xl flex flex-col sm:flex-row items-center gap-4 text-center sm:text-right">
            <div className="p-2.5 bg-slate-950 border border-slate-700 rounded-xl shrink-0 flex items-center justify-center">
              <img 
                src={qrCodeUrl} 
                alt="QR Code" 
                className="w-28 h-28 rounded-lg object-contain bg-slate-950"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>

            <div className="space-y-2 flex-1">
              <div className="font-bold text-slate-100 text-sm flex items-center justify-center sm:justify-start gap-1.5">
                <QrCode className="w-4 h-4 text-orange-400" />
                <span>مسح الرمز بكاميرا هاتف الأندرويد</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                افتح كاميرا هاتفك الأندرويد أو قارئ الباركود، ووجهها نحو الرمز لفتح البرنامج فوراً على الموبايل، ثم اضغط &quot;تثبيت&quot; ليظهر في درج التطبيقات.
              </p>

              {/* Share and Copy buttons */}
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleCopy}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedUrl ? 'تم نسخ الرابط' : 'نسخ رابط أندرويد'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleWhatsAppShare}
                  className="px-3 py-1.5 bg-emerald-600/90 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>إرسال الرابط إلى WhatsApp هاتفك</span>
                </button>
              </div>
            </div>
          </div>

          {/* Platform Tabs: Android WebAPK, Direct APK, and iOS */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300">اختر طريقة التحميل المناسبة لجهازك:</span>
              
              <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
                <button
                  type="button"
                  onClick={() => setActiveOS('android')}
                  className={`px-3 py-1 rounded-md font-bold transition-colors cursor-pointer ${
                    activeOS === 'android'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  أندرويد (تثبيت فوري)
                </button>
                <button
                  type="button"
                  onClick={() => setActiveOS('apk')}
                  className={`px-3 py-1 rounded-md font-bold transition-colors cursor-pointer ${
                    activeOS === 'apk'
                      ? 'bg-orange-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  حزمة APK المستقلة
                </button>
                <button
                  type="button"
                  onClick={() => setActiveOS('ios')}
                  className={`px-3 py-1 rounded-md font-bold transition-colors cursor-pointer ${
                    activeOS === 'ios'
                      ? 'bg-slate-700 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  آيفون (iOS)
                </button>
              </div>
            </div>

            {/* Method 1: Android Instant WebAPK Installation Guide */}
            {activeOS === 'android' && (
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3 text-xs">
                <div className="font-bold text-emerald-400 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>طريقة التثبيت المباشرة على جميع هواتف أندرويد (Chrome / Samsung / Xiaomi):</span>
                </div>

                <ol className="space-y-2.5 text-slate-300 pr-2">
                  <li className="flex items-start gap-2">
                    <span className="font-mono font-bold bg-slate-800 text-emerald-400 rounded-full w-5 h-5 flex items-center justify-center shrink-0">1</span>
                    <span>افتح الرابط في متصفح <strong>Google Chrome</strong> على هاتف الأندرويد.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="font-mono font-bold bg-slate-800 text-emerald-400 rounded-full w-5 h-5 flex items-center justify-center shrink-0">2</span>
                    <span>
                      ستظهر لك لافتة سفلية تقترح: <strong className="text-emerald-300">&quot;إضافة GasCalc إلى الشاشة الرئيسية&quot;</strong>.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="font-mono font-bold bg-slate-800 text-emerald-400 rounded-full w-5 h-5 flex items-center justify-center shrink-0">3</span>
                    <span>
                      إذا لم تظهر اللافتة: اضغط على <strong>قائمة الثلاث نقاط (⋮)</strong> أعلى يسار المتصفح، ثم اختر <strong className="text-emerald-300">تثبيت التطبيق (Install app)</strong>.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="font-mono font-bold bg-slate-800 text-emerald-400 rounded-full w-5 h-5 flex items-center justify-center shrink-0">4</span>
                    <span>
                      يقوم نظام أندرويد بتوليد تطبيق <strong>WebAPK</strong> رسمي وتثبيته في قائمة التطبيقات الرئيسية مع أيقونة شعلة الغاز.
                    </span>
                  </li>
                </ol>
              </div>
            )}

            {/* Method 2: Android APK Package */}
            {activeOS === 'apk' && (
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3 text-xs">
                <div className="font-bold text-orange-400 flex items-center gap-2">
                  <Package className="w-4 h-4 text-orange-400" />
                  <span>توليد وتحميل ملف APK مخصص لجهازك (Android Package):</span>
                </div>

                <p className="text-slate-300 leading-relaxed">
                  تم بناء هذا التطبيق وفق معايير <strong>Google PWA</strong> الحديثة، مما يسمح بتحويله فورياً إلى ملف <strong>APK</strong> أو رفعه إلى متجر <strong>Google Play Store</strong> بنقرة واحدة عبر أداة <strong>PWABuilder</strong> المعتمدة من مايكروسوفت وجوجل:
                </p>

                <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div>
                    <div className="font-bold text-slate-200">أداة حزم أندرويد الرسمية (PWABuilder / Android APK)</div>
                    <div className="text-[11px] text-slate-400">توليد ملف APK جاهز للتثبيت أو حزمة AAB لمتجر جوجل بلاي</div>
                  </div>
                  <button
                    type="button"
                    onClick={openPwaBuilder}
                    className="px-3.5 py-2 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 transition-colors shrink-0"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>فتح مولد الـ APK</span>
                  </button>
                </div>
              </div>
            )}

            {/* Method 3: iOS */}
            {activeOS === 'ios' && (
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3 text-xs">
                <div className="font-bold text-cyan-400 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                  <span>هواتف آبل آيفون (Apple Safari):</span>
                </div>

                <ol className="space-y-2.5 text-slate-300 pr-2">
                  <li className="flex items-start gap-2">
                    <span className="font-mono font-bold bg-slate-800 text-cyan-400 rounded-full w-5 h-5 flex items-center justify-center shrink-0">1</span>
                    <span>افتح الرابط في متصفح <strong>Safari</strong> على الآيفون.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="font-mono font-bold bg-slate-800 text-cyan-400 rounded-full w-5 h-5 flex items-center justify-center shrink-0">2</span>
                    <span>
                      اضغط على زر <strong className="text-white">المشاركة (Share ⎋)</strong> في أسفل الشاشة.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="font-mono font-bold bg-slate-800 text-cyan-400 rounded-full w-5 h-5 flex items-center justify-center shrink-0">3</span>
                    <span>
                      اختر <strong className="text-cyan-300">إضافة إلى الصفحة الرئيسية (Add to Home Screen ➕)</strong> ثم اضغط إضافة.
                    </span>
                  </li>
                </ol>
              </div>
            )}
          </div>

          {/* Advantages of Android WebAPK */}
          <div className="p-3.5 bg-gradient-to-r from-emerald-950/30 to-slate-950 border border-emerald-500/20 rounded-xl flex items-start gap-2.5 text-xs text-slate-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-emerald-400 block mb-0.5">لماذا يفضل تثبيت التطبيق على أندرويد؟</strong>
              يدعم التطبيق العمل بدون إنترنت (Offline)، ويخزن كافة الحسابات والأجهزة محلياً على هاتفك، ويعمل بحجم فائق الخفة (أقل من 3 ميجابايت) دون استهلاك بطارية أو ذاكرة.
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs">
          <span className="text-slate-500 font-mono">GasCalc for Android (v1.0.0)</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>

      </div>
    </div>
  );
};
