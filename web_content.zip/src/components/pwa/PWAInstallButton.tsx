import React, { useState } from 'react';
import { Download, Smartphone } from 'lucide-react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { ApkInstallModal } from './ApkInstallModal';

interface PWAInstallButtonProps {
  className?: string;
  variant?: 'pill' | 'button' | 'banner';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({
  className = '',
  variant = 'pill'
}) => {
  const { isInstalled } = usePWAInstall();
  const [isModalOpen, setIsModalOpen] = useState(false);

  // If running as standalone native app already, don't show the button
  if (isInstalled) {
    return null;
  }

  if (variant === 'banner') {
    return (
      <>
        <div 
          onClick={() => setIsModalOpen(true)}
          className={`p-3 rounded-2xl bg-gradient-to-r from-emerald-950/80 via-slate-900 to-teal-950/80 border border-emerald-800/60 shadow-md flex items-center justify-between cursor-pointer hover:border-emerald-600/80 transition-all ${className}`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black">
              <Download className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-black text-white flex items-center gap-1.5">
                <span>Install Task Earn Pro App (APK)</span>
                <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 font-bold">
                  4.2 MB
                </span>
              </h4>
              <p className="text-[10px] text-slate-400">
                Faster loading, offline support, and instant home screen access
              </p>
            </div>
          </div>

          <span className="text-xs font-black text-emerald-400 shrink-0">
            Install →
          </span>
        </div>

        <ApkInstallModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
        />
      </>
    );
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setIsModalOpen(true)}
        className={`px-3 py-1.5 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/35 text-emerald-300 font-bold text-xs flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer ${className}`}
        title="Install Android App / Download APK"
      >
        <Download className="w-3.5 h-3.5 text-emerald-400 animate-bounce" />
        <span className="hidden sm:inline">Install App</span>
        <span className="text-[10px] px-1 py-0.2 rounded-md bg-emerald-500/20 text-emerald-300 uppercase font-bold">
          APK
        </span>
      </button>

      <ApkInstallModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />
    </>
  );
};
