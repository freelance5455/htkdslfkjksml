import React, { useState } from 'react';
import { 
  Smartphone, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle,
  HelpCircle,
  ExternalLink,
  Download
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { usePWAInstall } from '../../hooks/usePWAInstall';

export const AndroidInstallPage: React.FC = () => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [installStatus, setInstallStatus] = useState<string | null>(null);
  const [activeGuideTab, setActiveGuideTab] = useState<'chrome' | 'samsung' | 'safari'>('chrome');

  const handleInstallPWA = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (accepted) {
        setInstallStatus('Installed successfully! You can find Task Earn Pro on your Android home screen and app launcher.');
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.65 }
        });
      }
    } else {
      setInstallStatus('Tap browser menu (⋮ on Chrome or Share on Safari) and select "Install App" or "Add to Home Screen".');
    }
  };

  const handleDownloadProjectZip = () => {
    const link = document.createElement('a');
    link.href = '/task-earn-pro-android-studio-project.zip';
    link.setAttribute('download', 'task-earn-pro-android-studio-project.zip');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="w-full max-w-xl mx-auto p-4 sm:p-6 space-y-6 text-slate-100 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex items-center gap-4 p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl">
        <img
          src="/pwa-192x192.png"
          alt="Task Earn Pro Logo"
          className="w-16 h-16 rounded-2xl object-cover border border-emerald-500/40 shadow-lg shadow-emerald-500/20 shrink-0"
        />
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              Android & PWA Center
            </span>
            <span className="text-[10px] text-slate-400 font-mono">com.subhodip.taskearnpro</span>
          </div>
          <h1 className="text-xl font-black text-white">
            Task Earn Pro Installation
          </h1>
          <p className="text-xs text-slate-400">
            Official Android package & mobile app portal
          </p>
        </div>
      </div>

      {/* Android APK Build Status Section */}
      <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <span className="text-sm font-bold text-slate-200 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-400" />
            <span>Android APK Build Status</span>
          </span>
          <span className="text-xs font-mono text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/20 font-bold">
            Not Built Yet
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs space-y-2">
          <p className="text-slate-300 leading-relaxed">
            Production APK has not been generated yet. This web environment cannot compile and sign the Android APK.
          </p>
        </div>

        {/* Two Options */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          {/* Option 1: Install as PWA */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between space-y-3">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4 text-sky-400" />
                  <span>1. Install as PWA</span>
                </span>
                <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded font-bold">
                  Recommended
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Instantly installs Task Earn Pro onto your phone with a home screen icon and offline support.
              </p>
            </div>

            {isInstalled ? (
              <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-300 text-xs font-bold text-center flex items-center justify-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>App Installed on Device!</span>
              </div>
            ) : (
              <button
                type="button"
                onClick={handleInstallPWA}
                className="w-full py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs transition-all cursor-pointer shadow-md shadow-sky-600/20 active:scale-95 flex items-center justify-center gap-2"
              >
                <Smartphone className="w-4 h-4" />
                <span>Install App to Home Screen</span>
              </button>
            )}
          </div>

          {/* Option 2: Build Real APK in Android Studio */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col justify-between space-y-3">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <ExternalLink className="w-4 h-4 text-emerald-400" />
                  <span>2. Build Real APK</span>
                </span>
                <span className="text-[10px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded font-bold">
                  Studio Required
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Export the Android project, open it in Android Studio, then generate a signed release APK.
              </p>
            </div>

            <button
              type="button"
              onClick={handleDownloadProjectZip}
              className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all cursor-pointer shadow-md shadow-emerald-600/20 active:scale-95 flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" />
              <span>Build APK in Android Studio</span>
            </button>
          </div>
        </div>

        {installStatus && (
          <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs text-center font-medium">
            {installStatus}
          </div>
        )}
      </div>

      {/* Step-by-Step Android Installation Guide */}
      <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-3 shadow-xl text-xs">
        <div className="flex items-center justify-between">
          <span className="font-bold text-slate-200 flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-amber-400" />
            <span>Step-by-Step Android Installation Guide</span>
          </span>
        </div>

        {/* Guide Tabs */}
        <div className="flex gap-1 bg-slate-950 p-1 rounded-xl">
          <button
            type="button"
            onClick={() => setActiveGuideTab('chrome')}
            className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeGuideTab === 'chrome'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Chrome
          </button>
          <button
            type="button"
            onClick={() => setActiveGuideTab('samsung')}
            className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeGuideTab === 'samsung'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Samsung
          </button>
          <button
            type="button"
            onClick={() => setActiveGuideTab('safari')}
            className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeGuideTab === 'safari'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            iOS / Safari
          </button>
        </div>

        {/* Guide Details */}
        {activeGuideTab === 'chrome' && (
          <div className="space-y-2 text-xs text-slate-300 leading-relaxed p-2">
            <p>1. Tap the three dots (⋮) in the top-right corner of Google Chrome.</p>
            <p>2. Tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</p>
            <p>3. Confirm <strong>"Install"</strong> when prompted. The official icon will appear on your phone!</p>
          </div>
        )}

        {activeGuideTab === 'samsung' && (
          <div className="space-y-2 text-xs text-slate-300 leading-relaxed p-2">
            <p>1. In Samsung Internet, tap the menu (☰) at the bottom right.</p>
            <p>2. Tap <strong>"Add page to"</strong> &rarr; <strong>"Home screen"</strong>.</p>
            <p>3. Tap <strong>"Install"</strong> to add the standalone application.</p>
          </div>
        )}

        {activeGuideTab === 'safari' && (
          <div className="space-y-2 text-xs text-slate-300 leading-relaxed p-2">
            <p>1. Tap the <strong>Share</strong> button (box with upward arrow) at the bottom.</p>
            <p>2. Scroll down and tap <strong>"Add to Home Screen"</strong>.</p>
            <p>3. Tap <strong>"Add"</strong> in the top right. Task Earn Pro is ready!</p>
          </div>
        )}
      </div>

      {/* Security & Verification Guarantee */}
      <div className="p-3.5 rounded-2xl bg-emerald-950/20 border border-emerald-900/40 text-xs text-emerald-400/90 flex items-center gap-2.5">
        <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-400" />
        <span>Zero malware, secure official web and mobile architecture.</span>
      </div>
    </div>
  );
};
