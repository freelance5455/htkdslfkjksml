import React, { useState } from 'react';
import { 
  Download, 
  Laptop, 
  ExternalLink, 
  CheckCircle2, 
  FileCode, 
  Database, 
  Sparkles, 
  X, 
  HelpCircle,
  Monitor,
  HardDriveDownload,
  Copy,
  Check,
  RefreshCw,
  Zap,
  Layers,
  FileText,
  ShieldAlert
} from 'lucide-react';
import { exportAllDataBackup } from '../../utils/storage';

interface DownloadInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  isInstallable: boolean;
  isInstalled: boolean;
  onInstallPWA: () => Promise<boolean>;
}

export const DownloadInstallModal: React.FC<DownloadInstallModalProps> = ({
  isOpen,
  onClose,
  isInstallable,
  isInstalled,
  onInstallPWA,
}) => {
  const [activeTab, setActiveTab] = useState<'windows' | 'launcher' | 'backup' | 'updates'>('windows');
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [installSuccess, setInstallSuccess] = useState(false);
  const [checkingUpdate, setCheckingUpdate] = useState(false);
  const [updateStatus, setUpdateStatus] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCheckUpdates = () => {
    setCheckingUpdate(true);
    setUpdateStatus(null);
    setTimeout(() => {
      setCheckingUpdate(false);
      setUpdateStatus('أنت تعمل على أحدث إصدار وتحديثات مستقرة للنظام! (v2.4 - التحديث الأخير)');
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.getRegistrations().then((registrations) => {
          for (const registration of registrations) {
            registration.update();
          }
        });
      }
    }, 1200);
  };

  const handleForceRefresh = () => {
    if (window.confirm('هل تريد إعادة تحميل التطبيق وتحديث ذاكرة التخزين المؤقت الآن؟')) {
      window.location.reload();
    }
  };

  // Real absolute URL of the running application
  const appUrl = typeof window !== 'undefined' ? window.location.href.split('?')[0] : '';

  const handleInstallClick = async () => {
    const success = await onInstallPWA();
    if (success) {
      setInstallSuccess(true);
    }
  };

  const handleOpenStandaloneTab = () => {
    window.open(appUrl, '_blank', 'noopener,noreferrer');
  };

  const handleCopyUrl = () => {
    if (navigator.clipboard && appUrl) {
      navigator.clipboard.writeText(appUrl);
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2500);
    }
  };

  // Generate and download a Windows Desktop .bat launcher
  const handleDownloadWindowsLauncher = () => {
    const batContent = `@echo off
chcp 65001 >nul
title برنامج المبيعات ونقاط البيع السريعة - WinSales POS
echo ========================================================
echo        جاري تشغيل برنامج المبيعات السريع WinSales POS
echo ========================================================
echo.
echo جاري فتح البرنامج في نافذة سطح مكتب مستقلة...
echo.

:: Try opening with Microsoft Edge in app mode
start msedge --app="${appUrl}" >nul 2>&1
if %ERRORLEVEL% EQU 0 exit

:: Try opening with Google Chrome in app mode
start chrome --app="${appUrl}" >nul 2>&1
if %ERRORLEVEL% EQU 0 exit

:: Fallback to default browser
start "" "${appUrl}"
exit
`;

    const blob = new Blob([batContent], { type: 'application/x-bat;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'تشغيل_برنامج_المبيعات_WinSales.bat';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        dir="rtl"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-blue-600/20 text-blue-400 border border-blue-500/30 rounded-xl">
              <Laptop className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                تحميل وتثبيت البرنامج على جهازك (Windows)
                <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30 rounded-full">
                  PWA + Desktop
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                طرق تثبيت برنامج المبيعات للعمل كتطبيق سطح مكتب سريع ومستقل دون متصفح
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-900/80 px-6 gap-2 pt-2 text-xs font-bold">
          <button
            onClick={() => setActiveTab('windows')}
            className={`pb-3 px-3 flex items-center gap-2 border-b-2 transition ${
              activeTab === 'windows'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Monitor className="w-4 h-4" />
            <span>تثبيت كتطبيق Windows (PWA)</span>
          </button>

          <button
            onClick={() => setActiveTab('launcher')}
            className={`pb-3 px-3 flex items-center gap-2 border-b-2 transition ${
              activeTab === 'launcher'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <HardDriveDownload className="w-4 h-4" />
            <span>ملف تشغيل سطح المكتب (.bat)</span>
          </button>

          <button
            onClick={() => setActiveTab('backup')}
            className={`pb-3 px-3 flex items-center gap-2 border-b-2 transition ${
              activeTab === 'backup'
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>تنزيل نسخة البيانات والكود</span>
          </button>

          <button
            onClick={() => setActiveTab('updates')}
            className={`pb-3 px-3 flex items-center gap-2 border-b-2 transition ${
              activeTab === 'updates'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <RefreshCw className="w-4 h-4" />
            <span className="flex items-center gap-1.5">
              <span>تحديثات النظام</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            </span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-sm">
          {activeTab === 'windows' && (
            <div className="space-y-5">
              {/* Status Banner */}
              {isInstalled || installSuccess ? (
                <div className="p-4 bg-emerald-950/40 border border-emerald-500/40 rounded-xl flex items-center gap-3 text-emerald-300">
                  <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
                  <div>
                    <div className="font-bold text-emerald-200">البرنامج مثبت بالفعل على جهازك!</div>
                    <div className="text-xs text-emerald-400/90 mt-0.5">
                      التطبيق مثبت كتطبيق سطح مكتب ويعمل بنافذة مستقلة مع دعم العمل دون إنترنت وحفظ كافة البيانات محلياً.
                    </div>
                  </div>
                </div>
              ) : isInstallable ? (
                <div className="p-5 bg-gradient-to-r from-blue-950/50 to-indigo-950/40 border border-blue-500/40 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="space-y-1 text-center sm:text-right">
                    <div className="font-bold text-white text-base flex items-center gap-2 justify-center sm:justify-start">
                      <Sparkles className="w-5 h-5 text-amber-400" />
                      جاهز للتثبيت الفوري على Windows!
                    </div>
                    <p className="text-xs text-slate-300 max-w-md">
                      اضغط على الزر أدناه لتثبيت البرنامج مباشرة على سطح المكتب وفي قائمة ابدأ (Start Menu).
                    </p>
                  </div>
                  <button
                    onClick={handleInstallClick}
                    className="w-full sm:w-auto px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 transition"
                  >
                    <Download className="w-4 h-4" />
                    <span>تثبيت البرنامج الآن</span>
                  </button>
                </div>
              ) : (
                <div className="p-4 bg-slate-800/80 border border-slate-700 rounded-xl space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="p-2 bg-blue-500/10 text-blue-400 rounded-lg shrink-0 mt-0.5">
                      <ExternalLink className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="font-bold text-slate-200">التثبيت المباشر بنقرة واحدة من المتصفح:</div>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        نظراً لأنك تشاهد التطبيق داخل بيئة المعاينة، تمنع المتصفحات ظهور نافذة التثبيت داخل الإطارات التجريبية. لتثبيت البرنامج فوراً على Windows:
                      </p>
                    </div>
                  </div>

                  <div className="pt-2 flex flex-col sm:flex-row gap-2">
                    <button
                      onClick={handleOpenStandaloneTab}
                      className="flex-1 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-md shadow-blue-600/20 transition"
                    >
                      <ExternalLink className="w-4 h-4" />
                      <span>فتح التطبيق في نافذة مستقلة للتثبيت</span>
                    </button>
                    <button
                      onClick={handleCopyUrl}
                      className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition"
                    >
                      {copiedUrl ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                      <span>{copiedUrl ? 'تم نسخ الرابط!' : 'نسخ رابط البرنامج'}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Step by Step Manual Guide for Windows (Edge / Chrome) */}
              <div className="space-y-3">
                <div className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <HelpCircle className="w-3.5 h-3.5 text-blue-400" />
                  خطوات التثبيت السريعة لمتصفحات نظام Windows:
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {/* Edge Guide */}
                  <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                    <div className="flex items-center gap-2 text-blue-400 font-bold text-xs">
                      <span className="w-2 h-2 rounded-full bg-blue-400" />
                      متصفح Microsoft Edge (الأفضل على ويندوز):
                    </div>
                    <ol className="text-xs text-slate-300 space-y-1.5 list-decimal list-inside pr-1 leading-relaxed">
                      <li>افتح البرنامج في متصفح Edge.</li>
                      <li>
                        انقر على أيقونة <strong className="text-white">التطبيقات (⊞)</strong> في شريط العنوان أعلى اليسار، أو من قائمة الثلاث نقاط (<strong className="text-white">...</strong>).
                      </li>
                      <li>
                        اختر <strong className="text-blue-300">التطبيقات (Apps)</strong> ثم <strong className="text-blue-300">تثبيت WinSales كتطبيق</strong>.
                      </li>
                      <li>حدد وضع اختصار على سطح المكتب واضغط <strong className="text-emerald-400">تثبيت</strong>.</li>
                    </ol>
                  </div>

                  {/* Chrome Guide */}
                  <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                    <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                      <span className="w-2 h-2 rounded-full bg-emerald-400" />
                      متصفح Google Chrome:
                    </div>
                    <ol className="text-xs text-slate-300 space-y-1.5 list-decimal list-inside pr-1 leading-relaxed">
                      <li>افتح رابط البرنامج في Chrome.</li>
                      <li>
                        انقر على أيقونة <strong className="text-white">التثبيت (🖥️ أو ⬇️)</strong> في أقصى يسار شريط الروابط.
                      </li>
                      <li>
                        أو اضغط على القائمة (<strong className="text-white">⋮</strong>) ثم <strong className="text-blue-300">حفظ ومشاركة</strong> &gt; <strong className="text-blue-300">تثبيت التطبيق</strong>.
                      </li>
                      <li>سيفتح البرنامج تلقائياً كنافذة تطبيق مستقلة على سطح المكتب.</li>
                    </ol>
                  </div>
                </div>
              </div>

              {/* Offline & Desktop Advantages */}
              <div className="p-3.5 bg-slate-800/40 border border-slate-700/60 rounded-xl text-xs text-slate-400 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <p>
                  <strong>ميزة التثبيت على Windows:</strong> يعمل البرنامج كنافذة كاشير مخصصة بكامل ميزات الفواتير والباركود والطابعات دون تشتيت أشرطة المتصفح، ويحفظ البيانات محلياً مع سرعة استجابة فائقة.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'launcher' && (
            <div className="space-y-4">
              <div className="p-4 bg-blue-950/30 border border-blue-500/30 rounded-xl space-y-2">
                <div className="font-bold text-white flex items-center gap-2">
                  <Laptop className="w-4 h-4 text-blue-400" />
                  أداة التشغيل السريع لسطح مكتب Windows (.bat)
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  إذا كنت ترغب بتشغيل البرنامج من سطح المكتب بنقرة مزدوجة مباشرة دون الحاجة لخطوات تثبيت PWA، يمكنك تنزيل ملف التشغيل التلقائي هذا ووضعه على سطح مكتب جهازك.
                </p>
              </div>

              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3 font-mono text-xs">
                <div className="text-slate-400 flex items-center justify-between">
                  <span>محتوى ملف التشغيل (WinSales_Launcher.bat):</span>
                  <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-blue-300">Windows Script</span>
                </div>
                <pre className="text-[11px] text-emerald-400/90 overflow-x-auto p-2 bg-slate-900 rounded border border-slate-800 whitespace-pre-wrap">
                  {`start msedge --app="${appUrl}"`}
                </pre>
                <div className="text-[11px] text-slate-400">
                  * يقوم الأمر بتشغيل البرنامج في وضع النافذة المستقلة (App Mode) لإخفاء أشرطة المتصفح بالكامل.
                </div>
              </div>

              <button
                onClick={handleDownloadWindowsLauncher}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 transition"
              >
                <Download className="w-4 h-4" />
                <span>تنزيل ملف تشغيل سطح المكتب (تشغيل_برنامج_المبيعات_WinSales.bat)</span>
              </button>
            </div>
          )}

          {activeTab === 'backup' && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-800/60 border border-slate-700 rounded-xl space-y-3">
                <div className="font-bold text-white flex items-center gap-2">
                  <Database className="w-4 h-4 text-blue-400" />
                  تنزيل نسخة احتياطية لكافة بيانات النظام (JSON)
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  احفظ نسخة كاملة من جميع المنتجات المخزنة، الفواتير، ديون العملاء، وسجلات الكود على القرص الصلب بجهاز الكمبيوتر في أي وقت لاستعادتها أو نقلها لجهاز آخر.
                </p>
                <button
                  onClick={exportAllDataBackup}
                  className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl flex items-center gap-2 transition"
                >
                  <Download className="w-4 h-4" />
                  <span>تنزيل ملف النسخة الاحتياطية الآن (.json)</span>
                </button>
              </div>

              <div className="p-4 bg-slate-800/60 border border-slate-700 rounded-xl space-y-2">
                <div className="font-bold text-white flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-amber-400" />
                  تصدير الكود البرمجي للمشروع كاملاً (Export to ZIP / GitHub)
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  يمكنك في أي وقت تنزيل وتصدير كامل الكود المصدري للمشروع (بملفات React, Vite, Express, TypeScript) كملف مضغوط <strong className="text-white">ZIP</strong> أو ربطه بمستودع <strong className="text-white">GitHub</strong> عبر خيارات قائمة المشاركة والإعدادات في بيئة العمل.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'updates' && (
            <div className="space-y-4">
              {/* Check for updates banner */}
              <div className="p-4 bg-gradient-to-r from-emerald-950/50 to-slate-900 border border-emerald-500/40 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 font-bold text-white">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    <span>حالة التحديثات والإصدار الحالي</span>
                    <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-mono px-2 py-0.5 rounded-full border border-emerald-500/30">
                      v2.4 الأحدث
                    </span>
                  </div>
                  <p className="text-xs text-slate-300">
                    تم تضمين جميع التحديثات الأخيرة والميزات المحاسبية وإدارة الأقسام وتفاصيل الفواتير.
                  </p>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    onClick={handleCheckUpdates}
                    disabled={checkingUpdate}
                    className="flex-1 sm:flex-none px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-emerald-600/20"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${checkingUpdate ? 'animate-spin' : ''}`} />
                    <span>{checkingUpdate ? 'جاري الفحص...' : 'فحص التحديثات'}</span>
                  </button>

                  <button
                    onClick={handleForceRefresh}
                    className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold transition"
                    title="تحديث فوري وإعادة تحميل الكاش"
                  >
                    تحديث فوري
                  </button>
                </div>
              </div>

              {updateStatus && (
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{updateStatus}</span>
                </div>
              )}

              {/* Changelog list of recent additions */}
              <div className="space-y-3">
                <div className="text-xs font-bold text-slate-300 flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <span>سجل آخر التحديثات والميزات المضافة للنظام:</span>
                </div>

                <div className="space-y-2.5">
                  <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-blue-400 flex items-center gap-1.5">
                        <FileText className="w-3.5 h-3.5" />
                        عرض الفواتير مفصلة بالكامل (بنقرة واحدة)
                      </span>
                      <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-mono">جديد</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      إمكانية توسيع أي فاتورة في شاشة الفواتير للاطلاع على جدول الأصناف المباعة، الكميات، الأسعار، نسبة الخصم، بيانات العميل والكاشير، والملخص المالي والضريبي دون الحاجة لمغادرة الجدول.
                    </p>
                  </div>

                  <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-emerald-400 flex items-center gap-1.5">
                        <Layers className="w-3.5 h-3.5" />
                        نظام إدارة وتعديل قائمة الأقسام والتصنيفات
                      </span>
                      <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-mono">جديد</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      إضافة نافذة متخصصة لإضافة الأقسام، إعادة تسميتها مع التحديث التلقائي لكافة الأصناف المرتبطة بها، وحذف الأقسام مع نقل المنتجات إلى أقسام بديلة، مع حفظها محلياً.
                    </p>
                  </div>

                  <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-amber-400 flex items-center gap-1.5">
                        <Laptop className="w-3.5 h-3.5" />
                        دعم Windows والتثبيت كـ PWA مع مشغل .bat
                      </span>
                      <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-mono">محدث</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      تشغيل البرنامج كنافذة سطح مكتب مخصصة على ويندوز تدعم العمل بدون إنترنت، وقارئات الباركود وطابعات الإيصالات الحرارية 80mm و A4.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between text-xs">
          <span className="text-slate-400 font-mono">WinSales POS v1.0 • Windows 10/11 Ready</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg font-medium transition"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
