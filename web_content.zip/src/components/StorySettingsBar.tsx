import React, { useState } from 'react';
import { Sparkles, SlidersHorizontal, BookOpen, Compass, Eye, ChevronDown } from 'lucide-react';

interface StorySettingsBarProps {
  genre: string;
  setGenre: (g: string) => void;
  tone: string;
  setTone: (t: string) => void;
  pov: string;
  setPov: (p: string) => void;
  hookType: string;
  setHookType: (h: string) => void;
  userPrompt: string;
  setUserPrompt: (p: string) => void;
  onGenerate: () => void;
  isAnalyzing: boolean;
  disabled: boolean;
}

const GENRES = [
  'Speculative Fiction',
  'Gothic Victorian Mystery',
  'Cyberpunk Noir',
  'High Epic Fantasy',
  'Magical Realism',
  'Cosmic Sci-Fi Thriller',
  'Post-Apocalyptic Survival',
  'Historical Literary Drama',
];

const TONES = [
  'Atmospheric & Evocative',
  'Melancholic & Lyrical',
  'High-Tension & Suspenseful',
  'Intimate & Psychological',
  'Epic & Portentous',
  'Whispered & Chilling',
];

const POVS = [
  'Third Person Limited',
  'First Person Introspective',
  'Third Person Omniscient',
  'Second Person Unsettling',
];

const HOOK_STYLES = [
  'Atmospheric Immersion',
  'In Media Res (Action Hook)',
  'Sudden Disruption',
  'Ancient Mystery & Lore',
  'Introspective Character Confession',
];

export const StorySettingsBar: React.FC<StorySettingsBarProps> = ({
  genre,
  setGenre,
  tone,
  setTone,
  pov,
  setPov,
  hookType,
  setHookType,
  userPrompt,
  setUserPrompt,
  onGenerate,
  isAnalyzing,
  disabled,
}) => {
  const [showAdvanced, setShowAdvanced] = useState(false);

  return (
    <div className="rounded-2xl border border-stone-800 bg-stone-900/70 backdrop-blur-sm p-4 sm:p-5 shadow-lg space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4 text-amber-400" />
          <h4 className="font-display text-sm font-semibold text-stone-200 tracking-wide">
            Ghostwriter Creative Direction
          </h4>
        </div>

        <button
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="text-xs text-stone-400 hover:text-amber-300 flex items-center gap-1 transition-colors self-start sm:self-auto"
        >
          <span>{showAdvanced ? 'Hide Custom Lenses' : 'Adjust Lenses & POV'}</span>
          <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showAdvanced ? 'rotate-180' : ''}`} />
        </button>
      </div>

      {/* Primary selectors */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
        {/* Genre */}
        <div className="space-y-1">
          <label className="text-[11px] font-medium text-stone-400 flex items-center gap-1">
            <BookOpen className="w-3 h-3 text-amber-500" />
            Genre
          </label>
          <select
            value={genre}
            onChange={(e) => setGenre(e.target.value)}
            disabled={disabled || isAnalyzing}
            className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-800 text-stone-200 focus:outline-none focus:border-amber-500 disabled:opacity-50"
          >
            {GENRES.map((g) => (
              <option key={g} value={g} className="bg-stone-950 text-stone-200">
                {g}
              </option>
            ))}
          </select>
        </div>

        {/* Tone */}
        <div className="space-y-1">
          <label className="text-[11px] font-medium text-stone-400 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-500" />
            Mood & Atmosphere
          </label>
          <select
            value={tone}
            onChange={(e) => setTone(e.target.value)}
            disabled={disabled || isAnalyzing}
            className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-800 text-stone-200 focus:outline-none focus:border-amber-500 disabled:opacity-50"
          >
            {TONES.map((t) => (
              <option key={t} value={t} className="bg-stone-950 text-stone-200">
                {t}
              </option>
            ))}
          </select>
        </div>

        {/* POV */}
        <div className="space-y-1">
          <label className="text-[11px] font-medium text-stone-400 flex items-center gap-1">
            <Eye className="w-3 h-3 text-amber-500" />
            Point of View
          </label>
          <select
            value={pov}
            onChange={(e) => setPov(e.target.value)}
            disabled={disabled || isAnalyzing}
            className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-800 text-stone-200 focus:outline-none focus:border-amber-500 disabled:opacity-50"
          >
            {POVS.map((p) => (
              <option key={p} value={p} className="bg-stone-950 text-stone-200">
                {p}
              </option>
            ))}
          </select>
        </div>

        {/* Hook Style */}
        <div className="space-y-1">
          <label className="text-[11px] font-medium text-stone-400 flex items-center gap-1">
            <Compass className="w-3 h-3 text-amber-500" />
            Opening Hook Type
          </label>
          <select
            value={hookType}
            onChange={(e) => setHookType(e.target.value)}
            disabled={disabled || isAnalyzing}
            className="w-full px-3 py-2 rounded-xl bg-stone-950 border border-stone-800 text-stone-200 focus:outline-none focus:border-amber-500 disabled:opacity-50"
          >
            {HOOK_STYLES.map((h) => (
              <option key={h} value={h} className="bg-stone-950 text-stone-200">
                {h}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Advanced prompt / premise input */}
      {showAdvanced && (
        <div className="pt-2 border-t border-stone-800/80 space-y-1.5 animate-fadeIn">
          <label className="text-[11px] font-medium text-stone-400">
            Specific Focus or Character Seed (Optional)
          </label>
          <input
            type="text"
            value={userPrompt}
            onChange={(e) => setUserPrompt(e.target.value)}
            disabled={disabled || isAnalyzing}
            placeholder="e.g., Focus on a solitary scholar observing an erratic eclipse through a telescope..."
            className="w-full px-3.5 py-2.5 rounded-xl bg-stone-950 border border-stone-800 text-xs text-stone-200 placeholder:text-stone-600 focus:outline-none focus:border-amber-500 disabled:opacity-50"
          />
        </div>
      )}

      {/* Big Action Button */}
      <div className="pt-1 flex justify-end">
        <button
          onClick={onGenerate}
          disabled={disabled || isAnalyzing}
          className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-stone-950 font-semibold text-xs sm:text-sm tracking-wide shadow-xl shadow-amber-500/20 hover:shadow-amber-500/30 transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-40 disabled:pointer-events-none flex items-center justify-center gap-2"
        >
          {isAnalyzing ? (
            <>
              <div className="w-4 h-4 rounded-full border-2 border-stone-900 border-t-transparent animate-spin" />
              <span>Analyzing Image & Ghostwriting Scene...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-stone-950" />
              <span>Analyze Scene & Ghostwrite Opening</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
