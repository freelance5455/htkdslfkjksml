import React, { useState } from 'react';
import { SaleInvoice, BusinessProfile } from '../types/business';
import {
  Printer,
  Share2,
  X,
  CheckCircle,
  Phone,
  MessageCircle,
  Copy,
  Check,
  Building2,
  Calendar,
  Clock,
  Eye,
  EyeOff,
} from 'lucide-react';

interface InvoiceModalProps {
  invoice: SaleInvoice;
  profile: BusinessProfile;
  lang: 'bn' | 'en';
  onClose: () => void;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({
  invoice,
  profile,
  lang,
  onClose,
}) => {
  const [showProfit, setShowProfit] = useState(false);
  const [copied, setCopied] = useState(false);

  const currency = profile.currency || '৳';

  // Format WhatsApp Share text
  const getShareText = () => {
    const itemsList = invoice.items
      .map(
        (item, idx) =>
          `${idx + 1}. ${item.brand} ${item.modelNumber} (${item.category}): ${item.quantity} পিস × ৳${item.unitPrice} = ৳${item.totalPrice}`
      )
      .join('\n');

    return `*${profile.businessName}*\n${profile.address} | ফোন: ${profile.phone}\n-----------------------------------\n*বিক্রয় রসিদ / চালান: ${invoice.invoiceNumber}*\nতারিখ: ${invoice.date} (${invoice.time})\nক্রেতা: ${invoice.customerName} (${invoice.customerPhone || 'নগদ'})\n-----------------------------------\n*পণ্যসমূহ:*\n${itemsList}\n-----------------------------------\nমোট বিল: ৳${invoice.totalSalesAmount}\nছাড়: ৳${invoice.discount}\n*সর্বমোট প্রদেয়: ৳${invoice.finalPayableAmount}*\nপরিশোধ: ৳${invoice.paidAmount} (${invoice.paymentMethod})\n*বাকি: ৳${invoice.dueAmount}*\n-----------------------------------\nআমাদের সাথে থাকার জন্য ধন্যবাদ!`;
  };

  // WhatsApp share
  const handleWhatsAppShare = () => {
    const text = encodeURIComponent(getShareText());
    const phone = invoice.customerPhone.replace(/[^0-9]/g, '');
    const url = phone
      ? `https://wa.me/${phone}?text=${text}`
      : `https://wa.me/?text=${text}`;
    window.open(url, '_blank');
  };

  // Android Web Share API
  const handleSystemShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Invoice ${invoice.invoiceNumber} - ${profile.businessName}`,
          text: getShareText(),
        });
      } catch (err) {
        console.warn('Share cancelled', err);
      }
    } else {
      // Fallback: Copy to clipboard
      navigator.clipboard.writeText(getShareText());
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // Android print flow
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-xl rounded-3xl shadow-2xl overflow-hidden my-4 border border-slate-200 print:m-0 print:p-0 print:border-none print:shadow-none print:w-full print:max-w-none">
        {/* Modal Top Actions (Hidden in Print) */}
        <div className="px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-full border border-emerald-800">
              ✓ বিক্রয় সংরক্ষিত
            </span>
            <span className="text-xs text-slate-300 font-mono">
              {invoice.invoiceNumber}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Toggle Merchant Profit View */}
            <button
              onClick={() => setShowProfit(!showProfit)}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium flex items-center gap-1 cursor-pointer"
              title="Toggle Profit Display"
            >
              {showProfit ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              <span>{showProfit ? 'লাভ লুকান' : 'লাভ দেখুন'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* PRINTABLE INVOICE BODY */}
        <div id="printable-invoice" className="p-6 sm:p-8 space-y-5 bg-white text-slate-900 font-sans">
          {/* Business Header */}
          <div className="text-center pb-4 border-b border-slate-200">
            {profile.businessLogo && (
              <img
                src={profile.businessLogo}
                alt="Logo"
                className="w-14 h-14 object-contain mx-auto mb-2"
              />
            )}
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight leading-tight">
              {profile.businessName}
            </h2>
            <p className="text-xs text-slate-600 font-medium mt-0.5">
              {profile.address}
            </p>
            <p className="text-xs font-bold text-slate-700 mt-0.5">
              মোবাইল: {profile.phone}
            </p>
            <div className="mt-2 inline-block px-3 py-0.5 bg-slate-100 rounded-full text-[10px] font-bold uppercase tracking-wider text-slate-600">
              বিক্রয় চালান / Sales Invoice
            </div>
          </div>

          {/* Invoice Meta Grid */}
          <div className="grid grid-cols-2 gap-3 p-3 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-bold block">চালান নম্বর</span>
              <span className="font-extrabold text-slate-900 font-mono text-sm">{invoice.invoiceNumber}</span>
              <div className="mt-1 flex items-center gap-2 text-slate-500 text-[11px]">
                <span>{invoice.date}</span>
                <span>•</span>
                <span>{invoice.time}</span>
              </div>
            </div>

            <div className="text-right">
              <span className="text-[10px] text-slate-400 uppercase font-bold block">ক্রেতা / কাস্টমার</span>
              <span className="font-bold text-slate-900 block">{invoice.customerName}</span>
              {invoice.customerPhone && (
                <span className="text-slate-600 text-[11px] block">{invoice.customerPhone}</span>
              )}
            </div>
          </div>

          {/* Items Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b-2 border-slate-200 text-slate-500 uppercase text-[10px] font-bold">
                  <th className="py-2">নং</th>
                  <th className="py-2">পণ্য ও মডেল বিবরণ</th>
                  <th className="py-2 text-center">পরিমাণ</th>
                  <th className="py-2 text-right">দর</th>
                  <th className="py-2 text-right">মোট (৳)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoice.items.map((item, index) => (
                  <tr key={index}>
                    <td className="py-2.5 text-slate-400 font-mono">{index + 1}</td>
                    <td className="py-2.5 font-medium text-slate-900">
                      <strong className="block">{item.brand} {item.modelNumber}</strong>
                      <span className="text-[10px] text-slate-500 font-normal">
                        {item.category}
                      </span>
                    </td>
                    <td className="py-2.5 text-center font-bold text-slate-800">
                      {item.quantity}
                    </td>
                    <td className="py-2.5 text-right font-medium text-slate-700">
                      ৳{item.unitPrice}
                    </td>
                    <td className="py-2.5 text-right font-bold text-slate-900">
                      ৳{item.totalPrice.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Invoice Summary Totals */}
          <div className="pt-3 border-t-2 border-slate-200 space-y-1.5 text-xs">
            <div className="flex justify-between text-slate-600">
              <span>মোট আইটেম:</span>
              <span className="font-semibold">{invoice.totalQuantity} পিস</span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>সাবটোটাল:</span>
              <span className="font-semibold">৳{invoice.totalSalesAmount.toLocaleString()}</span>
            </div>
            {invoice.discount > 0 && (
              <div className="flex justify-between text-rose-600">
                <span>ডিসকাউন্ট:</span>
                <span className="font-semibold">- ৳{invoice.discount.toLocaleString()}</span>
              </div>
            )}
            <div className="flex justify-between text-sm font-black text-slate-900 pt-2 border-t border-slate-200">
              <span>সর্বমোট প্রদেয় বিল:</span>
              <span className="text-base text-slate-900">৳{invoice.finalPayableAmount.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-emerald-700 font-bold">
              <span>জমা / পেইড ({invoice.paymentMethod}):</span>
              <span>৳{invoice.paidAmount.toLocaleString()}</span>
            </div>
            {invoice.dueAmount > 0 ? (
              <div className="flex justify-between text-amber-800 font-extrabold p-2 bg-amber-50 rounded-xl border border-amber-200">
                <span>বর্তমান বাকি (Due):</span>
                <span className="text-sm">৳{invoice.dueAmount.toLocaleString()}</span>
              </div>
            ) : (
              <div className="text-center py-1 text-emerald-600 font-bold text-[11px] bg-emerald-50 rounded-lg">
                ✓ সম্পূর্ণ বিল পরিশোধিত
              </div>
            )}

            {/* Merchant-Only Net Profit View */}
            {showProfit && (
              <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 text-xs font-bold flex justify-between">
                <span>ব্যবসায়িক নিট লাভ (Internal Copy):</span>
                <span>৳{invoice.netProfit.toLocaleString()}</span>
              </div>
            )}
          </div>

          {/* Footer Note */}
          <div className="pt-4 border-t border-dashed border-slate-300 text-center text-[10px] text-slate-400 space-y-1">
            <p className="font-medium text-slate-600">
              সোল্ডারিং বা রিফ্লেক্স করার পর এলসিডি ফেরত গ্রহণযোগ্য নয়।
            </p>
            <p>Developer: Jayed Ahmed • Balaganj, Sylhet</p>
          </div>
        </div>

        {/* BOTTOM ACTION BUTTONS (Share, Print, Copy) - Hidden in Print */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 print:hidden">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl bg-white border border-slate-200 text-slate-700 font-bold text-xs hover:bg-slate-100 cursor-pointer"
          >
            বন্ধ করুন
          </button>

          <div className="flex items-center gap-2">
            {/* WhatsApp */}
            <button
              onClick={handleWhatsAppShare}
              className="px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <MessageCircle className="w-4 h-4" />
              <span>হোয়াটসঅ্যাপ</span>
            </button>

            {/* System Share */}
            <button
              onClick={handleSystemShare}
              className="px-3.5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              {copied ? <Check className="w-4 h-4" /> : <Share2 className="w-4 h-4" />}
              <span>{copied ? 'কপি হয়েছে' : 'শেয়ার'}</span>
            </button>

            {/* Print */}
            <button
              onClick={handlePrint}
              className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>প্রিন্ট / Print</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
