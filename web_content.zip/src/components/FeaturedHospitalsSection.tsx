import React from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import { 
  Building2, 
  MapPin, 
  Award, 
  Star, 
  Send, 
  ArrowLeft, 
  ArrowRight,
  ShieldCheck,
  Crown
} from 'lucide-react';

export const FeaturedHospitalsSection: React.FC = () => {
  const { language, setCurrentView, openRequestModalForService, medicalCenters } = useApp();
  const t = translations[language];
  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  return (
    <section className="py-20 bg-zinc-950 text-white border-b border-[#D4AF37]/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 bg-black text-amber-300 text-xs font-bold px-3.5 py-1.5 rounded-full mb-3 border border-[#D4AF37]/40 shadow-sm">
              <Crown className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>{isAr ? 'الاعتماد الدولي والمحلي' : 'Accreditation & Quality'}</span>
            </div>
            <h2 className="text-3xl font-black bg-gradient-to-r from-white via-zinc-100 to-amber-200 bg-clip-text text-transparent">
              {isAr ? 'صروح طبية معتمدة وشراكات مرجعية' : 'Accredited Hospitals & Referral Hubs'}
            </h2>
            <p className="text-xs sm:text-sm text-zinc-400 mt-1">
              {isAr ? 'مستشفيات حائزة على الاعتماد الوطني GAHAR واللجنة الدولية JCI' : 'Certified according to national and international healthcare standards'}
            </p>
          </div>

          <button
            onClick={() => {
              setCurrentView('medical');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-2 text-xs sm:text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors self-start md:self-auto"
          >
            <span>{isAr ? 'استعراض كل المستشفيات والأطباء' : 'View all hospitals & doctors'}</span>
            <ArrowIcon className="w-4 h-4 text-[#D4AF37]" />
          </button>
        </div>

        {/* 2-Column Spotlight Cards in Black & Gold */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {medicalCenters.slice(0, 2).map(center => (
            <div 
              key={center.id}
              className="bg-black/95 rounded-3xl border border-[#D4AF37]/30 overflow-hidden shadow-xl hover:shadow-[0_0_25px_rgba(212,175,55,0.2)] transition-all duration-300 flex flex-col justify-between group hover:border-[#D4AF37]"
            >
              <div>
                <div className="relative h-56 overflow-hidden">
                  <img 
                    src={center.imageUrl} 
                    alt={isAr ? center.nameAr : center.nameEn}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
                  
                  <div className="absolute top-3 right-3 rtl:right-3 rtl:left-auto ltr:left-3 ltr:right-auto flex gap-1.5">
                    {center.accreditation.map((acc, aIdx) => (
                      <span key={aIdx} className="bg-black/90 backdrop-blur-md text-[#D4AF37] border border-[#D4AF37]/50 text-[10px] font-bold px-2.5 py-0.5 rounded-full shadow-md">
                        {acc}
                      </span>
                    ))}
                  </div>

                  <div className="absolute bottom-3 right-3 rtl:right-3 rtl:left-auto ltr:left-3 ltr:right-auto text-white">
                    <div className="flex items-center gap-1 text-xs text-amber-300 mb-0.5">
                      <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
                      <span>{center.city}</span>
                    </div>
                    <h3 className="text-lg font-bold text-white">
                      {isAr ? center.nameAr : center.nameEn}
                    </h3>
                  </div>
                </div>

                <div className="p-6 space-y-4">
                  <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
                    {isAr ? center.descriptionAr : center.descriptionEn}
                  </p>

                  <div className="flex flex-wrap gap-1.5">
                    {center.specialties.map((sp, sIdx) => (
                      <span key={sIdx} className="text-[11px] bg-zinc-900 text-amber-200 border border-zinc-800 px-2.5 py-1 rounded-md">
                        {sp}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="p-6 pt-0 flex gap-2">
                <button
                  onClick={() => openRequestModalForService('medical_sector')}
                  className="flex-1 py-3 bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 shadow-md shadow-amber-500/20"
                >
                  <Send className="w-3.5 h-3.5 text-black" />
                  <span>{isAr ? 'طلب التنسيق مع هذا المجمع' : 'Coordinate Inquiry'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
