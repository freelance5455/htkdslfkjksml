import React, { useState } from 'react';
import { ArrowRightLeft, Coins, CheckCircle2, Sparkles, ArrowUpRight, ShieldCheck } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';

export const MoneyConverterWidget: React.FC<{ onRequestWithdrawal: () => void }> = ({ onRequestWithdrawal }) => {
  const { currentUser, systemSettings, language, t } = useApp();
  const [coinInput, setCoinInput] = useState<number>(currentUser?.coins || 100);
  const [convertedNotice, setConvertedNotice] = useState(false);

  const rate = systemSettings.coinsPerCurrencyUnit || 1;
  const inrValue = Number((coinInput / rate).toFixed(2));
  const isVip = currentUser?.membershipTier && currentUser.membershipTier !== 'basic';

  const handleQuickConvert = () => {
    confetti({ particleCount: 50, spread: 50 });
    setConvertedNotice(true);
    setTimeout(() => setConvertedNotice(false), 3000);
  };

  return (
    <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white border border-indigo-800/60 shadow-lg space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-indigo-600/30 text-indigo-400 border border-indigo-500/40 flex items-center justify-center">
            <ArrowRightLeft className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm sm:text-base text-white">
              {language === 'bn' ? 'কয়েন ও নগদ রুপি কনভার্টার (Coins to INR)' : 'Coins & Rupee (₹) Instant Converter'}
            </h3>
            <p className="text-xs text-indigo-200">
              1 Coin = ₹1.00 INR (1:1 Direct Cash Exchange)
            </p>
          </div>
        </div>

        {isVip ? (
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1.5 self-start sm:self-auto">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Unlimited Withdrawal Active</span>
          </span>
        ) : (
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 self-start sm:self-auto">
            Standard Member
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
        {/* Coin input */}
        <div className="p-3.5 rounded-2xl bg-black/40 border border-slate-700 space-y-1">
          <span className="text-[11px] text-slate-400 uppercase font-semibold">Coins to Convert</span>
          <div className="flex items-center gap-2">
            <span className="text-xl">🪙</span>
            <input
              type="number"
              min={1}
              value={coinInput}
              onChange={(e) => setCoinInput(Math.max(0, Number(e.target.value)))}
              className="w-full bg-transparent text-xl font-black text-amber-300 focus:outline-hidden"
            />
          </div>
        </div>

        {/* INR Equivalent */}
        <div className="p-3.5 rounded-2xl bg-black/40 border border-slate-700 space-y-1">
          <span className="text-[11px] text-emerald-400 uppercase font-semibold">Cash Value in INR (₹)</span>
          <div className="flex items-center gap-2">
            <span className="text-xl font-bold text-emerald-400">₹</span>
            <span className="text-xl font-black text-white">
              {inrValue.toLocaleString()} INR
            </span>
          </div>
        </div>
      </div>

      {convertedNotice && (
        <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>Coins successfully valued at ₹{inrValue} INR! Ready for instant withdrawal.</span>
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
        <p className="text-[11px] text-slate-400">
          * Instant payouts supported via UPI (GPay, PhonePe, Paytm) & IMPS Bank Transfer.
        </p>

        <button
          onClick={onRequestWithdrawal}
          className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition-all cursor-pointer"
        >
          <span>Withdraw ₹{inrValue} Now</span>
          <ArrowUpRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
