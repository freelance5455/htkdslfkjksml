import { useState, useEffect } from 'react';
import { QrCode, Maximize2, Minimize2, Copy, Check, Download, ShieldCheck, WifiOff, Sparkles, RefreshCw } from 'lucide-react';
import { generateQRCodeDataURL } from '../../utils/qrcode';
import { Language } from '../../types';

interface ScannableQRCodeProps {
  data: string;
  documentTitle: string;
  documentNumber: string;
  passengerName?: string;
  language: Language;
  size?: number;
  className?: string;
  showExpandButton?: boolean;
}

export function ScannableQRCode({
  data,
  documentTitle,
  documentNumber,
  passengerName,
  language,
  size = 180,
  className = '',
  showExpandButton = true,
}: ScannableQRCodeProps) {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);

  useEffect(() => {
    let isMounted = true;
    setIsLoading(true);

    generateQRCodeDataURL(data, {
      width: size * 2, // High resolution for crisp scanning
      margin: 2,
      errorCorrectionLevel: 'M',
      color: {
        dark: '#050814',
        light: '#ffffff',
      },
    })
      .then((url) => {
        if (isMounted) {
          setQrDataUrl(url);
          setIsLoading(false);
        }
      })
      .catch((err) => {
        console.error('Error generating QR code:', err);
        if (isMounted) setIsLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [data, size]);

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(data).then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      });
    }
  };

  const handleDownloadQR = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!qrDataUrl) return;
    const link = document.createElement('a');
    link.href = qrDataUrl;
    link.download = `TAKI-GO-QR-${documentNumber}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 2500);
  };

  return (
    <>
      {/* Standard Wallet Card QR Box */}
      <div className={`flex flex-col items-center justify-center ${className}`}>
        <div
          onClick={() => showExpandButton && setIsModalOpen(true)}
          className={`bg-white p-3 sm:p-4 rounded-2xl flex flex-col items-center justify-center border-2 border-slate-900 shadow-xl transition-all relative group ${
            showExpandButton ? 'cursor-pointer hover:shadow-[0_0_20px_rgba(0,240,255,0.4)]' : ''
          }`}
          title={language === 'ar' ? 'انقر لتكبير رمز QR للبوابات الإلكترونية' : 'Click to enlarge for gate scanner'}
        >
          {isLoading ? (
            <div
              style={{ width: size, height: size }}
              className="flex flex-col items-center justify-center bg-slate-100 rounded-lg text-slate-400 gap-2"
            >
              <RefreshCw className="w-6 h-6 animate-spin text-cyan-600" />
              <span className="text-[10px] font-mono">Generating QR...</span>
            </div>
          ) : qrDataUrl ? (
            <div className="relative">
              <img
                src={qrDataUrl}
                alt={`Scannable QR for ${documentNumber}`}
                width={size}
                height={size}
                className="rounded-lg object-contain block select-none"
              />
              {showExpandButton && (
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center text-white backdrop-blur-[2px]">
                  <span className="text-xs font-bold bg-cyan-600 px-2.5 py-1 rounded-full shadow-lg flex items-center gap-1">
                    <Maximize2 className="w-3.5 h-3.5" />
                    {language === 'ar' ? 'تكبير للمسح' : 'Enlarge'}
                  </span>
                </div>
              )}
            </div>
          ) : (
            <div
              style={{ width: size, height: size }}
              className="flex items-center justify-center bg-slate-100 text-rose-500 text-xs font-mono"
            >
              QR Error
            </div>
          )}

          {/* Quick Info bar under QR inside white card */}
          <div className="w-full mt-2 pt-2 border-t border-slate-200 flex items-center justify-between text-slate-800 text-[10px] font-mono">
            <span className="font-black tracking-tight text-blue-900">TAKI-GO</span>
            <span className="bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded text-[9px] flex items-center gap-1">
              <WifiOff className="w-2.5 h-2.5" />
              {language === 'ar' ? 'بدون إنترنت' : 'Offline'}
            </span>
          </div>
        </div>

        {/* Action Pills Under QR */}
        <div className="flex items-center gap-2 mt-3">
          {showExpandButton && (
            <button
              type="button"
              onClick={() => setIsModalOpen(true)}
              className="px-2.5 py-1 rounded-lg bg-cyan-950/80 hover:bg-cyan-900/80 border border-cyan-500/30 text-cyan-300 text-[11px] font-semibold flex items-center gap-1 transition-colors cursor-pointer"
            >
              <Maximize2 className="w-3 h-3" />
              <span>{language === 'ar' ? 'وضع الماسح' : 'Scanner Mode'}</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleCopy}
            className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white text-[11px] font-mono flex items-center gap-1 transition-colors cursor-pointer"
            title="Copy QR Data string"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            <span>{copied ? (language === 'ar' ? 'تم النسخ!' : 'Copied!') : (language === 'ar' ? 'نسخ الكود' : 'Copy Data')}</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadQR}
            className="p-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-cyan-300 transition-colors cursor-pointer"
            title={language === 'ar' ? 'تحميل صورة الرمز QR' : 'Save QR Image'}
            aria-label="Download QR Code"
          >
            <Download className="w-3.5 h-3.5" />
          </button>
        </div>

        {downloadSuccess && (
          <p className="text-[10px] text-emerald-400 mt-1 font-mono">
            {language === 'ar' ? '✓ تم حفظ صورة الباركود في التنزيلات' : '✓ QR Image saved to downloads'}
          </p>
        )}
      </div>

      {/* Airport Gate Scanner Fullscreen Modal */}
      {isModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setIsModalOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm max-h-[92vh] overflow-y-auto bg-white rounded-3xl p-5 sm:p-6 text-slate-950 shadow-2xl border-4 border-cyan-400 space-y-3.5 animate-in fade-in zoom-in-95 duration-150"
          >
            {/* Modal Header */}
            <div className="flex items-start justify-between pb-2.5 border-b border-slate-200">
              <div>
                <span className="text-[10px] font-black uppercase text-blue-600 tracking-wider">
                  {language === 'ar' ? 'وضع المسح الضوئي في المطار' : 'Airport Gate Scanner Mode'}
                </span>
                <h3 className="text-base font-black text-slate-950 leading-tight">
                  {documentTitle}
                </h3>
                <p className="text-xs text-slate-500 font-mono">
                  {documentNumber} {passengerName ? `• ${passengerName}` : ''}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center cursor-pointer font-bold"
                aria-label="Close"
              >
                ✕
              </button>
            </div>

            {/* High-Contrast Maximum Brightness QR Display */}
            <div className="flex flex-col items-center justify-center bg-white p-1 rounded-2xl">
              {qrDataUrl && (
                <img
                  src={qrDataUrl}
                  alt={`High-contrast QR for ${documentNumber}`}
                  className="w-52 h-52 sm:w-56 sm:h-56 object-contain rounded-lg block shadow-sm border border-slate-100"
                />
              )}
              <div className="mt-2 text-center">
                <span className="text-[11px] font-bold text-slate-800 block">
                  {language === 'ar' ? 'مرّر هذا الرمز أمام قارئ البوابة أو موظف الاستقبال' : 'Present this QR code to the gate reader'}
                </span>
                <span className="text-[10px] font-mono text-emerald-700 font-semibold inline-flex items-center gap-1 mt-0.5">
                  <WifiOff className="w-3 h-3" />
                  {language === 'ar' ? 'متاح 100% دون اتصال بالإنترنت' : '100% Available Offline'}
                </span>
              </div>
            </div>

            {/* Encoded Data Display */}
            <div className="bg-slate-100 p-2.5 rounded-xl border border-slate-200">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-bold text-slate-500">
                  {language === 'ar' ? 'البيانات الرقمية المشفرة:' : 'Encoded QR Payload:'}
                </span>
                <button
                  type="button"
                  onClick={handleCopy}
                  className="text-[10px] text-blue-600 hover:underline flex items-center gap-1 font-semibold"
                >
                  {copied ? <Check className="w-2.5 h-2.5 text-emerald-600" /> : <Copy className="w-2.5 h-2.5" />}
                  {copied ? 'Copied' : 'Copy'}
                </button>
              </div>
              <p className="text-[11px] font-mono font-bold text-slate-800 break-all bg-white p-1.5 rounded border border-slate-200">
                {data}
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={handleDownloadQR}
                className="flex-1 h-10 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{language === 'ar' ? 'حفظ الصورة في الهاتف' : 'Save QR to Photos'}</span>
              </button>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 h-10 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs transition-colors cursor-pointer"
              >
                {language === 'ar' ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
