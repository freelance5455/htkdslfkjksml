import React, { useState } from 'react';
import { 
  Wallet, 
  ArrowUpRight, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  Coins, 
  CreditCard, 
  Building2, 
  Smartphone, 
  AlertCircle,
  FileText,
  ShieldCheck,
  Zap,
  ArrowRight,
  TrendingUp,
  History,
  Plus,
  Copy,
  Check,
  Filter
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp, isSubhodipUser } from '../../context/AppContext';
import { WithdrawalMethod } from '../../types';
import { WithdrawalHistory } from './WithdrawalHistory';
import { DepositModal } from './DepositModal';
import { SbiBankVerificationCard } from '../bank/SbiBankVerificationCard';

interface WalletViewProps {
  onOpenInvestments?: () => void;
}

export const WalletView: React.FC<WalletViewProps> = ({ onOpenInvestments }) => {
  const { 
    currentUser, 
    systemSettings, 
    withdrawals, 
    createWithdrawalRequest, 
    transactions,
    sbiBankAccount,
    language, 
    t 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'withdrawals' | 'transactions'>('withdrawals');
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
  const [copiedTxnId, setCopiedTxnId] = useState<string | null>(null);
  const [txnFilter, setTxnFilter] = useState<'all' | 'deposits' | 'withdrawals' | 'tasks'>('all');

  // Withdrawal form state
  const [selectedMethod, setSelectedMethod] = useState<'upi' | 'bank_transfer'>('upi');
  const [withdrawCoins, setWithdrawCoins] = useState<number>(systemSettings.minWithdrawalCoins || 6000);
  const [accountDetails, setAccountDetails] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const currentCoins = currentUser?.coins || 450;
  const userWithdrawals = withdrawals.filter(w => {
    if (isSubhodipUser(currentUser)) {
      return w.userId === currentUser?.id || 
             w.userId === 'user-subhodip-7654' || 
             w.userName?.toLowerCase().includes('subhodip');
    }
    return w.userId === currentUser?.id && 
           !w.userName?.toLowerCase().includes('subhodip') &&
           !w.accountDetails?.includes('7076216864');
  });
  const userTransactions = transactions.filter(tItem => tItem.userId === currentUser?.id);

  const isVipUser = currentUser?.membershipTier && ['vip1', 'vip2', 'vip3', 'vip4', 'vip5', 'pro', 'premium'].includes(currentUser.membershipTier);
  const minWithdrawalAllowed = isVipUser ? 10 : (systemSettings.minWithdrawalCoins || 100);

  const pendingWithdrawalCoins = userWithdrawals
    .filter(w => w.status === 'pending')
    .reduce((sum, w) => sum + w.amountCoins, 0);

  const lifetimeEarnings = currentUser?.lifetimeCoins || 820;
  const totalWithdrawn = currentUser?.withdrawnCoins || 300;

  const rate = systemSettings.coinsPerCurrencyUnit || 100;
  const estimatedINR = (currentCoins / rate).toFixed(2);
  const withdrawEquivalentINR = (withdrawCoins / rate).toFixed(2);

  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    if (!isVipUser && withdrawCoins < minWithdrawalAllowed) {
      setErrorMessage(`Minimum withdrawal is ${minWithdrawalAllowed} Coins for standard members.`);
      return;
    }

    // Secure validation for UPI and Bank Transfer
    if (selectedMethod === 'upi') {
      if (!accountDetails.includes('@') || accountDetails.trim().length < 5) {
        setErrorMessage('Please enter a valid secure UPI ID containing "@" (e.g., name@okhdfcbank or number@paytm).');
        return;
      }
    } else if (selectedMethod === 'bank_transfer') {
      if (accountDetails.trim().length < 8) {
        setErrorMessage('Please enter valid Bank Account Number, IFSC Code, and Account Holder Name.');
        return;
      }
    }

    const res = createWithdrawalRequest(withdrawCoins, selectedMethod, accountDetails);
    if (res.success) {
      setSuccessMessage(`Payout request of ${withdrawCoins} Coins submitted successfully via ${selectedMethod === 'upi' ? 'UPI' : 'Bank Transfer'} (${accountDetails})!`);
      confetti({ particleCount: 50, spread: 60 });
      setAccountDetails('');
      setTimeout(() => {
        setShowWithdrawModal(false);
        setSuccessMessage('');
      }, 2000);
    } else {
      setErrorMessage(res.message);
    }
  };

  return (
    <div className="max-w-xl mx-auto space-y-4 pb-24 animate-in fade-in duration-200">
      
      {/* Gold & Silver Investment Quick Access Card */}
      <div 
        onClick={() => onOpenInvestments?.()}
        className="p-4 rounded-3xl bg-gradient-to-r from-amber-950/80 via-slate-900 to-yellow-950/80 border border-amber-500/40 shadow-xl flex items-center justify-between cursor-pointer hover:border-amber-400 transition-all group"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center justify-center text-lg font-bold">
            🏆
          </div>
          <div>
            <h3 className="text-xs sm:text-sm font-black text-white group-hover:text-amber-300 transition-colors">
              Gold & Silver Investments Portfolio
            </h3>
            <p className="text-[10px] text-slate-300">
              Manage 24K 99.9% digital gold & silver. Min Gold Buy ₹300 • Aadhaar KYC Verified.
            </p>
          </div>
        </div>
        <span className="text-xs font-bold text-amber-400 group-hover:translate-x-1 transition-transform">
          View →
        </span>
      </div>

      {/* Wallet Header & Action */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-900/90 border border-slate-800 flex items-center justify-between gap-3 shadow-lg">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Wallet className="w-5 h-5 text-emerald-400" />
            <h1 className="text-lg font-black text-white">Wallet Dashboard</h1>
          </div>
          <p className="text-xs text-slate-400">
            Real-time balance, earnings, and payout tracking
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsDepositModalOpen(true)}
            className="px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs shadow-md shadow-emerald-600/20 active:scale-95 transition-all cursor-pointer flex items-center gap-1.5 shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Deposit</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setWithdrawCoins(systemSettings.minWithdrawalCoins || 6000);
              setShowWithdrawModal(true);
            }}
            className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 hover:border-slate-600 font-black text-xs active:scale-95 transition-all cursor-pointer flex items-center gap-1.5 shrink-0"
          >
            <span>Withdraw</span>
            <ArrowUpRight className="w-4 h-4 text-emerald-400" />
          </button>
        </div>
      </div>

      {/* 4 Clean Wallet Metrics Cards */}
      <div className="grid grid-cols-2 gap-3">
        {/* Available Coins */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-950/40 via-slate-900 to-slate-950 border border-emerald-800/50 space-y-1">
          <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-400 block">
            Available Coins
          </span>
          <h3 className="text-2xl font-black text-white tracking-tight">
            {currentCoins.toLocaleString()}
          </h3>
          <p className="text-[11px] font-semibold text-emerald-300">
            ≈ ₹{estimatedINR} INR
          </p>
        </div>

        {/* Pending Earnings */}
        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-1">
          <span className="text-[10px] uppercase font-bold tracking-wider text-amber-400 block">
            Pending Earnings
          </span>
          <h3 className="text-2xl font-black text-white tracking-tight">
            {pendingWithdrawalCoins.toLocaleString()}
          </h3>
          <p className="text-[11px] font-semibold text-slate-400">
            In Verification
          </p>
        </div>

        {/* Lifetime Earnings */}
        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-1">
          <span className="text-[10px] uppercase font-bold tracking-wider text-purple-400 block">
            Lifetime Earnings
          </span>
          <h3 className="text-2xl font-black text-white tracking-tight">
            {lifetimeEarnings.toLocaleString()}
          </h3>
          <p className="text-[11px] font-semibold text-slate-400">
            Total Earned
          </p>
        </div>

        {/* Total Withdrawn */}
        <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-1">
          <span className="text-[10px] uppercase font-bold tracking-wider text-blue-400 block">
            Total Withdrawn
          </span>
          <h3 className="text-2xl font-black text-white tracking-tight">
            {totalWithdrawn.toLocaleString()}
          </h3>
          <p className="text-[11px] font-semibold text-slate-400">
            Successfully Paid
          </p>
        </div>
      </div>

      {/* SBI Bank Account Verification Section */}
      <SbiBankVerificationCard />

      {/* Navigation Tabs: Withdrawal History / Transaction History */}
      <div className="flex border-b border-slate-800 gap-2 text-xs font-bold pt-2">
        <button
          type="button"
          onClick={() => setActiveTab('withdrawals')}
          className={`pb-2.5 px-3 border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'withdrawals'
              ? 'border-emerald-500 text-emerald-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <History className="w-3.5 h-3.5" />
          <span>Withdrawal History ({userWithdrawals.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('transactions')}
          className={`pb-2.5 px-3 border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'transactions'
              ? 'border-emerald-500 text-emerald-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Transaction History ({userTransactions.length})</span>
        </button>
      </div>

      {/* Tab 1: Withdrawal History Section */}
      {activeTab === 'withdrawals' && (
        <WithdrawalHistory
          withdrawals={userWithdrawals}
          onOpenWithdrawModal={() => setShowWithdrawModal(true)}
          currencyRate={rate}
        />
      )}

      {/* Tab 2: Transaction History */}
      {activeTab === 'transactions' && (
        <div className="space-y-3">
          {/* Sub-Filters */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] no-scrollbar">
            {[
              { id: 'all', label: 'All Transactions' },
              { id: 'deposits', label: 'Deposits' },
              { id: 'withdrawals', label: 'Withdrawals' },
              { id: 'tasks', label: 'Task Rewards' }
            ].map(f => (
              <button
                key={f.id}
                onClick={() => setTxnFilter(f.id as any)}
                className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all cursor-pointer ${
                  txnFilter === f.id
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {(() => {
            const filteredTxns = userTransactions.filter(tx => {
              if (txnFilter === 'deposits') return tx.title.toLowerCase().includes('deposit') || tx.coins > 500;
              if (txnFilter === 'withdrawals') return tx.coins < 0 || tx.title.toLowerCase().includes('withdraw');
              if (txnFilter === 'tasks') return tx.coins > 0 && !tx.title.toLowerCase().includes('deposit');
              return true;
            });

            if (filteredTxns.length === 0) {
              return (
                <div className="p-8 text-center text-slate-500 text-xs rounded-2xl bg-slate-900/40 border border-slate-800 space-y-2">
                  <div className="w-10 h-10 rounded-2xl bg-slate-800 text-slate-400 flex items-center justify-center mx-auto">
                    <History className="w-5 h-5" />
                  </div>
                  <p className="font-medium text-slate-300">No transactions found under this category.</p>
                  <p className="text-[11px] text-slate-500">Complete tasks or add funds to get started.</p>
                </div>
              );
            }

            return filteredTxns.map((tx) => {
              const txnId = `TXN-${tx.id.replace(/[^a-zA-Z0-9]/g, '').substring(0, 10).toUpperCase() || '73892147'}`;
              const isPositive = tx.coins >= 0;
              const inrVal = (Math.abs(tx.coins) / rate).toFixed(2);

              return (
                <div
                  key={tx.id}
                  className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2 hover:border-slate-700/80 transition-all text-xs shadow-sm"
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[10px] text-slate-400 bg-slate-950 px-2 py-0.5 rounded-md border border-slate-800">
                        {txnId}
                      </span>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(txnId);
                          setCopiedTxnId(txnId);
                          setTimeout(() => setCopiedTxnId(null), 2000);
                        }}
                        className="text-slate-400 hover:text-emerald-400 transition-colors cursor-pointer p-0.5"
                        title="Copy Transaction ID"
                      >
                        {copiedTxnId === txnId ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      </button>
                    </div>

                    <span className="px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-wider bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                      Verified & Completed
                    </span>
                  </div>

                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <h4 className="font-bold text-white text-xs">{tx.title}</h4>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        {new Date(tx.timestamp).toLocaleString()}
                      </p>
                    </div>

                    <div className="text-right">
                      <span className={`font-black text-xs block ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {isPositive ? `+${tx.coins.toLocaleString()}` : tx.coins.toLocaleString()} 🪙
                      </span>
                      <span className="text-[10px] text-slate-400">
                        ≈ ₹{inrVal} INR
                      </span>
                    </div>
                  </div>
                </div>
              );
            });
          })()}
        </div>
      )}

      {/* Deposit Modal */}
      <DepositModal
        isOpen={isDepositModalOpen}
        onClose={() => setIsDepositModalOpen(false)}
      />

      {/* Withdrawal Modal */}
      {showWithdrawModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl relative space-y-4">
            <button
              onClick={() => setShowWithdrawModal(false)}
              className="absolute top-4 right-4 p-1.5 rounded-xl text-slate-400 hover:text-white"
            >
              ✕
            </button>

            <div className="space-y-1">
              <h3 className="text-base font-black text-white">Request Payout</h3>
              <p className="text-xs text-slate-400">
                Available: <strong className="text-emerald-400">{currentCoins} Coins</strong>
              </p>
            </div>

            {errorMessage && (
              <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-semibold">
                {errorMessage}
              </div>
            )}

            {successMessage && (
              <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
                {successMessage}
              </div>
            )}

            <form onSubmit={handleWithdrawSubmit} className="space-y-3 text-xs">
              {/* VIP Quick ₹1,000 Task Withdrawal Preset */}
              <div className="p-3 rounded-2xl bg-gradient-to-r from-amber-500/15 via-yellow-500/10 to-emerald-500/15 border border-amber-500/40 flex items-center justify-between gap-2 flex-wrap">
                <div className="space-y-0.5">
                  <span className="font-black text-amber-300 block text-xs flex items-center gap-1">
                    <span>⚡</span>
                    <span>VIP Quick ₹1,000 Task Withdrawal</span>
                  </span>
                  <span className="text-[10px] text-slate-300">
                    Instant UPI cashout for VIP / Gold Mine Investors
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const targetCoins = 1000 * (systemSettings.coinsPerCurrencyUnit || 1000);
                    setWithdrawCoins(targetCoins);
                    setSelectedMethod('upi');
                    if (isSubhodipUser(currentUser)) {
                      setAccountDetails('subhodip***@oksbi');
                    }
                  }}
                  className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs cursor-pointer shadow-md shadow-amber-500/20 active:scale-95 transition-all shrink-0"
                >
                  ⚡ Select ₹1,000
                </button>
              </div>

              {/* Payment Methods */}
              <div className="space-y-1">
                <label className="font-bold text-slate-300 block">Payment Method</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedMethod('upi')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      selectedMethod === 'upi'
                        ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                    <span>UPI</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setSelectedMethod('bank_transfer');
                      if (sbiBankAccount?.status === 'verified') {
                        setAccountDetails(`${sbiBankAccount.accountHolderName} • SBI A/C ${sbiBankAccount.maskedAccountNumber} • IFSC: ${sbiBankAccount.ifscCode}`);
                      }
                    }}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      selectedMethod === 'bank_transfer'
                        ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <Building2 className="w-3.5 h-3.5" />
                    <span>Bank Account</span>
                  </button>
                </div>
              </div>

              {/* Amount Coins */}
              <div className="space-y-1">
                <label className="font-bold text-slate-300 block">Withdrawal Coins</label>
                <input
                  type="number"
                  required
                  min={minWithdrawalAllowed}
                  max={currentCoins}
                  value={withdrawCoins}
                  onChange={(e) => setWithdrawCoins(Number(e.target.value))}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono text-xs focus:outline-none focus:border-emerald-500"
                />
                <p className="text-[11px] text-slate-500">
                  Estimated Payout: ≈ ₹{withdrawEquivalentINR} INR
                </p>
              </div>

              {/* Account Details */}
              <div className="space-y-1">
                <label className="font-bold text-slate-300 block flex items-center justify-between">
                  <span>{selectedMethod === 'upi' ? 'Secure UPI ID (e.g. mobile@upi)' : 'Bank Account Number, IFSC & Name'}</span>
                  <span className="text-[10px] text-emerald-400 font-mono uppercase bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                    {selectedMethod === 'upi' ? 'Instant UPI' : 'NEFT / IMPS'}
                  </span>
                </label>
                <input
                  type="text"
                  required
                  value={accountDetails}
                  onChange={(e) => setAccountDetails(e.target.value)}
                  placeholder={selectedMethod === 'upi' ? 'name@okhdfcbank / number@paytm' : 'Account No, IFSC Code, Holder Name'}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-emerald-500 font-mono"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-md shadow-emerald-600/20 active:scale-95 transition-all cursor-pointer mt-2"
              >
                Submit Withdrawal
              </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
