import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PaidGig, GigCategory } from '../../types';
import {
  Wallet,
  DollarSign,
  Plus,
  Send,
  ArrowDownToLine,
  CheckCircle2,
  Clock,
  Briefcase,
  Search,
  X,
  Sparkles,
  ArrowUpRight,
  ArrowDownLeft,
  Filter,
} from 'lucide-react';

export const GigsAndWalletView: React.FC = () => {
  const {
    walletBalance,
    gigs,
    walletTransactions,
    claimGig,
    completeGig,
    postGig,
    sendTransfer,
    withdrawFunds,
    currentUser,
    activeSubView,
    setActiveSubView,
  } = useApp();

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [isPostModalOpen, setIsPostModalOpen] = useState(false);
  const [isSubmitWorkModalOpen, setIsSubmitWorkModalOpen] = useState(false);
  const [targetGigToComplete, setTargetGigToComplete] = useState<PaidGig | null>(null);
  const [submissionNotes, setSubmissionNotes] = useState('');

  // Transfer & Withdraw Modal states
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false);
  const [transferRecipient, setTransferRecipient] = useState('');
  const [transferAmount, setTransferAmount] = useState('25.00');
  const [transferNote, setTransferNote] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('100.00');
  const [withdrawDestination, setWithdrawDestination] = useState('Chase Checking (••••4021)');
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);

  // New gig post state
  const [gigTitle, setGigTitle] = useState('');
  const [gigCategory, setGigCategory] = useState<GigCategory>('Academic Tutoring');
  const [gigReward, setGigReward] = useState('50');
  const [gigHours, setGigHours] = useState('2 hours');
  const [gigDeadline, setGigDeadline] = useState('2026-11-06');
  const [gigDescription, setGigDescription] = useState('');

  const categories = [
    'All',
    'Academic Tutoring',
    'Campus Logistics',
    'Technical Support',
    'Design & Content',
    'Research & Data',
  ];

  const filteredGigs = gigs.filter((gig) => {
    const matchesCat = selectedCategory === 'All' || gig.category === selectedCategory;
    const matchesSearch =
      gig.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      gig.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      gig.posterName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const handlePostGig = (e: React.FormEvent) => {
    e.preventDefault();
    if (!gigTitle.trim()) return;

    postGig({
      title: gigTitle.trim(),
      category: gigCategory,
      reward: parseFloat(gigReward) || 20,
      description: gigDescription.trim() || 'Complete deliverables according to specifications.',
      estimatedHours: gigHours.trim() || '1-2 hours',
      deadline: gigDeadline,
    });

    setIsPostModalOpen(false);
    setGigTitle('');
    setGigDescription('');
    showSuccessToast('Paid gig bounty published to campus board!');
  };

  const handleCompleteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetGigToComplete) return;

    completeGig(targetGigToComplete.id, submissionNotes.trim() || 'Work completed and submitted.');
    setIsSubmitWorkModalOpen(false);
    setTargetGigToComplete(null);
    setSubmissionNotes('');
    showSuccessToast(`Reward of $${targetGigToComplete.reward.toFixed(2)} credited to your wallet!`);
  };

  const handleSendTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(transferAmount);
    if (!amt || amt <= 0) return;

    const success = sendTransfer(transferRecipient.trim() || 'Colleague', amt, transferNote);
    if (success) {
      setIsTransferModalOpen(false);
      setTransferAmount('25.00');
      setTransferRecipient('');
      setTransferNote('');
      showSuccessToast(`Transferred $${amt.toFixed(2)} successfully!`);
    } else {
      alert('Insufficient wallet balance for this transfer.');
    }
  };

  const handleWithdrawFunds = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(withdrawAmount);
    if (!amt || amt <= 0) return;

    const success = withdrawFunds(amt, withdrawDestination);
    if (success) {
      setIsWithdrawModalOpen(false);
      setWithdrawAmount('100.00');
      showSuccessToast(`Withdrawal of $${amt.toFixed(2)} processed to ${withdrawDestination}!`);
    } else {
      alert('Insufficient wallet balance for this withdrawal.');
    }
  };

  const showSuccessToast = (msg: string) => {
    setActionSuccessMsg(msg);
    setTimeout(() => setActionSuccessMsg(null), 3500);
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {actionSuccessMsg && (
        <div className="fixed top-20 right-6 z-50 bg-emerald-600 text-white px-4 py-2.5 rounded-xl shadow-xl flex items-center gap-2 text-xs font-semibold animate-in fade-in slide-in-from-top-4">
          <CheckCircle2 className="w-4 h-4" />
          <span>{actionSuccessMsg}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Earnings, Bounties & Digital Wallet
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Pick up peer gigs, earn task rewards, transfer funds to campus friends, and manage institutional payouts.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Quick Wallet Balance Pill */}
          <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-lg border border-slate-200">
            <Wallet className="w-4 h-4 text-emerald-600" />
            <span className="text-xs text-slate-500">Balance:</span>
            <span className="font-mono font-bold text-sm text-slate-900 tabular-nums">
              ${walletBalance.toFixed(2)}
            </span>
          </div>

          <button
            onClick={() => setIsPostModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Post a Gig</span>
          </button>
        </div>
      </div>

      {/* View Switcher: Gigs vs Wallet */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center p-1 bg-slate-100 rounded-lg text-xs font-medium">
          <button
            onClick={() => setActiveSubView('gigs')}
            className={`px-3.5 py-1.5 rounded-md transition-colors ${
              activeSubView === 'gigs'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Campus Gigs & Tasks ({gigs.filter((g) => g.status === 'available').length} Open)
          </button>
          <button
            onClick={() => setActiveSubView('wallet')}
            className={`px-3.5 py-1.5 rounded-md transition-colors ${
              activeSubView === 'wallet'
                ? 'bg-white text-slate-900 shadow-xs font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            My Wallet & Transactions
          </button>
        </div>

        {activeSubView === 'gigs' && (
          <div className="relative min-w-[220px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search gigs by title..."
              className="w-full pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs placeholder-slate-400 focus:outline-hidden focus:border-indigo-500"
            />
          </div>
        )}
      </div>

      {/* VIEW 1: CAMPUS GIGS DIRECTORY */}
      {activeSubView === 'gigs' && (
        <div className="space-y-4">
          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
                  selectedCategory === cat
                    ? 'bg-slate-900 text-white'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Gigs Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredGigs.map((gig) => {
              const isClaimedByMe = gig.claimedBy === currentUser.name;
              return (
                <div
                  key={gig.id}
                  className="bg-white border border-slate-200 rounded-xl p-5 hover:border-indigo-300 transition-all shadow-xs flex flex-col justify-between"
                >
                  <div>
                    {/* Header: Category & Reward */}
                    <div className="flex items-center justify-between text-xs mb-2">
                      <span className="font-semibold text-indigo-700">{gig.category}</span>
                      <span className="font-mono font-bold text-base text-emerald-700 tabular-nums">
                        ${gig.reward.toFixed(2)}
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-slate-900 mb-1 leading-snug">
                      {gig.title}
                    </h3>
                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed mb-4">
                      {gig.description}
                    </p>

                    {/* Meta items */}
                    <div className="space-y-1.5 text-[11px] text-slate-500 pb-3 border-b border-slate-100">
                      <div className="flex items-center justify-between">
                        <span>Est. Commitment:</span>
                        <span className="font-medium text-slate-700">{gig.estimatedHours}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Deadline:</span>
                        <span className="font-mono text-slate-700">{gig.deadline}</span>
                      </div>
                      {gig.submissionNotes && (
                        <div className="pt-1 text-slate-600 italic">
                          Notes: "{gig.submissionNotes}"
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Poster & Claim/Complete Actions */}
                  <div className="pt-3 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2 truncate max-w-[140px]">
                      <img
                        src={gig.posterAvatar}
                        alt={gig.posterName}
                        referrerPolicy="no-referrer"
                        className="w-6 h-6 rounded-full object-cover border border-slate-200"
                      />
                      <div className="truncate">
                        <div className="text-[11px] font-semibold text-slate-900 truncate">
                          {gig.posterName}
                        </div>
                        <div className="text-[10px] text-slate-400 truncate">
                          {gig.posterDepartment}
                        </div>
                      </div>
                    </div>

                    <div>
                      {gig.status === 'completed' ? (
                        <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          Completed & Paid
                        </span>
                      ) : gig.status === 'claimed' ? (
                        isClaimedByMe ? (
                          <button
                            onClick={() => {
                              setTargetGigToComplete(gig);
                              setIsSubmitWorkModalOpen(true);
                            }}
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs"
                          >
                            Submit & Cashout
                          </button>
                        ) : (
                          <span className="text-[11px] text-amber-700 font-semibold bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                            Claimed by {gig.claimedBy?.split(' ')[0]}
                          </span>
                        )
                      ) : (
                        <button
                          onClick={() => {
                            claimGig(gig.id);
                            showSuccessToast(`You claimed "${gig.title}"! Complete it to earn $${gig.reward}.`);
                          }}
                          className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs"
                        >
                          Claim Gig
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* VIEW 2: DIGITAL WALLET & TRANSACTION HISTORY */}
      {activeSubView === 'wallet' && (
        <div className="space-y-6">
          {/* Balance & Action Banner */}
          <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-md border border-slate-800">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
              <div>
                <div className="text-xs uppercase tracking-widest text-indigo-300 font-semibold">
                  Personal Campus Wallet
                </div>
                <div className="text-3xl sm:text-4xl font-mono font-bold mt-1 tabular-nums text-white">
                  ${walletBalance.toFixed(2)}
                </div>
                <div className="text-xs text-slate-300 mt-1 font-medium">
                  Linked to {currentUser.name} ({currentUser.email})
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setIsTransferModalOpen(true)}
                  className="px-4 py-2.5 bg-white text-slate-900 hover:bg-slate-100 rounded-xl font-bold text-xs flex items-center gap-2 transition-all shadow-sm"
                >
                  <Send className="w-4 h-4 text-indigo-600" />
                  <span>Send to Friend</span>
                </button>
                <button
                  onClick={() => setIsWithdrawModalOpen(true)}
                  className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs flex items-center gap-2 transition-all shadow-sm"
                >
                  <ArrowDownToLine className="w-4 h-4" />
                  <span>Cash Out</span>
                </button>
              </div>
            </div>
          </div>

          {/* Transactions Ledger */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900">
                Transaction History & Payout Records
              </h2>
              <span className="text-xs text-slate-500 font-mono">
                {walletTransactions.length} records
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="py-3 px-4">Transaction / Details</th>
                    <th className="py-3 px-4">Entity / Channel</th>
                    <th className="py-3 px-4">Date & Time</th>
                    <th className="py-3 px-4 text-right">Amount</th>
                    <th className="py-3 px-4 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {walletTransactions.map((txn) => {
                    const isPositive = txn.amount > 0;
                    return (
                      <tr key={txn.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3.5 px-4">
                          <div className="font-semibold text-slate-900 flex items-center gap-2">
                            {isPositive ? (
                              <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            ) : (
                              <ArrowUpRight className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                            )}
                            <span>{txn.title}</span>
                          </div>
                          {txn.referenceId && (
                            <div className="text-[10px] text-slate-400 font-mono pl-5.5">
                              Ref: {txn.referenceId}
                            </div>
                          )}
                        </td>
                        <td className="py-3.5 px-4 text-slate-600 font-medium">
                          {txn.destinationOrSource}
                        </td>
                        <td className="py-3.5 px-4 text-slate-500 font-mono text-[11px]">
                          {txn.timestamp}
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono font-bold text-xs tabular-nums">
                          <span className={isPositive ? 'text-emerald-700' : 'text-slate-800'}>
                            {isPositive ? '+' : ''}${txn.amount.toFixed(2)}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          <span className="text-[11px] font-semibold text-emerald-700 capitalize">
                            {txn.status}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: POST A GIG */}
      {isPostModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h2 className="text-base font-bold text-slate-900">Post Paid Task / Bounty</h2>
              <button
                onClick={() => setIsPostModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handlePostGig} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Gig Title</label>
                <input
                  type="text"
                  required
                  value={gigTitle}
                  onChange={(e) => setGigTitle(e.target.value)}
                  placeholder="e.g. Lab Sensor Calibration & Wire Routing"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Category</label>
                  <select
                    value={gigCategory}
                    onChange={(e) => setGigCategory(e.target.value as GigCategory)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500 bg-white"
                  >
                    {categories.filter((c) => c !== 'All').map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Reward Payout ($ USD)</label>
                  <input
                    type="number"
                    step="5"
                    min="10"
                    required
                    value={gigReward}
                    onChange={(e) => setGigReward(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono font-bold focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Est. Effort / Hours</label>
                  <input
                    type="text"
                    required
                    value={gigHours}
                    onChange={(e) => setGigHours(e.target.value)}
                    placeholder="e.g. 2-3 hours"
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Completion Deadline</label>
                  <input
                    type="date"
                    required
                    value={gigDeadline}
                    onChange={(e) => setGigDeadline(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Description & Deliverable Criteria</label>
                <textarea
                  rows={3}
                  required
                  value={gigDescription}
                  onChange={(e) => setGigDescription(e.target.value)}
                  placeholder="Detail exact task deliverables, meeting location, or files required..."
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500 resize-none leading-relaxed"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsPostModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold transition-colors shadow-xs"
                >
                  Publish Bounty
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: SUBMIT COMPLETED GIG WORK */}
      {isSubmitWorkModalOpen && targetGigToComplete && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">Submit Completed Gig</h3>
                <p className="text-xs text-slate-500">{targetGigToComplete.title}</p>
              </div>
              <button
                onClick={() => setIsSubmitWorkModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCompleteSubmit} className="space-y-4 text-xs">
              <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200 text-emerald-900">
                <div className="text-[11px] font-semibold uppercase">Pending Reward Credit</div>
                <div className="font-mono font-bold text-lg mt-0.5">
                  ${targetGigToComplete.reward.toFixed(2)} USD
                </div>
                <div className="text-[11px] text-emerald-700 mt-1">
                  Upon submission, funds will be immediately deposited into your campus digital wallet.
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Submission Notes / Proof of Completion
                </label>
                <textarea
                  rows={3}
                  required
                  value={submissionNotes}
                  onChange={(e) => setSubmissionNotes(e.target.value)}
                  placeholder="Describe completed tasks, share file drive links, or note handover to staff..."
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500 resize-none leading-relaxed"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsSubmitWorkModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold transition-colors shadow-xs"
                >
                  Claim & Credit Wallet
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: SEND PEER TRANSFER */}
      {isTransferModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h2 className="text-base font-bold text-slate-900">Send Payment to Friend / Colleague</h2>
              <button
                onClick={() => setIsTransferModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSendTransfer} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Recipient Name or Email</label>
                <input
                  type="text"
                  required
                  value={transferRecipient}
                  onChange={(e) => setTransferRecipient(e.target.value)}
                  placeholder="e.g. Sophia Thorne, arthur.p@synapse.edu"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Transfer Amount ($ USD)</label>
                <input
                  type="number"
                  step="0.01"
                  max={walletBalance}
                  min="1"
                  required
                  value={transferAmount}
                  onChange={(e) => setTransferAmount(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono font-bold focus:outline-hidden focus:border-indigo-500"
                />
                <div className="text-[11px] text-slate-400 mt-1 font-mono">
                  Available balance: ${walletBalance.toFixed(2)}
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Memo / Note</label>
                <input
                  type="text"
                  value={transferNote}
                  onChange={(e) => setTransferNote(e.target.value)}
                  placeholder="e.g. Coffee & study materials share"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsTransferModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold transition-colors shadow-xs"
                >
                  Confirm Transfer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: CASH OUT / WITHDRAW */}
      {isWithdrawModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h2 className="text-base font-bold text-slate-900">Cash Out Wallet Funds</h2>
              <button
                onClick={() => setIsWithdrawModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleWithdrawFunds} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Cashout Destination</label>
                <select
                  value={withdrawDestination}
                  onChange={(e) => setWithdrawDestination(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500 bg-white"
                >
                  <option value="Chase Checking (••••4021)">Chase Checking (••••4021) - Direct Deposit</option>
                  <option value="Campus OneCard Cash Account">Campus OneCard Cash Account</option>
                  <option value="PayPal Express (Instant)">PayPal Express (Instant)</option>
                  <option value="Venmo Direct">Venmo Direct</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Withdrawal Amount ($ USD)</label>
                <input
                  type="number"
                  step="5"
                  max={walletBalance}
                  min="5"
                  required
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono font-bold focus:outline-hidden focus:border-indigo-500"
                />
                <div className="text-[11px] text-slate-400 mt-1 font-mono">
                  Available to cash out: ${walletBalance.toFixed(2)}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsWithdrawModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold transition-colors shadow-xs"
                >
                  Confirm Cash Out
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
