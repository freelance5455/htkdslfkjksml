import React, { useState, useMemo } from 'react';
import { 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Copy, 
  Check, 
  Search, 
  ChevronRight, 
  ShieldCheck, 
  FileText, 
  Smartphone, 
  Building2, 
  CreditCard, 
  Coins, 
  X,
  ExternalLink,
  ArrowDownRight,
  TrendingDown,
  Info
} from 'lucide-react';
import { WithdrawalRequest, WithdrawalStatus, WithdrawalMethod } from '../../types';

interface WithdrawalHistoryProps {
  withdrawals: WithdrawalRequest[];
  onOpenWithdrawModal: () => void;
  currencyRate?: number;
}

type StatusFilter = 'all' | 'pending' | 'approved' | 'rejected';

export const WithdrawalHistory: React.FC<WithdrawalHistoryProps> = ({
  withdrawals,
  onOpenWithdrawModal,
  currencyRate = 100,
}) => {
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRequest, setSelectedRequest] = useState<WithdrawalRequest | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Stats calculation
  const stats = useMemo(() => {
    const totalCount = withdrawals.length;
    const pendingItems = withdrawals.filter((w) => w.status === 'pending');
    const approvedItems = withdrawals.filter((w) => w.status === 'approved');
    const rejectedItems = withdrawals.filter((w) => w.status === 'rejected');

    const pendingCoins = pendingItems.reduce((acc, curr) => acc + curr.amountCoins, 0);
    const approvedCoins = approvedItems.reduce((acc, curr) => acc + curr.amountCoins, 0);
    const rejectedCoins = rejectedItems.reduce((acc, curr) => acc + curr.amountCoins, 0);

    return {
      totalCount,
      pendingCount: pendingItems.length,
      approvedCount: approvedItems.length,
      rejectedCount: rejectedItems.length,
      pendingCoins,
      approvedCoins,
      rejectedCoins,
    };
  }, [withdrawals]);

  // Filtered withdrawals
  const filteredWithdrawals = useMemo(() => {
    return withdrawals.filter((w) => {
      // Status filter
      if (statusFilter !== 'all' && w.status !== statusFilter) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesRef = w.transactionRef?.toLowerCase().includes(query);
        const matchesAccount = w.accountDetails.toLowerCase().includes(query);
        const matchesId = w.id.toLowerCase().includes(query);
        const matchesMethod = w.method.toLowerCase().includes(query);
        if (!matchesRef && !matchesAccount && !matchesId && !matchesMethod) {
          return false;
        }
      }
      return true;
    });
  }, [withdrawals, statusFilter, searchQuery]);

  const handleCopy = (text: string, id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getMethodIcon = (method: WithdrawalMethod) => {
    switch (method) {
      case 'upi':
      case 'gpay':
      case 'phonepe':
      case 'paytm':
      case 'mobile_recharge':
        return <Smartphone className="w-4 h-4 text-emerald-400" />;
      case 'bank_transfer':
        return <Building2 className="w-4 h-4 text-sky-400" />;
      default:
        return <CreditCard className="w-4 h-4 text-purple-400" />;
    }
  };

  const getMethodLabel = (method: WithdrawalMethod) => {
    switch (method) {
      case 'upi': return 'UPI Instant';
      case 'gpay': return 'Google Pay';
      case 'phonepe': return 'PhonePe';
      case 'paytm': return 'Paytm Wallet';
      case 'bank_transfer': return 'Bank Account (NEFT/IMPS)';
      case 'paypal': return 'PayPal USD';
      case 'crypto_usdt': return 'USDT (TRC20)';
      default: return method.toUpperCase();
    }
  };

  const getStatusBadge = (status: WithdrawalStatus) => {
    switch (status) {
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-500/15 text-amber-300 border border-amber-500/30">
            <Clock className="w-3 h-3 text-amber-400 animate-spin" style={{ animationDuration: '3s' }} />
            <span>Pending Review</span>
          </span>
        );
      case 'approved':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            <span>Processed</span>
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-rose-500/15 text-rose-300 border border-rose-500/30">
            <XCircle className="w-3 h-3 text-rose-400" />
            <span>Rejected & Refunded</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-4">
      {/* Mini KPI Cards for Redemption Breakdown */}
      <div className="grid grid-cols-3 gap-2 sm:gap-3 text-xs">
        <div 
          onClick={() => setStatusFilter('approved')}
          className={`p-3 rounded-2xl border transition-all cursor-pointer ${
            statusFilter === 'approved' 
              ? 'bg-emerald-950/40 border-emerald-500/50 shadow-sm' 
              : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 mb-1">
            <span>Processed</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <p className="text-base sm:text-lg font-black text-white">
            {stats.approvedCoins.toLocaleString()} <span className="text-[10px] text-amber-400 font-bold">Coins</span>
          </p>
          <span className="text-[10px] text-emerald-400 font-semibold">
            {stats.approvedCount} {stats.approvedCount === 1 ? 'payout' : 'payouts'} completed
          </span>
        </div>

        <div 
          onClick={() => setStatusFilter('pending')}
          className={`p-3 rounded-2xl border transition-all cursor-pointer ${
            statusFilter === 'pending' 
              ? 'bg-amber-950/40 border-amber-500/50 shadow-sm' 
              : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 mb-1">
            <span>Pending</span>
            <Clock className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <p className="text-base sm:text-lg font-black text-white">
            {stats.pendingCoins.toLocaleString()} <span className="text-[10px] text-amber-400 font-bold">Coins</span>
          </p>
          <span className="text-[10px] text-amber-300 font-semibold">
            {stats.pendingCount} in queue
          </span>
        </div>

        <div 
          onClick={() => setStatusFilter('rejected')}
          className={`p-3 rounded-2xl border transition-all cursor-pointer ${
            statusFilter === 'rejected' 
              ? 'bg-rose-950/40 border-rose-500/50 shadow-sm' 
              : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 mb-1">
            <span>Rejected</span>
            <XCircle className="w-3.5 h-3.5 text-rose-400" />
          </div>
          <p className="text-base sm:text-lg font-black text-white">
            {stats.rejectedCoins.toLocaleString()} <span className="text-[10px] text-amber-400 font-bold">Coins</span>
          </p>
          <span className="text-[10px] text-rose-300 font-semibold">
            {stats.rejectedCount} refunded
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
        {/* Status Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 text-xs font-bold scrollbar-none">
          <button
            type="button"
            onClick={() => setStatusFilter('all')}
            className={`py-1.5 px-3 rounded-xl border transition-all cursor-pointer shrink-0 ${
              statusFilter === 'all'
                ? 'bg-slate-200 text-slate-950 border-white'
                : 'bg-slate-900/70 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
          >
            All ({stats.totalCount})
          </button>

          <button
            type="button"
            onClick={() => setStatusFilter('pending')}
            className={`py-1.5 px-3 rounded-xl border transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
              statusFilter === 'pending'
                ? 'bg-amber-500 text-slate-950 border-amber-400 font-black'
                : 'bg-slate-900/70 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            <span>Pending ({stats.pendingCount})</span>
          </button>

          <button
            type="button"
            onClick={() => setStatusFilter('approved')}
            className={`py-1.5 px-3 rounded-xl border transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
              statusFilter === 'approved'
                ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-black'
                : 'bg-slate-900/70 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span>Processed ({stats.approvedCount})</span>
          </button>

          <button
            type="button"
            onClick={() => setStatusFilter('rejected')}
            className={`py-1.5 px-3 rounded-xl border transition-all cursor-pointer flex items-center gap-1.5 shrink-0 ${
              statusFilter === 'rejected'
                ? 'bg-rose-500 text-white border-rose-400 font-black'
                : 'bg-slate-900/70 text-slate-400 border-slate-800 hover:text-slate-200'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
            <span>Rejected ({stats.rejectedCount})</span>
          </button>
        </div>

        {/* Search input */}
        <div className="relative shrink-0 sm:w-48">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search ref ID or account..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-slate-950/80 border border-slate-800 text-slate-200 text-xs placeholder:text-slate-500 focus:outline-none focus:border-slate-700"
          />
        </div>
      </div>

      {/* Main List */}
      <div className="space-y-2.5">
        {filteredWithdrawals.length === 0 ? (
          <div className="p-8 text-center rounded-2xl bg-slate-900/40 border border-slate-800 space-y-2">
            <div className="w-10 h-10 rounded-2xl bg-slate-800/80 text-slate-400 flex items-center justify-center mx-auto">
              <FileText className="w-5 h-5" />
            </div>
            <p className="text-xs font-bold text-slate-300">No withdrawal records found</p>
            <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
              {searchQuery
                ? 'No transactions matching your search query. Try clearing the search.'
                : statusFilter !== 'all'
                ? `You have zero ${statusFilter} withdrawal requests.`
                : 'You have not submitted any coin withdrawal requests yet.'}
            </p>
            {statusFilter === 'all' && (
              <button
                type="button"
                onClick={onOpenWithdrawModal}
                className="mt-2 py-2 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/20 cursor-pointer inline-flex items-center gap-1.5"
              >
                <span>Request First Payout</span>
              </button>
            )}
          </div>
        ) : (
          filteredWithdrawals.map((req) => {
            const isApproved = req.status === 'approved';
            const isRejected = req.status === 'rejected';
            const isPending = req.status === 'pending';

            return (
              <div
                key={req.id}
                onClick={() => setSelectedRequest(req)}
                className={`p-3.5 sm:p-4 rounded-2xl border transition-all cursor-pointer relative overflow-hidden group ${
                  isApproved
                    ? 'bg-slate-900/70 border-slate-800 hover:border-emerald-500/50'
                    : isRejected
                    ? 'bg-slate-900/70 border-rose-900/30 hover:border-rose-700/50'
                    : 'bg-slate-900/70 border-amber-900/30 hover:border-amber-600/50'
                }`}
              >
                {/* Left status color accent bar */}
                <div 
                  className={`absolute left-0 top-0 bottom-0 w-1 ${
                    isApproved ? 'bg-emerald-500' : isRejected ? 'bg-rose-500' : 'bg-amber-500'
                  }`} 
                />

                <div className="pl-1.5 space-y-2.5">
                  {/* Top row: Status Badge & Amount */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-xl bg-slate-800/80 flex items-center justify-center shrink-0">
                        {getMethodIcon(req.method)}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-white">
                            {getMethodLabel(req.method)}
                          </span>
                          {getStatusBadge(req.status)}
                        </div>
                        <span className="text-[11px] font-mono text-slate-400 block truncate max-w-[200px] sm:max-w-xs">
                          {req.accountDetails}
                        </span>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="text-xs sm:text-sm font-black text-white flex items-center justify-end gap-1">
                        <span>{req.amountCoins.toLocaleString()}</span>
                        <span className="text-amber-400 text-xs">Coins</span>
                      </div>
                      <span className="text-[11px] font-semibold text-emerald-400 block">
                        ≈ ₹{(req.amountCurrency || req.amountCoins / currencyRate).toFixed(2)} INR
                      </span>
                    </div>
                  </div>

                  {/* Middle row: Reference ID, Dates, and Admin Remark */}
                  <div className="pt-2 border-t border-slate-800/70 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span>Requested: {new Date(req.requestedAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                      
                      {req.transactionRef && (
                        <div className="flex items-center gap-1 bg-slate-950 px-2 py-0.5 rounded-md border border-slate-800 text-[10px] font-mono text-slate-300">
                          <span>Ref: {req.transactionRef}</span>
                          <button
                            type="button"
                            onClick={(e) => handleCopy(req.transactionRef!, req.id, e)}
                            className="text-slate-400 hover:text-white p-0.5"
                            title="Copy Reference ID"
                          >
                            {copiedId === req.id ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-1 text-slate-400 group-hover:text-emerald-400 text-[11px] font-bold transition-colors">
                      <span>View Receipt</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </div>
                  </div>

                  {/* Rejection / Admin Remark Alert */}
                  {isRejected && req.adminRemark && (
                    <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-[11px] flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                      <div>
                        <strong className="font-bold text-rose-200">Rejection Note:</strong> {req.adminRemark}
                      </div>
                    </div>
                  )}

                  {isPending && (
                    <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-[11px] flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      <span>Request is in anti-fraud audit queue. Typically credited in 2–4 hours.</span>
                    </div>
                  )}

                  {isApproved && req.processedAt && (
                    <div className="text-[10px] text-slate-500 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-emerald-500" />
                      <span>Completed on {new Date(req.processedAt).toLocaleString()}</span>
                    </div>
                  )}

                </div>
              </div>
            );
          })
        )}
      </div>

      {/* DETAILED RECEIPT / AUDIT TRAIL MODAL */}
      {selectedRequest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl relative space-y-4 max-h-[92vh] overflow-y-auto">
            
            {/* Close Button */}
            <button
              onClick={() => setSelectedRequest(null)}
              className="absolute top-4 right-4 p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Receipt Header */}
            <div className="text-center space-y-1.5 pt-2">
              <div className={`w-12 h-12 rounded-2xl mx-auto flex items-center justify-center shadow-lg ${
                selectedRequest.status === 'approved'
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shadow-emerald-500/10'
                  : selectedRequest.status === 'rejected'
                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30 shadow-rose-500/10'
                  : 'bg-amber-500/20 text-amber-400 border border-amber-500/30 shadow-amber-500/10'
              }`}>
                {selectedRequest.status === 'approved' ? (
                  <CheckCircle2 className="w-6 h-6" />
                ) : selectedRequest.status === 'rejected' ? (
                  <XCircle className="w-6 h-6" />
                ) : (
                  <Clock className="w-6 h-6" />
                )}
              </div>

              <h3 className="text-base font-black text-white">
                {selectedRequest.status === 'approved'
                  ? 'Withdrawal Processed Successfully'
                  : selectedRequest.status === 'rejected'
                  ? 'Withdrawal Request Rejected'
                  : 'Withdrawal In Verification'}
              </h3>
              
              <div className="text-2xl font-black text-white">
                {selectedRequest.amountCoins.toLocaleString()} <span className="text-amber-400 text-lg">Coins</span>
              </div>
              <p className="text-xs font-semibold text-emerald-400">
                Payout Value: ₹{(selectedRequest.amountCurrency || selectedRequest.amountCoins / currencyRate).toFixed(2)} INR
              </p>
            </div>

            {/* Lifecycle Timeline Steps */}
            <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-3">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                Verification & Payout Timeline
              </span>

              <div className="space-y-3 text-xs">
                {/* Step 1: Request Submitted */}
                <div className="flex items-start gap-3">
                  <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3 h-3 stroke-[3]" />
                  </div>
                  <div>
                    <h5 className="font-bold text-white text-xs">Request Created</h5>
                    <p className="text-[11px] text-slate-400">
                      {new Date(selectedRequest.requestedAt).toLocaleString()}
                    </p>
                  </div>
                </div>

                {/* Step 2: Security & Anti-Fraud Audit */}
                <div className="flex items-start gap-3">
                  <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
                    selectedRequest.status !== 'pending'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                      : 'bg-amber-500/20 text-amber-400 border border-amber-500/40 animate-pulse'
                  }`}>
                    {selectedRequest.status !== 'pending' ? (
                      <Check className="w-3 h-3 stroke-[3]" />
                    ) : (
                      <Clock className="w-3 h-3" />
                    )}
                  </div>
                  <div>
                    <h5 className="font-bold text-white text-xs">
                      {selectedRequest.status === 'pending' ? 'Security & Anti-Fraud Audit (In Progress)' : 'Security Audit Passed'}
                    </h5>
                    <p className="text-[11px] text-slate-400">
                      {selectedRequest.status === 'pending'
                        ? 'Automated task verification and compliance check.'
                        : 'Verified compliance and genuine user activity.'}
                    </p>
                  </div>
                </div>

                {/* Step 3: Bank / Gateway Payout */}
                <div className="flex items-start gap-3">
                  <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
                    selectedRequest.status === 'approved'
                      ? 'bg-emerald-500 text-slate-950 font-black'
                      : selectedRequest.status === 'rejected'
                      ? 'bg-rose-500 text-white'
                      : 'bg-slate-800 text-slate-500 border border-slate-700'
                  }`}>
                    {selectedRequest.status === 'approved' ? (
                      <Check className="w-3 h-3 stroke-[3]" />
                    ) : selectedRequest.status === 'rejected' ? (
                      <X className="w-3 h-3 stroke-[3]" />
                    ) : (
                      <span className="text-[10px] font-bold">3</span>
                    )}
                  </div>
                  <div>
                    <h5 className={`font-bold text-xs ${
                      selectedRequest.status === 'approved'
                        ? 'text-emerald-400'
                        : selectedRequest.status === 'rejected'
                        ? 'text-rose-400'
                        : 'text-slate-400'
                    }`}>
                      {selectedRequest.status === 'approved'
                        ? 'Transferred to Beneficiary Account'
                        : selectedRequest.status === 'rejected'
                        ? 'Payout Cancelled / Rejected'
                        : 'Pending Gateway Dispatch'}
                    </h5>
                    <p className="text-[11px] text-slate-400">
                      {selectedRequest.processedAt
                        ? `Finished at ${new Date(selectedRequest.processedAt).toLocaleString()}`
                        : 'Awaiting completion of review.'}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Transaction Data Table */}
            <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2 text-xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                Transaction Details
              </span>

              <div className="space-y-1.5 text-slate-300">
                <div className="flex justify-between py-1 border-b border-slate-800/80">
                  <span className="text-slate-500">Transaction ID</span>
                  <span className="font-mono text-slate-200">{selectedRequest.id}</span>
                </div>

                <div className="flex justify-between py-1 border-b border-slate-800/80">
                  <span className="text-slate-500">Payout Channel</span>
                  <span className="font-bold text-slate-200">{getMethodLabel(selectedRequest.method)}</span>
                </div>

                <div className="flex justify-between py-1 border-b border-slate-800/80">
                  <span className="text-slate-500">Destination Account</span>
                  <span className="font-mono text-slate-200 text-right truncate max-w-[200px]">
                    {selectedRequest.accountDetails}
                  </span>
                </div>

                {selectedRequest.transactionRef && (
                  <div className="flex justify-between py-1 border-b border-slate-800/80 items-center">
                    <span className="text-slate-500">Bank UTR / Ref ID</span>
                    <div className="flex items-center gap-1 font-mono text-emerald-400">
                      <span>{selectedRequest.transactionRef}</span>
                      <button
                        type="button"
                        onClick={(e) => handleCopy(selectedRequest.transactionRef!, 'modal', e)}
                        className="p-1 hover:text-white cursor-pointer"
                      >
                        {copiedId === 'modal' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      </button>
                    </div>
                  </div>
                )}

                <div className="flex justify-between py-1">
                  <span className="text-slate-500">Coin Conversion Rate</span>
                  <span className="font-medium text-slate-400">100 Coins = ₹1.00 INR</span>
                </div>
              </div>
            </div>

            {/* Rejection notice / Refund explanation */}
            {selectedRequest.status === 'rejected' && (
              <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs space-y-1">
                <div className="font-bold text-rose-200 flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>Rejection & Wallet Refund</span>
                </div>
                <p className="text-[11px] leading-relaxed text-rose-300">
                  {selectedRequest.adminRemark || 'The request was rejected due to an invalid destination account address.'}
                </p>
                <p className="text-[10px] text-rose-400 font-semibold pt-1 border-t border-rose-500/20">
                  ✓ {selectedRequest.amountCoins} Coins have been automatically credited back to your balance.
                </p>
              </div>
            )}

            {/* Action buttons */}
            <div className="pt-1">
              <button
                type="button"
                onClick={() => setSelectedRequest(null)}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-colors cursor-pointer"
              >
                Close Receipt
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
