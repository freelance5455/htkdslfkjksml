import { useState } from 'react';
import { Wallet, QrCode, Download, ShieldCheck, WifiOff, FileText, CheckCircle, ExternalLink, X, Smartphone, Sparkles, Lock, Fingerprint } from 'lucide-react';
import { WalletDocument, Language } from '../../types';
import { translations } from '../../i18n/translations';
import { ScannableQRCode } from './ScannableQRCode';

interface TravelWalletScreenProps {
  documents: WalletDocument[];
  language: Language;
  onLockVault?: () => void;
}

export function TravelWalletScreen({ documents, language, onLockVault }: TravelWalletScreenProps) {
  const [selectedDoc, setSelectedDoc] = useState<WalletDocument | null>(documents[1] || documents[0]);
  const [downloadNotice, setDownloadNotice] = useState('');
  const [offlineSimulated, setOfflineSimulated] = useState(false);

  const t = translations[language];

  const handleDownload = (doc: WalletDocument) => {
    setDownloadNotice(language === 'ar' ? `جاري تحميل ${doc.title} بتنسيق PDF رسمي مشفر...` : `Downloading ${doc.title} official PDF...`);
    setTimeout(() => {
      setDownloadNotice(language === 'ar' ? 'تم حفظ الوثيقة في ذاكرة الهاتف للاستخدام دون إنترنت!' : 'Document saved for offline viewing!');
      setTimeout(() => setDownloadNotice(''), 2500);
    }, 1200);
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-xl md:text-2xl font-black text-white">
            {t.walletTitle}
          </h1>
          <div className="flex items-center gap-2 mt-0.5">
            <span className="inline-flex items-center gap-1 text-[11px] text-cyan-400 font-mono">
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
              TAKI SecureVault (AES-256)
            </span>
            <span className="text-slate-600">·</span>
            <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400 font-mono">
              <Fingerprint className="w-3.5 h-3.5" />
              {language === 'ar' ? 'محمي بالبصمة' : 'Biometric Active'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onLockVault && (
            <button
              onClick={onLockVault}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-900 border border-slate-700/80 hover:border-cyan-400/60 text-slate-300 hover:text-cyan-300 text-xs font-semibold transition-all cursor-pointer shadow-sm"
              title={language === 'ar' ? 'قفل الخزنة فوراً' : 'Lock Vault Now'}
            >
              <Lock className="w-3.5 h-3.5 text-cyan-400" />
              <span>{language === 'ar' ? 'قفل الخزنة' : 'Lock'}</span>
            </button>
          )}

          {/* Offline Badge with Toggle */}
          <button
            onClick={() => setOfflineSimulated(!offlineSimulated)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-semibold transition-all cursor-pointer ${
              offlineSimulated
                ? 'bg-amber-500/20 border-amber-400/50 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.25)]'
                : 'bg-emerald-500/20 border-emerald-400/40 text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.2)]'
            }`}
            title="Toggle Offline Test Mode"
          >
            <WifiOff className="w-3.5 h-3.5" />
            <span>
              {offlineSimulated
                ? (language === 'ar' ? 'وضع عدم الاتصال' : 'Offline')
                : (language === 'ar' ? 'متاح دون إنترنت' : 'Offline Ready')}
            </span>
          </button>
        </div>
      </div>

      {offlineSimulated && (
        <div className="p-3 rounded-2xl bg-amber-950/60 border border-amber-500/40 text-amber-200 text-xs flex items-center gap-2.5 animate-pulse">
          <WifiOff className="w-4 h-4 text-amber-400 shrink-0" />
          <div>
            <p className="font-bold">
              {language === 'ar' ? 'أنت الآن في وضع عدم الاتصال (Offline)' : 'Offline Simulated Mode Active'}
            </p>
            <p className="text-[11px] text-amber-300/80 mt-0.5">
              {language === 'ar'
                ? 'جميع رموز الـ QR والوثائق مشفرة ومخزنة محلياً وقابلة للمسح الضوئي في المطارات والفنادق دون الحاجة إلى شبكة.'
                : 'All QR codes and travel documents are cached locally and 100% scannable at gates and hotels without internet.'}
            </p>
          </div>
        </div>
      )}

      {/* Featured Boarding Pass / Active Document Display */}
      {selectedDoc && (
        <div className="glass-panel-elevated rounded-3xl p-5 sm:p-6 border border-cyan-400/40 text-white relative overflow-hidden space-y-4">
          <div className="flex items-start justify-between pb-3 border-b border-slate-800">
            <div>
              <span className="text-[10px] text-cyan-400 uppercase tracking-widest font-mono font-bold">
                {selectedDoc.category.replace('_', ' ')}
              </span>
              <h2 className="text-base md:text-lg font-black text-white mt-0.5">
                {selectedDoc.title}
              </h2>
              <p className="text-xs text-slate-400 font-mono">
                {selectedDoc.documentNumber}
              </p>
            </div>

            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-400/30">
              <QrCode className="w-5 h-5" />
            </div>
          </div>

          {/* Passenger & Validity */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="bg-slate-900/90 p-3 rounded-2xl border border-slate-800">
              <span className="text-[10px] text-slate-400 block mb-0.5">{language === 'ar' ? 'المسافر' : 'Passenger'}</span>
              <p className="font-bold text-white font-mono">{selectedDoc.passengerName}</p>
            </div>
            <div className="bg-slate-900/90 p-3 rounded-2xl border border-slate-800">
              <span className="text-[10px] text-slate-400 block mb-0.5">{language === 'ar' ? 'تاريخ الإصدار' : 'Issue Date'}</span>
              <p className="font-bold text-white">{selectedDoc.issueDate}</p>
            </div>
          </div>

          {/* Real Scannable High-Contrast QR Code Visualizer */}
          <div className="bg-gradient-to-b from-[#060c22] to-slate-950 p-4 rounded-3xl border border-cyan-500/30 flex flex-col items-center justify-center">
            <div className="flex items-center gap-1.5 text-cyan-400 text-xs font-bold mb-3 font-mono">
              <QrCode className="w-4 h-4" />
              <span>{language === 'ar' ? 'رمز الصعود والمسح الضوئي المعتمد' : 'Official Scannable Gate QR Code'}</span>
            </div>

            <ScannableQRCode
              data={selectedDoc.qrCodeData}
              documentTitle={selectedDoc.title}
              documentNumber={selectedDoc.documentNumber}
              passengerName={selectedDoc.passengerName}
              language={language}
              size={170}
            />

            <p className="text-[11px] text-slate-400 text-center mt-2 font-mono">
              {language === 'ar'
                ? 'جاهز للمسح الضوئي عبر أجهزة التفتيش وبوابات الصعود الآلية'
                : 'Directly readable by airport e-gates and optical turnstiles'}
            </p>
          </div>

          {/* Download & Offline Action */}
          <button
            onClick={() => handleDownload(selectedDoc)}
            className="w-full h-11 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-bold text-xs flex items-center justify-center gap-2 hover:brightness-110 active:scale-[0.98] transition-all shadow-[0_0_15px_rgba(0,102,255,0.3)] cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>{t.downloadPdf} ({selectedDoc.fileSize})</span>
          </button>
        </div>
      )}

      {/* Download Status Toast */}
      {downloadNotice && (
        <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle className="w-4 h-4 shrink-0" />
          <span>{downloadNotice}</span>
        </div>
      )}

      {/* All Documents Grid / List */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-300">
            {language === 'ar' ? 'جميع وثائق السفر المخزنة (Offline Vault):' : 'All Stored Documents (Offline Vault):'}
          </h3>
          <span className="text-[11px] text-cyan-400 font-mono">
            {documents.length} {language === 'ar' ? 'وثائق' : 'Documents'}
          </span>
        </div>

        {documents.map(doc => (
          <div
            key={doc.id}
            onClick={() => setSelectedDoc(doc)}
            className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between text-white ${
              selectedDoc?.id === doc.id
                ? 'bg-blue-600/20 border-cyan-400 shadow-[0_0_15px_rgba(0,240,255,0.2)]'
                : 'glass-panel hover:border-slate-700'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-cyan-400 shrink-0">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-white">{doc.title}</p>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-[10px] text-slate-400 font-mono">{doc.documentNumber}</span>
                  <span className="text-[9px] bg-cyan-950 text-cyan-300 px-1.5 py-0.2 rounded border border-cyan-800 font-mono">
                    {doc.category}
                  </span>
                </div>
              </div>
            </div>

            <div className="text-left rtl:text-right flex items-center gap-2">
              <span className="text-[10px] text-emerald-400 font-mono bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-800/50 flex items-center gap-1">
                <WifiOff className="w-2.5 h-2.5" />
                Offline
              </span>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedDoc(doc);
                }}
                className={`p-1.5 rounded-lg border text-xs flex items-center gap-1 transition-colors ${
                  selectedDoc?.id === doc.id
                    ? 'bg-cyan-500 text-slate-950 font-bold border-cyan-400'
                    : 'bg-slate-800 hover:bg-slate-700 text-cyan-300 border-slate-700'
                }`}
                title={language === 'ar' ? 'عرض باركود الوثيقة' : 'View QR'}
              >
                <QrCode className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleDownload(doc);
                }}
                className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center cursor-pointer"
                title="Download PDF"
              >
                <Download className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

