import React, { useState } from 'react';
import { useKhata } from '../../context/KhataContext';
import { formatRupee } from '../../i18n/translations';
import { CategoryIcon } from '../common/CategoryIcon';
import {
  PieChart,
  Plus,
  AlertTriangle,
  AlertCircle,
  CheckCircle,
  Edit2,
  Check,
  TrendingDown,
  Layers
} from 'lucide-react';

export const BudgetView: React.FC = () => {
  const {
    budget,
    updateBudget,
    categories,
    currentMonthTransactions,
    monthlyExpense,
    budgetProgressPercent,
    language,
    t,
    setActiveModal
  } = useKhata();

  const [isEditingOverall, setIsEditingOverall] = useState(false);
  const [overallInput, setOverallInput] = useState(String(budget.overallBudget || 45000));
  const [editingCategoryId, setEditingCategoryId] = useState<string | null>(null);
  const [categoryLimitInput, setCategoryLimitInput] = useState('');

  // Calculate spending per category
  const expenseCategories = categories.filter(c => c.type === 'expense');

  const categorySpending = React.useMemo(() => {
    const map: Record<string, number> = {};
    currentMonthTransactions
      .filter(tx => tx.type === 'expense')
      .forEach(tx => {
        map[tx.categoryId] = (map[tx.categoryId] || 0) + tx.amount;
      });
    return map;
  }, [currentMonthTransactions]);

  const handleSaveOverall = () => {
    const num = parseFloat(overallInput);
    if (!isNaN(num) && num >= 0) {
      updateBudget(num, budget.categoryLimits || {});
    }
    setIsEditingOverall(false);
  };

  const handleSaveCategoryLimit = (categoryId: string) => {
    const num = parseFloat(categoryLimitInput);
    const updatedLimits = { ...(budget.categoryLimits || {}) };
    if (!isNaN(num) && num > 0) {
      updatedLimits[categoryId] = num;
    } else {
      delete updatedLimits[categoryId];
    }
    updateBudget(budget.overallBudget, updatedLimits);
    setEditingCategoryId(null);
  };

  const budgetRemaining = Math.max(0, budget.overallBudget - monthlyExpense);
  const isBudgetWarning = budgetProgressPercent >= 80 && budgetProgressPercent < 100;
  const isBudgetExceeded = budgetProgressPercent >= 100;

  return (
    <div className="space-y-4 pb-8">
      {/* Overall Budget Overview Card */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <PieChart className="w-5 h-5 text-emerald-700" />
            <h2 className="text-base font-bold text-slate-900">{t.overallBudgetTitle}</h2>
          </div>
          {!isEditingOverall && (
            <button
              onClick={() => {
                setOverallInput(String(budget.overallBudget));
                setIsEditingOverall(true);
              }}
              className="flex items-center gap-1 text-xs font-semibold text-emerald-700 hover:bg-emerald-50 px-2.5 py-1 rounded-lg transition"
            >
              <Edit2 className="w-3.5 h-3.5" />
              <span>{t.editBudget}</span>
            </button>
          )}
        </div>

        {isEditingOverall ? (
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 font-bold text-slate-400">₹</span>
              <input
                type="number"
                value={overallInput}
                onChange={e => setOverallInput(e.target.value)}
                className="w-full pl-8 pr-3 py-2 text-base font-bold border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 font-mono"
                autoFocus
              />
            </div>
            <button
              onClick={handleSaveOverall}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1"
            >
              <Check className="w-4 h-4" />
              <span>{t.saveBudget}</span>
            </button>
          </div>
        ) : (
          <div className="flex items-baseline justify-between">
            <div>
              <span className="text-3xl font-extrabold text-slate-900 tabular-nums">
                {formatRupee(budget.overallBudget)}
              </span>
              <span className="text-xs text-slate-400 ml-1.5 font-medium">/ महीना (Per Month)</span>
            </div>
            <span
              className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                isBudgetExceeded
                  ? 'bg-rose-100 text-rose-800'
                  : isBudgetWarning
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-emerald-100 text-emerald-800'
              }`}
            >
              {budgetProgressPercent}% खर्च हुआ
            </span>
          </div>
        )}

        {/* Progress Bar & Alert */}
        <div className="space-y-1.5">
          <div className="w-full h-3.5 bg-slate-100 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                isBudgetExceeded
                  ? 'bg-rose-500'
                  : isBudgetWarning
                  ? 'bg-amber-500'
                  : 'bg-emerald-600'
              }`}
              style={{ width: `${Math.min(100, budgetProgressPercent)}%` }}
            />
          </div>

          <div className="flex justify-between text-xs font-semibold text-slate-600 tabular-nums pt-1">
            <span className="text-rose-600">
              {t.budgetUsed}: {formatRupee(monthlyExpense)}
            </span>
            <span className="text-emerald-700">
              {t.budgetRemaining}: {formatRupee(budgetRemaining)}
            </span>
          </div>
        </div>

        {/* Dynamic Alert Banner */}
        {isBudgetExceeded && (
          <div className="p-3 bg-rose-50 rounded-xl border border-rose-200 text-rose-800 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span className="font-semibold">{t.budgetExceeded}</span>
          </div>
        )}
        {isBudgetWarning && (
          <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-800 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            <span className="font-semibold">{t.budgetWarning80}</span>
          </div>
        )}
        {!isBudgetWarning && !isBudgetExceeded && (
          <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="font-semibold">{t.budgetOnTrack}</span>
          </div>
        )}
      </div>

      {/* Category Wise Spending Limits Header */}
      <div className="flex items-center justify-between pt-2">
        <div>
          <h3 className="text-sm font-bold text-slate-900">{t.categoryWiseLimits}</h3>
          <p className="text-[11px] text-slate-500">
            {language === 'hi'
              ? 'हर श्रेणी के लिए अधिकतम मासिक खर्च की सीमा तय करें'
              : 'Set individual monthly spending limits for each category'}
          </p>
        </div>
        <button
          onClick={() => setActiveModal('add-category')}
          className="flex items-center gap-1 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition shadow-xs"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{t.addCustomCategory}</span>
        </button>
      </div>

      {/* Category Wise Limits List */}
      <div className="space-y-2.5">
        {expenseCategories.map(cat => {
          const spent = categorySpending[cat.id] || 0;
          const limit = budget.categoryLimits?.[cat.id] || cat.budgetLimit || 0;
          const hasLimit = limit > 0;
          const percent = hasLimit ? Math.min(100, Math.round((spent / limit) * 100)) : 0;
          const isCategoryExceeded = hasLimit && spent > limit;
          const isCategoryWarning = hasLimit && percent >= 80 && percent < 100;
          const isEditingThis = editingCategoryId === cat.id;

          return (
            <div
              key={cat.id}
              className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs space-y-2"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div
                    className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                    style={{ backgroundColor: `${cat.color}15`, color: cat.color }}
                  >
                    <CategoryIcon name={cat.icon} className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-800">
                      {language === 'hi' ? cat.nameHi : cat.nameEn}
                    </h4>
                    <span className="text-[11px] text-slate-400">
                      {t.spentOf}: <strong className="text-slate-700 tabular-nums">{formatRupee(spent)}</strong>
                    </span>
                  </div>
                </div>

                {/* Limit & Edit Trigger */}
                <div className="text-right">
                  {isEditingThis ? (
                    <div className="flex items-center gap-1.5">
                      <input
                        type="number"
                        value={categoryLimitInput}
                        onChange={e => setCategoryLimitInput(e.target.value)}
                        placeholder="₹"
                        className="w-20 px-2 py-1 text-xs border rounded font-mono"
                        autoFocus
                      />
                      <button
                        onClick={() => handleSaveCategoryLimit(cat.id)}
                        className="p-1 bg-emerald-700 text-white rounded hover:bg-emerald-800"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <div
                      onClick={() => {
                        setEditingCategoryId(cat.id);
                        setCategoryLimitInput(String(limit || ''));
                      }}
                      className="cursor-pointer group flex items-center gap-1"
                    >
                      <div className="text-right">
                        <div className="text-xs font-bold text-slate-800 tabular-nums">
                          {hasLimit ? formatRupee(limit) : <span className="text-slate-400 font-normal">{t.limitNotSet}</span>}
                        </div>
                        {hasLimit && (
                          <div
                            className={`text-[10px] font-semibold ${
                              isCategoryExceeded
                                ? 'text-rose-600'
                                : isCategoryWarning
                                ? 'text-amber-600'
                                : 'text-slate-400'
                            }`}
                          >
                            {percent}%
                          </div>
                        )}
                      </div>
                      <Edit2 className="w-3 h-3 text-slate-300 group-hover:text-emerald-700 transition" />
                    </div>
                  )}
                </div>
              </div>

              {/* Progress bar if limit is set */}
              {hasLimit && (
                <div className="space-y-1">
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        isCategoryExceeded
                          ? 'bg-rose-500'
                          : isCategoryWarning
                          ? 'bg-amber-500'
                          : 'bg-emerald-600'
                      }`}
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                  {isCategoryExceeded && (
                    <div className="text-[10px] text-rose-600 font-semibold flex items-center gap-1">
                      <AlertCircle className="w-3 h-3 shrink-0" />
                      <span>सीमा पार: {formatRupee(spent - limit)} अधिक खर्च!</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
