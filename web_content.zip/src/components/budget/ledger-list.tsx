import { Pencil, Trash2 } from "lucide-react";
import { CategoryGlyph } from "@/components/budget/icons";
import { Money } from "@/components/budget/money";
import { categoryById, formatDayLabel, plural, type Transaction } from "@/lib/budget/model";

export function LedgerList({
  items,
  filterLabel,
  pendingDelete,
  pendingClear,
  onEdit,
  onAskDelete,
  onConfirmDelete,
  onCancelDelete,
  onClearFilter,
  onAskClear,
  onConfirmClear,
  onCancelClear,
  onLoadExample,
}: {
  items: Transaction[];
  filterLabel: string | null;
  pendingDelete: string | null;
  pendingClear: boolean;
  onEdit: (tx: Transaction) => void;
  onAskDelete: (id: string) => void;
  onConfirmDelete: () => void;
  onCancelDelete: () => void;
  onClearFilter: () => void;
  onAskClear: () => void;
  onConfirmClear: () => void;
  onCancelClear: () => void;
  onLoadExample: () => void;
}) {
  const groups = groupByDate(items);
  const countLabel = `${items.length} ${plural(items.length, "операция", "операции", "операций")}`;

  return (
    <section className="overflow-hidden rounded-3xl bg-surface shadow-card">
      <header className="flex items-center justify-between gap-3 px-5 py-4">
        <div>
          <h2 className="text-lg font-semibold">Операции</h2>
          <p className="text-sm text-muted">{items.length === 0 ? "Пока пусто" : countLabel}</p>
        </div>
        {filterLabel ? (
          <button
            type="button"
            onClick={onClearFilter}
            className="rounded-full bg-bg px-3 py-2 text-sm font-medium"
          >
            {filterLabel} ×
          </button>
        ) : null}
      </header>

      {items.length === 0 ? (
        <div className="px-5 pb-6">
          <p className="text-sm text-muted">
            {filterLabel
              ? "В этой категории за месяц ничего нет."
              : "Добавьте доход или расход — остаток пересчитается сразу."}
          </p>
          {!filterLabel ? (
            <button type="button" onClick={onLoadExample} className="mt-3 text-sm font-semibold text-pine">
              Показать пример
            </button>
          ) : null}
        </div>
      ) : (
        <ul>
          {groups.map((group) => (
            <li key={group.date}>
              <p className="bg-bg px-5 py-2 text-xs font-semibold text-muted">{formatDayLabel(group.date)}</p>
              <ul>
                {group.items.map((tx) => {
                  const category = categoryById(tx.categoryId);
                  const confirming = pendingDelete === tx.id;
                  return (
                    <li key={tx.id} className="border-b border-line last:border-b-0">
                      {confirming ? (
                        <div className="flex min-h-16 items-center justify-between gap-3 px-5 py-3">
                          <p className="text-sm font-medium">Удалить операцию?</p>
                          <div className="flex gap-2">
                            <button
                              type="button"
                              onClick={onConfirmDelete}
                              className="h-11 rounded-xl bg-clay px-3 text-sm font-semibold text-on-clay"
                            >
                              Удалить
                            </button>
                            <button
                              type="button"
                              onClick={onCancelDelete}
                              className="h-11 rounded-xl bg-bg px-3 text-sm font-semibold"
                            >
                              Оставить
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1 pr-2">
                          <button
                            type="button"
                            onClick={() => onEdit(tx)}
                            className="flex min-h-16 min-w-0 flex-1 items-center gap-3 px-5 py-3 text-left"
                          >
                            <span
                              className={
                                tx.type === "income"
                                  ? "flex size-10 shrink-0 items-center justify-center rounded-full bg-pine-soft text-pine"
                                  : "flex size-10 shrink-0 items-center justify-center rounded-full bg-clay-soft text-clay"
                              }
                            >
                              <CategoryGlyph id={tx.categoryId} className="size-4" />
                            </span>
                            <span className="min-w-0 flex-1">
                              <span className="flex items-center gap-2">
                                <span className="truncate font-medium">{category?.label ?? "Без категории"}</span>
                                <Pencil className="size-3.5 shrink-0 text-muted" aria-hidden />
                              </span>
                              {tx.note ? <span className="block truncate text-sm text-muted">{tx.note}</span> : null}
                            </span>
                            <Money
                              cents={tx.type === "income" ? tx.amount : -tx.amount}
                              sign="always"
                              className={tx.type === "income" ? "text-pine" : "text-clay"}
                            />
                          </button>
                          <button
                            type="button"
                            aria-label={`Удалить: ${category?.label ?? "операция"}`}
                            onClick={() => onAskDelete(tx.id)}
                            className="flex size-11 shrink-0 items-center justify-center rounded-xl text-muted hover:bg-bg hover:text-clay"
                          >
                            <Trash2 className="size-4" aria-hidden />
                          </button>
                        </div>
                      )}
                    </li>
                  );
                })}
              </ul>
            </li>
          ))}
        </ul>
      )}

      {items.length > 0 ? (
        <footer className="border-t border-line px-5 py-4">
          {pendingClear ? (
            <div className="flex flex-wrap items-center gap-2">
              <p className="text-sm">Удалить все операции?</p>
              <button
                type="button"
                onClick={onConfirmClear}
                className="h-11 rounded-xl bg-clay px-3 text-sm font-semibold text-on-clay"
              >
                Удалить всё
              </button>
              <button type="button" onClick={onCancelClear} className="h-11 rounded-xl bg-bg px-3 text-sm font-semibold">
                Отмена
              </button>
            </div>
          ) : (
            <button type="button" onClick={onAskClear} className="text-sm font-medium text-muted hover:text-ink">
              Очистить все операции
            </button>
          )}
        </footer>
      ) : null}
    </section>
  );
}

function groupByDate(items: Transaction[]) {
  const sorted = items.slice().sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id));
  const groups: Array<{ date: string; items: Transaction[] }> = [];
  for (const tx of sorted) {
    const last = groups[groups.length - 1];
    if (!last || last.date !== tx.date) groups.push({ date: tx.date, items: [tx] });
    else last.items.push(tx);
  }
  return groups;
}
