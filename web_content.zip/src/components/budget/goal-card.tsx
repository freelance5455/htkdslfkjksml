import { useState } from "react";
import { PiggyBank } from "lucide-react";
import { Money } from "@/components/budget/money";
import { cn } from "@/lib/cn";
import { formatAmountInput, parseRubles } from "@/lib/budget/model";
import { useBudget } from "@/lib/budget/store";

export function GoalCard({ balance }: { balance: number }) {
  const goal = useBudget((state) => state.goal);
  const setGoal = useBudget((state) => state.setGoal);
  const [name, setName] = useState(goal.name);
  const [amount, setAmount] = useState(() => formatAmountInput(goal.target));

  const parsed = parseRubles(amount);
  const target = parsed ?? goal.target;
  const covered = balance > 0 ? balance : 0;
  const rawPct = target > 0 ? Math.round((covered / target) * 100) : 0;
  const bar = Math.min(100, Math.max(0, rawPct));
  const gap = target - balance;

  function commitName(next: string) {
    const trimmed = next.trim().slice(0, 40);
    if (!trimmed) {
      setName(goal.name);
      return;
    }
    setName(trimmed);
    setGoal({ name: trimmed, target });
  }

  function commitAmount() {
    if (parsed == null) {
      setAmount(formatAmountInput(goal.target));
      return;
    }
    setAmount(formatAmountInput(parsed));
    setGoal({ name: name.trim() || goal.name, target: parsed });
  }

  return (
    <section className="rounded-3xl bg-surface p-5 shadow-card">
      <div className="flex items-center gap-2 text-sm text-muted">
        <PiggyBank className="size-4 text-pine" aria-hidden />
        Цель накоплений
      </div>
      <input
        aria-label="Название цели"
        value={name}
        maxLength={40}
        onChange={(event) => {
          const next = event.target.value;
          setName(next);
          const trimmed = next.trim().slice(0, 40);
          if (trimmed) setGoal({ name: trimmed, target });
        }}
        onBlur={() => commitName(name)}
        className="mt-2 w-full bg-transparent text-lg font-semibold outline-none"
      />
      <label className="mt-4 block text-xs font-medium text-muted" htmlFor="goal-amount">
        Сколько хотите отложить
      </label>
      <input
        id="goal-amount"
        inputMode="decimal"
        autoComplete="off"
        value={amount}
        onChange={(event) => {
          const next = event.target.value;
          setAmount(next);
          const cents = parseRubles(next);
          if (cents != null) setGoal({ name: name.trim() || goal.name, target: cents });
        }}
        onBlur={commitAmount}
        className="mt-1 w-full bg-transparent font-display text-3xl tabular-nums tracking-tight outline-none"
      />
      <div className="mt-4 flex items-center justify-between gap-3 text-sm">
        <span className="font-medium tabular-nums">{balance < 0 ? "0%" : `${rawPct}%`}</span>
        <span className="text-right text-muted">от остатка этого месяца</span>
      </div>
      <div
        className="mt-2 h-2 overflow-hidden rounded-full bg-line"
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={bar}
        aria-label="Прогресс цели"
      >
        <div className={cn("h-full rounded-full", balance < 0 ? "bg-clay" : "bg-pine")} style={{ width: `${bar}%` }} />
      </div>
      <p className="mt-3 text-sm">
        {balance < 0 ? (
          <span className="text-clay">Сначала выйти в плюс — остаток отрицательный</span>
        ) : gap > 0 ? (
          <>
            Ещё <Money cents={gap} size="inline" />
          </>
        ) : gap === 0 ? (
          "Цель закрыта ровно"
        ) : (
          <>
            Сверх плана <Money cents={-gap} size="inline" className="text-pine" />
          </>
        )}
      </p>
    </section>
  );
}
