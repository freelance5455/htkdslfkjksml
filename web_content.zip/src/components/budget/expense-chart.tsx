import { useEffect, useState } from "react";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { Money } from "@/components/budget/money";
import { cn } from "@/lib/cn";
import type { Slice } from "@/lib/budget/model";

export function ExpenseChart({
  slices,
  total,
  activeId,
  onSelect,
}: {
  slices: Slice[];
  total: number;
  activeId: string | null;
  onSelect: (id: string | null) => void;
}) {
  const reduceMotion = usePrefersReducedMotion();

  if (slices.length === 0) {
    return (
      <div className="flex h-52 items-center justify-center">
        <div className="flex size-40 items-center justify-center rounded-full border border-dashed border-line px-6 text-center text-sm text-muted">
          Нет расходов за месяц
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="relative h-52">
        <div className="h-full w-full" aria-hidden>
          <ResponsiveContainer width="100%" height="100%" minWidth={0}>
            <PieChart>
              <Pie
                data={slices}
                dataKey="amount"
                nameKey="label"
                innerRadius="68%"
                outerRadius="92%"
                paddingAngle={2}
                cornerRadius={6}
                stroke="none"
                isAnimationActive={!reduceMotion}
                animationDuration={400}
                onClick={(entry) => {
                  const id = sliceId(entry);
                  if (!id) return;
                  onSelect(activeId === id ? null : id);
                }}
              >
                {slices.map((slice) => (
                  <Cell
                    key={slice.id}
                    fill={slice.chart}
                    opacity={activeId && activeId !== slice.id ? 0.35 : 1}
                    className="cursor-pointer"
                  />
                ))}
              </Pie>
              <Tooltip content={<ExpenseTip />} cursor={false} wrapperStyle={{ outline: "none" }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-xs font-medium text-muted">расходы</span>
          <Money cents={total} size="goal" />
        </div>
      </div>
      <ul className="mt-2 flex flex-col gap-1">
        {slices.map((slice) => {
          const pct = total > 0 ? Math.round((slice.amount / total) * 100) : 0;
          const selected = activeId === slice.id;
          return (
            <li key={slice.id}>
              <button
                type="button"
                onClick={() => onSelect(selected ? null : slice.id)}
                className={cn(
                  "w-full rounded-xl px-3 py-2 text-left transition-colors",
                  selected ? "bg-bg" : "hover:bg-bg",
                )}
                aria-pressed={selected}
              >
                <span className="flex items-center gap-2">
                  <span className="size-2.5 shrink-0 rounded-full" style={{ background: slice.chart }} />
                  <span className="min-w-0 flex-1 truncate text-sm">{slice.label}</span>
                  <span className="text-xs font-medium text-muted tabular-nums">{pct}%</span>
                  <Money cents={slice.amount} size="inline" />
                </span>
                <span className="mt-2 block h-1 overflow-hidden rounded-full bg-line">
                  <span
                    className="block h-full rounded-full"
                    style={{ width: `${pct}%`, background: slice.chart }}
                  />
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function ExpenseTip({
  active,
  payload,
}: {
  active?: boolean;
  payload?: Array<{ name?: string; value?: number }>;
}) {
  if (!active || !payload?.length || typeof payload[0].value !== "number") return null;
  return (
    <div className="rounded-xl bg-ink px-3 py-2 text-on-ink shadow-card">
      <p className="text-xs text-on-ink-soft">{payload[0].name}</p>
      <Money cents={payload[0].value} size="inline" className="text-on-ink" />
    </div>
  );
}

function sliceId(entry: unknown) {
  if (!entry || typeof entry !== "object") return null;
  const value = entry as { id?: string; payload?: { id?: string } };
  return value.id ?? value.payload?.id ?? null;
}

function usePrefersReducedMotion() {
  const [reduce, setReduce] = useState(false);
  useEffect(() => {
    const query = window.matchMedia("(prefers-reduced-motion: reduce)");
    const apply = () => setReduce(query.matches);
    apply();
    query.addEventListener("change", apply);
    return () => query.removeEventListener("change", apply);
  }, []);
  return reduce;
}
