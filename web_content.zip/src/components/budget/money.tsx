import { cn } from "@/lib/cn";
import { formatAmountInput } from "@/lib/budget/model";

const NUMBER = {
  hero: "text-4xl sm:text-5xl lg:text-6xl",
  stat: "text-xl sm:text-2xl",
  row: "text-base",
  goal: "text-xl",
  inline: "text-sm",
} as const;

const MARK = {
  hero: "text-xl sm:text-2xl",
  stat: "text-sm",
  row: "text-xs",
  goal: "text-sm",
  inline: "text-xs",
} as const;

export function Money({
  cents,
  size = "row",
  sign = "never",
  display = false,
  className,
}: {
  cents: number;
  size?: keyof typeof NUMBER;
  sign?: "never" | "auto" | "always";
  display?: boolean;
  className?: string;
}) {
  const negative = cents < 0;
  const prefix = sign === "never" ? "" : negative ? "−" : sign === "always" && cents > 0 ? "+" : "";
  const showDisplay = display || size === "hero" || size === "stat" || size === "goal";

  return (
    <span
      className={cn(
        "tabular-nums tracking-tight",
        showDisplay ? "font-display" : "font-sans font-semibold",
        NUMBER[size],
        className,
      )}
    >
      {prefix}
      {formatAmountInput(cents)}
      <span className={cn("ml-1 font-sans font-semibold tracking-normal opacity-70", MARK[size])}>₽</span>
    </span>
  );
}
