import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { ChevronLeft, ChevronRight, Minus, Plus } from "lucide-react";
import { ExpenseChart } from "@/components/budget/expense-chart";
import { GoalCard } from "@/components/budget/goal-card";
import { LedgerList } from "@/components/budget/ledger-list";
import { Money } from "@/components/budget/money";
import { TransactionForm } from "@/components/budget/transaction-form";
import { cn } from "@/lib/cn";
import {
  blankDraft,
  categoryById,
  expenseSlices,
  formatAmountInput,
  formatMonthLabel,
  monthOf,
  parseRubles,
  projectBalance,
  shiftMonth,
  summarize,
  type Transaction,
  type TxDraft,
} from "@/lib/budget/model";
import { useBudget } from "@/lib/budget/store";

export function BudgetApp() {
  const transactions = useBudget((state) => state.transactions);
  const add = useBudget((state) => state.add);
  const update = useBudget((state) => state.update);
  const remove = useBudget((state) => state.remove);
  const clearAll = useBudget((state) => state.clearAll);
  const loadExample = useBudget((state) => state.loadExample);

  const [ready, setReady] = useState(false);
  const [month, setMonth] = useState<string | null>(null);
  const [form, setForm] = useState<TxDraft | null>(null);
  const [open, setOpen] = useState(false);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState<string | null>(null);
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);
  const [pendingClear, setPendingClear] = useState(false);
  const amountRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    let cancel = false;
    let ran = false;
    const done = () => {
      if (cancel || ran) return;
      ran = true;
      const state = useBudget.getState();
      if (!state.initialized) state.loadExample();
      const nextMonth = new Date();
      const key = `${nextMonth.getFullYear()}-${String(nextMonth.getMonth() + 1).padStart(2, "0")}`;
      setMonth(key);
      setForm(blankDraft(key));
      setReady(true);
    };

    const persist = useBudget.persist;
    if (!persist) {
      done();
      return;
    }
    const unsubscribe = persist.onFinishHydration(() => done());
    void Promise.resolve(persist.rehydrate()).catch(() => done());
    return () => {
      cancel = true;
      unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (!open) return;
    const query = window.matchMedia("(min-width: 1024px)");
    if (query.matches) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    amountRef.current?.focus();
    return () => {
      document.body.style.overflow = previous;
    };
  }, [open]);

  const monthTxs = useMemo(
    () => (month ? transactions.filter((tx) => monthOf(tx.date) === month) : []),
    [transactions, month],
  );
  const totals = useMemo(() => summarize(monthTxs), [monthTxs]);
  const slices = useMemo(() => expenseSlices(monthTxs), [monthTxs]);
  const visible = filter ? monthTxs.filter((tx) => tx.categoryId === filter) : monthTxs;
  const draftCents = form ? parseRubles(form.amount) : null;
  const projection =
    form && month && draftCents != null
      ? projectBalance({
          balance: totals.balance,
          month,
          txs: transactions,
          draft: { id: form.id, type: form.type, amount: draftCents, date: form.date },
        })
      : null;
  const liveBalance = projection?.changed ? projection.next : totals.balance;
  const show = ready && month != null && form != null;

  function submit() {
    if (!form || !month) return;
    const amount = parseRubles(form.amount);
    if (amount == null) {
      setError("Введите сумму больше нуля");
      amountRef.current?.focus();
      return;
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(form.date)) {
      setError("Укажите дату");
      return;
    }
    const next = {
      type: form.type,
      amount,
      categoryId: form.categoryId,
      date: form.date,
      note: form.note.trim().slice(0, 80),
    };
    if (form.id) update(form.id, next);
    else add(next);
    const targetMonth = monthOf(form.date);
    setMonth(targetMonth);
    setForm(blankDraft(targetMonth));
    setError("");
    setOpen(false);
    setFilter(null);
  }

  function cancel() {
    if (!month) return;
    setForm(blankDraft(month));
    setError("");
    setOpen(false);
  }

  function edit(tx: Transaction) {
    setForm({
      id: tx.id,
      type: tx.type,
      amount: formatAmountInput(tx.amount),
      categoryId: tx.categoryId,
      date: tx.date,
      note: tx.note,
    });
    setError("");
    setOpen(true);
    amountRef.current?.focus();
  }

  const tone = liveBalance > 0 ? "good" : liveBalance < 0 ? "bad" : "flat";
  const status = liveBalance > 0 ? "в плюсе" : liveBalance < 0 ? "дефицит" : "ноль";

  return (
    <main className="mx-auto min-h-screen max-w-6xl px-4 py-4 lg:px-8 lg:py-8">
      <header className="sticky top-0 z-30 -mx-4 mb-5 border-b border-line bg-bg/90 px-4 py-3 backdrop-blur lg:-mx-8 lg:px-8">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="size-2.5 rounded-full bg-pine" aria-hidden />
              <h1 className="text-xl font-semibold tracking-tight">Смета</h1>
            </div>
            <p className="text-sm text-muted">Личный бюджет</p>
          </div>
          <button
            type="button"
            onClick={() => {
              if (month && form?.id) {
                setForm(blankDraft(month));
                setError("");
              }
              setOpen(true);
            }}
            className="inline-flex h-11 items-center gap-2 rounded-xl bg-ink pl-4 pr-3.5 text-sm font-semibold text-on-ink lg:hidden"
          >
            Добавить
            <Plus className="size-4" aria-hidden />
          </button>
        </div>
        <div className="mt-3 flex items-center gap-2">
          <div className="flex min-w-0 flex-1 items-center rounded-2xl bg-surface p-1 shadow-card">
            <button
              type="button"
              aria-label="Предыдущий месяц"
              disabled={!month}
              onClick={() => month && setMonth(shiftMonth(month, -1))}
              className="flex size-11 items-center justify-center rounded-xl hover:bg-bg disabled:opacity-40"
            >
              <ChevronLeft className="size-5" aria-hidden />
            </button>
            <p className="min-w-0 flex-1 text-center text-sm font-semibold">
              {month ? formatMonthLabel(month) : "Загрузка"}
            </p>
            <button
              type="button"
              aria-label="Следующий месяц"
              disabled={!month}
              onClick={() => month && setMonth(shiftMonth(month, 1))}
              className="flex size-11 items-center justify-center rounded-xl hover:bg-bg disabled:opacity-40"
            >
              <ChevronRight className="size-5" aria-hidden />
            </button>
          </div>
          {month && month !== currentKey() ? (
            <button
              type="button"
              onClick={() => setMonth(currentKey())}
              className="h-11 shrink-0 rounded-xl px-3 text-sm font-semibold text-pine"
            >
              Сегодня
            </button>
          ) : null}
        </div>
      </header>

      <div className="flex flex-col gap-5 lg:grid lg:grid-cols-5 lg:items-start lg:gap-6">
        <div className="contents lg:col-span-3 lg:flex lg:flex-col lg:gap-5">
          <section className="order-1 rounded-3xl bg-ink px-6 py-7 text-on-ink shadow-card lg:order-none">
            <div className="flex items-center justify-between gap-3">
              <p className="text-sm font-medium text-on-ink-soft">
                {month ? `Остаток за ${formatMonthLabel(month)}` : "Остаток"}
              </p>
              <span
                className={cn(
                  "rounded-full px-2.5 py-1 text-xs font-semibold",
                  projection?.changed
                    ? "bg-surface/15 text-on-ink"
                    : tone === "good"
                      ? "bg-pine text-on-pine"
                      : tone === "bad"
                        ? "bg-clay text-on-clay"
                        : "bg-surface/15 text-on-ink",
                )}
              >
                {projection?.changed ? "черновик" : status}
              </span>
            </div>
            <div className="mt-4" aria-live="polite">
              {show ? (
                <Money cents={liveBalance} size="hero" sign="auto" className="text-on-ink" />
              ) : (
                <span className="block h-12 w-48 animate-pulse rounded-xl bg-surface/15" />
              )}
            </div>
            <p className="mt-3 text-sm text-on-ink-soft">
              {projection?.changed ? (
                <>
                  если сохранить · сейчас <Money cents={totals.balance} size="inline" sign="auto" />
                </>
              ) : (
                "доходы минус расходы"
              )}
            </p>
          </section>

          <div className="order-2 grid grid-cols-2 gap-3 lg:order-none">
            <Stat
              label="Доходы"
              cents={totals.income}
              ready={show}
              icon={<Plus className="size-4" aria-hidden />}
              tone="income"
            />
            <Stat
              label="Расходы"
              cents={totals.expense}
              ready={show}
              icon={<Minus className="size-4" aria-hidden />}
              tone="expense"
            />
          </div>

          <div className="order-5 lg:order-none">
            {show ? (
              <LedgerList
                items={visible}
                filterLabel={filter ? (categoryById(filter)?.label ?? null) : null}
                pendingDelete={pendingDelete}
                pendingClear={pendingClear}
                onEdit={edit}
                onAskDelete={setPendingDelete}
                onConfirmDelete={() => {
                  if (pendingDelete) {
                    if (form?.id === pendingDelete) cancel();
                    remove(pendingDelete);
                  }
                  setPendingDelete(null);
                }}
                onCancelDelete={() => setPendingDelete(null)}
                onClearFilter={() => setFilter(null)}
                onAskClear={() => setPendingClear(true)}
                onConfirmClear={() => {
                  clearAll();
                  setPendingClear(false);
                  setFilter(null);
                  if (month) setForm(blankDraft(month));
                }}
                onCancelClear={() => setPendingClear(false)}
                onLoadExample={() => {
                  loadExample();
                  setFilter(null);
                }}
              />
            ) : (
              <div className="h-48 animate-pulse rounded-3xl bg-surface shadow-card" />
            )}
          </div>
        </div>

        <div className="contents lg:col-span-2 lg:flex lg:min-w-0 lg:flex-col lg:gap-5">
          {open ? (
            <button
              type="button"
              aria-label="Закрыть форму"
              className="fixed inset-0 z-40 bg-ink/40 lg:hidden"
              onClick={() => setOpen(false)}
            />
          ) : null}
          <aside
            className={cn(
              "order-6 min-w-0 lg:order-none lg:static",
              open ? "fixed inset-0 z-50 block overflow-y-auto bg-bg px-4 py-4" : "hidden lg:block",
            )}
          >
            <div className="rounded-3xl bg-surface p-5 shadow-card">
              {form ? (
                <TransactionForm
                  value={form}
                  error={error}
                  preview={projection ? { next: projection.next, inView: projection.inView } : null}
                  showCancel={open}
                  amountRef={amountRef}
                  onChange={(next) => {
                    setForm(next);
                    setError("");
                  }}
                  onSubmit={submit}
                  onCancel={cancel}
                />
              ) : null}
            </div>
          </aside>

          <div className="order-3 lg:order-none">
            {show ? <GoalCard balance={totals.balance} /> : <div className="h-44 animate-pulse rounded-3xl bg-surface shadow-card" />}
          </div>

          <section className="order-4 rounded-3xl bg-surface p-5 shadow-card lg:order-none">
            <h2 className="text-lg font-semibold">Расходы по категориям</h2>
            <div className="mt-2">
              {show ? (
                <ExpenseChart slices={slices} total={totals.expense} activeId={filter} onSelect={setFilter} />
              ) : (
                <div className="mx-auto mt-6 size-40 animate-pulse rounded-full bg-bg" />
              )}
            </div>
          </section>
        </div>
      </div>

      <p className="mt-6 text-center text-xs text-muted">Суммы хранятся только в этом браузере.</p>
    </main>
  );
}

function Stat({
  label,
  cents,
  ready,
  icon,
  tone,
}: {
  label: string;
  cents: number;
  ready: boolean;
  icon: ReactNode;
  tone: "income" | "expense";
}) {
  return (
    <section className="rounded-2xl bg-surface px-4 py-4 shadow-card">
      <div className="flex items-center gap-2 text-sm text-muted">
        <span
          className={cn(
            "flex size-8 items-center justify-center rounded-full",
            tone === "income" ? "bg-pine-soft text-pine" : "bg-clay-soft text-clay",
          )}
        >
          {icon}
        </span>
        {label}
      </div>
      <div className="mt-3">
        {ready ? (
          <Money cents={cents} size="stat" className={tone === "income" ? "text-pine" : "text-clay"} />
        ) : (
          <span className="block h-8 w-24 animate-pulse rounded-lg bg-bg" />
        )}
      </div>
    </section>
  );
}

function currentKey() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}
