import type { RefObject } from "react";
import { categoriesFor, type TxDraft, type TxType } from "@/lib/budget/model";
import { CategoryGlyph } from "@/components/budget/icons";
import { Money } from "@/components/budget/money";
import { cn } from "@/lib/cn";

export function TransactionForm({
  value,
  error,
  preview,
  showCancel,
  amountRef,
  onChange,
  onSubmit,
  onCancel,
}: {
  value: TxDraft;
  error: string;
  preview: { next: number; inView: boolean } | null;
  showCancel: boolean;
  amountRef: RefObject<HTMLInputElement | null>;
  onChange: (next: TxDraft) => void;
  onSubmit: () => void;
  onCancel: () => void;
}) {
  const categories = categoriesFor(value.type);

  function setType(type: TxType) {
    const nextCategories = categoriesFor(type);
    const categoryId = nextCategories.some((category) => category.id === value.categoryId)
      ? value.categoryId
      : nextCategories[0].id;
    onChange({ ...value, type, categoryId });
  }

  return (
    <form
      onSubmit={(event) => {
        event.preventDefault();
        onSubmit();
      }}
      className="flex flex-col gap-4 max-lg:pb-40"
    >
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-lg font-semibold">{value.id ? "Редактирование" : "Новая операция"}</h2>
        {showCancel ? (
          <button type="button" onClick={onCancel} className="text-sm font-medium text-muted lg:hidden">
            Закрыть
          </button>
        ) : null}
      </div>

      <div className="grid h-12 grid-cols-2 rounded-xl bg-bg p-1">
        <TypeButton active={value.type === "expense"} tone="expense" onClick={() => setType("expense")}>
          Расход
        </TypeButton>
        <TypeButton active={value.type === "income"} tone="income" onClick={() => setType("income")}>
          Доход
        </TypeButton>
      </div>

      <div className="border-b border-line pb-2">
        <label htmlFor="tx-amount" className="text-xs font-medium text-muted">
          Сумма
        </label>
        <input
          ref={amountRef}
          id="tx-amount"
          inputMode="decimal"
          autoComplete="off"
          placeholder="0"
          value={value.amount}
          onChange={(event) => onChange({ ...value, amount: event.target.value })}
          className={cn(
            "mt-1 w-full bg-transparent font-display text-4xl tabular-nums tracking-tight outline-none placeholder:text-muted",
            value.type === "income" ? "text-pine" : "text-clay",
          )}
        />
      </div>

      <fieldset>
        <legend className="mb-2 text-xs font-medium text-muted">Категория</legend>
        <div className="grid grid-cols-3 gap-2">
          {categories.map((category) => {
            const selected = category.id === value.categoryId;
            return (
              <button
                key={category.id}
                type="button"
                aria-pressed={selected}
                onClick={() => onChange({ ...value, categoryId: category.id })}
                className={cn(
                  "flex min-h-12 flex-col items-center justify-center gap-1 rounded-xl px-1 py-2 text-xs leading-tight transition-colors",
                  selected
                    ? value.type === "income"
                      ? "bg-pine-soft font-semibold text-pine"
                      : "bg-clay-soft font-semibold text-clay"
                    : "bg-bg text-ink hover:bg-line",
                )}
              >
                <CategoryGlyph id={category.id} className="size-4" />
                {category.label}
              </button>
            );
          })}
        </div>
      </fieldset>

      <div className="grid gap-3 sm:grid-cols-2">
        <label className="block text-xs font-medium text-muted" htmlFor="tx-date">
          Дата
          <input
            id="tx-date"
            type="date"
            required
            value={value.date}
            onChange={(event) => onChange({ ...value, date: event.target.value })}
            className="mt-1 h-11 w-full rounded-xl border border-line bg-bg px-3 text-sm font-medium text-ink"
          />
        </label>
        <label className="block text-xs font-medium text-muted" htmlFor="tx-note">
          Комментарий
          <input
            id="tx-note"
            maxLength={80}
            value={value.note}
            placeholder="Необязательно"
            onChange={(event) => onChange({ ...value, note: event.target.value })}
            className="mt-1 h-11 w-full rounded-xl border border-line bg-bg px-3 text-sm text-ink placeholder:text-muted"
          />
        </label>
      </div>

      <p className="text-sm" aria-live="polite">
        {preview ? (
          preview.inView ? (
            <>
              Остаток станет <Money cents={preview.next} size="inline" />
            </>
          ) : (
            "Дата в другом месяце — этот остаток не изменится"
          )
        ) : (
          "Остаток пересчитается сразу после сохранения"
        )}
      </p>

      {error ? (
        <p role="alert" className="text-sm font-medium text-clay">
          {error}
        </p>
      ) : null}

      <div className="flex gap-2">
        <button
          type="submit"
          className={cn(
            "h-12 flex-1 rounded-xl text-sm font-semibold",
            value.type === "income" ? "bg-pine text-on-pine" : "bg-ink text-on-ink",
          )}
        >
          {value.id ? "Сохранить" : value.type === "income" ? "Добавить доход" : "Добавить расход"}
        </button>
        {value.id ? (
          <button
            type="button"
            onClick={onCancel}
            className="h-12 rounded-xl bg-bg px-4 text-sm font-semibold text-ink"
          >
            Отмена
          </button>
        ) : null}
      </div>
    </form>
  );
}

function TypeButton({
  active,
  tone,
  onClick,
  children,
}: {
  active: boolean;
  tone: TxType;
  onClick: () => void;
  children: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "rounded-lg text-sm font-semibold transition-colors",
        active
          ? tone === "income"
            ? "bg-pine text-on-pine"
            : "bg-clay text-on-clay"
          : "text-muted",
      )}
    >
      {children}
    </button>
  );
}
