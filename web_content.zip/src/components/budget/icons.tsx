import {
  Briefcase,
  Bus,
  Coffee,
  Ellipsis,
  Gift,
  HeartPulse,
  Home,
  Laptop,
  Plus,
  Receipt,
  ShoppingBag,
  ShoppingBasket,
  Ticket,
  TrendingUp,
  type LucideIcon,
} from "lucide-react";

const ICONS: Record<string, LucideIcon> = {
  salary: Briefcase,
  freelance: Laptop,
  invest: TrendingUp,
  "gift-in": Gift,
  "other-in": Plus,
  groceries: ShoppingBasket,
  home: Home,
  transport: Bus,
  cafe: Coffee,
  health: HeartPulse,
  shopping: ShoppingBag,
  fun: Ticket,
  bills: Receipt,
  "other-out": Ellipsis,
};

export function CategoryGlyph({ id, className }: { id: string; className?: string }) {
  const Icon = ICONS[id] ?? Ellipsis;
  return <Icon className={className} strokeWidth={1.75} aria-hidden />;
}
