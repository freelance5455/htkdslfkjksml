import React, { useState } from 'react';
import { ALL_TEST_SERIES } from '../data/batchData';
import { TestSeries, TestStore } from '../types';
import { formatDisplayDate, getTestDetails, getTodayDateString } from '../utils/trackerLogic';

interface GraphsViewProps {
  testStore: TestStore;
}

interface TooltipData {
  title: string;
  subtitle: string;
  rows: { label: string; value: string; color?: string }[];
  note?: string;
  x: number;
  y: number;
}

export const GraphsView: React.FC<GraphsViewProps> = ({ testStore }) => {
  const [selectedSeriesId, setSelectedSeriesId] = useState<string>('b');
  const [viewModes, setViewModes] = useState<Record<string, 'chart' | 'table'>>({
    progress: 'chart',
    trend: 'chart',
    subject: 'chart',
  });
  const [tooltip, setTooltip] = useState<TooltipData | null>(null);

  const todayStr = getTodayDateString();
  const currentSeries =
    ALL_TEST_SERIES.find((s) => s.id === selectedSeriesId) || ALL_TEST_SERIES[0];

  const toggleMode = (key: string) => {
    setViewModes((prev) => ({
      ...prev,
      [key]: prev[key] === 'table' ? 'chart' : 'table',
    }));
  };

  // 1. Gather all attempted test data for current series
  interface TestPoint {
    k: string;
    n: string;
    d: string;
    ms: number;
    f: boolean;
    t: number | null;
    p: number | null;
    c: number | null;
    b: number | null;
    z: number | null;
    bio: number | null;
    r: number | null;
    note: string;
  }

  const seriesData: TestPoint[] = [];
  currentSeries.list.forEach((test) => {
    const res = getTestDetails(test.k, testStore);
    if (!res.s) return;

    const p = parseFloat(String(res.p));
    const c = parseFloat(String(res.c));
    const b = parseFloat(String(res.b));
    const z = parseFloat(String(res.z));
    const t = parseFloat(String(res.t));

    const validP = !isNaN(p) ? p : null;
    const validC = !isNaN(c) ? c : null;
    const validB = !isNaN(b) ? b : null;
    const validZ = !isNaN(z) ? z : null;
    const validT = !isNaN(t) ? t : null;

    let bio: number | null = null;
    if (validB !== null && validZ !== null) {
      bio = validB + validZ;
    } else if (validT !== null && validP !== null && validC !== null) {
      bio = validT - validP - validC;
    }

    seriesData.push({
      k: test.k,
      n: test.n,
      d: test.d,
      ms: new Date(test.d + 'T00:00:00').getTime(),
      f: !!test.f,
      t: validT,
      p: validP,
      c: validC,
      b: validB,
      z: validZ,
      bio,
      r: !isNaN(parseFloat(String(res.r))) ? parseFloat(String(res.r)) : null,
      note: String(res.n || ''),
    });
  });

  seriesData.sort((a, b) => a.ms - b.ms);

  const testsWithScore = seriesData.filter((x) => x.t !== null);
  const testsWithSubject = seriesData.filter((x) => x.p !== null || x.c !== null || x.bio !== null);

  // Score statistics
  const scoreValues = testsWithScore.map((x) => x.t as number);
  const last3 = scoreValues.slice(-3);
  const latestScore = scoreValues.length > 0 ? scoreValues[scoreValues.length - 1] : '—';
  const bestScore = scoreValues.length > 0 ? Math.max(...scoreValues) : '—';
  const last3Avg =
    last3.length > 0 ? Math.round(last3.reduce((a, b) => a + b, 0) / last3.length) : '—';

  // Progress stats for all series
  const progressRows = ALL_TEST_SERIES.map((s) => {
    let attempted = 0;
    let missed = 0;
    let upcoming = 0;

    s.list.forEach((t) => {
      const res = getTestDetails(t.k, testStore);
      const isPast = new Date(t.d + 'T00:00:00').getTime() < new Date(todayStr + 'T00:00:00').getTime();
      if (res.s) {
        attempted++;
      } else if (isPast) {
        missed++;
      } else {
        upcoming++;
      }
    });

    return {
      series: s,
      attempted,
      missed,
      upcoming,
      total: s.list.length,
    };
  });

  // SVG Chart Dimensions
  const chartW = 340;
  const chartH = 190;
  const padding = { top: 18, right: 30, bottom: 25, left: 36 };
  const plotW = chartW - padding.left - padding.right;
  const plotH = chartH - padding.top - padding.bottom;

  // Time X scale bounds
  let minMs = 0;
  let maxMs = 1;
  if (seriesData.length > 0) {
    const allMs = seriesData.map((x) => x.ms);
    minMs = Math.min(...allMs);
    maxMs = Math.max(...allMs);
    if (minMs === maxMs) {
      minMs -= 7 * 864e5;
      maxMs += 7 * 864e5;
    } else {
      const pad = Math.max(2 * 864e5, (maxMs - minMs) * 0.05);
      minMs -= pad;
      maxMs += pad;
    }
  }

  const getX = (ms: number) => {
    if (maxMs <= minMs) return padding.left + plotW / 2;
    return padding.left + ((ms - minMs) / (maxMs - minMs)) * plotW;
  };

  const getY = (val: number, minVal: number, maxVal: number) => {
    const clamped = Math.max(minVal, Math.min(maxVal, val));
    return padding.top + (1 - (clamped - minVal) / (maxVal - minVal)) * plotH;
  };

  return (
    <div className="space-y-4 pb-20">
      {/* 1. Overall Test Progress Card */}
      <div className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-4 shadow-sm backdrop-blur-sm">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-xs sm:text-sm font-bold text-white">All Series Test Progress</h3>
            <p className="text-[11px] text-zinc-400">
              {progressRows.reduce((a, b) => a + b.attempted, 0)} of{' '}
              {progressRows.reduce((a, b) => a + b.total, 0)} tests attempted
            </p>
          </div>
          <button
            onClick={() => toggleMode('progress')}
            className="px-2.5 py-1 rounded-full text-xs font-semibold bg-zinc-800 border border-zinc-700 text-zinc-300 hover:text-white"
          >
            {viewModes.progress === 'chart' ? 'View Table' : 'View Bars'}
          </button>
        </div>

        {viewModes.progress === 'chart' ? (
          <div className="space-y-2.5">
            {/* Legend */}
            <div className="flex items-center gap-3 text-[11px] text-zinc-400 pb-1">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500" /> Attempted
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-amber-500" /> Missed / Backlog
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-zinc-800" /> Upcoming
              </span>
            </div>

            {/* Stacked Bars */}
            <div className="space-y-2">
              {progressRows.map((r) => (
                <div key={r.series.id} className="flex items-center gap-2 text-xs">
                  <span className="w-16 font-semibold text-zinc-300 truncate">{r.series.sh}</span>
                  <div className="flex-1 h-5 bg-zinc-950 rounded-lg overflow-hidden flex border border-zinc-800">
                    {r.attempted > 0 && (
                      <div
                        style={{ width: `${(r.attempted / r.total) * 100}%` }}
                        className="bg-emerald-500 text-black font-extrabold text-[10px] flex items-center justify-center transition-all"
                      >
                        {r.attempted}
                      </div>
                    )}
                    {r.missed > 0 && (
                      <div
                        style={{ width: `${(r.missed / r.total) * 100}%` }}
                        className="bg-amber-500 text-black font-extrabold text-[10px] flex items-center justify-center transition-all"
                      >
                        {r.missed}
                      </div>
                    )}
                    {r.upcoming > 0 && (
                      <div
                        style={{ width: `${(r.upcoming / r.total) * 100}%` }}
                        className="bg-zinc-800/80 text-zinc-400 text-[10px] flex items-center justify-center"
                      />
                    )}
                  </div>
                  <span className="w-10 text-right text-[11px] text-zinc-500 font-medium">
                    {r.attempted}/{r.total}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-zinc-800 text-zinc-400 uppercase text-[10px]">
                  <th className="py-1.5 pr-2">Series</th>
                  <th className="py-1.5 px-2 text-right">Done</th>
                  <th className="py-1.5 px-2 text-right">Backlog</th>
                  <th className="py-1.5 px-2 text-right">Upcoming</th>
                  <th className="py-1.5 pl-2 text-right">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/60">
                {progressRows.map((r) => (
                  <tr key={r.series.id} className="text-zinc-300">
                    <td className="py-1.5 pr-2 font-semibold text-white">{r.series.name}</td>
                    <td className="py-1.5 px-2 text-right text-emerald-400 font-bold">{r.attempted}</td>
                    <td className="py-1.5 px-2 text-right text-amber-400 font-bold">{r.missed}</td>
                    <td className="py-1.5 px-2 text-right text-zinc-400">{r.upcoming}</td>
                    <td className="py-1.5 pl-2 text-right font-medium text-zinc-200">{r.total}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Series Switcher for Charts */}
      <div>
        <div className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
          View Scores &amp; Curves For:
        </div>
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {ALL_TEST_SERIES.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => setSelectedSeriesId(s.id)}
              className={`px-3.5 py-1.5 rounded-full text-xs whitespace-nowrap transition-all cursor-pointer ${
                s.id === currentSeries.id
                  ? 'bg-white text-[#0b0b0f] font-bold shadow-sm'
                  : 'bg-[#17171d] text-[#a3a3b0] font-medium hover:text-white'
              }`}
            >
              {s.name}
            </button>
          ))}
        </div>
      </div>

      {/* Score Stats Tiles */}
      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="p-2.5 rounded-xl border border-zinc-800/80 bg-zinc-900/40">
          <div className="text-xl font-extrabold text-orange-400 leading-none">{latestScore}</div>
          <div className="text-[10px] text-zinc-400 uppercase font-semibold mt-1">Latest</div>
        </div>
        <div className="p-2.5 rounded-xl border border-zinc-800/80 bg-zinc-900/40">
          <div className="text-xl font-extrabold text-purple-400 leading-none">{last3Avg}</div>
          <div className="text-[10px] text-zinc-400 uppercase font-semibold mt-1">Last 3 Avg</div>
        </div>
        <div className="p-2.5 rounded-xl border border-zinc-800/80 bg-zinc-900/40">
          <div className="text-xl font-extrabold text-emerald-400 leading-none">{bestScore}</div>
          <div className="text-[10px] text-zinc-400 uppercase font-semibold mt-1">Best</div>
        </div>
      </div>

      {/* 2. Total Score Trend Chart */}
      <div className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-4 shadow-sm backdrop-blur-sm relative">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h3 className="text-xs sm:text-sm font-bold text-white">Score Trend (0 - 720)</h3>
            <p className="text-[11px] text-zinc-400">Total score vs NEET 650 benchmark</p>
          </div>
          <button
            onClick={() => toggleMode('trend')}
            className="px-2.5 py-1 rounded-full text-xs font-semibold bg-zinc-800 border border-zinc-700 text-zinc-300 hover:text-white"
          >
            {viewModes.trend === 'chart' ? 'View Table' : 'View Chart'}
          </button>
        </div>

        {testsWithScore.length === 0 ? (
          <div className="py-12 text-center text-xs text-zinc-500">
            No test scores entered yet for {currentSeries.name}.
            <br />
            Enter a total score on any test card in the Tests tab to generate the trend.
          </div>
        ) : viewModes.trend === 'chart' ? (
          <div className="relative">
            <svg
              viewBox={`0 0 ${chartW} ${chartH}`}
              className="w-full h-auto overflow-visible"
              onMouseLeave={() => setTooltip(null)}
            >
              {/* Y Grid & Axis labels */}
              {[0, 180, 360, 540, 720].map((val) => {
                const y = getY(val, 0, 720);
                return (
                  <g key={val}>
                    <line
                      x1={padding.left}
                      x2={chartW - padding.right}
                      y1={y}
                      y2={y}
                      stroke="#27272a"
                      strokeWidth="1"
                    />
                    <text
                      x={padding.left - 6}
                      y={y + 3}
                      textAnchor="end"
                      fontSize="9"
                      fill="#71717a"
                    >
                      {val}
                    </text>
                  </g>
                );
              })}

              {/* 650 Target Line */}
              {(() => {
                const y650 = getY(650, 0, 720);
                return (
                  <g>
                    <line
                      x1={padding.left}
                      x2={chartW - padding.right}
                      y1={y650}
                      y2={y650}
                      stroke="#f59e0b"
                      strokeWidth="1.2"
                      strokeDasharray="4 3"
                    />
                    <text
                      x={padding.left + 4}
                      y={y650 - 4}
                      fontSize="9"
                      fill="#f59e0b"
                      fontWeight="bold"
                    >
                      650 target
                    </text>
                  </g>
                );
              })()}

              {/* Line Polyline */}
              {testsWithScore.length > 1 && (
                <polyline
                  points={testsWithScore
                    .map((d) => `${getX(d.ms)},${getY(d.t!, 0, 720)}`)
                    .join(' ')}
                  fill="none"
                  stroke="#ff6b3d"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              )}

              {/* Data Points */}
              {testsWithScore.map((d) => {
                const cx = getX(d.ms);
                const cy = getY(d.t!, 0, 720);
                return (
                  <g key={d.k}>
                    <circle cx={cx} cy={cy} r="5" fill="#141419" stroke="#ff6b3d" strokeWidth="2" />
                    <circle cx={cx} cy={cy} r="2.5" fill="#ff6b3d" />

                    {/* Invisible hover trigger */}
                    <rect
                      x={cx - 15}
                      y={0}
                      width="30"
                      height={chartH}
                      fill="transparent"
                      className="cursor-pointer"
                      onMouseEnter={(e) => {
                        const bounds = e.currentTarget.ownerSVGElement?.getBoundingClientRect();
                        setTooltip({
                          title: d.n,
                          subtitle: `${formatDisplayDate(d.d)} · ${d.f ? 'Full' : 'Part'} Syllabus`,
                          rows: [
                            { label: 'Total Score', value: `${d.t} / 720`, color: '#ff6b3d' },
                            ...(d.p !== null ? [{ label: 'Physics', value: `${d.p}` }] : []),
                            ...(d.c !== null ? [{ label: 'Chemistry', value: `${d.c}` }] : []),
                            ...(d.bio !== null ? [{ label: 'Biology', value: `${d.bio}` }] : []),
                            ...(d.r !== null ? [{ label: 'Rank', value: `#${d.r}` }] : []),
                            {
                              label: 'To 650',
                              value:
                                d.t! >= 650
                                  ? `+${d.t! - 650} above`
                                  : `-${650 - d.t!} short`,
                              color: d.t! >= 650 ? '#34d17f' : '#f2a93a',
                            },
                          ],
                          note: d.note,
                          x: cx,
                          y: cy,
                        });
                      }}
                    />
                  </g>
                );
              })}
            </svg>

            {/* Floating Tooltip */}
            {tooltip && (
              <div
                style={{
                  left: `${Math.max(10, Math.min(200, tooltip.x - 60))}px`,
                  top: `${Math.max(10, tooltip.y - 120)}px`,
                }}
                className="absolute z-20 pointer-events-none p-2.5 rounded-xl bg-zinc-950/95 border border-zinc-700 shadow-xl text-xs space-y-1 min-w-[150px]"
              >
                <div className="font-bold text-white text-xs">{tooltip.title}</div>
                <div className="text-[10px] text-zinc-400">{tooltip.subtitle}</div>
                <div className="space-y-0.5 pt-1 border-t border-zinc-800">
                  {tooltip.rows.map((r, i) => (
                    <div key={i} className="flex justify-between items-center text-[11px] gap-2">
                      <span className="text-zinc-400">{r.label}:</span>
                      <strong style={{ color: r.color || '#fff' }}>{r.value}</strong>
                    </div>
                  ))}
                </div>
                {tooltip.note && (
                  <div className="text-[10px] text-zinc-400 pt-1 border-t border-zinc-800 italic">
                    {tooltip.note}
                  </div>
                )}
              </div>
            )}

            <div className="text-[10px] text-zinc-400 mt-2">
              Dashed line = 650 target. Hover over data points to see test score breakdown.
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-zinc-800 text-zinc-400 uppercase text-[10px]">
                  <th className="py-1.5 pr-2">Test</th>
                  <th className="py-1.5 px-2">Date</th>
                  <th className="py-1.5 px-2 text-right">Total</th>
                  <th className="py-1.5 pl-2 text-right">To 650</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/60">
                {testsWithScore.map((d) => (
                  <tr key={d.k} className="text-zinc-300">
                    <td className="py-1.5 pr-2 font-bold text-white">{d.n}</td>
                    <td className="py-1.5 px-2 text-zinc-400">{formatDisplayDate(d.d)}</td>
                    <td className="py-1.5 px-2 text-right font-extrabold text-orange-400">{d.t}</td>
                    <td
                      className={`py-1.5 pl-2 text-right font-semibold ${
                        d.t! >= 650 ? 'text-emerald-400' : 'text-amber-400'
                      }`}
                    >
                      {d.t! >= 650 ? `+${d.t! - 650}` : `-${650 - d.t!}`}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* 3. Subject-wise Percentage Chart */}
      <div className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-4 shadow-sm backdrop-blur-sm">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h3 className="text-xs sm:text-sm font-bold text-white">Subject-wise Percentage</h3>
            <p className="text-[11px] text-zinc-400">Physics, Chemistry, and Biology (% of max)</p>
          </div>
          <button
            onClick={() => toggleMode('subject')}
            className="px-2.5 py-1 rounded-full text-xs font-semibold bg-zinc-800 border border-zinc-700 text-zinc-300 hover:text-white"
          >
            {viewModes.subject === 'chart' ? 'View Table' : 'View Chart'}
          </button>
        </div>

        {testsWithSubject.length === 0 ? (
          <div className="py-12 text-center text-xs text-zinc-500">
            No subject marks entered yet for {currentSeries.name}.
            <br />
            Fill Phy, Chem, Bot, Zoo in the Tests tab to see this curve.
          </div>
        ) : viewModes.subject === 'chart' ? (
          <div>
            {/* Subject Legend */}
            <div className="flex items-center gap-3 text-[11px] pb-2 font-semibold">
              <span className="flex items-center gap-1.5 text-blue-400">
                <span className="w-2.5 h-1 rounded bg-blue-500" /> Physics
              </span>
              <span className="flex items-center gap-1.5 text-orange-400">
                <span className="w-2.5 h-1 rounded bg-orange-500" /> Chemistry
              </span>
              <span className="flex items-center gap-1.5 text-teal-400">
                <span className="w-2.5 h-1 rounded bg-teal-400" /> Biology
              </span>
            </div>

            <svg viewBox={`0 0 ${chartW} ${chartH}`} className="w-full h-auto overflow-visible">
              {/* Y Axis Grid */}
              {[0, 25, 50, 75, 100].map((val) => {
                const y = getY(val, 0, 100);
                return (
                  <g key={val}>
                    <line
                      x1={padding.left}
                      x2={chartW - padding.right}
                      y1={y}
                      y2={y}
                      stroke="#27272a"
                      strokeWidth="1"
                    />
                    <text
                      x={padding.left - 6}
                      y={y + 3}
                      textAnchor="end"
                      fontSize="9"
                      fill="#71717a"
                    >
                      {val}%
                    </text>
                  </g>
                );
              })}

              {/* 90% Target line */}
              {(() => {
                const y90 = getY(90, 0, 100);
                return (
                  <g>
                    <line
                      x1={padding.left}
                      x2={chartW - padding.right}
                      y1={y90}
                      y2={y90}
                      stroke="#71717a"
                      strokeWidth="1.2"
                      strokeDasharray="4 3"
                    />
                    <text
                      x={padding.left + 4}
                      y={y90 - 4}
                      fontSize="9"
                      fill="#9ca3af"
                      fontWeight="bold"
                    >
                      90% ≈ 650
                    </text>
                  </g>
                );
              })()}

              {/* Physics Line */}
              {testsWithSubject.filter((d) => d.p !== null).length > 1 && (
                <polyline
                  points={testsWithSubject
                    .filter((d) => d.p !== null)
                    .map((d) => `${getX(d.ms)},${getY((d.p! / 180) * 100, 0, 100)}`)
                    .join(' ')}
                  fill="none"
                  stroke="#3b82f6"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
              )}

              {/* Chemistry Line */}
              {testsWithSubject.filter((d) => d.c !== null).length > 1 && (
                <polyline
                  points={testsWithSubject
                    .filter((d) => d.c !== null)
                    .map((d) => `${getX(d.ms)},${getY((d.c! / 180) * 100, 0, 100)}`)
                    .join(' ')}
                  fill="none"
                  stroke="#f97316"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
              )}

              {/* Biology Line */}
              {testsWithSubject.filter((d) => d.bio !== null).length > 1 && (
                <polyline
                  points={testsWithSubject
                    .filter((d) => d.bio !== null)
                    .map((d) => `${getX(d.ms)},${getY((d.bio! / 360) * 100, 0, 100)}`)
                    .join(' ')}
                  fill="none"
                  stroke="#14b8a6"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
              )}

              {/* Dots */}
              {testsWithSubject.map((d) => {
                const cx = getX(d.ms);
                return (
                  <g key={d.k}>
                    {d.p !== null && (
                      <circle
                        cx={cx}
                        cy={getY((d.p / 180) * 100, 0, 100)}
                        r="3.5"
                        fill="#3b82f6"
                        stroke="#141419"
                        strokeWidth="1.5"
                      />
                    )}
                    {d.c !== null && (
                      <circle
                        cx={cx}
                        cy={getY((d.c / 180) * 100, 0, 100)}
                        r="3.5"
                        fill="#f97316"
                        stroke="#141419"
                        strokeWidth="1.5"
                      />
                    )}
                    {d.bio !== null && (
                      <circle
                        cx={cx}
                        cy={getY((d.bio / 360) * 100, 0, 100)}
                        r="3.5"
                        fill="#14b8a6"
                        stroke="#141419"
                        strokeWidth="1.5"
                      />
                    )}
                  </g>
                );
              })}
            </svg>

            <div className="text-[10px] text-zinc-400 mt-2">
              Biology is plotted out of 360 (Botany + Zoology). 90% benchmark in each subject targets ~650 total.
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-zinc-800 text-zinc-400 uppercase text-[10px]">
                  <th className="py-1.5 pr-2">Test</th>
                  <th className="py-1.5 px-2 text-right">Phy /180</th>
                  <th className="py-1.5 px-2 text-right">Chem /180</th>
                  <th className="py-1.5 pl-2 text-right">Bio /360</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/60">
                {testsWithSubject.map((d) => (
                  <tr key={d.k} className="text-zinc-300">
                    <td className="py-1.5 pr-2 font-bold text-white">{d.n}</td>
                    <td className="py-1.5 px-2 text-right text-blue-400 font-semibold">
                      {d.p !== null ? `${d.p} (${Math.round((d.p / 180) * 100)}%)` : '—'}
                    </td>
                    <td className="py-1.5 px-2 text-right text-orange-400 font-semibold">
                      {d.c !== null ? `${d.c} (${Math.round((d.c / 180) * 100)}%)` : '—'}
                    </td>
                    <td className="py-1.5 pl-2 text-right text-teal-400 font-semibold">
                      {d.bio !== null ? `${d.bio} (${Math.round((d.bio / 360) * 100)}%)` : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
