import { useEffect, useMemo, useState } from "react";
import { BookOpen, Download, Pencil, Search, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";
import {
  deleteBook,
  listBooks,
  openBook,
  saveBook,
  updateBook,
  type BookCard,
  type BookFile,
} from "@/lib/library-api";
import { ConfirmDialog, Field, Modal, coverTone, downloadPdf, errorText, readFileAsDataUrl } from "@/components/bits";
import { PdfReader } from "@/components/pdf-reader";

const MAX_PDF_BYTES = 2.5 * 1024 * 1024;

export function LibraryPanel({ onChange }: { onChange: () => void }) {
  const [books, setBooks] = useState<BookCard[] | null>(null);
  const [query, setQuery] = useState("");
  const [uploadOpen, setUploadOpen] = useState(false);
  const [editing, setEditing] = useState<BookCard | null>(null);
  const [removing, setRemoving] = useState<BookCard | null>(null);
  const [reader, setReader] = useState<BookFile | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  async function reload() {
    setBooks(await listBooks());
  }

  useEffect(() => {
    let cancelled = false;
    listBooks()
      .then((rows) => {
        if (!cancelled) setBooks(rows);
      })
      .catch((err: unknown) => {
        if (!cancelled) toast.error(errorText(err));
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const shown = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return (books ?? []).filter((book) => {
      if (!needle) return true;
      return (
        book.title.toLowerCase().includes(needle) ||
        book.writer.toLowerCase().includes(needle) ||
        book.ownerName.toLowerCase().includes(needle)
      );
    });
  }, [books, query]);

  async function read(book: BookCard, recordOpen: boolean) {
    setBusyId(book.id + (recordOpen ? "-read" : "-down"));
    try {
      const file = await openBook({ data: { id: book.id, recordOpen } });
      if (recordOpen) {
        setReader(file);
        onChange();
      } else {
        downloadPdf(file.pdfBase64, file.title);
      }
    } catch (err) {
      toast.error(errorText(err));
    } finally {
      setBusyId(null);
    }
  }

  return (
    <section className="space-y-5">
      <div className="lift flex flex-col gap-4 p-5 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-semibold tracking-widest text-accent uppercase">Shared shelf</p>
          <h2 className="mt-1 font-display text-3xl">Library</h2>
          <p className="mt-1 max-w-xl text-sm text-muted">
            Read the editors’ pamphlets or upload a PDF you have the right to share. Files stay with your account.
          </p>
        </div>
        <button type="button" className="btn btn-primary" onClick={() => setUploadOpen(true)}>
          <Upload className="size-4" /> Upload book
        </button>
      </div>

      <label className="lift flex h-12 items-center gap-3 px-4">
        <Search className="size-4 text-primary" />
        <input
          id="library-search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search by title, writer, or reader"
          className="w-full bg-transparent text-base outline-none placeholder:text-muted"
        />
      </label>

      {books === null ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[0, 1, 2].map((item) => (
            <div key={item} className="h-80 animate-pulse rounded-2xl bg-paper-deep motion-reduce:animate-none" />
          ))}
        </div>
      ) : shown.length === 0 ? (
        <div className="lift px-6 py-14 text-center">
          <BookOpen className="mx-auto size-8 text-primary" />
          <p className="mt-3 font-display text-2xl">{books.length === 0 ? "The shelf is empty" : "No books match"}</p>
          <p className="mt-1 text-sm text-muted">Try another search, or upload a PDF under 2.5 MB.</p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {shown.map((book) => (
            <article key={book.id} className="lift lift-hover flex flex-col p-4">
              <div className={`cover tone-${coverTone(book.title)}`}>
                <div className="cover-spine" />
                <div className="cover-face">
                  <p className="text-xs font-semibold tracking-widest text-muted uppercase">
                    {book.isCatalog ? "Pamphlet" : "Upload"}
                  </p>
                  <div>
                    <h3 className="line-clamp-2 font-display text-xl">{book.title}</h3>
                    <p className="mt-1 line-clamp-1 text-sm text-muted">{book.writer}</p>
                  </div>
                </div>
              </div>
              <p className="mt-3 text-xs text-muted">Added by {book.ownerName}</p>
              <div className="mt-3 flex flex-col gap-2">
                <button
                  type="button"
                  className="btn btn-primary"
                  disabled={!book.readable || busyId === `${book.id}-read`}
                  onClick={() => void read(book, true)}
                >
                  <BookOpen className="size-4" />
                  {busyId === `${book.id}-read` ? "Opening…" : "Read"}
                </button>
                <div className="flex gap-2">
                  <button
                    type="button"
                    className="btn btn-ghost flex-1"
                    disabled={!book.readable || busyId === `${book.id}-down`}
                    onClick={() => void read(book, false)}
                  >
                    <Download className="size-4" />
                    {busyId === `${book.id}-down` ? "Preparing…" : "Download"}
                  </button>
                  {book.isMine && (
                    <button type="button" className="btn btn-ghost flex-1" onClick={() => setEditing(book)}>
                      <Pencil className="size-4" /> Edit
                    </button>
                  )}
                  {book.isMine && (
                    <button type="button" className="btn btn-ghost size-11 px-0" aria-label="Remove book" onClick={() => setRemoving(book)}>
                      <Trash2 className="size-4" />
                    </button>
                  )}
                </div>
              </div>
            </article>
          ))}
        </div>
      )}

      {uploadOpen && (
        <UploadModal
          onClose={() => setUploadOpen(false)}
          onSaved={async () => {
            setUploadOpen(false);
            await reload();
            onChange();
            toast.success("Book saved to the shelf");
          }}
        />
      )}
      {editing && (
        <EditModal
          book={editing}
          onClose={() => setEditing(null)}
          onSaved={async () => {
            setEditing(null);
            await reload();
            toast.success("Book details updated");
          }}
        />
      )}
      {removing && (
        <ConfirmDialog
          title="Remove this book?"
          body={`“${removing.title}” will leave the shared shelf. This cannot be undone.`}
          confirmLabel="Delete book"
          onClose={() => setRemoving(null)}
          onConfirm={() => {
            void (async () => {
              try {
                await deleteBook({ data: removing.id });
                setRemoving(null);
                await reload();
                onChange();
              } catch (err) {
                toast.error(errorText(err));
              }
            })();
          }}
        />
      )}
      {reader && (
        <PdfReader
          title={reader.title}
          writer={reader.writer}
          pdfBase64={reader.pdfBase64}
          onClose={() => setReader(null)}
        />
      )}
    </section>
  );
}

function UploadModal({ onClose, onSaved }: { onClose: () => void; onSaved: () => Promise<void> }) {
  const [title, setTitle] = useState("");
  const [writer, setWriter] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit() {
    if (!file) {
      toast.error("Choose a PDF to upload.");
      return;
    }
    if (file.size > MAX_PDF_BYTES) {
      toast.error("That PDF is too large. Keep uploads under 2.5 MB.");
      return;
    }
    setBusy(true);
    try {
      const pdfData = await readFileAsDataUrl(file);
      await saveBook({ data: { title, writer, pdfData } });
      await onSaved();
    } catch (err) {
      toast.error(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal title="Upload a book" onClose={onClose}>
      <div className="space-y-4">
        <Field label="Title">
          <input id="book-title" className="field-input" value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Evening notes on rest" />
        </Field>
        <Field label="Writer">
          <input id="book-writer" className="field-input" value={writer} onChange={(event) => setWriter(event.target.value)} placeholder="Your name" />
        </Field>
        <Field label="PDF file">
          <input
            id="book-file"
            className="block w-full text-sm"
            type="file"
            accept="application/pdf"
            onChange={(event) => setFile(event.target.files?.[0] ?? null)}
          />
          <span className="mt-1 block text-xs text-muted">PDF only, up to 2.5 MB. Share work you have the right to upload.</span>
        </Field>
        <div className="flex justify-end gap-2 pt-1">
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>Cancel</button>
          <button type="button" className="btn btn-primary" onClick={() => void submit()} disabled={busy}>
            {busy ? "Saving…" : "Save to shelf"}
          </button>
        </div>
      </div>
    </Modal>
  );
}

function EditModal({
  book,
  onClose,
  onSaved,
}: {
  book: BookCard;
  onClose: () => void;
  onSaved: () => Promise<void>;
}) {
  const [title, setTitle] = useState(book.title);
  const [writer, setWriter] = useState(book.writer);
  const [busy, setBusy] = useState(false);

  async function submit() {
    setBusy(true);
    try {
      await updateBook({ data: { id: book.id, title, writer } });
      await onSaved();
    } catch (err) {
      toast.error(errorText(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal title="Edit book details" onClose={onClose}>
      <div className="space-y-4">
        <Field label="Title">
          <input className="field-input" value={title} onChange={(event) => setTitle(event.target.value)} />
        </Field>
        <Field label="Writer">
          <input className="field-input" value={writer} onChange={(event) => setWriter(event.target.value)} />
        </Field>
        <div className="flex justify-end gap-2">
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>Cancel</button>
          <button type="button" className="btn btn-primary" onClick={() => void submit()} disabled={busy}>
            {busy ? "Saving…" : "Save changes"}
          </button>
        </div>
      </div>
    </Modal>
  );
}
