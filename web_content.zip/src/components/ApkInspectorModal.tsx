import React, { useState } from 'react';
import { AppConfig, WebFile } from '../types/apk';
import { generateManifestXml } from '../utils/manifestBuilder';
import { Code2, Copy, Check, FileText, Layers, ShieldCheck, X } from 'lucide-react';

interface ApkInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: AppConfig;
  webFiles: WebFile[];
}

export const ApkInspectorModal: React.FC<ApkInspectorModalProps> = ({
  isOpen,
  onClose,
  config,
  webFiles,
}) => {
  const [activeTab, setActiveTab] = useState<'manifest' | 'tree' | 'permissions'>('manifest');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const manifestXml = generateManifestXml(config);

  const copyManifest = () => {
    navigator.clipboard.writeText(manifestXml);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const enabledPermissions = Object.entries(config.permissions)
    .filter(([_, enabled]) => enabled)
    .map(([k]) => k.toUpperCase());

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2">
            <Code2 className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-white text-base">APK Package Inspector</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Subnav Tabs */}
        <div className="px-6 pt-3 border-b border-slate-800 flex items-center gap-4 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('manifest')}
            className={`pb-2.5 transition-colors border-b-2 flex items-center gap-1.5 ${
              activeTab === 'manifest'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>AndroidManifest.xml</span>
          </button>

          <button
            onClick={() => setActiveTab('tree')}
            className={`pb-2.5 transition-colors border-b-2 flex items-center gap-1.5 ${
              activeTab === 'tree'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Package Internal Tree</span>
          </button>

          <button
            onClick={() => setActiveTab('permissions')}
            className={`pb-2.5 transition-colors border-b-2 flex items-center gap-1.5 ${
              activeTab === 'permissions'
                ? 'border-emerald-400 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Permissions ({enabledPermissions.length})</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1">
          {activeTab === 'manifest' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Android Source Manifest for {config.packageName}</span>
                <button
                  onClick={copyManifest}
                  className="flex items-center gap-1 text-slate-300 hover:text-white bg-slate-800 px-2.5 py-1 rounded-md transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy XML'}</span>
                </button>
              </div>
              <pre className="p-4 bg-slate-950 border border-slate-800 rounded-xl font-mono text-xs text-slate-300 overflow-x-auto leading-relaxed max-h-[460px]">
                {manifestXml}
              </pre>
            </div>
          )}

          {activeTab === 'tree' && (
            <div className="space-y-4 text-xs font-mono">
              <p className="text-slate-400 font-sans">
                Internal structure of the generated APK zip container:
              </p>

              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-1.5 text-slate-300 leading-normal">
                <div className="text-emerald-400 font-bold">{config.appName.toLowerCase().replace(/[^a-z0-9]/g, '_')}.apk</div>
                <div className="pl-4 text-slate-400">├── AndroidManifest.xml (Compiled binary AXML)</div>
                <div className="pl-4 text-slate-400">├── classes.dex (Dalvik bytecode executable)</div>
                <div className="pl-4 text-slate-400">├── resources.arsc (Resource table)</div>
                <div className="pl-4 text-slate-400">├── res/</div>
                <div className="pl-8 text-slate-500">├── mipmap-mdpi/ic_launcher.png (48x48)</div>
                <div className="pl-8 text-slate-500">├── mipmap-hdpi/ic_launcher.png (72x72)</div>
                <div className="pl-8 text-slate-500">├── mipmap-xhdpi/ic_launcher.png (96x96)</div>
                <div className="pl-8 text-slate-500">├── mipmap-xxhdpi/ic_launcher.png (144x144)</div>
                <div className="pl-8 text-slate-500">└── mipmap-xxxhdpi/ic_launcher.png (192x192)</div>
                <div className="pl-4 text-slate-400">├── assets/www/</div>
                {webFiles.slice(0, 10).map((f, i) => (
                  <div key={i} className="pl-8 text-emerald-300/80">
                    {i === 9 && webFiles.length > 10 ? `└── ... (+${webFiles.length - 10} more files)` : `├── ${f.path}`}
                  </div>
                ))}
                <div className="pl-4 text-slate-400">└── META-INF/</div>
                <div className="pl-8 text-slate-500">├── MANIFEST.MF (SHA-256 digests)</div>
                <div className="pl-8 text-slate-500">├── CERT.SF (Signature file)</div>
                <div className="pl-8 text-slate-500">└── CERT.RSA (PKCS#7 X.509 Certificate)</div>
              </div>
            </div>
          )}

          {activeTab === 'permissions' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-400">
                Permissions requested in <code className="text-emerald-400">AndroidManifest.xml</code>:
              </p>
              <div className="divide-y divide-slate-800 border border-slate-800 rounded-xl overflow-hidden bg-slate-950">
                {Object.entries(config.permissions).map(([key, enabled]) => (
                  <div key={key} className="p-3 flex items-center justify-between text-xs">
                    <span className="font-mono text-slate-300">android.permission.{key.toUpperCase()}</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                        enabled
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                          : 'text-slate-600'
                      }`}
                    >
                      {enabled ? 'Granted' : 'Omitted'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-slate-800 bg-slate-950/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
