import React from 'react';
import { Receipt, CheckCircle, AlertCircle, FileSpreadsheet, Download, ShieldCheck } from 'lucide-react';
import { Voucher } from '../types/tally';
import { computeGSTSummary, formatCurrency } from '../utils/tallyEngine';

interface GSTReportViewProps {
  vouchers: Voucher[];
}

export const GSTReportView: React.FC<GSTReportViewProps> = ({ vouchers }) => {
  const gst = computeGSTSummary(vouchers);

  return (
    <div className="flex-1 flex flex-col pb-8 text-slate-800 dark:text-slate-100">
      {/* Header bar */}
      <div className="bg-emerald-900 text-white px-4 py-3 shadow-xs">
        <div className="text-[10px] uppercase font-bold text-emerald-300 tracking-wider">
          Compliance & Taxation
        </div>
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold">GST Return Summary (GSTR-1 & 3B)</h2>
          <span className="text-[11px] text-emerald-200 font-mono">Monthly Filing</span>
        </div>
      </div>

      {/* Tax Liability Banner */}
      <div className="p-3 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
        <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-between">
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-400">
              Net GST Cash Payable
            </div>
            <div className="text-xl font-bold font-mono text-slate-900 dark:text-white tabular-nums mt-0.5">
              {formatCurrency(gst.netTaxPayable)}
            </div>
            <div className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium mt-0.5">
              After setting off Input Tax Credit (ITC)
            </div>
          </div>

          <div className="text-right text-xs font-mono">
            <div className="text-rose-600">Output Tax: {formatCurrency(gst.totalOutputTax)}</div>
            <div className="text-emerald-600">Less ITC: -{formatCurrency(gst.totalInputTax)}</div>
          </div>
        </div>
      </div>

      <div className="p-3 space-y-4">
        {/* GSTR-1: OUTWARD SUPPLIES */}
        <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-xs">
          <div className="px-3 py-2 bg-slate-100 dark:bg-slate-800 text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-200 flex items-center justify-between">
            <span>GSTR-1: Outward Supplies (Sales)</span>
            <span className="text-[10px] font-normal text-slate-500 font-mono">{gst.b2bCount} Invoices</span>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-700/60 p-3 text-xs font-mono space-y-2">
            <div className="flex justify-between text-slate-600 dark:text-slate-300">
              <span>Total Taxable Value:</span>
              <span className="font-bold tabular-nums">{formatCurrency(gst.outwardTaxable)}</span>
            </div>

            <div className="flex justify-between text-slate-500">
              <span>Central Tax (CGST 9%):</span>
              <span className="tabular-nums">{formatCurrency(gst.outputCGST)}</span>
            </div>

            <div className="flex justify-between text-slate-500">
              <span>State Tax (SGST 9%):</span>
              <span className="tabular-nums">{formatCurrency(gst.outputSGST)}</span>
            </div>

            <div className="flex justify-between text-slate-500">
              <span>Integrated Tax (IGST 18%):</span>
              <span className="tabular-nums">{formatCurrency(gst.outputIGST)}</span>
            </div>

            <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex justify-between font-bold text-slate-900 dark:text-white">
              <span>Total Output Tax Collected:</span>
              <span className="tabular-nums text-rose-600">{formatCurrency(gst.totalOutputTax)}</span>
            </div>
          </div>
        </div>

        {/* GSTR-3B: INWARD SUPPLIES & ITC */}
        <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-xs">
          <div className="px-3 py-2 bg-slate-100 dark:bg-slate-800 text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-200 flex items-center justify-between">
            <span>GSTR-3B: Eligible Input Tax Credit (ITC)</span>
            <span className="text-[10px] font-normal text-emerald-600">Inward Bills</span>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-700/60 p-3 text-xs font-mono space-y-2">
            <div className="flex justify-between text-slate-600 dark:text-slate-300">
              <span>Inward Taxable Purchases:</span>
              <span className="font-bold tabular-nums">{formatCurrency(gst.inwardTaxable)}</span>
            </div>

            <div className="flex justify-between text-slate-500">
              <span>Input CGST Claimable:</span>
              <span className="tabular-nums">{formatCurrency(gst.inputCGST)}</span>
            </div>

            <div className="flex justify-between text-slate-500">
              <span>Input SGST Claimable:</span>
              <span className="tabular-nums">{formatCurrency(gst.inputSGST)}</span>
            </div>

            <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex justify-between font-bold text-slate-900 dark:text-white">
              <span>Total Input Tax Credit (ITC):</span>
              <span className="tabular-nums text-emerald-600">{formatCurrency(gst.totalInputTax)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
