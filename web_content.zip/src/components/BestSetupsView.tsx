import React from 'react';
import { Camera, Zap, RefreshCw, ArrowRight, ArrowDownRight, ArrowUpRight, Flame, ShieldAlert, Sparkles, Activity } from 'lucide-react';
import { QuantumSignal, Asset } from '../types/trading';
import { soundManager } from '../utils/soundEffects';

interface BestSetupsViewProps {
  onSelectPhotoMode: () => void;
  onSelectManualMode: () => void;
  onSelectSetup: (pairSymbol: string) => void;
  signalsCountToday: number;
}

interface SetupItem {
  id: string;
  pair: string;
  type: 'PUT' | 'CALL';
  entryTime: string;
  confidence: number;
  isSniper99: boolean;
}

export const BestSetupsView: React.FC<BestSetupsViewProps> = ({
  onSelectPhotoMode,
  onSelectManualMode,
  onSelectSetup,
  signalsCountToday,
}) => {
  const [refreshing, setRefreshing] = React.useState(false);
  const [setups, setSetups] = React.useState<SetupItem[]>([
    { id: '1', pair: 'USD/BDT OTC', type: 'CALL', entryTime: 'Next Candle', confidence: 99.2, isSniper99: true },
    { id: '2', pair: 'GBP/JPY OTC', type: 'PUT', entryTime: 'Next Candle', confidence: 80.5, isSniper99: false },
    { id: '3', pair: 'USD/INR OTC', type: 'PUT', entryTime: 'Next Candle', confidence: 78.4, isSniper99: false },
    { id: '4', pair: 'AUD/CHF OTC', type: 'PUT', entryTime: 'Next Candle', confidence: 83.1, isSniper99: false },
    { id: '5', pair: 'EUR/USD OTC', type: 'CALL', entryTime: 'Next Candle', confidence: 99.1, isSniper99: true },
  ]);

  const handleRefresh = () => {
    setRefreshing(true);
    soundManager.playPip();
    setTimeout(() => {
      setSetups([
        { id: '1', pair: 'USD/BDT OTC', type: 'CALL', entryTime: 'Next Candle', confidence: 99.4, isSniper99: true },
        { id: '2', pair: 'EUR/USD OTC', type: 'CALL', entryTime: 'Next Candle', confidence: 99.1, isSniper99: true },
        { id: '3', pair: 'GBP/JPY OTC', type: 'PUT', entryTime: 'Next Candle', confidence: 82.3, isSniper99: false },
        { id: '4', pair: 'USD/INR OTC', type: 'PUT', entryTime: 'Next Candle', confidence: 79.5, isSniper99: false },
        { id: '5', pair: 'BTC/USD OTC', type: 'CALL', entryTime: 'Next Candle', confidence: 98.8, isSniper99: true },
      ]);
      setRefreshing(false);
    }, 600);
  };

  return (
    <div className="w-full max-w-lg mx-auto flex flex-col items-center px-3 py-2 space-y-4">
      {/* Welcome Banner (Screenshot 7) */}
      <div className="w-full text-left">
        <h2 className="text-sm sm:text-base font-extrabold text-slate-100 tracking-wider uppercase flex items-center gap-1.5">
          <span>WELCOME, ELITE TRADER</span>
          <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping"></span>
        </h2>
        <p className="text-xs text-zinc-400 mt-0.5">
          Choose how the Quantum engine finds your next signal
        </p>
      </div>

      {/* 2 Primary Mode Choice Cards (Screenshot 7) */}
      <div className="w-full space-y-2.5">
        {/* Card 1: Photo Analysis */}
        <div
          onClick={() => {
            soundManager.playPip();
            onSelectPhotoMode();
          }}
          className="w-full bg-[#180710] hover:bg-[#200a16] border border-[#3b1223] hover:border-red-500/60 rounded-2xl p-3.5 flex items-center justify-between cursor-pointer transition-all duration-200 group shadow-md active:scale-[0.99]"
        >
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-red-950/80 border border-red-500/30 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <Camera className="w-5 h-5 text-red-500" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-black text-slate-100 group-hover:text-red-400 transition-colors">
                  Photo Analysis
                </h3>
                <span className="text-[10px] font-black px-1.5 py-0.2 bg-red-600 text-white rounded font-mono shadow-sm">
                  NEW
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-0.5 leading-snug">
                Upload a chart screenshot — AI reads the pair & gives a signal
              </p>
            </div>
          </div>
          <ArrowRight className="w-5 h-5 text-zinc-600 group-hover:text-red-400 group-hover:translate-x-0.5 transition-all" />
        </div>

        {/* Card 2: Manual Analysis */}
        <div
          onClick={() => {
            soundManager.playPip();
            onSelectManualMode();
          }}
          className="w-full bg-[#180710] hover:bg-[#200a16] border border-[#3b1223] hover:border-emerald-500/60 rounded-2xl p-3.5 flex items-center justify-between cursor-pointer transition-all duration-200 group shadow-md active:scale-[0.99]"
        >
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-950/80 border border-emerald-500/30 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <Zap className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-sm font-black text-slate-100 group-hover:text-emerald-400 transition-colors">
                Manual Analysis
              </h3>
              <p className="text-xs text-zinc-400 mt-0.5 leading-snug">
                Pick pair & timeframe yourself — classic AI signal flow
              </p>
            </div>
          </div>
          <ArrowRight className="w-5 h-5 text-zinc-600 group-hover:text-emerald-400 group-hover:translate-x-0.5 transition-all" />
        </div>
      </div>

      {/* TODAY'S BEST SETUPS Section (Screenshot 7) */}
      <div className="w-full pt-2">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-1.5 text-xs font-black tracking-wider text-slate-200 uppercase">
            <Flame className="w-4 h-4 text-red-500 fill-red-500" />
            <span>TODAY'S BEST SETUPS</span>
          </div>
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="flex items-center gap-1 text-[11px] font-bold text-zinc-400 hover:text-zinc-200 transition-colors"
          >
            <RefreshCw className={`w-3 h-3 ${refreshing ? 'animate-spin text-red-400' : ''}`} />
            <span>REFRESH</span>
          </button>
        </div>

        {/* Setups list */}
        <div className="space-y-2">
          {setups.map((setup) => {
            const isCall = setup.type === 'CALL';
            return (
              <div
                key={setup.id}
                onClick={() => {
                  soundManager.playPip();
                  onSelectSetup(setup.pair);
                }}
                className={`w-full bg-[#16060f] hover:bg-[#200815] border rounded-xl p-3 flex items-center justify-between cursor-pointer transition-all duration-150 active:scale-[0.99] ${
                  setup.isSniper99
                    ? 'border-amber-600/50 shadow-[0_0_12px_rgba(245,158,11,0.15)]'
                    : 'border-[#2f0e1c]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border ${
                      isCall
                        ? 'bg-emerald-950 text-emerald-400 border-emerald-700/50'
                        : 'bg-red-950 text-red-500 border-red-700/50'
                    }`}
                  >
                    {isCall ? (
                      <ArrowUpRight className="w-4 h-4" />
                    ) : (
                      <ArrowDownRight className="w-4 h-4" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold font-mono text-slate-100">
                        {setup.pair}
                      </span>
                      {setup.isSniper99 && (
                        <span className="text-[9px] font-extrabold px-1.5 py-0.2 bg-amber-950 text-amber-300 border border-amber-600/50 rounded font-mono">
                          99% SNIPER
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-zinc-400">
                      <span className={isCall ? 'text-emerald-400 font-semibold' : 'text-red-400 font-semibold'}>
                        {setup.type} signal
                      </span>
                      <span>·</span>
                      <span className="text-zinc-500">Entry next candle</span>
                    </div>
                  </div>
                </div>

                {/* Confidence */}
                <div className="text-right">
                  <div
                    className={`text-sm sm:text-base font-black font-mono tabular-nums ${
                      setup.confidence >= 95
                        ? 'text-amber-300'
                        : isCall
                        ? 'text-emerald-400'
                        : 'text-red-400'
                    }`}
                  >
                    {setup.confidence}%
                  </div>
                  <div className="text-[9px] text-zinc-500 uppercase font-semibold">
                    CONFIDENCE
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Signals Generated Today Banner (Screenshot 7) */}
      <div className="w-full bg-[#180710] border border-[#3b1223] rounded-2xl p-3.5 flex items-center justify-between shadow-inner">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-bold text-zinc-300">
            Signals generated today
          </span>
        </div>
        <span className="text-base sm:text-lg font-black font-mono text-emerald-400 tabular-nums">
          {signalsCountToday.toLocaleString()}
        </span>
      </div>
    </div>
  );
};
