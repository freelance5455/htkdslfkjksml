import React, { useState } from 'react';
import { Send, Smartphone, Hash, Radio, ExternalLink, CheckCircle } from 'lucide-react';
import { CNICRecord, Language, SIMSlot, TelecomOperator } from '../types';
import { formatCNIC } from '../utils/cnic';
import { t } from '../utils/translations';
import { sounds } from '../utils/audio';

interface SmsRequestCardProps {
  selectedSim: SIMSlot;
  operator: TelecomOperator;
  selectedRecord: CNICRecord | null;
  onSendRequest: () => void;
  sendStatusText: string;
  language: Language;
  onShowToast: (message: string, type?: 'success' | 'warning' | 'info') => void;
}

export const SmsRequestCard: React.FC<SmsRequestCardProps> = ({
  selectedSim,
  operator,
  selectedRecord,
  onSendRequest,
  sendStatusText,
  language,
  onShowToast,
}) => {
  const tr = t[language];
  const [isSending, setIsSending] = useState<boolean>(false);

  const handleSend = () => {
    if (!selectedRecord) {
      sounds.playError();
      onShowToast(tr.selectFirstAlert, 'warning');
      return;
    }

    if (selectedRecord.status !== 'Added') {
      sounds.playError();
      onShowToast(tr.alreadyUsedAlert, 'warning');
      return;
    }

    setIsSending(true);
    sounds.playSend();

    setTimeout(() => {
      onSendRequest();
      setIsSending(false);
      sounds.playSuccess();
      onShowToast(
        language === 'ur'
          ? '668 درخواست کامیابی کے ساتھ ارسال ہو گئی!'
          : '668 SIM Inquiry request dispatched!',
        'success'
      );
    }, 450);
  };

  const handleOpenMobileSms = () => {
    if (!selectedRecord) {
      sounds.playError();
      onShowToast(tr.selectFirstAlert, 'warning');
      return;
    }
    sounds.playClick();
    // Launch Android / iOS native SMS intent for Pakistan 668
    const smsUrl = `sms:668?body=${encodeURIComponent(selectedRecord.cnic)}`;
    window.location.href = smsUrl;
    onShowToast(tr.statusSmsAppOpened, 'info');
  };

  return (
    <div className="card-cyber relative p-5 rounded-2xl border border-[#247ab0] bg-gradient-to-br from-[#172e4d] to-[#0a1425] shadow-[0_5px_25px_rgba(0,30,65,0.45)] transition-all hover:border-[#389bd9]">
      <div className="flex items-center justify-between mb-4 pb-2 border-b border-[#214c77]">
        <div className="flex items-center gap-2">
          <Send className="w-5 h-5 text-[#41eaff]" />
          <h3 className="text-base sm:text-lg font-bold text-[#41eaff] tracking-wide m-0">
            {tr.smsRequest}
          </h3>
        </div>
        <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-cyan-950/70 border border-cyan-500/30 text-cyan-300 text-xs font-mono">
          <Radio className="w-3 h-3 text-cyan-400 animate-pulse" />
          <span>PORT 668</span>
        </div>
      </div>

      {/* Request Details Box */}
      <div className="p-3.5 bg-[#081525] border border-[#1f476e] rounded-xl space-y-2.5 text-xs sm:text-sm">
        <div className="flex items-center justify-between">
          <span className="text-[#9cb9d5] flex items-center gap-1.5">
            <Hash className="w-4 h-4 text-cyan-400" />
            {tr.destination}
          </span>
          <span className="font-mono font-bold text-cyan-300 text-base">
            668 <span className="text-xs text-slate-400 font-normal hidden sm:inline">(PTA System)</span>
          </span>
        </div>

        <div className="flex items-center justify-between border-t border-[#173351] pt-2">
          <span className="text-[#9cb9d5] flex items-center gap-1.5">
            <Smartphone className="w-4 h-4 text-cyan-400" />
            {language === 'ur' ? 'منتخب کردہ سم:' : 'Selected SIM:'}
          </span>
          <span className="font-semibold text-white font-mono">
            {selectedSim} ({operator})
          </span>
        </div>

        <div className="flex items-center justify-between border-t border-[#173351] pt-2">
          <span className="text-[#9cb9d5]">
            {tr.selectedCnicLabel}
          </span>
          <span className="font-mono font-bold text-[#4ceaff]">
            {selectedRecord ? formatCNIC(selectedRecord.cnic) : tr.noneSelected}
          </span>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="space-y-2 mt-4">
        <button
          type="button"
          onClick={handleSend}
          disabled={isSending}
          className="w-full p-3.5 border-0 rounded-xl bg-gradient-to-r from-[#087bd1] via-[#00a3cc] to-[#00d5ed] text-white font-bold text-sm tracking-wide shadow-[0_4px_20px_rgba(0,213,237,0.3)] hover:brightness-110 active:scale-[0.98] transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
        >
          <Send className={`w-4 h-4 ${isSending ? 'animate-bounce' : ''}`} />
          <span>{isSending ? 'SENDING INQUIRY...' : tr.sendRequestBtn}</span>
        </button>

        {/* Real Native Android SMS App Integration */}
        <button
          type="button"
          onClick={handleOpenMobileSms}
          className="w-full p-2.5 rounded-xl border border-[#208fc0]/60 bg-[#0c243f] hover:bg-[#123356] text-cyan-200 text-xs font-semibold tracking-wide transition-all cursor-pointer flex items-center justify-center gap-1.5"
          title="Opens default phone SMS app addressed to 668 with the CNIC pre-filled"
        >
          <ExternalLink className="w-3.5 h-3.5 text-cyan-400" />
          <span>{tr.openSmsAppBtn}</span>
        </button>
      </div>

      {/* Disclaimers & Status */}
      <div className="mt-3.5 pt-3 border-t border-[#183552] text-center space-y-1">
        <p className="text-xs text-[#9cb9d5] m-0">
          {tr.demoNotice}
        </p>
        <p className="text-xs font-mono font-bold text-[#50f6b0] tracking-wider m-0 flex items-center justify-center gap-1.5">
          <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
          <span id="sendStatus">{sendStatusText}</span>
        </p>
      </div>
    </div>
  );
};
