import React, { useState } from "react";
import {
  Search,
  Plus,
  Clock,
  Terminal,
  CheckSquare,
  Square,
  Mic,
  X,
  SlidersHorizontal,
  Menu,
  Feather,
  Check,
  Sun,
  Moon,
  Smartphone,
  Monitor,
  ChevronUp,
  ChevronDown,
  Sparkles,
  FileText,
  Layers,
  ArrowRight,
  Palette,
  Layout
} from "lucide-react";
import { Note, UIThemeStyle } from "../types";

interface IntegratedStrategicPKMViewProps {
  notes?: Note[];
  onOpenNote?: (note: Note) => void;
  onOpenNewNote?: () => void;
  onQuickCapture?: (draft: Partial<Note>) => void;
  onSwitchToTheme?: (style: UIThemeStyle) => void;
  onOpenThemeSettings?: () => void;
}

export type CircadianDisplayMode = "split" | "day" | "night";
export type FrameViewMode = "mockup" | "fullscreen";

/**
 * IntegratedStrategicPKMView Component
 * Exact implementation of the Circadian Dual-Theme PKM ("NOTLARIM") style
 * Features:
 * - 12:00 Gündüz (Warm parchment #FAF6EE, espresso pill, red/coral glow border #E0533C)
 * - 22:00 Gece (Obsidian dark #15161A, carbon pill, vivid magenta glow border #E11D48)
 * - Exact "NOTLARIM" header typography with menu and search icons
 * - Frosted glass radial quick-action disc with Metin, Sesli, Liste and Checkmark
 * - Orbital transition arc with directional chevrons
 * - Mobile Phone Frame mockup & Fullscreen Studio modes
 */
export const IntegratedStrategicPKMView: React.FC<IntegratedStrategicPKMViewProps> = ({
  notes = [],
  onOpenNote,
  onOpenNewNote,
  onQuickCapture,
  onSwitchToTheme,
  onOpenThemeSettings,
}) => {
  const [circadianMode, setCircadianMode] = useState<CircadianDisplayMode>("split");
  const [frameMode, setFrameMode] = useState<FrameViewMode>("mockup");
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isRadialDiskOpen, setIsRadialDiskOpen] = useState(true);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  // Day & Night tasks
  const [nightTasks, setNightTasks] = useState([
    { id: "nt-1", text: "Learn motor-spence data", type: "ERR", color: "#EF4444", done: false },
    { id: "nt-2", text: "data: 00.12.13.0.25 - 0670", type: "INFO", color: "#00F5FF", done: true },
    { id: "nt-3", text: "data line:229.180.46.51... #80F5FF", type: "INFO", color: "#80F5FF", done: false },
  ]);

  const handleCreateDraft = (type: "text" | "voice" | "checklist") => {
    if (onQuickCapture) {
      if (type === "voice") {
        onQuickCapture({
          title: "Sesli Not Kaydı 🎙️",
          content: "Ses kaydı başlatıldı...",
          category: "Ses",
          tags: ["#sesli", "#circadian"],
        });
      } else if (type === "checklist") {
        onQuickCapture({
          title: "Yeni Görev Listesi ☑️",
          content: "Görev öğeleri:\n- [ ] Yeni görev",
          category: "Görevler",
          tags: ["#liste", "#görev"],
        });
      } else {
        onQuickCapture({
          title: "Hızlı Düşünce Notu ✍️",
          content: "",
          category: "Genel",
          tags: ["#metin", "#hızlıyakalama"],
        });
      }
    } else if (onOpenNewNote) {
      onOpenNewNote();
    }
  };

  return (
    <div className="w-full min-h-screen py-4 px-2 md:px-6 flex flex-col items-center justify-start space-y-6 select-none">
      
      {/* 1. TOP CONTROL DOCK: MODE & FRAME TOGGLE */}
      <section className="w-full max-w-4xl bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border border-stone-200 dark:border-slate-800 rounded-2xl p-3 px-4 flex flex-wrap items-center justify-between gap-3 shadow-md z-30">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#E0533C] to-[#E11D48] text-white flex items-center justify-center font-black text-xs shadow-md">
            PKM
          </div>
          <div>
            <h2 className="text-xs font-black tracking-wider uppercase text-stone-900 dark:text-white">
              Sirkadiyen Stratejik PKM
            </h2>
            <span className="text-[10px] font-bold text-[#E0533C] dark:text-[#E11D48] uppercase tracking-widest block">
              12:00 Gündüz & 22:00 Gece İkili Mod
            </span>
          </div>
        </div>

        {/* Display Mode Toggles */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center bg-stone-100 dark:bg-slate-800 p-1 rounded-xl border border-stone-200 dark:border-slate-700">
            <button
              onClick={() => setCircadianMode("split")}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                circadianMode === "split"
                  ? "bg-gradient-to-r from-[#E0533C] to-[#E11D48] text-white shadow-sm"
                  : "text-stone-600 dark:text-slate-400 hover:text-stone-900 dark:hover:text-white"
              }`}
              title="İkili Bölünmüş Sirkadiyen Görünüm"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">İkili Bölünmüş</span>
            </button>
            <button
              onClick={() => setCircadianMode("day")}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                circadianMode === "day"
                  ? "bg-[#FAF6EE] text-[#352014] border border-[#E0533C] shadow-sm font-black"
                  : "text-stone-600 dark:text-slate-400 hover:text-stone-900 dark:hover:text-white"
              }`}
              title="12:00 Gündüz Modu"
            >
              <Sun className="w-3.5 h-3.5 text-[#E0533C]" />
              <span className="hidden sm:inline">12:00 Gündüz</span>
            </button>
            <button
              onClick={() => setCircadianMode("night")}
              className={`px-2.5 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                circadianMode === "night"
                  ? "bg-[#15161A] text-[#E11D48] border border-[#E11D48] shadow-sm font-black"
                  : "text-stone-600 dark:text-slate-400 hover:text-stone-900 dark:hover:text-white"
              }`}
              title="22:00 Gece Modu"
            >
              <Moon className="w-3.5 h-3.5 text-[#E11D48]" />
              <span className="hidden sm:inline">22:00 Gece</span>
            </button>
          </div>

          {/* Frame Toggle */}
          <div className="flex items-center bg-stone-100 dark:bg-slate-800 p-1 rounded-xl border border-stone-200 dark:border-slate-700">
            <button
              onClick={() => setFrameMode("mockup")}
              className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                frameMode === "mockup"
                  ? "bg-white dark:bg-slate-700 text-[#E11D48] shadow-sm"
                  : "text-stone-500 hover:text-stone-900 dark:hover:text-white"
              }`}
              title="Mobil Cihaz Görünümü (Mockup)"
            >
              <Smartphone className="w-4 h-4" />
            </button>
            <button
              onClick={() => setFrameMode("fullscreen")}
              className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                frameMode === "fullscreen"
                  ? "bg-white dark:bg-slate-700 text-[#E11D48] shadow-sm"
                  : "text-stone-500 hover:text-stone-900 dark:hover:text-white"
              }`}
              title="Geniş Ekran Stüdyo Modu"
            >
              <Monitor className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Style Switcher & Profile Theme Shortcut */}
          <div className="flex items-center gap-1.5 flex-wrap">
            {onSwitchToTheme && (
              <button
                onClick={() => onSwitchToTheme("minimalist")}
                className="px-2.5 py-1.5 rounded-xl text-xs font-bold bg-stone-100 hover:bg-stone-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-stone-700 dark:text-stone-300 flex items-center gap-1.5 transition-all cursor-pointer border border-stone-200 dark:border-slate-700"
                title="Klasik NoteFlow arayüzüne geri dön"
              >
                <Layout className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                <span className="hidden sm:inline">Klasik Stil</span>
              </button>
            )}
            {onOpenThemeSettings && (
              <button
                onClick={onOpenThemeSettings}
                className="px-2.5 py-1.5 rounded-xl text-xs font-bold bg-stone-100 hover:bg-stone-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-stone-700 dark:text-stone-300 flex items-center gap-1.5 transition-all cursor-pointer border border-stone-200 dark:border-slate-700"
                title="Profil > Tema ve Arayüz Ayarlarını Aç"
              >
                <Palette className="w-3.5 h-3.5 text-[#E11D48]" />
                <span className="hidden sm:inline">Stil Değiştir</span>
              </button>
            )}
          </div>
        </div>
      </section>

      {/* 2. MAIN STAGE WRAPPER (PHONE MOCKUP OR EXPANDED CANVAS) */}
      <div
        className={`w-full transition-all duration-300 flex items-center justify-center relative ${
          frameMode === "mockup" ? "w-full max-w-full sm:max-w-[420px]" : "w-full max-w-6xl"
        }`}
      >
        {/* Left Side Timeline Markers (Visible in both views) */}
        <div className="hidden lg:flex flex-col justify-between absolute -left-28 top-20 bottom-24 w-24 text-right py-4 pointer-events-none z-10">
          <div className="space-y-0.5">
            <div className="text-xs font-black text-stone-700 dark:text-stone-300">12:00</div>
            <div className="text-[11px] font-bold text-[#E0533C]">Gündüz</div>
            <div className="w-3 h-0.5 bg-[#E0533C] ml-auto mt-1 rounded-full" />
          </div>
          <div className="space-y-0.5">
            <div className="text-xs font-black text-stone-700 dark:text-stone-300">22:00</div>
            <div className="text-[11px] font-bold text-[#E11D48]">Gece</div>
            <div className="w-3 h-0.5 bg-[#E11D48] ml-auto mt-1 rounded-full" />
          </div>
        </div>

        {/* Right Side Circadian Orbital Cycle Arc with Chevrons */}
        <div className="hidden lg:flex flex-col items-center justify-center absolute -right-20 top-1/4 bottom-1/4 w-16 pointer-events-none z-10">
          <div className="flex flex-col items-center space-y-3 opacity-80">
            <div className="flex flex-col items-center text-[#E0533C] animate-pulse">
              <ChevronUp className="w-4 h-4 -mb-2" />
              <ChevronUp className="w-4 h-4" />
            </div>
            
            {/* Curved subtle arc indicator */}
            <div className="w-7 h-24 border-r-2 border-dashed border-gradient-to-b from-[#E0533C] to-[#E11D48] rounded-r-full" />
            
            <div className="flex flex-col items-center text-[#E11D48] animate-pulse">
              <ChevronDown className="w-4 h-4 -mb-2" />
              <ChevronDown className="w-4 h-4" />
            </div>
          </div>
        </div>

        {/* THE DEVICE CONTAINER (Mobile Phone Frame with bezel or Canvas) */}
        <div
          className={`w-full overflow-hidden transition-all duration-300 relative ${
            frameMode === "mockup"
              ? "rounded-[48px] border-[10px] border-[#22242B] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.6),0_0_0_1px_rgba(255,255,255,0.08)] bg-[#15161A]"
              : "rounded-3xl border border-stone-200 dark:border-slate-800 shadow-2xl bg-[#FAF6EE] dark:bg-[#15161A]"
          }`}
        >
          {/* Dynamic Island / Speaker notch in Mockup mode */}
          {frameMode === "mockup" && (
            <div className="w-full pt-3 pb-1 flex items-center justify-center bg-transparent z-40 relative">
              <div className="w-24 h-4.5 bg-black rounded-full flex items-center justify-end px-2.5 space-x-1.5 shadow-inner">
                <div className="w-2 h-2 rounded-full bg-[#1A1A24] border border-stone-800" />
                <div className="w-1.5 h-1.5 rounded-full bg-[#0F2236]" />
              </div>
            </div>
          )}

          {/* MAIN INTERNAL SCREEN CONTENT */}
          <div className="w-full flex flex-col relative overflow-hidden">
            
            {/* ========================================================
                SECTION A: 12:00 GÜNDÜZ (DAY VIEW)
                ======================================================== */}
            {(circadianMode === "split" || circadianMode === "day") && (
              <div className="w-full bg-[#FAF6EE] text-[#1C1917] p-4 sm:p-5 space-y-4 border-b border-stone-300/60 relative">
                
                {/* 1. Header Bar: Menu, NOTLARIM, Search */}
                <div className="flex items-center justify-between pt-1 pb-1">
                  <button
                    onClick={() => setIsDrawerOpen(!isDrawerOpen)}
                    className="p-1.5 text-stone-700 hover:text-stone-950 hover:bg-stone-200/60 rounded-xl transition-all cursor-pointer"
                    title="Menü"
                  >
                    <Menu className="w-5 h-5 stroke-[2.5]" />
                  </button>

                  <h1 className="text-sm sm:text-base font-black tracking-[0.2em] uppercase text-stone-900 select-none">
                    NOTLARIM
                  </h1>

                  <button
                    onClick={() => setIsSearchOpen(!isSearchOpen)}
                    className="p-1.5 text-stone-700 hover:text-stone-950 hover:bg-stone-200/60 rounded-xl transition-all cursor-pointer"
                    title="Ara"
                  >
                    <Search className="w-5 h-5 stroke-[2.5]" />
                  </button>
                </div>

                {/* Expandable Search Input */}
                {isSearchOpen && (
                  <div className="relative animate-in fade-in slide-in-from-top-2 duration-150">
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Notlarda hızlı arama yapın..."
                      className="w-full bg-white/90 border border-stone-300 focus:border-[#E0533C] text-xs text-stone-900 pl-3 pr-8 py-2 rounded-xl outline-none shadow-xs"
                      autoFocus
                    />
                    {searchQuery && (
                      <button
                        onClick={() => setSearchQuery("")}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 text-xs"
                      >
                        ✕
                      </button>
                    )}
                  </div>
                )}

                {/* 2. Full-width Pill Button: "Yeni Not Ekle" (Espresso/Dark Coffee) */}
                <button
                  onClick={() => onOpenNewNote && onOpenNewNote()}
                  className="w-full py-2.5 px-4 rounded-full bg-[#2A1810] hover:bg-[#3C2217] active:scale-[0.98] text-white text-xs font-bold tracking-wider uppercase transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Yeni Not Ekle</span>
                </button>

                {/* 3. Card 1: Aistudio Proje Raporu (Glowing Coral-Red Outline) */}
                <div
                  onClick={() => {
                    const matchedNote = notes.find((n) => n.title.includes("Aistudio") || n.title.includes("Proje"));
                    if (matchedNote && onOpenNote) {
                      onOpenNote(matchedNote);
                    } else if (onOpenNewNote) {
                      onOpenNewNote();
                    }
                  }}
                  className="w-full p-4 rounded-2xl bg-white border-2 border-[#E0533C] shadow-[0_0_18px_rgba(224,83,60,0.32)] space-y-3 cursor-pointer hover:shadow-[0_0_24px_rgba(224,83,60,0.45)] transition-all"
                >
                  {/* Card Title & Badge */}
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-xs sm:text-sm font-black text-stone-900 tracking-wide">
                      Aistudio Proje Raporu
                    </h3>
                    <span className="px-2 py-0.5 rounded-full bg-[#FEF08A] text-[#854D0E] text-[10px] font-extrabold tracking-wide uppercase shadow-xs">
                      Devam Ediyor
                    </span>
                  </div>

                  {/* Bullet Points */}
                  <div className="text-xs text-stone-700 space-y-1">
                    <div className="font-bold flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#E0533C]" />
                      <span>Proje Raporu:</span>
                    </div>
                    <div className="pl-4 space-y-0.5 text-stone-600 text-[11px]">
                      <div>- Dokümantasyon</div>
                      <div>- Proje Yönetimi</div>
                    </div>
                  </div>

                  {/* Image/Document Attachment Previews */}
                  <div className="grid grid-cols-3 gap-2 pt-1">
                    <div className="h-12 rounded-lg bg-stone-100 border border-stone-200 overflow-hidden flex flex-col items-center justify-center p-1 text-center group hover:border-[#E0533C] transition-colors">
                      <FileText className="w-3.5 h-3.5 text-[#E0533C] mb-0.5" />
                      <span className="text-[8px] font-bold text-stone-600 truncate w-full">Doküman</span>
                    </div>
                    <div className="h-12 rounded-lg bg-stone-100 border border-stone-200 overflow-hidden flex flex-col items-center justify-center p-1 text-center group hover:border-[#E0533C] transition-colors">
                      <Layers className="w-3.5 h-3.5 text-amber-600 mb-0.5" />
                      <span className="text-[8px] font-bold text-stone-600 truncate w-full">Mimari</span>
                    </div>
                    <div className="h-12 rounded-lg bg-[#2A1810] text-white overflow-hidden flex flex-col items-center justify-center p-1 text-center group shadow-xs">
                      <Terminal className="w-3.5 h-3.5 text-cyan-300 mb-0.5" />
                      <span className="text-[8px] font-bold text-stone-200 truncate w-full">Panel</span>
                    </div>
                  </div>

                  {/* Footer Tag */}
                  <div className="text-[10px] font-mono text-stone-500 pt-1 flex items-center justify-between border-t border-stone-100">
                    <span className="truncate">Aistudio Proje Raporu kanalları...</span>
                    <span className="font-bold text-[#C01D2E] shrink-0">#C01D2E</span>
                  </div>
                </div>

                {/* 4. Card 2: Log Dosyası [Gündüz] */}
                <div className="w-full p-3.5 rounded-2xl bg-white border border-stone-200 space-y-2.5 shadow-xs">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-stone-900 tracking-wide flex items-center gap-1.5">
                      <span>Log Dosyası [Gündüz]</span>
                    </h3>
                    <button
                      className="text-stone-400 hover:text-stone-700 p-1 rounded-md transition-colors"
                      title="Filtrele"
                    >
                      <SlidersHorizontal className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="p-2.5 rounded-xl bg-stone-50 border border-stone-200 font-mono text-[10px] leading-relaxed space-y-1 text-stone-700">
                    <div className="flex items-start gap-1.5">
                      <span className="font-bold text-[#EF4444] shrink-0">[ERR]</span>
                      <span className="truncate">Logim motors opens data</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <span className="font-bold text-[#0284C7] shrink-0">[INFO]</span>
                      <span className="truncate">data: 10.12.7.20.63 - 8728</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <span className="font-bold text-[#0284C7] shrink-0">[INFO]</span>
                      <span className="truncate">data line???:900.12:21</span>
                      <span className="font-bold text-[#4EA9E5] ml-auto shrink-0">#4EA9E5</span>
                    </div>
                  </div>
                </div>

              </div>
            )}

            {/* ========================================================
                SECTION B: 22:00 GECE (NIGHT VIEW)
                ======================================================== */}
            {(circadianMode === "split" || circadianMode === "night") && (
              <div className="w-full bg-[#15161A] text-slate-100 p-4 sm:p-5 space-y-4 relative">
                
                {/* 1. Header Bar: Menu, NOTLARIM, Search */}
                <div className="flex items-center justify-between pt-1 pb-1">
                  <button
                    onClick={() => setIsDrawerOpen(!isDrawerOpen)}
                    className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-all cursor-pointer"
                    title="Menü"
                  >
                    <Menu className="w-5 h-5 stroke-[2.5]" />
                  </button>

                  <h1 className="text-sm sm:text-base font-black tracking-[0.2em] uppercase text-white select-none">
                    NOTLARIM
                  </h1>

                  <button
                    onClick={() => setIsSearchOpen(!isSearchOpen)}
                    className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-all cursor-pointer"
                    title="Ara"
                  >
                    <Search className="w-5 h-5 stroke-[2.5]" />
                  </button>
                </div>

                {/* 2. Full-width Pill Button: "Yeni Not Ekle" (Carbon Pill) */}
                <button
                  onClick={() => onOpenNewNote && onOpenNewNote()}
                  className="w-full py-2.5 px-4 rounded-full bg-[#25272F] hover:bg-[#32353F] active:scale-[0.98] text-white text-xs font-bold tracking-wider uppercase transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer border border-slate-700/50"
                >
                  <span>Yeni Not Ekle</span>
                </button>

                {/* 3. Card 1: Sibergüvenlik Testi (Glowing Vivid Magenta Outline) */}
                <div
                  onClick={() => {
                    const matchedNote = notes.find((n) => n.title.includes("Siber") || n.title.includes("Güvenlik"));
                    if (matchedNote && onOpenNote) {
                      onOpenNote(matchedNote);
                    } else if (onOpenNewNote) {
                      onOpenNewNote();
                    }
                  }}
                  className="w-full p-4 rounded-2xl bg-[#1C1D24] border-2 border-[#E11D48] shadow-[0_0_20px_rgba(225,29,72,0.45)] space-y-3 cursor-pointer hover:shadow-[0_0_28px_rgba(225,29,72,0.6)] transition-all"
                >
                  {/* Card Title */}
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-xs sm:text-sm font-black text-white tracking-wide">
                      Sibergüvenlik Testi
                    </h3>
                  </div>

                  {/* Bullet Points */}
                  <div className="text-xs text-slate-300 space-y-1">
                    <div className="font-bold flex items-center gap-1.5 text-slate-200">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#E11D48]" />
                      <span>Proje Raporu:</span>
                    </div>
                    <div className="pl-4 space-y-0.5 text-slate-400 text-[11px]">
                      <div>- Dokümantasyon</div>
                      <div>- Proje Yönetimi</div>
                    </div>
                  </div>

                  {/* Footer Tag */}
                  <div className="text-[10px] font-mono text-slate-500 pt-1 flex items-center justify-between border-t border-slate-800">
                    <span className="truncate">Sibergüvenlik Testi formatı...</span>
                    <span className="text-[#E11D48] font-bold">#PROT</span>
                  </div>
                </div>

                {/* 4. Card 2: Yapılacaklar Listesi */}
                <div className="w-full p-3.5 rounded-2xl bg-[#1C1D24] border border-slate-800 space-y-2.5 shadow-xs">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold text-white tracking-wide">
                      Yapılacaklar Listesi
                    </h3>
                    <span className="text-[10px] font-mono text-slate-500">22:00</span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-[#121316] border border-slate-800/80 font-mono text-[10px] leading-relaxed space-y-1.5 text-slate-300">
                    {nightTasks.map((t) => (
                      <div
                        key={t.id}
                        onClick={() =>
                          setNightTasks((prev) =>
                            prev.map((item) => (item.id === t.id ? { ...item, done: !item.done } : item))
                          )
                        }
                        className="flex items-center gap-1.5 cursor-pointer hover:bg-slate-800/40 p-0.5 rounded transition-colors"
                      >
                        <span
                          className={`font-bold shrink-0 text-[9px] px-1 rounded ${
                            t.type === "ERR" ? "bg-red-950/60 text-[#EF4444]" : "bg-cyan-950/60 text-[#00F5FF]"
                          }`}
                        >
                          [{t.type}]
                        </span>
                        <span className={`truncate ${t.done ? "line-through text-slate-500" : ""}`}>
                          {t.text}
                        </span>
                        {t.done && <Check className="w-3 h-3 text-emerald-400 ml-auto shrink-0" />}
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            )}

            {/* ========================================================
                CIRCULAR FROSTED GLASS RADIAL ACTION DISK & PINK FAB
                ======================================================== */}
            <div className="absolute bottom-6 right-6 z-40 flex flex-col items-center">
              
              {/* Frosted Glass Radial Action Disk (Circle Hub) */}
              {isRadialDiskOpen && (
                <div className="relative mb-3 animate-in zoom-in-95 duration-200 select-none">
                  <div className="w-36 h-36 rounded-full bg-white/75 dark:bg-slate-800/85 backdrop-blur-md border border-white/60 dark:border-slate-600/50 shadow-[0_15px_35px_rgba(0,0,0,0.3)] flex flex-col items-center justify-between p-2.5 relative overflow-hidden">
                    
                    {/* Top Action: Metin (Feather Pen) */}
                    <button
                      onClick={() => handleCreateDraft("text")}
                      className="flex flex-col items-center text-stone-800 dark:text-slate-100 hover:text-[#E0533C] dark:hover:text-[#E11D48] transition-colors cursor-pointer group"
                      title="Metin Notu"
                    >
                      <Feather className="w-4 h-4 stroke-[2.2] group-hover:scale-110 transition-transform" />
                      <span className="text-[9px] font-bold mt-0.5">Metin</span>
                    </button>

                    {/* Middle Row: Sesli (Mic) & Liste (Checklist) */}
                    <div className="w-full flex items-center justify-between px-1">
                      {/* Left: Sesli */}
                      <button
                        onClick={() => handleCreateDraft("voice")}
                        className="flex flex-col items-center text-stone-800 dark:text-slate-100 hover:text-[#E0533C] dark:hover:text-[#E11D48] transition-colors cursor-pointer group"
                        title="Sesli Not"
                      >
                        <Mic className="w-4 h-4 stroke-[2.2] group-hover:scale-110 transition-transform" />
                        <span className="text-[9px] font-bold mt-0.5">Sesli</span>
                      </button>

                      {/* Center Hub: Checkmark Dark Circle Badge */}
                      <button
                        onClick={() => setIsRadialDiskOpen(false)}
                        className="w-7 h-7 rounded-full bg-[#2A1810] dark:bg-black text-white flex items-center justify-center shadow-md hover:scale-105 active:scale-95 transition-all cursor-pointer"
                        title="Kapat"
                      >
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </button>

                      {/* Right: Liste */}
                      <button
                        onClick={() => handleCreateDraft("checklist")}
                        className="flex flex-col items-center text-stone-800 dark:text-slate-100 hover:text-[#E0533C] dark:hover:text-[#E11D48] transition-colors cursor-pointer group"
                        title="Yapılacaklar Listesi"
                      >
                        <CheckSquare className="w-4 h-4 stroke-[2.2] group-hover:scale-110 transition-transform" />
                        <span className="text-[9px] font-bold mt-0.5">Liste</span>
                      </button>
                    </div>

                    {/* Bottom Indicator / Label */}
                    <div className="text-[8px] font-extrabold uppercase tracking-wider text-stone-400 dark:text-slate-500 pb-0.5">
                      Hızlı Eylem
                    </div>
                  </div>
                </div>
              )}

              {/* Main Hot Pink / Crimson Glowing Circular FAB (+) */}
              <button
                onClick={() => setIsRadialDiskOpen(!isRadialDiskOpen)}
                className={`w-13 h-13 rounded-full flex items-center justify-center text-white font-black shadow-[0_0_22px_rgba(225,29,72,0.6)] border-2 border-white/40 cursor-pointer active:scale-95 transition-all ${
                  isRadialDiskOpen
                    ? "bg-[#E11D48] rotate-45"
                    : "bg-gradient-to-tr from-[#E0533C] to-[#E11D48] hover:scale-105"
                }`}
                title="Hızlı İşlemler Menüsü"
              >
                <Plus className="w-7 h-7 stroke-[3]" />
              </button>

            </div>

          </div>
        </div>
      </div>

      {/* 3. QUICK DRAWER MODAL (When Hamburger Menu is clicked) */}
      {isDrawerOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-start justify-center p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 rounded-3xl p-5 space-y-4 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-stone-200 dark:border-slate-800 pb-3">
              <h3 className="text-sm font-black text-stone-900 dark:text-white flex items-center gap-2">
                <span>NOTLARIM</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-[#E11D48]/10 text-[#E11D48]">
                  Sirkadiyen PKM
                </span>
              </h3>
              <button
                onClick={() => setIsDrawerOpen(false)}
                className="text-stone-400 hover:text-stone-900 dark:hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              <button
                onClick={() => {
                  setCircadianMode("split");
                  setIsDrawerOpen(false);
                }}
                className="w-full p-3 rounded-xl bg-stone-50 dark:bg-slate-800 hover:bg-stone-100 dark:hover:bg-slate-700 text-left text-xs font-bold flex items-center justify-between transition-colors"
              >
                <span>İkili Bölünmüş Sirkadiyen Görünüm</span>
                <Sparkles className="w-4 h-4 text-[#E0533C]" />
              </button>

              <button
                onClick={() => {
                  setCircadianMode("day");
                  setIsDrawerOpen(false);
                }}
                className="w-full p-3 rounded-xl bg-stone-50 dark:bg-slate-800 hover:bg-stone-100 dark:hover:bg-slate-700 text-left text-xs font-bold flex items-center justify-between transition-colors"
              >
                <span>12:00 Gündüz Modu (Sıcak Parşömen)</span>
                <Sun className="w-4 h-4 text-[#E0533C]" />
              </button>

              <button
                onClick={() => {
                  setCircadianMode("night");
                  setIsDrawerOpen(false);
                }}
                className="w-full p-3 rounded-xl bg-stone-50 dark:bg-slate-800 hover:bg-stone-100 dark:hover:bg-slate-700 text-left text-xs font-bold flex items-center justify-between transition-colors"
              >
                <span>22:00 Gece Modu (Obsidiyen Füme)</span>
                <Moon className="w-4 h-4 text-[#E11D48]" />
              </button>
            </div>

            <div className="pt-2 border-t border-stone-200 dark:border-slate-800 flex justify-end">
              <button
                onClick={() => setIsDrawerOpen(false)}
                className="px-4 py-2 rounded-xl bg-[#2A1810] text-white text-xs font-bold"
              >
                Kapat
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
