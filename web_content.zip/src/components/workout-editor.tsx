import { ArrowDown, ArrowUp, Copy, Plus, RotateCcw, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { REST_PRESETS } from "@/lib/defaults";
import type { Exercise } from "@/lib/types";

type EditorHandlers = {
  onUpdate: (id: string, patch: Partial<Exercise>) => void;
  onAdd: () => void;
  onRemove: (id: string) => void;
  onDuplicate: (id: string) => void;
  onMove: (id: string, dir: -1 | 1) => void;
  onRestore: () => void;
};

export function WorkoutEditor({
  exercises,
  handlers,
}: {
  exercises: Exercise[];
  handlers: EditorHandlers;
}) {
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        <Button size="sm" onClick={handlers.onAdd}>
          <Plus /> Adicionar exercício
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={() => {
            handlers.onRestore();
            toast.success("Treino original restaurado");
          }}
        >
          <RotateCcw /> Restaurar original
        </Button>
      </div>
      {exercises.length === 0 ? (
        <Card className="p-6 text-sm text-muted-foreground">
          Nenhum exercício. Adicione o primeiro.
        </Card>
      ) : null}
      {exercises.map((ex, i) => (
        <Card key={ex.id} className="space-y-3 p-4">
          <div className="flex items-start gap-2">
            <Input
              value={ex.name}
              onChange={(e) => handlers.onUpdate(ex.id, { name: e.target.value })}
              className="font-medium"
            />
            <Button
              size="icon"
              variant="ghost"
              disabled={i === 0}
              onClick={() => handlers.onMove(ex.id, -1)}
              aria-label="Subir"
            >
              <ArrowUp />
            </Button>
            <Button
              size="icon"
              variant="ghost"
              disabled={i === exercises.length - 1}
              onClick={() => handlers.onMove(ex.id, 1)}
              aria-label="Descer"
            >
              <ArrowDown />
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <label className="space-y-1">
              <span className="text-[11px] text-muted-foreground">Séries</span>
              <Input
                type="number"
                min={1}
                value={ex.sets}
                onChange={(e) =>
                  handlers.onUpdate(ex.id, {
                    sets: Math.max(1, Number(e.target.value) || 1),
                  })
                }
              />
            </label>
            <label className="space-y-1">
              <span className="text-[11px] text-muted-foreground">
                Reps / tempo
              </span>
              <Input
                value={ex.reps}
                onChange={(e) => handlers.onUpdate(ex.id, { reps: e.target.value })}
              />
            </label>
            <label className="space-y-1">
              <span className="text-[11px] text-muted-foreground">Carga</span>
              <Input
                value={ex.load}
                onChange={(e) => handlers.onUpdate(ex.id, { load: e.target.value })}
              />
            </label>
            <label className="space-y-1">
              <span className="text-[11px] text-muted-foreground">Descanso (s)</span>
              <Input
                type="number"
                min={0}
                step={5}
                value={ex.restSec}
                onChange={(e) =>
                  handlers.onUpdate(ex.id, {
                    restSec: Math.max(0, Number(e.target.value) || 0),
                  })
                }
              />
            </label>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {REST_PRESETS.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => handlers.onUpdate(ex.id, { restSec: s })}
                className={`h-8 rounded-full px-2.5 text-[11px] font-medium ${
                  ex.restSec === s
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground"
                }`}
              >
                {s}s
              </button>
            ))}
          </div>
          <label className="block space-y-1">
            <span className="text-[11px] text-muted-foreground">Instrução</span>
            <Input
              value={ex.notes}
              onChange={(e) => handlers.onUpdate(ex.id, { notes: e.target.value })}
              placeholder="Opcional"
            />
          </label>
          <div className="flex justify-end gap-1">
            <Button
              size="sm"
              variant="ghost"
              onClick={() => {
                handlers.onDuplicate(ex.id);
                toast.success("Exercício duplicado");
              }}
            >
              <Copy /> Duplicar
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => handlers.onRemove(ex.id)}
            >
              <Trash2 /> Remover
            </Button>
          </div>
        </Card>
      ))}
    </div>
  );
}
