import React from 'react';
import { useData } from '../context/DataContext.tsx';
import { Target, Compass, Layers } from 'lucide-react';

export const AboutSection: React.FC = () => {
  const { data } = useData();

  if (data?.settings?.sectionVisibility?.about === false) {
    return null;
  }

  return (
    <section id="about" className="py-8 sm:py-12 max-w-[1120px] mx-auto px-4 sm:px-6">
      {/* Section Header */}
      <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-14">
        <span className="text-xs font-mono font-bold tracking-widest text-cyan-400 uppercase bg-cyan-950/60 px-3.5 py-1 rounded-full border border-cyan-500/30">
          {data?.settings?.aboutHeading || 'ABOUT CUBIX STUDIO'}
        </span>
        <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight mt-4 mb-4 font-['Plus_Jakarta_Sans']">
          {data?.settings?.aboutStatement || 'Building Digital Experiences With Purpose.'}
        </h2>
        <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
          {data?.settings?.aboutDescription ||
            'Cubix Studio brings development, design, and creative problem-solving together to build meaningful digital experiences. From websites and custom software to Discord systems and Minecraft development, we turn ideas into practical, well-crafted solutions.'}
        </p>
      </div>

      {/* Three Clean Cards: Mission, Approach, What We Build */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Card 1: Mission */}
        <div className="p-7 rounded-2xl bg-gradient-to-b from-[#081528] to-[#040c17] border border-cyan-500/15 hover:border-cyan-400/40 transition-all duration-200">
          <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-5">
            <Target className="w-6 h-6" />
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-white mb-2.5">Mission</h3>
          <p className="text-slate-300 text-sm leading-relaxed">
            {data?.settings?.aboutCards?.mission ||
              'To turn ideas into reliable, useful, and thoughtfully designed digital experiences.'}
          </p>
        </div>

        {/* Card 2: Approach */}
        <div className="p-7 rounded-2xl bg-gradient-to-b from-[#081528] to-[#040c17] border border-cyan-500/15 hover:border-cyan-400/40 transition-all duration-200">
          <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-5">
            <Compass className="w-6 h-6" />
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-white mb-2.5">Approach</h3>
          <p className="text-slate-300 text-sm leading-relaxed">
            {data?.settings?.aboutCards?.approach ||
              'Combining technical precision, creative thinking, and clear communication to deliver work that fits each project\'s needs.'}
          </p>
        </div>

        {/* Card 3: What We Build */}
        <div className="p-7 rounded-2xl bg-gradient-to-b from-[#081528] to-[#040c17] border border-cyan-500/15 hover:border-cyan-400/40 transition-all duration-200">
          <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-5">
            <Layers className="w-6 h-6" />
          </div>
          <h3 className="text-lg sm:text-xl font-bold text-white mb-2.5">What We Build</h3>
          <p className="text-slate-300 text-sm leading-relaxed">
            {data?.settings?.aboutCards?.whatWeBuild ||
              'Websites, graphic design, Discord solutions, Minecraft development, and custom digital projects.'}
          </p>
        </div>
      </div>
    </section>
  );
};
