import React, { useState } from 'react';
import { User, Heart, Baby, X } from 'lucide-react';
import { Child } from '../game/types';
import { playClickSound } from '../utils/audio';

interface RenameModalProps {
  playerName: string;
  partnerName: string;
  childrenList: Child[];
  onSave: (target: 'player' | 'partner' | string, newName: string) => void;
  onClose: () => void;
}

export const RenameModal: React.FC<RenameModalProps> = ({
  playerName,
  partnerName,
  childrenList,
  onSave,
  onClose
}) => {
  const [selectedTarget, setSelectedTarget] = useState<'player' | 'partner' | string>('player');
  const [newName, setNewName] = useState(playerName);

  const handleTargetChange = (target: 'player' | 'partner' | string) => {
    playClickSound();
    setSelectedTarget(target);
    if (target === 'player') setNewName(playerName);
    else if (target === 'partner') setNewName(partnerName);
    else {
      const child = childrenList.find(c => c.id === target);
      if (child) setNewName(child.name);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    playClickSound();
    onSave(selectedTarget, newName.trim());
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="w-full max-w-md bg-slate-900 border border-slate-700/80 rounded-3xl p-6 shadow-2xl text-right animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
              <User className="w-5 h-5" />
            </span>
            <h2 className="text-lg font-bold text-slate-100">تعديل وتغيير الأسماء</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-4">
          <label className="block text-xs font-semibold text-slate-300 mb-2">
            اختر الشخص الذي تريد تغيير اسمه:
          </label>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => handleTargetChange('player')}
              className={`px-3 py-2 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition ${
                selectedTarget === 'player'
                  ? 'bg-amber-400 text-slate-950 border-amber-400'
                  : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>اسمك ({playerName})</span>
            </button>

            <button
              type="button"
              onClick={() => handleTargetChange('partner')}
              className={`px-3 py-2 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition ${
                selectedTarget === 'partner'
                  ? 'bg-rose-500 text-white border-rose-500'
                  : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
              }`}
            >
              <Heart className="w-3.5 h-3.5" />
              <span>شريكتك ({partnerName})</span>
            </button>

            {childrenList.map(child => (
              <button
                key={child.id}
                type="button"
                onClick={() => handleTargetChange(child.id)}
                className={`px-3 py-2 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition ${
                  selectedTarget === child.id
                    ? 'bg-cyan-500 text-white border-cyan-500'
                    : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                }`}
              >
                <Baby className="w-3.5 h-3.5" />
                <span>{child.gender === 'boy' ? 'الولد' : 'البنت'} ({child.name})</span>
              </button>
            ))}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              الاسم الجديد:
            </label>
            <input
              type="text"
              required
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="اكتب الاسم الجديد هنا..."
              className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400"
            />
          </div>

          <div className="flex gap-2">
            <button
              type="submit"
              className="flex-1 py-2.5 px-4 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs hover:bg-amber-300 transition"
            >
              حفظ وتغيير الاسم
            </button>
            <button
              type="button"
              onClick={onClose}
              className="py-2.5 px-4 rounded-xl bg-slate-800 text-slate-300 text-xs hover:bg-slate-700 transition"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
