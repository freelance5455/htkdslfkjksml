import React, { useState } from 'react';
import { ArrowLeftRight, ArrowUpRight, Scale, Ruler, Thermometer, Gauge, HardDrive } from 'lucide-react';
import { audioService } from '../services/audioService';
import { historyStorage } from '../services/historyStorage';

interface UnitConverterViewProps {
  onShowToast: (text: string, type?: 'success' | 'info' | 'error') => void;
  onSendToCalculator: (val: string) => void;
}

type UnitCategory = 'length' | 'weight' | 'temp' | 'speed' | 'data';

export const UnitConverterView: React.FC<UnitConverterViewProps> = ({
  onShowToast,
  onSendToCalculator,
}) => {
  const [category, setCategory] = useState<UnitCategory>('length');
  const [fromValue, setFromValue] = useState<number>(100);
  const [fromUnit, setFromUnit] = useState<string>('km');
  const [toUnit, setToUnit] = useState<string>('miles');

  // Conversion rates (normalized to base unit)
  const lengthRates: Record<string, number> = {
    m: 1,
    km: 1000,
    cm: 0.01,
    mm: 0.001,
    miles: 1609.344,
    ft: 0.3048,
    in: 0.0254,
  };

  const weightRates: Record<string, number> = {
    kg: 1,
    g: 0.001,
    mg: 0.000001,
    lb: 0.45359237,
    oz: 0.02834952,
    ton: 1000,
  };

  const speedRates: Record<string, number> = {
    'm/s': 1,
    'km/h': 0.277777778,
    mph: 0.44704,
    knot: 0.514444,
  };

  const dataRates: Record<string, number> = {
    KB: 1,
    MB: 1024,
    GB: 1048576,
    TB: 1073741824,
  };

  let convertedValue = 0;

  if (category === 'temp') {
    // Temperature special formulas
    let celsius = fromValue;
    if (fromUnit === 'F') celsius = ((fromValue - 32) * 5) / 9;
    else if (fromUnit === 'K') celsius = fromValue - 273.15;

    if (toUnit === 'C') convertedValue = celsius;
    else if (toUnit === 'F') convertedValue = (celsius * 9) / 5 + 32;
    else if (toUnit === 'K') convertedValue = celsius + 273.15;
  } else if (category === 'length') {
    const base = fromValue * (lengthRates[fromUnit] || 1);
    convertedValue = base / (lengthRates[toUnit] || 1);
  } else if (category === 'weight') {
    const base = fromValue * (weightRates[fromUnit] || 1);
    convertedValue = base / (weightRates[toUnit] || 1);
  } else if (category === 'speed') {
    const base = fromValue * (speedRates[fromUnit] || 1);
    convertedValue = base / (speedRates[toUnit] || 1);
  } else if (category === 'data') {
    const base = fromValue * (dataRates[fromUnit] || 1);
    convertedValue = base / (dataRates[toUnit] || 1);
  }

  const getUnitsForCategory = (cat: UnitCategory): string[] => {
    switch (cat) {
      case 'length':
        return ['m', 'km', 'cm', 'mm', 'miles', 'ft', 'in'];
      case 'weight':
        return ['kg', 'g', 'lb', 'oz', 'ton'];
      case 'temp':
        return ['C', 'F', 'K'];
      case 'speed':
        return ['km/h', 'mph', 'm/s', 'knot'];
      case 'data':
        return ['MB', 'GB', 'TB', 'KB'];
    }
  };

  const handleCategoryChange = (cat: UnitCategory) => {
    audioService.playKeyClick();
    setCategory(cat);
    const units = getUnitsForCategory(cat);
    setFromUnit(units[0]);
    setToUnit(units[1] || units[0]);
  };

  const handleSwap = () => {
    audioService.playKeyClick();
    const temp = fromUnit;
    setFromUnit(toUnit);
    setToUnit(temp);
  };

  const handleSendVal = () => {
    audioService.playKeyClick();
    const formatted = convertedValue.toFixed(4).replace(/\.?0+$/, '');
    onSendToCalculator(formatted);
    historyStorage.add({
      type: 'unit',
      title: `${category.toUpperCase()} Conversion`,
      expression: `${fromValue} ${fromUnit} → ${toUnit}`,
      result: `${formatted} ${toUnit}`,
      numericResult: Number(formatted),
    });
    onShowToast(`Sent ${formatted} to Calculator!`, 'success');
  };

  return (
    <div className="flex flex-col h-full w-full max-w-md mx-auto p-3.5 space-y-3.5 overflow-y-auto">
      {/* Category Tabs */}
      <div className="grid grid-cols-5 gap-1 p-1 bg-[#0a0c12] rounded-xl border border-zinc-800 text-[10px] font-mono">
        {[
          { id: 'length', label: 'Length', icon: <Ruler className="w-3 h-3 mx-auto mb-0.5" /> },
          { id: 'weight', label: 'Weight', icon: <Scale className="w-3 h-3 mx-auto mb-0.5" /> },
          { id: 'temp', label: 'Temp', icon: <Thermometer className="w-3 h-3 mx-auto mb-0.5" /> },
          { id: 'speed', label: 'Speed', icon: <Gauge className="w-3 h-3 mx-auto mb-0.5" /> },
          { id: 'data', label: 'Data', icon: <HardDrive className="w-3 h-3 mx-auto mb-0.5" /> },
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => handleCategoryChange(item.id as UnitCategory)}
            className={`py-1.5 rounded-lg transition font-medium text-center ${
              category === item.id
                ? 'bg-amber-500/20 text-amber-300 border border-amber-400/40 font-bold'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            {item.icon}
            <span>{item.label}</span>
          </button>
        ))}
      </div>

      {/* Input & Unit Pickers */}
      <div className="rounded-2xl bg-[#0f111a] border border-amber-500/20 p-4 space-y-3">
        <div>
          <span className="text-zinc-400 text-xs font-mono block mb-1">Enter Value:</span>
          <input
            type="number"
            value={fromValue}
            onChange={(e) => setFromValue(parseFloat(e.target.value) || 0)}
            className="w-full px-3.5 py-2.5 rounded-xl bg-[#0a0c12] border border-zinc-800 text-base font-mono text-amber-200 focus:outline-none focus:border-amber-400"
          />
        </div>

        {/* Units Selection with Swap */}
        <div className="flex items-center gap-2">
          <div className="flex-1">
            <span className="text-[10px] text-zinc-400 font-mono block mb-1">From:</span>
            <select
              value={fromUnit}
              onChange={(e) => setFromUnit(e.target.value)}
              className="w-full px-2.5 py-2 rounded-xl bg-[#0a0c12] border border-zinc-800 text-xs font-mono text-zinc-100 focus:outline-none focus:border-amber-400"
            >
              {getUnitsForCategory(category).map((u) => (
                <option key={u} value={u}>
                  {u}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={handleSwap}
            className="mt-4 p-2 rounded-xl bg-zinc-900 border border-zinc-700/60 text-amber-400 hover:bg-zinc-800 transition active:scale-95"
            title="Swap Units"
          >
            <ArrowLeftRight className="w-4 h-4" />
          </button>

          <div className="flex-1">
            <span className="text-[10px] text-zinc-400 font-mono block mb-1">To:</span>
            <select
              value={toUnit}
              onChange={(e) => setToUnit(e.target.value)}
              className="w-full px-2.5 py-2 rounded-xl bg-[#0a0c12] border border-zinc-800 text-xs font-mono text-zinc-100 focus:outline-none focus:border-amber-400"
            >
              {getUnitsForCategory(category).map((u) => (
                <option key={u} value={u}>
                  {u}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Result Card */}
      <div className="rounded-2xl bg-gradient-to-br from-[#161a29] to-[#0c0e17] border border-amber-500/30 p-4 space-y-3 shadow-xl">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono text-zinc-400 uppercase">
              Converted Output
            </span>
            <div className="text-2xl sm:text-3xl font-mono font-bold gold-gradient-text">
              {convertedValue.toLocaleString('en-US', { maximumFractionDigits: 6 })} {toUnit}
            </div>
            <div className="text-xs text-zinc-500 font-mono">
              {fromValue} {fromUnit} = {convertedValue.toFixed(4)} {toUnit}
            </div>
          </div>
          <button
            onClick={handleSendVal}
            className="px-2.5 py-1.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/30 border border-amber-400/40 text-xs font-mono text-amber-300 flex items-center gap-1 transition"
          >
            <span>To Calc</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
