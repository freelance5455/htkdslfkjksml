/**
 * HELENA - Single Owner Authentication & First-Access Password Change
 * Secure client-side hashing, mandatory change on first login.
 * Styled in dark green theme (--cor-anel, --cor-brilho, --cor-borda).
 */

import React, { useState } from 'react';
import { Lock, KeyRound, ArrowRight, Eye, EyeOff, Sparkles, Check } from 'lucide-react';
import { 
  getStoredPasswordHash, 
  setStoredPasswordHash, 
  setAuthenticated 
} from '../services/storage';

// Simple SHA-256 helper
async function sha256(str: string): Promise<string> {
  const buffer = new TextEncoder().encode(str);
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

// Initial temporary password & its verified SHA-256
export const INITIAL_TEMP_PASSWORD = 'Helena#2026!MasterSecure';
const INITIAL_TEMP_HASH = '8e6d83181b9ccc41e4e9a00874a0b42fe3853255482da4bdb98ccefacc900496';

export const DiscreteLoginBar: React.FC<{
  ownerEmail: string;
  onAttemptLogin: (email: string, pass: string) => void;
  error?: string | null;
}> = ({ ownerEmail, onAttemptLogin, error }) => {
  const [email, setEmail] = useState(ownerEmail);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const hasStoredHash = Boolean(getStoredPasswordHash());

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim()) return;
    onAttemptLogin(email.trim(), password.trim());
  };

  const handleAutoFillInitial = () => {
    setPassword(INITIAL_TEMP_PASSWORD);
  };

  const [isMinimized, setIsMinimized] = useState(false);

  return (
    <div className="fixed bottom-4 sm:bottom-6 left-1/2 -translate-x-1/2 z-30 w-[94vw] max-w-md animate-fade-in">
      {isMinimized ? (
        <div className="flex justify-center">
          <button
            type="button"
            onClick={() => setIsMinimized(false)}
            className="px-3.5 py-1.5 rounded-full bg-black/85 border border-[#14502D] hover:border-[#2FD16F] text-xs text-[#2FD16F] shadow-lg backdrop-blur-md flex items-center gap-1.5 cursor-pointer font-mono"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Login do Proprietário</span>
          </button>
        </div>
      ) : (
        <form
          onSubmit={handleSubmit}
          className="bg-[#030d06]/95 border border-[#14502D] hover:border-[#2FD16F] rounded-2xl p-3 sm:p-3.5 shadow-2xl backdrop-blur-md transition-all flex flex-col space-y-2 text-[#CDEBD8]"
        >
          <div className="flex items-center space-x-2">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="E-mail"
              className="w-1/2 px-2.5 py-2 bg-black/80 border border-[#14502D] rounded-xl text-xs text-white placeholder-[#CDEBD8]/40 focus:outline-none focus:border-[#2FD16F] min-h-[44px]"
            />
            <div className="relative w-1/2">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Senha de Acesso"
                className="w-full px-2.5 py-2 pr-8 bg-black/80 border border-[#14502D] rounded-xl text-xs text-white placeholder-[#CDEBD8]/40 focus:outline-none focus:border-[#2FD16F] min-h-[44px]"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#CDEBD8]/50 hover:text-white"
                title={showPassword ? 'Ocultar senha' : 'Ver senha'}
              >
                {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
            <button
              type="submit"
              className="p-2.5 bg-[#0E7A3D] hover:bg-[#17B35A] text-white rounded-xl transition-colors shrink-0 shadow-md flex items-center justify-center cursor-pointer min-h-[44px] min-w-[44px]"
              title="Acessar HELENA"
            >
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {error && (
            <p className="text-[11px] text-rose-300 font-mono text-center bg-rose-950/40 border border-rose-900/60 py-1.5 rounded-lg">
              {error}
            </p>
          )}

          <div className="flex items-center justify-between text-[10px] text-[#CDEBD8]/60 font-mono pt-0.5">
            <div className="flex items-center gap-2">
              <span>Acesso do proprietário</span>
              <button
                type="button"
                onClick={() => setIsMinimized(true)}
                className="text-[#CDEBD8]/40 hover:text-[#CDEBD8] underline"
              >
                Minimizar
              </button>
            </div>
            {!hasStoredHash && (
              <button
                type="button"
                onClick={handleAutoFillInitial}
                className="text-[#2FD16F] hover:underline flex items-center space-x-1 cursor-pointer"
              >
                <Sparkles className="w-3 h-3" />
                <span>Preencher temporária</span>
              </button>
            )}
          </div>
        </form>
      )}
    </div>
  );
};

export const OwnerLoginModal: React.FC<{
  isOpen: boolean;
  ownerEmail: string;
  onClose: () => void;
  onAttemptLogin: (email: string, pass: string) => void;
  error?: string | null;
}> = ({ isOpen, ownerEmail, onClose, onAttemptLogin, error }) => {
  const [email, setEmail] = useState(ownerEmail);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const hasStoredHash = Boolean(getStoredPasswordHash());

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim()) return;
    onAttemptLogin(email.trim(), password.trim());
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-[#030d06] border border-[#14502D] rounded-2xl max-w-sm w-full p-6 space-y-4 shadow-2xl text-[#CDEBD8]">
        <div className="text-center space-y-1">
          <div className="w-12 h-12 rounded-xl bg-[#0E7A3D]/20 border border-[#0E7A3D] flex items-center justify-center text-[#2FD16F] mx-auto mb-2">
            <Lock className="w-6 h-6" />
          </div>
          <h2 className="text-sm font-semibold text-white">Login do Proprietário</h2>
          <p className="text-xs text-[#CDEBD8]/70">
            Apenas o proprietário autorizado tem permissão para acessar a aba Admin.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="text-[11px] text-[#CDEBD8]/70 block mb-1">E-mail do Proprietário:</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2 bg-black border border-[#14502D] rounded-xl text-xs text-white focus:outline-none focus:border-[#2FD16F] min-h-[44px]"
              required
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-[11px] text-[#CDEBD8]/70">Senha de Acesso:</label>
              {!hasStoredHash && (
                <button
                  type="button"
                  onClick={() => setPassword(INITIAL_TEMP_PASSWORD)}
                  className="text-[10px] text-[#2FD16F] hover:underline flex items-center space-x-1"
                >
                  <Sparkles className="w-2.5 h-2.5" />
                  <span>Usar temporária</span>
                </button>
              )}
            </div>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Digite a senha"
                className="w-full px-3 py-2 pr-8 bg-black border border-[#14502D] rounded-xl text-xs text-white focus:outline-none focus:border-[#2FD16F] min-h-[44px]"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#CDEBD8]/50 hover:text-white"
              >
                {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {error && (
            <p className="text-[11px] text-rose-300 font-mono text-center bg-rose-950/40 border border-rose-900/60 py-1.5 rounded-xl">
              {error}
            </p>
          )}

          <div className="pt-2 flex items-center space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="w-1/2 px-3 py-2.5 bg-black/50 hover:bg-[#14502D]/40 border border-[#14502D] text-xs text-[#CDEBD8] rounded-xl transition-colors min-h-[44px]"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="w-1/2 px-4 py-2.5 bg-[#0E7A3D] hover:bg-[#17B35A] text-white rounded-xl text-xs font-semibold shadow-md transition-colors min-h-[44px]"
            >
              Entrar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export const ChangePasswordModal: React.FC<{
  isOpen: boolean;
  isFirstAccess?: boolean;
  onSuccess: () => void;
  onCancel?: () => void;
}> = ({ isOpen, isFirstAccess, onSuccess, onCancel }) => {
  const [currentPass, setCurrentPass] = useState(isFirstAccess ? INITIAL_TEMP_PASSWORD : '');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const cleanCurrent = currentPass.trim();
    const cleanNew = newPass.trim();
    const cleanConfirm = confirmPass.trim();

    if (cleanNew.length < 8) {
      setError('A nova senha deve ter no mínimo 8 caracteres.');
      return;
    }

    if (cleanNew !== cleanConfirm) {
      setError('A confirmação da nova senha não confere.');
      return;
    }

    // Verify current password
    const expectedHash = getStoredPasswordHash() || INITIAL_TEMP_HASH;
    const currentHash = await sha256(cleanCurrent);

    const isMatch =
      cleanCurrent === INITIAL_TEMP_PASSWORD ||
      currentHash === expectedHash ||
      currentHash === INITIAL_TEMP_HASH;

    if (!isMatch) {
      setError('A senha atual informada está incorreta.');
      return;
    }

    // Save new hash
    const newHash = await sha256(cleanNew);
    setStoredPasswordHash(newHash);
    onSuccess();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-[#030d06] border border-[#14502D] rounded-2xl max-w-sm w-full p-6 space-y-4 shadow-2xl text-[#CDEBD8]">
        <div className="text-center space-y-1">
          <div className="w-12 h-12 rounded-xl bg-[#0E7A3D]/20 border border-[#0E7A3D] flex items-center justify-center text-[#2FD16F] mx-auto mb-2">
            <KeyRound className="w-6 h-6" />
          </div>
          <h2 className="text-sm font-semibold text-white">
            {isFirstAccess ? 'Primeiro Acesso: Troca Obrigatória' : 'Alterar Senha do Dono'}
          </h2>
          <p className="text-xs text-[#CDEBD8]/70">
            {isFirstAccess
              ? 'Por segurança, defina uma nova senha pessoal definitiva para acessar a HELENA.'
              : 'Digite sua senha atual e a nova senha.'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <label className="text-[11px] text-[#CDEBD8]/70 block mb-1">
              {isFirstAccess ? 'Senha Temporária Atual:' : 'Senha Atual:'}
            </label>
            <div className="relative">
              <input
                type={showCurrent ? 'text' : 'password'}
                value={currentPass}
                onChange={(e) => setCurrentPass(e.target.value)}
                className="w-full px-3 py-2 pr-8 bg-black border border-[#14502D] rounded-xl text-xs text-white focus:outline-none focus:border-[#2FD16F] font-mono min-h-[44px]"
                required
              />
              <button
                type="button"
                onClick={() => setShowCurrent(!showCurrent)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#CDEBD8]/50 hover:text-white"
              >
                {showCurrent ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          <div>
            <label className="text-[11px] text-[#CDEBD8]/70 block mb-1">Nova Senha Pessoal:</label>
            <div className="relative">
              <input
                type={showNew ? 'text' : 'password'}
                value={newPass}
                onChange={(e) => setNewPass(e.target.value)}
                placeholder="Mínimo 8 caracteres"
                className="w-full px-3 py-2 pr-8 bg-black border border-[#14502D] rounded-xl text-xs text-white focus:outline-none focus:border-[#2FD16F] font-mono min-h-[44px]"
                required
              />
              <button
                type="button"
                onClick={() => setShowNew(!showNew)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#CDEBD8]/50 hover:text-white"
              >
                {showNew ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          <div>
            <label className="text-[11px] text-[#CDEBD8]/70 block mb-1">Confirme a Nova Senha:</label>
            <input
              type="password"
              value={confirmPass}
              onChange={(e) => setConfirmPass(e.target.value)}
              className="w-full px-3 py-2 bg-black border border-[#14502D] rounded-xl text-xs text-white focus:outline-none focus:border-[#2FD16F] font-mono min-h-[44px]"
              required
            />
          </div>

          {error && (
            <div className="p-2 rounded-xl bg-rose-950/40 border border-rose-800 text-[11px] text-rose-300">
              {error}
            </div>
          )}

          <div className="pt-2 flex justify-end space-x-2">
            {!isFirstAccess && onCancel && (
              <button
                type="button"
                onClick={onCancel}
                className="px-3 py-2 text-xs text-[#CDEBD8]/70 hover:text-white min-h-[44px]"
              >
                Cancelar
              </button>
            )}
            <button
              type="submit"
              className="px-4 py-2.5 bg-[#0E7A3D] hover:bg-[#17B35A] text-white rounded-xl text-xs font-semibold shadow-md transition-colors w-full cursor-pointer min-h-[44px]"
            >
              Confirmar Nova Senha
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export async function verifyOwnerCredentials(password: string): Promise<boolean> {
  const clean = password.trim();
  if (!clean) return false;

  // Direct check for default temp password if no custom password is saved yet
  const stored = getStoredPasswordHash();
  if (!stored) {
    if (clean === INITIAL_TEMP_PASSWORD) return true;
  }

  const hash = await sha256(clean);
  if (stored) {
    return hash === stored;
  }
  return hash === INITIAL_TEMP_HASH;
}
