import { useCallback, useEffect, useMemo, useState, type FormEvent } from 'react';
import {
  ArrowDownLeft,
  ArrowUpRight,
  Calculator,
  CheckCircle2,
  ExternalLink,
  HelpCircle,
  Layers,
  Plus,
  Receipt,
  Search,
  ShieldCheck,
  ShoppingBag,
  Wallet,
} from 'lucide-react';
import { motion } from 'motion/react';
import { apiRequest } from '../api.ts';
import type {
  CustomerDashboardData,
  OrderItem,
  PaymentRecord,
  ServiceItem,
  SupportTicket,
  TransactionRecord,
  UpiConfig,
  UserProfile,
} from '../types.ts';
import {
  calculatePreviewPaise,
  formatDateTime,
  formatInr,
  formatInrExact,
  formatNumber,
  formatPaymentMethodLabel,
} from '../utils/format.ts';
import { CheckoutModal } from './CheckoutModal.tsx';
import { ReceiptModal } from './ReceiptModal.tsx';
import { StatusLabel } from './StatusLabel.tsx';

export type CustomerTab = 'overview' | 'order' | 'orders' | 'wallet' | 'support';

interface CustomerWorkspaceProps {
  user: UserProfile;
  services: ServiceItem[];
  paymentMode: 'upi_direct' | 'razorpay';
  upiConfig: UpiConfig;
  activeTab: CustomerTab;
  onChangeTab: (tab: CustomerTab) => void;
  onBalanceSync: (walletBalancePaise: number) => void;
  onAuthExpired: () => void;
}

const QUANTITY_PRESETS = [500, 1000, 5000, 10000, 25000];

export function CustomerWorkspace({
  user,
  services,
  paymentMode,
  upiConfig,
  activeTab,
  onChangeTab,
  onBalanceSync,
  onAuthExpired,
}: CustomerWorkspaceProps) {
  const [dashboard, setDashboard] = useState<CustomerDashboardData | null>(null);
  const [orders, setOrders] = useState<OrderItem[]>([]);
  const [transactions, setTransactions] = useState<TransactionRecord[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState(true);

  // Order placement state
  const [selectedServiceId, setSelectedServiceId] = useState<number>(services[0]?.id || 1);
  const [targetUrl, setTargetUrl] = useState('');
  const [quantityInput, setQuantityInput] = useState<string>('10000');
  const [orderSubmitting, setOrderSubmitting] = useState(false);
  const [orderError, setOrderError] = useState('');

  // Orders filter state
  const [orderSearch, setOrderSearch] = useState('');
  const [orderFilter, setOrderFilter] = useState<'all' | 'unpaid' | 'active' | 'completed'>('all');

  // Wallet topup state
  const [topupAmountInput, setTopupAmountInput] = useState('250');

  // Support ticket state
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketMessage, setTicketMessage] = useState('');
  const [ticketOrderId, setTicketOrderId] = useState('');
  const [ticketSubmitting, setTicketSubmitting] = useState(false);
  const [ticketFeedback, setTicketFeedback] = useState('');

  // Modals
  const [checkoutOrder, setCheckoutOrder] = useState<OrderItem | null>(null);
  const [checkoutTopupInr, setCheckoutTopupInr] = useState<number | null>(null);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [receiptCode, setReceiptCode] = useState<string | null>(null);

  const loadAllCustomerData = useCallback(async () => {
    try {
      const [dashRes, ordRes, txRes, supRes] = await Promise.all([
        apiRequest<CustomerDashboardData>('/api/customer/dashboard'),
        apiRequest<{ orders: OrderItem[] }>('/api/orders'),
        apiRequest<{ transactions: TransactionRecord[]; payments: PaymentRecord[] }>('/api/transactions'),
        apiRequest<{ tickets: SupportTicket[] }>('/api/support'),
      ]);
      setDashboard(dashRes);
      onBalanceSync(dashRes.walletBalancePaise);
      setOrders(ordRes.orders);
      setTransactions(txRes.transactions);
      setPayments(txRes.payments);
      setTickets(supRes.tickets);
    } catch (err) {
      if (err instanceof Error && /authentication required|session expired/i.test(err.message)) {
        onAuthExpired();
      }
    } finally {
      setLoading(false);
    }
  }, [onBalanceSync, onAuthExpired]);

  useEffect(() => {
    loadAllCustomerData();
  }, [loadAllCustomerData]);

  useEffect(() => {
    if (services.length > 0 && !services.some((s) => s.id === selectedServiceId)) {
      setSelectedServiceId(services[0].id);
      setQuantityInput(String(services[0].reference_quantity));
    }
  }, [services, selectedServiceId]);

  const selectedService = useMemo(
    () => services.find((s) => s.id === selectedServiceId) || services[0] || null,
    [services, selectedServiceId],
  );

  const parsedQuantity = Math.max(0, Math.floor(Number(quantityInput) || 0));
  const calculatedPricePaise = selectedService
    ? calculatePreviewPaise(parsedQuantity, selectedService.reference_quantity, selectedService.reference_price_paise)
    : 0;

  const handleQuickSelectService = (svc: ServiceItem) => {
    setSelectedServiceId(svc.id);
    setQuantityInput(String(svc.reference_quantity));
    setOrderError('');
    onChangeTab('order');
  };

  const handleCreateOrder = async (e: FormEvent) => {
    e.preventDefault();
    if (!selectedService) return;
    setOrderError('');
    setOrderSubmitting(true);
    try {
      const res = await apiRequest<{ order: OrderItem }>('/api/orders', {
        method: 'POST',
        body: JSON.stringify({
          serviceId: selectedService.id,
          quantity: parsedQuantity,
          targetUrl,
        }),
      });
      await loadAllCustomerData();
      setTargetUrl('');
      setCheckoutTopupInr(null);
      setCheckoutOrder(res.order);
      setCheckoutOpen(true);
    } catch (err) {
      setOrderError(err instanceof Error ? err.message : 'Unable to create order.');
    } finally {
      setOrderSubmitting(false);
    }
  };

  const handleStartTopup = (amountInr: number) => {
    if (!Number.isFinite(amountInr) || amountInr < 10) return;
    setCheckoutOrder(null);
    setCheckoutTopupInr(amountInr);
    setCheckoutOpen(true);
  };

  const handleCreateTicket = async (e: FormEvent) => {
    e.preventDefault();
    setTicketFeedback('');
    setTicketSubmitting(true);
    try {
      await apiRequest('/api/support', {
        method: 'POST',
        body: JSON.stringify({
          subject: ticketSubject,
          message: ticketMessage,
          orderId: ticketOrderId ? Number(ticketOrderId) : null,
        }),
      });
      setTicketSubject('');
      setTicketMessage('');
      setTicketOrderId('');
      setTicketFeedback('Support request submitted. Our team will respond shortly.');
      await loadAllCustomerData();
    } catch (err) {
      setTicketFeedback(err instanceof Error ? err.message : 'Could not submit support ticket.');
    } finally {
      setTicketSubmitting(false);
    }
  };

  const filteredOrders = useMemo(() => {
    return orders.filter((o) => {
      if (orderFilter === 'unpaid' && o.status !== 'awaiting_payment' && o.status !== 'payment_failed') {
        return false;
      }
      if (orderFilter === 'active' && o.status !== 'queued' && o.status !== 'in_progress') {
        return false;
      }
      if (orderFilter === 'completed' && o.status !== 'completed') {
        return false;
      }
      if (orderSearch.trim()) {
        const q = orderSearch.trim().toLowerCase();
        return (
          o.order_code.toLowerCase().includes(q) ||
          o.service_name_snapshot.toLowerCase().includes(q) ||
          o.target_url.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [orders, orderFilter, orderSearch]);

  const walletBalancePaise = dashboard?.walletBalancePaise ?? user.walletBalancePaise ?? 0;

  return (
    <div className="space-y-6 pb-20 md:pb-8">
      {/* OVERVIEW TAB */}
      {activeTab === 'overview' && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
          className="space-y-6"
        >
          {/* Welcome + Wallet Balance Hero Row */}
          <div className="rounded-2xl sb-surface p-5 sm:p-6 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
            <div className="space-y-1.5">
              <div className="text-xs font-medium text-cyan-300">
                Welcome back, {user.name} · Creator Dashboard
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-gradient-aurora [text-wrap:balance]">
                Campaign Overview &amp; Account Balance
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
                Monitor active social reach campaigns, launch custom quantity orders, and review verified INR receipts.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0">
              <div className="rounded-xl sb-surface-inner px-4 py-3 min-w-[180px]">
                <div className="text-xs text-slate-400">Account Balance</div>
                <div className="text-xl font-extrabold font-mono tabular-nums text-gradient-ocean mt-0.5">
                  {formatInrExact(walletBalancePaise)}
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => onChangeTab('wallet')}
                  className="flex-1 sm:flex-none min-h-[44px] px-4 rounded-xl border border-cyan-400/30 bg-cyan-500/10 hover:bg-cyan-500/20 text-xs font-semibold text-cyan-200 whitespace-nowrap cursor-pointer"
                >
                  Add Funds
                </button>
                <button
                  type="button"
                  onClick={() => onChangeTab('order')}
                  className="flex-1 sm:flex-none min-h-[44px] px-5 rounded-xl btn-gradient-primary text-xs font-semibold text-white flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer shadow-md shadow-fuchsia-500/20"
                >
                  <Plus className="h-4 w-4" />
                  <span>New Order</span>
                </button>
              </div>
            </div>
          </div>

          {/* 4-column KPI strip */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="rounded-2xl sb-surface p-4 sm:p-5">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>Available Services</span>
                <Layers className="h-4 w-4 text-fuchsia-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold font-mono tabular-nums text-fuchsia-300 mt-2">
                {loading ? '—' : formatNumber(dashboard?.availableServices ?? services.length)}
              </div>
              <div className="text-xs text-slate-400 mt-1">Policy-approved tiers</div>
            </div>

            <div className="rounded-2xl sb-surface p-4 sm:p-5">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>Total Orders</span>
                <ShoppingBag className="h-4 w-4 text-cyan-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold font-mono tabular-nums text-cyan-300 mt-2">
                {loading ? '—' : formatNumber(dashboard?.totalOrders ?? 0)}
              </div>
              <div className="text-xs text-slate-400 mt-1">All-time campaigns</div>
            </div>

            <div className="rounded-2xl sb-surface p-4 sm:p-5">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>Pending Orders</span>
                <Calculator className="h-4 w-4 text-amber-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold font-mono tabular-nums text-amber-300 mt-2">
                {loading ? '—' : formatNumber(dashboard?.pendingOrders ?? 0)}
              </div>
              <div className="text-xs text-slate-400 mt-1">Awaiting / in progress</div>
            </div>

            <div className="rounded-2xl sb-surface p-4 sm:p-5">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span>Completed Orders</span>
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold font-mono tabular-nums text-emerald-300 mt-2">
                {loading ? '—' : formatNumber(dashboard?.completedOrders ?? 0)}
              </div>
              <div className="text-xs text-slate-400 mt-1">Delivered campaigns</div>
            </div>
          </div>

          {/* Available Services Quick-Launch Grid */}
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-gradient-aurora">Available Services</h2>
              <button
                type="button"
                onClick={() => onChangeTab('order')}
                className="text-xs font-semibold text-cyan-300 hover:text-cyan-200 cursor-pointer"
              >
                Open Custom Calculator &rarr;
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
              {services.map((svc, idx) => {
                const titlePalette = [
                  'text-cyan-300',
                  'text-pink-300',
                  'text-violet-300',
                  'text-emerald-300',
                ];
                return (
                  <div
                    key={svc.id}
                    className="rounded-2xl sb-surface p-5 flex flex-col justify-between gap-4 hover:border-cyan-400/40 transition-colors"
                  >
                    <div className="space-y-2">
                      <div className="text-xs text-slate-400">{svc.category}</div>
                      <h3 className={`text-base font-bold ${titlePalette[idx % titlePalette.length]}`}>{svc.name}</h3>
                      <p className="text-xs text-slate-300 leading-relaxed">{svc.description}</p>
                    </div>

                    <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-3">
                      <div>
                        <div className="text-sm font-extrabold font-mono tabular-nums text-gradient-sunset">
                          {formatInr(svc.reference_price_paise)}
                        </div>
                        <div className="text-[11px] font-mono text-slate-400">
                          per {formatNumber(svc.reference_quantity)}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleQuickSelectService(svc)}
                        className="min-h-[40px] px-3.5 rounded-xl bg-white/[0.08] hover:bg-gradient-to-r hover:from-fuchsia-600 hover:to-cyan-500 text-xs font-semibold text-white transition-all whitespace-nowrap cursor-pointer"
                      >
                        Select
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          {/* Recent Orders & Recent Transactions Split */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Recent Orders */}
            <section className="lg:col-span-7 rounded-2xl sb-surface overflow-hidden">
              <div className="px-5 py-4 border-b border-white/[0.08] flex items-center justify-between">
                <h2 className="text-sm font-semibold text-white">Recent Orders</h2>
                <button
                  type="button"
                  onClick={() => onChangeTab('orders')}
                  className="text-xs font-medium text-blue-400 hover:text-blue-300 cursor-pointer"
                >
                  View All
                </button>
              </div>
              {dashboard?.recentOrders?.length ? (
                <div className="divide-y divide-white/[0.06]">
                  {dashboard.recentOrders.map((ord) => (
                    <div key={ord.id} className="px-5 py-3.5 flex items-center justify-between gap-4">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 text-xs">
                          <span className="font-mono font-semibold text-white">{ord.order_code}</span>
                          <span className="text-slate-500">·</span>
                          <span className="text-slate-300 truncate">{ord.service_name_snapshot}</span>
                        </div>
                        <div className="text-xs text-slate-400 mt-0.5 truncate">
                          {formatNumber(ord.quantity)} qty · {ord.target_url}
                        </div>
                      </div>

                      <div className="text-right shrink-0 space-y-1">
                        <div className="text-xs font-mono font-semibold text-white">
                          {formatInrExact(ord.total_amount_paise)}
                        </div>
                        <div className="flex items-center justify-end gap-2">
                          <StatusLabel status={ord.status} compact />
                          {(ord.status === 'awaiting_payment' || ord.status === 'payment_failed') && (
                            <button
                              type="button"
                              onClick={() => {
                                setCheckoutTopupInr(null);
                                setCheckoutOrder(ord);
                                setCheckoutOpen(true);
                              }}
                              className="text-xs font-semibold text-violet-400 hover:text-violet-300 underline cursor-pointer"
                            >
                              Pay
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="px-5 py-10 text-center space-y-2">
                  <p className="text-sm text-slate-400">No orders placed yet.</p>
                  <button
                    type="button"
                    onClick={() => onChangeTab('order')}
                    className="min-h-[40px] px-4 rounded-xl btn-gradient-primary text-xs font-semibold text-white cursor-pointer"
                  >
                    Create Your First Order
                  </button>
                </div>
              )}
            </section>

            {/* Recent Transactions */}
            <section className="lg:col-span-5 rounded-2xl sb-surface overflow-hidden">
              <div className="px-5 py-4 border-b border-white/[0.08] flex items-center justify-between">
                <h2 className="text-sm font-semibold text-white">Recent Transactions</h2>
                <button
                  type="button"
                  onClick={() => onChangeTab('wallet')}
                  className="text-xs font-medium text-blue-400 hover:text-blue-300 cursor-pointer"
                >
                  Full Ledger
                </button>
              </div>
              {dashboard?.recentTransactions?.length ? (
                <div className="divide-y divide-white/[0.06]">
                  {dashboard.recentTransactions.map((tx) => (
                    <div key={tx.id} className="px-5 py-3.5 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="h-9 w-9 rounded-xl sb-surface-inner flex items-center justify-center shrink-0">
                          {tx.direction === 'credit' ? (
                            <ArrowDownLeft className="h-4 w-4 text-emerald-400" />
                          ) : (
                            <ArrowUpRight className="h-4 w-4 text-violet-400" />
                          )}
                        </div>
                        <div className="min-w-0">
                          <div className="text-xs font-medium text-white truncate">{tx.description}</div>
                          <div className="text-[11px] text-slate-400 mt-0.5 font-mono">
                            {tx.tx_code} · {formatDateTime(tx.created_at)}
                          </div>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div
                          className={`text-xs font-mono font-semibold ${
                            tx.direction === 'credit' ? 'text-emerald-400' : 'text-slate-100'
                          }`}
                        >
                          {tx.direction === 'credit' ? '+' : '-'}
                          {formatInrExact(tx.amount_paise)}
                        </div>
                        {tx.payment_code && tx.status === 'completed' && (
                          <button
                            type="button"
                            onClick={() => setReceiptCode(tx.payment_code!)}
                            className="text-[11px] text-blue-400 hover:text-blue-300 cursor-pointer mt-0.5"
                          >
                            Receipt
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="px-5 py-10 text-center text-xs text-slate-400">
                  No transactions recorded yet.
                </div>
              )}
            </section>
          </div>
        </motion.div>
      )}

      {/* ORDER PLACEMENT & CUSTOM QUANTITY CALCULATOR TAB */}
      {activeTab === 'order' && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
          className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start"
        >
          <div className="lg:col-span-7 rounded-2xl sb-surface p-5 sm:p-7 space-y-6">
            <div>
              <h1 className="text-xl sm:text-2xl font-extrabold text-gradient-aurora">Place a Compliant Campaign Order</h1>
              <p className="text-xs sm:text-sm text-slate-300 mt-1">
                Select an approved service, paste your public post or profile URL, and enter any custom quantity.
              </p>
            </div>

            <form onSubmit={handleCreateOrder} className="space-y-5">
              {/* Service Selector */}
              <div className="space-y-2">
                <label className="block text-xs font-medium text-slate-300">1. Choose Service</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {services.map((svc) => {
                    const active = svc.id === selectedService?.id;
                    return (
                      <button
                        key={svc.id}
                        type="button"
                        onClick={() => {
                          setSelectedServiceId(svc.id);
                          setQuantityInput(String(svc.reference_quantity));
                          setOrderError('');
                        }}
                        className={`min-h-[68px] rounded-xl border p-3.5 text-left transition-all cursor-pointer flex flex-col justify-between ${
                          active
                            ? 'border-violet-500 bg-violet-500/15'
                            : 'border-white/10 sb-surface-inner hover:border-white/20'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-sm font-semibold text-white">{svc.name}</span>
                          <span className="text-xs font-mono font-semibold text-blue-300">
                            {formatInr(svc.reference_price_paise)}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 mt-1 font-mono">
                          Ref: {formatNumber(svc.reference_quantity)} · ETA {svc.estimated_turnaround}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Campaign or Post URL */}
              <div className="space-y-1.5">
                <label htmlFor="campaign-url" className="block text-xs font-medium text-slate-300">
                  2. Public Post, Reel, or Profile URL
                </label>
                <input
                  id="campaign-url"
                  type="url"
                  required
                  value={targetUrl}
                  onChange={(e) => setTargetUrl(e.target.value)}
                  placeholder="https://www.instagram.com/reel/C9xExample/"
                  className="w-full min-h-[46px] rounded-xl sb-surface-inner px-3.5 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500"
                />
                <p className="text-[11px] text-slate-400">
                  Your account must be public. Never enter your password anywhere.
                </p>
              </div>

              {/* Custom Quantity */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <label htmlFor="custom-qty" className="text-xs font-medium text-slate-300">
                    3. Enter Custom Quantity
                  </label>
                  {selectedService && (
                    <span className="text-[11px] font-mono text-slate-400">
                      Min {formatNumber(selectedService.min_quantity)} · Max {formatNumber(selectedService.max_quantity)}
                    </span>
                  )}
                </div>

                <input
                  id="custom-qty"
                  type="number"
                  min={selectedService?.min_quantity || 100}
                  max={selectedService?.max_quantity || 500000}
                  step={1}
                  required
                  value={quantityInput}
                  onChange={(e) => setQuantityInput(e.target.value)}
                  className="w-full min-h-[48px] rounded-xl sb-surface-inner px-3.5 text-base font-mono font-semibold text-white focus:outline-none focus:border-violet-500"
                />

                <div className="flex flex-wrap gap-2">
                  {QUANTITY_PRESETS.map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setQuantityInput(String(preset))}
                      className={`min-h-[38px] px-3 rounded-lg border text-xs font-mono transition-colors cursor-pointer ${
                        parsedQuantity === preset
                          ? 'border-blue-500 bg-blue-500/20 text-white'
                          : 'border-white/10 sb-surface-inner text-slate-300 hover:border-white/20'
                      }`}
                    >
                      {formatNumber(preset)}
                    </button>
                  ))}
                </div>
              </div>

              {orderError && (
                <div className="rounded-xl bg-rose-500/10 border border-rose-500/30 px-4 py-3 text-xs text-rose-300">
                  {orderError}
                </div>
              )}

              <button
                type="submit"
                disabled={orderSubmitting || !selectedService}
                className="w-full min-h-[48px] rounded-xl btn-gradient-primary hover:from-violet-500 hover:to-blue-500 disabled:opacity-60 text-sm font-semibold text-white cursor-pointer transition-all"
              >
                {orderSubmitting
                  ? 'Creating Order...'
                  : `Confirm Order & Pay ${formatInrExact(calculatedPricePaise)}`}
              </button>
            </form>
          </div>

          {/* Live Price Breakdown & Policy Compliance Sidebar */}
          <div className="lg:col-span-5 space-y-4">
            <div className="rounded-2xl sb-surface p-5 sm:p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-semibold text-white">Pre-Checkout Price Summary</h2>
                <Calculator className="h-4 w-4 text-violet-400" />
              </div>

              {selectedService && (
                <>
                  <div className="rounded-xl sb-surface-inner p-4 space-y-2">
                    <div className="text-xs text-slate-400">Calculated Total Price</div>
                    <div className="text-3xl font-extrabold font-mono tabular-nums text-gradient-sunset">
                      {formatInrExact(calculatedPricePaise)}
                    </div>
                    <div className="text-[11px] font-mono text-cyan-300 pt-1">
                      ({formatNumber(parsedQuantity)} &divide; {formatNumber(selectedService.reference_quantity)}) &times;{' '}
                      {formatInr(selectedService.reference_price_paise)}
                    </div>
                  </div>

                  <dl className="divide-y divide-white/[0.06] text-xs">
                    <div className="py-2.5 flex justify-between gap-4">
                      <dt className="text-slate-400">Selected Service</dt>
                      <dd className="text-white font-medium">{selectedService.name}</dd>
                    </div>
                    <div className="py-2.5 flex justify-between gap-4">
                      <dt className="text-slate-400">Reference Rate</dt>
                      <dd className="font-mono text-slate-200">
                        {formatInr(selectedService.reference_price_paise)} /{' '}
                        {formatNumber(selectedService.reference_quantity)}
                      </dd>
                    </div>
                    <div className="py-2.5 flex justify-between gap-4">
                      <dt className="text-slate-400">Estimated Window</dt>
                      <dd className="text-slate-200">{selectedService.estimated_turnaround}</dd>
                    </div>
                    <div className="py-2.5 flex justify-between gap-4">
                      <dt className="text-slate-400">Server Verification</dt>
                      <dd className="text-emerald-400">Price verified at checkout</dd>
                    </div>
                  </dl>
                </>
              )}
            </div>

            <div className="rounded-2xl sb-surface p-5 space-y-2.5">
              <div className="flex items-center gap-2 text-xs font-semibold text-white">
                <ShieldCheck className="h-4 w-4 text-blue-400" />
                <span>Platform Policy & Transparency</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                {selectedService?.compliance_note ||
                  'All active services follow platform promotional policies. We do not promise artificial engagement or guaranteed follower counts.'}
              </p>
            </div>
          </div>
        </motion.div>
      )}

      {/* ORDERS & TRACKING TAB */}
      {activeTab === 'orders' && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
          className="space-y-5"
        >
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-white">Order History & Tracking</h1>
              <p className="text-xs text-slate-400 mt-0.5">
                Track verified payment status, campaign progress, and download order receipts.
              </p>
            </div>

            <button
              type="button"
              onClick={() => onChangeTab('order')}
              className="min-h-[44px] px-4 rounded-xl btn-gradient-primary text-xs font-semibold text-white flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              <span>Place New Order</span>
            </button>
          </div>

          {/* Search + Filter Controls */}
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="h-4 w-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={orderSearch}
                onChange={(e) => setOrderSearch(e.target.value)}
                placeholder="Search by Order ID, service, or URL..."
                className="w-full min-h-[44px] rounded-xl sb-surface pl-10 pr-4 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500"
              />
            </div>

            <div className="flex items-center gap-1 p-1 rounded-xl sb-surface overflow-x-auto">
              {(
                [
                  { id: 'all', label: 'All' },
                  { id: 'unpaid', label: 'Unpaid' },
                  { id: 'active', label: 'Active' },
                  { id: 'completed', label: 'Completed' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setOrderFilter(tab.id)}
                  className={`min-h-[36px] px-3.5 rounded-lg text-xs font-medium whitespace-nowrap cursor-pointer transition-colors ${
                    orderFilter === tab.id
                      ? 'btn-gradient-primary text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {filteredOrders.length === 0 ? (
            <div className="rounded-2xl sb-surface p-10 text-center space-y-3">
              <p className="text-sm text-slate-400">No matching orders found.</p>
              <button
                type="button"
                onClick={() => {
                  setOrderFilter('all');
                  setOrderSearch('');
                }}
                className="min-h-[40px] px-4 rounded-xl border border-white/10 text-xs font-medium text-slate-200 cursor-pointer"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredOrders.map((ord) => {
                const canPay = ord.status === 'awaiting_payment' || ord.status === 'payment_failed';
                return (
                  <div
                    key={ord.id}
                    className="rounded-2xl sb-surface p-5 space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="space-y-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 text-xs">
                          <span className="font-mono font-bold text-white">{ord.order_code}</span>
                          <span className="text-slate-500">·</span>
                          <span className="font-medium text-violet-300">{ord.service_name_snapshot}</span>
                          <span className="text-slate-500">·</span>
                          <span className="font-mono text-slate-300">{formatNumber(ord.quantity)} qty</span>
                        </div>
                        <a
                          href={ord.target_url}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-blue-300 truncate max-w-full"
                        >
                          <span className="truncate">{ord.target_url}</span>
                          <ExternalLink className="h-3 w-3 shrink-0" />
                        </a>
                      </div>

                      <div className="flex items-center justify-between sm:justify-end gap-4 shrink-0">
                        <div className="text-left sm:text-right">
                          <div className="text-base font-bold font-mono tabular-nums text-white">
                            {formatInrExact(ord.total_amount_paise)}
                          </div>
                          <div className="text-[11px] font-mono text-slate-400">
                            {formatDateTime(ord.created_at)}
                          </div>
                        </div>
                        <StatusLabel status={ord.status} />
                      </div>
                    </div>

                    {/* Progress Tracker Bar */}
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-[11px] text-slate-400">
                        <span>{ord.notes || 'Tracking active'}</span>
                        <span className="font-mono tabular-nums">{ord.progress_percent}%</span>
                      </div>
                      <div className="h-1.5 w-full rounded-full bg-[#08071a] overflow-hidden">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-fuchsia-500 via-violet-500 to-cyan-400 transition-all duration-300"
                          style={{ width: `${ord.progress_percent}%` }}
                        />
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex flex-wrap items-center justify-end gap-2.5 pt-1">
                      {ord.latest_payment_code && ord.payment_status === 'paid' && (
                        <button
                          type="button"
                          onClick={() => setReceiptCode(ord.latest_payment_code!)}
                          className="min-h-[40px] px-3.5 rounded-xl border border-white/10 bg-white/[0.04] hover:bg-white/[0.08] text-xs font-medium text-slate-200 flex items-center gap-1.5 cursor-pointer"
                        >
                          <Receipt className="h-3.5 w-3.5 text-blue-400" />
                          <span>View Receipt</span>
                        </button>
                      )}
                      {canPay && (
                        <button
                          type="button"
                          onClick={() => {
                            setCheckoutTopupInr(null);
                            setCheckoutOrder(ord);
                            setCheckoutOpen(true);
                          }}
                          className="min-h-[40px] px-4 rounded-xl btn-gradient-primary hover:from-violet-500 hover:to-blue-500 text-xs font-semibold text-white cursor-pointer"
                        >
                          {ord.status === 'payment_failed' ? 'Retry Payment' : 'Complete Payment'}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </motion.div>
      )}

      {/* WALLET & TRANSACTION LEDGER TAB */}
      {activeTab === 'wallet' && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
          className="space-y-6"
        >
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Wallet Balance Card */}
            <div className="lg:col-span-5 rounded-2xl sb-surface p-6 space-y-5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-cyan-200">Available Wallet Balance</span>
                <Wallet className="h-5 w-5 text-emerald-400" />
              </div>
              <div className="text-3xl font-extrabold font-mono tabular-nums text-gradient-ocean">
                {formatInrExact(walletBalancePaise)}
              </div>

              <div className="space-y-2.5 pt-2 border-t border-white/[0.08]">
                <label htmlFor="topup-inr" className="block text-xs font-medium text-slate-300">
                  Add Funds via UPI / GPay / PhonePe / Paytm
                </label>
                <div className="flex gap-2">
                  <input
                    id="topup-inr"
                    type="number"
                    min={10}
                    max={50000}
                    value={topupAmountInput}
                    onChange={(e) => setTopupAmountInput(e.target.value)}
                    className="flex-1 min-h-[44px] rounded-xl sb-surface-inner px-3.5 text-sm font-mono text-white focus:outline-none focus:border-violet-500"
                  />
                  <button
                    type="button"
                    onClick={() => handleStartTopup(Number(topupAmountInput))}
                    className="min-h-[44px] px-5 rounded-xl btn-gradient-primary text-xs font-semibold text-white whitespace-nowrap cursor-pointer"
                  >
                    Add Funds
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {[100, 250, 500, 1000].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setTopupAmountInput(String(amt))}
                      className="min-h-[36px] px-3 rounded-lg sb-surface-inner hover:border-violet-500/40 text-xs font-mono text-slate-200 cursor-pointer"
                    >
                      ₹{amt}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Payment Records */}
            <div className="lg:col-span-7 rounded-2xl sb-surface overflow-hidden">
              <div className="px-5 py-4 border-b border-white/[0.08]">
                <h2 className="text-sm font-semibold text-white">Gateway Payment Records</h2>
              </div>
              {payments.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-400">No gateway payments recorded yet.</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-white/[0.06] text-slate-400">
                        <th className="px-5 py-3 font-medium">Payment ID</th>
                        <th className="px-5 py-3 font-medium">Method</th>
                        <th className="px-5 py-3 font-medium">Status</th>
                        <th className="px-5 py-3 font-medium text-right">Amount</th>
                        <th className="px-5 py-3 font-medium text-right">Receipt</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/[0.06]">
                      {payments.map((p) => (
                        <tr key={p.id} className="hover:bg-white/[0.02]">
                          <td className="px-5 py-3">
                            <div className="font-mono text-white">{p.payment_code}</div>
                            <div className="text-[11px] text-slate-400">
                              {p.order_code || 'Wallet Top-up'} · {formatDateTime(p.created_at)}
                            </div>
                          </td>
                          <td className="px-5 py-3 text-slate-300">{formatPaymentMethodLabel(p.method)}</td>
                          <td className="px-5 py-3">
                            <StatusLabel status={p.status} compact />
                          </td>
                          <td className="px-5 py-3 text-right font-mono font-semibold text-white">
                            {formatInrExact(p.amount_paise)}
                          </td>
                          <td className="px-5 py-3 text-right">
                            <button
                              type="button"
                              onClick={() => setReceiptCode(p.payment_code)}
                              className="text-blue-400 hover:text-blue-300 font-medium cursor-pointer"
                            >
                              View
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>

          {/* Full Transaction History */}
          <section className="rounded-2xl sb-surface overflow-hidden">
            <div className="px-5 py-4 border-b border-white/[0.08]">
              <h2 className="text-sm font-semibold text-white">Immutable Transaction History</h2>
            </div>
            {transactions.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">No ledger entries yet.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-white/[0.06] text-slate-400">
                      <th className="px-5 py-3 font-medium">Transaction ID</th>
                      <th className="px-5 py-3 font-medium">Description</th>
                      <th className="px-5 py-3 font-medium">Status</th>
                      <th className="px-5 py-3 font-medium text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/[0.06]">
                    {transactions.map((tx) => (
                      <tr key={tx.id} className="hover:bg-white/[0.02]">
                        <td className="px-5 py-3 font-mono text-slate-300 whitespace-nowrap">{tx.tx_code}</td>
                        <td className="px-5 py-3">
                          <div className="text-white">{tx.description}</div>
                          <div className="text-[11px] font-mono text-slate-400 mt-0.5">
                            {formatDateTime(tx.created_at)}
                          </div>
                        </td>
                        <td className="px-5 py-3">
                          <StatusLabel status={tx.status} compact />
                        </td>
                        <td
                          className={`px-5 py-3 text-right font-mono font-semibold whitespace-nowrap ${
                            tx.direction === 'credit' ? 'text-emerald-400' : 'text-white'
                          }`}
                        >
                          {tx.direction === 'credit' ? '+' : '-'}
                          {formatInrExact(tx.amount_paise)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        </motion.div>
      )}

      {/* SUPPORT TAB */}
      {activeTab === 'support' && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
          className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start"
        >
          <div className="lg:col-span-5 rounded-2xl sb-surface p-5 sm:p-6 space-y-4">
            <div className="flex items-center gap-2">
              <HelpCircle className="h-5 w-5 text-violet-400" />
              <h2 className="text-base font-bold text-white">Submit a Support Request</h2>
            </div>

            <form onSubmit={handleCreateTicket} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Related Order (Optional)</label>
                <select
                  value={ticketOrderId}
                  onChange={(e) => setTicketOrderId(e.target.value)}
                  className="w-full min-h-[44px] rounded-xl sb-surface-inner px-3 text-sm text-white focus:outline-none focus:border-violet-500"
                >
                  <option value="">General Account / Billing Question</option>
                  {orders.map((o) => (
                    <option key={o.id} value={o.id}>
                      {o.order_code} · {o.service_name_snapshot}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Subject</label>
                <input
                  type="text"
                  required
                  value={ticketSubject}
                  onChange={(e) => setTicketSubject(e.target.value)}
                  placeholder="e.g. Refund or pacing inquiry"
                  className="w-full min-h-[44px] rounded-xl sb-surface-inner px-3.5 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Message</label>
                <textarea
                  rows={4}
                  required
                  value={ticketMessage}
                  onChange={(e) => setTicketMessage(e.target.value)}
                  placeholder="Describe how our team can help..."
                  className="w-full rounded-xl sb-surface-inner p-3.5 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-violet-500"
                />
              </div>

              {ticketFeedback && (
                <div className="rounded-xl bg-blue-500/10 border border-blue-500/30 px-3.5 py-2.5 text-xs text-blue-200">
                  {ticketFeedback}
                </div>
              )}

              <button
                type="submit"
                disabled={ticketSubmitting}
                className="w-full min-h-[44px] rounded-xl btn-gradient-primary text-xs font-semibold text-white cursor-pointer"
              >
                {ticketSubmitting ? 'Submitting...' : 'Send Support Ticket'}
              </button>
            </form>
          </div>

          <div className="lg:col-span-7 rounded-2xl sb-surface overflow-hidden">
            <div className="px-5 py-4 border-b border-white/[0.08]">
              <h2 className="text-sm font-semibold text-white">Your Support Tickets</h2>
            </div>
            {tickets.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">No support tickets opened yet.</div>
            ) : (
              <div className="divide-y divide-white/[0.06]">
                {tickets.map((t) => (
                  <div key={t.id} className="p-5 space-y-2.5">
                    <div className="flex items-center justify-between gap-4">
                      <div className="text-sm font-semibold text-white">{t.subject}</div>
                      <StatusLabel status={t.status} compact />
                    </div>
                    <div className="text-[11px] font-mono text-slate-400">
                      {t.ticket_code} {t.order_code ? `· ${t.order_code}` : ''} · {formatDateTime(t.created_at)}
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">{t.message}</p>
                    {t.admin_reply && (
                      <div className="rounded-xl sb-surface-inner p-3 text-xs text-blue-200">
                        <span className="font-semibold text-white">Support Reply: </span>
                        {t.admin_reply}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </motion.div>
      )}

      {/* Modals */}
      <CheckoutModal
        open={checkoutOpen}
        order={checkoutOrder}
        walletTopupAmountInr={checkoutTopupInr}
        walletBalancePaise={walletBalancePaise}
        paymentMode={paymentMode}
        upiConfig={upiConfig}
        onClose={() => setCheckoutOpen(false)}
        onPaymentUpdated={loadAllCustomerData}
        onOpenReceipt={(code) => setReceiptCode(code)}
      />

      <ReceiptModal paymentCode={receiptCode} onClose={() => setReceiptCode(null)} />
    </div>
  );
}
