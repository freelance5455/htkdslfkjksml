import React from 'react';
import { Image, Video, Smile } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface CreatePostBoxProps {
  onOpenCreatePost: () => void;
  onOpenCreateReel: () => void;
}

export const CreatePostBox: React.FC<CreatePostBoxProps> = ({
  onOpenCreatePost,
  onOpenCreateReel,
}) => {
  const { user } = useAuth();

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-3.5 sm:p-4 mb-4">
      {/* Top Input Bar */}
      <div className="flex items-center gap-3">
        <img
          src={user?.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=240&auto=format&fit=crop&q=80'}
          alt={user?.displayName || 'User'}
          className="w-10 h-10 rounded-full object-cover ring-1 ring-slate-200 shrink-0"
        />
        <button
          onClick={onOpenCreatePost}
          className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-500 rounded-full px-4 py-2.5 text-left text-sm sm:text-base font-normal transition-colors cursor-pointer"
        >
          What's on your mind, {user?.displayName?.split(' ')[0] || 'Friend'}?
        </button>
      </div>

      <div className="border-t border-slate-100 mt-3 pt-2.5 flex items-center justify-between sm:justify-around">
        {/* Photo/Video action */}
        <button
          onClick={onOpenCreatePost}
          className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl hover:bg-slate-50 text-slate-600 transition-colors cursor-pointer text-xs sm:text-sm font-medium"
        >
          <div className="w-6 h-6 rounded-lg bg-emerald-50 flex items-center justify-center">
            <Image className="w-4 h-4 text-emerald-500" />
          </div>
          <span>Photo/video</span>
        </button>

        {/* Reel action */}
        <button
          onClick={onOpenCreateReel}
          className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl hover:bg-slate-50 text-slate-600 transition-colors cursor-pointer text-xs sm:text-sm font-medium"
        >
          <div className="w-6 h-6 rounded-lg bg-rose-50 flex items-center justify-center">
            <Video className="w-4 h-4 text-rose-500" />
          </div>
          <span>Reel</span>
        </button>

        {/* Feeling/Activity */}
        <button
          onClick={onOpenCreatePost}
          className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl hover:bg-slate-50 text-slate-600 transition-colors cursor-pointer text-xs sm:text-sm font-medium"
        >
          <div className="w-6 h-6 rounded-lg bg-amber-50 flex items-center justify-center">
            <Smile className="w-4 h-4 text-amber-500" />
          </div>
          <span className="hidden xs:inline">Feeling/activity</span>
          <span className="xs:hidden">Feeling</span>
        </button>
      </div>
    </div>
  );
};
