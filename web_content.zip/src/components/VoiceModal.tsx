import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, X, Volume2, Sparkles, RefreshCw } from 'lucide-react';
import logoImg from '../assets/images/sm_ai_logo_1786303544354.jpg';

interface VoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSendVoiceMessage: (text: string) => Promise<string>;
}

export const VoiceModal: React.FC<VoiceModalProps> = ({
  isOpen,
  onClose,
  onSendVoiceMessage,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [aiResponseText, setAiResponseText] = useState('');

  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if (!isOpen) {
      stopListening();
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      return;
    }

    // Auto start listening on open
    startListening();

    return () => {
      stopListening();
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [isOpen]);

  const startListening = () => {
    // Immediately stop AI speech if currently speaking
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);

    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      setTranscript('Brauzeriniz səs tanınmasını dəstəkləmir.');
      return;
    }

    try {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.lang = 'az-AZ';
      recognition.continuous = false;
      recognition.interimResults = true;

      recognition.onstart = () => {
        if ('speechSynthesis' in window) {
          window.speechSynthesis.cancel();
        }
        setIsSpeaking(false);
        setIsListening(true);
        setTranscript('Eşidirəm...');
      };

      recognition.onsoundstart = () => {
        // User started making sound/speaking - interrupt AI speech immediately!
        if ('speechSynthesis' in window) {
          window.speechSynthesis.cancel();
        }
        setIsSpeaking(false);
      };

      recognition.onresult = (event: any) => {
        // Stop AI speech if any speech detected from user
        if ('speechSynthesis' in window) {
          window.speechSynthesis.cancel();
        }
        setIsSpeaking(false);

        const currentTranscript = Array.from(event.results)
          .map((result: any) => result[0].transcript)
          .join('');
        setTranscript(currentTranscript);
      };

      recognition.onerror = (err: any) => {
        console.warn('Voice error:', err);
        setIsListening(false);
      };

      recognition.onend = async () => {
        setIsListening(false);
        // If transcript exists, process with SM AI
        if (transcript && transcript !== 'Eşidirəm...') {
          await processVoiceInput(transcript);
        }
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      console.error(err);
      setIsListening(false);
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {}
      recognitionRef.current = null;
    }
    setIsListening(false);
  };

  const processVoiceInput = async (text: string) => {
    setIsThinking(true);
    try {
      const reply = await onSendVoiceMessage(text);
      setAiResponseText(reply);
      speakResponse(reply);
    } catch (err) {
      console.error(err);
      setAiResponseText('Bağışlayın, cavab verərkən xəta baş verdi.');
    } finally {
      setIsThinking(false);
    }
  };

  const speakResponse = (text: string) => {
    if (!('speechSynthesis' in window)) return;

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Configure deep male voice (qalın oğlan səsi)
    utterance.pitch = 0.7; // Lower pitch for deep male voice
    utterance.rate = 0.95; // Slightly deeper pacing

    const voices = window.speechSynthesis.getVoices();
    if (voices && voices.length > 0) {
      const maleVoice = voices.find((v) =>
        /male|david|pavel|stefan|george|alex|daniel|google us english|turkish male/i.test(v.name)
      );
      if (maleVoice) {
        utterance.voice = maleVoice;
      }
    }

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => {
      setIsSpeaking(false);
      // Auto re-listen after speech completes
      setTimeout(() => startListening(), 1000);
    };
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  const handleMicClick = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);

    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-xl flex flex-col items-center justify-between p-6 animate-fade-in">
      {/* Top Bar */}
      <div className="w-full max-w-md flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" />
          <span className="text-xs font-bold text-amber-300 uppercase tracking-widest">
            SM AI Voice Mode
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-2 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Main Orb Visualizer */}
      <div
        onClick={handleMicClick}
        className="flex flex-col items-center justify-center my-auto space-y-8 text-center max-w-sm cursor-pointer select-none"
      >
        <div className="relative flex items-center justify-center">
          {/* Pulsating Waves */}
          <div
            className={`absolute w-44 h-44 rounded-full bg-amber-500/20 blur-xl transition-transform duration-500 ${
              isListening || isSpeaking ? 'scale-150 animate-pulse' : 'scale-100'
            }`}
          />
          <div
            className={`absolute w-36 h-36 rounded-full border border-amber-400/40 transition-all duration-300 ${
              isListening ? 'scale-125 border-amber-300 animate-ping' : ''
            }`}
          />

          {/* Center Logo/Icon */}
          <div className="relative w-28 h-28 rounded-full border-2 border-amber-400 p-1 bg-black shadow-[0_0_30px_rgba(245,208,97,0.4)] flex items-center justify-center">
            <img
              src={logoImg}
              alt="SM AI Voice Orb"
              className="w-full h-full rounded-full object-cover"
            />
          </div>
        </div>

        {/* Dynamic Status Text */}
        <div className="space-y-2 min-h-[90px]">
          <p className="text-sm font-semibold text-amber-300 uppercase tracking-wider flex items-center justify-center gap-2">
            {isListening && (
              <>
                <Mic className="w-4 h-4 text-amber-400 animate-bounce" /> Eşidirəm...
              </>
            )}
            {isThinking && (
              <>
                <RefreshCw className="w-4 h-4 text-amber-400 animate-spin" /> Düşünürəm...
              </>
            )}
            {isSpeaking && (
              <>
                <Volume2 className="w-4 h-4 text-amber-400 animate-pulse" /> SM AI Danışır... (Toxunsanız dayanacaq)
              </>
            )}
            {!isListening && !isThinking && !isSpeaking && (
              <>
                <Sparkles className="w-4 h-4 text-amber-400" /> Səsli Danışığa Hazırdır
              </>
            )}
          </p>

          <p className="text-xs text-zinc-300 px-4 py-2 bg-zinc-900/80 border border-zinc-800 rounded-xl max-h-24 overflow-y-auto italic">
            "{transcript || aiResponseText || 'Danışmaq üçün ekrana və ya mikrofona toxunun'}"
          </p>
        </div>
      </div>

      {/* Bottom Controls */}
      <div className="w-full max-w-md flex items-center justify-center gap-4">
        <button
          onClick={handleMicClick}
          className={`p-5 rounded-full transition duration-300 shadow-xl ${
            isListening
              ? 'bg-rose-500 text-white animate-pulse'
              : 'bg-gradient-to-r from-amber-500 to-amber-400 text-black'
          }`}
        >
          {isListening ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
        </button>
      </div>
    </div>
  );
};
