import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  PhoneOff,
  Sparkles,
  Loader2,
  Radio,
  Settings2,
  ChevronDown,
  AlertCircle,
  MessageSquareQuote,
  RotateCcw
} from 'lucide-react';
import { GeminiLiveClient, LiveClientState } from '../lib/geminiLiveClient';
import { AudioRecorder, transcribeAudio, synthesizeSpeech } from '../lib/audioRecorder';

interface VoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAppendMessage: (role: 'user' | 'assistant', content: string) => void;
  defaultVoice?: string;
  isLight?: boolean;
}

const LIVE_VOICES = [
  { id: 'Zephyr', name: 'زفير (Zephyr - دافئ ومتوازن)', gender: 'neutral' },
  { id: 'Puck', name: 'باك (Puck - نشيط ومرح)', gender: 'male' },
  { id: 'Charon', name: 'شارون (Charon - عميق ورسمي)', gender: 'male' },
  { id: 'Kore', name: 'كوري (Kore - هادئ ولطيف)', gender: 'female' },
  { id: 'Fenrir', name: 'فنرير (Fenrir - واثق وحيوي)', gender: 'male' },
];

export const VoiceModal: React.FC<VoiceModalProps> = ({
  isOpen,
  onClose,
  onAppendMessage,
  defaultVoice = 'Zephyr',
  isLight = false,
}) => {
  // Mode: 'live' uses gemini-3.8-live (Live API), 'turn' uses fallback recording
  const [mode, setMode] = useState<'live' | 'turn'>('live');
  const [liveState, setLiveState] = useState<LiveClientState>('disconnected');
  const [selectedVoice, setSelectedVoice] = useState<string>(defaultVoice);
  const [isMuted, setIsMuted] = useState(false);
  const [audioLevel, setAudioLevel] = useState<number>(10);
  const [isModelSpeaking, setIsModelSpeaking] = useState(false);
  const [liveTranscript, setLiveTranscript] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showVoicePicker, setShowVoicePicker] = useState(false);

  // Fallback Turn-by-Turn state
  const [isRecordingTurn, setIsRecordingTurn] = useState(false);
  const [isProcessingTurn, setIsProcessingTurn] = useState(false);
  const [turnTranscript, setTurnTranscript] = useState('');
  const [turnResponse, setTurnResponse] = useState('');

  const liveClientRef = useRef<GeminiLiveClient | null>(null);
  const recorderRef = useRef<AudioRecorder | null>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);

  // Sound wave bar heights
  const [waveHeights, setWaveHeights] = useState<number[]>([15, 25, 40, 20, 55, 35, 65, 30, 18, 45, 25, 35]);

  // Connect to Gemini 3.8 Live API when modal opens in 'live' mode
  useEffect(() => {
    if (!isOpen) {
      stopAll();
      return;
    }

    if (mode === 'live') {
      startLiveSession();
    }

    return () => {
      stopAll();
    };
  }, [isOpen, mode]);

  // Dynamic visualizer waves driven by live audio levels
  useEffect(() => {
    if (!isOpen) return;

    const interval = setInterval(() => {
      if (liveState === 'speaking' || liveState === 'listening' || isRecordingTurn) {
        const factor = Math.max(12, audioLevel);
        setWaveHeights(
          Array.from({ length: 12 }, () => Math.min(80, Math.floor(Math.random() * (factor * 0.75)) + 12))
        );
      } else {
        setWaveHeights([14, 18, 14, 20, 16, 14, 18, 14, 20, 16, 14, 18]);
      }
    }, 110);

    return () => clearInterval(interval);
  }, [isOpen, liveState, isRecordingTurn, audioLevel]);

  const startLiveSession = async (voiceToUse = selectedVoice) => {
    setErrorMessage(null);
    setLiveTranscript('');
    stopAll();

    const client = new GeminiLiveClient({
      voiceName: voiceToUse,
      systemInstruction:
        "You are OnyxMind AI, a real-time voice assistant running on Gemini 3.8 Live. Respond naturally, warmly, and concisely in the user's language (primarily Arabic if addressed in Arabic, or English if addressed in English). Keep your spoken responses concise and conversational.",
      onStateChange: (st) => {
        setLiveState(st);
        if (st === 'speaking') {
          setIsModelSpeaking(true);
        } else {
          setIsModelSpeaking(false);
        }
      },
      onText: (text) => {
        setLiveTranscript((prev) => prev + text);
      },
      onAudioLevel: (level, isModel) => {
        setAudioLevel(level);
        setIsModelSpeaking(isModel);
      },
      onInterrupted: () => {
        setLiveTranscript((prev) => prev + ' [تمت المقاطعة]');
      },
      onTurnComplete: () => {
        // When model finishes a turn, optionally log assistant message
        setLiveTranscript((current) => {
          if (current.trim()) {
            onAppendMessage('assistant', current.trim());
          }
          return '';
        });
      },
      onError: (err) => {
        setErrorMessage(err);
      },
    });

    liveClientRef.current = client;

    try {
      await client.start();
    } catch (err: any) {
      console.warn('Live API start issue, fallback ready:', err);
    }
  };

  const stopAll = () => {
    if (liveClientRef.current) {
      liveClientRef.current.stop();
      liveClientRef.current = null;
    }
    if (recorderRef.current && recorderRef.current.isRecording()) {
      recorderRef.current.cancel();
    }
    if (audioPlayerRef.current) {
      audioPlayerRef.current.pause();
      audioPlayerRef.current = null;
    }
    setIsRecordingTurn(false);
    setIsProcessingTurn(false);
    setIsModelSpeaking(false);
    setLiveState('disconnected');
  };

  const handleToggleMute = () => {
    if (!liveClientRef.current) return;
    const nextMuted = !isMuted;
    liveClientRef.current.setMute(nextMuted);
    setIsMuted(nextMuted);
  };

  const handleVoiceChange = (voiceId: string) => {
    setSelectedVoice(voiceId);
    setShowVoicePicker(false);
    if (mode === 'live' && isOpen) {
      startLiveSession(voiceId);
    }
  };

  // Fallback Turn-by-Turn handlers
  const handleToggleTurnMic = async () => {
    if (isRecordingTurn) {
      setIsRecordingTurn(false);
      setIsProcessingTurn(true);

      try {
        if (!recorderRef.current) return;
        const result = await recorderRef.current.stop();

        if (result.durationMs < 400) {
          setIsProcessingTurn(false);
          return;
        }

        const text = await transcribeAudio(result.base64, result.mimeType);
        if (!text || !text.trim()) {
          setIsProcessingTurn(false);
          return;
        }

        setTurnTranscript(text);
        onAppendMessage('user', text);

        const aiRes = await fetch('/api/chat/stream', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            messages: [{ role: 'user', content: text }],
            model: 'gemini-3.8-flash',
          }),
        });

        const reader = aiRes.body?.getReader();
        const decoder = new TextDecoder();
        let full = '';
        if (reader) {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            const chunk = decoder.decode(value, { stream: true });
            for (const line of chunk.split('\n')) {
              if (line.startsWith('data: ')) {
                try {
                  const d = JSON.parse(line.slice(6));
                  if (d.text) full += d.text;
                } catch {}
              }
            }
          }
        }

        const reply = full.trim() || 'أهلاً بك!';
        setTurnResponse(reply);
        onAppendMessage('assistant', reply);
        setIsProcessingTurn(false);

        const audioUrl = await synthesizeSpeech(reply, selectedVoice);
        const audio = new Audio(audioUrl);
        audioPlayerRef.current = audio;
        await audio.play();
      } catch (err: any) {
        setIsProcessingTurn(false);
        setErrorMessage(err.message || 'حدث خطأ في معالجة الصوت.');
      }
    } else {
      setErrorMessage(null);
      if (!recorderRef.current) {
        recorderRef.current = new AudioRecorder();
      }
      await recorderRef.current.start();
      setIsRecordingTurn(true);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      dir="rtl"
    >
      <div className="relative w-full max-w-md bg-gradient-to-b from-[#14141d] to-[#0c0c11] border border-[#232332] rounded-[36px] p-6 sm:p-8 flex flex-col items-center text-center shadow-2xl overflow-hidden">
        
        {/* Glow ambient background aura */}
        <div
          className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full blur-3xl pointer-events-none transition-all duration-700 ${
            isModelSpeaking
              ? 'w-72 h-72 bg-blue-500/25'
              : liveState === 'listening' || isRecordingTurn
              ? 'w-72 h-72 bg-emerald-500/20'
              : 'w-60 h-60 bg-blue-600/10'
          }`}
        />

        {/* Top Header Controls */}
        <div className="w-full flex items-center justify-between mb-4 z-10">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-blue-950/60 border border-blue-500/30 text-blue-300 text-xs font-medium">
              <Sparkles className="w-3.5 h-3.5 text-blue-400 animate-pulse" />
              <span>Gemini 3.8 Live</span>
            </div>

            {/* Mode Switcher */}
            <div className="flex items-center p-0.5 rounded-xl bg-neutral-900 border border-neutral-800 text-[11px]">
              <button
                onClick={() => setMode('live')}
                className={`px-2 py-0.5 rounded-lg transition-colors flex items-center gap-1 font-medium ${
                  mode === 'live'
                    ? 'bg-blue-600 text-white'
                    : 'text-neutral-400 hover:text-white'
                }`}
                title="محادثة صوتية مباشرة فورية بدون تقطيع"
              >
                <Radio className="w-3 h-3" />
                <span>مباشر</span>
              </button>
              <button
                onClick={() => setMode('turn')}
                className={`px-2 py-0.5 rounded-lg transition-colors font-medium ${
                  mode === 'turn'
                    ? 'bg-blue-600 text-white'
                    : 'text-neutral-400 hover:text-white'
                }`}
                title="تسجيل إملائي ثم رد"
              >
                <span>إملاء</span>
              </button>
            </div>
          </div>

          {/* Close/Hang up button */}
          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-white rounded-full bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-800 transition-colors"
            title="إنهاء المكالمة الصوتية"
          >
            <PhoneOff className="w-4 h-4 text-rose-400" />
          </button>
        </div>

        {/* Error Notification if any */}
        {errorMessage && (
          <div className="w-full mb-3 p-2.5 bg-rose-950/60 border border-rose-800/80 rounded-2xl text-rose-300 text-xs flex items-center justify-between gap-2 z-10 animate-in fade-in">
            <div className="flex items-center gap-1.5 truncate">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span className="truncate">{errorMessage}</span>
            </div>
            {mode === 'live' && (
              <button
                onClick={() => startLiveSession()}
                className="px-2 py-1 rounded-lg bg-rose-800 hover:bg-rose-700 text-white text-[11px] font-medium shrink-0 flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                <span>إعادة المحاولة</span>
              </button>
            )}
          </div>
        )}

        {/* Central Orb & Live Visualizer */}
        <div className="relative my-4 flex items-center justify-center">
          {/* Animated pulsing outer halo */}
          <div
            className={`absolute rounded-full transition-all duration-500 ${
              isModelSpeaking
                ? 'w-48 h-48 bg-blue-500/25 animate-pulse'
                : liveState === 'listening' || isRecordingTurn
                ? 'w-48 h-48 bg-emerald-500/25 animate-ping'
                : 'w-36 h-36 bg-neutral-800/30'
            }`}
          />

          {/* Core Orb */}
          <div
            className={`w-36 h-36 rounded-full flex items-center justify-center border-2 transition-all duration-300 shadow-2xl ${
              isModelSpeaking
                ? 'border-blue-400 bg-blue-950/60 text-blue-300 shadow-blue-500/40 ring-4 ring-blue-500/20'
                : liveState === 'listening' || isRecordingTurn
                ? 'border-emerald-400 bg-emerald-950/60 text-emerald-300 shadow-emerald-500/30 ring-4 ring-emerald-500/20'
                : liveState === 'connecting' || isProcessingTurn
                ? 'border-amber-400 bg-amber-950/50 text-amber-300'
                : 'border-[#2d2d40] bg-[#161622] text-neutral-300'
            }`}
          >
            {liveState === 'connecting' || isProcessingTurn ? (
              <Loader2 className="w-12 h-12 animate-spin text-amber-400" />
            ) : isModelSpeaking ? (
              <Volume2 className="w-12 h-12 animate-bounce text-blue-300" />
            ) : (
              <Mic
                className={`w-12 h-12 ${
                  isMuted ? 'text-neutral-500' : 'text-emerald-400 animate-pulse'
                }`}
              />
            )}
          </div>
        </div>

        {/* Live Sound Waves Bars */}
        <div className="flex items-center justify-center gap-1.5 h-14 my-2 w-full px-4">
          {waveHeights.map((h, i) => (
            <div
              key={i}
              className={`w-1.5 rounded-full transition-all duration-100 ${
                isModelSpeaking
                  ? 'bg-blue-400'
                  : liveState === 'listening' || isRecordingTurn
                  ? 'bg-emerald-400'
                  : 'bg-neutral-700'
              }`}
              style={{ height: `${h}px` }}
            />
          ))}
        </div>

        {/* Status Text & Subtitle */}
        <div className="my-2 space-y-1">
          <h3 className="text-base font-semibold text-white tracking-tight">
            {mode === 'live' ? (
              liveState === 'connecting'
                ? 'جارِ الاتصال بـ Gemini 3.8 Live...'
                : liveState === 'listening'
                ? isMuted
                  ? 'الميكروفون مكتوم مؤقتاً'
                  : 'أستمع إليك الآن.. تحدث بحرية'
                : liveState === 'speaking'
                ? 'الذكاء الاصطناعي يتحدث إليك...'
                : liveState === 'interrupted'
                ? 'تمت المقاطعة للاستماع إليك (Barge-in)'
                : 'متصل وجاهز للمحادثة'
            ) : isProcessingTurn ? (
              'جارِ المعالجة والتوليد...'
            ) : isRecordingTurn ? (
              'أستمع للتسجيل...'
            ) : (
              'اضغط على زر التسجيل للتحدث'
            )}
          </h3>

          <p className="text-xs text-neutral-400 max-w-xs leading-relaxed">
            {mode === 'live'
              ? 'محادثة صوتية ثنائية فائقة السرعة مع نموذج gemini-3.8-live بميزة المقاطعة الفورية.'
              : 'وضع الإملاء والتوليد الصوتي التقليدي عبر Gemini Flash.'}
          </p>
        </div>

        {/* Live Text Transcript Bubble if active */}
        {(liveTranscript || turnTranscript || turnResponse) && (
          <div className="w-full my-2 max-h-24 overflow-y-auto p-2.5 rounded-2xl bg-neutral-900/80 border border-neutral-800 text-xs text-neutral-200 text-right leading-relaxed animate-in fade-in">
            <div className="flex items-center gap-1 text-[10px] text-blue-400 font-medium mb-1">
              <MessageSquareQuote className="w-3 h-3" />
              <span>النص المباشر:</span>
            </div>
            <p className="line-clamp-3">
              {liveTranscript || turnResponse || turnTranscript}
            </p>
          </div>
        )}

        {/* Controls Footer */}
        <div className="w-full flex items-center justify-between gap-3 mt-4 pt-4 border-t border-[#232332] z-10">
          
          {/* Voice Selection Button */}
          <div className="relative">
            <button
              onClick={() => setShowVoicePicker(!showVoicePicker)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 text-xs font-medium transition-colors"
            >
              <Settings2 className="w-3.5 h-3.5" />
              <span>{selectedVoice}</span>
              <ChevronDown className="w-3 h-3 text-neutral-500" />
            </button>

            {showVoicePicker && (
              <div className="absolute right-0 bottom-12 w-56 p-1 rounded-2xl bg-[#1b1b26] border border-[#2e2e40] shadow-2xl z-50 text-right animate-in fade-in zoom-in-95">
                <div className="px-2.5 py-1.5 text-[10px] font-semibold text-neutral-400">
                  اختر صوت المساعد (Gemini Voice):
                </div>
                {LIVE_VOICES.map((v) => (
                  <button
                    key={v.id}
                    onClick={() => handleVoiceChange(v.id)}
                    className={`w-full text-right px-2.5 py-1.5 rounded-xl text-xs font-medium transition-colors flex items-center justify-between ${
                      selectedVoice === v.id
                        ? 'bg-blue-600 text-white'
                        : 'text-neutral-300 hover:bg-neutral-800'
                    }`}
                  >
                    <span>{v.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Primary Action Button */}
          <div className="flex items-center gap-2">
            {mode === 'live' ? (
              <button
                onClick={handleToggleMute}
                className={`p-3 rounded-full transition-all active:scale-95 shadow-md ${
                  isMuted
                    ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-600/30'
                    : 'bg-neutral-800 hover:bg-neutral-700 text-white'
                }`}
                title={isMuted ? 'إلغاء كتم المايك' : 'كتم المايك مؤقتاً'}
              >
                {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              </button>
            ) : (
              <button
                onClick={handleToggleTurnMic}
                disabled={isProcessingTurn}
                className={`p-3 rounded-full transition-all active:scale-95 shadow-md ${
                  isRecordingTurn
                    ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/30'
                    : 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-600/30'
                }`}
                title={isRecordingTurn ? 'إيقاف وإرسال' : 'بدء التحدث'}
              >
                {isRecordingTurn ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              </button>
            )}

            {/* Hang up end button */}
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-md shadow-rose-600/25"
            >
              <PhoneOff className="w-3.5 h-3.5" />
              <span>إنهاء</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
