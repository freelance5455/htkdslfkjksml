import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  MapPin,
  MapPinOff,
  Navigation,
  Phone,
  PhoneCall,
  Search,
  RefreshCw,
  AlertCircle,
  ExternalLink,
  Store,
} from 'lucide-react';
import { motion } from 'motion/react';
import { PreferredLanguage, PharmacyStore } from '../types';
import {
  fetchRealNearbyPharmacies,
  getDialablePhoneNumber,
} from '../data/pharmacyData';
import { ReadAloudButton } from './ReadAloudButton';

interface NearbyPharmacyStockViewProps {
  language: PreferredLanguage;
  onBack: () => void;
}

type LocationState = 'prompt' | 'requesting' | 'granted' | 'denied' | 'error';

async function fetchReverseGeocode(lat: number, lng: number): Promise<string> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4000);
    const res = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`,
      {
        headers: { 'User-Agent': 'MediguideAI/1.0' },
        signal: controller.signal,
      }
    );
    clearTimeout(timeoutId);
    if (res.ok) {
      const data = await res.json();
      if (data && data.display_name) {
        return data.display_name.split(',').slice(0, 3).join(', ');
      }
    }
  } catch (e) {
    // Ignore error
  }
  return `GPS: ${lat.toFixed(4)}, ${lng.toFixed(4)}`;
}

export const NearbyPharmacyStockView: React.FC<NearbyPharmacyStockViewProps> = ({
  language,
}) => {
  const [locationStatus, setLocationStatus] = useState<LocationState>('requesting');
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [locationAddress, setLocationAddress] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');

  const [pharmacies, setPharmacies] = useState<PharmacyStore[]>([]);
  const [isLoadingPharmacies, setIsLoadingPharmacies] = useState<boolean>(false);

  const [searchQuery, setSearchQuery] = useState<string>('');

  // Multilingual translations
  const t = {
    title: {
      English: 'Nearby Pharmacy Stock',
      Hindi: 'निकटतम फार्मेसी (Nearby Pharmacy Stock)',
      Marathi: 'जवळपासचे फार्मसी (Nearby Pharmacy Stock)',
    },
    subtitle: {
      English: 'Real pharmacies and medical stores located within 15 km of your location',
      Hindi: 'आपके स्थान से 15 किमी के दायरे में वास्तविक फार्मेसी और मेडिकल स्टोर',
      Marathi: 'तुमच्या स्थानापासून 15 किमी परिसरातील फार्मसी आणि मेडिकल स्टोअर्स',
    },
    locationRequesting: {
      English: 'Requesting location permission to find pharmacies within 15 km...',
      Hindi: '15 किमी के भीतर फार्मेसी खोजने के लिए स्थान की अनुमति ली जा रही है...',
      Marathi: '15 किमी परिसरातील फार्मसी शोधण्यासाठी स्थानाची परवानगी घेतली जात आहे...',
    },
    permissionDeniedTitle: {
      English: 'Location Permission Required',
      Hindi: 'स्थान की अनुमति आवश्यक है (Location Permission Required)',
      Marathi: 'स्थान परवानगी आवश्यक आहे (Location Permission Required)',
    },
    permissionDeniedMsg: {
      English:
        'Please allow location access to find real pharmacies and medical stores located within 15 km of your current location.',
      Hindi:
        'कृपया अपने वर्तमान स्थान से 15 किमी के भीतर फार्मेसी खोजने के लिए स्थान की अनुमति दें।',
      Marathi:
        'कृपया तुमच्या सध्याच्या ठिकाणापासून 15 किमी अंतरावर फार्मसी शोधण्यासाठी लोकेशन परवानगी द्या.',
    },
    allowLocationBtn: {
      English: 'Allow Location Access',
      Hindi: 'स्थान की अनुमति दें (Allow Location)',
      Marathi: 'स्थान परवानगी द्या (Allow Location)',
    },
    scanRadiusNotice: {
      English: 'Strict 15 km Maximum Radius from Your GPS Location',
      Hindi: 'आपके जीपीएस स्थान से अधिकतम 15 किमी का सख्त दायरा',
      Marathi: 'तुमच्या GPS स्थानापासून कमाल 15 किमी परिसर',
    },
    searchPlaceholder: {
      English: 'Search nearby pharmacies by name or address...',
      Hindi: 'फार्मेसी का नाम या पता खोजें...',
      Marathi: 'फार्मसीचे नाव किंवा पत्ता शोधा...',
    },
    noPharmaciesFound: {
      English: 'No nearby pharmacies found within 15 km.',
      Hindi: 'No nearby pharmacies found within 15 km.',
      Marathi: 'No nearby pharmacies found within 15 km.',
    },
    noPharmaciesHelper: {
      English: 'We could not detect any open retail pharmacies or medical stores within a 15 km radius of your coordinates.',
      Hindi: 'हम आपके वर्तमान जीपीएस निर्देशांक से 15 किमी के दायरे में कोई मेडिकल स्टोर नहीं खोज सके।',
      Marathi: 'आम्हाला तुमच्या सध्याच्या GPS समन्वयांच्या 15 किमी परिघात कोणतेही मेडिकल स्टोअर सापडले नाही.',
    },
    refreshLocation: {
      English: 'Refresh GPS & Scan Again',
      Hindi: 'जीपीएस रिफ्रेश करें और पुनः खोजें',
      Marathi: 'जीपीएस रिफ्रेश करा आणि पुन्हा शोधा',
    },
    pharmaciesFoundCount: {
      English: (n: number) => `${n} Pharmacies within 15 km (Sorted by nearest first)`,
      Hindi: (n: number) => `15 किमी के भीतर ${n} फार्मेसियां (निकटतम दूरी पहले)`,
      Marathi: (n: number) => `15 किमी च्या आत ${n} फार्मसी (जवळचे अंतर प्रथम)`,
    },
    callPharmacy: {
      English: 'Call Pharmacy',
      Hindi: 'कॉल करें',
      Marathi: 'कॉल करा',
    },
    getDirections: {
      English: 'Get Directions',
      Hindi: 'दिशा निर्देश',
      Marathi: 'दिशानिर्देश',
    },
    searchingPharmacies: {
      English: 'Scanning pharmacies within 15 km radius...',
      Hindi: '15 किमी के दायरे में फार्मेसी खोजी जा रही है...',
      Marathi: '15 किमी परिघातील फार्मसी शोधत आहे...',
    },
  };

  // Request actual user location using browser Geolocation API
  const requestLocation = useCallback(() => {
    setLocationStatus('requesting');
    setErrorMessage('');

    if (!navigator.geolocation) {
      setLocationStatus('error');
      setErrorMessage('Geolocation is not supported by your browser or environment.');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        setUserCoords({ lat, lng });
        setLocationStatus('granted');

        // Reverse geocode to show human-readable address
        fetchReverseGeocode(lat, lng).then((addr) => setLocationAddress(addr));

        // Fetch real nearby pharmacies within strict 15 km radius
        loadPharmacies(lat, lng);
      },
      (err) => {
        console.warn('[Geolocation] Error:', err);
        if (err.code === err.PERMISSION_DENIED) {
          setLocationStatus('denied');
        } else {
          setLocationStatus('error');
          setErrorMessage(err.message || 'Unable to retrieve your current location. Please check your device location settings.');
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 12000,
        maximumAge: 30000,
      }
    );
  }, []);

  // Fetch pharmacies from real OpenStreetMap Overpass / Nominatim
  const loadPharmacies = async (lat: number, lng: number) => {
    setIsLoadingPharmacies(true);
    try {
      // Strictly 15 km radius max
      const results = await fetchRealNearbyPharmacies(lat, lng, 15.0);
      // Double check filter: only pharmacies <= 15 km
      const filtered = results.filter((p) => p.distanceKm <= 15.0);
      // Sorted nearest first
      filtered.sort((a, b) => a.distanceKm - b.distanceKm);
      setPharmacies(filtered);
    } catch (e) {
      console.error('[NearbyPharmacy] Failed to load pharmacies:', e);
      setPharmacies([]);
    } finally {
      setIsLoadingPharmacies(false);
    }
  };

  // Trigger location request on mount
  useEffect(() => {
    requestLocation();
  }, [requestLocation]);

  // Filter pharmacies based on search query (pharmacy name or address)
  const filteredPharmacies = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return pharmacies.filter((pharmacy) => {
      // Must be within 15 km
      if (pharmacy.distanceKm > 15.0) return false;

      // Filter by search query if typed
      if (q) {
        const matchesPharmacyName = pharmacy.name.toLowerCase().includes(q);
        const matchesAddress = pharmacy.address.toLowerCase().includes(q);
        return matchesPharmacyName || matchesAddress;
      }

      return true;
    });
  }, [pharmacies, searchQuery]);

  return (
    <div className="space-y-6">
      {/* Top Controls & Location Banner */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-2xs space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600 shadow-2xs">
              <Store className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight">
                  {t.title[language]}
                </h1>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-2xs font-extrabold bg-amber-100 text-amber-800 border border-amber-200">
                  Max 15 km
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                {t.subtitle[language]}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <ReadAloudButton
              id="nearby-pharmacies-read-aloud"
              text={(() => {
                const parts: string[] = [];
                parts.push(`${t.title[language]}`);
                if (pharmacies.length > 0) {
                  parts.push(`Found ${pharmacies.length} pharmacies within 15 kilometers.`);
                  const topPharmacies = pharmacies.slice(0, 3).map((p, i) => `${i + 1}: ${p.name}, ${p.distanceKm.toFixed(1)} km away in ${p.address}`);
                  parts.push(`Closest stores: ${topPharmacies.join('. ')}`);
                } else if (isLoadingPharmacies) {
                  parts.push('Searching for pharmacies near your location');
                }
                return parts.join('. ');
              })()}
              language={language}
              variant="pill"
            />

            {/* Refresh GPS Button */}
            {userCoords && (
              <button
                onClick={requestLocation}
                disabled={isLoadingPharmacies}
                className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-700 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer"
                title="Refresh Location"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoadingPharmacies ? 'animate-spin text-amber-600' : ''}`} />
                <span>{t.refreshLocation[language]}</span>
              </button>
            )}
          </div>
        </div>

        {/* User Current Location Indicator */}
        {userCoords && (
          <div className="bg-gradient-to-r from-amber-50/70 via-orange-50/50 to-slate-50 p-3.5 rounded-2xl border border-amber-200/70 flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-xs">
                <Navigation className="w-4 h-4" />
              </div>
              <div className="truncate">
                <div className="font-extrabold text-slate-900 flex items-center gap-2 truncate">
                  <span>Current Location:</span>
                  <span className="text-amber-800 font-semibold truncate">
                    {locationAddress || `Lat: ${userCoords.lat.toFixed(4)}, Lng: ${userCoords.lng.toFixed(4)}`}
                  </span>
                </div>
                <div className="text-slate-500 text-2xs font-medium">
                  {t.scanRadiusNotice[language]} • Sorted nearest first
                </div>
              </div>
            </div>
            <div className="shrink-0 flex items-center gap-1 px-2.5 py-1 bg-white rounded-xl border border-amber-200 text-amber-800 font-extrabold text-2xs shadow-2xs">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>GPS Active</span>
            </div>
          </div>
        )}
      </div>

      {/* STATE 1: LOCATION REQUESTING */}
      {locationStatus === 'requesting' && (
        <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center space-y-4 shadow-2xs">
          <div className="relative mx-auto w-16 h-16 flex items-center justify-center">
            <div className="absolute inset-0 rounded-full bg-amber-100 animate-ping opacity-60" />
            <div className="relative w-14 h-14 bg-amber-500 text-white rounded-2xl flex items-center justify-center shadow-md">
              <Navigation className="w-7 h-7 animate-pulse" />
            </div>
          </div>
          <div className="space-y-1.5 max-w-md mx-auto">
            <h3 className="text-base font-extrabold text-slate-900">
              {t.locationRequesting[language]}
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Allow location access in your browser prompt to discover open pharmacies located within 15 km of your current position.
            </p>
          </div>
        </div>
      )}

      {/* STATE 2: LOCATION PERMISSION DENIED */}
      {locationStatus === 'denied' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-rose-200/90 text-center space-y-5 shadow-2xs">
          <div className="w-16 h-16 mx-auto rounded-3xl bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center shadow-xs">
            <MapPinOff className="w-8 h-8" />
          </div>

          <div className="space-y-2 max-w-lg mx-auto">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-rose-100 text-rose-800 border border-rose-200">
              <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
              Access Denied
            </span>
            <h3 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight">
              {t.permissionDeniedTitle[language]}
            </h3>
            <p className="text-sm text-slate-600 font-medium leading-relaxed bg-slate-50 p-4 rounded-2xl border border-slate-200/80">
              {t.permissionDeniedMsg[language]}
            </p>
          </div>

          <div className="pt-2">
            <button
              onClick={requestLocation}
              className="px-6 py-3 bg-amber-600 hover:bg-amber-700 text-white font-extrabold text-sm rounded-2xl shadow-md shadow-amber-600/20 transition-all active:scale-95 flex items-center gap-2 mx-auto cursor-pointer"
            >
              <Navigation className="w-4 h-4" />
              <span>{t.allowLocationBtn[language]}</span>
            </button>
            <p className="text-2xs text-slate-400 mt-3">
              If blocked permanently, tap the site settings / lock icon in your browser URL bar and change Location to &quot;Allow&quot;.
            </p>
          </div>
        </div>
      )}

      {/* STATE 3: LOCATION ERROR */}
      {locationStatus === 'error' && (
        <div className="bg-white rounded-3xl p-6 border border-amber-200 text-center space-y-4 shadow-2xs">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <AlertCircle className="w-7 h-7" />
          </div>
          <div className="space-y-1 max-w-md mx-auto">
            <h3 className="text-base font-extrabold text-slate-900">Location Detection Issue</h3>
            <p className="text-xs text-slate-600">{errorMessage || 'Could not retrieve your GPS location.'}</p>
          </div>
          <button
            onClick={requestLocation}
            className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
          >
            {t.refreshLocation[language]}
          </button>
        </div>
      )}

      {/* MAIN PHARMACY VIEW (When location granted) */}
      {locationStatus === 'granted' && (
        <div className="space-y-5">
          {/* Search Bar */}
          <div className="bg-white rounded-3xl p-4 border border-slate-200/80 shadow-2xs space-y-3">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t.searchPlaceholder[language]}
                className="w-full pl-10 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-medium text-slate-800 placeholder:text-slate-400 focus:bg-white focus:border-amber-500 focus:outline-none focus:ring-2 focus:ring-amber-500/20 transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          {/* Loading Indicator */}
          {isLoadingPharmacies && (
            <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center space-y-3 shadow-2xs">
              <div className="w-10 h-10 mx-auto border-3 border-amber-500 border-t-transparent rounded-full animate-spin" />
              <p className="text-xs font-bold text-slate-600">{t.searchingPharmacies[language]}</p>
            </div>
          )}

          {/* STATE 4: NO PHARMACIES FOUND WITHIN 15 KM */}
          {!isLoadingPharmacies && filteredPharmacies.length === 0 && (
            <div className="bg-white rounded-3xl p-8 border border-amber-200/80 text-center space-y-4 shadow-2xs">
              <div className="w-16 h-16 mx-auto rounded-3xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center shadow-xs">
                <Store className="w-8 h-8" />
              </div>

              <div className="space-y-2 max-w-md mx-auto">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-2xs font-extrabold uppercase tracking-wider bg-amber-100 text-amber-800 border border-amber-200">
                  Radius: 15 km Filter Active
                </span>
                {/* EXACT REQUIRED STRING */}
                <h3 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight">
                  {t.noPharmaciesFound[language]}
                </h3>
                <p className="text-xs text-slate-500 font-medium leading-relaxed">
                  {searchQuery
                    ? `No pharmacies matched "${searchQuery}" within 15 km of your location.`
                    : t.noPharmaciesHelper[language]}
                </p>
              </div>

              <div className="pt-2 flex items-center justify-center gap-2.5">
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    Clear Filter
                  </button>
                )}
                <button
                  onClick={requestLocation}
                  className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-2 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>{t.refreshLocation[language]}</span>
                </button>
              </div>
            </div>
          )}

          {/* STATE 5: PHARMACIES FOUND (Sorted nearest first) */}
          {!isLoadingPharmacies && filteredPharmacies.length > 0 && (
            <div className="space-y-4">
              {/* Header Count */}
              <div className="flex items-center justify-between px-1">
                <span className="text-xs font-black text-slate-800 tracking-tight flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-500" />
                  {t.pharmaciesFoundCount[language](filteredPharmacies.length)}
                </span>
                <span className="text-2xs font-bold text-slate-400">
                  Max 15 km
                </span>
              </div>

              {/* Pharmacy Cards List */}
              <div className="space-y-4">
                {filteredPharmacies.map((pharmacy, idx) => {
                  const dialablePhone = getDialablePhoneNumber(pharmacy.phone);

                  return (
                    <motion.div
                      key={pharmacy.id}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.2, delay: Math.min(0.25, idx * 0.04) }}
                      className="bg-white rounded-3xl border border-slate-200/80 shadow-2xs hover:shadow-md transition-all overflow-hidden p-4 sm:p-5 space-y-3.5"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="space-y-1 min-w-0 flex-1">
                          {/* Pharmacy name */}
                          <h2 className="text-base sm:text-lg font-black text-slate-900 tracking-tight leading-snug">
                            {pharmacy.name}
                          </h2>

                          {/* Address */}
                          <div className="flex items-start gap-1.5 text-xs text-slate-600 font-medium pt-0.5">
                            <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                            <span className="leading-tight">{pharmacy.address}</span>
                          </div>
                        </div>

                        {/* Distance from user's current location */}
                        <div className="shrink-0 text-right">
                          <div className="inline-flex items-center gap-1 px-3 py-1.5 rounded-2xl bg-amber-50 text-amber-900 border border-amber-200 shadow-2xs font-black text-xs sm:text-sm">
                            <Navigation className="w-3.5 h-3.5 text-amber-600" />
                            <span>{pharmacy.distanceText}</span>
                          </div>
                        </div>
                      </div>

                      {/* Contact Phone & Action Buttons */}
                      <div className="flex flex-wrap items-center justify-between gap-2 pt-2.5 border-t border-slate-100">
                        {/* Real contact/phone number if available */}
                        <div className="flex items-center gap-2 text-xs font-semibold text-slate-700">
                          <Phone className="w-3.5 h-3.5 text-slate-400" />
                          {pharmacy.phone ? (
                            <span className="text-slate-900 font-bold">{pharmacy.phone}</span>
                          ) : (
                            <span className="text-slate-400 italic">Phone number unavailable</span>
                          )}
                        </div>

                        <div className="flex items-center gap-2">
                          {/* Call Pharmacy button if a phone number is available */}
                          {pharmacy.phone && (
                            <a
                              id={`call-pharmacy-${pharmacy.id}`}
                              href={`tel:${dialablePhone}`}
                              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white rounded-xl text-xs font-bold transition-all shadow-2xs flex items-center gap-1.5 cursor-pointer"
                            >
                              <PhoneCall className="w-3 h-3" />
                              <span>{t.callPharmacy[language]}</span>
                            </a>
                          )}

                          {/* Get Directions button if it already exists */}
                          <a
                            id={`directions-pharmacy-${pharmacy.id}`}
                            href={`https://www.google.com/maps/dir/?api=1&destination=${pharmacy.latitude},${pharmacy.longitude}`}
                            target="_blank"
                            rel="noreferrer"
                            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                          >
                            <span>{t.getDirections[language]}</span>
                            <ExternalLink className="w-3 h-3 text-slate-400" />
                          </a>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
