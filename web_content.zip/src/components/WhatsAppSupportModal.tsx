import React, { useState } from 'react';
import { MessageSquare, ExternalLink, Copy, Check, ShieldCheck, X } from 'lucide-react';
import { APP_CONFIG } from '../config/appConfig';
import { useApp } from '../context/AppContext';

export const WhatsAppSupportModal: React.FC = () => {
  const { isWhatsAppModalOpen, setIsWhatsAppModalOpen, user, language } = useApp();
  const [copied, setCopied] = useState(false);
  const [selectedIssue, setSelectedIssue] = useState('Deposit Verification');

  if (!isWhatsAppModalOpen) return null;

  const prefilledMessages: Record<string, string> = {
    'Deposit Verification': `Hello X SABBIR Support, I need help with my deposit on E SPORTS TOUR. My Account Phone: ${user.phone}, FF UID: ${user.ffUid}. Please verify my TrxID.`,
    'Room ID & Password': `Hello X SABBIR Support, I have registered for a match on E SPORTS TOUR but need assistance with the Room ID / Password. My FF IGN: ${user.ffIgn}.`,
    'Withdrawal Payout': `Hello X SABBIR Support, I submitted a withdrawal request on E SPORTS TOUR for my account (${user.phone}). Could you please update me on the payout status?`,
    'General Inquiry': `Hello X SABBIR Support, I have a question regarding E SPORTS TOUR tournaments and rules.`
  };

  const messageText = prefilledMessages[selectedIssue];
  const encodedMessage = encodeURIComponent(messageText);
  // Official WhatsApp link format: https://wa.me/8801336161980
  const whatsappUrl = `https://wa.me/${APP_CONFIG.support.whatsappInternational}?text=${encodedMessage}`;
  const directBrowserUrl = `https://web.whatsapp.com/send?phone=${APP_CONFIG.support.whatsappInternational}&text=${encodedMessage}`;

  const copyNumber = () => {
    navigator.clipboard.writeText(APP_CONFIG.support.whatsappDisplay);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0e121a] border border-red-950/60 rounded-2xl shadow-2xl p-6 text-slate-100 overflow-hidden">
        {/* Glow Header */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-600 via-rose-500 to-amber-500" />
        
        {/* Close Button */}
        <button 
          onClick={() => setIsWhatsAppModalOpen(false)}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Content */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <MessageSquare className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-bold font-display text-white">
              {language === 'bn' ? 'হোয়াটসঅ্যাপ অফিশিয়াল সাপোর্ট' : 'Official WhatsApp Support'}
            </h3>
            <p className="text-xs text-slate-400">
              {APP_CONFIG.appName} · Developer: <span className="text-red-400 font-semibold">{APP_CONFIG.developerName}</span>
            </p>
          </div>
        </div>

        {/* Official Number Display */}
        <div className="bg-[#141923] border border-slate-800 rounded-xl p-4 mb-4">
          <div className="text-xs text-slate-400 mb-1">
            {language === 'bn' ? 'অফিশিয়াল হোয়াটসঅ্যাপ হেল্পলাইন নম্বর:' : 'Official WhatsApp Hotline Number:'}
          </div>
          <div className="flex items-center justify-between">
            <span className="text-2xl font-bold font-mono text-emerald-400 tracking-wider">
              {APP_CONFIG.support.whatsappDisplay}
            </span>
            <button
              onClick={copyNumber}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Number'}</span>
            </button>
          </div>
          <div className="mt-2 text-[11px] text-slate-500">
            International format: <span className="font-mono text-slate-400">+{APP_CONFIG.support.whatsappInternational}</span>
          </div>
        </div>

        {/* Choose Topic */}
        <div className="mb-4">
          <label className="block text-xs font-semibold text-slate-300 mb-2">
            {language === 'bn' ? 'সমস্যার ধরণ নির্বাচন করুন:' : 'Select Support Topic:'}
          </label>
          <div className="grid grid-cols-2 gap-2">
            {Object.keys(prefilledMessages).map((topic) => (
              <button
                key={topic}
                onClick={() => setSelectedIssue(topic)}
                className={`px-3 py-2 text-xs font-medium rounded-lg text-left transition-colors border ${
                  selectedIssue === topic 
                    ? 'bg-red-600/20 border-red-500 text-white' 
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {topic}
              </button>
            ))}
          </div>
        </div>

        {/* Message Preview */}
        <div className="bg-[#090b10] border border-slate-800 rounded-xl p-3 mb-5">
          <div className="text-[11px] font-semibold text-slate-400 mb-1">
            {language === 'bn' ? 'মেসেজ প্রিভিউ (আপনি নিজে রিভিউ করে সেন্ড করবেন):' : 'Message Preview (You will review & send on WhatsApp):'}
          </div>
          <p className="text-xs text-slate-300 font-mono italic bg-slate-900/60 p-2 rounded border border-slate-800/80">
            "{messageText}"
          </p>
          <p className="text-[10px] text-slate-500 mt-1">
            * Note: The link opens WhatsApp with this text pre-filled. You can edit it before hitting send.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2">
          {/* Working Primary Contact WhatsApp button */}
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full flex items-center justify-center gap-2 py-3.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-xl transition-transform active:scale-[0.99] shadow-lg shadow-emerald-950/40 text-sm"
          >
            <MessageSquare className="w-4 h-4 fill-current" />
            <span>{language === 'bn' ? 'হোয়াটসঅ্যাপে সাপোর্ট চ্যাট শুরু করুন' : 'Contact Support on WhatsApp'}</span>
            <ExternalLink className="w-3.5 h-3.5 opacity-80" />
          </a>

          {/* Browser Fallback Button */}
          <a
            href={directBrowserUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium rounded-xl text-xs transition-colors border border-slate-700"
          >
            <span>{language === 'bn' ? 'হোয়াটসঅ্যাপ ইনস্টল না থাকলে ব্রাউজারে খুলুন' : 'Open in Browser (if app is not installed)'}</span>
            <ExternalLink className="w-3 h-3 text-slate-400" />
          </a>
        </div>

        {/* Security badge */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-center gap-1.5 text-[11px] text-slate-400">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Verified developer support channel · Brand: {APP_CONFIG.developerName}</span>
        </div>
      </div>
    </div>
  );
};
