import { useRouter } from "@tanstack/react-router";
import { ChevronRight } from "lucide-react";

export function BackButton({ href }: { href?: string }) {
  const router = useRouter();
  return (
    <button
      type="button"
      className="tap-lg flex size-11 items-center justify-center rounded-full text-foreground hover:bg-surface"
      aria-label="رجوع"
      onClick={() => {
        if (href) router.navigate({ to: href });
        else if (window.history.length > 1) router.history.back();
        else router.navigate({ to: "/" });
      }}
    >
      <ChevronRight className="size-5" />
    </button>
  );
}
