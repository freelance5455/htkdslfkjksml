import { Play, RotateCcw } from "lucide-react";

type Props = {
  hasSave: boolean;
  onPlay: () => void;
  onFresh: () => void;
};

export function TitleScreen({ hasSave, onPlay, onFresh }: Props) {
  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-bg/80 px-6 text-center">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(125,206,196,0.08),transparent_55%)]" />
      <div className="relative max-w-xl">
        <p className="mb-3 text-xs font-medium tracking-[0.28em] text-accent uppercase">Independent grocer</p>
        <h1 className="font-display text-5xl leading-none tracking-tight text-fg text-balance sm:text-6xl">
          SUPER MARKET X
        </h1>
        <p className="mt-1 font-display text-xl tracking-[0.2em] text-muted">SIMULATOR</p>
        <p className="mx-auto mt-5 max-w-md text-sm leading-relaxed text-muted text-pretty">
          Stock the bays, run the till, hire a crew, and grow a corner grocery into a hypermarket.
        </p>
        <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
          <button
            type="button"
            onClick={onPlay}
            className="inline-flex h-12 min-w-[200px] items-center justify-center gap-2 rounded-xl bg-accent px-6 text-sm font-semibold text-accent-fg transition-transform duration-150 hover:brightness-110 active:scale-[0.98]"
          >
            <Play className="size-4" strokeWidth={2.2} />
            {hasSave ? "Continue" : "Open store"}
          </button>
          {hasSave ? (
            <button
              type="button"
              onClick={onFresh}
              className="inline-flex h-12 min-w-[160px] items-center justify-center gap-2 rounded-xl border border-border-strong bg-surface px-5 text-sm font-medium text-fg transition-transform duration-150 active:scale-[0.98]"
            >
              <RotateCcw className="size-4" />
              New game
            </button>
          ) : null}
        </div>
        <p className="mt-8 text-xs text-subtle">
          WASD move · mouse look · E interact · Shift sprint
        </p>
      </div>
    </div>
  );
}
