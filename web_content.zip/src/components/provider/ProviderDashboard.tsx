import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Power,
  MapPin,
  FileCheck2,
  DollarSign,
  Plus,
  CheckCircle2,
  XCircle,
  MessageSquare,
  Clock,
  Star,
  ShieldCheck,
  TrendingUp,
  Sliders,
  Upload,
  ArrowUpRight,
  Briefcase
} from 'lucide-react';
import { ServiceCategoryType, OrderStatus } from '../../types';

interface ProviderDashboardProps {
  onOpenChat: (sessionId: string) => void;
}

export const ProviderDashboard: React.FC<ProviderDashboardProps> = ({ onOpenChat }) => {
  const {
    currentProvider,
    toggleProviderAvailability,
    updateProviderRadius,
    uploadProviderDoc,
    orders,
    updateOrderStatus,
    addNewService,
    requestWithdrawal,
    chatSessions
  } = useApp();

  const [activeTab, setActiveTab] = useState<'jobs' | 'services' | 'earnings' | 'documents'>('jobs');

  // Add Service Form state
  const [showAddServiceModal, setShowAddServiceModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<ServiceCategoryType>('electrician');
  const [newPrice, setNewPrice] = useState<number>(450);
  const [newDuration, setNewDuration] = useState<number>(45);
  const [newDesc, setNewDesc] = useState('');

  // Withdrawal Form state
  const [showWithdrawalModal, setShowWithdrawalModal] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState<number>(1500);
  const [payoutMethod, setPayoutMethod] = useState<'upi' | 'bank'>('upi');
  const [payoutDetails, setPayoutDetails] = useState('rajesh.verma@okaxis');
  const [payoutSuccess, setPayoutSuccess] = useState(false);

  // File Upload state
  const [uploadDocType, setUploadDocType] = useState('Aadhaar Card');

  if (!currentProvider) return null;

  // Filter orders assigned or category-relevant to this provider
  const providerOrders = orders.filter(
    o => o.providerId === currentProvider.id || o.category === currentProvider.category
  );
  const activeOrders = providerOrders.filter(
    o => o.status !== 'completed' && o.status !== 'cancelled' && o.status !== 'refunded'
  );
  const completedOrders = providerOrders.filter(o => o.status === 'completed');

  const handleCreateService = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle) return;
    await addNewService({
      providerId: currentProvider.id,
      categoryId: newCategory,
      title: newTitle,
      description: newDesc || 'Professional doorstep service with genuine warranty.',
      price: newPrice,
      durationMinutes: newDuration,
      imageUrl:
        'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=800&auto=format&fit=crop&q=80'
    });
    setShowAddServiceModal(false);
    setNewTitle('');
    setNewDesc('');
  };

  const handleWithdrawalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await requestWithdrawal(withdrawAmount, payoutMethod, payoutDetails);
    setPayoutSuccess(true);
    setTimeout(() => {
      setPayoutSuccess(false);
      setShowWithdrawalModal(false);
    }, 1500);
  };

  const handleUploadSimulate = (docType: string) => {
    uploadProviderDoc(
      docType,
      `https://example.com/docs/${docType.toLowerCase().replace(' ', '_')}.pdf`
    );
  };

  return (
    <div className="pb-24">
      {/* Provider Header */}
      <div className="p-4 bg-slate-900 text-white space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src={currentProvider.avatar}
              alt={currentProvider.businessName}
              className="w-12 h-12 rounded-2xl object-cover border-2 border-amber-400"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm font-black text-white">{currentProvider.businessName}</h2>
                <span className="text-[10px] px-1.5 py-0.2 rounded-sm bg-blue-500/20 text-blue-300 font-bold border border-blue-400/30">
                  {currentProvider.kycStatus}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 capitalize">
                {currentProvider.category.replace('_', ' ')} Specialist • {currentProvider.city}
              </p>
            </div>
          </div>

          {/* Online / Offline Toggle */}
          <button
            id="provider-online-toggle"
            onClick={toggleProviderAvailability}
            className={`px-3 py-1.5 rounded-full text-xs font-black flex items-center gap-1.5 transition-all shadow-md ${
              currentProvider.isAvailable
                ? 'bg-emerald-500 text-slate-950 ring-4 ring-emerald-500/20'
                : 'bg-rose-900/60 text-rose-300 border border-rose-700'
            }`}
          >
            <Power className="w-3.5 h-3.5" />
            <span>{currentProvider.isAvailable ? 'ONLINE' : 'OFFLINE'}</span>
          </button>
        </div>

        {/* Coverage Slider */}
        <div className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-1.5 text-slate-300">
            <MapPin className="w-4 h-4 text-amber-400" />
            <span>Service Radius:</span>
            <b className="text-amber-400">{currentProvider.serviceRadiusKm} km</b>
          </div>

          <input
            type="range"
            min={2}
            max={30}
            step={1}
            value={currentProvider.serviceRadiusKm}
            onChange={e => updateProviderRadius(parseInt(e.target.value))}
            className="w-32 accent-amber-500 cursor-pointer"
          />
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="px-4 py-2.5 bg-white border-b border-slate-200 flex gap-2 overflow-x-auto no-scrollbar">
        {[
          { id: 'jobs', label: `Jobs (${activeOrders.length})` },
          { id: 'services', label: 'My Services' },
          { id: 'earnings', label: `Earnings (₹${currentProvider.earnings})` },
          { id: 'documents', label: 'KYC & ID' }
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as any)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
              activeTab === t.id
                ? 'bg-amber-500 text-slate-950 shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* TAB CONTENT */}
      <div className="p-4">
        {/* 1. JOBS TAB */}
        {activeTab === 'jobs' && (
          <div className="space-y-3">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-500">
              Customer Bookings & Requests
            </h3>

            {providerOrders.length === 0 ? (
              <div className="py-12 text-center bg-white rounded-2xl border border-slate-200 p-6">
                <Clock className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <p className="text-xs font-bold text-slate-700">No current booking requests</p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Keep status 'ONLINE' to receive instant nearby leads.
                </p>
              </div>
            ) : (
              providerOrders.map(order => {
                const linkedChat = chatSessions.find(s => s.orderId === order.id);
                return (
                  <div
                    key={order.id}
                    className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] uppercase font-bold text-slate-400">
                        #{order.orderNumber} • {order.scheduledSlot || 'Immediate'}
                      </span>
                      <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                        {order.status.replace('_', ' ')}
                      </span>
                    </div>

                    <div>
                      <h4 className="text-xs font-black text-slate-900">
                        {order.items.map(i => `${i.quantity}x ${i.title}`).join(', ')}
                      </h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Address: {order.deliveryAddress?.street || 'Customer Location'},{' '}
                        {order.deliveryAddress?.locality}
                      </p>
                    </div>

                    <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-xs">
                      <span className="font-bold text-slate-900">
                        Payout: <b className="text-emerald-700">₹{order.grandTotal}</b>
                      </span>

                      <div className="flex items-center gap-2">
                        {linkedChat && (
                          <button
                            onClick={() => onOpenChat(linkedChat.id)}
                            className="p-1.5 rounded-lg bg-amber-50 text-amber-700 border border-amber-200 flex items-center gap-1 text-[11px] font-bold"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>Chat</span>
                          </button>
                        )}

                        {order.status === 'placed' && (
                          <>
                            <button
                              onClick={() => updateOrderStatus(order.id, 'cancelled')}
                              className="px-2 py-1 rounded-lg bg-rose-50 text-rose-700 text-xs font-bold"
                            >
                              Reject
                            </button>
                            <button
                              onClick={() => updateOrderStatus(order.id, 'accepted')}
                              className="px-3 py-1 rounded-lg bg-emerald-600 text-white text-xs font-bold shadow-xs"
                            >
                              Accept Lead
                            </button>
                          </>
                        )}

                        {order.status === 'accepted' && (
                          <button
                            onClick={() => updateOrderStatus(order.id, 'in_progress')}
                            className="px-3 py-1 rounded-lg bg-blue-600 text-white text-xs font-bold"
                          >
                            Start Job
                          </button>
                        )}

                        {order.status === 'in_progress' && (
                          <button
                            onClick={() => updateOrderStatus(order.id, 'completed')}
                            className="px-3 py-1 rounded-lg bg-emerald-600 text-white text-xs font-bold"
                          >
                            Complete Job
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}

        {/* 2. SERVICES TAB (Add custom services with pricing & description) */}
        {activeTab === 'services' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-black uppercase tracking-wider text-slate-500">
                Custom Services Offered
              </h3>
              <button
                id="add-custom-service-btn"
                onClick={() => setShowAddServiceModal(true)}
                className="px-3 py-1.5 bg-amber-500 text-slate-950 rounded-xl text-xs font-black flex items-center gap-1 shadow-sm"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Service</span>
              </button>
            </div>

            <div className="space-y-2">
              {currentProvider.customServices?.map(s => (
                <div
                  key={s.id}
                  className="p-3 bg-white rounded-2xl border border-slate-200 flex items-center justify-between gap-3"
                >
                  <div className="flex-1">
                    <h4 className="text-xs font-bold text-slate-900">{s.title}</h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">{s.description}</p>
                    <div className="flex items-center gap-3 mt-1.5 text-xs">
                      <span className="font-black text-slate-900">₹{s.price}</span>
                      <span className="text-slate-400">{s.durationMinutes} mins</span>
                    </div>
                  </div>

                  <img
                    src={s.imageUrl}
                    alt={s.title}
                    className="w-16 h-16 rounded-xl object-cover shrink-0"
                  />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 3. EARNINGS & WITHDRAWAL TAB */}
        {activeTab === 'earnings' && (
          <div className="space-y-3">
            <div className="p-4 bg-gradient-to-r from-emerald-600 to-teal-700 text-white rounded-3xl shadow-lg">
              <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-200 block">
                Total Available Earnings
              </span>
              <div className="flex items-baseline justify-between mt-1">
                <h3 className="text-3xl font-black">₹{currentProvider.earnings}</h3>
                <span className="text-xs text-emerald-200 font-semibold">
                  {completedOrders.length} Completed Jobs
                </span>
              </div>

              <button
                id="request-withdrawal-btn"
                onClick={() => setShowWithdrawalModal(true)}
                className="mt-3 w-full py-2.5 rounded-xl bg-white text-emerald-900 font-black text-xs shadow-md hover:bg-emerald-50 active:scale-98 transition-all flex items-center justify-center gap-1.5"
              >
                <ArrowUpRight className="w-4 h-4 text-emerald-700" />
                <span>Request Payout Withdrawal</span>
              </button>
            </div>

            {/* Performance Stats */}
            <div className="grid grid-cols-3 gap-2">
              <div className="p-3 bg-white rounded-2xl border border-slate-200 text-center">
                <Star className="w-4 h-4 text-amber-500 mx-auto mb-1 fill-amber-400" />
                <p className="text-xs font-black text-slate-900">{currentProvider.rating}</p>
                <p className="text-[9px] text-slate-400">Rating ({currentProvider.reviewCount})</p>
              </div>

              <div className="p-3 bg-white rounded-2xl border border-slate-200 text-center">
                <Briefcase className="w-4 h-4 text-blue-500 mx-auto mb-1" />
                <p className="text-xs font-black text-slate-900">
                  {currentProvider.experienceYears} Yrs
                </p>
                <p className="text-[9px] text-slate-400">Experience</p>
              </div>

              <div className="p-3 bg-white rounded-2xl border border-slate-200 text-center">
                <ShieldCheck className="w-4 h-4 text-emerald-500 mx-auto mb-1" />
                <p className="text-xs font-black text-slate-900">Verified</p>
                <p className="text-[9px] text-slate-400">Background Checked</p>
              </div>
            </div>
          </div>
        )}

        {/* 4. DOCUMENTS & KYC TAB */}
        {activeTab === 'documents' && (
          <div className="space-y-3">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-500">
              Identity Verification & Licenses
            </h3>

            <div className="space-y-2">
              {currentProvider.documents.map(doc => (
                <div
                  key={doc.id}
                  className="p-3 bg-white rounded-2xl border border-slate-200 flex items-center justify-between"
                >
                  <div className="flex items-center gap-2.5">
                    <FileCheck2 className="w-5 h-5 text-amber-600" />
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">{doc.type}</h4>
                      <p className="text-[10px] text-slate-400">
                        Uploaded: {new Date(doc.uploadedAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  <span
                    className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase ${
                      doc.status === 'verified'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {doc.status}
                  </span>
                </div>
              ))}
            </div>

            {/* Upload Document Box */}
            <div className="p-4 bg-amber-50/50 rounded-2xl border border-dashed border-amber-300 text-center space-y-2">
              <Upload className="w-6 h-6 text-amber-600 mx-auto" />
              <p className="text-xs font-bold text-slate-900">Upload New Document / License</p>

              <div className="flex justify-center gap-2">
                {['Trade License', 'Police Clearance', 'Driving License'].map(docName => (
                  <button
                    key={docName}
                    onClick={() => handleUploadSimulate(docName)}
                    className="px-2.5 py-1 bg-white border border-amber-300 text-amber-800 rounded-lg text-[10px] font-bold hover:bg-amber-100 active:scale-95"
                  >
                    + {docName}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Add Custom Service Modal */}
      {showAddServiceModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleCreateService}
            className="bg-white rounded-3xl p-5 max-w-sm w-full space-y-3 shadow-2xl"
          >
            <h3 className="text-sm font-black text-slate-900">Add Custom Service</h3>

            <div>
              <label className="text-[11px] font-bold text-slate-600 block mb-1">Service Title</label>
              <input
                type="text"
                value={newTitle}
                onChange={e => setNewTitle(e.target.value)}
                placeholder="e.g. Inverter Wiring & Battery Setup"
                required
                className="w-full p-2 text-xs rounded-xl border border-slate-200"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[11px] font-bold text-slate-600 block mb-1">Price (₹)</label>
                <input
                  type="number"
                  value={newPrice}
                  onChange={e => setNewPrice(parseInt(e.target.value))}
                  required
                  className="w-full p-2 text-xs rounded-xl border border-slate-200"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold text-slate-600 block mb-1">Duration (Mins)</label>
                <input
                  type="number"
                  value={newDuration}
                  onChange={e => setNewDuration(parseInt(e.target.value))}
                  required
                  className="w-full p-2 text-xs rounded-xl border border-slate-200"
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-600 block mb-1">Description</label>
              <textarea
                rows={2}
                value={newDesc}
                onChange={e => setNewDesc(e.target.value)}
                placeholder="Scope of work, inclusions, warranty..."
                className="w-full p-2 text-xs rounded-xl border border-slate-200"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddServiceModal(false)}
                className="flex-1 py-2 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs shadow-md"
              >
                Add to My Catalog
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Withdrawal Modal */}
      {showWithdrawalModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleWithdrawalSubmit}
            className="bg-white rounded-3xl p-5 max-w-sm w-full space-y-3 shadow-2xl"
          >
            <h3 className="text-sm font-black text-slate-900">Request Earnings Withdrawal</h3>

            {payoutSuccess ? (
              <div className="py-6 text-center">
                <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
                <p className="text-xs font-bold text-slate-900">
                  Withdrawal request of ₹{withdrawAmount} submitted!
                </p>
                <p className="text-[10px] text-slate-500">Sent to admin for instant approval.</p>
              </div>
            ) : (
              <>
                <div>
                  <label className="text-[11px] font-bold text-slate-600 block mb-1">
                    Withdrawal Amount (Max ₹{currentProvider.earnings})
                  </label>
                  <input
                    type="number"
                    max={currentProvider.earnings}
                    min={100}
                    value={withdrawAmount}
                    onChange={e => setWithdrawAmount(parseInt(e.target.value))}
                    required
                    className="w-full p-2 text-xs rounded-xl border border-slate-200"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-600 block mb-1">Payout Channel</label>
                  <div className="flex gap-2 mb-2">
                    <button
                      type="button"
                      onClick={() => setPayoutMethod('upi')}
                      className={`flex-1 py-1.5 rounded-xl text-xs font-bold border ${
                        payoutMethod === 'upi' ? 'bg-amber-500 text-slate-950 border-amber-600' : 'bg-slate-50'
                      }`}
                    >
                      UPI ID
                    </button>
                    <button
                      type="button"
                      onClick={() => setPayoutMethod('bank')}
                      className={`flex-1 py-1.5 rounded-xl text-xs font-bold border ${
                        payoutMethod === 'bank' ? 'bg-amber-500 text-slate-950 border-amber-600' : 'bg-slate-50'
                      }`}
                    >
                      Bank Transfer
                    </button>
                  </div>

                  <input
                    type="text"
                    value={payoutDetails}
                    onChange={e => setPayoutDetails(e.target.value)}
                    placeholder={payoutMethod === 'upi' ? 'name@okhdfcbank' : 'A/C No. & IFSC'}
                    required
                    className="w-full p-2 text-xs rounded-xl border border-slate-200"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowWithdrawalModal(false)}
                    className="flex-1 py-2 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs shadow-md"
                  >
                    Submit Request
                  </button>
                </div>
              </>
            )}
          </form>
        </div>
      )}
    </div>
  );
};
