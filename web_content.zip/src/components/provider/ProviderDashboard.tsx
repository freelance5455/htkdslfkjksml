import React, { useState } from 'react';
import { useMohalla } from '../../context/MohallaContext';
import {
  Wrench,
  Clock,
  CheckCircle2,
  XCircle,
  Phone,
  MessageSquare,
  DollarSign,
  TrendingUp,
  ShieldCheck,
  MapPin,
  Calendar,
  AlertTriangle,
  FileCheck,
  Check,
  ChevronRight,
  User,
} from 'lucide-react';
import { formatCurrencyPKR } from '../../utils/geo';
import { Booking } from '../../types';

interface ProviderDashboardProps {
  onOpenChat: (bookingId: string) => void;
}

export const ProviderDashboard: React.FC<ProviderDashboardProps> = ({ onOpenChat }) => {
  const {
    providers,
    bookings,
    updateBookingStatus,
    toggleProviderAvailability,
    settings,
  } = useMohalla();

  // Active provider (Ali Electrician prov_1)
  const currentProvider = providers.find((p) => p.id === 'prov_1') || providers[0];

  const [completingBooking, setCompletingBooking] = useState<Booking | null>(null);
  const [additionalCharges, setAdditionalCharges] = useState<number>(0);
  const [partsNote, setPartsNote] = useState('');

  // Provider's bookings
  const providerBookings = bookings.filter((b) => b.providerId === currentProvider.id);
  const pendingRequests = providerBookings.filter((b) => b.status === 'PENDING');
  const activeJobs = providerBookings.filter((b) =>
    ['ACCEPTED', 'ARRIVING', 'IN_PROGRESS'].includes(b.status)
  );
  const completedJobs = providerBookings.filter((b) => b.status === 'COMPLETED');

  // Compute financial earnings
  const grossEarnings = completedJobs.reduce(
    (sum, b) => sum + (b.finalBill || b.visitFee || 0),
    0
  );
  const commissionPercentage = settings.commissionPercentage;
  const platformCommissionTotal = Math.round(grossEarnings * (commissionPercentage / 100));
  const netEarnings = grossEarnings - platformCommissionTotal;

  const handleAcceptJob = (bookingId: string) => {
    updateBookingStatus(bookingId, 'ACCEPTED', 'Accepted by provider. Preparing tools.');
  };

  const handleDeclineJob = (bookingId: string) => {
    updateBookingStatus(bookingId, 'REJECTED', 'Provider currently unable to take job.');
  };

  const handleMarkArriving = (bookingId: string) => {
    updateBookingStatus(bookingId, 'ARRIVING', 'Provider is en route to customer location.');
  };

  const handleStartWork = (bookingId: string) => {
    updateBookingStatus(bookingId, 'IN_PROGRESS', 'Work initiated on site.');
  };

  const handleConfirmCompletion = () => {
    if (!completingBooking) return;
    const finalBill = completingBooking.visitFee + Number(additionalCharges || 0);

    updateBookingStatus(
      completingBooking.id,
      'COMPLETED',
      `Job completed. Additional parts: ${partsNote || 'None'}`,
      {
        additionalCharges: Number(additionalCharges || 0),
        finalBill,
        paymentStatus: 'paid',
      }
    );
    setCompletingBooking(null);
    setAdditionalCharges(0);
    setPartsNote('');
  };

  return (
    <div className="space-y-6">
      {/* Provider Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-teal-950 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 font-black flex items-center justify-center text-2xl shadow-lg">
            {currentProvider.businessName.charAt(0)}
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl font-bold">{currentProvider.businessName}</h1>
              <span className="px-2 py-0.5 rounded-md text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                {currentProvider.verificationBadge}
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1">
              {currentProvider.city} • {currentProvider.serviceAreas.join(', ')} • Base Visit:{' '}
              {formatCurrencyPKR(currentProvider.visitCharge)}
            </p>
          </div>
        </div>

        {/* Available Now Toggle Switch */}
        <div className="flex items-center gap-3 bg-white/10 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/15">
          <div>
            <div className="text-xs font-bold flex items-center gap-1.5">
              <span
                className={`w-2.5 h-2.5 rounded-full ${
                  currentProvider.isAvailableNow ? 'bg-emerald-400 animate-ping' : 'bg-slate-400'
                }`}
              />
              <span>{currentProvider.isAvailableNow ? 'Available Now' : 'Busy / Off Duty'}</span>
            </div>
            <p className="text-[10px] text-slate-300">
              {currentProvider.isAvailableNow
                ? 'Appearing in urgent searches'
                : 'Hidden from live requests'}
            </p>
          </div>

          <button
            onClick={() => toggleProviderAvailability(currentProvider.id)}
            className={`w-14 h-8 rounded-full p-1 transition-colors cursor-pointer relative ${
              currentProvider.isAvailableNow ? 'bg-emerald-500' : 'bg-slate-600'
            }`}
          >
            <div
              className={`w-6 h-6 rounded-full bg-white transition-transform ${
                currentProvider.isAvailableNow ? 'translate-x-6' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Net Take-Home</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-extrabold text-slate-900">
            {formatCurrencyPKR(netEarnings)}
          </div>
          <span className="text-[11px] text-emerald-700 font-medium mt-0.5 block">
            After {commissionPercentage}% platform fee
          </span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Gross Revenue</span>
            <TrendingUp className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-xl font-extrabold text-slate-900">
            {formatCurrencyPKR(grossEarnings)}
          </div>
          <span className="text-[11px] text-slate-500 font-medium mt-0.5 block">
            Comm: {formatCurrencyPKR(platformCommissionTotal)}
          </span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Completed Jobs</span>
            <CheckCircle2 className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-xl font-extrabold text-slate-900">
            {currentProvider.completedJobs}
          </div>
          <span className="text-[11px] text-slate-500 font-medium mt-0.5 block">
            ⭐ {currentProvider.rating.toFixed(1)} rating ({currentProvider.reviewCount} reviews)
          </span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-1">
            <span>Trust Score</span>
            <ShieldCheck className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-xl font-extrabold text-amber-700">
            {currentProvider.trustScore} / 100
          </div>
          <span className="text-[11px] text-slate-500 font-medium mt-0.5 block">
            {currentProvider.onTimePercentage}% on-time arrival
          </span>
        </div>
      </div>

      {/* Pending Job Requests Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <span>Pending Customer Requests</span>
            <span className="text-xs bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded-full">
              {pendingRequests.length}
            </span>
          </h2>
          <span className="text-xs text-slate-400">Respond quickly to maintain high Trust Score</span>
        </div>

        {pendingRequests.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-2xl border border-slate-200 text-slate-400 text-xs">
            <Clock className="w-8 h-8 text-slate-300 mx-auto mb-1.5" />
            No new incoming booking requests at this moment. Keep "Available Now" ON to receive nearby calls!
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {pendingRequests.map((req) => (
              <div
                key={req.id}
                className="bg-white rounded-2xl border-2 border-amber-300 p-5 shadow-sm space-y-3 relative overflow-hidden"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-md inline-block mb-1">
                      New Booking Request
                    </span>
                    <h3 className="font-bold text-sm text-slate-900">{req.customerName}</h3>
                    <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                      {req.location.area} ({req.location.address})
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-base font-extrabold text-emerald-800 block">
                      {formatCurrencyPKR(req.visitFee)}
                    </span>
                    <span className="text-[10px] text-slate-400">Visit charge</span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs">
                  <span className="font-bold text-slate-400 uppercase text-[10px] block">Problem:</span>
                  <p className="text-slate-800 font-medium mt-0.5">"{req.problemDescription}"</p>
                  <p className="text-slate-500 mt-1 font-semibold">⏰ {req.preferredTime}</p>
                </div>

                <div className="flex gap-2 pt-1">
                  <button
                    onClick={() => handleDeclineJob(req.id)}
                    className="flex-1 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50 cursor-pointer"
                  >
                    Decline
                  </button>
                  <button
                    onClick={() => handleAcceptJob(req.id)}
                    className="flex-2 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-sm cursor-pointer hover:scale-[1.02] transition-all"
                  >
                    Accept Job
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Active Jobs in Progress */}
      <div className="space-y-3">
        <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
          <span>Active Jobs in Progress</span>
          <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
            {activeJobs.length}
          </span>
        </h2>

        {activeJobs.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-2xl border border-slate-200 text-slate-400 text-xs">
            No jobs currently in progress.
          </div>
        ) : (
          <div className="space-y-3">
            {activeJobs.map((job) => (
              <div
                key={job.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 text-sm">{job.customerName}</span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800">
                        {job.status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      📍 {job.location.address} • Phone: {job.customerPhone}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onOpenChat(job.id)}
                      className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                      Chat
                    </button>
                    <a
                      href={`tel:${job.customerPhone}`}
                      className="px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold flex items-center gap-1"
                    >
                      <Phone className="w-3.5 h-3.5 text-slate-500" />
                      Call Customer
                    </a>
                  </div>
                </div>

                <div className="text-xs text-slate-700">
                  <span className="font-bold text-slate-400 uppercase text-[10px] block">Problem:</span>
                  <p className="mt-0.5 font-medium">"{job.problemDescription}"</p>
                </div>

                {/* Status action transitions */}
                <div className="pt-2 flex flex-wrap items-center justify-end gap-2">
                  {job.status === 'ACCEPTED' && (
                    <button
                      onClick={() => handleMarkArriving(job.id)}
                      className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold cursor-pointer shadow-xs"
                    >
                      Mark as Arriving (On the Way)
                    </button>
                  )}

                  {job.status === 'ARRIVING' && (
                    <button
                      onClick={() => handleStartWork(job.id)}
                      className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold cursor-pointer shadow-xs"
                    >
                      Start Work on Site
                    </button>
                  )}

                  {job.status === 'IN_PROGRESS' && (
                    <button
                      onClick={() => setCompletingBooking(job)}
                      className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold cursor-pointer shadow-sm"
                    >
                      Complete Work & Settle Cash
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Completion & Final Bill Settlement Modal */}
      {completingBooking && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <h3 className="font-bold text-slate-900 text-base">Complete Job & Final Bill</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Customer: {completingBooking.customerName}
            </p>

            <div className="mt-4 space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                <span className="text-slate-600 font-medium">Base Visit Charge</span>
                <span className="font-bold text-slate-900">
                  {formatCurrencyPKR(completingBooking.visitFee)}
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Additional Spare Parts / Extra Work (PKR)
                </label>
                <input
                  type="number"
                  min="0"
                  step="50"
                  value={additionalCharges}
                  onChange={(e) => setAdditionalCharges(Number(e.target.value))}
                  placeholder="0"
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-xs font-bold text-slate-800"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Parts Description / Note
                </label>
                <input
                  type="text"
                  value={partsNote}
                  onChange={(e) => setPartsNote(e.target.value)}
                  placeholder="e.g. 1x 32A Breaker, 10 yards 7/29 copper cable"
                  className="w-full p-2.5 rounded-xl border border-slate-300 text-xs text-slate-800"
                />
              </div>

              {/* Commission breakdown */}
              <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-1">
                <div className="flex justify-between font-bold text-slate-900">
                  <span>Total Amount Due:</span>
                  <span>
                    {formatCurrencyPKR(
                      completingBooking.visitFee + Number(additionalCharges || 0)
                    )}
                  </span>
                </div>
                <div className="flex justify-between text-slate-600 text-[11px]">
                  <span>Mohalla Platform Fee ({commissionPercentage}%):</span>
                  <span>
                    -{' '}
                    {formatCurrencyPKR(
                      Math.round(
                        (completingBooking.visitFee + Number(additionalCharges || 0)) *
                          (commissionPercentage / 100)
                      )
                    )}
                  </span>
                </div>
                <div className="flex justify-between text-emerald-900 font-black text-sm pt-1 border-t border-emerald-200">
                  <span>Your Net Earning:</span>
                  <span>
                    {formatCurrencyPKR(
                      (completingBooking.visitFee + Number(additionalCharges || 0)) -
                        Math.round(
                          (completingBooking.visitFee + Number(additionalCharges || 0)) *
                            (commissionPercentage / 100)
                        )
                    )}
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-5 flex gap-2">
              <button
                onClick={() => setCompletingBooking(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmCompletion}
                className="flex-1 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold cursor-pointer"
              >
                Confirm Cash Collected & Complete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
