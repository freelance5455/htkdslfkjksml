import React, { useState, useEffect } from 'react';
import {
  AppSettings,
  ThemeMode,
  ThemeAccent,
  AppFontFamily,
  AppFontSize,
  AppFontWeight,
  Transaction,
  Category,
  SecuritySettings,
  UserProfile,
  Account,
  AuditHistoryLog,
} from '../../types';
import {
  Settings,
  Palette,
  Type,
  Languages,
  ShieldCheck,
  FolderPlus,
  FileDown,
  AlertTriangle,
  ChevronRight,
  ChevronDown,
  X,
  Sun,
  Moon,
  Sparkles,
  Check,
  ArrowLeftRight,
  RotateCcw,
  Globe2,
  Binary,
  DollarSign,
  Eye,
  Lock,
  HardDrive,
  FolderSync,
  Cloud,
  Trash2,
  Layers,
  CheckCircle2,
  Sliders,
  Search,
  User,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ExportReportModal } from '../ExportReportModal';
import { SecurityPopupMenuModal, SecurityPopupTab } from '../SecurityAndBackup/SecurityPopupMenuModal';
import { UserProfileModal } from '../UserProfileModal';
import { storage } from '../../utils/storage';
import {
  getDualAccentInfo,
  PRIMARY_ACCENT_COLORS,
  getAccentConfig,
  hexToHsl,
  hslToHex,
  getHueColorName,
} from '../../utils/theme';
import { formatCurrency, toBanglaDigits } from '../../utils/formatters';

interface SettingsViewProps {
  appSettings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  onResetAllData?: () => void;
  onOpenManageCategories?: () => void;
  onNavigateToSecurity?: () => void;
  onNavigateToTheme?: () => void;
  onNavigateToLanguage?: () => void;
  transactions?: Transaction[];
  categories?: Category[];
  securitySettings?: SecuritySettings;
  onUpdateSecurity?: (newSecurity: SecuritySettings) => void;
  onLockNow?: () => void;
  onAddCategory?: (newCat: Omit<Category, 'id'>) => void;
  onDeleteCategory?: (id: string) => void;
  onDataImported?: () => void;
  userProfile?: UserProfile;
  onSaveUserProfile?: (profile: UserProfile) => void;
  accounts?: Account[];
  onSaveOpeningBalances?: (accounts: Account[]) => void;
  auditLogs?: AuditHistoryLog[];
  onClearHistory?: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  appSettings,
  onUpdateSettings,
  onResetAllData,
  onOpenManageCategories,
  onNavigateToSecurity,
  onNavigateToTheme,
  onNavigateToLanguage,
  transactions,
  categories,
  securitySettings,
  onUpdateSecurity,
  onLockNow,
  onDataImported,
  userProfile,
  onSaveUserProfile,
  accounts,
  onSaveOpeningBalances,
  auditLogs,
  onClearHistory,
}) => {
  const isLight = appSettings.themeMode === 'light';
  const isEn = appSettings.language === 'en';

  // Fallbacks for data
  const activeTransactions = transactions || storage.getTransactions();
  const activeCategories = categories || storage.getCategories();
  const activeSecurity = securitySettings || storage.getSecuritySettings();
  const activeUserProfile = userProfile || storage.getUserProfile();
  const activeAccounts = accounts || storage.getAccounts();
  const activeAuditLogs = auditLogs || storage.getAuditLogs();

  // Modal Open States (Popups)
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isThemeModalOpen, setIsThemeModalOpen] = useState(false);
  const [themeModalTab, setThemeModalTab] = useState<'theme_color' | 'font'>('theme_color');
  const [isFontDropdownOpen, setIsFontDropdownOpen] = useState(false);
  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);
  const [isSecurityModalOpen, setIsSecurityModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);

  // Search in settings state
  const [searchQuery, setSearchQuery] = useState('');

  // Security popup tab
  const [securityModalInitialTab, setSecurityModalInitialTab] = useState<SecurityPopupTab>('app_lock');

  // Cloud drive sync state for Security popup
  const [isSyncingDrive, setIsSyncingDrive] = useState(false);
  const [syncStatusMsg, setSyncStatusMsg] = useState('');

  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );

  // Colors & styling
  const cardBg = isLight
    ? 'bg-white/95 border-slate-200/90 shadow-xs hover:border-slate-300'
    : 'bg-slate-800/90 border-slate-700/60 shadow-md hover:border-slate-600';
  const headingText = isLight ? 'text-slate-900' : 'text-slate-100';
  const subText = isLight ? 'text-slate-500' : 'text-slate-400';
  const modalBg = isLight ? 'bg-white text-slate-900 border-slate-200' : 'bg-slate-900 text-slate-100 border-slate-700';
  const modalInnerBg = isLight ? 'bg-slate-50/80 border-slate-200/70' : 'bg-slate-800/80 border-slate-700/60';

  // Accent Color Palette
  const ACCENT_OPTIONS: { id: ThemeAccent; nameEn: string; nameBn: string; hex: string }[] = [
    { id: 'green', nameEn: 'Green', nameBn: 'সবুজ', hex: '#5db962' },
    { id: 'teal', nameEn: 'Teal', nameBn: 'টিয়াল', hex: '#1ea896' },
    { id: 'cyan', nameEn: 'Cyan', nameBn: 'আকাশি', hex: '#20c1e8' },
    { id: 'blue', nameEn: 'Blue', nameBn: 'নীল', hex: '#3b96f6' },
    { id: 'navy', nameEn: 'Royal Blue', nameBn: 'রয়েল ব্লু', hex: '#3950ba' },
    { id: 'purple', nameEn: 'Purple', nameBn: 'বেগুনি', hex: '#7c3aed' },
    { id: 'pink', nameEn: 'Pink', nameBn: 'গোলাপি', hex: '#ec4899' },
    { id: 'rose', nameEn: 'Rose', nameBn: 'গোলাপ', hex: '#f43f5e' },
    { id: 'orange', nameEn: 'Orange', nameBn: 'কমলা', hex: '#f97316' },
    { id: 'amber', nameEn: 'Amber', nameBn: 'হলুদ', hex: '#eab308' },
    { id: 'emerald', nameEn: 'Emerald', nameBn: 'এমারেল্ড', hex: '#10b981' },
  ];

  // Theme Accent Customizer State
  const [activeThemeColorTarget, setActiveThemeColorTarget] = useState<'primary' | 'secondary'>('primary');

  const activePrimaryConfig = getAccentConfig(appSettings.themeAccent);
  const activeSecondaryConfig = getAccentConfig(appSettings.secondaryAccent || 'cyan');
  const currentTargetConfig = activeThemeColorTarget === 'primary' ? activePrimaryConfig : activeSecondaryConfig;
  const currentHex = currentTargetConfig.hex;

  const currentHsl = hexToHsl(currentHex);
  const [themeHue, setThemeHue] = useState<number>(currentHsl.h);
  const [themeLightness, setThemeLightness] = useState<number>(currentHsl.l);

  useEffect(() => {
    const updatedHsl = hexToHsl(currentHex);
    setThemeHue(updatedHsl.h);
    setThemeLightness(updatedHsl.l);
  }, [currentHex, activeThemeColorTarget]);

  const handleColorChange = (newHex: string) => {
    if (activeThemeColorTarget === 'primary') {
      onUpdateSettings({ ...appSettings, themeAccent: newHex });
    } else {
      onUpdateSettings({ ...appSettings, secondaryAccent: newHex });
    }
  };

  const handleHueChange = (newHue: number) => {
    setThemeHue(newHue);
    const newHex = hslToHex(newHue, 85, themeLightness);
    handleColorChange(newHex);
  };

  const handleLightnessChange = (newL: number) => {
    setThemeLightness(newL);
    const newHex = hslToHex(themeHue, 85, newL);
    handleColorChange(newHex);
  };

  const handleSwapColors = () => {
    onUpdateSettings({
      ...appSettings,
      themeAccent: appSettings.secondaryAccent || 'cyan',
      secondaryAccent: appSettings.themeAccent,
    });
  };

  const currentHueName = getHueColorName(themeHue);

  const CURRENCY_OPTIONS = [
    { symbol: '৳', code: 'BDT', nameEn: 'Bangladeshi Taka', nameBn: 'বাংলাদেশী টাকা' },
    { symbol: '$', code: 'USD', nameEn: 'US Dollar', nameBn: 'মার্কিন ডলার' },
    { symbol: '€', code: 'EUR', nameEn: 'Euro', nameBn: 'ইউরো' },
    { symbol: '₹', code: 'INR', nameEn: 'Indian Rupee', nameBn: 'ভারতীয় রুপি' },
    { symbol: '£', code: 'GBP', nameEn: 'British Pound', nameBn: 'ব্রিটিশ পাউন্ড' },
    { symbol: '﷼', code: 'SAR', nameEn: 'Saudi Riyal', nameBn: 'সৌদি রিয়াল' },
    { symbol: 'AED', code: 'AED', nameEn: 'UAE Dirham', nameBn: 'ইউনাইটেড আরব আমিরাত দিরহাম' },
    { symbol: 'RM', code: 'MYR', nameEn: 'Malaysian Ringgit', nameBn: 'মালয়েশিয়ান রিঙ্গিত' },
    { symbol: 'C$', code: 'CAD', nameEn: 'Canadian Dollar', nameBn: 'কানাডিয়ান ডলার' },
  ];

  // Font Settings Options (English & Bengali Fonts)
  const FONT_FAMILY_OPTIONS: {
    id: AppFontFamily;
    nameEn: string;
    nameBn: string;
    descEn: string;
    descBn: string;
    sample: string;
    fontClass: string;
    category: 'en' | 'bn';
  }[] = [
    // English & Modern Fonts
    {
      id: 'inter',
      nameEn: 'Inter (Modern UI)',
      nameBn: 'ইন্টার (Inter - আধুনিক ও স্পষ্ট)',
      descEn: 'The modern gold standard for web & fintech UI',
      descBn: 'আধুনিক ওয়েব ও অ্যাপের সবচেয়ে নিখুঁত ফন্ট',
      sample: 'Onu Finance • 12,450 ৳ (Aa Bb Gg 123)',
      fontClass: 'font-inter',
      category: 'en',
    },
    {
      id: 'poppins',
      nameEn: 'Poppins (Geometric)',
      nameBn: 'পপিন্স (Poppins - সুন্দর ও ফ্রেন্ডলি)',
      descEn: 'Friendly, geometric, and rounded typography',
      descBn: 'রাউন্ডেড ও রুচিশীল জ্যামিতিক ফন্ট',
      sample: 'Onu Finance • 12,450 ৳ (Aa Bb Gg 123)',
      fontClass: 'font-poppins',
      category: 'en',
    },
    {
      id: 'jakarta',
      nameEn: 'Plus Jakarta Sans',
      nameBn: 'প্লাস জাকার্তা সান্স (Plus Jakarta)',
      descEn: 'Premium fintech typography for dashboard clarity',
      descBn: 'প্রিমিয়াম আর্থিক হিসাব ও প্রফেশনাল লুক',
      sample: 'Onu Finance • 12,450 ৳ (Aa Bb Gg 123)',
      fontClass: 'font-jakarta',
      category: 'en',
    },
    {
      id: 'roboto',
      nameEn: 'Roboto (Google Classic)',
      nameBn: 'রোবোটো (Roboto - গুগল ক্লাসিক)',
      descEn: 'Google standard mechanical skeleton sans',
      descBn: 'গুগলের নির্ভরযোগ্য ও নিখুঁত ফন্ট',
      sample: 'Onu Finance • 12,450 ৳ (Aa Bb Gg 123)',
      fontClass: 'font-roboto',
      category: 'en',
    },
    {
      id: 'playfair',
      nameEn: 'Playfair Display (Serif)',
      nameBn: 'প্লেফেয়ার ডিসপ্লে (Playfair - ক্লাসিক সেরিফ)',
      descEn: 'High-contrast editorial serif for luxury aesthetic',
      descBn: 'মার্জিত, আভিজাত্যপূর্ণ ও স্টাইলিশ সেরিফ',
      sample: 'Onu Finance • 12,450 ৳ (Aa Bb Gg 123)',
      fontClass: 'font-playfair',
      category: 'en',
    },
    {
      id: 'montserrat',
      nameEn: 'Montserrat (Modern Bold)',
      nameBn: 'মন্টসেরাট (Montserrat - বোল্ড ও আধুনিক)',
      descEn: 'Popular geometric sans with modern urban flair',
      descBn: 'আন্তর্জাতিকভাবে অত্যন্ত জনপ্রিয় আধুনিক জ্যামিতিক ফন্ট',
      sample: 'Onu Finance • 12,450 ৳ (Aa Bb Gg 123)',
      fontClass: 'font-montserrat',
      category: 'en',
    },
    {
      id: 'lato',
      nameEn: 'Lato (Warm & Professional)',
      nameBn: 'লাতো (Lato - পেশাদার ও মার্জিত)',
      descEn: 'Warm corporate clarity and high readability',
      descBn: 'সহজে পাঠযোগ্য, পরিপাটি ও মার্জিত ফন্ট',
      sample: 'Onu Finance • 12,450 ৳ (Aa Bb Gg 123)',
      fontClass: 'font-lato',
      category: 'en',
    },
    {
      id: 'outfit',
      nameEn: 'Outfit (Fintech Minimal)',
      nameBn: 'আউটফিট (Outfit - মিনিমাল ও স্মার্ট)',
      descEn: 'Cutting-edge clean tech brand typography',
      descBn: 'নতুন প্রজন্মের স্মার্ট ও মিনিমালিস্টিক ফন্ট',
      sample: 'Onu Finance • 12,450 ৳ (Aa Bb Gg 123)',
      fontClass: 'font-outfit',
      category: 'en',
    },
    {
      id: 'raleway',
      nameEn: 'Raleway (Elegant Display)',
      nameBn: 'রেলওয়ে (Raleway - আভিজাত্যময়)',
      descEn: 'Sophisticated aesthetic with fine character curves',
      descBn: 'আভিজাত্যময় ও চমৎকার কার্ভযুক্ত প্রিমিয়াম ফন্ট',
      sample: 'Onu Finance • 12,450 ৳ (Aa Bb Gg 123)',
      fontClass: 'font-raleway',
      category: 'en',
    },
    {
      id: 'open_sans',
      nameEn: 'Open Sans (Ultra Clean)',
      nameBn: 'ওপেন সান্স (Open Sans - ক্লিয়ার ও ব্যালেন্সড)',
      descEn: 'Neutral, open forms designed for maximum screen clarity',
      descBn: 'স্ক্রিনে সবচেয়ে স্পষ্ট ও নিরপেক্ষ ক্লাসিক ফন্ট',
      sample: 'Onu Finance • 12,450 ৳ (Aa Bb Gg 123)',
      fontClass: 'font-open-sans',
      category: 'en',
    },
    {
      id: 'oswald',
      nameEn: 'Oswald (Impactful Bold)',
      nameBn: 'অসওয়াল্ড (Oswald - আকর্ষণীয় ও স্ট্রং)',
      descEn: 'Condensed, punchy headline style typography',
      descBn: 'বাজেট ও হিসাবের জন্য শক্তিশালী কনডেন্সড ফন্ট',
      sample: 'Onu Finance • 12,450 ৳ (Aa Bb Gg 123)',
      fontClass: 'font-oswald',
      category: 'en',
    },
    {
      id: 'mono',
      nameEn: 'JetBrains Mono',
      nameBn: 'জেটব্রেইন্স মোনো (JetBrains Mono)',
      descEn: 'Monospace for clean digits and financial balance',
      descBn: 'হিসাব ও সংখ্যার জন্য বিশেষ মোনোস্পেস ফন্ট',
      sample: '৳ 54,250.00 / 12,450',
      fontClass: 'font-mono',
      category: 'en',
    },
    {
      id: 'system',
      nameEn: 'System Modern (Default)',
      nameBn: 'সিস্টেম আধুনিক (System Default)',
      descEn: 'Fast & responsive native OS typeface',
      descBn: 'ডিভাইসের নিজস্ব দ্রুত ও আধুনিক ফন্ট',
      sample: 'Onu Finance • ১২,৪৫০ ৳',
      fontClass: 'font-system',
      category: 'en',
    },
    // Bengali Fonts
    {
      id: 'hind_siliguri',
      nameEn: 'Hind Siliguri',
      nameBn: 'হিন্দ শিলিগুড়ি (জনপ্রিয় ও স্পষ্ট বাংলা)',
      descEn: 'Crisp & readable Bengali typography',
      descBn: 'খুব স্পষ্ট ও জনপ্রিয় বাংলা ফন্ট',
      sample: 'হিন্দ শিলিগুড়ি - ঝকঝকে বাংলা হিসাব',
      fontClass: 'font-hind-siliguri',
      category: 'bn',
    },
    {
      id: 'tiro_bangla',
      nameEn: 'Tiro Bangla',
      nameBn: 'তিরো বাংলা (মার্জিত ক্লাসিক সেরিফ)',
      descEn: 'Traditional elegance with editorial touch',
      descBn: 'ঐতিহ্যবাহী ক্লাসিক ও মার্জিত রূপ',
      sample: 'তিরো বাংলা - ক্লাসিক সেরিফ শৈলী',
      fontClass: 'font-tiro-bangla',
      category: 'bn',
    },
    {
      id: 'noto_sans',
      nameEn: 'Noto Sans Bengali',
      nameBn: 'নোটো সান্স বাংলা (গুগল স্ট্যান্ডার্ড)',
      descEn: 'Universal accessibility & visual balance',
      descBn: 'গুগল স্ট্যান্ডার্ড সর্বজনীন ফন্ট',
      sample: 'নোটো সান্স বাংলা - পরিচ্ছন্ন টেক্সট',
      fontClass: 'font-noto-sans',
      category: 'bn',
    },
  ];

  const FONT_SIZE_OPTIONS: {
    id: AppFontSize;
    nameEn: string;
    nameBn: string;
    scale: string;
  }[] = [
    { id: 'small', nameEn: 'Small', nameBn: 'ছোট (৯০%)', scale: '90%' },
    { id: 'medium', nameEn: 'Standard', nameBn: 'ডিফল্ট (১০০%)', scale: '100%' },
    { id: 'large', nameEn: 'Large', nameBn: 'বড় (১১০%)', scale: '110%' },
    { id: 'xlarge', nameEn: 'Extra Large', nameBn: 'খুব বড় (১২০%)', scale: '120%' },
  ];

  const FONT_WEIGHT_OPTIONS: {
    id: AppFontWeight;
    nameEn: string;
    nameBn: string;
    weightName: string;
  }[] = [
    { id: 'normal', nameEn: 'Regular', nameBn: 'স্বাভাবিক (400)', weightName: '400' },
    { id: 'medium', nameEn: 'Medium', nameBn: 'মাঝারি (500)', weightName: '500' },
    { id: 'semibold', nameEn: 'Semi-Bold', nameBn: 'সেমি-বোল্ড (600)', weightName: '600' },
    { id: 'bold', nameEn: 'Bold', nameBn: 'বোল্ড (700)', weightName: '700' },
  ];

  const getFontCssString = (fontId?: string) => {
    switch (fontId) {
      case 'hind_siliguri':
        return "'Hind Siliguri', system-ui, sans-serif";
      case 'tiro_bangla':
        return "'Tiro Bangla', Georgia, serif";
      case 'noto_sans':
        return "'Noto Sans Bengali', system-ui, sans-serif";
      case 'inter':
        return "'Inter', system-ui, -apple-system, sans-serif";
      case 'poppins':
        return "'Poppins', system-ui, -apple-system, sans-serif";
      case 'jakarta':
        return "'Plus Jakarta Sans', system-ui, -apple-system, sans-serif";
      case 'roboto':
        return "'Roboto', system-ui, -apple-system, sans-serif";
      case 'playfair':
        return "'Playfair Display', Georgia, serif";
      case 'montserrat':
        return "'Montserrat', system-ui, -apple-system, sans-serif";
      case 'lato':
        return "'Lato', system-ui, -apple-system, sans-serif";
      case 'outfit':
        return "'Outfit', system-ui, -apple-system, sans-serif";
      case 'raleway':
        return "'Raleway', system-ui, -apple-system, sans-serif";
      case 'open_sans':
        return "'Open Sans', system-ui, -apple-system, sans-serif";
      case 'oswald':
        return "'Oswald', system-ui, sans-serif";
      case 'mono':
        return "'JetBrains Mono', ui-monospace, monospace";
      default:
        return 'system-ui, -apple-system, BlinkMacSystemFont, sans-serif';
    }
  };

  const selectedFont =
    FONT_FAMILY_OPTIONS.find((f) => (appSettings.fontFamily || 'system') === f.id) ||
    FONT_FAMILY_OPTIONS.find((f) => f.id === 'system') ||
    FONT_FAMILY_OPTIONS[0];

  const currentSizeIndex = Math.max(
    0,
    FONT_SIZE_OPTIONS.findIndex((s) => (appSettings.fontSize || 'medium') === s.id)
  );
  const activeSize = FONT_SIZE_OPTIONS[currentSizeIndex] || FONT_SIZE_OPTIONS[1];

  const currentWeightIndex = Math.max(
    0,
    FONT_WEIGHT_OPTIONS.findIndex((w) => (appSettings.fontWeight || 'medium') === w.id)
  );
  const activeWeight = FONT_WEIGHT_OPTIONS[currentWeightIndex] || FONT_WEIGHT_OPTIONS[1];

  // Cloud Drive Sync Handler
  const handleTriggerSync = () => {
    setIsSyncingDrive(true);
    setSyncStatusMsg(isEn ? 'Syncing with Google Drive...' : 'গুগল ড্রাইভে সিঙ্ক হচ্ছে...');
    setTimeout(() => {
      setIsSyncingDrive(false);
      const timeStr = new Date().toLocaleTimeString(isEn ? 'en-US' : 'bn-BD');
      setSyncStatusMsg(
        isEn
          ? `Auto-synced at ${timeStr}`
          : `ড্রাইভে অটো-সিঙ্ক সম্পন্ন (${timeStr})`
      );
      onUpdateSettings({
        ...appSettings,
        googleDriveConnected: true,
        googleDriveLastSynced: timeStr,
      });
    }, 1200);
  };

  // Download Backup
  const handleDownloadBackup = () => {
    const backupData = storage.exportBackupFile();
    const blob = new Blob([JSON.stringify(backupData, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `taka_tracker_backup_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Upload Backup
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        const success = storage.importBackupFile(json);
        if (success) {
          alert(isEn ? 'Backup imported successfully!' : 'ব্যাকআপ সফলভাবে রিস্টোর হয়েছে!');
          if (onDataImported) onDataImported();
          else window.location.reload();
        } else {
          alert(isEn ? 'Invalid backup file format.' : 'ভুল ব্যাকআপ ফাইল ফরম্যাট!');
        }
      } catch (err) {
        alert(isEn ? 'Failed to parse JSON file.' : 'ফাইলটি পড়তে ব্যর্থ হয়েছে!');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Search filtering logic
  const normalizedQuery = searchQuery.trim().toLowerCase();
  const matchesSearch = (terms: string[]) => {
    if (!normalizedQuery) return true;
    return terms.some((term) => term.toLowerCase().includes(normalizedQuery));
  };

  const isProfileVisible = matchesSearch([
    'profile', 'user', 'name', 'account', 'opening', 'balance', 'history', 'audit', 'avatar',
    'categories', 'category', 'manage', 'expense', 'income',
    'প্রোফাইল', 'ইউজার', 'নাম', 'ব্যালেন্স', 'ওপেনিং', 'হিস্ট্রি', 'অ্যাকাউন্ট', 'ছবি', 'লগ',
    'ক্যাটাগরি', 'ক্যাটেগরি', 'খরচ', 'আয়', 'পরিচালনা'
  ]);
  const isThemeVisible = matchesSearch([
    'theme', 'appearance', 'color', 'accent', 'font', 'typography', 'dark', 'light', 'oled',
    'shade', 'tone', 'deep', 'থিম', 'কালার', 'ফন্ট', 'রং', 'লাইট', 'ডার্ক', 'ওলেড', 'ডিসপ্লে',
    'শেড', 'টোন', 'ডিপ', 'হালকা', 'গাঢ়'
  ]);
  const isLanguageVisible = matchesSearch([
    'language', 'currency', 'digits', 'english', 'bangla', 'taka', 'dollar',
    'ভাষা', 'মুদ্রা', 'টাকা', 'সংখ্যা', 'ইংরেজি', 'বাংলা'
  ]);
  const isSecurityVisible = matchesSearch([
    'app lock', 'security', 'pin', 'pattern', 'password', 'lock',
    'লক', 'পিন', 'প্যাটার্ন', 'নিরাপত্তা', 'পাসওয়ার্ড'
  ]);
  const isBackupResetVisible = matchesSearch([
    'backup', 'reset', 'restore', 'cloud', 'sync', 'google drive', 'onedrive', 'dropbox', 'drive', 'json', 'snapshots',
    'রিসেট', 'রিস্টোর', 'ব্যাকআপ', 'ক্লাউড', 'সিঙ্ক', 'ড্রাইভ', 'গুগল ড্রাইভ', 'স্ন্যাপশট', 'ফাইল'
  ]);
  const isExportVisible = matchesSearch([
    'export', 'reports', 'ledger', 'excel', 'csv', 'pdf', 'statement',
    'রিপোর্ট', 'এক্সপোর্ট', 'স্টেটমেন্ট'
  ]);

  const visibleCount = [
    isProfileVisible,
    isThemeVisible,
    isLanguageVisible,
    isSecurityVisible,
    isBackupResetVisible,
    isExportVisible,
  ].filter(Boolean).length;

  const userFullName = [activeUserProfile.firstName, activeUserProfile.lastName].filter(Boolean).join(' ');
  const userInitials = (activeUserProfile.firstName?.[0] || '') + (activeUserProfile.lastName?.[0] || '');

  return (
    <div className="space-y-4 pb-12 animate-in fade-in duration-200">
      {/* Top Header: Avatar first, then Name, and on the right side spanning 40% width is the Search Bar */}
      <div className="flex items-center justify-between gap-3 sm:gap-4 pt-1">
        {/* Left Side: Avatar then Name */}
        <div className="flex items-center gap-3 sm:gap-3.5 min-w-0 flex-1">
          {/* Avatar */}
          <button
            type="button"
            onClick={() => setIsProfileModalOpen(true)}
            className={`w-14 h-14 sm:w-16 sm:h-16 aspect-square rounded-full ${cardBg} border-2 flex items-center justify-center p-0.5 group transition cursor-pointer shrink-0 hover:scale-105 shadow-xs`}
            style={{ borderColor: dualAccent.primary.hex }}
            id="btn-header-profile-avatar"
            title={isEn ? 'View Profile' : 'প্রোফাইল দেখুন'}
            aria-label={isEn ? 'User Profile' : 'ইউজার প্রোফাইল'}
          >
            <div className="w-full h-full rounded-full overflow-hidden flex items-center justify-center">
              {activeUserProfile.avatarUrl ? (
                <img
                  src={activeUserProfile.avatarUrl}
                  alt="User"
                  className="w-full h-full object-cover rounded-full"
                />
              ) : (
                <div
                  className="w-full h-full rounded-full flex items-center justify-center font-black text-lg sm:text-xl text-white shadow-2xs"
                  style={{ backgroundColor: dualAccent.primary.hex }}
                >
                  {userInitials || <User className="w-7 h-7" />}
                </div>
              )}
            </div>
          </button>

          {/* User Name in Large Font after Avatar */}
          <div className="min-w-0 flex-1">
            <button
              type="button"
              onClick={() => setIsProfileModalOpen(true)}
              className={`text-base sm:text-lg md:text-xl font-black ${headingText} hover:opacity-80 transition text-left truncate cursor-pointer tracking-tight block w-full leading-tight`}
              title={isEn ? 'View Profile' : 'প্রোফাইল দেখুন'}
            >
              {userFullName || (isEn ? 'User Profile' : 'ইউজার প্রোফাইল')}
            </button>
            <p className={`text-xs font-medium ${subText} truncate mt-0.5`}>
              {activeUserProfile.email || activeUserProfile.phone || (isEn ? 'Personal Account' : 'ব্যক্তিগত অ্যাকাউন্ট')}
            </p>
          </div>
        </div>

        {/* Right Side: Search Bar spanning 40% width with enhanced thickness matching Avatar */}
        <div className="relative w-[40%] shrink-0">
          <Search className={`w-4 h-4 absolute left-3 sm:left-3.5 top-1/2 -translate-y-1/2 pointer-events-none transition ${isLight ? 'text-slate-400' : 'text-slate-400'}`} />
          <input
            type="text"
            id="settings-search-bar"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isEn ? 'Search...' : 'খুঁজুন...'}
            className={`w-full pl-9 pr-7 sm:pl-10 sm:pr-8 py-2.5 sm:py-3 rounded-2xl border-2 text-xs sm:text-sm font-semibold outline-hidden transition shadow-xs ${
              isLight
                ? 'bg-white border-slate-200 text-slate-900 placeholder-slate-400 hover:border-slate-300'
                : 'bg-slate-800/95 border-slate-600 text-slate-100 placeholder-slate-400 hover:border-slate-500'
            }`}
            style={{
              borderColor: searchQuery ? dualAccent.primary.hex : undefined,
            }}
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer transition hover:bg-slate-100 dark:hover:bg-slate-700"
              title={isEn ? 'Clear' : 'মুছুন'}
              aria-label={isEn ? 'Clear search' : 'সার্চ মুছুন'}
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Settings Menu Items (Cards with Popup Triggers) */}
      <div className="space-y-2.5">
        {/* =========================================================================
            MENU 0: 👤 PROFILE (MAIN SETTINGS FIRST OPTION)
            ========================================================================= */}
        {isProfileVisible && (
          <button
            type="button"
            onClick={() => setIsProfileModalOpen(true)}
            className={`w-full p-4 ${cardBg} border rounded-3xl text-left flex items-center justify-between group transition cursor-pointer`}
            id="btn-open-profile-popup"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div
                className="p-3 rounded-2xl border transition shrink-0"
                style={{
                  backgroundColor: `color-mix(in srgb, ${dualAccent.primary.hex} 15%, transparent)`,
                  borderColor: `color-mix(in srgb, ${dualAccent.primary.hex} 30%, transparent)`,
                  color: dualAccent.primary.hex,
                }}
              >
                <User className="w-5 h-5" />
              </div>

              <div className="truncate">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2
                    className={`text-sm font-bold ${headingText} transition`}
                  >
                    {isEn ? 'Profile Setup' : 'প্রোফাইল সেটআপ'}
                  </h2>
                  <span
                    className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border flex items-center gap-1.5 ${
                      isLight
                        ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                        : 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                    }`}
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    {isEn ? 'Active' : 'অ্যাক্টিভ'}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span
                className="text-[11px] font-bold hidden sm:inline"
                style={{ color: dualAccent.primary.hex }}
              >
                {isEn ? 'Manage' : 'ম্যানেজ'}
              </span>
              <ChevronRight
                className={`w-4 h-4 ${subText} group-hover:translate-x-0.5 transition`}
              />
            </div>
          </button>
        )}

        {/* =========================================================================
            MENU 1: 🎨 THEME & APPEARANCE (OPENS THEME POPUP)
            ========================================================================= */}
        {isThemeVisible && (
          <button
            type="button"
            onClick={() => setIsThemeModalOpen(true)}
            className={`w-full p-4 ${cardBg} border rounded-3xl text-left flex items-center justify-between group transition cursor-pointer`}
            id="btn-open-theme-popup"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div
                className={`p-3 rounded-2xl border transition shrink-0 ${
                  isLight
                    ? 'bg-purple-100 text-purple-700 border-purple-200'
                    : 'bg-purple-950/50 text-purple-400 border-purple-500/30'
                }`}
              >
                <Palette className="w-5 h-5" />
              </div>

              <div className="truncate">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className={`text-sm font-bold ${headingText} group-hover:text-purple-600 dark:group-hover:text-purple-400 transition`}>
                    {isEn ? 'Theme & Appearance' : 'থিম ও কালার সেটিংস'}
                  </h2>
                  <span
                    className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${
                      isLight
                        ? 'bg-purple-100 text-purple-800 border-purple-200'
                        : 'bg-purple-950/60 text-purple-300 border-purple-500/40'
                    }`}
                  >
                    {appSettings.themeMode === 'light'
                      ? isEn ? 'Light' : 'লাইট'
                      : appSettings.themeMode === 'dark'
                      ? isEn ? 'Dark' : 'ডার্ক'
                      : isEn ? 'OLED' : 'ওলেড'}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span
                className="w-3.5 h-3.5 rounded-full border border-black/20 dark:border-white/20 shadow-xs"
                style={{ backgroundColor: dualAccent.primary.hex }}
              />
              <span className="text-[11px] font-bold text-purple-600 dark:text-purple-400 hidden sm:inline">
                {isEn ? 'Popup' : 'পপআপ'}
              </span>
              <ChevronRight className={`w-4 h-4 ${subText} group-hover:text-purple-500 group-hover:translate-x-0.5 transition`} />
            </div>
          </button>
        )}

        {/* =========================================================================
            MENU 2: 🌐 LANGUAGE & CURRENCY (OPENS LANGUAGE POPUP)
            ========================================================================= */}
        {isLanguageVisible && (
          <button
            type="button"
            onClick={() => setIsLanguageModalOpen(true)}
            className={`w-full p-4 ${cardBg} border rounded-3xl text-left flex items-center justify-between group transition cursor-pointer`}
            id="btn-open-language-popup"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div
                className={`p-3 rounded-2xl border transition shrink-0 ${
                  isLight
                    ? 'bg-cyan-100 text-cyan-700 border-cyan-200'
                    : 'bg-cyan-950/50 text-cyan-400 border-cyan-500/30'
                }`}
              >
                <Languages className="w-5 h-5" />
              </div>

              <div className="truncate">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className={`text-sm font-bold ${headingText} group-hover:text-cyan-600 dark:group-hover:text-cyan-400 transition`}>
                    {isEn ? 'Language & Currency' : 'ভাষা, সংখ্যা ও মুদ্রা'}
                  </h2>
                  <span
                    className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${
                      isLight
                        ? 'bg-cyan-100 text-cyan-800 border-cyan-300'
                        : 'bg-cyan-950/60 text-cyan-300 border-cyan-500/40'
                    }`}
                  >
                    {appSettings.language === 'bn' ? 'বাংলা' : 'English'} • {appSettings.currencySymbol}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="text-[11px] font-bold text-cyan-600 dark:text-cyan-400 hidden sm:inline">
                {isEn ? 'Popup' : 'পপআপ'}
              </span>
              <ChevronRight className={`w-4 h-4 ${subText} group-hover:text-cyan-500 group-hover:translate-x-0.5 transition`} />
            </div>
          </button>
        )}

        {/* =========================================================================
            MENU 3: 🔒 APP LOCK & SECURITY (OPENS APP LOCK POPUP)
            ========================================================================= */}
        {isSecurityVisible && (
          <button
            type="button"
            onClick={() => {
              setSecurityModalInitialTab('app_lock');
              setIsSecurityModalOpen(true);
            }}
            className={`w-full p-4 ${cardBg} border rounded-3xl text-left flex items-center justify-between group transition cursor-pointer`}
            id="btn-open-app-lock-popup"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div
                className={`p-3 rounded-2xl border transition shrink-0 ${
                  isLight
                    ? 'bg-blue-100 text-blue-700 border-blue-200'
                    : 'bg-blue-950/50 text-blue-400 border-blue-500/30'
                }`}
              >
                <Lock className="w-5 h-5" />
              </div>

              <div className="truncate">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className={`text-sm font-bold ${headingText} group-hover:text-blue-600 dark:group-hover:text-blue-400 transition`}>
                    {isEn ? 'Lock & Security' : 'লক ও নিরাপত্তা'}
                  </h2>
                  <span
                    className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${
                      activeSecurity.isPinEnabled || activeSecurity.isPatternEnabled
                        ? 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-500/40'
                        : 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-500/40'
                    }`}
                  >
                    {activeSecurity.isPinEnabled
                      ? isEn ? 'PIN Active' : 'পিন সক্রিয়'
                      : activeSecurity.isPatternEnabled
                      ? isEn ? 'Pattern Active' : 'প্যাটার্ন সক্রিয়'
                      : isEn ? 'Unlocked' : 'লক বন্ধ'}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="text-[11px] font-bold text-blue-600 dark:text-blue-400 hidden sm:inline">
                {isEn ? 'Popup' : 'পপআপ'}
              </span>
              <ChevronRight className={`w-4 h-4 ${subText} group-hover:text-blue-500 group-hover:translate-x-0.5 transition`} />
            </div>
          </button>
        )}

        {/* =========================================================================
            MENU 4: 💾 BACKUP & RESET (OPENS BACKUP & RESET POPUP)
            ========================================================================= */}
        {isBackupResetVisible && (
          <button
            type="button"
            onClick={() => {
              setSecurityModalInitialTab('backup_restore');
              setIsSecurityModalOpen(true);
            }}
            className={`w-full p-4 ${cardBg} border rounded-3xl text-left flex items-center justify-between group transition cursor-pointer`}
            id="btn-open-backup-reset-popup"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div
                className={`p-3 rounded-2xl border transition shrink-0 ${
                  isLight
                    ? 'bg-emerald-100 text-emerald-700 border-emerald-200'
                    : 'bg-emerald-950/50 text-emerald-400 border-emerald-500/30'
                }`}
              >
                <HardDrive className="w-5 h-5" />
              </div>

              <div className="truncate">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className={`text-sm font-bold ${headingText} group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition`}>
                    {isEn ? 'Backup & Reset' : 'ব্যাকআপ ও রিসেট'}
                  </h2>
                  <span
                    className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${
                      isLight
                        ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                        : 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                    }`}
                  >
                    {isEn ? 'Offline / Cloud' : 'অফলাইন ও ক্লাউড'}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 hidden sm:inline">
                {isEn ? 'Popup' : 'পপআপ'}
              </span>
              <ChevronRight className={`w-4 h-4 ${subText} group-hover:text-emerald-500 group-hover:translate-x-0.5 transition`} />
            </div>
          </button>
        )}

        {/* =========================================================================
            MENU 5: 📊 EXPORT REPORTS (OPENS EXPORT MODAL)
            ========================================================================= */}
        {isExportVisible && (
          <button
            type="button"
            onClick={() => setIsExportModalOpen(true)}
            className={`w-full p-4 ${cardBg} border rounded-3xl text-left flex items-center justify-between group transition cursor-pointer`}
            id="btn-open-export-popup"
          >
            <div className="flex items-center gap-3.5 min-w-0">
              <div
                className={`p-3 rounded-2xl border transition shrink-0 ${
                  isLight
                    ? 'bg-blue-100 text-blue-700 border-blue-200'
                    : 'bg-blue-950/50 text-blue-400 border-blue-500/30'
                }`}
              >
                <FileDown className="w-5 h-5" />
              </div>

              <div className="truncate">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className={`text-sm font-bold ${headingText} group-hover:text-blue-600 dark:group-hover:text-blue-400 transition`}>
                    {isEn ? 'Export Reports' : 'রিপোর্ট এক্সপোর্ট'}
                  </h2>
                  <span
                    className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${
                      isLight
                        ? 'bg-blue-100 text-blue-800 border-blue-300'
                        : 'bg-blue-950/60 text-blue-300 border-blue-500/40'
                    }`}
                  >
                    Excel / CSV / PDF
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="text-[11px] font-bold text-blue-600 dark:text-blue-400 hidden sm:inline">
                {isEn ? 'Popup' : 'পপআপ'}
              </span>
              <ChevronRight className={`w-4 h-4 ${subText} group-hover:text-blue-500 group-hover:translate-x-0.5 transition`} />
            </div>
          </button>
        )}

        {/* Empty State when no settings match search */}
        {visibleCount === 0 && (
          <div className={`p-8 rounded-3xl border text-center ${cardBg} space-y-3 shadow-2xs`}>
            <div className={`w-12 h-12 rounded-2xl mx-auto flex items-center justify-center ${isLight ? 'bg-slate-100 text-slate-400' : 'bg-slate-800 text-slate-500'}`}>
              <Search className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className={`text-sm font-bold ${headingText}`}>
                {isEn ? 'No settings found' : 'কোনো সেটিংস পাওয়া যায়নি'}
              </h3>
              <p className={`text-xs ${subText}`}>
                {isEn ? `No results for "${searchQuery}"` : `"${searchQuery}" এর সাথে কোনো সেটিংস মিলছে না`}
              </p>
            </div>
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white transition cursor-pointer"
            >
              {isEn ? 'Clear Search' : 'সার্চ মুছুন'}
            </button>
          </div>
        )}
      </div>

      {/* =========================================================================
          POPUP MODAL 1: 🎨 THEME & APPEARANCE POPUP
          ========================================================================= */}
      <AnimatePresence>
        {isThemeModalOpen && (
          <div
            className={`fixed inset-0 z-50 flex items-center justify-center ${
              isLight ? 'bg-slate-900/40 backdrop-blur-xs' : 'bg-black/75 backdrop-blur-xs'
            } p-3 sm:p-4 animate-in fade-in duration-200`}
          >
            {/* Backdrop click */}
            <div className="absolute inset-0" onClick={() => setIsThemeModalOpen(false)} />

            {/* Modal Dialog */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.2, ease: 'easeOut' }}
              className={`relative z-10 w-full max-w-lg max-h-[90vh] flex flex-col rounded-3xl shadow-2xl border ${modalBg} overflow-hidden`}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Modal Header */}
              <div className={`p-4 sm:p-5 border-b flex items-center justify-between gap-3 ${isLight ? 'border-slate-200' : 'border-slate-800'}`}>
                <div className="flex items-center gap-3">
                  <div
                    className="p-2.5 rounded-2xl text-white shadow-sm flex items-center justify-center transition-colors"
                    style={{ backgroundColor: dualAccent.primary.hex }}
                  >
                    {themeModalTab === 'theme_color' ? <Palette className="w-5 h-5" /> : <Type className="w-5 h-5" />}
                  </div>
                  <div>
                    <h3 className="text-base font-black tracking-tight">
                      {isEn ? 'Theme & Appearance' : 'থিম ও ফন্ট সেটিংস'}
                    </h3>
                    <p className={`text-xs ${subText}`}>
                      {themeModalTab === 'theme_color'
                        ? isEn ? 'Customize display mode and accent colors' : 'ডার্ক/লাইট মোড এবং অ্যাকসেন্ট কালার পরিবর্তন করুন'
                        : isEn ? 'Customize font style, typography & scale' : 'ফন্ট স্টাইল, সাইজ এবং বোল্ডনেস পরিবর্তন করুন'}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setIsThemeModalOpen(false)}
                  className={`p-2 rounded-xl transition cursor-pointer ${
                    isLight ? 'hover:bg-slate-100 text-slate-500' : 'hover:bg-slate-800 text-slate-400'
                  }`}
                  aria-label="Close"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Two Main Side-by-Side Menu Buttons: Theme & Color Settings and Font Setting */}
              <div className={`p-3 sm:px-5 border-b ${isLight ? 'border-slate-100 bg-slate-50/50' : 'border-slate-800/80 bg-slate-900/40'}`}>
                <div
                  className="grid grid-cols-2 gap-2 p-1 rounded-2xl border transition-colors"
                  style={{
                    backgroundColor: isLight
                      ? `color-mix(in srgb, ${dualAccent.primary.hex} 10%, #ffffff)`
                      : `color-mix(in srgb, ${dualAccent.primary.hex} 12%, #0f172a)`,
                    borderColor: `color-mix(in srgb, ${dualAccent.primary.hex} 25%, transparent)`,
                  }}
                >
                  <button
                    type="button"
                    onClick={() => setThemeModalTab('theme_color')}
                    id="theme-tab-theme-color-btn"
                    style={
                      themeModalTab === 'theme_color'
                        ? {
                            backgroundColor: dualAccent.primary.hex,
                            color: '#ffffff',
                            boxShadow: `0 4px 14px -2px ${dualAccent.primary.hex}60`,
                          }
                        : undefined
                    }
                    className={`py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 cursor-pointer ${
                      themeModalTab === 'theme_color'
                        ? 'font-black text-white shadow-md'
                        : isLight
                        ? 'text-slate-700 hover:text-slate-900 hover:bg-black/5'
                        : 'text-slate-300 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <Palette
                      className="w-4 h-4 shrink-0"
                      style={{ color: themeModalTab === 'theme_color' ? '#ffffff' : dualAccent.primary.hex }}
                    />
                    <span className="truncate">{isEn ? 'Theme & Color' : 'থিম এন্ড কালার'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setThemeModalTab('font')}
                    id="theme-tab-font-setting-btn"
                    style={
                      themeModalTab === 'font'
                        ? {
                            backgroundColor: dualAccent.primary.hex,
                            color: '#ffffff',
                            boxShadow: `0 4px 14px -2px ${dualAccent.primary.hex}60`,
                          }
                        : undefined
                    }
                    className={`py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 cursor-pointer ${
                      themeModalTab === 'font'
                        ? 'font-black text-white shadow-md'
                        : isLight
                        ? 'text-slate-700 hover:text-slate-900 hover:bg-black/5'
                        : 'text-slate-300 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <Type
                      className="w-4 h-4 shrink-0"
                      style={{ color: themeModalTab === 'font' ? '#ffffff' : dualAccent.primary.hex }}
                    />
                    <span className="truncate">{isEn ? 'Font Setting' : 'ফন্ট সেটিং'}</span>
                  </button>
                </div>
              </div>

              {/* Modal Body (Scrollable) */}
              <div className="p-4 sm:p-5 space-y-5 overflow-y-auto no-scrollbar">
                {themeModalTab === 'theme_color' ? (
                  <>
                {/* 1. Theme Mode Selection */}
                <div className="space-y-2">
                  <label className={`text-xs font-bold flex items-center gap-1.5 ${headingText}`}>
                    <Sun className="w-3.5 h-3.5 text-amber-500" />
                    <span>{isEn ? 'Theme Mode' : 'থিম মোড'}</span>
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'light', labelEn: 'Light', labelBn: 'লাইট', icon: <Sun className="w-4 h-4 text-amber-500" /> },
                      { id: 'dark', labelEn: 'Dark', labelBn: 'ডার্ক', icon: <Moon className="w-4 h-4 text-indigo-400" /> },
                      { id: 'oled', labelEn: 'OLED', labelBn: 'ওলেড', icon: <Sparkles className="w-4 h-4 text-emerald-400" /> },
                    ].map((mode) => {
                      const isSelected = appSettings.themeMode === mode.id;
                      return (
                        <button
                          key={mode.id}
                          type="button"
                          onClick={() =>
                            onUpdateSettings({
                              ...appSettings,
                              themeMode: mode.id as ThemeMode,
                            })
                          }
                          className={`p-3 rounded-2xl border text-center font-bold text-xs flex flex-col items-center gap-1.5 transition cursor-pointer ${
                            isSelected
                              ? 'shadow-xs'
                              : isLight
                              ? 'border-slate-200 hover:bg-slate-50 text-slate-700'
                              : 'border-slate-700 hover:bg-slate-800 text-slate-300'
                          }`}
                          style={
                            isSelected
                              ? {
                                  borderColor: dualAccent.primary.hex,
                                  backgroundColor: `color-mix(in srgb, ${dualAccent.primary.hex} 15%, transparent)`,
                                  color: dualAccent.primary.hex,
                                  boxShadow: `0 0 0 2px color-mix(in srgb, ${dualAccent.primary.hex} 30%, transparent)`,
                                }
                              : undefined
                          }
                        >
                          {mode.icon}
                          <span>{isEn ? mode.labelEn : mode.labelBn}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* 2. Accent Color (Unified Primary & Secondary with All-Colors & Shade/Tone bars) */}
                <div className="space-y-3">
                  {/* Header */}
                  <div className="flex items-center justify-between">
                    <label className={`text-xs font-bold flex items-center gap-1.5 ${headingText}`}>
                      <Palette className="w-3.5 h-3.5" style={{ color: currentHex }} />
                      <span>{isEn ? 'Accent Color' : 'অ্যাকসেন্ট কালার'}</span>
                    </label>
                    <div className="flex items-center gap-1.5">
                      <span className={`text-[10px] font-bold ${subText}`}>
                        {currentHueName[isEn ? 'en' : 'bn']}
                      </span>
                      <span
                        className="text-[10px] font-mono font-bold px-2 py-0.5 rounded border border-black/10 dark:border-white/10"
                        style={{ color: currentHex }}
                      >
                        {currentHex.toUpperCase()}
                      </span>
                    </div>
                  </div>

                  {/* Primary & Secondary Switch Buttons */}
                  <div className="flex items-center gap-2 p-1 rounded-2xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10">
                    <button
                      type="button"
                      onClick={() => setActiveThemeColorTarget('primary')}
                      id="theme-target-primary-btn"
                      className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs transition flex items-center justify-center gap-2 cursor-pointer ${
                        activeThemeColorTarget === 'primary'
                          ? isLight
                            ? 'bg-white text-slate-900 shadow-md font-black'
                            : 'bg-slate-700 text-white shadow-md ring-2 ring-white/20 font-black'
                          : isLight
                          ? 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                          : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
                      }`}
                      style={
                        activeThemeColorTarget === 'primary' && isLight
                          ? { boxShadow: `0 2px 8px ${dualAccent.primary.hex}30, 0 0 0 2px ${dualAccent.primary.hex}40` }
                          : undefined
                      }
                    >
                      <span
                        className="w-3.5 h-3.5 rounded-full border border-black/20 shadow-xs shrink-0 transition"
                        style={{ backgroundColor: activePrimaryConfig.hex }}
                      />
                      <span className="truncate">
                        {isEn ? 'Primary Color' : 'প্রাইমারি কালার'}
                      </span>
                      {activeThemeColorTarget === 'primary' && (
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => setActiveThemeColorTarget('secondary')}
                      id="theme-target-secondary-btn"
                      className={`flex-1 py-2 px-3 rounded-xl font-bold text-xs transition flex items-center justify-center gap-2 cursor-pointer ${
                        activeThemeColorTarget === 'secondary'
                          ? isLight
                            ? 'bg-white text-slate-900 shadow-md font-black'
                            : 'bg-slate-700 text-white shadow-md ring-2 ring-white/20 font-black'
                          : isLight
                          ? 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                          : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
                      }`}
                      style={
                        activeThemeColorTarget === 'secondary' && isLight
                          ? { boxShadow: `0 2px 8px ${dualAccent.secondary.hex}30, 0 0 0 2px ${dualAccent.secondary.hex}40` }
                          : undefined
                      }
                    >
                      <span
                        className="w-3.5 h-3.5 rounded-full border border-black/20 shadow-xs shrink-0 transition"
                        style={{ backgroundColor: activeSecondaryConfig.hex }}
                      />
                      <span className="truncate">
                        {isEn ? 'Secondary Color' : 'সেকেন্ডারি কালার'}
                      </span>
                      {activeThemeColorTarget === 'secondary' && (
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={handleSwapColors}
                      id="theme-swap-colors-btn"
                      className={`p-2 rounded-xl border text-xs font-bold transition flex items-center justify-center shrink-0 cursor-pointer active:scale-95 ${
                        isLight
                          ? 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 shadow-xs'
                          : 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700 shadow-xs'
                      }`}
                      title={isEn ? 'Swap Primary & Secondary colors' : 'প্রাইমারি ও সেকেন্ডারি অদলবদল করুন'}
                    >
                      <ArrowLeftRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* All-Color Bar (একটি অল কালার বার) */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className={`font-semibold flex items-center gap-1 ${subText}`}>
                        <Sliders className="w-3 h-3" style={{ color: currentHex }} />
                        {isEn ? 'All-Color Bar' : 'অল কালার বার'}
                      </span>
                      <span className={`font-mono text-[10px] px-1.5 py-0.5 rounded border ${
                        isLight ? 'bg-slate-100 border-slate-200 text-slate-800' : 'bg-slate-900 border-slate-700 text-slate-200'
                      }`}>
                        {themeHue}°
                      </span>
                    </div>

                    <div className="relative">
                      <input
                        type="range"
                        min="0"
                        max="360"
                        value={themeHue}
                        onChange={(e) => handleHueChange(Number(e.target.value))}
                        className="w-full h-7 rounded-xl appearance-none cursor-pointer spectrum-slider shadow-inner border border-black/15 dark:border-white/20 transition"
                        style={{
                          background:
                            'linear-gradient(to right, #ff0000 0%, #ff7700 8.3%, #ffdd00 16.7%, #88ff00 25%, #00ff00 33.3%, #00ff88 41.7%, #00ffff 50%, #0088ff 58.3%, #0000ff 66.7%, #8800ff 75%, #ff00ff 83.3%, #ff0077 91.7%, #ff0000 100%)',
                        }}
                        id="theme-all-color-slider"
                        aria-label="All Color Bar"
                      />
                    </div>
                  </div>

                  {/* Shade & Tone Bar (shad & ton বার) */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className={`font-semibold ${subText}`}>
                        {isEn ? 'Shade & Tone' : 'শেড ও টোন (Shad & Ton)'}
                      </span>
                      <span className={`font-mono text-[10px] px-1.5 py-0.5 rounded border ${
                        isLight ? 'bg-slate-100 border-slate-200 text-slate-800' : 'bg-slate-900 border-slate-700 text-slate-200'
                      }`}>
                        {themeLightness}%
                      </span>
                    </div>

                    <div className="relative">
                      <input
                        type="range"
                        min="25"
                        max="75"
                        value={themeLightness}
                        onChange={(e) => handleLightnessChange(Number(e.target.value))}
                        className="w-full h-3 rounded-lg appearance-none cursor-pointer shadow-inner border border-black/10 dark:border-white/15"
                        style={{
                          background: `linear-gradient(to right, #0f172a 0%, ${hslToHex(themeHue, 85, 50)} 50%, #ffffff 100%)`,
                          accentColor: currentHex,
                        }}
                        id="theme-shade-tone-slider"
                        aria-label="Shade and Tone Bar"
                      />
                    </div>
                  </div>

                  {/* Quick Color Presets in 1 Single Row (Round / Circular) */}
                  <div className="pt-1">
                    <div className="flex items-center justify-between gap-1 sm:gap-1.5 p-2 rounded-2xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 overflow-x-auto no-scrollbar">
                      {ACCENT_OPTIONS.map((c) => {
                        const isSelected = currentHex.toLowerCase() === c.hex.toLowerCase() || 
                          (activeThemeColorTarget === 'primary' ? appSettings.themeAccent === c.id : (appSettings.secondaryAccent || 'cyan') === c.id);
                        return (
                          <button
                            key={c.id}
                            type="button"
                            onClick={() => handleColorChange(c.hex)}
                            className={`w-6.5 h-6.5 sm:w-7 sm:h-7 md:w-8 md:h-8 rounded-full flex items-center justify-center shrink-0 transition-transform cursor-pointer ${
                              isSelected
                                ? 'scale-110 ring-2 ring-offset-2 ring-offset-white dark:ring-offset-slate-900 shadow-md ring-slate-800 dark:ring-white'
                                : 'hover:scale-110 opacity-85 hover:opacity-100'
                            }`}
                            style={{ backgroundColor: c.hex }}
                            title={isEn ? c.nameEn : c.nameBn}
                            aria-label={isEn ? c.nameEn : c.nameBn}
                          >
                            {isSelected && <Check className="w-3.5 h-3.5 text-white stroke-[3]" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Live Preview */}
                <div className={`p-3.5 rounded-2xl border ${modalInnerBg} space-y-2.5`}>
                  <div className="flex items-center justify-between text-xs font-bold">
                    <span className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
                      <Eye className="w-4 h-4" />
                      {isEn ? 'Live Preview' : 'লাইভ প্রিভিউ'}
                    </span>
                    <span className="font-extrabold text-slate-700 dark:text-slate-300">
                      {appSettings.currencySymbol} ২৫,৪৫০
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      className="flex-1 py-2 px-3 rounded-xl text-white font-bold text-xs shadow-sm"
                      style={{ backgroundColor: dualAccent.primary.hex }}
                    >
                      {isEn ? 'Primary Button' : 'প্রাইমারি বাটন'}
                    </button>
                    <button
                      type="button"
                      className="py-2 px-3.5 rounded-xl text-white font-bold text-xs shadow-sm"
                      style={{ backgroundColor: dualAccent.secondary.hex }}
                    >
                      {isEn ? 'Secondary' : 'সেকেন্ডারি'}
                    </button>
                  </div>
                </div>
                  </>
                ) : (
                  <>
                    {/* =========================================================
                        FONT SETTING TAB CONTENT
                        ========================================================= */}

                    {/* 1. Font Family Selection (Dropdown) */}
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between">
                        <label className={`text-xs font-bold flex items-center gap-1.5 ${headingText}`}>
                          <Type className="w-3.5 h-3.5" style={{ color: dualAccent.primary.hex }} />
                          <span>{isEn ? 'Font Family' : 'ফন্ট ফ্যামিলি (Font Family)'}</span>
                        </label>
                        <span
                          className="text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-black/10 dark:border-white/10"
                          style={{
                            color: dualAccent.primary.hex,
                            backgroundColor: `color-mix(in srgb, ${dualAccent.primary.hex} 12%, transparent)`,
                          }}
                        >
                          {selectedFont?.category === 'en' ? (isEn ? 'English Font' : 'ইংরেজি ফন্ট') : (isEn ? 'Bengali Font' : 'বাংলা ফন্ট')}
                        </span>
                      </div>

                      {/* Dropdown Container */}
                      <div className="relative">
                        {/* Overlay to close dropdown when clicking outside */}
                        {isFontDropdownOpen && (
                          <div
                            className="fixed inset-0 z-20"
                            onClick={() => setIsFontDropdownOpen(false)}
                          />
                        )}

                        <button
                          type="button"
                          id="font-family-dropdown-button"
                          onClick={() => setIsFontDropdownOpen(!isFontDropdownOpen)}
                          className={`w-full p-3 rounded-2xl border text-left flex items-center justify-between transition cursor-pointer relative z-20 ${
                            isFontDropdownOpen
                              ? 'border-slate-400 ring-2 ring-slate-300/40'
                              : isLight
                              ? 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
                              : 'bg-slate-800/90 border-slate-700 hover:border-slate-600 shadow-xs'
                          }`}
                          style={
                            isFontDropdownOpen
                              ? {
                                  borderColor: dualAccent.primary.hex,
                                  boxShadow: `0 0 0 2px color-mix(in srgb, ${dualAccent.primary.hex} 30%, transparent)`,
                                }
                              : undefined
                          }
                        >
                          <div className="min-w-0 pr-2">
                            <div className="flex items-center gap-2">
                              <p className={`text-xs font-bold ${headingText}`}>
                                {isEn ? selectedFont?.nameEn : selectedFont?.nameBn}
                              </p>
                              <span
                                className="text-[9px] font-bold px-1.5 py-0.5 rounded"
                                style={{
                                  backgroundColor: `color-mix(in srgb, ${dualAccent.primary.hex} 15%, transparent)`,
                                  color: dualAccent.primary.hex,
                                }}
                              >
                                {selectedFont?.category === 'en' ? 'EN' : 'বাং'}
                              </span>
                            </div>
                            <p className={`text-sm mt-0.5 truncate ${selectedFont?.fontClass} ${isLight ? 'text-slate-800' : 'text-slate-200'}`}>
                              {selectedFont?.sample}
                            </p>
                          </div>

                          <div className="shrink-0 flex items-center gap-2">
                            <div
                              className="w-7 h-7 rounded-xl flex items-center justify-center transition-transform duration-200"
                              style={{
                                backgroundColor: `color-mix(in srgb, ${dualAccent.primary.hex} 15%, transparent)`,
                                color: dualAccent.primary.hex,
                                transform: isFontDropdownOpen ? 'rotate(180deg)' : 'rotate(0deg)',
                              }}
                            >
                              <ChevronDown className="w-4 h-4" />
                            </div>
                          </div>
                        </button>

                        {/* Dropdown Menu Popup */}
                        <AnimatePresence>
                          {isFontDropdownOpen && (
                            <motion.div
                              initial={{ opacity: 0, y: -6, scale: 0.98 }}
                              animate={{ opacity: 1, y: 0, scale: 1 }}
                              exit={{ opacity: 0, y: -6, scale: 0.98 }}
                              transition={{ duration: 0.15 }}
                              className={`absolute z-30 left-0 right-0 mt-2 p-2 rounded-2xl border shadow-xl max-h-72 overflow-y-auto no-scrollbar ${
                                isLight
                                  ? 'bg-white/95 backdrop-blur-md border-slate-200 shadow-slate-300/50'
                                  : 'bg-slate-800/95 backdrop-blur-md border-slate-700 shadow-black/50'
                              }`}
                            >
                              {/* English Fonts Group */}
                              <div className="px-2.5 py-1.5 text-[10px] font-black uppercase tracking-wider text-slate-400 dark:text-slate-500 flex items-center justify-between border-b border-black/5 dark:border-white/5 mb-1">
                                <span>{isEn ? 'English & Modern Fonts' : 'ইংরেজি ও আধুনিক ফন্ট'}</span>
                                <span className="text-[9px] font-mono opacity-70">
                                  {FONT_FAMILY_OPTIONS.filter((f) => f.category === 'en').length} Fonts
                                </span>
                              </div>
                              <div className="space-y-1 mb-2">
                                {FONT_FAMILY_OPTIONS.filter((f) => f.category === 'en').map((f) => {
                                  const isSelected = (appSettings.fontFamily || 'system') === f.id;
                                  return (
                                    <button
                                      key={f.id}
                                      type="button"
                                      onClick={() => {
                                        onUpdateSettings({ ...appSettings, fontFamily: f.id });
                                        setIsFontDropdownOpen(false);
                                      }}
                                      className={`w-full p-2.5 rounded-xl text-left flex items-center justify-between transition cursor-pointer ${
                                        isSelected
                                          ? 'font-bold shadow-xs'
                                          : isLight
                                          ? 'hover:bg-slate-100/80 text-slate-700'
                                          : 'hover:bg-slate-700/60 text-slate-200'
                                      }`}
                                      style={
                                        isSelected
                                          ? {
                                              backgroundColor: `color-mix(in srgb, ${dualAccent.primary.hex} 15%, transparent)`,
                                              color: dualAccent.primary.hex,
                                              boxShadow: `0 0 0 1px color-mix(in srgb, ${dualAccent.primary.hex} 35%, transparent)`,
                                            }
                                          : undefined
                                      }
                                    >
                                      <div className="min-w-0 pr-2">
                                        <p className="text-xs font-bold leading-tight">{isEn ? f.nameEn : f.nameBn}</p>
                                        <p className={`text-xs mt-0.5 truncate ${f.fontClass} opacity-80`}>
                                          {f.sample}
                                        </p>
                                      </div>
                                      {isSelected && (
                                        <span
                                          className="w-5 h-5 rounded-full flex items-center justify-center text-white shrink-0 shadow-xs"
                                          style={{ backgroundColor: dualAccent.primary.hex }}
                                        >
                                          <Check className="w-3 h-3 stroke-[3]" />
                                        </span>
                                      )}
                                    </button>
                                  );
                                })}
                              </div>

                              {/* Bengali Fonts Group */}
                              <div className="px-2.5 py-1.5 text-[10px] font-black uppercase tracking-wider text-slate-400 dark:text-slate-500 flex items-center justify-between border-b border-black/5 dark:border-white/5 mb-1">
                                <span>{isEn ? 'Bengali Fonts' : 'বাংলা ফন্ট'}</span>
                                <span className="text-[9px] font-mono opacity-70">3 Fonts</span>
                              </div>
                              <div className="space-y-1">
                                {FONT_FAMILY_OPTIONS.filter((f) => f.category === 'bn').map((f) => {
                                  const isSelected = (appSettings.fontFamily || 'system') === f.id;
                                  return (
                                    <button
                                      key={f.id}
                                      type="button"
                                      onClick={() => {
                                        onUpdateSettings({ ...appSettings, fontFamily: f.id });
                                        setIsFontDropdownOpen(false);
                                      }}
                                      className={`w-full p-2.5 rounded-xl text-left flex items-center justify-between transition cursor-pointer ${
                                        isSelected
                                          ? 'font-bold shadow-xs'
                                          : isLight
                                          ? 'hover:bg-slate-100/80 text-slate-700'
                                          : 'hover:bg-slate-700/60 text-slate-200'
                                      }`}
                                      style={
                                        isSelected
                                          ? {
                                              backgroundColor: `color-mix(in srgb, ${dualAccent.primary.hex} 15%, transparent)`,
                                              color: dualAccent.primary.hex,
                                              boxShadow: `0 0 0 1px color-mix(in srgb, ${dualAccent.primary.hex} 35%, transparent)`,
                                            }
                                          : undefined
                                      }
                                    >
                                      <div className="min-w-0 pr-2">
                                        <p className="text-xs font-bold leading-tight">{isEn ? f.nameEn : f.nameBn}</p>
                                        <p className={`text-xs mt-0.5 truncate ${f.fontClass} opacity-80`}>
                                          {f.sample}
                                        </p>
                                      </div>
                                      {isSelected && (
                                        <span
                                          className="w-5 h-5 rounded-full flex items-center justify-center text-white shrink-0 shadow-xs"
                                          style={{ backgroundColor: dualAccent.primary.hex }}
                                        >
                                          <Check className="w-3 h-3 stroke-[3]" />
                                        </span>
                                      )}
                                    </button>
                                  );
                                })}
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    </div>

                    {/* 2 & 3. Font Size & Weight Bars Unified Section */}
                    <div className="p-3.5 rounded-2xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 space-y-3.5">
                      {/* Font Size Bar */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <label className={`text-xs font-bold flex items-center gap-1.5 ${headingText}`}>
                            <Sliders className="w-3.5 h-3.5" style={{ color: dualAccent.primary.hex }} />
                            <span>{isEn ? 'Font Size Bar' : 'ফন্ট সাইজ বার (Font Size)'}</span>
                          </label>
                          <span
                            className="text-[10px] font-black font-mono px-2 py-0.5 rounded-md border border-black/10 dark:border-white/10"
                            style={{
                              color: dualAccent.primary.hex,
                              backgroundColor: `color-mix(in srgb, ${dualAccent.primary.hex} 12%, transparent)`,
                            }}
                          >
                            {isEn ? activeSize.nameEn : activeSize.nameBn.split(' ')[0]} • {activeSize.scale}
                          </span>
                        </div>

                        {/* Range slider bar with point dots */}
                        <div className="relative flex items-center py-1">
                          <input
                            type="range"
                            min="0"
                            max="3"
                            step="1"
                            id="font-size-range-bar"
                            aria-label="Font Size"
                            value={currentSizeIndex}
                            onChange={(e) => {
                              const idx = Number(e.target.value);
                              onUpdateSettings({ ...appSettings, fontSize: FONT_SIZE_OPTIONS[idx].id });
                            }}
                            className="w-full h-3 rounded-lg appearance-none cursor-pointer shadow-inner border border-black/10 dark:border-white/15 relative z-10"
                            style={{
                              background: `linear-gradient(to right, ${dualAccent.primary.hex} 0%, ${dualAccent.primary.hex} ${(currentSizeIndex / 3) * 100}%, ${isLight ? '#cbd5e1' : '#475569'} ${(currentSizeIndex / 3) * 100}%, ${isLight ? '#cbd5e1' : '#475569'} 100%)`,
                              accentColor: dualAccent.primary.hex,
                            }}
                          />
                          {/* Point indicator dots along the bar */}
                          <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 pointer-events-none z-20 flex items-center">
                            {[0, 1, 2, 3].map((idx) => {
                              const isPassed = idx < currentSizeIndex;
                              const isCurrent = idx === currentSizeIndex;
                              return (
                                <span
                                  key={idx}
                                  className={`absolute rounded-full -translate-x-1/2 transition-all duration-200 ${
                                    isCurrent
                                      ? 'w-2 h-2 bg-white ring-2 ring-black/20 shadow-xs'
                                      : isPassed
                                      ? 'w-1.5 h-1.5 bg-white/90 shadow-xs'
                                      : isLight
                                      ? 'w-1.5 h-1.5 bg-slate-400'
                                      : 'w-1.5 h-1.5 bg-slate-500'
                                  }`}
                                  style={{
                                    left: `calc(9px + (100% - 18px) * (${idx} / 3))`,
                                  }}
                                />
                              );
                            })}
                          </div>
                        </div>
                      </div>

                      {/* Subtle divider between bars */}
                      <div className="h-px bg-black/5 dark:bg-white/5" />

                      {/* Font Weight / Wide Bar */}
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <label className={`text-xs font-bold flex items-center gap-1.5 ${headingText}`}>
                            <Layers className="w-3.5 h-3.5" style={{ color: dualAccent.primary.hex }} />
                            <span>{isEn ? 'Font Weight / Wide Bar' : 'ফন্ট ওয়াইড বার (Font Weight)'}</span>
                          </label>
                          <span
                            className="text-[10px] font-black font-mono px-2 py-0.5 rounded-md border border-black/10 dark:border-white/10"
                            style={{
                              color: dualAccent.primary.hex,
                              backgroundColor: `color-mix(in srgb, ${dualAccent.primary.hex} 12%, transparent)`,
                            }}
                          >
                            {isEn ? activeWeight.nameEn : activeWeight.nameBn.split(' ')[0]} • {activeWeight.weightName}
                          </span>
                        </div>

                        {/* Range slider bar with point dots */}
                        <div className="relative flex items-center py-1">
                          <input
                            type="range"
                            min="0"
                            max="3"
                            step="1"
                            id="font-weight-range-bar"
                            aria-label="Font Weight"
                            value={currentWeightIndex}
                            onChange={(e) => {
                              const idx = Number(e.target.value);
                              onUpdateSettings({ ...appSettings, fontWeight: FONT_WEIGHT_OPTIONS[idx].id });
                            }}
                            className="w-full h-3 rounded-lg appearance-none cursor-pointer shadow-inner border border-black/10 dark:border-white/15 relative z-10"
                            style={{
                              background: `linear-gradient(to right, ${dualAccent.primary.hex} 0%, ${dualAccent.primary.hex} ${(currentWeightIndex / 3) * 100}%, ${isLight ? '#cbd5e1' : '#475569'} ${(currentWeightIndex / 3) * 100}%, ${isLight ? '#cbd5e1' : '#475569'} 100%)`,
                              accentColor: dualAccent.primary.hex,
                            }}
                          />
                          {/* Point indicator dots along the bar */}
                          <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 pointer-events-none z-20 flex items-center">
                            {[0, 1, 2, 3].map((idx) => {
                              const isPassed = idx < currentWeightIndex;
                              const isCurrent = idx === currentWeightIndex;
                              return (
                                <span
                                  key={idx}
                                  className={`absolute rounded-full -translate-x-1/2 transition-all duration-200 ${
                                    isCurrent
                                      ? 'w-2 h-2 bg-white ring-2 ring-black/20 shadow-xs'
                                      : isPassed
                                      ? 'w-1.5 h-1.5 bg-white/90 shadow-xs'
                                      : isLight
                                      ? 'w-1.5 h-1.5 bg-slate-400'
                                      : 'w-1.5 h-1.5 bg-slate-500'
                                  }`}
                                  style={{
                                    left: `calc(9px + (100% - 18px) * (${idx} / 3))`,
                                  }}
                                />
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* 4. Live Font Preview Card */}
                    <div className={`p-4 rounded-2xl border ${modalInnerBg} space-y-3`}>
                      <div className="flex items-center justify-between text-xs font-bold">
                        <span className="flex items-center gap-1.5 text-cyan-600 dark:text-cyan-400">
                          <Eye className="w-4 h-4" />
                          <span>{isEn ? 'Live Font Preview' : 'লাইভ ফন্ট প্রিভিউ'}</span>
                        </span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-black/5 dark:bg-white/10">
                          {appSettings.fontFamily || 'system'} • {appSettings.fontSize || 'medium'} • {appSettings.fontWeight || 'medium'}
                        </span>
                      </div>

                      <div
                        className={`p-3.5 rounded-xl border ${
                          isLight ? 'bg-white border-slate-200/90' : 'bg-slate-900/90 border-slate-700/60'
                        } space-y-1.5 transition-all`}
                        style={{
                          fontFamily: getFontCssString(appSettings.fontFamily),
                          fontWeight:
                            appSettings.fontWeight === 'normal'
                              ? 400
                              : appSettings.fontWeight === 'medium'
                              ? 500
                              : appSettings.fontWeight === 'semibold'
                              ? 600
                              : 700,
                          fontSize:
                            appSettings.fontSize === 'small'
                              ? '0.92rem'
                              : appSettings.fontSize === 'medium'
                              ? '1rem'
                              : appSettings.fontSize === 'large'
                              ? '1.1rem'
                              : '1.2rem',
                        }}
                      >
                        <h4 className={`text-base leading-snug font-bold ${headingText}`}>
                          {isEn ? 'Onu Finance - Smart Financial Manager' : 'Onu Finance - আধুনিক বাংলা হিসাব কিতাব'}
                        </h4>
                        <p className={`text-xs ${subText}`}>
                          {isEn
                            ? 'Effortlessly track expenses, daily shopping, and monthly savings.'
                            : 'দৈনিক বাজার খরচ, আয়-ব্যয় এবং সঞ্চয়ের নিরাপদ হিসাব রাখুন।'}
                        </p>
                        <div className="pt-2 flex items-center justify-between">
                          <span className="text-sm font-black text-emerald-600 dark:text-emerald-400">
                            {appSettings.currencySymbol} {appSettings.useBanglaDigits ? '৫৪,২৫০.০০' : '54,250.00'}
                          </span>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 border border-emerald-500/20">
                            {isEn ? '+12.5% Growth' : '+১২.৫% সঞ্চয়'}
                          </span>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>

              {/* Modal Footer */}
              <div className={`p-4 border-t flex items-center justify-between ${isLight ? 'border-slate-200 bg-slate-50/50' : 'border-slate-800 bg-slate-900/50'}`}>
                <button
                  type="button"
                  onClick={() => {
                    if (themeModalTab === 'theme_color') {
                      onUpdateSettings({
                        ...appSettings,
                        themeMode: 'light',
                        themeAccent: 'green',
                        secondaryAccent: 'cyan',
                        accentPercentage: 50,
                      });
                    } else {
                      onUpdateSettings({
                        ...appSettings,
                        fontFamily: 'system',
                        fontSize: 'medium',
                        fontWeight: 'medium',
                      });
                    }
                  }}
                  className="text-xs font-bold text-rose-500 hover:text-rose-600 flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>
                    {themeModalTab === 'theme_color'
                      ? isEn ? 'Reset Theme' : 'ডিফল্ট থিম'
                      : isEn ? 'Reset Font' : 'ডিফল্ট ফন্ট'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsThemeModalOpen(false)}
                  className="px-5 py-2.5 rounded-2xl text-white font-bold text-xs shadow-md transition cursor-pointer"
                  style={{ backgroundColor: dualAccent.primary.hex }}
                >
                  {isEn ? 'Save & Close' : 'সংরক্ষণ ও বন্ধ করুন'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* =========================================================================
          POPUP MODAL 2: 🌐 LANGUAGE, NUMERALS & CURRENCY POPUP
          ========================================================================= */}
      <AnimatePresence>
        {isLanguageModalOpen && (
          <div
            className={`fixed inset-0 z-50 flex items-center justify-center ${
              isLight ? 'bg-slate-900/40 backdrop-blur-xs' : 'bg-black/75 backdrop-blur-xs'
            } p-3 sm:p-4 animate-in fade-in duration-200`}
          >
            {/* Backdrop click */}
            <div className="absolute inset-0" onClick={() => setIsLanguageModalOpen(false)} />

            {/* Modal Dialog */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.2, ease: 'easeOut' }}
              className={`relative z-10 w-full max-w-lg max-h-[90vh] flex flex-col rounded-3xl shadow-2xl border ${modalBg} overflow-hidden`}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Modal Header */}
              <div className={`p-4 sm:p-5 border-b flex items-center justify-between gap-3 ${isLight ? 'border-slate-200' : 'border-slate-800'}`}>
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-2xl text-white bg-cyan-500 shadow-sm flex items-center justify-center">
                    <Languages className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-black tracking-tight">
                      {isEn ? 'Language & Currency Settings' : 'ভাষা ও মুদ্রা সেটিংস'}
                    </h3>
                    <p className={`text-xs ${subText}`}>
                      {isEn ? 'Select language, numeral style, and currency' : 'ভাষা, সংখ্যা ফরম্যাট ও মুদ্রা প্রতীক নির্বাচন'}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setIsLanguageModalOpen(false)}
                  className={`p-2 rounded-xl transition cursor-pointer ${
                    isLight ? 'hover:bg-slate-100 text-slate-500' : 'hover:bg-slate-800 text-slate-400'
                  }`}
                  aria-label="Close"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Body (Scrollable) */}
              <div className="p-4 sm:p-5 space-y-5 overflow-y-auto no-scrollbar">
                {/* 1. Language Choice */}
                <div className="space-y-2">
                  <label className={`text-xs font-bold flex items-center gap-1.5 ${headingText}`}>
                    <Globe2 className="w-3.5 h-3.5 text-cyan-500" />
                    <span>{isEn ? 'App Interface Language' : 'অ্যাপের ভাষা'}</span>
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() =>
                        onUpdateSettings({
                          ...appSettings,
                          language: 'bn',
                          useBanglaDigits: true,
                        })
                      }
                      className={`p-3.5 rounded-2xl border text-left flex items-center justify-between transition cursor-pointer ${
                        appSettings.language === 'bn'
                          ? 'border-cyan-500 bg-cyan-500/10 text-cyan-700 dark:text-cyan-300 ring-2 ring-cyan-500/30'
                          : isLight
                          ? 'border-slate-200 hover:bg-slate-50 text-slate-800'
                          : 'border-slate-700 hover:bg-slate-800 text-slate-200'
                      }`}
                    >
                      <div>
                        <div className="font-black text-sm">🇧🇩 বাংলা</div>
                        <div className="text-[11px] text-slate-500 mt-0.5">বাংলাদেশ (Bengali)</div>
                      </div>
                      {appSettings.language === 'bn' && <CheckCircle2 className="w-5 h-5 text-cyan-500 shrink-0" />}
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        onUpdateSettings({
                          ...appSettings,
                          language: 'en',
                          useBanglaDigits: false,
                        })
                      }
                      className={`p-3.5 rounded-2xl border text-left flex items-center justify-between transition cursor-pointer ${
                        appSettings.language === 'en'
                          ? 'border-cyan-500 bg-cyan-500/10 text-cyan-700 dark:text-cyan-300 ring-2 ring-cyan-500/30'
                          : isLight
                          ? 'border-slate-200 hover:bg-slate-50 text-slate-800'
                          : 'border-slate-700 hover:bg-slate-800 text-slate-200'
                      }`}
                    >
                      <div>
                        <div className="font-black text-sm">🌐 English</div>
                        <div className="text-[11px] text-slate-500 mt-0.5">International (US)</div>
                      </div>
                      {appSettings.language === 'en' && <CheckCircle2 className="w-5 h-5 text-cyan-500 shrink-0" />}
                    </button>
                  </div>
                </div>

                {/* 2. Numeral Format */}
                <div className="space-y-2">
                  <label className={`text-xs font-bold flex items-center gap-1.5 ${headingText}`}>
                    <Binary className="w-3.5 h-3.5 text-emerald-500" />
                    <span>{isEn ? 'Number Style (Digits)' : 'সংখ্যার ফরম্যাট'}</span>
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() =>
                        onUpdateSettings({
                          ...appSettings,
                          useBanglaDigits: true,
                        })
                      }
                      className={`p-3 rounded-2xl border text-center font-bold text-xs transition cursor-pointer ${
                        appSettings.useBanglaDigits
                          ? 'border-emerald-500 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 ring-2 ring-emerald-500/30'
                          : isLight
                          ? 'border-slate-200 text-slate-700 hover:bg-slate-50'
                          : 'border-slate-700 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <div className="text-sm font-black">০, ১, ২, ৩, ৪...</div>
                      <div className="text-[10px] text-slate-500 mt-0.5">{isEn ? 'Bengali Digits' : 'বাংলা সংখ্যা'}</div>
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        onUpdateSettings({
                          ...appSettings,
                          useBanglaDigits: false,
                        })
                      }
                      className={`p-3 rounded-2xl border text-center font-bold text-xs transition cursor-pointer ${
                        !appSettings.useBanglaDigits
                          ? 'border-emerald-500 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 ring-2 ring-emerald-500/30'
                          : isLight
                          ? 'border-slate-200 text-slate-700 hover:bg-slate-50'
                          : 'border-slate-700 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <div className="text-sm font-black">0, 1, 2, 3, 4...</div>
                      <div className="text-[10px] text-slate-500 mt-0.5">{isEn ? 'English Digits' : 'ইংরেজি সংখ্যা'}</div>
                    </button>
                  </div>
                </div>

                {/* 3. Currency Symbol */}
                <div className="space-y-2">
                  <label className={`text-xs font-bold flex items-center gap-1.5 ${headingText}`}>
                    <DollarSign className="w-3.5 h-3.5 text-amber-500" />
                    <span>{isEn ? 'Currency Symbol' : 'মুদ্রা প্রতীক'}</span>
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {CURRENCY_OPTIONS.map((cur) => {
                      const isSelected = appSettings.currencySymbol === cur.symbol;
                      return (
                        <button
                          key={cur.code}
                          type="button"
                          onClick={() =>
                            onUpdateSettings({
                              ...appSettings,
                              currencySymbol: cur.symbol,
                            })
                          }
                          className={`p-2.5 rounded-2xl border text-center font-bold text-xs transition cursor-pointer ${
                            isSelected
                              ? 'border-amber-500 bg-amber-500/10 text-amber-700 dark:text-amber-300 ring-2 ring-amber-500/30'
                              : isLight
                              ? 'border-slate-200 text-slate-700 hover:bg-slate-50'
                              : 'border-slate-700 text-slate-300 hover:bg-slate-800'
                          }`}
                        >
                          <div className="text-base font-black">{cur.symbol}</div>
                          <div className="text-[10px] truncate text-slate-500">{cur.code}</div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Live Currency Preview */}
                <div className={`p-3.5 rounded-2xl border ${modalInnerBg} flex items-center justify-between`}>
                  <span className="text-xs font-bold text-slate-600 dark:text-slate-400">
                    {isEn ? 'Formatted Sample:' : 'নমুনা হিসাব প্রদর্শন:'}
                  </span>
                  <span className="text-sm font-black text-emerald-600 dark:text-emerald-400">
                    {formatCurrency(54200, appSettings.useBanglaDigits, appSettings.currencySymbol)}
                  </span>
                </div>
              </div>

              {/* Modal Footer */}
              <div className={`p-4 border-t flex items-center justify-end ${isLight ? 'border-slate-200 bg-slate-50/50' : 'border-slate-800 bg-slate-900/50'}`}>
                <button
                  type="button"
                  onClick={() => setIsLanguageModalOpen(false)}
                  className="px-6 py-2.5 rounded-2xl text-white font-bold text-xs shadow-md bg-cyan-600 hover:bg-cyan-700 transition cursor-pointer"
                >
                  {isEn ? 'Done' : 'সম্পন্ন করুন'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* =========================================================================
          POPUP MODAL 3: 🛡️ SECURITY & CLOUD BACKUP POPUP (FULL FEATURED)
          ========================================================================= */}
      <SecurityPopupMenuModal
        isOpen={isSecurityModalOpen}
        onClose={() => setIsSecurityModalOpen(false)}
        initialTab={securityModalInitialTab}
        securitySettings={activeSecurity}
        onUpdateSecurity={(newSec) => {
          if (onUpdateSecurity) onUpdateSecurity(newSec);
          else storage.saveSecuritySettings(newSec);
        }}
        appSettings={appSettings}
        onUpdateSettings={onUpdateSettings}
        onLockNow={() => {
          setIsSecurityModalOpen(false);
          if (onLockNow) onLockNow();
        }}
        isSyncingDrive={isSyncingDrive}
        syncStatusMsg={syncStatusMsg}
        onTriggerSync={handleTriggerSync}
        onDownloadBackup={handleDownloadBackup}
        onFileUpload={handleFileUpload}
        autoSnapshots={storage.getAutoBackupSnapshots()}
        onResetAllData={onResetAllData}
      />

      {/* =========================================================================
          POPUP MODAL 4: 📊 EXPORT REPORT MODAL
          ========================================================================= */}
      <ExportReportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        transactions={activeTransactions}
        categories={activeCategories}
        accounts={accounts}
        userProfile={userProfile}
        appSettings={appSettings}
      />

      {/* =========================================================================
          POPUP MODAL 0: 👤 USER PROFILE & OPENING BALANCE & AUDIT HISTORY
          ========================================================================= */}
      <UserProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        userProfile={activeUserProfile}
        onSaveProfile={(updatedProfile) => {
          if (onSaveUserProfile) onSaveUserProfile(updatedProfile);
          else storage.saveUserProfile(updatedProfile);
        }}
        accounts={activeAccounts}
        onSaveOpeningBalances={(updatedAccounts) => {
          if (onSaveOpeningBalances) onSaveOpeningBalances(updatedAccounts);
          else storage.saveAccounts(updatedAccounts);
        }}
        auditLogs={activeAuditLogs}
        onClearHistory={onClearHistory}
        appSettings={appSettings}
        onOpenManageCategories={onOpenManageCategories}
      />
    </div>
  );
};
