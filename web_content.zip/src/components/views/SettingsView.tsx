import React from 'react';
import {
  Palette,
  Moon,
  Sun,
  Smartphone,
  Monitor,
  Trash2,
  HardDrive,
  Cpu,
  ShieldCheck,
  Info,
  Sparkles,
  Check
} from 'lucide-react';
import { AppThemeSettings } from '../../types';
import { clearAllDocumentHistory } from '../../services/storageService';

interface SettingsViewProps {
  themeSettings: AppThemeSettings;
  onUpdateThemeSettings: (newSettings: Partial<AppThemeSettings>) => void;
  documentCount: number;
  totalSizeBytes: number;
  onHistoryCleared: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  themeSettings,
  onUpdateThemeSettings,
  documentCount,
  totalSizeBytes,
  onHistoryCleared
}) => {
  const dynamicColorPresets = [
    { name: 'Pixel Blue', hex: '#1972E8', bgClass: 'bg-blue-600' },
    { name: 'Jade Mint', hex: '#0F766E', bgClass: 'bg-teal-600' },
    { name: 'Modern Violet', hex: '#7C3AED', bgClass: 'bg-purple-600' },
    { name: 'Warm Amber', hex: '#D97706', bgClass: 'bg-amber-600' },
    { name: 'Coral Rose', hex: '#E11D48', bgClass: 'bg-rose-600' }
  ];

  const handleClear = () => {
    if (confirm('Clear all document history and cached files?')) {
      clearAllDocumentHistory();
      onHistoryCleared();
    }
  };

  const mbUsed = (totalSizeBytes / (1024 * 1024)).toFixed(2);

  return (
    <div className="flex-1 p-4 overflow-y-auto space-y-5 pb-20">
      {/* Material You Dynamic Theme Section */}
      <div className="rounded-3xl bg-white dark:bg-neutral-800 p-4 border border-neutral-200 dark:border-neutral-700 shadow-xs space-y-3">
        <div className="flex items-center gap-2">
          <Palette className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          <h3 className="text-xs font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider">
            Material 3 Theme & Accent
          </h3>
        </div>

        {/* Dynamic Color Palette */}
        <div>
          <span className="block text-[11px] font-semibold text-neutral-500 mb-2">
            Material You Dynamic Color
          </span>
          <div className="flex items-center gap-2">
            {dynamicColorPresets.map((preset) => {
              const isSelected = themeSettings.primaryColor === preset.hex;
              return (
                <button
                  key={preset.name}
                  type="button"
                  onClick={() => onUpdateThemeSettings({ primaryColor: preset.hex })}
                  title={preset.name}
                  className={`w-9 h-9 rounded-2xl ${preset.bgClass} flex items-center justify-center text-white transition-all ${
                    isSelected ? 'ring-3 ring-blue-500/50 scale-105 shadow-md' : 'opacity-80'
                  }`}
                >
                  {isSelected && <Check className="w-4 h-4 stroke-[3]" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Dark Mode & Device Mode Switches */}
        <div className="pt-2 border-t border-neutral-100 dark:border-neutral-700 space-y-2">
          <div className="flex items-center justify-between py-1">
            <div>
              <p className="text-xs font-bold text-neutral-900 dark:text-neutral-100">Dark Theme</p>
              <p className="text-[10px] text-neutral-500">Enable AMOLED dark surface styling</p>
            </div>
            <button
              type="button"
              onClick={() => onUpdateThemeSettings({ isDark: !themeSettings.isDark })}
              className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                themeSettings.isDark ? 'bg-blue-600' : 'bg-neutral-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  themeSettings.isDark ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between py-1">
            <div>
              <p className="text-xs font-bold text-neutral-900 dark:text-neutral-100">
                View Mode
              </p>
              <p className="text-[10px] text-neutral-500">
                {themeSettings.deviceMode === 'phone'
                  ? 'Pixel 8 Smartphone Frame'
                  : 'Full Adaptive Studio'}
              </p>
            </div>
            <div className="flex items-center gap-1 bg-neutral-100 dark:bg-neutral-700 p-0.5 rounded-xl text-xs font-bold">
              <button
                type="button"
                onClick={() => onUpdateThemeSettings({ deviceMode: 'phone' })}
                className={`p-1.5 rounded-lg flex items-center gap-1 ${
                  themeSettings.deviceMode === 'phone'
                    ? 'bg-white dark:bg-neutral-800 text-blue-600 dark:text-blue-400 shadow-xs'
                    : 'text-neutral-600 dark:text-neutral-300'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Phone</span>
              </button>
              <button
                type="button"
                onClick={() => onUpdateThemeSettings({ deviceMode: 'full' })}
                className={`p-1.5 rounded-lg flex items-center gap-1 ${
                  themeSettings.deviceMode === 'full'
                    ? 'bg-white dark:bg-neutral-800 text-blue-600 dark:text-blue-400 shadow-xs'
                    : 'text-neutral-600 dark:text-neutral-300'
                }`}
              >
                <Monitor className="w-3.5 h-3.5" />
                <span>Full</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Storage Access Framework & Cache */}
      <div className="rounded-3xl bg-white dark:bg-neutral-800 p-4 border border-neutral-200 dark:border-neutral-700 shadow-xs space-y-3">
        <div className="flex items-center gap-2">
          <HardDrive className="w-4 h-4 text-emerald-600" />
          <h3 className="text-xs font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider">
            Document Storage
          </h3>
        </div>

        <div className="flex items-center justify-between p-3 rounded-2xl bg-neutral-50 dark:bg-neutral-900/60 text-xs">
          <div>
            <p className="font-bold text-neutral-900 dark:text-neutral-100">
              {documentCount} Saved Documents
            </p>
            <p className="text-[10px] text-neutral-500">{mbUsed} MB currently utilized</p>
          </div>
          <button
            type="button"
            onClick={handleClear}
            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-900 font-bold text-xs active:scale-95 transition-all"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear Cache</span>
          </button>
        </div>
      </div>

      {/* Architecture & Privacy Badges */}
      <div className="rounded-3xl bg-white dark:bg-neutral-800 p-4 border border-neutral-200 dark:border-neutral-700 shadow-xs space-y-2.5">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          <h3 className="text-xs font-bold text-neutral-900 dark:text-neutral-100 uppercase tracking-wider">
            Privacy & Architecture
          </h3>
        </div>

        <div className="space-y-2 text-xs">
          <div className="flex items-start gap-2 text-neutral-600 dark:text-neutral-300">
            <Cpu className="w-4 h-4 text-neutral-400 shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed">
              <strong className="text-neutral-900 dark:text-neutral-100">100% On-Device Processing:</strong> OCR, PDF generation, DOCX composition, file merging, and background segmentation execute privately on-device without third-party tracking.
            </p>
          </div>

          <div className="flex items-start gap-2 text-neutral-600 dark:text-neutral-300">
            <Sparkles className="w-4 h-4 text-sky-500 shrink-0 mt-0.5" />
            <p className="text-[11px] leading-relaxed">
              <strong className="text-neutral-900 dark:text-neutral-100">AI Assistant Security:</strong> Gemini layout inspections preserve author wording verbatim and require user confirmation before applying typography rules.
            </p>
          </div>
        </div>
      </div>

      {/* Version Card */}
      <div className="text-center py-2 space-y-1">
        <p className="text-xs font-bold text-neutral-800 dark:text-neutral-200">
          DocuForge Studio v1.0.0
        </p>
        <p className="text-[10px] text-neutral-400">
          Android Jetpack Compose & Material Design 3 Architecture
        </p>
      </div>
    </div>
  );
};
