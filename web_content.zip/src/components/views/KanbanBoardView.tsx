import React, { useState } from "react";
import {
  FolderKanban,
  Plus,
  MoreVertical,
  Pin,
  Star,
  CheckSquare,
  Tag,
  ArrowRight,
  MoveHorizontal,
  Sparkles,
  Layers,
  Edit3,
  Trash2
} from "lucide-react";
import { Note, SectionItem } from "../../types";

interface KanbanBoardViewProps {
  notes: Note[];
  categories: string[];
  sections?: SectionItem[];
  onOpenNote: (note: Note) => void;
  onOpenNewNoteInCategory: (category: string) => void;
  onChangeCategory: (noteId: string, newCategory: string) => void;
  onTogglePin: (id: string, e: React.MouseEvent) => void;
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
  onDeleteNote: (id: string, e: React.MouseEvent) => void;
}

type GroupByMode = "category" | "status" | "priority";

export const KanbanBoardView: React.FC<KanbanBoardViewProps> = ({
  notes,
  categories,
  onOpenNote,
  onOpenNewNoteInCategory,
  onChangeCategory,
  onTogglePin,
  onToggleFavorite,
  onDeleteNote,
}) => {
  const [groupBy, setGroupBy] = useState<GroupByMode>("category");
  const [draggedNoteId, setDraggedNoteId] = useState<string | null>(null);
  const [moveMenuNoteId, setMoveMenuNoteId] = useState<string | null>(null);

  // Determine columns based on groupBy mode
  let columns: { id: string; title: string; color: string; notes: Note[] }[] = [];

  if (groupBy === "category") {
    const allCategories = Array.from(
      new Set([
        "Genel",
        ...categories,
        ...notes.map((n) => n.category || "Genel"),
      ])
    ).filter(Boolean);

    columns = allCategories.map((cat, idx) => {
      const catNotes = notes.filter((n) => (n.category || "Genel") === cat);
      const colorPalette = [
        "border-teal-500 bg-teal-500/10 text-teal-700 dark:text-teal-300",
        "border-blue-500 bg-blue-500/10 text-blue-700 dark:text-blue-300",
        "border-purple-500 bg-purple-500/10 text-purple-700 dark:text-purple-300",
        "border-amber-500 bg-amber-500/10 text-amber-700 dark:text-amber-300",
        "border-emerald-500 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300",
        "border-rose-500 bg-rose-500/10 text-rose-700 dark:text-rose-300",
      ];
      return {
        id: cat,
        title: cat,
        color: colorPalette[idx % colorPalette.length],
        notes: catNotes,
      };
    });
  } else if (groupBy === "status") {
    const todoNotes = notes.filter(
      (n) => n.tasks && n.tasks.length > 0 && n.tasks.some((t) => !t.completed)
    );
    const completedNotes = notes.filter(
      (n) => n.tasks && n.tasks.length > 0 && n.tasks.every((t) => t.completed)
    );
    const generalNotes = notes.filter((n) => !n.tasks || n.tasks.length === 0);

    columns = [
      {
        id: "Yapılacaklar",
        title: "📌 Yapılacaklar (To-Do)",
        color: "border-amber-500 bg-amber-500/10 text-amber-700 dark:text-amber-300",
        notes: todoNotes,
      },
      {
        id: "Genel Notlar",
        title: "📝 Genel & Bilgiler",
        color: "border-blue-500 bg-blue-500/10 text-blue-700 dark:text-blue-300",
        notes: generalNotes,
      },
      {
        id: "Tamamlananlar",
        title: "✅ Tamamlanan Görevler",
        color: "border-emerald-500 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300",
        notes: completedNotes,
      },
    ];
  } else {
    // Priority / Pin
    columns = [
      {
        id: "Sabitlenenler",
        title: "📌 Sabitlenen Önemli Notlar",
        color: "border-rose-500 bg-rose-500/10 text-rose-700 dark:text-rose-300",
        notes: notes.filter((n) => n.pinned),
      },
      {
        id: "Favoriler",
        title: "⭐ Favori Notlar",
        color: "border-amber-500 bg-amber-500/10 text-amber-700 dark:text-amber-300",
        notes: notes.filter((n) => n.favorite && !n.pinned),
      },
      {
        id: "Diğer Notlar",
        title: "📑 Standart Notlar",
        color: "border-slate-500 bg-slate-500/10 text-slate-700 dark:text-slate-300",
        notes: notes.filter((n) => !n.pinned && !n.favorite),
      },
    ];
  }

  // Drag & Drop Handlers
  const handleDragStart = (e: React.DragEvent, noteId: string) => {
    e.dataTransfer.setData("text/plain", noteId);
    setDraggedNoteId(noteId);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, targetColumnId: string) => {
    e.preventDefault();
    const noteId = e.dataTransfer.getData("text/plain") || draggedNoteId;
    if (noteId && groupBy === "category") {
      onChangeCategory(noteId, targetColumnId);
    }
    setDraggedNoteId(null);
  };

  return (
    <div className="space-y-4 animate-in fade-in">
      {/* Kanban Mode Switcher Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-teal-100 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400">
            <FolderKanban className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
              <span>Kanban Süreç Panosu</span>
              <span className="text-[10px] bg-teal-100 dark:bg-teal-900/60 text-teal-700 dark:text-teal-300 px-2 py-0.5 rounded-full font-extrabold">
                Sürükle & Bırak
              </span>
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Notlarınızı sütunlar halinde organize edin ve aralarında taşıyın
            </p>
          </div>
        </div>

        {/* Group By Filter Tabs */}
        <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold">
          <button
            onClick={() => setGroupBy("category")}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              groupBy === "category"
                ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-400 shadow-xs font-bold"
                : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            }`}
          >
            Kategorilere Göre
          </button>
          <button
            onClick={() => setGroupBy("status")}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              groupBy === "status"
                ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-400 shadow-xs font-bold"
                : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            }`}
          >
            Duruma Göre
          </button>
          <button
            onClick={() => setGroupBy("priority")}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              groupBy === "priority"
                ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-400 shadow-xs font-bold"
                : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            }`}
          >
            Öneme Göre
          </button>
        </div>
      </div>

      {/* Kanban Columns Container - Horizontally Scrollable */}
      <div className="flex items-start gap-4 overflow-x-auto pb-6 pt-1 snap-x scrollbar-thin">
        {columns.map((col) => (
          <div
            key={col.id}
            onDragOver={handleDragOver}
            onDrop={(e) => handleDrop(e, col.id)}
            className="w-80 shrink-0 snap-start flex flex-col bg-slate-100/80 dark:bg-slate-900/80 rounded-2xl border border-slate-200 dark:border-slate-800/80 p-3 max-h-[75vh] min-h-[420px]"
          >
            {/* Column Header */}
            <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-200/80 dark:border-slate-800">
              <div className="flex items-center gap-2 overflow-hidden">
                <div
                  className={`w-3 h-3 rounded-full border-2 ${col.color.split(" ")[0]} shrink-0`}
                />
                <h4 className="font-bold text-xs text-slate-800 dark:text-slate-200 truncate">
                  {col.title}
                </h4>
                <span className="text-[11px] font-mono font-bold bg-white dark:bg-slate-800 px-2 py-0.5 rounded-full text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 shrink-0">
                  {col.notes.length}
                </span>
              </div>

              {groupBy === "category" && (
                <button
                  onClick={() => onOpenNewNoteInCategory(col.id)}
                  title={`"${col.id}" kategorisine hızlı not ekle`}
                  className="p-1 text-slate-400 hover:text-teal-600 dark:hover:text-teal-400 hover:bg-white dark:hover:bg-slate-800 rounded-lg cursor-pointer transition-colors"
                >
                  <Plus className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Column Cards Container */}
            <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 scrollbar-thin">
              {col.notes.length === 0 ? (
                <div className="p-6 text-center border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl my-4">
                  <p className="text-xs text-slate-400 dark:text-slate-500">
                    Bu sütunda not yok
                  </p>
                  <p className="text-[10px] text-slate-400 dark:text-slate-600 mt-1">
                    Diğer sütunlardan sürükleyebilirsiniz
                  </p>
                </div>
              ) : (
                col.notes.map((note) => {
                  const completedTasksCount =
                    note.tasks?.filter((t) => t.completed).length || 0;
                  const totalTasksCount = note.tasks?.length || 0;

                  return (
                    <div
                      key={note.id}
                      draggable
                      onDragStart={(e) => handleDragStart(e, note.id)}
                      onClick={() => onOpenNote(note)}
                      className="group relative bg-white dark:bg-slate-800 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700/80 shadow-xs hover:shadow-md transition-all cursor-pointer hover:border-teal-400/80 dark:hover:border-teal-500/80"
                    >
                      {/* Top Bar: Pin, Favorite & Category */}
                      <div className="flex items-center justify-between gap-1 mb-2">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700/60 text-slate-600 dark:text-slate-300">
                          {note.category || "Genel"}
                        </span>

                        <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100">
                          <button
                            onClick={(e) => onTogglePin(note.id, e)}
                            title={note.pinned ? "İğneyi Kaldır" : "Sabitle"}
                            className={`p-1 rounded-md cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700 ${
                              note.pinned ? "text-rose-500 font-bold" : "text-slate-400"
                            }`}
                          >
                            <Pin className="w-3 h-3" />
                          </button>
                          <button
                            onClick={(e) => onToggleFavorite(note.id, e)}
                            title={note.favorite ? "Favorilerden Çıkar" : "Favoriye Ekle"}
                            className={`p-1 rounded-md cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-700 ${
                              note.favorite ? "text-amber-500 font-bold" : "text-slate-400"
                            }`}
                          >
                            <Star className="w-3 h-3 fill-current" />
                          </button>
                          <div className="relative">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setMoveMenuNoteId(
                                  moveMenuNoteId === note.id ? null : note.id
                                );
                              }}
                              className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-md cursor-pointer"
                              title="Kategori Değiştir / Taşı"
                            >
                              <MoveHorizontal className="w-3 h-3" />
                            </button>

                            {/* Quick Category Move Popup Menu */}
                            {moveMenuNoteId === note.id && (
                              <div
                                onClick={(e) => e.stopPropagation()}
                                className="absolute right-0 top-6 z-30 w-44 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-xl p-1.5 space-y-1 text-xs animate-in fade-in"
                              >
                                <p className="text-[10px] font-bold text-slate-400 dark:text-slate-500 px-2 py-0.5">
                                  Sütuna Taşı:
                                </p>
                                {categories.map((cat) => (
                                  <button
                                    key={cat}
                                    onClick={() => {
                                      onChangeCategory(note.id, cat);
                                      setMoveMenuNoteId(null);
                                    }}
                                    className={`w-full text-left px-2 py-1 rounded-lg hover:bg-teal-50 dark:hover:bg-teal-950/40 cursor-pointer flex items-center justify-between ${
                                      note.category === cat
                                        ? "font-bold text-teal-600"
                                        : "text-slate-700 dark:text-slate-300"
                                    }`}
                                  >
                                    <span>{cat}</span>
                                    {note.category === cat && <ArrowRight className="w-3 h-3 text-teal-600" />}
                                  </button>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Note Title */}
                      <h5 className="font-bold text-xs text-slate-900 dark:text-white line-clamp-2 mb-1">
                        {note.title || "Başlıksız Not"}
                      </h5>

                      {/* Snippet Content */}
                      {note.content && (
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 mb-2">
                          {note.content.replace(/<[^>]*>/g, "")}
                        </p>
                      )}

                      {/* Task items count indicator */}
                      {totalTasksCount > 0 && (
                        <div className="flex items-center gap-1.5 text-[10px] font-semibold text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-700/40 p-1.5 rounded-lg border border-slate-100 dark:border-slate-700 mb-2">
                          <CheckSquare className="w-3 h-3 text-teal-600" />
                          <span>
                            {completedTasksCount} / {totalTasksCount} Tamamlandı
                          </span>
                        </div>
                      )}

                      {/* Footer Tags & Date */}
                      <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-100 dark:border-slate-700/60">
                        <span className="font-mono">
                          {new Date(note.updatedAt || note.createdAt).toLocaleDateString("tr-TR", {
                            day: "numeric",
                            month: "short",
                          })}
                        </span>

                        {note.tags && note.tags.length > 0 && (
                          <span className="flex items-center gap-0.5 text-teal-600 dark:text-teal-400 font-medium">
                            <Tag className="w-2.5 h-2.5" />
                            <span>#{note.tags[0]}</span>
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Quick Add Note to Column */}
            {groupBy === "category" && (
              <button
                onClick={() => onOpenNewNoteInCategory(col.id)}
                className="w-full mt-2 py-2 border border-dashed border-slate-300 dark:border-slate-700 hover:border-teal-500 text-slate-500 dark:text-slate-400 hover:text-teal-600 dark:hover:text-teal-400 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{col.id}'ye Not Ekle</span>
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
