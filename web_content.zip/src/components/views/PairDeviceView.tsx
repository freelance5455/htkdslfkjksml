import React, { useState, useRef } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { useParentControl } from '../../context/ParentControlContext';
import { 
  PlusCircle, QrCode, Copy, CheckCircle2, 
  Smartphone, Shield, ArrowRight, Sparkles, 
  ExternalLink, Download, Check, Printer, Share2
} from 'lucide-react';

interface PairDeviceViewProps {
  onPairedSuccess?: () => void;
}

export const PairDeviceView: React.FC<PairDeviceViewProps> = ({ onPairedSuccess }) => {
  const { pairNewDevice, setIsSimulatorOpen, devices, language, showToast } = useParentControl();
  const isAr = language === 'ar';

  const [childNameAr, setChildNameAr] = useState('');
  const [childAge, setChildAge] = useState(10);
  const [deviceName, setDeviceName] = useState('');
  const [platform, setPlatform] = useState<'android' | 'ios'>('android');
  const [generatedCode, setGeneratedCode] = useState<string | null>(null);
  const [isCopied, setIsCopied] = useState(false);
  const [isLinkCopied, setIsLinkCopied] = useState(false);
  const [activeStep, setActiveStep] = useState<1 | 2>(1);
  const [qrContentType, setQrContentType] = useState<'url' | 'json'>('url');
  
  const qrContainerRef = useRef<HTMLDivElement | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!childNameAr.trim() || !deviceName.trim()) return;

    const code = pairNewDevice({
      childName: childNameAr,
      childNameAr: childNameAr,
      childAge,
      deviceName,
      platform,
    });

    setGeneratedCode(code);
    setActiveStep(2);
  };

  const handleCopyCode = () => {
    if (!generatedCode) return;
    navigator.clipboard?.writeText(generatedCode);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const currentPairUrl = typeof window !== 'undefined'
    ? `${window.location.origin}${window.location.pathname}?pairCode=${generatedCode || ''}&childName=${encodeURIComponent(childNameAr)}&device=${encodeURIComponent(deviceName)}&platform=${platform}`
    : `https://parentguard.app/pair?code=${generatedCode || ''}`;

  const currentJsonPayload = JSON.stringify({
    type: 'PARENTGUARD_PAIR',
    code: generatedCode || '',
    childName: childNameAr,
    childNameAr: childNameAr,
    deviceName: deviceName,
    platform: platform,
    timestamp: Date.now()
  });

  const activeQrPayload = qrContentType === 'url' ? currentPairUrl : currentJsonPayload;

  const handleCopyLink = () => {
    navigator.clipboard?.writeText(currentPairUrl);
    setIsLinkCopied(true);
    setTimeout(() => setIsLinkCopied(false), 2000);
  };

  // Download QR Code as a PNG image
  const handleDownloadQr = () => {
    if (!qrContainerRef.current) return;
    const svgElement = qrContainerRef.current.querySelector('svg');
    if (!svgElement) return;

    const svgData = new XMLSerializer().serializeToString(svgElement);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();

    img.onload = () => {
      canvas.width = 600;
      canvas.height = 600;
      if (ctx) {
        // White background
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        // Draw centered QR
        ctx.drawImage(img, 50, 50, 500, 500);

        const pngFile = canvas.toDataURL('image/png');
        const downloadLink = document.createElement('a');
        downloadLink.download = `ParentGuard-QR-${generatedCode || 'Pair'}.png`;
        downloadLink.href = pngFile;
        downloadLink.click();
      }
    };

    img.src = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgData)));
  };

  const handlePrintCard = () => {
    window.print();
  };

  // Check if this newly paired device is already marked online or active
  const isCurrentlyConnected = devices.some(d => d.pairingCode === generatedCode && d.isOnline);

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs transition-colors duration-200">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
            <PlusCircle className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              {isAr ? 'إقران وربط جهاز طفل جديد (Android أو iOS)' : 'Pair New Child Device (Android / iOS)'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
              {isAr 
                ? 'خطوات بسيطة لربط هاتف طفلك وتفعيل التحكم الكامل عن بعد بالكاميرا والتطبيقات'
                : 'Simple steps to bind your child device and enable remote control telemetry'}
            </p>
          </div>
        </div>

        {/* Steps Progress */}
        <div className="flex items-center gap-4 mt-6 pt-4 border-t border-slate-100 dark:border-slate-800">
          <div className={`flex items-center gap-2 text-xs font-semibold ${activeStep === 1 ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400 dark:text-slate-500'}`}>
            <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${activeStep === 1 ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'}`}>1</span>
            <span>{isAr ? 'بيانات الطفل والجهاز' : 'Child & Device Info'}</span>
          </div>
          <div className="h-0.5 w-12 bg-slate-200 dark:bg-slate-700" />
          <div className={`flex items-center gap-2 text-xs font-semibold ${activeStep === 2 ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400 dark:text-slate-500'}`}>
            <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${activeStep === 2 ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'}`}>2</span>
            <span>{isAr ? 'رمز الإقران وتفعيل الصلاحيات' : 'Pairing Code & Permissions'}</span>
          </div>
        </div>
      </div>

      {activeStep === 1 ? (
        /* STEP 1: FORM */
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-6 transition-colors duration-200">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1.5">
                  {isAr ? 'اسم الطفل:' : 'Child Name:'}
                </label>
                <input
                  type="text"
                  required
                  value={childNameAr}
                  onChange={(e) => setChildNameAr(e.target.value)}
                  placeholder={isAr ? 'مثال: يوسف، مريم، فيصل' : 'e.g. Yousef'}
                  className="w-full bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-800"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1.5">
                  {isAr ? 'عمر الطفل (سنوات):' : 'Child Age:'}
                </label>
                <input
                  type="number"
                  min="4"
                  max="18"
                  required
                  value={childAge}
                  onChange={(e) => setChildAge(Number(e.target.value))}
                  className="w-full bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-800 font-mono"
                />
              </div>
            </div>

            {/* Platform Selector */}
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1.5">
                {isAr ? 'نظام تشغيل هاتف الطفل:' : 'Child Device OS:'}
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setPlatform('android')}
                  className={`p-4 rounded-xl border flex items-center justify-center gap-3 transition-all ${
                    platform === 'android'
                      ? 'bg-indigo-50/70 dark:bg-indigo-950/50 border-indigo-500 text-slate-900 dark:text-white shadow-xs'
                      : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Smartphone className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                  <div className="text-start">
                    <p className="text-xs sm:text-sm font-bold">Android</p>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400">Samsung, Xiaomi, Oppo...</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setPlatform('ios')}
                  className={`p-4 rounded-xl border flex items-center justify-center gap-3 transition-all ${
                    platform === 'ios'
                      ? 'bg-indigo-50/70 dark:bg-indigo-950/50 border-indigo-500 text-slate-900 dark:text-white shadow-xs'
                      : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Smartphone className="w-5 h-5 text-sky-600 dark:text-sky-400" />
                  <div className="text-start">
                    <p className="text-xs sm:text-sm font-bold">iOS (Apple)</p>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400">iPhone, iPad</p>
                  </div>
                </button>
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1.5">
                {isAr ? 'طراز واسم الجهاز:' : 'Device Model / Name:'}
              </label>
              <input
                type="text"
                required
                value={deviceName}
                onChange={(e) => setDeviceName(e.target.value)}
                placeholder={platform === 'android' ? 'Galaxy A54 / Pixel 8' : 'iPhone 13 / iPad Air'}
                className="w-full bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-800"
              />
            </div>

            <div className="pt-4 flex justify-end">
              <button
                type="submit"
                className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-semibold rounded-xl shadow-xs transition-all flex items-center gap-2 active:scale-95"
              >
                <span>{isAr ? 'إنشاء رمز الإقران والمتابعة' : 'Generate Pairing Code'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        </div>
      ) : (
        /* STEP 2: PAIRING CODE & INSTRUCTIONS */
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xs text-center space-y-5 transition-colors duration-200">
            
            {/* Top Status Badge */}
            <div className="flex items-center justify-center gap-2">
              {isCurrentlyConnected ? (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 animate-in fade-in">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                  <span>{isAr ? 'تم الاقتران بنجاح وهو متصل الآن!' : 'Paired & Online Now!'}</span>
                </span>
              ) : (
                <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest block">
                  {isAr ? 'امسح رمز QR من هاتف الطفل للإقران الفوري' : 'SCAN QR CODE WITH CHILD PHONE'}
                </span>
              )}
            </div>

            {/* Real Interactive QR Code Card */}
            <div className="max-w-xs mx-auto flex flex-col items-center">
              <div 
                ref={qrContainerRef}
                className="relative p-5 bg-white rounded-3xl shadow-xl border-4 border-indigo-500/20 dark:border-indigo-500/30 flex flex-col items-center justify-center transition-transform hover:scale-102"
              >
                {/* Real Scannable QR Code */}
                <QRCodeSVG
                  value={activeQrPayload}
                  size={210}
                  level="H"
                  includeMargin={true}
                  className="w-48 h-48 sm:w-52 sm:h-52"
                />

                {/* Center shield emblem overlay */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 p-2 bg-indigo-600 text-white rounded-xl shadow-lg border-2 border-white pointer-events-none">
                  <Shield className="w-5 h-5" />
                </div>
              </div>

              {/* QR Payload Selector */}
              <div className="flex items-center gap-1.5 mt-3 bg-slate-100 dark:bg-slate-800/80 p-1 rounded-xl text-[11px] font-medium text-slate-600 dark:text-slate-300">
                <button
                  type="button"
                  onClick={() => setQrContentType('url')}
                  className={`px-3 py-1 rounded-lg transition-all ${qrContentType === 'url' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs font-bold' : ''}`}
                >
                  {isAr ? 'رابط فتح التطبيق' : 'Web Link URL'}
                </button>
                <button
                  type="button"
                  onClick={() => setQrContentType('json')}
                  className={`px-3 py-1 rounded-lg transition-all ${qrContentType === 'json' ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs font-bold' : ''}`}
                >
                  {isAr ? 'بيانات مشفرة JSON' : 'Direct JSON'}
                </button>
              </div>
            </div>

            {/* Quick Actions Row under QR Code */}
            <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
              <button
                type="button"
                onClick={handleDownloadQr}
                className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-200 dark:border-slate-700"
                title={isAr ? 'تحميل صورة رمز QR بصيغة PNG' : 'Download QR Image'}
              >
                <Download className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                <span>{isAr ? 'تحميل كصورة PNG' : 'Download PNG'}</span>
              </button>

              <button
                type="button"
                onClick={handleCopyLink}
                className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-200 dark:border-slate-700"
                title={isAr ? 'نسخ رابط الإقران المباشر' : 'Copy Direct Link'}
              >
                {isLinkCopied ? (
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                ) : (
                  <Share2 className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                )}
                <span>{isLinkCopied ? (isAr ? 'تم نسخ الرابط!' : 'Link Copied!') : (isAr ? 'نسخ رابط الإقران' : 'Copy Link')}</span>
              </button>

              <button
                type="button"
                onClick={handlePrintCard}
                className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-200 dark:border-slate-700"
                title={isAr ? 'طباعة كارت الإقران' : 'Print Pairing Card'}
              >
                <Printer className="w-3.5 h-3.5 text-slate-500" />
                <span>{isAr ? 'طباعة الكارت' : 'Print Card'}</span>
              </button>
            </div>

            {/* Manual Code Alternative */}
            <div className="pt-2">
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-2">
                {isAr 
                  ? 'أو يمكنك إدخال الرمز النصي يدوياً في هاتف الطفل:' 
                  : 'Or enter the 6-character code manually on child device:'}
              </p>

              <div className="inline-flex items-center justify-center gap-3 p-3 px-5 rounded-2xl bg-slate-50 dark:bg-slate-800 border-2 border-indigo-500 shadow-xs">
                <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white font-mono tracking-wider">
                  {generatedCode}
                </span>
                <button
                  onClick={handleCopyCode}
                  className="p-1.5 bg-white dark:bg-slate-700 hover:bg-slate-50 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 rounded-xl transition-colors border border-slate-200 dark:border-slate-600 shadow-xs"
                  title={isAr ? 'نسخ الرمز' : 'Copy Code'}
                >
                  {isCopied ? <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Primary Action Buttons */}
            <div className="pt-3 flex flex-wrap items-center justify-center gap-3">
              {/* Test in Simulator Button */}
              <button
                type="button"
                onClick={() => setIsSimulatorOpen(true)}
                className="px-5 py-2.5 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 font-bold text-xs sm:text-sm rounded-xl border border-indigo-300 dark:border-indigo-800 flex items-center gap-2 transition-all active:scale-95"
              >
                <Smartphone className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <span>{isAr ? 'فتح المحاكي وتجربة مسح الـ QR' : 'Test Scan in Simulator'}</span>
                <span className="text-[10px] bg-indigo-200/60 dark:bg-indigo-800 px-1.5 py-0.5 rounded text-indigo-900 dark:text-indigo-200 font-mono">Live</span>
              </button>

              <button
                onClick={() => {
                  if (onPairedSuccess) onPairedSuccess();
                  showToast(
                    isAr ? 'تم ربط الجهاز بنجاح! أصبح متاحاً الآن في لوحة التحكم.' : 'Device paired successfully!',
                    'success'
                  );
                }}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs sm:text-sm rounded-xl shadow-xs transition-colors flex items-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{isAr ? 'تأكيد اكتمال الاقتران والعودة' : 'Finish & Go to Dashboard'}</span>
              </button>
            </div>
          </div>

          {/* OS-specific Permissions Checklist */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4 transition-colors duration-200">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Shield className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
              <span>
                {platform === 'android' 
                  ? (isAr ? 'الصلاحيات المطلوبة على نظام أندرويد (Android Permissions):' : 'Required Android Permissions:')
                  : (isAr ? 'الصلاحيات المطلوبة على نظام أبل (iOS Screen Time / MDM):' : 'Required iOS Permissions:')}
              </span>
            </h3>

            <div className="space-y-2.5 text-xs text-slate-600 dark:text-slate-400">
              {platform === 'android' ? (
                <>
                  <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700 flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 shrink-0" />
                    <div>
                      <p className="font-bold text-slate-900 dark:text-white">إمكانية الوصول (Accessibility Service)</p>
                      <p className="text-slate-500 dark:text-slate-400 text-[11px]">لمراقبة تشغيل التطبيقات المحظورة وإغلاقها فوراً.</p>
                    </div>
                  </div>
                  <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700 flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 shrink-0" />
                    <div>
                      <p className="font-bold text-slate-900 dark:text-white">مسؤول الجهاز (Device Administrator - DevicePolicyManager)</p>
                      <p className="text-slate-500 dark:text-slate-400 text-[11px]">لقفل الشاشة عن بعد ومنع الطفل من حذف التطبيق.</p>
                    </div>
                  </div>
                  <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700 flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 shrink-0" />
                    <div>
                      <p className="font-bold text-slate-900 dark:text-white">الوصول لبيانات الاستخدام (Usage Access) والموقع دائماً</p>
                      <p className="text-slate-500 dark:text-slate-400 text-[11px]">لحساب وقت الشاشة وتتبع الـ GPS في الخلفية.</p>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700 flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 shrink-0" />
                    <div>
                      <p className="font-bold text-slate-900 dark:text-white">Apple Family Controls & ManagedSettings API</p>
                      <p className="text-slate-500 dark:text-slate-400 text-[11px]">موافقة ولي الأمر عبر Screen Time لحظر التطبيقات والويب.</p>
                    </div>
                  </div>
                  <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700 flex items-start gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 shrink-0" />
                    <div>
                      <p className="font-bold text-slate-900 dark:text-white">Always Allow Location & Microphone</p>
                      <p className="text-slate-500 dark:text-slate-400 text-[11px]">للتتبع الجغرافي المستمر والمحيط الصوتي الآمن.</p>
                    </div>
                  </div>
                </>
              )}
            </div>

            <button
              onClick={() => setActiveStep(1)}
              className="text-xs text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 font-semibold pt-2 block"
            >
              {isAr ? '← العودة لتعديل بيانات الجهاز' : '← Back to edit info'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
