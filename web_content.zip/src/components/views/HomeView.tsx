import React, { useState } from 'react';
import {
  FileText,
  ScanText,
  FileCheck2,
  FileImage,
  FileType,
  Images,
  Sparkles,
  GitMerge,
  Scissors,
  Palette,
  Star,
  Clock,
  ArrowRight,
  Upload,
  Plus,
  Search,
  ExternalLink,
  Download,
  Share2
} from 'lucide-react';
import { StoredDocument } from '../../types';
import { formatFileSize, formatFileTime, triggerFileDownload, shareFile } from '../../services/storageService';

export type FeatureToolId =
  | 'text_to_doc'
  | 'image_to_text'
  | 'ocr_to_doc'
  | 'pdf_to_image'
  | 'word_to_image'
  | 'image_to_doc'
  | 'ai_formatter'
  | 'merge_docs'
  | 'remove_bg'
  | 'replace_bg_color';

interface HomeViewProps {
  onSelectFeature: (featureId: FeatureToolId) => void;
  recentDocuments: StoredDocument[];
  onToggleFavorite: (id: string) => void;
  onOpenDocument: (doc: StoredDocument) => void;
  onQuickImport: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onSelectFeature,
  recentDocuments,
  onToggleFavorite,
  onOpenDocument,
  onQuickImport
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterFavorites, setFilterFavorites] = useState(false);

  const featureCards = [
    {
      id: 'text_to_doc' as FeatureToolId,
      title: 'Text to Document',
      description: 'Rich text composition with font library, margins & DOCX/PDF export',
      icon: FileText,
      color: 'from-blue-600 to-indigo-600',
      tag: 'DOCX • PDF'
    },
    {
      id: 'image_to_text' as FeatureToolId,
      title: 'Image to Text (OCR)',
      description: 'Extract printed & handwritten text in 12+ languages with editor',
      icon: ScanText,
      color: 'from-teal-600 to-cyan-600',
      tag: 'OCR • TXT'
    },
    {
      id: 'ocr_to_doc' as FeatureToolId,
      title: 'OCR to Document',
      description: 'Convert scanned text directly into formatted professional documents',
      icon: FileCheck2,
      color: 'from-emerald-600 to-teal-700',
      tag: 'Scans to Word'
    },
    {
      id: 'pdf_to_image' as FeatureToolId,
      title: 'PDF to Image',
      description: 'Convert PDF pages to 300 DPI high-resolution PNG or JPEG images',
      icon: FileImage,
      color: 'from-rose-600 to-red-600',
      tag: 'Hi-Res PNG'
    },
    {
      id: 'word_to_image' as FeatureToolId,
      title: 'Word to Image',
      description: 'Render DOCX document pages into crisp page graphics',
      icon: FileType,
      color: 'from-amber-600 to-orange-600',
      tag: 'DOCX to Image'
    },
    {
      id: 'image_to_doc' as FeatureToolId,
      title: 'Image to Document',
      description: 'Batch convert photos into PDF or reconstructed editable DOCX',
      icon: Images,
      color: 'from-purple-600 to-violet-700',
      tag: 'Batch Photos'
    },
    {
      id: 'ai_formatter' as FeatureToolId,
      title: 'AI Document Formatter',
      description: 'Gemini layout analysis for headings, tables, fonts & margins',
      icon: Sparkles,
      color: 'from-sky-500 to-blue-700',
      tag: 'Gemini AI'
    },
    {
      id: 'merge_docs' as FeatureToolId,
      title: 'Merge Documents',
      description: 'Combine multiple DOCX and PDF files with drag-and-drop reordering',
      icon: GitMerge,
      color: 'from-violet-600 to-purple-800',
      tag: 'DOCX + PDF'
    },
    {
      id: 'remove_bg' as FeatureToolId,
      title: 'Remove Background',
      description: 'On-device subject segmentation with edge refinement & PNG export',
      icon: Scissors,
      color: 'from-pink-600 to-rose-700',
      tag: 'Cutout PNG'
    },
    {
      id: 'replace_bg_color' as FeatureToolId,
      title: 'Replace Background Color',
      description: 'Replace transparency with studio colors, white, blue, or custom HEX',
      icon: Palette,
      color: 'from-cyan-600 to-blue-700',
      tag: 'Studio Colors'
    }
  ];

  const filteredDocs = recentDocuments.filter((doc) => {
    const matchesSearch = doc.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFav = filterFavorites ? doc.isFavorite : true;
    return matchesSearch && matchesFav;
  });

  return (
    <div className="flex-1 px-4 py-4 space-y-6 pb-20">
      {/* Hero Welcome & Quick Stats */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-700 p-5 text-white shadow-lg">
        <div className="relative z-10 space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>DocuForge Mobile Studio</span>
          </div>
          <h2 className="text-2xl font-black tracking-tight">Professional Document & Image Engine</h2>
          <p className="text-xs text-blue-100 max-w-sm leading-relaxed">
            Create, convert, extract, format, merge documents, and process high-fidelity images seamlessly on Android.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-2">
            <label className="cursor-pointer inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white text-blue-800 font-bold text-xs shadow-md active:scale-95 transition-all">
              <Upload className="w-4 h-4" />
              <span>Import Document</span>
              <input
                type="file"
                className="hidden"
                accept=".docx,.pdf,.png,.jpg,.jpeg,.txt"
                onChange={onQuickImport}
              />
            </label>
            <button
              type="button"
              onClick={() => onSelectFeature('text_to_doc')}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/15 hover:bg-white/25 backdrop-blur-md text-white font-semibold text-xs active:scale-95 transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>New Document</span>
            </button>
          </div>
        </div>
        {/* Subtle decorative circles */}
        <div className="absolute -bottom-8 -right-8 w-44 h-44 rounded-full bg-white/10 blur-xl pointer-events-none" />
      </div>

      {/* Feature Studio Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-neutral-800 dark:text-neutral-200 tracking-wide uppercase">
            Document & Image Tools
          </h3>
          <span className="text-xs text-neutral-500 font-medium">{featureCards.length} Tools Ready</span>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {featureCards.map((tool) => {
            const Icon = tool.icon;
            return (
              <button
                key={tool.id}
                type="button"
                onClick={() => onSelectFeature(tool.id)}
                className="flex flex-col text-left p-3.5 rounded-2xl bg-white dark:bg-neutral-800/80 border border-neutral-200/70 dark:border-neutral-700/60 shadow-xs hover:shadow-md hover:border-blue-400 dark:hover:border-blue-500 transition-all active:scale-[0.98] group"
              >
                <div className="flex items-center justify-between mb-2.5">
                  <div
                    className={`w-10 h-10 rounded-xl bg-gradient-to-tr ${tool.color} flex items-center justify-center text-white shadow-sm group-hover:scale-105 transition-transform`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-neutral-100 dark:bg-neutral-700/80 text-neutral-600 dark:text-neutral-300 font-medium">
                    {tool.tag}
                  </span>
                </div>
                <h4 className="text-xs font-bold text-neutral-900 dark:text-neutral-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                  {tool.title}
                </h4>
                <p className="text-[11px] text-neutral-500 dark:text-neutral-400 mt-1 line-clamp-2 leading-tight">
                  {tool.description}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Recent Files & Document History */}
      <div className="space-y-3 pt-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <h3 className="text-sm font-bold text-neutral-800 dark:text-neutral-200 tracking-wide uppercase">
              Recent Files
            </h3>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setFilterFavorites(!filterFavorites)}
              className={`px-2.5 py-1 rounded-full text-xs font-medium flex items-center gap-1 transition-colors ${
                filterFavorites
                  ? 'bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-300'
                  : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400'
              }`}
            >
              <Star className={`w-3.5 h-3.5 ${filterFavorites ? 'fill-amber-400 text-amber-500' : ''}`} />
              <span>Favorites</span>
            </button>
          </div>
        </div>

        {/* Search bar */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-neutral-400" />
          <input
            type="text"
            placeholder="Search recent files..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 text-xs text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* File items list */}
        <div className="space-y-2">
          {filteredDocs.length === 0 ? (
            <div className="text-center py-8 px-4 rounded-2xl border border-dashed border-neutral-300 dark:border-neutral-700 bg-neutral-50/50 dark:bg-neutral-800/30">
              <p className="text-xs text-neutral-500 dark:text-neutral-400 font-medium">
                {filterFavorites ? 'No favorite documents yet' : 'No documents found matching search'}
              </p>
            </div>
          ) : (
            filteredDocs.slice(0, 6).map((doc) => {
              const isPdf = doc.type === 'pdf';
              const isDocx = doc.type === 'docx';
              const isImg = doc.type === 'png' || doc.type === 'jpg';

              return (
                <div
                  key={doc.id}
                  className="flex items-center justify-between p-3 rounded-2xl bg-white dark:bg-neutral-800/90 border border-neutral-200/80 dark:border-neutral-700/60 shadow-xs hover:border-blue-400 dark:hover:border-blue-500 transition-colors"
                >
                  <div
                    onClick={() => onOpenDocument(doc)}
                    className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer"
                  >
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs uppercase text-white shadow-xs shrink-0 ${
                        isPdf
                          ? 'bg-rose-600'
                          : isDocx
                          ? 'bg-blue-600'
                          : isImg
                          ? 'bg-emerald-600'
                          : 'bg-neutral-600'
                      }`}
                    >
                      {doc.type}
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-neutral-900 dark:text-neutral-100 truncate">
                        {doc.name}
                      </p>
                      <div className="flex items-center gap-2 text-[10px] text-neutral-500 dark:text-neutral-400 mt-0.5">
                        <span>{formatFileSize(doc.sizeBytes)}</span>
                        <span>•</span>
                        <span>{formatFileTime(doc.createdAt)}</span>
                        {doc.pageCount && (
                          <>
                            <span>•</span>
                            <span>{doc.pageCount} {doc.pageCount === 1 ? 'page' : 'pages'}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0 ml-2">
                    <button
                      type="button"
                      onClick={() => onToggleFavorite(doc.id)}
                      aria-label="Toggle favorite"
                      className="p-1.5 rounded-lg text-neutral-400 hover:text-amber-500 hover:bg-neutral-100 dark:hover:bg-neutral-700 transition-colors"
                    >
                      <Star
                        className={`w-4 h-4 ${doc.isFavorite ? 'fill-amber-400 text-amber-500' : ''}`}
                      />
                    </button>
                    {doc.blobData && (
                      <button
                        type="button"
                        onClick={() => triggerFileDownload(doc.blobData!, doc.name)}
                        aria-label="Download file"
                        className="p-1.5 rounded-lg text-neutral-400 hover:text-blue-600 hover:bg-neutral-100 dark:hover:bg-neutral-700 transition-colors"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
