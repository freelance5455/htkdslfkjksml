import React, { useState } from 'react';
import {
  Flame,
  Clock,
  Dumbbell,
  Play,
  Trophy,
  ChevronRight,
  TrendingUp,
  Sparkles,
  Timer,
  Zap,
  ShieldCheck,
  Eye,
  ChevronDown,
  ChevronUp,
  Plus,
  X,
  Check,
  Search,
  Minus
} from 'lucide-react';
import { useWorkout } from '../../context/WorkoutContext';
import { PRESET_ROUTINES } from '../../data/presetRoutines';
import { TabType } from '../Navigation';
import { DailyHabitTracker } from '../DailyHabitTracker';
import { RoutinePreviewModal, RoutineInlinePreview } from '../RoutinePreviewModal';
import { CustomRoutine, SetType } from '../../types';
import { playPopSound } from '../../utils/audio';

interface HomeViewProps {
  onNavigate: (tab: TabType) => void;
  onOpenSkillDetails: (skillId: string) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({ onNavigate, onOpenSkillDetails }) => {
  const {
    user,
    startWorkout,
    startEmptyWorkout,
    logQuickSingleSet,
    skills,
    personalRecords,
    startRestTimer,
    workoutHistory,
    exercises
  } = useWorkout();
  const [previewRoutine, setPreviewRoutine] = useState<CustomRoutine | null>(null);
  const [showTodayInline, setShowTodayInline] = useState<boolean>(false);

  // Quick Add Floating Action Button (FAB) & Quick Single Set Logger Modal State
  const [isQuickFabOpen, setIsQuickFabOpen] = useState<boolean>(false);
  const [isQuickSetModalOpen, setIsQuickSetModalOpen] = useState<boolean>(false);
  const [quickSetSearch, setQuickSetSearch] = useState<string>('');
  const [quickExerciseId, setQuickExerciseId] = useState<string>(
    () => exercises[0]?.id || 'pull-ups'
  );
  const [quickReps, setQuickReps] = useState<number>(10);
  const [quickHoldSec, setQuickHoldSec] = useState<number>(30);
  const [quickWeightKg, setQuickWeightKg] = useState<number>(0);
  const [quickSetType, setQuickSetType] = useState<SetType>('normal');
  const [quickSetSavedToast, setQuickSetSavedToast] = useState<string | null>(null);

  const todayRoutine = PRESET_ROUTINES[0]; // Full body foundation

  const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
  const workoutsThisWeek = workoutHistory.filter(
    (w) => new Date(w.date).getTime() >= sevenDaysAgo
  ).length;
  const weeklyGoalPercent =
    user.weeklyGoal > 0 ? Math.min(100, Math.round((workoutsThisWeek / user.weeklyGoal) * 100)) : 0;

  const formatHours = (sec: number) => {
    const hours = (sec / 3600).toFixed(1);
    return `${hours}h`;
  };

  // Time based greeting
  const hour = new Date().getHours();
  const greeting =
    hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';

  return (
    <div className="space-y-6 pb-28 pt-2">
      {/* Hero Greeting & Profile Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xs font-semibold uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
            Liftbody Athlete
          </div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            {greeting}, {user.name.split(' ')[0]}
          </h1>
        </div>

        <button
          onClick={() => onNavigate('profile')}
          className="w-11 h-11 rounded-2xl bg-neutral-900 border border-cyan-500/30 flex items-center justify-center text-cyan-400 hover:border-cyan-400 transition-colors shadow-sm relative group active:scale-95 overflow-hidden"
          title="Open Profile"
        >
          {user.profileImage ? (
            <img
              src={user.profileImage}
              alt={user.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <span className="font-heading font-bold text-sm">
              {user.name ? user.name.charAt(0).toUpperCase() : 'A'}
            </span>
          )}
          <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-cyan-500 rounded-full border-2 border-[#0a0b0e]" />
        </button>
      </div>

      {/* Today's Workout Hero Card */}
      <div className="relative rounded-3xl overflow-hidden border border-cyan-500/30 bg-gradient-to-b from-neutral-900 to-[#10141d] p-5 shadow-xl shadow-cyan-950/20 group">
        {/* Background Image Scrim */}
        <div className="absolute inset-0 pointer-events-none opacity-20 group-hover:opacity-25 transition-opacity">
          <img
            src="/src/assets/images/hero_calisthenics_1790336423666.jpg"
            alt="Calisthenics athlete training"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#10141d] via-[#10141d]/80 to-transparent" />
        </div>

        <div className="relative z-10">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <div className="flex items-center gap-1.5 text-cyan-400 font-bold uppercase tracking-wider text-[11px]">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Today's Recommended Session</span>
            </div>
            <span className="font-mono text-slate-300 font-semibold">{todayRoutine.estimatedDurationMin} min</span>
          </div>

          <h2 className="text-xl font-extrabold text-white mb-2 leading-tight">
            {todayRoutine.name}
          </h2>

          <p className="text-xs text-slate-300 mb-4 line-clamp-2 leading-relaxed">
            {todayRoutine.description}
          </p>

          {showTodayInline && (
            <div className="mb-4">
              <RoutineInlinePreview routine={todayRoutine} exercises={exercises} />
            </div>
          )}

          <div className="flex items-center justify-between gap-2 pt-3 border-t border-neutral-800/80 flex-wrap">
            <button
              type="button"
              onClick={() => setShowTodayInline((prev) => !prev)}
              className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors"
            >
              {showTodayInline ? (
                <>
                  <ChevronUp className="w-3.5 h-3.5" />
                  <span>Hide Routine ({todayRoutine.exercises.length} exercises)</span>
                </>
              ) : (
                <>
                  <ChevronDown className="w-3.5 h-3.5" />
                  <span>Quick View ({todayRoutine.exercises.length} exercises)</span>
                </>
              )}
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setPreviewRoutine(todayRoutine)}
                className="px-3.5 py-2.5 bg-neutral-900/90 hover:bg-neutral-800 border border-neutral-700 hover:border-cyan-500/50 text-slate-200 hover:text-cyan-300 font-semibold text-xs rounded-xl transition-all flex items-center gap-1.5 active:scale-95"
                title="View workout routine without starting session"
              >
                <Eye className="w-3.5 h-3.5 text-cyan-400" />
                <span>View</span>
              </button>

              <button
                onClick={() => startWorkout(todayRoutine)}
                className="px-5 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-bold text-xs rounded-xl shadow-lg shadow-cyan-500/25 active:scale-95 transition-all flex items-center gap-2"
              >
                <Play className="w-4 h-4 fill-neutral-950" />
                <span>Start Workout</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 4 Core Metric Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Streak */}
        <div className="bg-[#12151c] border border-neutral-800 rounded-2xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[11px] font-semibold">Streak</span>
            <div className="w-7 h-7 rounded-lg bg-orange-500/10 text-orange-400 flex items-center justify-center">
              <Flame className="w-4 h-4 fill-orange-400/20" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-extrabold text-white font-mono">{user.streak} <span className="text-xs text-orange-400 font-sans font-bold">Days</span></div>
            <div className="text-[10px] text-slate-400">Active consistency</div>
          </div>
        </div>

        {/* Weekly Workouts */}
        <div className="bg-[#12151c] border border-neutral-800 rounded-2xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[11px] font-semibold">This Week</span>
            <div className="w-7 h-7 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center">
              <Zap className="w-4 h-4 fill-cyan-400/20" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-extrabold text-white font-mono">
              {workoutsThisWeek}<span className="text-xs text-slate-500">/{user.weeklyGoal}</span>
            </div>
            {/* Progression Line Bar */}
            <div className="w-full h-1.5 bg-neutral-900 rounded-full overflow-hidden my-1">
              <div
                style={{ width: `${weeklyGoalPercent}%` }}
                className="h-full bg-gradient-to-r from-cyan-600 to-cyan-400 rounded-full glow-cyan-sm"
              />
            </div>
            <div className="text-[10px] text-cyan-400 font-medium">Goal {weeklyGoalPercent}% met</div>
          </div>
        </div>

        {/* Total Sessions */}
        <div className="bg-[#12151c] border border-neutral-800 rounded-2xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[11px] font-semibold">Total Workouts</span>
            <div className="w-7 h-7 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center">
              <Dumbbell className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-extrabold text-white font-mono">{user.totalWorkouts}</div>
            <div className="text-[10px] text-slate-400">Sessions logged</div>
          </div>
        </div>

        {/* Training Time */}
        <div className="bg-[#12151c] border border-neutral-800 rounded-2xl p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[11px] font-semibold">Time Trained</span>
            <div className="w-7 h-7 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl font-extrabold text-white font-mono">{formatHours(user.totalTrainingTimeSec)}</div>
            <div className="text-[10px] text-slate-400 font-mono">{user.totalReps.toLocaleString()} total reps</div>
          </div>
        </div>
      </div>

      {/* Quick Action Bar */}
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={startEmptyWorkout}
          className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-cyan-500/40 text-left transition-all active:scale-[0.98] group"
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold text-white group-hover:text-cyan-400 transition-colors">
              Freestyle Workout
            </span>
            <Play className="w-3.5 h-3.5 text-cyan-400 fill-cyan-400" />
          </div>
          <p className="text-[11px] text-slate-400">Track sets on the fly without routine</p>
        </button>

        <button
          onClick={() => startRestTimer(user.defaultRestTimeSec)}
          className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-cyan-500/40 text-left transition-all active:scale-[0.98] group"
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold text-white group-hover:text-cyan-400 transition-colors">
              Quick Rest Timer
            </span>
            <Timer className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <p className="text-[11px] text-slate-400">{user.defaultRestTimeSec}s countdown chime</p>
        </button>
      </div>

      {/* Daily Habit Tracker Section */}
      <DailyHabitTracker />

      {/* Calisthenics Skills Section Snapshot */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white">Calisthenics Skills</h2>
            <p className="text-xs text-slate-400">Progression tiers & holds</p>
          </div>
          <button
            onClick={() => onNavigate('skills')}
            className="text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
          >
            <span>View All</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {skills.slice(0, 3).map((skill) => {
            const currentLevelObj = skill.levels.find((l) => l.level === skill.currentLevel);

            return (
              <button
                key={skill.id}
                onClick={() => onOpenSkillDetails(skill.id)}
                className="p-4 rounded-2xl bg-[#12151c] border border-neutral-800 hover:border-cyan-500/40 text-left transition-all group active:scale-[0.99] flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                    <span className="font-bold text-cyan-400 text-[11px] uppercase tracking-wider">
                      Level {skill.currentLevel} of {skill.maxLevel}
                    </span>
                    <span className="font-mono text-slate-300 text-[11px]">
                      PR: {skill.prHoldSec}s
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-white group-hover:text-cyan-400 transition-colors mb-0.5">
                    {skill.name}
                  </h3>
                  <div className="text-xs text-slate-300 font-medium truncate">
                    {currentLevelObj?.name}
                  </div>

                  {/* Skill Level Progression Line Bar */}
                  <div className="w-full h-1.5 bg-neutral-900 rounded-full overflow-hidden mt-2.5">
                    <div
                      style={{ width: `${(skill.currentLevel / skill.maxLevel) * 100}%` }}
                      className="h-full bg-gradient-to-r from-cyan-600 to-cyan-400 rounded-full glow-cyan-sm"
                    />
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-neutral-800/80 flex items-center justify-between text-[11px] text-slate-400">
                  <span>Target: {currentLevelObj?.targetHoldSec}s hold</span>
                  <span className="text-cyan-400 font-semibold group-hover:translate-x-0.5 transition-transform">
                    Train &rarr;
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Personal Records Highlight */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white">Personal Records</h2>
            <p className="text-xs text-slate-400">All-time calisthenics bests</p>
          </div>
          <button
            onClick={() => onNavigate('progress')}
            className="text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
          >
            <span>See PRs</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {personalRecords.length === 0 ? (
          <div className="p-4 rounded-2xl bg-[#12151c] border border-dashed border-neutral-800 text-center">
            <Trophy className="w-6 h-6 text-slate-600 mx-auto mb-1.5" />
            <p className="text-xs font-semibold text-slate-300">No Personal Records Logged Yet</p>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Complete workouts or log max sets to record your all-time calisthenics PRs!
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {personalRecords.slice(0, 4).map((pr) => (
              <div
                key={pr.id}
                className="p-3 rounded-2xl bg-neutral-900/80 border border-neutral-800"
              >
                <div className="text-[10px] text-slate-400 truncate mb-1">
                  {pr.exerciseName}
                </div>
                <div className="text-xl font-extrabold text-white font-mono flex items-baseline gap-1">
                  {pr.value}
                  <span className="text-xs text-cyan-400 font-sans font-semibold">
                    {pr.unit}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Safety Note for Home Training */}
      <div className="p-4 rounded-2xl bg-cyan-950/20 border border-cyan-500/20 flex items-start gap-3">
        <ShieldCheck className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
        <div className="text-xs text-slate-300 leading-relaxed">
          <span className="font-semibold text-white">Pure Bodyweight & Home Resistance:</span>{' '}
          Zero machines required. Focus on strict eccentric tempo, scapular stability, and joint conditioning before adding external backpack loads.
        </div>
      </div>

      {/* Read-Only Routine Preview Modal */}
      <RoutinePreviewModal
        routine={previewRoutine}
        exercises={exercises}
        onClose={() => setPreviewRoutine(null)}
        onStartWorkout={startWorkout}
      />

      {/* Quick Set Logged Confirmation Pill */}
      {quickSetSavedToast && (
        <div className="fixed bottom-36 right-4 z-40 px-3.5 py-2 rounded-2xl bg-cyan-500 text-neutral-950 font-extrabold text-xs shadow-lg shadow-cyan-500/30 flex items-center gap-1.5 animate-badge-pop">
          <Check className="w-4 h-4 stroke-[3]" />
          <span>{quickSetSavedToast}</span>
        </div>
      )}

      {/* 'Quick Add' Floating Action Button (FAB) at Bottom Right */}
      <div className="fixed bottom-20 right-4 z-30 flex flex-col items-end gap-2.5">
        {isQuickFabOpen && (
          <div className="flex flex-col items-end gap-2 mb-1 animate-in fade-in slide-in-from-bottom-2 duration-150">
            {/* Option 1: Start Freestyle Workout Session */}
            <button
              type="button"
              onClick={() => {
                setIsQuickFabOpen(false);
                startEmptyWorkout();
              }}
              className="px-4 py-2.5 rounded-2xl bg-[#12151c]/95 backdrop-blur-md border border-cyan-500/50 hover:border-cyan-400 text-white shadow-xl shadow-black/60 flex items-center gap-2.5 active:scale-95 transition-all group"
            >
              <span className="text-xs font-extrabold text-slate-100 group-hover:text-cyan-300">
                Freestyle Workout Session
              </span>
              <div className="w-8 h-8 rounded-xl bg-cyan-500 text-neutral-950 flex items-center justify-center shadow-sm shadow-cyan-500/40">
                <Play className="w-4 h-4 fill-neutral-950" />
              </div>
            </button>

            {/* Option 2: Log a Single Exercise Set Immediately */}
            <button
              type="button"
              onClick={() => {
                if (user.soundEnabled) playPopSound('bright');
                setIsQuickFabOpen(false);
                setIsQuickSetModalOpen(true);
              }}
              className="px-4 py-2.5 rounded-2xl bg-[#12151c]/95 backdrop-blur-md border border-amber-400/50 hover:border-amber-300 text-white shadow-xl shadow-black/60 flex items-center gap-2.5 active:scale-95 transition-all group"
            >
              <span className="text-xs font-extrabold text-slate-100 group-hover:text-amber-300">
                Log Single Exercise Set
              </span>
              <div className="w-8 h-8 rounded-xl bg-amber-400 text-neutral-950 flex items-center justify-center shadow-sm shadow-amber-400/40">
                <Dumbbell className="w-4 h-4" />
              </div>
            </button>
          </div>
        )}

        <button
          type="button"
          onClick={() => {
            if (user.soundEnabled) playPopSound(isQuickFabOpen ? 'soft' : 'bright');
            setIsQuickFabOpen((prev) => !prev);
          }}
          aria-label="Quick Add Workout or Single Set"
          title="Quick Add: Start Freestyle Session or Log Single Set"
          className={`h-13 px-4 rounded-2xl font-extrabold text-xs shadow-xl flex items-center gap-2 transition-all duration-200 active:scale-95 ${
            isQuickFabOpen
              ? 'bg-neutral-900 border border-neutral-700 text-slate-200'
              : 'bg-gradient-to-r from-cyan-500 to-cyan-400 hover:from-cyan-400 hover:to-cyan-300 text-neutral-950 shadow-cyan-500/30 border border-cyan-300/60'
          }`}
        >
          <Plus
            className={`w-5 h-5 stroke-[2.75] transition-transform duration-200 ${
              isQuickFabOpen ? 'rotate-45 text-cyan-400' : 'rotate-0 text-neutral-950'
            }`}
          />
          <span>{isQuickFabOpen ? 'Close' : 'Quick Add'}</span>
        </button>
      </div>

      {/* Quick Log Single Exercise Set Modal */}
      {isQuickSetModalOpen && (() => {
        const selectedEx =
          exercises.find((e) => e.id === quickExerciseId) || exercises[0];
        const isHoldEx = selectedEx?.isHold || false;
        const unitLabel = user.units === 'imperial' ? 'lbs' : 'kg';
        const matchingExercises = exercises.filter(
          (e) =>
            !quickSetSearch.trim() ||
            e.name.toLowerCase().includes(quickSetSearch.toLowerCase()) ||
            e.targetMuscles.some((m) =>
              m.toLowerCase().includes(quickSetSearch.toLowerCase())
            )
        );

        const handleSaveQuickSet = (e: React.FormEvent) => {
          e.preventDefault();
          if (!selectedEx) return;
          const res = logQuickSingleSet({
            exerciseId: selectedEx.id,
            reps: isHoldEx ? undefined : quickReps,
            durationSec: isHoldEx ? quickHoldSec : undefined,
            weightKg: quickWeightKg,
            setType: quickSetType
          });

          const summaryLabel = `${selectedEx.name}: ${
            isHoldEx ? `${quickHoldSec}s hold` : `${quickReps} reps`
          }${quickWeightKg > 0 ? ` (+${quickWeightKg}${unitLabel})` : ''}${
            res.isNewPr ? ' · NEW PR!' : ' logged!'
          }`;

          setQuickSetSavedToast(summaryLabel);
          setIsQuickSetModalOpen(false);
          window.setTimeout(() => setQuickSetSavedToast(null), 3200);
        };

        return (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-150">
            <form
              onSubmit={handleSaveQuickSet}
              className="w-full max-w-md bg-[#12151c] border border-neutral-800 rounded-3xl p-5 space-y-4 shadow-2xl"
            >
              <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                    <Dumbbell className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-base font-extrabold text-white">
                      Quick Log Single Set
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      Record a set immediately to your history & PR tracker
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsQuickSetModalOpen(false)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Exercise Search & Selector */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-300">
                  Select Exercise
                </label>
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Filter exercise (e.g. Pull-up, Dip, Planche)..."
                    value={quickSetSearch}
                    onChange={(e) => setQuickSetSearch(e.target.value)}
                    className="w-full text-xs bg-neutral-900 border border-neutral-800 rounded-xl pl-8 pr-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div className="max-h-36 overflow-y-auto space-y-1 pr-1">
                  {matchingExercises.map((ex) => {
                    const isSelected = ex.id === selectedEx?.id;
                    return (
                      <button
                        key={ex.id}
                        type="button"
                        onClick={() => {
                          setQuickExerciseId(ex.id);
                          setQuickReps(ex.defaultReps || 10);
                          setQuickHoldSec(ex.defaultHoldSec || 30);
                        }}
                        className={`w-full px-3 py-2 rounded-xl text-left text-xs flex items-center justify-between transition-all ${
                          isSelected
                            ? 'bg-cyan-500/20 border border-cyan-500/50 text-cyan-300 font-bold'
                            : 'bg-neutral-900/70 hover:bg-neutral-900 border border-neutral-800/80 text-slate-300'
                        }`}
                      >
                        <span className="truncate">{ex.name}</span>
                        <span className="text-[10px] font-mono text-slate-400 capitalize shrink-0 ml-2">
                          {ex.category}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Reps / Hold Seconds & Added Weight Controls */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-2xl bg-neutral-900/90 border border-neutral-800">
                  <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1.5">
                    {isHoldEx ? 'Hold Duration (sec)' : 'Completed Reps'}
                  </label>
                  <div className="flex items-center justify-between gap-1">
                    <button
                      type="button"
                      onClick={() =>
                        isHoldEx
                          ? setQuickHoldSec((v) => Math.max(5, v - 5))
                          : setQuickReps((v) => Math.max(1, v - 1))
                      }
                      className="w-8 h-8 rounded-lg bg-neutral-950 border border-neutral-800 flex items-center justify-center text-slate-300 hover:text-white"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <input
                      type="number"
                      min="1"
                      value={isHoldEx ? quickHoldSec : quickReps}
                      onChange={(e) => {
                        const val = Math.max(1, parseInt(e.target.value, 10) || 1);
                        if (isHoldEx) setQuickHoldSec(val);
                        else setQuickReps(val);
                      }}
                      className="w-16 text-center text-base font-mono font-extrabold bg-transparent text-cyan-400 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        isHoldEx
                          ? setQuickHoldSec((v) => v + 5)
                          : setQuickReps((v) => v + 1)
                      }
                      className="w-8 h-8 rounded-lg bg-neutral-950 border border-neutral-800 flex items-center justify-center text-cyan-400 hover:text-cyan-300"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-neutral-900/90 border border-neutral-800">
                  <label className="block text-[10px] font-bold uppercase text-slate-400 mb-1.5">
                    Added Weight (+{unitLabel})
                  </label>
                  <div className="flex items-center justify-between gap-1">
                    <button
                      type="button"
                      onClick={() =>
                        setQuickWeightKg((w) => Math.max(0, Math.round((w - 2.5) * 10) / 10))
                      }
                      className="w-8 h-8 rounded-lg bg-neutral-950 border border-neutral-800 flex items-center justify-center text-slate-300 hover:text-white"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <input
                      type="number"
                      min="0"
                      step="0.5"
                      value={quickWeightKg}
                      onChange={(e) =>
                        setQuickWeightKg(Math.max(0, parseFloat(e.target.value) || 0))
                      }
                      className="w-16 text-center text-base font-mono font-extrabold bg-transparent text-amber-300 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setQuickWeightKg((w) => Math.round((w + 2.5) * 10) / 10)
                      }
                      className="w-8 h-8 rounded-lg bg-neutral-950 border border-neutral-800 flex items-center justify-center text-amber-400 hover:text-amber-300"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Set Type Variation */}
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-semibold text-slate-400">Set Variation:</span>
                <select
                  value={quickSetType}
                  onChange={(e) => setQuickSetType(e.target.value as SetType)}
                  className="bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-1.5 text-xs font-bold text-cyan-400 focus:outline-none focus:border-cyan-500"
                >
                  <option value="normal">Working Set</option>
                  <option value="amrap">AMRAP / Max Effort</option>
                  <option value="dropset">Drop Set</option>
                  <option value="superset">Superset</option>
                  <option value="restpause">Rest-Pause</option>
                  <option value="tempo">Slow Eccentric Tempo</option>
                </select>
              </div>

              {/* Submit Actions */}
              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsQuickSetModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-slate-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-extrabold text-xs shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-1.5 active:scale-95 transition-all"
                >
                  <Check className="w-4 h-4 stroke-[2.5]" />
                  <span>Log Set Now</span>
                </button>
              </div>
            </form>
          </div>
        );
      })()}
    </div>
  );
};
