import React, { useState, useEffect, useRef } from 'react';
import {
  Award,
  Play,
  Square,
  Trophy,
  ChevronRight,
  Sparkles,
  CheckCircle2,
  Lock,
  ArrowRight,
  Info,
  Timer
} from 'lucide-react';
import { useWorkout } from '../../context/WorkoutContext';
import { Skill } from '../../types';

interface SkillsViewProps {
  initialSkillId?: string | null;
}

export const SkillsView: React.FC<SkillsViewProps> = ({ initialSkillId }) => {
  const { skills, updateSkillLevel, logSkillHold } = useWorkout();

  const [selectedSkillId, setSelectedSkillId] = useState<string>(initialSkillId || 'planche');
  const [skillCategoryFilter, setSkillCategoryFilter] = useState<'all' | 'push' | 'pull' | 'core'>('all');

  // Test Hold Stopwatch State
  const [isHolding, setIsHolding] = useState<boolean>(false);
  const [holdTimerSec, setHoldTimerSec] = useState<number>(0);
  const holdIntervalRef = useRef<number | null>(null);
  const [testResult, setTestResult] = useState<{ isNewPr: boolean; leveledUp: boolean } | null>(null);

  const filteredSkills = skills.filter(
    (s) => skillCategoryFilter === 'all' || s.category === skillCategoryFilter
  );

  const selectedSkill = skills.find((s) => s.id === selectedSkillId) || filteredSkills[0] || skills[0];
  const currentLevelObj = selectedSkill?.levels.find((l) => l.level === selectedSkill.currentLevel);

  useEffect(() => {
    if (initialSkillId) {
      setSelectedSkillId(initialSkillId);
    }
  }, [initialSkillId]);

  useEffect(() => {
    if (isHolding) {
      const startTime = Date.now() - holdTimerSec * 1000;
      holdIntervalRef.current = window.setInterval(() => {
        setHoldTimerSec(Math.floor((Date.now() - startTime) / 1000));
      }, 100);
    } else {
      if (holdIntervalRef.current) clearInterval(holdIntervalRef.current);
    }

    return () => {
      if (holdIntervalRef.current) clearInterval(holdIntervalRef.current);
    };
  }, [isHolding]);

  const handleStartHold = () => {
    setHoldTimerSec(0);
    setTestResult(null);
    setIsHolding(true);
  };

  const handleStopHold = () => {
    setIsHolding(false);
    if (holdTimerSec > 0) {
      const result = logSkillHold(selectedSkill.id, holdTimerSec);
      setTestResult(result);
    }
  };

  return (
    <div className="space-y-5 pb-28 pt-2">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight">Calisthenics Skills</h1>
        <p className="text-xs text-slate-400">
          Progression roadmaps, isometric hold test timer & level unlocking
        </p>
      </div>

      {/* Skill Category Filter Bar */}
      <div className="flex items-center gap-1.5 p-1 bg-neutral-900/80 border border-neutral-800 rounded-xl">
        {(['all', 'push', 'pull', 'core'] as const).map((cat) => (
          <button
            key={cat}
            onClick={() => setSkillCategoryFilter(cat)}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg capitalize transition-colors ${
              skillCategoryFilter === cat
                ? 'bg-cyan-500 text-neutral-950 shadow-sm font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {cat === 'all' ? `All (${skills.length})` : `${cat} (${skills.filter(s => s.category === cat).length})`}
          </button>
        ))}
      </div>

      {/* Skill Selector Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {filteredSkills.map((skill) => (
          <button
            key={skill.id}
            onClick={() => {
              setSelectedSkillId(skill.id);
              setIsHolding(false);
              setHoldTimerSec(0);
              setTestResult(null);
            }}
            className={`px-3.5 py-2 text-xs font-semibold rounded-xl whitespace-nowrap transition-all flex items-center gap-1.5 ${
              selectedSkill.id === skill.id
                ? 'bg-cyan-500 text-neutral-950 font-bold shadow-md shadow-cyan-500/20'
                : 'bg-neutral-900 text-slate-400 hover:text-white border border-neutral-800'
            }`}
          >
            <span>{skill.name}</span>
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded-md ${
                selectedSkill.id === skill.id
                  ? 'bg-neutral-950 text-cyan-400 font-bold'
                  : 'bg-neutral-800 text-slate-400'
              }`}
            >
              Lv.{skill.currentLevel}
            </span>
          </button>
        ))}
      </div>

      {/* Active Skill Showcase Hero Card */}
      <div className="relative rounded-3xl overflow-hidden border border-cyan-500/30 bg-[#12151c] p-5 shadow-xl shadow-cyan-950/30">
        {selectedSkill.imagePath && (
          <div className="absolute inset-0 pointer-events-none opacity-25">
            <img
              src={selectedSkill.imagePath}
              alt={selectedSkill.name}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#12151c] via-[#12151c]/80 to-transparent" />
          </div>
        )}

        <div className="relative z-10 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Skill Mastery Track</span>
            </span>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400 font-mono">
                PR: <strong className="text-white">{selectedSkill.prHoldSec}s</strong>
              </span>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-extrabold text-white tracking-tight">
              {selectedSkill.name}
            </h2>
            <div className="text-xs text-cyan-300 font-medium mt-0.5">
              {selectedSkill.subtitle}
            </div>
          </div>

          {/* Current Level Box with Interactive Progression Line Bar */}
          <div className="p-4 rounded-2xl bg-neutral-950/70 border border-neutral-800/80 space-y-4">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-semibold text-slate-300">
                Tier {selectedSkill.currentLevel} of {selectedSkill.maxLevel}
              </span>
              <span className="font-mono text-cyan-400 font-bold">
                Goal: {currentLevelObj?.targetHoldSec}s hold
              </span>
            </div>

            <div className="text-base font-bold text-white">
              {currentLevelObj?.name}
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              {currentLevelObj?.description}
            </p>

            {/* Hold Requirement Progression Line Bar */}
            {currentLevelObj && (
              <div className="space-y-1.5 pt-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-slate-400 flex items-center gap-1">
                    <span>Hold Mastery:</span>
                    <strong className="text-white font-mono">{selectedSkill.prHoldSec}s</strong>
                    <span className="text-slate-500">/ {currentLevelObj.targetHoldSec}s</span>
                  </span>
                  <span className="font-mono font-bold text-cyan-400">
                    {Math.min(100, Math.round((selectedSkill.prHoldSec / currentLevelObj.targetHoldSec) * 100))}%
                  </span>
                </div>
                {/* Progression Line Bar */}
                <div className="w-full h-2.5 bg-neutral-900 border border-neutral-800 rounded-full overflow-hidden p-0.5">
                  <div
                    style={{
                      width: `${Math.min(100, Math.round((selectedSkill.prHoldSec / currentLevelObj.targetHoldSec) * 100))}%`
                    }}
                    className="h-full rounded-full bg-gradient-to-r from-cyan-600 via-cyan-400 to-cyan-300 transition-all duration-500 glow-cyan-sm"
                  />
                </div>
              </div>
            )}

            {/* 5-Step Connected Progression Line Bar */}
            <div className="pt-3 border-t border-neutral-800/80 space-y-2">
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <span className="font-bold text-slate-300 uppercase tracking-wider text-[10px]">
                  Roadmap Line Track
                </span>
                <span className="text-[10px] text-cyan-400 font-medium">Tap step to switch tier</span>
              </div>

              <div className="relative py-2 px-1">
                {/* Connecting Background Line Track */}
                <div className="absolute top-1/2 left-3 right-3 -translate-y-1/2 h-1 bg-neutral-850 rounded-full z-0" />

                {/* Connecting Filled Progress Line Bar */}
                <div
                  className="absolute top-1/2 left-3 -translate-y-1/2 h-1 bg-gradient-to-r from-cyan-500 to-cyan-400 rounded-full z-0 transition-all duration-500 glow-cyan-sm"
                  style={{
                    width: `calc(${((selectedSkill.currentLevel - 1) / (selectedSkill.maxLevel - 1)) * 100}% - 12px)`
                  }}
                />

                {/* 5 Progression Step Nodes */}
                <div className="flex items-center justify-between relative z-10">
                  {selectedSkill.levels.map((lvl) => {
                    const isCompleted = selectedSkill.currentLevel > lvl.level;
                    const isCurrent = selectedSkill.currentLevel === lvl.level;

                    return (
                      <button
                        key={lvl.level}
                        onClick={() => updateSkillLevel(selectedSkill.id, lvl.level)}
                        className="flex flex-col items-center group focus:outline-none"
                        title={lvl.name}
                      >
                        <div
                          className={`w-7 h-7 rounded-full flex items-center justify-center font-mono text-xs font-bold transition-all duration-300 ${
                            isCurrent
                              ? 'bg-cyan-500 text-neutral-950 ring-4 ring-cyan-500/20 shadow-lg shadow-cyan-500/40 scale-110'
                              : isCompleted
                              ? 'bg-cyan-950 border border-cyan-500/60 text-cyan-400 hover:scale-105'
                              : 'bg-neutral-900 border border-neutral-800 text-slate-500 hover:border-slate-700'
                          }`}
                        >
                          {isCompleted ? (
                            <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />
                          ) : (
                            lvl.level
                          )}
                        </div>
                        <span
                          className={`text-[9px] mt-1 font-semibold truncate max-w-[52px] text-center ${
                            isCurrent
                              ? 'text-cyan-400 font-bold'
                              : isCompleted
                              ? 'text-slate-300'
                              : 'text-slate-500'
                          }`}
                        >
                          {lvl.name.split(' ')[0]}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Hold Test Stopwatch */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-neutral-950 to-cyan-950/30 border border-cyan-500/30 text-center">
            <div className="text-xs font-bold uppercase tracking-wider text-cyan-400 mb-2 flex items-center justify-center gap-1.5">
              <Timer className="w-3.5 h-3.5" />
              <span>Test Max Hold (Stopwatch)</span>
            </div>

            <div className="text-4xl font-extrabold text-white font-mono my-2 tracking-tight">
              {holdTimerSec}s
            </div>

            {testResult && (
              <div className="text-xs font-semibold text-cyan-300 mb-3 animate-in fade-in">
                {testResult.leveledUp ? (
                  <span className="text-emerald-400 flex items-center justify-center gap-1">
                    <Trophy className="w-4 h-4" /> Level Up Unlocked! Advancing to next tier.
                  </span>
                ) : testResult.isNewPr ? (
                  <span className="text-cyan-400 flex items-center justify-center gap-1">
                    <Sparkles className="w-4 h-4" /> New Personal Record Hold Logged!
                  </span>
                ) : (
                  <span>Hold recorded! Keep training to hit {currentLevelObj?.targetHoldSec}s.</span>
                )}
              </div>
            )}

            <div className="flex items-center justify-center gap-3">
              {!isHolding ? (
                <button
                  onClick={handleStartHold}
                  className="px-6 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-bold text-xs rounded-xl shadow-lg shadow-cyan-500/25 transition-all flex items-center gap-2 active:scale-95"
                >
                  <Play className="w-4 h-4 fill-neutral-950" />
                  <span>Start Hold Test</span>
                </button>
              ) : (
                <button
                  onClick={handleStopHold}
                  className="px-6 py-2.5 bg-red-500 hover:bg-red-400 text-white font-bold text-xs rounded-xl shadow-lg shadow-red-500/25 transition-all flex items-center gap-2 active:scale-95 animate-pulse"
                >
                  <Square className="w-4 h-4 fill-white" />
                  <span>Stop & Record Hold</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Progression Roadmap Path */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider">
          Progression Roadmap (Levels 1 - 5)
        </h3>

        <div className="space-y-2.5">
          {selectedSkill.levels.map((lvl) => {
            const isCompleted = selectedSkill.currentLevel > lvl.level;
            const isCurrent = selectedSkill.currentLevel === lvl.level;
            const isLocked = selectedSkill.currentLevel < lvl.level;

            return (
              <div
                key={lvl.level}
                onClick={() => updateSkillLevel(selectedSkill.id, lvl.level)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                  isCurrent
                    ? 'bg-[#141a24] border-cyan-500/60 shadow-md shadow-cyan-950/30'
                    : isCompleted
                    ? 'bg-neutral-900/60 border-neutral-800 hover:border-neutral-700'
                    : 'bg-neutral-950/40 border-neutral-900 opacity-60 hover:opacity-80'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold text-xs font-mono shrink-0 mt-0.5 ${
                        isCurrent
                          ? 'bg-cyan-500 text-neutral-950 shadow-sm'
                          : isCompleted
                          ? 'bg-neutral-800 text-cyan-400'
                          : 'bg-neutral-900 text-slate-500'
                      }`}
                    >
                      {lvl.level}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-white">{lvl.name}</h4>
                        {isCurrent && (
                          <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider bg-cyan-950/60 border border-cyan-500/40 rounded px-1.5 py-0.5">
                            Active
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        {lvl.description}
                      </p>

                      <div className="mt-2 text-[11px] text-slate-400 flex items-center gap-1.5">
                        <span className="font-semibold text-slate-300">Target:</span>
                        <span className="font-mono text-cyan-300">{lvl.targetHoldSec} seconds</span>
                      </div>
                    </div>
                  </div>

                  <div className="shrink-0 pl-2">
                    {isCompleted ? (
                      <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                    ) : isLocked ? (
                      <Lock className="w-4 h-4 text-slate-600" />
                    ) : null}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Form Cues & Training Exercises for Current Level */}
      {currentLevelObj && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="p-4 rounded-2xl bg-[#12151c] border border-neutral-800">
            <h4 className="text-xs font-bold text-cyan-400 uppercase tracking-wider mb-2">
              Key Form Cues
            </h4>
            <ul className="space-y-1.5">
              {currentLevelObj.formCues.map((cue, idx) => (
                <li key={idx} className="text-xs text-slate-300 flex items-start gap-2">
                  <span className="text-cyan-400 mt-0.5">•</span>
                  <span>{cue}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="p-4 rounded-2xl bg-[#12151c] border border-neutral-800">
            <h4 className="text-xs font-bold text-cyan-400 uppercase tracking-wider mb-2">
              Recommended Drills
            </h4>
            <ul className="space-y-1.5">
              {currentLevelObj.trainingExercises.map((drill, idx) => (
                <li key={idx} className="text-xs text-slate-300 flex items-start gap-2">
                  <span className="text-cyan-400 mt-0.5">•</span>
                  <span>{drill}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};
