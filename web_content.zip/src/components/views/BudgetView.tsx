import React, { useState, useMemo } from 'react';
import {
  Transaction,
  Category,
  MonthlyBudget,
  CategoryBudget,
  AppSettings,
  FinancialGoal,
} from '../../types';
import {
  formatCurrency,
  toBanglaDigits,
  getCurrentMonthFormatted,
  getMonthName,
} from '../../utils/formatters';
import { CategoryIcon } from '../CategoryIcon';
import { getDualAccentInfo } from '../../utils/theme';
import {
  Target,
  Globe,
  MoreVertical,
  ChevronRight,
  Plus,
  Calendar,
  Sparkles,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Edit2,
  Trash2,
  DollarSign,
  PiggyBank,
  ShieldCheck,
  Plane,
  Laptop,
  Car,
  Home as HomeIcon,
  Heart,
  Gift,
  X,
} from 'lucide-react';

interface BudgetViewProps {
  transactions: Transaction[];
  categories: Category[];
  budgets: MonthlyBudget[];
  currentBudget: MonthlyBudget;
  onSaveBudget: (budget: MonthlyBudget) => void;
  onOpenBudgetModal: () => void;
  useBanglaDigits: boolean;
  appSettings: AppSettings;
  goals: FinancialGoal[];
  onSaveGoals: (goals: FinancialGoal[]) => void;
  onNavigateToReports?: () => void;
}

export const BudgetView: React.FC<BudgetViewProps> = ({
  transactions = [],
  categories = [],
  budgets = [],
  currentBudget,
  onSaveBudget,
  onOpenBudgetModal,
  useBanglaDigits,
  appSettings,
  goals = [],
  onSaveGoals,
  onNavigateToReports,
}) => {
  const isEn = appSettings.language === 'en';
  const isLight = appSettings.themeMode === 'light';
  const isOled = appSettings.themeMode === 'oled';
  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );

  // 3 Primary Tabs: Monthly (মান্থলি), Yearly (ইয়ারলি), Goal (গোল)
  const [activeTab, setActiveTab] = useState<'monthly' | 'yearly' | 'goal'>('monthly');

  // Category filter state ('all' or specific category ID)
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');
  const [showCategoryFilterModal, setShowCategoryFilterModal] = useState<boolean>(false);

  // Quick Category Limit Edit State
  const [editingCatLimit, setEditingCatLimit] = useState<{ categoryId: string; limit: number } | null>(null);
  const [catLimitInputVal, setCatLimitInputVal] = useState<string>('');

  // Goal Modals State
  const [isGoalModalOpen, setIsGoalModalOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<FinancialGoal | null>(null);
  const [goalTitle, setGoalTitle] = useState('');
  const [goalTargetAmount, setGoalTargetAmount] = useState('');
  const [goalCurrentAmount, setGoalCurrentAmount] = useState('');
  const [goalTargetDate, setGoalTargetDate] = useState('');
  const [goalIcon, setGoalIcon] = useState('ShieldCheck');

  // Goal Deposit Modal State
  const [depositGoal, setDepositGoal] = useState<FinancialGoal | null>(null);
  const [depositAmountInput, setDepositAmountInput] = useState('');

  // Styling helpers
  const cardBg = isLight
    ? 'bg-white border-slate-200/90 shadow-xs'
    : 'bg-slate-900/90 border-slate-700/80 shadow-md';
  const innerBg = isLight ? 'bg-slate-50/80 border-slate-200/70' : 'bg-slate-800/80 border-slate-700/60';
  const headingText = isLight ? 'text-slate-900' : 'text-white';
  const subText = isLight ? 'text-slate-500' : 'text-slate-400';

  // Date and Time Calculations for Current Month
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonthNum = now.getMonth(); // 0-indexed
  const currentDay = now.getDate();
  const daysInMonth = new Date(currentYear, currentMonthNum + 1, 0).getDate();
  const daysRemainingInMonth = Math.max(0, daysInMonth - currentDay);
  const monthDayPacePercent = Math.min(100, Math.max(0, (currentDay / daysInMonth) * 100));

  // Current Month YYYY-MM
  const currentMonthStr = getCurrentMonthFormatted();

  // Current Month Expenses
  const currentMonthExpenses = useMemo(() => {
    return transactions.filter(
      (tx) => tx.type === 'expense' && tx.date && tx.date.startsWith(currentMonthStr)
    );
  }, [transactions, currentMonthStr]);

  // Total Month Spent
  const totalMonthSpent = useMemo(() => {
    return currentMonthExpenses.reduce((sum, tx) => sum + (Number(tx.amount) || 0), 0);
  }, [currentMonthExpenses]);

  // Effective Total Budget Limit
  const totalBudgetLimit = currentBudget?.totalLimit || 50000;

  // Amount you can spend (remaining)
  const amountCanSpendMonth = Math.max(0, totalBudgetLimit - totalMonthSpent);
  const monthSpendRatio = totalBudgetLimit > 0 ? totalMonthSpent / totalBudgetLimit : 0;
  const clampedMonthRatio = Math.min(1, Math.max(0, monthSpendRatio));

  // Category-wise spending in current month
  const categorySpendingMap = useMemo(() => {
    const map = new Map<string, number>();
    currentMonthExpenses.forEach((tx) => {
      const cat = tx.categoryId || 'other';
      map.set(cat, (map.get(cat) || 0) + (Number(tx.amount) || 0));
    });
    return map;
  }, [currentMonthExpenses]);

  // Map of category limits defined in currentBudget
  const categoryLimitsMap = useMemo(() => {
    const map = new Map<string, number>();
    if (Array.isArray(currentBudget?.categoryLimits)) {
      currentBudget.categoryLimits.forEach((cl) => {
        map.set(cl.categoryId, cl.limit);
      });
    }
    return map;
  }, [currentBudget]);

  // Filtered categories for display
  const expenseCategories = useMemo(() => {
    return categories.filter((c) => c.type === 'expense');
  }, [categories]);

  // Active filter category name
  const selectedCategoryObj = useMemo(() => {
    if (selectedCategoryFilter === 'all') return null;
    return expenseCategories.find((c) => c.id === selectedCategoryFilter);
  }, [selectedCategoryFilter, expenseCategories]);

  // Stats for filtered category (if selected)
  const activeDisplayBudget = useMemo(() => {
    if (!selectedCategoryObj) {
      return {
        name: isEn ? 'All Categories' : 'সকল ক্যাটাগরি',
        totalBudget: totalBudgetLimit,
        spent: totalMonthSpent,
        canSpend: amountCanSpendMonth,
        ratio: clampedMonthRatio,
        isOver: totalMonthSpent > totalBudgetLimit,
        overAmount: Math.max(0, totalMonthSpent - totalBudgetLimit),
      };
    }
    const catLimit = categoryLimitsMap.get(selectedCategoryObj.id) || 0;
    const catSpent = categorySpendingMap.get(selectedCategoryObj.id) || 0;
    const catCanSpend = Math.max(0, catLimit - catSpent);
    const catRatio = catLimit > 0 ? Math.min(1, catSpent / catLimit) : 0;
    return {
      name: isEn ? selectedCategoryObj.nameEnglish : selectedCategoryObj.nameBangla,
      totalBudget: catLimit,
      spent: catSpent,
      canSpend: catCanSpend,
      ratio: catRatio,
      isOver: catLimit > 0 && catSpent > catLimit,
      overAmount: catLimit > 0 ? Math.max(0, catSpent - catLimit) : 0,
    };
  }, [
    selectedCategoryObj,
    isEn,
    totalBudgetLimit,
    totalMonthSpent,
    amountCanSpendMonth,
    clampedMonthRatio,
    categoryLimitsMap,
    categorySpendingMap,
  ]);

  // Year Calculations
  const currentYearStr = String(currentYear);
  const currentYearExpenses = useMemo(() => {
    return transactions.filter(
      (tx) => tx.type === 'expense' && tx.date && tx.date.startsWith(currentYearStr)
    );
  }, [transactions, currentYearStr]);

  const totalYearSpent = useMemo(() => {
    return currentYearExpenses.reduce((sum, tx) => sum + (Number(tx.amount) || 0), 0);
  }, [currentYearExpenses]);

  // Estimated Yearly Budget (Monthly total * 12)
  const totalYearBudget = totalBudgetLimit * 12;
  const amountCanSpendYear = Math.max(0, totalYearBudget - totalYearSpent);
  const yearSpendRatio = totalYearBudget > 0 ? Math.min(1, totalYearSpent / totalYearBudget) : 0;

  // Days left in the year
  const endOfYear = new Date(currentYear, 11, 31);
  const daysRemainingInYear = Math.max(0, Math.ceil((endOfYear.getTime() - now.getTime()) / 86400000));

  // Gauge Arc Math
  // Semicircle from 180deg (left) to 0deg (right)
  // radius = 88, center = (110, 100)
  // arc path: M 22 100 A 88 88 0 0 1 198 100
  // arc length: π * 88 ≈ 276.46
  const arcRadius = 88;
  const arcCircumference = Math.PI * arcRadius;
  const activeRatio = activeTab === 'yearly' ? yearSpendRatio : activeDisplayBudget.ratio;
  const strokeDashoffset = arcCircumference * (1 - activeRatio);

  // Indicator circle coordinates on the arc curve:
  // Angle goes from 180deg (ratio=0) to 0deg (ratio=1)
  const indicatorAngleDeg = 180 - activeRatio * 180;
  const indicatorAngleRad = (indicatorAngleDeg * Math.PI) / 180;
  const indicatorX = 110 + arcRadius * Math.cos(indicatorAngleRad);
  const indicatorY = 100 - arcRadius * Math.sin(indicatorAngleRad);

  // Handler to open Quick Category Limit editor
  const handleStartEditCatLimit = (catId: string, currentLimit: number) => {
    setEditingCatLimit({ categoryId: catId, limit: currentLimit });
    setCatLimitInputVal(currentLimit > 0 ? String(currentLimit) : '');
  };

  const handleSaveCatLimit = () => {
    if (!editingCatLimit) return;
    const val = parseFloat(catLimitInputVal) || 0;
    const currentLimits = Array.isArray(currentBudget.categoryLimits) ? currentBudget.categoryLimits : [];
    const filtered = currentLimits.filter((cl) => cl.categoryId !== editingCatLimit.categoryId);
    const updatedLimits: CategoryBudget[] = val > 0 ? [...filtered, { categoryId: editingCatLimit.categoryId, limit: val }] : filtered;

    onSaveBudget({
      ...currentBudget,
      categoryLimits: updatedLimits,
    });
    setEditingCatLimit(null);
  };

  // Goal Form Handlers
  const handleOpenAddGoalModal = () => {
    setEditingGoal(null);
    setGoalTitle('');
    setGoalTargetAmount('');
    setGoalCurrentAmount('');
    setGoalTargetDate('');
    setGoalIcon('ShieldCheck');
    setIsGoalModalOpen(true);
  };

  const handleOpenEditGoal = (goal: FinancialGoal) => {
    setEditingGoal(goal);
    setGoalTitle(goal.title);
    setGoalTargetAmount(String(goal.targetAmount));
    setGoalCurrentAmount(String(goal.currentAmount));
    setGoalTargetDate(goal.targetDate || '');
    setGoalIcon(goal.icon || 'ShieldCheck');
    setIsGoalModalOpen(true);
  };

  const handleSaveGoalForm = (e: React.FormEvent) => {
    e.preventDefault();
    const targetVal = parseFloat(goalTargetAmount) || 0;
    const currentVal = parseFloat(goalCurrentAmount) || 0;
    if (!goalTitle.trim() || targetVal <= 0) return;

    if (editingGoal) {
      const updated = goals.map((g) =>
        g.id === editingGoal.id
          ? {
              ...g,
              title: goalTitle.trim(),
              targetAmount: targetVal,
              currentAmount: currentVal,
              targetDate: goalTargetDate,
              icon: goalIcon,
            }
          : g
      );
      onSaveGoals(updated);
    } else {
      const newGoal: FinancialGoal = {
        id: `goal_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        title: goalTitle.trim(),
        targetAmount: targetVal,
        currentAmount: currentVal,
        targetDate: goalTargetDate,
        icon: goalIcon,
        color: '#10B981',
        createdAt: Date.now(),
      };
      onSaveGoals([...goals, newGoal]);
    }
    setIsGoalModalOpen(false);
  };

  const handleDeleteGoal = (goalId: string) => {
    if (window.confirm(isEn ? 'Are you sure you want to delete this goal?' : 'আপনি কি এই লক্ষ্যটি মুছে ফেলতে চান?')) {
      const filtered = goals.filter((g) => g.id !== goalId);
      onSaveGoals(filtered);
    }
  };

  const handleDepositToGoal = () => {
    if (!depositGoal) return;
    const addVal = parseFloat(depositAmountInput) || 0;
    if (addVal <= 0) return;

    const updated = goals.map((g) =>
      g.id === depositGoal.id
        ? {
            ...g,
            currentAmount: g.currentAmount + addVal,
          }
        : g
    );
    onSaveGoals(updated);
    setDepositGoal(null);
    setDepositAmountInput('');
  };

  return (
    <div className="space-y-4 pb-8 animate-in fade-in duration-200" id="smart-budget-page">
      {/* 1. TOP HEADER: SMART BUDGET & ACCESSORIES */}
      <div className="flex items-center justify-between px-1">
        <div>
          <h1 className={`text-xl sm:text-2xl font-black tracking-tight ${headingText} flex items-center gap-2`}>
            <Target className="w-5 h-5 sm:w-6 sm:h-6 shrink-0" style={{ color: dualAccent.primary.hex }} />
            <span>{isEn ? 'Smart Budget' : 'স্মার্ট বাজেট'}</span>
          </h1>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setShowCategoryFilterModal(true)}
            className={`p-2 rounded-xl border transition cursor-pointer ${
              isLight
                ? 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700'
                : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-300'
            }`}
            title={isEn ? 'Filter Categories' : 'ক্যাটাগরি ফিল্টার'}
          >
            <Globe className="w-4 h-4 text-emerald-500" />
          </button>
          <button
            onClick={onOpenBudgetModal}
            className={`p-2 rounded-xl border transition cursor-pointer ${
              isLight
                ? 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700'
                : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-300'
            }`}
            title={isEn ? 'Budget Settings' : 'বাজেট সেটিংস'}
          >
            <MoreVertical className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 2. THREE PRIMARY TABS: MONTHLY, YEARLY, GOAL (মান্থলি, ইয়ারলি, গোল) */}
      <div
        className={`p-1 rounded-2xl border flex items-center justify-between gap-1 ${
          isLight ? 'bg-slate-100 border-slate-200' : 'bg-slate-900/90 border-slate-800'
        }`}
      >
        <button
          onClick={() => {
            setActiveTab('monthly');
            setSelectedCategoryFilter('all');
          }}
          className={`flex-1 py-2 text-xs font-black rounded-xl transition-all relative ${
            activeTab === 'monthly'
              ? isLight
                ? 'bg-white text-slate-900 shadow-xs'
                : 'bg-slate-800 text-white shadow-xs'
              : isLight
              ? 'text-slate-600 hover:text-slate-900'
              : 'text-slate-400 hover:text-white'
          }`}
          id="budget-tab-monthly"
        >
          <span>{isEn ? 'Monthly' : 'মান্থলি'}</span>
          {activeTab === 'monthly' && (
            <div
              className="absolute bottom-1 left-1/2 -translate-x-1/2 w-5 h-0.5 rounded-full"
              style={{ backgroundColor: dualAccent.primary.hex }}
            />
          )}
        </button>

        <button
          onClick={() => setActiveTab('yearly')}
          className={`flex-1 py-2 text-xs font-black rounded-xl transition-all relative ${
            activeTab === 'yearly'
              ? isLight
                ? 'bg-white text-slate-900 shadow-xs'
                : 'bg-slate-800 text-white shadow-xs'
              : isLight
              ? 'text-slate-600 hover:text-slate-900'
              : 'text-slate-400 hover:text-white'
          }`}
          id="budget-tab-yearly"
        >
          <span>{isEn ? 'Yearly' : 'ইয়ারলি'}</span>
          {activeTab === 'yearly' && (
            <div
              className="absolute bottom-1 left-1/2 -translate-x-1/2 w-5 h-0.5 rounded-full"
              style={{ backgroundColor: dualAccent.primary.hex }}
            />
          )}
        </button>

        <button
          onClick={() => setActiveTab('goal')}
          className={`flex-1 py-2 text-xs font-black rounded-xl transition-all relative ${
            activeTab === 'goal'
              ? isLight
                ? 'bg-white text-slate-900 shadow-xs'
                : 'bg-slate-800 text-white shadow-xs'
              : isLight
              ? 'text-slate-600 hover:text-slate-900'
              : 'text-slate-400 hover:text-white'
          }`}
          id="budget-tab-goal"
        >
          <span>{isEn ? 'Goal' : 'গোল'}</span>
          {activeTab === 'goal' && (
            <div
              className="absolute bottom-1 left-1/2 -translate-x-1/2 w-5 h-0.5 rounded-full"
              style={{ backgroundColor: dualAccent.primary.hex }}
            />
          )}
        </button>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: MONTHLY (মান্থলি) - Matches the exact layout of the attached image */}
      {/* ========================================================================= */}
      {activeTab === 'monthly' && (
        <div className="space-y-4">
          {/* Main Card with Speedometer Arc & 3 Stats */}
          <div className={`${cardBg} rounded-3xl p-5 border relative overflow-hidden transition-colors`}>
            {/* Top Subheader: Category filter button */}
            <button
              onClick={() => setShowCategoryFilterModal(true)}
              className={`flex items-center justify-between w-full pb-3 border-b mb-3 text-left transition group ${
                isLight
                  ? 'border-slate-100 hover:text-emerald-700'
                  : isOled
                  ? 'border-zinc-800 hover:text-emerald-400'
                  : 'border-slate-800 hover:text-emerald-400'
              }`}
            >
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-emerald-500/15 flex items-center justify-center text-emerald-600">
                  <Globe className="w-3.5 h-3.5" />
                </div>
                <span className={`text-sm font-bold ${headingText} group-hover:text-emerald-600`}>
                  {activeDisplayBudget.name}
                </span>
              </div>
              <ChevronRight className={`w-4 h-4 ${subText} group-hover:translate-x-0.5 transition`} />
            </button>

            {/* Semicircular Arc Speedometer */}
            <div className="relative flex flex-col items-center justify-center my-2">
              <svg viewBox="0 0 220 120" className="w-full max-w-[280px] overflow-visible">
                {/* Background Track Arc */}
                <path
                  d="M 22 100 A 88 88 0 0 1 198 100"
                  fill="none"
                  stroke={isLight ? '#e2e8f0' : '#334155'}
                  strokeWidth="12"
                  strokeLinecap="round"
                />

                {/* Active Progress Arc */}
                <path
                  d="M 22 100 A 88 88 0 0 1 198 100"
                  fill="none"
                  stroke={
                    activeDisplayBudget.isOver
                      ? '#ef4444'
                      : activeRatio > 0.85
                      ? '#f59e0b'
                      : '#22c55e'
                  }
                  strokeWidth="12"
                  strokeLinecap="round"
                  strokeDasharray={arcCircumference}
                  strokeDashoffset={strokeDashoffset}
                  className="transition-all duration-700 ease-out"
                />

                {/* Floating Thumb Indicator Dot on Arc Tip */}
                <circle
                  cx={indicatorX}
                  cy={indicatorY}
                  r="7"
                  fill="#ffffff"
                  stroke={
                    activeDisplayBudget.isOver
                      ? '#ef4444'
                      : activeRatio > 0.85
                      ? '#f59e0b'
                      : '#22c55e'
                  }
                  strokeWidth="4"
                  className="transition-all duration-700 ease-out drop-shadow-md"
                />
              </svg>

              {/* Center Content inside Arc */}
              <div className="absolute inset-0 flex flex-col items-center justify-end pb-2 text-center pointer-events-none">
                <p className={`text-[11px] font-semibold ${subText} tracking-wide`}>
                  {isEn ? 'Amount you can spend' : 'খরচ করার মতো বাকি আছে'}
                </p>
                <div
                  className={`text-2xl sm:text-3xl font-black tracking-tight mt-0.5 ${
                    activeDisplayBudget.isOver
                      ? 'text-rose-600 dark:text-rose-400'
                      : 'text-emerald-600 dark:text-emerald-400'
                  }`}
                >
                  {formatCurrency(activeDisplayBudget.canSpend, useBanglaDigits, appSettings.currencySymbol)}
                </div>
                {activeDisplayBudget.isOver && (
                  <span className="text-[10px] font-bold text-rose-500 mt-0.5">
                    {isEn ? 'Over budget by ' : 'বাজেট অতিরিক্ত '}
                    {formatCurrency(activeDisplayBudget.overAmount, useBanglaDigits, appSettings.currencySymbol)}
                  </span>
                )}
              </div>
            </div>

            {/* 3 Metric Columns under Arc (Matching screenshot) */}
            <div
              className={`grid grid-cols-3 gap-2 text-center pt-3 mt-1 border-t ${
                isLight ? 'border-slate-100' : isOled ? 'border-zinc-800' : 'border-slate-800'
              }`}
            >
              {/* Col 1: Total budgets */}
              <div>
                <p className={`text-xs sm:text-sm font-black ${headingText}`}>
                  {formatCurrency(activeDisplayBudget.totalBudget, useBanglaDigits, appSettings.currencySymbol)}
                </p>
                <p className={`text-[10px] font-medium ${subText} mt-0.5`}>
                  {isEn ? 'Total budgets' : 'মোট বাজেট'}
                </p>
              </div>

              {/* Col 2: Total spent */}
              <div>
                <p className={`text-xs sm:text-sm font-black ${activeDisplayBudget.isOver ? 'text-rose-600' : headingText}`}>
                  {formatCurrency(activeDisplayBudget.spent, useBanglaDigits, appSettings.currencySymbol)}
                </p>
                <p className={`text-[10px] font-medium ${subText} mt-0.5`}>
                  {isEn ? 'Total spent' : 'মোট খরচ'}
                </p>
              </div>

              {/* Col 3: End of month */}
              <div>
                <p className={`text-xs sm:text-sm font-black ${headingText}`}>
                  {useBanglaDigits ? toBanglaDigits(daysRemainingInMonth) : daysRemainingInMonth}{' '}
                  {isEn ? 'days' : 'দিন'}
                </p>
                <p className={`text-[10px] font-medium ${subText} mt-0.5`}>
                  {isEn ? 'End of month' : 'মাসের বাকি দিন'}
                </p>
              </div>
            </div>

            {/* "Create Budget" (বাজেট তৈরি করুন) Primary Pill Button */}
            <div className="mt-5 flex justify-center">
              <button
                onClick={onOpenBudgetModal}
                className="w-full sm:w-auto min-w-[200px] py-2.5 px-6 rounded-full font-bold text-xs sm:text-sm text-white hover:brightness-105 active:scale-95 transition flex items-center justify-center gap-2"
                style={dualAccent.primaryButtonStyle}
                id="create-budget-btn"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                <span>{isEn ? 'Create Budget' : 'বাজেট তৈরি / পরিবর্তন করুন'}</span>
              </button>
            </div>
          </div>

          {/* Category Budget Breakdown List (Shows only categories with budget set) */}
          {(() => {
            const budgetedCategories = expenseCategories.filter(
              (cat) => (categoryLimitsMap.get(cat.id) || 0) > 0
            );

            if (budgetedCategories.length === 0) {
              return null;
            }

            return (
              <div className="space-y-3">
                <div className="flex items-center justify-between px-1">
                  <h2 className={`text-xs font-black uppercase tracking-wider ${subText}`}>
                    {isEn ? 'Category Budgets' : 'ক্যাটাগরিভিত্তিক বাজেট'}
                  </h2>
                  <span className={`text-[10px] font-bold ${subText}`}>
                    {isEn
                      ? `${budgetedCategories.length} Categories`
                      : `${useBanglaDigits ? toBanglaDigits(budgetedCategories.length) : budgetedCategories.length}টি ক্যাটাগরি`}
                  </span>
                </div>

                <div className="space-y-2.5">
                  {budgetedCategories.map((cat) => {
                    const limit = categoryLimitsMap.get(cat.id) || 0;
                    const spent = categorySpendingMap.get(cat.id) || 0;
                    const left = Math.max(0, limit - spent);
                    const isOver = limit > 0 && spent > limit;
                    const progressRatio = limit > 0 ? Math.min(100, Math.max(0, (spent / limit) * 100)) : 0;

                    return (
                      <div
                        key={cat.id}
                        className={`${cardBg} rounded-2xl p-3 sm:p-3.5 border transition hover:border-emerald-300 dark:hover:border-emerald-700`}
                      >
                        <div className="flex items-center gap-3">
                          {/* Left: Category Icon */}
                          <div
                            className="w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center shrink-0 shadow-2xs"
                            style={{
                              backgroundColor: `${cat.color || '#10B981'}20`,
                              color: cat.color || '#10B981',
                            }}
                          >
                            <CategoryIcon name={cat.icon} className="w-4 h-4 sm:w-5 sm:h-5" />
                          </div>

                          {/* Right: Content Column */}
                          <div className="flex-1 min-w-0">
                            {/* Top row: Category Name & Budget Limit */}
                            <div className="flex items-center justify-between gap-2">
                              <h3 className={`text-xs sm:text-sm font-bold truncate ${headingText}`}>
                                {isEn ? cat.nameEnglish : cat.nameBangla}
                              </h3>
                              <span className={`text-xs sm:text-sm font-black shrink-0 ${headingText}`}>
                                {formatCurrency(limit, useBanglaDigits, appSettings.currencySymbol)}
                              </span>
                            </div>

                            {/* Bottom row: Left Amount --- Small Progress Bar with Today Marker --- Edit Limit */}
                            <div className="flex items-start justify-between gap-1.5 sm:gap-2 mt-2">
                              {/* Left Amount */}
                              <div className="text-[10px] sm:text-[11px] font-semibold shrink-0 whitespace-nowrap pt-0.5">
                                {isOver ? (
                                  <span className="text-rose-500 font-bold">
                                    {isEn ? 'Over by ' : 'অতিরিক্ত '}{formatCurrency(spent - limit, useBanglaDigits, appSettings.currencySymbol)}
                                  </span>
                                ) : (
                                  <span className={subText}>
                                    {isEn ? 'Left ' : 'বাকি '}
                                    <strong className="text-emerald-600 dark:text-emerald-400 font-bold">
                                      {formatCurrency(left, useBanglaDigits, appSettings.currencySymbol)}
                                    </strong>
                                  </span>
                                )}
                              </div>

                              {/* Small Progress Bar with Today Marker in the Middle */}
                              <div className="flex-1 min-w-[65px] relative mx-1.5 sm:mx-2 pt-1 pb-4 flex flex-col justify-start">
                                {/* Progress Bar Track */}
                                <div
                                  className={`w-full h-1.5 sm:h-2 rounded-full overflow-hidden relative ${
                                    isLight ? 'bg-slate-100' : isOled ? 'bg-zinc-800' : 'bg-slate-800'
                                  }`}
                                  title={`${Math.round(progressRatio)}%`}
                                >
                                  <div
                                    className={`h-full rounded-full transition-all duration-500 ${
                                      isOver
                                        ? 'bg-rose-500'
                                        : progressRatio > 85
                                        ? 'bg-amber-500'
                                        : 'bg-emerald-500'
                                    }`}
                                    style={{ width: `${progressRatio}%` }}
                                  />
                                </div>

                                {/* "Today" Indicator Marker (Showing timeline position in the month like before) */}
                                <div
                                  className="absolute top-0 flex flex-col items-center pointer-events-none -translate-x-1/2 z-10"
                                  style={{ left: `${Math.min(88, Math.max(12, monthDayPacePercent))}%` }}
                                >
                                  <div className="w-0.5 h-2.5 sm:h-3 bg-slate-400 dark:bg-slate-500 mb-0.5" />
                                  <span className="text-[8px] sm:text-[9px] font-bold px-1.5 py-0.2 rounded bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 shadow-2xs whitespace-nowrap">
                                    {isEn ? 'Today' : 'আজ'}
                                  </span>
                                </div>
                              </div>

                              {/* Edit Limit */}
                              <button
                                type="button"
                                onClick={() => handleStartEditCatLimit(cat.id, limit)}
                                className="text-[10px] sm:text-[11px] text-emerald-600 dark:text-emerald-400 font-bold hover:underline shrink-0 whitespace-nowrap cursor-pointer pt-0.5"
                              >
                                {isEn ? 'Edit limit' : 'পরিবর্তন'}
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: YEARLY (ইয়ারলি) - Annual Overview & Trends */}
      {/* ========================================================================= */}
      {activeTab === 'yearly' && (
        <div className="space-y-4">
          <div className={`${cardBg} rounded-3xl p-5 border relative overflow-hidden transition-colors`}>
            {/* Header with year */}
            <div
              className={`flex items-center justify-between pb-3 border-b mb-3 ${
                isLight ? 'border-slate-100' : isOled ? 'border-zinc-800' : 'border-slate-800'
              }`}
            >
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-emerald-500" />
                <span className={`text-sm font-bold ${headingText}`}>
                  {isEn ? `Annual Budget (${currentYear})` : `বাৎসরিক বাজেট (${useBanglaDigits ? toBanglaDigits(currentYear) : currentYear})`}
                </span>
              </div>
              <span className={`text-xs font-semibold ${subText}`}>
                12 {isEn ? 'Months' : 'মাস'}
              </span>
            </div>

            {/* Semicircular Arc Gauge for Yearly */}
            <div className="relative flex flex-col items-center justify-center my-2">
              <svg viewBox="0 0 220 120" className="w-full max-w-[280px] overflow-visible">
                <path
                  d="M 22 100 A 88 88 0 0 1 198 100"
                  fill="none"
                  stroke={isLight ? '#e2e8f0' : '#334155'}
                  strokeWidth="12"
                  strokeLinecap="round"
                />
                <path
                  d="M 22 100 A 88 88 0 0 1 198 100"
                  fill="none"
                  stroke={
                    totalYearSpent > totalYearBudget
                      ? '#ef4444'
                      : yearSpendRatio > 0.85
                      ? '#f59e0b'
                      : '#22c55e'
                  }
                  strokeWidth="12"
                  strokeLinecap="round"
                  strokeDasharray={arcCircumference}
                  strokeDashoffset={strokeDashoffset}
                  className="transition-all duration-700 ease-out"
                />
                <circle
                  cx={indicatorX}
                  cy={indicatorY}
                  r="7"
                  fill="#ffffff"
                  stroke={
                    totalYearSpent > totalYearBudget
                      ? '#ef4444'
                      : yearSpendRatio > 0.85
                      ? '#f59e0b'
                      : '#22c55e'
                  }
                  strokeWidth="4"
                  className="transition-all duration-700 ease-out drop-shadow-md"
                />
              </svg>

              <div className="absolute inset-0 flex flex-col items-center justify-end pb-2 text-center pointer-events-none">
                <p className={`text-[11px] font-semibold ${subText} tracking-wide`}>
                  {isEn ? 'Remaining annual budget' : 'বছরে খরচ করার মতো বাকি আছে'}
                </p>
                <div className="text-2xl sm:text-3xl font-black tracking-tight mt-0.5 text-emerald-600 dark:text-emerald-400">
                  {formatCurrency(amountCanSpendYear, useBanglaDigits, appSettings.currencySymbol)}
                </div>
              </div>
            </div>

            {/* 3 Metric Columns for Year */}
            <div
              className={`grid grid-cols-3 gap-2 text-center pt-3 mt-1 border-t ${
                isLight ? 'border-slate-100' : isOled ? 'border-zinc-800' : 'border-slate-800'
              }`}
            >
              <div>
                <p className={`text-xs sm:text-sm font-black ${headingText}`}>
                  {formatCurrency(totalYearBudget, useBanglaDigits, appSettings.currencySymbol)}
                </p>
                <p className={`text-[10px] font-medium ${subText} mt-0.5`}>
                  {isEn ? 'Yearly budget' : 'বাৎসরিক বাজেট'}
                </p>
              </div>

              <div>
                <p className={`text-xs sm:text-sm font-black ${headingText}`}>
                  {formatCurrency(totalYearSpent, useBanglaDigits, appSettings.currencySymbol)}
                </p>
                <p className={`text-[10px] font-medium ${subText} mt-0.5`}>
                  {isEn ? 'Year spent' : 'চলতি বছর খরচ'}
                </p>
              </div>

              <div>
                <p className={`text-xs sm:text-sm font-black ${headingText}`}>
                  {useBanglaDigits ? toBanglaDigits(daysRemainingInYear) : daysRemainingInYear}{' '}
                  {isEn ? 'days' : 'দিন'}
                </p>
                <p className={`text-[10px] font-medium ${subText} mt-0.5`}>
                  {isEn ? 'End of year' : 'বছরের বাকি দিন'}
                </p>
              </div>
            </div>
          </div>

          {/* Yearly Planning Tips & Category Allocation */}
          <div className={`${cardBg} rounded-2xl p-4 border space-y-3`}>
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <h3 className={`text-xs font-bold ${headingText}`}>
                {isEn ? 'Yearly Budgeting Insights' : 'বাৎসরিক বাজেট বিশ্লেষণ ও পরামর্শ'}
              </h3>
            </div>
            <p className={`text-xs ${subText} leading-relaxed`}>
              {isEn
                ? `Your annual budget is projected at ${formatCurrency(totalYearBudget, useBanglaDigits, appSettings.currencySymbol)} (based on ${formatCurrency(totalBudgetLimit, useBanglaDigits, appSettings.currencySymbol)}/month). You have spent ${((totalYearSpent / (totalYearBudget || 1)) * 100).toFixed(1)}% of your annual allocation so far.`
                : `আপনার মাসিক বাজেট ${formatCurrency(totalBudgetLimit, useBanglaDigits, appSettings.currencySymbol)} অনুযায়ী বাৎসরিক বাজেট নির্ধারিত হয়েছে ${formatCurrency(totalYearBudget, useBanglaDigits, appSettings.currencySymbol)}। চলতি বছরে আপনি এখন পর্যন্ত বরাদ্দের ${toBanglaDigits(((totalYearSpent / (totalYearBudget || 1)) * 100).toFixed(1))}% খরচ করেছেন।`}
            </p>
            <div className="pt-2">
              <button
                onClick={onOpenBudgetModal}
                className="w-full py-2 rounded-xl text-xs font-bold border border-emerald-500/50 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition flex items-center justify-center gap-1.5"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>{isEn ? 'Adjust Monthly Baseline' : 'মাসিক বেসলাইন পরিবর্তন করুন'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: GOAL (গোল) - Financial Goals & Savings Targets */}
      {/* ========================================================================= */}
      {activeTab === 'goal' && (
        <div className="space-y-4">
          {/* Goal Overview Card with Semicircular Curve Bar (Arc Gauge) following Annual Budget */}
          {(() => {
            const totalTarget = goals.reduce((sum, g) => sum + (Number(g.targetAmount) || 0), 0);
            const totalSaved = goals.reduce((sum, g) => sum + (Number(g.currentAmount) || 0), 0);
            const totalRemaining = Math.max(0, totalTarget - totalSaved);
            const overallPercent = totalTarget > 0 ? Math.min(100, Math.round((totalSaved / totalTarget) * 100)) : 0;
            const goalRatio = totalTarget > 0 ? Math.min(1, Math.max(0, totalSaved / totalTarget)) : 0;

            // Gauge Arc Math (radius = 88, arc path from 180deg to 0deg)
            const goalArcCircumference = Math.PI * 88;
            const goalStrokeDashoffset = goalArcCircumference * (1 - goalRatio);
            const goalIndicatorAngleDeg = 180 - goalRatio * 180;
            const goalIndicatorAngleRad = (goalIndicatorAngleDeg * Math.PI) / 180;
            const goalIndicatorX = 110 + 88 * Math.cos(goalIndicatorAngleRad);
            const goalIndicatorY = 100 - 88 * Math.sin(goalIndicatorAngleRad);

            return (
              <div className={`${cardBg} rounded-3xl p-5 border relative overflow-hidden transition-colors shadow-xs`}>
                {/* Header with New Logo & Action Button */}
                <div
                  className={`flex items-center justify-between pb-3 border-b mb-3 ${
                    isLight ? 'border-slate-100' : isOled ? 'border-zinc-800' : 'border-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    {/* New Distinct Logo Badge */}
                    <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl flex items-center justify-center shrink-0 shadow-xs bg-gradient-to-br from-emerald-500/20 via-teal-500/15 to-emerald-600/25 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 dark:border-emerald-400/30 ring-4 ring-emerald-500/5 dark:ring-emerald-400/10">
                      <Target className="w-5 h-5 stroke-[2.2]" />
                    </div>
                    <div>
                      <h2 className={`text-sm sm:text-base font-black tracking-tight ${headingText}`}>
                        {isEn ? 'Financial Goals & Savings' : 'আর্থিক লক্ষ্য ও সঞ্চয়'}
                      </h2>
                      <p className={`text-[10px] sm:text-[11px] font-medium ${subText}`}>
                        {isEn
                          ? `${goals.length} Active Goals`
                          : `${useBanglaDigits ? toBanglaDigits(goals.length) : goals.length}টি সক্রিয় লক্ষ্য`}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={handleOpenAddGoalModal}
                    className="py-1.5 px-3 sm:px-3.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 active:scale-95 transition shadow-xs flex items-center gap-1.5 cursor-pointer shrink-0"
                  >
                    <Plus className="w-3.5 h-3.5 stroke-[3]" />
                    <span>{isEn ? 'New Goal' : 'নতুন লক্ষ্য'}</span>
                  </button>
                </div>

                {/* Semicircular Curve Bar (Arc Gauge) for Goals - following Annual Budget style */}
                <div className="relative flex flex-col items-center justify-center my-2">
                  <svg viewBox="0 0 220 120" className="w-full max-w-[280px] overflow-visible">
                    <defs>
                      <linearGradient id="goalArcGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#10b981" />
                        <stop offset="100%" stopColor="#14b8a6" />
                      </linearGradient>
                    </defs>

                    {/* Track */}
                    <path
                      d="M 22 100 A 88 88 0 0 1 198 100"
                      fill="none"
                      stroke={isLight ? '#e2e8f0' : isOled ? '#27272a' : '#334155'}
                      strokeWidth="12"
                      strokeLinecap="round"
                    />

                    {/* Filled Curve Bar */}
                    <path
                      d="M 22 100 A 88 88 0 0 1 198 100"
                      fill="none"
                      stroke="url(#goalArcGradient)"
                      strokeWidth="12"
                      strokeLinecap="round"
                      strokeDasharray={goalArcCircumference}
                      strokeDashoffset={goalStrokeDashoffset}
                      className="transition-all duration-700 ease-out"
                    />

                    {/* Floating Indicator Dot on Arc Tip */}
                    <circle
                      cx={goalIndicatorX}
                      cy={goalIndicatorY}
                      r="7"
                      fill="#ffffff"
                      stroke="#10b981"
                      strokeWidth="4"
                      className="transition-all duration-700 ease-out drop-shadow-md"
                    />
                  </svg>

                  {/* Center Content inside the Arc Curve */}
                  <div className="absolute inset-0 flex flex-col items-center justify-end pb-2 text-center pointer-events-none">
                    <p className={`text-[11px] font-semibold ${subText} tracking-wide`}>
                      {isEn ? 'Total Saved' : 'মোট সঞ্চিত অর্থ'}
                    </p>
                    <div className="text-2xl sm:text-3xl font-black tracking-tight mt-0.5 text-emerald-600 dark:text-emerald-400">
                      {formatCurrency(totalSaved, useBanglaDigits, appSettings.currencySymbol)}
                    </div>
                    <div className="inline-flex items-center gap-1 mt-1 px-2.5 py-0.5 rounded-full text-[10px] sm:text-xs font-black bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
                      <TrendingUp className="w-3 h-3" />
                      <span>{useBanglaDigits ? toBanglaDigits(overallPercent) : overallPercent}% {isEn ? 'achieved' : 'অর্জিত'}</span>
                    </div>
                  </div>
                </div>

                {/* 3 Metric Columns for Goals - following Annual Budget 3-column layout */}
                <div
                  className={`grid grid-cols-3 gap-2 text-center pt-3 mt-1 border-t ${
                    isLight ? 'border-slate-100' : isOled ? 'border-zinc-800' : 'border-slate-800'
                  }`}
                >
                  <div>
                    <p className={`text-xs sm:text-sm font-black ${headingText}`}>
                      {formatCurrency(totalTarget, useBanglaDigits, appSettings.currencySymbol)}
                    </p>
                    <p className={`text-[10px] font-medium ${subText} mt-0.5`}>
                      {isEn ? 'Target Amount' : 'মোট টার্গেট'}
                    </p>
                  </div>

                  <div>
                    <p className={`text-xs sm:text-sm font-black text-emerald-600 dark:text-emerald-400`}>
                      {formatCurrency(totalSaved, useBanglaDigits, appSettings.currencySymbol)}
                    </p>
                    <p className={`text-[10px] font-medium ${subText} mt-0.5`}>
                      {isEn ? 'Total Saved' : 'মোট সঞ্চিত'}
                    </p>
                  </div>

                  <div>
                    <p className={`text-xs sm:text-sm font-black ${totalRemaining > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-emerald-600 dark:text-emerald-400'}`}>
                      {formatCurrency(totalRemaining, useBanglaDigits, appSettings.currencySymbol)}
                    </p>
                    <p className={`text-[10px] font-medium ${subText} mt-0.5`}>
                      {isEn ? 'Remaining' : 'বাকি আছে'}
                    </p>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Goal Cards List */}
          <div className="space-y-3">
            {goals.length === 0 ? (
              <div className={`${cardBg} rounded-3xl p-7 text-center border space-y-3.5 shadow-xs`}>
                <div className="w-14 h-14 rounded-3xl mx-auto flex items-center justify-center bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">
                  <Target className="w-7 h-7 stroke-[2.2]" />
                </div>
                <div>
                  <p className={`text-sm font-black ${headingText}`}>
                    {isEn ? 'No financial goals added yet' : 'কোনো আর্থিক লক্ষ্য তৈরি করা হয়নি'}
                  </p>
                  <p className={`text-xs ${subText} max-w-xs mx-auto mt-1`}>
                    {isEn
                      ? 'Create a savings goal for emergencies, vacation, hajj, gadgets, or vehicles.'
                      : 'জরুরি তহবিল, ভ্রমণ, গ্যাজেট বা গাড়ির জন্য একটি সঞ্চয় লক্ষ্য নির্ধারণ করুন।'}
                  </p>
                </div>
                <button
                  onClick={handleOpenAddGoalModal}
                  className="py-2.5 px-5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 transition shadow-xs inline-flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                  <span>{isEn ? 'Create First Goal' : 'প্রথম লক্ষ্য তৈরি করুন'}</span>
                </button>
              </div>
            ) : (
              goals.map((goal) => {
                const percent = Math.min(100, Math.round(((goal.currentAmount || 0) / (goal.targetAmount || 1)) * 100));
                const remaining = Math.max(0, (goal.targetAmount || 0) - (goal.currentAmount || 0));

                return (
                  <div
                    key={goal.id}
                    className={`${cardBg} rounded-2xl p-4 border transition hover:border-emerald-300 dark:hover:border-emerald-700 space-y-3`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <div
                          className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 shadow-2xs"
                          style={{
                            backgroundColor: `${goal.color || '#10B981'}20`,
                            color: goal.color || '#10B981',
                          }}
                        >
                          <CategoryIcon name={goal.icon || 'ShieldCheck'} className="w-5 h-5" />
                        </div>
                        <div>
                          <h3 className={`text-xs sm:text-sm font-bold ${headingText}`}>
                            {goal.title}
                          </h3>
                          {goal.targetDate && (
                            <p className={`text-[10px] ${subText} flex items-center gap-1 mt-0.5`}>
                              <Calendar className="w-3 h-3" />
                              <span>{isEn ? `Target: ${goal.targetDate}` : `মেয়াদ: ${goal.targetDate}`}</span>
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleOpenEditGoal(goal)}
                          className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 transition"
                          title={isEn ? 'Edit Goal' : 'সম্পাদনা'}
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteGoal(goal.id)}
                          className="p-1.5 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40 text-slate-400 hover:text-rose-600 transition"
                          title={isEn ? 'Delete Goal' : 'মুছুন'}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className={`font-black ${headingText}`}>
                          {formatCurrency(goal.currentAmount, useBanglaDigits, appSettings.currencySymbol)}
                        </span>
                        <span className={`font-semibold ${subText}`}>
                          {isEn ? 'of ' : 'টার্গেট '}{formatCurrency(goal.targetAmount, useBanglaDigits, appSettings.currencySymbol)}
                        </span>
                      </div>

                      <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                        <div
                          className="h-full rounded-full bg-emerald-500 transition-all duration-500"
                          style={{ width: `${percent}%` }}
                        />
                      </div>

                      <div className="flex items-center justify-between text-[10px]">
                        <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                          {useBanglaDigits ? toBanglaDigits(percent) : percent}% {isEn ? 'achieved' : 'অর্জিত'}
                        </span>
                        <span className={subText}>
                          {isEn ? 'Remaining: ' : 'বাকি: '}{formatCurrency(remaining, useBanglaDigits, appSettings.currencySymbol)}
                        </span>
                      </div>
                    </div>

                    {/* Action: Quick Deposit Money */}
                    <div className="pt-1 flex items-center justify-end">
                      <button
                        onClick={() => {
                          setDepositGoal(goal);
                          setDepositAmountInput('');
                        }}
                        className="py-1.5 px-3 rounded-xl text-xs font-bold border border-emerald-500/50 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition flex items-center gap-1.5"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>{isEn ? 'Deposit / Add Savings' : '+ টাকা জমা দিন'}</span>
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: Quick Category Limit Edit Modal */}
      {/* ========================================================================= */}
      {editingCatLimit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in">
          <div className={`w-full max-w-sm ${cardBg} rounded-3xl p-5 border shadow-2xl space-y-4`}>
            <div className="flex items-center justify-between">
              <h3 className={`text-sm font-black ${headingText}`}>
                {isEn ? 'Set Category Budget Limit' : 'ক্যাটাগরি বাজেট নির্ধারণ'}
              </h3>
              <button
                onClick={() => setEditingCatLimit(null)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <label className={`block text-xs font-semibold ${subText} mb-1`}>
                {isEn ? 'Monthly Budget Limit (৳)' : 'মাসিক বাজেট লিমিট (টাকা)'}
              </label>
              <input
                type="number"
                value={catLimitInputVal}
                onChange={(e) => setCatLimitInputVal(e.target.value)}
                placeholder="e.g. 5000"
                className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                  isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
                autoFocus
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setEditingCatLimit(null)}
                className={`px-3 py-2 rounded-xl text-xs font-bold ${
                  isLight ? 'text-slate-600 hover:bg-slate-100' : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                onClick={handleSaveCatLimit}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 transition"
              >
                {isEn ? 'Save Limit' : 'সংরক্ষণ করুন'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: Category Filter Selection Modal */}
      {/* ========================================================================= */}
      {showCategoryFilterModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in">
          <div className={`w-full max-w-sm ${cardBg} rounded-3xl p-5 border shadow-2xl space-y-4 max-h-[80vh] flex flex-col`}>
            <div
              className={`flex items-center justify-between border-b pb-3 ${
                isLight ? 'border-slate-100' : isOled ? 'border-zinc-800' : 'border-slate-800'
              } shrink-0`}
            >
              <h3 className={`text-sm font-black ${headingText} flex items-center gap-2`}>
                <Globe className="w-4 h-4 text-emerald-500" />
                <span>{isEn ? 'Filter Budget by Category' : 'ক্যাটাগরি অনুযায়ী বাজেট দেখুন'}</span>
              </h3>
              <button
                onClick={() => setShowCategoryFilterModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="overflow-y-auto space-y-1.5 pr-1">
              <button
                onClick={() => {
                  setSelectedCategoryFilter('all');
                  setShowCategoryFilterModal(false);
                }}
                className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between transition ${
                  selectedCategoryFilter === 'all'
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-700 dark:text-emerald-300 font-bold'
                    : isLight
                    ? 'border-slate-200 hover:bg-slate-50'
                    : 'border-slate-800 hover:bg-slate-800/60'
                }`}
              >
                <span className="text-xs font-bold">{isEn ? 'All Categories (Overview)' : 'সকল ক্যাটাগরি (মোট বাজেট)'}</span>
                {selectedCategoryFilter === 'all' && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
              </button>

              {expenseCategories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategoryFilter(cat.id);
                    setShowCategoryFilterModal(false);
                  }}
                  className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between transition ${
                    selectedCategoryFilter === cat.id
                      ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-700 dark:text-emerald-300 font-bold'
                      : isLight
                      ? 'border-slate-200 hover:bg-slate-50'
                      : 'border-slate-800 hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <CategoryIcon name={cat.icon} className="w-4 h-4" color={cat.color} />
                    <span className="text-xs">{isEn ? cat.nameEnglish : cat.nameBangla}</span>
                  </div>
                  {selectedCategoryFilter === cat.id && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: Create / Edit Goal Modal */}
      {/* ========================================================================= */}
      {isGoalModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in">
          <form
            onSubmit={handleSaveGoalForm}
            className={`w-full max-w-sm ${cardBg} rounded-3xl p-5 border shadow-2xl space-y-4`}
          >
            <div
              className={`flex items-center justify-between border-b pb-3 ${
                isLight ? 'border-slate-100' : isOled ? 'border-zinc-800' : 'border-slate-800'
              }`}
            >
              <h3 className={`text-sm font-black ${headingText}`}>
                {editingGoal
                  ? isEn
                    ? 'Edit Savings Goal'
                    : 'সঞ্চয় লক্ষ্য সম্পাদনা'
                  : isEn
                  ? 'Create New Savings Goal'
                  : 'নতুন সঞ্চয় লক্ষ্য তৈরি করুন'}
              </h3>
              <button
                type="button"
                onClick={() => setIsGoalModalOpen(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <label className={`block text-xs font-semibold ${subText} mb-1`}>
                {isEn ? 'Goal Title' : 'লক্ষ্যের নাম'}
              </label>
              <input
                type="text"
                required
                value={goalTitle}
                onChange={(e) => setGoalTitle(e.target.value)}
                placeholder={isEn ? 'e.g. Emergency Fund, Vacation, New Laptop' : 'যেমন: জরুরি তহবিল, ভ্রমণ, নতুন ল্যাপটপ'}
                className={`w-full px-3 py-2 rounded-xl border text-xs font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                  isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className={`block text-xs font-semibold ${subText} mb-1`}>
                  {isEn ? 'Target Amount (৳)' : 'টার্গেট পরিমাণ (৳)'}
                </label>
                <input
                  type="number"
                  required
                  value={goalTargetAmount}
                  onChange={(e) => setGoalTargetAmount(e.target.value)}
                  placeholder="50000"
                  className={`w-full px-3 py-2 rounded-xl border text-xs font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                    isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-800 border-slate-700 text-white'
                  }`}
                />
              </div>

              <div>
                <label className={`block text-xs font-semibold ${subText} mb-1`}>
                  {isEn ? 'Current Saved (৳)' : 'বর্তমান সঞ্চয় (৳)'}
                </label>
                <input
                  type="number"
                  value={goalCurrentAmount}
                  onChange={(e) => setGoalCurrentAmount(e.target.value)}
                  placeholder="0"
                  className={`w-full px-3 py-2 rounded-xl border text-xs font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                    isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-800 border-slate-700 text-white'
                  }`}
                />
              </div>
            </div>

            <div>
              <label className={`block text-xs font-semibold ${subText} mb-1`}>
                {isEn ? 'Target Date (Optional)' : 'টার্গেট তারিখ (ঐচ্ছিক)'}
              </label>
              <input
                type="date"
                value={goalTargetDate}
                onChange={(e) => setGoalTargetDate(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl border text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                  isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsGoalModalOpen(false)}
                className={`px-3 py-2 rounded-xl text-xs font-bold ${
                  isLight ? 'text-slate-600 hover:bg-slate-100' : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 transition"
              >
                {isEn ? 'Save Goal' : 'সংরক্ষণ করুন'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: Quick Deposit to Goal Modal */}
      {/* ========================================================================= */}
      {depositGoal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in">
          <div className={`w-full max-w-sm ${cardBg} rounded-3xl p-5 border shadow-2xl space-y-4`}>
            <div className="flex items-center justify-between">
              <h3 className={`text-sm font-black ${headingText}`}>
                {isEn ? `Add Savings to: ${depositGoal.title}` : `${depositGoal.title}-এ টাকা জমা করুন`}
              </h3>
              <button
                onClick={() => setDepositGoal(null)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <label className={`block text-xs font-semibold ${subText} mb-1`}>
                {isEn ? 'Deposit Amount (৳)' : 'জমার পরিমাণ (টাকা)'}
              </label>
              <input
                type="number"
                value={depositAmountInput}
                onChange={(e) => setDepositAmountInput(e.target.value)}
                placeholder="e.g. 5000"
                className={`w-full px-3.5 py-2.5 rounded-xl border text-sm font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                  isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-800 border-slate-700 text-white'
                }`}
                autoFocus
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setDepositGoal(null)}
                className={`px-3 py-2 rounded-xl text-xs font-bold ${
                  isLight ? 'text-slate-600 hover:bg-slate-100' : 'text-slate-300 hover:bg-slate-800'
                }`}
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                onClick={handleDepositToGoal}
                className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 transition"
              >
                {isEn ? 'Confirm Deposit' : 'জমা নিশ্চিত করুন'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
