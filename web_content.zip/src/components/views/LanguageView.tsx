import React from 'react';
import { AppSettings } from '../../types';
import {
  Languages,
  Check,
  ArrowLeft,
  RotateCcw,
  Globe2,
  DollarSign,
  Binary,
  Calendar,
  Wallet,
  Sparkles,
} from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';

interface LanguageViewProps {
  appSettings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  onBackToSettings: () => void;
}

export const LanguageView: React.FC<LanguageViewProps> = ({
  appSettings,
  onUpdateSettings,
  onBackToSettings,
}) => {
  const isLight = appSettings.themeMode === 'light';
  const isEn = appSettings.language === 'en';

  const cardBg = isLight
    ? 'bg-white/95 border-slate-200/90 shadow-xs'
    : 'bg-slate-800/90 border-slate-700/70 shadow-md';
  const innerCardBg = isLight
    ? 'bg-slate-50/80 border-slate-200/70'
    : 'bg-slate-900/80 border-slate-700/60';
  const headingText = isLight ? 'text-slate-900' : 'text-slate-100';
  const subText = isLight ? 'text-slate-500' : 'text-slate-400';

  const languagesList: {
    id: 'bn' | 'en';
    title: string;
    nativeName: string;
    descriptionEn: string;
    descriptionBn: string;
    badge: string;
  }[] = [
    {
      id: 'bn',
      title: 'Bengali',
      nativeName: 'বাংলা (বাংলাদেশ)',
      descriptionEn: 'Full Bengali interface with localized banking & expense terms.',
      descriptionBn: 'সম্পূর্ণ বাংলা ইন্টারফেস, হিসাব-নিকাশ ও সহজ ভাষা।',
      badge: 'বাংলা',
    },
    {
      id: 'en',
      title: 'English',
      nativeName: 'English (US / Global)',
      descriptionEn: 'Standard international financial terminology in English.',
      descriptionBn: 'আন্তর্জাতিক মানসম্মত স্ট্যান্ডার্ড ইংরেজি ভাষা।',
      badge: 'English',
    },
  ];

  const currencyOptions = [
    { symbol: '৳', code: 'BDT', nameEn: 'Bangladeshi Taka', nameBn: 'বাংলাদেশী টাকা' },
    { symbol: '$', code: 'USD', nameEn: 'US Dollar', nameBn: 'মার্কিন ডলার' },
    { symbol: '€', code: 'EUR', nameEn: 'Euro', nameBn: 'ইউরো' },
    { symbol: '₹', code: 'INR', nameEn: 'Indian Rupee', nameBn: 'ভারতীয় রুপি' },
    { symbol: '£', code: 'GBP', nameEn: 'British Pound', nameBn: 'ব্রিটিশ পাউন্ড' },
    { symbol: '﷼', code: 'SAR', nameEn: 'Saudi Riyal', nameBn: 'সৌদি রিয়াল' },
    { symbol: 'AED', code: 'AED', nameEn: 'UAE Dirham', nameBn: 'ইউএই দিরহাম' },
  ];

  // Sample formatted values for live preview
  const sampleAmount = 14520;
  const formattedSampleAmount = formatCurrency(
    sampleAmount,
    appSettings.useBanglaDigits,
    appSettings.currencySymbol
  );
  const formattedSampleDate = appSettings.useBanglaDigits
    ? '০৩ সেপ্টেম্বর ২০২৬'
    : '03 September 2026';

  return (
    <div className="space-y-5 pb-8 animate-in fade-in duration-200">
      {/* Top Navigation Bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToSettings}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition cursor-pointer ${
            isLight
              ? 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 shadow-xs'
              : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
          }`}
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>{isEn ? 'Back to Settings' : 'সেটিংসে ফিরে যান'}</span>
        </button>

        <span
          className={`text-[10px] font-bold px-2.5 py-1 rounded-full border uppercase tracking-wider ${
            isLight
              ? 'bg-slate-100 text-slate-800 border-slate-200'
              : 'bg-slate-800 text-slate-300 border-slate-700'
          }`}
        >
          {appSettings.language === 'bn' ? 'বাংলা' : 'ENGLISH'} • {appSettings.currencySymbol}
        </span>
      </div>

      {/* Header Title */}
      <div>
        <h1 className={`text-xl font-black ${headingText} flex items-center gap-2`}>
          <Languages className="w-6 h-6 text-cyan-500" />
          <span>{isEn ? 'Language' : 'ভাষা (Language)'}</span>
        </h1>
        <p className={`text-xs ${subText} mt-1`}>
          {isEn
            ? 'Choose display language, digit formats, and financial currency'
            : 'অ্যাপের ভাষা, বাংলা/ইংরেজি সংখ্যা ও মুদ্রা প্রতীক পছন্দমতো নির্ধারণ করুন'}
        </p>
      </div>

      {/* Language Selection */}
      <div className={`${cardBg} border rounded-3xl p-5 space-y-3.5`}>
        <div className="flex items-center justify-between">
          <h2 className={`text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 ${headingText}`}>
            <Globe2 className="w-4 h-4 text-cyan-500" />
            <span>{isEn ? 'App Interface Language' : 'অ্যাপের মূল ভাষা'}</span>
          </h2>
          <span className={`text-[11px] font-medium ${subText}`}>
            {isEn ? 'Select Preferred' : 'পছন্দের ভাষা বাছুন'}
          </span>
        </div>

        <div className="space-y-2.5">
          {languagesList.map((lang) => {
            const isSelected = appSettings.language === lang.id;

            return (
              <button
                key={lang.id}
                onClick={() =>
                  onUpdateSettings({
                    ...appSettings,
                    language: lang.id,
                    useBanglaDigits: lang.id === 'bn',
                  })
                }
                className={`w-full p-4 rounded-2xl border text-left transition flex items-center justify-between gap-3 ${
                  isSelected
                    ? isLight
                      ? 'bg-white border-cyan-500 shadow-md ring-2 ring-cyan-400/40'
                      : 'bg-slate-700/80 border-cyan-400 shadow-md ring-2 ring-cyan-400/40'
                    : isLight
                    ? 'bg-slate-50/80 border-slate-200 hover:bg-slate-100/80'
                    : 'bg-slate-900/60 border-slate-700/70 hover:bg-slate-800/80'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <div
                    className={`w-11 h-11 rounded-2xl border flex items-center justify-center font-bold text-sm ${
                      isSelected
                        ? isLight
                          ? 'bg-cyan-100 text-cyan-800 border-cyan-300 shadow-xs'
                          : 'bg-slate-800 text-cyan-400 border-cyan-500/50'
                        : isLight
                        ? 'bg-white text-slate-800 border-slate-200'
                        : 'bg-slate-800 text-slate-300 border-slate-700'
                    }`}
                  >
                    {lang.id.toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className={`text-xs font-bold ${headingText}`}>
                        {lang.nativeName}
                      </p>
                      {isSelected && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-md border bg-cyan-500/15 text-cyan-600 dark:text-cyan-400 border-cyan-500/30">
                          {isEn ? 'Selected' : 'নির্বাচিত'}
                        </span>
                      )}
                    </div>
                    <p className={`text-[11px] ${subText} mt-0.5`}>
                      {isEn ? lang.descriptionEn : lang.descriptionBn}
                    </p>
                  </div>
                </div>

                <div
                  className={`w-5 h-5 rounded-full border flex items-center justify-center transition shrink-0 ${
                    isSelected
                      ? 'bg-cyan-600 border-cyan-600 text-white'
                      : isLight
                      ? 'border-slate-300 bg-white'
                      : 'border-slate-600 bg-slate-800'
                  }`}
                >
                  {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Number Formatting (Bangla vs English Numerals) */}
      <div className={`${cardBg} border rounded-3xl p-5 space-y-3.5`}>
        <div className="flex items-center justify-between">
          <h2 className={`text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 ${headingText}`}>
            <Binary className="w-4 h-4 text-emerald-500" />
            <span>{isEn ? 'Numeral Format' : 'সংখ্যার ফরম্যাট (Digits)'}</span>
          </h2>
        </div>

        <div className={`p-4 rounded-2xl border ${innerCardBg} flex items-center justify-between gap-3`}>
          <div>
            <p className={`text-xs font-bold ${headingText}`}>
              {isEn ? 'Use Bengali Numerals (০, ১, ২, ৩...)' : 'বাংলা সংখ্যা প্রদর্শন (০, ১, ২, ৩...)'}
            </p>
            <p className={`text-[11px] ${subText} mt-0.5`}>
              {isEn
                ? 'When turned on, amounts and dates will display in Bengali numbers'
                : 'চালু থাকলে সকল হিসাব, টাকার পরিমাণ ও তারিখ বাংলা সংখ্যায় প্রদর্শিত হবে'}
            </p>
          </div>

          <label className="relative inline-flex items-center cursor-pointer shrink-0">
            <input
              type="checkbox"
              checked={appSettings.useBanglaDigits}
              onChange={(e) =>
                onUpdateSettings({
                  ...appSettings,
                  useBanglaDigits: e.target.checked,
                })
              }
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
          </label>
        </div>
      </div>

      {/* Currency Symbol Selection */}
      <div className={`${cardBg} border rounded-3xl p-5 space-y-3.5`}>
        <div className="flex items-center justify-between">
          <h2 className={`text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 ${headingText}`}>
            <DollarSign className="w-4 h-4 text-amber-500" />
            <span>{isEn ? 'Default Currency' : 'মুদ্রা প্রতীক (Currency)'}</span>
          </h2>
          <span className={`text-[11px] font-bold ${isLight ? 'text-amber-700' : 'text-amber-400'}`}>
            {appSettings.currencySymbol}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {currencyOptions.map((curr) => {
            const isSelected = appSettings.currencySymbol === curr.symbol;

            return (
              <button
                key={curr.code}
                onClick={() =>
                  onUpdateSettings({
                    ...appSettings,
                    currencySymbol: curr.symbol,
                  })
                }
                className={`p-3 rounded-2xl border text-left transition flex items-center justify-between gap-2 ${
                  isSelected
                    ? isLight
                      ? 'border-amber-500 bg-amber-50/70 font-bold text-amber-950 ring-2 ring-amber-400/40 shadow-xs'
                      : 'border-amber-400 bg-amber-950/30 font-bold text-white ring-2 ring-amber-400/30'
                    : isLight
                    ? 'border-slate-200 bg-white text-slate-800 hover:bg-slate-50'
                    : 'border-slate-700 bg-slate-900 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-base font-black">{curr.symbol}</span>
                    <span className="text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-black/5 dark:bg-white/10">
                      {curr.code}
                    </span>
                  </div>
                  <p className="text-[10px] mt-0.5 opacity-80 truncate">
                    {isEn ? curr.nameEn : curr.nameBn}
                  </p>
                </div>

                {isSelected && (
                  <Check className="w-4 h-4 text-amber-500 stroke-[3] shrink-0" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Live Sample Preview */}
      <div className={`${cardBg} border rounded-3xl p-5 space-y-3`}>
        <div className="flex items-center justify-between">
          <h2 className={`text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 ${headingText}`}>
            <Sparkles className="w-4 h-4 text-indigo-500" />
            <span>{isEn ? 'Live Formatting Preview' : 'লাইভ ফরম্যাট প্রিভিউ'}</span>
          </h2>
          <span className={`text-[10px] ${subText}`}>
            {isEn ? 'Current Output' : 'বর্তমান আউটপুট'}
          </span>
        </div>

        <div className={`p-4 rounded-2xl border ${innerCardBg} space-y-2.5`}>
          <div className="flex items-center justify-between">
            <span className={`text-xs flex items-center gap-1.5 ${subText}`}>
              <Wallet className="w-3.5 h-3.5" />
              {isEn ? 'Sample Balance' : 'নমুনা ব্যালেন্স:'}
            </span>
            <span className={`text-sm font-black ${headingText}`}>
              {formattedSampleAmount}
            </span>
          </div>

          <div className="flex items-center justify-between pt-1 border-t border-black/5 dark:border-white/5">
            <span className={`text-xs flex items-center gap-1.5 ${subText}`}>
              <Calendar className="w-3.5 h-3.5" />
              {isEn ? 'Sample Date' : 'নমুনা তারিখ:'}
            </span>
            <span className={`text-xs font-semibold ${headingText}`}>
              {formattedSampleDate}
            </span>
          </div>
        </div>
      </div>

      {/* Footer / Reset Action */}
      <div className="pt-1 flex items-center justify-between text-xs">
        <button
          onClick={() =>
            onUpdateSettings({
              ...appSettings,
              language: 'bn',
              useBanglaDigits: true,
              currencySymbol: '৳',
            })
          }
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl transition cursor-pointer ${
            isLight
              ? 'text-slate-600 hover:bg-slate-100'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>{isEn ? 'Reset to Default (বাংলা / ৳)' : 'ডিফল্ট বাংলায় রিসেট করুন'}</span>
        </button>

        <button
          onClick={onBackToSettings}
          className={`px-4 py-2 rounded-xl font-bold transition cursor-pointer ${
            isLight
              ? 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-sm'
              : 'bg-slate-700 hover:bg-slate-600 text-white shadow-sm'
          }`}
        >
          {isEn ? 'Done' : 'সম্পন্ন'}
        </button>
      </div>
    </div>
  );
};
