import React from 'react';
import { useParentControl } from '../../context/ParentControlContext';
import { 
  Smartphone, Battery, Wifi, Shield, Lock, Unlock, 
  Volume2, Camera, Mic, MapPin, Clock, Eye, AlertTriangle, 
  ArrowUpRight, Play, CheckCircle2, Sliders, SmartphoneNfc, QrCode
} from 'lucide-react';

interface DashboardViewProps {
  setActiveTab: (tab: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ setActiveTab }) => {
  const { 
    activeDevice, 
    language, 
    setDeviceLockdown, 
    triggerEmergencySiren,
    stopEmergencySiren,
    sirenPlaying,
    startCameraStream,
    startMicListening,
    setIsSimulatorOpen,
    commandsLog,
    launchAppInSimulator,
    toggleAppBlock,
    showToast
  } = useParentControl();

  if (!activeDevice) return null;

  const isAr = language === 'ar';
  const settings = activeDevice.settings;
  const isLocked = settings.screenLocked;

  const screenTimePercent = Math.min(
    100, 
    Math.round((activeDevice.screenTimeTodayMinutes / activeDevice.screenTimeLimitMinutes) * 100)
  );

  const topApps = [...activeDevice.installedApps]
    .sort((a, b) => b.usedMinutesToday - a.usedMinutesToday)
    .slice(0, 4);

  return (
    <div className="space-y-6">
      {/* Top Device Banner & Quick Stats */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xs transition-colors duration-200">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 sm:gap-6">
          
          {/* Child Identity Info */}
          <div className="flex items-start sm:items-center gap-3 sm:gap-4">
            <div className="relative shrink-0">
              <img 
                src={activeDevice.avatarUrl} 
                alt={activeDevice.childName} 
                className="w-14 h-14 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-indigo-100 dark:border-indigo-900 shadow-xs"
              />
              <span className="absolute -bottom-1 -end-1 w-4 h-4 sm:w-5 sm:h-5 bg-emerald-500 border-2 border-white dark:border-slate-900 rounded-full flex items-center justify-center">
                <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-white rounded-full"></span>
              </span>
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
                <h2 className="text-lg sm:text-2xl font-bold text-slate-900 dark:text-white truncate">
                  {activeDevice.childNameAr} ({activeDevice.childName})
                </h2>
                <span className="text-[10px] sm:text-xs px-2 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-800 font-semibold uppercase">
                  {activeDevice.platform}
                </span>
                <span className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400">
                  {isAr ? `${activeDevice.childAge} سنوات` : `${activeDevice.childAge} yrs`}
                </span>
              </div>

              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-1 flex items-center gap-1 sm:gap-1.5 flex-wrap">
                <Smartphone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span className="font-medium text-slate-900 dark:text-white">{activeDevice.deviceName}</span>
                <span className="text-slate-300 dark:text-slate-600">•</span>
                <span className="text-slate-500 dark:text-slate-400 font-mono text-[11px] sm:text-xs">{activeDevice.model}</span>
                <span className="text-slate-300 dark:text-slate-600">•</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-medium text-[11px] sm:text-xs">{activeDevice.lastSyncTime}</span>
                {activeDevice.pairingCode && (
                  <>
                    <span className="text-slate-300 dark:text-slate-600">•</span>
                    <button
                      onClick={() => setActiveTab('pair')}
                      className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 text-[10px] sm:text-[11px] font-mono font-bold border border-indigo-200 dark:border-indigo-800 transition-colors cursor-pointer"
                      title={isAr ? 'عرض رمز QR للإقران' : 'View QR Pairing Code'}
                    >
                      <QrCode className="w-3 h-3 text-indigo-600 dark:text-indigo-400" />
                      <span>{activeDevice.pairingCode}</span>
                    </button>
                  </>
                )}
              </p>

              {/* Location Tag */}
              <div className="flex items-center gap-1.5 mt-1.5 sm:mt-2 text-[11px] sm:text-xs text-slate-500 dark:text-slate-400">
                <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                <span className="truncate max-w-[220px] sm:max-w-md">{activeDevice.currentLocation.address}</span>
              </div>
            </div>
          </div>

          {/* Quick Hardware Controls Strip (2-Col Grid on Mobile, Flex on Desktop) */}
          <div className="grid grid-cols-2 sm:flex sm:flex-wrap items-center gap-2 sm:gap-2.5 w-full lg:w-auto pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100 dark:border-slate-800">
            {/* Instant Screen Lock */}
            <button
              id="dash-lock-toggle-btn"
              onClick={() => setDeviceLockdown(!isLocked)}
              className={`col-span-2 sm:col-span-1 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all shadow-xs active:scale-95 border ${
                isLocked 
                  ? 'bg-rose-50 dark:bg-rose-950/50 border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 hover:bg-rose-100 dark:hover:bg-rose-900/60' 
                  : 'bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700'
              }`}
            >
              {isLocked ? (
                <>
                  <Lock className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
                  <span>{isAr ? 'إلغاء قفل الجهاز' : 'Unlock Device'}</span>
                </>
              ) : (
                <>
                  <Unlock className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
                  <span>{isAr ? 'قفل الجهاز فورياً' : 'Lock Device Now'}</span>
                </>
              )}
            </button>

            {/* Quick Camera Stream */}
            <button
              id="dash-camera-stream-btn"
              onClick={() => {
                startCameraStream('environment');
                setActiveTab('camera_mic');
              }}
              className="px-3 py-2.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-xs"
            >
              <Camera className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>{isAr ? 'بث الكاميرا' : 'Camera'}</span>
            </button>

            {/* Quick Mic Stream */}
            <button
              id="dash-mic-stream-btn"
              onClick={() => {
                startMicListening();
                setActiveTab('camera_mic');
              }}
              className="px-3 py-2.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-xs"
            >
              <Mic className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
              <span>{isAr ? 'استماع للمايك' : 'Mic'}</span>
            </button>

            {/* Siren Button */}
            <button
              id="dash-siren-btn"
              onClick={sirenPlaying ? stopEmergencySiren : triggerEmergencySiren}
              className={`p-2.5 rounded-xl border text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 transition-all shadow-xs ${
                sirenPlaying
                  ? 'bg-rose-600 text-white border-rose-500 animate-bounce'
                  : 'bg-white dark:bg-slate-800 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-600 dark:text-rose-400 border-slate-200 dark:border-slate-700'
              }`}
              title={isAr ? 'رنين وصفارة إنذار عالية' : 'Ring Siren'}
            >
              <Volume2 className="w-4 h-4 shrink-0" />
              <span className="sm:hidden text-xs">{isAr ? 'صفارة إنذار' : 'Siren'}</span>
            </button>

            {/* Live Child Simulator Trigger */}
            <button
              id="dash-simulator-trigger-btn"
              onClick={() => setIsSimulatorOpen(true)}
              className="p-2.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-xs"
              title={isAr ? 'فتح محاكي شاشة الطفل' : 'Open Child Phone Simulator'}
            >
              <Eye className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
              <span className="sm:hidden text-xs">{isAr ? 'محاكي الطفل' : 'Simulator'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Grid of Key Status Cards (2x2 on Mobile, 4 Cols on Desktop) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Card 1: Screen Time */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 shadow-xs flex flex-col justify-between hover:border-slate-300 dark:hover:border-slate-700 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
              {isAr ? 'وقت الشاشة اليوم' : 'Screen Time Today'}
            </span>
            <div className="p-2 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 rounded-xl">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          
          <div className="my-3">
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-slate-900 dark:text-white font-mono">
                {Math.floor(activeDevice.screenTimeTodayMinutes / 60)}h {activeDevice.screenTimeTodayMinutes % 60}m
              </span>
              <span className="text-xs text-slate-400 dark:text-slate-500">
                / {Math.floor(activeDevice.screenTimeLimitMinutes / 60)}h
              </span>
            </div>
            {/* Progress bar */}
            <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 mt-2 overflow-hidden">
              <div 
                className={`h-full rounded-full ${
                  screenTimePercent > 85 ? 'bg-rose-500' : 'bg-indigo-600'
                }`}
                style={{ width: `${screenTimePercent}%` }}
              />
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
            <span>{isAr ? 'الحد الأقصى:' : 'Daily Limit:'} {Math.floor(activeDevice.screenTimeLimitMinutes / 60)} {isAr ? 'ساعات' : 'hours'}</span>
            <span className={screenTimePercent > 85 ? 'text-rose-600 dark:text-rose-400 font-bold' : 'text-emerald-600 dark:text-emerald-400 font-semibold'}>
              {screenTimePercent}%
            </span>
          </div>
        </div>

        {/* Card 2: Battery & Power */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 shadow-xs flex flex-col justify-between hover:border-slate-300 dark:hover:border-slate-700 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
              {isAr ? 'البطارية وحالة الشحن' : 'Battery & Power'}
            </span>
            <div className={`p-2 rounded-xl ${
              activeDevice.batteryLevel < 20 ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400' : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400'
            }`}>
              <Battery className="w-4 h-4" />
            </div>
          </div>

          <div className="my-3">
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-slate-900 dark:text-white font-mono">
                {activeDevice.batteryLevel}%
              </span>
              {activeDevice.isCharging && (
                <span className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
                  {isAr ? '⚡ قيد الشحن' : '⚡ Charging'}
                </span>
              )}
            </div>
            <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 mt-2 overflow-hidden">
              <div 
                className={`h-full rounded-full ${
                  activeDevice.batteryLevel < 20 ? 'bg-rose-500' : 'bg-emerald-500'
                }`}
                style={{ width: `${activeDevice.batteryLevel}%` }}
              />
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
            <span>{activeDevice.simCarrier}</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-medium">{isAr ? 'حالة سليمة' : 'Good Health'}</span>
          </div>
        </div>

        {/* Card 3: Network & Connectivity */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 shadow-xs flex flex-col justify-between hover:border-slate-300 dark:hover:border-slate-700 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
              {isAr ? 'الشبكة والاتصال' : 'Connectivity'}
            </span>
            <div className="p-2 bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 rounded-xl">
              <Wifi className="w-4 h-4" />
            </div>
          </div>

          <div className="my-3">
            <div className="flex items-center gap-2">
              <span className="text-xl font-bold text-slate-900 dark:text-white">
                {settings.wifiEnabled ? (isAr ? 'متصل بالواي فاي' : 'WiFi Connected') : (isAr ? 'بيانات الهاتف' : 'Cellular')}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              {settings.bluetoothEnabled ? 'Bluetooth ON' : 'Bluetooth OFF'} • GPS ON
            </p>
          </div>

          <div className="flex items-center justify-between text-[11px]">
            <button
              onClick={() => setActiveTab('settings')}
              className="text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 font-semibold flex items-center gap-1"
            >
              <span>{isAr ? 'تحكم بالشبكات' : 'Manage Networks'}</span>
              <ArrowUpRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Card 4: Protection Status */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 shadow-xs flex flex-col justify-between hover:border-slate-300 dark:hover:border-slate-700 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
              {isAr ? 'درع الحماية الأبوية' : 'Shield Status'}
            </span>
            <div className="p-2 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 rounded-xl">
              <Shield className="w-4 h-4" />
            </div>
          </div>

          <div className="my-3">
            <div className="flex items-center gap-2">
              <span className="text-xl font-bold text-emerald-600 dark:text-emerald-400">
                {isLocked ? (isAr ? 'الجهاز مقفل' : 'Locked') : (isAr ? 'نشط ومحمي 100%' : '100% Protected')}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              {isAr ? 'فلتر الويب الآمن + منع الحذف مفعل' : 'SafeSearch & Anti-Uninstall ON'}
            </p>
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
            <span>{isAr ? 'المناطق الجغرافية:' : 'Geofences:'} {activeDevice.geofenceZones.length} {isAr ? 'مناطق' : 'zones'}</span>
            <span className="text-emerald-700 dark:text-emerald-300 font-mono text-[10px] bg-emerald-50 dark:bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-200 dark:border-emerald-800">MDM Sync</span>
          </div>
        </div>
      </div>

      {/* Two Column Layout: Top Apps Usage & Interactive Control Center */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Top Apps Breakdown & Quick Management */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <span>{isAr ? 'التطبيقات الأكثر استخداماً اليوم' : 'Most Used Apps Today'}</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                {isAr ? 'يمكنك حظر أي تطبيق بضغطة زر واحدة أو تحديد وقت أقصى' : 'Block any app or set strict daily limits instantly'}
              </p>
            </div>

            <button
              onClick={() => setActiveTab('apps')}
              className="text-xs px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-indigo-600 dark:text-indigo-400 font-semibold flex items-center gap-1 transition-colors border border-slate-200 dark:border-slate-700 shadow-xs"
            >
              <span>{isAr ? 'عرض كافة التطبيقات' : 'View All Apps'}</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {topApps.map((app) => {
              const usedPercent = app.dailyLimitMinutes > 0 
                ? Math.min(100, Math.round((app.usedMinutesToday / app.dailyLimitMinutes) * 100))
                : 30;

              return (
                <div 
                  key={app.id}
                  className="flex flex-col sm:flex-row sm:items-center justify-between p-3 rounded-xl bg-slate-50/70 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/80 hover:bg-slate-50 dark:hover:bg-slate-800 hover:border-slate-300 dark:hover:border-slate-600 transition-all gap-3"
                >
                  <div className="flex items-center gap-3">
                    <img 
                      src={app.icon} 
                      alt={app.name} 
                      className="w-10 h-10 rounded-xl object-contain p-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs" 
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-slate-900 dark:text-white">{isAr ? app.nameAr : app.name}</span>
                        {app.isBlocked && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800 font-semibold">
                            {isAr ? 'محظور' : 'Blocked'}
                          </span>
                        )}
                        <span className="text-[10px] text-slate-500 dark:text-slate-400 uppercase font-mono">
                          {app.category}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                        {app.usedMinutesToday} {isAr ? 'دقيقة مستخدمة اليوم' : 'mins used today'}
                        {app.dailyLimitMinutes > 0 && ` / ${app.dailyLimitMinutes} ${isAr ? 'د' : 'm'}`}
                      </p>
                    </div>
                  </div>

                  {/* Action buttons */}
                  <div className="flex items-center gap-2 self-end sm:self-center">
                    <button
                      onClick={() => launchAppInSimulator(app.id)}
                      className="px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 text-xs font-medium flex items-center gap-1 transition-colors shadow-xs"
                      title={isAr ? 'معاينة التطبيق في محاكي الهاتف' : 'Preview App in Simulator'}
                    >
                      <Play className="w-3 h-3 text-indigo-600 dark:text-indigo-400" />
                      <span className="hidden sm:inline">{isAr ? 'معاينة' : 'Preview'}</span>
                    </button>
                    <button
                      onClick={() => {
                        toggleAppBlock(app.id);
                        showToast(
                          app.isBlocked
                            ? (isAr ? `تم إلغاء حظر تطبيق ${app.nameAr}` : `Unblocked ${app.name}`)
                            : (isAr ? `تم حظر تطبيق ${app.nameAr}` : `Blocked ${app.name}`),
                          app.isBlocked ? 'info' : 'warning'
                        );
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors border shadow-xs ${
                        app.isBlocked
                          ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border-emerald-200 dark:border-emerald-800'
                          : 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 hover:bg-rose-100 dark:hover:bg-rose-900/60 border-rose-200 dark:border-rose-800'
                      }`}
                    >
                      {app.isBlocked ? (isAr ? 'فك الحظر' : 'Unblock') : (isAr ? 'حظر الآن' : 'Block App')}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 1 Col: Live Audit Log & Quick Remote Commands */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <span>{isAr ? 'سجل الأوامر عن بُعد' : 'Remote Audit Log'}</span>
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 font-mono font-semibold">
                Live Sync
              </span>
            </div>

            <div className="mt-3 space-y-2.5 max-h-[290px] overflow-y-auto no-scrollbar">
              {commandsLog.length === 0 ? (
                <div className="py-8 text-center text-slate-400 dark:text-slate-500 text-xs">
                  <CheckCircle2 className="w-8 h-8 text-slate-300 dark:text-slate-650 mx-auto mb-2" />
                  <p>{isAr ? 'كل الأوامر السابقة تم تنفيذها بنجاح' : 'All commands executed successfully'}</p>
                  <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1">
                    {isAr ? 'جرب الضغط على قفل الشاشة أو فك الحظر لتشاهد التحديث المباشر' : 'Try toggling lock or app limits to test'}
                  </p>
                </div>
              ) : (
                commandsLog.map((log) => (
                  <div 
                    key={log.id} 
                    className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200/70 dark:border-slate-700 flex items-center justify-between text-xs"
                  >
                    <div>
                      <p className="font-semibold text-slate-800 dark:text-slate-200">
                        {isAr ? log.commandAr : log.command}
                      </p>
                      <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono">
                        {log.timestamp}
                      </span>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 font-mono font-medium">
                      ✓ {isAr ? 'تم التنفيذ' : 'Executed'}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Quick links footer */}
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <button
              onClick={() => setActiveTab('settings')}
              className="hover:text-slate-900 dark:hover:text-white flex items-center gap-1 font-medium"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>{isAr ? 'كافة الإعدادات' : 'All Settings'}</span>
            </button>
            <button
              onClick={() => setActiveTab('location')}
              className="hover:text-slate-900 dark:hover:text-white flex items-center gap-1 font-medium"
            >
              <MapPin className="w-3.5 h-3.5 text-rose-500" />
              <span>{isAr ? 'الخريطة الحية' : 'Live Map'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
