import React, { useState, useEffect, useMemo } from 'react';
import { Transaction, Category, MonthlyBudget, AppSettings, Account } from '../../types';
import {
  formatCurrency,
  formatDate,
  getPaymentMethodLabel,
  getMonthName,
  getCurrentMonthFormatted,
  toBanglaDigits,
} from '../../utils/formatters';
import { CategoryIcon } from '../CategoryIcon';
import { AccountsBalanceModal } from '../AccountsBalanceModal';
import { getDualAccentInfo } from '../../utils/theme';
import { storage } from '../../utils/storage';
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  AlertTriangle,
  Sparkles,
  SlidersHorizontal,
  X,
  Search,
  Trash2,
  PieChart,
  Target,
  Bot,
  RefreshCw,
  ArrowRightLeft,
  Pencil,
  ShieldCheck,
  ArrowDownLeft,
  ArrowUpRight,
  Clock,
  Handshake,
} from 'lucide-react';

interface DashboardViewProps {
  transactions: Transaction[];
  categories: Category[];
  budget: MonthlyBudget;
  accounts?: Account[];
  onOpenAddModal: () => void;
  onOpenBudgetModal: () => void;
  onDeleteTransaction: (id: string) => void;
  onEditTransaction?: (tx: Transaction) => void;
  onRequestDeleteTransaction?: (tx: Transaction) => void;
  useBanglaDigits: boolean;
  appSettings: AppSettings;
  onNavigateToReports: () => void;
  onNavigateToLoan?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  transactions = [],
  categories = [],
  budget,
  accounts = [],
  onOpenAddModal,
  onOpenBudgetModal,
  onDeleteTransaction,
  onEditTransaction,
  onRequestDeleteTransaction,
  useBanglaDigits,
  appSettings,
  onNavigateToReports,
  onNavigateToLoan,
}) => {
  const safeTransactions = Array.isArray(transactions) ? transactions : [];
  const safeCategories = Array.isArray(categories) ? categories : [];
  const safeAccounts = useMemo(() => {
    return Array.isArray(accounts) && accounts.length > 0
      ? accounts
      : storage.getAccounts();
  }, [accounts]);

  type HistoryFilterType = 'all' | 'income' | 'expense' | 'receivable' | 'payable';
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<HistoryFilterType>('all');
  const [showFilterMenu, setShowFilterMenu] = useState(true);
  const [activeActionTxId, setActiveActionTxId] = useState<string | null>(null);
  const [isAccountsModalOpen, setIsAccountsModalOpen] = useState(false);
  const [aiAdvice, setAiAdvice] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [showAiModal, setShowAiModal] = useState(false);
  const [customAiQuestion, setCustomAiQuestion] = useState('');

  // Close active action buttons when clicking anywhere outside
  useEffect(() => {
    if (!activeActionTxId) return;
    const handleOutsideClick = () => {
      setActiveActionTxId(null);
    };
    window.addEventListener('click', handleOutsideClick);
    return () => window.removeEventListener('click', handleOutsideClick);
  }, [activeActionTxId]);

  // Live Date & Time state
  const [currentDateTime, setCurrentDateTime] = useState<Date>(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatLiveDateTime = (date: Date) => {
    const daysEn = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const daysBn = ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'];
    const weekday = isEn ? daysEn[date.getDay()] : daysBn[date.getDay()];

    const dateFormatted = formatDate(date.toISOString().split('T')[0], isEn ? 'en' : 'bn', useBanglaDigits);

    let hours = date.getHours();
    const minutes = date.getMinutes();
    const seconds = date.getSeconds();
    const isPm = hours >= 12;
    hours = hours % 12;
    hours = hours ? hours : 12;
    const strH = String(hours).padStart(2, '0');
    const strM = String(minutes).padStart(2, '0');
    const strS = String(seconds).padStart(2, '0');
    const period = isPm ? 'PM' : 'AM';
    const rawTime = `${strH}:${strM}:${strS} ${period}`;
    const timeFormatted = useBanglaDigits ? toBanglaDigits(rawTime) : rawTime;

    return {
      weekday,
      dateFormatted,
      timeFormatted,
    };
  };

  const isEn = appSettings.language === 'en';
  const isLight = appSettings.themeMode === 'light';
  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );

  const cardBg = isLight
    ? 'bg-white border-slate-200/80 shadow-2xs'
    : 'bg-slate-850/90 border-slate-750/70 shadow-md';
  const innerCardBg = isLight
    ? 'bg-slate-50/80 border-slate-200/60'
    : 'bg-slate-900/80 border-slate-800/80';
  const headingText = isLight ? 'text-slate-900' : 'text-slate-100';
  const subText = isLight ? 'text-slate-500' : 'text-slate-400';

  const currentMonthKey = getCurrentMonthFormatted();

  // Filter transactions for current month
  const currentMonthTransactions = safeTransactions.filter((tx) =>
    tx.date && tx.date.startsWith(currentMonthKey)
  );

  const totalIncome = currentMonthTransactions
    .filter((tx) => tx.type === 'income')
    .reduce((sum, tx) => sum + tx.amount, 0);

  const totalExpense = currentMonthTransactions
    .filter((tx) => tx.type === 'expense')
    .reduce((sum, tx) => sum + tx.amount, 0);

  const netBalance = totalIncome - totalExpense;

  // Double-entry calculated account balances
  const balancedAccounts = useMemo(() => {
    return storage.calculateAccountBalances(safeAccounts, safeTransactions);
  }, [safeAccounts, safeTransactions]);

  // Cash Wallet Balance
  const cashWalletBalance = useMemo(() => {
    const cashAccounts = balancedAccounts.filter((acc) => acc.type === 'cash');
    if (cashAccounts.length > 0) {
      return cashAccounts.reduce(
        (sum, acc) => sum + (acc.currentBalance ?? acc.openingBalance ?? 0),
        0
      );
    }
    const fallbackCash = balancedAccounts.find((acc) => acc.id === 'acc_cash');
    return fallbackCash ? (fallbackCash.currentBalance ?? fallbackCash.openingBalance ?? 0) : 0;
  }, [balancedAccounts]);

  // Accounts Ledger Net Balance (Wallets + Receivables - Payables)
  const totalAccountsNetBalance = useMemo(() => {
    let walletTotal = 0;
    let receivableTotal = 0;
    let payableTotal = 0;
    balancedAccounts.forEach((acc) => {
      const bal = acc.currentBalance ?? acc.openingBalance ?? 0;
      if (acc.type === 'receivable') {
        receivableTotal += bal;
      } else if (acc.type === 'payable') {
        payableTotal += bal;
      } else {
        walletTotal += bal;
      }
    });
    return walletTotal + receivableTotal - payableTotal;
  }, [balancedAccounts]);

  const effectiveNetBalance = useMemo(() => {
    const hasAccountBalances = balancedAccounts.some(
      (acc) => (acc.currentBalance ?? acc.openingBalance ?? 0) !== 0
    );
    if (hasAccountBalances) {
      return totalAccountsNetBalance;
    }
    return netBalance;
  }, [balancedAccounts, totalAccountsNetBalance, netBalance]);

  // Budget calculations
  const budgetLimit = budget?.totalLimit || 50000;
  const budgetUsedPercent = Math.min(Math.round((totalExpense / budgetLimit) * 100), 100);
  const isBudgetExceeded = totalExpense > budgetLimit;
  const isBudgetNearThreshold =
    budgetUsedPercent >= (budget?.alertThreshold || 80) && !isBudgetExceeded;

  // Helper to detect Receivable transaction
  const isReceivableTransaction = (tx: Transaction): boolean => {
    if (tx.type === ('receivable' as any)) return true;
    const sourceAcc = safeAccounts.find((a) => a.id === tx.accountId);
    if (sourceAcc?.type === 'receivable' || tx.accountId === 'acc_receivable') return true;
    if (tx.fromAccountId === 'acc_receivable' || tx.toAccountId === 'acc_receivable') return true;
    const fromAcc = safeAccounts.find((a) => a.id === tx.fromAccountId);
    const toAcc = safeAccounts.find((a) => a.id === tx.toAccountId);
    if (fromAcc?.type === 'receivable' || toAcc?.type === 'receivable') return true;
    if (tx.ledgerAccountId) {
      const ledgerAcc = safeAccounts.find((a) => a.id === tx.ledgerAccountId);
      if (ledgerAcc?.type === 'receivable') return true;
    }
    const note = (tx.note || '').toLowerCase();
    const category = safeCategories.find((c) => c.id === tx.categoryId);
    const catName = category ? `${category.nameBangla} ${category.nameEnglish}`.toLowerCase() : '';
    if (
      note.includes('receivable') ||
      note.includes('ধার দেওয়া') ||
      note.includes('দেনাদার') ||
      catName.includes('receivable') ||
      catName.includes('ধার দেওয়া')
    ) {
      return true;
    }
    return false;
  };

  // Helper to detect Payable transaction
  const isPayableTransaction = (tx: Transaction): boolean => {
    if (tx.type === ('payable' as any)) return true;
    const sourceAcc = safeAccounts.find((a) => a.id === tx.accountId);
    if (sourceAcc?.type === 'payable' || tx.accountId === 'acc_payable') return true;
    if (tx.fromAccountId === 'acc_payable' || tx.toAccountId === 'acc_payable') return true;
    const fromAcc = safeAccounts.find((a) => a.id === tx.fromAccountId);
    const toAcc = safeAccounts.find((a) => a.id === tx.toAccountId);
    if (fromAcc?.type === 'payable' || toAcc?.type === 'payable') return true;
    if (tx.ledgerAccountId) {
      const ledgerAcc = safeAccounts.find((a) => a.id === tx.ledgerAccountId);
      if (ledgerAcc?.type === 'payable') return true;
    }
    const note = (tx.note || '').toLowerCase();
    const category = safeCategories.find((c) => c.id === tx.categoryId);
    const catName = category ? `${category.nameBangla} ${category.nameEnglish}`.toLowerCase() : '';
    if (
      note.includes('payable') ||
      note.includes('ধার নেওয়া') ||
      note.includes('পাওনাদার') ||
      note.includes('লোন') ||
      catName.includes('payable') ||
      catName.includes('ধার নেওয়া')
    ) {
      return true;
    }
    return false;
  };

  // Search & Filtered transactions
  const displayedTransactions = safeTransactions.filter((tx) => {
    const category = safeCategories.find((c) => c.id === tx.categoryId);
    const catName = category
      ? `${category.nameBangla} ${category.nameEnglish}`.toLowerCase()
      : '';
    const note = (tx.note || '').toLowerCase();
    const matchesSearch =
      catName.includes(searchTerm.toLowerCase()) || note.includes(searchTerm.toLowerCase());

    let matchesType = false;
    if (filterType === 'all') {
      matchesType = true;
    } else if (filterType === 'income') {
      matchesType = tx.type === 'income';
    } else if (filterType === 'expense') {
      matchesType = tx.type === 'expense';
    } else if (filterType === 'receivable') {
      matchesType = isReceivableTransaction(tx);
    } else if (filterType === 'payable') {
      matchesType = isPayableTransaction(tx);
    }

    return matchesSearch && matchesType;
  });

  // Top expense categories for AI advice
  const categoryExpenseMap: Record<string, number> = {};
  currentMonthTransactions
    .filter((tx) => tx.type === 'expense')
    .forEach((tx) => {
      categoryExpenseMap[tx.categoryId] = (categoryExpenseMap[tx.categoryId] || 0) + tx.amount;
    });

  const topExpenseCategories = Object.entries(categoryExpenseMap)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([catId, amount]) => {
      const cat = safeCategories.find((c) => c.id === catId);
      const name = cat ? (isEn ? cat.nameEnglish : cat.nameBangla) : catId;
      return `${name}: ৳${amount}`;
    });

  const fetchAiAdvice = async (question?: string) => {
    setIsAiLoading(true);
    setShowAiModal(true);
    try {
      const res = await fetch('/api/advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          income: totalIncome,
          expense: totalExpense,
          topCategories: topExpenseCategories,
          month: getMonthName(currentMonthKey, appSettings.language, useBanglaDigits),
          budgetStatus: isBudgetExceeded
            ? (isEn ? 'Budget exceeded!' : 'বাজেট সীমা ছাড়িয়ে গেছে!')
            : (isEn ? `${budgetUsedPercent}% of budget spent` : `বাজেটের ${budgetUsedPercent}% ব্যবহৃত`),
          customQuestion: question || undefined,
          language: appSettings.language,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setAiAdvice(data.advice);
      } else {
        setAiAdvice(
          isEn
            ? 'Sorry, could not load AI advice. Please check your connection.'
            : 'দুঃখিত, পরামর্শ লোড করা যায়নি। ইন্টারনেট বা সার্ভিস চেক করুন।'
        );
      }
    } catch (err) {
      setAiAdvice(
        isEn
          ? 'Unable to connect to AI server in offline mode.'
          : 'অফলাইন মোডে থাকার কারণে এআই পরামর্শ সরাসরি সার্ভার থেকে লোড হতে পারেনি।'
      );
    } finally {
      setIsAiLoading(false);
    }
  };

  return (
    <div className="space-y-5 pb-8">
      {/* Header: Onu Summary with Live Time & Date underneath, and Floating AI Button */}
      {(() => {
        const liveInfo = formatLiveDateTime(currentDateTime);
        return (
          <div className="flex items-center justify-between gap-3">
            <div>
              <h1 className={`text-2xl sm:text-3xl font-black tracking-tight ${headingText}`}>
                Onu Summary
              </h1>
              <div className="flex items-center gap-2 mt-0.5 text-xs">
                <span className="relative flex h-2 w-2 shrink-0">
                  <span
                    className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75"
                    style={{ backgroundColor: dualAccent.primary.hex }}
                  />
                  <span
                    className="relative inline-flex rounded-full h-2 w-2"
                    style={{ backgroundColor: dualAccent.primary.hex }}
                  />
                </span>
                <span className={`font-semibold ${subText} text-xs`}>
                  {liveInfo.weekday}, {liveInfo.dateFormatted}
                </span>
                <span className={`${subText} opacity-50`}>•</span>
                <span
                  className="font-mono font-bold tracking-wide tabular-nums text-xs"
                  style={{ color: dualAccent.primary.hex }}
                >
                  {liveInfo.timeFormatted}
                </span>
              </div>
            </div>

            <button
              onClick={() => fetchAiAdvice()}
              className="flex items-center gap-1.5 px-3 py-1.5 text-white font-bold text-xs rounded-full transition hover:scale-105 active:scale-95 shadow-md shrink-0"
              style={dualAccent.buttonStyle}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isEn ? 'AI Advisor' : 'এআই পরামর্শ'}</span>
            </button>
          </div>
        );
      })()}

      {/* Main Balance Card */}
      <div
        className={`relative overflow-hidden ${
          isLight
            ? 'bg-gradient-to-br from-white via-slate-50/50 to-slate-100/40 border-slate-200/90 text-slate-900 shadow-sm'
            : 'bg-gradient-to-br from-slate-800 via-slate-800 to-slate-900 border-slate-700/60 text-white shadow-2xl'
        } border rounded-3xl px-4.5 py-3.5 sm:px-6 sm:py-4`}
        style={dualAccent.cardAccentBorder}
      >
        <div
          className="absolute top-0 right-0 w-36 h-36 rounded-full blur-2xl pointer-events-none opacity-20"
          style={{ backgroundColor: dualAccent.secondary.hex }}
        />
        <div
          className="absolute bottom-0 left-0 w-28 h-28 rounded-full blur-2xl pointer-events-none opacity-15"
          style={{ backgroundColor: dualAccent.primary.hex }}
        />

        {/* Top Header: Current Balance */}
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0 flex-1">
            <div
              className={`flex items-center gap-1.5 text-xs font-semibold ${
                isLight ? 'text-slate-600' : 'text-gray-400'
              }`}
            >
              <Wallet className="w-4 h-4 shrink-0" style={{ color: dualAccent.primary.hex }} />
              <span className="truncate">{isEn ? 'Current Balance' : 'বর্তমান ব্যালেন্স'}</span>
            </div>
            <div className={`text-3xl sm:text-4xl font-black tracking-tight my-0.5 truncate ${headingText}`}>
              {formatCurrency(netBalance, useBanglaDigits, appSettings.currencySymbol)}
            </div>
            <button
              id="dashboard-available-cash-btn"
              type="button"
              onClick={() => setIsAccountsModalOpen(true)}
              className="flex items-center gap-1.5 sm:gap-2 text-sm sm:text-[15px] font-medium text-slate-600 dark:text-slate-300 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors truncate mt-0.5 text-left group cursor-pointer focus:outline-hidden"
              title={
                isEn
                  ? 'Available cash in wallet - Tap for accounts breakdown'
                  : 'ওয়ালেটে সহজলভ্য ক্যাশ - হিসাবের বিস্তারিত দেখতে ট্যাপ করুন'
              }
            >
              <span className="text-slate-500 dark:text-slate-400 group-hover:text-slate-700 dark:group-hover:text-slate-200 transition-colors shrink-0 font-medium">
                {isEn ? 'Available:' : 'এভেলেবল:'}
              </span>
              <span
                className={`font-black tracking-tight truncate text-sm sm:text-base ${
                  cashWalletBalance < 0
                    ? 'text-red-500 dark:text-red-400'
                    : 'text-emerald-600 dark:text-emerald-400'
                }`}
              >
                {formatCurrency(cashWalletBalance, useBanglaDigits, appSettings.currencySymbol)}
              </span>
            </button>
          </div>

          <button
            id="accounts-balance-trigger-btn"
            type="button"
            onClick={() => setIsAccountsModalOpen(true)}
            className="group relative shrink-0 w-24 h-24 sm:w-28 sm:h-28 -mt-2 sm:-mt-2.5 mb-0 rounded-full p-2 flex flex-col items-center justify-center text-center hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer focus:outline-hidden focus:ring-2 focus:ring-[var(--color-primary)] select-none"
            style={{
              background: isLight
                ? `radial-gradient(circle at center, ${dualAccent.primary.hex}26 0%, ${dualAccent.primary.hex}0c 65%, #ffffff 100%)`
                : `radial-gradient(circle at center, ${dualAccent.primary.hex}36 0%, ${dualAccent.primary.hex}14 65%, #1e293b 100%)`,
              boxShadow: isLight
                ? '-5px 5px 16px 2px #ffffff, -2px 2px 7px rgba(255, 255, 255, 0.95), 2px -2px 10px rgba(15, 23, 42, 0.07)'
                : '-5px 5px 20px 2px rgba(255, 255, 255, 0.5), -2px 2px 7px rgba(255, 255, 255, 0.85), 2px -2px 12px rgba(0, 0, 0, 0.4)',
            }}
            title={isEn ? 'Net Balance - Touch for accounts breakdown' : 'নেট ব্যালেন্স - হিসাবের বিস্তারিত দেখতে টাচ করুন'}
            aria-label={isEn ? 'Net Balance' : 'নেট ব্যালেন্স'}
          >
            <span
              className="relative z-10 text-xs sm:text-[13px] font-bold leading-none tracking-tight block truncate max-w-full px-1 text-slate-500 dark:text-slate-400"
            >
              {isEn ? 'Net Balance' : 'নেট ব্যালেন্স'}
            </span>
            <span
              className="relative z-10 text-sm sm:text-base font-black tracking-tight leading-tight mt-1.5 px-1 truncate max-w-full block"
              style={{
                color: effectiveNetBalance < 0 ? '#ef4444' : dualAccent.primary.hex,
              }}
            >
              {formatCurrency(effectiveNetBalance, useBanglaDigits, appSettings.currencySymbol)}
            </span>
          </button>
        </div>

        {/* Income vs Expense Grid */}
        <div
          className={`grid grid-cols-2 gap-3 mt-3 pt-3 border-t ${
            isLight ? 'border-slate-200/80' : 'border-gray-800/80'
          }`}
        >
          <div
            className={`px-3 py-2 sm:py-2.5 rounded-2xl border flex items-center gap-3 ${
              isLight
                ? 'bg-white/90 border-slate-200/80'
                : 'bg-gray-950/60 border-gray-800/80'
            }`}
          >
            <div
              className="p-2 rounded-xl"
              style={dualAccent.iconBoxPrimaryStyle}
            >
              <TrendingUp className="w-4 h-4" />
            </div>
            <div>
              <p className={`text-xs font-semibold ${subText}`}>
                {isEn ? 'Total Income' : 'মোট আয়'}
              </p>
              <p
                className="text-base font-black"
                style={{ color: dualAccent.primary.hex }}
              >
                {formatCurrency(totalIncome, useBanglaDigits)}
              </p>
            </div>
          </div>

          <div
            className={`px-3 py-2 sm:py-2.5 rounded-2xl border flex items-center gap-3 ${
              isLight
                ? 'bg-white/90 border-slate-200/80'
                : 'bg-gray-950/60 border-gray-800/80'
            }`}
          >
            <div
              className={`p-2 rounded-xl ${
                isLight ? 'bg-rose-100 text-rose-800' : 'bg-rose-950 text-rose-400'
              }`}
            >
              <TrendingDown className="w-4 h-4" />
            </div>
            <div>
              <p className={`text-xs font-semibold ${subText}`}>
                {isEn ? 'Total Expense' : 'মোট খরচ'}
              </p>
              <p
                className={`text-base font-bold ${
                  isLight ? 'text-rose-700 font-extrabold' : 'text-rose-400'
                }`}
              >
                {formatCurrency(totalExpense, useBanglaDigits)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Monthly Budget Gauge Card */}
      <div className={`${cardBg} rounded-3xl p-5 space-y-3`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Target className="w-4 h-4" style={{ color: dualAccent.primary.hex }} />
            <h2 className={`text-xs font-bold uppercase tracking-wider ${headingText}`}>
              {isEn ? 'Monthly Budget Tracker' : 'মাসিক বাজেট ট্র্যাকার'}
            </h2>
          </div>
          <button
            onClick={onOpenBudgetModal}
            className="text-xs hover:underline font-bold underline-offset-2 transition"
            style={{ color: dualAccent.primary.hex }}
          >
            {isEn ? 'Set Budget' : 'বাজেট সেট করুন'}
          </button>
        </div>

        <div>
          <div className="flex justify-between items-baseline text-xs mb-1.5">
            <span className={subText}>
              {isEn ? 'Limit: ' : 'সীমা: '}
              {formatCurrency(budgetLimit, useBanglaDigits)}
            </span>
            <span
              className={`font-bold ${
                isBudgetExceeded
                  ? 'text-rose-600 dark:text-rose-400'
                  : isBudgetNearThreshold
                  ? 'text-amber-600 dark:text-amber-400'
                  : ''
              }`}
              style={!isBudgetExceeded && !isBudgetNearThreshold ? { color: dualAccent.primary.hex } : undefined}
            >
              {budgetUsedPercent}% {isEn ? 'used' : 'ব্যবহৃত'} ({formatCurrency(totalExpense, useBanglaDigits)})
            </span>
          </div>

          {/* Progress Bar */}
          <div
            className={`w-full h-3 rounded-full overflow-hidden p-0.5 border ${
              isLight ? 'bg-slate-100 border-slate-200' : 'bg-gray-950 border-gray-800'
            }`}
          >
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                isBudgetExceeded
                  ? 'bg-gradient-to-r from-rose-600 to-red-500'
                  : isBudgetNearThreshold
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500'
                  : ''
              }`}
              style={{
                width: `${Math.min(budgetUsedPercent, 100)}%`,
                ...(isBudgetExceeded || isBudgetNearThreshold ? {} : { background: dualAccent.gradientHorizontal }),
              }}
            />
          </div>
        </div>

        {/* Alert Notifications */}
        {isBudgetExceeded ? (
          <div
            className={`p-3 rounded-2xl flex items-center gap-2.5 text-xs border ${
              isLight
                ? 'bg-rose-50 border-rose-200 text-rose-800'
                : 'bg-rose-950/80 border-rose-600/70 text-rose-200'
            }`}
          >
            <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0" />
            <p>
              <strong className="font-bold">{isEn ? 'Alert:' : 'সতর্কবার্তা:'}</strong>{' '}
              {isEn
                ? `You have exceeded your monthly budget of ${formatCurrency(budgetLimit, useBanglaDigits)}!`
                : `আপনি আপনার নির্ধারণ করা ${formatCurrency(budgetLimit, useBanglaDigits)} টাকা বাজেট অতিক্রম করে ফেলেছেন!`}
            </p>
          </div>
        ) : isBudgetNearThreshold ? (
          <div
            className={`p-3 rounded-2xl flex items-center gap-2.5 text-xs border ${
              isLight
                ? 'bg-amber-50 border-amber-200 text-amber-900'
                : 'bg-amber-950/80 border-amber-600/70 text-amber-200'
            }`}
          >
            <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
            <p>
              <strong className="font-bold">{isEn ? 'Warning:' : 'সাবধানতা:'}</strong>{' '}
              {isEn
                ? `You have spent ${budgetUsedPercent}% of your budget limit.`
                : `আপনি বাজেটের ${budgetUsedPercent}% খরচ করে ফেলেছেন।`}
            </p>
          </div>
        ) : null}
      </div>

      {/* Quick Action Bar */}
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={onNavigateToLoan}
          className="p-3.5 text-white font-bold text-xs rounded-2xl transition flex items-center justify-center gap-2 active:scale-95 shadow-xs hover:opacity-95 cursor-pointer"
          style={dualAccent.primaryButtonStyle}
          id="dashboard-loan-btn"
          title={isEn ? 'Loans & Debts (দেনা/পাওনা)' : 'দেনা/পাওনা হিসাব'}
        >
          <Handshake className="w-4 h-4 stroke-[2.5]" />
          <span>{isEn ? 'Loans & Debts' : 'দেনা/পাওনা'}</span>
        </button>

        <button
          onClick={onNavigateToReports}
          className="p-3.5 text-white font-bold text-xs rounded-2xl transition flex items-center justify-center gap-2 active:scale-95 shadow-xs hover:opacity-95 cursor-pointer"
          style={dualAccent.primaryButtonStyle}
        >
          <PieChart className="w-4 h-4 stroke-[2.5]" />
          <span>{isEn ? 'Reports & Charts' : 'রিপোর্ট ও চার্ট'}</span>
        </button>
      </div>

      {/* Transactions History Header & Filters */}
      <div className={`${cardBg} rounded-3xl p-5 space-y-4`}>
        <div className="flex items-center justify-between gap-3">
          <h2 className={`text-sm font-bold uppercase tracking-wider flex items-center gap-2 ${headingText} truncate`}>
            {isEn
              ? `Transaction History (${displayedTransactions.length})`
              : `লেনদেনের ইতিহাস (${displayedTransactions.length})`}
          </h2>

          {/* Filter Toggle Button at the far right end */}
          <button
            type="button"
            onClick={() => setShowFilterMenu((prev) => !prev)}
            className={`p-1.5 sm:p-2 rounded-xl border transition active:scale-95 cursor-pointer shrink-0 ${
              showFilterMenu || filterType !== 'all'
                ? 'text-white shadow-xs'
                : isLight
                ? 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700 shadow-2xs'
                : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-300'
            }`}
            style={
              showFilterMenu || filterType !== 'all'
                ? dualAccent.primaryButtonStyle
                : undefined
            }
            title={isEn ? 'Filter Transactions' : 'লেনদেন ফিল্টার'}
            aria-label="Filter"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Filter Menu Chips - Compact Single Row / No Scroll */}
        {showFilterMenu && (
          <div
            id="transaction-history-category-tabs"
            className={`p-1 rounded-xl border flex items-center justify-between sm:justify-start gap-1 w-full animate-in fade-in slide-in-from-top-2 duration-150 ${
              isLight
                ? 'bg-slate-100/80 border-slate-200/80'
                : 'bg-slate-900/90 border-slate-800'
            }`}
          >
            <button
              type="button"
              onClick={() => setFilterType('all')}
              className={`px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-lg text-[11px] sm:text-xs font-bold transition whitespace-nowrap cursor-pointer select-none ${
                filterType === 'all'
                  ? 'text-white shadow-xs'
                  : isLight
                  ? 'text-slate-700 hover:text-slate-900 hover:bg-white'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
              style={filterType === 'all' ? dualAccent.primaryButtonStyle : undefined}
              title={isEn ? 'All transactions' : 'সব লেনদেন'}
            >
              {isEn ? 'All' : 'সব'}
            </button>
            <button
              type="button"
              onClick={() => setFilterType('income')}
              className={`px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-lg text-[11px] sm:text-xs font-bold transition whitespace-nowrap cursor-pointer select-none ${
                filterType === 'income'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : isLight
                  ? 'text-emerald-700 hover:text-emerald-950 hover:bg-white/70'
                  : 'text-slate-400 hover:text-emerald-400 hover:bg-slate-800/60'
              }`}
              title={isEn ? 'Income transactions' : 'আয় লেনদেন'}
            >
              {isEn ? 'Income' : 'আয়'}
            </button>
            <button
              type="button"
              onClick={() => setFilterType('expense')}
              className={`px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-lg text-[11px] sm:text-xs font-bold transition whitespace-nowrap cursor-pointer select-none ${
                filterType === 'expense'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : isLight
                  ? 'text-rose-700 hover:text-rose-950 hover:bg-white/70'
                  : 'text-slate-400 hover:text-rose-400 hover:bg-slate-800/60'
              }`}
              title={isEn ? 'Expense transactions' : 'খরচ লেনদেন'}
            >
              {isEn ? 'Expense' : 'খরচ'}
            </button>
            <button
              type="button"
              onClick={() => setFilterType('receivable')}
              className={`px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-lg text-[11px] sm:text-xs font-bold transition whitespace-nowrap cursor-pointer select-none ${
                filterType === 'receivable'
                  ? 'bg-cyan-600 text-white shadow-xs'
                  : isLight
                  ? 'text-cyan-700 hover:text-cyan-950 hover:bg-white/70'
                  : 'text-slate-400 hover:text-cyan-400 hover:bg-slate-800/60'
              }`}
              title={isEn ? 'Receivables (Money owed to you)' : 'রিসিভেবল (পাওনা)'}
            >
              {isEn ? 'Receivables' : 'রিসিভেবল'}
            </button>
            <button
              type="button"
              onClick={() => setFilterType('payable')}
              className={`px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-lg text-[11px] sm:text-xs font-bold transition whitespace-nowrap cursor-pointer select-none ${
                filterType === 'payable'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : isLight
                  ? 'text-rose-700 hover:text-rose-950 hover:bg-white/70'
                  : 'text-slate-400 hover:text-rose-400 hover:bg-slate-800/60'
              }`}
              title={isEn ? 'Payables (Debts you owe)' : 'পেয়েবল (দেনা)'}
            >
              {isEn ? 'Payables' : 'পেয়েবল'}
            </button>
          </div>
        )}

        {/* Search Bar */}
        <div className="relative">
          <Search
            className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2"
            style={{ color: dualAccent.primary.hex }}
          />
          <input
            type="text"
            placeholder={isEn ? 'Search by category or note...' : 'ক্যাটাগরি বা নোট লিখে খুঁজুন...'}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className={`w-full pl-10 pr-9 py-2 rounded-xl text-xs focus:outline-none ${
              isLight
                ? 'bg-slate-50 border border-slate-200 text-slate-900 placeholder-slate-400'
                : 'bg-slate-900 border border-slate-700 text-slate-100 placeholder-slate-400'
            }`}
            style={{ borderColor: `${dualAccent.primary.hex}40` }}
          />
          {searchTerm && (
            <button
              type="button"
              onClick={() => setSearchTerm('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 rounded-full cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Transactions List */}
        <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1">
          {displayedTransactions.length === 0 ? (
            <div className={`py-8 text-center text-xs ${subText}`}>
              {filterType === 'receivable'
                ? isEn
                  ? 'No receivables transactions found.'
                  : 'কোনো রিসিভেবল লেনদেন পাওয়া যায়নি।'
                : filterType === 'payable'
                ? isEn
                  ? 'No payables transactions found.'
                  : 'কোনো পেয়েবল লেনদেন পাওয়া যায়নি।'
                : isEn
                ? 'No transactions found. Tap "+" to add a new transaction.'
                : 'কোনো লেনদেন পাওয়া যায়নি। নতুন লেনদেন যোগ করতে "+" বাটনে চাপুন।'}
            </div>
          ) : (
            displayedTransactions.map((tx, idx) => {
              const cat = categories.find((c) => c.id === tx.categoryId);
              const isIncome = tx.type === 'income';
              const isTransfer = tx.type === 'transfer';
              const isReceivable = isReceivableTransaction(tx);
              const isPayable = isPayableTransaction(tx);

              // Find accounts
              const sourceAccount = accounts.find((a) => a.id === (isTransfer ? tx.fromAccountId : tx.accountId));
              const destAccount = isTransfer ? accounts.find((a) => a.id === tx.toAccountId) : undefined;

              const sectorTitle = isTransfer
                ? isEn
                  ? `${sourceAccount?.nameEnglish || 'From'} ➔ ${destAccount?.nameEnglish || 'To'}`
                  : `${sourceAccount?.nameBangla || 'প্রেরক'} ➔ ${destAccount?.nameBangla || 'প্রাপক'}`
                : cat
                ? isEn
                  ? cat.nameEnglish
                  : cat.nameBangla
                : isReceivable
                ? isEn
                  ? 'Receivables / Loan'
                  : 'ধার দেওয়া / দেনাদার'
                : isPayable
                ? isEn
                  ? 'Payables / Debt'
                  : 'ধার নেওয়া / পাওনাদার'
                : isEn
                ? 'Category'
                : 'খাত / ক্যাটাগরি';

              return (
                <div
                  key={tx.id ? `${tx.id}-${idx}` : `tx-${idx}`}
                  className={`relative flex items-center justify-between gap-2.5 sm:gap-3 p-3 rounded-2xl border transition ${innerCardBg}`}
                >
                  {/* Left: Icon and Details */}
                  <div className="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1">
                    <div
                      className="p-2.5 rounded-xl shrink-0 flex items-center justify-center"
                      style={{
                        backgroundColor: isTransfer
                          ? '#4F46E520'
                          : isReceivable
                          ? '#06B6D420'
                          : isPayable
                          ? '#EF444420'
                          : cat
                          ? `${cat.color}20`
                          : '#37415120',
                        color: isTransfer
                          ? '#6366F1'
                          : isReceivable
                          ? '#06B6D4'
                          : isPayable
                          ? '#EF4444'
                          : cat
                          ? cat.color
                          : '#9CA3AF',
                      }}
                    >
                      {isTransfer ? (
                        <ArrowRightLeft className="w-4 h-4" />
                      ) : isReceivable ? (
                        <ArrowDownLeft className="w-4 h-4" />
                      ) : isPayable ? (
                        <ArrowUpRight className="w-4 h-4" />
                      ) : (
                        <CategoryIcon name={cat?.icon || 'CircleDollarSign'} className="w-4 h-4" />
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      {/* Sector (Category) title - Strictly single line */}
                      <div className="flex items-center gap-1.5 min-w-0 flex-nowrap">
                        <h3
                          className={`text-xs sm:text-[13px] font-bold truncate whitespace-nowrap ${
                            isLight ? 'text-slate-900' : 'text-gray-200'
                          }`}
                          title={sectorTitle}
                        >
                          {sectorTitle}
                        </h3>
                        {sourceAccount && !isTransfer && (
                          <span
                            className="text-[9px] px-1.5 py-0.5 rounded-md font-bold shrink-0 whitespace-nowrap"
                            style={{
                              backgroundColor: `${sourceAccount.color || (isReceivable ? '#06B6D4' : isPayable ? '#EF4444' : '#4F46E5')}18`,
                              color: sourceAccount.color || (isReceivable ? '#06B6D4' : isPayable ? '#EF4444' : '#4F46E5'),
                            }}
                          >
                            {isEn ? sourceAccount.nameEnglish : sourceAccount.nameBangla}
                          </span>
                        )}
                      </div>

                      {/* Date and Payment Method */}
                      <div className={`flex items-center gap-1.5 sm:gap-2 mt-0.5 text-[10px] sm:text-[11px] truncate whitespace-nowrap ${subText}`}>
                        <span className="shrink-0">{formatDate(tx.date, appSettings.language, useBanglaDigits)}</span>
                        <span>•</span>
                        <span className="truncate">
                          {isTransfer
                            ? isEn
                              ? 'Transfer'
                              : 'ট্রান্সফার'
                            : isReceivable
                            ? isEn
                              ? 'Receivables'
                              : 'রিসিভেবল'
                            : isPayable
                            ? isEn
                              ? 'Payables'
                              : 'পেয়েবল'
                            : getPaymentMethodLabel(tx.paymentMethod, appSettings.language)}
                        </span>
                      </div>

                      {/* Optional Note */}
                      {tx.note && (
                        <p className={`text-[10px] mt-0.5 truncate whitespace-nowrap italic ${isLight ? 'text-slate-500' : 'text-gray-500'}`}>
                          "{tx.note}"
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Top-Right Popup: Edit & Delete Icons (shown ONLY after tapping balance) */}
                  {activeActionTxId === tx.id && (
                    <div
                      className={`absolute top-1.5 right-2 flex items-center gap-1 p-0.5 rounded-lg shadow-md border z-20 animate-in fade-in zoom-in-90 duration-150 ${
                        isLight
                          ? 'bg-white/95 border-slate-200 text-slate-800 shadow-slate-900/10'
                          : 'bg-slate-800/95 border-slate-700 text-slate-100 shadow-black/40'
                      }`}
                    >
                      {onEditTransaction && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onEditTransaction(tx);
                            setActiveActionTxId(null);
                          }}
                          className={`p-1.5 rounded-md transition cursor-pointer active:scale-90 ${
                            isLight
                              ? 'text-slate-600 hover:text-indigo-600 hover:bg-slate-100'
                              : 'text-slate-300 hover:text-indigo-400 hover:bg-slate-700'
                          }`}
                          title={isEn ? 'Edit (Password Required)' : 'সম্পাদনা (পাসওয়ার্ড সুরক্ষিত)'}
                          aria-label={isEn ? 'Edit transaction' : 'লেনদেন সম্পাদনা'}
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (onRequestDeleteTransaction) {
                            onRequestDeleteTransaction(tx);
                          } else {
                            onDeleteTransaction(tx.id);
                          }
                          setActiveActionTxId(null);
                        }}
                        className={`p-1.5 rounded-md transition cursor-pointer active:scale-90 ${
                          isLight
                            ? 'text-rose-600 hover:text-rose-700 hover:bg-rose-100'
                            : 'text-rose-400 hover:text-rose-300 hover:bg-rose-950/40'
                        }`}
                        title={isEn ? 'Delete (Password Required)' : 'মুছে ফেলুন (পাসওয়ার্ড সুরক্ষিত)'}
                        aria-label={isEn ? 'Delete transaction' : 'লেনদেন মুছুন'}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}

                  {/* Right: Balance / Amount - Positioned in the vertical center (মাঝ বরাবর) of the card */}
                  <div className="flex items-center justify-end shrink-0 pl-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveActionTxId((prev) => (prev === tx.id ? null : tx.id));
                      }}
                      className={`group/amt flex items-center justify-center px-2 py-1 rounded-xl transition-all cursor-pointer touch-manipulation focus:outline-hidden ${
                        activeActionTxId === tx.id
                          ? isLight
                            ? 'bg-slate-100 ring-1 ring-slate-300'
                            : 'bg-slate-700/80 ring-1 ring-slate-500'
                          : 'hover:bg-slate-100/60 dark:hover:bg-slate-800/60 active:scale-95'
                      }`}
                      title={
                        isEn
                          ? activeActionTxId === tx.id
                            ? 'Tap to hide edit & delete'
                            : 'Tap balance to edit or delete'
                          : activeActionTxId === tx.id
                          ? 'আইকন লুকাতে ট্যাপ করুন'
                          : 'এডিট ও ডিলিট আইকন দেখতে ব্যালেন্সে ট্যাপ করুন'
                      }
                    >
                      <span
                        className={`text-xs sm:text-sm font-black whitespace-nowrap block tracking-tight ${
                          isTransfer
                            ? 'text-indigo-600 dark:text-indigo-400'
                            : isReceivable
                            ? 'text-cyan-600 dark:text-cyan-400'
                            : isPayable
                            ? 'text-rose-600 dark:text-rose-400'
                            : isIncome
                            ? isLight
                              ? 'text-emerald-700'
                              : 'text-emerald-400'
                            : isLight
                            ? 'text-rose-700'
                            : 'text-rose-400'
                        }`}
                      >
                        {isTransfer ? '↔' : isReceivable ? '↙' : isPayable ? '↗' : isIncome ? '+' : '-'} {formatCurrency(tx.amount, useBanglaDigits)}
                      </span>
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* AI Advice Modal Drawer */}
      {showAiModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-xs p-4 animate-in fade-in duration-200">
          <div
            className={`w-full max-w-lg border rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] ${
              isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-slate-800 border-slate-700 text-slate-100'
            }`}
          >
            <div
              className={`flex items-center justify-between px-6 py-4 border-b ${
                isLight ? 'border-slate-200 bg-slate-50' : 'border-slate-700 bg-slate-800/90'
              }`}
            >
              <h2 className={`text-sm font-bold flex items-center gap-2 ${headingText}`}>
                <Bot className="w-5 h-5" style={{ color: dualAccent.primary.hex }} />
                {isEn ? 'Smart AI Financial Advisor' : 'স্মার্ট এআই আর্থিক উপদেষ্টা'}
              </h2>
              <button
                onClick={() => setShowAiModal(false)}
                className={isLight ? 'text-slate-500 hover:text-slate-900' : 'text-gray-400 hover:text-white'}
              >
                ✕
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 text-xs">
              {isAiLoading ? (
                <div className="py-12 flex flex-col items-center justify-center space-y-3">
                  <RefreshCw
                    className="w-8 h-8 animate-spin"
                    style={{ color: dualAccent.primary.hex }}
                  />
                  <p className="font-semibold" style={{ color: dualAccent.primary.hex }}>
                    {isEn
                      ? 'Analyzing your financial data to generate smart recommendations...'
                      : 'আপনার আয়-ব্যয় বিশ্লেষণ করে চমৎকার পরামর্শ তৈরি করা হচ্ছে...'}
                  </p>
                </div>
              ) : (
                <div
                  className={`prose max-w-none space-y-3 leading-relaxed whitespace-pre-line p-4 rounded-2xl border ${
                    isLight
                      ? 'bg-slate-50 text-slate-900 border-slate-200'
                      : 'bg-slate-900 text-slate-100 border-slate-700'
                  }`}
                >
                  {aiAdvice}
                </div>
              )}

              {/* Custom question input for Gemini */}
              <div className={`pt-3 border-t ${isLight ? 'border-slate-200' : 'border-slate-700'}`}>
                <label className={`block text-[11px] font-semibold mb-1.5 ${subText}`}>
                  {isEn
                    ? 'Have a specific question? (e.g., "How can I reduce grocery expenses?")'
                    : 'অতিরিক্ত কোনো প্রশ্ন আছে? (যেমন: "বাড়ি ভাড়া কমানোর বুদ্ধি কি?")'}
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={customAiQuestion}
                    onChange={(e) => setCustomAiQuestion(e.target.value)}
                    placeholder={isEn ? 'Type your question...' : 'প্রশ্ন লিখুন...'}
                    className={`flex-1 px-3 py-2 rounded-xl text-xs focus:outline-none border ${
                      isLight
                        ? 'bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400'
                        : 'bg-slate-900 border-slate-700 text-white placeholder-slate-400'
                    }`}
                  />
                  <button
                    onClick={() => fetchAiAdvice(customAiQuestion)}
                    className="px-4 py-2 font-bold text-white rounded-xl text-xs transition"
                    style={dualAccent.buttonStyle}
                  >
                    {isEn ? 'Ask' : 'জিজ্ঞাসা করুন'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Accounts & Ledger Balance Chart Modal */}
      <AccountsBalanceModal
        isOpen={isAccountsModalOpen}
        onClose={() => setIsAccountsModalOpen(false)}
        accounts={safeAccounts}
        transactions={safeTransactions}
        useBanglaDigits={useBanglaDigits}
        appSettings={appSettings}
        onNavigateToLoan={onNavigateToLoan}
      />
    </div>
  );
};
