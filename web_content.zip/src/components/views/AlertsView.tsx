import React, { useState } from 'react';
import { useParentControl } from '../../context/ParentControlContext';
import { AlertSeverity } from '../../types';
import { 
  Bell, CheckCheck, Trash2, AlertTriangle, 
  ShieldAlert, Clock, Smartphone, Battery, MapPin, 
  Lock, CheckCircle2, PhoneCall
} from 'lucide-react';

export const AlertsView: React.FC = () => {
  const { 
    alerts, 
    unreadAlertsCount, 
    markAlertAsRead, 
    markAllAlertsAsRead, 
    deleteAlert, 
    language,
    activeDevice
  } = useParentControl();

  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const isAr = language === 'ar';

  const filteredAlerts = alerts.filter(a => {
    if (selectedFilter === 'all') return true;
    if (selectedFilter === 'unread') return !a.isRead;
    return a.type === selectedFilter;
  });

  const getSeverityStyle = (severity: AlertSeverity) => {
    switch (severity) {
      case 'critical':
      case 'danger':
        return 'border-rose-200 dark:border-rose-900/50 bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400';
      case 'warning':
        return 'border-amber-200 dark:border-amber-900/50 bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400';
      case 'info':
      default:
        return 'border-indigo-100 dark:border-indigo-900/50 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-400';
    }
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'geofence': return <MapPin className="w-4 h-4 text-rose-500 dark:text-rose-400" />;
      case 'app_limit': return <Lock className="w-4 h-4 text-amber-500 dark:text-amber-400" />;
      case 'battery': return <Battery className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />;
      case 'sos': return <PhoneCall className="w-4 h-4 text-rose-600 dark:text-rose-400 animate-pulse" />;
      default: return <Bell className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />;
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs transition-colors duration-200">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Bell className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
                <span>{isAr ? 'مركز التنبيهات والأمان الفوري' : 'Alerts & Safety Center'}</span>
              </h2>
              {unreadAlertsCount > 0 && (
                <span className="px-2.5 py-0.5 rounded-full bg-rose-500 text-white text-xs font-bold font-mono">
                  {unreadAlertsCount} {isAr ? 'جديد' : 'New'}
                </span>
              )}
            </div>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {isAr 
                ? 'إشعارات تجاوز الوقت، دخول وخروج المناطق الجغرافية، والنداءات العاجلة'
                : 'Real-time notifications, geofence breaches, time limits, and SOS triggers'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            {unreadAlertsCount > 0 && (
              <button
                id="mark-all-alerts-read-btn"
                onClick={markAllAlertsAsRead}
                className="px-3.5 py-2 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs sm:text-sm font-semibold rounded-xl border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 transition-colors shadow-xs"
              >
                <CheckCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>{isAr ? 'تحديد الكل كمقروء' : 'Mark All Read'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Filters Strip */}
        <div className="flex items-center gap-2 mt-5 pt-4 border-t border-slate-100 dark:border-slate-800 overflow-x-auto pb-1 no-scrollbar">
          {[
            { id: 'all', labelAr: 'كافة التنبيهات', labelEn: 'All Alerts' },
            { id: 'unread', labelAr: 'غير مقروءة', labelEn: 'Unread' },
            { id: 'app_limit', labelAr: 'حدود التطبيقات', labelEn: 'App Limits' },
            { id: 'geofence', labelAr: 'المناطق الجغرافية', labelEn: 'Geofences' },
            { id: 'battery', labelAr: 'البطارية والشحن', labelEn: 'Battery' },
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setSelectedFilter(f.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-colors ${
                selectedFilter === f.id
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-700'
              }`}
            >
              {isAr ? f.labelAr : f.labelEn}
            </button>
          ))}
        </div>
      </div>

      {/* Alerts List */}
      <div className="space-y-3">
        {filteredAlerts.length === 0 ? (
          <div className="py-16 text-center text-slate-400 dark:text-slate-500 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-xs">
            <CheckCircle2 className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
            <p className="text-sm font-bold text-slate-700 dark:text-slate-300">
              {isAr ? 'لا توجد أي تنبيهات في هذا القسم' : 'No alerts in this category'}
            </p>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
              {isAr ? 'أجهزتك وأطفالك جميعهم في أمان تام' : 'All devices and children are safe and sound'}
            </p>
          </div>
        ) : (
          filteredAlerts.map((alert) => {
            return (
              <div
                key={alert.id}
                className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                  !alert.isRead
                    ? 'bg-white dark:bg-slate-900 border-indigo-200 dark:border-indigo-800/80 shadow-xs'
                    : 'bg-white/80 dark:bg-slate-900/80 border-slate-200/80 dark:border-slate-800'
                }`}
              >
                <div className="flex items-start gap-3.5">
                  <div className={`p-2.5 rounded-xl border ${getSeverityStyle(alert.severity)} shrink-0 mt-0.5`}>
                    {getAlertIcon(alert.type)}
                  </div>

                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                        {isAr ? alert.titleAr : alert.title}
                      </h4>
                      <span className="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-indigo-700 dark:text-indigo-300 border border-slate-200/60 dark:border-slate-700 font-medium">
                        {alert.childName}
                      </span>
                      {!alert.isRead && (
                        <span className="w-2 h-2 rounded-full bg-rose-500" />
                      )}
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed max-w-2xl">
                      {isAr ? alert.messageAr : alert.message}
                    </p>

                    <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono mt-1.5 block">
                      {alert.timestamp}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  {!alert.isRead && (
                    <button
                      onClick={() => markAlertAsRead(alert.id)}
                      className="px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 hover:text-slate-900 dark:hover:text-white text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 transition-colors shadow-xs"
                    >
                      {isAr ? 'تم الاطلاع' : 'Mark Read'}
                    </button>
                  )}
                  <button
                    onClick={() => deleteAlert(alert.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors"
                    title={isAr ? 'حذف التنبيه' : 'Delete'}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
