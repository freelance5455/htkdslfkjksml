import React, { useState, useRef, useCallback } from 'react';
import {
  User,
  Settings,
  Flame,
  Clock,
  Dumbbell,
  Trophy,
  Download,
  Upload,
  RotateCcw,
  Volume2,
  VolumeX,
  Smartphone,
  ChevronRight,
  Shield,
  Edit2,
  Check,
  AlertTriangle,
  Camera,
  Trash2,
  X,
  Sparkles,
  Image as ImageIcon,
  CheckCircle2,
  Zap,
  Sun,
  Moon
} from 'lucide-react';
import { useWorkout } from '../../context/WorkoutContext';

// Built-in Athletic Crests / Preset Logos
interface PresetLogo {
  id: string;
  name: string;
  tag: string;
  svgDataUrl: string;
}

const PRESET_LOGOS: PresetLogo[] = [
  {
    id: 'spartan',
    name: 'Spartan Helm',
    tag: 'Warrior',
    svgDataUrl: `data:image/svg+xml;utf8,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">
        <rect width="100" height="100" rx="24" fill="#0b1329"/>
        <circle cx="50" cy="50" r="42" fill="#111c38" stroke="#0ea5e9" stroke-width="2.5"/>
        <path d="M50 14 C36 14 30 25 30 38 L30 54 C30 68 38 78 50 86 C62 78 70 68 70 54 L70 38 C70 25 64 14 50 14 Z" fill="#0284c7"/>
        <path d="M50 20 L50 65 M42 36 L58 36 M38 48 L62 48" stroke="#0b1329" stroke-width="5" stroke-linecap="round"/>
        <path d="M46 16 L54 16 L54 32 L46 32 Z" fill="#f59e0b"/>
      </svg>
    `)}`
  },
  {
    id: 'flame',
    name: 'Iron Flame',
    tag: 'Energy',
    svgDataUrl: `data:image/svg+xml;utf8,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">
        <rect width="100" height="100" rx="24" fill="#1c0f0a"/>
        <circle cx="50" cy="50" r="42" fill="#2d150b" stroke="#f97316" stroke-width="2.5"/>
        <path d="M50 16 C53 26 62 34 62 48 C62 62 52 74 48 80 C58 76 74 65 74 48 C74 30 60 20 50 16 Z" fill="#ea580c"/>
        <path d="M48 80 C44 74 34 62 34 48 C34 32 44 24 48 18 C46 28 38 36 42 50 C44 57 48 64 48 80 Z" fill="#f97316"/>
        <path d="M48 78 C52 70 56 64 56 56 C56 46 50 40 48 35 C46 42 42 46 42 56 C42 64 46 72 48 78 Z" fill="#fde047"/>
      </svg>
    `)}`
  },
  {
    id: 'wings',
    name: 'Aero Wings',
    tag: 'Flight',
    svgDataUrl: `data:image/svg+xml;utf8,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">
        <rect width="100" height="100" rx="24" fill="#081521"/>
        <circle cx="50" cy="50" r="42" fill="#0d2338" stroke="#06b6d4" stroke-width="2.5"/>
        <path d="M50 32 L20 42 C28 54 42 58 50 68 C58 58 72 54 80 42 Z" fill="#06b6d4"/>
        <path d="M50 38 L26 46 C32 54 44 58 50 64 C56 58 68 54 74 46 Z" fill="#67e8f9"/>
        <circle cx="50" cy="46" r="6" fill="#ffffff"/>
      </svg>
    `)}`
  },
  {
    id: 'beast',
    name: 'Bar Beast',
    tag: 'Strength',
    svgDataUrl: `data:image/svg+xml;utf8,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">
        <rect width="100" height="100" rx="24" fill="#061c16"/>
        <circle cx="50" cy="50" r="42" fill="#0a2e24" stroke="#10b981" stroke-width="2.5"/>
        <path d="M28 40 L40 24 L45 42 L55 42 L60 24 L72 40 C74 60 50 78 50 78 C50 78 26 60 28 40 Z" fill="#10b981"/>
        <circle cx="42" cy="48" r="3.5" fill="#061c16"/>
        <circle cx="58" cy="48" r="3.5" fill="#061c16"/>
        <path d="M43 60 Q50 67 57 60" stroke="#061c16" stroke-width="3.5" stroke-linecap="round" fill="none"/>
      </svg>
    `)}`
  },
  {
    id: 'thunder',
    name: 'Thunderbolt',
    tag: 'Speed',
    svgDataUrl: `data:image/svg+xml;utf8,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">
        <rect width="100" height="100" rx="24" fill="#0b1126"/>
        <circle cx="50" cy="50" r="42" fill="#121c40" stroke="#38bdf8" stroke-width="2.5"/>
        <path d="M54 18 L30 50 L46 50 L40 82 L70 46 L52 46 Z" fill="#22d3ee" stroke="#ffffff" stroke-width="2"/>
      </svg>
    `)}`
  },
  {
    id: 'crown',
    name: 'Champion Crown',
    tag: 'Elite',
    svgDataUrl: `data:image/svg+xml;utf8,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">
        <rect width="100" height="100" rx="24" fill="#1f1807"/>
        <circle cx="50" cy="50" r="42" fill="#36290c" stroke="#f59e0b" stroke-width="2.5"/>
        <path d="M26 64 L22 34 L38 48 L50 24 L62 48 L78 34 L74 64 Z" fill="#fbbf24"/>
        <circle cx="22" cy="32" r="3.5" fill="#fef08a"/>
        <circle cx="50" cy="22" r="4" fill="#fef08a"/>
        <circle cx="78" cy="32" r="3.5" fill="#fef08a"/>
        <rect x="28" y="66" width="44" height="6" rx="3" fill="#f59e0b"/>
      </svg>
    `)}`
  }
];

export const ProfileView: React.FC = () => {
  const {
    user,
    updateUser,
    theme,
    toggleTheme,
    personalRecords,
    skills,
    exportDataJSON,
    importDataJSON,
    resetAllData
  } = useWorkout();

  // Profile Edit Modal State
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editName, setEditName] = useState(user.name);
  const [editAthleteTitle, setEditAthleteTitle] = useState(user.athleteTitle || 'Calisthenics Athlete');
  const [editBio, setEditBio] = useState(user.bio);
  const [editProfileImage, setEditProfileImage] = useState(user.profileImage || '');
  const [editWeeklyGoal, setEditWeeklyGoal] = useState(user.weeklyGoal);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [saveSuccessNotice, setSaveSuccessNotice] = useState(false);
  const [isDraggingOver, setIsDraggingOver] = useState(false);

  // Hidden File Input
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Import Modal State
  const [importText, setImportText] = useState('');
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);

  // Reset Confirmation
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);

  const formatHours = (sec: number) => {
    return (sec / 3600).toFixed(1);
  };

  // Open Edit Modal with Fresh State
  const handleOpenEditModal = () => {
    setEditName(user.name);
    setEditAthleteTitle(user.athleteTitle || 'Calisthenics Athlete');
    setEditBio(user.bio);
    setEditProfileImage(user.profileImage || '');
    setEditWeeklyGoal(user.weeklyGoal);
    setUploadError(null);
    setIsEditingProfile(true);
  };

  // Client-side image processor: automatically downscales via canvas to 320x320 max JPEG
  const processImageFile = useCallback((file: File) => {
    setUploadError(null);
    if (!file.type.startsWith('image/')) {
      setUploadError('Please select a valid image file (PNG, JPG, WEBP, SVG)');
      return;
    }

    // Limit source file size to 15MB
    if (file.size > 15 * 1024 * 1024) {
      setUploadError('Image file is too large (max 15MB).');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDimension = 320;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxDimension) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          }
        } else {
          if (height > maxDimension) {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          setEditProfileImage(e.target?.result as string);
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        // High quality, compact JPEG data URL (~35KB)
        const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.88);
        setEditProfileImage(compressedDataUrl);
      };
      img.onerror = () => {
        setUploadError('Unable to process the image file. Please try another.');
      };
      img.src = e.target?.result as string;
    };
    reader.onerror = () => {
      setUploadError('Failed to read file.');
    };
    reader.readAsDataURL(file);
  }, []);

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processImageFile(file);
    }
  };

  // Drag and drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processImageFile(file);
    }
  };

  const handleSaveProfile = () => {
    const trimmedName = editName.trim() || 'Athlete';
    const trimmedTitle = editAthleteTitle.trim() || 'Calisthenics Athlete';
    const trimmedBio = editBio.trim() || 'Calisthenics athlete chasing strength milestones.';

    updateUser({
      name: trimmedName,
      athleteTitle: trimmedTitle,
      bio: trimmedBio,
      profileImage: editProfileImage,
      weeklyGoal: editWeeklyGoal
    });

    setSaveSuccessNotice(true);
    setTimeout(() => {
      setSaveSuccessNotice(false);
      setIsEditingProfile(false);
    }, 600);
  };

  const handleExport = () => {
    const jsonStr = exportDataJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `liftbody_backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleImportSubmit = () => {
    if (!importText.trim()) return;
    const success = importDataJSON(importText);
    if (success) {
      setImportStatus('Data successfully restored!');
      setTimeout(() => {
        setIsImportModalOpen(false);
        setImportStatus(null);
        setImportText('');
      }, 1500);
    } else {
      setImportStatus('Invalid JSON data format. Please verify the file.');
    }
  };

  return (
    <div className="space-y-5 pb-28 pt-2">
      {/* Profile Header Card */}
      <div className="p-5 rounded-3xl bg-[#12151c] border border-cyan-500/20 relative overflow-hidden shadow-xl shadow-cyan-950/10">
        <div className="flex items-start justify-between relative z-10 gap-3">
          <div className="flex items-center gap-3.5 min-w-0">
            {/* Athlete Logo / Avatar with Quick-Edit Camera Overlay */}
            <div className="relative group shrink-0">
              <div
                onClick={handleOpenEditModal}
                className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-600 via-cyan-500 to-cyan-400 p-[2px] shadow-lg shadow-cyan-500/25 cursor-pointer hover:scale-105 active:scale-95 transition-all overflow-hidden"
                title="Tap to change logo and profile"
              >
                <div className="w-full h-full bg-neutral-950 rounded-[14px] flex items-center justify-center overflow-hidden">
                  {user.profileImage ? (
                    <img
                      src={user.profileImage}
                      alt={user.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span className="text-cyan-400 text-2xl font-bold font-heading">
                      {user.name ? user.name.charAt(0).toUpperCase() : 'A'}
                    </span>
                  )}
                </div>
              </div>

              {/* Camera Icon Overlay Badge */}
              <button
                onClick={handleOpenEditModal}
                className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-cyan-500 text-neutral-950 border-2 border-[#12151c] flex items-center justify-center shadow-md hover:bg-cyan-400 active:scale-90 transition-all"
                title="Upload or Change Logo"
              >
                <Camera className="w-3 h-3 fill-neutral-950" />
              </button>
            </div>

            {/* Athlete Details */}
            <div className="min-w-0">
              <div className="text-[11px] font-semibold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5 truncate">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                <span>{user.athleteTitle || 'Calisthenics Athlete'}</span>
              </div>
              <h2 className="text-xl font-extrabold text-white tracking-tight truncate flex items-center gap-1.5">
                <span>{user.name}</span>
                <Shield className="w-4 h-4 text-cyan-400 fill-cyan-400/20 shrink-0" />
              </h2>
              <p className="text-xs text-slate-400 line-clamp-1 mt-0.5">{user.bio}</p>
            </div>
          </div>

          {/* Edit Profile & Logo Trigger Button */}
          <button
            onClick={handleOpenEditModal}
            className="py-2 px-3 rounded-xl text-slate-300 hover:text-white bg-neutral-900 border border-neutral-800 hover:border-cyan-500/40 transition-all flex items-center gap-1.5 shrink-0 active:scale-95 text-xs font-semibold"
            title="Edit Name, Logo, & Bio"
          >
            <Edit2 className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Edit Profile & Logo</span>
            <span className="sm:hidden">Edit</span>
          </button>
        </div>

        {/* Weekly Goal Progress Pill */}
        <div className="mt-4 pt-3 border-t border-neutral-800/80 flex items-center justify-between text-xs">
          <div className="text-slate-400 flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5 text-orange-400 fill-orange-400" />
            <span>Weekly Target:</span>
            <strong className="text-white font-mono">{user.weeklyGoal} workouts/week</strong>
          </div>
          <button
            onClick={handleOpenEditModal}
            className="text-[11px] text-cyan-400 hover:underline font-semibold"
          >
            Customize Profile →
          </button>
        </div>
      </div>

      {/* Full Modal: Edit Profile & Upload Logo */}
      {isEditingProfile && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-[#12151c] border border-cyan-500/30 rounded-3xl p-5 sm:p-6 max-w-md w-full shadow-2xl relative my-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800 mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                  <User className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-white leading-none">
                    Profile & Logo Settings
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Customize your athlete name, bio, and custom logo
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsEditingProfile(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white bg-neutral-900 border border-neutral-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Hidden Native File Input */}
            <input
              type="file"
              ref={fileInputRef}
              accept="image/png, image/jpeg, image/webp, image/svg+xml"
              onChange={handleFileInputChange}
              className="hidden"
            />

            <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-1">
              {/* Live Preview Card */}
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
                  Live Card Preview
                </label>
                <div className="p-3.5 rounded-2xl bg-neutral-950 border border-cyan-500/30 flex items-center gap-3">
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-tr from-cyan-600 to-cyan-400 p-[2px] shrink-0 shadow-md shadow-cyan-500/20 overflow-hidden">
                    <div className="w-full h-full bg-neutral-900 rounded-[10px] flex items-center justify-center overflow-hidden">
                      {editProfileImage ? (
                        <img
                          src={editProfileImage}
                          alt="Preview"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span className="text-cyan-400 text-xl font-bold font-heading">
                          {editName ? editName.charAt(0).toUpperCase() : 'A'}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-[10px] font-semibold text-cyan-400 uppercase tracking-wider truncate">
                      {editAthleteTitle || 'Calisthenics Athlete'}
                    </div>
                    <div className="text-base font-extrabold text-white truncate">
                      {editName || 'Athlete Name'}
                    </div>
                    <div className="text-[11px] text-slate-400 truncate mt-0.5">
                      {editBio || 'No bio specified'}
                    </div>
                  </div>
                </div>
              </div>

              {/* Upload Logo Section */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    Athlete Logo / Avatar
                  </label>
                  {editProfileImage && (
                    <button
                      onClick={() => setEditProfileImage('')}
                      className="text-[11px] text-red-400 hover:text-red-300 flex items-center gap-1 font-semibold"
                    >
                      <Trash2 className="w-3 h-3" />
                      <span>Remove Logo</span>
                    </button>
                  )}
                </div>

                {/* Drag and Drop / Upload Button Container */}
                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`p-4 rounded-2xl border-2 border-dashed transition-all cursor-pointer text-center ${
                    isDraggingOver
                      ? 'border-cyan-400 bg-cyan-500/10'
                      : 'border-neutral-800 hover:border-cyan-500/40 bg-neutral-900/60'
                  }`}
                >
                  <div className="flex flex-col items-center justify-center gap-2">
                    <div className="w-10 h-10 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center border border-cyan-500/20">
                      <Upload className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white flex items-center justify-center gap-1">
                        <span>Click to Upload Logo</span>
                        <span className="text-slate-400 font-normal">or drag & drop</span>
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        PNG, JPG, WEBP, or SVG • Auto-resizes & compresses
                      </div>
                    </div>
                  </div>
                </div>

                {uploadError && (
                  <div className="text-xs text-red-400 bg-red-950/40 border border-red-500/30 p-2 rounded-xl flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    <span>{uploadError}</span>
                  </div>
                )}

                {/* Preset Athletic Crests */}
                <div className="pt-2">
                  <div className="text-[11px] font-semibold text-slate-400 mb-2 flex items-center justify-between">
                    <span>Or choose an athletic crest:</span>
                    <Sparkles className="w-3 h-3 text-cyan-400" />
                  </div>

                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                    {PRESET_LOGOS.map((preset) => {
                      const isSelected = editProfileImage === preset.svgDataUrl;
                      return (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => {
                            setUploadError(null);
                            setEditProfileImage(preset.svgDataUrl);
                          }}
                          className={`p-1.5 rounded-xl border flex flex-col items-center gap-1 transition-all ${
                            isSelected
                              ? 'border-cyan-400 bg-cyan-500/15 shadow-md shadow-cyan-500/20 scale-105'
                              : 'border-neutral-800 bg-neutral-900/80 hover:border-neutral-700'
                          }`}
                          title={preset.name}
                        >
                          <img
                            src={preset.svgDataUrl}
                            alt={preset.name}
                            className="w-10 h-10 rounded-lg object-contain"
                          />
                          <span className="text-[9px] font-semibold text-slate-300 truncate w-full text-center">
                            {preset.name}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Name & Title Inputs */}
              <div className="space-y-3 pt-2 border-t border-neutral-800">
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                    Athlete Name <span className="text-cyan-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    placeholder="e.g. Alex Vance"
                    maxLength={32}
                    className="w-full text-xs font-semibold bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                    Athlete Title / Focus
                  </label>
                  <input
                    type="text"
                    value={editAthleteTitle}
                    onChange={(e) => setEditAthleteTitle(e.target.value)}
                    placeholder="e.g. Calisthenics Athlete, Street Workout Beast"
                    maxLength={40}
                    className="w-full text-xs bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors"
                  />

                  {/* Suggestion Chips */}
                  <div className="flex items-center gap-1.5 flex-wrap mt-1.5">
                    {[
                      'Calisthenics Athlete',
                      'Street Workout Beast',
                      'Static Skills Specialist',
                      'Bodyweight Athlete'
                    ].map((titleOption) => (
                      <button
                        key={titleOption}
                        type="button"
                        onClick={() => setEditAthleteTitle(titleOption)}
                        className={`text-[10px] px-2 py-0.5 rounded-md border transition-colors ${
                          editAthleteTitle === titleOption
                            ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300 font-bold'
                            : 'bg-neutral-900 border-neutral-800 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {titleOption}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                    Bio & Motivation
                  </label>
                  <textarea
                    rows={2}
                    value={editBio}
                    onChange={(e) => setEditBio(e.target.value)}
                    placeholder="e.g. Chasing full planche, strict muscle-ups & 20 pull-ups."
                    maxLength={140}
                    className="w-full text-xs bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                    Weekly Workout Target
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {[3, 4, 5, 6].map((goal) => (
                      <button
                        key={goal}
                        type="button"
                        onClick={() => setEditWeeklyGoal(goal)}
                        className={`py-2 text-xs font-semibold rounded-xl border transition-all ${
                          editWeeklyGoal === goal
                            ? 'bg-cyan-500 border-cyan-400 text-neutral-950 font-bold shadow-md shadow-cyan-500/20'
                            : 'bg-neutral-900 border-neutral-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {goal} days
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer Controls */}
            <div className="pt-4 border-t border-neutral-800 mt-4 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => setIsEditingProfile(false)}
                className="flex-1 py-2.5 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-slate-300 text-xs font-semibold rounded-xl transition-colors"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleSaveProfile}
                disabled={!editName.trim()}
                className="flex-1 py-2.5 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-neutral-950 text-xs font-bold rounded-xl shadow-lg shadow-cyan-500/25 transition-all flex items-center justify-center gap-1.5 active:scale-95"
              >
                {saveSuccessNotice ? (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Saved!</span>
                  </>
                ) : (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Save Changes</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Lifetime Training Statistics */}
      <div>
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2.5">
          Career Statistics
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className="p-3.5 rounded-2xl bg-[#12151c] border border-neutral-800">
            <div className="flex items-center gap-1.5 text-orange-400 text-xs font-medium mb-1">
              <Flame className="w-3.5 h-3.5 fill-orange-400" />
              <span>Current Streak</span>
            </div>
            <div className="text-2xl font-extrabold text-white font-mono">
              {user.streak} <span className="text-xs text-slate-400">days</span>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-[#12151c] border border-neutral-800">
            <div className="flex items-center gap-1.5 text-cyan-400 text-xs font-medium mb-1">
              <Dumbbell className="w-3.5 h-3.5" />
              <span>Total Workouts</span>
            </div>
            <div className="text-2xl font-extrabold text-white font-mono">
              {user.totalWorkouts}
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-[#12151c] border border-neutral-800">
            <div className="flex items-center gap-1.5 text-cyan-400 text-xs font-medium mb-1">
              <Clock className="w-3.5 h-3.5" />
              <span>Training Time</span>
            </div>
            <div className="text-2xl font-extrabold text-white font-mono">
              {formatHours(user.totalTrainingTimeSec)} <span className="text-xs text-slate-400">hrs</span>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-[#12151c] border border-neutral-800">
            <div className="flex items-center gap-1.5 text-cyan-400 text-xs font-medium mb-1">
              <Trophy className="w-3.5 h-3.5" />
              <span>Total Reps</span>
            </div>
            <div className="text-2xl font-extrabold text-white font-mono">
              {user.totalReps.toLocaleString()}
            </div>
          </div>
        </div>
      </div>

      {/* App Preferences & Settings */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
          Preferences & Settings
        </h3>

        <div className="rounded-2xl bg-[#12151c] border border-neutral-800 overflow-hidden divide-y divide-neutral-800/80">
          {/* Display Theme (Outdoor High-Contrast Light Mode) */}
          <div className="p-3.5 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-neutral-900 flex items-center justify-center text-cyan-400 shrink-0">
                {theme === 'light' ? (
                  <Sun className="w-4 h-4 text-amber-500 fill-amber-400" />
                ) : (
                  <Moon className="w-4 h-4 text-cyan-400" />
                )}
              </div>
              <div>
                <div className="text-xs font-bold text-white">Display Theme</div>
                <div className="text-[11px] text-slate-400">
                  {theme === 'light'
                    ? 'High-Contrast Light Mode (Outdoor Park & Sunlight)'
                    : 'Dark Mode (Indoor & Low-Glare)'}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1 bg-neutral-900 p-1 rounded-xl border border-neutral-800 shrink-0">
              <button
                type="button"
                onClick={() => updateUser({ theme: 'dark' })}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1 ${
                  theme === 'dark' ? 'bg-cyan-500 text-neutral-950 font-bold' : 'text-slate-400'
                }`}
              >
                <Moon className="w-3 h-3" />
                <span>Dark</span>
              </button>
              <button
                type="button"
                onClick={() => updateUser({ theme: 'light' })}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1 ${
                  theme === 'light' ? 'bg-cyan-500 text-neutral-950 font-bold' : 'text-slate-400'
                }`}
              >
                <Sun className="w-3 h-3" />
                <span>Light</span>
              </button>
            </div>
          </div>

          {/* Units Setting */}
          <div className="p-3.5 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-white">Weight Units</div>
              <div className="text-[11px] text-slate-400">
                Backpack loading measurement ({user.units === 'metric' ? 'Kilograms' : 'Pounds'})
              </div>
            </div>
            <div className="flex items-center gap-1 bg-neutral-900 p-1 rounded-xl border border-neutral-800">
              <button
                onClick={() => updateUser({ units: 'metric' })}
                className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors ${
                  user.units === 'metric' ? 'bg-cyan-500 text-neutral-950 font-bold' : 'text-slate-400'
                }`}
              >
                Kg
              </button>
              <button
                onClick={() => updateUser({ units: 'imperial' })}
                className={`px-3 py-1 text-xs font-semibold rounded-lg transition-colors ${
                  user.units === 'imperial' ? 'bg-cyan-500 text-neutral-950 font-bold' : 'text-slate-400'
                }`}
              >
                Lbs
              </button>
            </div>
          </div>

          {/* Default Rest Timer */}
          <div className="p-3.5 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-white">Default Rest Interval</div>
              <div className="text-[11px] text-slate-400">Auto-suggested recovery between sets</div>
            </div>
            <select
              value={user.defaultRestTimeSec}
              onChange={(e) => updateUser({ defaultRestTimeSec: parseInt(e.target.value, 10) })}
              className="bg-neutral-900 border border-neutral-800 rounded-xl px-2.5 py-1 text-xs font-mono text-cyan-400 focus:outline-none"
            >
              <option value={45}>45s</option>
              <option value={60}>60s</option>
              <option value={90}>90s</option>
              <option value={120}>120s</option>
              <option value={180}>180s</option>
            </select>
          </div>

          {/* Sound Audio Cues */}
          <div className="p-3.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-neutral-900 flex items-center justify-center text-slate-300">
                {user.soundEnabled ? <Volume2 className="w-4 h-4 text-cyan-400" /> : <VolumeX className="w-4 h-4" />}
              </div>
              <div>
                <div className="text-xs font-bold text-white">Synthesized Audio Cues</div>
                <div className="text-[11px] text-slate-400">Countdown timer beeps & PR chimes</div>
              </div>
            </div>
            <button
              onClick={() => updateUser({ soundEnabled: !user.soundEnabled })}
              className={`w-11 h-6 rounded-full transition-colors relative ${
                user.soundEnabled ? 'bg-cyan-500' : 'bg-neutral-800'
              }`}
            >
              <span
                className={`w-4 h-4 rounded-full bg-neutral-950 absolute top-1 transition-transform ${
                  user.soundEnabled ? 'left-6' : 'left-1'
                }`}
              />
            </button>
          </div>

          {/* Vibration / Haptics */}
          <div className="p-3.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-neutral-900 flex items-center justify-center text-slate-300">
                <Smartphone className={`w-4 h-4 ${user.vibrationEnabled ? 'text-cyan-400' : ''}`} />
              </div>
              <div>
                <div className="text-xs font-bold text-white">Tactile Vibration (Haptics)</div>
                <div className="text-[11px] text-slate-400">Haptic feedback on set completion</div>
              </div>
            </div>
            <button
              onClick={() => updateUser({ vibrationEnabled: !user.vibrationEnabled })}
              className={`w-11 h-6 rounded-full transition-colors relative ${
                user.vibrationEnabled ? 'bg-cyan-500' : 'bg-neutral-800'
              }`}
            >
              <span
                className={`w-4 h-4 rounded-full bg-neutral-950 absolute top-1 transition-transform ${
                  user.vibrationEnabled ? 'left-6' : 'left-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* Data Management Section */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
          Data Management & Backup
        </h3>

        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={handleExport}
            className="p-3 rounded-2xl bg-[#12151c] border border-neutral-800 hover:border-cyan-500/40 text-left transition-colors flex flex-col justify-between group active:scale-[0.98]"
          >
            <Download className="w-4 h-4 text-cyan-400 mb-2 group-hover:scale-110 transition-transform" />
            <div>
              <div className="text-xs font-bold text-white">Export Backup</div>
              <div className="text-[10px] text-slate-400">Save JSON file of history & PRs</div>
            </div>
          </button>

          <button
            onClick={() => setIsImportModalOpen(true)}
            className="p-3 rounded-2xl bg-[#12151c] border border-neutral-800 hover:border-cyan-500/40 text-left transition-colors flex flex-col justify-between group active:scale-[0.98]"
          >
            <Upload className="w-4 h-4 text-cyan-400 mb-2 group-hover:scale-110 transition-transform" />
            <div>
              <div className="text-xs font-bold text-white">Restore Data</div>
              <div className="text-[10px] text-slate-400">Import previous JSON backup</div>
            </div>
          </button>
        </div>

        {/* Reset App Progress Button */}
        <button
          onClick={() => setConfirmResetOpen(true)}
          className="w-full p-3 rounded-2xl bg-neutral-950 border border-neutral-900 hover:border-red-500/30 text-slate-500 hover:text-red-400 text-xs font-medium transition-colors flex items-center justify-center gap-1.5"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset All App Progress</span>
        </button>
      </div>

      {/* Import Modal */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-60 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#12151c] border border-neutral-800 rounded-3xl p-6 max-w-sm w-full animate-in fade-in duration-200">
            <h3 className="text-base font-bold text-white mb-1">Restore Workout Data</h3>
            <p className="text-xs text-slate-400 mb-3">Paste your Liftbody JSON backup string below:</p>

            <textarea
              rows={5}
              placeholder="Paste JSON content here..."
              value={importText}
              onChange={(e) => setImportText(e.target.value)}
              className="w-full text-xs font-mono bg-neutral-900 border border-neutral-800 rounded-xl p-3 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 mb-3"
            />

            {importStatus && (
              <div className="text-xs font-medium text-cyan-400 mb-3">
                {importStatus}
              </div>
            )}

            <div className="flex gap-2">
              <button
                onClick={() => {
                  setIsImportModalOpen(false);
                  setImportStatus(null);
                }}
                className="flex-1 py-2.5 bg-neutral-900 text-slate-400 text-xs font-semibold rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleImportSubmit}
                disabled={!importText.trim()}
                className="flex-1 py-2.5 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-neutral-950 text-xs font-bold rounded-xl shadow-md transition-all active:scale-95"
              >
                Import
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reset Confirmation Dialog */}
      {confirmResetOpen && (
        <div className="fixed inset-0 z-60 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#12151c] border border-red-500/40 rounded-3xl p-6 max-w-xs w-full text-center">
            <AlertTriangle className="w-10 h-10 text-red-400 mx-auto mb-2.5" />
            <h3 className="text-base font-bold text-white mb-1">Reset All Progress?</h3>
            <p className="text-xs text-slate-400 mb-4">
              This will reset all workout history, streaks, personal records, skill levels, and achievements back to zero.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setConfirmResetOpen(false)}
                className="flex-1 py-2 bg-neutral-900 text-slate-300 text-xs font-semibold rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  resetAllData();
                  setConfirmResetOpen(false);
                }}
                className="flex-1 py-2 bg-red-600 hover:bg-red-500 text-white text-xs font-bold rounded-xl shadow-md"
              >
                Reset
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
