import React, { useState, useRef, useEffect } from 'react';
import { ShoppingItem, Category, AppSettings } from '../../types';
import { formatCurrency } from '../../utils/formatters';
import {
  ShoppingBag,
  Plus,
  CheckCircle,
  Circle,
  Trash2,
  ArrowRightLeft,
  CheckCheck,
  Tag,
  FolderCheck,
  Sparkles,
  Undo2,
  Calculator,
  X,
} from 'lucide-react';
import { BazarCalculatorModal } from '../BazarCalculatorModal';
import { getDualAccentInfo } from '../../utils/theme';

interface ShoppingListViewProps {
  items: ShoppingItem[];
  categories: Category[];
  onAddItem: (item: Omit<ShoppingItem, 'id'>) => void;
  onToggleBought: (id: string) => void;
  onDeleteItem: (id: string) => void;
  onConvertToTransaction: (item: ShoppingItem) => void;
  useBanglaDigits: boolean;
  appSettings: AppSettings;
  onUpdateSettings?: (newSettings: AppSettings) => void;
  onAddItemFormTyping?: (isTyping: boolean) => void;
}

export const ShoppingListView: React.FC<ShoppingListViewProps> = ({
  items = [],
  categories = [],
  onAddItem,
  onToggleBought,
  onDeleteItem,
  onConvertToTransaction,
  useBanglaDigits,
  appSettings,
  onUpdateSettings,
  onAddItemFormTyping,
}) => {
  const isEn = appSettings.language === 'en';
  const defaultCategory = isEn ? 'Food & Grocery' : 'খাবার ও মুদি';
  const [title, setTitle] = useState('');
  const [quantity, setQuantity] = useState('');
  const [estimatedPrice, setEstimatedPrice] = useState('');
  const [category, setCategory] = useState(defaultCategory);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState<'active' | 'complete'>('active');
  const [movedNotification, setMovedNotification] = useState<string | null>(null);
  const [isCalculatorOpen, setIsCalculatorOpen] = useState(false);
  const [isAddOpen, setIsAddOpen] = useState(false);

  const addItemFormRef = useRef<HTMLFormElement>(null);
  const blurTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Sync typing state with parent so bottom navigation bar does not rise/push up while typing in Add New Item form
  const handleFormFocus = () => {
    if (blurTimeoutRef.current) {
      clearTimeout(blurTimeoutRef.current);
      blurTimeoutRef.current = null;
    }
    onAddItemFormTyping?.(true);
  };

  const handleFormBlur = (e: React.FocusEvent<HTMLFormElement>) => {
    if (blurTimeoutRef.current) {
      clearTimeout(blurTimeoutRef.current);
    }
    blurTimeoutRef.current = setTimeout(() => {
      if (addItemFormRef.current && !addItemFormRef.current.contains(document.activeElement)) {
        onAddItemFormTyping?.(false);
      }
    }, 100);
  };

  const handleInputChange = () => {
    if (blurTimeoutRef.current) {
      clearTimeout(blurTimeoutRef.current);
      blurTimeoutRef.current = null;
    }
    onAddItemFormTyping?.(true);
  };

  useEffect(() => {
    if (!isAddOpen) {
      if (blurTimeoutRef.current) {
        clearTimeout(blurTimeoutRef.current);
      }
      onAddItemFormTyping?.(false);
    }
    return () => {
      if (blurTimeoutRef.current) {
        clearTimeout(blurTimeoutRef.current);
      }
      onAddItemFormTyping?.(false);
    };
  }, [isAddOpen, onAddItemFormTyping]);

  const isLight = appSettings.themeMode === 'light';
  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );
  const cardBg = isLight
    ? 'bg-white/95 border-slate-200/90 shadow-xs'
    : 'bg-slate-800/90 border-slate-700/60 shadow-md';
  const innerCardBg = isLight
    ? 'bg-slate-50/80 border-slate-200/70'
    : 'bg-slate-900/80 border-slate-700/50';
  const headingText = isLight ? 'text-slate-900' : 'text-slate-100';
  const subText = isLight ? 'text-slate-500' : 'text-slate-400';

  const safeItems = Array.isArray(items) ? items : [];
  const pendingItems = safeItems.filter((i) => !i.isBought);
  const completedItems = safeItems.filter((i) => i.isBought);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError(isEn ? 'Please enter item name' : 'পণ্য বা দ্রব্যের নাম লিখুন');
      return;
    }

    onAddItem({
      title: title.trim(),
      quantity: quantity.trim() || (isEn ? '1 item' : '১ টি'),
      estimatedPrice: parseFloat(estimatedPrice) || 0,
      category,
      isBought: false,
    });

    setTitle('');
    setQuantity('');
    setEstimatedPrice('');
    setError('');
    setActiveTab('active');

    // Remove focus and reset typing state so navigation bar restores cleanly
    if (document.activeElement instanceof HTMLElement) {
      document.activeElement.blur();
    }
    onAddItemFormTyping?.(false);
  };

  const handleItemCheck = (item: ShoppingItem) => {
    onToggleBought(item.id);
    if (!item.isBought) {
      setMovedNotification(
        isEn
          ? `"${item.title}" moved to Shopping History`
          : `"${item.title}" Shopping History-তে সরানো হয়েছে`
      );
      setTimeout(() => {
        setMovedNotification(null);
      }, 3500);
    }
  };

  const handleConvertAllUnconverted = () => {
    const unconverted = completedItems.filter((i) => !i.convertedToTransactionId);
    if (unconverted.length === 0) return;

    const confirmMsg = isEn
      ? `Convert all ${unconverted.length} completed items to expenses?`
      : `ক্রয় সম্পন্ন ${unconverted.length}টি আইটেম কি একবারে খরচে যোগ করতে চান?`;

    if (confirm(confirmMsg)) {
      unconverted.forEach((item) => {
        onConvertToTransaction(item);
      });
    }
  };

  const totalEstimated = items.reduce((sum, i) => sum + i.estimatedPrice, 0);
  const totalBoughtCost = completedItems.reduce(
    (sum, i) => sum + (i.actualPrice || i.estimatedPrice),
    0
  );

  const categoryOptions = [
    { value: isEn ? 'Food & Grocery' : 'খাবার ও মুদি', label: isEn ? 'Food & Grocery' : 'খাবার ও মুদি' },
    { value: isEn ? 'Meat & Fish' : 'মাছ-মাংস', label: isEn ? 'Meat & Fish' : 'মাছ-মাংস' },
    { value: isEn ? 'Fruits & Vegetables' : 'সবজি', label: isEn ? 'Fruits & Vegetables' : 'ফল ও সবজি' },
    { value: isEn ? 'Household & Toiletries' : 'প্রসাধন ও গৃহস্থালি', label: isEn ? 'Household & Toiletries' : 'প্রসাধন ও গৃহস্থালি' },
    { value: isEn ? 'Other' : 'অন্যান্য', label: isEn ? 'Other' : 'অন্যান্য' },
  ];

  return (
    <div className="space-y-5 pb-8 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <h1 className={`text-xl font-black flex items-center gap-2 truncate ${headingText}`}>
              <ShoppingBag className="w-5 h-5 text-emerald-500 shrink-0" />
              <span>{isEn ? 'Shopping List' : 'বাজারের তালিকা (Shopping)'}</span>
            </h1>
          </div>
        </div>

        {/* Calculator Button alongside Shopping List Headline */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setIsCalculatorOpen(true)}
            id="shopping-header-calculator-btn"
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl active:scale-95 text-white text-xs font-black shadow-md transition hover:opacity-95"
            style={dualAccent.primaryButtonStyle}
            title={isEn ? 'Open Bazar & Cash Calculator' : 'বাজার ও নোট গনক ক্যালকুলেটর'}
          >
            <Calculator className="w-4 h-4" />
            <span>{isEn ? 'Calculator' : 'ক্যালকুলেটর'}</span>
          </button>
        </div>
      </div>

      {/* Overview Metric */}
      <div className="grid grid-cols-2 gap-3">
        <div className={`${cardBg} p-4 rounded-2xl border`}>
          <p className={`text-[10px] font-semibold uppercase tracking-wider ${subText}`}>
            {isEn ? 'Estimated Total' : 'আনুমানিক মোট খরচ'}
          </p>
          <p className={`text-lg font-black mt-1 ${isLight ? 'text-amber-700' : 'text-amber-400'}`}>
            {formatCurrency(totalEstimated, useBanglaDigits, appSettings.currencySymbol)}
          </p>
          <p className={`text-[10px] ${subText} mt-0.5`}>
            {isEn ? `${items.length} total items` : `মোট ${items.length}টি পণ্য`}
          </p>
        </div>

        <div className={`${cardBg} p-4 rounded-2xl border`}>
          <p className={`text-[10px] font-semibold uppercase tracking-wider ${subText}`}>
            Shopping History
          </p>
          <p className={`text-lg font-black mt-1 ${isLight ? 'text-emerald-700' : 'text-emerald-400'}`}>
            {formatCurrency(totalBoughtCost, useBanglaDigits, appSettings.currencySymbol)}
          </p>
          <p className={`text-[10px] ${subText} mt-0.5`}>
            {isEn ? `${completedItems.length} purchased` : `${completedItems.length}টি কেনা হয়েছে`}
          </p>
        </div>
      </div>

      {/* Moved Notification Toast */}
      {movedNotification && (
        <div className="p-3 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-700 dark:text-emerald-300 text-xs font-semibold flex items-center justify-between shadow-sm animate-in slide-in-from-top duration-300">
          <div className="flex items-center gap-2">
            <FolderCheck className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>{movedNotification}</span>
          </div>
          <button
            onClick={() => setActiveTab('complete')}
            className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 underline ml-2 shrink-0 hover:opacity-80"
          >
            {isEn ? 'View History' : 'হিস্ট্রি দেখুন'}
          </button>
        </div>
      )}

      {/* Add to List Trigger Button & Expandable Form (Placed above Shopping List & Shopping History tabs) */}
      {!isAddOpen ? (
        <button
          type="button"
          onClick={() => {
            setIsAddOpen(true);
            setActiveTab('active');
          }}
          style={dualAccent.primaryButtonStyle}
          className="w-full py-3 px-4 text-white font-bold rounded-2xl text-xs sm:text-sm shadow-md hover:shadow-lg transition flex items-center justify-center gap-2 active:scale-98 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{isEn ? 'Add to List' : 'অ্যাড টু লিস্ট'}</span>
        </button>
      ) : (
        /* Add New Shopping Item Form (opens upon touching Add to List) */
        <form
          ref={addItemFormRef}
          id="add-new-item-form"
          onSubmit={handleAdd}
          onFocus={handleFormFocus}
          onBlur={handleFormBlur}
          className={`${cardBg} p-4 rounded-3xl border space-y-3 transition`}
        >
          <div className="flex items-center justify-between">
            <h2 className={`text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 ${headingText}`}>
              <Plus className="w-4 h-4 text-emerald-500" />
              <span>{isEn ? 'Add New Item' : 'নতুন পণ্য যুক্ত করুন'}</span>
            </h2>
            <button
              type="button"
              onClick={() => {
                setIsAddOpen(false);
                setError('');
                onAddItemFormTyping?.(false);
              }}
              className={`p-1.5 rounded-lg transition ${
                isLight
                  ? 'text-slate-400 hover:text-slate-700 hover:bg-slate-100'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700'
              }`}
              title={isEn ? 'Close / Hide' : 'হাইড করুন'}
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <input
              type="text"
              placeholder={isEn ? 'Item name (e.g. Rice, Milk) *' : 'পণ্যের নাম (যেমন: মিনিকেট চাল) *'}
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
                setError('');
              }}
              onInput={handleInputChange}
              className={`sm:col-span-2 px-3 py-2 border rounded-xl text-xs focus:outline-none ${
                isLight
                  ? 'bg-slate-50/80 border-slate-200 text-slate-900 placeholder-slate-400 focus:border-indigo-500'
                  : 'bg-slate-900 border-slate-700 text-white placeholder-slate-400 focus:border-indigo-400'
              }`}
              autoFocus
            />
            <input
              type="text"
              placeholder={isEn ? 'Quantity (e.g. 2 kg, 1 pc)' : 'পরিমাণ (যেমন: ৫ কেজি)'}
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              onInput={handleInputChange}
              className={`px-3 py-2 border rounded-xl text-xs focus:outline-none ${
                isLight
                  ? 'bg-slate-50/80 border-slate-200 text-slate-900 placeholder-slate-400 focus:border-indigo-500'
                  : 'bg-slate-900 border-slate-700 text-white placeholder-slate-400 focus:border-indigo-400'
              }`}
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <input
              type="number"
              placeholder={isEn ? 'Estimated price' : 'আনুমানিক দাম'}
              value={estimatedPrice}
              onChange={(e) => setEstimatedPrice(e.target.value)}
              onInput={handleInputChange}
              className={`px-3 py-2 border rounded-xl text-xs focus:outline-none ${
                isLight
                  ? 'bg-slate-50/80 border-slate-200 text-slate-900 placeholder-slate-400 focus:border-indigo-500'
                  : 'bg-slate-900 border-slate-700 text-white placeholder-slate-400 focus:border-indigo-400'
              }`}
            />

            <select
              value={category}
              onChange={(e) => {
                setCategory(e.target.value);
                handleInputChange();
              }}
              className={`px-3 py-2 border rounded-xl text-xs font-bold focus:outline-none transition ${
                isLight
                  ? 'bg-white border-indigo-200 text-indigo-950 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500'
                  : 'bg-slate-800 border-indigo-500/50 text-indigo-200 focus:border-indigo-400 focus:ring-1 focus:ring-indigo-400'
              }`}
            >
              {categoryOptions.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>

          {error && <p className="text-xs text-rose-500 font-semibold">{error}</p>}

          <div className="flex items-center gap-2 pt-1">
            <button
              type="button"
              onClick={() => {
                setIsAddOpen(false);
                setError('');
                onAddItemFormTyping?.(false);
              }}
              className={`py-2.5 px-3.5 rounded-xl text-xs font-bold transition border ${
                isLight
                  ? 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                  : 'bg-slate-700/60 hover:bg-slate-700 text-slate-300 border-slate-600'
              }`}
            >
              {isEn ? 'Cancel' : 'বাতিল'}
            </button>

            <button
              type="submit"
              style={dualAccent.primaryButtonStyle}
              className="flex-1 py-2.5 text-white font-bold rounded-xl text-xs shadow-md transition flex items-center justify-center gap-1.5 active:scale-98 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{isEn ? 'Add to List' : 'তালিকায় যোগ করুন'}</span>
            </button>
          </div>
        </form>
      )}

      {/* Section Navigation Tabs: Active Shopping vs Shopping History */}
      <div
        className={`p-1.5 rounded-2xl border flex items-center gap-1.5 ${
          isLight ? 'bg-slate-100/80 border-slate-200' : 'bg-slate-900/90 border-slate-700/70'
        }`}
      >
        <button
          onClick={() => setActiveTab('active')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'active'
              ? isLight
                ? 'bg-white text-slate-900 shadow-xs border border-slate-200/80'
                : 'bg-slate-800 text-white shadow-sm border border-slate-600'
              : isLight
              ? 'text-slate-600 hover:text-slate-900'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <ShoppingBag className="w-3.5 h-3.5" style={{ color: 'var(--color-primary)' }} />
          <span>{isEn ? 'Shopping List' : 'চলতি তালিকা'}</span>
          <span
            className={`text-[10px] px-1.5 py-0.5 rounded-full font-extrabold ${
              activeTab === 'active'
                ? isLight
                  ? 'bg-slate-100 text-slate-800'
                  : 'bg-slate-950 text-slate-300'
                : isLight
                ? 'bg-slate-200/60 text-slate-700'
                : 'bg-slate-800 text-slate-300'
            }`}
          >
            {pendingItems.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('complete')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
            activeTab === 'complete'
              ? isLight
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-emerald-600 text-white shadow-sm'
              : isLight
              ? 'text-emerald-800/80 hover:text-emerald-950'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <FolderCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>{isEn ? 'Shopping History' : 'Shopping History'}</span>
          <span
            className={`text-[10px] px-1.5 py-0.5 rounded-full font-extrabold ${
              activeTab === 'complete'
                ? 'bg-emerald-700 text-white'
                : isLight
                ? 'bg-emerald-200/80 text-emerald-900'
                : 'bg-emerald-950 text-emerald-300 border border-emerald-700/50'
            }`}
          >
            {completedItems.length}
          </span>
        </button>
      </div>

      {/* VIEW 1: ACTIVE SHOPPING LIST */}
      {activeTab === 'active' && (
        <div className="space-y-4">
          {/* Active Items List */}
          <div className={`${cardBg} rounded-3xl p-5 border space-y-3`}>
            <div className="flex items-center justify-between">
              <h2 className={`text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 ${headingText}`}>
                <ShoppingBag className="w-4 h-4" style={{ color: 'var(--color-primary)' }} />
                <span>
                  {isEn
                    ? `Pending Shopping Items (${pendingItems.length})`
                    : `কেনার জন্য প্রস্তুত পণ্য (${pendingItems.length})`}
                </span>
              </h2>
              <span className={`text-[10px] ${subText}`}>
                {isEn ? 'Tap circle when bought' : 'কেনা হলে বৃত্তে টিক দিন'}
              </span>
            </div>

            <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
              {pendingItems.length === 0 ? (
                <div className={`py-8 text-center space-y-2 ${subText}`}>
                  <p className="text-xs font-medium">
                    {isEn
                      ? 'No pending items to purchase right now!'
                      : 'কেনার মতো কোনো অবশিষ্ট পণ্য নেই!'}
                  </p>
                  {completedItems.length > 0 && (
                    <button
                      onClick={() => setActiveTab('complete')}
                      className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center justify-center gap-1 mx-auto"
                    >
                      <FolderCheck className="w-3.5 h-3.5" />
                      <span>{isEn ? 'View Shopping History' : 'Shopping History দেখুন'}</span>
                    </button>
                  )}
                </div>
              ) : (
                pendingItems.map((item) => (
                  <div
                    key={item.id}
                    className={`p-3 rounded-2xl border transition flex items-center justify-between ${innerCardBg}`}
                  >
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => handleItemCheck(item)}
                        className="transition group p-1"
                        title={isEn ? 'Mark as bought (moves to Shopping History)' : 'ক্রয় সম্পন্ন চিহ্নিত করুন (Shopping History-তে যাবে)'}
                      >
                        <Circle
                          className={`w-5 h-5 transition ${
                            isLight
                              ? 'text-slate-400 group-hover:text-emerald-600'
                              : 'text-slate-500 group-hover:text-emerald-400'
                          }`}
                        />
                      </button>

                      <div>
                        <h3 className={`text-xs font-bold ${headingText}`}>
                          {item.title}
                        </h3>
                        <div className={`flex items-center gap-2 text-[10px] mt-0.5 ${subText}`}>
                          <span>
                            {isEn ? 'Qty:' : 'পরিমাণ:'} {item.quantity}
                          </span>
                          <span>•</span>
                          <span className="flex items-center gap-0.5">
                            <Tag className="w-2.5 h-2.5" /> {item.category}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5">
                      <span className={`text-xs font-black ${isLight ? 'text-amber-700' : 'text-amber-400'}`}>
                        {formatCurrency(item.estimatedPrice, useBanglaDigits, appSettings.currencySymbol)}
                      </span>

                      <button
                        onClick={() => onDeleteItem(item.id)}
                        className={`p-1.5 rounded-lg transition cursor-pointer ${
                          isLight
                            ? 'text-slate-400 hover:text-rose-600 hover:bg-rose-100'
                            : 'text-slate-400 hover:text-rose-400 hover:bg-rose-950/50'
                        }`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: "SHOPPING HISTORY" VIEW */}
      {activeTab === 'complete' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          {/* Folder Main Container */}
          <div className={`${cardBg} rounded-3xl p-5 border space-y-4`}>
            <div className="flex items-center justify-between border-b pb-3.5 border-black/5 dark:border-white/5">
              <div className="flex items-center gap-3">
                <div
                  className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
                    isLight
                      ? 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                      : 'bg-emerald-950 text-emerald-400 border border-emerald-700/60'
                  }`}
                >
                  <FolderCheck className="w-5 h-5" />
                </div>
                <div>
                  <h2 className={`text-sm font-black ${headingText} flex items-center gap-1.5`}>
                    <span>Shopping History</span>
                    <span className="text-[10px] font-normal text-emerald-600 dark:text-emerald-400">
                      ({completedItems.length})
                    </span>
                  </h2>
                  <p className={`text-[10px] ${subText}`}>
                    {isEn
                      ? 'Purchased goods stored in your history. Convert them to expenses or restore.'
                      : 'ক্রয় সম্পন্ন করা আইটেমসমূহ। এখান থেকে সরাসরি খরচে রূপান্তর বা পুনরায় ফিরিয়ে নেওয়া যাবে।'}
                  </p>
                </div>
              </div>

              {/* Batch Convert Button if unconverted items exist */}
              {completedItems.some((i) => !i.convertedToTransactionId) && (
                <button
                  onClick={handleConvertAllUnconverted}
                  className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-[10px] font-bold shadow-xs transition flex items-center gap-1"
                  title={isEn ? 'Convert all to expense' : 'সবগুলো একবারে খরচে যোগ করুন'}
                >
                  <ArrowRightLeft className="w-3 h-3" />
                  <span className="hidden sm:inline">
                    {isEn ? 'Convert All' : 'সবগুলো খরচে যোগ'}
                  </span>
                  <span className="sm:hidden">{isEn ? 'Convert' : 'খরচে যোগ'}</span>
                </button>
              )}
            </div>

            {/* Folder Item List */}
            <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1">
              {completedItems.length === 0 ? (
                <div className={`py-12 text-center space-y-3 ${subText}`}>
                  <div className="w-12 h-12 mx-auto rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-500">
                    <FolderCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-700 dark:text-slate-300">
                      {isEn
                        ? 'The Shopping History is currently empty'
                        : 'Shopping History বর্তমানে খালি আছে'}
                    </p>
                    <p className="text-[11px] mt-1 max-w-xs mx-auto">
                      {isEn
                        ? 'Check items off in your active shopping list and they will automatically appear here!'
                        : 'বাজার করার পর চলতি তালিকা থেকে কোনো আইটেমে টিকচিহ্ন দিলে তা স্বয়ংক্রিয়ভাবে এই ফোল্ডারে চলে আসবে!'}
                    </p>
                  </div>
                  <button
                    onClick={() => setActiveTab('active')}
                    className="px-4 py-1.5 rounded-xl border border-slate-200 bg-white dark:bg-slate-800 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 transition inline-block cursor-pointer"
                  >
                    {isEn ? 'Go to Shopping List' : 'চলতি তালিকায় যান'}
                  </button>
                </div>
              ) : (
                completedItems.map((item) => (
                  <div
                    key={item.id}
                    className={`p-3 rounded-2xl border transition flex items-center gap-3 ${
                      isLight
                        ? 'bg-emerald-50/70 border-emerald-200/80 shadow-xs'
                        : 'bg-emerald-950/20 border-emerald-900/40'
                    }`}
                  >
                    {/* Checkmark button to uncheck / restore */}
                    <button
                      onClick={() => handleItemCheck(item)}
                      className="transition group p-1 shrink-0"
                      title={
                        isEn
                          ? 'Uncheck to restore back to active shopping list'
                          : 'টিক তুলে নিয়ে চলতি তালিকায় ফেরত পাঠান'
                      }
                    >
                      <CheckCircle className="w-5 h-5 text-emerald-500 group-hover:scale-110 transition" />
                    </button>

                    {/* Content container with 2 aligned rows */}
                    <div className="min-w-0 flex-1 flex flex-col gap-1">
                      {/* প্রথম লাইন: সোজা আইটেমের নাম, শেষ প্রান্তের দিকে দাম, বেক ও লাল ডিলিট বাটন */}
                      <div className="flex items-center justify-between gap-2 min-w-0">
                        <h3 className={`text-xs font-bold truncate min-w-0 ${headingText}`}>
                          {item.title}
                        </h3>

                        <div className="flex items-center gap-2 shrink-0">
                          {/* দাম */}
                          <span className={`text-xs font-black ${isLight ? 'text-emerald-800' : 'text-emerald-400'}`}>
                            {formatCurrency(
                              item.actualPrice || item.estimatedPrice,
                              useBanglaDigits,
                              appSettings.currencySymbol
                            )}
                          </span>

                          {/* বেক বাটন */}
                          <button
                            onClick={() => handleItemCheck(item)}
                            className={`p-1 rounded-md transition cursor-pointer ${
                              isLight
                                ? 'text-slate-500 hover:text-slate-800 hover:bg-slate-100'
                                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                            }`}
                            title={isEn ? 'Move back to active list' : 'চলতি তালিকায় ফেরত নিন'}
                          >
                            <Undo2 className="w-3.5 h-3.5" />
                          </button>

                          {/* লাল ডিলিট বাটন */}
                          <button
                            onClick={() => onDeleteItem(item.id)}
                            className={`p-1 rounded-md transition ${
                              isLight
                                ? 'text-rose-600 hover:text-rose-700 hover:bg-rose-100'
                                : 'text-rose-400 hover:text-rose-300 hover:bg-rose-950/50'
                            }`}
                            title={isEn ? 'Delete from folder' : 'ফোল্ডার থেকে ডিলিট করুন'}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* দ্বিতীয় লাইন: সোজা পরিমাণ শ্রেণী ও এক্সপেন্স বাটন */}
                      <div className="flex items-center justify-between gap-2 min-w-0">
                        {/* পরিমাণ ও শ্রেণী */}
                        <div className={`flex items-center gap-2 text-[10px] truncate ${subText}`}>
                          <span>
                            {isEn ? 'Qty:' : 'পরিমাণ:'} {item.quantity}
                          </span>
                          <span>•</span>
                          <span className="flex items-center gap-0.5">
                            <Tag className="w-2.5 h-2.5" /> {item.category}
                          </span>
                        </div>

                        {/* এক্সপেন্স বাটন */}
                        <div className="shrink-0">
                          {!item.convertedToTransactionId ? (
                            <button
                              onClick={() => onConvertToTransaction(item)}
                              className={`px-2 py-0.5 border text-[10px] font-bold rounded-lg transition flex items-center gap-1 active:scale-95 ${
                                isLight
                                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs'
                                  : 'bg-emerald-700 hover:bg-emerald-600 text-white'
                              }`}
                              title={isEn ? 'Convert to expense record' : 'সরাসরি খরচে যোগ করুন'}
                            >
                              <ArrowRightLeft className="w-3 h-3" />
                              <span>{isEn ? 'Expense' : 'খরচে যোগ'}</span>
                            </button>
                          ) : (
                            <span
                              className={`text-[10px] px-2 py-0.5 rounded-md flex items-center gap-1 font-bold ${
                                isLight
                                  ? 'text-emerald-800 bg-emerald-100/90 border border-emerald-200'
                                  : 'text-emerald-300 bg-emerald-950/80 border border-emerald-700/50'
                              }`}
                              title={isEn ? 'Already added to expenses' : 'ইতিমধ্যে খরচে যুক্ত'}
                            >
                              <CheckCheck className="w-3 h-3" />
                              <span>{isEn ? 'Added' : 'খরচে যুক্ত'}</span>
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Bazar & Note Counter Calculator Modal */}
      <BazarCalculatorModal
        isOpen={isCalculatorOpen}
        onClose={() => setIsCalculatorOpen(false)}
        appSettings={appSettings}
        onUpdateSettings={onUpdateSettings}
      />
    </div>
  );
};

