import React, { useState, useEffect } from 'react';
import { AppSettings, ThemeMode, ThemeAccent } from '../../types';
import {
  PRIMARY_ACCENT_COLORS,
  EXTENDED_SPECTRUM_PALETTE,
  getAccentConfig,
  hexToHsl,
  hslToHex,
  getHueColorName,
} from '../../utils/theme';
import { toBanglaDigits } from '../../utils/formatters';
import {
  Palette,
  Sun,
  Moon,
  Sparkles,
  Check,
  ArrowLeft,
  RotateCcw,
  Eye,
  TrendingUp,
  TrendingDown,
  Wallet,
  Pipette,
  ArrowLeftRight,
  Sliders,
  Paintbrush,
  Hash,
} from 'lucide-react';

interface ThemeViewProps {
  appSettings: AppSettings;
  onUpdateSettings: (newSettings: AppSettings) => void;
  onBackToSettings: () => void;
}

export const ThemeView: React.FC<ThemeViewProps> = ({
  appSettings,
  onUpdateSettings,
  onBackToSettings,
}) => {
  const isLight = appSettings.themeMode === 'light';
  const isEn = appSettings.language === 'en';

  // State for toggling between Primary and Secondary color configuration
  const [activeColorTab, setActiveColorTab] = useState<'primary' | 'secondary'>('primary');

  const cardBg = isLight
    ? 'bg-white/95 border-slate-200/90 shadow-xs'
    : 'bg-slate-800/90 border-slate-700/70 shadow-md';
  const innerCardBg = isLight
    ? 'bg-slate-50/80 border-slate-200/70'
    : 'bg-slate-900/80 border-slate-700/60';
  const headingText = isLight ? 'text-slate-900' : 'text-slate-100';
  const subText = isLight ? 'text-slate-500' : 'text-slate-400';

  const themeModes: {
    id: ThemeMode;
    titleEn: string;
    titleBn: string;
    descEn: string;
    descBn: string;
    icon: React.ReactNode;
    colorBadge: string;
  }[] = [
    {
      id: 'light',
      titleEn: 'Light Mode',
      titleBn: 'লাইট মোড',
      descEn: 'Clean, radiant daylight theme with optimal readability.',
      descBn: 'দিনের আলোর মতো পরিষ্কার, ফ্রেশ লাইট থিম।',
      icon: <Sun className="w-5 h-5 text-amber-500" />,
      colorBadge: 'bg-amber-100 text-amber-800 border-amber-300',
    },
    {
      id: 'dark',
      titleEn: 'Slate Dark',
      titleBn: 'স্লেট ডার্ক (Dark)',
      descEn: 'Modern indigo-slate dark mode, soft on the eyes in low light.',
      descBn: 'চোখের আরামের জন্য প্রিমিয়াম স্লেট-ইন্ডিগো ডার্ক থিম।',
      icon: <Moon className="w-5 h-5 text-indigo-400" />,
      colorBadge: 'bg-indigo-950/60 text-indigo-300 border-indigo-500/40',
    },
    {
      id: 'oled',
      titleEn: 'Charcoal OLED',
      titleBn: 'চারকোল ওলেড (OLED)',
      descEn: 'Ultra-deep contrast dark theme, battery-efficient on AMOLED screens.',
      descBn: 'ব্যাটারি সাশ্রয়ী গভীর ডার্ক থিম ও শার্প কনট্রাস্ট।',
      icon: <Sparkles className="w-5 h-5 text-emerald-400" />,
      colorBadge: 'bg-slate-900 text-emerald-400 border-emerald-500/40',
    },
  ];

  const activeAccentConfig = getAccentConfig(appSettings.themeAccent);
  const activeSecondaryConfig = getAccentConfig(appSettings.secondaryAccent || 'cyan');

  // Currently target configuration based on the active tab
  const currentTargetConfig = activeColorTab === 'primary' ? activeAccentConfig : activeSecondaryConfig;
  const currentHex = currentTargetConfig.hex;

  const currentHsl = hexToHsl(currentHex);
  const [hue, setHue] = useState<number>(currentHsl.h);
  const [lightness, setLightness] = useState<number>(currentHsl.l);
  const [customHexInput, setCustomHexInput] = useState<string>(currentHex);

  // Synchronize spectrum sliders and inputs when switching tab or when color changes
  useEffect(() => {
    const updatedHsl = hexToHsl(currentHex);
    setHue(updatedHsl.h);
    setLightness(updatedHsl.l);
    setCustomHexInput(currentHex);
  }, [currentHex, activeColorTab]);

  const handleColorChange = (newHexOrId: string) => {
    if (activeColorTab === 'primary') {
      onUpdateSettings({ ...appSettings, themeAccent: newHexOrId });
    } else {
      onUpdateSettings({ ...appSettings, secondaryAccent: newHexOrId });
    }
  };

  const handleHueChange = (newHue: number) => {
    setHue(newHue);
    const s = 80;
    const l = Math.min(68, Math.max(38, lightness));
    const newHex = hslToHex(newHue, s, l);
    handleColorChange(newHex);
  };

  const handleLightnessChange = (newL: number) => {
    setLightness(newL);
    const s = 80;
    const newHex = hslToHex(hue, s, newL);
    handleColorChange(newHex);
  };

  const handleSwapColors = () => {
    onUpdateSettings({
      ...appSettings,
      themeAccent: appSettings.secondaryAccent || 'cyan',
      secondaryAccent: appSettings.themeAccent,
    });
  };

  const currentHueName = getHueColorName(hue);

  return (
    <div className="space-y-5 pb-8 animate-in fade-in duration-200">
      {/* Top Bar with Back to Settings navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBackToSettings}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition cursor-pointer ${
            isLight
              ? 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 shadow-xs'
              : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
          }`}
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>{isEn ? 'Back to Settings' : 'সেটিংসে ফিরে যান'}</span>
        </button>

        <span
          className={`text-[10px] font-bold px-2.5 py-1 rounded-full border uppercase tracking-wider ${
            isLight
              ? 'bg-slate-100 text-slate-800 border-slate-200'
              : 'bg-slate-800 text-slate-300 border-slate-700'
          }`}
        >
          {appSettings.themeMode.toUpperCase()} MODE
        </span>
      </div>

      {/* Header Banner */}
      <div>
        <h1 className={`text-xl font-black ${headingText} flex items-center gap-2`}>
          <Palette className="w-6 h-6 text-indigo-500" />
          <span>{isEn ? 'Theme & Visual Styling' : 'থিম ও ভিজ্যুয়াল স্টাইলিং'}</span>
        </h1>
        <p className={`text-xs ${subText} mt-1`}>
          {isEn
            ? 'Personalize your interface mode, accent colors and card aesthetics'
            : 'অ্যাপের ব্যাকগ্রাউন্ড থিম, প্রাইমারি ও সেকেন্ডারি কালার পছন্দমত সাজান'}
        </p>
      </div>

      {/* Theme Modes Selection */}
      <div className={`${cardBg} border rounded-3xl p-5 space-y-3.5`}>
        <div className="flex items-center justify-between">
          <h2 className={`text-xs font-bold uppercase tracking-wider ${headingText}`}>
            {isEn ? 'Background Theme Mode' : 'ব্যাকগ্রাউন্ড থিম মোড'}
          </h2>
          <span className={`text-[11px] font-medium ${subText}`}>
            {isEn ? 'Choose 1 of 3' : '৩টির মধ্যে একটি নির্বাচন করুন'}
          </span>
        </div>

        <div className="space-y-2.5">
          {themeModes.map((mode) => {
            const isSelected = appSettings.themeMode === mode.id;

            return (
              <button
                key={mode.id}
                onClick={() => onUpdateSettings({ ...appSettings, themeMode: mode.id })}
                className={`w-full p-4 rounded-2xl border text-left transition flex items-center justify-between gap-3 ${
                  isSelected
                    ? isLight
                      ? 'bg-white border-slate-400 shadow-md ring-2 ring-slate-300/50'
                      : 'bg-slate-700/80 border-indigo-400 shadow-md ring-2 ring-indigo-400/40'
                    : isLight
                    ? 'bg-slate-50/80 border-slate-200 hover:bg-slate-100/80'
                    : 'bg-slate-900/60 border-slate-700/70 hover:bg-slate-800/80'
                }`}
                style={
                  isSelected && isLight
                    ? { borderColor: activeAccentConfig.hex, boxShadow: `0 0 0 2px ${activeAccentConfig.hex}40` }
                    : undefined
                }
              >
                <div className="flex items-center gap-3.5">
                  <div
                    className={`p-3 rounded-2xl border ${
                      isSelected
                        ? isLight
                          ? 'bg-slate-100 border-slate-300 shadow-xs'
                          : 'bg-slate-800 border-indigo-500/50'
                        : isLight
                        ? 'bg-white border-slate-200'
                        : 'bg-slate-800 border-slate-700'
                    }`}
                  >
                    {mode.icon}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className={`text-xs font-bold ${headingText}`}>
                        {isEn ? mode.titleEn : mode.titleBn}
                      </p>
                      {isSelected && (
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${mode.colorBadge}`}>
                          {isEn ? 'Active' : 'সক্রিয়'}
                        </span>
                      )}
                    </div>
                    <p className={`text-[11px] ${subText} mt-0.5 line-clamp-1`}>
                      {isEn ? mode.descEn : mode.descBn}
                    </p>
                  </div>
                </div>

                <div
                  className={`w-5 h-5 rounded-full border flex items-center justify-center transition shrink-0 ${
                    isSelected
                      ? 'text-white'
                      : isLight
                      ? 'border-slate-300 bg-white'
                      : 'border-slate-600 bg-slate-800'
                  }`}
                  style={
                    isSelected
                      ? { backgroundColor: activeAccentConfig.hex, borderColor: activeAccentConfig.hex }
                      : undefined
                  }
                >
                  {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Color Customization with Primary / Secondary Menu Switch */}
      <div className={`${cardBg} border rounded-3xl p-5 space-y-4`}>
        {/* Section Header */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className={`text-base font-black tracking-tight ${headingText} flex items-center gap-2`}>
              <Paintbrush className="w-4 h-4 text-indigo-500" />
              <span>{isEn ? 'Accent Color' : 'অ্যাকসেন্ট কালার'}</span>
            </h2>
          </div>
        </div>

        {/* Menu Switch Buttons: Primary vs Secondary */}
        <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10">
          <button
            type="button"
            onClick={() => setActiveColorTab('primary')}
            id="menu-switch-primary-color"
            className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs transition flex items-center justify-center gap-2 cursor-pointer ${
              activeColorTab === 'primary'
                ? isLight
                  ? 'bg-white text-slate-900 shadow-md font-black'
                  : 'bg-slate-700 text-white shadow-md ring-2 ring-white/20 font-black'
                : isLight
                ? 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
            style={
              activeColorTab === 'primary' && isLight
                ? { boxShadow: `0 2px 8px ${activeAccentConfig.hex}30, 0 0 0 2px ${activeAccentConfig.hex}40` }
                : undefined
            }
          >
            <span
              className="w-3.5 h-3.5 rounded-full border border-black/20 shadow-xs shrink-0 transition"
              style={{ backgroundColor: activeAccentConfig.hex }}
            />
            <span className="truncate">
              {isEn ? 'Primary Color' : 'প্রাইমারি কালার'}
            </span>
            {activeColorTab === 'primary' && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveColorTab('secondary')}
            id="menu-switch-secondary-color"
            className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs transition flex items-center justify-center gap-2 cursor-pointer ${
              activeColorTab === 'secondary'
                ? isLight
                  ? 'bg-white text-slate-900 shadow-md font-black'
                  : 'bg-slate-700 text-white shadow-md ring-2 ring-white/20 font-black'
                : isLight
                ? 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
            style={
              activeColorTab === 'secondary' && isLight
                ? { boxShadow: `0 2px 8px ${activeSecondaryConfig.hex}30, 0 0 0 2px ${activeSecondaryConfig.hex}40` }
                : undefined
            }
          >
            <span
              className="w-3.5 h-3.5 rounded-full border border-black/20 shadow-xs shrink-0 transition"
              style={{ backgroundColor: activeSecondaryConfig.hex }}
            />
            <span className="truncate">
              {isEn ? 'Secondary Color' : 'সেকেন্ডারি কালার'}
            </span>
            {activeColorTab === 'secondary' && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
            )}
          </button>

          {/* Quick Swap Colors Button */}
          <button
            type="button"
            onClick={handleSwapColors}
            id="menu-switch-swap-colors"
            className={`p-2.5 rounded-xl border text-xs font-bold transition flex items-center justify-center shrink-0 cursor-pointer active:scale-95 ${
              isLight
                ? 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 shadow-xs'
                : 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700 shadow-xs'
            }`}
            title={isEn ? 'Swap Primary and Secondary colors' : 'প্রাইমারি ও সেকেন্ডারি অদলবদল করুন'}
          >
            <ArrowLeftRight className="w-4 h-4" />
          </button>
        </div>

        {/* Active Target Banner */}
        <div className={`p-3 rounded-2xl border ${innerCardBg} flex items-center justify-between gap-3`}>
          <div className="flex items-center gap-3">
            <div
              className="w-8 h-8 rounded-xl border border-black/20 dark:border-white/20 shadow-sm shrink-0 flex items-center justify-center"
              style={{ backgroundColor: currentHex }}
            >
              <Check className="w-4 h-4 text-white drop-shadow-sm" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className={`text-[10px] font-bold uppercase tracking-wider ${subText}`}>
                  {activeColorTab === 'primary'
                    ? isEn ? 'Editing Primary' : 'বর্তমানে প্রাইমারি নির্বাচন করছেন'
                    : isEn ? 'Editing Secondary' : 'বর্তমানে সেকেন্ডারি নির্বাচন করছেন'}
                </span>
              </div>
              <p className={`text-xs font-black ${headingText}`}>
                {isEn ? currentTargetConfig.nameEn : currentTargetConfig.nameBn}
              </p>
            </div>
          </div>

          <span className="text-[11px] font-mono font-bold px-2.5 py-1 rounded-xl border border-black/10 dark:border-white/10 bg-black/5 dark:bg-white/5">
            {currentHex.toUpperCase()}
          </span>
        </div>

        {/* All-Colors Bar (সমস্ত রং এর বার / Full Spectrum Hue Slider) */}
        <div className="space-y-2 pt-1">
          <div className="flex items-center justify-between">
            <label className={`text-xs font-bold flex items-center gap-1.5 ${headingText}`}>
              <Sliders className="w-3.5 h-3.5" style={{ color: currentHex }} />
              <span>{isEn ? 'All-Color Bar' : 'অল কালার বার'}</span>
            </label>
            <div className="flex items-center gap-2">
              <span className={`text-[11px] font-bold ${subText}`}>
                {currentHueName[isEn ? 'en' : 'bn']}
              </span>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded-md border ${
                isLight ? 'bg-slate-100 border-slate-200 text-slate-800 font-bold' : 'bg-slate-900 border-slate-700 text-slate-200 font-bold'
              }`}>
                {hue}°
              </span>
            </div>
          </div>

          {/* Full rainbow hue spectrum bar */}
          <div className="relative pt-1 pb-1">
            <input
              type="range"
              min="0"
              max="360"
              value={hue}
              onChange={(e) => handleHueChange(Number(e.target.value))}
              className="w-full h-8 rounded-2xl appearance-none cursor-pointer spectrum-slider shadow-inner border border-black/15 dark:border-white/20 transition"
              style={{
                background:
                  'linear-gradient(to right, #ff0000 0%, #ff7700 8.3%, #ffdd00 16.7%, #88ff00 25%, #00ff00 33.3%, #00ff88 41.7%, #00ffff 50%, #0088ff 58.3%, #0000ff 66.7%, #8800ff 75%, #ff00ff 83.3%, #ff0077 91.7%, #ff0000 100%)',
              }}
              id="all-color-spectrum-slider"
              aria-label="All color spectrum bar"
            />
          </div>

          {/* Lightness & Shade slider */}
          <div className="space-y-1 pt-1.5">
            <div className="flex items-center justify-between text-[11px]">
              <span className={`font-semibold ${subText}`}>
                {isEn ? 'Shade & Tone' : 'শেড ও টোন (Shad & Ton)'}
              </span>
              <span className={`font-bold ${headingText}`}>
                {lightness}%
              </span>
            </div>
            <input
              type="range"
              min="28"
              max="72"
              value={lightness}
              onChange={(e) => handleLightnessChange(Number(e.target.value))}
              className="w-full h-3 rounded-xl appearance-none cursor-pointer shadow-inner border border-black/10 dark:border-white/15"
              style={{
                background: `linear-gradient(to right, #0f172a 0%, ${hslToHex(hue, 85, 50)} 50%, #ffffff 100%)`,
                accentColor: currentHex,
              }}
              id="color-lightness-slider"
              aria-label="Color lightness and shade slider"
            />
          </div>
        </div>

        {/* Full Spectrum Swatches (সমগ্র রঙের প্যালেট) */}
        <div className="space-y-2 pt-2">
          <div className="flex items-center justify-between">
            <span className={`text-xs font-bold uppercase tracking-wider ${headingText}`}>
              {isEn ? 'Full Spectrum Palette' : 'সমগ্র রঙের প্যালেট'}
            </span>
            <span className={`text-[10px] ${subText}`}>
              {isEn ? '24 Spectrum Colors' : '২৪টি স্পেকট্রাম শেড'}
            </span>
          </div>

          <div className="grid grid-cols-6 sm:grid-cols-8 gap-2 justify-items-center py-1">
            {EXTENDED_SPECTRUM_PALETTE.map((color) => {
              const isSelected = currentHex.toLowerCase() === color.hex.toLowerCase();
              return (
                <button
                  key={color.hex}
                  type="button"
                  onClick={() => handleColorChange(color.hex)}
                  className="group flex flex-col items-center gap-1 focus:outline-none cursor-pointer"
                  title={`${color.nameEn} / ${color.nameBn} (${color.hex})`}
                >
                  <div
                    className={`w-10 h-10 sm:w-11 sm:h-11 rounded-full transition-all duration-200 flex items-center justify-center relative ${
                      isSelected
                        ? 'scale-110 shadow-md ring-2 ring-offset-2 ring-offset-white dark:ring-offset-slate-900 ring-slate-400 dark:ring-slate-500'
                        : 'hover:scale-105 active:scale-95 opacity-90 hover:opacity-100 shadow-xs'
                    }`}
                    style={{
                      backgroundColor: color.hex,
                      borderWidth: isSelected ? '3px' : '0px',
                      borderColor: '#ffffff',
                    }}
                  >
                    {isSelected && (
                      <span className="w-1.5 h-1.5 rounded-full bg-white shadow-xs" />
                    )}
                  </div>
                  <span
                    className={`text-[9px] font-semibold text-center leading-tight truncate max-w-[50px] transition ${
                      isSelected ? `${headingText} font-black` : subText
                    }`}
                  >
                    {isEn ? color.nameEn : color.nameBn}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Custom Color Code & Native Color Picker */}
        <div className={`p-3 rounded-2xl border ${innerCardBg} flex items-center justify-between gap-3 mt-2`}>
          <div className="flex items-center gap-2.5">
            {/* Native HTML5 Color Picker with Eyedropper Icon */}
            <label
              className="relative cursor-pointer w-10 h-10 rounded-xl border border-black/15 dark:border-white/20 flex items-center justify-center shadow-xs transition hover:scale-105 active:scale-95 shrink-0"
              style={{ backgroundColor: currentHex }}
              title={isEn ? 'Open color wheel / eyedropper' : 'কালার ড্রপার বা হুইল খুলুন'}
            >
              <Pipette className="w-4 h-4 text-white drop-shadow-md" />
              <input
                type="color"
                value={currentHex.startsWith('#') ? currentHex : '#3b82f6'}
                onChange={(e) => handleColorChange(e.target.value)}
                className="sr-only"
                aria-label="Native color picker"
              />
            </label>

            <div>
              <p className={`text-xs font-bold ${headingText}`}>
                {isEn ? 'Custom Color Picker / HEX' : 'কাস্টম হেক্স কোড ও পিকার'}
              </p>
              <p className={`text-[10px] ${subText}`}>
                {isEn ? 'Type HEX code or use eyedropper' : 'যেকোনো হেক্স কোড লিখুন বা ড্রপারে ক্লিক করুন'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <div
              className={`flex items-center px-2.5 py-1.5 rounded-xl border ${
                isLight ? 'bg-white border-slate-200' : 'bg-slate-800 border-slate-700'
              } shadow-xs`}
            >
              <Hash className={`w-3.5 h-3.5 ${subText}`} />
              <input
                type="text"
                maxLength={7}
                value={customHexInput.replace('#', '')}
                onChange={(e) => {
                  const val = e.target.value.replace(/[^0-9a-fA-F]/g, '');
                  setCustomHexInput(`#${val}`);
                  if (val.length === 6) {
                    handleColorChange(`#${val}`);
                  }
                }}
                placeholder="10B981"
                className={`w-16 bg-transparent text-xs font-mono font-bold uppercase focus:outline-none ${headingText}`}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Live Appearance Preview */}
      <div className={`${cardBg} border rounded-3xl p-5 space-y-3.5`}>
        <div className="flex items-center justify-between">
          <h2 className={`text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 ${headingText}`}>
            <Eye className="w-4 h-4 text-emerald-500" />
            <span>{isEn ? 'Live Appearance Preview' : 'লাইভ প্রিভিউ (সরাসরি প্রদর্শন)'}</span>
          </h2>
          <span className={`text-[10px] ${subText}`}>
            {isEn ? 'Real-time look' : 'বাস্তব লুক'}
          </span>
        </div>

        <div className={`p-4 rounded-2xl border ${innerCardBg} space-y-3`}>
          {/* Mini Balance Card Preview */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div
                className="w-8 h-8 rounded-xl flex items-center justify-center transition-colors"
                style={{
                  backgroundColor: `${activeAccentConfig.hex}25`,
                  color: activeAccentConfig.hex,
                }}
              >
                <Wallet className="w-4 h-4" />
              </div>
              <div>
                <p className={`text-[10px] ${subText}`}>
                  {isEn ? 'Total Balance' : 'মোট বর্তমান স্থিতি'}
                </p>
                <p className={`text-sm font-black ${headingText}`}>
                  {appSettings.currencySymbol} ২৫,৪৫০
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <span className="px-2 py-1 rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 font-bold text-[10px] flex items-center gap-0.5">
                <TrendingUp className="w-3 h-3" /> +৳৫,০০০
              </span>
              <span className="px-2 py-1 rounded-lg bg-rose-500/15 text-rose-600 dark:text-rose-400 font-bold text-[10px] flex items-center gap-0.5">
                <TrendingDown className="w-3 h-3" /> -৳১,২০০
              </span>
            </div>
          </div>

          {/* Sample Button Preview with Primary and Secondary */}
          <div className="pt-1 flex gap-2">
            <button
              type="button"
              className="flex-1 py-2 px-3 rounded-xl text-white font-bold text-xs shadow-sm transition hover:opacity-90 active:scale-95 flex items-center justify-center gap-1.5"
              style={{
                backgroundColor: activeAccentConfig.hex,
              }}
            >
              <span>{isEn ? 'Primary Accent' : 'প্রাইমারি বাটন'}</span>
            </button>
            <button
              type="button"
              className="px-3.5 py-2 rounded-xl text-xs font-bold text-white shadow-sm transition hover:opacity-90 active:scale-95"
              style={{
                backgroundColor: activeSecondaryConfig.hex,
              }}
            >
              {isEn ? 'Secondary Accent' : 'সেকেন্ডারি বাটন'}
            </button>
          </div>
        </div>
      </div>

      {/* Quick Reset Theme */}
      <div className="pt-1 flex items-center justify-between text-xs">
        <button
          onClick={() =>
            onUpdateSettings({
              ...appSettings,
              themeMode: 'light',
              themeAccent: 'green',
              secondaryAccent: 'cyan',
              accentPercentage: 50,
            })
          }
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl transition cursor-pointer ${
            isLight
              ? 'text-slate-600 hover:bg-slate-100'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>{isEn ? 'Reset to Default Theme' : 'ডিফল্ট থিমে রিসেট করুন'}</span>
        </button>

        <button
          onClick={onBackToSettings}
          className="px-4 py-2 rounded-xl font-bold transition cursor-pointer text-white shadow-sm hover:opacity-90"
          style={{ backgroundColor: activeAccentConfig.hex }}
        >
          {isEn ? 'Done' : 'সম্পন্ন'}
        </button>
      </div>
    </div>
  );
};

