import React, { useState, useRef } from "react";
import {
  BrainCircuit,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Search,
  Plus,
  Sparkles,
  Layers,
  ArrowRight,
  MousePointer,
  RotateCcw
} from "lucide-react";
import { Note } from "../../types";

interface MindMapCanvasViewProps {
  notes: Note[];
  categories: string[];
  onOpenNote: (note: Note) => void;
  onOpenNewNoteInCategory?: (category: string) => void;
}

export const MindMapCanvasView: React.FC<MindMapCanvasViewProps> = ({
  notes,
  categories,
  onOpenNote,
  onOpenNewNoteInCategory,
}) => {
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [selectedNoteId, setSelectedNoteId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>("");

  const canvasRef = useRef<HTMLDivElement>(null);

  // Filter notes
  const filteredNotes = notes.filter(
    (n) =>
      !searchQuery ||
      n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      n.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      n.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // Group notes by category for radial/tree placement
  const allCategories = Array.from(
    new Set([
      ...categories,
      ...filteredNotes.map((n) => n.category || "Genel"),
    ])
  ).filter(Boolean);

  // Center hub position
  const centerX = 500;
  const centerY = 400;

  // Calculate coordinates for Category Nodes and Note Nodes
  const categoryRadius = 220;
  const categoryNodes = allCategories.map((cat, idx) => {
    const angle = (idx / Math.max(1, allCategories.length)) * 2 * Math.PI - Math.PI / 2;
    const cx = centerX + categoryRadius * Math.cos(angle);
    const cy = centerY + categoryRadius * Math.sin(angle);

    const catNotes = filteredNotes.filter((n) => (n.category || "Genel") === cat);

    const noteRadius = 140;
    const noteNodes = catNotes.map((note, noteIdx) => {
      // Fan out notes around category node
      const totalInCat = Math.max(1, catNotes.length);
      const fanSpread = Math.min(Math.PI * 0.8, totalInCat * 0.35);
      const startAngle = angle - fanSpread / 2;
      const noteAngle =
        totalInCat === 1
          ? angle
          : startAngle + (noteIdx / (totalInCat - 1)) * fanSpread;

      const nx = cx + noteRadius * Math.cos(noteAngle);
      const ny = cy + noteRadius * Math.sin(noteAngle);

      return {
        ...note,
        x: nx,
        y: ny,
      };
    });

    return {
      category: cat,
      x: cx,
      y: cy,
      angle,
      notes: noteNodes,
    };
  });

  // Drag Pan handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    // Only pan if clicking canvas background, not a button
    if ((e.target as HTMLElement).tagName === "BUTTON" || (e.target as HTMLElement).closest("button")) {
      return;
    }
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPan({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleReset = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
    setSelectedNoteId(null);
  };

  return (
    <div className="space-y-3 animate-in fade-in">
      {/* Canvas Controls Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-teal-100 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400">
            <BrainCircuit className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
              <span>Anlamsal Zihin Haritası</span>
              <span className="text-[10px] bg-teal-100 dark:bg-teal-900/60 text-teal-700 dark:text-teal-300 px-2 py-0.5 rounded-full font-bold">
                Interaktif Tuval
              </span>
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Notlarınızı ve kategorilerinizi 2B bağlantı tuvalinde inceleyin
            </p>
          </div>
        </div>

        {/* Search & Canvas Zoom Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative w-40 sm:w-52">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Zihin haritasında ara..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:border-teal-500"
            />
          </div>

          <div className="flex items-center p-0.5 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
            <button
              onClick={() => setZoom((z) => Math.min(2, z + 0.15))}
              title="Yakınlaştır (+)"
              className="p-1.5 text-slate-500 hover:text-teal-600 dark:hover:text-teal-400 cursor-pointer"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <span className="text-[11px] font-mono px-1 font-bold text-slate-600 dark:text-slate-300">
              {Math.round(zoom * 100)}%
            </span>
            <button
              onClick={() => setZoom((z) => Math.max(0.4, z - 0.15))}
              title="Uzaklaştır (-)"
              className="p-1.5 text-slate-500 hover:text-teal-600 dark:hover:text-teal-400 cursor-pointer"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <button
              onClick={handleReset}
              title="Görünümü Sıfırla"
              className="p-1.5 text-slate-500 hover:text-teal-600 dark:hover:text-teal-400 border-l border-slate-200 dark:border-slate-700 ml-0.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Infinite Canvas Window */}
      <div
        ref={canvasRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="relative w-full h-[620px] bg-slate-950/90 rounded-3xl border border-slate-800 overflow-hidden cursor-grab active:cursor-grabbing select-none shadow-2xl"
        style={{
          backgroundImage: `radial-gradient(rgba(255, 255, 255, 0.1) 1px, transparent 1px)`,
          backgroundSize: "24px 24px",
        }}
      >
        {/* Transformable Canvas Surface */}
        <div
          className="absolute inset-0 transition-transform duration-75 origin-center"
          style={{
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
            width: "1000px",
            height: "800px",
          }}
        >
          {/* SVG Connector Lines */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
            {categoryNodes.map((cat) => {
              // Smooth bezier curve from center to category
              const path1 = `M ${centerX} ${centerY} Q ${(centerX + cat.x) / 2} ${(centerY + cat.y) / 2 - 20} ${cat.x} ${cat.y}`;

              return (
                <g key={cat.category}>
                  {/* Center to Category line */}
                  <path
                    d={path1}
                    fill="none"
                    stroke="#14b8a6"
                    strokeWidth="2.5"
                    strokeDasharray="4 2"
                    className="opacity-70"
                  />

                  {/* Category to Notes lines */}
                  {cat.notes.map((note) => {
                    const isSelected = selectedNoteId === note.id;
                    const path2 = `M ${cat.x} ${cat.y} Q ${(cat.x + note.x) / 2} ${(cat.y + note.y) / 2} ${note.x} ${note.y}`;

                    return (
                      <path
                        key={note.id}
                        d={path2}
                        fill="none"
                        stroke={isSelected ? "#f59e0b" : "#3b82f6"}
                        strokeWidth={isSelected ? "3" : "1.5"}
                        className={isSelected ? "opacity-100" : "opacity-40"}
                      />
                    );
                  })}
                </g>
              );
            })}
          </svg>

          {/* Central Hub Node */}
          <div
            style={{ left: `${centerX - 60}px`, top: `${centerY - 30}px` }}
            className="absolute z-20 w-32 h-16 rounded-2xl bg-gradient-to-r from-teal-600 to-emerald-600 text-white flex flex-col items-center justify-center p-2 shadow-lg shadow-teal-500/30 border border-teal-400"
          >
            <BrainCircuit className="w-5 h-5 mb-0.5 text-teal-200 animate-pulse" />
            <span className="font-extrabold text-xs text-center tracking-wide">
              Notlarım & Bilgi Ağı
            </span>
          </div>

          {/* Category Hub Nodes */}
          {categoryNodes.map((cat) => (
            <div
              key={cat.category}
              style={{ left: `${cat.x - 55}px`, top: `${cat.y - 20}px` }}
              className="absolute z-10 w-28 p-2 rounded-xl bg-slate-900 border border-teal-500/80 text-teal-300 shadow-md shadow-teal-950 flex flex-col items-center justify-center text-center group"
            >
              <span className="font-bold text-[11px] truncate max-w-full">
                {cat.category}
              </span>
              <span className="text-[9px] font-mono text-slate-400 bg-slate-800 px-1.5 rounded-full mt-0.5">
                {cat.notes.length} Not
              </span>
            </div>
          ))}

          {/* Note Leaf Nodes */}
          {categoryNodes.flatMap((cat) =>
            cat.notes.map((note) => {
              const isSelected = selectedNoteId === note.id;

              return (
                <div
                  key={note.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedNoteId(note.id);
                  }}
                  onDoubleClick={(e) => {
                    e.stopPropagation();
                    onOpenNote(note);
                  }}
                  style={{ left: `${note.x - 60}px`, top: `${note.y - 22}px` }}
                  className={`absolute z-20 w-32 p-2.5 rounded-xl border text-left shadow-lg transition-all cursor-pointer ${
                    isSelected
                      ? "bg-amber-950/90 border-amber-400 text-amber-100 scale-110 shadow-amber-500/30"
                      : "bg-slate-900/90 border-slate-700 hover:border-teal-400 text-slate-200 hover:scale-105"
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-teal-950 text-teal-300 border border-teal-800">
                      {note.category || "Genel"}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenNote(note);
                      }}
                      title="Notu Aç"
                      className="p-0.5 text-slate-400 hover:text-white"
                    >
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>

                  <h5 className="font-bold text-[11px] line-clamp-1 leading-tight">
                    {note.title || "Başlıksız Not"}
                  </h5>

                  {note.content && (
                    <p className="text-[9px] text-slate-400 line-clamp-1 mt-0.5">
                      {note.content.replace(/<[^>]*>/g, "")}
                    </p>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Bottom Tip Badge */}
        <div className="absolute bottom-3 left-3 z-30 bg-slate-900/90 backdrop-blur-xs border border-slate-800 text-slate-300 px-3 py-1.5 rounded-xl text-xs flex items-center gap-2">
          <MousePointer className="w-3.5 h-3.5 text-teal-400" />
          <span>Sürükleyerek gezinin • Not kartına çift tıklayarak açın</span>
        </div>
      </div>
    </div>
  );
};
