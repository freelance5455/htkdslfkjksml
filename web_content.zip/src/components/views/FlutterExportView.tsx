import React, { useState } from 'react';
import { useParentControl } from '../../context/ParentControlContext';
import { FLUTTER_CODE_SNIPPETS } from '../../data/mockData';
import { 
  Code2, Copy, Check, Download, Terminal, 
  Layers, Smartphone, Sparkles, FolderTree, FileCode
} from 'lucide-react';

export const FlutterExportView: React.FC = () => {
  const { language } = useParentControl();
  const isAr = language === 'ar';

  const [activeCodeTab, setActiveCodeTab] = useState<'architecture' | 'main' | 'android' | 'accessibility' | 'ios'>('architecture');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const getCodeContent = () => {
    switch (activeCodeTab) {
      case 'architecture': return FLUTTER_CODE_SNIPPETS.architecture;
      case 'main': return FLUTTER_CODE_SNIPPETS.mainDart;
      case 'android': return FLUTTER_CODE_SNIPPETS.androidAdminKt;
      case 'accessibility': return FLUTTER_CODE_SNIPPETS.accessibilityKt;
      case 'ios': return FLUTTER_CODE_SNIPPETS.iosScreenTimeSwift;
      default: return '';
    }
  };

  const handleCopy = (key: string, text: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleDownload = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const files = [
    { id: 'architecture', name: 'Architecture & Structure', ext: 'txt', icon: FolderTree },
    { id: 'main', name: 'main.dart (Flutter App)', ext: 'dart', icon: FileCode },
    { id: 'android', name: 'DeviceAdminReceiver.kt', ext: 'kt', icon: Smartphone },
    { id: 'accessibility', name: 'AppBlockerAccessibility.kt', ext: 'kt', icon: Smartphone },
    { id: 'ios', name: 'ScreenTimeShield.swift', ext: 'swift', icon: Layers },
  ];

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs transition-colors duration-200">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Code2 className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                {isAr ? 'كود وبنية تطبيق Flutter للتحكم الأبوي (Android & iOS)' : 'Flutter Cross-Platform Source Code & Architecture'}
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {isAr 
                ? 'مشروع Flutter كامل جاهز للتطوير مع كود الصلاحيات الأصلية (Device Policy Manager & iOS FamilyControls)'
                : 'Complete Flutter production project structure with Android Device Admin and iOS ScreenTime integration'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleDownload(`${activeCodeTab}.${activeCodeTab === 'main' ? 'dart' : activeCodeTab === 'ios' ? 'swift' : 'kt'}`, getCodeContent())}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-semibold rounded-xl flex items-center gap-2 shadow-xs transition-all active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>{isAr ? 'تحميل الملف الحالي' : 'Download File'}</span>
            </button>
          </div>
        </div>

        {/* Flutter Tech Stack Highlights */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-5 pt-4 border-t border-slate-100 dark:border-slate-800 text-xs">
          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700">
            <span className="text-indigo-600 dark:text-indigo-400 font-bold block">Flutter 3.24+</span>
            <span className="text-[10px] text-slate-500 dark:text-slate-400">Dart 3 with Material 3 UI</span>
          </div>
          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700">
            <span className="text-emerald-600 dark:text-emerald-400 font-bold block">Android Device Admin</span>
            <span className="text-[10px] text-slate-500 dark:text-slate-400">Lock, Wipe, Accessibility API</span>
          </div>
          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700">
            <span className="text-sky-600 dark:text-sky-400 font-bold block">Apple Screen Time</span>
            <span className="text-[10px] text-slate-500 dark:text-slate-400">FamilyControls & ManagedSettings</span>
          </div>
          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700">
            <span className="text-amber-600 dark:text-amber-400 font-bold block">Real-time WebSockets</span>
            <span className="text-[10px] text-slate-500 dark:text-slate-400">Sub-100ms Instant Remote Sync</span>
          </div>
        </div>
      </div>

      {/* Code Viewer Box */}
      <div className="bg-slate-950 border border-slate-900 rounded-2xl overflow-hidden shadow-xs">
        
        {/* File tabs bar */}
        <div className="flex items-center justify-between bg-slate-900 px-4 py-2.5 border-b border-slate-800 overflow-x-auto">
          <div className="flex items-center gap-1.5 no-scrollbar">
            {files.map((file) => {
              const Icon = file.icon;
              const isActive = activeCodeTab === file.id;

              return (
                <button
                  key={file.id}
                  onClick={() => setActiveCodeTab(file.id as any)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-mono transition-colors whitespace-nowrap ${
                    isActive
                      ? 'bg-slate-800 text-indigo-400 border border-slate-700 font-bold'
                      : 'text-slate-400 hover:text-white hover:bg-slate-850'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{file.name}</span>
                </button>
              );
            })}
          </div>

          <button
            onClick={() => handleCopy(activeCodeTab, getCodeContent())}
            className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-mono rounded-lg border border-slate-700 transition-colors shrink-0 ms-2"
          >
            {copiedKey === activeCodeTab ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">{isAr ? 'تم النسخ!' : 'Copied!'}</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>{isAr ? 'نسخ الكود' : 'Copy'}</span>
              </>
            )}
          </button>
        </div>

        {/* Code Content Container */}
        <div className="p-4 sm:p-6 bg-slate-950 font-mono text-xs text-slate-200 overflow-x-auto max-h-[580px] leading-relaxed select-all">
          <pre className="whitespace-pre">
            {getCodeContent()}
          </pre>
        </div>
      </div>
    </div>
  );
};
