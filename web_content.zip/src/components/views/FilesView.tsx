import React, { useState } from 'react';
import {
  FolderOpen,
  Search,
  Star,
  Download,
  Share2,
  Trash2,
  Edit2,
  Eye,
  FileText,
  Filter,
  Check,
  X
} from 'lucide-react';
import { StoredDocument } from '../../types';
import {
  formatFileSize,
  formatFileTime,
  triggerFileDownload,
  shareFile,
  renameDocument,
  deleteDocument,
  toggleDocumentFavorite
} from '../../services/storageService';

interface FilesViewProps {
  documents: StoredDocument[];
  onRefresh: () => void;
  onOpenDocument: (doc: StoredDocument) => void;
}

export const FilesView: React.FC<FilesViewProps> = ({
  documents,
  onRefresh,
  onOpenDocument
}) => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'docx' | 'pdf' | 'img' | 'fav'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');
  const [previewDoc, setPreviewDoc] = useState<StoredDocument | null>(null);

  const filteredDocs = documents.filter((doc) => {
    const matchesSearch = doc.name.toLowerCase().includes(searchQuery.toLowerCase());
    let matchesCategory = true;
    if (activeFilter === 'docx') matchesCategory = doc.type === 'docx';
    if (activeFilter === 'pdf') matchesCategory = doc.type === 'pdf';
    if (activeFilter === 'img') matchesCategory = doc.type === 'png' || doc.type === 'jpg';
    if (activeFilter === 'fav') matchesCategory = !!doc.isFavorite;
    return matchesSearch && matchesCategory;
  });

  const handleStartRename = (doc: StoredDocument) => {
    setEditingId(doc.id);
    setEditingName(doc.name);
  };

  const handleConfirmRename = (id: string) => {
    if (editingName.trim()) {
      renameDocument(id, editingName.trim());
      onRefresh();
    }
    setEditingId(null);
  };

  const handleDelete = (id: string) => {
    deleteDocument(id);
    onRefresh();
  };

  const handleToggleFav = (id: string) => {
    toggleDocumentFavorite(id);
    onRefresh();
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-neutral-50 dark:bg-neutral-900 pb-20">
      {/* Top Filter & Search */}
      <div className="px-4 py-3 bg-white dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 space-y-3">
        {/* Search Input */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-neutral-400" />
          <input
            type="text"
            placeholder="Search saved documents..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-neutral-100 dark:bg-neutral-700 border border-neutral-200 dark:border-neutral-600 text-xs text-neutral-900 dark:text-neutral-100 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Filter Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto text-xs pb-0.5">
          {[
            { id: 'all', label: 'All Files' },
            { id: 'docx', label: 'DOCX' },
            { id: 'pdf', label: 'PDF' },
            { id: 'img', label: 'Images' },
            { id: 'fav', label: 'Favorites' }
          ].map((chip) => {
            const isSelected = activeFilter === chip.id;
            return (
              <button
                key={chip.id}
                type="button"
                onClick={() => setActiveFilter(chip.id as any)}
                className={`px-3 py-1.5 rounded-full font-bold text-xs whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-neutral-100 dark:bg-neutral-700 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-600'
                }`}
              >
                {chip.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Document List */}
      <div className="flex-1 p-3 overflow-y-auto space-y-2">
        {filteredDocs.length === 0 ? (
          <div className="text-center py-20 px-6 rounded-3xl border-2 border-dashed border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800/40 space-y-3">
            <div className="w-16 h-16 mx-auto rounded-3xl bg-neutral-100 dark:bg-neutral-800 text-neutral-500 flex items-center justify-center">
              <FolderOpen className="w-8 h-8" />
            </div>
            <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
              No Documents in this Category
            </h3>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 max-w-xs mx-auto">
              Export documents or images from any tool to view, organize, and manage them here.
            </p>
          </div>
        ) : (
          filteredDocs.map((doc) => {
            const isPdf = doc.type === 'pdf';
            const isDocx = doc.type === 'docx';
            const isImg = doc.type === 'png' || doc.type === 'jpg';

            return (
              <div
                key={doc.id}
                className="flex items-center justify-between p-3 rounded-2xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 shadow-xs hover:border-blue-400 dark:hover:border-blue-500 transition-all"
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-xs uppercase text-white shadow-xs shrink-0 ${
                      isPdf
                        ? 'bg-rose-600'
                        : isDocx
                        ? 'bg-blue-600'
                        : isImg
                        ? 'bg-emerald-600'
                        : 'bg-neutral-600'
                    }`}
                  >
                    {doc.type}
                  </div>

                  <div className="min-w-0 flex-1 mr-2">
                    {editingId === doc.id ? (
                      <div className="flex items-center gap-1">
                        <input
                          type="text"
                          value={editingName}
                          onChange={(e) => setEditingName(e.target.value)}
                          className="px-2 py-0.5 text-xs rounded border border-blue-500 bg-neutral-50 dark:bg-neutral-900 text-neutral-900 dark:text-neutral-100 w-full"
                          autoFocus
                        />
                        <button
                          type="button"
                          onClick={() => handleConfirmRename(doc.id)}
                          className="p-1 text-emerald-600"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingId(null)}
                          className="p-1 text-neutral-400"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <p
                        onClick={() => onOpenDocument(doc)}
                        className="text-xs font-bold text-neutral-900 dark:text-neutral-100 truncate cursor-pointer hover:text-blue-600 dark:hover:text-blue-400"
                      >
                        {doc.name}
                      </p>
                    )}

                    <div className="flex items-center gap-2 text-[10px] text-neutral-500 mt-0.5">
                      <span>{formatFileSize(doc.sizeBytes)}</span>
                      <span>•</span>
                      <span>{formatFileTime(doc.createdAt)}</span>
                      <span>•</span>
                      <span className="text-blue-600 dark:text-blue-400 font-medium">
                        {doc.sourceFeature}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={() => handleToggleFav(doc.id)}
                    className="p-1.5 rounded-lg text-neutral-400 hover:text-amber-500 transition-colors"
                    title="Toggle Favorite"
                  >
                    <Star
                      className={`w-3.5 h-3.5 ${
                        doc.isFavorite ? 'fill-amber-400 text-amber-500' : ''
                      }`}
                    />
                  </button>

                  <button
                    type="button"
                    onClick={() => handleStartRename(doc)}
                    className="p-1.5 rounded-lg text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200"
                    title="Rename"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>

                  {doc.blobData && (
                    <button
                      type="button"
                      onClick={() => shareFile(doc.blobData!, doc.name)}
                      className="p-1.5 rounded-lg text-neutral-400 hover:text-blue-600"
                      title="Share"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                    </button>
                  )}

                  {doc.blobData && (
                    <button
                      type="button"
                      onClick={() => triggerFileDownload(doc.blobData!, doc.name)}
                      className="p-1.5 rounded-lg text-neutral-400 hover:text-blue-600"
                      title="Download"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => handleDelete(doc.id)}
                    className="p-1.5 rounded-lg text-neutral-400 hover:text-rose-600"
                    title="Delete"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
