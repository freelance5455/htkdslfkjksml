import React from "react";
import {
  History,
  Clock,
  Calendar,
  Pin,
  Star,
  Tag,
  Paperclip,
  CheckSquare,
  FileText,
  Volume2,
  Sparkles,
  ArrowUpRight
} from "lucide-react";
import { Note } from "../../types";

interface TimelineFeedViewProps {
  notes: Note[];
  onOpenNote: (note: Note) => void;
  onTogglePin: (id: string, e: React.MouseEvent) => void;
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
  onDeleteNote: (id: string, e: React.MouseEvent) => void;
  onTagClick?: (tag: string) => void;
}

export const TimelineFeedView: React.FC<TimelineFeedViewProps> = ({
  notes,
  onOpenNote,
  onTogglePin,
  onToggleFavorite,
  onDeleteNote,
  onTagClick,
}) => {
  // Sort notes chronologically (newest first)
  const sortedNotes = [...notes].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  // Group notes by time periods
  const now = new Date();
  const todayStr = now.toDateString();
  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = yesterday.toDateString();

  const groups: { label: string; dateBadge: string; notes: Note[] }[] = [];

  const todayNotes: Note[] = [];
  const yesterdayNotes: Note[] = [];
  const thisWeekNotes: Note[] = [];
  const earlierNotes: Note[] = [];

  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

  sortedNotes.forEach((note) => {
    const noteDate = new Date(note.createdAt);
    const noteDateStr = noteDate.toDateString();

    if (noteDateStr === todayStr) {
      todayNotes.push(note);
    } else if (noteDateStr === yesterdayStr) {
      yesterdayNotes.push(note);
    } else if (noteDate >= sevenDaysAgo) {
      thisWeekNotes.push(note);
    } else {
      earlierNotes.push(note);
    }
  });

  if (todayNotes.length > 0) {
    groups.push({
      label: "Bugün",
      dateBadge: "BUGÜN",
      notes: todayNotes,
    });
  }
  if (yesterdayNotes.length > 0) {
    groups.push({
      label: "Dün",
      dateBadge: "DÜN",
      notes: yesterdayNotes,
    });
  }
  if (thisWeekNotes.length > 0) {
    groups.push({
      label: "Bu Hafta",
      dateBadge: "BU HAFTA",
      notes: thisWeekNotes,
    });
  }
  if (earlierNotes.length > 0) {
    groups.push({
      label: "Daha Eski Notlar",
      dateBadge: "GEÇMİŞ",
      notes: earlierNotes,
    });
  }

  return (
    <div className="space-y-6 animate-in fade-in max-w-4xl mx-auto">
      {/* Feed Header Banner */}
      <div className="flex items-center justify-between bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-100 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400">
            <History className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
              <span>Zaman Çizelgesi & Günlük Akışı</span>
              <span className="text-xs bg-teal-100 dark:bg-teal-900/60 text-teal-700 dark:text-teal-300 px-2.5 py-0.5 rounded-full font-bold">
                {notes.length} Not
              </span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Notlarınızın kronolojik zaman tüneli ve geçmiş kayıtları
            </p>
          </div>
        </div>
      </div>

      {/* Timeline Section Feed */}
      <div className="relative pl-6 sm:pl-10 space-y-8 before:absolute before:left-3 sm:before:left-5 before:top-2 before:bottom-2 before:w-0.5 before:bg-gradient-to-b before:from-teal-500 before:via-blue-500 before:to-slate-300 dark:before:to-slate-700">
        {groups.map((group) => (
          <div key={group.label} className="space-y-4 relative">
            {/* Group Marker Node */}
            <div className="flex items-center gap-3 -ml-6 sm:-ml-10">
              <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-full bg-teal-600 text-white flex items-center justify-center font-extrabold text-xs shadow-md shadow-teal-500/20 z-10 shrink-0">
                <Calendar className="w-3.5 h-3.5" />
              </div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-sm text-slate-900 dark:text-white">
                  {group.label}
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
                  {group.notes.length} Kayıt
                </span>
              </div>
            </div>

            {/* Note Cards in this Group */}
            <div className="space-y-3 pl-2">
              {group.notes.map((note) => {
                const formattedTime = new Date(note.createdAt).toLocaleTimeString("tr-TR", {
                  hour: "2-digit",
                  minute: "2-digit",
                });
                const formattedDate = new Date(note.createdAt).toLocaleDateString("tr-TR", {
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                });

                const completedTasks = note.tasks?.filter((t) => t.completed).length || 0;
                const totalTasks = note.tasks?.length || 0;

                return (
                  <div
                    key={note.id}
                    onClick={() => onOpenNote(note)}
                    className="relative group bg-white dark:bg-slate-900 p-4 sm:p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs hover:shadow-lg transition-all cursor-pointer hover:border-teal-500/80 dark:hover:border-teal-500/80"
                  >
                    {/* Top Row: Timestamp & Category */}
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2 text-xs text-slate-400 font-medium">
                        <Clock className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
                        <span>
                          {formattedDate} • {formattedTime}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold px-2.5 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                          {note.category || "Genel"}
                        </span>
                        <button
                          onClick={(e) => onTogglePin(note.id, e)}
                          className={`p-1 rounded-md cursor-pointer ${
                            note.pinned ? "text-rose-500 font-bold" : "text-slate-400 hover:text-slate-600"
                          }`}
                        >
                          <Pin className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={(e) => onToggleFavorite(note.id, e)}
                          className={`p-1 rounded-md cursor-pointer ${
                            note.favorite ? "text-amber-500 font-bold" : "text-slate-400 hover:text-slate-600"
                          }`}
                        >
                          <Star className="w-3.5 h-3.5 fill-current" />
                        </button>
                      </div>
                    </div>

                    {/* Title */}
                    <h4 className="text-base font-bold text-slate-900 dark:text-white mb-1.5 group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors">
                      {note.title || "Başlıksız Not"}
                    </h4>

                    {/* Content Snippet */}
                    {note.content && (
                      <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-3 mb-3 leading-relaxed">
                        {note.content.replace(/<[^>]*>/g, "")}
                      </p>
                    )}

                    {/* Metadata Badges: Attachments, Tasks, Audio */}
                    <div className="flex flex-wrap items-center gap-3 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
                      {totalTasks > 0 && (
                        <span className="flex items-center gap-1 text-teal-600 dark:text-teal-400 font-semibold bg-teal-50 dark:bg-teal-950/40 px-2 py-0.5 rounded-md">
                          <CheckSquare className="w-3.5 h-3.5" />
                          <span>
                            {completedTasks}/{totalTasks} Görev
                          </span>
                        </span>
                      )}

                      {note.attachments && note.attachments.length > 0 && (
                        <span className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md">
                          <Paperclip className="w-3.5 h-3.5" />
                          <span>{note.attachments.length} Dosya</span>
                        </span>
                      )}

                      {note.audioNotes && note.audioNotes.length > 0 && (
                        <span className="flex items-center gap-1 bg-purple-50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-400 px-2 py-0.5 rounded-md">
                          <Volume2 className="w-3.5 h-3.5" />
                          <span>{note.audioNotes.length} Ses Kaydı</span>
                        </span>
                      )}

                      {/* Tags */}
                      {note.tags && note.tags.length > 0 && (
                        <div className="flex items-center gap-1 ml-auto">
                          {note.tags.map((t) => (
                            <button
                              key={t}
                              onClick={(e) => {
                                e.stopPropagation();
                                if (onTagClick) onTagClick(t);
                              }}
                              className="text-[11px] font-medium text-teal-600 dark:text-teal-400 hover:underline cursor-pointer"
                            >
                              #{t}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
