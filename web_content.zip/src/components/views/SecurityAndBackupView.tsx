import React, { useState } from 'react';
import { SecuritySettings, AppSettings } from '../../types';
import { storage, ExportDataEnvelope } from '../../utils/storage';
import { getDualAccentInfo } from '../../utils/theme';
import { AppLockSettingsCard } from '../AppLock';
import { BackupAndSyncSection } from '../BackupAndSync';
import { BackupAndRestoreCard } from '../BackupAndRestore';
import {
  ShieldCheck,
  CheckCircle2,
  Database,
  ArrowLeft,
  HardDrive,
  FolderSync,
} from 'lucide-react';

interface SecurityAndBackupViewProps {
  securitySettings: SecuritySettings;
  appSettings: AppSettings;
  onUpdateSecurity: (newSettings: SecuritySettings) => void;
  onUpdateSettings: (newSettings: AppSettings) => void;
  onDataImported: () => void;
  onLockNow: () => void;
  onBackToSettings?: () => void;
  onResetAllData?: () => void;
}

export const SecurityAndBackupView: React.FC<SecurityAndBackupViewProps> = ({
  securitySettings,
  appSettings,
  onUpdateSecurity,
  onUpdateSettings,
  onDataImported,
  onLockNow,
  onBackToSettings,
  onResetAllData,
}) => {
  const [isSyncingDrive, setIsSyncingDrive] = useState(false);
  const [syncStatusMsg, setSyncStatusMsg] = useState('');
  const [backupTab, setBackupTab] = useState<'backup_restore' | 'backup_sync'>('backup_restore');

  const autoSnapshots = storage.getAutoBackupSnapshots();

  const isLight = appSettings.themeMode === 'light';
  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );
  const cardBg = isLight
    ? 'bg-white/95 border-slate-200/90 shadow-xs'
    : 'bg-slate-800/90 border-slate-700/60 shadow-md';
  const innerCardBg = isLight
    ? 'bg-slate-50/80 border-slate-200/70'
    : 'bg-slate-900/80 border-slate-700/50';
  const headingText = isLight ? 'text-slate-900' : 'text-slate-100';
  const subText = isLight ? 'text-slate-500' : 'text-slate-400';

  const isEn = appSettings.language === 'en';

  // Google Drive / Cloud Sync simulation
  const handleGoogleDriveSync = () => {
    setIsSyncingDrive(true);
    setSyncStatusMsg(isEn ? 'Connecting to Cloud Drive...' : 'ক্লাউড ড্রাইভ কানেক্ট করা হচ্ছে...');
    setTimeout(() => {
      setSyncStatusMsg(isEn ? 'Encrypting data and uploading to Drive vault...' : 'ডেটা এনক্রিপ্ট করে ড্রাইভে পাঠানো হচ্ছে...');
      setTimeout(() => {
        setIsSyncingDrive(false);
        const lastSyncTime = new Date().toLocaleTimeString(isEn ? 'en-US' : 'bn-BD');
        const prevConfig = appSettings.backupSyncConfig;
        onUpdateSettings({
          ...appSettings,
          googleDriveConnected: true,
          googleDriveLastSynced: lastSyncTime,
          backupSyncConfig: {
            connected: true,
            provider: prevConfig?.provider || 'google_drive',
            accountEmail: prevConfig?.accountEmail || 'excelbdtech@gmail.com',
            folderName: prevConfig?.folderName || 'TakaTracker_Backups',
            syncInterval: prevConfig?.syncInterval || '1h',
            isAutoSyncActive: prevConfig?.isAutoSyncActive ?? true,
            lastSyncedAt: lastSyncTime,
            lastSyncStatus: 'success',
            lastStatusMessage: isEn
              ? `Synced successfully (${lastSyncTime})`
              : `সফলভাবে সিঙ্ক হয়েছে (${lastSyncTime})`,
          },
        });
        setSyncStatusMsg(
          isEn
            ? `Successfully auto-synced with Cloud Drive (${lastSyncTime})`
            : `ক্লাউড ড্রাইভে সফলভাবে অটো-সিঙ্ক হয়েছে (${lastSyncTime})`
        );
      }, 1200);
    }, 1000);
  };

  // Export File
  const handleDownloadBackup = () => {
    const backupData = storage.exportBackupFile();
    const blob = new Blob([JSON.stringify(backupData, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `taka_tracker_backup_${new Date().toISOString().split('T')[0]}.json`;
    link.click();
  };

  // Import File
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string) as ExportDataEnvelope;
        const success = storage.importBackupFile(json);
        if (success) {
          alert(isEn ? 'Backup file restored successfully!' : 'ব্যাকআপ ফাইল সফলভাবে রিস্টোর করা হয়েছে!');
          onDataImported();
        } else {
          alert(isEn ? 'Error: Invalid backup file structure!' : 'ত্রুটি: ভুল ব্যাকআপ ফাইল স্ট্রাকচার!');
        }
      } catch (err) {
        alert(isEn ? 'Failed to read the file!' : 'ফাইল রীড করতে সমস্যা হয়েছে!');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-5 pb-8 animate-in fade-in duration-200">
      {/* Top Bar with Back to Settings navigation */}
      {onBackToSettings && (
        <div className="flex items-center justify-between">
          <button
            onClick={onBackToSettings}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition cursor-pointer ${
              isLight
                ? 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 shadow-xs'
                : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
            }`}
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>{isEn ? 'Back to Settings' : 'সেটিংসে ফিরে যান'}</span>
          </button>

          <span
            className={`text-[10px] font-bold px-2.5 py-1 rounded-full border uppercase tracking-wider ${
              isLight
                ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                : 'bg-slate-800 text-emerald-400 border-emerald-800/40'
            }`}
          >
            {isEn ? 'Protected' : 'সুরক্ষিত'}
          </span>
        </div>
      )}

      {/* Header */}
      <div>
        <h1 className={`text-xl font-black flex items-center gap-2 ${headingText}`}>
          <ShieldCheck className="w-5 h-5 text-emerald-500" />
          <span>{isEn ? 'Security & Backup Center' : 'নিরাপত্তা ও ব্যাকআপ কেন্দ্র'}</span>
        </h1>
        <p className={`text-xs ${subText}`}>
          {isEn
            ? 'Encrypted PIN security, 2FA, offline backups & Google Drive sync'
            : 'এনক্রিপটেড পিন সুরক্ষা, ২এফএ, অফলাইন ব্যাকআপ এবং গুগল ড্রাইভ সিঙ্কিং'}
        </p>
      </div>

      {/* AES Encryption Status Badge */}
      <div
        className={`p-4 rounded-3xl flex items-center gap-3 border ${
          isLight
            ? 'bg-gradient-to-r from-emerald-50/80 to-slate-50/80 border-slate-200/90 text-slate-900 shadow-xs'
            : 'bg-gradient-to-r from-emerald-950/60 to-gray-900 border-emerald-800/60 text-white'
        }`}
      >
        <div
          className={`p-2.5 rounded-2xl ${
            isLight ? 'bg-emerald-100 text-emerald-800' : 'bg-emerald-900/60 text-emerald-400'
          }`}
        >
          <Database className="w-5 h-5" />
        </div>
        <div>
          <h2 className={`text-xs font-bold flex items-center gap-1.5 ${headingText}`}>
            {isEn ? 'AES-256 Encryption Active' : 'AES-256 এনক্রিপশন সক্রিয়'}{' '}
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </h2>
          <p className={`text-[10px] mt-0.5 ${subText}`}>
            {isEn
              ? 'Your financial transactions and records are stored encrypted directly on your local device.'
              : 'আপনার প্রতিটি খরচের তথ্য এবং হিসাব আপনার স্থানীয় ডিভাইসে এনক্রিপ্ট হয়ে জমা থাকে।'}
          </p>
        </div>
      </div>

      {/* 1. Lock & Security (Pattern + PIN) Section */}
      <AppLockSettingsCard
        securitySettings={securitySettings}
        onUpdateSecurity={onUpdateSecurity}
        appSettings={appSettings}
        onLockNow={onLockNow}
      />

      {/* 2. Backup & Reset Section (with two main buttons: Backup & Restore and Cloud & Sync) */}
      <div className="space-y-4">
        {/* Two Main Side-by-Side Buttons */}
        <div
          className="grid grid-cols-2 gap-2 p-1.5 rounded-2xl border transition-colors"
          style={{
            backgroundColor: isLight
              ? `color-mix(in srgb, ${dualAccent.primary.hex} 10%, #ffffff)`
              : `color-mix(in srgb, ${dualAccent.primary.hex} 12%, #0f172a)`,
            borderColor: `color-mix(in srgb, ${dualAccent.primary.hex} 25%, transparent)`,
          }}
        >
          <button
            type="button"
            onClick={() => setBackupTab('backup_restore')}
            id="page-tab-backup-restore-btn"
            style={
              backupTab === 'backup_restore'
                ? {
                    backgroundColor: dualAccent.primary.hex,
                    color: '#ffffff',
                    boxShadow: `0 4px 14px -2px ${dualAccent.primary.hex}60`,
                  }
                : undefined
            }
            className={`py-3 px-3 rounded-xl font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 cursor-pointer ${
              backupTab === 'backup_restore'
                ? 'font-black text-white shadow-md'
                : isLight
                ? 'text-slate-700 hover:text-slate-900 hover:bg-black/5'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <HardDrive
              className="w-4 h-4 shrink-0"
              style={{ color: backupTab === 'backup_restore' ? '#ffffff' : dualAccent.primary.hex }}
            />
            <span className="truncate">{isEn ? 'Backup & Restore' : 'ব্যাকআপ ও রিস্টোর'}</span>
          </button>

          <button
            type="button"
            onClick={() => setBackupTab('backup_sync')}
            id="page-tab-cloud-sync-btn"
            style={
              backupTab === 'backup_sync'
                ? {
                    backgroundColor: dualAccent.primary.hex,
                    color: '#ffffff',
                    boxShadow: `0 4px 14px -2px ${dualAccent.primary.hex}60`,
                  }
                : undefined
            }
            className={`py-3 px-3 rounded-xl font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 cursor-pointer ${
              backupTab === 'backup_sync'
                ? 'font-black text-white shadow-md'
                : isLight
                ? 'text-slate-700 hover:text-slate-900 hover:bg-black/5'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <FolderSync
              className="w-4 h-4 shrink-0"
              style={{ color: backupTab === 'backup_sync' ? '#ffffff' : dualAccent.primary.hex }}
            />
            <span className="truncate">{isEn ? 'Cloud & Sync' : 'ক্লাউড ও সিঙ্ক'}</span>
          </button>
        </div>

        {backupTab === 'backup_restore' ? (
          <BackupAndRestoreCard
            appSettings={appSettings}
            onDownloadBackup={handleDownloadBackup}
            onFileUpload={handleFileUpload}
            autoSnapshots={autoSnapshots}
            onResetAllData={onResetAllData}
            isPopupView={false}
          />
        ) : (
          <BackupAndSyncSection
            appSettings={appSettings}
            onUpdateSettings={onUpdateSettings}
            isSyncingDrive={isSyncingDrive}
            syncStatusMsg={syncStatusMsg}
            onTriggerSync={handleGoogleDriveSync}
          />
        )}
      </div>
    </div>
  );
};
