import React, { useState } from 'react';
import {
  GitMerge,
  Upload,
  ArrowUp,
  ArrowDown,
  Trash2,
  Download,
  FileText,
  FileCheck2,
  RefreshCw,
  Info,
  Layers,
  Sparkles
} from 'lucide-react';
import { MergeFileItem, MergeMode, MergeOutputFormat } from '../../types';
import { mergePdfFiles } from '../../utils/pdfProcessor';
import { mergeDocxFiles, parseDocxFile } from '../../utils/docxProcessor';
import { extractTextFromPdf } from '../../utils/pdfProcessor';
import {
  generateDocxBlob,
  generatePdfBlob,
  DEFAULT_STYLE_SETTINGS,
  parseRawTextToSections
} from '../../utils/documentEngine';
import { triggerFileDownload, saveStoredDocument, formatFileSize } from '../../services/storageService';

interface DocumentMergeViewProps {
  onBack: () => void;
}

export const DocumentMergeView: React.FC<DocumentMergeViewProps> = ({ onBack }) => {
  const [files, setFiles] = useState<MergeFileItem[]>([]);
  const [outputFormat, setOutputFormat] = useState<MergeOutputFormat>('pdf');
  const [mergeMode, setMergeMode] = useState<MergeMode>('visual_fidelity');
  const [isMerging, setIsMerging] = useState(false);
  const [progressMsg, setProgressMsg] = useState('');
  const [mergedDocName, setMergedDocName] = useState('Merged_Document');

  // Handle file uploads
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const uploaded = Array.from(e.target.files);

    const newItems: MergeFileItem[] = uploaded.map((file) => {
      const isPdf = file.name.toLowerCase().endsWith('.pdf');
      return {
        id: 'file-' + Math.random().toString(36).substring(2, 9),
        name: file.name,
        file,
        type: isPdf ? 'pdf' : 'docx',
        sizeBytes: file.size
      };
    });

    setFiles((prev) => [...prev, ...newItems]);
  };

  const moveUp = (index: number) => {
    if (index === 0) return;
    const next = [...files];
    const temp = next[index - 1];
    next[index - 1] = next[index];
    next[index] = temp;
    setFiles(next);
  };

  const moveDown = (index: number) => {
    if (index === files.length - 1) return;
    const next = [...files];
    const temp = next[index + 1];
    next[index + 1] = next[index];
    next[index] = temp;
    setFiles(next);
  };

  const removeFile = (id: string) => {
    setFiles((prev) => prev.filter((f) => f.id !== id));
  };

  const handleExecuteMerge = async () => {
    if (files.length === 0) return;
    setIsMerging(true);
    setProgressMsg('Analyzing document formats...');

    try {
      const allPdf = files.every((f) => f.type === 'pdf');
      const allDocx = files.every((f) => f.type === 'docx');

      let resultBlob: Blob;

      if (allPdf && outputFormat === 'pdf') {
        // Pure PDF merge (highest visual fidelity)
        setProgressMsg('Merging PDF page streams...');
        resultBlob = await mergePdfFiles(files.map((f) => f.file));
      } else if (allDocx && outputFormat === 'docx') {
        // Pure DOCX merge
        setProgressMsg('Merging Word document structures...');
        resultBlob = await mergeDocxFiles(files.map((f) => f.file), 'docx');
      } else if (allDocx && outputFormat === 'pdf') {
        // DOCX to PDF merge
        setProgressMsg('Converting Word documents to unified PDF...');
        resultBlob = await mergeDocxFiles(files.map((f) => f.file), 'pdf');
      } else {
        // Mixed Formats: PDF + DOCX
        setProgressMsg('Synthesizing mixed formats...');
        const combinedSections: any[] = [];

        for (let i = 0; i < files.length; i++) {
          const item = files[i];
          setProgressMsg(`Processing ${item.name} (${i + 1}/${files.length})...`);

          if (i > 0) {
            combinedSections.push({
              id: 'break-' + i,
              type: 'page_break',
              content: ''
            });
          }

          combinedSections.push({
            id: 'title-' + i,
            type: 'heading',
            content: item.name.replace(/\.[^/.]+$/, ''),
            level: 1
          });

          if (item.type === 'docx') {
            const parsed = await parseDocxFile(item.file);
            combinedSections.push(...parsed.sections);
          } else {
            // PDF text extraction
            const extractedText = await extractTextFromPdf(item.file);
            const sections = parseRawTextToSections(extractedText);
            combinedSections.push(...sections);
          }
        }

        if (outputFormat === 'docx') {
          resultBlob = await generateDocxBlob(mergedDocName, combinedSections, DEFAULT_STYLE_SETTINGS);
        } else {
          resultBlob = await generatePdfBlob(mergedDocName, combinedSections, DEFAULT_STYLE_SETTINGS);
        }
      }

      const fileName = `${mergedDocName.replace(/\s+/g, '_')}.${outputFormat}`;
      triggerFileDownload(resultBlob, fileName);

      saveStoredDocument({
        id: 'merged-' + Date.now(),
        name: fileName,
        type: outputFormat,
        sizeBytes: resultBlob.size,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        blobData: resultBlob,
        pageCount: files.length,
        sourceFeature: 'Document Merging'
      });
    } catch (e) {
      console.error('Merge execution error:', e);
    } finally {
      setIsMerging(false);
    }
  };

  const hasMixedFormats = files.some(f => f.type === 'pdf') && files.some(f => f.type === 'docx');

  return (
    <div className="flex-1 flex flex-col h-full bg-neutral-50 dark:bg-neutral-900 pb-16">
      {/* Header Settings */}
      <div className="px-4 py-3 bg-white dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <input
            type="text"
            value={mergedDocName}
            onChange={(e) => setMergedDocName(e.target.value)}
            className="text-sm font-bold bg-transparent border-b border-transparent hover:border-neutral-300 focus:border-blue-500 text-neutral-900 dark:text-neutral-100 focus:outline-none"
            placeholder="Merged Document Name"
          />

          <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs shadow-xs active:scale-95 transition-all">
            <Upload className="w-3.5 h-3.5" />
            <span>Add DOCX / PDF Files</span>
            <input
              type="file"
              multiple
              accept=".docx,.pdf"
              className="hidden"
              onChange={handleFileUpload}
            />
          </label>
        </div>

        {/* Output format & Mode selection */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div>
            <label className="block text-[10px] font-semibold text-neutral-500 uppercase mb-1">
              Output Format
            </label>
            <div className="grid grid-cols-2 gap-1 bg-neutral-100 dark:bg-neutral-700 p-0.5 rounded-xl">
              <button
                type="button"
                onClick={() => setOutputFormat('pdf')}
                className={`py-1 rounded-lg text-xs font-bold transition-all ${
                  outputFormat === 'pdf'
                    ? 'bg-white dark:bg-neutral-800 text-violet-700 dark:text-violet-300 shadow-xs'
                    : 'text-neutral-600 dark:text-neutral-300'
                }`}
              >
                PDF
              </button>
              <button
                type="button"
                onClick={() => setOutputFormat('docx')}
                className={`py-1 rounded-lg text-xs font-bold transition-all ${
                  outputFormat === 'docx'
                    ? 'bg-white dark:bg-neutral-800 text-violet-700 dark:text-violet-300 shadow-xs'
                    : 'text-neutral-600 dark:text-neutral-300'
                }`}
              >
                DOCX (Word)
              </button>
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-semibold text-neutral-500 uppercase mb-1">
              Merge Mode
            </label>
            <div className="grid grid-cols-2 gap-1 bg-neutral-100 dark:bg-neutral-700 p-0.5 rounded-xl">
              <button
                type="button"
                onClick={() => setMergeMode('visual_fidelity')}
                className={`py-1 rounded-lg text-xs font-bold transition-all ${
                  mergeMode === 'visual_fidelity'
                    ? 'bg-white dark:bg-neutral-800 text-violet-700 dark:text-violet-300 shadow-xs'
                    : 'text-neutral-600 dark:text-neutral-300'
                }`}
              >
                Visual Fidelity
              </button>
              <button
                type="button"
                onClick={() => setMergeMode('editable')}
                className={`py-1 rounded-lg text-xs font-bold transition-all ${
                  mergeMode === 'editable'
                    ? 'bg-white dark:bg-neutral-800 text-violet-700 dark:text-violet-300 shadow-xs'
                    : 'text-neutral-600 dark:text-neutral-300'
                }`}
              >
                Editable Reconstruct
              </button>
            </div>
          </div>
        </div>

        {/* Informational callout for mixed formats */}
        {hasMixedFormats && (
          <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-[11px] text-amber-800 dark:text-amber-300 flex items-start gap-2">
            <Info className="w-4 h-4 shrink-0 mt-0.5 text-amber-600" />
            <span>
              Mixed format merge detected (DOCX + PDF). Sections will be synthesized sequentially while preserving headers, lists, and tables.
            </span>
          </div>
        )}
      </div>

      {isMerging && (
        <div className="px-4 py-2 bg-violet-50 dark:bg-violet-950/60 border-b border-violet-200 dark:border-violet-800 flex items-center justify-between text-xs font-semibold text-violet-800 dark:text-violet-300">
          <span className="flex items-center gap-1.5">
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            <span>{progressMsg}</span>
          </span>
        </div>
      )}

      {/* File Sequence Workspace */}
      <div className="flex-1 p-3 overflow-y-auto space-y-3">
        {files.length === 0 ? (
          <div className="text-center py-20 px-6 rounded-3xl border-2 border-dashed border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800/40 space-y-3">
            <div className="w-16 h-16 mx-auto rounded-3xl bg-violet-50 dark:bg-violet-950/40 text-violet-600 flex items-center justify-center">
              <GitMerge className="w-8 h-8" />
            </div>
            <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
              Select Files to Merge
            </h3>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 max-w-xs mx-auto">
              Add multiple DOCX files, multiple PDF files, or mixed documents. Reorder them below before exporting.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            <div className="flex items-center justify-between px-1">
              <span className="text-xs font-bold text-neutral-700 dark:text-neutral-300">
                Sequence Order ({files.length} files)
              </span>
              <span className="text-[11px] text-neutral-500">
                Use arrows to adjust order
              </span>
            </div>

            {files.map((file, idx) => {
              const isPdf = file.type === 'pdf';
              return (
                <div
                  key={file.id}
                  className="flex items-center justify-between p-3 rounded-2xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 shadow-xs"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="w-6 h-6 rounded-full bg-neutral-100 dark:bg-neutral-700 text-neutral-600 dark:text-neutral-300 flex items-center justify-center font-bold text-xs shrink-0">
                      {idx + 1}
                    </span>

                    <span
                      className={`px-2 py-0.5 rounded-md font-bold text-[10px] uppercase text-white shrink-0 ${
                        isPdf ? 'bg-rose-600' : 'bg-blue-600'
                      }`}
                    >
                      {file.type}
                    </span>

                    <div className="min-w-0">
                      <p className="text-xs font-bold text-neutral-900 dark:text-neutral-100 truncate max-w-[150px] sm:max-w-xs">
                        {file.name}
                      </p>
                      <p className="text-[10px] text-neutral-500">
                        {formatFileSize(file.sizeBytes)}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      disabled={idx === 0}
                      onClick={() => moveUp(idx)}
                      title="Move Up"
                      className="p-1.5 rounded-lg text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 disabled:opacity-30"
                    >
                      <ArrowUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      disabled={idx === files.length - 1}
                      onClick={() => moveDown(idx)}
                      title="Move Down"
                      className="p-1.5 rounded-lg text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 disabled:opacity-30"
                    >
                      <ArrowDown className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => removeFile(file.id)}
                      title="Remove"
                      className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Action Footer */}
      <div className="sticky bottom-0 px-4 py-3 bg-white/95 dark:bg-neutral-800/95 backdrop-blur-md border-t border-neutral-200 dark:border-neutral-700 flex items-center justify-between gap-2 shadow-lg">
        <button
          type="button"
          onClick={onBack}
          className="px-4 py-2 rounded-xl text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-xs font-semibold"
        >
          Back
        </button>

        <button
          type="button"
          disabled={files.length === 0 || isMerging}
          onClick={handleExecuteMerge}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all disabled:opacity-40"
        >
          <GitMerge className="w-4 h-4" />
          <span>Merge {files.length} Files to {outputFormat.toUpperCase()}</span>
        </button>
      </div>
    </div>
  );
};
