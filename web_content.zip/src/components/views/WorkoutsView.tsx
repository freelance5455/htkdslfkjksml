import React, { useState } from 'react';
import {
  Play,
  Plus,
  Clock,
  Dumbbell,
  Trash2,
  Copy,
  Edit,
  History,
  CheckCircle2,
  ChevronRight,
  Flame,
  Calendar,
  X,
  ArrowUp,
  ArrowDown,
  FileText,
  Eye,
  ChevronDown,
  ChevronUp,
  TrendingUp,
  Minus
} from 'lucide-react';
import { useWorkout } from '../../context/WorkoutContext';
import { CustomRoutine, CustomRoutineExercise, Exercise, SetType, Workout } from '../../types';
import { MuscleMapCharacter } from '../MuscleMapCharacter';
import { PRBadgeChip, PRSummaryShowcase } from '../PRBadge';
import { RoutinePreviewModal, RoutineInlinePreview } from '../RoutinePreviewModal';

export const WorkoutsView: React.FC = () => {
  const {
    customRoutines,
    startWorkout,
    startEmptyWorkout,
    workoutHistory,
    deleteWorkoutFromHistory,
    saveCustomRoutine,
    overloadRoutine,
    deleteCustomRoutine,
    duplicateCustomRoutine,
    triggerPRNotification,
    exercises,
    user
  } = useWorkout();

  const [activeTab, setActiveTab] = useState<'presets' | 'custom' | 'history'>('presets');
  const [selectedHistoryWorkout, setSelectedHistoryWorkout] = useState<Workout | null>(null);
  const [previewRoutine, setPreviewRoutine] = useState<CustomRoutine | null>(null);
  const [expandedRoutineIds, setExpandedRoutineIds] = useState<Record<string, boolean>>({});
  // Tracks which individual exercise inside a routine card is focused to inspect its muscle map
  const [routineFocusedExercise, setRoutineFocusedExercise] = useState<Record<string, string | null>>({});

  const toggleInlineRoutine = (routineId: string) => {
    setExpandedRoutineIds((prev) => ({
      ...prev,
      [routineId]: !prev[routineId]
    }));
  };

  // Custom Workout Builder Modal State
  const [isBuilderOpen, setIsBuilderOpen] = useState(false);
  const [builderId, setBuilderId] = useState<string | null>(null);
  const [builderName, setBuilderName] = useState('');
  const [builderDescription, setBuilderDescription] = useState('');
  const [builderExercises, setBuilderExercises] = useState<CustomRoutineExercise[]>([]);
  const [isAddingExercise, setIsAddingExercise] = useState(false);
  const [exerciseSearch, setExerciseSearch] = useState('');

  const formatSeconds = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = sec % 60;
    return `${mins}m ${secs}s`;
  };

  const formatDate = (isoString: string) => {
    const d = new Date(isoString);
    return d.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const handleOpenBuilder = (routineToEdit?: CustomRoutine) => {
    if (routineToEdit) {
      setBuilderId(routineToEdit.id);
      setBuilderName(routineToEdit.name);
      setBuilderDescription(routineToEdit.description);
      setBuilderExercises([...routineToEdit.exercises]);
    } else {
      setBuilderId(null);
      setBuilderName('');
      setBuilderDescription('');
      setBuilderExercises([
        { exerciseId: 'pull-up', setsCount: 3, defaultReps: 8, restTimeSec: 90 },
        { exerciseId: 'push-up', setsCount: 3, defaultReps: 12, restTimeSec: 60 }
      ]);
    }
    setIsBuilderOpen(true);
  };

  const handleSaveRoutine = () => {
    if (!builderName.trim() || builderExercises.length === 0) return;

    const newRoutine: CustomRoutine = {
      id: builderId || `routine_${Date.now()}`,
      name: builderName.trim(),
      description: builderDescription.trim() || 'Custom home calisthenics routine',
      exercises: builderExercises,
      estimatedDurationMin: Math.max(15, builderExercises.length * 7),
      isCustom: true
    };

    saveCustomRoutine(newRoutine);
    setIsBuilderOpen(false);
  };

  const handleAddExerciseToBuilder = (exerciseId: string) => {
    const exDef = exercises.find((e) => e.id === exerciseId);
    setBuilderExercises((prev) => [
      ...prev,
      {
        exerciseId,
        setsCount: 3,
        defaultReps: exDef?.isHold ? undefined : (exDef?.defaultReps || 10),
        defaultHoldSec: exDef?.isHold ? (exDef?.defaultHoldSec || 30) : undefined,
        restTimeSec: 60
      }
    ]);
    setIsAddingExercise(false);
  };

  const handleRemoveBuilderExercise = (index: number) => {
    setBuilderExercises((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleMoveBuilderExercise = (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === builderExercises.length - 1) return;
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    const updated = [...builderExercises];
    const [moved] = updated.splice(index, 1);
    updated.splice(targetIdx, 0, moved);
    setBuilderExercises(updated);
  };

  const presetRoutinesList = customRoutines.filter((r) => !r.isCustom);
  const myCustomRoutinesList = customRoutines.filter((r) => r.isCustom);

  return (
    <div className="space-y-5 pb-28 pt-2">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">Workouts</h1>
          <p className="text-xs text-slate-400">Routines, custom sessions & workout history</p>
        </div>

        <button
          onClick={() => handleOpenBuilder()}
          className="px-3.5 py-2 bg-neutral-900 border border-cyan-500/30 text-cyan-400 hover:border-cyan-400 font-semibold text-xs rounded-xl shadow-sm transition-all flex items-center gap-1.5 active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>New Routine</span>
        </button>
      </div>

      {/* Main Tabs Segmented Control */}
      <div className="flex items-center p-1 bg-neutral-900/80 border border-neutral-800 rounded-xl">
        <button
          onClick={() => setActiveTab('presets')}
          className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-colors ${
            activeTab === 'presets'
              ? 'bg-cyan-500 text-neutral-950 shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Preset Routines
        </button>
        <button
          onClick={() => setActiveTab('custom')}
          className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-colors ${
            activeTab === 'custom'
              ? 'bg-cyan-500 text-neutral-950 shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          My Routines ({myCustomRoutinesList.length})
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-colors ${
            activeTab === 'history'
              ? 'bg-cyan-500 text-neutral-950 shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          History ({workoutHistory.length})
        </button>
      </div>

      {/* TAB 1: PRESET ROUTINES */}
      {activeTab === 'presets' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Calisthenics Programs
            </span>
            <button
              onClick={startEmptyWorkout}
              className="text-xs font-semibold text-cyan-400 hover:text-cyan-300"
            >
              + Quick Freestyle
            </button>
          </div>

          <div className="space-y-4">
            {presetRoutinesList.map((routine) => {
              const routineExercises = routine.exercises
                .map((item) => exercises.find((e) => e.id === item.exerciseId))
                .filter((e): e is Exercise => Boolean(e));
              const focusedExId = routineFocusedExercise[routine.id] || null;
              const focusedExObj = focusedExId
                ? exercises.find((e) => e.id === focusedExId) || null
                : null;

              return (
                <div
                  key={routine.id}
                  className="bg-[#12151c] border border-neutral-800 hover:border-cyan-500/40 rounded-2xl p-4 transition-all group shadow-sm flex flex-col justify-between space-y-3"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-cyan-400" />
                        <span className="font-mono text-slate-300 font-medium">
                          {routine.estimatedDurationMin} min
                        </span>
                        <span>·</span>
                        <span>{routine.exercises.length} Exercises</span>
                      </div>
                      {focusedExObj && (
                        <button
                          type="button"
                          onClick={() =>
                            setRoutineFocusedExercise((prev) => ({ ...prev, [routine.id]: null }))
                          }
                          className="text-[11px] font-semibold text-cyan-400 hover:text-cyan-300"
                        >
                          Show Full Plan Muscles
                        </button>
                      )}
                    </div>

                    <h3 className="text-base font-bold text-white mb-1 group-hover:text-cyan-400 transition-colors">
                      {routine.name}
                    </h3>

                    <p className="text-xs text-slate-400 mb-3 leading-relaxed">
                      {routine.description}
                    </p>

                    {/* Cyan & Dark Muscle Character for Workout Plan or Focused Exercise */}
                    <div className="mb-3">
                      <MuscleMapCharacter
                        exercise={focusedExObj}
                        exercises={focusedExObj ? undefined : routineExercises}
                        size="sm"
                        title={
                          focusedExObj
                            ? `Exercise Focus: ${focusedExObj.name}`
                            : 'Workout Plan Target Muscles'
                        }
                        subtitle={
                          focusedExObj
                            ? `Muscles targeted by ${focusedExObj.name}`
                            : 'Tap any exercise below to see which muscle it targets'
                        }
                      />
                    </div>

                    {/* Interactive Exercises Selector */}
                    <div className="flex flex-wrap gap-1.5">
                      {routine.exercises.map((item, idx) => {
                        const ex = exercises.find((e) => e.id === item.exerciseId);
                        const isSelected = focusedExId === item.exerciseId;
                        return (
                          <button
                            type="button"
                            key={idx}
                            onClick={() =>
                              setRoutineFocusedExercise((prev) => ({
                                ...prev,
                                [routine.id]: isSelected ? null : item.exerciseId
                              }))
                            }
                            className={`text-[11px] rounded-lg px-2.5 py-1 border transition-colors text-left ${
                              isSelected
                                ? 'bg-cyan-500 text-neutral-950 font-bold border-cyan-400 shadow-sm'
                                : 'text-slate-300 bg-neutral-900 hover:border-cyan-500/40 border-neutral-800'
                            }`}
                          >
                            {ex?.name || item.exerciseId}
                          </button>
                        );
                      })}
                    </div>

                    {/* Inline Routine Breakdown (View without opening) */}
                    {expandedRoutineIds[routine.id] && (
                      <RoutineInlinePreview
                        routine={routine}
                        exercises={exercises}
                        focusedExerciseId={focusedExId}
                        onSelectExercise={(exId) =>
                          setRoutineFocusedExercise((prev) => ({
                            ...prev,
                            [routine.id]: prev[routine.id] === exId ? null : exId
                          }))
                        }
                      />
                    )}
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-3 border-t border-neutral-800/80 flex-wrap">
                    <div className="flex items-center gap-3 flex-wrap">
                      <button
                        type="button"
                        onClick={() => toggleInlineRoutine(routine.id)}
                        className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors"
                      >
                        {expandedRoutineIds[routine.id] ? (
                          <>
                            <ChevronUp className="w-3.5 h-3.5" />
                            <span>Hide Routine</span>
                          </>
                        ) : (
                          <>
                            <ChevronDown className="w-3.5 h-3.5" />
                            <span>Quick View</span>
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => handleOpenBuilder(routine)}
                        className="text-xs font-semibold text-slate-300 hover:text-cyan-400 flex items-center gap-1 transition-colors"
                        title="Edit Routine & Overload Sets / Reps"
                      >
                        <Edit className="w-3.5 h-3.5 text-cyan-400" />
                        <span>Edit / Overload</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => overloadRoutine(routine.id, 'reps')}
                        className="px-2 py-0.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-[10px] font-bold text-cyan-300 flex items-center gap-1 active:scale-95 transition-all"
                        title="Progressive Overload: Add +2 reps (+5s hold) to all exercises in this routine"
                      >
                        <TrendingUp className="w-3 h-3" />
                        <span>+2 Reps</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => overloadRoutine(routine.id, 'sets')}
                        className="px-2 py-0.5 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 text-[10px] font-bold text-purple-300 flex items-center gap-1 active:scale-95 transition-all"
                        title="Progressive Overload: Add +1 set to all exercises in this routine"
                      >
                        <Plus className="w-3 h-3" />
                        <span>+1 Set</span>
                      </button>

                      <button
                        onClick={() => duplicateCustomRoutine(routine.id)}
                        className="text-xs text-slate-400 hover:text-white flex items-center gap-1 transition-colors"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setPreviewRoutine(routine)}
                        className="px-3.5 py-2 bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 hover:border-cyan-500/50 text-slate-200 hover:text-cyan-300 font-semibold text-xs rounded-xl transition-all flex items-center gap-1.5 active:scale-95"
                        title="View full workout routine details without starting session"
                      >
                        <Eye className="w-3.5 h-3.5 text-cyan-400" />
                        <span>View</span>
                      </button>

                      <button
                        onClick={() => startWorkout(routine)}
                        className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-bold text-xs rounded-xl shadow-md shadow-cyan-500/20 active:scale-95 transition-all flex items-center gap-1.5"
                      >
                        <Play className="w-3.5 h-3.5 fill-neutral-950" />
                        <span>Start Session</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: MY CUSTOM ROUTINES */}
      {activeTab === 'custom' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Your Custom Programs
            </span>
            <button
              onClick={() => handleOpenBuilder()}
              className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create Routine</span>
            </button>
          </div>

          {myCustomRoutinesList.length === 0 ? (
            <div className="text-center py-12 px-4 rounded-3xl bg-neutral-900/50 border border-dashed border-neutral-800">
              <Dumbbell className="w-10 h-10 text-slate-600 mx-auto mb-2.5" />
              <h3 className="text-sm font-bold text-white mb-1">No custom routines yet</h3>
              <p className="text-xs text-slate-400 mb-4 max-w-xs mx-auto">
                Design your own calisthenics or backpack training split with tailored exercises, sets, and rest intervals.
              </p>
              <button
                onClick={() => handleOpenBuilder()}
                className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-bold text-xs rounded-xl shadow-md transition-all active:scale-95"
              >
                + Build Your First Routine
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {myCustomRoutinesList.map((routine) => {
                const routineExercises = routine.exercises
                  .map((item) => exercises.find((e) => e.id === item.exerciseId))
                  .filter((e): e is Exercise => Boolean(e));
                const focusedExId = routineFocusedExercise[routine.id] || null;
                const focusedExObj = focusedExId
                  ? exercises.find((e) => e.id === focusedExId) || null
                  : null;

                return (
                  <div
                    key={routine.id}
                    className="bg-[#12151c] border border-neutral-800 hover:border-cyan-500/40 rounded-2xl p-4 transition-all group shadow-sm flex flex-col justify-between space-y-3"
                  >
                    <div>
                      <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-cyan-400" />
                          <span className="font-mono text-slate-300 font-medium">
                            {routine.estimatedDurationMin} min
                          </span>
                          <span>·</span>
                          <span>{routine.exercises.length} Exercises</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => setPreviewRoutine(routine)}
                            className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-neutral-800 rounded-lg transition-colors"
                            title="View Routine"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleOpenBuilder(routine)}
                            className="p-1.5 text-slate-400 hover:text-white hover:bg-neutral-800 rounded-lg transition-colors"
                            title="Edit"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => duplicateCustomRoutine(routine.id)}
                            className="p-1.5 text-slate-400 hover:text-white hover:bg-neutral-800 rounded-lg transition-colors"
                            title="Duplicate"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => deleteCustomRoutine(routine.id)}
                            className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <h3 className="text-base font-bold text-white mb-1.5 group-hover:text-cyan-400 transition-colors">
                        {routine.name}
                      </h3>
                      <p className="text-xs text-slate-400 mb-3">{routine.description}</p>

                      {/* Cyan & Dark Muscle Character for Custom Workout Plan */}
                      <div className="mb-3">
                        <MuscleMapCharacter
                          exercise={focusedExObj}
                          exercises={focusedExObj ? undefined : routineExercises}
                          size="sm"
                          title={
                            focusedExObj
                              ? `Exercise Focus: ${focusedExObj.name}`
                              : 'Custom Plan Target Muscles'
                          }
                          subtitle="Tap any exercise below to inspect its targeted muscles"
                        />
                      </div>

                      <div className="flex flex-wrap gap-1.5">
                        {routine.exercises.map((item, idx) => {
                          const ex = exercises.find((e) => e.id === item.exerciseId);
                          const isSelected = focusedExId === item.exerciseId;
                          return (
                            <button
                              type="button"
                              key={idx}
                              onClick={() =>
                                setRoutineFocusedExercise((prev) => ({
                                  ...prev,
                                  [routine.id]: isSelected ? null : item.exerciseId
                                }))
                              }
                              className={`text-[11px] rounded-lg px-2.5 py-1 border transition-colors text-left ${
                                isSelected
                                  ? 'bg-cyan-500 text-neutral-950 font-bold border-cyan-400 shadow-sm'
                                  : 'text-slate-300 bg-neutral-900 hover:border-cyan-500/40 border-neutral-800'
                              }`}
                            >
                              {ex?.name || item.exerciseId} ({item.setsCount} sets)
                            </button>
                          );
                        })}
                      </div>

                      {/* Inline Routine Breakdown (View without opening) */}
                      {expandedRoutineIds[routine.id] && (
                        <RoutineInlinePreview
                          routine={routine}
                          exercises={exercises}
                          focusedExerciseId={focusedExId}
                          onSelectExercise={(exId) =>
                            setRoutineFocusedExercise((prev) => ({
                              ...prev,
                              [routine.id]: prev[routine.id] === exId ? null : exId
                            }))
                          }
                        />
                      )}
                    </div>

                    <div className="flex items-center justify-between gap-2 pt-3 border-t border-neutral-800/80 flex-wrap">
                      <div className="flex items-center gap-2.5 flex-wrap">
                        <button
                          type="button"
                          onClick={() => toggleInlineRoutine(routine.id)}
                          className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors"
                        >
                          {expandedRoutineIds[routine.id] ? (
                            <>
                              <ChevronUp className="w-3.5 h-3.5" />
                              <span>Hide Routine</span>
                            </>
                          ) : (
                            <>
                              <ChevronDown className="w-3.5 h-3.5" />
                              <span>Quick View</span>
                            </>
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() => handleOpenBuilder(routine)}
                          className="text-xs font-semibold text-slate-300 hover:text-cyan-400 flex items-center gap-1 transition-colors"
                        >
                          <Edit className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Edit / Overload</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => overloadRoutine(routine.id, 'reps')}
                          className="px-2 py-0.5 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-[10px] font-bold text-cyan-300 flex items-center gap-1 active:scale-95 transition-all"
                          title="Progressive Overload: +2 reps (+5s hold) across all exercises"
                        >
                          <TrendingUp className="w-3 h-3" />
                          <span>+2 Reps</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => overloadRoutine(routine.id, 'sets')}
                          className="px-2 py-0.5 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 text-[10px] font-bold text-purple-300 flex items-center gap-1 active:scale-95 transition-all"
                          title="Progressive Overload: +1 set across all exercises"
                        >
                          <Plus className="w-3 h-3" />
                          <span>+1 Set</span>
                        </button>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setPreviewRoutine(routine)}
                          className="px-3.5 py-2 bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 hover:border-cyan-500/50 text-slate-200 hover:text-cyan-300 font-semibold text-xs rounded-xl transition-all flex items-center gap-1.5 active:scale-95"
                          title="View full workout routine details without starting session"
                        >
                          <Eye className="w-3.5 h-3.5 text-cyan-400" />
                          <span>View</span>
                        </button>

                        <button
                          onClick={() => startWorkout(routine)}
                          className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-bold text-xs rounded-xl shadow-md shadow-cyan-500/20 active:scale-95 transition-all flex items-center gap-1.5"
                        >
                          <Play className="w-3.5 h-3.5 fill-neutral-950" />
                          <span>Start Workout</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: WORKOUT HISTORY */}
      {activeTab === 'history' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Previous Training Sessions
            </span>
            <span className="text-xs text-slate-400 font-mono">
              {workoutHistory.length} Sessions Logged
            </span>
          </div>

          {workoutHistory.length === 0 ? (
            <div className="text-center py-12 px-4 rounded-3xl bg-neutral-900/50 border border-dashed border-neutral-800">
              <History className="w-10 h-10 text-slate-600 mx-auto mb-2.5" />
              <h3 className="text-sm font-bold text-white mb-1">No workout history yet</h3>
              <p className="text-xs text-slate-400 mb-4">
                Completed workouts will automatically appear here with duration, sets, and PRs.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {workoutHistory.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedHistoryWorkout(item)}
                  className="bg-[#12151c] border border-neutral-800 hover:border-cyan-500/40 rounded-2xl p-4 transition-all group cursor-pointer active:scale-[0.99]"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <div className="flex items-center gap-2 text-[11px] text-slate-400 mb-1">
                        <Calendar className="w-3 h-3 text-cyan-400" />
                        <span>{formatDate(item.date)}</span>
                        <span>·</span>
                        <Clock className="w-3 h-3 text-slate-400" />
                        <span className="font-mono">{formatSeconds(item.durationSec)}</span>
                      </div>
                      <h3 className="text-base font-bold text-white group-hover:text-cyan-400 transition-colors">
                        {item.name}
                      </h3>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteWorkoutFromHistory(item.id);
                        }}
                        className="p-1.5 text-slate-500 hover:text-red-400 rounded-lg hover:bg-neutral-800"
                        title="Delete record"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                      <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-cyan-400 group-hover:translate-x-0.5 transition-all" />
                    </div>
                  </div>

                  <div className="flex items-center gap-3 text-xs text-slate-400 mb-2">
                    <span>
                      <strong className="text-white font-mono">{item.totalSets}</strong> sets
                    </span>
                    <span>·</span>
                    <span>
                      <strong className="text-white font-mono">{item.totalReps}</strong> reps
                    </span>
                    <span>·</span>
                    <span>
                      <strong className="text-white font-mono">{item.exercises.length}</strong>{' '}
                      exercises
                    </span>
                  </div>

                  {item.notes && (
                    <div className="mb-2 p-2.5 rounded-xl bg-neutral-900/80 border border-neutral-800/90 flex items-start gap-2 text-xs text-slate-300">
                      <FileText className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                      <p className="line-clamp-2 leading-relaxed">{item.notes}</p>
                    </div>
                  )}

                  {item.prDetails && item.prDetails.length > 0 ? (
                    <div className="flex flex-wrap items-center gap-1.5 pt-1">
                      {item.prDetails.map((pr, prIdx) => (
                        <PRBadgeChip
                          key={pr.id || prIdx}
                          type={
                            pr.unit === 'kg' || pr.unit === 'lbs'
                              ? 'weight'
                              : pr.unit === 'seconds'
                              ? 'hold'
                              : 'reps'
                          }
                          value={`${pr.exerciseName}: ${
                            pr.unit === 'kg' || pr.unit === 'lbs' ? `+${pr.value}` : pr.value
                          }`}
                          unit={pr.unit}
                          size="xs"
                          animated={false}
                        />
                      ))}
                    </div>
                  ) : (
                    item.prsEarned &&
                    item.prsEarned.length > 0 && (
                      <div className="flex items-center gap-1.5 text-[11px] text-cyan-400 font-semibold bg-cyan-950/30 border border-cyan-500/30 rounded-lg px-2.5 py-1 w-fit">
                        <Flame className="w-3 h-3 fill-cyan-400" />
                        <span>PR: {item.prsEarned.join(', ')}</span>
                      </div>
                    )
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Workout History Detail Modal */}
      {selectedHistoryWorkout && (
        <div className="fixed inset-0 z-60 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#12151c] border border-neutral-800 rounded-3xl p-6 max-w-md w-full max-h-[85vh] flex flex-col overflow-hidden animate-in fade-in duration-200">
            <div className="flex items-start justify-between pb-4 border-b border-neutral-800">
              <div>
                <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider">
                  Workout Summary
                </span>
                <h3 className="text-lg font-bold text-white">{selectedHistoryWorkout.name}</h3>
                <div className="text-xs text-slate-400 mt-0.5">
                  {formatDate(selectedHistoryWorkout.date)} ·{' '}
                  <span className="font-mono">{formatSeconds(selectedHistoryWorkout.durationSec)}</span>
                </div>
              </div>
              <button
                onClick={() => setSelectedHistoryWorkout(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-white bg-neutral-900"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Stat Bar */}
            <div className="grid grid-cols-3 gap-2 py-3 border-b border-neutral-800 text-center">
              <div>
                <div className="text-base font-extrabold text-white font-mono">
                  {selectedHistoryWorkout.totalSets}
                </div>
                <div className="text-[10px] text-slate-400">Total Sets</div>
              </div>
              <div>
                <div className="text-base font-extrabold text-white font-mono">
                  {selectedHistoryWorkout.totalReps}
                </div>
                <div className="text-[10px] text-slate-400">Total Reps</div>
              </div>
              <div>
                <div className="text-base font-extrabold text-white font-mono">
                  {selectedHistoryWorkout.exercises.length}
                </div>
                <div className="text-[10px] text-slate-400">Exercises</div>
              </div>
            </div>

            {/* Exercises breakdown */}
            <div className="flex-1 overflow-y-auto py-4 space-y-3">
              {selectedHistoryWorkout.prDetails && selectedHistoryWorkout.prDetails.length > 0 && (
                <PRSummaryShowcase
                  records={selectedHistoryWorkout.prDetails}
                  onCelebratePR={triggerPRNotification}
                />
              )}

              {selectedHistoryWorkout.notes && (
                <div className="p-3.5 rounded-2xl bg-neutral-900/70 border border-neutral-800 space-y-1.5">
                  <div className="flex items-center gap-1.5 text-[11px] font-bold text-cyan-400 uppercase tracking-wider">
                    <FileText className="w-3.5 h-3.5" />
                    <span>Workout Notes</span>
                  </div>
                  <p className="text-xs text-slate-300 whitespace-pre-wrap leading-relaxed">
                    {selectedHistoryWorkout.notes}
                  </p>
                </div>
              )}

              <MuscleMapCharacter
                exercises={selectedHistoryWorkout.exercises
                  .map((e) => exercises.find((ex) => ex.id === e.exerciseId))
                  .filter((e): e is Exercise => Boolean(e))}
                size="sm"
                title="Muscles Trained in Session"
              />
              {selectedHistoryWorkout.exercises.map((exItem, idx) => {
                const exDef = exercises.find((e) => e.id === exItem.exerciseId);
                const isHold = exDef?.isHold || false;
                const repOrHoldPR = selectedHistoryWorkout.prDetails?.find(
                  (p) =>
                    p.exerciseId === exItem.exerciseId &&
                    (p.unit === 'reps' || p.unit === 'seconds')
                );
                const weightPR = selectedHistoryWorkout.prDetails?.find(
                  (p) =>
                    p.exerciseId === `${exItem.exerciseId}-weight` ||
                    (p.exerciseId === exItem.exerciseId && (p.unit === 'kg' || p.unit === 'lbs'))
                );
                return (
                  <div
                    key={idx}
                    className={`p-3 rounded-xl border ${
                      repOrHoldPR || weightPR
                        ? 'bg-cyan-950/20 border-cyan-500/40'
                        : 'bg-neutral-900/60 border-neutral-800'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 mb-2 flex-wrap">
                      <div className="text-xs font-bold text-white">
                        {exDef?.name || exItem.exerciseId}
                      </div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {repOrHoldPR && (
                          <PRBadgeChip
                            type={isHold ? 'hold' : 'reps'}
                            value={repOrHoldPR.value}
                            unit={repOrHoldPR.unit}
                            size="xs"
                          />
                        )}
                        {weightPR && (
                          <PRBadgeChip
                            type="weight"
                            value={`+${weightPR.value}`}
                            unit={weightPR.unit}
                            size="xs"
                          />
                        )}
                      </div>
                    </div>
                    <div className="space-y-1">
                      {exItem.sets.map((s) => (
                        <div
                          key={s.id}
                          className="flex items-center justify-between text-xs text-slate-300 font-mono"
                        >
                          <span className="text-slate-500">Set {s.setNumber}</span>
                          <span>
                            {s.weightKg && s.weightKg > 0 ? `+${s.weightKg}kg ` : ''}
                            {s.durationSec ? `${s.durationSec}s hold` : `${s.reps} reps`}
                          </span>
                          <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                        </div>
                      ))}
                    </div>
                    {exItem.notes && (
                      <div className="mt-2 pt-2 border-t border-neutral-800 text-[11px] text-slate-400 italic">
                        "{exItem.notes}"
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="pt-3 border-t border-neutral-800 flex gap-2">
              <button
                onClick={() => {
                  const routineToRepeat: CustomRoutine = {
                    id: `repeat_${Date.now()}`,
                    name: selectedHistoryWorkout.name,
                    description: 'Repeated from workout history',
                    estimatedDurationMin: Math.round(selectedHistoryWorkout.durationSec / 60),
                    exercises: selectedHistoryWorkout.exercises.map((e) => ({
                      exerciseId: e.exerciseId,
                      setsCount: e.sets.length,
                      defaultReps: e.sets[0]?.reps,
                      defaultHoldSec: e.sets[0]?.durationSec,
                      restTimeSec: 60
                    }))
                  };
                  setSelectedHistoryWorkout(null);
                  startWorkout(routineToRepeat);
                }}
                className="flex-1 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-bold text-xs rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center gap-1.5"
              >
                <Play className="w-3.5 h-3.5 fill-neutral-950" />
                <span>Repeat Workout</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Workout Builder Modal */}
      {isBuilderOpen && (
        <div className="fixed inset-0 z-60 bg-black/85 backdrop-blur-md flex flex-col justify-end sm:justify-center p-0 sm:p-4">
          <div className="bg-[#12151c] border-t sm:border border-neutral-800 rounded-t-3xl sm:rounded-3xl w-full max-w-lg mx-auto max-h-[90vh] flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-200">
            {/* Header */}
            <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white">
                  {builderId ? 'Edit Routine' : 'Create Custom Routine'}
                </h3>
                <p className="text-xs text-slate-400">Configure sets, reps & rest periods</p>
              </div>
              <button
                onClick={() => setIsBuilderOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-white bg-neutral-900"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Builder Body */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Routine Name
                </label>
                <input
                  type="text"
                  placeholder="e.g., Pull Power & Lever Training"
                  value={builderName}
                  onChange={(e) => setBuilderName(e.target.value)}
                  className="w-full text-xs bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Description
                </label>
                <input
                  type="text"
                  placeholder="Focus areas, tempo notes, or target progression"
                  value={builderDescription}
                  onChange={(e) => setBuilderDescription(e.target.value)}
                  className="w-full text-xs bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              {/* Live Muscle Map Coverage for Custom Routine Builder */}
              <MuscleMapCharacter
                exercises={builderExercises
                  .map((item) => exercises.find((e) => e.id === item.exerciseId))
                  .filter((e): e is Exercise => Boolean(e))}
                size="sm"
                title="Workout Plan Muscle Coverage"
                subtitle="Updates automatically as you add or remove exercises"
              />

              {/* Progressive Overload Quick-Apply Bar */}
              <div className="p-3 rounded-2xl bg-cyan-950/20 border border-cyan-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-extrabold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                    <TrendingUp className="w-3.5 h-3.5" />
                    <span>Progressive Overload All Exercises</span>
                  </span>
                  <span className="text-[10px] text-slate-400">1-Tap Bulk Overload</span>
                </div>
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    type="button"
                    onClick={() =>
                      setBuilderExercises((prev) =>
                        prev.map((item) => {
                          const ex = exercises.find((e) => e.id === item.exerciseId);
                          if (ex?.isHold) {
                            return {
                              ...item,
                              defaultHoldSec: (item.defaultHoldSec || ex.defaultHoldSec || 30) + 5
                            };
                          }
                          return {
                            ...item,
                            defaultReps: (item.defaultReps || ex?.defaultReps || 10) + 2
                          };
                        })
                      )
                    }
                    className="py-1.5 px-2 rounded-xl bg-neutral-900 hover:bg-cyan-500/20 border border-cyan-500/40 text-[11px] font-bold text-cyan-300 active:scale-95 transition-all"
                  >
                    +2 Reps / +5s
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setBuilderExercises((prev) =>
                        prev.map((item) => ({
                          ...item,
                          setsCount: Math.min(12, item.setsCount + 1)
                        }))
                      )
                    }
                    className="py-1.5 px-2 rounded-xl bg-neutral-900 hover:bg-purple-500/20 border border-purple-500/40 text-[11px] font-bold text-purple-300 active:scale-95 transition-all"
                  >
                    +1 Set All
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setBuilderExercises((prev) =>
                        prev.map((item) => ({
                          ...item,
                          targetWeightKg:
                            Math.round(((item.targetWeightKg || 0) + 2.5) * 10) / 10
                        }))
                      )
                    }
                    className="py-1.5 px-2 rounded-xl bg-neutral-900 hover:bg-amber-500/20 border border-amber-500/40 text-[11px] font-bold text-amber-300 active:scale-95 transition-all"
                  >
                    +2.5 {user.units === 'imperial' ? 'lbs' : 'kg'} All
                  </button>
                </div>
              </div>

              {/* Exercises List with Full Sets, Reps/Hold, Weight & Rest Editors */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold text-slate-300">
                    Exercises & Overload Targets ({builderExercises.length})
                  </label>
                  <button
                    onClick={() => setIsAddingExercise(true)}
                    className="text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Exercise</span>
                  </button>
                </div>

                {builderExercises.map((item, idx) => {
                  const ex = exercises.find((e) => e.id === item.exerciseId);
                  const isHold = ex?.isHold || false;
                  const unitLabel = user.units === 'imperial' ? 'lbs' : 'kg';
                  const curRepsOrHold = isHold
                    ? item.defaultHoldSec ?? ex?.defaultHoldSec ?? 30
                    : item.defaultReps ?? ex?.defaultReps ?? 10;
                  const curWeight = item.targetWeightKg ?? 0;

                  return (
                    <div
                      key={idx}
                      className="p-3 bg-neutral-900/90 border border-neutral-800 rounded-2xl space-y-2.5"
                    >
                      {/* Top Row: Reorder, Exercise Title, Set Variation & Delete */}
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <div className="flex flex-col">
                            <button
                              onClick={() => handleMoveBuilderExercise(idx, 'up')}
                              disabled={idx === 0}
                              className="text-slate-500 hover:text-white disabled:opacity-20 p-0.5"
                            >
                              <ArrowUp className="w-3 h-3" />
                            </button>
                            <button
                              onClick={() => handleMoveBuilderExercise(idx, 'down')}
                              disabled={idx === builderExercises.length - 1}
                              className="text-slate-500 hover:text-white disabled:opacity-20 p-0.5"
                            >
                              <ArrowDown className="w-3 h-3" />
                            </button>
                          </div>
                          <div>
                            <div className="text-xs font-bold text-white">
                              {ex?.name || item.exerciseId}
                            </div>
                            <div className="text-[10px] text-cyan-400 font-mono">
                              {item.setsCount} sets × {curRepsOrHold}
                              {isHold ? 's hold' : ' reps'}
                              {curWeight > 0 ? ` @ +${curWeight}${unitLabel}` : ''} · {item.restTimeSec}s rest
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <select
                            value={item.defaultSetType || 'normal'}
                            onChange={(e) => {
                              const val = e.target.value as SetType;
                              setBuilderExercises((prev) =>
                                prev.map((b, i) => (i === idx ? { ...b, defaultSetType: val } : b))
                              );
                            }}
                            className="text-[10px] font-bold bg-neutral-950 border border-neutral-800 rounded-lg px-2 py-1 text-cyan-400 focus:outline-none focus:border-cyan-500"
                            title="Set Variation Type"
                          >
                            <option value="normal">Working</option>
                            <option value="dropset">Drop Set</option>
                            <option value="superset">Superset</option>
                            <option value="restpause">Rest-Pause</option>
                            <option value="amrap">AMRAP</option>
                            <option value="tempo">Tempo</option>
                            <option value="cluster">Cluster</option>
                            <option value="warmup">Warm-Up</option>
                          </select>
                          <button
                            onClick={() => handleRemoveBuilderExercise(idx)}
                            className="text-slate-500 hover:text-red-400 p-1"
                            title="Remove Exercise"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Bottom Row: Direct Overload Controls for Sets, Reps/Hold, Weight & Rest */}
                      <div className="grid grid-cols-4 gap-2 pt-2 border-t border-neutral-800/70">
                        {/* SETS */}
                        <div>
                          <label className="block text-[9px] font-bold uppercase text-slate-400 mb-1">
                            Sets
                          </label>
                          <div className="flex items-center bg-neutral-950 border border-neutral-800 rounded-lg overflow-hidden">
                            <button
                              type="button"
                              onClick={() =>
                                setBuilderExercises((prev) =>
                                  prev.map((b, i) =>
                                    i === idx
                                      ? { ...b, setsCount: Math.max(1, b.setsCount - 1) }
                                      : b
                                  )
                                )
                              }
                              className="px-1.5 py-1 text-slate-400 hover:text-white"
                            >
                              <Minus className="w-2.5 h-2.5" />
                            </button>
                            <input
                              type="number"
                              min="1"
                              max="15"
                              value={item.setsCount}
                              onChange={(e) => {
                                const val = Math.max(1, parseInt(e.target.value, 10) || 1);
                                setBuilderExercises((prev) =>
                                  prev.map((b, i) => (i === idx ? { ...b, setsCount: val } : b))
                                );
                              }}
                              className="w-full text-center text-xs font-mono font-bold bg-transparent text-white focus:outline-none"
                            />
                            <button
                              type="button"
                              onClick={() =>
                                setBuilderExercises((prev) =>
                                  prev.map((b, i) =>
                                    i === idx
                                      ? { ...b, setsCount: Math.min(15, b.setsCount + 1) }
                                      : b
                                  )
                                )
                              }
                              className="px-1.5 py-1 text-cyan-400 hover:text-cyan-300"
                            >
                              <Plus className="w-2.5 h-2.5" />
                            </button>
                          </div>
                        </div>

                        {/* REPS or HOLD SEC */}
                        <div>
                          <label className="block text-[9px] font-bold uppercase text-slate-400 mb-1">
                            {isHold ? 'Hold (s)' : 'Reps'}
                          </label>
                          <div className="flex items-center bg-neutral-950 border border-neutral-800 rounded-lg overflow-hidden">
                            <button
                              type="button"
                              onClick={() =>
                                setBuilderExercises((prev) =>
                                  prev.map((b, i) => {
                                    if (i !== idx) return b;
                                    return isHold
                                      ? { ...b, defaultHoldSec: Math.max(5, curRepsOrHold - 5) }
                                      : { ...b, defaultReps: Math.max(1, curRepsOrHold - 1) };
                                  })
                                )
                              }
                              className="px-1.5 py-1 text-slate-400 hover:text-white"
                            >
                              <Minus className="w-2.5 h-2.5" />
                            </button>
                            <input
                              type="number"
                              min="1"
                              value={curRepsOrHold}
                              onChange={(e) => {
                                const val = Math.max(1, parseInt(e.target.value, 10) || 1);
                                setBuilderExercises((prev) =>
                                  prev.map((b, i) => {
                                    if (i !== idx) return b;
                                    return isHold
                                      ? { ...b, defaultHoldSec: val }
                                      : { ...b, defaultReps: val };
                                  })
                                );
                              }}
                              className="w-full text-center text-xs font-mono font-bold bg-transparent text-cyan-300 focus:outline-none"
                            />
                            <button
                              type="button"
                              onClick={() =>
                                setBuilderExercises((prev) =>
                                  prev.map((b, i) => {
                                    if (i !== idx) return b;
                                    return isHold
                                      ? { ...b, defaultHoldSec: curRepsOrHold + 5 }
                                      : { ...b, defaultReps: curRepsOrHold + 1 };
                                  })
                                )
                              }
                              className="px-1.5 py-1 text-cyan-400 hover:text-cyan-300"
                            >
                              <Plus className="w-2.5 h-2.5" />
                            </button>
                          </div>
                        </div>

                        {/* WEIGHT (+KG / +LBS) */}
                        <div>
                          <label className="block text-[9px] font-bold uppercase text-slate-400 mb-1">
                            +{unitLabel} Load
                          </label>
                          <div className="flex items-center bg-neutral-950 border border-neutral-800 rounded-lg overflow-hidden">
                            <input
                              type="number"
                              min="0"
                              step="0.5"
                              value={curWeight}
                              onChange={(e) => {
                                const val = Math.max(0, parseFloat(e.target.value) || 0);
                                setBuilderExercises((prev) =>
                                  prev.map((b, i) =>
                                    i === idx ? { ...b, targetWeightKg: val } : b
                                  )
                                );
                              }}
                              className="w-full text-center text-xs font-mono font-bold bg-transparent py-1 text-amber-300 focus:outline-none"
                            />
                            <button
                              type="button"
                              onClick={() =>
                                setBuilderExercises((prev) =>
                                  prev.map((b, i) =>
                                    i === idx
                                      ? {
                                          ...b,
                                          targetWeightKg:
                                            Math.round(((b.targetWeightKg || 0) + 2.5) * 10) / 10
                                        }
                                      : b
                                  )
                                )
                              }
                              className="px-1.5 py-1 text-amber-400 hover:text-amber-300 text-[10px] font-bold"
                              title={`Add +2.5 ${unitLabel}`}
                            >
                              +
                            </button>
                          </div>
                        </div>

                        {/* REST SECONDS */}
                        <div>
                          <label className="block text-[9px] font-bold uppercase text-slate-400 mb-1">
                            Rest (s)
                          </label>
                          <select
                            value={item.restTimeSec}
                            onChange={(e) => {
                              const val = parseInt(e.target.value, 10) || 60;
                              setBuilderExercises((prev) =>
                                prev.map((b, i) => (i === idx ? { ...b, restTimeSec: val } : b))
                              );
                            }}
                            className="w-full text-center text-xs font-mono font-bold bg-neutral-950 border border-neutral-800 rounded-lg py-1 text-slate-200 focus:outline-none focus:border-cyan-500"
                          >
                            {[15, 30, 45, 60, 75, 90, 120, 180].map((sec) => (
                              <option key={sec} value={sec}>
                                {sec}s
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-neutral-800 flex items-center gap-3">
              <button
                onClick={() => setIsBuilderOpen(false)}
                className="flex-1 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-slate-300 font-semibold text-xs rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveRoutine}
                disabled={!builderName.trim() || builderExercises.length === 0}
                className="flex-1 py-2.5 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-neutral-950 font-bold text-xs rounded-xl shadow-md shadow-cyan-500/20 active:scale-95 transition-all"
              >
                Save Routine
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Select Exercise for Builder Sub-Modal */}
      {isAddingExercise && (
        <div className="fixed inset-0 z-70 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#12151c] border border-neutral-800 rounded-3xl p-5 max-w-sm w-full max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <h4 className="text-sm font-bold text-white">Add Exercise</h4>
              <button
                onClick={() => setIsAddingExercise(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="py-2">
              <input
                type="text"
                placeholder="Search..."
                value={exerciseSearch}
                onChange={(e) => setExerciseSearch(e.target.value)}
                className="w-full text-xs bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-white placeholder-slate-500"
              />
            </div>

            <div className="flex-1 overflow-y-auto space-y-1.5 py-2">
              {exercises
                .filter((e) => e.name.toLowerCase().includes(exerciseSearch.toLowerCase()))
                .map((ex) => (
                  <button
                    key={ex.id}
                    onClick={() => handleAddExerciseToBuilder(ex.id)}
                    className="w-full text-left p-2.5 rounded-xl hover:bg-neutral-800/80 text-xs font-semibold text-slate-200 hover:text-cyan-400 transition-colors flex items-center justify-between"
                  >
                    <span>{ex.name}</span>
                    <span className="text-[10px] text-slate-400 uppercase">{ex.category}</span>
                  </button>
                ))}
            </div>
          </div>
        </div>
      )}
      {/* Read-Only Routine Preview Modal */}
      <RoutinePreviewModal
        routine={previewRoutine}
        exercises={exercises}
        onClose={() => setPreviewRoutine(null)}
        onStartWorkout={startWorkout}
        onEditRoutine={(routine) => handleOpenBuilder(routine)}
      />
    </div>
  );
};
