import React, { useState } from 'react';
import {
  Upload,
  Download,
  FileType,
  Eye,
  RefreshCw,
  ArrowDownToLine
} from 'lucide-react';
import { convertDocxToImages, DocxRenderedPage } from '../../utils/docxProcessor';
import { triggerFileDownload } from '../../services/storageService';

interface WordToImageViewProps {
  onBack: () => void;
}

export const WordToImageView: React.FC<WordToImageViewProps> = ({ onBack }) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [scale, setScale] = useState<number>(2.0);
  const [format, setFormat] = useState<'image/png' | 'image/jpeg'>('image/png');
  const [quality, setQuality] = useState<number>(0.92);
  const [isConverting, setIsConverting] = useState(false);
  const [renderedPages, setRenderedPages] = useState<DocxRenderedPage[]>([]);
  const [previewPage, setPreviewPage] = useState<DocxRenderedPage | null>(null);

  const handleDocxUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    setSelectedFile(file);
    startConversion(file, scale, format, quality);
  };

  const startConversion = async (
    file: File,
    targetScale: number,
    targetFormat: 'image/png' | 'image/jpeg',
    targetQuality: number
  ) => {
    try {
      setIsConverting(true);
      const pages = await convertDocxToImages(file, {
        scale: targetScale,
        format: targetFormat,
        quality: targetQuality
      });
      setRenderedPages(pages);
    } catch (err) {
      console.error('Word to Image conversion error:', err);
    } finally {
      setIsConverting(false);
    }
  };

  const handleDownloadPage = (page: DocxRenderedPage) => {
    const ext = format === 'image/png' ? 'png' : 'jpg';
    const fileName = `${selectedFile?.name.replace(/\.[^/.]+$/, '')}_page_${page.pageNumber}.${ext}`;
    const a = document.createElement('a');
    a.href = page.dataUrl;
    a.download = fileName;
    a.click();
  };

  const handleDownloadAll = () => {
    renderedPages.forEach((page, idx) => {
      setTimeout(() => handleDownloadPage(page), idx * 300);
    });
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-neutral-50 dark:bg-neutral-900 pb-16">
      {/* Controls */}
      <div className="px-4 py-3 bg-white dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-xs active:scale-95 transition-all">
            <Upload className="w-3.5 h-3.5" />
            <span>{selectedFile ? 'Change DOCX' : 'Select Word DOCX File'}</span>
            <input
              type="file"
              accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
              className="hidden"
              onChange={handleDocxUpload}
            />
          </label>

          {selectedFile && (
            <span className="text-xs font-semibold text-neutral-700 dark:text-neutral-300 truncate max-w-[200px]">
              {selectedFile.name}
            </span>
          )}
        </div>

        <div className="grid grid-cols-3 gap-2 text-xs">
          <div>
            <label className="block text-[10px] font-semibold text-neutral-500 uppercase mb-1">
              Resolution
            </label>
            <select
              value={scale}
              onChange={(e) => {
                const s = parseFloat(e.target.value);
                setScale(s);
                if (selectedFile) startConversion(selectedFile, s, format, quality);
              }}
              className="w-full px-2 py-1.5 rounded-xl bg-neutral-100 dark:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 font-medium text-neutral-900 dark:text-neutral-100"
            >
              <option value={1.0}>1x Standard (72 DPI)</option>
              <option value={2.0}>2x High (150 DPI)</option>
              <option value={3.0}>3x Ultra (300 DPI)</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-semibold text-neutral-500 uppercase mb-1">
              Format
            </label>
            <select
              value={format}
              onChange={(e) => {
                const f = e.target.value as any;
                setFormat(f);
                if (selectedFile) startConversion(selectedFile, scale, f, quality);
              }}
              className="w-full px-2 py-1.5 rounded-xl bg-neutral-100 dark:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 font-medium text-neutral-900 dark:text-neutral-100"
            >
              <option value="image/png">PNG</option>
              <option value="image/jpeg">JPEG</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-semibold text-neutral-500 uppercase mb-1">
              Quality ({Math.round(quality * 100)}%)
            </label>
            <input
              type="range"
              min={0.5}
              max={1.0}
              step={0.05}
              value={quality}
              onChange={(e) => {
                const q = parseFloat(e.target.value);
                setQuality(q);
                if (selectedFile && format === 'image/jpeg') {
                  startConversion(selectedFile, scale, format, q);
                }
              }}
              className="w-full accent-amber-600 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {isConverting && (
        <div className="px-4 py-2 bg-amber-50 dark:bg-amber-950/60 border-b border-amber-200 dark:border-amber-800 flex items-center justify-between text-xs font-semibold text-amber-800 dark:text-amber-300">
          <span className="flex items-center gap-1.5">
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            <span>Rendering Word document pages into image graphics...</span>
          </span>
        </div>
      )}

      {/* Gallery */}
      <div className="flex-1 p-3 overflow-y-auto">
        {!selectedFile ? (
          <div className="text-center py-20 px-6 rounded-3xl border-2 border-dashed border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800/40 space-y-3">
            <div className="w-16 h-16 mx-auto rounded-3xl bg-amber-50 dark:bg-amber-950/40 text-amber-600 flex items-center justify-center">
              <FileType className="w-8 h-8" />
            </div>
            <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
              Select a Word DOCX Document
            </h3>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 max-w-xs mx-auto">
              Preserve layout, tables, headings, and typography into crisp PNG or JPEG images.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-neutral-800 dark:text-neutral-200">
                {renderedPages.length} {renderedPages.length === 1 ? 'Page Rendered' : 'Pages Rendered'}
              </span>

              {renderedPages.length > 0 && (
                <button
                  type="button"
                  onClick={handleDownloadAll}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-xs active:scale-95 transition-all"
                >
                  <ArrowDownToLine className="w-3.5 h-3.5" />
                  <span>Download All Pages</span>
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {renderedPages.map((page) => (
                <div
                  key={page.pageNumber}
                  className="rounded-2xl overflow-hidden bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 shadow-xs flex flex-col"
                >
                  <div className="aspect-[3/4] bg-neutral-100 dark:bg-neutral-900 flex items-center justify-center overflow-hidden relative">
                    <img
                      src={page.dataUrl}
                      alt={`Page ${page.pageNumber}`}
                      className="w-full h-full object-contain p-1"
                    />
                    <div className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-black/70 text-[10px] text-white font-bold">
                      Page {page.pageNumber}
                    </div>
                  </div>
                  <div className="p-2 bg-neutral-50 dark:bg-neutral-800/80 border-t border-neutral-200 dark:border-neutral-700 flex items-center justify-between">
                    <span className="text-[10px] text-neutral-500">
                      {Math.round(page.width)}x{Math.round(page.height)}
                    </span>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => setPreviewPage(page)}
                        className="p-1 rounded-lg text-neutral-600 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-neutral-700"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDownloadPage(page)}
                        className="p-1 rounded-lg text-amber-600 dark:text-amber-400 hover:bg-neutral-200 dark:hover:bg-neutral-700"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {previewPage && (
        <div className="fixed inset-0 z-50 bg-black/90 flex flex-col items-center justify-center p-4">
          <div className="w-full max-w-lg flex justify-between items-center text-white pb-2 text-xs font-bold">
            <span>Page {previewPage.pageNumber} Preview</span>
            <button
              type="button"
              onClick={() => setPreviewPage(null)}
              className="px-3 py-1 bg-white/20 rounded-full"
            >
              Close
            </button>
          </div>
          <div className="max-w-lg max-h-[80vh] overflow-auto bg-white rounded-xl p-2">
            <img src={previewPage.dataUrl} alt="Preview" className="w-full h-auto" />
          </div>
        </div>
      )}

      <div className="sticky bottom-0 px-4 py-3 bg-white/95 dark:bg-neutral-800/95 backdrop-blur-md border-t border-neutral-200 dark:border-neutral-700 flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          className="px-4 py-2 rounded-xl text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-xs font-semibold"
        >
          Back
        </button>
      </div>
    </div>
  );
};
