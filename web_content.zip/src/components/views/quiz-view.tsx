import { useState } from "react";
import { Button, fieldClass, useCopy } from "@/components/bits";
import { subjectName } from "@/lib/model";
import { useStudy } from "@/lib/store";

type Phase = "pick" | "play" | "result";

export function QuizView() {
  const { lang, t } = useCopy();
  const subjects = useStudy((s) => s.subjects);
  const questions = useStudy((s) => s.questions);
  const attempts = useStudy((s) => s.attempts);
  const addQuestion = useStudy((s) => s.addQuestion);
  const removeQuestion = useStudy((s) => s.removeQuestion);
  const recordAttempt = useStudy((s) => s.recordAttempt);

  const [phase, setPhase] = useState<Phase>("pick");
  const [subjectId, setSubjectId] = useState<string | null>(null);
  const [order, setOrder] = useState<string[]>([]);
  const [index, setIndex] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [checked, setChecked] = useState(false);
  const [score, setScore] = useState(0);
  const [adding, setAdding] = useState(false);

  const bank = questions.filter((q) => q.subjectId === subjectId);
  const current = questions.find((q) => q.id === order[index]);
  const custom = questions.filter((q) => q.custom && q.subjectId === subjectId);

  function start(id: string) {
    const ids = questions.filter((q) => q.subjectId === id).map((q) => q.id);
    if (ids.length === 0) {
      setSubjectId(id);
      return;
    }
    const next = [...ids];
    for (let i = next.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      const swap = next[i] ?? "";
      next[i] = next[j] ?? "";
      next[j] = swap;
    }
    setSubjectId(id);
    setOrder(next);
    setIndex(0);
    setPicked(null);
    setChecked(false);
    setScore(0);
    setPhase("play");
  }

  function resetPick() {
    setPhase("pick");
    setOrder([]);
    setIndex(0);
    setPicked(null);
    setChecked(false);
  }

  if (phase === "result") {
    const total = order.length || 1;
    const pct = Math.round((score / total) * 100);
    const message = pct >= 80 ? t("great") : pct >= 50 ? t("good") : t("againSoon");
    const sub = subjects.find((item) => item.id === subjectId);
    return (
      <div className="mx-auto flex max-w-md flex-col items-center gap-4 py-6 text-center">
        <p className="text-sm text-muted">{sub ? subjectName(sub, lang) : t("resultTitle")}</p>
        <h1 className="text-3xl font-semibold">{message}</h1>
        <p className="text-6xl font-semibold tabular-nums">
          {score}
          <span className="text-2xl text-muted">/{order.length}</span>
        </p>
        <p className="text-sm text-muted tabular-nums">{pct}%</p>
        <div className="flex gap-2">
          <Button
            onClick={() => {
              if (subjectId) start(subjectId);
            }}
          >
            {t("retry")}
          </Button>
          <Button variant="surface" onClick={resetPick}>
            {t("back")}
          </Button>
        </div>
      </div>
    );
  }

  if (phase === "play" && current) {
    const last = index === order.length - 1;
    return (
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between text-sm text-muted">
          <span>
            {t("question")} {index + 1}/{order.length}
          </span>
          <button type="button" className="min-h-11 text-fg" onClick={resetPick}>
            {t("back")}
          </button>
        </div>
        <div className="h-1.5 overflow-hidden rounded-full bg-surface-2">
          <div
            className="h-full bg-primary"
            style={{ width: `${((index + (checked ? 1 : 0)) / order.length) * 100}%` }}
          />
        </div>
        <h1 className="text-2xl font-semibold leading-snug">{current.prompt}</h1>
        <div className="flex flex-col gap-2">
          {current.options.map((option, optionIndex) => {
            const isAnswer = optionIndex === current.answer;
            const isPicked = optionIndex === picked;
            let tone = "border-border bg-surface";
            if (checked && isAnswer) tone = "border-primary bg-primary text-primary-fg";
            else if (checked && isPicked) tone = "border-accent bg-surface text-accent";
            else if (isPicked) tone = "border-primary bg-surface-2";
            return (
              <button
                key={`${current.id}-${optionIndex}`}
                type="button"
                disabled={checked}
                className={`min-h-12 rounded-md border px-3 py-3 text-left text-base disabled:cursor-default ${tone}`}
                onClick={() => setPicked(optionIndex)}
              >
                {option}
              </button>
            );
          })}
        </div>
        {checked ? (
          <p className={`text-sm font-semibold ${picked === current.answer ? "text-primary" : "text-accent"}`}>
            {picked === current.answer ? t("correct") : t("wrong")}
          </p>
        ) : null}
        {!checked ? (
          <Button
            disabled={picked === null}
            onClick={() => {
              setChecked(true);
              if (picked === current.answer) setScore((value) => value + 1);
            }}
          >
            {t("check")}
          </Button>
        ) : (
          <Button
            onClick={() => {
              if (last) {
                if (subjectId) recordAttempt(subjectId, score, order.length);
                setPhase("result");
                return;
              }
              setIndex((value) => value + 1);
              setPicked(null);
              setChecked(false);
            }}
          >
            {last ? t("seeResult") : t("next")}
          </Button>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-3xl font-semibold">{t("quiz")}</h1>
        <Button variant="surface" onClick={() => setAdding((value) => !value)}>
          {adding ? t("close") : t("addQuestion")}
        </Button>
      </div>
      <ul className="flex flex-col gap-3">
        {subjects.map((sub) => {
          const count = questions.filter((q) => q.subjectId === sub.id).length;
          const last = [...attempts].reverse().find((a) => a.subjectId === sub.id);
          return (
            <li key={sub.id}>
              <button
                type="button"
                className="flex w-full items-center justify-between gap-3 rounded-lg border border-border bg-surface px-4 py-3 text-left"
                onClick={() => start(sub.id)}
              >
                <span>
                  <span className="block font-semibold">{subjectName(sub, lang)}</span>
                  <span className="text-sm text-muted">
                    {count} {t("questionsN")}
                    {last ? ` · ${t("lastScore")} ${last.score}/${last.total}` : ""}
                  </span>
                </span>
                <span className="text-sm font-semibold text-primary">{count ? t("startQuiz") : t("addQuestion")}</span>
              </button>
            </li>
          );
        })}
      </ul>
      {subjectId && bank.length === 0 ? <p className="text-sm text-muted">{t("noQuestions")}</p> : null}
      {adding ? (
        <AddQuestion
          subjectId={subjectId ?? subjects[0]?.id ?? ""}
          subjects={subjects.map((sub) => ({ id: sub.id, name: subjectName(sub, lang) }))}
          onSave={(draft) => {
            addQuestion(draft);
            setSubjectId(draft.subjectId);
          }}
        />
      ) : null}
      {custom.length > 0 ? (
        <ul className="flex flex-col gap-2">
          {custom.map((q) => (
            <li key={q.id} className="flex items-center justify-between gap-3 rounded-md border border-border px-3 py-2">
              <span className="truncate text-sm">{q.prompt}</span>
              <button type="button" className="min-h-11 shrink-0 text-sm text-accent" onClick={() => removeQuestion(q.id)}>
                {t("delete")}
              </button>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

function AddQuestion({
  subjectId,
  subjects,
  onSave,
}: {
  subjectId: string;
  subjects: { id: string; name: string }[];
  onSave: (q: { subjectId: string; prompt: string; options: string[]; answer: number }) => void;
}) {
  const { t } = useCopy();
  const [sid, setSid] = useState(subjectId);
  const [prompt, setPrompt] = useState("");
  const [options, setOptions] = useState(["", "", "", ""]);
  const [answer, setAnswer] = useState(0);
  const ready = prompt.trim().length > 0 && options.every((option) => option.trim().length > 0);

  return (
    <form
      className="flex flex-col gap-3 rounded-lg border border-border bg-surface p-4"
      onSubmit={(event) => {
        event.preventDefault();
        if (!ready || !sid) return;
        onSave({ subjectId: sid, prompt, options, answer });
        setPrompt("");
        setOptions(["", "", "", ""]);
        setAnswer(0);
      }}
    >
      <label className="flex flex-col gap-1 text-sm text-muted">
        {t("subjects")}
        <select className={fieldClass} value={sid} onChange={(e) => setSid(e.target.value)}>
          {subjects.map((sub) => (
            <option key={sub.id} value={sub.id}>
              {sub.name}
            </option>
          ))}
        </select>
      </label>
      <label className="flex flex-col gap-1 text-sm text-muted">
        {t("prompt")}
        <textarea className={`${fieldClass} min-h-20`} value={prompt} onChange={(e) => setPrompt(e.target.value)} />
      </label>
      <fieldset className="flex flex-col gap-2">
        <legend className="mb-1 text-sm text-muted">{t("markCorrect")}</legend>
        {options.map((option, optionIndex) => (
          <label key={optionIndex} className="flex items-center gap-2">
            <input
              type="radio"
              className="size-5 accent-primary"
              name="correct-option"
              checked={answer === optionIndex}
              onChange={() => setAnswer(optionIndex)}
            />
            <input
              className={fieldClass}
              placeholder={`${t("option")} ${optionIndex + 1}`}
              value={option}
              onChange={(e) =>
                setOptions((current) => current.map((item, i) => (i === optionIndex ? e.target.value : item)))
              }
            />
          </label>
        ))}
      </fieldset>
      <Button type="submit" disabled={!ready}>
        {t("save")}
      </Button>
    </form>
  );
}
