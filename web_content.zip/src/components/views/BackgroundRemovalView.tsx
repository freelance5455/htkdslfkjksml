import React, { useState, useRef, useEffect } from 'react';
import {
  Upload,
  Camera,
  Scissors,
  Palette,
  Undo2,
  Redo2,
  Download,
  Brush,
  Eraser,
  Sliders,
  RefreshCw,
  Check,
  Eye,
  Sparkles
} from 'lucide-react';
import {
  COMMON_COLOR_PRESETS,
  segmentBackgroundOnCanvas,
  renderCanvasWithBackgroundColor,
  imageToCanvas,
  hexToRgb
} from '../../utils/imageProcessor';
import { triggerFileDownload, saveStoredDocument } from '../../services/storageService';

interface BackgroundRemovalViewProps {
  onBack: () => void;
}

export const BackgroundRemovalView: React.FC<BackgroundRemovalViewProps> = ({ onBack }) => {
  const [sourceImage, setSourceImage] = useState<string | null>(null);
  const [tolerance, setTolerance] = useState<number>(35);
  const [feather, setFeather] = useState<number>(3);
  const [brushMode, setBrushMode] = useState<'none' | 'erase' | 'restore'>('none');
  const [brushSize, setBrushSize] = useState<number>(20);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedBgColor, setSelectedBgColor] = useState<string>('transparent');
  const [customHex, setCustomHex] = useState<string>('#FFFFFF');
  const [undoStack, setUndoStack] = useState<ImageData[]>([]);
  const [redoStack, setRedoStack] = useState<ImageData[]>([]);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const sourceCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const isDrawingRef = useRef(false);

  // Load sample or uploaded image
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = async (ev) => {
      if (ev.target?.result) {
        const dataUrl = ev.target.result as string;
        setSourceImage(dataUrl);
        await initCanvasWithImage(dataUrl);
      }
    };
    reader.readAsDataURL(file);
  };

  const initCanvasWithImage = async (url: string) => {
    try {
      setIsProcessing(true);
      const srcCanvas = await imageToCanvas(url);
      sourceCanvasRef.current = srcCanvas;

      // Run automatic segmentation
      const segmented = segmentBackgroundOnCanvas(srcCanvas, {
        tolerance,
        feather,
        edgeContrast: 1.2
      });

      const displayCanvas = canvasRef.current;
      if (displayCanvas) {
        displayCanvas.width = segmented.width;
        displayCanvas.height = segmented.height;
        const ctx = displayCanvas.getContext('2d')!;
        ctx.clearRect(0, 0, displayCanvas.width, displayCanvas.height);
        ctx.drawImage(segmented, 0, 0);

        // Save to undo stack
        const initialSnapshot = ctx.getImageData(0, 0, displayCanvas.width, displayCanvas.height);
        setUndoStack([initialSnapshot]);
        setRedoStack([]);
      }
    } catch (e) {
      console.error('Initialization error:', e);
    } finally {
      setIsProcessing(false);
    }
  };

  // Re-run segmentation when tolerance/feather slider changes
  const applySegmentationWithSettings = (newTol: number, newFeather: number) => {
    if (!sourceCanvasRef.current || !canvasRef.current) return;
    setIsProcessing(true);
    setTimeout(() => {
      const segmented = segmentBackgroundOnCanvas(sourceCanvasRef.current!, {
        tolerance: newTol,
        feather: newFeather,
        edgeContrast: 1.2
      });
      const ctx = canvasRef.current!.getContext('2d')!;
      ctx.clearRect(0, 0, canvasRef.current!.width, canvasRef.current!.height);
      ctx.drawImage(segmented, 0, 0);

      const snapshot = ctx.getImageData(0, 0, canvasRef.current!.width, canvasRef.current!.height);
      setUndoStack((prev) => [...prev.slice(-10), snapshot]);
      setRedoStack([]);
      setIsProcessing(false);
    }, 50);
  };

  // Touch-up Brush interaction
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (brushMode === 'none' || !canvasRef.current) return;
    isDrawingRef.current = true;
    paintAtEvent(e);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawingRef.current || brushMode === 'none') return;
    paintAtEvent(e);
  };

  const handlePointerUp = () => {
    if (isDrawingRef.current && canvasRef.current) {
      isDrawingRef.current = false;
      const ctx = canvasRef.current.getContext('2d')!;
      const snapshot = ctx.getImageData(0, 0, canvasRef.current.width, canvasRef.current.height);
      setUndoStack((prev) => [...prev.slice(-10), snapshot]);
      setRedoStack([]);
    }
  };

  const paintAtEvent = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;

    const ctx = canvas.getContext('2d')!;
    ctx.save();
    ctx.beginPath();
    ctx.arc(x, y, brushSize * scaleX, 0, Math.PI * 2);

    if (brushMode === 'erase') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.fillStyle = 'rgba(0, 0, 0, 1)';
      ctx.fill();
    } else if (brushMode === 'restore' && sourceCanvasRef.current) {
      // Restore from original source canvas
      ctx.clip();
      ctx.drawImage(sourceCanvasRef.current, 0, 0);
    }
    ctx.restore();
  };

  // Undo / Redo
  const handleUndo = () => {
    if (undoStack.length <= 1 || !canvasRef.current) return;
    const current = undoStack[undoStack.length - 1];
    const previous = undoStack[undoStack.length - 2];
    const nextUndo = undoStack.slice(0, undoStack.length - 1);

    setRedoStack((prev) => [current, ...prev]);
    setUndoStack(nextUndo);

    const ctx = canvasRef.current.getContext('2d')!;
    ctx.putImageData(previous, 0, 0);
  };

  const handleRedo = () => {
    if (redoStack.length === 0 || !canvasRef.current) return;
    const nextSnapshot = redoStack[0];
    setRedoStack((prev) => prev.slice(1));
    setUndoStack((prev) => [...prev, nextSnapshot]);

    const ctx = canvasRef.current.getContext('2d')!;
    ctx.putImageData(nextSnapshot, 0, 0);
  };

  // Export finished image
  const handleExportImage = () => {
    if (!canvasRef.current) return;
    const finalCanvas = renderCanvasWithBackgroundColor(canvasRef.current, selectedBgColor);
    const isPng = selectedBgColor === 'transparent';
    const mime = isPng ? 'image/png' : 'image/jpeg';
    const ext = isPng ? 'png' : 'jpg';

    finalCanvas.toBlob((blob) => {
      if (!blob) return;
      const fileName = `DocuForge_Processed_${Date.now()}.${ext}`;
      triggerFileDownload(blob, fileName);

      saveStoredDocument({
        id: 'img-bg-' + Date.now(),
        name: fileName,
        type: isPng ? 'png' : 'jpg',
        sizeBytes: blob.size,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        blobData: blob,
        pageCount: 1,
        sourceFeature: selectedBgColor === 'transparent' ? 'Background Removal' : 'Background Color Replacement'
      });
    }, mime, 0.95);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-neutral-50 dark:bg-neutral-900 pb-16">
      {/* Top Controls Toolbar */}
      <div className="px-4 py-2.5 bg-white dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-pink-600 hover:bg-pink-700 text-white font-bold text-xs shadow-xs active:scale-95 transition-all">
            <Upload className="w-3.5 h-3.5" />
            <span>{sourceImage ? 'Change Image' : 'Select Image'}</span>
            <input type="file" accept="image/*" className="hidden" onChange={handleFileUpload} />
          </label>

          {/* Undo / Redo buttons */}
          <div className="flex items-center gap-1 bg-neutral-100 dark:bg-neutral-700 p-0.5 rounded-xl">
            <button
              type="button"
              disabled={undoStack.length <= 1}
              onClick={handleUndo}
              title="Undo"
              className="p-1.5 rounded-lg text-neutral-600 dark:text-neutral-300 hover:bg-white dark:hover:bg-neutral-800 disabled:opacity-30"
            >
              <Undo2 className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              disabled={redoStack.length === 0}
              onClick={handleRedo}
              title="Redo"
              className="p-1.5 rounded-lg text-neutral-600 dark:text-neutral-300 hover:bg-white dark:hover:bg-neutral-800 disabled:opacity-30"
            >
              <Redo2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Refinement Sliders */}
        {sourceImage && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs pt-1">
            <div>
              <div className="flex justify-between text-[10px] text-neutral-500 font-semibold mb-1">
                <span>Edge Tolerance</span>
                <span>{tolerance}</span>
              </div>
              <input
                type="range"
                min={10}
                max={70}
                value={tolerance}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10);
                  setTolerance(val);
                  applySegmentationWithSettings(val, feather);
                }}
                className="w-full accent-pink-600 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-[10px] text-neutral-500 font-semibold mb-1">
                <span>Edge Feathering</span>
                <span>{feather}px</span>
              </div>
              <input
                type="range"
                min={0}
                max={8}
                value={feather}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10);
                  setFeather(val);
                  applySegmentationWithSettings(tolerance, val);
                }}
                className="w-full accent-pink-600 cursor-pointer"
              />
            </div>

            {/* Brush Touch-up Selector */}
            <div>
              <span className="block text-[10px] text-neutral-500 font-semibold mb-1">
                Touch-Up Brush
              </span>
              <div className="flex items-center gap-1 bg-neutral-100 dark:bg-neutral-700 p-0.5 rounded-xl">
                <button
                  type="button"
                  onClick={() => setBrushMode(brushMode === 'erase' ? 'none' : 'erase')}
                  className={`px-2 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 ${
                    brushMode === 'erase'
                      ? 'bg-rose-500 text-white'
                      : 'text-neutral-600 dark:text-neutral-300'
                  }`}
                >
                  <Eraser className="w-3 h-3" />
                  <span>Erase</span>
                </button>
                <button
                  type="button"
                  onClick={() => setBrushMode(brushMode === 'restore' ? 'none' : 'restore')}
                  className={`px-2 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 ${
                    brushMode === 'restore'
                      ? 'bg-emerald-500 text-white'
                      : 'text-neutral-600 dark:text-neutral-300'
                  }`}
                >
                  <Brush className="w-3 h-3" />
                  <span>Restore</span>
                </button>
              </div>
            </div>

            {brushMode !== 'none' && (
              <div>
                <div className="flex justify-between text-[10px] text-neutral-500 font-semibold mb-1">
                  <span>Brush Radius</span>
                  <span>{brushSize}px</span>
                </div>
                <input
                  type="range"
                  min={5}
                  max={60}
                  value={brushSize}
                  onChange={(e) => setBrushSize(parseInt(e.target.value, 10))}
                  className="w-full accent-pink-600 cursor-pointer"
                />
              </div>
            )}
          </div>
        )}
      </div>

      {/* Background Color Replacement Ribbon */}
      {sourceImage && (
        <div className="px-4 py-2 bg-neutral-100/90 dark:bg-neutral-800/80 border-b border-neutral-200 dark:border-neutral-700 flex items-center gap-2 overflow-x-auto text-xs">
          <Palette className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
          <span className="text-[11px] font-bold text-neutral-600 dark:text-neutral-300 shrink-0">
            Background:
          </span>

          <div className="flex items-center gap-1.5 shrink-0">
            {COMMON_COLOR_PRESETS.map((preset) => {
              const isSelected = selectedBgColor === preset.hex;
              return (
                <button
                  key={preset.name}
                  type="button"
                  onClick={() => setSelectedBgColor(preset.hex)}
                  title={preset.name}
                  className={`w-6 h-6 rounded-full border-2 transition-all flex items-center justify-center shrink-0 ${
                    preset.hex === 'transparent' ? 'checkerboard-bg' : ''
                  } ${
                    isSelected
                      ? 'border-blue-600 scale-110 ring-2 ring-blue-500/30'
                      : 'border-neutral-300 dark:border-neutral-600'
                  }`}
                  style={{
                    backgroundColor: preset.hex !== 'transparent' ? preset.hex : undefined
                  }}
                >
                  {isSelected && (
                    <Check
                      className="w-3 h-3"
                      style={{ color: preset.hex === '#FFFFFF' ? '#000000' : '#FFFFFF' }}
                    />
                  )}
                </button>
              );
            })}
          </div>

          {/* Custom Hex & Color Picker */}
          <div className="flex items-center gap-1 ml-2 shrink-0">
            <input
              type="color"
              value={customHex}
              onChange={(e) => {
                setCustomHex(e.target.value);
                setSelectedBgColor(e.target.value);
              }}
              className="w-6 h-6 rounded-lg cursor-pointer border-0 bg-transparent p-0"
              title="Custom Color Picker"
            />
            <input
              type="text"
              value={selectedBgColor === 'transparent' ? 'Transparent' : selectedBgColor}
              onChange={(e) => {
                if (e.target.value.startsWith('#')) {
                  setSelectedBgColor(e.target.value);
                }
              }}
              className="w-20 px-1.5 py-0.5 rounded bg-white dark:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 text-[10px] font-mono text-center"
            />
          </div>
        </div>
      )}

      {/* Main Interactive Canvas Area */}
      <div className="flex-1 p-3 overflow-auto flex items-center justify-center">
        {!sourceImage ? (
          <div className="text-center py-20 px-6 rounded-3xl border-2 border-dashed border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800/40 space-y-3">
            <div className="w-16 h-16 mx-auto rounded-3xl bg-pink-50 dark:bg-pink-950/40 text-pink-600 flex items-center justify-center">
              <Scissors className="w-8 h-8" />
            </div>
            <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
              Select or Capture an Image
            </h3>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 max-w-xs mx-auto">
              Automatic edge segmentation removes backgrounds cleanly with transparent checkerboard preview and color replacement.
            </p>
          </div>
        ) : (
          <div
            className={`relative max-w-full max-h-full rounded-2xl overflow-hidden shadow-xl border border-neutral-200 dark:border-neutral-700 ${
              selectedBgColor === 'transparent' ? 'checkerboard-bg' : ''
            }`}
            style={{
              backgroundColor: selectedBgColor !== 'transparent' ? selectedBgColor : undefined
            }}
          >
            <canvas
              ref={canvasRef}
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              className={`max-w-full max-h-[65vh] object-contain block ${
                brushMode !== 'none' ? 'cursor-crosshair' : 'cursor-default'
              }`}
            />

            {brushMode !== 'none' && (
              <div className="absolute top-2 left-2 px-2.5 py-1 rounded-full bg-black/75 backdrop-blur-md text-[10px] text-white font-bold flex items-center gap-1.5">
                <Brush className="w-3 h-3 text-pink-400" />
                <span>
                  Painting: {brushMode === 'erase' ? 'Erasing Background' : 'Restoring Subject'}
                </span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Bottom Export Bar */}
      <div className="sticky bottom-0 px-4 py-3 bg-white/95 dark:bg-neutral-800/95 backdrop-blur-md border-t border-neutral-200 dark:border-neutral-700 flex items-center justify-between gap-2 shadow-lg">
        <button
          type="button"
          onClick={onBack}
          className="px-4 py-2 rounded-xl text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-xs font-semibold"
        >
          Back
        </button>

        <button
          type="button"
          disabled={!sourceImage || isProcessing}
          onClick={handleExportImage}
          className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-pink-600 hover:bg-pink-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all disabled:opacity-40"
        >
          <Download className="w-4 h-4" />
          <span>
            {selectedBgColor === 'transparent'
              ? 'Export Transparent PNG'
              : 'Export Processed Image'}
          </span>
        </button>
      </div>
    </div>
  );
};
