import { useState } from "react";
import { Flame } from "lucide-react";
import { Button, Meter, Monogram, useCopy } from "@/components/bits";
import { WeekChart } from "@/components/week-chart";
import { greetingKey } from "@/lib/i18n";
import {
  formatSpan,
  streakCount,
  subjectName,
  taskProgress,
  todayMinutes,
  weekSeries,
} from "@/lib/model";
import { useStudy } from "@/lib/store";

export function HomeView() {
  const { lang, t } = useCopy();
  const name = useStudy((s) => s.name);
  const setName = useStudy((s) => s.setName);
  const subjects = useStudy((s) => s.subjects);
  const tasks = useStudy((s) => s.tasks);
  const sessions = useStudy((s) => s.sessions);
  const timer = useStudy((s) => s.timer);
  const goal = useStudy((s) => s.dailyGoalMin);
  const nudgeGoal = useStudy((s) => s.nudgeGoal);
  const beginFocus = useStudy((s) => s.beginFocus);
  const toggleTask = useStudy((s) => s.toggleTask);
  const setView = useStudy((s) => s.setView);
  const [editing, setEditing] = useState(false);

  const today = todayMinutes(sessions);
  const streak = streakCount(sessions);
  const week = weekSeries(sessions, lang);
  const weekSum = week.reduce((sum, row) => sum + row.minutes, 0);
  const pct = Math.min(100, Math.round((today / goal) * 100));
  const open = tasks.filter((task) => !task.done).slice(0, 5);
  const hour = new Date().getHours();
  const hello = t(greetingKey(hour));
  const subject = subjects.find((item) => item.id === (timer.subjectId ?? subjects[0]?.id));
  const cta =
    timer.status === "running"
      ? t("viewTimer")
      : timer.status === "paused" && timer.mode === "focus"
        ? t("resumeFocus")
        : t("startFocus");

  return (
    <div className="grid items-start gap-5 lg:grid-cols-2">
      <div className="flex flex-col gap-5">
      <div>
        <h1 className="text-3xl font-semibold">
          {hello}
          {name ? `, ${name}` : ""}
        </h1>
        {editing ? (
          <form
            className="mt-3 flex gap-2"
            onSubmit={(event) => {
              event.preventDefault();
              setEditing(false);
            }}
          >
            <input
              className="min-h-11 flex-1 rounded-md border border-border bg-surface px-3 text-base outline-none focus-visible:ring-2 focus-visible:ring-primary"
              value={name}
              autoFocus
              placeholder={t("namePlaceholder")}
              onChange={(event) => setName(event.target.value)}
            />
            <Button type="submit">{t("save")}</Button>
          </form>
        ) : (
          <button
            type="button"
            className="mt-1 text-sm text-muted underline-offset-2 hover:text-fg hover:underline"
            onClick={() => setEditing(true)}
          >
            {name ? t("rename") : t("addName")}
          </button>
        )}
      </div>

      <section className="rounded-xl border border-border bg-surface p-4">
        <div className="flex items-center gap-4">
          <div
            className="grid h-28 w-28 shrink-0 place-items-center rounded-full"
            style={{
              background: `conic-gradient(var(--color-primary) ${pct * 3.6}deg, var(--color-surface-2) 0deg)`,
            }}
            aria-hidden="true"
          >
            <div className="grid h-20 w-20 place-items-center rounded-full bg-surface text-center">
              <span className="text-2xl font-semibold tabular-nums leading-none">{today}</span>
              <span className="text-xs text-muted">{t("minutesWord")}</span>
            </div>
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm text-muted">{t("todayStudy")}</p>
            <p className="mt-1 text-lg font-semibold">
              {today >= goal ? t("goalMet") : `${today} / ${goal}`}
            </p>
            <div className="mt-3 flex items-center gap-2">
              <button
                type="button"
                className="grid h-11 w-11 place-items-center rounded-md border border-border text-lg"
                aria-label={t("goalDown")}
                onClick={() => nudgeGoal(-15)}
              >
                −
              </button>
              <span className="text-sm text-muted">
                {t("dailyGoal")} {goal}
              </span>
              <button
                type="button"
                className="grid h-11 w-11 place-items-center rounded-md border border-border text-lg"
                aria-label={t("goalUp")}
                onClick={() => nudgeGoal(15)}
              >
                +
              </button>
            </div>
          </div>
        </div>
        <div className="mt-4 flex items-center justify-between gap-3">
          <p className="flex items-center gap-2 text-sm">
            <Flame className="size-4 text-accent" aria-hidden="true" />
            <span className="font-semibold tabular-nums">{streak}</span>
            <span className="text-muted">{t("streak")}</span>
          </p>
          <Button onClick={beginFocus}>{cta}</Button>
        </div>
        {subject ? (
          <p className="mt-3 truncate text-sm text-muted">{subjectName(subject, lang)}</p>
        ) : null}
      </section>

      <section>
        <div className="mb-2 flex items-baseline justify-between">
          <h2 className="text-lg font-semibold">{t("openTasks")}</h2>
          <button type="button" className="text-sm text-primary" onClick={() => setView("subjects")}>
            {t("subjects")}
          </button>
        </div>
        {open.length === 0 ? (
          <p className="rounded-lg border border-border bg-surface px-4 py-5 text-sm text-muted">{t("allDone")}</p>
        ) : (
          <ul className="overflow-hidden rounded-lg border border-border bg-surface">
            {open.map((task) => {
              const sub = subjects.find((item) => item.id === task.subjectId);
              return (
                <li key={task.id} className="border-b border-border last:border-b-0">
                  <label className="flex min-h-12 items-center gap-3 px-3 py-2">
                    <input
                      type="checkbox"
                      className="size-5 accent-primary"
                      checked={task.done}
                      onChange={() => toggleTask(task.id)}
                    />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate">{task.title}</span>
                      {sub ? (
                        <span className="block truncate text-xs text-muted">{subjectName(sub, lang)}</span>
                      ) : null}
                    </span>
                  </label>
                </li>
              );
            })}
          </ul>
        )}
      </section>
      </div>

      <div className="flex flex-col gap-5">
      <section className="rounded-xl border border-border bg-surface p-4">
        <div className="mb-1 flex items-baseline justify-between gap-3">
          <h2 className="text-lg font-semibold">{t("week")}</h2>
          <button type="button" className="text-sm text-primary" onClick={() => setView("progress")}>
            {t("progress")}
          </button>
        </div>
        <p className="mb-2 text-sm text-muted">
          {t("weekTotal")}: {formatSpan(weekSum, lang)}
        </p>
        <WeekChart data={week} />
        {weekSum === 0 ? <p className="text-sm text-muted">{t("noMinutes")}</p> : null}
      </section>

      {subjects.length > 0 ? (
        <section className="grid grid-cols-2 gap-3">
          {subjects.slice(0, 4).map((sub) => {
            const prog = taskProgress(tasks, sub.id);
            return (
              <button
                key={sub.id}
                type="button"
                className="rounded-lg border border-border bg-surface p-3 text-left"
                onClick={() => setView("subjects")}
              >
                <Monogram name={subjectName(sub, lang)} mark={sub.mark} />
                <p className="mt-3 truncate font-semibold">{subjectName(sub, lang)}</p>
                <p className="mt-1 text-xs text-muted tabular-nums">
                  {prog.done}/{prog.total}
                </p>
                <div className="mt-2">
                  <Meter pct={prog.pct} />
                </div>
              </button>
            );
          })}
        </section>
      ) : null}
      </div>
    </div>
  );
}
