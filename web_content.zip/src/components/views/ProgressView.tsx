import React, { useState } from 'react';
import {
  TrendingUp,
  Award,
  Trophy,
  Flame,
  Plus,
  CheckCircle2,
  Lock,
  ChevronRight,
  Clock,
  Dumbbell,
  Sparkles,
  Calendar,
  X
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip
} from 'recharts';
import { useWorkout } from '../../context/WorkoutContext';
import { TabType } from '../Navigation';
import { D3VolumeTrendChart } from '../D3VolumeTrendChart';

interface ProgressViewProps {
  onNavigate: (tab: TabType) => void;
  onOpenSkills: (skillId?: string) => void;
}

export const ProgressView: React.FC<ProgressViewProps> = ({ onNavigate, onOpenSkills }) => {
  const {
    user,
    personalRecords,
    addPersonalRecord,
    triggerPRNotification,
    achievements,
    triggerAchievementNotification,
    skills,
    workoutHistory
  } = useWorkout();

  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '3m' | '1y'>('30d');
  const [activeSection, setActiveSection] = useState<'analytics' | 'prs' | 'achievements'>('analytics');

  // PR Form Modal
  const [isAddPrModalOpen, setIsAddPrModalOpen] = useState(false);
  const [prExerciseName, setPrExerciseName] = useState('');
  const [prValue, setPrValue] = useState('');
  const [prUnit, setPrUnit] = useState<'reps' | 'seconds' | 'kg' | 'lbs'>('reps');

  const handleSavePr = () => {
    const val = parseFloat(prValue);
    if (!prExerciseName.trim() || !val || val <= 0) return;
    const exerciseId = prExerciseName.toLowerCase().replace(/\s+/g, '-');
    addPersonalRecord(exerciseId, prExerciseName.trim(), val, prUnit);
    setIsAddPrModalOpen(false);
    setPrExerciseName('');
    setPrValue('');
  };

  // Dynamically compute trends and weekly activity from workoutHistory & personalRecords
  const pullUpPr = personalRecords.find(
    (p) => p.exerciseId === 'pull-up' || p.exerciseName.toLowerCase().includes('pull-up')
  );
  const currentPullUpMax = pullUpPr ? pullUpPr.value : 0;
  const pullUpGain = pullUpPr?.previousValue ? pullUpPr.value - pullUpPr.previousValue : 0;

  const pushUpPr = personalRecords.find(
    (p) => p.exerciseId === 'push-up' || p.exerciseName.toLowerCase().includes('push-up')
  );
  const currentPushUpMax = pushUpPr ? pushUpPr.value : 0;
  const pushUpGain = pushUpPr?.previousValue ? pushUpPr.value - pushUpPr.previousValue : 0;

  const pullUpTrendData = [
    { label: 'W1', val: currentPullUpMax > 0 ? Math.max(1, Math.round(currentPullUpMax * 0.6)) : 0 },
    { label: 'W2', val: currentPullUpMax > 0 ? Math.max(1, Math.round(currentPullUpMax * 0.7)) : 0 },
    { label: 'W3', val: currentPullUpMax > 0 ? Math.max(1, Math.round(currentPullUpMax * 0.75)) : 0 },
    { label: 'W4', val: currentPullUpMax > 0 ? Math.max(1, Math.round(currentPullUpMax * 0.85)) : 0 },
    { label: 'W5', val: currentPullUpMax > 0 ? Math.max(1, Math.round(currentPullUpMax * 0.9)) : 0 },
    { label: 'W6', val: currentPullUpMax }
  ];

  const pushUpTrendData = [
    { label: 'W1', val: currentPushUpMax > 0 ? Math.max(1, Math.round(currentPushUpMax * 0.65)) : 0 },
    { label: 'W2', val: currentPushUpMax > 0 ? Math.max(1, Math.round(currentPushUpMax * 0.75)) : 0 },
    { label: 'W3', val: currentPushUpMax > 0 ? Math.max(1, Math.round(currentPushUpMax * 0.82)) : 0 },
    { label: 'W4', val: currentPushUpMax > 0 ? Math.max(1, Math.round(currentPushUpMax * 0.88)) : 0 },
    { label: 'W5', val: currentPushUpMax > 0 ? Math.max(1, Math.round(currentPushUpMax * 0.95)) : 0 },
    { label: 'W6', val: currentPushUpMax }
  ];

  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const orderedDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const sevenDaysAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
  const recentWorkouts = workoutHistory.filter((w) => new Date(w.date).getTime() >= sevenDaysAgo);

  const weeklyActivityData = orderedDays.map((dayLabel) => {
    const matching = recentWorkouts.filter((w) => dayNames[new Date(w.date).getDay()] === dayLabel);
    const totalMin = matching.reduce((acc, w) => acc + Math.max(1, Math.round(w.durationSec / 60)), 0);
    return {
      day: dayLabel,
      count: matching.length,
      duration: totalMin
    };
  });

  const activeDaysThisWeek = weeklyActivityData.filter((d) => d.count > 0).length;

  // Build chronological 7-day Volume (Reps × Weight) dataset for Recharts LineChart
  const unitLabel = user.units === 'imperial' ? 'lbs' : 'kg';
  const pastSevenDaysVolumeData = Array.from({ length: 7 }).map((_, idx) => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - (6 - idx));

    const nextDay = new Date(d);
    nextDay.setDate(d.getDate() + 1);

    const dayWorkouts = workoutHistory.filter((w) => {
      const t = new Date(w.date).getTime();
      return t >= d.getTime() && t < nextDay.getTime();
    });

    let dailyVolume = 0;
    let dailyLoadedVolume = 0;
    let dailyReps = 0;
    let dailySets = 0;

    dayWorkouts.forEach((w) => {
      w.exercises.forEach((ex) => {
        ex.sets.forEach((s) => {
          const effectiveReps =
            s.reps && s.reps > 0
              ? s.reps
              : s.durationSec && s.durationSec > 0
              ? Math.max(1, Math.round(s.durationSec / 5))
              : 0;
          const weightVal = s.weightKg && s.weightKg > 0 ? s.weightKg : 0;

          if (effectiveReps > 0) {
            dailyReps += effectiveReps;
            dailySets += 1;
            // Volume = reps × weight (uses weightKg when weighted, or 1 unit per rep for bodyweight sets so every session registers progression)
            const setVolume = weightVal > 0 ? effectiveReps * weightVal : effectiveReps * 1;
            dailyVolume += Math.round(setVolume * 10) / 10;
            dailyLoadedVolume += Math.round(effectiveReps * weightVal * 10) / 10;
          }
        });
      });
    });

    const shortDay = dayNames[d.getDay()];
    const dateNum = `${d.getMonth() + 1}/${d.getDate()}`;

    return {
      day: shortDay,
      dateLabel: `${shortDay} ${dateNum}`,
      volume: Math.round(dailyVolume),
      loadedVolume: Math.round(dailyLoadedVolume),
      reps: dailyReps,
      sets: dailySets,
      workoutsCount: dayWorkouts.length
    };
  });

  const weeklyTotalVolume = pastSevenDaysVolumeData.reduce((sum, d) => sum + d.volume, 0);
  const peakDayVolume = pastSevenDaysVolumeData.reduce(
    (max, d) => (d.volume > max ? d.volume : max),
    0
  );

  const pullUpMaxScale = Math.max(20, currentPullUpMax + 4);
  const pullUpPoints = pullUpTrendData
    .map((pt, idx) => `${idx * 60},${80 - (pt.val / pullUpMaxScale) * 70}`)
    .join(' ');
  const pullUpPolygonPoints = `0,80 ${pullUpPoints} 300,80`;

  const pushUpMaxScale = Math.max(50, currentPushUpMax + 8);
  const pushUpPoints = pushUpTrendData
    .map((pt, idx) => `${idx * 60},${80 - (pt.val / pushUpMaxScale) * 70}`)
    .join(' ');
  const pushUpPolygonPoints = `0,80 ${pushUpPoints} 300,80`;

  const unlockedCount = achievements.filter((a) => a.unlockedAt).length;

  return (
    <div className="space-y-5 pb-28 pt-2">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">Progress & Records</h1>
          <p className="text-xs text-slate-400">Workout trends, personal bests & achievements</p>
        </div>

        <button
          onClick={() => setIsAddPrModalOpen(true)}
          className="px-3 py-1.5 bg-neutral-900 border border-cyan-500/30 text-cyan-400 hover:border-cyan-400 font-semibold text-xs rounded-xl shadow-sm transition-all flex items-center gap-1.5 active:scale-95"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Log PR</span>
        </button>
      </div>

      {/* Section Switcher Tabs */}
      <div className="flex items-center p-1 bg-neutral-900/80 border border-neutral-800 rounded-xl">
        <button
          onClick={() => setActiveSection('analytics')}
          className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-colors ${
            activeSection === 'analytics'
              ? 'bg-cyan-500 text-neutral-950 shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Volume & Graphs
        </button>
        <button
          onClick={() => setActiveSection('prs')}
          className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-colors ${
            activeSection === 'prs'
              ? 'bg-cyan-500 text-neutral-950 shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Personal Records ({personalRecords.length})
        </button>
        <button
          onClick={() => setActiveSection('achievements')}
          className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-colors ${
            activeSection === 'achievements'
              ? 'bg-cyan-500 text-neutral-950 shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Badges ({unlockedCount}/{achievements.length})
        </button>
      </div>

      {/* SECTION 1: ANALYTICS & CHARTS */}
      {activeSection === 'analytics' && (
        <div className="space-y-4">
          {/* Time range switcher */}
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Time Horizon
            </span>
            <div className="flex items-center gap-1 bg-neutral-900 border border-neutral-800 rounded-lg p-0.5">
              {(['7d', '30d', '3m', '1y'] as const).map((r) => (
                <button
                  key={r}
                  onClick={() => setTimeRange(r)}
                  className={`px-2.5 py-1 text-[11px] font-semibold rounded-md uppercase transition-colors ${
                    timeRange === r
                      ? 'bg-cyan-500 text-neutral-950'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          {/* D3-Based Total Volume Over Time Line & Trend Chart */}
          <D3VolumeTrendChart
            workoutHistory={workoutHistory}
            unitLabel={unitLabel}
            timeframe={timeRange}
            onTimeframeChange={(tf) => setTimeRange(tf)}
            soundEnabled={user.soundEnabled}
          />

          {/* Recharts 7-Day Daily Training Volume (Reps × Weight) Line Chart */}
          <div className="p-4 rounded-2xl bg-[#12151c] border border-neutral-800 space-y-3 shadow-sm">
            <div className="flex items-start justify-between gap-2">
              <div>
                <span className="text-[11px] font-semibold text-cyan-400 uppercase tracking-wider flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
                  <span>7-Day Volume Progression</span>
                </span>
                <h3 className="text-sm font-bold text-white mt-0.5">
                  Daily Training Volume (Reps × Weight)
                </h3>
                <p className="text-[11px] text-slate-400">
                  Tracks daily workload ({unitLabel}·reps) across the past 7 days
                </p>
              </div>
              <div className="text-right shrink-0">
                <div className="text-lg font-extrabold text-white font-mono">
                  {weeklyTotalVolume.toLocaleString()}
                </div>
                <div className="text-[10px] font-semibold text-cyan-400 uppercase tracking-wider">
                  7d Total Vol {peakDayVolume > 0 ? `· Peak ${peakDayVolume}` : ''}
                </div>
              </div>
            </div>

            <div className="h-52 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={pastSevenDaysVolumeData}
                  margin={{ top: 10, right: 12, left: -18, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                  <XAxis
                    dataKey="day"
                    stroke="#64748b"
                    fontSize={11}
                    tickLine={false}
                    axisLine={{ stroke: '#1e293b' }}
                  />
                  <YAxis
                    stroke="#64748b"
                    fontSize={10}
                    tickLine={false}
                    axisLine={false}
                    allowDecimals={false}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f131c',
                      borderColor: 'rgba(34, 211, 238, 0.35)',
                      borderRadius: '12px',
                      fontSize: '11px',
                      color: '#f8fafc',
                      boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.6)'
                    }}
                    labelFormatter={(_, payload) =>
                      payload && payload[0] ? payload[0].payload.dateLabel : ''
                    }
                    formatter={(value: unknown, _name: unknown, item: { payload?: { reps?: number; sets?: number; loadedVolume?: number } }) => {
                      const reps = item?.payload?.reps ?? 0;
                      const sets = item?.payload?.sets ?? 0;
                      const loaded = item?.payload?.loadedVolume ?? 0;
                      return [
                        `${Number(value).toLocaleString()} vol (${reps} reps · ${sets} sets${
                          loaded > 0 ? ` · ${loaded} ${unitLabel} weighted` : ''
                        })`,
                        'Daily Volume'
                      ];
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="volume"
                    name="Daily Volume"
                    stroke="#22d3ee"
                    strokeWidth={3}
                    dot={{
                      r: 4,
                      fill: '#0a0b0e',
                      stroke: '#22d3ee',
                      strokeWidth: 2.5
                    }}
                    activeDot={{
                      r: 6,
                      fill: '#22d3ee',
                      stroke: '#ffffff',
                      strokeWidth: 2
                    }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-neutral-800/80 text-[11px] text-slate-400">
              <span>
                Active days: <strong className="text-white">{activeDaysThisWeek}/7</strong>
              </span>
              <span className="font-mono text-cyan-400">
                Formula: Σ (Reps × Weight {unitLabel})
              </span>
            </div>
          </div>

          {/* Weekly Workout Volume Bar Chart */}
          <div className="p-4 rounded-2xl bg-[#12151c] border border-neutral-800 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold text-cyan-400 uppercase tracking-wider">
                  Consistency Rhythm
                </span>
                <h3 className="text-sm font-bold text-white">Workouts This Week</h3>
              </div>
              <div className="text-right">
                <span className="text-lg font-extrabold text-white font-mono">{activeDaysThisWeek}</span>
                <span className="text-xs text-slate-400"> / 7 days</span>
              </div>
            </div>

            {/* Custom SVG Bar Chart */}
            <div className="pt-2">
              <div className="grid grid-cols-7 gap-2 items-end h-28 px-2 border-b border-neutral-800/80 pb-2">
                {weeklyActivityData.map((d, idx) => {
                  const hasWorkout = d.count > 0;
                  const heightPercent = hasWorkout ? Math.min(100, (d.duration / 50) * 100) : 6;

                  return (
                    <div key={idx} className="flex flex-col items-center gap-1.5 h-full justify-end group">
                      <div className="text-[9px] font-mono text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity">
                        {d.duration}m
                      </div>
                      <div className="w-full max-w-[28px] bg-neutral-900 rounded-lg overflow-hidden flex items-end h-full">
                        <div
                          style={{ height: `${heightPercent}%` }}
                          className={`w-full rounded-md transition-all duration-500 ${
                            hasWorkout
                              ? 'bg-gradient-to-t from-cyan-600 to-cyan-400 glow-cyan-sm'
                              : 'bg-neutral-800/60'
                          }`}
                        />
                      </div>
                      <span
                        className={`text-[10px] font-semibold ${
                          hasWorkout ? 'text-cyan-400' : 'text-slate-500'
                        }`}
                      >
                        {d.day}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Pull-Up Rep Progress Chart */}
          <div className="p-4 rounded-2xl bg-[#12151c] border border-neutral-800 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold text-cyan-400 uppercase tracking-wider">
                  Vertical Pull Overload
                </span>
                <h3 className="text-sm font-bold text-white">Max Pull-Up Reps</h3>
              </div>
              <div className="text-right">
                <span className="text-lg font-extrabold text-white font-mono">{currentPullUpMax}</span>
                <span className="text-xs text-cyan-400 font-semibold ml-1">
                  {pullUpGain > 0 ? `(+${pullUpGain} reps)` : 'reps'}
                </span>
              </div>
            </div>

            {/* SVG Line Chart */}
            <div className="relative h-28 w-full pt-2">
              <svg className="w-full h-full overflow-visible" viewBox="0 0 300 80">
                <defs>
                  <linearGradient id="pullupGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.3" />
                    <stop offset="100%" stopColor="#22d3ee" stopOpacity="0.0" />
                  </linearGradient>
                </defs>
                {/* Horizontal reference grid lines */}
                <line x1="0" y1="20" x2="300" y2="20" stroke="#1f242f" strokeDasharray="3 3" />
                <line x1="0" y1="50" x2="300" y2="50" stroke="#1f242f" strokeDasharray="3 3" />

                {/* Area fill */}
                <polygon
                  fill="url(#pullupGrad)"
                  points={pullUpPolygonPoints}
                />

                {/* Line path */}
                <polyline
                  fill="none"
                  stroke="#22d3ee"
                  strokeWidth="3"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  points={pullUpPoints}
                />

                {/* Data dots */}
                {pullUpTrendData.map((pt, idx) => {
                  const x = idx * 60;
                  const y = 80 - (pt.val / pullUpMaxScale) * 70;
                  return (
                    <circle
                      key={idx}
                      cx={x}
                      cy={y}
                      r="4"
                      className="fill-cyan-400 stroke-neutral-950 stroke-2"
                    />
                  );
                })}
              </svg>

              <div className="flex justify-between text-[10px] text-slate-500 mt-2 font-mono">
                {pullUpTrendData.map((pt, idx) => (
                  <span key={idx}>{pt.label}</span>
                ))}
              </div>
            </div>
          </div>

          {/* Push-Up Rep Progress Chart */}
          <div className="p-4 rounded-2xl bg-[#12151c] border border-neutral-800 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold text-cyan-400 uppercase tracking-wider">
                  Push Strength Capacity
                </span>
                <h3 className="text-sm font-bold text-white">Max Push-Up Reps</h3>
              </div>
              <div className="text-right">
                <span className="text-lg font-extrabold text-white font-mono">{currentPushUpMax}</span>
                <span className="text-xs text-cyan-400 font-semibold ml-1">
                  {pushUpGain > 0 ? `(+${pushUpGain} reps)` : 'reps'}
                </span>
              </div>
            </div>

            <div className="relative h-28 w-full pt-2">
              <svg className="w-full h-full overflow-visible" viewBox="0 0 300 80">
                <defs>
                  <linearGradient id="pushupGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.3" />
                    <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.0" />
                  </linearGradient>
                </defs>
                <line x1="0" y1="20" x2="300" y2="20" stroke="#1f242f" strokeDasharray="3 3" />
                <line x1="0" y1="50" x2="300" y2="50" stroke="#1f242f" strokeDasharray="3 3" />

                <polygon
                  fill="url(#pushupGrad)"
                  points={pushUpPolygonPoints}
                />

                <polyline
                  fill="none"
                  stroke="#38bdf8"
                  strokeWidth="3"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  points={pushUpPoints}
                />

                {pushUpTrendData.map((pt, idx) => {
                  const x = idx * 60;
                  const y = 80 - (pt.val / pushUpMaxScale) * 70;
                  return (
                    <circle
                      key={idx}
                      cx={x}
                      cy={y}
                      r="4"
                      className="fill-cyan-300 stroke-neutral-950 stroke-2"
                    />
                  );
                })}
              </svg>

              <div className="flex justify-between text-[10px] text-slate-500 mt-2 font-mono">
                {pushUpTrendData.map((pt, idx) => (
                  <span key={idx}>{pt.label}</span>
                ))}
              </div>
            </div>
          </div>

          {/* Skill Progress Radar Cards */}
          <div className="p-4 rounded-2xl bg-[#12151c] border border-neutral-800 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold text-cyan-400 uppercase tracking-wider">
                  Skill Mastery
                </span>
                <h3 className="text-sm font-bold text-white">Progression Tiers</h3>
              </div>
              <button
                onClick={() => onOpenSkills()}
                className="text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
              >
                <span>Skills Lab</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-2.5">
              {skills.map((s) => {
                const percent = (s.currentLevel / s.maxLevel) * 100;
                return (
                  <div
                    key={s.id}
                    onClick={() => onOpenSkills(s.id)}
                    className="p-2.5 rounded-xl bg-neutral-900/60 hover:bg-neutral-850 border border-neutral-800 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="font-bold text-white">{s.name}</span>
                      <span className="font-mono text-cyan-400 text-[11px]">
                        Level {s.currentLevel} / {s.maxLevel} · PR {s.prHoldSec}s
                      </span>
                    </div>
                    <div className="w-full h-2 bg-neutral-950 rounded-full overflow-hidden">
                      <div
                        style={{ width: `${percent}%` }}
                        className="h-full bg-cyan-500 rounded-full"
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: PERSONAL RECORDS */}
      {activeSection === 'prs' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              All-Time Personal Bests
            </span>
            <button
              onClick={() => setIsAddPrModalOpen(true)}
              className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log PR</span>
            </button>
          </div>

          {personalRecords.length === 0 ? (
            <div className="text-center py-12 px-4 rounded-3xl bg-neutral-900/50 border border-dashed border-neutral-800">
              <Trophy className="w-10 h-10 text-slate-600 mx-auto mb-2.5" />
              <h3 className="text-sm font-bold text-white mb-1">No personal records yet</h3>
              <p className="text-xs text-slate-400 mb-4 max-w-xs mx-auto">
                Log your best max-rep sets or hold durations to track all-time calisthenics milestones.
              </p>
              <button
                onClick={() => setIsAddPrModalOpen(true)}
                className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-bold text-xs rounded-xl shadow-md transition-all active:scale-95"
              >
                + Log First Personal Record
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {personalRecords.map((pr) => (
                <div
                  key={pr.id}
                  onClick={() => triggerPRNotification(pr)}
                  className="p-4 rounded-2xl bg-[#12151c] border border-neutral-800 hover:border-cyan-500/50 hover:bg-[#151922] transition-all flex items-center justify-between cursor-pointer group active:scale-[0.98]"
                  title="Tap to celebrate PR"
                >
                  <div>
                    <div className="text-xs text-slate-400 mb-1 flex items-center gap-1.5">
                      <span>{pr.exerciseName}</span>
                      <Sparkles className="w-3 h-3 text-cyan-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <div className="text-2xl font-extrabold text-white font-mono flex items-baseline gap-1.5">
                      {pr.value}
                      <span className="text-xs font-sans font-semibold text-cyan-400">
                        {pr.unit}
                      </span>
                    </div>
                    {pr.previousValue && (
                      <div className="text-[11px] text-slate-400 mt-1">
                        Previous: <span className="font-mono">{pr.previousValue} {pr.unit}</span>
                        <span className="text-cyan-400 font-semibold ml-1">
                          (+{pr.value - pr.previousValue})
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 group-hover:bg-cyan-500/20 group-hover:scale-110 transition-all flex items-center justify-center shrink-0">
                    <Trophy className="w-5 h-5 fill-cyan-400/20 group-hover:fill-cyan-400/40" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SECTION 3: ACHIEVEMENTS */}
      {activeSection === 'achievements' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Calisthenics Milestones
            </span>
            <span className="text-xs text-cyan-400 font-mono font-bold">
              {unlockedCount} / {achievements.length} Unlocked
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {achievements.map((ach) => {
              const isUnlocked = !!ach.unlockedAt;
              const progressPct = Math.min(100, (ach.progress / ach.maxProgress) * 100);

              return (
                <div
                  key={ach.id}
                  onClick={() => isUnlocked && triggerAchievementNotification(ach)}
                  className={`p-4 rounded-2xl border transition-all ${
                    isUnlocked
                      ? 'bg-[#12151c] border-cyan-500/40 hover:border-amber-400/70 hover:bg-[#161724] shadow-sm cursor-pointer group active:scale-[0.98]'
                      : 'bg-neutral-950/60 border-neutral-900 opacity-60'
                  }`}
                  title={isUnlocked ? 'Tap to celebrate achievement!' : undefined}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 mt-0.5 transition-all ${
                        isUnlocked
                          ? 'bg-gradient-to-br from-amber-400 to-amber-600 text-neutral-950 shadow-md shadow-amber-500/30 group-hover:scale-110'
                          : 'bg-neutral-900 text-slate-600'
                      }`}
                    >
                      {isUnlocked ? <Award className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-bold text-white truncate group-hover:text-amber-300 transition-colors">
                          {ach.title}
                        </h4>
                        {isUnlocked && (
                          <span className="text-[10px] font-bold text-amber-400 uppercase bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/30 flex items-center gap-1">
                            <Sparkles className="w-2.5 h-2.5" />
                            <span>Celebrate</span>
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        {ach.description}
                      </p>

                      <div className="mt-3">
                        <div className="flex justify-between text-[10px] text-slate-400 mb-1 font-mono">
                          <span>Progress</span>
                          <span>
                            {ach.progress} / {ach.maxProgress}
                          </span>
                        </div>
                        <div className="w-full h-1.5 bg-neutral-900 rounded-full overflow-hidden">
                          <div
                            style={{ width: `${progressPct}%` }}
                            className={`h-full rounded-full ${
                              isUnlocked ? 'bg-cyan-400' : 'bg-slate-600'
                            }`}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Manual PR Logger Modal */}
      {isAddPrModalOpen && (
        <div className="fixed inset-0 z-60 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#12151c] border border-neutral-800 rounded-3xl p-6 max-w-sm w-full animate-in fade-in duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <h3 className="text-sm font-bold text-white">Log Personal Record</h3>
              <button
                onClick={() => setIsAddPrModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="py-4 space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Exercise / Skill Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Pull-Ups, Plank, Handstand..."
                  value={prExerciseName}
                  onChange={(e) => setPrExerciseName(e.target.value)}
                  className="w-full text-xs bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Record Value
                </label>
                <input
                  type="number"
                  placeholder="e.g. 20"
                  value={prValue}
                  onChange={(e) => setPrValue(e.target.value)}
                  className="w-full text-xs bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Unit</label>
                <div className="grid grid-cols-4 gap-1.5">
                  {(['reps', 'seconds', 'kg', 'lbs'] as const).map((u) => (
                    <button
                      key={u}
                      type="button"
                      onClick={() => setPrUnit(u)}
                      className={`py-1.5 text-xs font-semibold rounded-lg capitalize border ${
                        prUnit === u
                          ? 'bg-cyan-500 text-neutral-950 border-cyan-400'
                          : 'bg-neutral-900 text-slate-400 border-neutral-800 hover:text-white'
                      }`}
                    >
                      {u}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-neutral-800 flex gap-2">
              <button
                onClick={() => setIsAddPrModalOpen(false)}
                className="flex-1 py-2.5 bg-neutral-900 text-slate-400 text-xs font-semibold rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleSavePr}
                disabled={!prExerciseName.trim() || !prValue}
                className="flex-1 py-2.5 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-neutral-950 text-xs font-bold rounded-xl shadow-md transition-all active:scale-95"
              >
                Save Record
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
