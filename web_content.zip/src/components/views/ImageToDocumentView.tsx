import React, { useState } from 'react';
import {
  Upload,
  RotateCw,
  ArrowUp,
  ArrowDown,
  Trash2,
  FileCheck2,
  Download,
  ScanText,
  Images,
  RefreshCw,
  Eye
} from 'lucide-react';
import { convertImagesToPdf } from '../../utils/pdfProcessor';
import { performBatchOcr } from '../../utils/ocrService';
import { generateDocxBlob, generatePdfBlob, DEFAULT_STYLE_SETTINGS, parseRawTextToSections } from '../../utils/documentEngine';
import { triggerFileDownload, saveStoredDocument } from '../../services/storageService';

interface ImageItem {
  id: string;
  name: string;
  dataUrl: string;
  rotation: number; // 0, 90, 180, 270
  file?: File;
}

interface ImageToDocumentViewProps {
  onBack: () => void;
  onSendToFullEditor?: (text: string) => void;
}

export const ImageToDocumentView: React.FC<ImageToDocumentViewProps> = ({
  onBack,
  onSendToFullEditor
}) => {
  const [images, setImages] = useState<ImageItem[]>([]);
  const [mode, setMode] = useState<'original_image' | 'ocr_reconstruct'>('original_image');
  const [pageSize, setPageSize] = useState<'A4' | 'Letter'>('A4');
  const [isProcessing, setIsProcessing] = useState(false);
  const [progressMsg, setProgressMsg] = useState('');
  const [docTitle, setDocTitle] = useState('Scanned Document');

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const files = Array.from(e.target.files);

    files.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const res = ev.target?.result;
        if (typeof res === 'string') {
          setImages((prev) => [
            ...prev,
            {
              id: 'img-' + Math.random().toString(36).substring(2, 9),
              name: file.name,
              dataUrl: res,
              rotation: 0,
              file
            }
          ]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const rotateImage = (id: string) => {
    setImages((prev) =>
      prev.map((img) => {
        if (img.id !== id) return img;
        const newRot = (img.rotation + 90) % 360;

        // Apply rotation to canvas dataUrl
        const imageObj = new Image();
        imageObj.src = img.dataUrl;
        imageObj.onload = () => {
          const canvas = document.createElement('canvas');
          if (newRot === 90 || newRot === 270) {
            canvas.width = imageObj.naturalHeight;
            canvas.height = imageObj.naturalWidth;
          } else {
            canvas.width = imageObj.naturalWidth;
            canvas.height = imageObj.naturalHeight;
          }
          const ctx = canvas.getContext('2d');
          if (!ctx) return;
          ctx.translate(canvas.width / 2, canvas.height / 2);
          ctx.rotate((newRot * Math.PI) / 180);
          ctx.drawImage(imageObj, -imageObj.naturalWidth / 2, -imageObj.naturalHeight / 2);
          img.dataUrl = canvas.toDataURL('image/jpeg', 0.95);
        };

        return { ...img, rotation: newRot };
      })
    );
  };

  const moveUp = (index: number) => {
    if (index === 0) return;
    const next = [...images];
    const temp = next[index - 1];
    next[index - 1] = next[index];
    next[index] = temp;
    setImages(next);
  };

  const moveDown = (index: number) => {
    if (index === images.length - 1) return;
    const next = [...images];
    const temp = next[index + 1];
    next[index + 1] = next[index];
    next[index] = temp;
    setImages(next);
  };

  const removeImage = (id: string) => {
    setImages((prev) => prev.filter((img) => img.id !== id));
  };

  const handleExport = async (format: 'pdf' | 'docx') => {
    if (images.length === 0) return;
    setIsProcessing(true);

    try {
      if (mode === 'original_image') {
        setProgressMsg('Embedding images into document pages...');
        const pdfBlob = await convertImagesToPdf(
          images.map((img) => ({ dataUrl: img.dataUrl })),
          pageSize
        );

        const fileName = `${docTitle.replace(/\s+/g, '_')}.pdf`;
        triggerFileDownload(pdfBlob, fileName);
        saveStoredDocument({
          id: 'imgdoc-' + Date.now(),
          name: fileName,
          type: 'pdf',
          sizeBytes: pdfBlob.size,
          createdAt: Date.now(),
          updatedAt: Date.now(),
          blobData: pdfBlob,
          pageCount: images.length,
          sourceFeature: 'Image to Document'
        });
      } else {
        // OCR Reconstruction Mode
        setProgressMsg('Running OCR reconstruction across images...');
        const ocrResults = await performBatchOcr(
          images.map((img) => ({ dataUrl: img.dataUrl, name: img.name })),
          'eng',
          (p) => setProgressMsg(p.status)
        );

        const combinedText = ocrResults.map((r) => r.extractedText).join('\n\n');
        const sections = parseRawTextToSections(combinedText);

        if (format === 'docx') {
          const docxBlob = await generateDocxBlob(docTitle, sections, {
            ...DEFAULT_STYLE_SETTINGS,
            pageSize
          });
          const fileName = `${docTitle.replace(/\s+/g, '_')}.docx`;
          triggerFileDownload(docxBlob, fileName);
          saveStoredDocument({
            id: 'imgdoc-docx-' + Date.now(),
            name: fileName,
            type: 'docx',
            sizeBytes: docxBlob.size,
            createdAt: Date.now(),
            updatedAt: Date.now(),
            blobData: docxBlob,
            pageCount: images.length,
            sourceFeature: 'Image to Document (OCR)'
          });
        } else {
          const pdfBlob = await generatePdfBlob(docTitle, sections, {
            ...DEFAULT_STYLE_SETTINGS,
            pageSize
          });
          const fileName = `${docTitle.replace(/\s+/g, '_')}.pdf`;
          triggerFileDownload(pdfBlob, fileName);
          saveStoredDocument({
            id: 'imgdoc-pdf-' + Date.now(),
            name: fileName,
            type: 'pdf',
            sizeBytes: pdfBlob.size,
            createdAt: Date.now(),
            updatedAt: Date.now(),
            blobData: pdfBlob,
            pageCount: images.length,
            sourceFeature: 'Image to Document (OCR)'
          });
        }
      }
    } catch (e) {
      console.error('Image to document export error:', e);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-neutral-50 dark:bg-neutral-900 pb-16">
      {/* Top Configuration */}
      <div className="px-4 py-3 bg-white dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <input
            type="text"
            value={docTitle}
            onChange={(e) => setDocTitle(e.target.value)}
            className="text-sm font-bold bg-transparent border-b border-transparent hover:border-neutral-300 focus:border-blue-500 text-neutral-900 dark:text-neutral-100 focus:outline-none"
            placeholder="Document Name"
          />

          <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-xs active:scale-95 transition-all">
            <Upload className="w-3.5 h-3.5" />
            <span>Add Images</span>
            <input
              type="file"
              multiple
              accept="image/*"
              className="hidden"
              onChange={handleImageUpload}
            />
          </label>
        </div>

        {/* Mode Selector Tabs */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-neutral-100 dark:bg-neutral-700 rounded-xl">
          <button
            type="button"
            onClick={() => setMode('original_image')}
            className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              mode === 'original_image'
                ? 'bg-white dark:bg-neutral-800 text-purple-700 dark:text-purple-300 shadow-xs'
                : 'text-neutral-600 dark:text-neutral-300'
            }`}
          >
            <Images className="w-3.5 h-3.5" />
            <span>(a) Original-Image Mode</span>
          </button>

          <button
            type="button"
            onClick={() => setMode('ocr_reconstruct')}
            className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              mode === 'ocr_reconstruct'
                ? 'bg-white dark:bg-neutral-800 text-purple-700 dark:text-purple-300 shadow-xs'
                : 'text-neutral-600 dark:text-neutral-300'
            }`}
          >
            <ScanText className="w-3.5 h-3.5" />
            <span>(b) OCR Reconstruction Mode</span>
          </button>
        </div>

        {/* Sub-options: Page Size */}
        <div className="flex items-center justify-between text-xs">
          <span className="text-neutral-500 font-medium">
            {mode === 'original_image'
              ? 'Preserves each image as a crisp full-page element'
              : 'Extracts editable text with paragraph and table recognition'}
          </span>

          <select
            value={pageSize}
            onChange={(e) => setPageSize(e.target.value as any)}
            className="px-2 py-1 rounded-lg bg-neutral-100 dark:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 font-medium text-neutral-900 dark:text-neutral-100"
          >
            <option value="A4">A4 Page</option>
            <option value="Letter">Letter Page</option>
          </select>
        </div>
      </div>

      {isProcessing && (
        <div className="px-4 py-2 bg-purple-50 dark:bg-purple-950/60 border-b border-purple-200 dark:border-purple-800 flex items-center justify-between text-xs font-semibold text-purple-800 dark:text-purple-300">
          <span className="flex items-center gap-1.5">
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            <span>{progressMsg}</span>
          </span>
        </div>
      )}

      {/* Images List & Ordering */}
      <div className="flex-1 p-3 overflow-y-auto space-y-3">
        {images.length === 0 ? (
          <div className="text-center py-20 px-6 rounded-3xl border-2 border-dashed border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800/40 space-y-3">
            <div className="w-16 h-16 mx-auto rounded-3xl bg-purple-50 dark:bg-purple-950/40 text-purple-600 flex items-center justify-center">
              <Images className="w-8 h-8" />
            </div>
            <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
              No Images Added Yet
            </h3>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 max-w-xs mx-auto">
              Select one or multiple images from your gallery to create a multi-page PDF or editable DOCX.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {images.map((img, idx) => (
              <div
                key={img.id}
                className="flex items-center justify-between p-2.5 rounded-2xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 shadow-xs"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative w-14 h-14 rounded-xl overflow-hidden bg-neutral-100 dark:bg-neutral-900 shrink-0 border border-neutral-200 dark:border-neutral-700">
                    <img src={img.dataUrl} alt={img.name} className="w-full h-full object-cover" />
                    <span className="absolute bottom-0 left-0 px-1.5 bg-black/70 text-[9px] text-white font-bold rounded-tr">
                      #{idx + 1}
                    </span>
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-neutral-900 dark:text-neutral-100 truncate max-w-[140px] sm:max-w-xs">
                      {img.name}
                    </p>
                    <p className="text-[10px] text-neutral-500 mt-0.5">
                      Rotation: {img.rotation}°
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => rotateImage(img.id)}
                    title="Rotate 90°"
                    className="p-1.5 rounded-lg text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700"
                  >
                    <RotateCw className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    disabled={idx === 0}
                    onClick={() => moveUp(idx)}
                    title="Move Up"
                    className="p-1.5 rounded-lg text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 disabled:opacity-30"
                  >
                    <ArrowUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    disabled={idx === images.length - 1}
                    onClick={() => moveDown(idx)}
                    title="Move Down"
                    className="p-1.5 rounded-lg text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 disabled:opacity-30"
                  >
                    <ArrowDown className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => removeImage(img.id)}
                    title="Remove"
                    className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Floating Export Bar */}
      <div className="sticky bottom-0 px-4 py-3 bg-white/95 dark:bg-neutral-800/95 backdrop-blur-md border-t border-neutral-200 dark:border-neutral-700 flex items-center justify-between gap-2 shadow-lg">
        <button
          type="button"
          onClick={onBack}
          className="px-4 py-2 rounded-xl text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-xs font-semibold"
        >
          Back
        </button>

        <div className="flex items-center gap-2">
          {mode === 'ocr_reconstruct' && (
            <button
              type="button"
              disabled={images.length === 0 || isProcessing}
              onClick={() => handleExport('docx')}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all disabled:opacity-40"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export DOCX</span>
            </button>
          )}

          <button
            type="button"
            disabled={images.length === 0 || isProcessing}
            onClick={() => handleExport('pdf')}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all disabled:opacity-40"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export PDF</span>
          </button>
        </div>
      </div>
    </div>
  );
};
