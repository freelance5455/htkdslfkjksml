import { useState } from "react";
import { WeekChart } from "@/components/week-chart";
import { Button, useCopy } from "@/components/bits";
import { formatSpan, streakCount, subjectName, taskProgress, weekSeries } from "@/lib/model";
import { useStudy } from "@/lib/store";

export function ProgressView() {
  const { lang, t } = useCopy();
  const subjects = useStudy((s) => s.subjects);
  const tasks = useStudy((s) => s.tasks);
  const sessions = useStudy((s) => s.sessions);
  const attempts = useStudy((s) => s.attempts);
  const restoreDemo = useStudy((s) => s.restoreDemo);
  const [confirm, setConfirm] = useState(false);

  const week = weekSeries(sessions, lang);
  const weekSum = week.reduce((sum, row) => sum + row.minutes, 0);
  const totalMin = sessions.reduce((sum, session) => sum + session.minutes, 0);
  const streak = streakCount(sessions);
  const tasksStat = taskProgress(tasks);
  const avg = attempts.length
    ? Math.round(
        attempts.reduce((sum, attempt) => sum + (attempt.total ? (attempt.score / attempt.total) * 100 : 0), 0) /
          attempts.length,
      )
    : 0;
  const bySubject = subjects
    .map((sub) => ({
      id: sub.id,
      name: subjectName(sub, lang),
      minutes: sessions.filter((session) => session.subjectId === sub.id).reduce((sum, session) => sum + session.minutes, 0),
    }))
    .sort((a, b) => b.minutes - a.minutes);
  const maxMin = Math.max(1, ...bySubject.map((row) => row.minutes));
  const recent = [...attempts].reverse().slice(0, 6);

  return (
    <div className="flex flex-col gap-5">
      <h1 className="text-3xl font-semibold">{t("progress")}</h1>
      <div className="grid grid-cols-2 gap-3">
        <Stat label={t("totalFocus")} value={formatSpan(totalMin, lang)} />
        <Stat label={t("streak")} value={String(streak)} />
        <Stat label={t("quizAvg")} value={`${avg}%`} />
        <Stat label={t("tasksDone")} value={`${tasksStat.done}/${tasksStat.total}`} />
      </div>

      <section className="rounded-xl border border-border bg-surface p-4">
        <div className="mb-1 flex items-baseline justify-between">
          <h2 className="text-lg font-semibold">{t("week")}</h2>
          <p className="text-sm text-muted tabular-nums">{formatSpan(weekSum, lang)}</p>
        </div>
        <WeekChart data={week} />
        {weekSum === 0 ? <p className="text-sm text-muted">{t("noMinutes")}</p> : null}
      </section>

      <section className="rounded-xl border border-border bg-surface p-4">
        <h2 className="mb-3 text-lg font-semibold">{t("perSubject")}</h2>
        <ul className="flex flex-col gap-3">
          {bySubject.map((row, index) => (
            <li key={row.id}>
              <div className="mb-1 flex items-baseline justify-between gap-3 text-sm">
                <span className="truncate font-medium">{row.name}</span>
                <span className="shrink-0 tabular-nums text-muted">{formatSpan(row.minutes, lang)}</span>
              </div>
              <div className="h-2 overflow-hidden rounded-full bg-surface-2">
                <div
                  className={`h-full rounded-full ${index === 0 && row.minutes > 0 ? "bg-accent" : "bg-primary"}`}
                  style={{ width: `${(row.minutes / maxMin) * 100}%` }}
                />
              </div>
            </li>
          ))}
        </ul>
      </section>

      <section>
        <h2 className="mb-2 text-lg font-semibold">{t("recentQuizzes")}</h2>
        {recent.length === 0 ? (
          <p className="text-sm text-muted">{t("noQuizzes")}</p>
        ) : (
          <ul className="overflow-hidden rounded-lg border border-border bg-surface">
            {recent.map((attempt) => {
              const sub = subjects.find((item) => item.id === attempt.subjectId);
              const pct = attempt.total ? Math.round((attempt.score / attempt.total) * 100) : 0;
              return (
                <li key={attempt.id} className="flex items-center justify-between gap-3 border-b border-border px-3 py-3 last:border-b-0">
                  <span className="min-w-0">
                    <span className="block truncate font-medium">{sub ? subjectName(sub, lang) : t("quiz")}</span>
                    <span className="text-xs text-muted">
                      {new Date(attempt.at).toLocaleDateString(lang === "hi" ? "hi-IN" : "en-IN", {
                        day: "numeric",
                        month: "short",
                      })}
                    </span>
                  </span>
                  <span className="font-semibold tabular-nums">
                    {attempt.score}/{attempt.total}
                    <span className="ml-2 text-sm text-muted">{pct}%</span>
                  </span>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      {confirm ? (
        <div className="flex flex-wrap items-center gap-2">
          <p className="text-sm">{t("confirmRestore")}</p>
          <Button variant="accent" onClick={restoreDemo}>
            {t("yes")}
          </Button>
          <Button variant="surface" onClick={() => setConfirm(false)}>
            {t("cancel")}
          </Button>
        </div>
      ) : (
        <Button variant="ghost" onClick={() => setConfirm(true)}>
          {t("restore")}
        </Button>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-surface px-3 py-4">
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-1 text-2xl font-semibold tabular-nums">{value}</p>
    </div>
  );
}
