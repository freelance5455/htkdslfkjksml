import React, { useState, useRef, useEffect } from 'react';
import {
  Bold,
  Italic,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  Download,
  Eye,
  Edit3,
  FileText,
  Table as TableIcon,
  Sparkles,
  Layout,
  Type,
  Maximize2,
  Check,
  RotateCcw,
  ChevronDown,
  FileDown,
  FileType,
  X,
  Settings
} from 'lucide-react';
import {
  DocumentStyleSettings,
  DocumentSection,
  DocumentTemplateId,
  StoredDocument
} from '../../types';
import {
  SUPPORTED_FONTS,
  TEMPLATE_PRESETS,
  DEFAULT_STYLE_SETTINGS,
  generateDocxBlob,
  generatePdfBlob,
  generatePdfBlobWithJsPdf,
  parseRawTextToSections
} from '../../utils/documentEngine';
import { triggerFileDownload, saveStoredDocument } from '../../services/storageService';

interface TextToDocumentViewProps {
  onBack: () => void;
  initialText?: string;
  initialSections?: DocumentSection[];
  initialSettings?: Partial<DocumentStyleSettings>;
  onSaveDocument?: (doc: StoredDocument) => void;
}

export const TextToDocumentView: React.FC<TextToDocumentViewProps> = ({
  onBack,
  initialText,
  initialSections,
  initialSettings,
  onSaveDocument
}) => {
  const [activeTab, setActiveTab] = useState<'editor' | 'preview'>('editor');
  const [documentTitle, setDocumentTitle] = useState('My Document');
  const [styleSettings, setStyleSettings] = useState<DocumentStyleSettings>({
    ...DEFAULT_STYLE_SETTINGS,
    ...(initialSettings || {})
  });

  const defaultContent = initialText || `# Strategic Product Architecture
DocuForge provides high-precision document synthesis on Android.

## Core Capabilities
- Lossless document conversion between DOCX and PDF
- Multi-language optical character recognition with layout retention
- On-device image segmentation and background color customization

Metric | Baseline | DocuForge
Conversion Speed | 1.8s | 0.4s
OCR Accuracy | 91.2% | 98.6%

> "High-quality mobile typography brings professional publishing to smartphone screens."`;

  const [rawText, setRawText] = useState(defaultContent);
  const [sections, setSections] = useState<DocumentSection[]>(
    initialSections || parseRawTextToSections(defaultContent)
  );
  const [isExporting, setIsExporting] = useState(false);
  const [exportSuccessMessage, setExportSuccessMessage] = useState<string | null>(null);
  const [showExportDropdown, setShowExportDropdown] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [exportPdfEngine, setExportPdfEngine] = useState<'pdf-lib' | 'jspdf'>('pdf-lib');

  // Apply template preset
  const handleSelectTemplate = (templateId: DocumentTemplateId) => {
    const preset = TEMPLATE_PRESETS[templateId];
    if (preset) {
      setStyleSettings((prev) => ({
        ...prev,
        ...preset.settings
      }));
      if (!initialText) {
        setSections(preset.sampleSections);
        const reconstructedText = preset.sampleSections.map(s => {
          if (s.type === 'heading') return `# ${s.content}`;
          if (s.type === 'subheading') return `## ${s.content}`;
          if (s.type === 'bullet_list') return s.content.split('\n').map(l => `- ${l}`).join('\n');
          if (s.type === 'quote') return `> ${s.content}`;
          return s.content;
        }).join('\n\n');
        setRawText(reconstructedText);
      }
    }
  };

  // Sync raw text changes to parsed sections
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setRawText(val);
    setSections(parseRawTextToSections(val));
  };

  // Insert helper markdown structures
  const insertFormatting = (prefix: string, suffix: string = '') => {
    setRawText((prev) => prev + `\n${prefix}Sample Text${suffix}\n`);
    setSections(parseRawTextToSections(rawText + `\n${prefix}Sample Text${suffix}\n`));
  };

  const insertTable = () => {
    const tableTemplate = `\nHeader 1 | Header 2 | Header 3\nData A | Data B | Data C\nData X | Data Y | Data Z\n`;
    setRawText((prev) => prev + tableTemplate);
    setSections(parseRawTextToSections(rawText + tableTemplate));
  };

  // Export handlers
  const handleExportDocx = async () => {
    try {
      setIsExporting(true);
      const blob = await generateDocxBlob(documentTitle, sections, styleSettings);
      const fileName = `${documentTitle.replace(/\s+/g, '_')}.docx`;
      triggerFileDownload(blob, fileName);

      const stored: StoredDocument = {
        id: 'doc-' + Date.now(),
        name: fileName,
        type: 'docx',
        sizeBytes: blob.size,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        blobData: blob,
        pageCount: 1,
        sourceFeature: 'Text to Document'
      };
      saveStoredDocument(stored);
      onSaveDocument?.(stored);

      setExportSuccessMessage('Successfully downloaded .DOCX file!');
      setTimeout(() => setExportSuccessMessage(null), 3500);
    } catch (err: any) {
      console.error('Export DOCX failed:', err);
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportPdf = async (engine: 'pdf-lib' | 'jspdf' = exportPdfEngine) => {
    try {
      setIsExporting(true);
      let blob: Blob;
      if (engine === 'jspdf') {
        blob = await generatePdfBlobWithJsPdf(documentTitle, sections, styleSettings);
      } else {
        blob = await generatePdfBlob(documentTitle, sections, styleSettings);
      }
      const fileName = `${documentTitle.replace(/\s+/g, '_')}.pdf`;
      triggerFileDownload(blob, fileName);

      const stored: StoredDocument = {
        id: 'doc-' + Date.now(),
        name: fileName,
        type: 'pdf',
        sizeBytes: blob.size,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        blobData: blob,
        pageCount: 1,
        sourceFeature: `Text to Document (${engine})`
      };
      saveStoredDocument(stored);
      onSaveDocument?.(stored);

      setExportSuccessMessage(`Successfully downloaded .PDF file using ${engine === 'jspdf' ? 'jsPDF' : 'pdf-lib'}!`);
      setTimeout(() => setExportSuccessMessage(null), 3500);
    } catch (err: any) {
      console.error('Export PDF failed:', err);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-neutral-50 dark:bg-neutral-900 pb-16">
      {/* Title & Mode Switcher Bar */}
      <div className="px-3 py-2 bg-white dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 flex items-center justify-between gap-2">
        <input
          type="text"
          value={documentTitle}
          onChange={(e) => setDocumentTitle(e.target.value)}
          placeholder="Document Title"
          className="font-bold text-sm bg-transparent text-neutral-900 dark:text-neutral-100 border-b border-transparent hover:border-neutral-300 focus:border-blue-500 focus:outline-none flex-1 min-w-[100px] truncate py-1"
        />

        <div className="flex items-center gap-1.5 shrink-0">
          {/* Tab Switcher */}
          <div className="flex items-center gap-1 bg-neutral-100 dark:bg-neutral-700 p-0.5 rounded-xl">
            <button
              type="button"
              onClick={() => setActiveTab('editor')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all ${
                activeTab === 'editor'
                  ? 'bg-white dark:bg-neutral-800 text-blue-600 dark:text-blue-400 shadow-xs'
                  : 'text-neutral-600 dark:text-neutral-300'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Editor</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('preview')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all ${
                activeTab === 'preview'
                  ? 'bg-white dark:bg-neutral-800 text-blue-600 dark:text-blue-400 shadow-xs'
                  : 'text-neutral-600 dark:text-neutral-300'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Preview</span>
            </button>
          </div>

          {/* Quick Download / Export Action Menu */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowExportDropdown(!showExportDropdown)}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs active:scale-95 transition-all"
              aria-label="Download or Export document"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download</span>
              <ChevronDown className="w-3 h-3 ml-0.5" />
            </button>

            {showExportDropdown && (
              <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 shadow-xl z-50 p-1.5 space-y-1">
                <button
                  type="button"
                  onClick={() => {
                    setShowExportDropdown(false);
                    handleExportPdf('pdf-lib');
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-100 transition-colors"
                >
                  <div className="w-6 h-6 rounded-lg bg-rose-100 text-rose-600 flex items-center justify-center font-bold text-[10px]">
                    PDF
                  </div>
                  <div>
                    <p className="font-bold">Download as PDF</p>
                    <p className="text-[10px] text-neutral-500 font-normal">Formatted PDF with styling</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setShowExportDropdown(false);
                    handleExportPdf('jspdf');
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-100 transition-colors"
                >
                  <div className="w-6 h-6 rounded-lg bg-red-100 text-red-600 flex items-center justify-center font-bold text-[10px]">
                    PDF
                  </div>
                  <div>
                    <p className="font-bold">Download via jsPDF</p>
                    <p className="text-[10px] text-neutral-500 font-normal">Client-side jsPDF engine</p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setShowExportDropdown(false);
                    handleExportDocx();
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-100 transition-colors"
                >
                  <div className="w-6 h-6 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-[10px]">
                    DOCX
                  </div>
                  <div>
                    <p className="font-bold">Download as Word (.docx)</p>
                    <p className="text-[10px] text-neutral-500 font-normal">Microsoft Word format via docx</p>
                  </div>
                </button>

                <div className="border-t border-neutral-100 dark:border-neutral-700 my-1 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setShowExportDropdown(false);
                      setShowExportModal(true);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg text-[11px] text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 font-medium flex items-center gap-1.5"
                  >
                    <Settings className="w-3 h-3" />
                    <span>More export options...</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Formatting Ribbon / Controls */}
      <div className="px-3 py-2 bg-neutral-100/90 dark:bg-neutral-800/60 border-b border-neutral-200 dark:border-neutral-700 overflow-x-auto flex items-center gap-2 text-xs">
        {/* Template selector */}
        <select
          value={styleSettings.templateId}
          onChange={(e) => handleSelectTemplate(e.target.value as DocumentTemplateId)}
          className="px-2 py-1.5 rounded-lg bg-white dark:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 text-neutral-900 dark:text-neutral-100 font-medium focus:ring-1 focus:ring-blue-500"
        >
          <option value="general">Template: General</option>
          <option value="academic">Template: Academic (APA)</option>
          <option value="business">Template: Business</option>
          <option value="report">Template: Report</option>
          <option value="letter">Template: Formal Letter</option>
          <option value="notes">Template: Meeting Notes</option>
        </select>

        {/* Font Family selector */}
        <select
          value={styleSettings.fontFamily}
          onChange={(e) => setStyleSettings({ ...styleSettings, fontFamily: e.target.value })}
          className="px-2 py-1.5 rounded-lg bg-white dark:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 text-neutral-900 dark:text-neutral-100 font-medium"
        >
          {SUPPORTED_FONTS.map((font) => (
            <option key={font.name} value={font.name}>
              {font.name} ({font.category})
            </option>
          ))}
        </select>

        {/* Font Size & Custom Input */}
        <div className="flex items-center gap-1">
          <input
            type="number"
            min={8}
            max={48}
            value={styleSettings.bodySize}
            onChange={(e) =>
              setStyleSettings({
                ...styleSettings,
                bodySize: Math.max(8, parseInt(e.target.value, 10) || 11)
              })
            }
            className="w-14 px-1.5 py-1.5 rounded-lg bg-white dark:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 text-neutral-900 dark:text-neutral-100 text-center font-semibold"
          />
          <span className="text-[11px] text-neutral-500">pt</span>
        </div>

        {/* Alignment */}
        <div className="flex items-center bg-white dark:bg-neutral-700 rounded-lg p-0.5 border border-neutral-300 dark:border-neutral-600">
          {(['left', 'center', 'right', 'justify'] as const).map((align) => (
            <button
              key={align}
              type="button"
              onClick={() => setStyleSettings({ ...styleSettings, alignment: align })}
              className={`p-1.5 rounded ${
                styleSettings.alignment === align
                  ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300'
                  : 'text-neutral-600 dark:text-neutral-300'
              }`}
            >
              {align === 'left' && <AlignLeft className="w-3.5 h-3.5" />}
              {align === 'center' && <AlignCenter className="w-3.5 h-3.5" />}
              {align === 'right' && <AlignRight className="w-3.5 h-3.5" />}
              {align === 'justify' && <AlignJustify className="w-3.5 h-3.5" />}
            </button>
          ))}
        </div>

        {/* Line spacing */}
        <select
          value={styleSettings.lineSpacing}
          onChange={(e) =>
            setStyleSettings({ ...styleSettings, lineSpacing: parseFloat(e.target.value) })
          }
          className="px-2 py-1.5 rounded-lg bg-white dark:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 text-neutral-900 dark:text-neutral-100 font-medium"
        >
          <option value={1.0}>1.0 Spacing</option>
          <option value={1.15}>1.15 Spacing</option>
          <option value={1.25}>1.25 Spacing</option>
          <option value={1.5}>1.5 Spacing</option>
          <option value={2.0}>2.0 Double</option>
        </select>

        {/* Margins */}
        <select
          value={styleSettings.margins.top}
          onChange={(e) => {
            const m = parseFloat(e.target.value);
            setStyleSettings({
              ...styleSettings,
              margins: { top: m, bottom: m, left: m, right: m }
            });
          }}
          className="px-2 py-1.5 rounded-lg bg-white dark:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 text-neutral-900 dark:text-neutral-100 font-medium"
        >
          <option value={1.0}>Margins: Normal (1.0")</option>
          <option value={0.5}>Margins: Narrow (0.5")</option>
          <option value={1.25}>Margins: Wide (1.25")</option>
        </select>

        {/* Page Size & Orientation */}
        <select
          value={styleSettings.pageSize}
          onChange={(e) => setStyleSettings({ ...styleSettings, pageSize: e.target.value as any })}
          className="px-2 py-1.5 rounded-lg bg-white dark:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 text-neutral-900 dark:text-neutral-100 font-medium"
        >
          <option value="A4">Size: A4</option>
          <option value="Letter">Size: Letter</option>
          <option value="Legal">Size: Legal</option>
        </select>

        <select
          value={styleSettings.orientation}
          onChange={(e) => setStyleSettings({ ...styleSettings, orientation: e.target.value as any })}
          className="px-2 py-1.5 rounded-lg bg-white dark:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 text-neutral-900 dark:text-neutral-100 font-medium"
        >
          <option value="portrait">Portrait</option>
          <option value="landscape">Landscape</option>
        </select>

        {/* Quick structure insert buttons */}
        <button
          type="button"
          onClick={() => insertFormatting('# ')}
          className="px-2 py-1 rounded bg-neutral-200 dark:bg-neutral-700 text-neutral-800 dark:text-neutral-200 font-bold"
        >
          H1
        </button>
        <button
          type="button"
          onClick={() => insertFormatting('## ')}
          className="px-2 py-1 rounded bg-neutral-200 dark:bg-neutral-700 text-neutral-800 dark:text-neutral-200 font-bold"
        >
          H2
        </button>
        <button
          type="button"
          onClick={() => insertFormatting('- ')}
          className="px-2 py-1 rounded bg-neutral-200 dark:bg-neutral-700 text-neutral-800 dark:text-neutral-200"
        >
          List
        </button>
        <button
          type="button"
          onClick={insertTable}
          className="px-2 py-1 rounded bg-neutral-200 dark:bg-neutral-700 text-neutral-800 dark:text-neutral-200 flex items-center gap-1"
        >
          <TableIcon className="w-3.5 h-3.5" />
          <span>Table</span>
        </button>
      </div>

      {/* Success alert banner */}
      {exportSuccessMessage && (
        <div className="mx-4 mt-2 p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs font-semibold flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          <span>{exportSuccessMessage}</span>
        </div>
      )}

      {/* Main Content Area: Editor Tab vs Live Document Preview Tab */}
      <div className="flex-1 p-3 overflow-y-auto">
        {activeTab === 'editor' ? (
          <div className="h-full flex flex-col bg-white dark:bg-neutral-800 rounded-2xl border border-neutral-200 dark:border-neutral-700 shadow-xs overflow-hidden">
            <textarea
              value={rawText}
              onChange={handleTextChange}
              placeholder="Start typing your document text here or paste extracted OCR content..."
              className="w-full flex-1 p-4 bg-transparent text-neutral-900 dark:text-neutral-100 font-mono text-xs leading-relaxed focus:outline-none resize-none"
            />
            <div className="px-4 py-2 bg-neutral-50 dark:bg-neutral-800/80 border-t border-neutral-200 dark:border-neutral-700 text-[11px] text-neutral-500 flex justify-between items-center">
              <span>{rawText.length} characters • {rawText.split(/\s+/).filter(Boolean).length} words</span>
              <span>{sections.length} structural elements</span>
            </div>
          </div>
        ) : (
          /* Live Document Paper Preview */
          <div className="flex flex-col items-center py-2 space-y-4">
            <div
              className="w-full max-w-[500px] min-h-[640px] bg-white text-neutral-900 p-8 rounded-xl shadow-lg border border-neutral-200 transition-all"
              style={{
                fontFamily: styleSettings.fontFamily,
                fontSize: `${styleSettings.bodySize}pt`,
                lineHeight: styleSettings.lineSpacing,
                textAlign: styleSettings.alignment,
                paddingTop: `${styleSettings.margins.top * 28}px`,
                paddingBottom: `${styleSettings.margins.bottom * 28}px`,
                paddingLeft: `${styleSettings.margins.left * 28}px`,
                paddingRight: `${styleSettings.margins.right * 28}px`
              }}
            >
              {/* Document Header */}
              {styleSettings.headerText && (
                <div className="text-[10px] text-neutral-400 border-b border-neutral-200 pb-1 mb-4 text-right">
                  {styleSettings.headerText}
                </div>
              )}

              {/* Document Title */}
              <h1
                className="font-bold mb-4"
                style={{
                  fontSize: `${styleSettings.headingSize + 4}pt`,
                  color: styleSettings.accentColor
                }}
              >
                {documentTitle}
              </h1>

              {/* Sections rendering */}
              <div className="space-y-3">
                {sections.map((section, idx) => {
                  switch (section.type) {
                    case 'heading':
                      return (
                        <h2
                          key={idx}
                          className="font-bold mt-4 mb-2"
                          style={{
                            fontSize: `${styleSettings.headingSize}pt`,
                            color: styleSettings.accentColor
                          }}
                        >
                          {section.content}
                        </h2>
                      );
                    case 'subheading':
                      return (
                        <h3
                          key={idx}
                          className="font-bold mt-3 mb-1 text-neutral-800"
                          style={{ fontSize: `${styleSettings.headingSize - 3}pt` }}
                        >
                          {section.content}
                        </h3>
                      );
                    case 'bullet_list':
                      return (
                        <ul key={idx} className="list-disc pl-5 space-y-1">
                          {section.content.split('\n').filter(Boolean).map((li, lIdx) => (
                            <li key={lIdx}>{li.replace(/^[-*•]\s*/, '')}</li>
                          ))}
                        </ul>
                      );
                    case 'quote':
                      return (
                        <blockquote
                          key={idx}
                          className="border-l-4 pl-3 italic text-neutral-600 my-2"
                          style={{ borderColor: styleSettings.accentColor }}
                        >
                          {section.content}
                        </blockquote>
                      );
                    case 'table': {
                      const rows = section.content.split('\n').filter(Boolean);
                      return (
                        <div key={idx} className="overflow-x-auto my-3">
                          <table className="min-w-full border border-neutral-300 text-xs">
                            <tbody>
                              {rows.map((row, rIdx) => {
                                const cells = row.split('|').map(c => c.trim());
                                const isHead = rIdx === 0;
                                return (
                                  <tr key={rIdx} className={isHead ? 'bg-neutral-100 font-bold' : ''}>
                                    {cells.map((c, cIdx) => (
                                      <td key={cIdx} className="border border-neutral-300 px-2 py-1">
                                        {c}
                                      </td>
                                    ))}
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                      );
                    }
                    case 'paragraph':
                    default:
                      return (
                        <p
                          key={idx}
                          style={{
                            textIndent: styleSettings.indentFirstLine ? '1.5em' : '0',
                            marginBottom: `${styleSettings.paragraphSpacing}px`
                          }}
                        >
                          {section.content}
                        </p>
                      );
                  }
                })}
              </div>

              {/* Document Footer & Page Number */}
              <div className="mt-8 pt-3 border-t border-neutral-200 text-[10px] text-neutral-400 flex justify-between items-center">
                <span>{styleSettings.footerText}</span>
                {styleSettings.includePageNumbers && <span>Page 1 of 1</span>}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Floating Export Action Bar */}
      <div className="sticky bottom-0 px-4 py-3 bg-white/95 dark:bg-neutral-800/95 backdrop-blur-md border-t border-neutral-200 dark:border-neutral-700 flex items-center justify-between gap-3 shadow-lg">
        <button
          type="button"
          onClick={onBack}
          className="px-3 py-2 rounded-xl text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-xs font-semibold"
        >
          Cancel
        </button>

        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={isExporting}
            onClick={handleExportDocx}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all disabled:opacity-50"
            aria-label="Download DOCX"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download DOCX</span>
          </button>
          <button
            type="button"
            disabled={isExporting}
            onClick={() => handleExportPdf('pdf-lib')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-neutral-900 dark:bg-neutral-100 hover:bg-neutral-800 dark:hover:bg-neutral-200 text-white dark:text-neutral-900 font-bold text-xs shadow-md active:scale-95 transition-all disabled:opacity-50"
            aria-label="Download PDF"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download PDF</span>
          </button>
          <button
            type="button"
            onClick={() => setShowExportModal(true)}
            title="Download Options & Settings"
            aria-label="Download Options"
            className="p-2 rounded-xl bg-neutral-100 dark:bg-neutral-700 hover:bg-neutral-200 dark:hover:bg-neutral-600 text-neutral-700 dark:text-neutral-300 transition-colors"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Dedicated Export / Download Modal Dialog */}
      {showExportModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-sm rounded-3xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-neutral-100 dark:border-neutral-700 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-900/60 text-blue-600 dark:text-blue-300 flex items-center justify-center">
                  <Download className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
                    Download Document
                  </h3>
                  <p className="text-[10px] text-neutral-500">Save formatted file to device</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowExportModal(false)}
                className="p-1 rounded-full text-neutral-400 hover:bg-neutral-100 dark:hover:bg-neutral-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[10px] font-semibold text-neutral-500 uppercase mb-1">
                  File Name
                </label>
                <input
                  type="text"
                  value={documentTitle}
                  onChange={(e) => setDocumentTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-100 dark:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 text-neutral-900 dark:text-neutral-100 font-medium"
                />
              </div>

              <div>
                <label className="block text-[10px] font-semibold text-neutral-500 uppercase mb-1">
                  PDF Engine Library
                </label>
                <div className="grid grid-cols-2 gap-1.5 p-1 bg-neutral-100 dark:bg-neutral-700 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setExportPdfEngine('pdf-lib')}
                    className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                      exportPdfEngine === 'pdf-lib'
                        ? 'bg-white dark:bg-neutral-800 text-blue-600 dark:text-blue-400 shadow-xs'
                        : 'text-neutral-600 dark:text-neutral-300'
                    }`}
                  >
                    pdf-lib (Native)
                  </button>
                  <button
                    type="button"
                    onClick={() => setExportPdfEngine('jspdf')}
                    className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                      exportPdfEngine === 'jspdf'
                        ? 'bg-white dark:bg-neutral-800 text-blue-600 dark:text-blue-400 shadow-xs'
                        : 'text-neutral-600 dark:text-neutral-300'
                    }`}
                  >
                    jsPDF (Fast)
                  </button>
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <button
                  type="button"
                  disabled={isExporting}
                  onClick={() => {
                    setShowExportModal(false);
                    handleExportPdf(exportPdfEngine);
                  }}
                  className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-neutral-900 dark:bg-neutral-100 hover:bg-neutral-800 dark:hover:bg-neutral-200 text-white dark:text-neutral-900 font-bold text-xs shadow-md active:scale-95 transition-all"
                >
                  <Download className="w-4 h-4" />
                  <span>Download as .PDF ({exportPdfEngine === 'jspdf' ? 'jsPDF' : 'pdf-lib'})</span>
                </button>

                <button
                  type="button"
                  disabled={isExporting}
                  onClick={() => {
                    setShowExportModal(false);
                    handleExportDocx();
                  }}
                  className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all"
                >
                  <Download className="w-4 h-4" />
                  <span>Download as .DOCX (docx library)</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
