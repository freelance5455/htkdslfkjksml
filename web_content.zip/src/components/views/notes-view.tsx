import { useMemo, useState } from "react";
import { ChevronLeft, Trash2 } from "lucide-react";
import { Button, fieldClass, IconButton, useCopy } from "@/components/bits";
import { subjectName } from "@/lib/model";
import { useStudy } from "@/lib/store";

export function NotesView() {
  const { lang, t } = useCopy();
  const subjects = useStudy((s) => s.subjects);
  const notes = useStudy((s) => s.notes);
  const addNote = useStudy((s) => s.addNote);
  const updateNote = useStudy((s) => s.updateNote);
  const removeNote = useStudy((s) => s.removeNote);
  const [filter, setFilter] = useState<string>("all");
  const [query, setQuery] = useState("");
  const [activeId, setActiveId] = useState<string | null>(null);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return [...notes]
      .filter((note) => (filter === "all" ? true : note.subjectId === filter))
      .filter((note) => {
        if (!q) return true;
        return `${note.title} ${note.body}`.toLowerCase().includes(q);
      })
      .sort((a, b) => b.updatedAt - a.updatedAt);
  }, [notes, filter, query]);

  const active = notes.find((note) => note.id === activeId) ?? null;

  function create() {
    const subjectId = filter !== "all" ? filter : subjects[0]?.id;
    if (!subjectId) return;
    const id = addNote(subjectId);
    setActiveId(id);
  }

  return (
    <div className="flex flex-col gap-4 md:grid md:grid-cols-[16rem_minmax(0,1fr)] md:items-start md:gap-6">
      <div className={active ? "hidden md:block" : ""}>
        <div className="mb-4 flex items-center justify-between gap-3">
          <h1 className="text-3xl font-semibold">{t("notes")}</h1>
          <Button onClick={create} disabled={subjects.length === 0}>
            {t("newNote")}
          </Button>
        </div>
        <input
          className={fieldClass}
          value={query}
          placeholder={t("searchNotes")}
          onChange={(e) => setQuery(e.target.value)}
        />
        <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
          <FilterChip active={filter === "all"} onClick={() => setFilter("all")}>
            {t("allSubjects")}
          </FilterChip>
          {subjects.map((sub) => (
            <FilterChip key={sub.id} active={filter === sub.id} onClick={() => setFilter(sub.id)}>
              {subjectName(sub, lang)}
            </FilterChip>
          ))}
        </div>
        {visible.length === 0 ? (
          <p className="mt-4 text-sm text-muted">{t("noNotes")}</p>
        ) : (
          <ul className="mt-3 flex flex-col gap-2">
            {visible.map((note) => {
              const sub = subjects.find((item) => item.id === note.subjectId);
              const on = note.id === activeId;
              return (
                <li key={note.id}>
                  <button
                    type="button"
                    className={`w-full rounded-lg border px-3 py-3 text-left ${
                      on ? "border-primary bg-surface-2" : "border-border bg-surface"
                    }`}
                    onClick={() => setActiveId(note.id)}
                  >
                    <span className="block truncate font-semibold">{note.title}</span>
                    <span className="mt-1 block truncate text-sm text-muted">
                      {sub ? subjectName(sub, lang) : ""} ·{" "}
                      {new Date(note.updatedAt).toLocaleDateString(lang === "hi" ? "hi-IN" : "en-IN", {
                        day: "numeric",
                        month: "short",
                      })}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      <div className={!active ? "hidden md:block" : ""}>
        {active ? (
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-2 md:hidden">
              <IconButton aria-label={t("back")} onClick={() => setActiveId(null)}>
                <ChevronLeft className="size-5" />
              </IconButton>
              <p className="font-semibold">{t("notes")}</p>
            </div>
            <input
              className={fieldClass}
              value={active.title}
              aria-label={t("noteTitle")}
              onChange={(e) => updateNote(active.id, { title: e.target.value })}
            />
            <select
              className={fieldClass}
              value={active.subjectId}
              aria-label={t("subjects")}
              onChange={(e) => updateNote(active.id, { subjectId: e.target.value })}
            >
              {subjects.map((sub) => (
                <option key={sub.id} value={sub.id}>
                  {subjectName(sub, lang)}
                </option>
              ))}
            </select>
            <textarea
              className={`${fieldClass} min-h-64 resize-y leading-relaxed`}
              value={active.body}
              placeholder={t("noteBody")}
              onChange={(e) => updateNote(active.id, { body: e.target.value })}
            />
            <Button
              variant="ghost"
              onClick={() => {
                removeNote(active.id);
                setActiveId(null);
              }}
            >
              <Trash2 className="size-4" />
              {t("delete")}
            </Button>
          </div>
        ) : (
          <p className="hidden rounded-lg border border-border bg-surface px-4 py-10 text-center text-sm text-muted md:block">
            {t("pickNote")}
          </p>
        )}
      </div>
    </div>
  );
}

function FilterChip({
  active,
  children,
  onClick,
}: {
  active: boolean;
  children: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      className={`min-h-11 shrink-0 rounded-full border px-3 text-sm ${
        active ? "border-primary bg-primary text-primary-fg" : "border-border bg-surface text-fg"
      }`}
      onClick={onClick}
    >
      {children}
    </button>
  );
}
