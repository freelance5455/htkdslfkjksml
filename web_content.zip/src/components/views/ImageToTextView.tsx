import React, { useState, useRef } from 'react';
import {
  Camera,
  Image as ImageIcon,
  Copy,
  Download,
  FileCheck2,
  Check,
  RefreshCw,
  Globe,
  Sliders,
  Layers,
  Sparkles,
  AlertCircle,
  ScanText
} from 'lucide-react';
import { OcrResultItem } from '../../types';
import {
  performBatchOcr,
  SUPPORTED_OCR_LANGUAGES,
  performOcr
} from '../../utils/ocrService';
import { triggerFileDownload, saveStoredDocument } from '../../services/storageService';

interface ImageToTextViewProps {
  onBack: () => void;
  onNavigateToDocumentFormatter: (extractedText: string) => void;
}

export const ImageToTextView: React.FC<ImageToTextViewProps> = ({
  onBack,
  onNavigateToDocumentFormatter
}) => {
  const [selectedLanguage, setSelectedLanguage] = useState('eng');
  const [images, setImages] = useState<Array<{ name: string; dataUrl: string; file?: File }>>([]);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [ocrResults, setOcrResults] = useState<OcrResultItem[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progressStatus, setProgressStatus] = useState('');
  const [progressPercent, setProgressPercent] = useState(0);
  const [editedText, setEditedText] = useState('');
  const [copiedSuccess, setCopiedSuccess] = useState(false);

  // Camera state
  const [isCameraActive, setIsCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Handle image upload from file picker
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const files = Array.from(e.target.files);

    const loaded: Array<{ name: string; dataUrl: string; file: File }> = [];
    let processedCount = 0;

    files.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (ev) => {
        if (ev.target?.result) {
          loaded.push({
            name: file.name,
            dataUrl: ev.target.result as string,
            file
          });
        }
        processedCount++;
        if (processedCount === files.length) {
          setImages(loaded);
          setActiveImageIndex(0);
          runOcrOnImages(loaded, selectedLanguage);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  // Camera capture methods
  const startCamera = async () => {
    try {
      setIsCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1920 } },
        audio: false
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.error('Camera access error:', err);
      setIsCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  const capturePhoto = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 1280;
    canvas.height = videoRef.current.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
    stopCamera();

    const newPhoto = {
      name: `Photo_${Date.now()}.jpg`,
      dataUrl
    };

    const nextImages = [...images, newPhoto];
    setImages(nextImages);
    setActiveImageIndex(nextImages.length - 1);
    runOcrOnImages([newPhoto], selectedLanguage);
  };

  // Run OCR processing
  const runOcrOnImages = async (
    itemsToProcess: Array<{ name: string; dataUrl: string; file?: File }>,
    lang: string
  ) => {
    setIsProcessing(true);
    setProgressPercent(0);
    setProgressStatus('Initializing OCR engine...');

    try {
      const results = await performBatchOcr(itemsToProcess, lang, (p) => {
        setProgressStatus(p.status);
        setProgressPercent(Math.round(p.progress * 100));
      });

      setOcrResults((prev) => {
        const merged = [...prev, ...results];
        return merged;
      });

      // Combine text into editable view
      const combined = results.map((r) => r.extractedText).join('\n\n--- Next Document Page ---\n\n');
      setEditedText(combined);
    } catch (e: any) {
      console.error('OCR run failed:', e);
      setProgressStatus('OCR Error: ' + (e?.message || 'Processing failed'));
    } finally {
      setIsProcessing(false);
    }
  };

  // Copy to clipboard
  const handleCopyText = async () => {
    try {
      await navigator.clipboard.writeText(editedText);
      setCopiedSuccess(true);
      setTimeout(() => setCopiedSuccess(false), 2500);
    } catch (err) {
      console.error('Clipboard copy failed:', err);
    }
  };

  // Download TXT
  const handleDownloadTxt = () => {
    const blob = new Blob([editedText], { type: 'text/plain;charset=utf-8' });
    const fileName = `OCR_Extracted_${Date.now()}.txt`;
    triggerFileDownload(blob, fileName);

    saveStoredDocument({
      id: 'ocr-txt-' + Date.now(),
      name: fileName,
      type: 'txt',
      sizeBytes: blob.size,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      blobData: blob,
      sourceFeature: 'Image to Text'
    });
  };

  const currentResult = ocrResults[activeImageIndex];

  return (
    <div className="flex-1 flex flex-col h-full bg-neutral-50 dark:bg-neutral-900 pb-16">
      {/* Top Config Ribbon */}
      <div className="px-4 py-2.5 bg-white dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-neutral-500" />
          <select
            value={selectedLanguage}
            onChange={(e) => setSelectedLanguage(e.target.value)}
            disabled={isProcessing}
            className="text-xs px-2.5 py-1.5 rounded-xl bg-neutral-100 dark:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 text-neutral-900 dark:text-neutral-100 font-medium"
          >
            {SUPPORTED_OCR_LANGUAGES.map((l) => (
              <option key={l.code} value={l.code}>
                {l.name}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          {/* File Picker button */}
          <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 text-xs font-bold active:scale-95 transition-all">
            <ImageIcon className="w-3.5 h-3.5" />
            <span>Select Images</span>
            <input
              type="file"
              multiple
              accept="image/*"
              className="hidden"
              onChange={handleFileUpload}
            />
          </label>

          {/* Camera Capture button */}
          <button
            type="button"
            onClick={startCamera}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-100 dark:bg-neutral-700 hover:bg-neutral-200 dark:hover:bg-neutral-600 text-neutral-800 dark:text-neutral-200 text-xs font-bold active:scale-95 transition-all"
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Camera</span>
          </button>
        </div>
      </div>

      {/* Live Camera View Modal */}
      {isCameraActive && (
        <div className="fixed inset-0 z-50 bg-black/90 flex flex-col items-center justify-between p-4">
          <div className="w-full flex justify-between items-center text-white text-xs font-semibold">
            <span>Point camera steadily at document or text</span>
            <button
              type="button"
              onClick={stopCamera}
              className="px-3 py-1 rounded-full bg-white/20"
            >
              Cancel
            </button>
          </div>

          <div className="relative w-full max-w-sm aspect-[3/4] rounded-2xl overflow-hidden border-2 border-white/40 shadow-2xl">
            <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
            {/* Guide overlay */}
            <div className="absolute inset-4 border-2 border-dashed border-white/60 rounded-xl pointer-events-none" />
          </div>

          <div className="pb-6">
            <button
              type="button"
              onClick={capturePhoto}
              className="w-16 h-16 rounded-full bg-white text-neutral-900 border-4 border-blue-500 shadow-xl flex items-center justify-center active:scale-90 transition-transform"
            >
              <Camera className="w-7 h-7 text-blue-600" />
            </button>
          </div>
        </div>
      )}

      {/* Processing Status Bar */}
      {isProcessing && (
        <div className="px-4 py-3 bg-blue-50 dark:bg-blue-950/70 border-b border-blue-200 dark:border-blue-800 space-y-1.5">
          <div className="flex justify-between text-xs text-blue-800 dark:text-blue-300 font-semibold">
            <span className="flex items-center gap-1.5">
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>{progressStatus}</span>
            </span>
            <span>{progressPercent}%</span>
          </div>
          <div className="w-full bg-blue-200 dark:bg-blue-900 h-1.5 rounded-full overflow-hidden">
            <div
              className="bg-blue-600 h-full rounded-full transition-all duration-200"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      )}

      {/* Main OCR Content */}
      <div className="flex-1 p-3 overflow-y-auto space-y-4">
        {images.length === 0 ? (
          <div className="text-center py-16 px-6 rounded-3xl border-2 border-dashed border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800/40 space-y-4">
            <div className="w-16 h-16 mx-auto rounded-3xl bg-blue-50 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center shadow-xs">
              <ScanText className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
                Capture or Select Images for OCR
              </h3>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 max-w-xs mx-auto mt-1">
                Extract printed and handwritten text with paragraph and table recognition.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {/* Multi-image thumbnail strip */}
            {images.length > 1 && (
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setActiveImageIndex(idx)}
                    className={`relative w-16 h-16 rounded-xl overflow-hidden border-2 shrink-0 transition-all ${
                      activeImageIndex === idx
                        ? 'border-blue-600 scale-105 shadow-md'
                        : 'border-transparent opacity-60'
                    }`}
                  >
                    <img src={img.dataUrl} alt={img.name} className="w-full h-full object-cover" />
                    <span className="absolute bottom-0 right-0 px-1 bg-black/70 text-[9px] text-white font-bold rounded-tl">
                      {idx + 1}
                    </span>
                  </button>
                ))}
              </div>
            )}

            {/* Confidence & stats badge */}
            {currentResult && (
              <div className="flex items-center justify-between text-xs px-3 py-1.5 rounded-xl bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700">
                <span className="font-semibold text-neutral-700 dark:text-neutral-300">
                  {currentResult.imageName}
                </span>
                <span
                  className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                    currentResult.confidence > 85
                      ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300'
                      : 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300'
                  }`}
                >
                  {currentResult.confidence}% Confidence
                </span>
              </div>
            )}

            {/* Editable OCR text area */}
            <div className="bg-white dark:bg-neutral-800 rounded-2xl border border-neutral-200 dark:border-neutral-700 shadow-xs overflow-hidden flex flex-col">
              <div className="px-4 py-2 bg-neutral-50 dark:bg-neutral-800/80 border-b border-neutral-200 dark:border-neutral-700 flex justify-between items-center text-xs">
                <span className="font-bold text-neutral-700 dark:text-neutral-300">
                  Extracted Text Editor (Editable)
                </span>
                <span className="text-[11px] text-neutral-400">
                  Correct any OCR typos before export
                </span>
              </div>

              <textarea
                value={editedText}
                onChange={(e) => setEditedText(e.target.value)}
                placeholder="Extracted text will appear here..."
                rows={12}
                className="w-full p-4 bg-transparent text-neutral-900 dark:text-neutral-100 font-sans text-xs leading-relaxed focus:outline-none resize-none"
              />
            </div>
          </div>
        )}
      </div>

      {/* Floating Action Ribbon */}
      <div className="sticky bottom-0 px-4 py-3 bg-white/95 dark:bg-neutral-800/95 backdrop-blur-md border-t border-neutral-200 dark:border-neutral-700 flex items-center justify-between gap-2 shadow-lg">
        <button
          type="button"
          onClick={onBack}
          className="px-3 py-2 rounded-xl text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-xs font-semibold"
        >
          Back
        </button>

        <div className="flex items-center gap-2">
          {/* Copy Plain Text */}
          <button
            type="button"
            disabled={!editedText}
            onClick={handleCopyText}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-neutral-100 dark:bg-neutral-700 hover:bg-neutral-200 dark:hover:bg-neutral-600 text-neutral-800 dark:text-neutral-200 font-bold text-xs active:scale-95 transition-all disabled:opacity-40"
          >
            {copiedSuccess ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-500" />
                <span>Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy</span>
              </>
            )}
          </button>

          {/* TXT Export */}
          <button
            type="button"
            disabled={!editedText}
            onClick={handleDownloadTxt}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-neutral-100 dark:bg-neutral-700 hover:bg-neutral-200 dark:hover:bg-neutral-600 text-neutral-800 dark:text-neutral-200 font-bold text-xs active:scale-95 transition-all disabled:opacity-40"
          >
            <Download className="w-3.5 h-3.5" />
            <span>TXT</span>
          </button>

          {/* Format as DOCX/PDF with Full Engine */}
          <button
            type="button"
            disabled={!editedText}
            onClick={() => onNavigateToDocumentFormatter(editedText)}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all disabled:opacity-40"
          >
            <FileCheck2 className="w-3.5 h-3.5" />
            <span>Format as DOCX / PDF</span>
          </button>
        </div>
      </div>
    </div>
  );
};
