import { Pause, Play, RotateCcw, Volume2, VolumeX } from "lucide-react";
import { Button, useCopy } from "@/components/bits";
import { chime } from "@/lib/chime";
import { durationFor, formatClock, subjectName, todayMinutes, type TimerMode } from "@/lib/model";
import { useStudy } from "@/lib/store";

const MODES: TimerMode[] = ["focus", "short", "long"];

export function TimerView() {
  const { lang, t } = useCopy();
  const subjects = useStudy((s) => s.subjects);
  const sessions = useStudy((s) => s.sessions);
  const timer = useStudy((s) => s.timer);
  const sound = useStudy((s) => s.sound);
  const toggleSound = useStudy((s) => s.toggleSound);
  const setTimerSubject = useStudy((s) => s.setTimerSubject);
  const setMode = useStudy((s) => s.setMode);
  const nudgeFocus = useStudy((s) => s.nudgeFocus);
  const startTimer = useStudy((s) => s.startTimer);
  const pauseTimer = useStudy((s) => s.pauseTimer);
  const resetTimer = useStudy((s) => s.resetTimer);
  const stopAndSave = useStudy((s) => s.stopAndSave);

  const ratio = timer.durationSec === 0 ? 0 : timer.remainingSec / timer.durationSec;
  const radius = 52;
  const circ = 2 * Math.PI * radius;
  const locked = timer.status === "running";
  const elapsed = timer.durationSec - timer.remainingSec;
  const modeLabel =
    timer.mode === "focus" ? t("focus") : timer.mode === "short" ? t("shortBreak") : t("longBreak");
  const ring = timer.mode === "focus" ? "stroke-primary" : "stroke-accent";

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-semibold">{t("timer")}</h1>
        <button
          type="button"
          className="grid h-11 w-11 place-items-center rounded-md hover:bg-surface-2"
          aria-label={sound ? t("soundOn") : t("soundOff")}
          onClick={() => {
            toggleSound();
            if (!sound) chime();
          }}
        >
          {sound ? <Volume2 className="size-5" /> : <VolumeX className="size-5 text-muted" />}
        </button>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {subjects.map((sub) => {
          const active = timer.subjectId === sub.id;
          return (
            <button
              key={sub.id}
              type="button"
              className={`min-h-11 shrink-0 rounded-full border px-4 text-sm font-medium ${
                active ? "border-primary bg-primary text-primary-fg" : "border-border bg-surface text-fg"
              }`}
              onClick={() => setTimerSubject(sub.id)}
            >
              {subjectName(sub, lang)}
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-3 gap-2">
        {MODES.map((mode) => {
          const active = timer.mode === mode;
          const label = mode === "focus" ? t("focus") : mode === "short" ? t("shortBreak") : t("longBreak");
          const mins = Math.round(durationFor(mode, timer.focusMin) / 60);
          return (
            <button
              key={mode}
              type="button"
              disabled={locked}
              className={`min-h-11 rounded-md border px-2 text-sm font-medium disabled:opacity-50 ${
                active ? "border-primary bg-surface-2 text-fg" : "border-border bg-surface text-muted"
              }`}
              onClick={() => setMode(mode)}
            >
              {label}
              <span className="mt-0.5 block text-xs tabular-nums opacity-80">{mins}</span>
            </button>
          );
        })}
      </div>

      <div className="relative mx-auto grid h-64 w-64 place-items-center">
        <svg viewBox="0 0 120 120" className="h-64 w-64" aria-hidden="true">
          <circle cx="60" cy="60" r={radius} className="stroke-surface-2" strokeWidth="8" fill="none" />
          <circle
            cx="60"
            cy="60"
            r={radius}
            className={ring}
            strokeWidth="8"
            fill="none"
            strokeLinecap="round"
            strokeDasharray={circ}
            strokeDashoffset={circ * (1 - ratio)}
            transform="rotate(-90 60 60)"
          />
        </svg>
        <div className="absolute inset-0 grid place-items-center text-center">
          <div>
            <p className="text-6xl font-semibold tabular-nums tracking-tight">{formatClock(timer.remainingSec)}</p>
            <p className="mt-1 text-sm text-muted">{modeLabel}</p>
          </div>
        </div>
      </div>

      {timer.mode === "focus" ? (
        <div className="flex items-center justify-center gap-3">
          <button
            type="button"
            className="grid h-11 w-11 place-items-center rounded-md border border-border disabled:opacity-40"
            aria-label={t("shorter")}
            disabled={locked}
            onClick={() => nudgeFocus(-5)}
          >
            −
          </button>
          <span className="min-w-24 text-center text-sm tabular-nums">
            {timer.focusMin} {t("minutesWord")}
          </span>
          <button
            type="button"
            className="grid h-11 w-11 place-items-center rounded-md border border-border disabled:opacity-40"
            aria-label={t("longer")}
            disabled={locked}
            onClick={() => nudgeFocus(5)}
          >
            +
          </button>
        </div>
      ) : null}

      {timer.status === "done" ? (
        <div className="rounded-lg border border-border bg-surface px-4 py-4 text-center">
          <p className="text-lg font-semibold">{t("doneTitle")}</p>
          <p className="mt-1 text-sm text-muted">{timer.mode === "focus" ? t("doneFocus") : t("doneBreak")}</p>
          <div className="mt-4 flex flex-wrap justify-center gap-2">
            <Button onClick={() => { setMode("focus"); startTimer(); }}>{t("again")}</Button>
            {timer.mode === "focus" ? (
              <Button
                variant="surface"
                onClick={() => {
                  setMode("short");
                  startTimer();
                }}
              >
                {t("startBreak")}
              </Button>
            ) : null}
          </div>
        </div>
      ) : (
        <div className="flex flex-wrap items-center justify-center gap-2">
          {timer.status === "running" ? (
            <Button onClick={pauseTimer}>
              <Pause className="size-4" />
              {t("pause")}
            </Button>
          ) : (
            <Button onClick={startTimer}>
              <Play className="size-4" />
              {timer.status === "paused" ? t("resume") : t("start")}
            </Button>
          )}
          <Button variant="surface" onClick={resetTimer}>
            <RotateCcw className="size-4" />
            {t("reset")}
          </Button>
        </div>
      )}

      {timer.mode === "focus" && elapsed >= 60 && timer.status !== "idle" && timer.status !== "done" ? (
        <button type="button" className="text-center text-sm text-primary" onClick={stopAndSave}>
          {t("saveStop")}
        </button>
      ) : null}

      <p className="text-center text-sm text-muted">
        {t("todayStudy")}: {todayMinutes(sessions)} {t("minutesWord")}
      </p>
    </div>
  );
}
