import React, { useState } from 'react';
import { useParentControl } from '../../context/ParentControlContext';
import { 
  Sliders, Wifi, Bluetooth, Radio, Plane, 
  MapPin, Moon, Sun, Volume2, Volume1, VolumeX, 
  Lock, Unlock, RotateCcw, AlertTriangle, ShieldAlert,
  Clock, Sparkles, CheckCircle2, Flame, BellRing
} from 'lucide-react';

export const DeviceSettingsView: React.FC = () => {
  const { 
    activeDevice, 
    language, 
    toggleHardwareSetting, 
    updateSliderSetting,
    setDeviceLockdown,
    triggerEmergencySiren,
    stopEmergencySiren,
    sirenPlaying,
    showToast
  } = useParentControl();

  const [lockMsgInput, setLockMsgInput] = useState(activeDevice?.settings.lockMessage || '');
  const [showRebootModal, setShowRebootModal] = useState(false);
  const [rebootInProgress, setRebootInProgress] = useState(false);

  if (!activeDevice) return null;

  const isAr = language === 'ar';
  const settings = activeDevice.settings;
  const isLocked = settings.screenLocked;

  const handleApplyLockMessage = () => {
    setDeviceLockdown(isLocked, lockMsgInput);
    showToast(
      isAr ? 'تم حفظ وتحديث رسالة القفل على هاتف الطفل بنجاح' : 'Lock message updated on child phone',
      'success'
    );
  };

  const handleRemoteReboot = () => {
    setRebootInProgress(true);
    setTimeout(() => {
      setRebootInProgress(false);
      setShowRebootModal(false);
      showToast(
        isAr ? 'تم إرسال أمر إعادة تشغيل الجهاز بنجاح' : 'Remote reboot command executed',
        'info'
      );
    }, 2500);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs transition-colors duration-200">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Sliders className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
              <span>{isAr ? 'التحكم الشامل في إعدادات هاتف الطفل عن بُعد' : 'Remote Device Settings & Hardware Controls'}</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {isAr 
                ? `تعديل الشبكات، الاتصال، الصوت، السطوع، وحظر الميزات لهاتف ${activeDevice.childNameAr} (${activeDevice.deviceName})`
                : `Manage radios, connectivity, volumes, brightness, and policies for ${activeDevice.childName}'s phone`}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowRebootModal(true)}
              className="px-4 py-2 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 hover:text-slate-900 dark:hover:text-white text-xs sm:text-sm font-semibold rounded-xl border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <RotateCcw className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span>{isAr ? 'إعادة تشغيل الجهاز' : 'Remote Reboot'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Grid: Instant Lock & Bedtime Schedule */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Instant Screen Lock Box */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <div className={`p-2 rounded-xl ${isLocked ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400' : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'}`}>
                {isLocked ? <Lock className="w-5 h-5" /> : <Unlock className="w-5 h-5" />}
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {isAr ? 'القفل الفوري لشاشة الهاتف' : 'Instant Device Lockdown'}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {isLocked ? (isAr ? 'الشاشة مقفلة الآن بكلمة سر الوالدين' : 'Device is currently locked') : (isAr ? 'الجهاز مفتوح ومتاح للاستخدام' : 'Device is currently unlocked')}
                </p>
              </div>
            </div>

            <button
              id="settings-screen-lock-btn"
              onClick={() => setDeviceLockdown(!isLocked, lockMsgInput)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all shadow-xs active:scale-95 ${
                isLocked 
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white' 
                  : 'bg-rose-600 hover:bg-rose-700 text-white'
              }`}
            >
              {isLocked ? (isAr ? 'إلغاء القفل' : 'Unlock Phone') : (isAr ? 'قفل فوراً' : 'Lock Now')}
            </button>
          </div>

          {/* Custom Message input */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              {isAr ? 'الرسالة التي تظهر على شاشة هاتف الطفل عند القفل:' : 'Display message when locked:'}
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={lockMsgInput}
                onChange={(e) => setLockMsgInput(e.target.value)}
                placeholder={isAr ? 'مثال: حان وقت الصلاة / المذاكرة، تم إيقاف الهاتف مؤقتاً' : 'e.g. Bedtime! Phone locked.'}
                className="flex-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-900"
              />
              <button
                onClick={handleApplyLockMessage}
                className="px-3.5 py-2 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 text-xs font-semibold rounded-xl transition-colors shadow-xs"
              >
                {isAr ? 'تحديث' : 'Update'}
              </button>
            </div>
          </div>
        </div>

        {/* Bedtime Curfew Schedule */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
                <Moon className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {isAr ? 'جدول موعد النوم الليلي (Bedtime Curfew)' : 'Bedtime Curfew Schedule'}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {isAr ? 'قفل الهاتف تلقائياً خلال ساعات النوم المحددة' : 'Auto-lock device during sleep hours'}
                </p>
              </div>
            </div>

            <button
              onClick={() => toggleHardwareSetting('bedtimeActive')}
              className={`w-12 h-6 flex items-center rounded-full p-1 transition-colors ${
                settings.bedtimeActive ? 'bg-indigo-600 justify-end' : 'bg-slate-200 dark:bg-slate-700 justify-start'
              }`}
            >
              <span className="bg-white w-4 h-4 rounded-full shadow-xs" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium block">
                {isAr ? 'بداية القفل الليلي:' : 'Lock Starts at:'}
              </span>
              <span className="text-lg font-bold text-slate-900 dark:text-white font-mono mt-1 block">
                {settings.bedtimeStart} {isAr ? 'مساءً' : 'PM'}
              </span>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium block">
                {isAr ? 'إعادة الفتح صباحاً:' : 'Unlock at Morning:'}
              </span>
              <span className="text-lg font-bold text-slate-900 dark:text-white font-mono mt-1 block">
                {settings.bedtimeEnd} {isAr ? 'صباحاً' : 'AM'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Hardware Radios & Connectivity Grid */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs space-y-4">
        <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Wifi className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
          <span>{isAr ? 'التحكم في الشبكات والمستشعرات اللاسلكية' : 'Wireless Radios & Network Toggles'}</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* WiFi Toggle */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2.5 rounded-xl ${settings.wifiEnabled ? 'bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400' : 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500'}`}>
                <Wifi className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-900 dark:text-white">WiFi</p>
                <span className="text-[10px] text-slate-500 dark:text-slate-400">
                  {settings.wifiEnabled ? (isAr ? 'مفعل ومتصل' : 'Enabled') : (isAr ? 'معطل' : 'Disabled')}
                </span>
              </div>
            </div>
            <button
              id="toggle-wifi-btn"
              onClick={() => toggleHardwareSetting('wifiEnabled')}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                settings.wifiEnabled ? 'bg-indigo-600 justify-end' : 'bg-slate-200 dark:bg-slate-700 justify-start'
              }`}
            >
              <span className="bg-white w-4 h-4 rounded-full shadow-xs" />
            </button>
          </div>

          {/* Bluetooth Toggle */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2.5 rounded-xl ${settings.bluetoothEnabled ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400' : 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500'}`}>
                <Bluetooth className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-900 dark:text-white">Bluetooth</p>
                <span className="text-[10px] text-slate-500 dark:text-slate-400">
                  {settings.bluetoothEnabled ? (isAr ? 'مفعل' : 'Enabled') : (isAr ? 'معطل' : 'Disabled')}
                </span>
              </div>
            </div>
            <button
              id="toggle-bluetooth-btn"
              onClick={() => toggleHardwareSetting('bluetoothEnabled')}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                settings.bluetoothEnabled ? 'bg-indigo-600 justify-end' : 'bg-slate-200 dark:bg-slate-700 justify-start'
              }`}
            >
              <span className="bg-white w-4 h-4 rounded-full shadow-xs" />
            </button>
          </div>

          {/* Cellular 5G/4G Data */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2.5 rounded-xl ${settings.cellularDataEnabled ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400' : 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500'}`}>
                <Radio className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-900 dark:text-white">{isAr ? 'بيانات الجوال 5G' : 'Cellular Data'}</p>
                <span className="text-[10px] text-slate-500 dark:text-slate-400">
                  {settings.cellularDataEnabled ? (isAr ? 'مفعل' : 'Enabled') : (isAr ? 'معطل' : 'Disabled')}
                </span>
              </div>
            </div>
            <button
              id="toggle-cellular-data-btn"
              onClick={() => toggleHardwareSetting('cellularDataEnabled')}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                settings.cellularDataEnabled ? 'bg-indigo-600 justify-end' : 'bg-slate-200 dark:bg-slate-700 justify-start'
              }`}
            >
              <span className="bg-white w-4 h-4 rounded-full shadow-xs" />
            </button>
          </div>

          {/* Airplane Mode */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2.5 rounded-xl ${settings.airplaneMode ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400' : 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500'}`}>
                <Plane className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-900 dark:text-white">{isAr ? 'وضع الطيران' : 'Airplane Mode'}</p>
                <span className="text-[10px] text-slate-500 dark:text-slate-400">
                  {settings.airplaneMode ? (isAr ? 'مفعل' : 'Enabled') : (isAr ? 'معطل' : 'Disabled')}
                </span>
              </div>
            </div>
            <button
              id="toggle-airplane-mode-btn"
              onClick={() => toggleHardwareSetting('airplaneMode')}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                settings.airplaneMode ? 'bg-amber-500 justify-end' : 'bg-slate-200 dark:bg-slate-700 justify-start'
              }`}
            >
              <span className="bg-white w-4 h-4 rounded-full shadow-xs" />
            </button>
          </div>
        </div>
      </div>

      {/* Audio Volumes & Brightness Sliders */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Remote Volume Levels */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <span>{isAr ? 'التحكم في مستويات الصوت عن بُعد' : 'Remote Volume Controls'}</span>
          </h3>

          <div className="space-y-4">
            {/* Media Volume */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-slate-700 dark:text-slate-300 font-medium">{isAr ? 'صوت الوسائط والألعاب (Media)' : 'Media Volume'}</span>
                <span className="font-mono text-indigo-600 dark:text-indigo-400 font-bold">{settings.volumeMedia}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.volumeMedia}
                onChange={(e) => updateSliderSetting('volumeMedia', Number(e.target.value))}
                className="w-full accent-indigo-600 cursor-pointer"
              />
            </div>

            {/* Ringtone Volume */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-slate-700 dark:text-slate-300 font-medium">{isAr ? 'صوت نغمة الرنين (Ringtone)' : 'Ringtone Volume'}</span>
                <span className="font-mono text-indigo-600 dark:text-indigo-400 font-bold">{settings.volumeRing}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.volumeRing}
                onChange={(e) => updateSliderSetting('volumeRing', Number(e.target.value))}
                className="w-full accent-indigo-600 cursor-pointer"
              />
            </div>

            {/* Alarm Volume */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-slate-700 dark:text-slate-300 font-medium">{isAr ? 'صوت المنبه والتنبيهات (Alarm)' : 'Alarm Volume'}</span>
                <span className="font-mono text-indigo-600 dark:text-indigo-400 font-bold">{settings.volumeAlarm}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.volumeAlarm}
                onChange={(e) => updateSliderSetting('volumeAlarm', Number(e.target.value))}
                className="w-full accent-indigo-600 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Screen Brightness & Display Controls */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Sun className="w-5 h-5 text-amber-500" />
            <span>{isAr ? 'التحكم في سطوع الشاشة والعرض' : 'Screen Brightness & Display'}</span>
          </h3>

          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-slate-700 dark:text-slate-300 font-medium">{isAr ? 'نسبة السطوع الحالية' : 'Brightness Level'}</span>
                <span className="font-mono text-amber-600 dark:text-amber-400 font-bold">{settings.brightness}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="100"
                value={settings.brightness}
                onChange={(e) => updateSliderSetting('brightness', Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700">
              <div>
                <p className="text-xs font-bold text-slate-900 dark:text-white">{isAr ? 'السطوع التلقائي التكيفي' : 'Adaptive Brightness'}</p>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">{isAr ? 'يتكيف تلقائياً مع إضاءة الغرفة' : 'Auto adjusts to ambient light'}</p>
              </div>
              <button
                onClick={() => toggleHardwareSetting('autoBrightness')}
                className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                  settings.autoBrightness ? 'bg-indigo-600 justify-end' : 'bg-slate-200 dark:bg-slate-700 justify-start'
                }`}
              >
                <span className="bg-white w-4 h-4 rounded-full shadow-xs" />
              </button>
            </div>

            <div className="flex items-center justify-between p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700">
              <div>
                <p className="text-xs font-bold text-slate-900 dark:text-white">{isAr ? 'وضع عدم الإزعاج (DND)' : 'Do Not Disturb'}</p>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">{isAr ? 'كتم كافة الإشعارات والمكالمات' : 'Mutes all notifications'}</p>
              </div>
              <button
                onClick={() => toggleHardwareSetting('doNotDisturb')}
                className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                  settings.doNotDisturb ? 'bg-indigo-600 justify-end' : 'bg-slate-200 dark:bg-slate-700 justify-start'
                }`}
              >
                <span className="bg-white w-4 h-4 rounded-full shadow-xs" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Reboot Modal */}
      {showRebootModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 w-full max-w-sm shadow-xl space-y-4 text-center">
            <div className="w-14 h-14 rounded-2xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 mx-auto flex items-center justify-center">
              <RotateCcw className={`w-8 h-8 ${rebootInProgress ? 'animate-spin' : ''}`} />
            </div>

            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              {isAr ? 'تأكيد إعادة تشغيل هاتف الطفل عن بُعد؟' : 'Reboot Child Device Remotely?'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {isAr 
                ? 'سيتم إرسال أمر فوري لنظام التشغيل لإعادة التشغيل وإعادة الاتصال بخوادم ParentGuard تلقائياً.'
                : 'The device will reboot and reconnect securely to ParentGuard.'}
            </p>

            <div className="flex items-center gap-2 pt-2">
              <button
                disabled={rebootInProgress}
                onClick={handleRemoteReboot}
                className="flex-1 py-2.5 bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white text-xs font-semibold rounded-xl transition-colors shadow-xs"
              >
                {rebootInProgress ? (isAr ? 'جارٍ إعادة التشغيل...' : 'Rebooting...') : (isAr ? 'نعم، أعد التشغيل' : 'Yes, Reboot')}
              </button>
              <button
                disabled={rebootInProgress}
                onClick={() => setShowRebootModal(false)}
                className="py-2.5 px-4 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-medium rounded-xl border border-slate-200 dark:border-slate-700 shadow-xs"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
