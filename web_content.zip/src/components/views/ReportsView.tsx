import React, { useState } from 'react';
import { Transaction, Category, Account, AppSettings } from '../../types';
import { ReportsTab } from './reports/ReportsTab';
import { SummaryTab } from './reports/SummaryTab';
import { ChartsTab } from './reports/ChartsTab';
import { ExportReportModal } from '../ExportReportModal';
import {
  FileText,
  CalendarDays,
  PieChart,
  Download,
} from 'lucide-react';

interface ReportsViewProps {
  transactions: Transaction[];
  categories: Category[];
  accounts?: Account[];
  useBanglaDigits: boolean;
  appSettings: AppSettings;
  onBack?: () => void;
}

type MainTab = 'reports' | 'summary' | 'charts';

export const ReportsView: React.FC<ReportsViewProps> = ({
  transactions = [],
  categories = [],
  accounts = [],
  useBanglaDigits,
  appSettings,
  onBack,
}) => {
  const [activeMainTab, setActiveMainTab] = useState<MainTab>('reports');
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);

  const isEn = appSettings.language === 'en';
  const isLight = appSettings.themeMode === 'light';

  const headingText = isLight ? 'text-slate-900' : 'text-slate-100';

  return (
    <div className="space-y-5 pb-10">
      {/* Top Header: Heading on left, Export button on right */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <h1 className={`text-xl font-black flex items-center gap-2 truncate ${headingText}`}>
            <PieChart className="w-5 h-5 text-emerald-500 shrink-0" />
            <span>{isEn ? 'Reports & Charts' : 'রিপোর্টস ও চার্টস'}</span>
          </h1>
        </div>

        {/* Export Button on the right corner */}
        <button
          onClick={() => setIsExportModalOpen(true)}
          className={`px-3 sm:px-3.5 py-2 border rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shrink-0 cursor-pointer ${
            isLight
              ? 'bg-white border-slate-200 hover:bg-slate-50 text-slate-800 shadow-xs'
              : 'bg-slate-800 border-slate-700 hover:bg-slate-700 text-slate-200 shadow-xs'
          }`}
          title={isEn ? 'Export Reports' : 'রিপোর্ট এক্সপোর্ট'}
          id="btn-reports-export"
        >
          <Download className="w-4 h-4 text-emerald-500" />
          <span className="whitespace-nowrap">{isEn ? 'Export' : 'এক্সপোর্ট'}</span>
        </button>
      </div>

      {/* THREE MAIN TOP BUTTONS: রিপোর্টস, সামারি, চার্টস (ব্যবহারকারীর রিকুয়েস্ট অনুযায়ী) */}
      <div
        className={`p-1.5 rounded-2xl border grid grid-cols-3 gap-1.5 shadow-sm ${
          isLight ? 'bg-slate-100/90 border-slate-200' : 'bg-slate-800/80 border-slate-700'
        }`}
      >
        <button
          onClick={() => setActiveMainTab('reports')}
          className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-black transition-all flex items-center justify-center gap-2 ${
            activeMainTab === 'reports'
              ? 'bg-emerald-600 text-white shadow-md'
              : isLight
              ? 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>{isEn ? 'Reports' : 'রিপোর্টস'}</span>
        </button>

        <button
          onClick={() => setActiveMainTab('summary')}
          className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-black transition-all flex items-center justify-center gap-2 ${
            activeMainTab === 'summary'
              ? 'bg-emerald-600 text-white shadow-md'
              : isLight
              ? 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
          }`}
        >
          <CalendarDays className="w-4 h-4" />
          <span>{isEn ? 'Summary' : 'সামারি'}</span>
        </button>

        <button
          onClick={() => setActiveMainTab('charts')}
          className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-black transition-all flex items-center justify-center gap-2 ${
            activeMainTab === 'charts'
              ? 'bg-emerald-600 text-white shadow-md'
              : isLight
              ? 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
          }`}
        >
          <PieChart className="w-4 h-4" />
          <span>{isEn ? 'Charts' : 'চার্টস'}</span>
        </button>
      </div>

      {/* TAB CONTENT */}
      {activeMainTab === 'reports' && (
        <ReportsTab
          transactions={transactions}
          categories={categories}
          accounts={accounts}
          appSettings={appSettings}
          useBanglaDigits={useBanglaDigits}
        />
      )}

      {activeMainTab === 'summary' && (
        <SummaryTab
          transactions={transactions}
          appSettings={appSettings}
          useBanglaDigits={useBanglaDigits}
        />
      )}

      {activeMainTab === 'charts' && (
        <ChartsTab
          transactions={transactions}
          categories={categories}
          appSettings={appSettings}
          useBanglaDigits={useBanglaDigits}
        />
      )}

      {/* Settings' Export Report Modal */}
      <ExportReportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        transactions={transactions}
        categories={categories}
        accounts={accounts}
        appSettings={appSettings}
      />
    </div>
  );
};
