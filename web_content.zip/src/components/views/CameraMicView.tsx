import React, { useState, useEffect, useRef } from 'react';
import { useParentControl } from '../../context/ParentControlContext';
import { 
  Camera, Mic, Volume2, Video, VideoOff, RotateCcw, 
  Flashlight, Download, Radio, Shield, Sparkles, 
  Eye, RefreshCw, AlertCircle, Play, Square, CheckCircle
} from 'lucide-react';

export const CameraMicView: React.FC = () => {
  const { 
    activeDevice, 
    language, 
    isLiveCameraStreaming, 
    startCameraStream, 
    stopCameraStream,
    cameraFacing,
    toggleCameraFacing,
    isFlashlightActive,
    toggleFlashlight,
    isMicListening,
    startMicListening,
    stopMicListening,
    micDecibels,
    showToast
  } = useParentControl();

  const [activeSubTab, setActiveSubTab] = useState<'camera' | 'mic' | 'screen'>('camera');
  const [useRealWebcam, setUseRealWebcam] = useState(false);
  const [useRealMic, setUseRealMic] = useState(false);
  const [snapshots, setSnapshots] = useState<string[]>([]);
  const [isRecordingVideo, setIsRecordingVideo] = useState(false);
  const [recordTimer, setRecordTimer] = useState(0);
  const [audioRecordings, setAudioRecordings] = useState<{ id: string; time: string; duration: string }[]>([]);
  
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);

  const isAr = language === 'ar';

  // Video recording timer
  useEffect(() => {
    let interval: any;
    if (isRecordingVideo) {
      interval = setInterval(() => setRecordTimer(t => t + 1), 1000);
    } else {
      setRecordTimer(0);
    }
    return () => clearInterval(interval);
  }, [isRecordingVideo]);

  // Real Webcam handler
  useEffect(() => {
    if (useRealWebcam && isLiveCameraStreaming) {
      navigator.mediaDevices?.getUserMedia({ 
        video: { facingMode: cameraFacing } 
      }).then((stream) => {
        mediaStreamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      }).catch((err) => {
        console.warn('Webcam permission not granted or unavailable:', err);
        setUseRealWebcam(false);
      });
    } else {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
        mediaStreamRef.current = null;
      }
    }

    return () => {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, [useRealWebcam, isLiveCameraStreaming, cameraFacing]);

  // Take Snapshot
  const handleTakeSnapshot = () => {
    let snapUrl = '';
    if (useRealWebcam && videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth || 640;
      canvas.height = videoRef.current.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        snapUrl = canvas.toDataURL('image/jpeg');
      }
    } else {
      // High fidelity simulated snapshot
      snapUrl = cameraFacing === 'user' 
        ? 'https://images.unsplash.com/photo-1543610892-0b1f7e6d8ac1?w=600&auto=format&fit=crop&q=80'
        : 'https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=600&auto=format&fit=crop&q=80';
    }
    if (snapUrl) {
      setSnapshots(prev => [snapUrl, ...prev]);
    }
  };

  // Add audio recording
  const handleRecordAudio = () => {
    const newRec = {
      id: 'rec_' + Date.now(),
      time: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' }),
      duration: '0:15 د'
    };
    setAudioRecordings(prev => [newRec, ...prev]);
  };

  return (
    <div className="space-y-6">
      
      {/* Header with Sub-tabs */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs transition-colors duration-200">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Camera className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
              <span>{isAr ? 'البث المباشر للكاميرا والميكروفون عن بُعد' : 'Remote Camera & Ambient Audio'}</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {isAr 
                ? `اتصال مشفر ومباشر مع أجهزة استشعار هاتف ${activeDevice?.childNameAr} (${activeDevice?.deviceName})`
                : `Encrypted live sensor telemetry from ${activeDevice?.childName}'s device`}
            </p>
          </div>

          {/* Sub-tab navigation */}
          <div className="w-full sm:w-auto grid grid-cols-3 sm:flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
            <button
              onClick={() => setActiveSubTab('camera')}
              className={`flex items-center justify-center gap-1.5 sm:gap-2 px-2.5 sm:px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeSubTab === 'camera'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Camera className="w-4 h-4 shrink-0" />
              <span>{isAr ? 'الكاميرا' : 'Camera'}</span>
              {isLiveCameraStreaming && <span className="w-2 h-2 rounded-full bg-white animate-ping shrink-0" />}
            </button>

            <button
              onClick={() => setActiveSubTab('mic')}
              className={`flex items-center justify-center gap-1.5 sm:gap-2 px-2.5 sm:px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeSubTab === 'mic'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Mic className="w-4 h-4 shrink-0" />
              <span>{isAr ? 'المايك' : 'Mic'}</span>
              {isMicListening && <span className="w-2 h-2 rounded-full bg-white animate-ping shrink-0" />}
            </button>

            <button
              onClick={() => setActiveSubTab('screen')}
              className={`flex items-center justify-center gap-1.5 sm:gap-2 px-2.5 sm:px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeSubTab === 'screen'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Eye className="w-4 h-4 shrink-0" />
              <span>{isAr ? 'الشاشة' : 'Screen'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* ==================== 1. CAMERA TAB ==================== */}
      {activeSubTab === 'camera' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Main Camera Viewfinder (2 cols) */}
          <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xs flex flex-col justify-between">
            <div>
              {/* Controls bar above viewfinder */}
              <div className="flex flex-wrap items-center justify-between pb-3 mb-3 border-b border-slate-100 dark:border-slate-800 gap-2">
                <div className="flex items-center gap-2">
                  <span className={`w-2.5 h-2.5 rounded-full ${isLiveCameraStreaming ? 'bg-emerald-500 animate-ping' : 'bg-slate-400'}`} />
                  <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                    {isLiveCameraStreaming 
                      ? (isAr ? `بث مباشر: الكاميرا ${cameraFacing === 'user' ? 'الأمامية' : 'الخلفية'}` : `LIVE: ${cameraFacing.toUpperCase()} CAM`)
                      : (isAr ? 'الكاميرا متوقفة' : 'CAMERA STANDBY')}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  {/* Real webcam switch */}
                  <button
                    onClick={() => setUseRealWebcam(w => !w)}
                    className={`text-[11px] px-2.5 py-1 rounded-xl border transition-colors shadow-xs ${
                      useRealWebcam 
                        ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800 font-bold'
                        : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-700'
                    }`}
                  >
                    {isAr ? (useRealWebcam ? 'كاميرا حقيقية (مفعل)' : 'استخدام كاميرا حقيقية') : (useRealWebcam ? 'Real Cam: ON' : 'Use Real Cam')}
                  </button>

                  {/* Switch Front/Rear */}
                  <button
                    disabled={!isLiveCameraStreaming}
                    onClick={toggleCameraFacing}
                    className="p-1.5 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 disabled:opacity-40 text-slate-700 dark:text-slate-200 rounded-xl border border-slate-200 dark:border-slate-700 transition-colors shadow-xs"
                    title={isAr ? 'تبديل الكاميرا (أمامية / خلفية)' : 'Toggle Front/Rear'}
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>

                  {/* Flashlight toggle */}
                  <button
                    disabled={!isLiveCameraStreaming || cameraFacing === 'user'}
                    onClick={toggleFlashlight}
                    className={`p-1.5 rounded-xl border transition-colors shadow-xs ${
                      isFlashlightActive
                        ? 'bg-amber-500 text-white border-amber-500'
                        : 'bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 disabled:opacity-40 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700'
                    }`}
                    title={isAr ? 'تشغيل الفلاش كشاف' : 'Torch'}
                  >
                    <Flashlight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Viewfinder Canvas / Container */}
              <div className="relative aspect-video w-full rounded-2xl overflow-hidden bg-slate-950 border border-slate-900 flex items-center justify-center shadow-inner">
                {isLiveCameraStreaming ? (
                  useRealWebcam ? (
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="relative w-full h-full">
                      {/* Simulated high quality room / child environment */}
                      <img
                        src={cameraFacing === 'user' 
                          ? 'https://images.unsplash.com/photo-1543610892-0b1f7e6d8ac1?w=900&auto=format&fit=crop&q=80'
                          : 'https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=900&auto=format&fit=crop&q=80'
                        }
                        alt="Child Camera Stream"
                        className="w-full h-full object-cover"
                      />

                      {/* Viewfinder HUD Overlays */}
                      <div className="absolute inset-0 p-4 flex flex-col justify-between pointer-events-none">
                        <div className="flex items-center justify-between text-[11px] font-mono text-emerald-400 bg-slate-950/60 px-2.5 py-1 rounded-lg backdrop-blur-sm self-start">
                          <span>REC ● 1080p 30FPS</span>
                          <span className="ms-3">{new Date().toLocaleTimeString()}</span>
                        </div>

                        {/* Crosshairs & Focusing frame */}
                        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-28 h-28 border border-white/40 rounded-xl flex items-center justify-center">
                          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                        </div>

                        {/* Bottom telemetry */}
                        <div className="flex items-center justify-between text-[11px] text-white/80 bg-slate-950/60 px-3 py-1.5 rounded-lg backdrop-blur-sm">
                          <span>{activeDevice?.deviceName} ({activeDevice?.platform.toUpperCase()})</span>
                          <span>ISO 400 • F/1.8 • 1/60s</span>
                        </div>
                      </div>
                    </div>
                  )
                ) : (
                  <div className="flex flex-col items-center justify-center p-8 text-center">
                    <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500 mb-3">
                      <VideoOff className="w-8 h-8" />
                    </div>
                    <h4 className="text-base font-bold text-slate-300">
                      {isAr ? 'البث المباشر للكاميرا غير مفعل حالياً' : 'Camera Streaming is Inactive'}
                    </h4>
                    <p className="text-xs text-slate-400 mt-1 max-w-sm">
                      {isAr 
                        ? 'اضغط على زر "بدء البث" لفتح تدفق الفيديو المشفر من كاميرا هاتف طفلك عن بُعد'
                        : 'Press "Start Stream" to open the encrypted live video feed'}
                    </p>
                    <button
                      id="start-camera-stream-btn"
                      onClick={() => startCameraStream('environment')}
                      className="mt-4 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 shadow-xs transition-all active:scale-95"
                    >
                      <Camera className="w-4 h-4" />
                      <span>{isAr ? 'بدء بث الكاميرا عن بُعد' : 'Start Camera Stream'}</span>
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Bottom Stream Action Buttons */}
            {isLiveCameraStreaming && (
              <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 gap-2 flex-wrap">
                <div className="flex items-center gap-2">
                  {/* Snapshot */}
                  <button
                    id="take-snapshot-btn"
                    onClick={handleTakeSnapshot}
                    className="px-4 py-2 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 transition-colors shadow-xs"
                  >
                    <Download className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                    <span>{isAr ? 'التقاط صورة فورية' : 'Take Snapshot'}</span>
                  </button>

                  {/* Video Record */}
                  <button
                    id="record-video-btn"
                    onClick={() => setIsRecordingVideo(r => !r)}
                    className={`px-4 py-2 text-xs font-semibold rounded-xl border flex items-center gap-1.5 transition-all shadow-xs ${
                      isRecordingVideo
                        ? 'bg-rose-600 text-white border-rose-500 animate-pulse'
                        : 'bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    <Video className="w-3.5 h-3.5" />
                    <span>
                      {isRecordingVideo 
                        ? (isAr ? `إيقاف التسجيل (${recordTimer}ث)` : `Stop (${recordTimer}s)`)
                        : (isAr ? 'تسجيل مقطع' : 'Record Clip')}
                    </span>
                  </button>
                </div>

                <button
                  id="stop-camera-stream-btn"
                  onClick={stopCameraStream}
                  className="px-4 py-2 bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 dark:hover:bg-rose-900/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800 text-xs font-semibold rounded-xl transition-colors shadow-xs"
                >
                  {isAr ? 'إيقاف البث' : 'End Stream'}
                </button>
              </div>
            )}
          </div>

          {/* Snapshots Gallery & Privacy Safeguards (1 col) */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Download className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                  <span>{isAr ? 'معرض الصور الملتقطة' : 'Captured Snapshots'}</span>
                </h3>
                <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">{snapshots.length} {isAr ? 'صور' : 'snaps'}</span>
              </div>

              {snapshots.length === 0 ? (
                <div className="py-12 text-center text-slate-400 dark:text-slate-500 text-xs">
                  <Camera className="w-8 h-8 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
                  <p>{isAr ? 'لم يتم التقاط أي صور بعد' : 'No snapshots taken yet'}</p>
                  <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1">
                    {isAr ? 'اضغط "التقاط صورة فورية" لحفظ لقطات من الكاميرا' : 'Click "Take Snapshot" during active stream'}
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-2 mt-3 max-h-[300px] overflow-y-auto no-scrollbar">
                  {snapshots.map((snap, idx) => (
                    <div key={idx} className="group relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-950 aspect-video shadow-xs">
                      <img src={snap} alt={`Snapshot ${idx}`} className="w-full h-full object-cover" />
                      <a
                        href={snap}
                        download={`parentguard-snapshot-${idx}.jpg`}
                        className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity text-xs gap-1"
                      >
                        <Download className="w-4 h-4" />
                        <span>{isAr ? 'تحميل' : 'Save'}</span>
                      </a>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Privacy Compliance Box */}
            <div className="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/50 rounded-xl text-[11px] text-indigo-900 dark:text-indigo-300">
              <div className="flex items-center gap-1.5 text-indigo-700 dark:text-indigo-300 font-bold mb-1">
                <Shield className="w-3.5 h-3.5" />
                <span>{isAr ? 'حماية وخصوصية الأطفال' : 'Privacy & Security'}</span>
              </div>
              <p className="leading-relaxed text-slate-600 dark:text-slate-400">
                {isAr 
                  ? 'يتم تشفير البث المباشر بتقنية AES-256 بين جهاز الوالد وجهاز الطفل ولا يتم تخزين أي محتوى على خوادم خارجية.'
                  : 'Streams are end-to-end encrypted with zero server storage compliance.'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ==================== 2. MICROPHONE TAB ==================== */}
      {activeSubTab === 'mic' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Main Audio Visualizer & Listener (2 cols) */}
          <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <span className={`w-2.5 h-2.5 rounded-full ${isMicListening ? 'bg-amber-500 animate-ping' : 'bg-slate-400'}`} />
                  <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                    {isMicListening 
                      ? (isAr ? 'استماع مباشر للمحيط الصوتي (نشط)' : 'AMBIENT AUDIO LISTENING ACTIVE')
                      : (isAr ? 'الميكروفون في وضع الاستعداد' : 'MICROPHONE STANDBY')}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setUseRealMic(m => !m)}
                    className={`text-[11px] px-2.5 py-1 rounded-xl border transition-colors shadow-xs ${
                      useRealMic 
                        ? 'bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border-amber-200 dark:border-amber-800 font-bold'
                        : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-700'
                    }`}
                  >
                    {isAr ? (useRealMic ? 'ميكروفون حقيقي (مفعل)' : 'ميكروفون المتصفح') : (useRealMic ? 'Real Mic: ON' : 'Use Real Mic')}
                  </button>
                </div>
              </div>

              {/* Sound Pulse Visualizer Box */}
              <div className="relative aspect-video w-full rounded-2xl overflow-hidden bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 border border-slate-900 flex flex-col items-center justify-center p-6 text-center">
                {isMicListening ? (
                  <div className="w-full flex flex-col items-center justify-center">
                    {/* Animated Pulsing Sound Rings */}
                    <div className="relative flex items-center justify-center my-4">
                      <div className="w-32 h-32 rounded-full bg-amber-500/10 animate-ping absolute" />
                      <div className="w-24 h-24 rounded-full bg-amber-500/20 animate-pulse absolute" />
                      <div className="w-16 h-16 rounded-full bg-amber-500 flex items-center justify-center text-slate-950 shadow-lg shadow-amber-500/40 z-10">
                        <Mic className="w-8 h-8 animate-bounce" />
                      </div>
                    </div>

                    {/* Decibel Meter */}
                    <div className="mt-3">
                      <span className="text-3xl font-extrabold text-white font-mono">{micDecibels} dB</span>
                      <p className="text-xs text-amber-300 font-semibold mt-0.5">
                        {micDecibels < 45 ? (isAr ? 'محيط هادئ (غرفة نوم أو دراسة)' : 'Quiet room atmosphere') : 
                         micDecibels < 70 ? (isAr ? 'محادثة عادية أو أصوات ألعاب' : 'Conversation / Gaming audio') : 
                         (isAr ? 'صوت مرتفع / تلفاز أو حركة نشطة' : 'Loud ambient sounds')}
                      </p>
                    </div>

                    {/* Animated Equalizer Waveform Bars */}
                    <div className="flex items-end justify-center gap-1.5 h-16 w-full max-w-xs mt-4">
                      {[35, 55, 75, 40, 90, 65, 80, 45, 95, 60, 40, 70, 85, 50, 30].map((h, i) => (
                        <div
                          key={i}
                          className="w-2 rounded-full bg-gradient-to-t from-amber-500 to-indigo-400 transition-all duration-300"
                          style={{
                            height: `${Math.min(100, Math.max(15, (h * (micDecibels / 50))))}%`
                          }}
                        />
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center">
                    <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500 mb-3">
                      <Mic className="w-8 h-8" />
                    </div>
                    <h4 className="text-base font-bold text-slate-300">
                      {isAr ? 'الاستماع الصوتي متوقف حالياً' : 'Ambient Audio Inactive'}
                    </h4>
                    <p className="text-xs text-slate-400 mt-1 max-w-sm">
                      {isAr 
                        ? 'يمكنك الاستماع المباشر للأصوات المحيطة بطفلك للاطمئنان عليه في المدرسة أو الشارع'
                        : 'Listen to ambient sounds around your child to ensure their safety'}
                    </p>
                    <button
                      id="start-mic-listening-btn"
                      onClick={startMicListening}
                      className="mt-4 px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 shadow-xs transition-all active:scale-95"
                    >
                      <Mic className="w-4 h-4" />
                      <span>{isAr ? 'بدء الاستماع للمحيط الصوتي' : 'Start Audio Listening'}</span>
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Bottom Actions */}
            {isMicListening && (
              <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 gap-2 flex-wrap">
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleRecordAudio}
                    className="px-4 py-2 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold rounded-xl border border-slate-200 dark:border-slate-700 flex items-center gap-1.5 transition-colors shadow-xs"
                  >
                    <Radio className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                    <span>{isAr ? 'تسجيل مقطع صوتي (15ث)' : 'Record Clip'}</span>
                  </button>
                </div>

                <button
                  id="stop-mic-listening-btn"
                  onClick={stopMicListening}
                  className="px-4 py-2 bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 dark:hover:bg-rose-900/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800 text-xs font-semibold rounded-xl transition-colors shadow-xs"
                >
                  {isAr ? 'إيقاف الاستماع' : 'Stop Listening'}
                </button>
              </div>
            )}
          </div>

          {/* Audio Recordings Log & Sound Profiles (1 col) */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <Volume2 className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                  <span>{isAr ? 'سجل المقاطع الصوتية' : 'Audio Recordings'}</span>
                </h3>
                <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">{audioRecordings.length} {isAr ? 'مقاطع' : 'clips'}</span>
              </div>

              {audioRecordings.length === 0 ? (
                <div className="py-12 text-center text-slate-400 dark:text-slate-500 text-xs">
                  <Volume2 className="w-8 h-8 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
                  <p>{isAr ? 'لم يتم حفظ تسجيلات بعد' : 'No audio clips recorded'}</p>
                  <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1">
                    {isAr ? 'اضغط "تسجيل مقطع" لأرشفة لقطة صوتية للسلامة' : 'Record ambient clips for safety verification'}
                  </p>
                </div>
              ) : (
                <div className="space-y-2 mt-3 max-h-[300px] overflow-y-auto no-scrollbar">
                  {audioRecordings.map((rec) => (
                    <div key={rec.id} className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700 flex items-center justify-between text-xs">
                      <div>
                        <p className="font-bold text-slate-900 dark:text-white">{isAr ? 'تسجيل محيط صوتي' : 'Ambient Clip'}</p>
                        <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">{rec.time} • {rec.duration}</span>
                      </div>
                      <button 
                        onClick={() => showToast(isAr ? 'جاري تشغيل المقطع الصوتي المسجل...' : 'Playing recorded audio clip...', 'info')}
                        className="p-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs"
                      >
                        <Play className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="p-3 bg-amber-50/70 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 rounded-xl text-[11px] text-amber-900 dark:text-amber-300">
              <span className="font-bold">{isAr ? 'ميزة التعرف على الصراخ والاستغاثة:' : 'SOS Screaming Detection:'}</span>
              <p className="mt-1 text-slate-600 dark:text-slate-400">
                {isAr ? 'يقوم التطبيق بتحليل مستويات الصوت تلقائياً لتنبيهك إذا تجاوز الصوت 85 ديسيبل مصحوباً بنبرة استغاثة.' : 'Auto-detects crying or emergency screams > 85dB and sends instant alerts.'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ==================== 3. SCREEN MIRROR TAB ==================== */}
      {activeSubTab === 'screen' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Eye className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                <span>{isAr ? 'بث ومطابقة شاشة هاتف الطفل (Screen Mirroring)' : 'Live Screen Mirroring'}</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                {isAr ? 'معاينة مباشرة لما يراه طفلك على شاشته في هذه اللحظة' : 'Real-time mirror of child active viewport'}
              </p>
            </div>

            <button
              onClick={() => showToast(isAr ? 'تم التقاط صورة من الشاشة وحفظها في المعرض' : 'Screen captured and saved', 'success')}
              className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isAr ? 'التقاط الشاشة (Screenshot)' : 'Capture Screen'}</span>
            </button>
          </div>

          <div className="relative aspect-video max-w-2xl mx-auto rounded-2xl overflow-hidden bg-slate-950 border border-slate-900 shadow-xl p-4 flex flex-col justify-between">
            {/* Mock child screen content */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-2 text-[11px] text-slate-400">
              <span>{activeDevice?.currentActiveApp || 'com.google.android.youtube'}</span>
              <span className="text-emerald-400 font-mono">Live 60 FPS • 1080p</span>
            </div>

            <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
              <img 
                src="https://cdn-icons-png.flaticon.com/512/1384/1384060.png" 
                alt="Active App" 
                className="w-16 h-16 rounded-2xl mb-3 shadow-lg"
              />
              <h4 className="text-base font-bold text-white">
                {isAr ? 'يشاهد مقطع تعليمي في يوتيوب' : 'Watching YouTube Educational Video'}
              </h4>
              <p className="text-xs text-slate-400 mt-1 max-w-md">
                "مغامرات الفضاء والمجموعة الشمسية للأطفال"
              </p>
              <span className="mt-3 px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full text-xs font-medium">
                {isAr ? 'محتوى آمن متوافق مع فلتر الوالدين' : 'Safe Filter Verified'}
              </span>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-[11px] text-slate-400">
              <span>{isAr ? 'دقة البث: تلقائية' : 'Bitrate: Auto'}</span>
              <span>{isAr ? 'تأخير الاتصال (Latency): 42ms' : 'Latency: 42ms'}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
