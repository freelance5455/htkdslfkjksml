import React, { useState } from 'react';
import {
  Sparkles,
  CheckCircle2,
  Lock,
  ArrowRight,
  RefreshCw,
  Sliders,
  Type,
  FileCheck2,
  FileText,
  AlertCircle
} from 'lucide-react';
import { AiAnalysisResult, DocumentTemplateId, DocumentStyleSettings } from '../../types';
import { parseRawTextToSections, DEFAULT_STYLE_SETTINGS } from '../../utils/documentEngine';

interface AiFormattingAssistantViewProps {
  onBack: () => void;
  onApplyAndCreateDocument: (text: string, styleSettings: Partial<DocumentStyleSettings>) => void;
}

export const AiFormattingAssistantView: React.FC<AiFormattingAssistantViewProps> = ({
  onBack,
  onApplyAndCreateDocument
}) => {
  const sampleDoc = `# Global Cloud Architecture Review
The migration of document processing workloads to distributed edge containers has produced significant performance improvements.

## Empirical Metrics & Latency
- Latency reduced by 64% across cross-region endpoints
- Native OCR inference sustained 98.4% glyph accuracy
- Zero memory leakage observed during stress cycles

## Key Takeaways
System stability remains uncompromised even under peak concurrency.

> "Preserving structural semantic integrity is the paramount objective of mobile document compilation."

Component | Previous | Modernized
Gateway | 140ms | 22ms
Parser | 420ms | 110ms`;

  const [documentText, setDocumentText] = useState(sampleDoc);
  const [templateType, setTemplateType] = useState<DocumentTemplateId>('business');
  const [preserveWording, setPreserveWording] = useState(true);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AiAnalysisResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleAnalyze = async () => {
    if (!documentText.trim()) return;
    setIsAnalyzing(true);
    setErrorMsg(null);

    try {
      const response = await fetch('/api/ai/format-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: documentText,
          templateType,
          preserveWording
        })
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data: AiAnalysisResult = await response.json();
      setAnalysisResult(data);
    } catch (err: any) {
      console.warn('API call issue, generating local typography analysis:', err);
      // Client-side fallback analyzer
      const fallbackSections = parseRawTextToSections(documentText);
      setAnalysisResult({
        recommendations: {
          fontFamily: templateType === 'academic' ? 'Times New Roman' : 'Calibri',
          headingFont: templateType === 'academic' ? 'Times New Roman' : 'Aptos',
          bodySize: 11,
          headingSize: 18,
          lineSpacing: templateType === 'academic' ? 2.0 : 1.15,
          paragraphSpacing: 10,
          margins: { top: 1, bottom: 1, left: 1, right: 1 },
          align: 'left',
          indentFirstLine: templateType === 'academic',
          accentColor: '#005FB8',
          rationale: 'Balanced typography with optimal readability and zero content modification.'
        },
        structure: fallbackSections.map(s => ({ type: s.type as any, content: s.content })),
        detectedElements: {
          headingsCount: fallbackSections.filter(s => s.type === 'heading').length,
          paragraphsCount: fallbackSections.filter(s => s.type === 'paragraph').length,
          listItemsCount: fallbackSections.filter(s => s.type === 'bullet_list' || s.type === 'numbered_list').length,
          tablesCount: fallbackSections.filter(s => s.type === 'table').length,
          quotesCount: fallbackSections.filter(s => s.type === 'quote').length,
          referencesCount: 0
        },
        observations: [
          'Preserved original wording verbatim',
          'Applied professional typographic scale without changing meaning'
        ],
        source: 'local_typography_engine'
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleApply = () => {
    if (!analysisResult) return;
    const rec = analysisResult.recommendations;
    const styleSettings: Partial<DocumentStyleSettings> = {
      templateId: templateType,
      fontFamily: rec.fontFamily,
      headingFont: rec.headingFont,
      bodySize: rec.bodySize,
      headingSize: rec.headingSize,
      lineSpacing: rec.lineSpacing,
      paragraphSpacing: rec.paragraphSpacing,
      margins: rec.margins,
      alignment: rec.align,
      indentFirstLine: rec.indentFirstLine,
      accentColor: rec.accentColor
    };

    onApplyAndCreateDocument(documentText, styleSettings);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-neutral-50 dark:bg-neutral-900 pb-16">
      {/* Header Info */}
      <div className="px-4 py-3 bg-white dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 space-y-2">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-sky-100 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 flex items-center justify-center">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-neutral-900 dark:text-neutral-100">
              AI Document Formatting Assistant
            </h3>
            <p className="text-[10px] text-neutral-500">
              Inspects text and recommends professional typography and layout adjustments without altering facts or meaning.
            </p>
          </div>
        </div>

        {/* Configuration Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs">
          <div className="flex items-center gap-2">
            <label className="text-[11px] font-semibold text-neutral-500">Target Style:</label>
            <select
              value={templateType}
              onChange={(e) => setTemplateType(e.target.value as any)}
              className="px-2.5 py-1 rounded-xl bg-neutral-100 dark:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 text-neutral-900 dark:text-neutral-100 font-medium"
            >
              <option value="business">Corporate Business</option>
              <option value="academic">Academic (APA/MLA)</option>
              <option value="report">Executive Report</option>
              <option value="letter">Formal Letter</option>
              <option value="notes">Meeting Notes</option>
              <option value="general">Universal Clean</option>
            </select>
          </div>

          <label className="flex items-center gap-1.5 cursor-pointer text-[11px] font-semibold text-neutral-700 dark:text-neutral-300">
            <input
              type="checkbox"
              checked={preserveWording}
              onChange={(e) => setPreserveWording(e.target.checked)}
              className="accent-blue-600 rounded"
            />
            <Lock className="w-3 h-3 text-blue-600" />
            <span>Preserve original wording strictly</span>
          </label>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 p-3 overflow-y-auto space-y-4">
        {/* Document Text Input */}
        <div className="bg-white dark:bg-neutral-800 rounded-2xl border border-neutral-200 dark:border-neutral-700 shadow-xs overflow-hidden flex flex-col">
          <div className="px-4 py-2 bg-neutral-50 dark:bg-neutral-800/80 border-b border-neutral-200 dark:border-neutral-700 flex justify-between items-center text-xs">
            <span className="font-bold text-neutral-700 dark:text-neutral-300 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-neutral-500" />
              <span>Document Text for Inspection</span>
            </span>
            <span className="text-[11px] text-neutral-400">
              {documentText.split(/\s+/).filter(Boolean).length} words
            </span>
          </div>

          <textarea
            value={documentText}
            onChange={(e) => setDocumentText(e.target.value)}
            placeholder="Type or paste document text to analyze..."
            rows={7}
            className="w-full p-3 bg-transparent text-neutral-900 dark:text-neutral-100 font-mono text-xs leading-relaxed focus:outline-none resize-none"
          />

          <div className="p-3 bg-neutral-50 dark:bg-neutral-800/80 border-t border-neutral-200 dark:border-neutral-700 flex justify-end">
            <button
              type="button"
              disabled={isAnalyzing || !documentText.trim()}
              onClick={handleAnalyze}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all disabled:opacity-50"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Inspecting Structure & Typography...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>Inspect & Recommend Layout</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* AI Recommendations Card */}
        {analysisResult && (
          <div className="rounded-3xl bg-white dark:bg-neutral-800 border border-blue-200 dark:border-blue-800 shadow-md p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-neutral-200 dark:border-neutral-700 pb-3">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                <div>
                  <h4 className="text-xs font-bold text-neutral-900 dark:text-neutral-100">
                    AI Typography & Layout Recommendations
                  </h4>
                  <p className="text-[10px] text-neutral-500">
                    {analysisResult.source === 'gemini_ai'
                      ? 'Generated by Gemini AI'
                      : 'Generated by Built-in Typography Engine'}
                  </p>
                </div>
              </div>

              <span className="text-[10px] font-bold px-2.5 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300">
                100% Meaning Preserved
              </span>
            </div>

            {/* Detected Elements Badges */}
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-wider">
                Detected Document Elements
              </span>
              <div className="flex flex-wrap gap-1.5">
                <span className="px-2.5 py-1 rounded-lg bg-neutral-100 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300 text-[11px] font-semibold">
                  {analysisResult.detectedElements.headingsCount} Headings
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-neutral-100 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300 text-[11px] font-semibold">
                  {analysisResult.detectedElements.paragraphsCount} Paragraphs
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-neutral-100 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300 text-[11px] font-semibold">
                  {analysisResult.detectedElements.listItemsCount} List Items
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-neutral-100 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300 text-[11px] font-semibold">
                  {analysisResult.detectedElements.tablesCount} Tables
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-neutral-100 dark:bg-neutral-700 text-neutral-700 dark:text-neutral-300 text-[11px] font-semibold">
                  {analysisResult.detectedElements.quotesCount} Quotes
                </span>
              </div>
            </div>

            {/* Recommended Styling Parameters */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 bg-neutral-50 dark:bg-neutral-900/60 p-3 rounded-2xl text-xs">
              <div>
                <span className="text-[10px] text-neutral-500 block">Body Font</span>
                <span className="font-bold text-neutral-900 dark:text-neutral-100">
                  {analysisResult.recommendations.fontFamily}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-neutral-500 block">Heading Font</span>
                <span className="font-bold text-neutral-900 dark:text-neutral-100">
                  {analysisResult.recommendations.headingFont}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-neutral-500 block">Line Spacing</span>
                <span className="font-bold text-neutral-900 dark:text-neutral-100">
                  {analysisResult.recommendations.lineSpacing}x
                </span>
              </div>
              <div>
                <span className="text-[10px] text-neutral-500 block">Body Size</span>
                <span className="font-bold text-neutral-900 dark:text-neutral-100">
                  {analysisResult.recommendations.bodySize} pt
                </span>
              </div>
              <div>
                <span className="text-[10px] text-neutral-500 block">Heading Size</span>
                <span className="font-bold text-neutral-900 dark:text-neutral-100">
                  {analysisResult.recommendations.headingSize} pt
                </span>
              </div>
              <div>
                <span className="text-[10px] text-neutral-500 block">Margins</span>
                <span className="font-bold text-neutral-900 dark:text-neutral-100">
                  {analysisResult.recommendations.margins.top}" all sides
                </span>
              </div>
            </div>

            {/* AI Rationale */}
            <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 text-xs text-blue-900 dark:text-blue-200">
              <span className="font-bold block mb-1">Layout Rationale:</span>
              <p className="leading-relaxed">{analysisResult.recommendations.rationale}</p>
            </div>

            {/* Apply Button */}
            <div className="pt-2">
              <button
                type="button"
                onClick={handleApply}
                className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all"
              >
                <FileCheck2 className="w-4 h-4" />
                <span>Apply Recommendations & Compose Document</span>
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="sticky bottom-0 px-4 py-3 bg-white/95 dark:bg-neutral-800/95 backdrop-blur-md border-t border-neutral-200 dark:border-neutral-700 flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          className="px-4 py-2 rounded-xl text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-xs font-semibold"
        >
          Back
        </button>
      </div>
    </div>
  );
};
