import React, { useState } from 'react';
import { useParentControl } from '../../context/ParentControlContext';
import { FLUTTER_CODE_SNIPPETS } from '../../data/mockData';
import JSZip from 'jszip';
import { 
  Download, 
  ExternalLink, 
  Smartphone, 
  CheckCircle2, 
  Copy, 
  Check, 
  Terminal, 
  PackageCheck, 
  ShieldCheck, 
  Layers, 
  Sparkles, 
  FileCode2, 
  Cpu, 
  HelpCircle,
  FolderArchive,
  ArrowUpRight
} from 'lucide-react';

export const ApkExportView: React.FC = () => {
  const { language, showToast } = useParentControl();
  const isAr = language === 'ar';

  const [copiedUrl, setCopiedUrl] = useState(false);
  const [isZipping, setIsZipping] = useState(false);
  const [zipDownloaded, setZipDownloaded] = useState(false);
  const [activeTab, setActiveTab] = useState<'pwabuilder' | 'flutter_zip' | 'github_actions' | 'webapk'>('pwabuilder');

  const appUrl = typeof window !== 'undefined' ? window.location.origin : 'https://ais-pre-dg5s3z6edyrlupxsyzjd64-826841532519.europe-west2.run.app';
  const pwaBuilderUrl = `https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(appUrl)}`;

  const handleCopyUrl = () => {
    navigator.clipboard?.writeText(appUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  // Generate complete Flutter & Android project zip on the client side
  const handleDownloadFlutterZip = async () => {
    try {
      setIsZipping(true);
      const zip = new JSZip();

      // 1. Pubspec
      const pubspec = `name: parent_guard
description: "ParentGuard - Complete Remote Parental Control Cross-Platform System"
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.0.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  flutter_localizations:
    sdk: flutter
  cupertino_icons: ^1.0.6
  web_socket_channel: ^2.4.1
  geolocator: ^11.0.0
  camera: ^0.10.5+9
  permission_handler: ^11.3.1
  flutter_local_notifications: ^17.1.1
  shared_preferences: ^2.2.3

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0

flutter:
  uses-material-design: true
`;
      zip.file('pubspec.yaml', pubspec);

      // 2. lib/main.dart
      zip.file('lib/main.dart', FLUTTER_CODE_SNIPPETS.mainDart);

      // 3. Android files
      const androidFolder = zip.folder('android');
      const appFolder = androidFolder?.folder('app');
      const srcFolder = appFolder?.folder('src')?.folder('main');

      // AndroidManifest.xml
      const manifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.parentguard.app">

    <!-- Critical Parental Control Permissions -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_BACKGROUND_LOCATION" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.PACKAGE_USAGE_STATS" />
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />

    <application
        android:label="ParentGuard"
        android:name="\${applicationName}"
        android:icon="@mipmap/ic_launcher">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:hardwareAccelerated="true"
            android:windowSoftInputMode="adjustResize">
            <meta-data
              android:name="io.flutter.embedding.android.NormalTheme"
              android:resource="@style/NormalTheme" />
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>

        <!-- Device Policy Administrator (Prevents Child Uninstall & Screen Lock) -->
        <receiver
            android:name=".DeviceAdminReceiver"
            android:description="@string/device_admin_description"
            android:label="@string/device_admin_label"
            android:permission="android.permission.BIND_DEVICE_ADMIN"
            android:exported="true">
            <meta-data
                android:name="android.app.device_admin"
                android:resource="@xml/device_admin" />
            <intent-filter>
                <action android:name="android.app.action.DEVICE_ADMIN_ENABLED" />
                <action android:name="android.app.action.DEVICE_ADMIN_DISABLE_REQUESTED" />
                <action android:name="android.app.action.DEVICE_ADMIN_DISABLED" />
            </intent-filter>
        </receiver>

        <!-- Accessibility Service (Instant Realtime App Blocker) -->
        <service
            android:name=".AppBlockerAccessibility"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
            android:exported="true">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>

        <meta-data
            android:name="flutterEmbedding"
            android:value="2" />
    </application>
</manifest>`;
      srcFolder?.file('AndroidManifest.xml', manifestXml);

      // Kotlin directory
      const kotlinFolder = srcFolder?.folder('kotlin')?.folder('com')?.folder('parentguard')?.folder('app');
      kotlinFolder?.file('DeviceAdminReceiver.kt', FLUTTER_CODE_SNIPPETS.androidAdminKt);
      kotlinFolder?.file('AppBlockerAccessibility.kt', FLUTTER_CODE_SNIPPETS.accessibilityKt);

      const mainActivityKt = `package com.parentguard.app

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.parentguard.app/control"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "lockDevice" -> {
                    val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                    val compName = ComponentName(this, DeviceAdminReceiver::class.java)
                    if (dpm.isAdminActive(compName)) {
                        dpm.lockNow()
                        result.success(true)
                    } else {
                        result.error("NOT_ADMIN", "Device admin not active", null)
                    }
                }
                "isDeviceAdminActive" -> {
                    val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                    val compName = ComponentName(this, DeviceAdminReceiver::class.java)
                    result.success(dpm.isAdminActive(compName))
                }
                else -> result.notImplemented()
            }
        }
    }
}
`;
      kotlinFolder?.file('MainActivity.kt', mainActivityKt);

      // res/xml
      const resXmlFolder = srcFolder?.folder('res')?.folder('xml');
      const deviceAdminXml = `<device-admin xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-policies>
        <limit-password />
        <watch-login />
        <reset-password />
        <force-lock />
        <wipe-data />
        <expire-password />
        <encrypted-storage />
        <disable-camera />
    </uses-policies>
</device-admin>`;
      resXmlFolder?.file('device_admin.xml', deviceAdminXml);

      const accessibilityConfigXml = `<accessibility-service xmlns:android="http://schemas.android.com/apk/res/android"
    android:description="@string/accessibility_desc"
    android:accessibilityEventTypes="typeWindowStateChanged|typeWindowContentChanged"
    android:accessibilityFeedbackType="feedbackGeneric"
    android:notificationTimeout="50"
    android:accessibilityFlags="flagDefault|flagRetrieveInteractiveWindows"
    android:canRetrieveWindowContent="true" />`;
      resXmlFolder?.file('accessibility_service_config.xml', accessibilityConfigXml);

      // build.gradle (app)
      const buildGradle = `plugins {
    id "com.android.application"
    id "kotlin-android"
    id "dev.flutter.flutter-gradle-plugin"
}

android {
    namespace "com.parentguard.app"
    compileSdk 34

    defaultConfig {
        applicationId "com.parentguard.app"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0.0"
    }

    buildTypes {
        release {
            signingConfig signingConfigs.debug
            minifyEnabled false
            shrinkResources false
        }
    }
}
`;
      appFolder?.file('build.gradle', buildGradle);

      // 4. One-click Build Scripts
      const buildBat = `@echo off
echo ========================================================
echo  ParentGuard APK Builder (Flutter + Android)
echo ========================================================
echo Checking Flutter installation...
where flutter >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Flutter SDK is not found in PATH!
    echo Please install Flutter from https://flutter.dev and retry.
    pause
    exit /b 1
)

echo.
echo [1/3] Getting Flutter packages...
call flutter pub get

echo.
echo [2/3] Building Release APK...
call flutter build apk --release

echo.
echo [3/3] Done! Your APK file is ready at:
echo build\\app\\outputs\\flutter-apk\\app-release.apk
echo.
pause
`;
      zip.file('build_apk.bat', buildBat);

      const buildSh = `#!/bin/bash
set -e
echo "========================================================"
echo " ParentGuard APK Builder (Flutter + Android)"
echo "========================================================"

if ! command -v flutter &> /dev/null; then
    echo "[ERROR] Flutter SDK is not installed or not in PATH!"
    echo "Please install Flutter from https://flutter.dev and retry."
    exit 1
fi

echo "[1/3] Getting dependencies..."
flutter pub get

echo "[2/3] Building Android APK (Release)..."
flutter build apk --release

echo "[3/3] Build complete!"
echo "Your APK file is located at: build/app/outputs/flutter-apk/app-release.apk"
`;
      zip.file('build_apk.sh', buildSh);

      // 5. GitHub Actions workflow
      const ghWorkflow = `name: Build ParentGuard APK
on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build-apk:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: 'zulu'
          java-version: '17'
      - uses: subosito/flutter-action@v2
        with:
          flutter-version: '3.24.x'
          channel: 'stable'
          cache: true
      - run: flutter pub get
      - run: flutter build apk --release
      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: ParentGuard-Release-APK
          path: build/app/outputs/flutter-apk/app-release.apk
`;
      const ghFolder = zip.folder('.github')?.folder('workflows');
      ghFolder?.file('build_apk.yml', ghWorkflow);

      // 6. Readme
      const readme = `ParentGuard - Flutter Android APK Source Package
=====================================================

How to build your APK:

METHOD 1: Instant Local Build (If you have Flutter installed)
- Windows: Double-click 'build_apk.bat'
- Mac/Linux: Run 'chmod +x build_apk.sh && ./build_apk.sh'
- Output file: build/app/outputs/flutter-apk/app-release.apk

METHOD 2: Free Cloud Build (GitHub Actions - Zero local software needed)
1. Push this folder to a new private or public GitHub repository.
2. Go to the "Actions" tab in your repository.
3. The "Build ParentGuard APK" workflow will run automatically in ~2 minutes!
4. Download the generated 'ParentGuard-Release-APK' directly to your phone!
`;
      zip.file('README_APK.txt', readme);

      // Generate blob and trigger download
      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'ParentGuard_Flutter_Android_Project.zip';
      a.click();
      URL.revokeObjectURL(url);

      setZipDownloaded(true);
      showToast(isAr ? 'تم إنشاء ملف ZIP لمشروع Flutter بنجاح وجاري التنزيل' : 'Flutter project ZIP generated successfully', 'success');
      setTimeout(() => setZipDownloaded(false), 4000);
    } catch (err) {
      console.error(err);
      showToast(isAr ? 'فشل إنشاء ملف الـ ZIP، يرجى المحاولة مرة أخرى' : 'Failed to generate zip file', 'error');
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs transition-colors duration-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0">
              <PackageCheck className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                  {isAr ? 'استخراج وتحميل التطبيق بصيغة APK للأندرويد' : 'Export & Build Android APK Package'}
                </h2>
                <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 font-bold">
                  APK Ready
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                {isAr 
                  ? 'خيارات متعددة وسريعة للحصول على ملف APK جاهز للتثبيت على هواتف الأندرويد سواء لوحة تحكم الأب أو هاتف الطفل.'
                  : 'Multiple ways to export, build, and install the Android APK on parent and child devices.'}
              </p>
            </div>
          </div>
        </div>

        {/* Option Tabs */}
        <div className="flex items-center gap-2 mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 overflow-x-auto pb-1 no-scrollbar">
          {[
            { id: 'pwabuilder', labelAr: '1. التحويل المباشر لـ APK (أسرع طريقة)', labelEn: '1. Instant APK (PWABuilder)', icon: ArrowUpRight },
            { id: 'flutter_zip', labelAr: '2. تحميل مشروع Flutter كامل (ZIP)', labelEn: '2. Download Flutter Project (ZIP)', icon: FolderArchive },
            { id: 'github_actions', labelAr: '3. بناء سحابي مجاني (GitHub Actions)', labelEn: '3. Cloud Build (GitHub Actions)', icon: Cpu },
            { id: 'webapk', labelAr: '4. تثبيت فوري على الهاتف (WebAPK)', labelEn: '4. Instant Phone Install', icon: Smartphone },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-700'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{isAr ? tab.labelAr : tab.labelEn}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* TAB 1: PWABUILDER (INSTANT APK GENERATOR) */}
      {activeTab === 'pwabuilder' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-5">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-5">
              <div>
                <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest block mb-1">
                  {isAr ? 'الطريقة الأسرع والأسهل (بنقرة زر واحدة)' : 'Fastest & Recommended 1-Click Method'}
                </span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                  {isAr ? 'توليد ملف APK موقّع عبر PWABuilder' : 'Generate Signed Android APK via PWABuilder'}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl leading-relaxed">
                  {isAr 
                    ? 'تم تهيئة تطبيق ParentGuard بملف Manifest وService Worker كامل ومعتمد دولياً. يمكنك الآن تحويل الرابط السحابي المباشر إلى ملف APK جاهز للتثبيت بنقرة واحدة بدون الحاجة لكتابة أي كود أو تثبيت برامج!'
                    : 'ParentGuard is fully PWA-certified with compliant manifest and service workers. Convert the live URL into an installable Android APK in 30 seconds.'}
                </p>
              </div>

              <a
                id="open-pwabuilder-btn"
                href={pwaBuilderUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-5 py-3 bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-semibold rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 active:scale-95 shrink-0"
              >
                <span>{isAr ? 'فتح أداة توليد APK الآن' : 'Launch APK Generator'}</span>
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>

            {/* Live App URL Box */}
            <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 block">
                  {isAr ? 'رابط تطبيقك السحابي المباشر المعتمد:' : 'Your Deployed Live App URL:'}
                </span>
                <span className="text-xs sm:text-sm font-mono font-semibold text-slate-800 dark:text-slate-200 break-all">
                  {appUrl}
                </span>
              </div>
              <button
                onClick={handleCopyUrl}
                className="px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs shrink-0 self-start sm:self-center"
              >
                {copiedUrl ? <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{copiedUrl ? (isAr ? 'تم النسخ!' : 'Copied!') : (isAr ? 'نسخ الرابط' : 'Copy URL')}</span>
              </button>
            </div>

            {/* 3 Simple Steps */}
            <div>
              <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-3">
                {isAr ? 'خطوات الحصول على ملف الـ APK في 30 ثانية:' : '3 Simple steps to get your APK:'}
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700 space-y-1.5">
                  <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold font-mono">1</div>
                  <p className="text-xs font-bold text-slate-900 dark:text-white">{isAr ? 'اضغط فتح الأداة' : 'Click Launch'}</p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">{isAr ? 'سيتم فتح موقع PWABuilder ورابط تطبيقك جاهز وفاحص لكل المتطلبات.' : 'Opens PWABuilder with your pre-configured URL.'}</p>
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700 space-y-1.5">
                  <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold font-mono">2</div>
                  <p className="text-xs font-bold text-slate-900 dark:text-white">{isAr ? 'اختر Package for Android' : 'Click Package for Android'}</p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">{isAr ? 'يقوم المحرك السحابي بتجميع ملف APK رسمي موقّع بشهادة أمان مجانية.' : 'Cloud engine compiles a signed Android APK package.'}</p>
                </div>

                <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700 space-y-1.5">
                  <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold font-mono">3</div>
                  <p className="text-xs font-bold text-slate-900 dark:text-white">{isAr ? 'تثبيت الـ APK على هاتفك' : 'Install APK on Phone'}</p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">{isAr ? 'افتح ملف الـ APK على هاتف الأندرويد واضغط "تثبيت" وسيعمل كتطبيق أصلي!' : 'Transfer APK to phone and tap install to run as native app.'}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: FLUTTER ZIP DOWNLOAD */}
      {activeTab === 'flutter_zip' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-5">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-5">
              <div>
                <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest block mb-1">
                  {isAr ? 'حزمة المشروع الكاملة المجهزة للبناء' : 'Complete Ready-To-Build Project Bundle'}
                </span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                  {isAr ? 'تحميل مشروع Flutter + Android كاملاً بملف مضغوط (ZIP)' : 'Download Full Flutter + Android Project (.ZIP)'}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl leading-relaxed">
                  {isAr 
                    ? 'قم بتحميل الحزمة الكاملة التي تحتوي على كود Flutter (main.dart) مع صلاحيات أندرويد الأصلية ومستقبل الأدمن (DeviceAdminReceiver) وخدمة إمكانية الوصول لحظر التطبيقات، بالإضافة لسكربت البناء بنقرة واحدة (build_apk.bat) لويندوز وماك.'
                    : 'Download the complete Flutter & Android native repository containing main.dart, DeviceAdminReceiver.kt, AppBlockerAccessibility.kt, and 1-click build scripts.'}
                </p>
              </div>

              <button
                id="download-flutter-zip-btn"
                onClick={handleDownloadFlutterZip}
                disabled={isZipping}
                className="px-5 py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs sm:text-sm font-semibold rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 active:scale-95 shrink-0"
              >
                {isZipping ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>{isAr ? 'جاري ضغط الملفات...' : 'Creating ZIP...'}</span>
                  </>
                ) : zipDownloaded ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-white" />
                    <span>{isAr ? 'تم تحميل ملف ZIP بنجاح!' : 'Downloaded!'}</span>
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4" />
                    <span>{isAr ? 'تحميل مشروع Flutter (ZIP)' : 'Download Flutter ZIP'}</span>
                  </>
                )}
              </button>
            </div>

            {/* Included Files Checklist */}
            <div>
              <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-3">
                {isAr ? 'محتويات ملف الـ ZIP المجهز:' : 'Included files in the bundle:'}
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {[
                  { name: 'build_apk.bat', desc: 'سكربت بناء الـ APK للويندوز بنقرة واحدة' },
                  { name: 'build_apk.sh', desc: 'سكربت بناء الـ APK للماك ولينكس' },
                  { name: 'lib/main.dart', desc: 'تطبيق فلاتر الكامل مع واجهات التحكم والاستماع' },
                  { name: 'DeviceAdminReceiver.kt', desc: 'كود مسؤول الجهاز لمنع الحذف وقفل الشاشة' },
                  { name: 'AppBlockerAccessibility.kt', desc: 'كود مراقبة وحظر التطبيقات الفوري (0ms)' },
                  { name: 'AndroidManifest.xml', desc: 'كافة الصلاحيات وإعدادات تشغيل الخلفية التلقائي' },
                  { name: '.github/workflows/build_apk.yml', desc: 'ملف البناء السحابي التلقائي المجاني على GitHub' },
                  { name: 'pubspec.yaml', desc: 'ملف الحزم والاعتماديات الكامل' }
                ].map((item, idx) => (
                  <div key={idx} className="p-2.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700 flex items-center justify-between">
                    <span className="font-mono font-bold text-indigo-700 dark:text-indigo-400">{item.name}</span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400">{item.desc}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* How to build commands */}
            <div className="p-4 bg-slate-950 text-slate-200 rounded-xl font-mono text-xs space-y-2">
              <p className="text-indigo-400 font-bold">{isAr ? '// للبناء محلياً على جهازك:' : '// To build locally on your machine:'}</p>
              <div className="space-y-1">
                <p className="text-emerald-400">$ flutter pub get</p>
                <p className="text-emerald-400">$ flutter build apk --release</p>
                <p className="text-slate-400 text-[11px]">{isAr ? '# سيتم حفظ ملف الـ APK النهائي في:' : '# Your finished APK will be saved at:'}</p>
                <p className="text-amber-300 text-[11px]">build/app/outputs/flutter-apk/app-release.apk</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: GITHUB ACTIONS CLOUD BUILD */}
      {activeTab === 'github_actions' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-5">
            <div>
              <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest block mb-1">
                {isAr ? 'البناء السحابي المجاني 100% بدون أي برامج' : 'Free Cloud APK Build via GitHub Actions'}
              </span>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                {isAr ? 'بناء ملف APK على سيرفرات GitHub وتحميله مباشرة' : 'Build APK in GitHub Cloud & Download to Phone'}
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl leading-relaxed">
                {isAr 
                  ? 'إذا لم يكن لديك Flutter أو Android Studio على حاسوبك، يمكنك الاستفادة من سيرفرات GitHub المجانية لبناء ملف الـ APK وتنزيله مباشرة لهاتفك في 3 خطوات بسيطة:'
                  : 'No Android Studio or Flutter installed? Use GitHub Actions free Ubuntu runners to compile and generate your APK in ~2 minutes.'}
              </p>
            </div>

            {/* Step 1-2-3 */}
            <div className="space-y-3">
              <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700 flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold font-mono shrink-0 mt-0.5">1</span>
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                    {isAr ? 'تصدير المشروع إلى GitHub' : 'Export Project to GitHub'}
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                    {isAr 
                      ? 'من القائمة العلوية أو قائمة الإعدادات في AI Studio، اضغط على "Export to GitHub" لرفع مشروعك إلى حسابك على GitHub.'
                      : 'From the AI Studio menu, click Export to GitHub to push your app to your GitHub account.'}
                  </p>
                </div>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700 flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold font-mono shrink-0 mt-0.5">2</span>
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                    {isAr ? 'سير العمل سيبدأ تلقائياً (GitHub Actions)' : 'Workflow Runs Automatically'}
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                    {isAr 
                      ? 'ملف البناء (.github/workflows/build_apk.yml) المرفق في المشروع سيقوم تلقائياً بتشغيل بيئة Ubuntu، وتثبيت Flutter 3.24، وتشغيل أمر البناء "flutter build apk --release".'
                      : 'The included workflow file automatically launches an Ubuntu runner, configures Java 17 and Flutter, and executes release build.'}
                  </p>
                </div>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700 flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold font-mono shrink-0 mt-0.5">3</span>
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
                    {isAr ? 'تحميل الـ APK إلى هاتفك (Download APK Artifact)' : 'Download APK Artifact to Phone'}
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                    {isAr 
                      ? 'ادخل إلى تبويب "Actions" في مستودع GitHub الخاص بك، وستجد ملف "ParentGuard-Release-APK" جاهزاً للتحميل مباشرة بصيغة .apk!'
                      : 'Go to your repository Actions tab, open the completed run, and click ParentGuard-Release-APK under Artifacts.'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: INSTANT WEB APK ON PHONE */}
      {activeTab === 'webapk' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-5">
            <div>
              <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest block mb-1">
                {isAr ? 'تثبيت فوري على شاشة الهاتف بدون تحميل ملف خارجي' : 'Direct Installation via WebAPK'}
              </span>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                {isAr ? 'تثبيت ParentGuard كـ WebAPK رسمي على هاتف أندرويد' : 'Install Official WebAPK Directly from Mobile Browser'}
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl leading-relaxed">
                {isAr 
                  ? 'يقوم نظام أندرويد ومتصفح Google Chrome تلقائياً بتجميع ملف APK وتثبيته في قائمة التطبيقات والشاشة الرئيسية مع إشعارات كاملة وأيقونة مخصصة وبدون شريط المتصفح!'
                  : 'Android and Google Chrome can automatically mint and install an official WebAPK into your phone app drawer with standalone windowing and notifications.'}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
              <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700 space-y-2">
                <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 mx-auto flex items-center justify-center font-bold">1</div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">{isAr ? 'افتح الرابط من الهاتف' : 'Open Link on Phone'}</h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  {isAr ? 'افتح رابط التطبيق عبر متصفح Chrome على هاتف الأندرويد.' : 'Open the app URL in Chrome on your Android phone.'}
                </p>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700 space-y-2">
                <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 mx-auto flex items-center justify-center font-bold">2</div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">{isAr ? 'اضغط خيارات (⋮)' : 'Tap Menu (⋮)'}</h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  {isAr ? 'اضغط على النقاط الثلاث في أعلى المتصفح واختر "تثبيت التطبيق" (Install App).' : 'Tap the 3 dots menu and select "Install App" or "Add to Home screen".'}
                </p>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700 space-y-2">
                <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 mx-auto flex items-center justify-center font-bold">3</div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">{isAr ? 'جاهز في قائمة التطبيقات' : 'Ready in App Drawer'}</h4>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  {isAr ? 'يظهر التطبيق فوراً كبرنامج مستقل على هاتفك مع وصول فوري للوحة التحكم.' : 'The app is registered into your app drawer with offline caching.'}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Child Device Installation & Permissions Guide (Crucial for Parent Control) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-4">
        <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400">
          <ShieldCheck className="w-5 h-5" />
          <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
            {isAr ? 'تفعيل تطبيق هاتف الطفل (Child Companion APK) وصلاحيات الحماية القصوى:' : 'Child Companion APK Setup & High-Privilege Activation:'}
          </h3>
        </div>

        <div className="space-y-2.5 text-xs text-slate-600 dark:text-slate-400">
          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700 flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 shrink-0" />
            <div>
              <p className="font-bold text-slate-900 dark:text-white">{isAr ? '1. تثبيت الـ APK وتفعيل مسؤول الجهاز (Device Administrator):' : '1. Enable Device Administrator:'}</p>
              <p className="text-slate-500 dark:text-slate-400 text-[11px] mt-0.5">
                {isAr 
                  ? 'يمنع الطفل نهائياً من إلغاء تثبيت التطبيق ويسمح لولي الأمر بقفل الشاشة وتعيين رسالة القفل عن بعد.'
                  : 'Prevents child from uninstalling the app and gives parent remote lock capability.'}
              </p>
            </div>
          </div>

          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700 flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 shrink-0" />
            <div>
              <p className="font-bold text-slate-900 dark:text-white">{isAr ? '2. تفعيل خدمة إمكانية الوصول (Accessibility Service):' : '2. Enable Accessibility Service:'}</p>
              <p className="text-slate-500 dark:text-slate-400 text-[11px] mt-0.5">
                {isAr 
                  ? 'تسمح باكتشاف فوري لتشغيل أي تطبيق محظور (مثل تيك توك، يوتيوب، الألعاب) وإغلاقه في 0 جزء من الثانية.'
                  : 'Detects blocked app launches in 0ms and closes them before the child can use them.'}
              </p>
            </div>
          </div>

          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200/70 dark:border-slate-700 flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 shrink-0" />
            <div>
              <p className="font-bold text-slate-900 dark:text-white">{isAr ? '3. استثناء التطبيق من توفير شحن البطارية (Battery Optimization):' : '3. Ignore Battery Optimizations:'}</p>
              <p className="text-slate-500 dark:text-slate-400 text-[11px] mt-0.5">
                {isAr 
                  ? 'يضمن استمرار التتبع الجغرافي والاتصال السريع للكاميرا والمايك في الخلفية 24/7 دون أن يوقفه نظام أندرويد.'
                  : 'Ensures GPS location and telemetry stream 24/7 in background without OS throttling.'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
