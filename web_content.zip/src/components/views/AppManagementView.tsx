import React, { useState } from 'react';
import { useParentControl } from '../../context/ParentControlContext';
import { CURATED_APPS_STORE } from '../../data/mockData';
import { AppCategory, InstalledApp } from '../../types';
import { 
  Grid, Search, Filter, Lock, Unlock, Trash2, 
  Download, Plus, Clock, ShieldCheck, AlertCircle, 
  Play, CheckCircle2, X
} from 'lucide-react';

export const AppManagementView: React.FC = () => {
  const { 
    activeDevice, 
    language, 
    toggleAppBlock, 
    setAppLimit, 
    uninstallApp, 
    installApp,
    toggleHardwareSetting,
    launchAppInSimulator
  } = useParentControl();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);
  const [customPackageName, setCustomPackageName] = useState('');
  const [customAppName, setCustomAppName] = useState('');
  const [editingLimitAppId, setEditingLimitAppId] = useState<string | null>(null);
  const [tempLimitMinutes, setTempLimitMinutes] = useState<number>(60);

  if (!activeDevice) return null;

  const isAr = language === 'ar';
  const settings = activeDevice.settings;

  // Filter apps
  const filteredApps = activeDevice.installedApps.filter((app) => {
    const matchesSearch = 
      app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.nameAr.includes(searchQuery) ||
      app.packageName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || app.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories: { id: string; labelAr: string; labelEn: string }[] = [
    { id: 'all', labelAr: 'الكل', labelEn: 'All' },
    { id: 'social', labelAr: 'تواصل اجتماعي', labelEn: 'Social' },
    { id: 'games', labelAr: 'ألعاب', labelEn: 'Games' },
    { id: 'entertainment', labelAr: 'ترفيه وفيديو', labelEn: 'Entertainment' },
    { id: 'education', labelAr: 'تعليم وتطوير', labelEn: 'Education' },
    { id: 'system', labelAr: 'تطبيقات النظام', labelEn: 'System' },
  ];

  const handleOpenLimitModal = (app: InstalledApp) => {
    setEditingLimitAppId(app.id);
    setTempLimitMinutes(app.dailyLimitMinutes || 60);
  };

  const handleSaveLimit = () => {
    if (editingLimitAppId) {
      setAppLimit(editingLimitAppId, tempLimitMinutes);
      setEditingLimitAppId(null);
    }
  };

  const handleInstallCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customAppName.trim()) return;
    installApp({
      name: customAppName,
      nameAr: customAppName,
      packageName: customPackageName || `com.app.${Date.now()}`,
      category: 'utility',
      icon: 'https://cdn-icons-png.flaticon.com/512/1006/1006771.png',
      sizeMb: 50,
    });
    setCustomAppName('');
    setCustomPackageName('');
    setIsInstallModalOpen(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner & Security Policies */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs transition-colors duration-200">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Grid className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
              <span>{isAr ? 'إدارة تطبيقات هاتف الطفل والتحكم الكامل' : 'App Management & Remote Control'}</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {isAr 
                ? `التحكم في ${activeDevice.installedApps.length} تطبيق مثبت على جهاز ${activeDevice.childNameAr} (${activeDevice.deviceName})`
                : `Controlling ${activeDevice.installedApps.length} installed apps on ${activeDevice.childName}'s device`}
            </p>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              id="open-install-app-modal-btn"
              onClick={() => setIsInstallModalOpen(true)}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-semibold flex items-center gap-2 shadow-xs transition-all active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>{isAr ? 'تثبيت تطبيق جديد عن بُعد' : 'Install Remote App'}</span>
            </button>
          </div>
        </div>

        {/* Anti-tamper policies strip */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mt-5 pt-4 border-t border-slate-100 dark:border-slate-800">
          {/* Prevent app installation */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200/70 dark:border-slate-700">
            <div>
              <p className="text-xs font-bold text-slate-900 dark:text-white">
                {isAr ? 'منع تثبيت تطبيقات جديدة' : 'Block App Installations'}
              </p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                {isAr ? 'يمنع متجر Google Play / App Store' : 'Prevents store downloads'}
              </p>
            </div>
            <button
              id="toggle-install-apps-blocked-btn"
              onClick={() => toggleHardwareSetting('installAppsBlocked')}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                settings.installAppsBlocked ? 'bg-indigo-600 justify-end' : 'bg-slate-200 dark:bg-slate-700 justify-start'
              }`}
            >
              <span className="bg-white w-4 h-4 rounded-full shadow-xs" />
            </button>
          </div>

          {/* Prevent app removal */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200/70 dark:border-slate-700">
            <div>
              <p className="text-xs font-bold text-slate-900 dark:text-white">
                {isAr ? 'منع الطفل من حذف التطبيقات' : 'Prevent App Uninstallation'}
              </p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                {isAr ? 'حماية تطبيقات الحماية والأمان' : 'Protects security packages'}
              </p>
            </div>
            <button
              id="toggle-uninstall-apps-blocked-btn"
              onClick={() => toggleHardwareSetting('uninstallAppsBlocked')}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                settings.uninstallAppsBlocked ? 'bg-indigo-600 justify-end' : 'bg-slate-200 dark:bg-slate-700 justify-start'
              }`}
            >
              <span className="bg-white w-4 h-4 rounded-full shadow-xs" />
            </button>
          </div>

          {/* Safe search enforce */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200/70 dark:border-slate-700">
            <div>
              <p className="text-xs font-bold text-slate-900 dark:text-white">
                {isAr ? 'فلتر الويب والبحث الآمن' : 'SafeSearch & Web Filter'}
              </p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                {isAr ? 'حجب المواقع والمحتوى غير اللائق' : 'Restricts adult content'}
              </p>
            </div>
            <button
              id="toggle-safe-search-btn"
              onClick={() => toggleHardwareSetting('safeSearchEnabled')}
              className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                settings.safeSearchEnabled ? 'bg-emerald-600 justify-end' : 'bg-slate-200 dark:bg-slate-700 justify-start'
              }`}
            >
              <span className="bg-white w-4 h-4 rounded-full shadow-xs" />
            </button>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        {/* Search input */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 dark:text-slate-500 absolute start-3.5 top-1/2 -translate-y-1/2" />
          <input
            id="app-search-input"
            type="text"
            placeholder={isAr ? 'ابحث عن اسم التطبيق أو الحزمة...' : 'Search apps by name or package...'}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl py-2.5 ps-10 pe-4 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:border-indigo-600 dark:focus:border-indigo-500 transition-colors shadow-xs"
          />
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedCategory === cat.id
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
              }`}
            >
              {isAr ? cat.labelAr : cat.labelEn}
            </button>
          ))}
        </div>
      </div>

      {/* Apps Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filteredApps.length === 0 ? (
          <div className="col-span-full py-16 text-center text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <AlertCircle className="w-10 h-10 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
            <p className="text-sm font-medium">{isAr ? 'لم يتم العثور على أي تطبيقات تطابق البحث' : 'No apps match your query'}</p>
          </div>
        ) : (
          filteredApps.map((app) => {
            return (
              <div
                key={app.id}
                className={`flex flex-col justify-between p-4 rounded-2xl border transition-all ${
                  app.isBlocked
                    ? 'bg-rose-50/40 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/60 shadow-xs'
                    : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 shadow-xs'
                }`}
              >
                <div>
                  {/* Card Header: Icon, Name, Category */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <img 
                          src={app.icon} 
                          alt={app.name} 
                          className="w-12 h-12 rounded-xl object-contain p-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs" 
                        />
                        {app.isBlocked && (
                          <div className="absolute -top-1 -end-1 bg-rose-600 text-white rounded-full p-0.5 border-2 border-white dark:border-slate-900 shadow-xs">
                            <Lock className="w-3 h-3" />
                          </div>
                        )}
                      </div>

                      <div>
                        <h4 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                          <span>{isAr ? app.nameAr : app.name}</span>
                        </h4>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono truncate max-w-[150px]">
                          {app.packageName}
                        </p>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="text-[10px] px-2 py-0.2 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono">
                            {app.sizeMb} MB
                          </span>
                          <span className="text-[10px] px-2 py-0.2 rounded-md bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-medium">
                            v{app.version}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Block / Unblock Toggle Button */}
                    <button
                      id={`toggle-app-block-${app.id}`}
                      onClick={() => toggleAppBlock(app.id)}
                      className={`p-2 rounded-xl border transition-all active:scale-95 shadow-xs ${
                        app.isBlocked
                          ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800 hover:bg-rose-100 dark:hover:bg-rose-900/60'
                          : 'bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                      }`}
                      title={app.isBlocked ? (isAr ? 'فك حظر التطبيق' : 'Unblock App') : (isAr ? 'حظر هذا التطبيق' : 'Block App')}
                    >
                      {app.isBlocked ? <Lock className="w-4 h-4 text-rose-600 dark:text-rose-400" /> : <Unlock className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />}
                    </button>
                  </div>

                  {/* Usage stats & limit */}
                  <div className="mt-4 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700 space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500 dark:text-slate-400">{isAr ? 'الاستخدام اليوم:' : 'Usage today:'}</span>
                      <span className="font-mono font-bold text-slate-900 dark:text-white">
                        {app.usedMinutesToday} {isAr ? 'دقيقة' : 'mins'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500 dark:text-slate-400">{isAr ? 'الحد اليومي المسموح:' : 'Daily Limit:'}</span>
                      <button
                        onClick={() => handleOpenLimitModal(app)}
                        className="text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 font-medium flex items-center gap-1 underline underline-offset-2"
                      >
                        <Clock className="w-3 h-3" />
                        <span>{app.dailyLimitMinutes > 0 ? `${app.dailyLimitMinutes} ${isAr ? 'دقيقة' : 'mins'}` : (isAr ? 'مفتوح (بلا حد)' : 'Unlimited')}</span>
                      </button>
                    </div>

                    {/* Mini progress bar */}
                    {app.dailyLimitMinutes > 0 && (
                      <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-1.5 overflow-hidden mt-1">
                        <div 
                          className={`h-full rounded-full ${
                            app.usedMinutesToday >= app.dailyLimitMinutes ? 'bg-rose-500' : 'bg-indigo-600'
                          }`}
                          style={{
                            width: `${Math.min(100, Math.round((app.usedMinutesToday / app.dailyLimitMinutes) * 100))}%`
                          }}
                        />
                      </div>
                    )}
                  </div>
                </div>

                {/* Bottom Actions Bar */}
                <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 gap-2">
                  <button
                    onClick={() => launchAppInSimulator(app.id)}
                    className="px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 text-xs font-medium flex items-center gap-1.5 transition-colors shadow-xs"
                  >
                    <Play className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                    <span>{isAr ? 'فتح بالمحاكي' : 'Simulator'}</span>
                  </button>

                  <div className="flex items-center gap-1.5">
                    {/* Limit edit */}
                    <button
                      onClick={() => handleOpenLimitModal(app)}
                      className="px-2.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 text-xs font-medium flex items-center gap-1 transition-colors shadow-xs"
                    >
                      <Clock className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                      <span>{isAr ? 'تحديد وقت' : 'Limit'}</span>
                    </button>

                    {/* Uninstall button (disabled for system apps) */}
                    {!app.isSystemApp && (
                      <button
                        onClick={() => {
                          if (confirm(isAr ? `هل أنت متأكد من حذف تطبيق "${app.nameAr}" عن بُعد من هاتف الطفل؟` : `Uninstall "${app.name}" remotely?`)) {
                            uninstallApp(app.id);
                          }
                        }}
                        className="p-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/60 hover:bg-rose-100 dark:hover:bg-rose-900/60 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800 text-xs transition-colors shadow-xs"
                        title={isAr ? 'حذف التطبيق عن بُعد' : 'Uninstall Remotely'}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* MODAL: Time Limit Picker */}
      {editingLimitAppId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 w-full max-w-sm shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Clock className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                <span>{isAr ? 'تحديد الحد اليومي للتطبيق' : 'Set Daily Time Limit'}</span>
              </h3>
              <button 
                onClick={() => setEditingLimitAppId(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-center py-2">
              <span className="text-3xl font-extrabold text-indigo-600 dark:text-indigo-400 font-mono">
                {tempLimitMinutes === 0 ? (isAr ? 'بلا حدود' : 'Unlimited') : `${tempLimitMinutes} ${isAr ? 'دقيقة' : 'mins'}`}
              </span>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                {tempLimitMinutes > 0 && `(${Math.floor(tempLimitMinutes / 60)} ساعة و ${tempLimitMinutes % 60} دقيقة)`}
              </p>
            </div>

            {/* Slider */}
            <input 
              type="range"
              min="0"
              max="240"
              step="15"
              value={tempLimitMinutes}
              onChange={(e) => setTempLimitMinutes(Number(e.target.value))}
              className="w-full accent-indigo-600 cursor-pointer"
            />

            {/* Preset quick buttons */}
            <div className="grid grid-cols-4 gap-1.5 pt-1">
              {[15, 30, 60, 120].map((m) => (
                <button
                  key={m}
                  onClick={() => setTempLimitMinutes(m)}
                  className={`py-1.5 rounded-xl text-xs font-semibold border ${
                    tempLimitMinutes === m
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700'
                  }`}
                >
                  {m} {isAr ? 'د' : 'm'}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={handleSaveLimit}
                className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors"
              >
                {isAr ? 'حفظ وتطبيق الحد' : 'Save & Apply'}
              </button>
              <button
                onClick={() => setEditingLimitAppId(null)}
                className="py-2.5 px-4 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-xs font-medium rounded-xl transition-colors shadow-xs"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: Remote App Install from Curated Store or Custom */}
      {isInstallModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 w-full max-w-lg shadow-xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div>
                <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Download className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                  <span>{isAr ? 'تثبيت تطبيقات آمنة عن بُعد' : 'Remote App Installation'}</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  {isAr ? 'اختر من التطبيقات التعليمية المعتمدة أو أدخل اسم حزمة لتثبيتها فوراً' : 'Select curated educational apps or enter package identifier'}
                </p>
              </div>
              <button 
                onClick={() => setIsInstallModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Curated list */}
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider">
                {isAr ? 'تطبيقات تعليمية وترفيهية آمنة موصى بها:' : 'Curated Safe Apps:'}
              </h4>

              {CURATED_APPS_STORE.map((storeApp) => {
                const isAlreadyInstalled = activeDevice.installedApps.some(a => a.packageName === storeApp.packageName);

                return (
                  <div 
                    key={storeApp.id}
                    className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <img src={storeApp.icon} alt={storeApp.name} className="w-10 h-10 rounded-xl object-contain p-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs" />
                      <div>
                        <p className="text-xs font-bold text-slate-900 dark:text-white">{isAr ? storeApp.nameAr : storeApp.name}</p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">{storeApp.descriptionAr}</p>
                        <span className="text-[10px] text-indigo-600 dark:text-indigo-400 font-mono font-semibold">{storeApp.sizeMb} MB</span>
                      </div>
                    </div>

                    <button
                      disabled={isAlreadyInstalled}
                      onClick={() => {
                        installApp({
                          name: storeApp.name,
                          nameAr: storeApp.nameAr,
                          packageName: storeApp.packageName,
                          category: storeApp.category as any,
                          icon: storeApp.icon,
                          sizeMb: storeApp.sizeMb,
                        });
                        setIsInstallModalOpen(false);
                      }}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors border shadow-xs ${
                        isAlreadyInstalled
                          ? 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500 border-slate-200 dark:border-slate-700 cursor-not-allowed'
                          : 'bg-indigo-600 hover:bg-indigo-700 text-white border-transparent'
                      }`}
                    >
                      {isAlreadyInstalled ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                          <span>{isAr ? 'مثبت' : 'Installed'}</span>
                        </>
                      ) : (
                        <>
                          <Download className="w-3.5 h-3.5" />
                          <span>{isAr ? 'تثبيت' : 'Install'}</span>
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>

            {/* Custom App Form */}
            <form onSubmit={handleInstallCustom} className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-3">
              <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300">
                {isAr ? 'أو تثبيت تطبيق مخصص بواسطة اسم الحزمة:' : 'Or Install Custom Package:'}
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder={isAr ? 'اسم التطبيق (مثال: نون كيدز)' : 'App Name'}
                  value={customAppName}
                  onChange={(e) => setCustomAppName(e.target.value)}
                  className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:border-indigo-600 dark:focus:border-indigo-500 shadow-xs"
                />
                <input
                  type="text"
                  placeholder={isAr ? 'اسم الحزمة (مثال: com.noon.kids)' : 'Package Name'}
                  value={customPackageName}
                  onChange={(e) => setCustomPackageName(e.target.value)}
                  className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:border-indigo-600 dark:focus:border-indigo-500 shadow-xs"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsInstallModalOpen(false)}
                  className="px-4 py-2 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-xs font-medium rounded-xl shadow-xs"
                >
                  {isAr ? 'إغلاق' : 'Close'}
                </button>
                <button
                  type="submit"
                  disabled={!customAppName.trim()}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-semibold rounded-xl shadow-xs"
                >
                  {isAr ? 'إرسال أمر التثبيت' : 'Push Install'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
