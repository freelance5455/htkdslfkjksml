import React, { useState, useMemo } from 'react';
import {
  RotateCw,
  Search,
  SlidersHorizontal,
  UserPlus,
  Phone,
  MessageCircle,
  Trash2,
  Edit2,
  ChevronRight,
  Plus,
  Minus,
  CheckCircle2,
  X,
  Wallet,
  Calendar,
  AlertCircle,
  Printer,
  Share2,
  Handshake,
  ShoppingCart,
  ArrowDownLeft,
  ArrowUpRight,
  ArrowUpDown,
  Users,
  Receipt,
  Clock,
} from 'lucide-react';
import { Account, Transaction, AppSettings, Category } from '../../types';
import { formatCurrency, formatDate, toBanglaDigits } from '../../utils/formatters';
import { getDualAccentInfo } from '../../utils/theme';
import { storage } from '../../utils/storage';

interface LoanViewProps {
  accounts: Account[];
  transactions: Transaction[];
  categories: Category[];
  appSettings: AppSettings;
  useBanglaDigits: boolean;
  onBack: () => void;
  onAddAccount: (account: Omit<Account, 'id'>) => Account;
  onUpdateAccount: (account: Account) => void;
  onDeleteAccount: (id: string) => void;
  onAddTransaction: (tx: Omit<Transaction, 'id' | 'createdAt'>) => void;
}

type FilterType = 'all' | 'receivable' | 'payable' | 'settled';
type SubTabType = 'accounts' | 'transactions';
type TxSortType = 'date_desc' | 'date_asc' | 'amount_desc' | 'amount_asc';

export const LoanView: React.FC<LoanViewProps> = ({
  accounts,
  transactions,
  categories,
  appSettings,
  useBanglaDigits,
  onBack,
  onAddAccount,
  onUpdateAccount,
  onDeleteAccount,
  onAddTransaction,
}) => {
  const isLight = appSettings.themeMode === 'light';
  const isOled = appSettings.themeMode === 'oled';
  const isEn = appSettings.language === 'en';

  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );

  const cardBg = isLight
    ? 'bg-white border-slate-200/90 shadow-xs'
    : isOled
    ? 'bg-black border-slate-800 shadow-md'
    : 'bg-slate-900/90 border-slate-750/80 shadow-md';

  const innerCardBg = isLight
    ? 'bg-slate-50/80 border-slate-200/70'
    : isOled
    ? 'bg-zinc-950 border-slate-850'
    : 'bg-slate-850/90 border-slate-750/60';

  const headingText = isLight ? 'text-slate-900' : 'text-slate-100';
  const subText = isLight ? 'text-slate-500' : 'text-slate-400';

  // States
  const [activeSubTab, setActiveSubTab] = useState<SubTabType>('accounts');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<FilterType>('all');
  const [showFilterMenu, setShowFilterMenu] = useState(true);
  const [txSortOrder, setTxSortOrder] = useState<TxSortType>('date_desc');
  const [ledgerSortOrder, setLedgerSortOrder] = useState<'date_desc' | 'date_asc'>('date_desc');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Modals
  const [isAddAccountModalOpen, setIsAddAccountModalOpen] = useState(false);
  const [selectedAccountForLedger, setSelectedAccountForLedger] = useState<Account | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [accountToEdit, setAccountToEdit] = useState<Account | null>(null);

  // Quick transaction within Ledger modal: 'gave' (টাকা দিয়েছি) | 'received' (টাকা পেয়েছি) | 'credit_purchase' (ধারে পণ্য কেনা)
  const [ledgerTxType, setLedgerTxType] = useState<'gave' | 'received' | 'credit_purchase' | null>(null);
  const [ledgerTxAmount, setLedgerTxAmount] = useState('');
  const [ledgerTxCategory, setLedgerTxCategory] = useState('exp_grocery');
  const [ledgerTxWalletId, setLedgerTxWalletId] = useState('acc_cash');
  const [ledgerTxDate, setLedgerTxDate] = useState(new Date().toISOString().split('T')[0]);
  const [ledgerTxNote, setLedgerTxNote] = useState('');

  // Add Account Form State
  const [newAccName, setNewAccName] = useState('');
  const [newAccPhone, setNewAccPhone] = useState('');
  const [newAccType, setNewAccType] = useState<'receivable' | 'payable'>('receivable');
  const [newAccAmount, setNewAccAmount] = useState('');
  const [newAccDate, setNewAccDate] = useState(new Date().toISOString().split('T')[0]);
  const [newAccWalletId, setNewAccWalletId] = useState<string>('none');
  const [newAccNotes, setNewAccNotes] = useState('');

  // Show temporary toast
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2400);
  };

  // Re-calculate updated balances using double entry
  const balancedAccounts = useMemo(() => {
    return storage.calculateAccountBalances(accounts, transactions);
  }, [accounts, transactions]);

  // Filter only receivable and payable accounts
  const loanAccounts = useMemo(() => {
    return balancedAccounts.filter(
      (acc) => acc.type === 'receivable' || acc.type === 'payable'
    );
  }, [balancedAccounts]);

  // Wallet accounts for paying/receiving money (Cash, bKash, Nagad, Bank)
  const walletAccounts = useMemo(() => {
    return balancedAccounts.filter(
      (acc) => acc.type !== 'receivable' && acc.type !== 'payable'
    );
  }, [balancedAccounts]);

  // Calculate 3 summary cards & live count badges
  const {
    totalReceivable,
    totalPayable,
    receivableCount,
    payableCount,
    settledCount,
  } = useMemo(() => {
    let rec = 0;
    let pay = 0;
    let recCount = 0;
    let payCount = 0;
    let setlCount = 0;

    loanAccounts.forEach((acc) => {
      const bal = acc.currentBalance ?? acc.openingBalance ?? 0;
      if (Math.abs(bal) < 0.01) {
        setlCount += 1;
      } else if (acc.type === 'receivable') {
        if (bal > 0) {
          rec += bal;
          recCount += 1;
        } else {
          pay += Math.abs(bal);
          payCount += 1;
        }
      } else if (acc.type === 'payable') {
        if (bal > 0) {
          pay += bal;
          payCount += 1;
        } else {
          rec += Math.abs(bal);
          recCount += 1;
        }
      }
    });

    return {
      totalReceivable: rec,
      totalPayable: pay,
      receivableCount: recCount,
      payableCount: payCount,
      settledCount: setlCount,
    };
  }, [loanAccounts]);

  // Filtered loan accounts based on search query & filter pill
  const filteredAccounts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return loanAccounts.filter((acc) => {
      const bal = acc.currentBalance ?? acc.openingBalance ?? 0;
      const isSettled = Math.abs(bal) < 0.01;

      // Filter Type Check - Fixed so receivable and payable are strictly mutually exclusive
      if (filterType === 'receivable') {
        const willReceive =
          (acc.type === 'receivable' && bal > 0) ||
          (acc.type === 'payable' && bal < 0);
        if (!willReceive) return false;
      } else if (filterType === 'payable') {
        const willPay =
          (acc.type === 'payable' && bal > 0) ||
          (acc.type === 'receivable' && bal < 0);
        if (!willPay) return false;
      } else if (filterType === 'settled') {
        if (!isSettled) return false;
      }

      // Search Query Check
      if (q) {
        const nameBn = (acc.nameBangla || '').toLowerCase();
        const nameEn = (acc.nameEnglish || '').toLowerCase();
        const phone = (acc.phoneNumber || acc.accountNumber || '').toLowerCase();
        const notes = (acc.notes || '').toLowerCase();
        return (
          nameBn.includes(q) ||
          nameEn.includes(q) ||
          phone.includes(q) ||
          notes.includes(q)
        );
      }

      return true;
    });
  }, [loanAccounts, searchQuery, filterType]);

  // Classified Loan Transactions for the Ledger & Transactions View
  interface ClassifiedLoanTx {
    tx: Transaction;
    account?: Account;
    partyName: string;
    flowType: 'receivable' | 'payable';
    actionLabelBangla: string;
    actionLabelEnglish: string;
    badgeClass: string;
    sign: '+' | '-';
    amountColorClass: string;
    impactBangla: string;
    impactEnglish: string;
    walletAccount?: Account;
  }

  const allLoanTransactions = useMemo(() => {
    const result: ClassifiedLoanTx[] = [];

    for (const tx of transactions) {
      // 1. Find linked loan account
      const linkedAccount = loanAccounts.find(
        (a) =>
          a.id === tx.accountId ||
          a.id === tx.fromAccountId ||
          a.id === tx.toAccountId ||
          a.id === tx.ledgerAccountId
      );

      // 2. Check fallback by note or default accounts
      let flowType: 'receivable' | 'payable' | null = null;
      let targetAccount = linkedAccount;

      if (linkedAccount) {
        flowType = linkedAccount.type === 'receivable' ? 'receivable' : 'payable';
      } else if (
        tx.accountId === 'acc_receivable' ||
        tx.fromAccountId === 'acc_receivable' ||
        tx.toAccountId === 'acc_receivable'
      ) {
        flowType = 'receivable';
        targetAccount = balancedAccounts.find((a) => a.id === 'acc_receivable');
      } else if (
        tx.accountId === 'acc_payable' ||
        tx.fromAccountId === 'acc_payable' ||
        tx.toAccountId === 'acc_payable'
      ) {
        flowType = 'payable';
        targetAccount = balancedAccounts.find((a) => a.id === 'acc_payable');
      } else {
        const note = (tx.note || '').toLowerCase();
        if (
          note.includes('receivable') ||
          note.includes('ধার দেওয়া') ||
          note.includes('দেনাদার')
        ) {
          flowType = 'receivable';
          targetAccount = balancedAccounts.find((a) => a.type === 'receivable');
        } else if (
          note.includes('payable') ||
          note.includes('ধার নেওয়া') ||
          note.includes('পাওনাদার') ||
          note.includes('লোন')
        ) {
          flowType = 'payable';
          targetAccount = balancedAccounts.find((a) => a.type === 'payable');
        }
      }

      if (!flowType) continue;

      // 3. Determine Party Name
      let partyName = '';
      if (targetAccount) {
        partyName = isEn ? targetAccount.nameEnglish : targetAccount.nameBangla;
      } else if (tx.ledgerPerson) {
        partyName = tx.ledgerPerson;
      } else {
        partyName =
          flowType === 'receivable'
            ? isEn
              ? 'Receivables / Debtor'
              : 'দেনাদার'
            : isEn
            ? 'Payables / Creditor'
            : 'পাওনাদার';
      }

      // 4. Determine Wallet Account
      const walletAcc = balancedAccounts.find(
        (a) =>
          a.type !== 'receivable' &&
          a.type !== 'payable' &&
          (a.id === tx.accountId ||
            a.id === tx.fromAccountId ||
            a.id === tx.toAccountId)
      );

      // 5. Determine Classification Details
      if (flowType === 'receivable') {
        const isDebtIncrease =
          tx.type === 'expense' ||
          (tx.type === 'transfer' && tx.toAccountId === targetAccount?.id) ||
          (tx.ledgerAccountId === targetAccount?.id && tx.type === 'expense');

        if (isDebtIncrease) {
          result.push({
            tx,
            account: targetAccount,
            partyName,
            flowType: 'receivable',
            actionLabelBangla: 'ঋণ প্রদান / ধার দেওয়া',
            actionLabelEnglish: 'Loan Given',
            badgeClass:
              'bg-cyan-100 text-cyan-800 dark:bg-cyan-950/70 dark:text-cyan-300 border border-cyan-200 dark:border-cyan-800',
            sign: '+',
            amountColorClass: 'text-cyan-600 dark:text-cyan-400',
            impactBangla: 'পাওনা বৃদ্ধি',
            impactEnglish: 'Receivable increased',
            walletAccount: walletAcc,
          });
        } else {
          result.push({
            tx,
            account: targetAccount,
            partyName,
            flowType: 'receivable',
            actionLabelBangla: 'টাকা আদায় / ফেরত',
            actionLabelEnglish: 'Payment Received',
            badgeClass:
              'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800',
            sign: '-',
            amountColorClass: 'text-emerald-600 dark:text-emerald-400',
            impactBangla: 'পাওনা আদায়',
            impactEnglish: 'Receivable collected',
            walletAccount: walletAcc,
          });
        }
      } else {
        // Payable
        if (tx.type === 'expense' && tx.accountId === targetAccount?.id) {
          result.push({
            tx,
            account: targetAccount,
            partyName,
            flowType: 'payable',
            actionLabelBangla: 'ধারে পণ্য ক্রয়',
            actionLabelEnglish: 'Credit Purchase',
            badgeClass:
              'bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300 border border-amber-200 dark:border-amber-800',
            sign: '+',
            amountColorClass: 'text-amber-600 dark:text-amber-400',
            impactBangla: 'দেনা বৃদ্ধি',
            impactEnglish: 'Debt increased',
            walletAccount: walletAcc,
          });
        } else if (
          (tx.type === 'transfer' && tx.toAccountId === targetAccount?.id) ||
          (tx.type === 'expense' && tx.ledgerAccountId === targetAccount?.id)
        ) {
          result.push({
            tx,
            account: targetAccount,
            partyName,
            flowType: 'payable',
            actionLabelBangla: 'ঋণ পরিশোধ / শোধ',
            actionLabelEnglish: 'Debt Repaid',
            badgeClass:
              'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800',
            sign: '-',
            amountColorClass: 'text-emerald-600 dark:text-emerald-400',
            impactBangla: 'দেনা হ্রাস',
            impactEnglish: 'Debt reduced',
            walletAccount: walletAcc,
          });
        } else {
          result.push({
            tx,
            account: targetAccount,
            partyName,
            flowType: 'payable',
            actionLabelBangla: 'ধার গ্রহণ / ঋণ নেওয়া',
            actionLabelEnglish: 'Loan Taken',
            badgeClass:
              'bg-rose-100 text-rose-800 dark:bg-rose-950/70 dark:text-rose-300 border border-rose-200 dark:border-rose-800',
            sign: '+',
            amountColorClass: 'text-rose-600 dark:text-rose-400',
            impactBangla: 'দেনা বৃদ্ধি',
            impactEnglish: 'Debt increased',
            walletAccount: walletAcc,
          });
        }
      }
    }

    return result;
  }, [transactions, loanAccounts, balancedAccounts, isEn]);

  // Transaction counts for filter pills
  const { receivableTxCount, payableTxCount } = useMemo(() => {
    let rec = 0;
    let pay = 0;
    allLoanTransactions.forEach((item) => {
      if (item.flowType === 'receivable') rec += 1;
      if (item.flowType === 'payable') pay += 1;
    });
    return { receivableTxCount: rec, payableTxCount: pay };
  }, [allLoanTransactions]);

  // Filtered loan transactions based on filterType, search query & sorting
  const filteredLoanTransactions = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();

    const list = allLoanTransactions.filter((item) => {
      if (filterType === 'receivable') {
        if (item.flowType !== 'receivable') return false;
      } else if (filterType === 'payable') {
        if (item.flowType !== 'payable') return false;
      } else if (filterType === 'settled') {
        const bal = item.account
          ? item.account.currentBalance ?? item.account.openingBalance ?? 0
          : null;
        if (bal === null || Math.abs(bal) >= 0.01) return false;
      }

      if (q) {
        const party = item.partyName.toLowerCase();
        const note = (item.tx.note || '').toLowerCase();
        const amtStr = item.tx.amount.toString();
        const dateStr = item.tx.date.toLowerCase();
        return (
          party.includes(q) ||
          note.includes(q) ||
          amtStr.includes(q) ||
          dateStr.includes(q)
        );
      }

      return true;
    });

    return list.sort((a, b) => {
      if (txSortOrder === 'date_desc') {
        const d = new Date(b.tx.date).getTime() - new Date(a.tx.date).getTime();
        return d !== 0 ? d : (b.tx.createdAt || 0) - (a.tx.createdAt || 0);
      }
      if (txSortOrder === 'date_asc') {
        const d = new Date(a.tx.date).getTime() - new Date(b.tx.date).getTime();
        return d !== 0 ? d : (a.tx.createdAt || 0) - (b.tx.createdAt || 0);
      }
      if (txSortOrder === 'amount_desc') {
        return b.tx.amount - a.tx.amount;
      }
      if (txSortOrder === 'amount_asc') {
        return a.tx.amount - b.tx.amount;
      }
      return 0;
    });
  }, [allLoanTransactions, filterType, searchQuery, txSortOrder]);

  // Refresh handler
  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
      triggerToast(isEn ? 'Loan accounts updated' : 'দেনা/পাওনা হিসাব রিফ্রেশ করা হয়েছে');
    }, 450);
  };

  // Print or PDF export for all loan accounts
  const handleExportAllPdf = () => {
    const dateStr = new Date().toLocaleDateString(isEn ? 'en-US' : 'bn-BD', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>${isEn ? 'Loan and Debt Statement' : 'দেনা/পাওনা হিসাব বিবরণী'}</title>
          <meta charset="utf-8" />
          <style>
            @page { size: A4; margin: 15mm; }
            body { font-family: system-ui, -apple-system, sans-serif; padding: 20px; color: #0f172a; line-height: 1.5; font-size: 13px; }
            .header { text-align: center; border-bottom: 2px solid ${dualAccent.primary.hex}; padding-bottom: 12px; margin-bottom: 20px; }
            .title { font-size: 24px; font-weight: bold; color: ${dualAccent.primary.hex}; margin: 0; }
            .subtitle { font-size: 13px; color: #64748b; margin: 4px 0 0; }
            .summary-box { display: flex; gap: 14px; margin-bottom: 22px; }
            .stat-card { flex: 1; padding: 12px; border-radius: 12px; background: #f8fafc; border: 1px solid #cbd5e1; text-align: center; }
            .stat-label { font-size: 12px; font-weight: bold; text-transform: uppercase; margin-bottom: 4px; }
            .stat-val { font-size: 18px; font-weight: 900; }
            .receivable { color: #059669; }
            .payable { color: #dc2626; }
            .transactions { color: ${dualAccent.primary.hex}; }
            table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 12px; }
            th, td { border: 1px solid #cbd5e1; padding: 8px 10px; text-align: left; }
            th { background: #f1f5f9; font-weight: bold; color: #1e293b; }
            tr:nth-child(even) { background: #f8fafc; }
            .badge { display: inline-block; padding: 3px 8px; border-radius: 6px; font-size: 11px; font-weight: bold; }
            .badge-rec { background: #d1fae5; color: #065f46; }
            .badge-pay { background: #fee2e2; color: #991b1b; }
            .badge-settled { background: #e2e8f0; color: #475569; }
            .footer { margin-top: 30px; font-size: 11px; color: #94a3b8; text-align: center; border-top: 1px solid #e2e8f0; padding-top: 10px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1 class="title">${isEn ? 'Onu Finance - Loan & Debt Statement' : 'Onu Finance - দেনা/পাওনা হিসাব বিবরণী'}</h1>
            <p class="subtitle">${isEn ? 'Date of Issue:' : 'প্রতিবেদন তৈরির তারিখ:'} ${dateStr}</p>
          </div>

          <div class="summary-box">
            <div class="stat-card">
              <div class="stat-label receivable">${isEn ? 'I will Receive (Receivables)' : 'আমি পাবো (দেনাদার)'}</div>
              <div class="stat-val receivable">৳ ${totalReceivable.toLocaleString()}</div>
            </div>
            <div class="stat-card">
              <div class="stat-label payable">${isEn ? 'Total Payables (Debt)' : 'মোট দিবো (পাওনাদার)'}</div>
              <div class="stat-val payable">৳ ${totalPayable.toLocaleString()}</div>
            </div>
            <div class="stat-card">
              <div class="stat-label transactions">${isEn ? 'Total Parties/Records' : 'মোট দেনা/পাওনা হিসাব'}</div>
              <div class="stat-val transactions">${loanAccounts.length} টি</div>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th style="width: 40px;">#</th>
                <th>${isEn ? 'Account / Party Name' : 'অ্যাকাউন্ট / ব্যক্তির নাম'}</th>
                <th>${isEn ? 'Phone' : 'মোবাইল'}</th>
                <th>${isEn ? 'Type' : 'ধরণ'}</th>
                <th>${isEn ? 'Notes' : 'বিবরণ / নোট'}</th>
                <th style="text-align: right;">${isEn ? 'Balance (BDT)' : 'জের / ব্যালেন্স (টাকা)'}</th>
              </tr>
            </thead>
            <tbody>
              ${filteredAccounts
                .map((acc, i) => {
                  const bal = acc.currentBalance ?? acc.openingBalance ?? 0;
                  const isRec = acc.type === 'receivable';
                  const isSettled = bal === 0;
                  const badgeClass = isSettled
                    ? 'badge-settled'
                    : isRec
                    ? 'badge-rec'
                    : 'badge-pay';
                  const typeLabel = isSettled
                    ? isEn
                      ? 'Settled'
                      : 'পরিশোধিত'
                    : isRec
                    ? isEn
                      ? 'Receivables (পাবো)'
                      : 'আমি পাবো (দেনাদার)'
                    : isEn
                    ? 'Payables (দিবো)'
                    : 'মোট দিবো (পাওনাদার)';
                  return `
                  <tr>
                    <td>${i + 1}</td>
                    <td style="font-weight: bold;">${isEn ? acc.nameEnglish : acc.nameBangla}</td>
                    <td>${acc.phoneNumber || acc.accountNumber || '-'}</td>
                    <td><span class="badge ${badgeClass}">${typeLabel}</span></td>
                    <td>${acc.notes || '-'}</td>
                    <td style="text-align: right; font-weight: bold; ${
                      bal > 0
                        ? isRec
                          ? 'color: #059669;'
                          : 'color: #dc2626;'
                        : 'color: #475569;'
                    }">৳ ${Math.abs(bal).toLocaleString()}</td>
                  </tr>
                `;
                })
                .join('')}
            </tbody>
          </table>

          <div class="footer">
            ${isEn ? 'Generated securely from Onu Finance App.' : 'Onu Finance অ্যাপ্লিকেশন থেকে প্রস্তুতকৃত।'}
          </div>
        </body>
      </html>
    `;

    printDocumentHtml(htmlContent);
  };

  // Print helper supporting iframe / popup window
  const printDocumentHtml = (htmlContent: string) => {
    try {
      const iframe = document.createElement('iframe');
      iframe.style.position = 'fixed';
      iframe.style.right = '0';
      iframe.style.bottom = '0';
      iframe.style.width = '0';
      iframe.style.height = '0';
      iframe.style.border = '0';
      document.body.appendChild(iframe);
      const doc = iframe.contentWindow?.document;
      if (doc) {
        doc.open();
        doc.write(htmlContent);
        doc.close();
        setTimeout(() => {
          iframe.contentWindow?.focus();
          iframe.contentWindow?.print();
          setTimeout(() => {
            if (document.body.contains(iframe)) {
              document.body.removeChild(iframe);
            }
          }, 2000);
        }, 400);
        return;
      }
    } catch {
      // Fallback to window.open
    }

    const printWin = window.open('', '_blank');
    if (printWin) {
      printWin.document.write(htmlContent);
      printWin.document.close();
      printWin.focus();
      setTimeout(() => {
        printWin.print();
      }, 400);
    }
  };

  // Handle Add New Loan Account
  const handleCreateNewAccount = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = newAccName.trim();
    if (!cleanName) {
      triggerToast(isEn ? 'Please enter a name' : 'অনুগ্রহ করে নাম লিখুন');
      return;
    }

    const amountNum = parseFloat(newAccAmount) || 0;
    const cleanPhone = newAccPhone.trim();

    const created = onAddAccount({
      nameBangla: cleanName,
      nameEnglish: cleanName,
      type: newAccType,
      openingBalance: newAccWalletId === 'none' ? amountNum : 0,
      phoneNumber: cleanPhone,
      accountNumber: cleanPhone,
      notes: newAccNotes.trim() || undefined,
      isCustom: true,
      color: newAccType === 'receivable' ? '#10B981' : '#EF4444',
      icon: newAccType === 'receivable' ? 'ArrowDownLeft' : 'ArrowUpRight',
      createdAt: Date.now(),
    });

    // If source wallet selected and amount > 0, create corresponding wallet adjustment transfer/transaction
    if (newAccWalletId !== 'none' && amountNum > 0) {
      if (newAccType === 'receivable') {
        // Loan given from Wallet to Customer
        onAddTransaction({
          type: 'transfer',
          amount: amountNum,
          categoryId: '',
          paymentMethod: 'cash',
          fromAccountId: newAccWalletId,
          toAccountId: created.id,
          date: newAccDate,
          note: `ঋণ প্রদান: ${cleanName} (${newAccNotes.trim() || 'প্রাথমিক দেনাদার'})`,
        });
      } else {
        // Loan taken from Creditor into Wallet
        onAddTransaction({
          type: 'transfer',
          amount: amountNum,
          categoryId: '',
          paymentMethod: 'cash',
          fromAccountId: created.id,
          toAccountId: newAccWalletId,
          date: newAccDate,
          note: `ঋণ গ্রহণ: ${cleanName} (${newAccNotes.trim() || 'প্রাথমিক পাওনাদার'})`,
        });
      }
    }

    // Reset Form & Close
    setNewAccName('');
    setNewAccPhone('');
    setNewAccAmount('');
    setNewAccNotes('');
    setNewAccWalletId('none');
    setIsAddAccountModalOpen(false);
    triggerToast(isEn ? 'Account created successfully' : 'নতুন অ্যাকাউন্ট সফলভাবে যুক্ত হয়েছে');
  };

  // Transactions linked to the selected account for detailed ledger
  const selectedAccountTransactions = useMemo(() => {
    if (!selectedAccountForLedger) return [];
    return transactions.filter(
      (tx) =>
        tx.accountId === selectedAccountForLedger.id ||
        tx.fromAccountId === selectedAccountForLedger.id ||
        tx.toAccountId === selectedAccountForLedger.id ||
        tx.ledgerAccountId === selectedAccountForLedger.id
    );
  }, [selectedAccountForLedger, transactions]);

  // Chronologically sorted with running balance for ledger modal
  const sortedSelectedAccountTransactionsWithBalance = useMemo(() => {
    if (!selectedAccountForLedger) return [];

    const rawTxs = transactions.filter(
      (tx) =>
        tx.accountId === selectedAccountForLedger.id ||
        tx.fromAccountId === selectedAccountForLedger.id ||
        tx.toAccountId === selectedAccountForLedger.id ||
        tx.ledgerAccountId === selectedAccountForLedger.id
    );

    // Sort chronologically oldest first to calculate running balance
    const chronological = [...rawTxs].sort((a, b) => {
      const d = new Date(a.date).getTime() - new Date(b.date).getTime();
      return d !== 0 ? d : (a.createdAt || 0) - (b.createdAt || 0);
    });

    let running = Number(selectedAccountForLedger.openingBalance) || 0;
    const itemsWithBalance = chronological.map((tx) => {
      const amt = Number(tx.amount) || 0;
      let delta = 0;

      if (selectedAccountForLedger.type === 'payable') {
        if (tx.type === 'income' && tx.accountId === selectedAccountForLedger.id) {
          delta = amt;
        } else if (tx.type === 'expense' && tx.accountId === selectedAccountForLedger.id) {
          delta = amt;
        } else if (tx.type === 'transfer' && tx.toAccountId === selectedAccountForLedger.id) {
          delta = -amt;
        } else if (tx.type === 'transfer' && tx.fromAccountId === selectedAccountForLedger.id) {
          delta = amt;
        } else if (tx.ledgerAccountId === selectedAccountForLedger.id) {
          delta = tx.type === 'expense' ? -amt : amt;
        }
      } else {
        // Receivable
        if (tx.type === 'expense' && tx.accountId === selectedAccountForLedger.id) {
          delta = amt;
        } else if (tx.type === 'income' && tx.accountId === selectedAccountForLedger.id) {
          delta = -amt;
        } else if (tx.type === 'transfer' && tx.toAccountId === selectedAccountForLedger.id) {
          delta = amt;
        } else if (tx.type === 'transfer' && tx.fromAccountId === selectedAccountForLedger.id) {
          delta = -amt;
        } else if (tx.ledgerAccountId === selectedAccountForLedger.id) {
          delta = tx.type === 'expense' ? amt : -amt;
        }
      }

      running += delta;
      return {
        tx,
        runningBalance: running,
      };
    });

    // Sort by user's chosen ledgerSortOrder (default newest first)
    return itemsWithBalance.sort((a, b) => {
      if (ledgerSortOrder === 'date_desc') {
        const d = new Date(b.tx.date).getTime() - new Date(a.tx.date).getTime();
        return d !== 0 ? d : (b.tx.createdAt || 0) - (a.tx.createdAt || 0);
      } else {
        const d = new Date(a.tx.date).getTime() - new Date(b.tx.date).getTime();
        return d !== 0 ? d : (a.tx.createdAt || 0) - (b.tx.createdAt || 0);
      }
    });
  }, [selectedAccountForLedger, transactions, ledgerSortOrder]);

  // Current balance for the ledger modal account
  const currentLedgerAccount = useMemo(() => {
    if (!selectedAccountForLedger) return null;
    return (
      balancedAccounts.find((a) => a.id === selectedAccountForLedger.id) ||
      selectedAccountForLedger
    );
  }, [selectedAccountForLedger, balancedAccounts]);

  // Record a transaction from within the Personal Ledger
  const handleSaveLedgerTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentLedgerAccount) return;

    const amount = parseFloat(ledgerTxAmount);
    if (!amount || amount <= 0) {
      triggerToast(isEn ? 'Please enter a valid amount' : 'সঠিক টাকার পরিমাণ দিন');
      return;
    }

    const isRec = currentLedgerAccount.type === 'receivable';

    if (ledgerTxType === 'credit_purchase') {
      // Buying goods on credit from this creditor -> records expense and increases payable debt!
      onAddTransaction({
        type: 'expense',
        amount,
        categoryId: ledgerTxCategory || 'exp_grocery',
        paymentMethod: 'cash',
        accountId: currentLedgerAccount.id,
        ledgerAccountId: currentLedgerAccount.id,
        ledgerPerson: currentLedgerAccount.nameBangla,
        date: ledgerTxDate,
        note: ledgerTxNote.trim() || (isEn ? `Credit purchase: ${currentLedgerAccount.nameBangla}` : `ধারে পণ্য কেনা: ${currentLedgerAccount.nameBangla}`),
      });
      triggerToast(isEn ? 'Recorded credit purchase' : 'ধারে পণ্য ক্রয়ের হিসাব রেকর্ড হয়েছে');
    } else if (ledgerTxType === 'gave') {
      // User gave money to this person
      if (isRec) {
        // New loan given to customer -> transfers from wallet to customer (increases receivable)
        onAddTransaction({
          type: 'transfer',
          amount,
          categoryId: '',
          paymentMethod: 'cash',
          fromAccountId: ledgerTxWalletId,
          toAccountId: currentLedgerAccount.id,
          date: ledgerTxDate,
          note: ledgerTxNote.trim() || `টাকা প্রদান: ${currentLedgerAccount.nameBangla}`,
        });
      } else {
        // Repaying debt to creditor -> transfers from wallet to creditor (decreases payable)
        onAddTransaction({
          type: 'transfer',
          amount,
          categoryId: '',
          paymentMethod: 'cash',
          fromAccountId: ledgerTxWalletId,
          toAccountId: currentLedgerAccount.id,
          date: ledgerTxDate,
          note: ledgerTxNote.trim() || `ঋণ পরিশোধ: ${currentLedgerAccount.nameBangla}`,
        });
      }
      triggerToast(isEn ? 'Recorded money given' : 'টাকা দেওয়ার হিসাব রেকর্ড হয়েছে');
    } else if (ledgerTxType === 'received') {
      // User received money from this person
      if (isRec) {
        // Customer paid back loan -> transfers from customer to wallet (decreases receivable)
        onAddTransaction({
          type: 'transfer',
          amount,
          categoryId: '',
          paymentMethod: 'cash',
          fromAccountId: currentLedgerAccount.id,
          toAccountId: ledgerTxWalletId,
          date: ledgerTxDate,
          note: ledgerTxNote.trim() || `টাকা গ্রহণ / আদায়: ${currentLedgerAccount.nameBangla}`,
        });
      } else {
        // Borrowed more from creditor -> transfers from creditor to wallet (increases payable)
        onAddTransaction({
          type: 'transfer',
          amount,
          categoryId: '',
          paymentMethod: 'cash',
          fromAccountId: currentLedgerAccount.id,
          toAccountId: ledgerTxWalletId,
          date: ledgerTxDate,
          note: ledgerTxNote.trim() || `ধার গ্রহণ: ${currentLedgerAccount.nameBangla}`,
        });
      }
      triggerToast(isEn ? 'Recorded money received' : 'টাকা পাওয়ার হিসাব রেকর্ড হয়েছে');
    }

    // Reset ledger quick tx form
    setLedgerTxType(null);
    setLedgerTxAmount('');
    setLedgerTxNote('');
  };

  // Delete account confirmation
  const handleDeleteAccountConfirm = (acc: Account) => {
    const isConfirmed = window.confirm(
      isEn
        ? `Are you sure you want to delete ${acc.nameEnglish || acc.nameBangla}?`
        : `আপনি কি নিশ্চিতভাবে "${acc.nameBangla}" অ্যাকাউন্টটি মুছে ফেলতে চান?`
    );
    if (isConfirmed) {
      onDeleteAccount(acc.id);
      setSelectedAccountForLedger(null);
      triggerToast(isEn ? 'Account deleted' : 'অ্যাকাউন্ট মুছে ফেলা হয়েছে');
    }
  };

  return (
    <div className="flex flex-col min-h-full pb-24 relative space-y-4 animate-in fade-in duration-200">
      {/* Toast Banner */}
      {toastMessage && (
        <div className="fixed top-14 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-2xl bg-slate-900/90 dark:bg-white/95 text-white dark:text-slate-950 font-bold text-xs shadow-2xl backdrop-blur-md animate-in slide-in-from-top-4 duration-150">
          {toastMessage}
        </div>
      )}

      {/* Page Title Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="min-w-0">
            <h1 className={`text-xl sm:text-2xl font-black tracking-tight ${headingText} flex items-center gap-2`}>
              <div
                className="w-8 h-8 rounded-xl flex items-center justify-center text-white shrink-0 shadow-sm"
                style={{ background: dualAccent.gradient }}
              >
                <Handshake className="w-4 h-4" />
              </div>
              <span className="truncate">{isEn ? 'Loans & Debts' : 'দেনা/পাওনা হিসাব'}</span>
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {/* Refresh Button */}
          <button
            type="button"
            onClick={handleRefresh}
            className={`p-2 rounded-xl border transition cursor-pointer active:scale-95 ${
              isLight
                ? 'bg-white hover:bg-slate-50 border-slate-200 text-slate-600 shadow-2xs'
                : isOled
                ? 'bg-black hover:bg-zinc-900 border-slate-800 text-slate-300'
                : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-300'
            }`}
            title={isEn ? 'Refresh' : 'রিফ্রেশ করুন'}
            aria-label="Refresh"
          >
            <RotateCw
              className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`}
              style={isRefreshing ? { color: dualAccent.primary.hex } : undefined}
            />
          </button>
        </div>
      </div>

      {/* Top 3-Column Summary Card (আমি পাবো | মোট দিবো | মোট খতিয়ান) with Interactive Filtering */}
      <div
        className={`relative overflow-hidden ${cardBg} border rounded-3xl p-3 sm:p-3.5`}
        style={dualAccent.cardAccentBorder}
      >
        {/* Ambient glows matching theme accents */}
        <div
          className="absolute top-0 right-0 w-28 h-28 rounded-full blur-2xl pointer-events-none opacity-20"
          style={{ backgroundColor: dualAccent.secondary.hex }}
        />
        <div
          className="absolute bottom-0 left-0 w-24 h-24 rounded-full blur-2xl pointer-events-none opacity-15"
          style={{ backgroundColor: dualAccent.primary.hex }}
        />

        <div className="grid grid-cols-3 divide-x divide-slate-200/80 dark:divide-slate-800 items-center text-center relative z-10">
          {/* Column 1: আমি পাবো (Green) - Click to filter receivable */}
          <button
            type="button"
            onClick={() => setFilterType(filterType === 'receivable' ? 'all' : 'receivable')}
            className={`px-1 sm:px-2 py-1 flex flex-col items-center justify-center rounded-2xl transition-all cursor-pointer group ${
              filterType === 'receivable'
                ? 'bg-emerald-50/80 dark:bg-emerald-950/40 ring-1 ring-emerald-500/60 shadow-xs'
                : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
            }`}
            title={isEn ? 'Filter receivable accounts' : 'আমি পাবো ফিল্টার করুন'}
          >
            <div className="flex items-center gap-1 mb-1">
              <span className="text-xs sm:text-[13px] font-bold text-emerald-600 dark:text-emerald-400 leading-none">
                {isEn ? 'I will receive' : 'আমি পাবো'}
              </span>
              <span className="text-[10px] font-extrabold px-1.5 py-0.2 rounded-full bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300">
                {useBanglaDigits ? toBanglaDigits(receivableCount) : receivableCount}
              </span>
            </div>
            <span className={`text-base sm:text-lg lg:text-xl font-black tracking-tight truncate max-w-full text-emerald-600 dark:text-emerald-400`}>
              {formatCurrency(totalReceivable, useBanglaDigits, appSettings.currencySymbol)}
            </span>
            <span className="text-[10px] text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-300 font-medium">
              {filterType === 'receivable' ? (isEn ? '● Active' : '● সক্রিয়') : (isEn ? 'Tap to filter' : 'ক্লিক করুন')}
            </span>
          </button>

          {/* Column 2: মোট দিবো (Red) - Click to filter payable */}
          <button
            type="button"
            onClick={() => setFilterType(filterType === 'payable' ? 'all' : 'payable')}
            className={`px-1 sm:px-2 py-1 flex flex-col items-center justify-center rounded-2xl transition-all cursor-pointer group ${
              filterType === 'payable'
                ? 'bg-rose-50/80 dark:bg-rose-950/40 ring-1 ring-rose-500/60 shadow-xs'
                : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
            }`}
            title={isEn ? 'Filter payable accounts' : 'মোট দিবো ফিল্টার করুন'}
          >
            <div className="flex items-center gap-1 mb-1">
              <span className="text-xs sm:text-[13px] font-bold text-rose-600 dark:text-rose-400 leading-none">
                {isEn ? 'I will pay' : 'মোট দিবো'}
              </span>
              <span className="text-[10px] font-extrabold px-1.5 py-0.2 rounded-full bg-rose-100 dark:bg-rose-900/60 text-rose-800 dark:text-rose-300">
                {useBanglaDigits ? toBanglaDigits(payableCount) : payableCount}
              </span>
            </div>
            <span className={`text-base sm:text-lg lg:text-xl font-black tracking-tight truncate max-w-full text-rose-600 dark:text-rose-400`}>
              {formatCurrency(totalPayable, useBanglaDigits, appSettings.currencySymbol)}
            </span>
            <span className="text-[10px] text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-300 font-medium">
              {filterType === 'payable' ? (isEn ? '● Active' : '● সক্রিয়') : (isEn ? 'Tap to filter' : 'ক্লিক করুন')}
            </span>
          </button>

          {/* Column 3: মোট খতিয়ান (Accent Color) - Click to view all */}
          <button
            type="button"
            onClick={() => setFilterType('all')}
            className={`px-1 sm:px-2 py-1 flex flex-col items-center justify-center rounded-2xl transition-all cursor-pointer group ${
              filterType === 'all'
                ? 'bg-slate-100/60 dark:bg-slate-800/60 ring-1 ring-slate-300 dark:ring-slate-700 shadow-xs'
                : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
            }`}
            title={isEn ? 'Show all accounts' : 'সব হিসাব দেখুন'}
          >
            <span
              className="text-xs sm:text-[13px] font-bold mb-1 leading-none"
              style={{ color: dualAccent.primary.hex }}
            >
              {isEn ? 'Total Accounts' : 'মোট খতিয়ান'}
            </span>
            <span className={`text-base sm:text-lg lg:text-xl font-black tracking-tight ${headingText}`}>
              {useBanglaDigits ? toBanglaDigits(loanAccounts.length) : loanAccounts.length}
            </span>
            <span className="text-[10px] text-slate-400 group-hover:text-slate-600 dark:group-hover:text-slate-300 font-medium">
              {filterType === 'all' ? (isEn ? '● All' : '● সব') : (isEn ? 'Show all' : 'সব দেখুন')}
            </span>
          </button>
        </div>
      </div>

      {/* Sub-Tab Navigation: খতিয়ান তালিকা (Accounts) vs দেনা-পাওনার লেনদেন (Transactions) */}
      <div className="flex items-center p-1 rounded-2xl border bg-slate-100/80 dark:bg-slate-900 border-slate-200/90 dark:border-slate-800">
        <button
          type="button"
          onClick={() => setActiveSubTab('accounts')}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
            activeSubTab === 'accounts'
              ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
          style={activeSubTab === 'accounts' ? dualAccent.cardAccentBorder : undefined}
        >
          <Users className="w-4 h-4" />
          <span>{isEn ? 'Party Accounts' : 'খতিয়ান হিসাব'}</span>
          <span className="text-[11px] font-extrabold px-1.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700/80 text-slate-600 dark:text-slate-300">
            {useBanglaDigits ? toBanglaDigits(loanAccounts.length) : loanAccounts.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('transactions')}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
            activeSubTab === 'transactions'
              ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-xs'
              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
          style={activeSubTab === 'transactions' ? dualAccent.cardAccentBorder : undefined}
        >
          <Receipt className="w-4 h-4" />
          <span>{isEn ? 'Transactions' : 'দেনা-পাওনার লেনদেন'}</span>
          <span className="text-[11px] font-extrabold px-1.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-700/80 text-slate-600 dark:text-slate-300">
            {useBanglaDigits ? toBanglaDigits(allLoanTransactions.length) : allLoanTransactions.length}
          </span>
        </button>
      </div>

      {/* Search & Sorting Toolbar */}
      <div className="flex items-center gap-2">
        <div
          className={`flex-1 flex items-center gap-2.5 px-3.5 py-2.5 rounded-2xl border transition shadow-2xs ${
            isLight
              ? 'bg-white border-slate-200 text-slate-800'
              : isOled
              ? 'bg-black border-slate-800 text-slate-100'
              : 'bg-slate-900/90 border-slate-800 text-slate-100'
          }`}
          style={{
            borderColor: searchQuery ? dualAccent.primary.hex : undefined,
            boxShadow: searchQuery ? `0 0 0 2px ${dualAccent.primary.hex}25` : undefined,
          }}
        >
          <Search
            className="w-4 h-4 shrink-0 transition-colors"
            style={{ color: searchQuery ? dualAccent.primary.hex : '#94a3b8' }}
          />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              activeSubTab === 'accounts'
                ? isEn
                  ? 'Search by name or number...'
                  : 'নাম বা নাম্বার দিয়ে খুঁজুন...'
                : isEn
                ? 'Search transaction or party...'
                : 'লেনদেন বা ব্যক্তির নাম দিয়ে খুঁজুন...'
            }
            className="w-full bg-transparent text-xs sm:text-sm font-medium focus:outline-hidden placeholder:text-slate-400"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="p-1 text-slate-400 hover:text-slate-600 rounded-full cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* If on Transactions subtab, show Sort Selector */}
        {activeSubTab === 'transactions' && (
          <div className="relative">
            <select
              value={txSortOrder}
              onChange={(e) => setTxSortOrder(e.target.value as TxSortType)}
              className={`text-xs font-bold px-2.5 py-2.5 rounded-2xl border transition cursor-pointer appearance-none pr-7 ${
                isLight
                  ? 'bg-white border-slate-200 text-slate-700 shadow-2xs'
                  : isOled
                  ? 'bg-black border-slate-800 text-slate-200'
                  : 'bg-slate-900 border-slate-800 text-slate-200 shadow-sm'
              }`}
            >
              <option value="date_desc">{isEn ? 'Date: Newest first' : 'তারিখ: নতুন আগে'}</option>
              <option value="date_asc">{isEn ? 'Date: Oldest first' : 'তারিখ: পুরাতন আগে'}</option>
              <option value="amount_desc">{isEn ? 'Amount: High to Low' : 'পরিমাণ: বেশি আগে'}</option>
              <option value="amount_asc">{isEn ? 'Amount: Low to High' : 'পরিমাণ: কম আগে'}</option>
            </select>
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-400 absolute right-2 top-3 pointer-events-none" />
          </div>
        )}

        {/* Filter Toggle Button */}
        <button
          type="button"
          onClick={() => setShowFilterMenu((prev) => !prev)}
          className={`p-2.5 sm:p-3 rounded-2xl border transition active:scale-95 cursor-pointer relative ${
            showFilterMenu || filterType !== 'all'
              ? 'text-white shadow-md'
              : isLight
              ? 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700 shadow-2xs'
              : isOled
              ? 'bg-black hover:bg-zinc-900 border-slate-800 text-slate-300'
              : 'bg-slate-900 hover:bg-slate-850 border-slate-800 text-slate-300 shadow-sm'
          }`}
          style={showFilterMenu || filterType !== 'all' ? dualAccent.primaryButtonStyle : undefined}
          title={isEn ? 'Filter Accounts' : 'ফিল্টার অপশন'}
          aria-label="Filter"
        >
          <SlidersHorizontal className="w-4 h-4" />
          {filterType !== 'all' && (
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-rose-500 ring-2 ring-white dark:ring-slate-900" />
          )}
        </button>
      </div>

      {/* Filter Menu Chips */}
      {showFilterMenu && (
        <div
          className={`p-1.5 rounded-2xl border flex items-center gap-1.5 overflow-x-auto scrollbar-none animate-in fade-in slide-in-from-top-2 duration-150 ${
            isLight
              ? 'bg-slate-100/90 border-slate-200/90'
              : isOled
              ? 'bg-zinc-950 border-slate-850'
              : 'bg-slate-900/90 border-slate-800'
          }`}
        >
          <button
            type="button"
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
              filterType === 'all'
                ? 'text-white shadow-xs'
                : isLight
                ? 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
            style={filterType === 'all' ? dualAccent.primaryButtonStyle : undefined}
          >
            <span>{isEn ? 'All' : 'সব'}</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
              filterType === 'all' ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
            }`}>
              {useBanglaDigits
                ? toBanglaDigits(activeSubTab === 'accounts' ? loanAccounts.length : allLoanTransactions.length)
                : (activeSubTab === 'accounts' ? loanAccounts.length : allLoanTransactions.length)}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setFilterType('receivable')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
              filterType === 'receivable'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40'
            }`}
          >
            <span>{isEn ? 'I will receive' : 'আমি পাবো'}</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
              filterType === 'receivable' ? 'bg-white/20 text-white' : 'bg-emerald-100 dark:bg-emerald-900/50 text-emerald-800 dark:text-emerald-300'
            }`}>
              {useBanglaDigits
                ? toBanglaDigits(activeSubTab === 'accounts' ? receivableCount : receivableTxCount)
                : (activeSubTab === 'accounts' ? receivableCount : receivableTxCount)}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setFilterType('payable')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
              filterType === 'payable'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40'
            }`}
          >
            <span>{isEn ? 'I will pay' : 'মোট দিবো'}</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
              filterType === 'payable' ? 'bg-white/20 text-white' : 'bg-rose-100 dark:bg-rose-900/50 text-rose-800 dark:text-rose-300'
            }`}>
              {useBanglaDigits
                ? toBanglaDigits(activeSubTab === 'accounts' ? payableCount : payableTxCount)
                : (activeSubTab === 'accounts' ? payableCount : payableTxCount)}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setFilterType('settled')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
              filterType === 'settled'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <span>{isEn ? 'Settled' : 'পরিশোধিত'}</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
              filterType === 'settled' ? 'bg-white/20 text-white' : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
            }`}>
              {useBanglaDigits ? toBanglaDigits(settledCount) : settledCount}
            </span>
          </button>
        </div>
      )}

      {/* SUB-TAB 1: Accounts List */}
      {activeSubTab === 'accounts' && (
        <>
          {filteredAccounts.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center py-14 px-4">
              <div className="w-20 h-24 mb-4 relative flex items-center justify-center opacity-40">
                <svg
                  viewBox="0 0 72 88"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-full h-full text-slate-400 dark:text-slate-500"
                >
                  <rect x="6" y="4" width="60" height="76" rx="6" stroke="currentColor" strokeWidth="4" />
                  <path d="M18 20H54" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
                  <path d="M18 32H40" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
                  <circle cx="48" cy="32" r="3" fill="currentColor" />
                  <circle cx="56" cy="32" r="3" fill="currentColor" />
                  <path d="M18 44H54" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
                  <path d="M18 56H48" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
                  <path d="M6 72C6 72 16 68 24 74C32 80 40 70 48 74C56 78 66 72 66 72" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
                </svg>
              </div>

              <h3 className={`text-base font-bold mb-1 ${headingText}`}>
                {filterType === 'receivable'
                  ? isEn
                    ? 'No receivable accounts found'
                    : 'কোনো দেনাদার হিসাব নেই (আমি পাবো)'
                  : filterType === 'payable'
                  ? isEn
                    ? 'No payable accounts found'
                    : 'কোনো পাওনাদার হিসাব নেই (মোট দিবো)'
                  : filterType === 'settled'
                  ? isEn
                    ? 'No settled accounts'
                    : 'কোনো পরিশোধিত খতিয়ান নেই'
                  : isEn
                  ? 'No accounts found'
                  : 'কোনো খতিয়ান হিসাব নেই!'}
              </h3>
              <p className={`text-xs max-w-xs leading-relaxed ${subText}`}>
                {isEn
                  ? 'Tap the New Account button below to add a borrower or lender.'
                  : 'নতুন দেনা বা পাওনা হিসাব যোগ করতে নিচের বাটনে চাপ দিন।'}
              </p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {filteredAccounts.map((acc) => {
                const bal = acc.currentBalance ?? acc.openingBalance ?? 0;
                const isSettled = Math.abs(bal) < 0.01;
                // Determine whether this account is currently receivable or payable based on balance
                const isRec =
                  (acc.type === 'receivable' && bal >= 0) ||
                  (acc.type === 'payable' && bal < 0);
                const phone = acc.phoneNumber || acc.accountNumber;

                const initialLetter = (acc.nameBangla || acc.nameEnglish || 'খ')
                  .trim()
                  .charAt(0);

                return (
                  <div
                    key={acc.id}
                    onClick={() => setSelectedAccountForLedger(acc)}
                    className={`flex items-center justify-between gap-3 p-3.5 rounded-2xl border transition-all hover:shadow-md active:scale-[0.99] cursor-pointer ${cardBg}`}
                  >
                    {/* Left: Avatar + Name + Phone / Note */}
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <div
                        className="w-10 h-10 rounded-2xl flex items-center justify-center font-black text-sm text-white shrink-0 shadow-xs"
                        style={{
                          backgroundColor: isSettled
                            ? '#64748b'
                            : isRec
                            ? '#10b981'
                            : '#ef4444',
                        }}
                      >
                        {initialLetter}
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className={`text-sm font-bold truncate ${headingText}`}>
                            {isEn ? acc.nameEnglish : acc.nameBangla}
                          </h4>
                          {isSettled ? (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400">
                              {isEn ? 'Settled' : 'পরিশোধিত'}
                            </span>
                          ) : (
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                isRec
                                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300'
                                  : 'bg-rose-100 text-rose-800 dark:bg-rose-950/70 dark:text-rose-300'
                              }`}
                            >
                              {isRec
                                ? isEn
                                  ? 'Debtor (Receivable)'
                                  : 'দেনাদার (আমি পাবো)'
                                : isEn
                                ? 'Creditor (Payable)'
                                : 'পাওনাদার (মোট দিবো)'}
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                          {phone ? (
                            <span className="flex items-center gap-1 font-mono">
                              <Phone className="w-3 h-3 text-slate-400" />
                              {phone}
                            </span>
                          ) : (
                            <span className={`truncate text-xs ${subText}`}>
                              {acc.notes || (isEn ? 'No phone' : 'নাম্বার নেই')}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Right: Status label + Balance amount */}
                    <div className="flex flex-col items-end justify-center shrink-0 text-right">
                      <span
                        className={`text-[11px] font-bold leading-none mb-1 ${
                          isSettled
                            ? 'text-slate-400'
                            : isRec
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : 'text-rose-600 dark:text-rose-400'
                        }`}
                      >
                        {isSettled
                          ? isEn
                            ? 'Settled'
                            : 'পরিশোধিত'
                          : isRec
                          ? isEn
                            ? 'I will receive'
                            : 'আমি পাবো'
                          : isEn
                          ? 'I will pay'
                          : 'মোট দিবো'}
                      </span>
                      <span
                        className={`text-sm sm:text-base font-black tracking-tight ${
                          isSettled
                            ? 'text-slate-400'
                            : isRec
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : 'text-rose-600 dark:text-rose-400'
                        }`}
                      >
                        {formatCurrency(Math.abs(bal), useBanglaDigits, appSettings.currencySymbol)}
                      </span>
                    </div>

                    <ChevronRight className="w-4 h-4 text-slate-300 dark:text-slate-600 shrink-0" />
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* SUB-TAB 2: Transactions List (সাজানো দেনা-পাওনা লেনদেনসমূহ) */}
      {activeSubTab === 'transactions' && (
        <div className="space-y-3">
          {/* Header Bar */}
          <div className="flex items-center justify-between px-1">
            <span className={`text-xs font-bold uppercase tracking-wider ${subText}`}>
              {isEn ? 'Sorted Transactions' : 'সাজানো দেনা-পাওনার লেনদেন'} (
              {useBanglaDigits ? toBanglaDigits(filteredLoanTransactions.length) : filteredLoanTransactions.length})
            </span>
            <span className="text-[11px] text-slate-400 font-medium">
              {txSortOrder === 'date_desc' && (isEn ? 'Newest first' : 'নতুন আগে')}
              {txSortOrder === 'date_asc' && (isEn ? 'Oldest first' : 'পুরাতন আগে')}
              {txSortOrder === 'amount_desc' && (isEn ? 'Highest first' : 'বেশি আগে')}
              {txSortOrder === 'amount_asc' && (isEn ? 'Lowest first' : 'কম আগে')}
            </span>
          </div>

          {filteredLoanTransactions.length === 0 ? (
            <div className="flex flex-col items-center justify-center text-center py-14 px-4">
              <div className="w-16 h-16 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center mb-3 opacity-60">
                <Receipt className="w-8 h-8 text-slate-400" />
              </div>
              <h3 className={`text-base font-bold mb-1 ${headingText}`}>
                {isEn ? 'No loan transactions found' : 'কোনো লেনদেন পাওয়া যায়নি'}
              </h3>
              <p className={`text-xs max-w-xs leading-relaxed ${subText}`}>
                {isEn
                  ? 'There are no transactions matching your current search or filter criteria.'
                  : 'বর্তমান ফিল্টার বা অনুসন্ধানের সাথে মিল রেখে কোনো দেনা-পাওনার লেনদেন পাওয়া যায়নি।'}
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredLoanTransactions.map((item) => {
                const {
                  tx,
                  account,
                  partyName,
                  flowType,
                  actionLabelBangla,
                  actionLabelEnglish,
                  badgeClass,
                  sign,
                  amountColorClass,
                  impactBangla,
                  impactEnglish,
                  walletAccount,
                } = item;

                return (
                  <div
                    key={tx.id}
                    className={`p-3.5 rounded-2xl border transition-all hover:shadow-md ${cardBg}`}
                  >
                    <div className="flex items-start justify-between gap-2.5">
                      {/* Left: Flow Icon + Party Name + Note */}
                      <div className="flex items-start gap-3 min-w-0 flex-1">
                        <div
                          className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                            flowType === 'receivable'
                              ? sign === '+'
                                ? 'bg-cyan-100 text-cyan-700 dark:bg-cyan-950/80 dark:text-cyan-400'
                                : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-400'
                              : sign === '-'
                              ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-400'
                              : 'bg-rose-100 text-rose-700 dark:bg-rose-950/80 dark:text-rose-400'
                          }`}
                        >
                          {flowType === 'receivable' ? (
                            sign === '+' ? (
                              <ArrowUpRight className="w-5 h-5 stroke-[2.5]" />
                            ) : (
                              <ArrowDownLeft className="w-5 h-5 stroke-[2.5]" />
                            )
                          ) : sign === '-' ? (
                            <ArrowUpRight className="w-5 h-5 stroke-[2.5]" />
                          ) : (
                            <ArrowDownLeft className="w-5 h-5 stroke-[2.5]" />
                          )}
                        </div>

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <button
                              type="button"
                              onClick={() => {
                                if (account) setSelectedAccountForLedger(account);
                              }}
                              className={`text-sm font-bold truncate hover:underline text-left cursor-pointer ${headingText}`}
                              title={isEn ? 'View Ledger' : 'খতিয়ান দেখুন'}
                            >
                              {partyName}
                            </button>
                            <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-md ${badgeClass}`}>
                              {isEn ? actionLabelEnglish : actionLabelBangla}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-1 flex-wrap">
                            <span className="flex items-center gap-1 font-mono">
                              <Calendar className="w-3 h-3 text-slate-400" />
                              {formatDate(tx.date, useBanglaDigits)}
                            </span>
                            {walletAccount && (
                              <span className="flex items-center gap-1">
                                <Wallet className="w-3 h-3 text-slate-400" />
                                {isEn ? walletAccount.nameEnglish : walletAccount.nameBangla}
                              </span>
                            )}
                          </div>

                          {tx.note && (
                            <p className={`text-xs mt-1 truncate ${subText}`}>
                              {tx.note}
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Right: Amount + Impact */}
                      <div className="flex flex-col items-end justify-start shrink-0 text-right">
                        <span className={`text-sm sm:text-base font-black tracking-tight ${amountColorClass}`}>
                          {sign} {formatCurrency(tx.amount, useBanglaDigits, appSettings.currencySymbol)}
                        </span>
                        <span className="text-[10px] text-slate-400 mt-0.5 font-medium">
                          {isEn ? impactEnglish : impactBangla}
                        </span>

                        {account && (
                          <button
                            type="button"
                            onClick={() => setSelectedAccountForLedger(account)}
                            className="text-[10px] font-bold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 mt-1 flex items-center gap-0.5 cursor-pointer underline decoration-dotted"
                          >
                            <span>{isEn ? 'Ledger' : 'খতিয়ান'}</span>
                            <ChevronRight className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Floating Action Button (FAB) at Bottom Right */}
      <div className="fixed sm:absolute bottom-6 right-5 sm:bottom-6 sm:right-6 z-40">
        <button
          type="button"
          onClick={() => setIsAddAccountModalOpen(true)}
          className="text-white font-bold py-3.5 px-5 sm:px-6 rounded-2xl shadow-xl hover:scale-105 active:scale-95 transition-all cursor-pointer flex items-center gap-2 border border-white/20"
          style={dualAccent.buttonStyle}
          id="add-new-loan-account-btn"
        >
          <UserPlus className="w-5 h-5 stroke-[2.5]" />
          <span className="text-sm font-black tracking-wide">
            {isEn ? 'New Account' : 'নতুন খতিয়ান'}
          </span>
        </button>
      </div>

      {/* Modal: Add New Account ("নতুন অ্যাকাউন্ট যোগ করুন") */}
      {isAddAccountModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div
            className={`w-full max-w-md rounded-3xl p-5 border shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto ${
              isLight
                ? 'bg-white border-slate-200 text-slate-900 shadow-2xl'
                : isOled
                ? 'bg-black border-slate-800 text-white shadow-black'
                : 'bg-slate-900 border-slate-700 text-white shadow-2xl'
            }`}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <div
                  className="p-2.5 rounded-xl flex items-center justify-center text-white shrink-0 shadow-xs"
                  style={{
                    background: dualAccent.gradient,
                    boxShadow: `0 4px 12px -2px ${dualAccent.primary.hex}40`,
                  }}
                >
                  <UserPlus className="w-5 h-5 stroke-[2.5]" />
                </div>
                <div>
                  <h3 className={`font-black text-base leading-tight ${headingText}`}>
                    {isEn ? 'New Debt/Loan Account' : 'নতুন দেনা/পাওনা অ্যাকাউন্ট'}
                  </h3>
                  <p className={`text-xs ${subText}`}>
                    {isEn ? 'Customer or supplier khata' : 'গ্রাহক বা সরবরাহকারীর খতিয়ান'}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsAddAccountModalOpen(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleCreateNewAccount} className="space-y-4">
              {/* Type Selector (আমি পাবো vs মোট দিবো) */}
              <div
                className={`grid grid-cols-2 gap-2 p-1 rounded-2xl border ${
                  isLight
                    ? 'bg-slate-100/80 border-slate-200/80'
                    : isOled
                    ? 'bg-zinc-950 border-slate-850'
                    : 'bg-slate-800/80 border-slate-700'
                }`}
              >
                <button
                  type="button"
                  onClick={() => setNewAccType('receivable')}
                  className={`py-2 px-3 rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 cursor-pointer ${
                    newAccType === 'receivable'
                      ? 'bg-emerald-600 text-white shadow-md'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  <span>{isEn ? 'I will Receive (Receivables)' : 'আমি পাবো (দেনাদার)'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setNewAccType('payable')}
                  className={`py-2 px-3 rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 cursor-pointer ${
                    newAccType === 'payable'
                      ? 'bg-rose-600 text-white shadow-md'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  <span>{isEn ? 'I will Pay (Payables)' : 'মোট দিবো (পাওনাদার)'}</span>
                </button>
              </div>

              {/* Name */}
              <div>
                <label className={`block text-xs font-bold mb-1 ${subText}`}>
                  {isEn ? 'Contact / Person Name *' : 'ব্যক্তি বা প্রতিষ্ঠানের নাম *'}
                </label>
                <input
                  type="text"
                  required
                  value={newAccName}
                  onChange={(e) => setNewAccName(e.target.value)}
                  placeholder={isEn ? 'e.g. Rahim Mia, Office Loan' : 'যেমন: রহিম মিয়া, কামাল ভাই'}
                  className={`w-full px-3.5 py-2.5 rounded-2xl border text-sm font-medium focus:outline-hidden transition ${
                    isLight
                      ? 'bg-white border-slate-200 text-slate-900 focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                      : isOled
                      ? 'bg-zinc-950 border-slate-800 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                      : 'bg-slate-800 border-slate-700 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                  }`}
                />
              </div>

              {/* Mobile Phone */}
              <div>
                <label className={`block text-xs font-bold mb-1 ${subText}`}>
                  {isEn ? 'Mobile Number (Optional)' : 'মোবাইল নম্বর (ঐচ্ছিক)'}
                </label>
                <input
                  type="tel"
                  value={newAccPhone}
                  onChange={(e) => setNewAccPhone(e.target.value)}
                  placeholder="01XXXXXXXXX"
                  className={`w-full px-3.5 py-2.5 rounded-2xl border text-sm font-mono focus:outline-hidden transition ${
                    isLight
                      ? 'bg-white border-slate-200 text-slate-900 focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                      : isOled
                      ? 'bg-zinc-950 border-slate-800 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                      : 'bg-slate-800 border-slate-700 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                  }`}
                />
              </div>

              {/* Amount & Date */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={`block text-xs font-bold mb-1 ${subText}`}>
                    {isEn ? 'Opening Balance (৳)' : 'প্রারম্ভিক জের / ব্যালেন্স (৳)'}
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={newAccAmount}
                    onChange={(e) => setNewAccAmount(e.target.value)}
                    placeholder="0.00"
                    className={`w-full px-3.5 py-2.5 rounded-2xl border text-sm font-bold focus:outline-hidden transition ${
                      isLight
                        ? 'bg-white border-slate-200 text-slate-900 focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                        : isOled
                        ? 'bg-zinc-950 border-slate-800 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                        : 'bg-slate-800 border-slate-700 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                    }`}
                  />
                </div>

                <div>
                  <label className={`block text-xs font-bold mb-1 ${subText}`}>
                    {isEn ? 'Date' : 'তারিখ'}
                  </label>
                  <input
                    type="date"
                    value={newAccDate}
                    onChange={(e) => setNewAccDate(e.target.value)}
                    className={`w-full px-3 py-2.5 rounded-2xl border text-xs sm:text-sm focus:outline-hidden transition ${
                      isLight
                        ? 'bg-white border-slate-200 text-slate-900 focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                        : isOled
                        ? 'bg-zinc-950 border-slate-800 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                        : 'bg-slate-800 border-slate-700 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                    }`}
                  />
                </div>
              </div>

              {/* Adjust with wallet? */}
              <div>
                <label className={`block text-xs font-bold mb-1 ${subText}`}>
                  {isEn ? 'Adjust with wallet?' : 'ওয়ালেট থেকে সমন্বয় করবেন?'}
                </label>
                <select
                  value={newAccWalletId}
                  onChange={(e) => setNewAccWalletId(e.target.value)}
                  className={`w-full px-3.5 py-2.5 rounded-2xl border text-xs sm:text-sm focus:outline-hidden transition ${
                    isLight
                      ? 'bg-white border-slate-200 text-slate-900 focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                      : isOled
                      ? 'bg-zinc-950 border-slate-800 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                      : 'bg-slate-800 border-slate-700 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                  }`}
                >
                  <option value="none">
                    {isEn ? 'No (Initial Opening Balance only)' : 'না (কেবলমাত্র প্রারম্ভিক জের হিসেবে)'}
                  </option>
                  {walletAccounts.map((w) => (
                    <option key={w.id} value={w.id}>
                      {isEn ? w.nameEnglish : w.nameBangla} (
                      {formatCurrency(w.currentBalance ?? w.openingBalance ?? 0, useBanglaDigits)})
                    </option>
                  ))}
                </select>
              </div>

              {/* Note / Description */}
              <div>
                <label className={`block text-xs font-bold mb-1 ${subText}`}>
                  {isEn ? 'Note / Description (Optional)' : 'বিবরণ / নোট (ঐচ্ছিক)'}
                </label>
                <input
                  type="text"
                  value={newAccNotes}
                  onChange={(e) => setNewAccNotes(e.target.value)}
                  placeholder={isEn ? 'e.g. Friendly loan, Shop purchase' : 'যেমন: ধার প্রদান, দোকানের বাকী'}
                  className={`w-full px-3.5 py-2.5 rounded-2xl border text-sm font-medium focus:outline-hidden transition ${
                    isLight
                      ? 'bg-white border-slate-200 text-slate-900 focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                      : isOled
                      ? 'bg-zinc-950 border-slate-800 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                      : 'bg-slate-800 border-slate-700 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                  }`}
                />
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddAccountModalOpen(false)}
                  className={`w-1/3 py-3 rounded-2xl border text-xs font-bold transition cursor-pointer ${
                    isLight
                      ? 'border-slate-200 text-slate-600 hover:bg-slate-50'
                      : isOled
                      ? 'border-slate-800 text-slate-300 hover:bg-zinc-900'
                      : 'border-slate-700 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  {isEn ? 'Cancel' : 'বাতিল'}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-2xl text-white text-xs font-black shadow-lg transition active:scale-95 cursor-pointer"
                  style={dualAccent.buttonStyle}
                >
                  {isEn ? 'Create Account' : 'অ্যাকাউন্ট তৈরি করুন'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Personal Detailed Ledger (ব্যক্তির বিস্তারিত খতিয়ান) */}
      {selectedAccountForLedger && currentLedgerAccount && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/65 backdrop-blur-xs animate-in fade-in duration-200">
          <div
            className={`w-full max-w-lg rounded-3xl p-5 border shadow-2xl flex flex-col max-h-[92vh] overflow-hidden ${
              isLight
                ? 'bg-white border-slate-200 text-slate-900 shadow-2xl'
                : isOled
                ? 'bg-black border-slate-800 text-white shadow-black'
                : 'bg-slate-900 border-slate-700 text-white shadow-2xl'
            }`}
          >
            {/* Header */}
            <div className="flex items-start justify-between pb-3.5 border-b border-slate-200 dark:border-slate-800 shrink-0">
              <div className="flex items-center gap-3">
                <div
                  className="w-11 h-11 rounded-2xl flex items-center justify-center text-white font-black text-base shadow-sm shrink-0"
                  style={{
                    backgroundColor:
                      (currentLedgerAccount.currentBalance ?? 0) === 0
                        ? '#64748b'
                        : currentLedgerAccount.type === 'receivable'
                        ? '#10b981'
                        : '#ef4444',
                  }}
                >
                  {(currentLedgerAccount.nameBangla || 'খ').charAt(0)}
                </div>
                <div>
                  <h3 className={`font-black text-base leading-tight ${headingText}`}>
                    {isEn ? currentLedgerAccount.nameEnglish : currentLedgerAccount.nameBangla}
                  </h3>
                  <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-400">
                    {currentLedgerAccount.phoneNumber && (
                      <span className="font-mono flex items-center gap-1">
                        <Phone className="w-3 h-3 text-slate-400" />
                        {currentLedgerAccount.phoneNumber}
                      </span>
                    )}
                    <span>•</span>
                    <span className="font-bold">
                      {currentLedgerAccount.type === 'receivable'
                        ? isEn
                          ? 'Customer / Borrower'
                          : 'দেনাদার'
                        : isEn
                        ? 'Supplier / Lender'
                        : 'পাওনাদার'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1">
                {currentLedgerAccount.phoneNumber && (
                  <a
                    href={`tel:${currentLedgerAccount.phoneNumber}`}
                    className="p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400 transition"
                    title={isEn ? 'Call' : 'কল করুন'}
                  >
                    <Phone className="w-4 h-4" />
                  </a>
                )}

                <button
                  type="button"
                  onClick={() => handleDeleteAccountConfirm(currentLedgerAccount)}
                  className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-950/60 dark:text-rose-400 transition cursor-pointer"
                  title={isEn ? 'Delete Account' : 'অ্যাকাউন্ট মুছুন'}
                >
                  <Trash2 className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setSelectedAccountForLedger(null);
                    setLedgerTxType(null);
                  }}
                  className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Current Balance Banner */}
            <div
              className={`p-3.5 my-3 rounded-2xl border shrink-0 flex items-center justify-between ${
                (currentLedgerAccount.currentBalance ?? 0) === 0
                  ? 'bg-slate-100 dark:bg-slate-800/80 border-slate-200 text-slate-700 dark:text-slate-300'
                  : currentLedgerAccount.type === 'receivable'
                  ? 'bg-emerald-50/90 dark:bg-emerald-950/50 border-emerald-200 text-emerald-950 dark:text-emerald-100'
                  : 'bg-rose-50/90 dark:bg-rose-950/50 border-rose-200 text-rose-950 dark:text-rose-100'
              }`}
            >
              <div>
                <p className="text-xs font-bold text-slate-500 dark:text-slate-400">
                  {isEn ? 'Current Net Position:' : 'বর্তমান জের বা স্থিতি:'}
                </p>
                <p className="text-sm font-black mt-0.5">
                  {(currentLedgerAccount.currentBalance ?? 0) === 0
                    ? isEn
                      ? 'Account Fully Settled (৳0)'
                      : 'হিসাব সম্পূর্ণ পরিশোধিত (৳০)'
                    : currentLedgerAccount.type === 'receivable'
                    ? isEn
                      ? 'You will receive from this person'
                      : 'আপনি এই ব্যক্তির থেকে পাবেন'
                    : isEn
                    ? 'You will pay to this person'
                    : 'আপনি এই ব্যক্তিকে পরিশোধ করবেন'}
                </p>
              </div>
              <div className="text-right">
                <span
                  className={`text-xl font-black ${
                    (currentLedgerAccount.currentBalance ?? 0) === 0
                      ? 'text-slate-600 dark:text-slate-300'
                      : currentLedgerAccount.type === 'receivable'
                      ? 'text-emerald-700 dark:text-emerald-400'
                      : 'text-rose-700 dark:text-rose-400'
                  }`}
                >
                  {formatCurrency(
                    Math.abs(currentLedgerAccount.currentBalance ?? currentLedgerAccount.openingBalance ?? 0),
                    useBanglaDigits,
                    appSettings.currencySymbol
                  )}
                </span>
              </div>
            </div>

            {/* Quick Entry Form (If Gave, Received, or Credit Purchase clicked) */}
            {ledgerTxType && (
              <form
                onSubmit={handleSaveLedgerTransaction}
                className={`p-3.5 rounded-2xl border mb-3 shrink-0 space-y-3 animate-in fade-in slide-in-from-top-2 duration-150 ${innerCardBg}`}
              >
                <div className="flex items-center justify-between">
                  <span
                    className={`text-xs font-black flex items-center gap-1.5 ${
                      ledgerTxType === 'credit_purchase'
                        ? 'text-amber-600 dark:text-amber-400'
                        : ledgerTxType === 'gave'
                        ? currentLedgerAccount.type === 'payable'
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-cyan-600 dark:text-cyan-400'
                        : currentLedgerAccount.type === 'payable'
                        ? 'text-rose-600 dark:text-rose-400'
                        : 'text-emerald-600 dark:text-emerald-400'
                    }`}
                  >
                    {ledgerTxType === 'credit_purchase' ? (
                      <ShoppingCart className="w-4 h-4" />
                    ) : ledgerTxType === 'gave' ? (
                      <Minus className="w-4 h-4" />
                    ) : (
                      <Plus className="w-4 h-4" />
                    )}

                    {ledgerTxType === 'credit_purchase'
                      ? isEn
                        ? 'Credit Purchase (Increases Debt)'
                        : 'ধারে পণ্য কেনা (দেনা বৃদ্ধি)'
                      : ledgerTxType === 'gave'
                      ? currentLedgerAccount.type === 'payable'
                        ? isEn
                          ? 'Repay Debt (Decreases Debt)'
                          : 'টাকা পরিশোধ (দেনা হ্রাস)'
                        : isEn
                        ? 'Give Loan / Goods (Increases Receivable)'
                        : 'টাকা / ঋণ প্রদান (পাওনা বৃদ্ধি)'
                      : currentLedgerAccount.type === 'payable'
                      ? isEn
                        ? 'Borrow Cash (Increases Debt)'
                        : 'নগদ ধার গ্রহণ (দেনা বৃদ্ধি)'
                      : isEn
                      ? 'Payment Received (Decreases Receivable)'
                      : 'টাকা আদায় / ফেরত (পাওনা হ্রাস)'}
                  </span>
                  <button
                    type="button"
                    onClick={() => setLedgerTxType(null)}
                    className="text-xs text-slate-400 hover:text-slate-600 font-bold cursor-pointer"
                  >
                    {isEn ? 'Close' : 'বন্ধ করুন'}
                  </button>
                </div>

                {ledgerTxType === 'credit_purchase' && (
                  <div className="text-[11px] p-2 rounded-xl bg-amber-500/10 text-amber-800 dark:text-amber-300 font-medium border border-amber-500/20">
                    💡 {isEn ? 'No money will be deducted from your wallet. It will be recorded as an expense and will increase your debt to this creditor.' : 'কোনো ওয়ালেট থেকে টাকা কাটবে না। এটি সরাসরি খরচ হিসেবে যুক্ত হয়ে বকেয়া দেনা বৃদ্ধি করবে।'}
                  </div>
                )}

                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className={`block text-[11px] font-bold mb-1 ${subText}`}>
                      {isEn ? 'Amount (৳)' : 'টাকার পরিমাণ (৳)'}
                    </label>
                    <input
                      type="number"
                      required
                      min="1"
                      step="any"
                      autoFocus
                      value={ledgerTxAmount}
                      onChange={(e) => setLedgerTxAmount(e.target.value)}
                      placeholder="0.00"
                      className={`w-full px-3 py-2 rounded-xl border text-sm font-bold focus:outline-hidden transition ${
                        isLight
                          ? 'bg-white border-slate-200 text-slate-900 focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                          : isOled
                          ? 'bg-black border-slate-800 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                          : 'bg-slate-900 border-slate-700 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                      }`}
                    />
                  </div>

                  <div>
                    {ledgerTxType === 'credit_purchase' ? (
                      <>
                        <label className={`block text-[11px] font-bold mb-1 ${subText}`}>
                          {isEn ? 'Category' : 'খরচের খাত'}
                        </label>
                        <select
                          value={ledgerTxCategory}
                          onChange={(e) => setLedgerTxCategory(e.target.value)}
                          className={`w-full px-2.5 py-2 rounded-xl border text-xs focus:outline-hidden transition ${
                            isLight
                              ? 'bg-white border-slate-200 text-slate-900 focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                              : isOled
                              ? 'bg-black border-slate-800 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                              : 'bg-slate-900 border-slate-700 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                          }`}
                        >
                          {categories
                            .filter((c) => c.type === 'expense')
                            .map((c) => (
                              <option key={c.id} value={c.id}>
                                {isEn ? c.nameEnglish : c.nameBangla}
                              </option>
                            ))}
                        </select>
                      </>
                    ) : (
                      <>
                        <label className={`block text-[11px] font-bold mb-1 ${subText}`}>
                          {isEn ? 'Wallet' : 'ওয়ালেট'}
                        </label>
                        <select
                          value={ledgerTxWalletId}
                          onChange={(e) => setLedgerTxWalletId(e.target.value)}
                          className={`w-full px-2.5 py-2 rounded-xl border text-xs focus:outline-hidden transition ${
                            isLight
                              ? 'bg-white border-slate-200 text-slate-900 focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                              : isOled
                              ? 'bg-black border-slate-800 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                              : 'bg-slate-900 border-slate-700 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                          }`}
                        >
                          {walletAccounts.map((w) => (
                            <option key={w.id} value={w.id}>
                              {isEn ? w.nameEnglish : w.nameBangla}
                            </option>
                          ))}
                        </select>
                      </>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className={`block text-[11px] font-bold mb-1 ${subText}`}>
                      {isEn ? 'Date' : 'তারিখ'}
                    </label>
                    <input
                      type="date"
                      value={ledgerTxDate}
                      onChange={(e) => setLedgerTxDate(e.target.value)}
                      className={`w-full px-2.5 py-1.5 rounded-xl border text-xs focus:outline-hidden transition ${
                        isLight
                          ? 'bg-white border-slate-200 text-slate-900 focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                          : isOled
                          ? 'bg-black border-slate-800 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                          : 'bg-slate-900 border-slate-700 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                      }`}
                    />
                  </div>
                  <div>
                    <label className={`block text-[11px] font-bold mb-1 ${subText}`}>
                      {isEn ? 'Note' : 'নোট / বিবরণ'}
                    </label>
                    <input
                      type="text"
                      value={ledgerTxNote}
                      onChange={(e) => setLedgerTxNote(e.target.value)}
                      placeholder={
                        ledgerTxType === 'credit_purchase'
                          ? isEn
                            ? 'e.g. Rice, oil, groceries'
                            : 'যেমন: চাল, ডাল, মুদি বাজার'
                          : isEn
                          ? 'e.g. Loan, repayment'
                          : 'নোট লিখুন'
                      }
                      className={`w-full px-2.5 py-1.5 rounded-xl border text-xs focus:outline-hidden transition ${
                        isLight
                          ? 'bg-white border-slate-200 text-slate-900 focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                          : isOled
                          ? 'bg-black border-slate-800 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                          : 'bg-slate-900 border-slate-700 text-white focus:border-[var(--color-primary)] focus:ring-2 focus:ring-[var(--color-primary)]/20'
                      }`}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className={`w-full py-2.5 rounded-xl text-white font-black text-xs transition active:scale-95 shadow-md cursor-pointer ${
                    ledgerTxType === 'credit_purchase'
                      ? 'bg-amber-600 hover:bg-amber-700'
                      : ledgerTxType === 'gave'
                      ? currentLedgerAccount.type === 'payable'
                        ? 'bg-emerald-600 hover:bg-emerald-700'
                        : 'bg-cyan-600 hover:bg-cyan-700'
                      : currentLedgerAccount.type === 'payable'
                      ? 'bg-rose-600 hover:bg-rose-700'
                      : 'bg-emerald-600 hover:bg-emerald-700'
                  }`}
                >
                  {ledgerTxType === 'credit_purchase'
                    ? isEn
                      ? 'Confirm Credit Purchase (+)'
                      : 'ধারে ক্রয়ের হিসাব নিশ্চিত করুন (+)'
                    : ledgerTxType === 'gave'
                    ? currentLedgerAccount.type === 'payable'
                      ? isEn
                        ? 'Confirm Repayment (-)'
                        : 'টাকা পরিশোধ নিশ্চিত করুন (-)'
                      : isEn
                      ? 'Confirm Giving Loan (+)'
                      : 'টাকা প্রদান নিশ্চিত করুন (+)'
                    : currentLedgerAccount.type === 'payable'
                    ? isEn
                      ? 'Confirm Borrowing (+)'
                      : 'ধার গ্রহণ নিশ্চিত করুন (+)'
                    : isEn
                    ? 'Confirm Payment Received (-)'
                    : 'টাকা আদায় নিশ্চিত করুন (-)'}
                </button>
              </form>
            )}

            {/* Transaction History Section */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              <div className="flex items-center justify-between mb-2">
                <h4 className={`text-xs font-bold uppercase tracking-wider ${subText}`}>
                  {isEn ? 'Ledger History' : 'লেনদেনের বিস্তারিত ইতিহাস'} (
                  {useBanglaDigits
                    ? toBanglaDigits(sortedSelectedAccountTransactionsWithBalance.length + (currentLedgerAccount.openingBalance ? 1 : 0))
                    : sortedSelectedAccountTransactionsWithBalance.length + (currentLedgerAccount.openingBalance ? 1 : 0)})
                </h4>

                {/* Sort Order Toggle for Ledger Modal */}
                <button
                  type="button"
                  onClick={() =>
                    setLedgerSortOrder((prev) => (prev === 'date_desc' ? 'date_asc' : 'date_desc'))
                  }
                  className="flex items-center gap-1 text-[11px] font-bold px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-white/70 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer"
                  title={isEn ? 'Toggle sort order' : 'সাজানোর ক্রম পরিবর্তন'}
                >
                  <ArrowUpDown className="w-3 h-3" />
                  <span>
                    {ledgerSortOrder === 'date_desc'
                      ? isEn
                        ? 'Newest'
                        : 'নতুন আগে'
                      : isEn
                      ? 'Oldest'
                      : 'পুরাতন আগে'}
                  </span>
                </button>
              </div>

              {/* Opening balance item if present */}
              {currentLedgerAccount.openingBalance !== 0 && (
                <div
                  className={`p-2.5 rounded-xl border flex items-center justify-between text-xs ${innerCardBg}`}
                >
                  <div>
                    <span className={`font-bold block ${headingText}`}>
                      {isEn ? 'Initial Balance' : 'প্রারম্ভিক জের'}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {currentLedgerAccount.notes || (isEn ? 'Opening entry' : 'শুরুর ব্যালেন্স')}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className={`font-black text-sm block ${headingText}`}>
                      {formatCurrency(currentLedgerAccount.openingBalance, useBanglaDigits, appSettings.currencySymbol)}
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium">
                      {isEn ? 'Opening Balance' : 'শুরুর স্থিতি'}
                    </span>
                  </div>
                </div>
              )}

              {/* Transactions list with running balance */}
              {sortedSelectedAccountTransactionsWithBalance.length === 0 && currentLedgerAccount.openingBalance === 0 ? (
                <p className="text-xs text-center py-6 text-slate-400">
                  {isEn ? 'No transaction history yet.' : 'এখনো কোনো লেনদেন রেকর্ড করা হয়নি।'}
                </p>
              ) : (
                sortedSelectedAccountTransactionsWithBalance.map(({ tx, runningBalance }) => {
                  const txDetails = (() => {
                    if (currentLedgerAccount.type === 'payable') {
                      if (tx.type === 'expense' && tx.accountId === currentLedgerAccount.id) {
                        return {
                          badge: isEn ? 'Credit Purchase' : 'ধারে পণ্য ক্রয়',
                          badgeClass: 'bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300',
                          sign: '+',
                          amountClass: 'text-amber-600 dark:text-amber-400',
                          impact: isEn ? 'Debt increased' : 'দেনা বৃদ্ধি',
                        };
                      } else if (tx.type === 'transfer' && tx.toAccountId === currentLedgerAccount.id) {
                        return {
                          badge: isEn ? 'Debt Repaid' : 'টাকা পরিশোধ',
                          badgeClass: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300',
                          sign: '-',
                          amountClass: 'text-emerald-600 dark:text-emerald-400',
                          impact: isEn ? 'Debt reduced' : 'দেনা হ্রাস',
                        };
                      } else if (tx.type === 'transfer' && tx.fromAccountId === currentLedgerAccount.id) {
                        return {
                          badge: isEn ? 'Cash Borrowed' : 'নগদ ধার গ্রহণ',
                          badgeClass: 'bg-rose-100 text-rose-700 dark:bg-rose-950/70 dark:text-rose-400',
                          sign: '+',
                          amountClass: 'text-rose-600 dark:text-rose-400',
                          impact: isEn ? 'Debt increased' : 'দেনা বৃদ্ধি',
                        };
                      } else if (tx.type === 'income' && tx.accountId === currentLedgerAccount.id) {
                        return {
                          badge: isEn ? 'Cash Borrowed' : 'ধার গ্রহণ',
                          badgeClass: 'bg-rose-100 text-rose-700 dark:bg-rose-950/70 dark:text-rose-400',
                          sign: '+',
                          amountClass: 'text-rose-600 dark:text-rose-400',
                          impact: isEn ? 'Debt increased' : 'দেনা বৃদ্ধি',
                        };
                      } else if (tx.ledgerAccountId === currentLedgerAccount.id) {
                        if (tx.type === 'expense') {
                          return {
                            badge: isEn ? 'Debt Repaid' : 'টাকা পরিশোধ',
                            badgeClass: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300',
                            sign: '-',
                            amountClass: 'text-emerald-600 dark:text-emerald-400',
                            impact: isEn ? 'Debt reduced' : 'দেনা হ্রাস',
                          };
                        } else {
                          return {
                            badge: isEn ? 'Debt Increased' : 'দেনা বৃদ্ধি',
                            badgeClass: 'bg-rose-100 text-rose-700 dark:bg-rose-950/70 dark:text-rose-400',
                            sign: '+',
                            amountClass: 'text-rose-600 dark:text-rose-400',
                            impact: isEn ? 'Debt increased' : 'দেনা বৃদ্ধি',
                          };
                        }
                      } else {
                        return {
                          badge: isEn ? 'Entry' : 'হিসাব',
                          badgeClass: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
                          sign: '+',
                          amountClass: 'text-slate-600 dark:text-slate-400',
                          impact: '',
                        };
                      }
                    } else {
                      // Receivable
                      if (tx.type === 'expense' && tx.accountId === currentLedgerAccount.id) {
                        return {
                          badge: isEn ? 'Loan / Goods Given' : 'ধার / পণ্য প্রদান',
                          badgeClass: 'bg-cyan-100 text-cyan-800 dark:bg-cyan-950/70 dark:text-cyan-300',
                          sign: '+',
                          amountClass: 'text-cyan-600 dark:text-cyan-400',
                          impact: isEn ? 'Receivable increased' : 'পাওনা বৃদ্ধি',
                        };
                      } else if (tx.type === 'income' && tx.accountId === currentLedgerAccount.id) {
                        return {
                          badge: isEn ? 'Payment Received' : 'টাকা আদায় / ফেরত',
                          badgeClass: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300',
                          sign: '-',
                          amountClass: 'text-emerald-600 dark:text-emerald-400',
                          impact: isEn ? 'Receivable reduced' : 'পাওনা হ্রাস',
                        };
                      } else if (tx.type === 'transfer' && tx.toAccountId === currentLedgerAccount.id) {
                        return {
                          badge: isEn ? 'Loan Given' : 'টাকা প্রদান',
                          badgeClass: 'bg-cyan-100 text-cyan-800 dark:bg-cyan-950/70 dark:text-cyan-300',
                          sign: '+',
                          amountClass: 'text-cyan-600 dark:text-cyan-400',
                          impact: isEn ? 'Receivable increased' : 'পাওনা বৃদ্ধি',
                        };
                      } else if (tx.type === 'transfer' && tx.fromAccountId === currentLedgerAccount.id) {
                        return {
                          badge: isEn ? 'Payment Received' : 'টাকা আদায় / ফেরত',
                          badgeClass: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300',
                          sign: '-',
                          amountClass: 'text-emerald-600 dark:text-emerald-400',
                          impact: isEn ? 'Receivable reduced' : 'পাওনা হ্রাস',
                        };
                      } else if (tx.ledgerAccountId === currentLedgerAccount.id) {
                        if (tx.type === 'expense') {
                          return {
                            badge: isEn ? 'Loan Given' : 'ধার প্রদান',
                            badgeClass: 'bg-cyan-100 text-cyan-800 dark:bg-cyan-950/70 dark:text-cyan-300',
                            sign: '+',
                            amountClass: 'text-cyan-600 dark:text-cyan-400',
                            impact: isEn ? 'Receivable increased' : 'পাওনা বৃদ্ধি',
                          };
                        } else {
                          return {
                            badge: isEn ? 'Payment Received' : 'টাকা আদায়',
                            badgeClass: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300',
                            sign: '-',
                            amountClass: 'text-emerald-600 dark:text-emerald-400',
                            impact: isEn ? 'Receivable reduced' : 'পাওনা হ্রাস',
                          };
                        }
                      } else {
                        return {
                          badge: isEn ? 'Entry' : 'হিসাব',
                          badgeClass: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
                          sign: '+',
                          amountClass: 'text-slate-600 dark:text-slate-400',
                          impact: '',
                        };
                      }
                    }
                  })();

                  return (
                    <div
                      key={tx.id}
                      className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 text-xs ${innerCardBg}`}
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span
                            className={`font-black text-[10px] px-1.5 py-0.5 rounded-md ${txDetails.badgeClass}`}
                          >
                            {txDetails.badge}
                          </span>
                          <span className="text-slate-400 text-[11px] font-mono">
                            {formatDate(tx.date, useBanglaDigits)}
                          </span>
                        </div>
                        <p className={`font-medium truncate mt-0.5 ${subText}`}>
                          {tx.note || (isEn ? 'No notes' : 'নোট নেই')}
                        </p>
                      </div>

                      <div className="text-right shrink-0">
                        <span className={`font-black text-sm block ${txDetails.amountClass}`}>
                          {txDetails.sign} {formatCurrency(tx.amount, useBanglaDigits, appSettings.currencySymbol)}
                        </span>
                        <span className="text-[10px] text-slate-400 block font-medium">
                          {isEn ? 'Bal: ' : 'জের: '}
                          {formatCurrency(Math.abs(runningBalance), useBanglaDigits, appSettings.currencySymbol)}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Bottom Action Buttons */}
            {currentLedgerAccount.type === 'payable' ? (
              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 grid grid-cols-3 gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    setLedgerTxType('credit_purchase');
                    setLedgerTxCategory('exp_grocery');
                  }}
                  className="py-2.5 px-1.5 rounded-2xl bg-amber-600 hover:bg-amber-700 text-white font-black text-[11px] flex flex-col items-center justify-center gap-1 shadow-sm active:scale-95 transition cursor-pointer text-center"
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span>{isEn ? 'Credit Buy (+)' : 'ধারে পণ্য কেনা (+)'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setLedgerTxType('gave')}
                  className="py-2.5 px-1.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-[11px] flex flex-col items-center justify-center gap-1 shadow-sm active:scale-95 transition cursor-pointer text-center"
                >
                  <Minus className="w-4 h-4 stroke-[3]" />
                  <span>{isEn ? 'Repay Debt (-)' : 'টাকা পরিশোধ (-)'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setLedgerTxType('received')}
                  className="py-2.5 px-1.5 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-black text-[11px] flex flex-col items-center justify-center gap-1 shadow-sm active:scale-95 transition cursor-pointer text-center"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                  <span>{isEn ? 'Borrow Cash (+)' : 'নগদ ধার (+)'}</span>
                </button>
              </div>
            ) : (
              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 grid grid-cols-2 gap-3 shrink-0">
                <button
                  type="button"
                  onClick={() => setLedgerTxType('gave')}
                  className="py-3 px-4 rounded-2xl bg-cyan-600 hover:bg-cyan-700 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition cursor-pointer"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                  <span>{isEn ? 'Give Loan / Goods (+)' : 'ধার / বাকিতে প্রদান (+)'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setLedgerTxType('received')}
                  className="py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition cursor-pointer"
                >
                  <Minus className="w-4 h-4 stroke-[3]" />
                  <span>{isEn ? 'Receive Payment (-)' : 'টাকা আদায় / ফেরত (-)'}</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
