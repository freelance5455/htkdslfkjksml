import React, { useState } from 'react';
import {
  Upload,
  Download,
  FileImage,
  Eye,
  Check,
  RefreshCw,
  Sliders,
  Layers,
  ArrowDownToLine
} from 'lucide-react';
import { convertPdfToImages, RenderedPdfPage } from '../../utils/pdfProcessor';
import { triggerFileDownload, saveStoredDocument } from '../../services/storageService';

interface PdfToImageViewProps {
  onBack: () => void;
}

export const PdfToImageView: React.FC<PdfToImageViewProps> = ({ onBack }) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [scale, setScale] = useState<number>(2.0); // 2x = 150 DPI, 3x = 300 DPI
  const [format, setFormat] = useState<'image/png' | 'image/jpeg'>('image/png');
  const [quality, setQuality] = useState<number>(0.92);
  const [pageRange, setPageRange] = useState<string>('all');
  const [isConverting, setIsConverting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [renderedPages, setRenderedPages] = useState<RenderedPdfPage[]>([]);
  const [previewPage, setPreviewPage] = useState<RenderedPdfPage | null>(null);

  const handlePdfUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    setSelectedFile(file);
    startConversion(file, scale, format, quality, pageRange);
  };

  const startConversion = async (
    file: File,
    targetScale: number,
    targetFormat: 'image/png' | 'image/jpeg',
    targetQuality: number,
    targetRange: string
  ) => {
    try {
      setIsConverting(true);
      setProgress(0);

      const pages = await convertPdfToImages(file, {
        scale: targetScale,
        imageFormat: targetFormat,
        quality: targetQuality,
        pageRange: targetRange,
        onProgress: (p) => setProgress(Math.round(p * 100))
      });

      setRenderedPages(pages);
    } catch (err: any) {
      console.error('PDF conversion error:', err);
    } finally {
      setIsConverting(false);
    }
  };

  // Download single page
  const handleDownloadPage = (page: RenderedPdfPage) => {
    const ext = format === 'image/png' ? 'png' : 'jpg';
    const fileName = `${selectedFile?.name.replace(/\.[^/.]+$/, '')}_page_${page.pageNumber}.${ext}`;
    if (page.blob) {
      triggerFileDownload(page.blob, fileName);
    } else {
      const a = document.createElement('a');
      a.href = page.dataUrl;
      a.download = fileName;
      a.click();
    }
  };

  // Download all pages sequentially
  const handleDownloadAll = () => {
    renderedPages.forEach((page, idx) => {
      setTimeout(() => {
        handleDownloadPage(page);
      }, idx * 300);
    });
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-neutral-50 dark:bg-neutral-900 pb-16">
      {/* Configuration Panel */}
      <div className="px-4 py-3 bg-white dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          {/* File picker */}
          <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs active:scale-95 transition-all">
            <Upload className="w-3.5 h-3.5" />
            <span>{selectedFile ? 'Change PDF' : 'Select PDF File'}</span>
            <input
              type="file"
              accept=".pdf,application/pdf"
              className="hidden"
              onChange={handlePdfUpload}
            />
          </label>

          {selectedFile && (
            <span className="text-xs font-semibold text-neutral-700 dark:text-neutral-300 truncate max-w-[200px]">
              {selectedFile.name}
            </span>
          )}
        </div>

        {/* Conversion Controls */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          {/* Resolution / DPI */}
          <div>
            <label className="block text-[10px] font-semibold text-neutral-500 uppercase mb-1">
              Resolution
            </label>
            <select
              value={scale}
              onChange={(e) => {
                const s = parseFloat(e.target.value);
                setScale(s);
                if (selectedFile) startConversion(selectedFile, s, format, quality, pageRange);
              }}
              className="w-full px-2 py-1.5 rounded-xl bg-neutral-100 dark:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 font-medium text-neutral-900 dark:text-neutral-100"
            >
              <option value={1.0}>1x Standard (72 DPI)</option>
              <option value={2.0}>2x High (150 DPI)</option>
              <option value={3.0}>3x Ultra (300 DPI)</option>
            </select>
          </div>

          {/* Format */}
          <div>
            <label className="block text-[10px] font-semibold text-neutral-500 uppercase mb-1">
              Image Format
            </label>
            <select
              value={format}
              onChange={(e) => {
                const f = e.target.value as any;
                setFormat(f);
                if (selectedFile) startConversion(selectedFile, scale, f, quality, pageRange);
              }}
              className="w-full px-2 py-1.5 rounded-xl bg-neutral-100 dark:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 font-medium text-neutral-900 dark:text-neutral-100"
            >
              <option value="image/png">PNG (Lossless)</option>
              <option value="image/jpeg">JPEG (Compact)</option>
            </select>
          </div>

          {/* Page Range */}
          <div>
            <label className="block text-[10px] font-semibold text-neutral-500 uppercase mb-1">
              Page Range
            </label>
            <select
              value={pageRange}
              onChange={(e) => {
                const r = e.target.value;
                setPageRange(r);
                if (selectedFile) startConversion(selectedFile, scale, format, quality, r);
              }}
              className="w-full px-2 py-1.5 rounded-xl bg-neutral-100 dark:bg-neutral-700 border border-neutral-300 dark:border-neutral-600 font-medium text-neutral-900 dark:text-neutral-100"
            >
              <option value="all">All Pages</option>
              <option value="1">Page 1 Only</option>
              <option value="1-3">Pages 1 to 3</option>
              <option value="odd">Odd Pages Only</option>
              <option value="even">Even Pages Only</option>
            </select>
          </div>

          {/* Quality slider for JPEG */}
          <div>
            <label className="block text-[10px] font-semibold text-neutral-500 uppercase mb-1">
              Quality ({Math.round(quality * 100)}%)
            </label>
            <input
              type="range"
              min={0.5}
              max={1.0}
              step={0.05}
              value={quality}
              onChange={(e) => {
                const q = parseFloat(e.target.value);
                setQuality(q);
                if (selectedFile && format === 'image/jpeg') {
                  startConversion(selectedFile, scale, format, q, pageRange);
                }
              }}
              className="w-full accent-blue-600 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Progress banner */}
      {isConverting && (
        <div className="px-4 py-2 bg-blue-50 dark:bg-blue-950/60 border-b border-blue-200 dark:border-blue-800 flex items-center justify-between text-xs font-semibold text-blue-800 dark:text-blue-300">
          <span className="flex items-center gap-1.5">
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            <span>Rendering PDF pages at high resolution...</span>
          </span>
          <span>{progress}%</span>
        </div>
      )}

      {/* Rendered Pages Gallery */}
      <div className="flex-1 p-3 overflow-y-auto">
        {!selectedFile ? (
          <div className="text-center py-20 px-6 rounded-3xl border-2 border-dashed border-neutral-300 dark:border-neutral-700 bg-white dark:bg-neutral-800/40 space-y-3">
            <div className="w-16 h-16 mx-auto rounded-3xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 flex items-center justify-center">
              <FileImage className="w-8 h-8" />
            </div>
            <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-100">
              Select a PDF Document to Convert
            </h3>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 max-w-xs mx-auto">
              Extract every page into sharp 300 DPI PNG or JPEG images with preserved typography and proportions.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-neutral-800 dark:text-neutral-200">
                {renderedPages.length} {renderedPages.length === 1 ? 'Page Rendered' : 'Pages Rendered'}
              </span>

              {renderedPages.length > 0 && (
                <button
                  type="button"
                  onClick={handleDownloadAll}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs active:scale-95 transition-all"
                >
                  <ArrowDownToLine className="w-3.5 h-3.5" />
                  <span>Batch Download All</span>
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {renderedPages.map((page) => (
                <div
                  key={page.pageNumber}
                  className="group relative rounded-2xl overflow-hidden bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 shadow-xs hover:shadow-md transition-all flex flex-col"
                >
                  <div className="relative aspect-[3/4] bg-neutral-100 dark:bg-neutral-900 flex items-center justify-center overflow-hidden">
                    <img
                      src={page.dataUrl}
                      alt={`Page ${page.pageNumber}`}
                      className="w-full h-full object-contain p-1"
                    />
                    <div className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-black/70 backdrop-blur-sm text-[10px] text-white font-bold">
                      Page {page.pageNumber}
                    </div>
                  </div>

                  <div className="p-2 bg-neutral-50 dark:bg-neutral-800/80 border-t border-neutral-200 dark:border-neutral-700 flex items-center justify-between">
                    <span className="text-[10px] text-neutral-500 font-medium">
                      {Math.round(page.width)}x{Math.round(page.height)}
                    </span>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => setPreviewPage(page)}
                        className="p-1 rounded-lg hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-600 dark:text-neutral-300"
                        title="Zoom Preview"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDownloadPage(page)}
                        className="p-1 rounded-lg hover:bg-neutral-200 dark:hover:bg-neutral-700 text-blue-600 dark:text-blue-400"
                        title="Download Page"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Fullscreen Zoom Modal */}
      {previewPage && (
        <div className="fixed inset-0 z-50 bg-black/90 flex flex-col items-center justify-center p-4">
          <div className="w-full max-w-lg flex justify-between items-center text-white pb-2 text-xs font-bold">
            <span>Page {previewPage.pageNumber} Preview</span>
            <button
              type="button"
              onClick={() => setPreviewPage(null)}
              className="px-3 py-1 bg-white/20 rounded-full"
            >
              Close
            </button>
          </div>
          <div className="max-w-lg max-h-[80vh] overflow-auto bg-white rounded-xl shadow-2xl p-2">
            <img src={previewPage.dataUrl} alt="Preview" className="w-full h-auto" />
          </div>
        </div>
      )}

      {/* Bottom bar */}
      <div className="sticky bottom-0 px-4 py-3 bg-white/95 dark:bg-neutral-800/95 backdrop-blur-md border-t border-neutral-200 dark:border-neutral-700 flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          className="px-4 py-2 rounded-xl text-neutral-600 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-xs font-semibold"
        >
          Back
        </button>
      </div>
    </div>
  );
};
