import React, { useState } from "react";
import {
  Tags,
  Pin,
  Star,
  CheckSquare,
  Sparkles,
  Search,
  ExternalLink,
  Tag,
  Paperclip,
  Clock
} from "lucide-react";
import { Note } from "../../types";

interface CompactStripViewProps {
  notes: Note[];
  onOpenNote: (note: Note) => void;
  onTogglePin: (id: string, e: React.MouseEvent) => void;
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
  onDeleteNote: (id: string, e: React.MouseEvent) => void;
  onTagClick?: (tag: string) => void;
}

export const CompactStripView: React.FC<CompactStripViewProps> = ({
  notes,
  onOpenNote,
  onTogglePin,
  onToggleFavorite,
  onDeleteNote,
  onTagClick,
}) => {
  const [hoveredNote, setHoveredNote] = useState<Note | null>(null);
  const [hoverPos, setHoverPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [density, setDensity] = useState<"tight" | "medium" | "badge">("medium");

  const handleMouseEnter = (e: React.MouseEvent, note: Note) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setHoverPos({ x: rect.left, y: rect.bottom + 8 });
    setHoveredNote(note);
  };

  const handleMouseLeave = () => {
    setHoveredNote(null);
  };

  return (
    <div className="space-y-4 animate-in fade-in">
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-slate-900 p-3 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-teal-100 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400">
            <Tags className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
              <span>Minimal Şerit & Kompakt Rozet Görünümü</span>
              <span className="text-[10px] bg-teal-100 dark:bg-teal-900/60 text-teal-700 dark:text-teal-300 px-2 py-0.5 rounded-full font-bold">
                Yüksek Yoğunluk ({notes.length} Not)
              </span>
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Yüzlerce notu tek bir ekranda hızlıca inceleyin ve sıralayın
            </p>
          </div>
        </div>

        {/* Density Selector */}
        <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold">
          <button
            onClick={() => setDensity("tight")}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              density === "tight"
                ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-400 shadow-xs font-bold"
                : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            }`}
          >
            Sıkı Rozetler
          </button>
          <button
            onClick={() => setDensity("medium")}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              density === "medium"
                ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-400 shadow-xs font-bold"
                : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            }`}
          >
            Normal Şerit
          </button>
          <button
            onClick={() => setDensity("badge")}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              density === "badge"
                ? "bg-white dark:bg-slate-700 text-teal-600 dark:text-teal-400 shadow-xs font-bold"
                : "text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            }`}
          >
            Kutu Rozet
          </button>
        </div>
      </div>

      {/* Badges Container */}
      <div
        className={
          density === "tight"
            ? "flex flex-wrap gap-1.5"
            : density === "medium"
            ? "flex flex-wrap gap-2"
            : "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2"
        }
      >
        {notes.map((note) => {
          const categoryColors: Record<string, string> = {
            Kişisel: "bg-blue-500/15 text-blue-700 dark:text-blue-300 border-blue-300 dark:border-blue-800",
            İş: "bg-purple-500/15 text-purple-700 dark:text-purple-300 border-purple-300 dark:border-purple-800",
            Fikirler: "bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-300 dark:border-amber-800",
            Ders: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-300 dark:border-emerald-800",
            Genel: "bg-teal-500/15 text-teal-700 dark:text-teal-300 border-teal-300 dark:border-teal-800",
          };

          const colStyle =
            categoryColors[note.category || "Genel"] ||
            "bg-teal-500/15 text-teal-700 dark:text-teal-300 border-teal-300 dark:border-teal-800";

          if (density === "tight") {
            return (
              <button
                key={note.id}
                onClick={() => onOpenNote(note)}
                onMouseEnter={(e) => handleMouseEnter(e, note)}
                onMouseLeave={handleMouseLeave}
                className={`group flex items-center gap-1.5 px-2.5 py-1 rounded-xl border text-xs font-semibold transition-all cursor-pointer hover:scale-105 ${colStyle}`}
              >
                {note.pinned && <Pin className="w-3 h-3 text-rose-500 shrink-0" />}
                {note.favorite && <Star className="w-3 h-3 text-amber-500 fill-current shrink-0" />}
                <span className="truncate max-w-[140px] text-slate-900 dark:text-white font-bold">
                  {note.title || "Başlıksız"}
                </span>
                <span className="text-[10px] opacity-75 font-mono">
                  ({note.category || "Genel"})
                </span>
              </button>
            );
          }

          if (density === "medium") {
            return (
              <div
                key={note.id}
                onClick={() => onOpenNote(note)}
                onMouseEnter={(e) => handleMouseEnter(e, note)}
                onMouseLeave={handleMouseLeave}
                className={`group flex items-center justify-between gap-2 px-3 py-1.5 rounded-2xl border text-xs font-semibold shadow-2xs hover:shadow-md transition-all cursor-pointer hover:border-teal-500 ${colStyle} bg-white dark:bg-slate-800`}
              >
                <div className="flex items-center gap-2 overflow-hidden">
                  <span className="w-2 h-2 rounded-full bg-teal-500 shrink-0" />
                  {note.pinned && <Pin className="w-3 h-3 text-rose-500 shrink-0" />}
                  <span className="font-bold text-slate-900 dark:text-white truncate max-w-[180px]">
                    {note.title || "Başlıksız Not"}
                  </span>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                    {note.category || "Genel"}
                  </span>
                  {note.tasks && note.tasks.length > 0 && (
                    <CheckSquare className="w-3.5 h-3.5 text-teal-600" />
                  )}
                </div>
              </div>
            );
          }

          // Badge Mode (Grid of small chips)
          return (
            <div
              key={note.id}
              onClick={() => onOpenNote(note)}
              onMouseEnter={(e) => handleMouseEnter(e, note)}
              onMouseLeave={handleMouseLeave}
              className="p-3 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs hover:shadow-lg transition-all cursor-pointer hover:border-teal-500 text-left flex flex-col justify-between h-24"
            >
              <div className="flex items-center justify-between gap-1 mb-1">
                <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800 truncate">
                  {note.category || "Genel"}
                </span>
                {note.pinned && <Pin className="w-3 h-3 text-rose-500" />}
              </div>

              <h5 className="font-bold text-xs text-slate-900 dark:text-white line-clamp-2">
                {note.title || "Başlıksız Not"}
              </h5>

              <div className="text-[10px] text-slate-400 font-mono mt-auto flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-700/60">
                <span>{new Date(note.updatedAt || note.createdAt).toLocaleDateString("tr-TR")}</span>
                <ExternalLink className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </div>
          );
        })}
      </div>

      {/* Hover Floating Preview Tooltip */}
      {hoveredNote && (
        <div
          className="fixed z-50 w-72 bg-slate-900 text-white rounded-2xl border border-slate-700 shadow-2xl p-3.5 space-y-2 pointer-events-none animate-in fade-in duration-150"
          style={{
            left: `${Math.min(window.innerWidth - 300, Math.max(16, hoverPos.x))}px`,
            top: `${Math.min(window.innerHeight - 200, hoverPos.y)}px`,
          }}
        >
          <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono border-b border-slate-800 pb-1.5">
            <span className="text-teal-400 font-bold">{hoveredNote.category || "Genel"}</span>
            <span>{new Date(hoveredNote.createdAt).toLocaleDateString("tr-TR")}</span>
          </div>

          <h5 className="font-bold text-xs text-white line-clamp-2">
            {hoveredNote.title || "Başlıksız Not"}
          </h5>

          {hoveredNote.content && (
            <p className="text-[11px] text-slate-300 line-clamp-4 leading-relaxed">
              {hoveredNote.content.replace(/<[^>]*>/g, "")}
            </p>
          )}

          {hoveredNote.tags && hoveredNote.tags.length > 0 && (
            <div className="flex flex-wrap gap-1 pt-1">
              {hoveredNote.tags.map((t) => (
                <span
                  key={t}
                  className="text-[9px] bg-slate-800 text-teal-300 px-1.5 py-0.5 rounded-md"
                >
                  #{t}
                </span>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
