import React, { useState } from 'react';
import { useParentControl } from '../../context/ParentControlContext';
import { 
  MapPin, Navigation, Shield, Plus, Trash2, 
  Clock, Battery, Gauge, Compass, AlertCircle, 
  CheckCircle2, X
} from 'lucide-react';

export const LocationView: React.FC = () => {
  const { activeDevice, language, addGeofence, removeGeofence, showToast } = useParentControl();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newZoneName, setNewZoneName] = useState('');
  const [newZoneRadius, setNewZoneRadius] = useState(200);
  const [newZoneAddress, setNewZoneAddress] = useState('');

  if (!activeDevice) return null;

  const isAr = language === 'ar';
  const loc = activeDevice.currentLocation;

  const handleCreateZone = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newZoneName.trim()) return;
    addGeofence({
      name: newZoneName,
      nameAr: newZoneName,
      lat: loc.lat + 0.002,
      lng: loc.lng + 0.002,
      radiusMeters: newZoneRadius,
      address: newZoneAddress || 'منطقة محددة جديدة',
      type: 'safe',
    });
    setNewZoneName('');
    setNewZoneAddress('');
    setIsAddModalOpen(false);
  };

  const timelineSteps = [
    { time: '07:45 ص', titleAr: 'وصل إلى مدرسة الأفق النموذجية', titleEn: 'Arrived at Horizon School', icon: 'school' },
    { time: '13:30 م', titleAr: 'مغادرة المدرسة باتجاه حي النخيل', titleEn: 'Left School towards Al-Nakheel', icon: 'car' },
    { time: '14:15 م', titleAr: 'وصل إلى المنزل (المنطقة الآمنة)', titleEn: 'Arrived at Home Zone', icon: 'home' },
    { time: '17:00 م', titleAr: 'التواجد في النادي الرياضي (شارع التخصصي)', titleEn: 'At Sports Club', icon: 'club' },
  ];

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs transition-colors duration-200">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <MapPin className="w-6 h-6 text-rose-500" />
              <span>{isAr ? 'تتبع الموقع المباشر والمناطق الجغرافية (GPS & Geofences)' : 'Live GPS Tracking & Geofencing'}</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {isAr 
                ? `مراقبة تحركات ${activeDevice.childNameAr} وسرعة التنقل والمناطق الآمنة لحظة بلحظة`
                : `Real-time location, movement speed, and geofence safety zones for ${activeDevice.childName}`}
            </p>
          </div>

          <button
            id="open-add-geofence-btn"
            onClick={() => setIsAddModalOpen(true)}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-semibold rounded-xl flex items-center gap-2 shadow-xs transition-all self-start md:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>{isAr ? 'إضافة منطقة آمنة (Geofence)' : 'Add Safe Zone'}</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Interactive Map Visualizer + Geofence Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Map Canvas (2 cols) */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex flex-wrap items-center justify-between pb-3 mb-3 border-b border-slate-100 dark:border-slate-800 gap-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping shrink-0" />
                <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  {isAr ? 'إشارة GPS حية ودقيقة (دقة 4 أمتار)' : 'LIVE GPS LOCK (4M ACCURACY)'}
                </span>
              </div>

              <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                <Compass className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
                <span className="font-mono text-[11px] sm:text-xs">{loc.lat.toFixed(4)}° N, {loc.lng.toFixed(4)}° E</span>
              </div>
            </div>

            {/* Simulated Interactive Map Display */}
            <div className="relative aspect-[4/3] sm:aspect-[16/10] w-full rounded-2xl overflow-hidden bg-slate-950 border border-slate-900 shadow-inner">
              {/* Stylized Dark Grid Map SVG */}
              <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                    <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1e293b" strokeWidth="1" />
                  </pattern>
                  <radialGradient id="safeZoneGlow" cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stopColor="#6366f1" stopOpacity="0.4" />
                    <stop offset="100%" stopColor="#6366f1" stopOpacity="0.05" />
                  </radialGradient>
                </defs>
                <rect width="100%" height="100%" fill="#090d16" />
                <rect width="100%" height="100%" fill="url(#grid)" />

                {/* Simulated Roads */}
                <path d="M -20 180 Q 200 160 400 240 T 900 210" fill="none" stroke="#334155" strokeWidth="12" strokeLinecap="round" opacity="0.6" />
                <path d="M 280 -20 Q 320 200 360 450" fill="none" stroke="#334155" strokeWidth="10" strokeLinecap="round" opacity="0.6" />
                <path d="M 100 350 L 700 80" fill="none" stroke="#1e293b" strokeWidth="6" strokeDasharray="6,6" />

                {/* Geofence Circles */}
                <circle cx="50%" cy="50%" r="110" fill="url(#safeZoneGlow)" stroke="#6366f1" strokeWidth="2" strokeDasharray="4,4" />
                <circle cx="28%" cy="35%" r="70" fill="url(#safeZoneGlow)" stroke="#10b981" strokeWidth="1.5" strokeDasharray="3,3" />

                {/* Home & School Map Badges */}
                <g transform="translate(160, 130)">
                  <circle r="14" fill="#065f46" />
                  <text y="4" textAnchor="middle" fill="#34d399" fontSize="11" fontWeight="bold">🏫</text>
                </g>

                <g transform="translate(380, 240)">
                  <circle r="14" fill="#1e1b4b" />
                  <text y="4" textAnchor="middle" fill="#818cf8" fontSize="11" fontWeight="bold">🏠</text>
                </g>
              </svg>

              {/* Real-time Child Pin in Center */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center pointer-events-none">
                <div className="relative flex items-center justify-center">
                  <span className="animate-ping absolute w-12 h-12 rounded-full bg-rose-500 opacity-60"></span>
                  <span className="animate-pulse absolute w-8 h-8 rounded-full bg-rose-500/40"></span>
                  <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-600 to-amber-500 p-0.5 shadow-xl flex items-center justify-center">
                    <img 
                      src={activeDevice.avatarUrl} 
                      alt={activeDevice.childName} 
                      className="w-full h-full rounded-[14px] object-cover" 
                    />
                  </div>
                </div>
                <div className="mt-2 bg-slate-900/95 border border-slate-700 px-3 py-1 rounded-xl shadow-xl backdrop-blur-md text-center">
                  <p className="text-[11px] font-bold text-white whitespace-nowrap">
                    {activeDevice.childNameAr} ({isAr ? 'هنا الآن' : 'Here Now'})
                  </p>
                  <p className="text-[9px] text-emerald-400 font-mono">
                    {loc.speedKmh > 0 ? `${loc.speedKmh} km/h` : (isAr ? 'ثابت (متوقف)' : 'Stationary')}
                  </p>
                </div>
              </div>

              {/* Live Info Card overlay */}
              <div className="absolute bottom-3 start-3 bg-white/95 dark:bg-slate-900/95 border border-slate-200 dark:border-slate-700 p-3 rounded-xl backdrop-blur-xs max-w-xs shadow-xs text-xs space-y-1">
                <p className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                  <span className="truncate">{loc.address}</span>
                </p>
                <div className="flex items-center gap-3 text-[11px] text-slate-500 dark:text-slate-400 pt-1">
                  <span className="flex items-center gap-1">
                    <Gauge className="w-3 h-3 text-sky-600 dark:text-sky-400" />
                    <span>{loc.speedKmh} {isAr ? 'كم/س' : 'km/h'}</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                    <span>{loc.lastUpdated}</span>
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Quick links below map */}
          <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
            <span>{isAr ? 'مستشعر GPS متصل بالقمر الصناعي' : 'GPS Satellite Link Active'}</span>
            <button 
              onClick={() => showToast(isAr ? 'تم تحديث الموقع الجغرافي وإحداثيات GPS بنجاح' : 'Location & GPS coordinates refreshed', 'success')}
              className="text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 font-semibold"
            >
              {isAr ? 'تحديث الإحداثيات الآن' : 'Refresh Coordinates'}
            </button>
          </div>
        </div>

        {/* Geofence Zones & Timeline (1 col) */}
        <div className="space-y-4 flex flex-col justify-between">
          
          {/* Geofences Box */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Shield className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <span>{isAr ? 'المناطق الجغرافية الآمنة' : 'Safe Geofences'}</span>
              </h3>
              <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">{activeDevice.geofenceZones.length} {isAr ? 'مناطق' : 'zones'}</span>
            </div>

            <div className="space-y-2 max-h-[220px] overflow-y-auto no-scrollbar">
              {activeDevice.geofenceZones.length === 0 ? (
                <div className="py-6 text-center text-slate-400 dark:text-slate-500 text-xs">
                  <p>{isAr ? 'لا توجد مناطق جغرافية مضافة بعد' : 'No geofences added yet'}</p>
                </div>
              ) : (
                activeDevice.geofenceZones.map((zone) => (
                  <div 
                    key={zone.id} 
                    className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-slate-900 dark:text-white">{isAr ? zone.nameAr : zone.name}</span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 font-semibold">
                          {zone.radiusMeters}m
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate max-w-[170px] mt-0.5">{zone.address}</p>
                    </div>

                    <button
                      onClick={() => removeGeofence(zone.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      title={isAr ? 'حذف المنطقة' : 'Delete'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Location Timeline Today */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
              <Clock className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>{isAr ? 'سجل تحركات الطفل اليوم' : 'Movement Timeline'}</span>
            </h3>

            <div className="space-y-3">
              {timelineSteps.map((step, idx) => (
                <div key={idx} className="flex items-start gap-2.5 text-xs">
                  <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 whitespace-nowrap pt-0.5">{step.time}</span>
                  <div className="w-2 h-2 rounded-full bg-indigo-600 dark:bg-indigo-400 mt-1.5 shrink-0" />
                  <p className="text-slate-700 dark:text-slate-300 font-medium">{isAr ? step.titleAr : step.titleEn}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Add Geofence Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 w-full max-w-md shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Shield className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                <span>{isAr ? 'إضافة منطقة جغرافية آمنة جديدة' : 'Add New Safe Geofence'}</span>
              </h3>
              <button 
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateZone} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  {isAr ? 'اسم المنطقة (مثال: بيت الجد، نادي السباحة):' : 'Zone Name:'}
                </label>
                <input
                  type="text"
                  required
                  value={newZoneName}
                  onChange={(e) => setNewZoneName(e.target.value)}
                  placeholder={isAr ? 'اسم المنطقة الآمنة' : 'e.g. Grandparent House'}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-900"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  {isAr ? 'العنوان التقريبي:' : 'Approximate Address:'}
                </label>
                <input
                  type="text"
                  value={newZoneAddress}
                  onChange={(e) => setNewZoneAddress(e.target.value)}
                  placeholder={isAr ? 'الرياض - شارع العليا' : 'e.g. King Fahd Road'}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-900"
                />
              </div>

              <div>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-slate-700 dark:text-slate-300 font-medium">{isAr ? 'نصف قطر المنطقة الآمنة:' : 'Safety Radius:'}</span>
                  <span className="font-mono text-indigo-600 dark:text-indigo-400 font-bold">{newZoneRadius} {isAr ? 'متر' : 'm'}</span>
                </div>
                <input
                  type="range"
                  min="100"
                  max="1000"
                  step="50"
                  value={newZoneRadius}
                  onChange={(e) => setNewZoneRadius(Number(e.target.value))}
                  className="w-full accent-indigo-600 cursor-pointer"
                />
              </div>

              <div className="p-3 bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/50 rounded-xl text-[11px] text-indigo-900 dark:text-indigo-300">
                {isAr ? '⚡ ستحصل على إشعار فوري عند دخول أو خروج طفلك من هذه المنطقة.' : '⚡ You will be notified whenever your child enters or exits this zone.'}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-medium rounded-xl border border-slate-200 dark:border-slate-700 shadow-xs"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl shadow-xs"
                >
                  {isAr ? 'حفظ المنطقة' : 'Save Zone'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
