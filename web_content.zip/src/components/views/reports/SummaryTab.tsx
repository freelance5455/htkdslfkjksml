import React, { useState, useMemo } from 'react';
import { Transaction, AppSettings } from '../../../types';
import { formatCurrency, getMonthName } from '../../../utils/formatters';
import { ChevronDown, ChevronUp, Calendar, TrendingUp, TrendingDown, Wallet } from 'lucide-react';

interface SummaryTabProps {
  transactions: Transaction[];
  appSettings: AppSettings;
  useBanglaDigits: boolean;
}

type SummaryPeriod = 'daily' | 'monthly' | 'yearly';

interface PeriodSummaryItem {
  id: string;
  label: string;
  subLabel?: string;
  income: number;
  expense: number;
  total: number;
  transactionCount: number;
  transactions: Transaction[];
}

/**
 * Mini Donut Chart Component matching Image 1:
 * Circular ring with Green (Income) and Red (Expense) arcs.
 */
const MiniDonut: React.FC<{
  income: number;
  expense: number;
  size?: number;
}> = ({ income, expense, size = 64 }) => {
  const total = income + expense;
  const strokeWidth = 8.5;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;

  if (total === 0) {
    return (
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="shrink-0">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="#e2e8f0"
          strokeWidth={strokeWidth}
        />
      </svg>
    );
  }

  const incomeFraction = income / total;
  const expenseFraction = expense / total;

  const incomeStroke = incomeFraction * circumference;
  const expenseStroke = expenseFraction * circumference;

  // Gap between arcs if both exist
  const hasBoth = income > 0 && expense > 0;
  const gap = hasBoth ? 1.5 : 0;
  const adjIncomeStroke = Math.max(0, incomeStroke - gap);
  const adjExpenseStroke = Math.max(0, expenseStroke - gap);

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="shrink-0 -rotate-90">
      {/* Background ring */}
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        stroke="#f1f5f9"
        strokeWidth={strokeWidth}
      />
      {/* Income arc (Green) */}
      {income > 0 && (
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="#10b981"
          strokeWidth={strokeWidth}
          strokeDasharray={`${adjIncomeStroke} ${circumference}`}
          strokeDashoffset={-gap / 2}
          strokeLinecap="round"
        />
      )}
      {/* Expense arc (Red) */}
      {expense > 0 && (
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="#ef4444"
          strokeWidth={strokeWidth}
          strokeDasharray={`${adjExpenseStroke} ${circumference}`}
          strokeDashoffset={-(incomeStroke + gap / 2)}
          strokeLinecap="round"
        />
      )}
    </svg>
  );
};

export const SummaryTab: React.FC<SummaryTabProps> = ({
  transactions = [],
  appSettings,
  useBanglaDigits,
}) => {
  const [periodType, setPeriodType] = useState<SummaryPeriod>('monthly');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const isEn = appSettings.language === 'en';
  const isLight = appSettings.themeMode === 'light';

  // Card & background styles
  const cardBg = isLight
    ? 'bg-white border-slate-200/80 shadow-xs'
    : 'bg-slate-900 border-slate-800 shadow-md';
  const headingText = isLight ? 'text-slate-900' : 'text-slate-100';
  const subText = isLight ? 'text-slate-500' : 'text-slate-400';
  const dividerBorder = isLight ? 'border-slate-100' : 'border-slate-800';

  // Aggregate transactions by period
  const summaryData = useMemo<PeriodSummaryItem[]>(() => {
    const map = new Map<string, { income: number; expense: number; txs: Transaction[] }>();

    transactions.forEach((tx) => {
      if (!tx.date) return;
      let key = '';

      if (periodType === 'daily') {
        key = tx.date; // YYYY-MM-DD
      } else if (periodType === 'monthly') {
        key = tx.date.substring(0, 7); // YYYY-MM
      } else if (periodType === 'yearly') {
        key = tx.date.substring(0, 4); // YYYY
      }

      if (!map.has(key)) {
        map.set(key, { income: 0, expense: 0, txs: [] });
      }

      const entry = map.get(key)!;
      entry.txs.push(tx);
      if (tx.type === 'income') {
        entry.income += tx.amount;
      } else if (tx.type === 'expense') {
        entry.expense += tx.amount;
      }
    });

    // Sort keys in descending order (latest first)
    const sortedKeys = Array.from(map.keys()).sort().reverse();

    return sortedKeys.map((key) => {
      const { income, expense, txs } = map.get(key)!;
      let label = key;
      let subLabel = '';

      if (periodType === 'daily') {
        // e.g. 06 Sep 2026 or ০৬ সেপ্টেম্বর ২০২৬
        const parts = key.split('-');
        if (parts.length === 3) {
          const d = new Date(key);
          if (!isNaN(d.getTime())) {
            const today = new Date().toISOString().substring(0, 10);
            const isToday = key === today;
            label = isEn
              ? `${d.getDate()} ${d.toLocaleString('en-US', { month: 'short' })} ${d.getFullYear()}`
              : `${parts[2]}/${parts[1]}/${parts[0]}`;
            if (isToday) {
              subLabel = isEn ? 'Today' : 'আজ';
            }
          }
        }
      } else if (periodType === 'monthly') {
        // e.g. June 2026 or জুন ২০২৬ (Matches Image 1)
        label = getMonthName(key, appSettings.language, useBanglaDigits);
      } else if (periodType === 'yearly') {
        // e.g. 2026 or ২০২৬
        label = isEn ? key : `${key} সাল`;
      }

      return {
        id: key,
        label,
        subLabel,
        income,
        expense,
        total: income - expense,
        transactionCount: txs.length,
        transactions: txs,
      };
    });
  }, [transactions, periodType, appSettings.language, useBanglaDigits, isEn]);

  // Overall totals for active period
  const overall = useMemo(() => {
    let totalIncome = 0;
    let totalExpense = 0;
    summaryData.forEach((item) => {
      totalIncome += item.income;
      totalExpense += item.expense;
    });
    return {
      income: totalIncome,
      expense: totalExpense,
      total: totalIncome - totalExpense,
    };
  }, [summaryData]);

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="space-y-4">
      {/* Sub-Tabs: Daily, Monthly, Yearly (ছবি অনুযায়ী) */}
      <div
        className={`p-1.5 rounded-2xl border flex items-center justify-between gap-1 shadow-xs ${
          isLight ? 'bg-slate-100/90 border-slate-200' : 'bg-slate-800/80 border-slate-700'
        }`}
      >
        <button
          onClick={() => setPeriodType('daily')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
            periodType === 'daily'
              ? 'bg-emerald-600 text-white shadow-md'
              : isLight
              ? 'text-slate-600 hover:text-slate-900'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          {isEn ? 'Daily' : 'ডেইলি (Daily)'}
        </button>

        <button
          onClick={() => setPeriodType('monthly')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
            periodType === 'monthly'
              ? 'bg-emerald-600 text-white shadow-md'
              : isLight
              ? 'text-slate-600 hover:text-slate-900'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          {isEn ? 'Monthly' : 'মান্থলি (Monthly)'}
        </button>

        <button
          onClick={() => setPeriodType('yearly')}
          className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
            periodType === 'yearly'
              ? 'bg-emerald-600 text-white shadow-md'
              : isLight
              ? 'text-slate-600 hover:text-slate-900'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          {isEn ? 'Yearly' : 'ইয়ারলি (Yearly)'}
        </button>
      </div>

      {/* Overview Top Metric Header */}
      <div
        className={`p-4 rounded-2xl border ${
          isLight
            ? 'bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-100/50 border-emerald-200/80'
            : 'bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 border-emerald-800/40'
        }`}
      >
        <div className="flex items-center justify-between text-xs mb-2">
          <span className={`font-bold uppercase tracking-wider ${isLight ? 'text-emerald-900' : 'text-emerald-300'}`}>
            {isEn ? 'Cumulative Summary' : 'সর্বমোট সামারি ওভারভিউ'}
          </span>
          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${isLight ? 'bg-emerald-200/60 text-emerald-800' : 'bg-emerald-900/60 text-emerald-300'}`}>
            {summaryData.length} {isEn ? 'Periods' : 'পিরিয়ড'}
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2 text-center pt-1">
          <div className={`p-2.5 rounded-xl ${isLight ? 'bg-white/80' : 'bg-slate-800/60'}`}>
            <p className="text-[10px] text-emerald-600 font-semibold flex items-center justify-center gap-1">
              <TrendingUp className="w-3 h-3" />
              <span>{isEn ? 'Income' : 'আয়'}</span>
            </p>
            <p className="text-xs sm:text-sm font-black text-emerald-600 mt-0.5">
              {formatCurrency(overall.income, useBanglaDigits)}
            </p>
          </div>

          <div className={`p-2.5 rounded-xl ${isLight ? 'bg-white/80' : 'bg-slate-800/60'}`}>
            <p className="text-[10px] text-rose-500 font-semibold flex items-center justify-center gap-1">
              <TrendingDown className="w-3 h-3" />
              <span>{isEn ? 'Expenses' : 'খরচ'}</span>
            </p>
            <p className="text-xs sm:text-sm font-black text-rose-500 mt-0.5">
              {formatCurrency(overall.expense, useBanglaDigits)}
            </p>
          </div>

          <div className={`p-2.5 rounded-xl ${isLight ? 'bg-white/80' : 'bg-slate-800/60'}`}>
            <p className="text-[10px] text-slate-500 font-semibold flex items-center justify-center gap-1">
              <Wallet className="w-3 h-3" />
              <span>{isEn ? 'Total' : 'মোট স্থিতি'}</span>
            </p>
            <p
              className={`text-xs sm:text-sm font-black mt-0.5 ${
                overall.total >= 0 ? 'text-emerald-600' : 'text-rose-500'
              }`}
            >
              {formatCurrency(overall.total, useBanglaDigits)}
            </p>
          </div>
        </div>
      </div>

      {/* Main List matching Image 1 */}
      <div className={`${cardBg} rounded-2xl border divide-y ${dividerBorder} overflow-hidden shadow-sm`}>
        {summaryData.length === 0 ? (
          <div className="py-16 text-center">
            <Calendar className={`w-10 h-10 mx-auto mb-2 opacity-40 ${subText}`} />
            <p className={`text-sm font-bold ${headingText}`}>
              {isEn ? 'No summary data available' : 'কোনো তথ্য পাওয়া যায়নি'}
            </p>
            <p className={`text-xs mt-1 ${subText}`}>
              {isEn
                ? 'Add your daily income and expense transactions to see period summaries.'
                : 'দৈনিক আয় ও ব্যয়ের হিসাব যুক্ত করলে এখানে সামারি দেখা যাবে।'}
            </p>
          </div>
        ) : (
          summaryData.map((item) => {
            const isExpanded = expandedId === item.id;
            return (
              <div key={item.id} className="transition hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                {/* Single Row styled exactly like Image 1 */}
                <div
                  className="p-4 sm:p-5 flex items-center justify-between gap-4 cursor-pointer select-none"
                  onClick={() => toggleExpand(item.id)}
                >
                  {/* Left Column: Period Title & Donut Chart */}
                  <div className="flex flex-col items-start gap-2.5">
                    <div className="flex items-center gap-2">
                      <h3 className={`text-sm sm:text-base font-bold ${headingText}`}>
                        {item.label}
                      </h3>
                      {item.subLabel && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300">
                          {item.subLabel}
                        </span>
                      )}
                    </div>

                    {/* Circular ring chart like in screenshot */}
                    <div className="flex items-center gap-2">
                      <MiniDonut income={item.income} expense={item.expense} size={58} />
                    </div>
                  </div>

                  {/* Right Column: Values formatted like Image 1 */}
                  <div className="flex items-center gap-3">
                    <div className="space-y-1 text-right text-xs sm:text-sm font-semibold">
                      {/* Income: £3,164.00 (in green) */}
                      <div className="flex items-center justify-end gap-2">
                        <span className={`text-[11px] sm:text-xs ${subText}`}>
                          {isEn ? 'Income:' : 'আয়:'}
                        </span>
                        <span className="font-bold text-emerald-600 dark:text-emerald-400">
                          +{formatCurrency(item.income, useBanglaDigits)}
                        </span>
                      </div>

                      {/* Expenses: -£2,136.24 (in red) */}
                      <div className="flex items-center justify-end gap-2">
                        <span className={`text-[11px] sm:text-xs ${subText}`}>
                          {isEn ? 'Expenses:' : 'খরচ:'}
                        </span>
                        <span className="font-bold text-rose-500 dark:text-rose-400">
                          -{formatCurrency(item.expense, useBanglaDigits)}
                        </span>
                      </div>

                      {/* Total: £1,027.76 (green if positive, red if negative) */}
                      <div className="flex items-center justify-end gap-2 pt-0.5 border-t border-slate-100 dark:border-slate-800">
                        <span className={`text-[11px] sm:text-xs ${subText}`}>
                          {isEn ? 'Total:' : 'মোট:'}
                        </span>
                        <span
                          className={`font-black ${
                            item.total >= 0
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : 'text-rose-500 dark:text-rose-400'
                          }`}
                        >
                          {formatCurrency(item.total, useBanglaDigits)}
                        </span>
                      </div>
                    </div>

                    <div className={`p-1 rounded-full text-slate-400 hover:text-slate-600 ${isLight ? 'bg-slate-100' : 'bg-slate-800'}`}>
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </div>
                  </div>
                </div>

                {/* Expandable Breakdown Drawer */}
                {isExpanded && (
                  <div className={`px-4 sm:px-6 pb-4 pt-2 ${isLight ? 'bg-slate-50/70' : 'bg-slate-950/40'}`}>
                    <div className="text-xs font-bold uppercase tracking-wider mb-2 text-slate-500">
                      {isEn ? `Breakdown for ${item.label}` : `${item.label} এর বিস্তারিত লেনদেন (${item.transactionCount})`}
                    </div>

                    {item.transactions.length === 0 ? (
                      <p className="text-xs text-slate-400 italic py-2">
                        {isEn ? 'No transactions recorded.' : 'কোনো লেনদেন রেকর্ড নেই।'}
                      </p>
                    ) : (
                      <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                        {item.transactions.slice(0, 10).map((tx) => (
                          <div
                            key={tx.id}
                            className={`p-2 rounded-xl flex items-center justify-between text-xs border ${
                              isLight ? 'bg-white border-slate-200' : 'bg-slate-800 border-slate-700'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <span
                                className={`w-2 h-2 rounded-full ${
                                  tx.type === 'income' ? 'bg-emerald-500' : 'bg-rose-500'
                                }`}
                              />
                              <span className={`font-semibold ${headingText}`}>
                                {tx.notes || (tx.type === 'income' ? (isEn ? 'Income' : 'আয়') : (isEn ? 'Expense' : 'খরচ'))}
                              </span>
                              <span className="text-[10px] text-slate-400">{tx.date}</span>
                            </div>
                            <span
                              className={`font-black ${
                                tx.type === 'income' ? 'text-emerald-600' : 'text-rose-500'
                              }`}
                            >
                              {tx.type === 'income' ? '+' : '-'}
                              {formatCurrency(tx.amount, useBanglaDigits)}
                            </span>
                          </div>
                        ))}
                        {item.transactions.length > 10 && (
                          <p className="text-[10px] text-center text-slate-400 pt-1">
                            {isEn
                              ? `+ ${item.transactions.length - 10} more transactions`
                              : `+ আরো ${item.transactions.length - 10} টি লেনদেন রয়েছে`}
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
