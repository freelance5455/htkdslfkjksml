import React, { useState, useMemo } from 'react';
import { Transaction, Category, Account, AppSettings } from '../../../types';
import { formatCurrency, getMonthName, getCurrentMonthFormatted, formatDate } from '../../../utils/formatters';
import { CategoryIcon } from '../../CategoryIcon';
import { storage } from '../../../utils/storage';
import {
  ArrowDownRight,
  ArrowUpRight,
  ArrowDownLeft,
  Banknote,
  Smartphone,
  Landmark,
  ShieldAlert,
  Wallet,
  Calendar,
  Search,
  CreditCard,
  Clock,
  Coins,
  Receipt,
} from 'lucide-react';

interface ReportsTabProps {
  transactions: Transaction[];
  categories: Category[];
  accounts?: Account[];
  appSettings: AppSettings;
  useBanglaDigits: boolean;
}

type ReportSubTab = 'expenses' | 'incomes' | 'assets' | 'liabilities';

export const ReportsTab: React.FC<ReportsTabProps> = ({
  transactions = [],
  categories = [],
  accounts = [],
  appSettings,
  useBanglaDigits,
}) => {
  const [subTab, setSubTab] = useState<ReportSubTab>('expenses');
  const [selectedMonth, setSelectedMonth] = useState<string>(getCurrentMonthFormatted());
  const [searchQuery, setSearchQuery] = useState<string>('');

  const isEn = appSettings.language === 'en';
  const isLight = appSettings.themeMode === 'light';

  const cardBg = isLight
    ? 'bg-white border-slate-200/80 shadow-xs'
    : 'bg-slate-900 border-slate-800 shadow-md';
  const headingText = isLight ? 'text-slate-900' : 'text-slate-100';
  const subText = isLight ? 'text-slate-500' : 'text-slate-400';

  // Calculate live account balances based on transactions
  const balancedAccounts = useMemo(() => {
    return storage.calculateAccountBalances(accounts, transactions);
  }, [accounts, transactions]);

  // Unique months available
  const availableMonths = useMemo(() => {
    const set = new Set<string>();
    set.add(getCurrentMonthFormatted());
    transactions.forEach((tx) => {
      if (tx.date) set.add(tx.date.substring(0, 7));
    });
    return Array.from(set).sort().reverse();
  }, [transactions]);

  // Filter transactions by selected month for Income & Expense
  const monthTransactions = useMemo(() => {
    return transactions.filter((tx) => (tx.date ? tx.date.startsWith(selectedMonth) : false));
  }, [transactions, selectedMonth]);

  // EXPENSE DATA
  const expenseTxs = useMemo(() => {
    return monthTransactions
      .filter((tx) => tx.type === 'expense')
      .filter((tx) => {
        if (!searchQuery) return true;
        const q = searchQuery.toLowerCase();
        const cat = categories.find((c) => c.id === tx.categoryId);
        const catName = (cat ? (isEn ? cat.nameEnglish : cat.nameBangla) : '').toLowerCase();
        const notes = (tx.notes || '').toLowerCase();
        return catName.includes(q) || notes.includes(q);
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime() || b.id.localeCompare(a.id));
  }, [monthTransactions, categories, searchQuery, isEn]);

  const groupedExpenseTxs = useMemo(() => {
    const groups: { date: string; total: number; txs: Transaction[] }[] = [];
    const map = new Map<string, { date: string; total: number; txs: Transaction[] }>();

    expenseTxs.forEach((tx) => {
      const d = tx.date || 'Unknown';
      if (!map.has(d)) {
        const newGroup = { date: d, total: 0, txs: [] };
        map.set(d, newGroup);
        groups.push(newGroup);
      }
      const g = map.get(d)!;
      g.txs.push(tx);
      g.total += tx.amount;
    });

    return groups;
  }, [expenseTxs]);

  const expenseCategoryBreakdown = useMemo(() => {
    const map: Record<string, { amount: number; count: number }> = {};
    let total = 0;
    monthTransactions
      .filter((tx) => tx.type === 'expense')
      .forEach((tx) => {
        if (!map[tx.categoryId]) {
          map[tx.categoryId] = { amount: 0, count: 0 };
        }
        map[tx.categoryId].amount += tx.amount;
        map[tx.categoryId].count += 1;
        total += tx.amount;
      });

    return {
      total,
      list: Object.entries(map)
        .map(([catId, info]) => {
          const cat = categories.find((c) => c.id === catId);
          const percentage = total > 0 ? (info.amount / total) * 100 : 0;
          return {
            catId,
            name: cat ? (isEn ? cat.nameEnglish : cat.nameBangla) : catId,
            icon: cat ? cat.icon : 'ShoppingBag',
            color: cat ? cat.color : '#ef4444',
            amount: info.amount,
            count: info.count,
            percentage,
          };
        })
        .sort((a, b) => b.amount - a.amount),
    };
  }, [monthTransactions, categories, isEn]);

  // INCOME DATA
  const incomeTxs = useMemo(() => {
    return monthTransactions
      .filter((tx) => tx.type === 'income')
      .filter((tx) => {
        if (!searchQuery) return true;
        const q = searchQuery.toLowerCase();
        const cat = categories.find((c) => c.id === tx.categoryId);
        const catName = (cat ? (isEn ? cat.nameEnglish : cat.nameBangla) : '').toLowerCase();
        const notes = (tx.notes || '').toLowerCase();
        return catName.includes(q) || notes.includes(q);
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime() || b.id.localeCompare(a.id));
  }, [monthTransactions, categories, searchQuery, isEn]);

  const groupedIncomeTxs = useMemo(() => {
    const groups: { date: string; total: number; txs: Transaction[] }[] = [];
    const map = new Map<string, { date: string; total: number; txs: Transaction[] }>();

    incomeTxs.forEach((tx) => {
      const d = tx.date || 'Unknown';
      if (!map.has(d)) {
        const newGroup = { date: d, total: 0, txs: [] };
        map.set(d, newGroup);
        groups.push(newGroup);
      }
      const g = map.get(d)!;
      g.txs.push(tx);
      g.total += tx.amount;
    });

    return groups;
  }, [incomeTxs]);

  const incomeCategoryBreakdown = useMemo(() => {
    const map: Record<string, { amount: number; count: number }> = {};
    let total = 0;
    monthTransactions
      .filter((tx) => tx.type === 'income')
      .forEach((tx) => {
        if (!map[tx.categoryId]) {
          map[tx.categoryId] = { amount: 0, count: 0 };
        }
        map[tx.categoryId].amount += tx.amount;
        map[tx.categoryId].count += 1;
        total += tx.amount;
      });

    return {
      total,
      list: Object.entries(map)
        .map(([catId, info]) => {
          const cat = categories.find((c) => c.id === catId);
          const percentage = total > 0 ? (info.amount / total) * 100 : 0;
          return {
            catId,
            name: cat ? (isEn ? cat.nameEnglish : cat.nameBangla) : catId,
            icon: cat ? cat.icon : 'CircleDollarSign',
            color: cat ? cat.color : '#10b981',
            amount: info.amount,
            count: info.count,
            percentage,
          };
        })
        .sort((a, b) => b.amount - a.amount),
    };
  }, [monthTransactions, categories, isEn]);

  // ASSETS DATA
  // Assets are cash, bank, mobile_banking, card, and receivable (money owed to you)
  const assetAccounts = useMemo(() => {
    return balancedAccounts.filter(
      (acc) =>
        acc.type === 'cash' ||
        acc.type === 'bank' ||
        acc.type === 'mobile_banking' ||
        acc.type === 'card' ||
        acc.type === 'receivable'
    );
  }, [balancedAccounts]);

  const assetSummary = useMemo(() => {
    let cashTotal = 0;
    let bankTotal = 0;
    let mobileTotal = 0;
    let receivableTotal = 0;
    let cardTotal = 0;

    assetAccounts.forEach((acc) => {
      const bal = acc.currentBalance ?? acc.openingBalance;
      if (acc.type === 'cash') cashTotal += bal;
      else if (acc.type === 'bank') bankTotal += bal;
      else if (acc.type === 'mobile_banking') mobileTotal += bal;
      else if (acc.type === 'receivable') receivableTotal += bal;
      else if (acc.type === 'card') cardTotal += bal;
    });

    const totalAssets = cashTotal + bankTotal + mobileTotal + receivableTotal + cardTotal;
    return {
      totalAssets,
      cashTotal,
      bankTotal,
      mobileTotal,
      receivableTotal,
      cardTotal,
    };
  }, [assetAccounts]);

  // LIABILITIES DATA
  // Liabilities are accounts with type === 'payable' (debts/loans you owe)
  const liabilityAccounts = useMemo(() => {
    return balancedAccounts.filter((acc) => acc.type === 'payable');
  }, [balancedAccounts]);

  const liabilitySummary = useMemo(() => {
    let totalLiabilities = 0;
    liabilityAccounts.forEach((acc) => {
      totalLiabilities += acc.currentBalance ?? acc.openingBalance;
    });

    const netWorth = assetSummary.totalAssets - totalLiabilities;
    return {
      totalLiabilities,
      netWorth,
    };
  }, [liabilityAccounts, assetSummary]);

  const renderAccountIcon = (acc: Account) => {
    if (acc.icon === 'Banknote') return <Banknote className="w-5 h-5" />;
    if (acc.icon === 'Smartphone') return <Smartphone className="w-5 h-5" />;
    if (acc.icon === 'Landmark') return <Landmark className="w-5 h-5" />;
    if (acc.icon === 'CreditCard') return <CreditCard className="w-5 h-5" />;
    if (acc.icon === 'ArrowDownLeft') return <ArrowDownLeft className="w-5 h-5" />;
    if (acc.icon === 'ArrowUpRight') return <ArrowUpRight className="w-5 h-5" />;
    if (acc.icon === 'Wallet') return <Wallet className="w-5 h-5" />;
    if (acc.icon === 'Coins') return <Coins className="w-5 h-5" />;

    switch (acc.type) {
      case 'cash':
        return <Banknote className="w-5 h-5" />;
      case 'bank':
        return <Landmark className="w-5 h-5" />;
      case 'mobile_banking':
        return <Smartphone className="w-5 h-5" />;
      case 'card':
        return <CreditCard className="w-5 h-5" />;
      case 'receivable':
        return <ArrowDownLeft className="w-5 h-5" />;
      case 'payable':
        return <ArrowUpRight className="w-5 h-5" />;
      default: {
        const text = `${acc.nameEnglish || ''} ${acc.nameBangla || ''} ${acc.institutionName || ''}`.toLowerCase();
        if (text.includes('cash') || text.includes('নগদ') || text.includes('হাতের')) return <Banknote className="w-5 h-5" />;
        if (text.includes('bank') || text.includes('ব্যাংক')) return <Landmark className="w-5 h-5" />;
        if (text.includes('bkash') || text.includes('বিকাশ') || text.includes('nagad') || text.includes('rocket') || text.includes('upay')) return <Smartphone className="w-5 h-5" />;
        if (text.includes('card') || text.includes('কার্ড')) return <CreditCard className="w-5 h-5" />;
        if (text.includes('receivable') || text.includes('পাওনা')) return <ArrowDownLeft className="w-5 h-5" />;
        return <Wallet className="w-5 h-5" />;
      }
    }
  };

  const getAccountTypeLabel = (type: Account['type']) => {
    switch (type) {
      case 'cash':
        return isEn ? 'Cash Wallet' : 'নগদ ক্যাশ';
      case 'bank':
        return isEn ? 'Bank Account' : 'ব্যাংক হিসাব';
      case 'mobile_banking':
        return isEn ? 'Mobile Wallet' : 'মোবাইল ওয়ালেট';
      case 'card':
        return isEn ? 'Card Wallet' : 'কার্ড ওয়ালেট';
      case 'receivable':
        return isEn ? 'Receivables' : 'প্রাপ্য দেনাদার';
      case 'payable':
        return isEn ? 'Payables' : 'প্রদেয় পাওনাদার';
      default:
        return type;
    }
  };

  return (
    <div className="space-y-4">
      {/* 4 Sub-Pills in a single row: Expenses, Incomes, Assets, Liabilities (এক সারিতে) */}
      <div
        className={`p-1.5 rounded-2xl border grid grid-cols-4 gap-1 sm:gap-1.5 shadow-xs ${
          isLight ? 'bg-slate-100/90 border-slate-200' : 'bg-slate-800/80 border-slate-700'
        }`}
      >
        <button
          onClick={() => setSubTab('expenses')}
          className={`py-2 px-1 sm:px-3 rounded-xl text-[11px] sm:text-xs font-bold transition flex items-center justify-center gap-1 sm:gap-1.5 whitespace-nowrap ${
            subTab === 'expenses'
              ? 'bg-rose-600 text-white shadow-md'
              : isLight
              ? 'text-slate-600 hover:text-slate-900'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <ArrowDownRight className="w-3.5 h-3.5 shrink-0" />
          <span className="truncate">{isEn ? 'Expenses' : 'এক্সপেন্স'}</span>
        </button>

        <button
          onClick={() => setSubTab('incomes')}
          className={`py-2 px-1 sm:px-3 rounded-xl text-[11px] sm:text-xs font-bold transition flex items-center justify-center gap-1 sm:gap-1.5 whitespace-nowrap ${
            subTab === 'incomes'
              ? 'bg-emerald-600 text-white shadow-md'
              : isLight
              ? 'text-slate-600 hover:text-slate-900'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <ArrowUpRight className="w-3.5 h-3.5 shrink-0" />
          <span className="truncate">{isEn ? 'Incomes' : 'ইনকামস'}</span>
        </button>

        <button
          onClick={() => setSubTab('assets')}
          className={`py-2 px-1 sm:px-3 rounded-xl text-[11px] sm:text-xs font-bold transition flex items-center justify-center gap-1 sm:gap-1.5 whitespace-nowrap ${
            subTab === 'assets'
              ? 'bg-blue-600 text-white shadow-md'
              : isLight
              ? 'text-slate-600 hover:text-slate-900'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Landmark className="w-3.5 h-3.5 shrink-0" />
          <span className="truncate">{isEn ? 'Assets' : 'অ্যাসেটস্'}</span>
        </button>

        <button
          onClick={() => setSubTab('liabilities')}
          className={`py-2 px-1 sm:px-3 rounded-xl text-[11px] sm:text-xs font-bold transition flex items-center justify-center gap-1 sm:gap-1.5 whitespace-nowrap ${
            subTab === 'liabilities'
              ? 'bg-amber-600 text-white shadow-md'
              : isLight
              ? 'text-slate-600 hover:text-slate-900'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
          <span className="truncate">{isEn ? 'Liabilities' : 'লাইবেলিটিস'}</span>
        </button>
      </div>

      {/* Action Header: Month selector and Search for Expenses / Incomes */}
      {(subTab === 'expenses' || subTab === 'incomes') && (
        <div className="flex flex-wrap items-center gap-2.5">
          <div className="flex items-center gap-1.5">
            <Calendar className={`w-4 h-4 ${subText}`} />
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className={`px-3 py-1.5 border rounded-xl text-xs font-bold focus:outline-none ${
                isLight
                  ? 'bg-white border-slate-300 text-slate-900'
                  : 'bg-slate-900 border-slate-700 text-slate-100'
              }`}
            >
              {availableMonths.map((m) => (
                <option key={m} value={m}>
                  {getMonthName(m, appSettings.language, useBanglaDigits)}
                </option>
              ))}
            </select>
          </div>

          <div className="relative flex-1 sm:w-56">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isEn ? 'Search records...' : 'সার্চ করুন...'}
              className={`w-full pl-8 pr-3 py-1.5 rounded-xl text-xs border focus:outline-none ${
                isLight
                  ? 'bg-white border-slate-200 text-slate-900 focus:border-slate-400'
                  : 'bg-slate-800 border-slate-700 text-slate-100 focus:border-slate-600'
              }`}
            />
          </div>
        </div>
      )}

      {/* VIEW 1: EXPENSES */}
      {subTab === 'expenses' && (
        <div className="space-y-4">
          {/* Metrics */}
          <div className="grid grid-cols-2 gap-3">
            <div className={`${cardBg} rounded-2xl p-4 border border-rose-200/50 dark:border-rose-950/50`}>
              <p className="text-[11px] font-bold text-rose-500 uppercase tracking-wider">
                {isEn ? 'Total Expenses' : 'সর্বমোট খরচ'}
              </p>
              <p className="text-xl sm:text-2xl font-black text-rose-500 mt-1">
                {formatCurrency(expenseCategoryBreakdown.total, useBanglaDigits)}
              </p>
            </div>

            <div className={`${cardBg} rounded-2xl p-4 border border-rose-100 dark:border-rose-900/30`}>
              <p className={`text-[11px] font-bold uppercase tracking-wider ${subText}`}>
                {isEn ? 'Top Expense Category' : 'শীর্ষ খরচের খাত'}
              </p>
              <p className={`text-base sm:text-lg font-black ${headingText} mt-1 truncate`}>
                {expenseCategoryBreakdown.list[0]?.name || (isEn ? 'None' : 'নেই')}
              </p>
              {expenseCategoryBreakdown.list[0] && (
                <p className="text-xs font-bold text-rose-500 mt-0.5">
                  {formatCurrency(expenseCategoryBreakdown.list[0].amount, useBanglaDigits)}
                  <span className="text-[10px] font-normal text-slate-400 ml-1">
                    ({expenseCategoryBreakdown.list[0].percentage.toFixed(0)}%)
                  </span>
                </p>
              )}
            </div>
          </div>

          {/* Transactions List */}
          <div className={`${cardBg} rounded-2xl p-5 space-y-3`}>
            <div className="flex items-center justify-between">
              <h3 className={`text-xs font-bold uppercase tracking-wider ${headingText}`}>
                {isEn ? `Transaction Records (${expenseTxs.length})` : `লেনদেনের তালিকা (${expenseTxs.length})`}
              </h3>
              <span className="text-[11px] text-slate-400">
                {isEn ? 'By Date & Category' : 'তারিখ ও খাত অনুসারে'}
              </span>
            </div>

            {expenseTxs.length === 0 ? (
              <p className="text-xs text-slate-400 py-6 text-center italic">
                {isEn ? 'No matching transactions.' : 'কোনো লেনদেন পাওয়া যায়নি।'}
              </p>
            ) : (
              <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                {groupedExpenseTxs.map((group) => (
                  <div key={group.date} className="space-y-1.5">
                    {/* Date Header */}
                    <div className="flex items-center justify-between px-2.5 py-1 bg-slate-100/70 dark:bg-slate-800/60 rounded-lg text-[11px] font-bold text-slate-600 dark:text-slate-300">
                      <span className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        {formatDate(group.date, isEn ? 'en' : 'bn', useBanglaDigits)}
                      </span>
                      <span className="text-rose-500 font-extrabold">
                        -{formatCurrency(group.total, useBanglaDigits)}
                      </span>
                    </div>

                    {/* Transactions under this date */}
                    <div className="divide-y divide-slate-100 dark:divide-slate-800/60 px-1">
                      {group.txs.map((tx) => {
                        const cat = categories.find((c) => c.id === tx.categoryId);
                        const acc = accounts.find((a) => a.id === tx.accountId);
                        const catName = cat
                          ? isEn
                            ? cat.nameEnglish || cat.nameBangla
                            : cat.nameBangla || cat.nameEnglish
                          : isEn
                          ? 'Expense'
                          : 'খরচ';
                        const subtitle = [
                          tx.notes,
                          acc
                            ? isEn
                              ? acc.nameEnglish || acc.nameBangla
                              : acc.nameBangla || acc.nameEnglish
                            : tx.paymentMethod,
                        ]
                          .filter(Boolean)
                          .join(' • ');

                        return (
                          <div key={tx.id} className="py-2 flex items-center justify-between gap-3 text-xs">
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div
                                className="w-7 h-7 rounded-xl flex items-center justify-center text-white shrink-0 shadow-2xs"
                                style={{ backgroundColor: cat?.color || '#ef4444' }}
                              >
                                <CategoryIcon name={cat?.icon || 'Receipt'} className="w-4 h-4" />
                              </div>
                              <div className="min-w-0">
                                <p className={`font-bold truncate text-xs ${headingText}`}>
                                  {catName}
                                </p>
                                {subtitle && (
                                  <p className="text-[10px] text-slate-400 truncate mt-0.5">
                                    {subtitle}
                                  </p>
                                )}
                              </div>
                            </div>
                            <span className="font-black text-rose-500 shrink-0">
                              -{formatCurrency(tx.amount, useBanglaDigits)}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* VIEW 2: INCOMES */}
      {subTab === 'incomes' && (
        <div className="space-y-4">
          {/* Metrics */}
          <div className="grid grid-cols-2 gap-3">
            <div className={`${cardBg} rounded-2xl p-4 border border-emerald-200/50 dark:border-emerald-950/50`}>
              <p className="text-[11px] font-bold text-emerald-600 uppercase tracking-wider">
                {isEn ? 'Total Incomes' : 'সর্বমোট আয়'}
              </p>
              <p className="text-xl sm:text-2xl font-black text-emerald-600 mt-1">
                {formatCurrency(incomeCategoryBreakdown.total, useBanglaDigits)}
              </p>
            </div>

            <div className={`${cardBg} rounded-2xl p-4 border border-emerald-100 dark:border-emerald-900/30`}>
              <p className={`text-[11px] font-bold uppercase tracking-wider ${subText}`}>
                {isEn ? 'Top Income Source' : 'শীর্ষ আয়ের উৎস'}
              </p>
              <p className={`text-base sm:text-lg font-black ${headingText} mt-1 truncate`}>
                {incomeCategoryBreakdown.list[0]?.name || (isEn ? 'None' : 'নেই')}
              </p>
              {incomeCategoryBreakdown.list[0] && (
                <p className="text-xs font-bold text-emerald-600 dark:text-emerald-400 mt-0.5">
                  {formatCurrency(incomeCategoryBreakdown.list[0].amount, useBanglaDigits)}
                  <span className="text-[10px] font-normal text-slate-400 ml-1">
                    ({incomeCategoryBreakdown.list[0].percentage.toFixed(0)}%)
                  </span>
                </p>
              )}
            </div>
          </div>

          {/* Income Transactions List */}
          <div className={`${cardBg} rounded-2xl p-5 space-y-3`}>
            <div className="flex items-center justify-between">
              <h3 className={`text-xs font-bold uppercase tracking-wider ${headingText}`}>
                {isEn ? `Transaction Records (${incomeTxs.length})` : `লেনদেনের তালিকা (${incomeTxs.length})`}
              </h3>
              <span className="text-[11px] text-slate-400">
                {isEn ? 'By Date & Source' : 'তারিখ ও খাত অনুসারে'}
              </span>
            </div>

            {incomeTxs.length === 0 ? (
              <p className="text-xs text-slate-400 py-6 text-center italic">
                {isEn ? 'No matching transactions.' : 'কোনো লেনদেন পাওয়া যায়নি।'}
              </p>
            ) : (
              <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                {groupedIncomeTxs.map((group) => (
                  <div key={group.date} className="space-y-1.5">
                    {/* Date Header */}
                    <div className="flex items-center justify-between px-2.5 py-1 bg-slate-100/70 dark:bg-slate-800/60 rounded-lg text-[11px] font-bold text-slate-600 dark:text-slate-300">
                      <span className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        {formatDate(group.date, isEn ? 'en' : 'bn', useBanglaDigits)}
                      </span>
                      <span className="text-emerald-600 dark:text-emerald-400 font-extrabold">
                        +{formatCurrency(group.total, useBanglaDigits)}
                      </span>
                    </div>

                    {/* Transactions under this date */}
                    <div className="divide-y divide-slate-100 dark:divide-slate-800/60 px-1">
                      {group.txs.map((tx) => {
                        const cat = categories.find((c) => c.id === tx.categoryId);
                        const acc = accounts.find((a) => a.id === tx.accountId);
                        const catName = cat
                          ? isEn
                            ? cat.nameEnglish || cat.nameBangla
                            : cat.nameBangla || cat.nameEnglish
                          : isEn
                          ? 'Income'
                          : 'আয়';
                        const subtitle = [
                          tx.notes,
                          acc
                            ? isEn
                              ? acc.nameEnglish || acc.nameBangla
                              : acc.nameBangla || acc.nameEnglish
                            : tx.paymentMethod,
                        ]
                          .filter(Boolean)
                          .join(' • ');

                        return (
                          <div key={tx.id} className="py-2 flex items-center justify-between gap-3 text-xs">
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div
                                className="w-7 h-7 rounded-xl flex items-center justify-center text-white shrink-0 shadow-2xs"
                                style={{ backgroundColor: cat?.color || '#10b981' }}
                              >
                                <CategoryIcon name={cat?.icon || 'Coins'} className="w-4 h-4" />
                              </div>
                              <div className="min-w-0">
                                <p className={`font-bold truncate text-xs ${headingText}`}>
                                  {catName}
                                </p>
                                {subtitle && (
                                  <p className="text-[10px] text-slate-400 truncate mt-0.5">
                                    {subtitle}
                                  </p>
                                )}
                              </div>
                            </div>
                            <span className="font-black text-emerald-600 dark:text-emerald-400 shrink-0">
                              +{formatCurrency(tx.amount, useBanglaDigits)}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* VIEW 3: ASSETS */}
      {subTab === 'assets' && (
        <div className="space-y-4">
          {/* Asset Distribution Bar */}
          {assetSummary.totalAssets > 0 && (
            <div className={`${cardBg} rounded-2xl p-4 space-y-2`}>
              <div className="flex items-center justify-between text-xs font-bold text-slate-500">
                <span>{isEn ? 'Asset Distribution' : 'সম্পদের বণ্টন অনুপাত'}</span>
                <span>100%</span>
              </div>
              <div className="w-full h-3 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden flex">
                {assetSummary.cashTotal > 0 && (
                  <div
                    title="Cash"
                    className="h-full bg-emerald-500"
                    style={{ width: `${(assetSummary.cashTotal / assetSummary.totalAssets) * 100}%` }}
                  />
                )}
                {assetSummary.bankTotal > 0 && (
                  <div
                    title="Bank"
                    className="h-full bg-blue-500"
                    style={{ width: `${(assetSummary.bankTotal / assetSummary.totalAssets) * 100}%` }}
                  />
                )}
                {assetSummary.mobileTotal > 0 && (
                  <div
                    title="Mobile Wallets"
                    className="h-full bg-pink-500"
                    style={{ width: `${(assetSummary.mobileTotal / assetSummary.totalAssets) * 100}%` }}
                  />
                )}
                {assetSummary.receivableTotal > 0 && (
                  <div
                    title="Receivables"
                    className="h-full bg-amber-500"
                    style={{ width: `${(assetSummary.receivableTotal / assetSummary.totalAssets) * 100}%` }}
                  />
                )}
              </div>
              <div className="flex flex-wrap items-center gap-3 pt-1 text-[11px] font-semibold text-slate-500">
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  Cash ({((assetSummary.cashTotal / assetSummary.totalAssets) * 100).toFixed(0)}%)
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                  Bank ({((assetSummary.bankTotal / assetSummary.totalAssets) * 100).toFixed(0)}%)
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-pink-500" />
                  Mobile ({((assetSummary.mobileTotal / assetSummary.totalAssets) * 100).toFixed(0)}%)
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  Receivable ({((assetSummary.receivableTotal / assetSummary.totalAssets) * 100).toFixed(0)}%)
                </span>
              </div>
            </div>
          )}

          {/* Accounts Breakdown List */}
          <div className={`${cardBg} rounded-2xl p-5 space-y-3`}>
            <h3 className={`text-xs font-bold uppercase tracking-wider ${headingText}`}>
              {isEn ? `Asset Accounts List (${assetAccounts.length})` : `সম্পদ হিসাব তালিকা (${assetAccounts.length})`}
            </h3>

            {assetAccounts.length === 0 ? (
              <p className="text-xs text-slate-400 py-6 text-center italic">
                {isEn ? 'No asset accounts registered.' : 'কোনো সম্পদ অ্যাকাউন্ট পাওয়া যায়নি।'}
              </p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                {assetAccounts.map((acc) => {
                  const bal = acc.currentBalance ?? acc.openingBalance;
                  return (
                    <div
                      key={acc.id}
                      className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 ${
                        isLight ? 'bg-slate-50/80 border-slate-200' : 'bg-slate-800/60 border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div
                          className="w-10 h-10 rounded-xl flex items-center justify-center text-white shrink-0 shadow-xs"
                          style={{ backgroundColor: acc.color || '#3b82f6' }}
                        >
                          {renderAccountIcon(acc)}
                        </div>
                        <div className="min-w-0">
                          <p className={`text-xs sm:text-sm font-bold truncate ${headingText}`}>
                            {isEn ? (acc.nameEnglish || acc.nameBangla) : (acc.nameBangla || acc.nameEnglish)}
                          </p>
                          <p className="text-[10px] text-slate-400 truncate mt-0.5">
                            {acc.institutionName || acc.accountNumber || (isEn ? 'Asset Account' : 'সম্পদ হিসাব')}
                          </p>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <p className="text-xs sm:text-sm font-black text-emerald-600 dark:text-emerald-400">
                          {formatCurrency(bal, useBanglaDigits)}
                        </p>
                        <span className="inline-block text-[10px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700/60 text-slate-600 dark:text-slate-300 mt-0.5">
                          {getAccountTypeLabel(acc.type)}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* VIEW 4: LIABILITIES */}
      {subTab === 'liabilities' && (
        <div className="space-y-4">
          {/* Liabilities Metrics */}
          <div className="grid grid-cols-2 gap-3">
            <div className={`${cardBg} rounded-2xl p-4 border border-rose-200/60 dark:border-rose-950/60`}>
              <p className="text-[11px] font-bold text-rose-500 uppercase tracking-wider">
                {isEn ? 'Total Liabilities' : 'সর্বমোট দায় ও ঋণ'}
              </p>
              <p className="text-xl sm:text-2xl font-black text-rose-500 mt-1">
                {formatCurrency(liabilitySummary.totalLiabilities, useBanglaDigits)}
              </p>
            </div>

            <div className={`${cardBg} rounded-2xl p-4`}>
              <p className={`text-[11px] font-bold uppercase tracking-wider ${subText}`}>
                {isEn ? 'Payable Accounts' : 'মোট প্রদেয় খতিয়ান'}
              </p>
              <p className={`text-xl sm:text-2xl font-black ${headingText} mt-1`}>
                {liabilityAccounts.length} {isEn ? 'accounts' : 'টি হিসাব'}
              </p>
            </div>
          </div>

          {/* Payables List */}
          <div className={`${cardBg} rounded-2xl p-5 space-y-3`}>
            <h3 className={`text-xs font-bold uppercase tracking-wider ${headingText}`}>
              {isEn ? `Payable Dues & Debts (${liabilityAccounts.length})` : `প্রদেয় দেনা ও ঋণের হিসাব (${liabilityAccounts.length})`}
            </h3>

            {liabilityAccounts.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400">
                <p className="font-bold text-emerald-600">{isEn ? 'Great! You have no outstanding liabilities.' : 'দারুণ! আপনার কোনো বকেয়া ঋণ বা দেনা নেই।'}</p>
                <p className="mt-1 text-[11px]">{isEn ? 'All debt accounts are clear.' : 'সকল ঋণ পরিশোধিত রয়েছে।'}</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                {liabilityAccounts.map((acc) => {
                  const bal = acc.currentBalance ?? acc.openingBalance;
                  return (
                    <div
                      key={acc.id}
                      className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 ${
                        isLight ? 'bg-rose-50/40 border-rose-100' : 'bg-slate-800/60 border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-9 h-9 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center shrink-0">
                          <ShieldAlert className="w-5 h-5" />
                        </div>
                        <div className="min-w-0">
                          <p className={`text-xs font-bold truncate ${headingText}`}>
                            {isEn ? acc.nameEnglish : acc.nameBangla}
                          </p>
                          <p className="text-[10px] text-slate-400 truncate">
                            {acc.phoneNumber ? `Phone: ${acc.phoneNumber}` : acc.notes || 'Payable'}
                          </p>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <p className="text-xs sm:text-sm font-black text-rose-500">
                          {formatCurrency(bal, useBanglaDigits)}
                        </p>
                        {acc.dueDate && (
                          <p className="text-[10px] text-amber-500 font-semibold flex items-center justify-end gap-1">
                            <Clock className="w-2.5 h-2.5" />
                            {acc.dueDate}
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
