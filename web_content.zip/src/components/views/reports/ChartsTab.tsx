import React, { useState, useMemo } from 'react';
import { Transaction, Category, AppSettings } from '../../../types';
import { formatCurrency, getMonthName, getCurrentMonthFormatted } from '../../../utils/formatters';
import {
  PieChart as RePieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
} from 'recharts';
import { Calendar, Filter, Sparkles } from 'lucide-react';

interface ChartsTabProps {
  transactions: Transaction[];
  categories: Category[];
  appSettings: AppSettings;
  useBanglaDigits: boolean;
}

// Accessible colorful palette inspired by Image 2
const PALETTE = [
  '#0284c7', // Sky blue
  '#7c3aed', // Purple / Violet
  '#334155', // Slate dark
  '#f59e0b', // Amber
  '#ec4899', // Pink
  '#10b981', // Emerald
  '#f97316', // Orange
  '#06b6d4', // Cyan
  '#6366f1', // Indigo
  '#14b8a6', // Teal
  '#e11d48', // Rose
  '#84cc16', // Lime
  '#a855f7', // Purple
  '#0ea5e9', // Ocean
];

export const ChartsTab: React.FC<ChartsTabProps> = ({
  transactions = [],
  categories = [],
  appSettings,
  useBanglaDigits,
}) => {
  const isEn = appSettings.language === 'en';
  const isLight = appSettings.themeMode === 'light';

  const [timeframe, setTimeframe] = useState<'this_month' | 'last_month' | 'this_year' | 'all' | 'custom'>('this_month');
  const [selectedMonth, setSelectedMonth] = useState<string>(getCurrentMonthFormatted());

  const cardBg = isLight
    ? 'bg-white border-slate-200/80 shadow-xs'
    : 'bg-slate-900 border-slate-800 shadow-md';
  const headingText = isLight ? 'text-slate-900' : 'text-slate-100';
  const subText = isLight ? 'text-slate-500' : 'text-slate-400';

  // Extract available months for custom dropdown
  const availableMonths = useMemo(() => {
    const set = new Set<string>();
    set.add(getCurrentMonthFormatted());
    transactions.forEach((tx) => {
      if (tx.date) set.add(tx.date.substring(0, 7));
    });
    return Array.from(set).sort().reverse();
  }, [transactions]);

  // Filter transactions according to selected timeframe
  const filteredTransactions = useMemo(() => {
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonthStr = getCurrentMonthFormatted();

    // Last month
    const lastMonthDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const lastMonthStr = `${lastMonthDate.getFullYear()}-${String(lastMonthDate.getMonth() + 1).padStart(2, '0')}`;

    return transactions.filter((tx) => {
      if (!tx.date) return false;
      if (timeframe === 'this_month') {
        return tx.date.startsWith(currentMonthStr);
      }
      if (timeframe === 'last_month') {
        return tx.date.startsWith(lastMonthStr);
      }
      if (timeframe === 'this_year') {
        return tx.date.startsWith(String(currentYear));
      }
      if (timeframe === 'custom') {
        return tx.date.startsWith(selectedMonth);
      }
      return true; // 'all'
    });
  }, [transactions, timeframe, selectedMonth]);

  // Aggregate by category for Income, Expense, and Combined Overview
  const { incomeItems, expenseItems, overviewItems, totalIncome, totalExpense } = useMemo(() => {
    const incMap: Record<string, number> = {};
    const expMap: Record<string, number> = {};
    let incSum = 0;
    let expSum = 0;

    filteredTransactions.forEach((tx) => {
      if (tx.type === 'income') {
        incMap[tx.categoryId] = (incMap[tx.categoryId] || 0) + tx.amount;
        incSum += tx.amount;
      } else if (tx.type === 'expense') {
        expMap[tx.categoryId] = (expMap[tx.categoryId] || 0) + tx.amount;
        expSum += tx.amount;
      }
    });

    const formatCategoryData = (map: Record<string, number>, total: number) => {
      return Object.entries(map)
        .map(([catId, amount], idx) => {
          const cat = categories.find((c) => c.id === catId);
          const name = cat
            ? isEn
              ? cat.nameEnglish
              : cat.nameBangla
            : catId;
          const percentage = total > 0 ? (amount / total) * 100 : 0;
          return {
            id: catId,
            name,
            value: amount,
            percentage: Math.round(percentage),
            exactPct: percentage.toFixed(1),
            color: cat?.color && cat.color.startsWith('#') ? cat.color : PALETTE[idx % PALETTE.length],
          };
        })
        .sort((a, b) => b.value - a.value);
    };

    const incList = formatCategoryData(incMap, incSum);
    const expList = formatCategoryData(expMap, expSum);

    // Overview list: combines all categories
    const totalAll = incSum + expSum;
    const allMap: Record<string, { amount: number; type: 'income' | 'expense' }> = {};
    filteredTransactions.forEach((tx) => {
      if (!allMap[tx.categoryId]) {
        allMap[tx.categoryId] = { amount: 0, type: tx.type === 'income' ? 'income' : 'expense' };
      }
      allMap[tx.categoryId].amount += tx.amount;
    });

    const ovList = Object.entries(allMap)
      .map(([catId, info], idx) => {
        const cat = categories.find((c) => c.id === catId);
        const name = cat ? (isEn ? cat.nameEnglish : cat.nameBangla) : catId;
        const percentage = totalAll > 0 ? (info.amount / totalAll) * 100 : 0;
        return {
          id: catId,
          name,
          value: info.amount,
          type: info.type,
          percentage: Math.round(percentage),
          exactPct: percentage.toFixed(1),
          color: cat?.color && cat.color.startsWith('#') ? cat.color : PALETTE[idx % PALETTE.length],
        };
      })
      .sort((a, b) => b.value - a.value);

    return {
      incomeItems: incList,
      expenseItems: expList,
      overviewItems: ovList,
      totalIncome: incSum,
      totalExpense: expSum,
    };
  }, [filteredTransactions, categories, isEn]);

  return (
    <div className="space-y-6">
      {/* Timeframe Filter Bar */}
      <div
        className={`p-3 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
          isLight ? 'bg-slate-100/90 border-slate-200' : 'bg-slate-800/80 border-slate-700'
        }`}
      >
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          <button
            onClick={() => setTimeframe('this_month')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition ${
              timeframe === 'this_month'
                ? 'bg-emerald-600 text-white shadow-sm'
                : isLight
                ? 'text-slate-600 hover:text-slate-900 bg-white/60'
                : 'text-slate-300 hover:text-white bg-slate-900/60'
            }`}
          >
            {isEn ? 'This Month' : 'এই মাস'}
          </button>
          <button
            onClick={() => setTimeframe('last_month')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition ${
              timeframe === 'last_month'
                ? 'bg-emerald-600 text-white shadow-sm'
                : isLight
                ? 'text-slate-600 hover:text-slate-900 bg-white/60'
                : 'text-slate-300 hover:text-white bg-slate-900/60'
            }`}
          >
            {isEn ? 'Last Month' : 'গত মাস'}
          </button>
          <button
            onClick={() => setTimeframe('this_year')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition ${
              timeframe === 'this_year'
                ? 'bg-emerald-600 text-white shadow-sm'
                : isLight
                ? 'text-slate-600 hover:text-slate-900 bg-white/60'
                : 'text-slate-300 hover:text-white bg-slate-900/60'
            }`}
          >
            {isEn ? 'This Year' : 'এই বছর'}
          </button>
          <button
            onClick={() => setTimeframe('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition ${
              timeframe === 'all'
                ? 'bg-emerald-600 text-white shadow-sm'
                : isLight
                ? 'text-slate-600 hover:text-slate-900 bg-white/60'
                : 'text-slate-300 hover:text-white bg-slate-900/60'
            }`}
          >
            {isEn ? 'All Time' : 'সব সময়'}
          </button>
          <button
            onClick={() => setTimeframe('custom')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition flex items-center gap-1 ${
              timeframe === 'custom'
                ? 'bg-emerald-600 text-white shadow-sm'
                : isLight
                ? 'text-slate-600 hover:text-slate-900 bg-white/60'
                : 'text-slate-300 hover:text-white bg-slate-900/60'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>{isEn ? 'Custom' : 'নির্দিষ্ট মাস'}</span>
          </button>
        </div>

        {timeframe === 'custom' && (
          <div className="flex items-center gap-2">
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className={`px-3 py-1.5 border rounded-xl text-xs font-bold focus:outline-none ${
                isLight
                  ? 'bg-white border-slate-300 text-slate-900'
                  : 'bg-slate-900 border-slate-700 text-slate-100'
              }`}
            >
              {availableMonths.map((m) => (
                <option key={m} value={m}>
                  {getMonthName(m, appSettings.language, useBanglaDigits)}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* SECTION 1: INCOME DONUT CHART (ছবি অনুযায়ী) */}
      <div className={`${cardBg} rounded-3xl p-5 sm:p-6 space-y-4`}>
        <div className="text-center">
          <h2 className="text-xs sm:text-sm font-black tracking-widest text-slate-400 dark:text-slate-500 uppercase">
            {isEn ? 'INCOME' : 'আয় বিশ্লেষণ (INCOME)'}
          </h2>
          <p className="text-lg sm:text-xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
            {formatCurrency(totalIncome, useBanglaDigits)}
          </p>
        </div>

        {incomeItems.length === 0 ? (
          <div className="py-12 text-center text-xs text-slate-400">
            {isEn ? 'No income records found for this period.' : 'এই সময়ে কোনো আয়ের রেকর্ড পাওয়া যায়নি।'}
          </div>
        ) : (
          <div className="space-y-4">
            {/* Donut Chart with center hole */}
            <div className="h-56 sm:h-64 w-full relative flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <RePieChart>
                  <Pie
                    data={incomeItems}
                    cx="50%"
                    cy="50%"
                    innerRadius={58}
                    outerRadius={88}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {incomeItems.map((entry) => (
                      <Cell key={entry.id} fill={entry.color} stroke="none" />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(val: number) => [
                      formatCurrency(val, useBanglaDigits),
                      isEn ? 'Amount' : 'পরিমাণ',
                    ]}
                    contentStyle={{
                      backgroundColor: isLight ? '#ffffff' : '#0f172a',
                      borderColor: isLight ? '#e2e8f0' : '#334155',
                      borderRadius: '12px',
                      fontSize: '12px',
                      boxShadow: '0 8px 24px rgba(0,0,0,0.12)',
                    }}
                  />
                </RePieChart>
              </ResponsiveContainer>

              {/* Center Ring Label */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-[11px] font-bold text-slate-400 uppercase">
                  {isEn ? 'Income' : 'মোট আয়'}
                </span>
                <span className="text-sm font-black text-emerald-600">
                  {formatCurrency(totalIncome, useBanglaDigits)}
                </span>
              </div>
            </div>

            {/* Legend Pills Grid matching Image 2 */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-2">
              {incomeItems.map((item) => (
                <div
                  key={item.id}
                  className={`p-2.5 rounded-2xl border flex items-center gap-2.5 transition ${
                    isLight ? 'bg-slate-50/80 border-slate-200/80' : 'bg-slate-800/60 border-slate-700/60'
                  }`}
                >
                  <span
                    className="w-3.5 h-3.5 rounded-full shrink-0 ring-2 ring-white/50"
                    style={{ backgroundColor: item.color }}
                  />
                  <div className="min-w-0 flex-1">
                    <p className={`text-xs font-bold truncate ${headingText}`}>
                      {item.name} {item.percentage}%
                    </p>
                    <p className="text-[11px] font-semibold text-emerald-600 truncate">
                      ({formatCurrency(item.value, useBanglaDigits)})
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* SECTION 2: EXPENSE DONUT CHART (ছবি অনুযায়ী) */}
      <div className={`${cardBg} rounded-3xl p-5 sm:p-6 space-y-4`}>
        <div className="text-center">
          <h2 className="text-xs sm:text-sm font-black tracking-widest text-slate-400 dark:text-slate-500 uppercase">
            {isEn ? 'EXPENSE' : 'ব্যয় বিশ্লেষণ (EXPENSE)'}
          </h2>
          <p className="text-lg sm:text-xl font-black text-rose-500 dark:text-rose-400 mt-1">
            {formatCurrency(totalExpense, useBanglaDigits)}
          </p>
        </div>

        {expenseItems.length === 0 ? (
          <div className="py-12 text-center text-xs text-slate-400">
            {isEn ? 'No expense records found for this period.' : 'এই সময়ে কোনো খরচের রেকর্ড পাওয়া যায়নি।'}
          </div>
        ) : (
          <div className="space-y-4">
            {/* Donut Chart with multi-color slices */}
            <div className="h-60 sm:h-72 w-full relative flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <RePieChart>
                  <Pie
                    data={expenseItems}
                    cx="50%"
                    cy="50%"
                    innerRadius={62}
                    outerRadius={96}
                    paddingAngle={2.5}
                    dataKey="value"
                  >
                    {expenseItems.map((entry) => (
                      <Cell key={entry.id} fill={entry.color} stroke="none" />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(val: number) => [
                      formatCurrency(val, useBanglaDigits),
                      isEn ? 'Amount' : 'পরিমাণ',
                    ]}
                    contentStyle={{
                      backgroundColor: isLight ? '#ffffff' : '#0f172a',
                      borderColor: isLight ? '#e2e8f0' : '#334155',
                      borderRadius: '12px',
                      fontSize: '12px',
                      boxShadow: '0 8px 24px rgba(0,0,0,0.12)',
                    }}
                  />
                </RePieChart>
              </ResponsiveContainer>

              {/* Center Ring Label */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-[11px] font-bold text-slate-400 uppercase">
                  {isEn ? 'Expense' : 'মোট খরচ'}
                </span>
                <span className="text-sm font-black text-rose-500">
                  {formatCurrency(totalExpense, useBanglaDigits)}
                </span>
              </div>
            </div>

            {/* Legend Pills Grid matching Image 2 */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 pt-2">
              {expenseItems.map((item) => (
                <div
                  key={item.id}
                  className={`p-2.5 rounded-2xl border flex items-center gap-2.5 transition ${
                    isLight ? 'bg-slate-50/80 border-slate-200/80' : 'bg-slate-800/60 border-slate-700/60'
                  }`}
                >
                  <span
                    className="w-3.5 h-3.5 rounded-full shrink-0 ring-2 ring-white/50"
                    style={{ backgroundColor: item.color }}
                  />
                  <div className="min-w-0 flex-1">
                    <p className={`text-xs font-bold truncate ${headingText}`}>
                      {item.name} {item.percentage}%
                    </p>
                    <p className="text-[11px] font-semibold text-rose-500 truncate">
                      ({formatCurrency(item.value, useBanglaDigits)})
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* SECTION 3: OVERVIEW DONUT CHART (ছবি অনুযায়ী) */}
      <div className={`${cardBg} rounded-3xl p-5 sm:p-6 space-y-4`}>
        <div className="text-center">
          <h2 className="text-xs sm:text-sm font-black tracking-widest text-slate-400 dark:text-slate-500 uppercase">
            {isEn ? 'OVERVIEW' : 'সামগ্রিক বিশ্লেষণ (OVERVIEW)'}
          </h2>
          <div className="flex items-center justify-center gap-4 mt-1 text-xs font-bold">
            <span className="text-emerald-600">
              {isEn ? 'Income: ' : 'আয়: '}
              {formatCurrency(totalIncome, useBanglaDigits)}
            </span>
            <span className="text-slate-300">|</span>
            <span className="text-rose-500">
              {isEn ? 'Expense: ' : 'খরচ: '}
              {formatCurrency(totalExpense, useBanglaDigits)}
            </span>
          </div>
        </div>

        {overviewItems.length === 0 ? (
          <div className="py-12 text-center text-xs text-slate-400">
            {isEn ? 'No transaction records found for this period.' : 'কোনো লেনদেনের রেকর্ড পাওয়া যায়নি।'}
          </div>
        ) : (
          <div className="space-y-4">
            {/* Holistic Donut Chart */}
            <div className="h-60 sm:h-72 w-full relative flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <RePieChart>
                  <Pie
                    data={overviewItems}
                    cx="50%"
                    cy="50%"
                    innerRadius={62}
                    outerRadius={96}
                    paddingAngle={2.5}
                    dataKey="value"
                  >
                    {overviewItems.map((entry) => (
                      <Cell key={entry.id} fill={entry.color} stroke="none" />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(val: number) => [
                      formatCurrency(val, useBanglaDigits),
                      isEn ? 'Amount' : 'পরিমাণ',
                    ]}
                    contentStyle={{
                      backgroundColor: isLight ? '#ffffff' : '#0f172a',
                      borderColor: isLight ? '#e2e8f0' : '#334155',
                      borderRadius: '12px',
                      fontSize: '12px',
                      boxShadow: '0 8px 24px rgba(0,0,0,0.12)',
                    }}
                  />
                </RePieChart>
              </ResponsiveContainer>

              {/* Center Ring Label */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-[11px] font-bold text-slate-400 uppercase">
                  {isEn ? 'Net Balance' : 'নিট উদ্বৃত্ত'}
                </span>
                <span
                  className={`text-sm font-black ${
                    totalIncome - totalExpense >= 0 ? 'text-emerald-600' : 'text-rose-500'
                  }`}
                >
                  {formatCurrency(totalIncome - totalExpense, useBanglaDigits)}
                </span>
              </div>
            </div>

            {/* Legend Pills Grid matching Image 2 */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 pt-2">
              {overviewItems.map((item) => (
                <div
                  key={item.id}
                  className={`p-2.5 rounded-2xl border flex items-center gap-2.5 transition ${
                    isLight ? 'bg-slate-50/80 border-slate-200/80' : 'bg-slate-800/60 border-slate-700/60'
                  }`}
                >
                  <span
                    className="w-3.5 h-3.5 rounded-full shrink-0 ring-2 ring-white/50"
                    style={{ backgroundColor: item.color }}
                  />
                  <div className="min-w-0 flex-1">
                    <p className={`text-xs font-bold truncate ${headingText}`}>
                      {item.name} {item.percentage}%
                    </p>
                    <p
                      className={`text-[11px] font-semibold truncate ${
                        item.type === 'income' ? 'text-emerald-600' : 'text-rose-500'
                      }`}
                    >
                      ({formatCurrency(item.value, useBanglaDigits)})
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
