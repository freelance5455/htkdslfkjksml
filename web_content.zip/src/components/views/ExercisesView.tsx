import React, { useState } from 'react';
import {
  Search,
  Filter,
  ShieldAlert,
  Info,
  ChevronRight,
  Plus,
  Play,
  Trophy,
  X,
  Dumbbell,
  CheckCircle2
} from 'lucide-react';
import { useWorkout } from '../../context/WorkoutContext';
import { Exercise } from '../../types';
import {
  MuscleMapCharacter,
  MuscleGroupId,
  MUSCLE_GROUP_LABELS,
  mapMuscleStringToGroups
} from '../MuscleMapCharacter';
import { playPopSound } from '../../utils/audio';

type MajorMuscleChipId =
  | 'all'
  | 'chest'
  | 'back'
  | 'legs'
  | 'shoulders'
  | 'arms'
  | 'core'
  | 'glutes';

const MAJOR_MUSCLE_CHIPS: {
  id: MajorMuscleChipId;
  label: string;
  groups: MuscleGroupId[];
  primaryMapGroup: MuscleGroupId | null;
}[] = [
  { id: 'all', label: 'All Muscles', groups: [], primaryMapGroup: null },
  { id: 'chest', label: 'Chest', groups: ['chest'], primaryMapGroup: 'chest' },
  {
    id: 'back',
    label: 'Back',
    groups: ['lats', 'mid-back', 'traps', 'lower-back'],
    primaryMapGroup: 'lats'
  },
  {
    id: 'legs',
    label: 'Legs',
    groups: ['quads', 'hamstrings', 'glutes', 'calves', 'adductors'],
    primaryMapGroup: 'quads'
  },
  {
    id: 'shoulders',
    label: 'Shoulders',
    groups: ['front-delts', 'side-delts', 'rear-delts'],
    primaryMapGroup: 'front-delts'
  },
  {
    id: 'arms',
    label: 'Arms',
    groups: ['biceps', 'triceps', 'forearms'],
    primaryMapGroup: 'biceps'
  },
  {
    id: 'core',
    label: 'Core / Abs',
    groups: ['abs', 'obliques'],
    primaryMapGroup: 'abs'
  },
  {
    id: 'glutes',
    label: 'Glutes & Hams',
    groups: ['glutes', 'hamstrings'],
    primaryMapGroup: 'glutes'
  }
];

export const ExercisesView: React.FC = () => {
  const {
    exercises,
    activeWorkout,
    addExerciseToActiveWorkout,
    setIsWorkoutModalOpen,
    startWorkout,
    addPersonalRecord,
    user
  } = useWorkout();

  const [search, setSearch] = useState('');
  const [selectedMuscleChip, setSelectedMuscleChip] = useState<MajorMuscleChipId>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');
  const [selectedEquipment, setSelectedEquipment] = useState<string>('all');
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null);
  const [selectedMuscleGroup, setSelectedMuscleGroup] = useState<MuscleGroupId | null>(null);
  const [previewExercise, setPreviewExercise] = useState<Exercise | null>(null);
  const [showMuscleExplorer, setShowMuscleExplorer] = useState<boolean>(true);

  // Quick PR Log inside exercise modal
  const [prValueInput, setPrValueInput] = useState<string>('');
  const [prLogSuccess, setPrLogSuccess] = useState<boolean>(false);

  const categories: { label: string; value: string }[] = [
    { label: 'All', value: 'all' },
    { label: 'Calisthenics Skills', value: 'skills' },
    { label: 'Pull', value: 'pull' },
    { label: 'Push', value: 'push' },
    { label: 'Core', value: 'core' },
    { label: 'Legs', value: 'legs' },
    { label: 'Resistance Band', value: 'resistance band' },
    { label: 'Towel', value: 'towel' },
    { label: 'Backpack', value: 'backpack' }
  ];

  const difficulties: { label: string; value: string }[] = [
    { label: 'All Levels', value: 'all' },
    { label: 'Beginner', value: 'beginner' },
    { label: 'Intermediate', value: 'intermediate' },
    { label: 'Advanced', value: 'advanced' }
  ];

  const equipmentList: { label: string; value: string }[] = [
    { label: 'All Equipment', value: 'all' },
    { label: 'None (Bodyweight)', value: 'none' },
    { label: 'Resistance Band', value: 'resistance band' },
    { label: 'Towel', value: 'towel' },
    { label: 'Pull-up Bar', value: 'pull-up bar' },
    { label: 'Parallettes', value: 'parallettes' },
    { label: 'Dip Bars', value: 'dip bars' },
    { label: 'Backpack', value: 'backpack' }
  ];

  const activeChipMeta =
    MAJOR_MUSCLE_CHIPS.find((c) => c.id === selectedMuscleChip) || MAJOR_MUSCLE_CHIPS[0];

  const doesExerciseMatchMuscleChip = (ex: Exercise, chipId: MajorMuscleChipId): boolean => {
    if (chipId === 'all') return true;
    const chip = MAJOR_MUSCLE_CHIPS.find((c) => c.id === chipId);
    if (!chip) return true;
    const exGroups = ex.targetMuscles.flatMap((m) => mapMuscleStringToGroups(m));
    return chip.groups.some((g) => exGroups.includes(g));
  };

  const isCalisthenicsSkillExercise = (ex: Exercise): boolean => {
    const id = ex.id.toLowerCase();
    const n = ex.name.toLowerCase();
    return (
      id.includes('planche') ||
      id.includes('lever') ||
      id.includes('ninety-degree') ||
      id.includes('l-sit') ||
      id.includes('v-sit') ||
      id.includes('manna') ||
      id.includes('handstand') ||
      id.includes('human-flag') ||
      id.includes('dragon-flag') ||
      id.includes('muscle-up') ||
      id.includes('hefesto') ||
      id.includes('victorian') ||
      id.includes('iron-cross') ||
      id.includes('frog-stand') ||
      id.includes('crane-pose') ||
      id.includes('two-finger') ||
      n.includes('one-arm')
    );
  };

  const filteredExercises = exercises.filter((ex) => {
    const q = search.trim().toLowerCase();
    const matchesSearch =
      !q ||
      ex.name.toLowerCase().includes(q) ||
      ex.description.toLowerCase().includes(q) ||
      ex.equipment.toLowerCase().includes(q) ||
      ex.targetMuscles.some((m) => m.toLowerCase().includes(q));

    const matchesCategory =
      selectedCategory === 'all' ||
      ex.category === selectedCategory ||
      (selectedCategory === 'skills' && isCalisthenicsSkillExercise(ex)) ||
      (selectedCategory === 'resistance band' && ex.equipment === 'resistance band') ||
      (selectedCategory === 'towel' && ex.equipment === 'towel');

    const matchesDiff = selectedDifficulty === 'all' || ex.difficulty === selectedDifficulty;
    const matchesEquip = selectedEquipment === 'all' || ex.equipment === selectedEquipment;

    const matchesMuscleChip = doesExerciseMatchMuscleChip(ex, selectedMuscleChip);

    const matchesMuscleGroup =
      !selectedMuscleGroup ||
      selectedMuscleChip !== 'all' ||
      ex.targetMuscles.some((m) => mapMuscleStringToGroups(m).includes(selectedMuscleGroup));

    return (
      matchesSearch &&
      matchesCategory &&
      matchesDiff &&
      matchesEquip &&
      matchesMuscleChip &&
      matchesMuscleGroup
    );
  });

  const handleSelectMuscleChip = (chipId: MajorMuscleChipId) => {
    if (user.soundEnabled) playPopSound('bright');
    setSelectedMuscleChip(chipId);
    const chip = MAJOR_MUSCLE_CHIPS.find((c) => c.id === chipId);
    setSelectedMuscleGroup(chip?.primaryMapGroup || null);
  };

  const handleLogPRFromDetail = (exercise: Exercise) => {
    const val = parseFloat(prValueInput);
    if (!val || val <= 0) return;
    const unit = exercise.category === 'backpack' ? 'kg' : exercise.isHold ? 'seconds' : 'reps';
    addPersonalRecord(exercise.id, exercise.name, val, unit);
    setPrLogSuccess(true);
    setTimeout(() => {
      setPrLogSuccess(false);
      setPrValueInput('');
    }, 2500);
  };

  return (
    <div className="space-y-4 pb-28 pt-2">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">Exercise Library</h1>
          <p className="text-xs text-slate-400">
            Calisthenics, resistance bands, towel & home backpack exercises
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowMuscleExplorer((prev) => !prev)}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${
            showMuscleExplorer
              ? 'bg-cyan-500/15 border-cyan-500/40 text-cyan-300'
              : 'bg-neutral-900 border-neutral-800 text-slate-400 hover:text-white'
          }`}
        >
          {showMuscleExplorer ? 'Hide Muscle Map' : 'Show Muscle Map'}
        </button>
      </div>

      {/* Interactive Cyan & Dark Muscle Map Character Explorer */}
      {showMuscleExplorer && (
        <MuscleMapCharacter
          exercise={previewExercise || selectedExercise || filteredExercises[0] || null}
          selectedMuscleGroup={selectedMuscleGroup}
          onSelectMuscleGroup={(group) => setSelectedMuscleGroup(group)}
          interactive={true}
          size="md"
          title={
            previewExercise
              ? `Target Muscles: ${previewExercise.name}`
              : selectedMuscleGroup
              ? `Filtering by: ${MUSCLE_GROUP_LABELS[selectedMuscleGroup]}`
              : filteredExercises[0]
              ? `Target Muscles: ${filteredExercises[0].name}`
              : 'Interactive Muscle Anatomy Map'
          }
          subtitle="Tap any muscle on the character to filter exercises, or hover/tap an exercise below"
        />
      )}

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-cyan-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input
          type="text"
          placeholder="Search movements, target muscles, or gear (e.g. Chest, Pull-up, Halo, Squat)..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full text-xs bg-[#12151c] border border-neutral-800 hover:border-neutral-700 rounded-2xl pl-10 pr-9 py-3 text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/30 transition-all shadow-sm"
        />
        {search && (
          <button
            onClick={() => setSearch('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-0.5 rounded-lg"
            title="Clear search"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Muscle-Group Filter Chips (Chest, Back, Legs, Shoulders, Arms, Core / Abs, Glutes) */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between px-1">
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-cyan-400 flex items-center gap-1">
            <Filter className="w-3 h-3" />
            <span>Filter by Muscle Group</span>
          </span>
          {selectedMuscleChip !== 'all' && (
            <button
              type="button"
              onClick={() => handleSelectMuscleChip('all')}
              className="text-[10px] font-semibold text-slate-400 hover:text-cyan-400"
            >
              Reset muscle filter
            </button>
          )}
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {MAJOR_MUSCLE_CHIPS.map((chip) => {
            const isSelected = selectedMuscleChip === chip.id;
            const count = exercises.filter((ex) => doesExerciseMatchMuscleChip(ex, chip.id)).length;
            return (
              <button
                key={chip.id}
                type="button"
                onClick={() => handleSelectMuscleChip(chip.id)}
                className={`px-3 py-1.5 text-xs font-bold rounded-xl whitespace-nowrap transition-all flex items-center gap-1.5 active:scale-95 ${
                  isSelected
                    ? 'bg-cyan-500 text-neutral-950 shadow-md shadow-cyan-500/20 border border-cyan-400'
                    : 'bg-[#12151c] text-slate-300 hover:text-white border border-neutral-800 hover:border-cyan-500/40'
                }`}
              >
                <span>{chip.label}</span>
                <span
                  className={`px-1.5 py-0.2 rounded-md text-[10px] font-mono font-extrabold ${
                    isSelected
                      ? 'bg-neutral-950/20 text-neutral-950'
                      : 'bg-neutral-900 text-cyan-400'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Filter 2: Category & Style Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat.value}
            onClick={() => {
              if (user.soundEnabled) playPopSound('soft');
              setSelectedCategory(cat.value);
            }}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors ${
              selectedCategory === cat.value
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50'
                : 'bg-neutral-900 text-slate-400 hover:text-white border border-neutral-800/80'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Secondary Filter Row: Difficulty & Equipment */}
      <div className="flex items-center gap-2">
        <select
          value={selectedDifficulty}
          onChange={(e) => setSelectedDifficulty(e.target.value)}
          className="flex-1 bg-neutral-900 border border-neutral-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
        >
          {difficulties.map((d) => (
            <option key={d.value} value={d.value} className="bg-neutral-900 text-slate-200">
              {d.label}
            </option>
          ))}
        </select>

        <select
          value={selectedEquipment}
          onChange={(e) => setSelectedEquipment(e.target.value)}
          className="flex-1 bg-neutral-900 border border-neutral-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
        >
          {equipmentList.map((eq) => (
            <option key={eq.value} value={eq.value} className="bg-neutral-900 text-slate-200">
              {eq.label}
            </option>
          ))}
        </select>
      </div>

      {/* Backpack Safety Guidance Banner */}
      {selectedCategory === 'backpack' && (
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-neutral-900 to-cyan-950/20 border border-cyan-500/20 flex items-start gap-3">
          <ShieldAlert className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
          <div className="text-xs text-slate-300 leading-relaxed">
            <span className="font-semibold text-white">Backpack Training Safety:</span> Fill bag
            evenly with books or water bottles. Pull shoulder and chest straps tightly against the
            body to prevent load shifting. Start light (5–8 kg) and never compromise neutral spine alignment.
          </div>
        </div>
      )}

      {/* Resistance Band Training Tips Banner */}
      {(selectedCategory === 'resistance band' || selectedEquipment === 'resistance band') && (
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-neutral-900 to-cyan-950/20 border border-cyan-500/20 flex items-start gap-3">
          <Info className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
          <div className="text-xs text-slate-300 leading-relaxed">
            <span className="font-semibold text-white">Resistance Band Mastery:</span> Elastic bands deliver ascending resistance curve (greatest tension at peak contraction). Perfect for deloading advanced calisthenics skills (Planche, Front Lever, Muscle-Up) and bulletproofing rotator cuffs and scapulae.
          </div>
        </div>
      )}

      {/* Results Count */}
      <div className="flex items-center justify-between text-xs text-slate-400 px-1">
        <span>
          Showing <strong className="text-white">{filteredExercises.length}</strong> exercises
          {selectedMuscleChip !== 'all'
            ? ` targeting ${activeChipMeta.label}`
            : selectedMuscleGroup
            ? ` targeting ${MUSCLE_GROUP_LABELS[selectedMuscleGroup]}`
            : ''}
        </span>
        {(selectedMuscleChip !== 'all' ||
          selectedCategory !== 'all' ||
          selectedDifficulty !== 'all' ||
          selectedEquipment !== 'all' ||
          selectedMuscleGroup !== null ||
          search !== '') && (
          <button
            onClick={() => {
              setSelectedMuscleChip('all');
              setSelectedCategory('all');
              setSelectedDifficulty('all');
              setSelectedEquipment('all');
              setSelectedMuscleGroup(null);
              setSearch('');
            }}
            className="text-cyan-400 hover:underline font-semibold"
          >
            Clear filters
          </button>
        )}
      </div>

      {/* Exercises List */}
      <div className="space-y-2.5">
        {filteredExercises.map((exercise) => (
          <div
            key={exercise.id}
            onMouseEnter={() => setPreviewExercise(exercise)}
            onClick={() => setSelectedExercise(exercise)}
            className="p-3.5 rounded-2xl bg-[#12151c] border border-neutral-800 hover:border-cyan-500/40 transition-all cursor-pointer group active:scale-[0.99] flex items-center justify-between"
          >
            <div className="min-w-0 pr-3">
              <div className="flex items-center gap-2 text-[11px] text-slate-400 mb-1">
                <span className="text-cyan-400 font-semibold uppercase tracking-wider text-[10px]">
                  {exercise.category}
                </span>
                <span aria-hidden="true">·</span>
                <span className="capitalize text-slate-300">Equipment: {exercise.equipment}</span>
                <span aria-hidden="true">·</span>
                <span className="capitalize">{exercise.difficulty}</span>
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-cyan-400 transition-colors truncate">
                {exercise.name}
              </h3>
              <p className="text-xs text-slate-400 line-clamp-1 mt-0.5">
                {exercise.description}
              </p>
              <div className="text-[11px] text-cyan-400/90 mt-1 truncate">
                Targets: <span className="text-slate-300">{exercise.targetMuscles.join(' · ')}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {activeWorkout && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    addExerciseToActiveWorkout(exercise.id);
                    setIsWorkoutModalOpen(true);
                  }}
                  className="w-8 h-8 rounded-xl bg-neutral-900 group-hover:bg-cyan-500 group-hover:text-neutral-950 flex items-center justify-center text-slate-300 transition-colors"
                  title="Add to Current Active Workout"
                >
                  <Plus className="w-4 h-4" />
                </button>
              )}
              <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-cyan-400 group-hover:translate-x-0.5 transition-all" />
            </div>
          </div>
        ))}
      </div>

      {/* Exercise Detail Modal */}
      {selectedExercise && (
        <div className="fixed inset-0 z-60 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#12151c] border border-neutral-800 rounded-3xl p-6 max-w-md w-full max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in duration-200">
            {/* Modal Header */}
            <div className="flex items-start justify-between pb-3 border-b border-neutral-800">
              <div>
                <div className="flex items-center gap-2 text-[11px] text-slate-400 mb-1">
                  <span className="text-cyan-400 font-semibold uppercase">{selectedExercise.category}</span>
                  <span>·</span>
                  <span className="capitalize">{selectedExercise.difficulty}</span>
                  <span>·</span>
                  <span className="capitalize font-medium text-slate-300">Equipment: {selectedExercise.equipment}</span>
                </div>
                <h3 className="text-lg font-bold text-white">{selectedExercise.name}</h3>
              </div>
              <button
                onClick={() => setSelectedExercise(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-white bg-neutral-900"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="flex-1 overflow-y-auto py-4 space-y-4">
              <p className="text-xs text-slate-300 leading-relaxed">
                {selectedExercise.description}
              </p>

              {/* Safety note if backpack */}
              {selectedExercise.safetyNote && (
                <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-xs text-amber-300 flex items-start gap-2">
                  <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
                  <span>{selectedExercise.safetyNote}</span>
                </div>
              )}

              {/* Target Muscle Anatomy Character (Cyan & Dark Theme) */}
              <MuscleMapCharacter
                exercise={selectedExercise}
                size="md"
                title="Target Muscle Anatomy"
                subtitle="Highlighted in cyan: primary & secondary muscles activated"
              />

              {/* Target Muscles */}
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                  Muscles Worked
                </h4>
                <div className="text-xs text-slate-300 leading-relaxed">
                  {selectedExercise.targetMuscles.map((muscle, idx) => (
                    <React.Fragment key={idx}>
                      {idx > 0 && <span className="mx-1.5 text-slate-600">·</span>}
                      <span className={idx === 0 ? 'text-cyan-400 font-semibold' : 'text-slate-300'}>
                        {muscle}
                      </span>
                    </React.Fragment>
                  ))}
                </div>
              </div>

              {/* Step-by-Step Instructions */}
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                  Execution Instructions
                </h4>
                <ol className="space-y-2">
                  {selectedExercise.instructions.map((step, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-300">
                      <span className="w-5 h-5 rounded-full bg-neutral-900 border border-cyan-500/30 text-cyan-400 flex items-center justify-center text-[10px] font-mono shrink-0 font-bold">
                        {idx + 1}
                      </span>
                      <span className="leading-relaxed">{step}</span>
                    </li>
                  ))}
                </ol>
              </div>

              {/* Quick Record Logger */}
              <div className="p-3.5 bg-neutral-900/80 border border-neutral-800 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Trophy className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Log Personal Record</span>
                  </span>
                  <span className="text-[10px] text-slate-400">
                    {selectedExercise.isHold
                      ? 'Duration (seconds)'
                      : selectedExercise.category === 'backpack'
                      ? 'Weight (kg)'
                      : 'Max Reps'}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="1"
                    placeholder={selectedExercise.isHold ? 'e.g. 25 seconds' : 'e.g. 15 reps'}
                    value={prValueInput}
                    onChange={(e) => setPrValueInput(e.target.value)}
                    className="flex-1 bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-mono"
                  />
                  <button
                    onClick={() => handleLogPRFromDetail(selectedExercise)}
                    disabled={!prValueInput}
                    className="px-3 py-2 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-neutral-950 font-bold text-xs rounded-xl transition-all"
                  >
                    Save PR
                  </button>
                </div>

                {prLogSuccess && (
                  <div className="text-[11px] text-cyan-400 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Personal Record saved successfully!</span>
                  </div>
                )}
              </div>
            </div>

            {/* Modal Footer Actions */}
            <div className="pt-3 border-t border-neutral-800 flex gap-2">
              {activeWorkout ? (
                <button
                  onClick={() => {
                    addExerciseToActiveWorkout(selectedExercise.id);
                    setSelectedExercise(null);
                    setIsWorkoutModalOpen(true);
                  }}
                  className="flex-1 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-bold text-xs rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add to Active Workout</span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    startWorkout(undefined, `Solo: ${selectedExercise.name}`);
                    setSelectedExercise(null);
                  }}
                  className="flex-1 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-bold text-xs rounded-xl shadow-md transition-all active:scale-95 flex items-center justify-center gap-1.5"
                >
                  <Play className="w-3.5 h-3.5 fill-neutral-950" />
                  <span>Start Tracking Exercise</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
