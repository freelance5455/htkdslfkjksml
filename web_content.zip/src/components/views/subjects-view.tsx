import { useMemo, useState } from "react";
import { ChevronLeft, Trash2 } from "lucide-react";
import { Button, fieldClass, IconButton, Meter, Monogram, useCopy } from "@/components/bits";
import { subjectName, taskProgress } from "@/lib/model";
import { useStudy } from "@/lib/store";

export function SubjectsView() {
  const { lang, t } = useCopy();
  const subjects = useStudy((s) => s.subjects);
  const tasks = useStudy((s) => s.tasks);
  const [openId, setOpenId] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const [nameHi, setNameHi] = useState("");
  const [nameEn, setNameEn] = useState("");
  const addSubject = useStudy((s) => s.addSubject);

  const open = subjects.find((sub) => sub.id === openId);
  if (open) return <SubjectDetail id={open.id} onBack={() => setOpenId(null)} />;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-3xl font-semibold">{t("subjects")}</h1>
        {!adding ? <Button onClick={() => setAdding(true)}>{t("addSubject")}</Button> : null}
      </div>

      {adding ? (
        <form
          className="flex flex-col gap-3 rounded-lg border border-border bg-surface p-4"
          onSubmit={(event) => {
            event.preventDefault();
            addSubject(nameHi, nameEn);
            setNameHi("");
            setNameEn("");
            setAdding(false);
          }}
        >
          <label className="flex flex-col gap-1 text-sm text-muted">
            {t("subjectHi")}
            <input className={fieldClass} value={nameHi} onChange={(e) => setNameHi(e.target.value)} required />
          </label>
          <label className="flex flex-col gap-1 text-sm text-muted">
            {t("subjectEn")}
            <input className={fieldClass} value={nameEn} onChange={(e) => setNameEn(e.target.value)} />
          </label>
          <div className="flex gap-2">
            <Button type="submit">{t("save")}</Button>
            <Button variant="surface" onClick={() => setAdding(false)}>
              {t("cancel")}
            </Button>
          </div>
        </form>
      ) : null}

      {subjects.length === 0 ? (
        <p className="rounded-lg border border-border bg-surface px-4 py-8 text-center text-sm text-muted">
          {t("noSubjects")}
        </p>
      ) : (
        <ul className="flex flex-col gap-3">
          {subjects.map((sub) => {
            const prog = taskProgress(tasks, sub.id);
            const label = subjectName(sub, lang);
            return (
              <li key={sub.id}>
                <button
                  type="button"
                  className="flex w-full items-center gap-3 rounded-lg border border-border bg-surface p-3 text-left"
                  onClick={() => setOpenId(sub.id)}
                >
                  <Monogram name={label} mark={sub.mark} />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate font-semibold">{label}</span>
                    <span className="mt-1 block text-xs text-muted tabular-nums">
                      {prog.done}/{prog.total} · {prog.pct}%
                    </span>
                    <span className="mt-2 block">
                      <Meter pct={prog.pct} />
                    </span>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function SubjectDetail({ id, onBack }: { id: string; onBack: () => void }) {
  const { lang, t } = useCopy();
  const subject = useStudy((s) => s.subjects.find((item) => item.id === id));
  const allTasks = useStudy((s) => s.tasks);
  const tasks = useMemo(() => allTasks.filter((task) => task.subjectId === id), [allTasks, id]);
  const toggleTask = useStudy((s) => s.toggleTask);
  const addTask = useStudy((s) => s.addTask);
  const removeTask = useStudy((s) => s.removeTask);
  const removeSubject = useStudy((s) => s.removeSubject);
  const renameSubject = useStudy((s) => s.renameSubject);
  const [title, setTitle] = useState("");
  const [confirm, setConfirm] = useState(false);
  const [renaming, setRenaming] = useState(false);
  const [nameHi, setNameHi] = useState(subject?.nameHi ?? "");
  const [nameEn, setNameEn] = useState(subject?.nameEn ?? "");

  if (!subject) return null;
  const prog = taskProgress(tasks);
  const label = subjectName(subject, lang);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-2">
        <IconButton aria-label={t("back")} onClick={onBack}>
          <ChevronLeft className="size-5" />
        </IconButton>
        <h1 className="min-w-0 flex-1 truncate text-2xl font-semibold">{label}</h1>
      </div>

      <div className="rounded-lg border border-border bg-surface p-4">
        <div className="flex items-center justify-between gap-3">
          <p className="text-sm text-muted">{t("tasks")}</p>
          <p className="text-sm font-semibold tabular-nums">
            {prog.done}/{prog.total}
          </p>
        </div>
        <div className="mt-3">
          <Meter pct={prog.pct} />
        </div>
      </div>

      {renaming ? (
        <form
          className="flex flex-col gap-3 rounded-lg border border-border bg-surface p-4"
          onSubmit={(event) => {
            event.preventDefault();
            renameSubject(id, nameHi, nameEn);
            setRenaming(false);
          }}
        >
          <input className={fieldClass} value={nameHi} onChange={(e) => setNameHi(e.target.value)} />
          <input className={fieldClass} value={nameEn} onChange={(e) => setNameEn(e.target.value)} />
          <div className="flex gap-2">
            <Button type="submit">{t("save")}</Button>
            <Button variant="surface" onClick={() => setRenaming(false)}>
              {t("cancel")}
            </Button>
          </div>
        </form>
      ) : (
        <Button variant="surface" onClick={() => setRenaming(true)}>
          {t("rename")}
        </Button>
      )}

      {tasks.length === 0 ? <p className="text-sm text-muted">{t("noTasks")}</p> : null}
      <ul className="overflow-hidden rounded-lg border border-border bg-surface">
        {tasks.map((task) => (
          <li key={task.id} className="flex items-center gap-1 border-b border-border last:border-b-0">
            <label className="flex min-h-12 min-w-0 flex-1 items-center gap-3 px-3 py-2">
              <input
                type="checkbox"
                className="size-5 accent-primary"
                checked={task.done}
                onChange={() => toggleTask(task.id)}
              />
              <span className={task.done ? "truncate text-muted line-through" : "truncate"}>{task.title}</span>
            </label>
            <IconButton aria-label={t("delete")} onClick={() => removeTask(task.id)}>
              <Trash2 className="size-4 text-muted" />
            </IconButton>
          </li>
        ))}
      </ul>

      <form
        className="flex gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          addTask(id, title);
          setTitle("");
        }}
      >
        <input
          className={fieldClass}
          value={title}
          placeholder={t("taskPlaceholder")}
          onChange={(e) => setTitle(e.target.value)}
        />
        <Button type="submit">{t("addTask")}</Button>
      </form>

      {confirm ? (
        <div className="flex flex-wrap items-center gap-2">
          <p className="text-sm">{t("confirmDelete")}</p>
          <Button
            variant="accent"
            onClick={() => {
              removeSubject(id);
              onBack();
            }}
          >
            {t("yes")}
          </Button>
          <Button variant="surface" onClick={() => setConfirm(false)}>
            {t("cancel")}
          </Button>
        </div>
      ) : (
        <Button variant="ghost" onClick={() => setConfirm(true)}>
          {t("delete")}
        </Button>
      )}
    </div>
  );
}
