import React, { useState } from 'react';
import { 
  FileCode, Download, Copy, Check, Search, FolderTree, FileText, Layers,
  ChevronRight, Filter, ExternalLink, Smartphone, Terminal
} from 'lucide-react';
import JSZip from 'jszip';
import { ANDROID_PROJECT_FILES, AndroidFile } from '../data/androidProjectFiles';

export const AndroidProjectExplorer: React.FC = () => {
  const [selectedFilePath, setSelectedFilePath] = useState<string>('app/src/main/java/com/universal/remote/core/ir/IrEncoder.kt');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);

  const currentFile = ANDROID_PROJECT_FILES.find((f) => f.path === selectedFilePath) || ANDROID_PROJECT_FILES[0];

  const filteredFiles = ANDROID_PROJECT_FILES.filter((file) => {
    const matchesSearch = file.path.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          file.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          file.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || file.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleCopy = () => {
    navigator.clipboard.writeText(currentFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();

      // Add each project file into the zip
      ANDROID_PROJECT_FILES.forEach((f) => {
        zip.file(f.path, f.content);
      });

      // Add README.md
      zip.file(
        'README.md',
        `# Universal Remote Pro
تطبيق أندرويد متكامل للتحكم بالشاشات الذكية وأجهزة الاستقبال (Sunplus Receivers)
تقنيات: IR + Wi-Fi + Bluetooth HID
معمارية: Clean Architecture + MVVM + Hilt + Room + Jetpack Compose

## خطوات التشغيل:
1. افتح المجلد في Android Studio (Ladybug / Koala أو الأحدث).
2. تأكد من ضبط JDK 17 أو 21.
3. قم بتنفيذ:
   ./gradlew assembleDebug
4. ثبت الـ APK على هاتف يحتوي على IR Blaster أو يدعم Bluetooth HID.
`
      );

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'UniversalRemotePro-Android-Project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error(e);
      alert('حدث خطأ أثناء ضغط ملفات المشروع');
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Top action bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-cyan-500/10 text-cyan-400 rounded-xl">
            <FolderTree className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-white text-base">مستكشف كود مشروع أندرويد (Android Studio Project Tree)</h3>
            <p className="text-xs text-slate-400">
              ملفات Kotlin كاملة بدون اختصارات، جاهزة للاستيراد المباشر في أندرويد ستوديو
            </p>
          </div>
        </div>

        <button
          onClick={handleDownloadZip}
          disabled={isZipping}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold rounded-xl text-xs transition-all shadow-md active:scale-95 disabled:opacity-50"
        >
          <Download className="w-4 h-4" />
          <span>{isZipping ? 'جاري تجهيز الأرشيف...' : 'تحميل المشروع كاملاً (.ZIP)'}</span>
        </button>
      </div>

      {/* Main split view */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left column: File tree list (4 cols) */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-3 flex flex-col h-[650px]">
          {/* Search */}
          <div className="relative mb-2">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="بحث في أسماء الملفات أو المسارات..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-xs text-white placeholder-slate-500 focus:border-cyan-500 outline-none"
            />
          </div>

          {/* Category filter pills */}
          <div className="flex gap-1 overflow-x-auto pb-2 mb-2 scrollbar-none text-[11px]">
            {[
              { id: 'all', label: 'الكل' },
              { id: 'ir', label: 'IR و Sunplus' },
              { id: 'wifi', label: 'مشغلات Wi-Fi' },
              { id: 'bluetooth', label: 'بلوتوث HID' },
              { id: 'ui', label: 'واجهات Compose' },
              { id: 'data', label: 'قاعدة Room' },
              { id: 'config', label: 'Gradle و Manifest' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-2.5 py-1 rounded-lg whitespace-nowrap transition-colors ${
                  selectedCategory === cat.id
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'bg-slate-950 text-slate-400 hover:text-white'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Files List */}
          <div className="flex-1 overflow-y-auto space-y-1 pr-1">
            {filteredFiles.map((file) => {
              const isSelected = file.path === selectedFilePath;
              return (
                <div
                  key={file.path}
                  onClick={() => setSelectedFilePath(file.path)}
                  className={`p-2.5 rounded-xl cursor-pointer transition-all border text-right ${
                    isSelected
                      ? 'bg-cyan-500/10 border-cyan-500/60 text-white'
                      : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <FileCode className={`w-3.5 h-3.5 ${isSelected ? 'text-cyan-400' : 'text-slate-400'}`} />
                    <span className="font-semibold text-xs truncate flex-1">{file.title}</span>
                  </div>
                  <div className="text-[10px] font-mono text-slate-500 truncate ltr text-left pl-5">
                    {file.path}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right column: Code Viewer (8 cols) */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl flex flex-col h-[650px] overflow-hidden">
          {/* Header of code viewer */}
          <div className="p-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-slate-800 text-cyan-400 font-bold">
                {currentFile.path.endsWith('.kt') ? 'Kotlin' : currentFile.path.endsWith('.xml') ? 'XML' : 'Gradle'}
              </span>
              <span className="text-xs font-mono text-slate-300 truncate font-semibold">
                {currentFile.path}
              </span>
            </div>

            <button
              onClick={handleCopy}
              className="flex items-center gap-1 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs rounded-lg transition-colors border border-slate-700"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'تم النسخ!' : 'نسخ الكود'}</span>
            </button>
          </div>

          {/* Description bar */}
          <div className="px-4 py-2 bg-slate-900 border-b border-slate-800/60 text-xs text-slate-400">
            {currentFile.description}
          </div>

          {/* Code Body */}
          <div className="flex-1 overflow-auto p-4 bg-slate-950 font-mono text-xs text-slate-200 leading-relaxed ltr text-left">
            <pre className="whitespace-pre">
              {currentFile.content}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
