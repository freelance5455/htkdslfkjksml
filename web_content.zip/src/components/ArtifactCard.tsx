import React, { useState } from 'react';
import {
  Code,
  Copy,
  Check,
  Download,
  ExternalLink,
  Eye,
  FileSpreadsheet,
  FileText,
  Globe,
  Image as ImageIcon,
  Layers,
  Maximize2,
  Video,
  X,
} from 'lucide-react';

export type ArtifactType =
  | 'website'
  | 'application'
  | 'document'
  | 'code'
  | 'image'
  | 'video'
  | 'data'
  | 'research';

export interface ArtifactData {
  id: string;
  type: ArtifactType;
  title: string;
  language?: string;
  content: string;
  downloadUrl?: string;
  previewUrl?: string;
  summary?: string;
  metadata?: Record<string, unknown>;
}

interface ArtifactCardProps {
  artifact: ArtifactData;
}

export const ArtifactCard: React.FC<ArtifactCardProps> = ({ artifact }) => {
  const [copied, setCopied] = useState(false);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(artifact.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    if (artifact.downloadUrl) {
      const a = document.createElement('a');
      a.href = artifact.downloadUrl;
      a.download = artifact.title;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      return;
    }

    const mime =
      artifact.type === 'website'
        ? 'text/html'
        : artifact.type === 'data'
        ? 'application/json'
        : artifact.type === 'document'
        ? 'text/markdown'
        : 'text/plain';

    const blob = new Blob([artifact.content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = artifact.title;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getIcon = () => {
    switch (artifact.type) {
      case 'website':
        return <Globe className="w-4 h-4 text-sky-600" />;
      case 'application':
        return <Layers className="w-4 h-4 text-purple-600" />;
      case 'document':
        return <FileText className="w-4 h-4 text-blue-600" />;
      case 'image':
        return <ImageIcon className="w-4 h-4 text-pink-600" />;
      case 'video':
        return <Video className="w-4 h-4 text-amber-600" />;
      case 'data':
        return <FileSpreadsheet className="w-4 h-4 text-emerald-600" />;
      default:
        return <Code className="w-4 h-4 text-indigo-600" />;
    }
  };

  const getBadgeClass = () => {
    switch (artifact.type) {
      case 'website':
        return 'bg-sky-50 text-sky-700 border-sky-200';
      case 'application':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'document':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'image':
        return 'bg-pink-50 text-pink-700 border-pink-200';
      case 'video':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'data':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      default:
        return 'bg-indigo-50 text-indigo-700 border-indigo-200';
    }
  };

  const canPreview =
    artifact.type === 'website' ||
    artifact.language === 'html' ||
    artifact.language === 'json' ||
    artifact.language === 'markdown' ||
    artifact.language === 'md';

  return (
    <div
      id={`artifact-card-${artifact.id}`}
      className="my-2.5 rounded-xl border border-slate-200 bg-slate-50/70 overflow-hidden shadow-2xs hover:border-slate-300 transition-all font-sans text-xs"
    >
      {/* Header */}
      <div className="px-3.5 py-2.5 bg-white border-b border-slate-200/80 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <div className="p-1.5 rounded-lg bg-slate-100 border border-slate-200 shrink-0">
            {getIcon()}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-slate-900 truncate text-[12px]">
                {artifact.title}
              </span>
              <span
                className={`text-[9px] font-mono px-1.5 py-0.2 rounded border font-semibold uppercase ${getBadgeClass()}`}
              >
                {artifact.type}
              </span>
              {artifact.language && (
                <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 border border-slate-200">
                  {artifact.language}
                </span>
              )}
            </div>
            {artifact.summary && (
              <p className="text-[10px] text-slate-500 truncate mt-0.5">
                {artifact.summary}
              </p>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1 shrink-0">
          {canPreview && (
            <button
              type="button"
              onClick={() => setIsPreviewOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-700 border border-sky-200 font-semibold transition-colors cursor-pointer"
              title="Live interactive preview"
            >
              <Eye className="w-3 h-3" />
              <span>Preview</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleCopy}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 font-medium transition-colors cursor-pointer"
            title="Copy content to clipboard"
          >
            {copied ? (
              <>
                <Check className="w-3 h-3 text-emerald-600" />
                <span className="text-emerald-700">Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3 h-3" />
                <span>Copy</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={handleDownload}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 font-medium transition-colors cursor-pointer"
            title="Download file"
          >
            <Download className="w-3 h-3" />
            <span>Download</span>
          </button>
        </div>
      </div>

      {/* Code / Content Snippet or Project Files Overview */}
      {artifact.previewUrl ? (
        <div className="p-3 bg-slate-900 text-slate-100 font-mono text-[11px] flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs text-sky-400 font-bold">
            <span>📦 Multi-File Production Project</span>
            <a
              href={artifact.previewUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-sky-300 hover:text-white hover:underline transition-colors"
            >
              <ExternalLink className="w-3 h-3" />
              <span>Open in New Tab</span>
            </a>
          </div>
          <div className="text-slate-300 text-[10px] space-y-0.5 font-mono">
            <div>✓ <code>package.json</code> (Vite &amp; Tailwind build scripts)</div>
            <div>✓ <code>index.html</code> (Semantic Light WOW UI, Hero, Menu, Reviews &amp; Modals)</div>
            <div>✓ <code>src/main.js</code> (Interactive Cart, Drawer Animation &amp; Form Validation)</div>
            <div>✓ <code>src/styles/main.css</code> (Responsive styling &amp; design tokens)</div>
            <div>✓ <code>src/data/menu.json</code> (Item catalog &amp; pricing)</div>
            <div>✓ <code>public/manifest.json</code> (PWA Web App Manifest)</div>
          </div>
        </div>
      ) : (
        <div className="p-3 bg-slate-900 text-slate-100 font-mono text-[11px] overflow-x-auto max-h-48 leading-relaxed selection:bg-sky-700">
          <pre>{artifact.content.slice(0, 1500)}</pre>
          {artifact.content.length > 1500 && (
            <div className="text-[10px] text-slate-400 mt-1 italic">
              ... truncated ({artifact.content.length} characters total). Click Preview or Download to see full content.
            </div>
          )}
        </div>
      )}

      {/* Interactive Modal Preview */}
      {isPreviewOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-300 shadow-2xl w-full max-w-4xl h-[85vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded bg-white border border-slate-200">
                  {getIcon()}
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900 leading-tight">
                    {artifact.title}
                  </h3>
                  <span className="text-[10px] font-mono text-slate-500 uppercase">
                    Interactive Live Preview ({artifact.type})
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleDownload}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 text-xs font-semibold"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsPreviewOpen(false)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-hidden bg-slate-100 p-2">
              {artifact.type === 'website' || artifact.language === 'html' ? (
                <iframe
                  title={artifact.title}
                  src={artifact.previewUrl}
                  srcDoc={artifact.previewUrl ? undefined : artifact.content}
                  className="w-full h-full bg-white rounded-xl border border-slate-300 shadow-inner"
                  sandbox="allow-scripts allow-modals allow-same-origin"
                />
              ) : (
                <div className="w-full h-full bg-slate-900 text-slate-100 p-4 rounded-xl overflow-auto font-mono text-xs leading-relaxed">
                  <pre>{artifact.content}</pre>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
