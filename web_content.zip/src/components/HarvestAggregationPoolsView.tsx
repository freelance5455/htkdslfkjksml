import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Ship,
  TrendingUp,
  Award,
  CheckCircle2,
  Calendar,
  MapPin,
  FileText,
  Clock,
  Printer,
  ChevronRight,
  ShieldCheck,
  QrCode,
  DollarSign,
  Layers,
  Sparkles,
  ArrowRight,
  Check,
  Plus,
  Boxes,
  Users,
  Building2,
  Scale,
  Truck,
  Download,
  AlertCircle,
} from 'lucide-react';
import { Language, UserProfile, AggregationPool, HarvestPledge } from '../types';
import { INITIAL_AGGREGATION_POOLS, SAMPLE_HARVEST_PLEDGES } from '../data/mockData';
import { playKeyTap, playSuccessChime } from '../utils/audio';

interface HarvestAggregationPoolsViewProps {
  language: Language;
  user: UserProfile;
  onNavigateToWallet?: () => void;
  onNavigateToBuyers?: () => void;
}

export default function HarvestAggregationPoolsView({
  language,
  user,
  onNavigateToWallet,
  onNavigateToBuyers,
}: HarvestAggregationPoolsViewProps) {
  const isSw = language === 'sw';

  // Sub-tabs: 'pools' | 'my_pledges' | 'how_it_works'
  const [activeTab, setActiveTab] = useState<'pools' | 'my_pledges' | 'how_it_works'>('pools');

  // Pools state
  const [pools, setPools] = useState<AggregationPool[]>(INITIAL_AGGREGATION_POOLS);
  const [pledges, setPledges] = useState<HarvestPledge[]>(SAMPLE_HARVEST_PLEDGES);

  // Selected pool for pledging or detail viewing
  const [selectedPool, setSelectedPool] = useState<AggregationPool | null>(pools[0]);
  const [pledgeKg, setPledgeKg] = useState<number>(1500);
  const [isPledgeModalOpen, setIsPledgeModalOpen] = useState<boolean>(false);
  const [activeReceiptPledge, setActiveReceiptPledge] = useState<HarvestPledge | null>(null);

  // Filter state
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Calculate live numbers for selected pool & pledge
  const activePool = selectedPool || pools[0];
  const totalPayout = pledgeKg * activePool.exportPriceTshKg;
  const advancePayout = Math.round(totalPayout * (activePool.advancePaymentPercentage / 100));
  const finalBalance = totalPayout - advancePayout;
  const localBrokerTotal = pledgeKg * activePool.localBrokerPriceTshKg;
  const extraFarmerGain = totalPayout - localBrokerTotal;
  const gainPercentage = Math.round(((activePool.exportPriceTshKg - activePool.localBrokerPriceTshKg) / activePool.localBrokerPriceTshKg) * 100);

  // Submit new harvest pledge
  const handleConfirmPledge = () => {
    if (pledgeKg <= 0) return;
    playSuccessChime();

    const receiptNum = `WRS-TZ-${activePool.amcosCoopName.slice(0, 3).toUpperCase()}-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const newPledge: HarvestPledge = {
      id: `pledge-${Date.now()}`,
      poolId: activePool.id,
      farmerName: user.name,
      farmerPhone: user.phone,
      quantityKg: pledgeKg,
      totalPayoutTsh: totalPayout,
      advancePayoutTsh: advancePayout,
      finalBalanceTsh: finalBalance,
      warehouseReceiptNumber: receiptNum,
      pledgeDate: 'Leo, Septemba 2026',
      status: 'confirmed',
    };

    // Update pool pledged quantity
    setPools((prev) =>
      prev.map((p) =>
        p.id === activePool.id
          ? { ...p, currentPledgedKg: Math.min(p.targetQuantityKg, p.currentPledgedKg + pledgeKg) }
          : p
      )
    );

    setPledges((prev) => [newPledge, ...prev]);
    setIsPledgeModalOpen(false);
    setActiveReceiptPledge(newPledge);
  };

  const filteredPools = pools.filter((p) => {
    if (statusFilter === 'all') return true;
    return p.status === statusFilter;
  });

  return (
    <div id="aggregation-pools-view" className="space-y-4 pb-12">
      {/* 1. Top Feature Hero Card */}
      <div className="rounded-3xl p-5 bg-gradient-to-br from-indigo-900 via-blue-900 to-emerald-900 text-[#F7F4E9] shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-full bg-blue-400/20 text-blue-200 text-[10px] font-bold uppercase tracking-wider border border-blue-400/30 flex items-center gap-1">
                <Ship className="w-3 h-3 text-amber-300" />
                <span>{isSw ? 'Uuzaji wa Pamoja (AMCOS Pools)' : 'Cooperative Export Pools'}</span>
              </span>
              <span className="text-[10px] bg-emerald-400/20 text-emerald-300 px-2 py-0.5 rounded-full font-bold">
                {isSw ? '+35% hadi +75% Faida Zaidi' : '+35% to +75% Middleman Premium'}
              </span>
            </div>
            <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white">
              {isSw ? 'Uuzaji wa Mazao kwa Makontena ya Nje' : 'Direct Collective Export Shipping Pools'}
            </h1>
            <p className="text-xs sm:text-sm text-blue-100/90 max-w-xl mt-1 leading-relaxed">
              {isSw
                ? 'Ungana na wakulima wenzako kupitia vyama vya ushirika (AMCOS) kujaza makontena ya futi 20 na 40 (FCL) na kuuza moja kwa moja kwa wanunuzi wa kimataifa bila madalali.'
                : 'Pool your crop harvest with fellow smallholders via verified AMCOS cooperatives to fill 20ft & 40ft export containers directly to global buyers at peak port prices.'}
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <div className="bg-black/25 backdrop-blur-md rounded-2xl p-3 border border-white/10 text-center min-w-[95px]">
              <div className="font-mono text-lg font-bold text-amber-300">
                {pools.length}
              </div>
              <div className="text-[10px] text-white/80">{isSw ? 'Makontena Wazi' : 'Active Pools'}</div>
            </div>
            <div className="bg-black/25 backdrop-blur-md rounded-2xl p-3 border border-white/10 text-center min-w-[95px]">
              <div className="font-mono text-lg font-bold text-emerald-300">
                70%
              </div>
              <div className="text-[10px] text-white/80">{isSw ? 'Malipo ya Awali' : 'Instant Advance'}</div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Sub-Tabs Bar */}
      <div className="flex p-1 bg-[var(--bg)] rounded-2xl border border-[var(--line)] gap-1 shadow-xs overflow-x-auto">
        <button
          onClick={() => {
            playKeyTap();
            setActiveTab('pools');
          }}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeTab === 'pools'
              ? 'bg-[var(--paper)] text-[var(--forest)] shadow-xs border border-[var(--line)]'
              : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
          }`}
        >
          <Ship className="w-4 h-4 text-blue-600 flex-shrink-0" />
          <span>{isSw ? 'Makontena Yanayokusanya' : 'Active Export Pools'}</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-blue-500/15 text-blue-700 font-mono">
            {pools.length}
          </span>
        </button>

        <button
          onClick={() => {
            playKeyTap();
            setActiveTab('my_pledges');
          }}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeTab === 'my_pledges'
              ? 'bg-[var(--paper)] text-[var(--forest)] shadow-xs border border-[var(--line)]'
              : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
          }`}
        >
          <FileText className="w-4 h-4 text-emerald-600 flex-shrink-0" />
          <span>{isSw ? 'Ahadi Zangu & Stakabadhi' : 'My Pledges & WRS'}</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-emerald-500/15 text-emerald-700 font-mono">
            {pledges.length}
          </span>
        </button>

        <button
          onClick={() => {
            playKeyTap();
            setActiveTab('how_it_works');
          }}
          className={`flex-1 min-w-[110px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeTab === 'how_it_works'
              ? 'bg-[var(--paper)] text-[var(--forest)] shadow-xs border border-[var(--line)]'
              : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-500 flex-shrink-0" />
          <span>{isSw ? 'Faida ya AMCOS' : 'The AMCOS Edge'}</span>
        </button>
      </div>

      {/* SUB-TAB 1: ACTIVE EXPORT POOLS */}
      {activeTab === 'pools' && (
        <div className="space-y-4">
          {/* Quick Filter Bar */}
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="text-xs font-bold text-[var(--ink)]">
              {isSw ? 'Chagua Kontena la Mazao Yako:' : 'Select an Export Container:'}
            </div>
            <div className="flex items-center gap-1.5">
              {[
                { id: 'all', sw: 'Zote', en: 'All' },
                { id: 'filling_fast', sw: 'Zinazojaa Haraka 🔥', en: 'Filling Fast 🔥' },
                { id: 'open', sw: 'Wazi', en: 'Open' },
              ].map((btn) => (
                <button
                  key={btn.id}
                  onClick={() => {
                    playKeyTap();
                    setStatusFilter(btn.id);
                  }}
                  className={`py-1.5 px-2.5 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                    statusFilter === btn.id
                      ? 'bg-[var(--forest)] text-white shadow-xs'
                      : 'bg-[var(--paper)] border border-[var(--line)] text-[var(--ink-soft)] hover:text-[var(--ink)]'
                  }`}
                >
                  {isSw ? btn.sw : btn.en}
                </button>
              ))}
            </div>
          </div>

          {/* Grid of Aggregation Pools */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredPools.map((pool) => {
              const fillPercentage = Math.round((pool.currentPledgedKg / pool.targetQuantityKg) * 100);
              const remainingKg = Math.max(0, pool.targetQuantityKg - pool.currentPledgedKg);
              const extraPerKg = pool.exportPriceTshKg - pool.localBrokerPriceTshKg;

              return (
                <div
                  key={pool.id}
                  className="rounded-3xl p-5 bg-[var(--paper)] border border-[var(--line)] hover:border-blue-500/50 shadow-sm transition-all flex flex-col justify-between group"
                >
                  <div>
                    {/* Header: Destination & Status */}
                    <div className="flex items-start justify-between gap-2 mb-3">
                      <div className="flex items-center gap-2">
                        <span className="text-3xl">{pool.icon}</span>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-base">{pool.exportBuyer.flag}</span>
                            <span className="text-xs font-bold text-blue-700 dark:text-blue-300">
                              {pool.exportBuyer.country} ({pool.containerType})
                            </span>
                          </div>
                          <h3 className="font-display font-bold text-sm sm:text-base text-[var(--ink)] leading-snug">
                            {isSw ? pool.titleSw : pool.titleEn}
                          </h3>
                        </div>
                      </div>

                      <span
                        className={`text-[9px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                          pool.status === 'filling_fast'
                            ? 'bg-amber-500/20 text-amber-800 dark:text-amber-300 border border-amber-500/30'
                            : 'bg-emerald-500/20 text-emerald-800 dark:text-emerald-300 border border-emerald-500/30'
                        }`}
                      >
                        {pool.status === 'filling_fast' ? (isSw ? 'Inajaa Haraka' : 'Filling Fast') : (isSw ? 'Wazi' : 'Open')}
                      </span>
                    </div>

                    {/* AMCOS and Trade Corridor Info */}
                    <div className="p-3 rounded-2xl bg-[var(--bg)] border border-[var(--line)] space-y-1.5 text-xs mb-3">
                      <div className="flex items-center justify-between">
                        <span className="text-[var(--ink-soft)] flex items-center gap-1">
                          <Building2 className="w-3.5 h-3.5 text-blue-600" />
                          <span>{isSw ? 'Ushirika (AMCOS):' : 'Cooperative Union:'}</span>
                        </span>
                        <span className="font-bold text-[var(--ink)] truncate max-w-[170px] text-right">
                          {pool.amcosCoopName}
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-[var(--ink-soft)] flex items-center gap-1">
                          <Truck className="w-3.5 h-3.5 text-emerald-600" />
                          <span>{isSw ? 'Njia ya Usafirishaji:' : 'Corridor Line:'}</span>
                        </span>
                        <span className="font-semibold text-emerald-700 dark:text-emerald-300 text-right truncate max-w-[170px]">
                          {pool.exportBuyer.corridor}
                        </span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-[var(--ink-soft)] flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-amber-600" />
                          <span>{isSw ? 'Kituo cha Kushusha:' : 'Depot:'}</span>
                        </span>
                        <span className="font-medium text-[var(--ink)] text-right truncate max-w-[170px]">
                          {isSw ? pool.dropoffDepotSw : pool.dropoffDepotEn}
                        </span>
                      </div>
                    </div>

                    {/* Comparison Pill: Export Price vs Local Broker */}
                    <div className="grid grid-cols-2 gap-2 mb-3">
                      <div className="p-2.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/25">
                        <div className="text-[10px] text-emerald-800 dark:text-emerald-300 uppercase font-bold">
                          {isSw ? 'Bei ya Nje (AMCOS Pool)' : 'FOB Export Price'}
                        </div>
                        <div className="font-mono text-base font-bold text-emerald-700 dark:text-emerald-300">
                          Tsh {pool.exportPriceTshKg.toLocaleString()}
                          <span className="text-xs font-normal"> /kg</span>
                        </div>
                        <div className="text-[10px] text-emerald-800 dark:text-emerald-300 font-bold">
                          +{Math.round((extraPerKg / pool.localBrokerPriceTshKg) * 100)}% {isSw ? 'Faida Zaidi' : 'Higher Gain'}
                        </div>
                      </div>

                      <div className="p-2.5 rounded-2xl bg-red-500/10 border border-red-500/20">
                        <div className="text-[10px] text-red-800 dark:text-red-300 uppercase font-bold">
                          {isSw ? 'Bei ya Dalali Mtaani' : 'Middleman Spot Price'}
                        </div>
                        <div className="font-mono text-base font-bold text-red-700 dark:text-red-300">
                          Tsh {pool.localBrokerPriceTshKg.toLocaleString()}
                          <span className="text-xs font-normal"> /kg</span>
                        </div>
                        <div className="text-[10px] text-red-800 dark:text-red-300">
                          {isSw ? 'Unapoteza ' : 'You lose '}Tsh {extraPerKg.toLocaleString()}/kg
                        </div>
                      </div>
                    </div>

                    {/* Progress Bar of Container Volume */}
                    <div className="space-y-1.5 mb-4">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-[var(--ink)] flex items-center gap-1">
                          <Boxes className="w-3.5 h-3.5 text-blue-600" />
                          <span>{isSw ? 'Hali ya Kontena:' : 'Container Volume:'}</span>
                        </span>
                        <span className="font-mono font-bold text-blue-700 dark:text-blue-300">
                          {(pool.currentPledgedKg / 1000).toFixed(1)} / {(pool.targetQuantityKg / 1000).toFixed(1)} MT ({fillPercentage}%)
                        </span>
                      </div>

                      <div className="w-full h-3 rounded-full bg-[var(--bg)] border border-[var(--line)] overflow-hidden p-0.5">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${Math.min(100, fillPercentage)}%` }}
                          transition={{ duration: 0.8, ease: 'easeOut' }}
                          className={`h-full rounded-full ${
                            fillPercentage > 75
                              ? 'bg-gradient-to-r from-amber-400 to-emerald-500'
                              : 'bg-gradient-to-r from-blue-500 to-emerald-400'
                          }`}
                        />
                      </div>

                      <div className="flex items-center justify-between text-[10px] text-[var(--ink-soft)]">
                        <span>
                          {isSw ? 'Zimebaki: ' : 'Remaining: '}
                          <strong className="text-[var(--ink)] font-mono">{remainingKg.toLocaleString()} kg</strong>
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3 text-amber-500" />
                          <span>{isSw ? 'Mwisho: ' : 'Deadline: '} {pool.closingDateStr}</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* CTA Buttons */}
                  <div className="pt-2 border-t border-[var(--line)] flex items-center justify-between gap-2">
                    <button
                      onClick={() => {
                        playKeyTap();
                        setSelectedPool(pool);
                        setIsPledgeModalOpen(true);
                      }}
                      className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-500 hover:to-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm active:scale-95 transition-all cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>{isSw ? 'Weka Ahadi ya Mzigo (Pledge)' : 'Pledge Your Harvest'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SUB-TAB 2: MY PLEDGES & WAREHOUSE RECEIPTS (STAKABADHI GHALANI WRS) */}
      {activeTab === 'my_pledges' && (
        <div className="space-y-4">
          <div className="rounded-3xl p-5 bg-[var(--paper)] border border-[var(--line)] shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 className="text-base sm:text-lg font-bold text-[var(--ink)] flex items-center gap-2">
                  <Award className="w-5 h-5 text-emerald-600" />
                  <span>{isSw ? 'Stakabadhi za Ghala (Warehouse Receipts - WRS)' : 'Official Warehouse Receipts (WRS)'}</span>
                </h2>
                <p className="text-xs text-[var(--ink-soft)] mt-0.5">
                  {isSw
                    ? 'Stakabadhi hizi zinatambuliwa kisheria na benki (CRDB, NMB, TADB) na zinaweza kutumika kama dhamana ya mkopo wa fedha taslimu.'
                    : 'These receipts are legally recognized collateral accepted by CRDB, NMB, and TADB for immediate bridge financing.'}
                </p>
              </div>

              <div className="px-3 py-1 rounded-xl bg-emerald-500/15 text-emerald-800 dark:text-emerald-300 text-xs font-bold font-mono">
                {pledges.length} {isSw ? 'Stakabadhi Zilizoidhinishwa' : 'Active Receipts'}
              </div>
            </div>

            {/* List of Farmer's Pledges */}
            <div className="space-y-3">
              {pledges.map((pledge) => {
                const pool = pools.find((p) => p.id === pledge.poolId) || pools[0];
                return (
                  <div
                    key={pledge.id}
                    className="p-4 rounded-2xl bg-[var(--bg)] border border-[var(--line)] hover:border-emerald-500/40 transition-all space-y-3"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[var(--line)] pb-2.5">
                      <div className="flex items-center gap-2.5">
                        <span className="text-2xl">{pool.icon}</span>
                        <div>
                          <div className="font-bold text-xs sm:text-sm text-[var(--ink)]">
                            {isSw ? pool.cropNameSw : pool.cropNameEn} ({pool.amcosCoopName})
                          </div>
                          <div className="text-[11px] text-[var(--ink-soft)] font-mono">
                            Namba ya Stakabadhi: <strong className="text-emerald-700 dark:text-emerald-300">{pledge.warehouseReceiptNumber}</strong>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-800 dark:text-emerald-300 text-[10px] font-bold uppercase flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>{isSw ? 'Imethibitishwa' : 'Verified & Pledged'}</span>
                        </span>

                        <button
                          onClick={() => {
                            playKeyTap();
                            setActiveReceiptPledge(pledge);
                          }}
                          className="py-1 px-2.5 rounded-xl bg-[var(--paper)] border border-[var(--line)] hover:border-emerald-500 text-xs font-bold text-[var(--ink)] flex items-center gap-1 cursor-pointer transition-all"
                        >
                          <QrCode className="w-3.5 h-3.5 text-blue-600" />
                          <span>{isSw ? 'Tazama Hati' : 'Certificate'}</span>
                        </button>
                      </div>
                    </div>

                    {/* Breakdown metrics */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                      <div className="p-2 rounded-xl bg-[var(--paper)] border border-[var(--line)]">
                        <div className="text-[10px] text-[var(--ink-soft)] uppercase font-bold">{isSw ? 'Uzito wa Mzigo' : 'Pledged Volume'}</div>
                        <div className="font-mono text-sm font-bold text-[var(--ink)] mt-0.5">
                          {pledge.quantityKg.toLocaleString()} kg
                        </div>
                      </div>

                      <div className="p-2 rounded-xl bg-[var(--paper)] border border-[var(--line)]">
                        <div className="text-[10px] text-[var(--ink-soft)] uppercase font-bold">{isSw ? 'Jumla ya Malipo' : 'Gross Value'}</div>
                        <div className="font-mono text-sm font-bold text-emerald-700 dark:text-emerald-300 mt-0.5">
                          Tsh {pledge.totalPayoutTsh.toLocaleString()}
                        </div>
                      </div>

                      <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
                        <div className="text-[10px] text-emerald-800 dark:text-emerald-300 uppercase font-bold">{isSw ? 'Malipo ya Awali (70%)' : 'Advance Cash'}</div>
                        <div className="font-mono text-sm font-bold text-emerald-800 dark:text-emerald-200 mt-0.5">
                          Tsh {pledge.advancePayoutTsh.toLocaleString()}
                        </div>
                      </div>

                      <div className="p-2 rounded-xl bg-blue-500/10 border border-blue-500/20">
                        <div className="text-[10px] text-blue-800 dark:text-blue-300 uppercase font-bold">{isSw ? 'Salio la Bandari (30%)' : 'Port Balance'}</div>
                        <div className="font-mono text-sm font-bold text-blue-800 dark:text-blue-200 mt-0.5">
                          Tsh {pledge.finalBalanceTsh.toLocaleString()}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 3: THE AMCOS ADVANTAGE EXPLAINER */}
      {activeTab === 'how_it_works' && (
        <div className="rounded-3xl p-5 sm:p-6 bg-[var(--paper)] border border-[var(--line)] shadow-sm space-y-5">
          <div>
            <h2 className="text-lg font-bold text-[var(--ink)] flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              <span>{isSw ? 'Jinsi Uuzaji wa Pamoja (AMCOS Pools) Unavyokuongezea Faida' : 'How Aggregation Pools Maximize Smallholder Wealth'}</span>
            </h2>
            <p className="text-xs text-[var(--ink-soft)] mt-1 max-w-2xl">
              {isSw
                ? 'Mkulima anayeuza peke yake hupewa bei ya chini na walanguzi wanaotumia mizani isiyo sahihi. Kupitia AMCOS, unauza moja kwa moja kwenye soko la dunia.'
                : 'Individual smallholders are vulnerable to middlemen with calibrated scales and distress pricing. By pooling into export containers, you gain direct access to international port FOB prices.'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-[var(--bg)] border border-[var(--line)] space-y-2">
              <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-sm">
                1
              </div>
              <div className="font-bold text-sm text-[var(--ink)]">
                {isSw ? 'Kusanya Mzigo Shambani' : 'Harvest & Field Grading'}
              </div>
              <p className="text-xs text-[var(--ink-soft)] leading-relaxed">
                {isSw
                  ? 'Vuna na kukausha mazao yako kulingana na vigezo vya ubora (unyevu chini ya 7%, mbegu safi zisizo na mawe).'
                  : 'Harvest, clean, and dry your crop to meet export moisture thresholds (under 7% for sesame, proper avocado maturity).'}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-[var(--bg)] border border-[var(--line)] space-y-2">
              <div className="w-9 h-9 rounded-xl bg-amber-600 text-white flex items-center justify-center font-bold text-sm">
                2
              </div>
              <div className="font-bold text-sm text-[var(--ink)]">
                {isSw ? 'Pata Malipo ya Awali (70%)' : 'Instant 70% Advance Cash'}
              </div>
              <p className="text-xs text-[var(--ink-soft)] leading-relaxed">
                {isSw
                  ? 'Ukikabidhi mzigo wako ghalani, unapokea papo hapo asilimia 70 ya pesa yako kwenye Pochi ya Mkulima na Stakabadhi ya Ghala (WRS).'
                  : 'Receive 70% instant payment into your Farmer Wallet upon depot delivery, backed by a verified Warehouse Receipt.'}
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-[var(--bg)] border border-[var(--line)] space-y-2">
              <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-sm">
                3
              </div>
              <div className="font-bold text-sm text-[var(--ink)]">
                {isSw ? 'Salio Baada ya Kontena Kutweka' : 'Port Clearance Settlement'}
              </div>
              <p className="text-xs text-[var(--ink-soft)] leading-relaxed">
                {isSw
                  ? 'Kontena linapopakiwa kwenye meli kuelekea China au Ulaya, asilimia 30 iliyobaki inalipwa moja kwa moja bila usumbufu.'
                  : 'When the container passes port inspection and loads onto the vessel, the remaining 30% balance is deposited with zero deductions.'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 4. Interactive Harvest Pledge Modal / Drawer */}
      <AnimatePresence>
        {isPledgeModalOpen && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[var(--paper)] text-[var(--ink)] rounded-3xl p-5 sm:p-6 max-w-lg w-full border border-[var(--line)] shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between border-b border-[var(--line)] pb-3">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{activePool.icon}</span>
                  <div>
                    <h3 className="font-display font-bold text-base text-[var(--ink)]">
                      {isSw ? 'Weka Ahadi ya Mzigo Wako' : 'Pledge Your Harvest Quantity'}
                    </h3>
                    <div className="text-xs text-[var(--ink-soft)]">
                      {activePool.amcosCoopName}
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => setIsPledgeModalOpen(false)}
                  className="w-8 h-8 rounded-full bg-[var(--bg)] hover:bg-[var(--line)] flex items-center justify-center text-[var(--ink-soft)] cursor-pointer"
                >
                  ✕
                </button>
              </div>

              {/* Quantity Input Slider & Box */}
              <div className="p-4 rounded-2xl bg-[var(--bg)] border border-[var(--line)] space-y-3">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span>{isSw ? 'Uzito Unaotaka Kuuza (Kilo)' : 'Harvest Weight (Kilograms)'}</span>
                  <span className="font-mono text-lg text-emerald-700 dark:text-emerald-300">
                    {pledgeKg.toLocaleString()} kg
                  </span>
                </div>

                <input
                  type="range"
                  min="200"
                  max="10000"
                  step="100"
                  value={pledgeKg}
                  onChange={(e) => setPledgeKg(parseInt(e.target.value))}
                  className="w-full accent-emerald-600 cursor-pointer"
                />

                <div className="flex items-center justify-between gap-1.5 pt-1">
                  {[500, 1000, 1500, 2500, 5000].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setPledgeKg(preset)}
                      className={`flex-1 py-1 px-1 rounded-xl text-[11px] font-mono font-bold transition-all cursor-pointer ${
                        pledgeKg === preset
                          ? 'bg-emerald-600 text-white'
                          : 'bg-[var(--paper)] border border-[var(--line)] text-[var(--ink-soft)] hover:text-[var(--ink)]'
                      }`}
                    >
                      {preset >= 1000 ? `${preset / 1000}T` : `${preset}kg`}
                    </button>
                  ))}
                </div>
              </div>

              {/* Real-time Calculation Breakdown */}
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/25 space-y-2 text-xs">
                <div className="flex items-center justify-between text-emerald-900 dark:text-emerald-200">
                  <span>{isSw ? 'Bei ya Kuuza Nje (FOB):' : 'Export Price (FOB):'}</span>
                  <span className="font-mono font-bold">Tsh {activePool.exportPriceTshKg.toLocaleString()}/kg</span>
                </div>

                <div className="flex items-center justify-between text-emerald-900 dark:text-emerald-200">
                  <span>{isSw ? 'Jumla ya Malipo Yako:' : 'Total Gross Payout:'}</span>
                  <span className="font-mono font-bold text-base text-emerald-800 dark:text-emerald-300">
                    Tsh {totalPayout.toLocaleString()}
                  </span>
                </div>

                <div className="pt-2 border-t border-emerald-500/20 flex items-center justify-between font-bold text-blue-800 dark:text-blue-300">
                  <span>{isSw ? '1. Malipo ya Awali (70% Ghalani):' : '1. Advance Payment (70% at Depot):'}</span>
                  <span className="font-mono text-sm">Tsh {advancePayout.toLocaleString()}</span>
                </div>

                <div className="flex items-center justify-between text-[var(--ink-soft)]">
                  <span>{isSw ? '2. Salio la Meli (30% Bandarini):' : '2. Port Balance (30% after loading):'}</span>
                  <span className="font-mono">Tsh {finalBalance.toLocaleString()}</span>
                </div>

                {/* Extra gain over middleman */}
                <div className="pt-2 border-t border-emerald-500/20 text-[11px] font-bold text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
                  <TrendingUp className="w-3.5 h-3.5 text-amber-600" />
                  <span>
                    {isSw
                      ? `Faida ya Ziada: Utapata Tsh ${extraFarmerGain.toLocaleString()} zaidi (+${gainPercentage}%) kulinganisha na madalali!`
                      : `Extra Profit: You earn Tsh ${extraFarmerGain.toLocaleString()} more (+${gainPercentage}%) than selling to middlemen!`}
                  </span>
                </div>
              </div>

              {/* Quality Commitment Checkbox */}
              <div className="p-3 rounded-2xl bg-[var(--bg)] border border-[var(--line)] text-xs text-[var(--ink-soft)] flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                <span>
                  {isSw
                    ? `Ninakubali kuleta mzigo wenye unyevu chini ya 7.0% kwenye kituo cha ${activePool.dropoffDepotSw} kabla ya tarehe ${activePool.closingDateStr}.`
                    : `I commit to delivering export quality grade crop to ${activePool.dropoffDepotEn} before ${activePool.closingDateStr}.`}
                </span>
              </div>

              {/* Submit Button */}
              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsPledgeModalOpen(false)}
                  className="py-2.5 px-4 rounded-xl border border-[var(--line)] text-xs font-bold text-[var(--ink-soft)] hover:text-[var(--ink)] cursor-pointer"
                >
                  {isSw ? 'Ghairi' : 'Cancel'}
                </button>
                <button
                  type="button"
                  onClick={handleConfirmPledge}
                  className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-500 hover:to-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md active:scale-95 transition-all cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isSw ? 'Thibitisha Ahadi ya Mzigo' : 'Confirm Pledge & Generate WRS'}</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 5. Official Warehouse Receipt (WRS) Certificate Modal */}
      <AnimatePresence>
        {activeReceiptPledge && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[var(--paper)] text-[var(--ink)] rounded-3xl p-6 max-w-lg w-full border-2 border-emerald-500 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto"
            >
              {/* Receipt Top Header */}
              <div className="text-center border-b-2 border-dashed border-[var(--line)] pb-4">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-emerald-600 text-white font-bold text-xl mb-1 shadow-sm">
                  WRS
                </div>
                <div className="text-[10px] uppercase tracking-widest font-bold text-emerald-700 dark:text-emerald-300">
                  JAMHURI YA MUUNGANO WA TANZANIA • BODI YA STAKABADHI ZA GHALA (WRRB)
                </div>
                <h3 className="font-display text-lg font-bold text-[var(--ink)] mt-0.5">
                  {isSw ? 'Hati Rasmi ya Stakabadhi ya Ghala' : 'Official Warehouse Receipt Certificate'}
                </h3>
                <div className="font-mono text-xs font-bold text-blue-700 dark:text-blue-300">
                  {activeReceiptPledge.warehouseReceiptNumber}
                </div>
              </div>

              {/* Receipt Meta Details */}
              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b border-[var(--line)]">
                  <span className="text-[var(--ink-soft)]">{isSw ? 'Jina la Mkulima:' : 'Farmer Name:'}</span>
                  <span className="font-bold text-[var(--ink)]">{activeReceiptPledge.farmerName}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[var(--line)]">
                  <span className="text-[var(--ink-soft)]">{isSw ? 'Namba ya Simu:' : 'Phone Number:'}</span>
                  <span className="font-mono font-bold text-[var(--ink)]">{activeReceiptPledge.farmerPhone}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[var(--line)]">
                  <span className="text-[var(--ink-soft)]">{isSw ? 'Uzito Uliothibitishwa:' : 'Verified Net Weight:'}</span>
                  <span className="font-mono font-bold text-emerald-700 dark:text-emerald-300">
                    {activeReceiptPledge.quantityKg.toLocaleString()} kg
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-[var(--line)]">
                  <span className="text-[var(--ink-soft)]">{isSw ? 'Thamani ya Mzigo (Jumla):' : 'Gross Asset Value:'}</span>
                  <span className="font-mono font-bold text-base text-[var(--ink)]">
                    Tsh {activeReceiptPledge.totalPayoutTsh.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-[var(--line)] bg-emerald-500/10 px-2 rounded-lg">
                  <span className="text-emerald-800 dark:text-emerald-300 font-bold">{isSw ? 'Malipo ya Awali (70%):' : 'Advance Payout (70%):'}</span>
                  <span className="font-mono font-bold text-emerald-800 dark:text-emerald-300">
                    Tsh {activeReceiptPledge.advancePayoutTsh.toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-[var(--line)]">
                  <span className="text-[var(--ink-soft)]">{isSw ? 'Hali ya Stakabadhi:' : 'Status:'}</span>
                  <span className="font-bold text-emerald-600 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{isSw ? 'Imethibitishwa na AMCOS' : 'Verified by AMCOS'}</span>
                  </span>
                </div>
              </div>

              {/* QR Verification Barcode Simulation */}
              <div className="p-3 rounded-2xl bg-[var(--bg)] border border-[var(--line)] flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <QrCode className="w-10 h-10 text-[var(--ink)] flex-shrink-0" />
                  <div className="text-[10px] text-[var(--ink-soft)] leading-tight">
                    <div className="font-bold text-[var(--ink)] font-mono">ARDHI-WRRB-VERIFIED</div>
                    <div>{isSw ? 'Scan kuthibitisha na benki za CRDB / NMB' : 'Scan to authenticate with CRDB / NMB'}</div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-[9px] text-[var(--ink-soft)]">{isSw ? 'Kikomo cha Mkopo:' : 'Max Loan Collateral:'}</div>
                  <div className="font-mono font-bold text-xs text-blue-700 dark:text-blue-300">
                    Tsh {Math.round(activeReceiptPledge.totalPayoutTsh * 0.75).toLocaleString()}
                  </div>
                </div>
              </div>

              {/* Close & Print Buttons */}
              <div className="pt-2 flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="py-2.5 px-4 rounded-xl bg-[var(--bg)] border border-[var(--line)] hover:border-emerald-500 text-xs font-bold text-[var(--ink)] flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>{isSw ? 'Chapisha (Print)' : 'Print WRS'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveReceiptPledge(null)}
                  className="py-2.5 px-5 rounded-xl bg-[var(--forest)] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm hover:opacity-95"
                >
                  <span>{isSw ? 'Sawa, Nimeelewa' : 'Done & Close'}</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
