import type { Square } from "chess.js";
import { PieceGlyph } from "@/components/piece-glyph";
import { cn } from "@/lib/cn";
import {
  FILES,
  isLightSquare,
  pieceName,
  type BoardMap,
  type BoardPiece,
} from "@/lib/chess/position";

export type SquareMark = "correct" | "missing" | "wrong" | "extra";

type Props = {
  pieces: BoardMap;
  ghosts?: BoardMap;
  badges?: BoardMap;
  marks?: Partial<Record<Square, SquareMark>>;
  flipped: boolean;
  interactive: boolean;
  armedSquare?: Square | null;
  liftedSquare?: Square | null;
  dimPieces?: boolean;
  label: string;
  onSquarePointerDown?: (square: Square, event: React.PointerEvent<HTMLDivElement>) => void;
};

const RANKS_WHITE = ["8", "7", "6", "5", "4", "3", "2", "1"];
const RANKS_BLACK = ["1", "2", "3", "4", "5", "6", "7", "8"];

export function squareFromPoint(x: number, y: number): Square | null {
  const element = document.elementFromPoint(x, y);
  const node = element?.closest?.("[data-square]");
  const square = node?.getAttribute("data-square");
  return square ? (square as Square) : null;
}

export function ChessBoard({
  pieces,
  ghosts,
  badges,
  marks,
  flipped,
  interactive,
  armedSquare,
  liftedSquare,
  dimPieces = false,
  label,
  onSquarePointerDown,
}: Props) {
  const files = flipped ? [...FILES].reverse() : [...FILES];
  const ranks = flipped ? RANKS_BLACK : RANKS_WHITE;

  return (
    <div className="rounded-2xl bg-raised p-2 shadow-lg ring-1 ring-line sm:p-3">
      <div className="flex gap-1">
        <div className="grid w-4 shrink-0 grid-rows-8" aria-hidden="true">
          {ranks.map((rank) => (
            <span key={rank} className="flex items-center justify-center text-xs font-medium text-muted">
              {rank}
            </span>
          ))}
        </div>
        <div
          role="grid"
          aria-label={label}
          data-testid="board"
          className="grid aspect-square min-w-0 flex-1 touch-none grid-cols-8 overflow-hidden rounded-lg select-none"
        >
          {ranks.map((rank) =>
            files.map((file) => {
              const square = `${file}${rank}` as Square;
              const piece = pieces[square];
              const ghost = ghosts?.[square];
              const badge = badges?.[square];
              const mark = marks?.[square];
              const light = isLightSquare(square);
              const lifted = liftedSquare === square;
              return (
                <div
                  key={square}
                  role="gridcell"
                  data-square={square}
                  data-testid={`square-${square}`}
                  aria-label={squareLabel(square, piece, mark)}
                  onPointerDown={(event) => {
                    if (!interactive) return;
                    event.preventDefault();
                    onSquarePointerDown?.(square, event);
                  }}
                  className={cn(
                    "relative aspect-square",
                    light ? "bg-light" : "bg-darksq",
                    interactive && "cursor-pointer",
                    armedSquare === square && "ring-2 ring-brass ring-inset",
                  )}
                >
                  {mark === "correct" && (
                    <span className="pointer-events-none absolute inset-0 bg-good/30" />
                  )}
                  {mark === "missing" && (
                    <span className="pointer-events-none absolute inset-0 bg-brass/25" />
                  )}
                  {(mark === "wrong" || mark === "extra") && (
                    <span className="pointer-events-none absolute inset-0 bg-bad/30" />
                  )}
                  <div
                    className={cn(
                      "absolute inset-0 p-1 transition-opacity duration-200 sm:p-1.5",
                      dimPieces && "opacity-0",
                    )}
                  >
                    {ghost && <PieceGlyph piece={ghost} className="opacity-60" />}
                    {piece && !lifted && <PieceGlyph piece={piece} />}
                  </div>
                  {badge && (
                    <span className="pointer-events-none absolute top-0 right-0 h-2/5 w-2/5 rounded-sm bg-light p-px ring-1 ring-brass">
                      <PieceGlyph piece={badge} />
                    </span>
                  )}
                </div>
              );
            }),
          )}
        </div>
      </div>
      <div className="mt-1 flex gap-1" aria-hidden="true">
        <div className="w-4 shrink-0" />
        <div className="grid min-w-0 flex-1 grid-cols-8">
          {files.map((file) => (
            <span key={file} className="text-center text-xs font-medium text-muted">
              {file}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

function squareLabel(square: Square, piece?: BoardPiece, mark?: SquareMark) {
  const occupant = piece ? pieceName(piece) : "empty";
  if (!mark) return `${square}, ${occupant}`;
  return `${square}, ${occupant}, ${mark}`;
}
