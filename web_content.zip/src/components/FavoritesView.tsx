import React, { useState } from "react";
import { Heart, Copy, Share2, Check, BookOpen } from "lucide-react";
import { GeneratedPoetry, AppSettings } from "../types";
import { MODE_METADATA } from "../data/constants";

interface FavoritesViewProps {
  favorites: string[];
  history: GeneratedPoetry[];
  settings: AppSettings;
  onToggleFavorite: (id: string) => void;
  onSelectPoetry: (poetry: GeneratedPoetry) => void;
}

export const FavoritesView: React.FC<FavoritesViewProps> = ({
  favorites,
  history,
  settings,
  onToggleFavorite,
  onSelectPoetry
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const favoriteItems = history.filter((item) => favorites.includes(item.id));

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleShare = async (text: string) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Hassan's MisraSaaz AI - پسندیدہ کلام",
          text: `${text}\n\n— Hassan's MisraSaaz AI (حسنؔ کا مصرع ساز)`
        });
      } catch {
        navigator.clipboard.writeText(text);
      }
    } else {
      navigator.clipboard.writeText(text);
    }
  };

  const fontClass = settings.selectedFont === "nastaliq" ? "font-urdu" : "font-urdu-sans";

  return (
    <div className="space-y-4 pb-20">
      <div className="bg-stone-900/90 rounded-2xl p-4 border border-rose-900/40 shadow-lg flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Heart className="w-5 h-5 text-rose-400 fill-rose-500" />
          <h3 className="font-urdu-title text-xl text-rose-200 font-bold">
            پسندیدہ کلام و نغمات (Favorites)
          </h3>
        </div>
        <span className="text-xs font-urdu-sans px-2.5 py-1 rounded-full bg-rose-950/80 border border-rose-800 text-rose-300">
          {favoriteItems.length} اشعار
        </span>
      </div>

      {favoriteItems.length === 0 ? (
        <div className="text-center py-12 px-4 rounded-2xl bg-stone-900/40 border border-dashed border-stone-800">
          <Heart className="w-10 h-10 text-stone-600 mx-auto mb-2" />
          <p className="font-urdu-title text-lg text-stone-400">کوئی کلام پسندیدہ میں شامل نہیں ہے</p>
          <p className="font-urdu-sans text-xs text-stone-500 mt-1">
            شاعری تخلیق کرنے کے بعد دل کے آئیکن پر کلک کر کے محفوظ کریں۔
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {favoriteItems.map((item) => {
            const isCopied = copiedId === item.id;
            const meta = MODE_METADATA[item.mode];

            return (
              <div
                key={item.id}
                className="bg-stone-900/90 rounded-2xl p-4 border border-stone-800 hover:border-rose-500/40 transition-all shadow-md"
              >
                <div className="flex items-center justify-between border-b border-stone-800/80 pb-2 mb-3 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-md bg-rose-950/80 text-rose-300 font-urdu-sans border border-rose-800/50">
                      {meta?.badge || item.mode}
                    </span>
                    <span className="font-urdu-title font-bold text-amber-200">
                      {item.topic}
                    </span>
                  </div>
                  <span className="text-[10px] font-ui text-stone-500">
                    {new Date(item.timestamp).toLocaleDateString()}
                  </span>
                </div>

                <div
                  onClick={() => onSelectPoetry(item)}
                  className={`text-base md:text-lg text-amber-100/90 ${fontClass} whitespace-pre-line cursor-pointer hover:text-amber-200 transition-colors my-2 px-2`}
                >
                  {item.content}
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-800/60 mt-3">
                  <button
                    onClick={() => handleCopy(item.id, item.content)}
                    className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-urdu-sans flex items-center gap-1"
                  >
                    {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{isCopied ? "کاپی شد" : "کاپی"}</span>
                  </button>

                  <button
                    onClick={() => handleShare(item.content)}
                    className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-urdu-sans flex items-center gap-1"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>شیئر</span>
                  </button>

                  <button
                    onClick={() => onToggleFavorite(item.id)}
                    className="p-1.5 rounded-lg bg-rose-950/80 border border-rose-500/60 text-rose-300 text-xs flex items-center gap-1"
                    title="پسندیدہ سے ہٹائیں"
                  >
                    <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500" />
                    <span className="font-urdu-sans">محفوظ</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
