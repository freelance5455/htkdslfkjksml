import { KeyRound, Settings2, Volume2, VolumeX, Wrench } from "lucide-react";
import { useEffect, useRef, useState, type RefObject } from "react";
import { MakerPanel } from "@/components/panel";
import { usePwa } from "@/components/pwa";
import { Shifter } from "@/components/shifter";
import { copy, isRtl, LANGS, LANG_LABEL, type Lang } from "@/engine/i18n";
import { curve, engineTitle, perf } from "@/engine/spec";
import { Runtime } from "@/engine/runtime";
import { sanitize, type Spec } from "@/engine/types";

const SPEC_KEY = "em_spec";
const LANG_KEY = "em_lang";
const BG_KEY = "em_bg";
const VOL_KEY = "em_vol";

function readJSON<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

function applyBg(color: string) {
  const root = document.documentElement;
  const keys = ["--color-fg", "--color-panel", "--color-line", "--color-muted", "--color-chip"];
  if (!color) {
    root.removeAttribute("data-forced");
    root.style.removeProperty("--color-bg");
    keys.forEach((k) => root.style.removeProperty(k));
    root.style.colorScheme = "";
    return;
  }
  const n = Number.parseInt(color.slice(1), 16);
  const L = (0.299 * (n >> 16) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255;
  const light = L > 0.55;
  const pal = light
    ? ["#15181d", "#ffffff", "#c9ced6", "#5b6370", "#f3f5f8"]
    : ["#e8eaee", "#1a1d23", "#2d323b", "#8b93a1", "#23272f"];
  root.setAttribute("data-forced", "1");
  root.style.setProperty("--color-bg", color);
  keys.forEach((k, i) => root.style.setProperty(k, pal[i]!));
  root.style.colorScheme = light ? "light" : "dark";
}

export function EngineApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rtRef = useRef<Runtime | null>(null);
  const langRef = useRef<Lang>("en");
  const [spec, setSpec] = useState<Spec>(() => {
    const saved = sanitize(readJSON(SPEC_KEY));
    // A saved V12 diesel becomes gasoline so the plug and mixture match the motor.
    // Bore, stroke and layout stay put, so displacement does not change.
    if (saved.type === "v12" && saved.fuel === "dsl") {
      const next = { ...saved, fuel: "gas" as const };
      try {
        localStorage.setItem(SPEC_KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    }
    return saved;
  });
  const [lang, setLang] = useState<Lang>(() => {
    const saved = localStorage.getItem(LANG_KEY);
    return LANGS.includes(saved as Lang) ? (saved as Lang) : "en";
  });
  const [askLang, setAskLang] = useState(() => !localStorage.getItem(LANG_KEY));
  const [open, setOpen] = useState(() => window.innerWidth > 960);
  const [gear, setGear] = useState(0);
  const [dead, setDead] = useState(false);
  const [sound, setSound] = useState(false);
  const [volume, setVolume] = useState(() => {
    const n = Number(localStorage.getItem(VOL_KEY));
    return Number.isFinite(n) ? Math.min(1, Math.max(0, n)) : 0.7;
  });
  const [bg, setBg] = useState(() => localStorage.getItem(BG_KEY) ?? "");
  const [fail, setFail] = useState("");
  const titleRef = useRef<HTMLElement>(null);
  const ccRef = useRef<HTMLSpanElement>(null);
  const hpRef = useRef<HTMLSpanElement>(null);
  const tqRef = useRef<HTMLSpanElement>(null);
  const spdRef = useRef<HTMLElement>(null);
  const gearRef = useRef<HTMLElement>(null);
  const barRef = useRef<HTMLElement>(null);
  const statRef = useRef<HTMLParagraphElement>(null);
  const ignRef = useRef<HTMLButtonElement>(null);
  const gasRef = useRef<HTMLButtonElement>(null);
  const brakeRef = useRef<HTMLButtonElement>(null);
  const clutchRef = useRef<HTMLButtonElement>(null);
  langRef.current = lang;
  const tr = copy(lang);
  const pwa = usePwa();

  useEffect(() => {
    applyBg(bg);
  }, [bg]);

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let rt: Runtime;
    try {
      rt = new Runtime(canvas, spec, {
        onDead: setDead,
        onGear: setGear,
      });
      rt.audio.setVolume(volume);
    } catch (err) {
      setFail(err instanceof Error ? err.message : "WebGL unavailable");
      return;
    }
    rtRef.current = rt;
    rt.start();
    let raf = 0;
    const paint = () => {
      const live = rt.live;
      const s = rt.spec;
      const c = copy(langRef.current);
      const p = perf(s, live.rpm);
      const k = 0.08 + 0.92 * live.thr;
      const red = curve(s).red;
      if (titleRef.current) titleRef.current.textContent = engineTitle(s, c);
      if (ccRef.current) ccRef.current.textContent = `${Math.round(p.cc)} cc`;
      if (hpRef.current) hpRef.current.textContent = `${Math.round(p.hp * k)} hp`;
      if (tqRef.current) tqRef.current.textContent = `${Math.round(p.tq * k)} N·m`;
      if (spdRef.current) spdRef.current.textContent = String(Math.round(live.spd * 3.6));
      if (gearRef.current) gearRef.current.textContent = live.gear ? String(live.gear) : "N";
      if (barRef.current) {
        barRef.current.style.width = `${Math.min(100, (live.rpm / red) * 100)}%`;
        barRef.current.style.background = live.rpm > red * 0.92 ? "var(--color-danger)" : "var(--color-accent)";
      }
      if (statRef.current) {
        const bits = [`${Math.round(live.rpm)} ${c.rpmRed} ${Math.round(red)}`];
        if (live.dead) bits.push(c.blown);
        else if (live.rpm > red * 1.08) bits.push(c.overrev);
        if (live.stall) bits.push(live.crank > 0 ? c.ignCrank : c.stall);
        if (live.msg > 0) bits.push(c.msgClutch);
        if (live.grind > 0) bits.push(c.grind);
        statRef.current.textContent = bits.join("   ");
      }
      if (ignRef.current) ignRef.current.childNodes[1] && (ignRef.current.lastChild!.textContent = live.stall ? (live.crank > 0 ? c.ignCrank : c.ignStart) : c.ignStop);
      gasRef.current?.style.setProperty("--t", live.thr.toFixed(2));
      gasRef.current?.classList.toggle("border-accent", live.pedal > 0);
      gasRef.current?.classList.toggle("text-accent", live.pedal > 0);
      brakeRef.current?.classList.toggle("border-danger", live.brk > 0);
      brakeRef.current?.classList.toggle("text-danger", live.brk > 0);
      clutchRef.current?.classList.toggle("border-clutch", live.cin > 0);
      clutchRef.current?.classList.toggle("text-clutch", live.cin > 0);
      raf = requestAnimationFrame(paint);
    };
    raf = requestAnimationFrame(paint);
    const stage = canvas.parentElement;
    const ro = new ResizeObserver(() => rt.resize());
    if (stage) ro.observe(stage);
    const drag = { x: 0, y: 0, on: false };
    const pts = new Map<number, { x: number; y: number }>();
    let pinch = 0;
    const down = (e: PointerEvent) => {
      pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      canvas.setPointerCapture(e.pointerId);
      if (pts.size >= 2) {
        drag.on = false;
        const [a, b] = [...pts.values()];
        pinch = Math.hypot(a!.x - b!.x, a!.y - b!.y);
        return;
      }
      drag.on = true;
      drag.x = e.clientX;
      drag.y = e.clientY;
    };
    const move = (e: PointerEvent) => {
      if (!pts.has(e.pointerId)) return;
      pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pts.size >= 2) {
        const [a, b] = [...pts.values()];
        const d = Math.hypot(a!.x - b!.x, a!.y - b!.y);
        if (pinch > 8) rt.scene.zoom((pinch - d) * 0.0045);
        pinch = d;
        return;
      }
      if (!drag.on) return;
      rt.scene.orbit(e.clientX - drag.x, e.clientY - drag.y);
      drag.x = e.clientX;
      drag.y = e.clientY;
    };
    const up = (e: PointerEvent) => {
      pts.delete(e.pointerId);
      pinch = 0;
      if (pts.size === 1) {
        const p = [...pts.values()][0]!;
        drag.on = true;
        drag.x = p.x;
        drag.y = p.y;
        return;
      }
      drag.on = false;
    };
    const wheel = (e: WheelEvent) => {
      e.preventDefault();
      const dy = Math.max(-90, Math.min(90, e.deltaY));
      rt.scene.zoom(dy * 0.0016);
    };
    canvas.addEventListener("pointerdown", down);
    canvas.addEventListener("pointermove", move);
    canvas.addEventListener("pointerup", up);
    canvas.addEventListener("pointercancel", up);
    canvas.addEventListener("wheel", wheel, { passive: false });
    canvas.addEventListener("dblclick", () => rt.scene.resetView());
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      canvas.removeEventListener("pointerdown", down);
      canvas.removeEventListener("pointermove", move);
      canvas.removeEventListener("pointerup", up);
      canvas.removeEventListener("pointercancel", up);
      canvas.removeEventListener("wheel", wheel);
      rt.stop();
      rtRef.current = null;
    };
    // Mount once — later spec changes go through the runtime ref.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function patch(p: Partial<Spec>) {
    setSpec((prev) => {
      const next = sanitize({ ...prev, ...p });
      rtRef.current?.setSpec(next);
      try {
        localStorage.setItem(SPEC_KEY, JSON.stringify(next));
      } catch {
        /* ignore quota */
      }
      return next;
    });
  }

  function chooseLang(l: Lang) {
    setLang(l);
    setAskLang(false);
    try {
      localStorage.setItem(LANG_KEY, l);
    } catch {
      /* ignore */
    }
  }

  function hold(ref: "pedal" | "brk" | "cin", v: number) {
    const live = rtRef.current?.live;
    if (live) live[ref] = v;
  }

  const dir = isRtl(lang) ? "rtl" : "ltr";

  return (
    <div dir={dir} className="flex h-dvh overflow-hidden bg-bg font-sans text-fg">
      <div className="relative min-h-0 min-w-0 flex-1">
        <canvas ref={canvasRef} className="stage-canvas" />
        <header className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-2 px-3 pt-[max(0.75rem,env(safe-area-inset-top))]">
          <div className="pointer-events-none min-w-0">
            <p className="font-display text-base leading-none font-bold tracking-[0.12em] sm:text-lg sm:tracking-[0.14em]">
              ENGINE MAKER <span className="text-accent">1.0</span>
            </p>
            <p className="mt-1 hidden text-xs text-muted sm:block">{tr.drag}</p>
          </div>
          <div className="pointer-events-auto flex shrink-0 flex-wrap justify-end gap-2">
            <button
              type="button"
              aria-label={open ? tr.close : tr.title}
              className="inline-flex min-h-11 items-center gap-1.5 rounded-xl bg-accent px-3 text-sm font-semibold text-accent-fg"
              onClick={() => setOpen((v) => !v)}
            >
              <Settings2 className="size-4" />
              <span className="max-sm:sr-only">{open ? tr.close : tr.title}</span>
            </button>
            <button
              type="button"
              aria-label={sound ? tr.soundOff : tr.soundOn}
              className="inline-flex min-h-11 items-center gap-1.5 rounded-xl border border-line bg-panel/90 px-3 text-sm font-semibold backdrop-blur"
              onClick={() => {
                const on = rtRef.current?.audio.toggle() ?? false;
                setSound(on);
              }}
            >
              {sound ? <Volume2 className="size-4" /> : <VolumeX className="size-4" />}
              <span className="max-sm:sr-only">{sound ? tr.soundOff : tr.soundOn}</span>
            </button>
            <button
              ref={ignRef}
              type="button"
              aria-label={tr.ignStart}
              className="inline-flex min-h-11 items-center gap-1.5 rounded-xl border border-line bg-panel/90 px-3 text-sm font-semibold backdrop-blur"
              onClick={() => rtRef.current?.ignition()}
            >
              <KeyRound className="size-4" />
              <span className="max-sm:sr-only">{tr.ignStart}</span>
            </button>
          </div>
        </header>

        {fail && (
          <p className="absolute top-24 left-3 rounded-lg border border-danger bg-panel px-3 py-2 text-sm text-danger">{fail}</p>
        )}

        {dead && (
          <div className="blow-card absolute left-1/2 z-10 flex -translate-x-1/2 -translate-y-1/2 flex-col items-center gap-2 rounded-2xl border-2 border-danger bg-panel px-4 py-4 text-center">
            <p className="font-display text-2xl font-bold text-danger">{tr.deadT}</p>
            <p className="text-sm text-muted">{tr.deadD}</p>
            <button
              type="button"
              className="inline-flex min-h-11 items-center gap-1.5 rounded-lg bg-danger px-4 font-semibold text-accent-fg"
              onClick={() => rtRef.current?.repair()}
            >
              <Wrench className="size-4" />
              {tr.fix}
            </button>
          </div>
        )}

        <aside className="hud pointer-events-none absolute start-2 z-[1] w-[min(12.5rem,46vw)] rounded-xl border border-line bg-panel/75 px-2 py-1.5 shadow-sm backdrop-blur-sm top-[max(3.2rem,calc(env(safe-area-inset-top)+2.7rem))]">
          <div className="flex items-baseline justify-between gap-2">
            <b ref={titleRef} className="truncate text-sm font-bold tracking-wide">
              {engineTitle(spec, tr)}
            </b>
            <span ref={ccRef} className="shrink-0 text-[11px] text-muted" />
          </div>
          <div className="mt-0.5 flex gap-2 text-[11px] text-muted">
            <span ref={hpRef} />
            <span ref={tqRef} />
          </div>
          <div className="mt-1 flex items-end gap-1.5">
            <b ref={spdRef} className="font-display text-2xl leading-none font-bold">
              0
            </b>
            <span className="pb-0.5 text-[10px] text-muted">km/h</span>
            <b ref={gearRef} className="ms-auto font-display text-xl leading-none font-bold">
              N
            </b>
          </div>
          <div className="mt-1 h-1 overflow-hidden rounded-full bg-line">
            <i ref={barRef} className="block h-full w-0 bg-accent" />
          </div>
          <p ref={statRef} className="mt-0.5 truncate text-[10px] text-muted" />
          <p className="mt-0.5 hidden truncate text-[10px] text-fg md:block">{tr.hint}</p>
          <p className="mt-0.5 hidden truncate text-[10px] text-muted lg:block">{tr.keys}</p>
        </aside>

        <footer className="dock pointer-events-none absolute inset-x-2 bottom-2 flex items-end gap-2">
          <div className="pointer-events-auto">
            <Shifter gear={gear} onShift={(g) => rtRef.current?.shift(g) ?? g} />
          </div>
          <div className="pointer-events-auto ms-auto flex items-end gap-2">
            <Pedal
              btnRef={clutchRef}
              label={tr.clutch}
              onDown={() => hold("cin", 1)}
              onUp={() => hold("cin", 0)}
            />
            <Pedal
              btnRef={brakeRef}
              label={tr.brake}
              onDown={() => hold("brk", 1)}
              onUp={() => hold("brk", 0)}
            />
            <button
              ref={gasRef}
              type="button"
              className="ped ped-gas h-36 w-20 rounded-2xl border border-line text-xs font-bold"
              onPointerDown={(e) => {
                e.currentTarget.setPointerCapture(e.pointerId);
                hold("pedal", 1);
              }}
              onPointerUp={() => hold("pedal", 0)}
              onPointerCancel={() => hold("pedal", 0)}
            >
              {tr.gas}
            </button>
          </div>
        </footer>
      </div>

      {open && (
        <MakerPanel
          tr={tr}
          lang={lang}
          spec={spec}
          volume={volume}
          bg={bg}
          onClose={() => setOpen(false)}
          onLang={chooseLang}
          onSpec={patch}
          onVolume={(v) => {
            setVolume(v);
            rtRef.current?.audio.setVolume(v);
            try {
              localStorage.setItem(VOL_KEY, String(v));
            } catch {
              /* ignore */
            }
          }}
          onBg={(c) => {
            setBg(c);
            try {
              localStorage.setItem(BG_KEY, c);
            } catch {
              /* ignore */
            }
          }}
          pwa={{
            canInstall: pwa.canInstall,
            installed: pwa.installed,
            ios: pwa.ios,
            shareNote: pwa.shareNote,
            onInstall: () => {
              void pwa.install();
            },
            onShare: () => {
              void pwa.share();
            },
          }}
        />
      )}

      {askLang && (
        <div className="fixed inset-0 z-30 grid place-items-center bg-black/60 p-4">
          <div className="w-full max-w-xs rounded-2xl border border-line bg-panel p-4 text-center">
            <p className="mb-3 text-sm font-semibold">{tr.langPick}</p>
            <div className="grid gap-2">
              {LANGS.map((l) => (
                <button key={l} type="button" className="min-h-11 rounded-xl border border-line bg-chip text-base font-semibold" onClick={() => chooseLang(l)}>
                  {LANG_LABEL[l]}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Pedal({
  label,
  btnRef,
  onDown,
  onUp,
}: {
  label: string;
  btnRef: RefObject<HTMLButtonElement | null>;
  onDown: () => void;
  onUp: () => void;
}) {
  return (
    <button
      ref={btnRef}
      type="button"
      className="ped h-28 w-16 rounded-2xl border border-line text-xs font-bold"
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        onDown();
      }}
      onPointerUp={onUp}
      onPointerCancel={onUp}
    >
      {label}
    </button>
  );
}
