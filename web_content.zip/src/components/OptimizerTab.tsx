/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useNetwork } from '../context/NetworkContext';
import { 
  Sparkles, 
  Wifi, 
  Radio, 
  AlertTriangle, 
  CheckCircle2, 
  RefreshCw, 
  Info, 
  Zap, 
  ShieldCheck, 
  Sliders,
  Check
} from 'lucide-react';
import { NEIGHBOR_NETWORKS } from '../data/mockNetworkData';

export const OptimizerTab: React.FC = () => {
  const { 
    channels24, 
    channels5, 
    applyChannelOptimization, 
    dnsServers, 
    applyDnsServer, 
    runDnsBenchmark,
    metrics
  } = useNetwork();

  const [selectedBand, setSelectedBand] = useState<'2.4GHz' | '5GHz'>('2.4GHz');
  const [isBenchmarkingDns, setIsBenchmarkingDns] = useState(false);
  const [mtuResult, setMtuResult] = useState<{ status: 'ideal' | 'testing'; mtu: number }>({
    status: 'ideal',
    mtu: 1500,
  });

  const activeChannels = selectedBand === '2.4GHz' ? channels24 : channels5;
  const currentChannel = activeChannels.find(c => c.isCurrent);
  const recommendedChannel = activeChannels.find(c => c.isRecommended);

  const handleBenchmarkDns = async () => {
    setIsBenchmarkingDns(true);
    await new Promise(r => setTimeout(r, 600));
    await runDnsBenchmark();
    setIsBenchmarkingDns(false);
  };

  return (
    <div className="space-y-4 pb-20 pt-1">
      {/* Required Disclaimer Banner */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800/80 p-3.5 flex items-start gap-3">
        <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
        <p className="text-xs text-slate-300 leading-relaxed">
          <strong className="text-white">Speed Optimization Scope:</strong> Optimization cleans up Wi-Fi channel interference, eliminates bufferbloat queues, and selects lower-latency DNS resolvers. It <em>cannot increase raw speeds beyond your ISP plan or physical connection limits</em>.
        </p>
      </div>

      {/* Wi-Fi Channel Spectrum & Congestion Analyzer */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800/80 p-4 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Radio className="w-4 h-4 text-cyan-400" />
              <span>Wi-Fi Spectrum & Channel Analyzer</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Current SSID: {metrics.wifiSsid}
            </p>
          </div>

          {/* Band Selector */}
          <div className="flex items-center p-0.5 rounded-lg bg-slate-950 border border-slate-800 text-xs">
            <button
              onClick={() => setSelectedBand('2.4GHz')}
              className={`px-3 py-1 rounded-md font-medium transition ${
                selectedBand === '2.4GHz'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              2.4 GHz
            </button>
            <button
              onClick={() => setSelectedBand('5GHz')}
              className={`px-3 py-1 rounded-md font-medium transition ${
                selectedBand === '5GHz'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              5 GHz
            </button>
          </div>
        </div>

        {/* Channel Interference Visualizer */}
        <div className="my-3 p-3 rounded-xl bg-slate-950/80 border border-slate-800/80">
          <div className="flex justify-between text-[11px] text-slate-400 mb-2">
            <span>Spectrum Density & Channel Crowding</span>
            <span className="text-[10px] text-slate-500">Lower bar = cleaner channel</span>
          </div>

          {/* Bar Spectrum Chart */}
          <div className="grid grid-cols-11 gap-1 items-end h-28 pt-2">
            {activeChannels.map(ch => {
              const heightPct = ch.interferencePct;
              const isHigh = heightPct > 65;
              const isLow = heightPct < 30;

              return (
                <div key={ch.channel} className="flex flex-col items-center h-full justify-end group">
                  {/* Neighbor badge on hover / top */}
                  <span className="text-[9px] font-mono text-slate-400 mb-1 opacity-0 group-hover:opacity-100 transition">
                    {ch.neighborCount}
                  </span>

                  {/* Channel Bar */}
                  <div
                    style={{ height: `${heightPct}%` }}
                    className={`w-full rounded-t-md transition-all duration-300 relative ${
                      ch.isCurrent
                        ? 'bg-gradient-to-t from-cyan-600 to-cyan-400 ring-2 ring-cyan-400/50'
                        : ch.isRecommended
                        ? 'bg-gradient-to-t from-emerald-600 to-emerald-400'
                        : isHigh
                        ? 'bg-rose-500/60'
                        : isLow
                        ? 'bg-emerald-500/40'
                        : 'bg-slate-700/60'
                    }`}
                  >
                    {ch.isRecommended && (
                      <span className="absolute -top-3 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                    )}
                  </div>

                  {/* Channel Number Label */}
                  <span className={`text-[10px] font-mono mt-1 ${
                    ch.isCurrent 
                      ? 'text-cyan-400 font-bold' 
                      : ch.isRecommended 
                      ? 'text-emerald-400 font-bold' 
                      : 'text-slate-400'
                  }`}>
                    {ch.channel}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between text-[10px] text-slate-400 mt-3 pt-2 border-t border-slate-800">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-cyan-400" />
              <span>Current (Ch {currentChannel?.channel || '--'})</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>Recommended (Ch {recommendedChannel?.channel || '--'})</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-rose-500/70" />
              <span>Crowded (&gt;65% loss)</span>
            </div>
          </div>
        </div>

        {/* Optimization Recommendation Box */}
        {recommendedChannel && (
          <div className="p-3 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 flex items-center justify-between gap-3">
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Optimal Channel Found: Channel {recommendedChannel.channel}</span>
              </div>
              <p className="text-[11px] text-slate-300 mt-0.5 leading-relaxed">
                Switching from Channel {currentChannel?.channel} drops interference by {Math.max(0, (currentChannel?.interferencePct || 0) - recommendedChannel.interferencePct)}% and eliminates packet retries.
              </p>
            </div>

            <button
              onClick={() => applyChannelOptimization(selectedBand, recommendedChannel.channel)}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shrink-0 transition"
            >
              Switch to Ch {recommendedChannel.channel}
            </button>
          </div>
        )}
      </div>

      {/* Neighboring Overlapping Wi-Fi Networks */}
      <div className="rounded-2xl bg-slate-900/80 border border-slate-800/80 p-4">
        <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-2">
          Detected Neighbor Wi-Fi Networks ({NEIGHBOR_NETWORKS.length})
        </h3>
        <div className="space-y-1.5">
          {NEIGHBOR_NETWORKS.map((net, idx) => (
            <div
              key={idx}
              className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/60 flex items-center justify-between text-xs"
            >
              <div>
                <div className="font-semibold text-white">{net.ssid}</div>
                <div className="text-[10px] text-slate-400 font-mono">
                  BSSID: {net.bssid} · {net.security}
                </div>
              </div>
              <div className="text-right font-mono">
                <div className="text-cyan-400 font-bold">Ch {net.channel} ({net.band})</div>
                <div className="text-[10px] text-slate-500">{net.rssiDbm} dBm</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* DNS Benchmark & Switcher */}
      <div className="rounded-2xl bg-slate-900/80 border border-slate-800/80 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>DNS Resolver Latency Benchmark</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Fast DNS reduces initial web connection handshake times
            </p>
          </div>

          <button
            onClick={handleBenchmarkDns}
            disabled={isBenchmarkingDns}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs transition"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isBenchmarkingDns ? 'animate-spin' : ''}`} />
            <span>Retest</span>
          </button>
        </div>

        <div className="space-y-2">
          {dnsServers.map(dns => {
            const isFastest = dns.latencyMs <= 12;

            return (
              <div
                key={dns.name}
                className={`p-3 rounded-xl border flex items-center justify-between transition ${
                  dns.isCurrent
                    ? 'bg-cyan-950/20 border-cyan-500/40 shadow-sm'
                    : 'bg-slate-950/60 border-slate-800/60'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">{dns.name}</span>
                    {dns.isCurrent && (
                      <span className="text-[9px] font-bold text-cyan-400 bg-cyan-500/10 px-1.5 py-0.2 rounded">
                        ACTIVE
                      </span>
                    )}
                    {isFastest && !dns.isCurrent && (
                      <span className="text-[9px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.2 rounded">
                        FASTEST
                      </span>
                    )}
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                    {dns.primaryIp} · {dns.features}
                  </div>
                </div>

                <div className="flex items-center gap-2.5">
                  <div className="text-right">
                    <div className={`text-sm font-bold font-mono ${
                      dns.latencyMs < 15 ? 'text-emerald-400' : 'text-slate-300'
                    }`}>
                      {dns.latencyMs} ms
                    </div>
                  </div>

                  {!dns.isCurrent && (
                    <button
                      onClick={() => applyDnsServer(dns.name)}
                      className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition"
                    >
                      Use
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* MTU Size & Packet Fragmentation Test */}
      <div className="rounded-2xl bg-slate-900/80 border border-slate-800/80 p-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Maximum Transmission Unit (MTU)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Current MTU 1500 bytes (Ethernet Standard) · Zero fragmentation
            </p>
          </div>
          <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
            Optimal (1500)
          </span>
        </div>
      </div>
    </div>
  );
};
