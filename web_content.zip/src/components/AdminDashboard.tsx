"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ApiError, apiGet, apiPatch } from "@/lib/client/api";
import { Pill, Spinner, useToast } from "./ui";
import { TOOL_IDS, toolById } from "@/lib/ai/tools";
import type { PublicPlan } from "@/lib/plans";

type Stats = {
  totalUsers: number;
  paidUsers: number;
  freeUsers: number;
  activeSubscriptions: number;
  totalGenerations: number;
  mrrCents: number;
  arrCents: number;
  conversionRate: number;
};

type AdminPlan = PublicPlan & { id: number; isActive: boolean };

type Settings = {
  niches: string[];
  features: Record<string, boolean>;
  freeLimitBonus: number;
  burstLimitPerMinute: number;
  signupEnabled: boolean;
  announcement: string;
  brandName: string;
};

type Payload = {
  stats: Stats;
  popularTools: { tool: string; total: number }[];
  usageByDay: { day: string; total: number }[];
  plans: AdminPlan[];
  recentUsers: { id: number; email: string; name: string; planKey: string; createdAt: string }[];
  recentGenerations: { id: number; tool: string; topic: string; createdAt: string }[];
};

export default function AdminDashboard({ settings: initialSettings, plans: initialPlans }: { settings: Settings; plans: AdminPlan[] }) {
  const router = useRouter();
  const { show, node } = useToast();
  const [data, setData] = useState<Payload | null>(null);
  const [settings, setSettings] = useState(initialSettings);
  const [plans, setPlans] = useState(initialPlans);
  const [nicheDraft, setNicheDraft] = useState(initialSettings.niches.join(", "));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const res = await apiGet<Payload>("/api/admin/stats");
      setData(res);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not load stats");
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const saveSettings = async (patch: Partial<Settings>) => {
    setSaving(true);
    try {
      const res = await apiPatch<{ settings: Settings; plans: AdminPlan[] }>("/api/admin/settings", patch);
      setSettings(res.settings);
      if (res.plans) setPlans(res.plans);
      show("Settings saved");
      router.refresh();
    } catch (err) {
      show(err instanceof ApiError ? err.message : "Could not save", "bad");
    } finally {
      setSaving(false);
    }
  };

  const savePlans = async () => {
    setSaving(true);
    try {
      const res = await apiPatch<{ settings: Settings; plans: AdminPlan[] }>("/api/admin/settings", {
        plans: plans.map((p) => ({
          key: p.key,
          name: p.name,
          tagline: p.tagline,
          priceCents: p.priceCents,
          monthlyLimit: p.monthlyLimit,
          isActive: p.isActive,
          features: p.features,
        })),
      });
      setPlans(res.plans);
      show("Plans updated");
      router.refresh();
    } catch (err) {
      show(err instanceof ApiError ? err.message : "Could not save plans", "bad");
    } finally {
      setSaving(false);
    }
  };

  const money = (cents: number) => `$${(cents / 100).toFixed(2)}`;
  const maxDay = Math.max(1, ...(data?.usageByDay.map((d) => d.total) ?? [1]));

  return (
    <div className="space-y-5">
      {node}
      <div>
        <h1 className="text-2xl font-black">Admin dashboard</h1>
        <p className="text-sm text-[color:var(--muted)]">Users, revenue, usage and platform configuration.</p>
      </div>

      {error ? <p className="card p-4 text-sm text-rose-200">{error}</p> : null}

      <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          { label: "Total users", value: data?.stats.totalUsers ?? "—" },
          { label: "Free users", value: data?.stats.freeUsers ?? "—" },
          { label: "Paid users", value: data?.stats.paidUsers ?? "—" },
          { label: "Active subscriptions", value: data?.stats.activeSubscriptions ?? "—" },
          { label: "AI generations", value: data?.stats.totalGenerations ?? "—" },
          { label: "MRR", value: data ? money(data.stats.mrrCents) : "—" },
          { label: "ARR (projected)", value: data ? money(data.stats.arrCents) : "—" },
          { label: "Paid conversion", value: data ? `${data.stats.conversionRate}%` : "—" },
        ].map((card) => (
          <div key={card.label} className="card p-4">
            <p className="text-[0.65rem] uppercase tracking-wider text-[color:var(--muted)]">{card.label}</p>
            <p className="mt-1 text-xl font-bold">{card.value}</p>
          </div>
        ))}
      </section>

      <section className="grid gap-3 lg:grid-cols-2">
        <div className="card p-4">
          <p className="text-sm font-semibold">Popular tools</p>
          {!data?.popularTools.length ? (
            <p className="mt-2 text-xs text-[color:var(--muted)]">No generations yet.</p>
          ) : (
            <ul className="mt-3 space-y-2">
              {data.popularTools.map((row) => {
                const max = Math.max(...data.popularTools.map((t) => t.total));
                return (
                  <li key={row.tool}>
                    <div className="flex items-center justify-between text-xs">
                      <span>
                        {toolById(row.tool, settings.niches)?.emoji ?? "✨"} {toolById(row.tool, settings.niches)?.name ?? row.tool}
                      </span>
                      <span className="text-white/80">{row.total}</span>
                    </div>
                    <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-violet-400 to-cyan-300"
                        style={{ width: `${(row.total / max) * 100}%` }}
                      />
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        <div className="card p-4">
          <p className="text-sm font-semibold">Usage — last 7 days</p>
          {!data?.usageByDay.length ? (
            <p className="mt-2 text-xs text-[color:var(--muted)]">No usage recorded yet.</p>
          ) : (
            <div className="mt-4 flex h-32 items-end gap-2">
              {data.usageByDay.map((d) => (
                <div key={d.day} className="flex flex-1 flex-col items-center gap-1">
                  <div
                    className="w-full rounded-t-lg bg-gradient-to-t from-violet-500/40 to-cyan-300/70"
                    style={{ height: `${(d.total / maxDay) * 100}%` }}
                    title={`${d.total} credits`}
                  />
                  <span className="text-[0.6rem] text-[color:var(--muted)]">{d.day.slice(5)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="card p-4">
        <div className="flex items-center justify-between gap-2">
          <p className="text-sm font-semibold">Plans &amp; pricing</p>
          <button type="button" className="btn btn-primary btn-sm" onClick={savePlans} disabled={saving}>
            {saving ? <Spinner /> : "Save plans"}
          </button>
        </div>
        <div className="mt-3 grid gap-3 lg:grid-cols-3">
          {plans.map((plan, index) => (
            <div key={plan.key} className="rounded-xl border border-white/10 bg-black/25 p-3">
              <p className="text-xs uppercase tracking-wider text-[color:var(--muted)]">{plan.key}</p>
              <label className="label mt-2">Name</label>
              <input
                className="input"
                value={plan.name}
                onChange={(e) => {
                  const next = [...plans];
                  next[index] = { ...plan, name: e.target.value };
                  setPlans(next);
                }}
              />
              <label className="label mt-2">Price (cents / month)</label>
              <input
                type="number"
                min={0}
                className="input"
                value={plan.priceCents}
                onChange={(e) => {
                  const next = [...plans];
                  next[index] = { ...plan, priceCents: Number(e.target.value) };
                  setPlans(next);
                }}
              />
              <label className="label mt-2">Monthly generation limit</label>
              <input
                type="number"
                min={0}
                className="input"
                value={plan.monthlyLimit}
                onChange={(e) => {
                  const next = [...plans];
                  next[index] = { ...plan, monthlyLimit: Number(e.target.value) };
                  setPlans(next);
                }}
              />
              <label className="label mt-2">Feature bullets (one per line)</label>
              <textarea
                className="textarea"
                value={plan.features.join("\n")}
                onChange={(e) => {
                  const next = [...plans];
                  next[index] = { ...plan, features: e.target.value.split("\n") };
                  setPlans(next);
                }}
              />
              <label className="mt-2 flex items-center gap-2 text-xs text-[color:var(--muted)]">
                <input
                  type="checkbox"
                  checked={plan.isActive}
                  onChange={(e) => {
                    const next = [...plans];
                    next[index] = { ...plan, isActive: e.target.checked };
                    setPlans(next);
                  }}
                />
                Available for purchase
              </label>
            </div>
          ))}
        </div>
      </section>

      <section className="card space-y-4 p-4">
        <div className="flex items-center justify-between gap-2">
          <p className="text-sm font-semibold">Platform settings</p>
          <button
            type="button"
            className="btn btn-primary btn-sm"
            disabled={saving}
            onClick={() =>
              saveSettings({
                niches: nicheDraft.split(",").map((n) => n.trim()).filter(Boolean),
                freeLimitBonus: settings.freeLimitBonus,
                burstLimitPerMinute: settings.burstLimitPerMinute,
                signupEnabled: settings.signupEnabled,
                announcement: settings.announcement,
                brandName: settings.brandName,
                features: settings.features,
              })
            }
          >
            {saving ? <Spinner /> : "Save settings"}
          </button>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="brand">
              Brand name
            </label>
            <input id="brand" className="input" value={settings.brandName} onChange={(e) => setSettings({ ...settings, brandName: e.target.value })} />
          </div>
          <div>
            <label className="label" htmlFor="announce">
              Announcement banner
            </label>
            <input
              id="announce"
              className="input"
              value={settings.announcement}
              onChange={(e) => setSettings({ ...settings, announcement: e.target.value })}
            />
          </div>
          <div>
            <label className="label" htmlFor="bonus">
              Extra free credits (bonus on top of Free plan)
            </label>
            <input
              id="bonus"
              type="number"
              min={0}
              className="input"
              value={settings.freeLimitBonus}
              onChange={(e) => setSettings({ ...settings, freeLimitBonus: Number(e.target.value) })}
            />
          </div>
          <div>
            <label className="label" htmlFor="burst">
              Burst limit (credits per minute per user)
            </label>
            <input
              id="burst"
              type="number"
              min={1}
              className="input"
              value={settings.burstLimitPerMinute}
              onChange={(e) => setSettings({ ...settings, burstLimitPerMinute: Number(e.target.value) })}
            />
          </div>
        </div>

        <div>
          <label className="label" htmlFor="niches">
            Available niches (comma separated)
          </label>
          <textarea id="niches" className="textarea" value={nicheDraft} onChange={(e) => setNicheDraft(e.target.value)} />
        </div>

        <div>
          <p className="label">Tool availability</p>
          <div className="grid gap-2 sm:grid-cols-3">
            {TOOL_IDS.map((id) => (
              <label key={id} className="flex items-center gap-2 rounded-xl border border-white/10 bg-black/25 p-2 text-xs">
                <input
                  type="checkbox"
                  checked={settings.features[id] !== false}
                  onChange={(e) => setSettings({ ...settings, features: { ...settings.features, [id]: e.target.checked } })}
                />
                {toolById(id, settings.niches)?.name ?? id}
              </label>
            ))}
          </div>
        </div>

        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={settings.signupEnabled}
            onChange={(e) => setSettings({ ...settings, signupEnabled: e.target.checked })}
          />
          Allow new sign ups
        </label>
      </section>

      <section className="grid gap-3 lg:grid-cols-2">
        <div className="card p-4">
          <p className="text-sm font-semibold">Newest users</p>
          <ul className="mt-2 space-y-1 text-xs">
            {data?.recentUsers.map((u) => (
              <li key={u.id} className="flex items-center justify-between gap-2">
                <span className="truncate">
                  {u.name || "—"} · {u.email}
                </span>
                <Pill tone={u.planKey === "free" ? "default" : "brand"}>{u.planKey}</Pill>
              </li>
            ))}
          </ul>
        </div>
        <div className="card p-4">
          <p className="text-sm font-semibold">Latest generations</p>
          <ul className="mt-2 space-y-1 text-xs">
            {data?.recentGenerations.map((g) => (
              <li key={g.id} className="flex items-center justify-between gap-2">
                <span className="truncate">{g.topic || g.tool}</span>
                <span className="text-[color:var(--muted)]">{g.tool}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
}
