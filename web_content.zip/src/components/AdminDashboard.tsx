import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Users, 
  FileText, 
  Film, 
  Heart, 
  Trash2, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  RefreshCw, 
  Smartphone, 
  Database, 
  ExternalLink,
  Ban,
  Search
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useSocial } from '../context/SocialContext';
import { testConnection, getActiveFirebaseConfig } from '../firebase/config';
import { AndroidPackagingModal } from './AndroidPackagingModal';

interface AdminDashboardProps {
  onOpenProfile?: (userId: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onOpenProfile }) => {
  const { allUsers, user: currentUser, banUser, updateUserProfile } = useAuth();
  const { posts, reels, reports, deletePost, deleteReel, resolveReport } = useSocial();

  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'moderation' | 'firebase' | 'apk'>('overview');
  const [userSearch, setUserSearch] = useState('');
  const [contentSearch, setContentSearch] = useState('');
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);
  const [pingStatus, setPingStatus] = useState<string | null>(null);
  const [isPinging, setIsPinging] = useState(false);

  const firebaseConfig = getActiveFirebaseConfig();

  // Metrics
  const totalLikes = posts.reduce((acc, p) => acc + p.likesCount, 0) + reels.reduce((acc, r) => acc + r.likesCount, 0);
  const totalComments = posts.reduce((acc, p) => acc + p.commentsCount, 0) + reels.reduce((acc, r) => acc + r.commentsCount, 0);
  const totalInteractions = totalLikes + totalComments;

  const handlePing = async () => {
    setIsPinging(true);
    setPingStatus(null);
    try {
      const start = Date.now();
      const res = await testConnection();
      const latency = Date.now() - start;
      if (res.success) {
        setPingStatus(`Firestore online • ${latency}ms latency • 0 errors`);
      } else {
        setPingStatus(`Firestore offline cache: ${res.error || 'Check network'}`);
      }
    } catch (e: any) {
      setPingStatus(`Ping error: ${e.message}`);
    } finally {
      setIsPinging(false);
    }
  };

  const filteredUsers = allUsers.filter(u => 
    u.displayName.toLowerCase().includes(userSearch.toLowerCase()) ||
    u.username.toLowerCase().includes(userSearch.toLowerCase()) ||
    u.email.toLowerCase().includes(userSearch.toLowerCase())
  );

  const filteredPosts = posts.filter(p => 
    p.content.toLowerCase().includes(contentSearch.toLowerCase()) ||
    p.authorName.toLowerCase().includes(contentSearch.toLowerCase())
  );

  return (
    <div className="max-w-6xl mx-auto pb-16 space-y-6">
      
      {/* Top Banner */}
      <div className="bg-linear-to-r from-slate-900 via-slate-800 to-indigo-950 rounded-3xl p-5 sm:p-6 text-white shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
              <ShieldAlert className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight">FaceLook Owner & Admin Center</h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-300">
            Real-time management for users, media content, Firebase database health, and Android packaging.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsApkModalOpen(true)}
            className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-3.5 py-2 rounded-xl transition-colors cursor-pointer shadow-md"
          >
            <Smartphone className="w-4 h-4" />
            <span>Packaging Guide</span>
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        
        {/* Total Users */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Registered Users</span>
            <Users className="w-4 h-4 text-blue-600" />
          </div>
          <p className="text-2xl sm:text-3xl font-black text-slate-900">{allUsers.length}</p>
          <span className="text-[11px] text-emerald-600 font-semibold mt-1 block">Active members</span>
        </div>

        {/* Total Posts */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Feed Posts</span>
            <FileText className="w-4 h-4 text-indigo-600" />
          </div>
          <p className="text-2xl sm:text-3xl font-black text-slate-900">{posts.length}</p>
          <span className="text-[11px] text-slate-500 font-semibold mt-1 block">Photos & text published</span>
        </div>

        {/* Total Reels */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Short Reels</span>
            <Film className="w-4 h-4 text-rose-500" />
          </div>
          <p className="text-2xl sm:text-3xl font-black text-slate-900">{reels.length}</p>
          <span className="text-[11px] text-rose-600 font-semibold mt-1 block">Vertical video clips</span>
        </div>

        {/* Interactions */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/90 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider">Total Interactions</span>
            <Heart className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-2xl sm:text-3xl font-black text-slate-900">{totalInteractions}</p>
          <span className="text-[11px] text-amber-600 font-semibold mt-1 block">Likes & comments</span>
        </div>

      </div>

      {/* Tabs */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-1.5 flex items-center gap-1 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'overview' ? 'bg-[#1877F2] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Overview & Activity
        </button>

        <button
          onClick={() => setActiveTab('users')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'users' ? 'bg-[#1877F2] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          User Management ({allUsers.length})
        </button>

        <button
          onClick={() => setActiveTab('moderation')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'moderation' ? 'bg-[#1877F2] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Moderation & Reports ({reports.length})
        </button>

        <button
          onClick={() => setActiveTab('firebase')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'firebase' ? 'bg-[#1877F2] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Firebase Diagnostics
        </button>

        <button
          onClick={() => setActiveTab('apk')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'apk' ? 'bg-[#1877F2] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Android APK Workflow
        </button>
      </div>

      {/* TAB: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          
          {/* Recent Activity */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs">
            <h3 className="font-bold text-slate-900 text-sm mb-3">Live Content Stream</h3>
            <div className="space-y-3">
              {posts.slice(0, 4).map(p => (
                <div key={p.id} className="p-3 bg-slate-50 rounded-xl flex items-start justify-between gap-3 text-xs">
                  <div className="flex items-start gap-2.5">
                    <img src={p.authorPhotoURL} alt={p.authorName} className="w-8 h-8 rounded-full object-cover shrink-0" />
                    <div>
                      <p className="font-bold text-slate-900">{p.authorName} <span className="text-slate-400 font-normal">posted</span></p>
                      <p className="text-slate-600 line-clamp-1 mt-0.5">{p.content || '[Media Post]'}</p>
                    </div>
                  </div>
                  <span className="text-[10px] text-slate-400 font-medium shrink-0">
                    {new Date(p.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Quick System Health */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-4">
            <h3 className="font-bold text-slate-900 text-sm">System Health</h3>
            
            <div className="space-y-2 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                <span className="font-medium text-slate-700">Firestore Cloud Database</span>
                <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-md">Connected</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                <span className="font-medium text-slate-700">Firebase Security Rules</span>
                <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-md">Hardened & Deployed</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                <span className="font-medium text-slate-700">Android Gallery Upload Pipeline</span>
                <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-md">Ready (Image + Video)</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                <span className="font-medium text-slate-700">PWA Manifest Standalone</span>
                <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-md">Valid #1877F2</span>
              </div>
            </div>

            <button
              onClick={handlePing}
              disabled={isPinging}
              className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isPinging ? 'animate-spin' : ''}`} />
              <span>Run Firestore Diagnostics Ping</span>
            </button>
            {pingStatus && (
              <p className="text-xs font-medium text-center text-slate-600 mt-1">{pingStatus}</p>
            )}
          </div>

        </div>
      )}

      {/* TAB: USERS */}
      {activeTab === 'users' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
          
          <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <h3 className="font-bold text-slate-900 text-base">User Directory & Permissions</h3>
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                placeholder="Filter by name or email..."
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 rounded-xl border border-slate-200 focus:outline-hidden"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">User</th>
                  <th className="py-3 px-4">Email</th>
                  <th className="py-3 px-4">Role</th>
                  <th className="py-3 px-4">Joined</th>
                  <th className="py-3 px-4 text-right">Admin Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredUsers.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <img src={u.photoURL} alt={u.displayName} className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-200" />
                        <div>
                          <p className="font-bold text-slate-900 flex items-center gap-1">
                            {u.displayName}
                            {u.isVerified && <span className="text-blue-500 font-bold">✓</span>}
                          </p>
                          <p className="text-slate-400 text-[11px]">@{u.username}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600">{u.email}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${
                        u.role === 'admin' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {u.role}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-500">
                      {new Date(u.createdAt).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4 text-right space-x-1.5">
                      <button
                        onClick={() => onOpenProfile && onOpenProfile(u.id)}
                        className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold cursor-pointer"
                      >
                        Profile
                      </button>
                      <button
                        onClick={() => banUser(u.id, !u.bio?.includes('[Banned'))}
                        className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg font-semibold cursor-pointer"
                      >
                        {u.bio?.includes('[Banned') ? 'Unban' : 'Suspend'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>
      )}

      {/* TAB: MODERATION */}
      {activeTab === 'moderation' && (
        <div className="space-y-4">
          
          {/* Reports section */}
          <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5">
            <h3 className="font-bold text-slate-900 text-base mb-3 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-500" />
              <span>Flagged Content & Reports ({reports.length})</span>
            </h3>

            {reports.length === 0 ? (
              <p className="text-xs text-slate-500">No reports submitted. The community is clean!</p>
            ) : (
              <div className="space-y-2">
                {reports.map((rep) => (
                  <div key={rep.id} className="p-3 bg-amber-50/50 border border-amber-200 rounded-xl flex items-center justify-between text-xs">
                    <div>
                      <p className="font-bold text-slate-900">
                        {rep.targetType.toUpperCase()} reported by {rep.reporterName}
                      </p>
                      <p className="text-slate-600 mt-0.5">Reason: "{rep.reason}"</p>
                      <span className="text-[10px] text-slate-400 mt-1 block">ID: {rep.targetId}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        rep.status === 'resolved' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {rep.status}
                      </span>
                      {rep.status !== 'resolved' && (
                        <button
                          onClick={() => resolveReport(rep.id)}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-2.5 py-1 rounded-lg cursor-pointer"
                        >
                          Resolve
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Quick Content Moderation Table */}
          <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-slate-900 text-base">Direct Content Deletion</h3>
              <input
                type="text"
                value={contentSearch}
                onChange={(e) => setContentSearch(e.target.value)}
                placeholder="Search posts..."
                className="px-3 py-1.5 text-xs bg-slate-50 rounded-xl border border-slate-200"
              />
            </div>

            <div className="space-y-2 max-h-96 overflow-y-auto">
              {filteredPosts.map((p) => (
                <div key={p.id} className="p-3 bg-slate-50 rounded-xl flex items-center justify-between gap-3 text-xs border border-slate-100">
                  <div className="flex items-center gap-2.5 truncate">
                    <img src={p.authorPhotoURL} alt={p.authorName} className="w-8 h-8 rounded-full object-cover shrink-0" />
                    <div className="truncate">
                      <p className="font-bold text-slate-900">{p.authorName} <span className="text-slate-400 font-normal">(@{p.authorUsername})</span></p>
                      <p className="text-slate-600 truncate">{p.content || `[${p.mediaType} media]`}</p>
                    </div>
                  </div>

                  <button
                    onClick={() => deletePost(p.id)}
                    className="p-2 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 shrink-0 cursor-pointer"
                    title="Delete post permanently"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* TAB: FIREBASE DIAGNOSTICS */}
      {activeTab === 'firebase' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="font-bold text-slate-900 text-base">Firebase Cloud Architecture</h3>
              <p className="text-xs text-slate-500">Live configuration and diagnostic health check</p>
            </div>
            <button
              onClick={handlePing}
              disabled={isPinging}
              className="bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs px-3.5 py-2 rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isPinging ? 'animate-spin' : ''}`} />
              <span>Ping Cloud Firestore</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-slate-400 font-semibold block text-[10px]">PROJECT ID</span>
              <span className="font-mono text-slate-900 font-bold">{firebaseConfig.projectId}</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-slate-400 font-semibold block text-[10px]">DATABASE ID</span>
              <span className="font-mono text-slate-900 font-bold">{firebaseConfig.firestoreDatabaseId || '(default)'}</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-slate-400 font-semibold block text-[10px]">AUTH DOMAIN</span>
              <span className="font-mono text-slate-900 font-bold">{firebaseConfig.authDomain}</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-slate-400 font-semibold block text-[10px]">STORAGE BUCKET</span>
              <span className="font-mono text-slate-900 font-bold">{firebaseConfig.storageBucket}</span>
            </div>
          </div>

          <div className="p-4 bg-orange-50/70 border border-orange-200 rounded-xl text-xs text-orange-950 space-y-1.5 leading-relaxed">
            <p className="font-bold flex items-center gap-1 text-orange-900">
              <ShieldCheck className="w-4 h-4 text-orange-600" />
              Firebase Security Rules Status
            </p>
            <p>
              Your rules are active in <code className="font-mono font-bold">firestore.rules</code> and successfully deployed. Public read is permitted for user feeds, while writes and deletes are strictly guarded to authenticated users and administrators.
            </p>
          </div>
        </div>
      )}

      {/* TAB: APK */}
      {activeTab === 'apk' && (
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="font-bold text-slate-900 text-base">Android APK Free Build Workflows</h3>
              <p className="text-xs text-slate-500">Package FaceLook for Google Play Store or direct APK installation</p>
            </div>
            <button
              onClick={() => setIsApkModalOpen(true)}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2 rounded-xl transition-colors cursor-pointer"
            >
              Open Packaging Wizard
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/40">
              <h4 className="font-bold text-emerald-950 mb-1">1. PWABuilder (Zero Code)</h4>
              <p className="text-slate-600 leading-relaxed">
                Paste your app URL at pwabuilder.com. Microsoft's free cloud builder outputs a signed APK file in 60 seconds without installing Android Studio.
              </p>
            </div>

            <div className="p-4 rounded-xl border border-teal-200 bg-teal-50/40">
              <h4 className="font-bold text-teal-950 mb-1">2. Bubblewrap CLI (Google)</h4>
              <p className="text-slate-600 leading-relaxed">
                Use Google's official open-source tool: <code className="font-mono text-teal-800">npm i -g @bubblewrap/cli</code>. Wraps your PWA into a native Android APK with full screen support.
              </p>
            </div>

            <div className="p-4 rounded-xl border border-blue-200 bg-blue-50/40">
              <h4 className="font-bold text-blue-950 mb-1">3. Capacitor Native Studio</h4>
              <p className="text-slate-600 leading-relaxed">
                Run <code className="font-mono text-blue-800">npx cap add android</code> to generate full Java/Kotlin Android Studio projects for custom native hardware APIs.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* APK Modal */}
      <AndroidPackagingModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />

    </div>
  );
};
