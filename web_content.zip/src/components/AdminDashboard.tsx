import React, { useState, useEffect } from 'react';
import { UserProfile, Room, PaymentRequest } from '../types';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { reviewTopupFn, walletErrorMessage } from '../wallet';
import { AdminWithdrawals } from './AdminWithdrawals';
import { 
  collection, 
  onSnapshot, 
  doc, 
  updateDoc, 
  deleteDoc, 
  increment,
  runTransaction,
  query,
  orderBy,
  limit 
} from 'firebase/firestore';
import { 
  ShieldCheck, 
  Users, 
  Radio, 
  Gift, 
  Wallet, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Search, 
  Trash2, 
  Check, 
  X, 
  Clock, 
  Phone, 
  Copy, 
  RefreshCw, 
  Sparkles,
  UserX,
  BadgeAlert
} from 'lucide-react';
import { AVAILABLE_GIFTS } from '../gifts';

interface AdminDashboardProps {
  currentUser: UserProfile;
  onClose: () => void;
  showToast: (msg: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ 
  currentUser, 
  onClose,
  showToast 
}) => {
  const [activeTab, setActiveTab] = useState<'payments' | 'withdrawals' | 'users' | 'rooms' | 'gifts'>('payments');
  
  // Real data from Firestore
  const [paymentRequests, setPaymentRequests] = useState<PaymentRequest[]>([]);
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [allRooms, setAllRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  // Search & Filters
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [flaggedOnly, setFlaggedOnly] = useState(false);
  const [paymentFilter, setPaymentFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');

  // Confirmation modal state
  const [userToDelete, setUserToDelete] = useState<UserProfile | null>(null);
  const [roomToDelete, setRoomToDelete] = useState<Room | null>(null);

  // 1. Listen to real Payment Requests in Firestore
  useEffect(() => {
    const paymentsRef = collection(db, 'payment_requests');
    const unsub = onSnapshot(paymentsRef, (snapshot) => {
      const list: PaymentRequest[] = [];
      snapshot.forEach((d) => {
        list.push({ id: d.id, ...d.data() } as PaymentRequest);
      });
      // Sort pending first, then by date
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setPaymentRequests(list);
      setLoading(false);
    }, (err) => {
      console.warn('Payment requests listener error:', err);
      setLoading(false);
    });
    return () => unsub();
  }, []);

  // 2. Listen to real users in Firestore
  useEffect(() => {
    const usersRef = collection(db, 'users');
    const unsub = onSnapshot(usersRef, (snapshot) => {
      const list: UserProfile[] = [];
      snapshot.forEach((d) => {
        list.push({ uid: d.id, ...d.data() } as UserProfile);
      });
      setAllUsers(list);
    }, (err) => {
      console.warn('Users listener error:', err);
    });
    return () => unsub();
  }, []);

  // 3. Listen to real rooms in Firestore
  useEffect(() => {
    const roomsRef = collection(db, 'rooms');
    const unsub = onSnapshot(roomsRef, (snapshot) => {
      const list: Room[] = [];
      snapshot.forEach((d) => {
        list.push({ id: d.id, ...d.data() } as Room);
      });
      setAllRooms(list);
    }, (err) => {
      console.warn('Rooms listener error:', err);
    });
    return () => unsub();
  }, []);

  // Approve / reject a Vodafone Cash top-up. The server verifies the request is still
  // pending, takes the amounts from its own package table and credits the wallet.
  const handleApprovePayment = async (req: PaymentRequest) => {
    setActionLoading(req.id);
    try {
      await reviewTopupFn(req.id, 'approve');
      showToast(`✓ تمت الموافقة على طلب ${req.userDisplayName} وإضافة الرصيد`);
    } catch (err) {
      console.error('Approve payment error:', err);
      showToast(walletErrorMessage(err));
    } finally {
      setActionLoading(null);
    }
  };

  const handleRejectPayment = async (req: PaymentRequest) => {
    setActionLoading(req.id);
    try {
      await reviewTopupFn(req.id, 'reject');
      showToast(`تم رفض طلب الشحن للعملية (${req.transactionReference})`);
    } catch (err) {
      console.error('Reject payment error:', err);
      showToast(walletErrorMessage(err));
    } finally {
      setActionLoading(null);
    }
  };

  // Delete suspicious user after owner confirmation
  const handleConfirmDeleteUser = async () => {
    if (!userToDelete) return;
    setActionLoading(userToDelete.uid);
    try {
      await deleteDoc(doc(db, 'users', userToDelete.uid));
      setAllUsers((prev) => prev.filter((u) => u.uid !== userToDelete.uid));
      showToast(`تم حذف الحساب (${userToDelete.displayName}) بنجاح`);
    } catch (err) {
      console.error('Delete user error:', err);
      showToast('حدث خطأ أثناء حذف الحساب');
    } finally {
      setActionLoading(null);
      setUserToDelete(null);
    }
  };

  // Delete abusive room
  const handleConfirmDeleteRoom = async () => {
    if (!roomToDelete) return;
    setActionLoading(roomToDelete.id);
    try {
      await deleteDoc(doc(db, 'rooms', roomToDelete.id));
      setAllRooms((prev) => prev.filter((r) => r.id !== roomToDelete.id));
      showToast(`تم إغلاق وحذف الغرفة (${roomToDelete.title}) بنجاح`);
    } catch (err) {
      console.error('Delete room error:', err);
      showToast('حدث خطأ أثناء إغلاق الغرفة');
    } finally {
      setActionLoading(null);
      setRoomToDelete(null);
    }
  };

  // Detect suspicious accounts (no name or generic dummy patterns)
  const isSuspicious = (u: UserProfile) => {
    const name = (u.displayName || '').trim().toLowerCase();
    const username = (u.username || '').trim().toLowerCase();
    return (
      name.length < 2 ||
      name.includes('test') ||
      name.includes('bot') ||
      username.includes('test_bot') ||
      (u.coins === 0 && u.flowersCount === 0 && !u.photoURL)
    );
  };

  // Filter users
  const filteredUsers = allUsers.filter((u) => {
    const matchesSearch =
      (u.displayName || '').toLowerCase().includes(userSearchQuery.toLowerCase()) ||
      (u.email || '').toLowerCase().includes(userSearchQuery.toLowerCase()) ||
      (u.username || '').toLowerCase().includes(userSearchQuery.toLowerCase());
    if (flaggedOnly) {
      return matchesSearch && isSuspicious(u);
    }
    return matchesSearch;
  });

  const isOwner = currentUser.email?.toLowerCase() === 'smsmsohag20@gmail.com' || currentUser.email?.toLowerCase() === 'smsm.sohag@gmail.com';
  const pendingCount = paymentRequests.filter((p) => p.status === 'pending').length;

  if (!isOwner) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-white/90 backdrop-blur-md">
        <div className="bg-slate-50 border border-red-500/30 rounded-3xl p-6 text-center max-w-sm">
          <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-900 mb-2">غير مصرح بالدخول</h3>
          <p className="text-xs text-slate-500 mb-4">هذه اللوحة مخصصة فقط لمالك التطبيق المعتمد (smsmsohag20@gmail.com).</p>
          <button onClick={onClose} className="px-5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-900 text-xs font-bold cursor-pointer">إغلاق</button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-white/80 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-4xl h-[92vh] rounded-3xl bg-slate-50 border border-purple-500/30 shadow-2xl flex flex-col overflow-hidden text-slate-800 font-['Cairo']">
        
        {/* Top Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-gradient-to-r from-purple-950/80 via-slate-50 to-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-pink-600 flex items-center justify-center text-white shadow-lg shadow-purple-900/40">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-slate-900">
                  لوحة تحكم المالك والمدير العام
                </h2>
                <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-600 border border-emerald-500/30 font-bold">
                  صلاحيات كاملة 👑
                </span>
              </div>
              <p className="text-xs text-purple-600/80 mt-0.5">
                المالك المعتمد: {currentUser.email}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 p-3 sm:p-4 bg-white/60 border-b border-slate-200/80 text-xs">
          <div className="p-3 rounded-2xl bg-slate-50/90 border border-slate-200">
            <span className="text-slate-500 block text-[11px]">طلبات الشحن المعلقة</span>
            <span className="text-lg font-black text-amber-600 mt-1 block">
              {pendingCount} طلب
            </span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50/90 border border-slate-200">
            <span className="text-slate-500 block text-[11px]">إجمالي المستخدمين</span>
            <span className="text-lg font-black text-slate-900 mt-1 block">
              {allUsers.length} مستخدم
            </span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50/90 border border-slate-200">
            <span className="text-slate-500 block text-[11px]">الغرف النشطة</span>
            <span className="text-lg font-black text-rose-500 mt-1 block">
              {allRooms.length} غرفة
            </span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50/90 border border-slate-200">
            <span className="text-slate-500 block text-[11px]">رقم فودافون كاش المعتمد</span>
            <span className="text-sm font-black text-emerald-600 mt-1 block tracking-wider font-mono">
              01066257254
            </span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1.5 px-4 pt-3 border-b border-slate-200 bg-slate-50/60 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab('payments')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-2xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
              activeTab === 'payments'
                ? 'bg-slate-100 text-amber-600 border-t-2 border-amber-400 shadow-md'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Wallet className="w-4 h-4" />
            <span>طلبات فودافون كاش</span>
            {pendingCount > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-amber-500 text-slate-950 text-[10px] font-black">
                {pendingCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('users')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-2xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
              activeTab === 'users'
                ? 'bg-slate-100 text-purple-500 border-t-2 border-purple-400 shadow-md'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>إدارة الحسابات والحماية ({allUsers.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('rooms')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-2xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
              activeTab === 'rooms'
                ? 'bg-slate-100 text-rose-500 border-t-2 border-rose-400 shadow-md'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Radio className="w-4 h-4" />
            <span>إدارة الغرف الصوتية ({allRooms.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('gifts')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-2xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
              activeTab === 'gifts'
                ? 'bg-slate-100 text-pink-500 border-t-2 border-pink-400 shadow-md'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Gift className="w-4 h-4" />
            <span>كتالوج الهدايا ({AVAILABLE_GIFTS.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('withdrawals')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-2xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
              activeTab === 'withdrawals'
                ? 'bg-slate-100 text-emerald-600 border-t-2 border-emerald-500 shadow-md'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <span>💸 طلبات السحب</span>
          </button>
        </div>

        {activeTab === 'withdrawals' && <AdminWithdrawals showToast={showToast} />}

        {/* Tab 1: Vodafone Cash Payments */}
        {activeTab === 'payments' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs">
              <div className="flex items-center gap-2 text-amber-700">
                <Phone className="w-4 h-4 shrink-0" />
                <span>
                  الرقم المخصص لاستلام التحويلات: <strong className="font-mono text-slate-900 text-sm">01066257254</strong>
                </span>
              </div>
              <span className="text-[11px] text-amber-600 font-medium">
                لا يتم شحن الرصيد إلا بعد مطابقة مرجع التحويل يدوياً بواسطة المالك.
              </span>
            </div>

            {/* Filter buttons */}
            <div className="flex items-center gap-2">
              {(['all', 'pending', 'approved', 'rejected'] as const).map((status) => (
                <button
                  key={status}
                  onClick={() => setPaymentFilter(status)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    paymentFilter === status
                      ? 'bg-amber-500 text-slate-950 shadow-md'
                      : 'bg-slate-100 text-slate-500 hover:text-slate-900'
                  }`}
                >
                  {status === 'all' && 'الكل'}
                  {status === 'pending' && `معلق (${pendingCount})`}
                  {status === 'approved' && 'مقبول'}
                  {status === 'rejected' && 'مرفوض'}
                </button>
              ))}
            </div>

            {paymentRequests.filter((p) => paymentFilter === 'all' || p.status === paymentFilter).length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs">
                <Clock className="w-10 h-10 mx-auto text-slate-700 mb-2" />
                <span>لا توجد طلبات شحن في هذا القسم</span>
              </div>
            ) : (
              paymentRequests
                .filter((p) => paymentFilter === 'all' || p.status === paymentFilter)
                .map((req) => (
                  <div
                    key={req.id}
                    className="p-4 rounded-2xl bg-white/80 border border-slate-200 hover:border-slate-200 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-slate-900">
                          {req.userDisplayName}
                        </span>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                          req.status === 'pending'
                            ? 'bg-amber-500/20 text-amber-700 border border-amber-500/30'
                            : req.status === 'approved'
                              ? 'bg-emerald-500/20 text-emerald-600 border border-emerald-500/30'
                              : 'bg-red-500/20 text-red-600 border border-red-500/30'
                        }`}>
                          {req.status === 'pending' && 'قيد المراجعة ⏳'}
                          {req.status === 'approved' && 'تم الشحن ✓'}
                          {req.status === 'rejected' && 'مرفوض ✕'}
                        </span>
                      </div>

                      <div className="text-xs text-slate-500 flex flex-wrap items-center gap-3">
                        <span>رقم المحوّل: <strong className="text-slate-900 font-mono">{req.senderNumber}</strong></span>
                        <span>•</span>
                        <span>كود العملية / المرجع: <strong className="text-amber-700 font-mono">{req.transactionReference}</strong></span>
                        <span>•</span>
                        <span>المبلغ: <strong className="text-emerald-600">{req.amountEGP} ج.م</strong></span>
                        <span>•</span>
                        <span>الباقة: 🪙 {req.coins} عملة و 🌸 {req.flowers} زهرة</span>
                      </div>

                      <div className="text-[10px] text-slate-500">
                        تاريخ الطلب: {new Date(req.createdAt).toLocaleString('ar-EG')}
                      </div>
                    </div>

                    {req.status === 'pending' && (
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          disabled={actionLoading === req.id}
                          onClick={() => handleApprovePayment(req)}
                          className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-950/40 cursor-pointer transition-all"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>تأكيد وشحن الرصيد</span>
                        </button>

                        <button
                          disabled={actionLoading === req.id}
                          onClick={() => handleRejectPayment(req)}
                          className="px-3 py-2 rounded-xl bg-red-600/80 hover:bg-red-600 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-1 cursor-pointer transition-all"
                        >
                          <X className="w-3.5 h-3.5" />
                          <span>رفض</span>
                        </button>
                      </div>
                    )}
                  </div>
                ))
            )}
          </div>
        )}

        {/* Tab 2: Users Management & Anti-Abuse */}
        {activeTab === 'users' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {/* Search and Suspicious Filter */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-500 absolute right-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={userSearchQuery}
                  onChange={(e) => setUserSearchQuery(e.target.value)}
                  placeholder="بحث بالاسم أو البريد الإلكتروني..."
                  className="w-full bg-white border border-slate-200 rounded-xl pr-9 pl-3 py-2 text-xs text-slate-900 placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>

              <button
                onClick={() => setFlaggedOnly(!flaggedOnly)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  flaggedOnly
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                <AlertTriangle className="w-4 h-4" />
                <span>الحسابات المشبوهة فقط</span>
              </button>
            </div>

            {/* Users list */}
            <div className="space-y-2">
              {filteredUsers.map((u) => {
                const suspicious = isSuspicious(u);
                return (
                  <div
                    key={u.uid}
                    className={`p-3.5 rounded-2xl border flex items-center justify-between transition-colors ${
                      suspicious
                        ? 'bg-amber-950/20 border-amber-500/30'
                        : 'bg-white/70 border-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={u.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${u.uid}`}
                        alt={u.displayName}
                        className="w-10 h-10 rounded-full object-cover border border-slate-200"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900">
                            {u.displayName || 'بدون اسم'}
                          </span>
                          {suspicious && (
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-700 border border-amber-500/30 flex items-center gap-1">
                              <BadgeAlert className="w-3 h-3" />
                              <span>مشبوه للمراجعة</span>
                            </span>
                          )}
                          {(u.email === 'smsmsohag20@gmail.com' || u.email === 'smsm.sohag@gmail.com') && (
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-600 font-bold">
                              المالك 👑
                            </span>
                          )}
                        </div>

                        <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                          <span>{u.email || u.username || u.uid.slice(0, 8)}</span>
                          <span>•</span>
                          <span className="text-amber-600 font-semibold">{u.coins || 0} 🪙</span>
                          <span>•</span>
                          <span className="text-pink-500 font-semibold">{u.flowersCount || 0} 🌸</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {!(u.email === 'smsmsohag20@gmail.com' || u.email === 'smsm.sohag@gmail.com') && (
                        <button
                          onClick={() => setUserToDelete(u)}
                          className="p-2 rounded-xl bg-red-500/15 hover:bg-red-500/30 text-red-500 transition-colors cursor-pointer"
                          title="حذف هذا الحساب نهائياً"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Tab 3: Rooms Management */}
        {activeTab === 'rooms' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {allRooms.map((room) => (
                <div
                  key={room.id}
                  className="p-4 rounded-2xl bg-white/80 border border-slate-200 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-2xl">{room.icon}</span>
                      <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                        {room.category}
                      </span>
                    </div>
                    <h4 className="text-sm font-bold text-slate-900 line-clamp-1">{room.title}</h4>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">{room.description}</p>
                    <div className="text-[11px] text-slate-500 mt-2">
                      المضيف: <strong className="text-slate-600">{room.hostName}</strong>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-200/80 flex items-center justify-between">
                    <span className="text-xs text-slate-500">
                      {room.participantsCount || 1} متواجد
                    </span>
                    <button
                      onClick={() => setRoomToDelete(room)}
                      className="px-3 py-1.5 rounded-xl bg-red-600/10 hover:bg-red-600 text-red-600 hover:text-white text-xs font-bold transition-all cursor-pointer flex items-center gap-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>إغلاق وحذف الغرفة</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 4: Gifts Catalog */}
        {activeTab === 'gifts' && (
          <div className="flex-1 overflow-y-auto p-4">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {AVAILABLE_GIFTS.map((g) => (
                <div
                  key={g.id}
                  className="p-3.5 rounded-2xl bg-white border border-slate-200 flex flex-col items-center text-center"
                >
                  <span className="text-4xl my-1">{g.icon}</span>
                  <h4 className="text-xs font-bold text-slate-900 mt-1">{g.name}</h4>
                  <p className="text-[10px] text-slate-500 mt-0.5">{g.description}</p>
                  <div className="mt-2.5 pt-2 border-t border-slate-200 w-full flex items-center justify-around text-xs font-bold">
                    <span className="text-amber-600">{g.costCoins} 🪙</span>
                    <span className="text-pink-500">{g.cost} 🌸</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>

      {/* User Deletion Confirmation Dialog */}
      {userToDelete && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-sm rounded-3xl bg-slate-50 border border-red-500/30 p-6 shadow-2xl text-center space-y-4">
            <div className="w-14 h-14 mx-auto rounded-full bg-red-500/20 text-red-500 flex items-center justify-center">
              <UserX className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">تأكيد حذف الحساب نهائياً</h3>
              <p className="text-xs text-slate-500 mt-1">
                هل أنت متأكد من حذف حساب "{userToDelete.displayName}"؟ هذا الإجراء لا يمكن التراجع عنه.
              </p>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                disabled={actionLoading === userToDelete.uid}
                onClick={handleConfirmDeleteUser}
                className="flex-1 py-2 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white font-bold text-xs cursor-pointer"
              >
                نعم، احذف الحساب
              </button>
              <button
                onClick={() => setUserToDelete(null)}
                className="flex-1 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Room Deletion Confirmation Dialog */}
      {roomToDelete && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-sm rounded-3xl bg-slate-50 border border-red-500/30 p-6 shadow-2xl text-center space-y-4">
            <div className="w-14 h-14 mx-auto rounded-full bg-red-500/20 text-red-500 flex items-center justify-center">
              <Radio className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">إغلاق الغرفة وحذفها</h3>
              <p className="text-xs text-slate-500 mt-1">
                هل تريد بالتأكيد إغلاق غرفة "{roomToDelete.title}" وحذفها من التطبيق؟
              </p>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <button
                disabled={actionLoading === roomToDelete.id}
                onClick={handleConfirmDeleteRoom}
                className="flex-1 py-2 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white font-bold text-xs cursor-pointer"
              >
                نعم، إغلاق وحذف
              </button>
              <button
                onClick={() => setRoomToDelete(null)}
                className="flex-1 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
