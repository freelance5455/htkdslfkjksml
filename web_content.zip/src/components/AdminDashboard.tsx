import React, { useState, useEffect } from 'react';
import {
  Users, UserPlus, ShieldAlert, Flag, MessageSquare, Settings as SettingsIcon,
  LogOut, Search, CheckCircle2, XCircle, ShieldCheck, KeyRound, Trash2,
  RefreshCw, Lock, AlertTriangle, ExternalLink, Calendar,
  History, ArrowLeft, Eye, Check, Bot, Sparkles, Play
} from 'lucide-react';
import { api } from '../services/api.ts';
import type { User, Report, AuditLog, AppSettings, BanRecord, AIAgentConfig } from '../types/index.ts';
import { BlueTick } from './BlueTick.tsx';

interface AdminDashboardProps {
  onClose: () => void;
  onLogout: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onClose, onLogout }) => {
  const [activeTab, setActiveTab] = useState<'users' | 'create' | 'reports' | 'groups' | 'audit' | 'settings' | 'ai-agent'>('users');
  const [users, setUsers] = useState<User[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'banned' | 'verified'>('all');

  // AI Agent Training State
  const [aiConfig, setAiConfig] = useState<AIAgentConfig | null>(null);
  const [aiName, setAiName] = useState('Unknown Gamer AI Support');
  const [aiSystemPrompt, setAiSystemPrompt] = useState('');
  const [aiKnowledge, setAiKnowledge] = useState('');
  const [aiActive, setAiActive] = useState(true);
  const [aiSaveStatus, setAiSaveStatus] = useState<string | null>(null);
  const [testPrompt, setTestPrompt] = useState('');
  const [testReply, setTestReply] = useState<string | null>(null);
  const [testingAI, setTestingAI] = useState(false);

  // Modals inside Admin
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [banningUser, setBanningUser] = useState<User | null>(null);
  const [banType, setBanType] = useState<'temporary' | 'permanent'>('temporary');
  const [banDuration, setBanDuration] = useState('7');
  const [banReason, setBanReason] = useState('');

  const [createdCredentials, setCreatedCredentials] = useState<{ username: string; tempPass: string } | null>(null);
  const [resetPassResult, setResetPassResult] = useState<{ username: string; tempPass: string } | null>(null);

  // New User Form State
  const [newFullName, setNewFullName] = useState('');
  const [newUsername, setNewUsername] = useState('');
  const [newTempPassword, setNewTempPassword] = useState('');
  const [newBio, setNewBio] = useState('Unknown Gamer Clan Recruit');
  const [newVerified, setNewVerified] = useState(false);
  const [newStatus, setNewStatus] = useState<'active' | 'banned'>('active');
  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);

  // Settings State
  const [serviceNumber, setServiceNumber] = useState('');
  const [serviceUrl, setServiceUrl] = useState('');
  const [appVersion, setAppVersion] = useState('');
  const [systemNotice, setSystemNotice] = useState('');
  const [currentAdminKey, setCurrentAdminKey] = useState('');
  const [newAdminKey, setNewAdminKey] = useState('');
  const [keyChangeStatus, setKeyChangeStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Clan Groups State
  const [allGroups, setAllGroups] = useState<any[]>([]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [usersData, reportsData, logsData, settingsData, statsData] = await Promise.all([
        api.getAdminUsers(),
        api.getAdminReports(),
        api.getAuditLogs(),
        api.getAdminSettings(),
        api.getAdminStats(),
      ]);
      setUsers(usersData || []);
      setReports(reportsData || []);
      setAuditLogs(logsData || []);
      setSettings(settingsData || null);
      setStats(statsData || null);

      if (settingsData) {
        setServiceNumber(settingsData.whatsappServiceNumber);
        setServiceUrl(settingsData.whatsappUrl);
        setAppVersion(settingsData.appVersion);
        setSystemNotice(settingsData.systemNotice || '');
      }

      // Fetch AI Agent Config
      const aiData = await api.getAIAgentConfig();
      setAiConfig(aiData || null);
      if (aiData) {
        setAiName(aiData.name);
        setAiSystemPrompt(aiData.systemPrompt);
        setAiKnowledge(aiData.knowledgeBase);
        setAiActive(aiData.isActive);
      }

      // Fetch groups by getting chats of first user or querying
      const sampleChats = await api.getChats(usersData[0]?.id || 'usr_shadow_01');
      setAllGroups(sampleChats.filter(c => c.type === 'group'));
    } catch (err) {
      console.error('Failed to load admin data', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveAITraining = async (e: React.FormEvent) => {
    e.preventDefault();
    setAiSaveStatus(null);
    try {
      const res = await api.updateAIAgentConfig({
        name: aiName.trim() || 'Unknown Gamer AI Support',
        systemPrompt: aiSystemPrompt.trim(),
        knowledgeBase: aiKnowledge.trim(),
        isActive: aiActive,
      });
      if (res.success) {
        setAiConfig(res.config);
        setAiSaveStatus('AI Agent training saved successfully! Bot is updated across all player chats.');
        loadData();
        setTimeout(() => setAiSaveStatus(null), 4000);
      }
    } catch {
      alert('Failed to save AI training');
    }
  };

  const handleTestAI = async () => {
    if (!testPrompt.trim()) return;
    setTestingAI(true);
    setTestReply(null);
    try {
      const res = await api.testAIAgent(testPrompt, aiSystemPrompt, aiKnowledge);
      if (res.success) {
        setTestReply(res.reply);
      } else {
        setTestReply('Failed to get response');
      }
    } catch {
      setTestReply('Error contacting AI server');
    } finally {
      setTestingAI(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setFormSuccess(null);

    if (!newFullName.trim() || !newUsername.trim()) {
      setFormError('Full Name and Username are required');
      return;
    }

    const assignedTempPass = newTempPassword.trim() || 'gamer' + Math.floor(1000 + Math.random() * 9000);

    try {
      const res = await api.createAdminUser({
        fullName: newFullName.trim(),
        username: newUsername.trim(),
        temporaryPassword: assignedTempPass,
        bio: newBio.trim(),
        verifiedBlueTick: newVerified,
        status: newStatus,
      });

      if (res.success && res.user) {
        setCreatedCredentials({
          username: res.user.username,
          tempPass: assignedTempPass,
        });
        setNewFullName('');
        setNewUsername('');
        setNewTempPassword('');
        setNewBio('Unknown Gamer Clan Recruit');
        setNewVerified(false);
        loadData();
      } else {
        setFormError(res.error || 'Failed to create user');
      }
    } catch {
      setFormError('Failed to communicate with server');
    }
  };

  const handleToggleBlueTick = async (user: User) => {
    const nextState = !user.verifiedBlueTick;
    await api.toggleBlueTick(user.id, nextState);
    setUsers(prev => prev.map(u => u.id === user.id ? { ...u, verifiedBlueTick: nextState } : u));
    loadData();
  };

  const handleResetPassword = async (user: User) => {
    const generated = 'gamer' + Math.floor(1000 + Math.random() * 9000);
    const res = await api.resetUserPassword(user.id, generated);
    if (res.success) {
      setResetPassResult({
        username: user.username,
        tempPass: res.temporaryPassword || generated,
      });
      loadData();
    }
  };

  const handleBanSubmit = async () => {
    if (!banningUser) return;
    const res = await api.banUser(banningUser.id, {
      banType,
      durationDays: banType === 'temporary' ? parseInt(banDuration, 10) : undefined,
      reason: banReason || 'Violation of esports gaming rules',
    });

    if (res.success) {
      setBanningUser(null);
      setBanReason('');
      loadData();
    }
  };

  const handleUnban = async (userId: string) => {
    const res = await api.unbanUser(userId);
    if (res.success) {
      loadData();
    }
  };

  const handleDeleteUser = async (user: User) => {
    if (confirm(`Are you sure you want to permanently delete user @${user.username}?`)) {
      await api.deleteUser(user.id);
      loadData();
    }
  };

  const handleResolveReport = async (reportId: string, status: 'action_taken' | 'dismissed') => {
    await api.resolveReport(reportId, status);
    loadData();
  };

  const handleDeleteGroup = async (groupId: string, name?: string) => {
    if (confirm(`Delete clan squad "${name || 'Group'}"? This cannot be undone.`)) {
      await api.deleteGroup(groupId);
      loadData();
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    await api.updateAdminSettings({
      whatsappServiceNumber: serviceNumber,
      whatsappUrl: serviceUrl,
      appVersion,
      systemNotice,
    });
    alert('Settings saved successfully');
    loadData();
  };

  const handleChangeAdminKey = async (e: React.FormEvent) => {
    e.preventDefault();
    setKeyChangeStatus(null);
    try {
      const res = await api.changeAdminKey(currentAdminKey, newAdminKey);
      if (res.success) {
        setKeyChangeStatus({ type: 'success', message: 'Admin Key successfully updated!' });
        setCurrentAdminKey('');
        setNewAdminKey('');
      } else {
        setKeyChangeStatus({ type: 'error', message: res.error || 'Failed to update Admin Key' });
      }
    } catch {
      setKeyChangeStatus({ type: 'error', message: 'Server communication error' });
    }
  };

  const filteredUsers = users.filter(u => {
    const matchesSearch = u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          u.fullName.toLowerCase().includes(searchQuery.toLowerCase());
    if (!matchesSearch) return false;

    if (filterStatus === 'active') return u.status === 'active';
    if (filterStatus === 'banned') return u.status === 'banned';
    if (filterStatus === 'verified') return u.verifiedBlueTick;
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#07090e] text-slate-100 overflow-hidden font-sans">
      {/* Top Gaming Command Bar */}
      <header className="h-16 px-4 md:px-6 bg-[#0a0f18] border-b border-cyan-500/30 flex items-center justify-between shrink-0 shadow-[0_4px_20px_rgba(0,210,255,0.1)]">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:border-cyan-500/40 transition-colors"
            title="Return to App"
          >
            <ArrowLeft size={18} />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-500/60 flex items-center justify-center text-cyan-400 shadow-[0_0_10px_rgba(0,210,255,0.3)]">
              <ShieldAlert size={18} />
            </div>
            <div>
              <h1 className="text-base font-extrabold tracking-wider uppercase text-white font-display flex items-center gap-2">
                Unknown Gamer
                <span className="text-[10px] font-semibold tracking-widest text-cyan-400 bg-cyan-950/80 border border-cyan-500/40 px-2 py-0.5 rounded">
                  ADMIN CONSOLE
                </span>
              </h1>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadData}
            className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-cyan-400 border border-slate-800 transition-colors"
            title="Refresh Data"
          >
            <RefreshCw size={18} className={loading ? 'animate-spin text-cyan-400' : ''} />
          </button>
          <button
            onClick={onLogout}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-red-950/40 hover:bg-red-900/60 border border-red-500/40 text-red-300 text-xs font-semibold transition-colors"
          >
            <LogOut size={16} />
            <span className="hidden sm:inline">Admin Logout</span>
          </button>
        </div>
      </header>

      {/* Main Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <aside className="w-16 md:w-56 bg-[#090d15] border-r border-slate-800/80 flex flex-col shrink-0">
          <nav className="p-2 md:p-3 space-y-1.5 flex-1">
            <button
              onClick={() => setActiveTab('users')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'users'
                  ? 'bg-gradient-to-r from-cyan-950 to-blue-950 text-cyan-300 border border-cyan-500/40 shadow-[0_0_15px_rgba(0,210,255,0.15)]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <Users size={18} className={activeTab === 'users' ? 'text-cyan-400' : ''} />
              <span className="hidden md:inline">Users Directory</span>
            </button>

            <button
              onClick={() => setActiveTab('create')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'create'
                  ? 'bg-gradient-to-r from-cyan-950 to-blue-950 text-cyan-300 border border-cyan-500/40 shadow-[0_0_15px_rgba(0,210,255,0.15)]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <UserPlus size={18} className={activeTab === 'create' ? 'text-cyan-400' : ''} />
              <span className="hidden md:inline">Create User</span>
            </button>

            <button
              onClick={() => setActiveTab('reports')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'reports'
                  ? 'bg-gradient-to-r from-cyan-950 to-blue-950 text-cyan-300 border border-cyan-500/40 shadow-[0_0_15px_rgba(0,210,255,0.15)]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <div className="flex items-center gap-3">
                <Flag size={18} className={activeTab === 'reports' ? 'text-cyan-400' : ''} />
                <span className="hidden md:inline">Moderation</span>
              </div>
              {reports.filter(r => r.status === 'pending').length > 0 && (
                <span className="hidden md:inline px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-red-600 text-white">
                  {reports.filter(r => r.status === 'pending').length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('groups')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'groups'
                  ? 'bg-gradient-to-r from-cyan-950 to-blue-950 text-cyan-300 border border-cyan-500/40 shadow-[0_0_15px_rgba(0,210,255,0.15)]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <MessageSquare size={18} className={activeTab === 'groups' ? 'text-cyan-400' : ''} />
              <span className="hidden md:inline">Clan Squads</span>
            </button>

            <button
              onClick={() => setActiveTab('audit')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'audit'
                  ? 'bg-gradient-to-r from-cyan-950 to-blue-950 text-cyan-300 border border-cyan-500/40 shadow-[0_0_15px_rgba(0,210,255,0.15)]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <History size={18} className={activeTab === 'audit' ? 'text-cyan-400' : ''} />
              <span className="hidden md:inline">Audit Logs</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'settings'
                  ? 'bg-gradient-to-r from-cyan-950 to-blue-950 text-cyan-300 border border-cyan-500/40 shadow-[0_0_15px_rgba(0,210,255,0.15)]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <SettingsIcon size={18} className={activeTab === 'settings' ? 'text-cyan-400' : ''} />
              <span className="hidden md:inline">Settings & Key</span>
            </button>

            <button
              onClick={() => setActiveTab('ai-agent')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeTab === 'ai-agent'
                  ? 'bg-gradient-to-r from-cyan-950 to-blue-950 text-cyan-300 border border-cyan-500/40 shadow-[0_0_15px_rgba(0,210,255,0.15)]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <Bot size={18} className={activeTab === 'ai-agent' ? 'text-cyan-400' : ''} />
              <span className="hidden md:inline">AI Agent Trainer</span>
            </button>
          </nav>

          <div className="p-3 hidden md:block border-t border-slate-800/80 text-[11px] text-slate-500 font-mono">
            <div>Auth: Verified Root</div>
            <div>Key: Abu bakr</div>
          </div>
        </aside>

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          {/* Quick Metrics Banner */}
          {stats && (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              <div className="p-3.5 rounded-xl bg-[#0b101c] border border-cyan-500/20 shadow-sm">
                <div className="text-[11px] uppercase tracking-wider text-slate-400 font-medium">Total Gamers</div>
                <div className="text-2xl font-bold font-mono text-cyan-300 mt-1">{stats.totalUsers}</div>
              </div>
              <div className="p-3.5 rounded-xl bg-[#0b101c] border border-emerald-500/20 shadow-sm">
                <div className="text-[11px] uppercase tracking-wider text-slate-400 font-medium">Online Now</div>
                <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">{stats.onlineUsers}</div>
              </div>
              <div className="p-3.5 rounded-xl bg-[#0b101c] border border-sky-500/20 shadow-sm">
                <div className="text-[11px] uppercase tracking-wider text-slate-400 font-medium">UG Verified</div>
                <div className="text-2xl font-bold font-mono text-sky-400 mt-1">{stats.verifiedGamers}</div>
              </div>
              <div className="p-3.5 rounded-xl bg-[#0b101c] border border-red-500/20 shadow-sm">
                <div className="text-[11px] uppercase tracking-wider text-slate-400 font-medium">Banned Users</div>
                <div className="text-2xl font-bold font-mono text-red-400 mt-1">{stats.bannedUsers}</div>
              </div>
              <div className="p-3.5 rounded-xl bg-[#0b101c] border border-amber-500/20 shadow-sm">
                <div className="text-[11px] uppercase tracking-wider text-slate-400 font-medium">Reports</div>
                <div className="text-2xl font-bold font-mono text-amber-400 mt-1">{stats.totalReports}</div>
              </div>
              <div className="p-3.5 rounded-xl bg-[#0b101c] border border-blue-500/20 shadow-sm">
                <div className="text-[11px] uppercase tracking-wider text-slate-400 font-medium">Clan Squads</div>
                <div className="text-2xl font-bold font-mono text-blue-400 mt-1">{allGroups.length}</div>
              </div>
            </div>
          )}

          {/* TAB 1: USERS DIRECTORY */}
          {activeTab === 'users' && (
            <div className="space-y-4">
              {/* Filter and Search Bar */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                <div className="relative flex-1 max-w-md">
                  <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search by username or full name..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 rounded-xl bg-[#0c121e] border border-slate-700/80 text-white placeholder-slate-500 text-xs focus:border-cyan-400 outline-none"
                  />
                </div>

                <div className="flex items-center gap-1.5 p-1 bg-[#0c121e] border border-slate-800 rounded-xl text-xs">
                  <button
                    onClick={() => setFilterStatus('all')}
                    className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${filterStatus === 'all' ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/40' : 'text-slate-400 hover:text-white'}`}
                  >
                    All ({users.length})
                  </button>
                  <button
                    onClick={() => setFilterStatus('active')}
                    className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${filterStatus === 'active' ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/40' : 'text-slate-400 hover:text-white'}`}
                  >
                    Active
                  </button>
                  <button
                    onClick={() => setFilterStatus('verified')}
                    className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${filterStatus === 'verified' ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/40' : 'text-slate-400 hover:text-white'}`}
                  >
                    Blue Tick
                  </button>
                  <button
                    onClick={() => setFilterStatus('banned')}
                    className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${filterStatus === 'banned' ? 'bg-red-950 text-red-300 border border-red-500/40' : 'text-slate-400 hover:text-white'}`}
                  >
                    Banned
                  </button>
                </div>
              </div>

              {/* Users Table / Grid */}
              <div className="rounded-2xl bg-[#0a0f18] border border-slate-800/80 overflow-hidden shadow-xl">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-800 bg-[#080d16] text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                        <th className="py-3 px-4">Gamer Profile</th>
                        <th className="py-3 px-4">Account Status</th>
                        <th className="py-3 px-4">Verification</th>
                        <th className="py-3 px-4">Activity</th>
                        <th className="py-3 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 text-xs">
                      {filteredUsers.map((user) => (
                        <tr key={user.id} className="hover:bg-slate-900/40 transition-colors">
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-3">
                              <img
                                src={user.avatarUrl}
                                alt={user.username}
                                className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-700 object-cover"
                              />
                              <div>
                                <div className="font-bold text-white flex items-center gap-1.5">
                                  <span>{user.fullName}</span>
                                  {user.verifiedBlueTick && <BlueTick size="sm" />}
                                </div>
                                <div className="text-[11px] text-cyan-400 font-mono">@{user.username}</div>
                                {user.customStatus && (
                                  <div className="text-[10px] text-slate-400 truncate max-w-[180px]">{user.customStatus}</div>
                                )}
                              </div>
                            </div>
                          </td>
                          <td className="py-3 px-4">
                            {user.status === 'banned' ? (
                              <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-red-950/70 border border-red-500/40 text-red-300 font-medium text-[11px]">
                                <AlertTriangle size={12} className="text-red-400" />
                                <span>Banned</span>
                              </div>
                            ) : (
                              <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-emerald-950/50 border border-emerald-500/30 text-emerald-300 font-medium text-[11px]">
                                <CheckCircle2 size={12} className="text-emerald-400" />
                                <span>Active</span>
                              </div>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            <button
                              onClick={() => handleToggleBlueTick(user)}
                              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-semibold border transition-all cursor-pointer ${
                                user.verifiedBlueTick
                                  ? 'bg-cyan-950/80 border-cyan-500/50 text-cyan-300 shadow-[0_0_10px_rgba(0,210,255,0.2)]'
                                  : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-slate-200'
                              }`}
                              title={user.verifiedBlueTick ? 'Revoke Blue Tick' : 'Grant Blue Tick'}
                            >
                              <BlueTick size="sm" showTooltip={false} />
                              <span>{user.verifiedBlueTick ? 'Verified' : 'Grant Badge'}</span>
                            </button>
                          </td>
                          <td className="py-3 px-4 text-slate-400">
                            <div>{user.online ? <span className="text-emerald-400 font-medium">● Online Now</span> : 'Offline'}</div>
                            <div className="text-[10px] text-slate-500">Joined: {new Date(user.createdAt).toLocaleDateString()}</div>
                          </td>
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => handleResetPassword(user)}
                                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 hover:text-amber-200 transition-colors"
                                title="Reset Temporary Password"
                              >
                                <KeyRound size={15} />
                              </button>

                              {user.status === 'banned' ? (
                                <button
                                  onClick={() => handleUnban(user.id)}
                                  className="px-2.5 py-1 rounded-lg bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-500/40 text-emerald-300 text-[11px] font-semibold transition-colors"
                                >
                                  Unban
                                </button>
                              ) : (
                                <button
                                  onClick={() => setBanningUser(user)}
                                  className="p-1.5 rounded-lg bg-red-950/40 hover:bg-red-900/60 border border-red-500/30 text-red-300 transition-colors"
                                  title="Ban Gamer"
                                >
                                  <Lock size={15} />
                                </button>
                              )}

                              <button
                                onClick={() => handleDeleteUser(user)}
                                className="p-1.5 rounded-lg bg-slate-800 hover:bg-red-900/60 text-slate-400 hover:text-red-300 transition-colors"
                                title="Delete User"
                              >
                                <Trash2 size={15} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: CREATE NEW USER */}
          {activeTab === 'create' && (
            <div className="max-w-xl mx-auto rounded-2xl bg-[#0a0f18] border border-cyan-500/30 p-6 shadow-2xl">
              <div className="flex items-center gap-3 mb-5 pb-4 border-b border-slate-800">
                <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-500/50 flex items-center justify-center text-cyan-400">
                  <UserPlus size={20} />
                </div>
                <div>
                  <h2 className="text-base font-bold text-white font-display">Create New Gamer Account</h2>
                  <p className="text-xs text-slate-400">
                    Accounts are managed by Admin. User can change temporary password on first login.
                  </p>
                </div>
              </div>

              {formError && (
                <div className="mb-4 p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
                  <AlertTriangle size={16} />
                  <span>{formError}</span>
                </div>
              )}

              <form onSubmit={handleCreateUser} className="space-y-4 text-xs">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Full Name *</label>
                  <input
                    type="text"
                    value={newFullName}
                    onChange={(e) => setNewFullName(e.target.value)}
                    placeholder="e.g. Zain Malik"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700 text-white placeholder-slate-500 focus:border-cyan-400 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Unique Gaming Tag / Username *</label>
                  <input
                    type="text"
                    value={newUsername}
                    onChange={(e) => setNewUsername(e.target.value)}
                    placeholder="e.g. GhostSniper99"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700 text-white placeholder-slate-500 focus:border-cyan-400 outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Temporary Password (Optional - leave blank to auto-generate)
                  </label>
                  <input
                    type="text"
                    value={newTempPassword}
                    onChange={(e) => setNewTempPassword(e.target.value)}
                    placeholder="e.g. gamer2026"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700 text-white placeholder-slate-500 focus:border-cyan-400 outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Gamer Bio / Clan Role</label>
                  <input
                    type="text"
                    value={newBio}
                    onChange={(e) => setNewBio(e.target.value)}
                    placeholder="e.g. Assaulter / Scrims team"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700 text-white placeholder-slate-500 focus:border-cyan-400 outline-none"
                  />
                </div>

                <div className="flex items-center justify-between p-3.5 rounded-xl bg-[#0c121e] border border-slate-800">
                  <div className="flex items-center gap-2">
                    <BlueTick size="sm" />
                    <div>
                      <div className="font-semibold text-slate-200">Grant Unknown Gamer Verified Badge</div>
                      <div className="text-[10px] text-slate-400">Assigns official esports verified blue tick</div>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={newVerified}
                    onChange={(e) => setNewVerified(e.target.checked)}
                    className="w-4 h-4 accent-cyan-500 cursor-pointer"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl font-bold bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 shadow-lg shadow-cyan-500/20 active:scale-[0.98] transition-all cursor-pointer"
                  >
                    Create User & Generate Credentials
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 3: REPORTS & MODERATION */}
          {activeTab === 'reports' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base font-bold text-white font-display">User Reports & Chat Moderation</h2>
                  <p className="text-xs text-slate-400">Review reported messages and conduct violations submitted by gamers</p>
                </div>
                <div className="text-xs text-slate-400">
                  Total Reports: <span className="font-mono text-cyan-400 font-bold">{reports.length}</span>
                </div>
              </div>

              {reports.length === 0 ? (
                <div className="p-8 text-center rounded-2xl bg-[#0a0f18] border border-slate-800 text-slate-400">
                  <CheckCircle2 size={36} className="mx-auto text-emerald-400 mb-2 opacity-80" />
                  <p className="text-sm font-semibold text-slate-200">All Clear!</p>
                  <p className="text-xs mt-1">No pending reports in Unknown Gamer community.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {reports.map((report) => (
                    <div
                      key={report.id}
                      className="p-4 rounded-xl bg-[#0a0f18] border border-slate-800 hover:border-slate-700 transition-colors flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
                    >
                      <div className="space-y-1.5 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-red-400 text-xs">Reported User: @{report.reportedUsername}</span>
                          <span className="text-[10px] text-slate-500">·</span>
                          <span className="text-xs text-slate-400">By: @{report.reporterUsername}</span>
                          <span className="text-[10px] text-slate-500">·</span>
                          <span className="text-[10px] text-slate-500">{new Date(report.createdAt).toLocaleString()}</span>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                            report.status === 'pending' ? 'bg-amber-950 text-amber-300 border border-amber-500/40' : 'bg-slate-800 text-slate-400'
                          }`}>
                            {report.status.toUpperCase()}
                          </span>
                        </div>
                        <div className="text-xs text-slate-200 font-medium">
                          <span className="text-slate-400">Reason: </span> {report.reason}
                        </div>
                        {report.evidenceSnippet && (
                          <div className="text-xs text-slate-300 p-2 rounded-lg bg-[#070b12] border border-slate-800/80 font-mono">
                            <span className="text-slate-500">Evidence: </span>"{report.evidenceSnippet}"
                          </div>
                        )}
                      </div>

                      {report.status === 'pending' && (
                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            onClick={() => handleResolveReport(report.id, 'dismissed')}
                            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 transition-colors"
                          >
                            Dismiss
                          </button>
                          <button
                            onClick={() => {
                              const target = users.find(u => u.id === report.reportedUserId);
                              if (target) setBanningUser(target);
                              handleResolveReport(report.id, 'action_taken');
                            }}
                            className="px-3 py-1.5 rounded-lg bg-red-950 hover:bg-red-900 border border-red-500/40 text-xs font-semibold text-red-200 transition-colors"
                          >
                            Take Action / Ban
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: CLAN GROUPS */}
          {activeTab === 'groups' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base font-bold text-white font-display">Clan Squads & Group Chats</h2>
                  <p className="text-xs text-slate-400">Oversee active multiplayer clans and channels</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {allGroups.map((grp) => (
                  <div key={grp.id} className="p-4 rounded-xl bg-[#0a0f18] border border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <img src={grp.avatar} alt={grp.name} className="w-12 h-12 rounded-xl bg-slate-900 border border-cyan-500/30 object-cover" />
                      <div>
                        <h4 className="font-bold text-white text-sm">{grp.name}</h4>
                        <div className="text-xs text-cyan-400">{grp.participants.length} Active Clan Members</div>
                        <div className="text-[11px] text-slate-400 truncate max-w-xs">{grp.description}</div>
                      </div>
                    </div>

                    <button
                      onClick={() => handleDeleteGroup(grp.id, grp.name)}
                      className="p-2 rounded-lg bg-red-950/40 hover:bg-red-900/60 border border-red-500/30 text-red-300 transition-colors"
                      title="Disband Squad"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: AUDIT LOGS */}
          {activeTab === 'audit' && (
            <div className="space-y-4">
              <div>
                <h2 className="text-base font-bold text-white font-display">Administrative Audit Trail</h2>
                <p className="text-xs text-slate-400">Complete immutable record of all administrative actions</p>
              </div>

              <div className="rounded-xl bg-[#0a0f18] border border-slate-800 divide-y divide-slate-800/80 text-xs font-mono">
                {auditLogs.map((log) => (
                  <div key={log.id} className="p-3.5 flex items-start justify-between gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-cyan-400">{log.action}</span>
                        {log.targetUsername && (
                          <span className="text-slate-400">Target: @{log.targetUsername}</span>
                        )}
                      </div>
                      <div className="text-slate-300 font-sans text-xs">{log.details}</div>
                    </div>
                    <div className="text-[10px] text-slate-500 shrink-0">
                      {new Date(log.timestamp).toLocaleTimeString()} · {new Date(log.timestamp).toLocaleDateString()}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: SETTINGS & WHATSAPP SERVICE */}
          {activeTab === 'settings' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* WhatsApp Service Config */}
              <div className="rounded-2xl bg-[#0a0f18] border border-slate-800 p-5 space-y-4 text-xs">
                <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
                  <MessageSquare size={18} className="text-emerald-400" />
                  <h3 className="font-bold text-white text-sm">WhatsApp Service Settings</h3>
                </div>

                <form onSubmit={handleSaveSettings} className="space-y-3.5">
                  <div>
                    <label className="block text-slate-300 font-medium mb-1">WhatsApp Service Number</label>
                    <input
                      type="text"
                      value={serviceNumber}
                      onChange={(e) => setServiceNumber(e.target.value)}
                      placeholder="03260715961"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700 text-white font-mono text-xs focus:border-cyan-400 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-medium mb-1">WhatsApp Direct Contact URL</label>
                    <input
                      type="text"
                      value={serviceUrl}
                      onChange={(e) => setServiceUrl(e.target.value)}
                      placeholder="https://wa.me/923260715961"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700 text-white font-mono text-xs focus:border-cyan-400 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-medium mb-1">App Version String</label>
                    <input
                      type="text"
                      value={appVersion}
                      onChange={(e) => setAppVersion(e.target.value)}
                      placeholder="v2.4.0 Esports Edition"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700 text-white font-mono text-xs focus:border-cyan-400 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-medium mb-1">Global System Notice (Broadcast)</label>
                    <textarea
                      rows={2}
                      value={systemNotice}
                      onChange={(e) => setSystemNotice(e.target.value)}
                      placeholder="Welcome notice displayed on app banner..."
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700 text-white text-xs focus:border-cyan-400 outline-none resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl font-bold bg-cyan-600 hover:bg-cyan-500 text-slate-950 transition-colors cursor-pointer"
                  >
                    Save Service Settings
                  </button>
                </form>
              </div>

              {/* Secret Admin Key Change */}
              <div className="rounded-2xl bg-[#0a0f18] border border-cyan-500/30 p-5 space-y-4 text-xs">
                <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
                  <KeyRound size={18} className="text-cyan-400" />
                  <div>
                    <h3 className="font-bold text-white text-sm">Update Secret Admin Key</h3>
                    <p className="text-[11px] text-slate-400">Change initial 'Abu bakr' key to custom secret password</p>
                  </div>
                </div>

                {keyChangeStatus && (
                  <div className={`p-3 rounded-xl border text-xs ${
                    keyChangeStatus.type === 'success'
                      ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
                      : 'bg-red-950/60 border-red-500/40 text-red-300'
                  }`}>
                    {keyChangeStatus.message}
                  </div>
                )}

                <form onSubmit={handleChangeAdminKey} className="space-y-3.5">
                  <div>
                    <label className="block text-slate-300 font-medium mb-1">Current Admin Key</label>
                    <input
                      type="password"
                      value={currentAdminKey}
                      onChange={(e) => setCurrentAdminKey(e.target.value)}
                      placeholder="e.g. Abu bakr"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700 text-white text-xs focus:border-cyan-400 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-medium mb-1">New Secret Admin Key</label>
                    <input
                      type="password"
                      value={newAdminKey}
                      onChange={(e) => setNewAdminKey(e.target.value)}
                      placeholder="Enter new admin key..."
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700 text-white text-xs focus:border-cyan-400 outline-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl font-bold bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 transition-all cursor-pointer"
                  >
                    Update Secret Key
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* TAB 7: AI AGENT TRAINER */}
          {activeTab === 'ai-agent' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-[#0a0f18] border border-cyan-500/40 shadow-xl">
                <div className="flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-2xl bg-cyan-950 border border-cyan-400/60 flex items-center justify-center text-cyan-400 shadow-[0_0_20px_rgba(0,210,255,0.3)]">
                    <Bot size={26} />
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-white font-display flex items-center gap-2">
                      <span>Unknown Gamer AI Agent Command</span>
                      <span className="text-[10px] font-semibold uppercase tracking-wider text-cyan-400 bg-cyan-950/80 border border-cyan-500/40 px-2 py-0.5 rounded">
                        Gemini 3.8 Flash
                      </span>
                    </h2>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Only Admin can train this AI agent. It answers player queries, explains ban policies, and assists with reporting in Urdu & English.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-slate-400">Agent Status:</span>
                    <button
                      type="button"
                      onClick={() => setAiActive(!aiActive)}
                      className={`px-3 py-1.5 rounded-xl font-semibold border transition-all cursor-pointer ${
                        aiActive
                          ? 'bg-emerald-950/70 border-emerald-500/50 text-emerald-300'
                          : 'bg-slate-900 border-slate-700 text-slate-400'
                      }`}
                    >
                      {aiActive ? '● Active & Responding' : '○ Paused'}
                    </button>
                  </div>
                </div>
              </div>

              {aiSaveStatus && (
                <div className="p-3.5 rounded-xl bg-emerald-950/70 border border-emerald-500/50 text-emerald-200 text-xs flex items-center gap-2 animate-in fade-in">
                  <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />
                  <span>{aiSaveStatus}</span>
                </div>
              )}

              {/* Training Form */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <form onSubmit={handleSaveAITraining} className="p-5 rounded-2xl bg-[#0a0f18] border border-slate-800 space-y-4 text-xs">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div className="flex items-center gap-2">
                      <Sparkles size={16} className="text-cyan-400" />
                      <h3 className="font-bold text-white text-sm">Agent Persona & Instructions</h3>
                    </div>
                    {aiConfig?.lastTrainedAt && (
                      <span className="text-[10px] text-slate-500 font-mono">
                        Trained: {new Date(aiConfig.lastTrainedAt).toLocaleTimeString()}
                      </span>
                    )}
                  </div>

                  <div>
                    <label className="block text-slate-300 font-medium mb-1">AI Agent Display Name</label>
                    <input
                      type="text"
                      value={aiName}
                      onChange={(e) => setAiName(e.target.value)}
                      placeholder="Unknown Gamer AI Support"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700 text-white outline-none focus:border-cyan-400 font-semibold text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-medium mb-1">
                      System Instructions & Tone (Behavior)
                    </label>
                    <textarea
                      rows={5}
                      value={aiSystemPrompt}
                      onChange={(e) => setAiSystemPrompt(e.target.value)}
                      placeholder="Prompt instructions defining how the AI should talk, its esports persona, and supported languages..."
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700 text-white outline-none focus:border-cyan-400 text-xs font-mono leading-relaxed resize-y"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-300 font-medium mb-1">
                      Custom Knowledge Base & Rules (Admin Training Data)
                    </label>
                    <textarea
                      rows={6}
                      value={aiKnowledge}
                      onChange={(e) => setAiKnowledge(e.target.value)}
                      placeholder="Provide rules, ban appeal instructions, WhatsApp number (03260715961), tournament schedules, and reporting conduct..."
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#0c121e] border border-slate-700 text-white outline-none focus:border-cyan-400 text-xs font-mono leading-relaxed resize-y"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl font-bold bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 shadow-lg shadow-cyan-500/20 active:scale-[0.98] transition-all cursor-pointer"
                  >
                    Save & Train AI Agent
                  </button>
                </form>

                {/* Live Testing Sandbox */}
                <div className="p-5 rounded-2xl bg-[#0a0f18] border border-slate-800 space-y-4 text-xs flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
                      <Play size={16} className="text-emerald-400" />
                      <h3 className="font-bold text-white text-sm">Interactive AI Testing Arena</h3>
                    </div>
                    <p className="text-slate-400 text-[11px] mt-2 mb-3">
                      Test prompts as a gamer to preview how the trained AI agent will reply to real users.
                    </p>

                    {/* Quick test prompts */}
                    <div className="space-y-1.5 mb-3">
                      <span className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold block">
                        Quick Gamer Test Inquiries:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        <button
                          type="button"
                          onClick={() => setTestPrompt('Mera account ban ho gaya hai, unban kaise karun?')}
                          className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-cyan-500 text-[10px] text-cyan-300"
                        >
                          Ban Inquiry (Urdu)
                        </button>
                        <button
                          type="button"
                          onClick={() => setTestPrompt('Hacker ko report karne ka kya tareeqa hai?')}
                          className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-cyan-500 text-[10px] text-cyan-300"
                        >
                          Report Hacker
                        </button>
                        <button
                          type="button"
                          onClick={() => setTestPrompt('Admin ka WhatsApp number kya hai?')}
                          className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-cyan-500 text-[10px] text-cyan-300"
                        >
                          WhatsApp Support
                        </button>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <textarea
                        rows={2}
                        value={testPrompt}
                        onChange={(e) => setTestPrompt(e.target.value)}
                        placeholder="Type question in Urdu, Roman Urdu or English..."
                        className="w-full px-3 py-2 rounded-xl bg-[#0c121e] border border-slate-700 text-white outline-none focus:border-cyan-400 text-xs resize-none"
                      />
                      <button
                        type="button"
                        onClick={handleTestAI}
                        disabled={testingAI || !testPrompt.trim()}
                        className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 font-semibold border border-cyan-500/30 transition-colors disabled:opacity-50 cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <Sparkles size={14} className={testingAI ? 'animate-spin' : ''} />
                        <span>{testingAI ? 'Simulating AI Response...' : 'Test AI Response'}</span>
                      </button>
                    </div>

                    {/* AI Output Window */}
                    {testReply && (
                      <div className="mt-4 p-3.5 rounded-xl bg-[#0c121e] border border-cyan-500/30 space-y-1.5 animate-in fade-in">
                        <div className="flex items-center gap-2 font-bold text-cyan-400 text-xs">
                          <Bot size={15} />
                          <span>AI Agent Response:</span>
                        </div>
                        <div className="text-slate-200 text-xs leading-relaxed whitespace-pre-wrap">
                          {testReply}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-500/20 text-[11px] text-slate-400">
                    💡 All gamers can message this AI agent directly in their Chats list or start a conversation anytime.
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* BAN USER MODAL */}
      {banningUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl bg-[#0a0f18] border border-red-500/40 p-5 space-y-4 text-xs text-slate-200">
            <div className="flex items-center gap-2 text-red-400 font-bold text-sm">
              <AlertTriangle size={18} />
              <span>Ban Gamer: @{banningUser.username}</span>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-slate-300 mb-1">Ban Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setBanType('temporary')}
                    className={`py-2 rounded-xl font-semibold border ${banType === 'temporary' ? 'bg-red-950 border-red-500 text-red-300' : 'bg-slate-900 border-slate-800 text-slate-400'}`}
                  >
                    Temporary
                  </button>
                  <button
                    type="button"
                    onClick={() => setBanType('permanent')}
                    className={`py-2 rounded-xl font-semibold border ${banType === 'permanent' ? 'bg-red-950 border-red-500 text-red-300' : 'bg-slate-900 border-slate-800 text-slate-400'}`}
                  >
                    Permanent
                  </button>
                </div>
              </div>

              {banType === 'temporary' && (
                <div>
                  <label className="block text-slate-300 mb-1">Duration (Days)</label>
                  <select
                    value={banDuration}
                    onChange={(e) => setBanDuration(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-[#0c121e] border border-slate-700 text-white outline-none"
                  >
                    <option value="1">1 Day</option>
                    <option value="3">3 Days</option>
                    <option value="7">7 Days (1 Week)</option>
                    <option value="14">14 Days (2 Weeks)</option>
                    <option value="30">30 Days (1 Month)</option>
                  </select>
                </div>
              )}

              <div>
                <label className="block text-slate-300 mb-1">Ban Reason</label>
                <textarea
                  rows={2}
                  value={banReason}
                  onChange={(e) => setBanReason(e.target.value)}
                  placeholder="e.g. Toxic behavior, hacking, unverified clan impersonation"
                  className="w-full px-3 py-2 rounded-xl bg-[#0c121e] border border-slate-700 text-white outline-none resize-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setBanningUser(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={handleBanSubmit}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold"
              >
                Enforce Ban
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CREDENTIALS RESULT MODAL */}
      {createdCredentials && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl bg-[#0a0f18] border border-cyan-500/50 p-6 space-y-4 text-xs text-slate-200">
            <div className="flex items-center gap-2 text-cyan-400 font-bold text-sm">
              <CheckCircle2 size={18} />
              <span>Gamer Account Created</span>
            </div>
            <p className="text-slate-400">Share these temporary login credentials with the user:</p>

            <div className="p-3.5 rounded-xl bg-[#0c121e] border border-slate-800 font-mono space-y-1.5 text-xs">
              <div>
                <span className="text-slate-500">Username: </span>
                <span className="text-cyan-300 font-bold">{createdCredentials.username}</span>
              </div>
              <div>
                <span className="text-slate-500">Temporary Password: </span>
                <span className="text-amber-300 font-bold">{createdCredentials.tempPass}</span>
              </div>
            </div>

            <button
              onClick={() => {
                navigator.clipboard.writeText(
                  `Unknown Gamer Login:\nUsername: ${createdCredentials.username}\nPassword: ${createdCredentials.tempPass}\nContact WhatsApp Support: 03260715961`
                );
                alert('Credentials copied to clipboard!');
              }}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 font-semibold text-slate-200 transition-colors"
            >
              Copy Credentials
            </button>

            <button
              onClick={() => setCreatedCredentials(null)}
              className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold transition-colors"
            >
              Done
            </button>
          </div>
        </div>
      )}

      {/* RESET PASSWORD RESULT MODAL */}
      {resetPassResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl bg-[#0a0f18] border border-amber-500/50 p-6 space-y-4 text-xs text-slate-200">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
              <KeyRound size={18} />
              <span>Password Reset Successful</span>
            </div>
            <p className="text-slate-400">New temporary credentials for @{resetPassResult.username}:</p>

            <div className="p-3.5 rounded-xl bg-[#0c121e] border border-slate-800 font-mono text-xs">
              <span className="text-slate-500">Temporary Password: </span>
              <span className="text-amber-300 font-bold">{resetPassResult.tempPass}</span>
            </div>

            <button
              onClick={() => {
                navigator.clipboard.writeText(resetPassResult.tempPass);
                alert('Copied to clipboard');
              }}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 font-semibold text-slate-200 transition-colors"
            >
              Copy Password
            </button>

            <button
              onClick={() => setResetPassResult(null)}
              className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
