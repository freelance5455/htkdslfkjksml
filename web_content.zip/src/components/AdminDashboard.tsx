import React, { useState } from 'react';
import { 
  ShieldAlert, 
  FileText, 
  Download, 
  Users, 
  CheckCircle2, 
  XCircle, 
  Ban, 
  HardDrive, 
  Activity, 
  TrendingUp, 
  Search, 
  Eye, 
  ShieldCheck, 
  RefreshCw 
} from 'lucide-react';
import { SystemStats, Paper, User, UserRole, Language } from '../types';
import { TRANSLATIONS } from '../lib/translations';

interface AdminDashboardProps {
  stats: SystemStats;
  papers: Paper[];
  users: User[];
  language: Language;
  onPaperStatusChange: (paperId: string, status: 'APPROVED' | 'REJECTED') => void;
  onUserRoleChange: (userId: string, role: UserRole) => void;
  onBanUserToggle: (userId: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  stats,
  papers,
  users,
  language,
  onPaperStatusChange,
  onUserRoleChange,
  onBanUserToggle
}) => {
  const t = TRANSLATIONS[language];
  const [activeTab, setActiveTab] = useState<'PENDING_PAPERS' | 'USERS' | 'AUDIT_LOGS'>('PENDING_PAPERS');
  const [rejectReasonModal, setRejectReasonModal] = useState<{ paperId: string } | null>(null);
  const [rejectReason, setRejectReason] = useState('');

  const pendingPapers = papers.filter((p) => p.status === 'PENDING');

  const handleConfirmReject = () => {
    if (rejectReasonModal) {
      onPaperStatusChange(rejectReasonModal.paperId, 'REJECTED');
      setRejectReasonModal(null);
      setRejectReason('');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950 border border-slate-800 rounded-3xl p-6 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-500 text-slate-950 font-bold">
              <ShieldAlert className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-extrabold text-white">{t.adminTitle}</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Enterprise administration control panel for paper verification, user moderation, and platform metrics.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <span className="px-3 py-1 bg-emerald-500/10 text-emerald-400 text-xs font-bold rounded-full border border-emerald-500/20 flex items-center gap-1.5">
            <Activity className="w-4 h-4" />
            <span>System Operational</span>
          </span>
        </div>
      </div>

      {/* Metrics Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-1 shadow-lg">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold">Total Papers</span>
            <FileText className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-xl font-black text-white">{stats.totalPapers}</p>
          <p className="text-[10px] text-emerald-400 font-semibold">+12 this week</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-1 shadow-lg">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold">Total Downloads</span>
            <Download className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-xl font-black text-white">{stats.totalDownloads.toLocaleString()}</p>
          <p className="text-[10px] text-emerald-400 font-semibold">High Engagement</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-1 shadow-lg">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold">Pending Approvals</span>
            <ShieldAlert className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-xl font-black text-amber-400">{pendingPapers.length}</p>
          <p className="text-[10px] text-slate-400">Requires Review</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-1 shadow-lg">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold">Total Users</span>
            <Users className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-xl font-black text-white">{stats.totalUsers.toLocaleString()}</p>
          <p className="text-[10px] text-emerald-400 font-semibold">Verified Students & Teachers</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-1 shadow-lg col-span-2 lg:col-span-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-bold">Storage Used</span>
            <HardDrive className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-xl font-black text-white">{stats.storageUsedGB} GB</p>
          <p className="text-[10px] text-slate-400">Cloud Storage</p>
        </div>

      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveTab('PENDING_PAPERS')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeTab === 'PENDING_PAPERS' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white bg-slate-900'
          }`}
        >
          <span>Pending Uploads ({pendingPapers.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('USERS')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeTab === 'USERS' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white bg-slate-900'
          }`}
        >
          <span>User Role Moderation</span>
        </button>

        <button
          onClick={() => setActiveTab('AUDIT_LOGS')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeTab === 'AUDIT_LOGS' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white bg-slate-900'
          }`}
        >
          <span>System Audit Logs</span>
        </button>
      </div>

      {/* Pending Papers Table */}
      {activeTab === 'PENDING_PAPERS' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
          <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">Pending Upload Review Queue</h3>
            <span className="text-xs text-amber-400 font-bold">{pendingPapers.length} awaiting approval</span>
          </div>

          {pendingPapers.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400">
              <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
              <p className="font-bold text-white">All paper uploads have been reviewed!</p>
              <p>No pending submissions in the moderator queue.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950 text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="p-4">Paper Title & Details</th>
                    <th className="p-4">Subject & Grade</th>
                    <th className="p-4">Medium</th>
                    <th className="p-4">Uploaded By</th>
                    <th className="p-4 text-right">Moderation Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {pendingPapers.map((paper) => (
                    <tr key={paper.id} className="hover:bg-slate-800/50 transition-colors">
                      <td className="p-4 font-bold text-white max-w-xs">
                        <p className="line-clamp-1">{paper.title}</p>
                        <p className="text-[10px] text-slate-400 font-normal">{paper.school} • {paper.year}</p>
                      </td>
                      <td className="p-4 font-semibold text-amber-300">
                        {paper.subject} ({paper.grade})
                      </td>
                      <td className="p-4 font-semibold">{paper.medium}</td>
                      <td className="p-4">
                        <div className="flex items-center gap-2">
                          <img src={paper.uploaderAvatar} alt={paper.uploaderName} className="w-6 h-6 rounded-full object-cover" />
                          <span className="font-semibold">{paper.uploaderName}</span>
                        </div>
                      </td>
                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => onPaperStatusChange(paper.id, 'APPROVED')}
                            className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl flex items-center gap-1 cursor-pointer transition-all"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Approve (+50 Pts)</span>
                          </button>
                          <button
                            onClick={() => setRejectReasonModal({ paperId: paper.id })}
                            className="px-3 py-1.5 bg-red-500/20 text-red-400 hover:bg-red-500/30 font-bold rounded-xl flex items-center gap-1 cursor-pointer transition-all"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Reject</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Users Table */}
      {activeTab === 'USERS' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
          <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">Platform User Roles & Permissions</h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-4">User</th>
                  <th className="p-4">Role</th>
                  <th className="p-4">School & Province</th>
                  <th className="p-4">Points</th>
                  <th className="p-4 text-right">Role Assignment</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-800/50 transition-colors">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <img src={u.avatar} alt={u.name} className="w-8 h-8 rounded-full object-cover ring-1 ring-amber-500/40" />
                        <div>
                          <p className="font-bold text-white flex items-center gap-1">
                            <span>{u.name}</span>
                            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                          </p>
                          <p className="text-[10px] text-slate-400">{u.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="px-2.5 py-0.5 text-[10px] font-extrabold uppercase rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30">
                        {u.role}
                      </span>
                    </td>
                    <td className="p-4">{u.school} ({u.province})</td>
                    <td className="p-4 font-black text-amber-400">{u.points} Pts</td>
                    <td className="p-4 text-right">
                      <select
                        value={u.role}
                        onChange={(e) => onUserRoleChange(u.id, e.target.value as UserRole)}
                        className="bg-slate-800 text-xs text-amber-300 border border-slate-700 rounded-xl p-1.5 font-bold focus:outline-none"
                      >
                        <option value="STUDENT">STUDENT</option>
                        <option value="TEACHER">TEACHER</option>
                        <option value="MODERATOR">MODERATOR</option>
                        <option value="ADMIN">ADMIN</option>
                        <option value="SUPER_ADMIN">SUPER_ADMIN</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Audit Logs */}
      {activeTab === 'AUDIT_LOGS' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-3 shadow-2xl">
          <h3 className="text-sm font-bold text-white">System Security & Audit Trail</h3>
          <div className="space-y-2 text-xs font-mono text-slate-300">
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
              <span>[2024-07-24 00:12:04] PAPER_UPLOAD_APPROVED: Paper p_1 approved by Super Admin.</span>
              <span className="text-emerald-400 font-bold">SUCCESS</span>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
              <span>[2024-07-24 00:10:15] VIRUS_SCAN_CLEAN: File 'Physics_2023_TermTest.pdf' passed virus definition check.</span>
              <span className="text-emerald-400 font-bold">CLEAN</span>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
              <span>[2024-07-24 00:08:42] JWT_AUTH_VERIFIED: Token issued for Kasun Perera (Role: TEACHER).</span>
              <span className="text-emerald-400 font-bold">VERIFIED</span>
            </div>
          </div>
        </div>
      )}

      {/* Reject Reason Modal */}
      {rejectReasonModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 w-full max-w-md space-y-4">
            <h3 className="text-sm font-bold text-white">Reason for Rejection</h3>
            <textarea
              rows={3}
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="e.g. Incomplete scan pages, missing marking scheme, or wrong subject category..."
              className="w-full bg-slate-800 text-xs text-white p-3 rounded-xl border border-slate-700 focus:outline-none"
            />
            <div className="flex justify-end gap-2">
              <button onClick={() => setRejectReasonModal(null)} className="px-3 py-1.5 text-xs text-slate-400">
                Cancel
              </button>
              <button onClick={handleConfirmReject} className="px-4 py-1.5 bg-red-500 text-white font-bold text-xs rounded-xl">
                Confirm Reject
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
