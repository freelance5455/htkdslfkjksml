import React, { useEffect, useState } from 'react';
import { Shield, Users, CreditCard, Activity, ArrowLeft } from 'lucide-react';

export function AdminDashboard({ onClose }: { onClose: () => void }) {
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    fetch('/api/admin/stats')
      .then(res => res.json())
      .then(data => setStats(data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="fixed inset-0 z-[300] bg-slate-50 dark:bg-slate-950 flex flex-col animate-fade-in overflow-hidden">
      <div className="flex items-center gap-4 p-4 md:p-6 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-sm">
        <button onClick={onClose} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
          <ArrowLeft size={24} className="text-slate-600 dark:text-slate-300" />
        </button>
        <h1 className="text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
          <Shield className="text-orange-500" />
          Admin Dashboard
        </h1>
      </div>

      <div className="flex-1 overflow-y-auto p-4 md:p-8">
        <div className="max-w-6xl mx-auto space-y-8">
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard icon={<Users />} label="Total Users" value={stats?.totalUsers ?? '...'} color="text-blue-500" bg="bg-blue-50 dark:bg-blue-900/20" />
            <StatCard icon={<Activity />} label="Free Plan Users" value={stats?.freeUsers ?? '...'} color="text-slate-500" bg="bg-slate-100 dark:bg-slate-800" />
            <StatCard icon={<CreditCard />} label="Pro Users" value={stats?.proUsers ?? '...'} color="text-orange-500" bg="bg-orange-50 dark:bg-orange-900/20" />
            <StatCard icon={<Shield />} label="Premium Users" value={stats?.premiumUsers ?? '...'} color="text-purple-500" bg="bg-purple-50 dark:bg-purple-900/20" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <h2 className="text-xl font-bold mb-4 text-slate-900 dark:text-white">Active Subscriptions</h2>
              <div className="flex items-end gap-4">
                <div className="text-5xl font-black text-green-500">{stats?.activeSubs ?? '...'}</div>
                <div className="text-slate-500 dark:text-slate-400 mb-1">currently active</div>
              </div>
            </div>
            
            <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <h2 className="text-xl font-bold mb-4 text-slate-900 dark:text-white">System Status</h2>
              <ul className="space-y-3">
                <li className="flex justify-between items-center text-sm border-b border-slate-100 dark:border-slate-800 pb-2">
                  <span className="text-slate-600 dark:text-slate-400">Database</span>
                  <span className="text-green-500 font-bold bg-green-50 dark:bg-green-900/20 px-2 py-0.5 rounded">Online</span>
                </li>
                <li className="flex justify-between items-center text-sm border-b border-slate-100 dark:border-slate-800 pb-2">
                  <span className="text-slate-600 dark:text-slate-400">Payment Gateway (Stripe)</span>
                  <span className="text-green-500 font-bold bg-green-50 dark:bg-green-900/20 px-2 py-0.5 rounded">Connected</span>
                </li>
                <li className="flex justify-between items-center text-sm">
                  <span className="text-slate-600 dark:text-slate-400">AI Models</span>
                  <span className="text-green-500 font-bold bg-green-50 dark:bg-green-900/20 px-2 py-0.5 rounded">Available</span>
                </li>
              </ul>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, color, bg }: { icon: React.ReactNode, label: string, value: string | number, color: string, bg: string }) {
  return (
    <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
      <div className={`p-4 rounded-2xl ${bg} ${color}`}>
        {icon}
      </div>
      <div>
        <p className="text-sm font-medium text-slate-500 dark:text-slate-400">{label}</p>
        <p className="text-3xl font-black text-slate-900 dark:text-white">{value}</p>
      </div>
    </div>
  );
}
