import React, { useState } from 'react';
import { Search, X, BookOpen, HelpCircle, FileText, Sparkles, ArrowRight } from 'lucide-react';
import { Language } from '../types';
import { EXAM_PREPS, SUBJECT_METADATA } from '../presets';

interface GlobalSearchModalProps {
  language: Language;
  onClose: () => void;
  onSelectAction: (tab: string, payload?: any) => void;
}

export default function GlobalSearchModal({ language, onClose, onSelectAction }: GlobalSearchModalProps) {
  const [query, setQuery] = useState<string>('');

  const searchResults = query.trim() ? [
    ...SUBJECT_METADATA.filter(s => s.subject.toLowerCase().includes(query.toLowerCase())).map(s => ({
      type: 'subject',
      title: s.subject,
      description: s.description,
      tab: 'classroom',
      payload: { subject: s.subject }
    })),
    ...EXAM_PREPS.filter(e => e.exam.toLowerCase().includes(query.toLowerCase()) || e.description.toLowerCase().includes(query.toLowerCase())).map(e => ({
      type: 'exam',
      title: e.exam,
      description: e.description,
      tab: 'examprep',
      payload: { exam: e.exam }
    })),
    {
      type: 'ai',
      title: `AI search for "${query}"`,
      description: language === 'bn' ? 'স্মার্ট ক্লাসরুমে এই বিষয়ে বিস্তৃত ক্লাস শুনুন' : 'Learn this topic with AI Smart Classroom',
      tab: 'classroom',
      payload: { topic: query }
    }
  ] : [];

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 px-4 bg-slate-950/70 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 text-slate-100 rounded-3xl max-w-xl w-full p-4 shadow-2xl space-y-4">
        
        {/* Search Bar Input */}
        <div className="relative flex items-center">
          <Search className="w-5 h-5 absolute left-4 text-indigo-400" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={
              language === 'bn' 
                ? 'বিষয়, চ্যাপ্টার, পরীক্ষা বা যেকোনো প্রশ্ন সার্চ করুন...' 
                : 'Search subjects, exams, topics or questions...'
            }
            className="w-full bg-slate-800 border border-slate-700 rounded-2xl pl-12 pr-10 py-3.5 text-sm text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button
            onClick={onClose}
            className="absolute right-3 p-1 rounded-full text-slate-400 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Results */}
        {query.trim() && (
          <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
            {searchResults.map((res, idx) => (
              <button
                key={idx}
                onClick={() => {
                  onSelectAction(res.tab, res.payload);
                  onClose();
                }}
                className="w-full p-3.5 bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 rounded-2xl text-left transition-all flex items-center justify-between cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-600/30 text-indigo-300 rounded-xl group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                    {res.type === 'subject' && <BookOpen className="w-4 h-4" />}
                    {res.type === 'exam' && <FileText className="w-4 h-4" />}
                    {res.type === 'ai' && <Sparkles className="w-4 h-4" />}
                  </div>
                  <div>
                    <div className="text-xs font-black text-white">{res.title}</div>
                    <div className="text-[11px] text-slate-400">{res.description}</div>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-white group-hover:translate-x-0.5 transition-all" />
              </button>
            ))}
          </div>
        )}

        {!query.trim() && (
          <div className="py-6 text-center text-xs text-slate-400 font-medium">
            {language === 'bn' ? 'উদাহরণ: "Madhyamik", "History", "Railway Math", "Photosynthesis"' : 'e.g. "Madhyamik", "Railway Math", "SSC Reasoning", "History"'}
          </div>
        )}

      </div>
    </div>
  );
}
