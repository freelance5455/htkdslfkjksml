import React, { useState, useMemo } from 'react';
import { Search, X, Play, Radio, BookOpen, Music, Sparkles, Tag, Video, Image as ImageIcon, CheckCircle2 } from 'lucide-react';
import { FEATURED_TRACKS, SERMONS_ARCHIVE, DAILY_DEVOTIONALS } from '../data/spiritualData';
import { Track, UploadedMediaItem } from '../types';
import { offlineCache } from '../lib/offlineCache';
import { tagManagementService } from '../lib/tagManagementService';

interface GlobalSearchModalProps {
  onClose: () => void;
  onSelectTrack: (track: Track) => void;
  onSelectTab: (tab: 'worship' | 'sermons' | 'devotionals' | 'soaking' | 'journal' | 'audio' | 'video' | 'image') => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  onClose,
  onSelectTrack,
  onSelectTab,
}) => {
  const [query, setQuery] = useState('');
  const [selectedTagFilter, setSelectedTagFilter] = useState<string | null>(null);

  const uploadedMedia = useMemo(() => {
    return offlineCache.getUploadedMedia();
  }, []);

  // Popular and indexed tags
  const popularTags = useMemo(() => {
    const unique = tagManagementService.getAllUniqueTags();
    const defaults = ['prophetic', 'worship', '528hz', 'healing', 'sermon', 'revival', 'glory', 'deliverance', 'sanctuary'];
    const combined = Array.from(new Set([...unique.map(u => u.tag), ...defaults]));
    return combined.slice(0, 10);
  }, []);

  const q = (selectedTagFilter || query).toLowerCase().trim().replace(/^#/, '');

  // 1. Matched Uploaded Media (Audio, Video, Image) indexed by title, description, speaker, and TAGS
  const matchedUploadedMedia = useMemo(() => {
    if (!q) return [];
    return uploadedMedia.filter((item) => {
      const matchTitle = item.title.toLowerCase().includes(q);
      const matchDesc = item.description.toLowerCase().includes(q);
      const matchArtist = (item.artistOrProphet || '').toLowerCase().includes(q);
      const matchType = item.type.toLowerCase().includes(q);
      const matchTags = item.tags && item.tags.some(t => t.toLowerCase().includes(q));
      return matchTitle || matchDesc || matchArtist || matchType || matchTags;
    });
  }, [uploadedMedia, q]);

  // 2. Matched Tracks
  const matchedTracks = useMemo(() => {
    if (!q) return [];
    return FEATURED_TRACKS.filter(
      (t) =>
        t.title.toLowerCase().includes(q) ||
        t.artist.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q) ||
        t.scriptureRef.toLowerCase().includes(q) ||
        (t.synthPreset && t.synthPreset.toLowerCase().includes(q))
    );
  }, [q]);

  // 3. Matched Sermons (indexed by title, prophet, category, summary, and TAGS)
  const matchedSermons = useMemo(() => {
    if (!q) return [];
    return SERMONS_ARCHIVE.filter(
      (s) =>
        s.title.toLowerCase().includes(q) ||
        s.prophet.toLowerCase().includes(q) ||
        s.category.toLowerCase().includes(q) ||
        s.summary.toLowerCase().includes(q) ||
        (s.tags && s.tags.some(tag => tag.toLowerCase().includes(q)))
    );
  }, [q]);

  // 4. Matched Devotionals (indexed by title, scripture, message, and TAGS)
  const matchedDevotionals = useMemo(() => {
    if (!q) return [];
    return DAILY_DEVOTIONALS.filter(
      (d) =>
        d.title.toLowerCase().includes(q) ||
        d.scripture.toLowerCase().includes(q) ||
        d.scriptureText.toLowerCase().includes(q) ||
        d.message.toLowerCase().includes(q) ||
        (d.tags && d.tags.some(tag => tag.toLowerCase().includes(q)))
    );
  }, [q]);

  const totalResults = matchedUploadedMedia.length + matchedTracks.length + matchedSermons.length + matchedDevotionals.length;

  const handleSelectTag = (tag: string) => {
    if (selectedTagFilter === tag) {
      setSelectedTagFilter(null);
    } else {
      setSelectedTagFilter(tag);
      setQuery(tag);
    }
  };

  const handlePlayUploadedTrack = (item: UploadedMediaItem) => {
    // Construct a Track object from the uploaded media item and play it
    const convertedTrack: Track = {
      id: item.id,
      title: item.title,
      artist: item.artistOrProphet,
      category: 'Anointed Worship',
      duration: 360,
      albumArt: item.thumbnailUrl || 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80',
      description: item.description,
      scriptureRef: 'Psalm 23:1-6',
      plays: item.likes * 10,
      audioUrl: item.url,
      synthPreset: '528hz'
    };
    onSelectTrack(convertedTrack);
    onSelectTab('audio');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-2xl flex items-start justify-center pt-16 px-4 sm:px-6 animate-fadeIn">
      <div className="w-full max-w-3xl bg-slate-900 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative space-y-6">
        
        {/* Header Search Input */}
        <div className="flex items-center space-x-3 pb-4 border-b border-amber-500/20">
          <Search className="w-5 h-5 text-amber-400 flex-shrink-0" />
          <input
            type="text"
            autoFocus
            placeholder="Search anointed songs, broadcasts, sermons, or tags (e.g. #528hz, prophetic, worship)..."
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedTagFilter(null);
            }}
            className="w-full bg-transparent text-amber-100 text-base sm:text-lg placeholder-slate-500 focus:outline-none"
          />
          {query && (
            <button
              onClick={() => {
                setQuery('');
                setSelectedTagFilter(null);
              }}
              className="text-slate-400 hover:text-amber-300 text-xs font-mono px-2 py-1"
            >
              Clear
            </button>
          )}
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-slate-800 text-slate-300 hover:text-amber-300 border border-amber-500/20"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Tag Filter Index Pills */}
        <div className="space-y-2">
          <div className="flex items-center space-x-2 text-xs font-mono text-slate-400">
            <Tag className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-bold text-amber-300">Indexed Tags Filter:</span>
            <span>Click to filter instantly by tag</span>
          </div>
          <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
            {popularTags.map((tag) => {
              const isSelected = (selectedTagFilter === tag) || (query.toLowerCase().replace(/^#/, '') === tag.toLowerCase());
              return (
                <button
                  key={tag}
                  onClick={() => handleSelectTag(tag)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition-all flex items-center space-x-1 border ${
                    isSelected
                      ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/20 scale-105'
                      : 'bg-slate-950/80 hover:bg-slate-800 text-amber-300 border-amber-500/30'
                  }`}
                >
                  <span>#{tag}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Results Container */}
        <div className="max-h-[58vh] overflow-y-auto space-y-6 pr-2">
          {!q ? (
            <div className="py-12 text-center space-y-2">
              <Sparkles className="w-8 h-8 text-amber-400/60 mx-auto animate-pulse" />
              <p className="text-sm text-slate-300 font-serif">
                Type above or select an indexed tag to search across Worship Tracks, Sermons, Devotionals, and Inbuilt Repository.
              </p>
              <p className="text-xs text-slate-500 font-mono">
                Tags system indexes audio, video, image, and scripture content atomically.
              </p>
            </div>
          ) : totalResults === 0 ? (
            <div className="py-12 text-center space-y-2">
              <p className="text-sm text-slate-400">No spiritual content found matching tag or query &ldquo;{q}&rdquo;.</p>
              <p className="text-xs text-slate-500">Try searching for #prophetic, #worship, #528hz, #glory, or #healing.</p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Indexed Uploaded Media (Audio, Video, Image) */}
              {matchedUploadedMedia.length > 0 && (
                <div className="space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center space-x-1.5">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span>Inbuilt Sanctuary Media with Matching Tags ({matchedUploadedMedia.length})</span>
                  </h4>
                  <div className="grid grid-cols-1 gap-2.5">
                    {matchedUploadedMedia.map((item) => (
                      <div
                        key={item.id}
                        onClick={() => {
                          if (item.type === 'audio') {
                            handlePlayUploadedTrack(item);
                          } else if (item.type === 'video') {
                            onSelectTab('video');
                            onClose();
                          } else {
                            onSelectTab('image');
                            onClose();
                          }
                        }}
                        className="p-3.5 rounded-2xl bg-slate-950/80 border border-amber-500/30 hover:border-amber-400 flex items-center justify-between cursor-pointer transition-all hover:bg-slate-900 group shadow-lg"
                      >
                        <div className="flex items-center space-x-3 min-w-0">
                          <div className="w-11 h-11 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center border border-amber-500/20 shrink-0">
                            {item.type === 'audio' ? <Music className="w-5 h-5" /> : item.type === 'video' ? <Video className="w-5 h-5" /> : <ImageIcon className="w-5 h-5" />}
                          </div>
                          <div className="min-w-0 space-y-1">
                            <div className="flex items-center space-x-2">
                              <span className="text-[9px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                                {item.type}
                              </span>
                              <h5 className="text-xs font-bold text-amber-100 truncate group-hover:text-amber-300 transition-colors">
                                {item.title}
                              </h5>
                            </div>
                            <p className="text-[10px] text-slate-400 truncate">{item.artistOrProphet} • {item.date}</p>
                            
                            {/* Render matching tags */}
                            {item.tags && item.tags.length > 0 && (
                              <div className="flex flex-wrap gap-1 pt-0.5">
                                {item.tags.map((t, idx) => {
                                  const isTagMatch = t.toLowerCase().includes(q);
                                  return (
                                    <span
                                      key={idx}
                                      className={`px-1.5 py-0.5 rounded text-[9px] font-mono ${
                                        isTagMatch
                                          ? 'bg-amber-400 text-slate-950 font-bold'
                                          : 'bg-slate-900 text-amber-300/80 border border-amber-500/20'
                                      }`}
                                    >
                                      #{t}
                                    </span>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center space-x-2 shrink-0 pl-2">
                          <span className="text-[10px] font-bold text-amber-400">Open {item.type}</span>
                          <Play className="w-4 h-4 text-amber-400" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Worship Tracks */}
              {matchedTracks.length > 0 && (
                <div className="space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center space-x-1.5">
                    <Music className="w-4 h-4" />
                    <span>Worship Tracks ({matchedTracks.length})</span>
                  </h4>
                  <div className="grid grid-cols-1 gap-2">
                    {matchedTracks.map((track) => (
                      <div
                        key={track.id}
                        onClick={() => {
                          onSelectTrack(track);
                          onSelectTab('worship');
                          onClose();
                        }}
                        className="p-3 rounded-2xl bg-slate-950/70 border border-amber-500/20 hover:border-amber-400 flex items-center justify-between cursor-pointer transition-all"
                      >
                        <div className="flex items-center space-x-3 min-w-0">
                          <img
                            src={track.albumArt}
                            alt={track.title}
                            className="w-10 h-10 rounded-xl object-cover"
                          />
                          <div className="min-w-0">
                            <h5 className="text-xs font-bold text-amber-100 truncate">{track.title}</h5>
                            <p className="text-[10px] text-slate-400">{track.category} • {track.scriptureRef}</p>
                            <span className="inline-block mt-1 px-1.5 py-0.5 rounded text-[9px] font-mono bg-amber-500/10 text-amber-300 border border-amber-500/20">
                              #{track.synthPreset || 'worship'}
                            </span>
                          </div>
                        </div>
                        <Play className="w-4 h-4 text-amber-400 flex-shrink-0" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Sermons */}
              {matchedSermons.length > 0 && (
                <div className="space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center space-x-1.5">
                    <Radio className="w-4 h-4" />
                    <span>Prophetic Sermons ({matchedSermons.length})</span>
                  </h4>
                  <div className="grid grid-cols-1 gap-2">
                    {matchedSermons.map((sermon) => (
                      <div
                        key={sermon.id}
                        onClick={() => {
                          onSelectTab('sermons');
                          onClose();
                        }}
                        className="p-3 rounded-2xl bg-slate-950/70 border border-amber-500/20 hover:border-amber-400 flex items-center justify-between cursor-pointer transition-all"
                      >
                        <div>
                          <h5 className="text-xs font-bold text-amber-100">{sermon.title}</h5>
                          <p className="text-[10px] text-slate-400">{sermon.category} • {sermon.duration}</p>
                          {sermon.tags && (
                            <div className="flex flex-wrap gap-1 pt-1">
                              {sermon.tags.map((t, idx) => (
                                <span key={idx} className="text-[9px] font-mono text-amber-300">#{t}</span>
                              ))}
                            </div>
                          )}
                        </div>
                        <span className="text-[10px] font-bold text-amber-400">View Sermon</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Devotionals */}
              {matchedDevotionals.length > 0 && (
                <div className="space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center space-x-1.5">
                    <BookOpen className="w-4 h-4" />
                    <span>Daily Devotionals ({matchedDevotionals.length})</span>
                  </h4>
                  <div className="grid grid-cols-1 gap-2">
                    {matchedDevotionals.map((dev) => (
                      <div
                        key={dev.id}
                        onClick={() => {
                          onSelectTab('devotionals');
                          onClose();
                        }}
                        className="p-3 rounded-2xl bg-slate-950/70 border border-amber-500/20 hover:border-amber-400 flex items-center justify-between cursor-pointer transition-all"
                      >
                        <div>
                          <span className="text-[10px] text-amber-400 font-mono">{dev.date}</span>
                          <h5 className="text-xs font-bold text-amber-100">{dev.title}</h5>
                          <p className="text-[10px] text-slate-400">{dev.scripture}</p>
                          {dev.tags && (
                            <div className="flex flex-wrap gap-1 pt-1">
                              {dev.tags.map((t, idx) => (
                                <span key={idx} className="text-[9px] font-mono text-amber-300">#{t}</span>
                              ))}
                            </div>
                          )}
                        </div>
                        <span className="text-[10px] font-bold text-amber-400">Read Word</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
