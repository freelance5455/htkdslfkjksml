import React, { useState } from 'react';
import { StorageService } from '../db/storage';
import { Product, Customer, SaleInvoice } from '../types/business';
import { Search, X, Package, User, Receipt, ArrowRight } from 'lucide-react';

interface GlobalSearchModalProps {
  initialQuery?: string;
  lang: 'bn' | 'en';
  onClose: () => void;
  onSelectProduct: (p: Product) => void;
  onSelectCustomer: (c: Customer) => void;
  onSelectInvoice: (inv: SaleInvoice) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  initialQuery = '',
  lang,
  onClose,
  onSelectProduct,
  onSelectCustomer,
  onSelectInvoice,
}) => {
  const [query, setQuery] = useState(initialQuery);

  const results = StorageService.searchAll(query);

  const totalResults =
    results.products.length + results.customers.length + results.invoices.length;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-start justify-center p-4 pt-12 overflow-y-auto">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Search Input Bar */}
        <div className="p-4 border-b border-slate-200 flex items-center gap-3">
          <Search className="w-5 h-5 text-slate-400 shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={
              lang === 'bn'
                ? 'ব্র্যান্ড, মডেল, পার্টস, কাস্টমার বা চালান খুঁজুন...'
                : 'Search brand, model, parts, customer, invoice...'
            }
            className="flex-1 text-sm font-semibold text-slate-900 focus:outline-none"
          />
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results Body */}
        <div className="p-4 max-h-[70vh] overflow-y-auto space-y-5">
          {!query.trim() ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              কীওয়ার্ড লিখে অনুসন্ধান করুন (যেমন: Samsung A12, Oppo, কামরুল, INV-2026-0001)
            </div>
          ) : totalResults === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              "{query}" সংক্রান্ত কোন পণ্য, কাস্টমার বা চালান পাওয়া যায়নি
            </div>
          ) : (
            <>
              {/* Products */}
              {results.products.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Package className="w-3.5 h-3.5 text-blue-600" />
                    <span>পণ্যসমূহ ({results.products.length})</span>
                  </h4>
                  <div className="space-y-1.5">
                    {results.products.map((p) => (
                      <div
                        key={p.id}
                        onClick={() => {
                          onSelectProduct(p);
                          onClose();
                        }}
                        className="p-3 rounded-xl bg-slate-50 hover:bg-blue-50 border border-slate-200/80 hover:border-blue-300 transition-colors flex items-center justify-between gap-3 cursor-pointer text-xs"
                      >
                        <div className="flex items-center gap-2.5">
                          <span className="font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                            {p.brand}
                          </span>
                          <span className="font-bold text-slate-900">{p.modelNumber}</span>
                          <span className="text-slate-500">({p.category})</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="font-bold text-emerald-700">৳{p.retailPrice}</span>
                          <span className="text-slate-500">স্টক: {p.stockQuantity}</span>
                          <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Customers */}
              {results.customers.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-indigo-600" />
                    <span>কাস্টমার ({results.customers.length})</span>
                  </h4>
                  <div className="space-y-1.5">
                    {results.customers.map((c) => (
                      <div
                        key={c.id}
                        onClick={() => {
                          onSelectCustomer(c);
                          onClose();
                        }}
                        className="p-3 rounded-xl bg-slate-50 hover:bg-indigo-50 border border-slate-200/80 hover:border-indigo-300 transition-colors flex items-center justify-between gap-3 cursor-pointer text-xs"
                      >
                        <div>
                          <span className="font-bold text-slate-900">{c.name}</span>
                          <span className="text-slate-500 ml-2 font-mono">{c.phone}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          {c.currentDue > 0 && (
                            <span className="text-amber-800 bg-amber-100 px-2 py-0.5 rounded font-bold">
                              বাকি: ৳{c.currentDue}
                            </span>
                          )}
                          <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Invoices */}
              {results.invoices.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Receipt className="w-3.5 h-3.5 text-emerald-600" />
                    <span>চালান / ইনভয়েস ({results.invoices.length})</span>
                  </h4>
                  <div className="space-y-1.5">
                    {results.invoices.map((inv) => (
                      <div
                        key={inv.id}
                        onClick={() => {
                          onSelectInvoice(inv);
                          onClose();
                        }}
                        className="p-3 rounded-xl bg-slate-50 hover:bg-emerald-50 border border-slate-200/80 hover:border-emerald-300 transition-colors flex items-center justify-between gap-3 cursor-pointer text-xs"
                      >
                        <div>
                          <span className="font-mono font-bold text-indigo-700">{inv.invoiceNumber}</span>
                          <span className="text-slate-700 ml-2">{inv.customerName}</span>
                          <span className="text-slate-400 ml-2 text-[10px]">{inv.date}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="font-bold text-slate-900">৳{inv.finalPayableAmount}</span>
                          <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
