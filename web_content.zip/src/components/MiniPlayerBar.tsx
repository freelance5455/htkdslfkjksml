import React from 'react';
import { Track } from '../types/audio';
import { Play, Pause, SkipForward, SkipBack, Maximize2, Sliders } from 'lucide-react';

interface Props {
  currentTrack: Track | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  isBeat: boolean;
  bpm: number;
  onTogglePlay: () => void;
  onNext: () => void;
  onPrev: () => void;
  onExpand: () => void;
  onOpenDSP: () => void;
}

export const MiniPlayerBar: React.FC<Props> = ({
  currentTrack,
  isPlaying,
  currentTime,
  duration,
  isBeat,
  bpm,
  onTogglePlay,
  onNext,
  onPrev,
  onExpand,
  onOpenDSP,
}) => {
  if (!currentTrack) return null;

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-slate-900/95 backdrop-blur-xl border-t border-slate-800 shadow-2xl">
      {/* Top micro progress line */}
      <div className="w-full h-1 bg-slate-800">
        <div
          className="h-full bg-gradient-to-r from-indigo-500 to-pink-500 transition-all duration-150"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      <div className="max-w-6xl mx-auto px-4 py-2.5 flex items-center justify-between gap-3">
        {/* Left: Thumbnail & Info (Clickable to expand to Full Player) */}
        <div
          onClick={onExpand}
          className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer group"
        >
          <div className="relative w-11 h-11 rounded-xl overflow-hidden shrink-0 border border-slate-700/60 bg-slate-800 shadow-sm">
            <img
              src={currentTrack.coverUrl || '/icon.svg'}
              alt={currentTrack.title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform"
            />
            {isPlaying && (
              <div
                className={`absolute inset-0 bg-indigo-500/20 transition-opacity duration-75 ${
                  isBeat ? 'opacity-100' : 'opacity-0'
                }`}
              />
            )}
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <p className="text-xs sm:text-sm font-semibold text-white truncate group-hover:text-indigo-300 transition-colors">
                {currentTrack.title}
              </p>
              <div
                className={`w-1.5 h-1.5 rounded-full shrink-0 transition-colors ${
                  isBeat ? 'bg-emerald-400' : 'bg-slate-600'
                }`}
                title={`Ritmo: ${bpm} BPM`}
              />
            </div>
            <p className="text-[11px] text-slate-400 truncate mt-0.5">
              {currentTrack.artist}
            </p>
          </div>
        </div>

        {/* Center/Right: Playback Controls */}
        <div className="flex items-center gap-1 sm:gap-2 shrink-0">
          <button
            onClick={onOpenDSP}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 hidden sm:flex items-center transition"
            title="Abrir Ecualizador DSP"
          >
            <Sliders className="w-4 h-4" />
          </button>

          <button
            onClick={onPrev}
            className="p-2 text-slate-300 hover:text-white rounded-xl hover:bg-slate-800 transition active:scale-95"
          >
            <SkipBack className="w-4 h-4" />
          </button>

          <button
            onClick={onTogglePlay}
            className="w-10 h-10 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white flex items-center justify-center shadow-md shadow-indigo-600/30 transition active:scale-95"
          >
            {isPlaying ? (
              <Pause className="w-4 h-4 fill-current" />
            ) : (
              <Play className="w-4 h-4 fill-current ml-0.5" />
            )}
          </button>

          <button
            onClick={onNext}
            className="p-2 text-slate-300 hover:text-white rounded-xl hover:bg-slate-800 transition active:scale-95"
          >
            <SkipForward className="w-4 h-4" />
          </button>

          <button
            onClick={onExpand}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
            title="Expandir reproductor"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
