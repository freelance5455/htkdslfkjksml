/**
 * GODEX P4.3 — Production VFX Studio Workspace
 * 
 * Professional Visual Effects Workstation:
 * - Multi-layer timeline & track manager
 * - Real chroma keying & despill controls
 * - Vector masks & rotoscoping with keyframe interpolation
 * - 2D feature motion tracking with confidence scoring
 * - Temporal clean-plate object removal
 * - Cinematic VFX (Glow, Bloom, Vignette, Lens Distortion, Chromatic Aberration, Particles)
 * - Real-time alpha inspection & quality analyzer
 * - Zero-fabrication truthful evidence contracts
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Layers,
  Sparkles,
  Sliders,
  Play,
  Pause,
  RotateCcw,
  Maximize2,
  Minimize2,
  ZoomIn,
  ZoomOut,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  Trash2,
  Plus,
  Compass,
  Crosshair,
  ShieldCheck,
  Activity,
  Palette,
  Volume2,
  Video,
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
  Clock,
  Download,
  SplitSquareVertical,
  Camera,
  Film,
  Zap,
  Wand2
} from 'lucide-react';
import {
  VfxTimeline,
  VfxLayer,
  VfxMask,
  MotionTrackingData,
  KeyingParameters,
  CinematicVfxParameters,
  ParticleSystemParameters,
  VfxExecutionEvidence,
  VfxBlendMode,
  VfxTruthClassification
} from '../builder/creative/vfx/vfxTypes';
import { VfxTimelineEngine } from '../builder/creative/vfx/vfxTimelineEngine';
import { VfxExecutionController } from '../builder/creative/vfx/vfxExecutionController';
import { KeyingEngine } from '../builder/creative/vfx/keyingEngine';
import { MaskingEngine } from '../builder/creative/vfx/maskingEngine';
import { RotoscopingEngine } from '../builder/creative/vfx/rotoscopingEngine';
import { MotionTrackingEngine } from '../builder/creative/vfx/motionTrackingEngine';
import { ObjectRemovalEngine } from '../builder/creative/vfx/objectRemovalEngine';
import { ParticleEffectsEngine } from '../builder/creative/vfx/particleEffectsEngine';
import { VfxEngineRegistry } from '../builder/creative/vfx/vfxEngineRegistry';

interface GodexVfxStudioWorkspaceProps {
  onOpenDiagnostics?: () => void;
}

export const GodexVfxStudioWorkspace: React.FC<GodexVfxStudioWorkspaceProps> = ({
  onOpenDiagnostics
}) => {
  const timelineEngine = useRef(VfxTimelineEngine.getInstance()).current;
  const executionController = useRef(VfxExecutionController.getInstance()).current;
  const keyingEngine = useRef(KeyingEngine.getInstance()).current;
  const rotoEngine = useRef(RotoscopingEngine.getInstance()).current;
  const trackingEngine = useRef(MotionTrackingEngine.getInstance()).current;
  const particleEngine = useRef(ParticleEffectsEngine.getInstance()).current;
  const registry = useRef(VfxEngineRegistry.getInstance()).current;

  // Timeline State
  const [timeline, setTimeline] = useState<VfxTimeline>(() => {
    const t = timelineEngine.getTimeline();
    if (t.tracks[0].layers.length === 0) {
      // Seed default demo background and keyed subject layers
      timelineEngine.addLayer(t.tracks[1].id, {
        name: 'Cyber City Background',
        type: 'SOLID_COLOR',
        meta: { color: '#091326' }
      });
      timelineEngine.addLayer(t.tracks[0].id, {
        name: 'Hero Subject (Green Screen)',
        type: 'SOLID_COLOR',
        meta: { color: '#00FF00' },
        keying: keyingEngine.getDefaultParameters('GREEN_SCREEN'),
        effects: particleEngine.getDefaultEffects()
      });
    }
    return { ...timelineEngine.getTimeline() };
  });

  const [currentFrame, setCurrentFrame] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [selectedLayerId, setSelectedLayerId] = useState<string | null>(() => {
    const all = timelineEngine.getAllLayers();
    return all.length > 0 ? all[0].id : null;
  });

  const [activeInspectorTab, setActiveInspectorTab] = useState<
    'KEYING' | 'MASKS' | 'TRACKING' | 'EFFECTS' | 'REMOVAL' | 'QUALITY'
  >('KEYING');

  const [viewMode, setViewMode] = useState<'COMPOSITE' | 'ALPHA_MATTE' | 'BEFORE_AFTER' | 'RED_CHANNEL'>('COMPOSITE');
  const [splitPos, setSplitPos] = useState<number>(50);
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [lastEvidence, setLastEvidence] = useState<VfxExecutionEvidence | null>(null);
  const [isRendering, setIsRendering] = useState<boolean>(false);
  const [renderProgress, setRenderProgress] = useState<number>(0);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number | null>(null);

  const selectedLayer = timelineEngine.getAllLayers().find(l => l.id === selectedLayerId);

  // Render canvas frame on state change
  const redrawCanvas = useCallback(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = timeline.resolution.width;
    const height = timeline.resolution.height;
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }

    // Generate mock procedural layer buffers for current frame if none loaded from external files
    const layerBuffers = new Map<string, Uint8ClampedArray>();
    for (const l of timelineEngine.getAllLayers()) {
      const buf = new Uint8ClampedArray(width * height * 4);
      if (l.type === 'SOLID_COLOR') {
        const hex = l.meta?.color || '#1A2B4C';
        const rgb = keyingEngine.parseColor(hex);
        // Add subtle gradient pattern
        for (let y = 0; y < height; y++) {
          const dy = y / height;
          for (let x = 0; x < width; x++) {
            const dx = x / width;
            const idx = (y * width + x) * 4;
            buf[idx] = Math.min(255, Math.round(rgb.r * (0.8 + 0.4 * dx)));
            buf[idx + 1] = Math.min(255, Math.round(rgb.g * (0.8 + 0.4 * dy)));
            buf[idx + 2] = Math.min(255, Math.round(rgb.b * (0.8 + 0.4 * (1 - dx))));
            buf[idx + 3] = 255;
          }
        }
      }
      layerBuffers.set(l.id, buf);
    }

    const res = executionController.renderFrame(timeline, currentFrame, layerBuffers);
    setLastEvidence(res.evidence);

    const imgData = ctx.createImageData(width, height);
    if (viewMode === 'ALPHA_MATTE') {
      // Show alpha channel as grayscale
      for (let i = 0; i < width * height; i++) {
        const a = res.buffer[i * 4 + 3];
        imgData.data[i * 4] = a;
        imgData.data[i * 4 + 1] = a;
        imgData.data[i * 4 + 2] = a;
        imgData.data[i * 4 + 3] = 255;
      }
    } else if (viewMode === 'BEFORE_AFTER') {
      const splitX = Math.round((splitPos / 100) * width);
      const rawFirst = layerBuffers.values().next().value || res.buffer;
      for (let y = 0; y < height; y++) {
        const row = y * width * 4;
        for (let x = 0; x < width; x++) {
          const idx = row + x * 4;
          if (x < splitX) {
            imgData.data[idx] = rawFirst[idx];
            imgData.data[idx + 1] = rawFirst[idx + 1];
            imgData.data[idx + 2] = rawFirst[idx + 2];
            imgData.data[idx + 3] = 255;
          } else {
            imgData.data[idx] = res.buffer[idx];
            imgData.data[idx + 1] = res.buffer[idx + 1];
            imgData.data[idx + 2] = res.buffer[idx + 2];
            imgData.data[idx + 3] = res.buffer[idx + 3];
          }
        }
      }
    } else {
      imgData.data.set(res.buffer);
    }

    ctx.putImageData(imgData, 0, 0);

    // Draw overlays (Masks & Tracking points)
    if (selectedLayer && selectedLayer.masks && selectedLayer.masks.length > 0) {
      ctx.strokeStyle = '#06B6D4';
      ctx.lineWidth = 2;
      for (const m of selectedLayer.masks) {
        if (m.points.length > 1) {
          ctx.beginPath();
          ctx.moveTo(m.points[0].x, m.points[0].y);
          for (let i = 1; i < m.points.length; i++) {
            ctx.lineTo(m.points[i].x, m.points[i].y);
          }
          ctx.closePath();
          ctx.stroke();

          // Draw vertex handles
          ctx.fillStyle = '#FFFFFF';
          for (const p of m.points) {
            ctx.fillRect(p.x - 3, p.y - 3, 6, 6);
          }
        }
      }
    }

    // Draw Tracking Points
    if (selectedLayer && selectedLayer.trackingData) {
      for (const track of selectedLayer.trackingData) {
        const pt = track.trackPoints.find(p => p.frame === currentFrame) || track.trackPoints[track.trackPoints.length - 1];
        if (pt) {
          ctx.strokeStyle = pt.status === 'TRACKED' ? '#10B981' : '#EF4444';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(pt.x, pt.y, 8, 0, Math.PI * 2);
          ctx.stroke();
          ctx.fillStyle = pt.status === 'TRACKED' ? '#10B981' : '#EF4444';
          ctx.fillText(`${track.name} (${pt.confidence}%)`, pt.x + 12, pt.y + 4);
        }
      }
    }
  }, [timeline, currentFrame, viewMode, splitPos, selectedLayer, executionController, keyingEngine, timelineEngine]);

  useEffect(() => {
    redrawCanvas();
  }, [redrawCanvas]);

  // Playback Loop
  useEffect(() => {
    if (!isPlaying) {
      if (animRef.current) cancelAnimationFrame(animRef.current);
      return;
    }

    let lastTime = performance.now();
    const frameInterval = 1000 / timeline.fps;

    const tick = (now: number) => {
      if (now - lastTime >= frameInterval) {
        setCurrentFrame(prev => {
          const next = prev + 1;
          return next >= timeline.totalFrames ? 0 : next;
        });
        lastTime = now;
      }
      animRef.current = requestAnimationFrame(tick);
    };

    animRef.current = requestAnimationFrame(tick);
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [isPlaying, timeline.fps, timeline.totalFrames]);

  // Layer Management Handlers
  const handleAddSolidLayer = () => {
    const layer = timelineEngine.addLayer(timeline.tracks[0].id, {
      name: `Solid Layer ${timelineEngine.getAllLayers().length + 1}`,
      type: 'SOLID_COLOR',
      meta: { color: '#1E293B' }
    });
    setTimeline({ ...timelineEngine.getTimeline() });
    setSelectedLayerId(layer.id);
  };

  const handleToggleSolo = (layerId: string) => {
    const all = timelineEngine.getAllLayers();
    const l = all.find(x => x.id === layerId);
    if (l) {
      timelineEngine.updateLayer(layerId, { solo: !l.solo });
      setTimeline({ ...timelineEngine.getTimeline() });
    }
  };

  const handleToggleVisible = (layerId: string) => {
    const all = timelineEngine.getAllLayers();
    const l = all.find(x => x.id === layerId);
    if (l) {
      timelineEngine.updateLayer(layerId, { visible: !l.visible });
      setTimeline({ ...timelineEngine.getTimeline() });
    }
  };

  const handleToggleLock = (layerId: string) => {
    const all = timelineEngine.getAllLayers();
    const l = all.find(x => x.id === layerId);
    if (l) {
      timelineEngine.updateLayer(layerId, { locked: !l.locked });
      setTimeline({ ...timelineEngine.getTimeline() });
    }
  };

  const handleDeleteLayer = (layerId: string) => {
    timelineEngine.removeLayer(layerId);
    setTimeline({ ...timelineEngine.getTimeline() });
    const remaining = timelineEngine.getAllLayers();
    setSelectedLayerId(remaining.length > 0 ? remaining[0].id : null);
  };

  const handleUpdateKeying = (updates: Partial<KeyingParameters>) => {
    if (!selectedLayer) return;
    const current = selectedLayer.keying || keyingEngine.getDefaultParameters();
    timelineEngine.updateLayer(selectedLayer.id, {
      keying: { ...current, ...updates }
    });
    setTimeline({ ...timelineEngine.getTimeline() });
  };

  const handleUpdateEffects = (updates: Partial<CinematicVfxParameters>) => {
    if (!selectedLayer) return;
    const current = selectedLayer.effects || particleEngine.getDefaultEffects();
    timelineEngine.updateLayer(selectedLayer.id, {
      effects: { ...current, ...updates }
    });
    setTimeline({ ...timelineEngine.getTimeline() });
  };

  const handleAddDefaultMask = () => {
    if (!selectedLayer) return;
    const newMask: VfxMask = {
      id: `mask-${Date.now()}`,
      name: `Mask ${selectedLayer.masks.length + 1}`,
      enabled: true,
      inverted: false,
      mode: 'ADD',
      shapeType: 'POLYGON',
      points: [
        { x: 300, y: 150 },
        { x: 700, y: 150 },
        { x: 700, y: 550 },
        { x: 300, y: 550 }
      ],
      opacity: 1.0,
      feather: 10,
      expansion: 0,
      keyframed: true
    };
    rotoEngine.createRotoTrack(newMask, currentFrame);
    timelineEngine.updateLayer(selectedLayer.id, {
      masks: [...selectedLayer.masks, newMask]
    });
    setTimeline({ ...timelineEngine.getTimeline() });
  };

  const handleAddTracker = () => {
    if (!selectedLayer) return;
    const tracker = trackingEngine.initializeTracker(
      `Point_Track_${(selectedLayer.trackingData?.length || 0) + 1}`,
      { x: 450, y: 300, width: 64, height: 64 },
      currentFrame
    );
    timelineEngine.updateLayer(selectedLayer.id, {
      trackingData: [...(selectedLayer.trackingData || []), tracker]
    });
    setTimeline({ ...timelineEngine.getTimeline() });
  };

  const handleExecuteFullRender = async () => {
    setIsRendering(true);
    setRenderProgress(0);
    const job = {
      jobId: `vfx-job-${Date.now()}`,
      name: 'VFX Master Sequence Render',
      targetTimelineId: timeline.id,
      frameRange: { start: 0, end: timeline.totalFrames - 1 },
      layersToRender: timelineEngine.getAllLayers().map(l => l.id),
      status: 'RUNNING' as const,
      progressPercent: 0,
      currentFrame: 0,
      totalFrames: timeline.totalFrames
    };

    const layerBuffers = new Map<string, Uint8ClampedArray>();
    for (const l of timelineEngine.getAllLayers()) {
      const buf = new Uint8ClampedArray(timeline.resolution.width * timeline.resolution.height * 4);
      buf.fill(128);
      layerBuffers.set(l.id, buf);
    }

    await executionController.executeRenderJob(job, timeline, layerBuffers, (prog, f) => {
      setRenderProgress(prog);
      setCurrentFrame(f);
    });

    setIsRendering(false);
  };

  return (
    <div className="flex flex-col h-full bg-[#0B0F19] text-gray-200 overflow-hidden select-none">
      {/* TOP VFX WORKSPACE TOOLBAR */}
      <div className="h-12 border-b border-[#1E293B] bg-[#0E1424] px-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-cyan-400 font-semibold text-sm">
            <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse" />
            <span>GODEX Production VFX Core</span>
          </div>
          <span className="text-xs px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-400 border border-cyan-800/60 font-mono">
            P4.3 DETERMINISTIC + NEURAL
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* View Modes */}
          <div className="flex bg-[#0A0D18] border border-[#1E293B] rounded-lg p-0.5 text-xs">
            <button
              onClick={() => setViewMode('COMPOSITE')}
              className={`px-2.5 py-1 rounded ${viewMode === 'COMPOSITE' ? 'bg-cyan-600 text-white font-medium' : 'text-gray-400 hover:text-gray-200'}`}
            >
              Composite
            </button>
            <button
              onClick={() => setViewMode('ALPHA_MATTE')}
              className={`px-2.5 py-1 rounded ${viewMode === 'ALPHA_MATTE' ? 'bg-cyan-600 text-white font-medium' : 'text-gray-400 hover:text-gray-200'}`}
            >
              Alpha Matte
            </button>
            <button
              onClick={() => setViewMode('BEFORE_AFTER')}
              className={`px-2.5 py-1 rounded ${viewMode === 'BEFORE_AFTER' ? 'bg-cyan-600 text-white font-medium' : 'text-gray-400 hover:text-gray-200'}`}
            >
              Split View
            </button>
          </div>

          <button
            onClick={handleExecuteFullRender}
            disabled={isRendering}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium shadow-md transition-colors disabled:opacity-50"
          >
            <Film className="w-3.5 h-3.5" />
            <span>{isRendering ? `Rendering (${renderProgress}%)` : 'Render Timeline'}</span>
          </button>

          {onOpenDiagnostics && (
            <button
              onClick={onOpenDiagnostics}
              className="px-2.5 py-1.5 rounded-lg border border-[#1E293B] hover:bg-[#1A2234] text-xs text-gray-300 flex items-center gap-1"
            >
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              <span>Engines</span>
            </button>
          )}
        </div>
      </div>

      {/* MAIN VFX MIDDLE REGION (VIEWER + LAYER STACK + INSPECTOR) */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* LEFT: LAYER STACK (240px) */}
        <div className="w-full md:w-64 border-r border-[#1E293B] bg-[#0A0E1A] flex flex-col shrink-0">
          <div className="h-9 px-3 border-b border-[#1E293B] flex items-center justify-between text-xs font-medium text-gray-300">
            <div className="flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-cyan-400" />
              <span>Layers ({timelineEngine.getAllLayers().length})</span>
            </div>
            <button
              onClick={handleAddSolidLayer}
              className="p-1 rounded hover:bg-[#1A2338] text-cyan-400"
              title="Add Layer"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {timelineEngine.getAllLayers().map((layer) => {
              const isSelected = layer.id === selectedLayerId;
              return (
                <div
                  key={layer.id}
                  onClick={() => setSelectedLayerId(layer.id)}
                  className={`p-2 rounded-lg border text-xs cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-cyan-950/40 border-cyan-500/80 text-white shadow-sm'
                      : 'bg-[#111728] border-[#1E2B44] text-gray-300 hover:border-gray-600'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-medium truncate max-w-[120px]">{layer.name}</span>
                    <span className="text-[10px] uppercase font-mono px-1 py-0.5 rounded bg-[#090D18] text-gray-400">
                      {layer.type}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-gray-400 pt-1 border-t border-gray-800/60">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleVisible(layer.id);
                        }}
                        className={`hover:text-white ${layer.visible ? 'text-cyan-400' : 'text-gray-600'}`}
                      >
                        {layer.visible ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleSolo(layer.id);
                        }}
                        className={`text-[10px] px-1 py-0.2 rounded font-bold ${
                          layer.solo ? 'bg-amber-500 text-black' : 'text-gray-500 hover:text-white'
                        }`}
                      >
                        S
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleLock(layer.id);
                        }}
                        className={`hover:text-white ${layer.locked ? 'text-red-400' : 'text-gray-500'}`}
                      >
                        {layer.locked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                      </button>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteLayer(layer.id);
                      }}
                      className="hover:text-red-400 text-gray-500"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* CENTER: MEDIA CANVAS VIEWER */}
        <div className="flex-1 bg-[#05070D] flex flex-col relative overflow-hidden">
          {/* Canvas Viewport */}
          <div className="flex-1 flex items-center justify-center p-4 overflow-auto relative">
            <div className="relative border border-[#1E293B] shadow-2xl rounded bg-black/80 flex items-center justify-center">
              <canvas
                ref={canvasRef}
                className="max-h-[52vh] max-w-full object-contain"
              />

              {viewMode === 'BEFORE_AFTER' && (
                <div
                  className="absolute inset-y-0 w-0.5 bg-cyan-400 cursor-ew-resize flex items-center justify-center"
                  style={{ left: `${splitPos}%` }}
                >
                  <div className="w-4 h-4 rounded-full bg-cyan-500 border border-white flex items-center justify-center shadow">
                    <SplitSquareVertical className="w-2.5 h-2.5 text-white" />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Quick HUD Metrics Badge */}
          {lastEvidence && (
            <div className="absolute top-3 left-3 bg-[#0A0F1D]/90 backdrop-blur border border-[#1E2B44] px-3 py-1.5 rounded-lg text-xs flex items-center gap-3">
              <div className="flex items-center gap-1.5 text-cyan-400 font-mono">
                <Activity className="w-3 h-3" />
                <span>Score: {lastEvidence.qualityMetrics.overallVfxQualityScore}/100</span>
              </div>
              <div className="text-gray-400 border-l border-gray-700 pl-3">
                Alpha Sharpness: <span className="text-white font-mono">{lastEvidence.qualityMetrics.alphaEdgeSharpness}%</span>
              </div>
              <div className="text-gray-400 border-l border-gray-700 pl-3">
                Spill: <span className="text-emerald-400 font-mono">{lastEvidence.qualityMetrics.spillLeakageScore}%</span>
              </div>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 font-mono border border-emerald-800">
                {lastEvidence.truthClassification}
              </span>
            </div>
          )}
        </div>

        {/* RIGHT: VFX PARAMETERS & INSPECTOR (320px) */}
        <div className="w-full md:w-80 border-l border-[#1E293B] bg-[#0A0E1A] flex flex-col shrink-0">
          {/* Inspector Tabs */}
          <div className="h-9 px-1 border-b border-[#1E293B] flex items-center justify-between text-xs bg-[#0E1424]">
            <button
              onClick={() => setActiveInspectorTab('KEYING')}
              className={`flex-1 py-1.5 text-center font-medium border-b-2 transition-colors ${
                activeInspectorTab === 'KEYING' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-gray-400 hover:text-gray-200'
              }`}
            >
              Keying
            </button>
            <button
              onClick={() => setActiveInspectorTab('MASKS')}
              className={`flex-1 py-1.5 text-center font-medium border-b-2 transition-colors ${
                activeInspectorTab === 'MASKS' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-gray-400 hover:text-gray-200'
              }`}
            >
              Masks
            </button>
            <button
              onClick={() => setActiveInspectorTab('TRACKING')}
              className={`flex-1 py-1.5 text-center font-medium border-b-2 transition-colors ${
                activeInspectorTab === 'TRACKING' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-gray-400 hover:text-gray-200'
              }`}
            >
              Track
            </button>
            <button
              onClick={() => setActiveInspectorTab('EFFECTS')}
              className={`flex-1 py-1.5 text-center font-medium border-b-2 transition-colors ${
                activeInspectorTab === 'EFFECTS' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-gray-400 hover:text-gray-200'
              }`}
            >
              Cinematic
            </button>
            <button
              onClick={() => setActiveInspectorTab('QUALITY')}
              className={`flex-1 py-1.5 text-center font-medium border-b-2 transition-colors ${
                activeInspectorTab === 'QUALITY' ? 'border-cyan-400 text-cyan-300' : 'border-transparent text-gray-400 hover:text-gray-200'
              }`}
            >
              Truth
            </button>
          </div>

          {/* Inspector Panel Body */}
          <div className="flex-1 overflow-y-auto p-3 space-y-4 text-xs">
            {/* TAB: CHROMA KEYING */}
            {activeInspectorTab === 'KEYING' && selectedLayer && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-gray-200">Chroma Key & Despill</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 font-mono">
                    Deterministic DSP
                  </span>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-gray-400">Key Method</label>
                    <select
                      value={selectedLayer.keying?.method || 'GREEN_SCREEN'}
                      onChange={(e) => handleUpdateKeying({ method: e.target.value as any })}
                      className="bg-[#111728] border border-[#1E2B44] rounded px-2 py-1 text-gray-200"
                    >
                      <option value="GREEN_SCREEN">Green Screen</option>
                      <option value="BLUE_SCREEN">Blue Screen</option>
                      <option value="LUMA_KEY">Luminance Key</option>
                      <option value="COLOR_DIFFERENCE">Color Difference</option>
                    </select>
                  </div>

                  <div>
                    <div className="flex justify-between text-gray-400 mb-1">
                      <span>Tolerance</span>
                      <span className="font-mono text-cyan-400">{selectedLayer.keying?.tolerance || 40}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={selectedLayer.keying?.tolerance || 40}
                      onChange={(e) => handleUpdateKeying({ tolerance: Number(e.target.value) })}
                      className="w-full accent-cyan-500"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-gray-400 mb-1">
                      <span>Smoothness</span>
                      <span className="font-mono text-cyan-400">{selectedLayer.keying?.smoothness || 15}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={selectedLayer.keying?.smoothness || 15}
                      onChange={(e) => handleUpdateKeying({ smoothness: Number(e.target.value) })}
                      className="w-full accent-cyan-500"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-gray-400 mb-1">
                      <span>Spill Suppression</span>
                      <span className="font-mono text-cyan-400">{selectedLayer.keying?.spillSuppression || 75}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={selectedLayer.keying?.spillSuppression || 75}
                      onChange={(e) => handleUpdateKeying({ spillSuppression: Number(e.target.value) })}
                      className="w-full accent-cyan-500"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-gray-400 mb-1">
                      <span>Feather Radius (px)</span>
                      <span className="font-mono text-cyan-400">{selectedLayer.keying?.feather || 2}px</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="30"
                      value={selectedLayer.keying?.feather || 2}
                      onChange={(e) => handleUpdateKeying({ feather: Number(e.target.value) })}
                      className="w-full accent-cyan-500"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-gray-400 mb-1">
                      <span>Edge Choke</span>
                      <span className="font-mono text-cyan-400">{selectedLayer.keying?.edgeChoke || 0}px</span>
                    </div>
                    <input
                      type="range"
                      min="-15"
                      max="15"
                      value={selectedLayer.keying?.edgeChoke || 0}
                      onChange={(e) => handleUpdateKeying({ edgeChoke: Number(e.target.value) })}
                      className="w-full accent-cyan-500"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* TAB: MASKS & ROTOSCOPING */}
            {activeInspectorTab === 'MASKS' && selectedLayer && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-gray-200">Vector Masks ({selectedLayer.masks?.length || 0})</span>
                  <button
                    onClick={handleAddDefaultMask}
                    className="flex items-center gap-1 px-2 py-1 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-medium"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Add Mask</span>
                  </button>
                </div>

                <div className="space-y-2">
                  {selectedLayer.masks?.map((mask) => (
                    <div key={mask.id} className="p-2.5 rounded-lg border border-[#1E2B44] bg-[#111728] space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-cyan-300">{mask.name}</span>
                        <select
                          value={mask.mode}
                          onChange={(e) => {
                            const updated = selectedLayer.masks.map(m => m.id === mask.id ? { ...m, mode: e.target.value as any } : m);
                            timelineEngine.updateLayer(selectedLayer.id, { masks: updated });
                            setTimeline({ ...timelineEngine.getTimeline() });
                          }}
                          className="bg-[#0A0D18] border border-[#1E2B44] rounded text-[10px] px-1.5 py-0.5"
                        >
                          <option value="ADD">Add</option>
                          <option value="SUBTRACT">Subtract</option>
                          <option value="INTERSECT">Intersect</option>
                          <option value="DIFFERENCE">Difference</option>
                        </select>
                      </div>

                      <div className="flex items-center justify-between text-gray-400">
                        <span>Feather: {mask.feather}px</span>
                        <span>Points: {mask.points.length}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB: MOTION TRACKING */}
            {activeInspectorTab === 'TRACKING' && selectedLayer && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-gray-200">2D Motion Trackers</span>
                  <button
                    onClick={handleAddTracker}
                    className="flex items-center gap-1 px-2 py-1 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-medium"
                  >
                    <Crosshair className="w-3 h-3" />
                    <span>Add Tracker</span>
                  </button>
                </div>

                <div className="space-y-2">
                  {selectedLayer.trackingData?.map((track) => (
                    <div key={track.id} className="p-2.5 rounded-lg border border-[#1E2B44] bg-[#111728] space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-emerald-400">{track.name}</span>
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300">
                          {track.avgConfidence}% Conf
                        </span>
                      </div>
                      <p className="text-[10px] text-gray-400">
                        Status: {track.isLost ? 'LOST AT FRAME ' + track.lostAtFrame : 'LOCKED & TRACKING'}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB: CINEMATIC EFFECTS */}
            {activeInspectorTab === 'EFFECTS' && selectedLayer && (
              <div className="space-y-3">
                <div className="font-semibold text-gray-200">Cinematic Optics & Finishing</div>

                {/* Glow & Bloom */}
                <div className="p-2.5 rounded-lg border border-[#1E2B44] bg-[#111728] space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Glow & Bloom</span>
                    <input
                      type="checkbox"
                      checked={selectedLayer.effects?.glowEnabled || false}
                      onChange={(e) => handleUpdateEffects({ glowEnabled: e.target.checked })}
                      className="accent-cyan-500"
                    />
                  </div>
                  {selectedLayer.effects?.glowEnabled && (
                    <div className="space-y-1.5 pt-1">
                      <div className="flex justify-between text-gray-400">
                        <span>Intensity</span>
                        <span className="font-mono text-cyan-400">{selectedLayer.effects.glowIntensity}x</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="5"
                        step="0.1"
                        value={selectedLayer.effects.glowIntensity || 1.5}
                        onChange={(e) => handleUpdateEffects({ glowIntensity: Number(e.target.value) })}
                        className="w-full accent-cyan-500"
                      />
                    </div>
                  )}
                </div>

                {/* Chromatic Aberration */}
                <div className="p-2.5 rounded-lg border border-[#1E2B44] bg-[#111728] space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Chromatic Aberration</span>
                    <input
                      type="checkbox"
                      checked={selectedLayer.effects?.chromaticAberrationEnabled || false}
                      onChange={(e) => handleUpdateEffects({ chromaticAberrationEnabled: e.target.checked })}
                      className="accent-cyan-500"
                    />
                  </div>
                </div>

                {/* Lens Distortion */}
                <div className="p-2.5 rounded-lg border border-[#1E2B44] bg-[#111728] space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Lens Distortion (K1)</span>
                    <input
                      type="checkbox"
                      checked={selectedLayer.effects?.lensDistortionEnabled || false}
                      onChange={(e) => handleUpdateEffects({ lensDistortionEnabled: e.target.checked })}
                      className="accent-cyan-500"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* TAB: QUALITY & TRUTH EVIDENCE */}
            {activeInspectorTab === 'QUALITY' && (
              <div className="space-y-3">
                <div className="font-semibold text-gray-200">Truth & Quality Evidence</div>
                {lastEvidence ? (
                  <div className="p-3 rounded-lg border border-[#1E2B44] bg-[#111728] space-y-2 font-mono text-[11px]">
                    <div className="text-cyan-400 font-bold">{lastEvidence.operation}</div>
                    <div className="text-gray-300">Engine: {lastEvidence.engineName}</div>
                    <div className="text-gray-300">Truth Status: <span className="text-emerald-400">{lastEvidence.truthClassification}</span></div>
                    <div className="text-gray-300">Duration: {lastEvidence.durationMs}ms</div>
                    <div className="text-gray-300">SNR: {lastEvidence.qualityMetrics.signalToNoiseRatioDb} dB</div>
                    <div className="text-gray-300">Contrast: {lastEvidence.qualityMetrics.contrastRatio}:1</div>
                  </div>
                ) : (
                  <p className="text-gray-500">Render a frame to inspect structured telemetry evidence.</p>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* BOTTOM: UNIFIED VFX TIMELINE TRACKS (180px) */}
      <div className="h-44 border-t border-[#1E293B] bg-[#090D18] flex flex-col shrink-0">
        {/* Timeline Header Controls */}
        <div className="h-10 border-b border-[#1E293B] px-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="p-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </button>
            <button
              onClick={() => setCurrentFrame(0)}
              className="p-1.5 rounded hover:bg-[#1E293B] text-gray-400 hover:text-white"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
            <div className="font-mono text-sm text-cyan-400 font-bold">
              FRAME {currentFrame.toString().padStart(4, '0')} / {timeline.totalFrames}
            </div>
            <span className="text-xs text-gray-400 font-mono">
              ({(currentFrame / timeline.fps).toFixed(2)}s @ {timeline.fps} FPS)
            </span>
          </div>

          <div className="flex items-center gap-2 text-xs text-gray-400">
            <ZoomOut className="w-3.5 h-3.5 cursor-pointer" onClick={() => setZoomLevel(Math.max(50, zoomLevel - 10))} />
            <span className="font-mono">{zoomLevel}%</span>
            <ZoomIn className="w-3.5 h-3.5 cursor-pointer" onClick={() => setZoomLevel(Math.min(200, zoomLevel + 10))} />
          </div>
        </div>

        {/* Timeline Tracks View */}
        <div className="flex-1 overflow-x-auto overflow-y-auto p-2 space-y-1.5">
          {timeline.tracks.map((track) => (
            <div key={track.id} className="flex items-center h-8 bg-[#0F1626] border border-[#1E2B44] rounded">
              <div className="w-36 px-2 border-r border-[#1E2B44] text-[11px] font-medium text-gray-300 truncate">
                {track.name}
              </div>
              <div className="flex-1 h-full relative bg-[#0B0F1C]/80">
                {track.layers.map((l) => (
                  <div
                    key={l.id}
                    onClick={() => setSelectedLayerId(l.id)}
                    className={`absolute top-1 bottom-1 rounded px-2 text-[10px] font-medium flex items-center cursor-pointer ${
                      l.id === selectedLayerId ? 'bg-cyan-600 text-white' : 'bg-blue-900/60 text-blue-200 border border-blue-700/50'
                    }`}
                    style={{
                      left: `${(l.startFrame / timeline.totalFrames) * 100}%`,
                      width: `${(l.durationFrames / timeline.totalFrames) * 100}%`
                    }}
                  >
                    <span className="truncate">{l.name}</span>
                  </div>
                ))}

                {/* Red Playhead */}
                <div
                  className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-10 pointer-events-none"
                  style={{ left: `${(currentFrame / timeline.totalFrames) * 100}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
