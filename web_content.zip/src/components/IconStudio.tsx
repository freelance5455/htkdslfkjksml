import React, { useEffect, useRef, useState } from 'react';
import { AppIconConfig } from '../types/apk';
import { renderIconToCanvas } from '../utils/iconGenerator';
import { Upload, Sparkles, Image as ImageIcon, Smartphone, Layers, Check } from 'lucide-react';

interface IconStudioProps {
  iconConfig: AppIconConfig;
  onChange: (updated: Partial<AppIconConfig>) => void;
  appName: string;
}

const COLOR_PRESETS = [
  '#2563eb', // Cobalt Blue
  '#10b981', // Emerald
  '#0f172a', // Obsidian Slate
  '#7c3aed', // Violet
  '#f43f5e', // Rose
  '#f97316', // Sunset Amber
  '#06b6d4', // Cyan
  '#e11d48', // Crimson
];

const GRADIENT_PRESETS = [
  { id: 'none', label: 'Solid' },
  { id: 'ocean', label: 'Ocean' },
  { id: 'sunset', label: 'Sunset' },
  { id: 'emerald', label: 'Emerald' },
  { id: 'violet', label: 'Violet' },
  { id: 'cyber', label: 'Cyber' },
];

export const IconStudio: React.FC<IconStudioProps> = ({ iconConfig, onChange, appName }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [previewDataUrl, setPreviewDataUrl] = useState<string>('');

  useEffect(() => {
    let isMounted = true;
    renderIconToCanvas(iconConfig, 384).then((canvas) => {
      if (isMounted) {
        setPreviewDataUrl(canvas.toDataURL('image/png'));
      }
    });
    return () => {
      isMounted = false;
    };
  }, [iconConfig]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      onChange({
        type: 'upload',
        uploadedImage: dataUrl,
      });
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Icon Generator Controls (7 cols) */}
        <div className="lg:col-span-7 space-y-5">
          {/* Mode Switch: Upload vs Generate */}
          <div className="flex p-1 bg-slate-900 border border-slate-800 rounded-xl">
            <button
              onClick={() => onChange({ type: 'generate' })}
              className={`flex-1 flex items-center justify-center gap-2 py-2 text-xs font-semibold rounded-lg transition-all ${
                iconConfig.type === 'generate'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>Studio Generator</span>
            </button>
            <button
              onClick={() => onChange({ type: 'upload' })}
              className={`flex-1 flex items-center justify-center gap-2 py-2 text-xs font-semibold rounded-lg transition-all ${
                iconConfig.type === 'upload'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Upload className="w-3.5 h-3.5 text-emerald-400" />
              <span>Upload Custom Icon</span>
            </button>
          </div>

          {/* Upload Panel */}
          {iconConfig.type === 'upload' && (
            <div className="p-5 bg-slate-900/60 border border-slate-800 rounded-xl space-y-4">
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-800 hover:border-emerald-500/50 rounded-xl p-6 text-center cursor-pointer transition-colors bg-slate-950/40"
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/svg+xml"
                  className="hidden"
                  onChange={handleImageUpload}
                />
                <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center mx-auto mb-2 text-emerald-400">
                  <ImageIcon className="w-5 h-5" />
                </div>
                <p className="text-xs font-semibold text-white">Click to upload custom app icon</p>
                <p className="text-[11px] text-slate-400 mt-1">
                  Square PNG, JPG, WebP, or SVG (Recommended: 512x512px). Automatically resized into all Android mipmap densities.
                </p>
              </div>

              {iconConfig.uploadedImage && (
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span className="text-emerald-400 flex items-center gap-1 font-medium">
                    <Check className="w-3.5 h-3.5" /> Custom image loaded
                  </span>
                  <button
                    onClick={() => onChange({ uploadedImage: null, type: 'generate' })}
                    className="text-rose-400 hover:underline"
                  >
                    Remove
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Studio Generator Controls */}
          {iconConfig.type === 'generate' && (
            <div className="p-5 bg-slate-900/60 border border-slate-800 rounded-xl space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Icon Monogram / Symbol
                  </label>
                  <input
                    type="text"
                    maxLength={3}
                    value={iconConfig.symbol}
                    onChange={(e) => onChange({ symbol: e.target.value })}
                    placeholder="CR"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm font-bold text-center text-white focus:outline-none focus:border-emerald-500 uppercase"
                  />
                  <span className="text-[11px] text-slate-500 mt-1 block">1-3 letters or symbol</span>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Corner Badge (Optional)
                  </label>
                  <input
                    type="text"
                    maxLength={4}
                    value={iconConfig.badgeText}
                    onChange={(e) => onChange({ badgeText: e.target.value })}
                    placeholder="PRO, HD, NEW"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm font-bold text-center text-white focus:outline-none focus:border-emerald-500 uppercase"
                  />
                  <span className="text-[11px] text-slate-500 mt-1 block">Emblem in corner</span>
                </div>
              </div>

              {/* Gradient Styles */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">
                  Color Scheme & Gradient
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                  {GRADIENT_PRESETS.map((g) => (
                    <button
                      key={g.id}
                      onClick={() => onChange({ bgGradient: g.id })}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-medium border text-center transition-all ${
                        iconConfig.bgGradient === g.id
                          ? 'bg-slate-800 border-emerald-500 text-white shadow-sm'
                          : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {g.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Solid Color Palette Presets */}
              {iconConfig.bgGradient === 'none' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-2">
                    Solid Background Color
                  </label>
                  <div className="flex items-center gap-2 flex-wrap">
                    {COLOR_PRESETS.map((color) => (
                      <button
                        key={color}
                        onClick={() => onChange({ bgColor: color })}
                        style={{ backgroundColor: color }}
                        className={`w-7 h-7 rounded-full border-2 transition-transform ${
                          iconConfig.bgColor === color
                            ? 'scale-110 border-white ring-2 ring-emerald-500'
                            : 'border-transparent hover:scale-105'
                        }`}
                      />
                    ))}
                    <input
                      type="color"
                      value={iconConfig.bgColor}
                      onChange={(e) => onChange({ bgColor: e.target.value })}
                      className="w-7 h-7 rounded cursor-pointer bg-transparent border-0"
                      title="Custom color picker"
                    />
                  </div>
                </div>
              )}

              {/* Monogram size slider */}
              <div>
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>Monogram Scale</span>
                  <span className="font-mono text-slate-400">{iconConfig.fontSize}%</span>
                </div>
                <input
                  type="range"
                  min="30"
                  max="70"
                  value={iconConfig.fontSize}
                  onChange={(e) => onChange({ fontSize: parseInt(e.target.value, 10) })}
                  className="w-full accent-emerald-400"
                />
              </div>
            </div>
          )}

          {/* Adaptive Icon Shape Selector */}
          <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-xl space-y-3">
            <label className="block text-xs font-semibold text-slate-300">
              Android Adaptive Icon Mask Shape
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { id: 'squircle', label: 'Squircle' },
                { id: 'circle', label: 'Circle' },
                { id: 'rounded', label: 'Rounded' },
                { id: 'square', label: 'Square' },
              ].map((s) => (
                <button
                  key={s.id}
                  onClick={() => onChange({ shape: s.id as any })}
                  className={`py-2 px-3 text-xs font-medium rounded-lg border text-center transition-all ${
                    iconConfig.shape === s.id
                      ? 'bg-slate-800 border-emerald-500 text-white'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Live Android Icon Preview & Mipmap Grid (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-5 bg-slate-900/60 border border-slate-800 rounded-xl flex flex-col items-center text-center">
            <span className="text-xs font-medium text-slate-400 mb-4">
              Android 14/15 Home Screen Preview
            </span>

            {/* Android Home Screen Icon Lockup */}
            <div className="p-6 bg-slate-950/80 rounded-2xl border border-slate-800/80 flex flex-col items-center shadow-xl w-full max-w-[240px]">
              <div className="relative mb-3">
                {previewDataUrl ? (
                  <img
                    src={previewDataUrl}
                    alt="App Icon Preview"
                    className="w-20 h-20 shadow-lg shadow-black/40 transition-transform duration-200 hover:scale-105"
                  />
                ) : (
                  <div className="w-20 h-20 bg-slate-800 rounded-2xl animate-pulse" />
                )}
              </div>
              <span className="text-xs font-bold text-white truncate max-w-full">
                {appName || 'My App'}
              </span>
              <span className="text-[10px] text-slate-500 mt-0.5 font-mono">
                {iconConfig.shape} mask
              </span>
            </div>

            {/* Auto-Generated Density Mipmaps List */}
            <div className="w-full mt-6 pt-5 border-t border-slate-800 text-left">
              <span className="text-[11px] font-semibold text-slate-300 block mb-2">
                Auto-Generated Mipmap Densities:
              </span>
              <div className="grid grid-cols-2 gap-2 text-[11px] font-mono text-slate-400">
                <div className="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between">
                  <span>mdpi (1x)</span>
                  <span className="text-slate-500">48px</span>
                </div>
                <div className="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between">
                  <span>hdpi (1.5x)</span>
                  <span className="text-slate-500">72px</span>
                </div>
                <div className="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between">
                  <span>xhdpi (2x)</span>
                  <span className="text-slate-500">96px</span>
                </div>
                <div className="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between">
                  <span>xxhdpi (3x)</span>
                  <span className="text-slate-500">144px</span>
                </div>
                <div className="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between">
                  <span>xxxhdpi (4x)</span>
                  <span className="text-slate-500">192px</span>
                </div>
                <div className="p-2 bg-slate-950 rounded border border-slate-800 flex justify-between">
                  <span>Play Store</span>
                  <span className="text-slate-500">512px</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
