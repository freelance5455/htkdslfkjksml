import { format, isSameDay, parseISO } from "date-fns";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { sessionForDate } from "@/lib/program";
import { useGymStore } from "@/lib/store";

type WeekStripProps = {
  days: Date[];
  selected: Date;
  today: Date;
  onSelect: (date: Date) => void;
};

export function WeekStrip({ days, selected, today, onSelect }: WeekStripProps) {
  const logs = useGymStore((s) => s.logs);

  return (
    <div className="grid grid-cols-7 gap-1.5" role="tablist" aria-label="Haftalık program">
      {days.map((day) => {
        const key = format(day, "yyyy-MM-dd");
        const session = sessionForDate(day);
        const isSelected = isSameDay(day, selected);
        const isToday = isSameDay(day, today);
        const completed = Boolean(logs[key]?.completed);
        const isRest = !session.isTraining;

        return (
          <button
            key={key}
            type="button"
            role="tab"
            aria-selected={isSelected}
            onClick={() => onSelect(day)}
            className={cn(
              "flex min-h-20 min-w-0 w-full flex-col items-center justify-between rounded-xl px-0.5 py-2 transition-[background-color,box-shadow,color] duration-150",
              isSelected ? "bg-primary text-primary-fg" : "bg-surface text-muted shadow-[var(--shadow-border)]",
            )}
          >
            <span className="text-xs font-medium">{session.shortName}</span>
            <span
              className={cn(
                "font-display text-lg leading-none tabular-nums",
                isSelected ? "text-primary-fg" : "text-fg",
              )}
            >
              {format(day, "d")}
            </span>
            <span className="flex h-4 items-center text-xs font-semibold tracking-wide">
              {completed ? (
                <Check className="size-3" strokeWidth={2.5} />
              ) : (
                <span className={cn(isRest && !isSelected && "text-subtle")}>{session.code}</span>
              )}
            </span>
            <span className={cn("mt-1 size-1 rounded-full", isToday && !isSelected ? "bg-accent" : "bg-transparent")} />
          </button>
        );
      })}
    </div>
  );
}

export function dateFromKey(key: string): Date {
  return parseISO(`${key}T12:00:00`);
}
