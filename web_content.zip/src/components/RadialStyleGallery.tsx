import React from "react";
import { RadialMenuSettings } from "./RadialMenuSettings";
import { RadialMenuTheme } from "../types";

interface RadialStyleGalleryProps {
  activeStyleId?: RadialMenuTheme;
  onSelectStyle?: (styleId: RadialMenuTheme) => void;
}

export const RadialStyleGallery: React.FC<RadialStyleGalleryProps> = () => {
  return <RadialMenuSettings />;
};
