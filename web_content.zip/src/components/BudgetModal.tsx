import React, { useState } from 'react';
import { MonthlyBudget, Category, AppSettings } from '../types';
import { X, Target, Bell, Plus, Trash2 } from 'lucide-react';
import { formatCurrency, getCurrentMonthFormatted, getMonthName } from '../utils/formatters';
import { getDualAccentInfo } from '../utils/theme';

interface BudgetModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentBudget: MonthlyBudget;
  expenseCategories: Category[];
  onSaveBudget: (budget: MonthlyBudget) => void;
  useBanglaDigits: boolean;
  appSettings?: AppSettings;
}

export const BudgetModal: React.FC<BudgetModalProps> = ({
  isOpen,
  onClose,
  currentBudget,
  expenseCategories = [],
  onSaveBudget,
  useBanglaDigits,
  appSettings,
}) => {
  const safeExpenseCategories = Array.isArray(expenseCategories) ? expenseCategories : [];
  const [totalLimit, setTotalLimit] = useState<string>(String(currentBudget?.totalLimit || 50000));
  const [alertThreshold, setAlertThreshold] = useState<number>(currentBudget?.alertThreshold || 80);
  const [categoryLimits, setCategoryLimits] = useState<{ categoryId: string; limit: number }[]>(
    Array.isArray(currentBudget?.categoryLimits) ? currentBudget.categoryLimits : []
  );

  const [selectedCatId, setSelectedCatId] = useState<string>('');
  const [catLimitInput, setCatLimitInput] = useState<string>('');

  const isLight = appSettings?.themeMode === 'light';
  const isEn = appSettings?.language === 'en';
  const dualAccent = getDualAccentInfo(
    appSettings?.themeAccent,
    appSettings?.secondaryAccent,
    appSettings?.accentPercentage
  );

  if (!isOpen) return null;

  const currentMonthStr = getMonthName(
    currentBudget.month || getCurrentMonthFormatted(),
    appSettings?.language,
    useBanglaDigits
  );

  const handleAddCategoryLimit = () => {
    const val = parseFloat(catLimitInput);
    if (!selectedCatId || isNaN(val) || val <= 0) return;

    setCategoryLimits((prev) => {
      const existing = prev.filter((item) => item.categoryId !== selectedCatId);
      return [...existing, { categoryId: selectedCatId, limit: val }];
    });
    setSelectedCatId('');
    setCatLimitInput('');
  };

  const handleRemoveCategoryLimit = (catId: string) => {
    setCategoryLimits((prev) => prev.filter((item) => item.categoryId !== catId));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedTotal = parseFloat(totalLimit) || 0;
    onSaveBudget({
      month: currentBudget.month || getCurrentMonthFormatted(),
      totalLimit: parsedTotal,
      alertThreshold,
      categoryLimits,
    });
    onClose();
  };

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center ${
      isLight ? 'bg-slate-900/40 backdrop-blur-xs' : 'bg-slate-900/80 backdrop-blur-xs'
    } p-4 animate-in fade-in duration-200`}>
      <div className={`w-full max-w-lg ${
        isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-slate-800 border-slate-700 text-slate-100'
      } border rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]`}>
        <div className={`flex items-center justify-between px-6 py-4 border-b ${
          isLight ? 'border-slate-200 bg-slate-50/90 text-slate-900' : 'border-slate-700 bg-slate-800/90 text-gray-100'
        }`}>
          <h2 className="text-lg font-bold flex items-center gap-2">
            <Target className="w-5 h-5" style={{ color: dualAccent.primary.hex }} />
            <span>
              {isEn ? `Monthly Budget & Alerts (${currentMonthStr})` : `মাসিক বাজেট ও সতর্কবার্তা (${currentMonthStr})`}
            </span>
          </h2>
          <button
            onClick={onClose}
            className={`p-2 rounded-full cursor-pointer ${
              isLight ? 'text-slate-600 hover:text-slate-900 hover:bg-slate-100' : 'text-slate-400 hover:text-white hover:bg-slate-700'
            } transition`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5">
          {/* Total Monthly Limit */}
          <div>
            <label className={`block text-xs font-semibold uppercase tracking-wider ${
              isLight ? 'text-slate-700' : 'text-gray-400'
            } mb-1.5`}>
              {isEn ? 'Total Monthly Expense Budget (৳)' : 'মোট মাসিক সর্বোচ্চ খরচের বাজেট (৳)'}
            </label>
            <div className="relative">
              <span
                className="absolute left-4 top-1/2 -translate-y-1/2 text-lg font-bold"
                style={{ color: dualAccent.primary.hex }}
              >
                ৳
              </span>
              <input
                type="number"
                value={totalLimit}
                onChange={(e) => setTotalLimit(e.target.value)}
                placeholder="50000"
                className={`w-full pl-10 pr-4 py-3 ${
                  isLight
                    ? 'bg-slate-50/80 border-slate-200 text-slate-900 placeholder-slate-400'
                    : 'bg-slate-900 border-slate-700 text-white'
                } border rounded-xl text-lg font-bold focus:outline-none`}
                style={{ borderColor: `${dualAccent.primary.hex}40` }}
              />
            </div>
            <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-gray-500'} mt-1`}>
              {isEn
                ? 'An alert will be shown when total expenses exceed this limit.'
                : 'মাস জুড়ে মোট খরচ এই বাজেট ছাড়িয়ে গেলে অ্যাপে সতর্কতা দেখা যাবে।'}
            </p>
          </div>

          {/* Alert Threshold Slider */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className={`text-xs font-semibold uppercase tracking-wider ${
                isLight ? 'text-slate-700' : 'text-gray-400'
              } flex items-center gap-1.5`}>
                <Bell className="w-3.5 h-3.5" style={{ color: dualAccent.secondary.hex }} />
                <span>{isEn ? 'Budget Alert Threshold' : 'বাজেট সতর্কতা শতাংশ'}</span>
              </label>
              <span className="text-sm font-bold" style={{ color: dualAccent.primary.hex }}>
                {alertThreshold}%
              </span>
            </div>
            <input
              type="range"
              min="50"
              max="100"
              step="5"
              value={alertThreshold}
              onChange={(e) => setAlertThreshold(parseInt(e.target.value, 10))}
              className={`w-full ${isLight ? 'bg-slate-200' : 'bg-slate-900'} rounded-lg cursor-pointer`}
              style={{ accentColor: dualAccent.primary.hex }}
            />
            <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-gray-500'} mt-1`}>
              {isEn
                ? `You will receive an early warning when ${alertThreshold}% of the budget is spent.`
                : `মোট বাজেটের ${alertThreshold}% খরচ হয়ে গেলে আগাম সতর্কবার্তা দেওয়া হবে।`}
            </p>
          </div>

          <hr className={isLight ? 'border-slate-200' : 'border-slate-700'} />

          {/* Category-wise specific limits */}
          <div>
            <h3 className={`text-sm font-bold ${isLight ? 'text-slate-900' : 'text-gray-200'} mb-2`}>
              {isEn ? 'Category-wise Budget Limits' : 'খাতভিত্তিক বাজেট নির্ধারণ'}
            </h3>

            <div className="flex items-center gap-2 mb-3">
              <select
                value={selectedCatId}
                onChange={(e) => setSelectedCatId(e.target.value)}
                className={`flex-1 px-3 py-2 ${
                  isLight
                    ? 'bg-slate-50/80 border-slate-200 text-slate-900'
                    : 'bg-slate-900 border-slate-700 text-gray-200'
                } border rounded-xl text-xs focus:outline-none`}
              >
                <option value="">{isEn ? 'Select category...' : 'খাত নির্বাচন করুন...'}</option>
                {safeExpenseCategories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {isEn ? cat.nameEnglish : cat.nameBangla}
                  </option>
                ))}
              </select>

              <input
                type="number"
                placeholder={isEn ? 'Limit ৳' : 'সীমা ৳'}
                value={catLimitInput}
                onChange={(e) => setCatLimitInput(e.target.value)}
                className={`w-28 px-3 py-2 ${
                  isLight
                    ? 'bg-slate-50/80 border-slate-200 text-slate-900 placeholder-slate-400'
                    : 'bg-slate-900 border-slate-700 text-white'
                } border rounded-xl text-xs focus:outline-none`}
              />

              <button
                type="button"
                onClick={handleAddCategoryLimit}
                className="p-2 text-white rounded-xl transition shrink-0 cursor-pointer"
                style={dualAccent.primaryButtonStyle}
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
              </button>
            </div>

            {/* List of defined category limits */}
            <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
              {categoryLimits.length === 0 ? (
                <p className={`text-xs ${
                  isLight ? 'text-slate-500 bg-slate-50 border-slate-200' : 'text-gray-500 bg-gray-950/40 border-gray-800/60'
                } text-center py-3 rounded-xl border`}>
                  {isEn ? 'No category-specific limits set.' : 'কোনো নির্দিষ্ট খাতের বাজেট যুক্ত করা হয়নি।'}
                </p>
              ) : (
                (categoryLimits || []).map((cl) => {
                  const cat = safeExpenseCategories.find((c) => c.id === cl.categoryId);
                  return (
                    <div
                      key={cl.categoryId}
                      className={`flex items-center justify-between p-2.5 ${
                        isLight ? 'bg-slate-50/80 border-slate-200' : 'bg-gray-950 border-gray-800'
                      } border rounded-xl text-xs`}
                    >
                      <span className={`font-semibold ${isLight ? 'text-slate-900' : 'text-gray-200'}`}>
                        {cat ? (isEn ? cat.nameEnglish : cat.nameBangla) : cl.categoryId}
                      </span>
                      <div className="flex items-center gap-3">
                        <span className="font-bold" style={{ color: dualAccent.primary.hex }}>
                          {formatCurrency(cl.limit, useBanglaDigits)}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleRemoveCategoryLimit(cl.categoryId)}
                          className="text-gray-400 hover:text-rose-500 transition cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <div className="pt-3 flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className={`flex-1 py-3 px-4 rounded-xl border ${
                isLight
                  ? 'border-slate-200 text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                  : 'border-gray-800 text-gray-400 hover:text-white'
              } font-medium text-sm transition cursor-pointer`}
            >
              {isEn ? 'Cancel' : 'বাতিল'}
            </button>
            <button
              type="submit"
              className="flex-1 py-3 px-4 rounded-xl text-white font-bold text-sm shadow-lg transition cursor-pointer"
              style={dualAccent.buttonStyle}
            >
              {isEn ? 'Save Budget' : 'সংরক্ষণ করুন'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
