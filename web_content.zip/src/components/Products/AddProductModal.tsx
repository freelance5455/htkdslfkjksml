import React, { useState, useRef } from 'react';
import { 
  X, 
  Upload, 
  Camera, 
  Image as ImageIcon, 
  Check, 
  Plus, 
  ShoppingBag,
  Sparkles,
  Trash2
} from 'lucide-react';
import { Product, ProductCategory, UnitType } from '../../types';

interface AddProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddProduct: (product: Omit<Product, 'id'>) => void;
  editingProduct?: Product | null;
  onUpdateProduct?: (product: Product) => void;
  onDeleteProduct?: (id: string) => void;
}

const CATEGORIES: ProductCategory[] = [
  'চাল ও ডাল',
  'তেল ও ঘি',
  'পেঁয়াজ, আলু ও রসুন',
  'মসলা ও লবণ',
  'স্ন্যাক্স ও নুডলস',
  'চা, চিনি ও বেকারি',
  'দুগ্ধ ও ডিম',
  'সাবান ও প্রসাধন',
  'পানীয় ও পান মশলা',
  'অন্যান্য',
];

const UNITS: UnitType[] = ['কেজি', 'গ্রাম', 'লিটার', 'মিলি', 'প্যাকেট', 'পিস', 'ডজন', 'হালি', 'বস্তা', 'বক্স'];

export const AddProductModal: React.FC<AddProductModalProps> = ({
  isOpen,
  onClose,
  onAddProduct,
  editingProduct,
  onUpdateProduct,
  onDeleteProduct,
}) => {
  const [nameBn, setNameBn] = useState(editingProduct?.nameBn || '');
  const [nameEn, setNameEn] = useState(editingProduct?.nameEn || '');
  const [category, setCategory] = useState<ProductCategory>(editingProduct?.category || 'চাল ও ডাল');
  const [purchasePrice, setPurchasePrice] = useState(editingProduct ? String(editingProduct.purchasePrice) : '');
  const [sellPrice, setSellPrice] = useState(editingProduct ? String(editingProduct.sellPrice) : '');
  const [unit, setUnit] = useState<UnitType>(editingProduct?.unit || 'কেজি');
  const [stock, setStock] = useState(editingProduct ? String(editingProduct.stock) : '20');
  const [lowStockAlert, setLowStockAlert] = useState(editingProduct ? String(editingProduct.lowStockAlert) : '5');
  const [barcode, setBarcode] = useState(editingProduct?.barcode || '');
  const [imageUrl, setImageUrl] = useState<string>(editingProduct?.imageUrl || '');
  const [imageTab, setImageTab] = useState<'upload' | 'url'>('upload');
  
  const [savedNotice, setSavedNotice] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync when editingProduct changes
  React.useEffect(() => {
    if (editingProduct) {
      setNameBn(editingProduct.nameBn);
      setNameEn(editingProduct.nameEn);
      setCategory(editingProduct.category);
      setPurchasePrice(String(editingProduct.purchasePrice));
      setSellPrice(String(editingProduct.sellPrice));
      setUnit(editingProduct.unit);
      setStock(String(editingProduct.stock));
      setLowStockAlert(String(editingProduct.lowStockAlert));
      setBarcode(editingProduct.barcode || '');
      setImageUrl(editingProduct.imageUrl || '');
    } else {
      resetForm();
    }
  }, [editingProduct, isOpen]);

  const resetForm = () => {
    setNameBn('');
    setNameEn('');
    setCategory('চাল ও ডাল');
    setPurchasePrice('');
    setSellPrice('');
    setUnit('কেজি');
    setStock('20');
    setLowStockAlert('5');
    setBarcode('');
    setImageUrl('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  if (!isOpen) return null;

  // Handle Photo File Upload & compress to lightweight Data URL
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        // Compress and resize image to 300x300 max
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 300;
        const MAX_HEIGHT = 300;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.82);
          setImageUrl(compressedDataUrl);
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleSave = (addAnother = false) => {
    const sPrice = parseFloat(sellPrice);
    const pPrice = parseFloat(purchasePrice) || +(sPrice * 0.85).toFixed(2);
    const st = parseFloat(stock) || 0;
    const alertLim = parseFloat(lowStockAlert) || 5;

    if (!nameBn.trim()) {
      alert('দয়া করে পণ্যের নাম লিখুন');
      return;
    }
    if (isNaN(sPrice) || sPrice <= 0) {
      alert('দয়া করে সঠিক বিক্রয় মূল্য নির্ধারণ করুন');
      return;
    }

    if (editingProduct && onUpdateProduct) {
      onUpdateProduct({
        ...editingProduct,
        nameBn: nameBn.trim(),
        nameEn: nameEn.trim(),
        category,
        purchasePrice: pPrice,
        sellPrice: sPrice,
        unit,
        stock: st,
        lowStockAlert: alertLim,
        barcode: barcode.trim() || undefined,
        imageUrl: imageUrl.trim() || undefined,
      });
      onClose();
    } else {
      onAddProduct({
        nameBn: nameBn.trim(),
        nameEn: nameEn.trim(),
        category,
        purchasePrice: pPrice,
        sellPrice: sPrice,
        unit,
        stock: st,
        lowStockAlert: alertLim,
        barcode: barcode.trim() || undefined,
        imageUrl: imageUrl.trim() || undefined,
      });

      if (addAnother) {
        setSavedNotice(`"${nameBn.trim()}" সফলভাবে যোগ হয়েছে! পরবর্তী পণ্য লিখুন।`);
        resetForm();
        setTimeout(() => setSavedNotice(null), 3000);
      } else {
        onClose();
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden my-6">
        
        {/* Modal Header */}
        <div className="bg-emerald-800 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-emerald-300" />
            <div>
              <h3 className="font-bold text-base">
                {editingProduct ? 'পণ্যের তথ্য, ছবি, মূল্য ও স্টক এডিট করুন' : 'দোকানে নতুন পণ্য যুক্ত করুন'}
              </h3>
              <p className="text-xs text-emerald-200/80">
                {editingProduct 
                  ? 'পণ্যের নাম, ছবি, বিক্রয়/ক্রয় মূল্য ও মজুদের পরিমাণ পরিবর্তন করে আপডেট করুন' 
                  : 'পণ্যের নাম, ছবি, মূল্য ও মজুদের পরিমাণ দিয়ে দোকানে যুক্ত করুন'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-emerald-200 hover:text-white hover:bg-emerald-700 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success Notice if added another */}
        {savedNotice && (
          <div className="bg-emerald-100 border-b border-emerald-300 p-2.5 text-xs font-bold text-emerald-900 flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-700" />
            <span>{savedNotice}</span>
          </div>
        )}

        {/* Form Body */}
        <div className="p-4 sm:p-5 max-h-[78vh] overflow-y-auto space-y-4 text-xs">
          
          {/* PHOTO UPLOAD & PREVIEW SECTION */}
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2.5">
            <label className="block text-slate-800 font-bold">
              পণ্যের ছবি / ফটো (Camera বা Gallery থেকে আপলোড করুন):
            </label>
            
            <div className="flex items-center gap-4">
              {/* Preview Container */}
              <div className="w-20 h-20 rounded-xl bg-white border-2 border-dashed border-slate-300 overflow-hidden flex items-center justify-center shrink-0 relative group">
                {imageUrl ? (
                  <>
                    <img
                      src={imageUrl}
                      alt="Product preview"
                      className="w-full h-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => setImageUrl('')}
                      className="absolute inset-0 bg-black/50 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition"
                      title="ছবি মুছুন"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </>
                ) : (
                  <div className="text-center p-1 text-slate-400">
                    <ImageIcon className="w-6 h-6 mx-auto mb-1 text-slate-300" />
                    <span className="text-[10px] leading-tight block">ছবি নেই</span>
                  </div>
                )}
              </div>

              {/* Upload Controls */}
              <div className="flex-1 space-y-2">
                <div className="flex gap-1.5">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-semibold shadow-xs transition"
                  >
                    <Camera className="w-4 h-4" />
                    <span>ছবি তুলুন / ফাইল বাছুন</span>
                  </button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageFileChange}
                    className="hidden"
                  />
                </div>

                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    placeholder="অথবা ছবির ওয়েব লিংক (URL) দিন..."
                    value={imageUrl.startsWith('data:') ? '' : imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    className="flex-1 px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
                  />
                  {imageUrl && (
                    <button
                      type="button"
                      onClick={() => setImageUrl('')}
                      className="text-red-500 hover:underline px-1 text-[11px]"
                    >
                      মুছুন
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* PRODUCT NAME (BANGLA & ENGLISH) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                পণ্যের নাম (বাংলা)*
              </label>
              <input
                type="text"
                placeholder="যেমন: মিনিকেট চাল / দেশি পেঁয়াজ / রূপচাঁদা তেল"
                value={nameBn}
                onChange={(e) => setNameBn(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-medium focus:ring-2 focus:ring-emerald-600"
                required
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                ইংরেজি নাম / ব্র্যান্ড (ঐচ্ছিক)
              </label>
              <input
                type="text"
                placeholder="e.g. Miniket Rice / Onion"
                value={nameEn}
                onChange={(e) => setNameEn(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          {/* CATEGORY & UNIT */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                ক্যাটাগরি
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                একক (Unit)
              </label>
              <select
                value={unit}
                onChange={(e) => setUnit(e.target.value as any)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white"
              >
                {UNITS.map((u) => (
                  <option key={u} value={u}>{u}</option>
                ))}
              </select>
            </div>
          </div>

          {/* PRICING (BUYING & SELLING) */}
          <div className="grid grid-cols-2 gap-3 bg-emerald-50/50 p-3 rounded-xl border border-emerald-100">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                বিক্রয় মূল্য প্রতি {unit} (৳)*
              </label>
              <input
                type="number"
                step="any"
                placeholder="যেমন: ৭৫"
                value={sellPrice}
                onChange={(e) => setSellPrice(e.target.value)}
                className="w-full px-3 py-2 border border-emerald-400 bg-white rounded-lg font-mono text-base font-bold text-emerald-900 focus:ring-2 focus:ring-emerald-600"
                required
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                পাইকারি ক্রয় মূল্য (৳)
              </label>
              <input
                type="number"
                step="any"
                placeholder="যেমন: ৬৫"
                value={purchasePrice}
                onChange={(e) => setPurchasePrice(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 bg-white rounded-lg font-mono text-slate-700"
              />
              <span className="text-[10px] text-slate-400 mt-0.5 block">লাভ-ক্ষতি নির্ধারণে ব্যবহৃত</span>
            </div>
          </div>

          {/* STOCK QUANTITY & LOW STOCK THRESHOLD */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                দোকানের মজুদ (স্টক) পরিমাণ ({unit}):
              </label>
              <input
                type="number"
                step="any"
                value={stock}
                onChange={(e) => setStock(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-slate-800 font-bold"
                required
              />
            </div>
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                লো স্টক সতর্কবার্তা সীমা ({unit}):
              </label>
              <input
                type="number"
                step="any"
                value={lowStockAlert}
                onChange={(e) => setLowStockAlert(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-amber-800"
              />
              <span className="text-[10px] text-slate-400 mt-0.5 block">স্টক এর নিচে নামলে অ্যালার্ট দিবে</span>
            </div>
          </div>

          {/* BARCODE / CODE */}
          <div>
            <label className="block text-slate-700 font-semibold mb-1">
              বারকোড / পণ্য কোড (ঐচ্ছিক)
            </label>
            <input
              type="text"
              placeholder="e.g. 8941005"
              value={barcode}
              onChange={(e) => setBarcode(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono"
            />
          </div>

        </div>

        {/* Modal Footer with Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-white border border-slate-300 text-slate-700 rounded-xl font-medium hover:bg-slate-100 transition"
            >
              বন্ধ করুন
            </button>

            {editingProduct && onDeleteProduct && (
              <button
                type="button"
                onClick={() => {
                  if (confirm(`আপনি কি নিশ্চিত যে "${editingProduct.nameBn}" পণ্যটি তালিকা থেকে মুছে ফেলতে চান?`)) {
                    onDeleteProduct(editingProduct.id);
                    onClose();
                  }
                }}
                className="px-3.5 py-2.5 bg-red-50 text-red-700 border border-red-200 hover:bg-red-100 rounded-xl font-medium transition flex items-center gap-1.5"
                title="পণ্যটি সম্পূর্ণ মুছে ফেলুন"
              >
                <Trash2 className="w-4 h-4 text-red-600" />
                <span>পণ্য মুছুন</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            {!editingProduct && (
              <button
                type="button"
                onClick={() => handleSave(true)}
                className="px-4 py-2.5 bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-xl font-bold hover:bg-emerald-200 transition flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4 text-emerald-800" />
                <span>সংরক্ষণ ও আরও যোগ করুন</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => handleSave(false)}
              className="px-5 py-2.5 bg-emerald-800 hover:bg-emerald-700 text-white rounded-xl font-bold shadow-md transition flex items-center gap-1.5"
            >
              <Check className="w-4 h-4 text-emerald-300" />
              <span>{editingProduct ? 'পরিবর্তনগুলো সংরক্ষণ করুন' : 'পণ্যটি সংরক্ষণ করুন'}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
