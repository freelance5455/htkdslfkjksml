import React, { useState } from 'react';
import {
  FileSpreadsheet,
  MessageCircle,
  Copy,
  Printer,
  Check,
  Search,
  Filter,
  Users,
  Sparkles,
  Phone,
  MapPin,
  HeartHandshake,
  Calendar,
  CheckCircle2,
  Clock,
  Heart,
} from 'lucide-react';
import { useChurch } from '../../context/ChurchContext';
import { generateWhatsAppMessage, formatPhoneNumber } from '../../utils/whatsapp';

export const SecretaryView: React.FC = () => {
  const { visitors, service } = useChurch();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterFirstTime, setFilterFirstTime] = useState<'all' | 'first' | 'returning'>('all');
  const [copiedSummary, setCopiedSummary] = useState(false);

  // Filtered list
  const filtered = visitors.filter((v) => {
    const matchSearch =
      v.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (v.cityOrNeighborhood && v.cityOrNeighborhood.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (v.invitedBy && v.invitedBy.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchFirstTime =
      filterFirstTime === 'all'
        ? true
        : filterFirstTime === 'first'
        ? v.isFirstTime
        : !v.isFirstTime;

    return matchSearch && matchFirstTime;
  });

  // Calculate statistics
  const totalVisitors = visitors.length;
  const totalCompanions = visitors.reduce((acc, curr) => acc + (curr.companionCount || 0), 0);
  const totalPeople = totalVisitors + totalCompanions;
  const firstTimeCount = visitors.filter((v) => v.isFirstTime).length;
  const withPhoneCount = visitors.filter((v) => !!v.phone).length;

  // Copy structured summary for pastoral/leaders WhatsApp group
  const handleCopySummaryForGroup = () => {
    let text = `📋 *RELATÓRIO DE VISITANTES - ${service.churchName || 'NOSSA IGREJA'}*\n`;
    text += `🏛️ *Culto:* ${service.title}\n`;
    text += `👤 *Dirigente:* ${service.leaderName || 'Pastor'}\n`;
    text += `📅 *Data:* ${new Date().toLocaleDateString('pt-BR')}\n`;
    text += `👥 *Total:* ${totalPeople} pessoas (${totalVisitors} cadastros + ${totalCompanions} acompanhantes)\n\n`;

    if (visitors.length === 0) {
      text += `Nenhum visitante registrado.\n`;
    } else {
      visitors.forEach((v, idx) => {
        text += `${idx + 1}. *${v.name}*`;
        if (v.companionCount > 0) text += ` (+${v.companionCount} familiares)`;
        if (v.cityOrNeighborhood) text += ` - ${v.cityOrNeighborhood}`;
        if (v.invitedBy) text += ` (Convite: ${v.invitedBy})`;
        if (v.isFirstTime) text += ` ⭐ 1ª vez`;
        if (v.phone) text += ` 📱 ${v.phone}`;
        if (v.prayerRequest) text += `\n   ↳ Oração: "${v.prayerRequest}"`;
        text += `\n`;
      });
    }

    text += `\n_“Alegrei-me quando me disseram: Vamos à casa do SENHOR.” (Sl 122:1)_`;

    navigator.clipboard.writeText(text);
    setCopiedSummary(true);
    setTimeout(() => setCopiedSummary(false), 2500);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-[calc(100vh-105px)] bg-neutral-950 text-white p-3 sm:p-6 print:bg-white print:text-black">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 rounded-3xl bg-neutral-900/80 border border-neutral-800 p-4 sm:p-6 shadow-xl print:hidden">
          <div className="flex items-center gap-3.5">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <FileSpreadsheet className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                Secretaria & Acompanhamento
              </h2>
              <p className="text-xs sm:text-sm text-neutral-400">
                Pós-culto: Envio de mensagens no WhatsApp, relatórios e estatísticas da congregação.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={handleCopySummaryForGroup}
              className="flex items-center gap-2 rounded-2xl bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 px-4 py-2.5 text-xs sm:text-sm font-bold text-white transition"
              title="Copiar lista formatada para enviar no WhatsApp da liderança"
            >
              {copiedSummary ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4 text-amber-400" />}
              <span>{copiedSummary ? 'Copiado para o Zap!' : 'Copiar para Grupo de Obreiros'}</span>
            </button>

            <button
              onClick={handlePrint}
              className="flex items-center gap-2 rounded-2xl bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 px-4 py-2.5 text-xs sm:text-sm font-semibold text-neutral-200 transition"
              title="Imprimir lista de visitantes"
            >
              <Printer className="h-4 w-4" />
              <span>Imprimir / PDF</span>
            </button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 print:hidden">
          <div className="rounded-2xl bg-neutral-900/90 border border-neutral-800 p-4 space-y-1">
            <div className="flex items-center justify-between text-neutral-400 text-xs">
              <span>Total de Pessoas</span>
              <Users className="h-4 w-4 text-amber-400" />
            </div>
            <p className="text-2xl sm:text-3xl font-extrabold text-white">{totalPeople}</p>
            <p className="text-[11px] text-neutral-400">
              {totalVisitors} cadastros + {totalCompanions} acompanhantes
            </p>
          </div>

          <div className="rounded-2xl bg-neutral-900/90 border border-neutral-800 p-4 space-y-1">
            <div className="flex items-center justify-between text-neutral-400 text-xs">
              <span>Primeira Vez</span>
              <Sparkles className="h-4 w-4 text-emerald-400" />
            </div>
            <p className="text-2xl sm:text-3xl font-extrabold text-emerald-400">{firstTimeCount}</p>
            <p className="text-[11px] text-neutral-400">
              {totalVisitors > 0 ? `${Math.round((firstTimeCount / totalVisitors) * 100)}% dos visitantes` : '0%'}
            </p>
          </div>

          <div className="rounded-2xl bg-neutral-900/90 border border-neutral-800 p-4 space-y-1">
            <div className="flex items-center justify-between text-neutral-400 text-xs">
              <span>Com WhatsApp</span>
              <Phone className="h-4 w-4 text-emerald-400" />
            </div>
            <p className="text-2xl sm:text-3xl font-extrabold text-white">{withPhoneCount}</p>
            <p className="text-[11px] text-neutral-400">Prontos para mensagem de boas-vindas</p>
          </div>

          <div className="rounded-2xl bg-neutral-900/90 border border-neutral-800 p-4 space-y-1">
            <div className="flex items-center justify-between text-neutral-400 text-xs">
              <span>Apresentados no Altar</span>
              <CheckCircle2 className="h-4 w-4 text-amber-400" />
            </div>
            <p className="text-2xl sm:text-3xl font-extrabold text-amber-400">
              {visitors.filter((v) => v.status === 'presented').length}
            </p>
            <p className="text-[11px] text-neutral-400">Saudados pelo dirigente</p>
          </div>
        </div>

        {/* Filter and Search Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 bg-neutral-900/60 border border-neutral-800 p-3 rounded-2xl print:hidden">
          <div className="relative flex-1 min-w-[240px]">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar por nome, bairro ou quem convidou..."
              className="w-full rounded-xl bg-neutral-800 border border-neutral-700 pl-10 pr-4 py-2 text-xs sm:text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-neutral-400" />
            <div className="flex rounded-xl bg-neutral-800 p-1 border border-neutral-700 text-xs font-semibold">
              <button
                onClick={() => setFilterFirstTime('all')}
                className={`px-3 py-1 rounded-lg transition ${
                  filterFirstTime === 'all' ? 'bg-amber-500 text-neutral-950' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Todos ({visitors.length})
              </button>
              <button
                onClick={() => setFilterFirstTime('first')}
                className={`px-3 py-1 rounded-lg transition ${
                  filterFirstTime === 'first' ? 'bg-amber-500 text-neutral-950' : 'text-neutral-400 hover:text-white'
                }`}
              >
                1ª Vez
              </button>
              <button
                onClick={() => setFilterFirstTime('returning')}
                className={`px-3 py-1 rounded-lg transition ${
                  filterFirstTime === 'returning' ? 'bg-amber-500 text-neutral-950' : 'text-neutral-400 hover:text-white'
                }`}
              >
                Já Conheciam
              </button>
            </div>
          </div>
        </div>

        {/* Visitors Table / List */}
        <div className="rounded-3xl bg-neutral-900/90 border border-neutral-800 overflow-hidden shadow-xl print:border-none print:shadow-none">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-neutral-300">
              <thead className="bg-neutral-800/80 text-xs font-bold text-neutral-300 uppercase tracking-wider border-b border-neutral-700 print:bg-neutral-200 print:text-black">
                <tr>
                  <th className="px-5 py-4">Visitante & Família</th>
                  <th className="px-5 py-4">Bairro / Cidade</th>
                  <th className="px-5 py-4">Convidado Por</th>
                  <th className="px-5 py-4">Pedido de Oração</th>
                  <th className="px-5 py-4">Telefone</th>
                  <th className="px-5 py-4 text-right print:hidden">Ação no WhatsApp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800 print:divide-neutral-300">
                {filtered.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-5 py-12 text-center text-neutral-500">
                      Nenhum visitante encontrado com os filtros selecionados.
                    </td>
                  </tr>
                ) : (
                  filtered.map((visitor) => {
                    const waLink = generateWhatsAppMessage(visitor, service.churchName);

                    return (
                      <tr key={visitor.id} className="hover:bg-neutral-800/50 transition print:text-black">
                        {/* Name & Badge */}
                        <td className="px-5 py-4">
                          <div className="font-bold text-white text-base print:text-black">
                            {visitor.name}
                          </div>
                          <div className="flex items-center gap-1.5 text-xs text-neutral-400 pt-0.5">
                            {visitor.isFirstTime ? (
                              <span className="text-amber-400 font-semibold">1ª Vez</span>
                            ) : (
                              <span>Já visitou</span>
                            )}
                            {visitor.companionCount > 0 && (
                              <>
                                <span>•</span>
                                <span>+{visitor.companionCount} com ele(a) ({visitor.companionsDetails || 'família'})</span>
                              </>
                            )}
                          </div>
                        </td>

                        {/* City / Neighborhood */}
                        <td className="px-5 py-4 text-xs sm:text-sm">
                          {visitor.cityOrNeighborhood || '—'}
                        </td>

                        {/* Invited By */}
                        <td className="px-5 py-4 text-xs sm:text-sm">
                          {visitor.invitedBy ? (
                            <span className="font-medium text-amber-300 print:text-black">{visitor.invitedBy}</span>
                          ) : (
                            '—'
                          )}
                        </td>

                        {/* Prayer Request */}
                        <td className="px-5 py-4 text-xs max-w-xs">
                          {visitor.prayerRequest ? (
                            <span className="italic text-neutral-300 bg-neutral-800/60 p-1.5 rounded-lg border border-neutral-700/50 block">
                              &ldquo;{visitor.prayerRequest}&rdquo;
                            </span>
                          ) : (
                            '—'
                          )}
                        </td>

                        {/* Phone */}
                        <td className="px-5 py-4 text-xs sm:text-sm font-mono">
                          {visitor.phone || 'Não informado'}
                        </td>

                        {/* WhatsApp Action */}
                        <td className="px-5 py-4 text-right print:hidden">
                          {waLink ? (
                            <a
                              href={waLink}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1.5 text-xs shadow-md transition"
                            >
                              <MessageCircle className="h-4 w-4" />
                              <span>Enviar WhatsApp</span>
                            </a>
                          ) : (
                            <span className="text-xs text-neutral-600">Sem telefone</span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
