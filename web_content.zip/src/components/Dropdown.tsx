import React, { useState, useRef, useEffect } from "react";
import { ChevronDown, Check } from "lucide-react";

export interface DropdownItem<T = string> {
  label: string;
  value: T;
  icon?: React.ReactNode;
  fontFamily?: string;
  category?: string;
}

interface DropdownProps<T = string> {
  items: DropdownItem<T>[];
  selectedValue: T;
  onSelect: (value: T) => void;
  placeholder?: string;
  icon?: React.ReactNode;
  className?: string;
  menuWidth?: string;
  renderPreview?: boolean;
}

export function Dropdown<T = string>({
  items,
  selectedValue,
  onSelect,
  placeholder = "Seçiniz...",
  icon,
  className = "",
  menuWidth = "w-56",
  renderPreview = false,
}: DropdownProps<T>) {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Outside Click (Click Away Handler)
  useEffect(() => {
    function handleClickOutside(event: MouseEvent | TouchEvent) {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    }

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
      document.addEventListener("touchstart", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("touchstart", handleClickOutside);
    };
  }, [isOpen]);

  const selectedItem = items.find((item) => item.value === selectedValue);

  return (
    <div ref={containerRef} className={`relative inline-block text-left ${className}`}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-100 shadow-2xs hover:bg-slate-50 dark:hover:bg-slate-700/80 transition-all cursor-pointer"
        style={
          renderPreview && selectedItem?.fontFamily
            ? { fontFamily: selectedItem.fontFamily }
            : {}
        }
      >
        {icon && <span className="shrink-0">{icon}</span>}
        <span className="truncate max-w-[120px]">
          {selectedItem ? selectedItem.label : placeholder}
        </span>
        <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${isOpen ? "rotate-180" : ""}`} />
      </button>

      {/* Dropdown Menu Layer (z-50) */}
      {isOpen && (
        <div
          className={`absolute left-0 mt-1.5 ${menuWidth} rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl z-50 p-1.5 space-y-0.5 animate-in fade-in zoom-in-95 duration-150 max-h-72 overflow-y-auto scrollbar-thin`}
        >
          {items.map((item, idx) => {
            const isSelected = item.value === selectedValue;
            return (
              <button
                key={`${item.label}-${idx}`}
                type="button"
                onClick={() => {
                  onSelect(item.value);
                  setIsOpen(false);
                }}
                className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center justify-between transition-colors cursor-pointer ${
                  isSelected
                    ? "bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 font-bold"
                    : "text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 font-normal"
                }`}
                style={
                  renderPreview && item.fontFamily
                    ? { fontFamily: item.fontFamily }
                    : {}
                }
              >
                <div className="flex items-center gap-2 truncate">
                  {item.icon && <span className="shrink-0">{item.icon}</span>}
                  <span className="truncate">{item.label}</span>
                </div>
                {isSelected && <Check className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0" />}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
