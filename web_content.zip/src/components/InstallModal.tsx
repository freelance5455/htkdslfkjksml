import React, { useState } from 'react';
import { 
  Download, 
  Smartphone, 
  Apple, 
  Monitor, 
  Share2, 
  Check, 
  X, 
  Sparkles, 
  CheckCircle2, 
  WifiOff, 
  Layers
} from 'lucide-react';
import { usePWAInstall } from '../utils/usePWAInstall';

interface InstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallModal: React.FC<InstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'android' | 'ios' | 'pc'>('android');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDirectInstall = async () => {
    const success = await install();
    if (success) {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto">
      <div 
        className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-6 text-slate-100 my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 left-5 w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-12 h-12 rounded-2xl bg-red-600 text-white flex items-center justify-center shadow-lg shadow-red-950">
            <Download className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-black text-white font-heading">
              تثبيت تطبيق ScreenSound Fixer
            </h3>
            <p className="text-xs text-slate-400">
              تثبيت التطبيق كبرنامج أصلي على هاتفك يعمل دون إنترنت
            </p>
          </div>
        </div>

        {/* If browser supports native one-click install */}
        {isInstallable && (
          <div className="mb-5 bg-gradient-to-r from-red-950/60 to-slate-950 border border-red-800/60 p-4 rounded-2xl flex items-center justify-between gap-3">
            <div>
              <span className="text-sm font-bold text-white block">متصفحك يدعم التثبيت الفوري</span>
              <span className="text-xs text-slate-400">اضغط للتحميل المباشر إلى شاشة هاتفك</span>
            </div>
            <button
              onClick={handleDirectInstall}
              className="bg-red-600 hover:bg-red-700 active:scale-95 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-md transition-all cursor-pointer whitespace-nowrap"
            >
              تثبيت الآن
            </button>
          </div>
        )}

        {isInstalled && (
          <div className="mb-5 bg-emerald-950/40 border border-emerald-800 p-3 rounded-2xl flex items-center gap-2 text-xs text-emerald-300">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>التطبيق مثبت ويعمل بالفعل على جهازك في الوضع المستقل (Standalone)!</span>
          </div>
        )}

        {/* Device selector tabs */}
        <div className="grid grid-cols-3 gap-2 p-1 bg-slate-950 rounded-2xl mb-4 border border-slate-800">
          <button
            onClick={() => setActiveTab('android')}
            className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'android' ? 'bg-red-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>أندرويد (Android)</span>
          </button>

          <button
            onClick={() => setActiveTab('ios')}
            className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'ios' ? 'bg-red-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Apple className="w-3.5 h-3.5" />
            <span>آيفون (iOS)</span>
          </button>

          <button
            onClick={() => setActiveTab('pc')}
            className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'pc' ? 'bg-red-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>الكمبيوتر</span>
          </button>
        </div>

        {/* Tab Instructions Content */}
        <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800/80 text-xs text-slate-300 space-y-3 leading-relaxed">
          {activeTab === 'android' && (
            <div className="space-y-2.5">
              <span className="font-bold text-white text-sm block">
                طريقة التثبيت على هواتف أندرويد (Chrome / Samsung Internet):
              </span>
              <ol className="list-decimal list-inside space-y-2 text-slate-300">
                <li>
                  اضغط على زر <span className="font-bold text-red-400">قائمة الخيارات (⋮)</span> الموجودة في الزاوية العلوية لمتصفح Chrome.
                </li>
                <li>
                  اختر من القائمة <span className="font-bold text-white bg-slate-900 px-2 py-0.5 rounded border border-slate-700">«تثبيت التطبيق» (Install app)</span> أو <span className="font-bold text-white bg-slate-900 px-2 py-0.5 rounded border border-slate-700">«إضافة إلى الشاشة الرئيسية»</span>.
                </li>
                <li>
                  انقر على تأكيد <span className="font-bold text-emerald-400">تثبيت</span>.
                </li>
              </ol>
              <div className="mt-2 p-2.5 bg-slate-900 rounded-xl text-[11px] text-slate-400 border border-slate-800 flex items-center gap-2">
                <WifiOff className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>بعد التثبيت، ستظهر أيقونة التطبيق في شاشة هاتفك وتعمل فوراً بدون إنترنت!</span>
              </div>
            </div>
          )}

          {activeTab === 'ios' && (
            <div className="space-y-2.5">
              <span className="font-bold text-white text-sm block">
                طريقة التثبيت على هواتف iPhone وأجهزة iPad (متصفح Safari):
              </span>
              <ol className="list-decimal list-inside space-y-2 text-slate-300">
                <li>
                  افتح الرابط في متصفح <span className="font-bold text-white">Safari</span>.
                </li>
                <li>
                  اضغط على زر <span className="font-bold text-red-400">المشاركة (Share ⎘)</span> في شريط Safari السفلي.
                </li>
                <li>
                  مرر للأسفل واختر <span className="font-bold text-white bg-slate-900 px-2 py-0.5 rounded border border-slate-700">«إضافة إلى الصفحة الرئيسية» (Add to Home Screen)</span>.
                </li>
                <li>
                  اضغط على <span className="font-bold text-emerald-400">إضافة (Add)</span> في الزاوية العلوية.
                </li>
              </ol>
            </div>
          )}

          {activeTab === 'pc' && (
            <div className="space-y-2.5">
              <span className="font-bold text-white text-sm block">
                طريقة التثبيت على الكمبيوتر (Windows / Mac عبر Chrome أو Edge):
              </span>
              <p>
                انقر على أيقونة التثبيت <span className="font-bold text-white">(⬇️ أو 🖥️)</span> التي تظهر في نهاية شريط العنوان أعلى المتصفح بجوار رابط الصفحة، ثم اضغط على «تثبيت».
              </p>
            </div>
          )}
        </div>

        {/* Direct ZIP Archive Download Section */}
        <div className="mt-4 p-4 rounded-2xl bg-gradient-to-r from-red-950/70 via-slate-900 to-slate-950 border border-red-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-bold text-white mb-0.5">
              <Download className="w-4 h-4 text-red-500" />
              <span>تحميل نسخة طبق الأصل كاملة (ملف ZIP)</span>
            </div>
            <p className="text-[11px] text-slate-400">
              يحتوي الملف على الكود المصدري الأصلي الكامل، الأيقونات، الصور، ودليل التشغيل.
            </p>
          </div>

          <a
            href="/ScreenSound_Fixer_App.zip"
            download="ScreenSound_Fixer_App.zip"
            className="inline-flex items-center justify-center gap-1.5 bg-red-600 hover:bg-red-700 active:scale-95 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-md transition-all whitespace-nowrap cursor-pointer shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            <span>تنزيل ملف ZIP (1 MB)</span>
          </a>
        </div>

        {/* Copy Link for Mobile */}
        <div className="mt-4 pt-4 border-t border-slate-800 flex items-center justify-between gap-3">
          <div className="text-[11px] text-slate-400">
            لفتح التطبيق على هاتفك المحمول وتثبيته مباشرة:
          </div>

          <button
            onClick={handleCopyLink}
            className="inline-flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-3.5 py-2 rounded-xl border border-slate-700 transition-colors cursor-pointer shrink-0"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">تم نسخ الرابط!</span>
              </>
            ) : (
              <>
                <Share2 className="w-3.5 h-3.5" />
                <span>نسخ رابط التطبيق</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
