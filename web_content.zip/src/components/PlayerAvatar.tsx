import React from 'react';
import type { AvatarId } from '../shared/unoTypes';

interface PlayerAvatarProps {
  avatar: AvatarId;
  size?: 'sm' | 'md' | 'lg';
  isBot?: boolean;
  className?: string;
}

const AVATAR_STYLES: Record<AvatarId, { bg: string; fg: string }> = {
  spade: { bg: 'bg-stone-800', fg: 'text-amber-300' },
  diamond: { bg: 'bg-sky-900', fg: 'text-sky-300' },
  flame: { bg: 'bg-rose-900', fg: 'text-rose-300' },
  bolt: { bg: 'bg-emerald-900', fg: 'text-emerald-300' },
  crown: { bg: 'bg-amber-900', fg: 'text-amber-200' },
  prism: { bg: 'bg-violet-900', fg: 'text-violet-300' },
};

export const AVATAR_OPTIONS: Array<{ id: AvatarId; label: string }> = [
  { id: 'spade', label: 'Sekop' },
  { id: 'diamond', label: 'Wajik' },
  { id: 'flame', label: 'Api' },
  { id: 'bolt', label: 'Petir' },
  { id: 'crown', label: 'Mahkota' },
  { id: 'prism', label: 'Prisma' },
];

export const PlayerAvatar: React.FC<PlayerAvatarProps> = ({
  avatar,
  size = 'md',
  isBot = false,
  className = '',
}) => {
  const style = AVATAR_STYLES[avatar] ?? AVATAR_STYLES.spade;
  const sizeClass =
    size === 'sm' ? 'w-8 h-8' : size === 'lg' ? 'w-12 h-12' : 'w-10 h-10';
  const iconSize = size === 'sm' ? 16 : size === 'lg' ? 24 : 20;

  return (
    <div
      className={`${sizeClass} ${style.bg} ${style.fg} rounded-xl flex items-center justify-center shrink-0 border border-white/15 shadow-sm relative ${className}`}
      aria-hidden="true"
    >
      {isBot ? (
        <svg width={iconSize} height={iconSize} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <rect x="4" y="7" width="16" height="12" rx="3" />
          <path d="M12 3v4" />
          <circle cx="9" cy="13" r="1.2" fill="currentColor" />
          <circle cx="15" cy="13" r="1.2" fill="currentColor" />
        </svg>
      ) : avatar === 'spade' ? (
        <svg width={iconSize} height={iconSize} viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 3C8 8 4 11 4 14.5C4 17 6 19 8.5 19C10 19 11 18.2 11.4 17.5C11.2 19.3 10.5 20.4 9.2 21H14.8C13.5 20.4 12.8 19.3 12.6 17.5C13 18.2 14 19 15.5 19C18 19 20 17 20 14.5C20 11 16 8 12 3Z" />
        </svg>
      ) : avatar === 'diamond' ? (
        <svg width={iconSize} height={iconSize} viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 2.5L20 12L12 21.5L4 12L12 2.5Z" />
        </svg>
      ) : avatar === 'flame' ? (
        <svg width={iconSize} height={iconSize} viewBox="0 0 24 24" fill="currentColor">
          <path d="M12.5 2.5C12.5 2.5 18 7.2 18 13.2C18 17.4 15.3 21 11.8 21C8.3 21 6 18.1 6 14.4C6 11.4 7.7 8.8 9.2 7.2C9.1 9.1 10.1 10.3 11.2 10.5C10.7 8 11.4 4.8 12.5 2.5Z" />
        </svg>
      ) : avatar === 'bolt' ? (
        <svg width={iconSize} height={iconSize} viewBox="0 0 24 24" fill="currentColor">
          <path d="M13.5 2L5 13.5H11.5L10.5 22L19 10.5H12.5L13.5 2Z" />
        </svg>
      ) : avatar === 'crown' ? (
        <svg width={iconSize} height={iconSize} viewBox="0 0 24 24" fill="currentColor">
          <path d="M3.5 18.5H20.5V20.5H3.5V18.5ZM3.5 7.5L8 11.5L12 5L16 11.5L20.5 7.5L19 16.5H5L3.5 7.5Z" />
        </svg>
      ) : (
        <svg width={iconSize} height={iconSize} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinejoin="round">
          <polygon points="12 3 21 19 3 19" />
          <line x1="12" y1="3" x2="12" y2="19" />
        </svg>
      )}
    </div>
  );
};
