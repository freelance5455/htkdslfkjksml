import { useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Field, Input, Textarea } from "@/components/ui/input";
import { postOperation } from "@/lib/accounting/actions";
import { AccountingError, buildJournalLines } from "@/lib/accounting/engine";
import { formatJalaliLong, formatRial, OP_LABELS, parseFaNumber, todayIso } from "@/lib/accounting/format";
import type { OpType, PostingInput } from "@/lib/accounting/types";
import { booksFromBootstrap, useBootstrap, useInvalidateBooks } from "@/lib/accounting/use-books";
import { cn } from "@/lib/utils";

function kindsFor(t: OpType): string[] | null {
  if (["receipt", "sale_cash", "sale_credit", "sale_mixed", "sale_return", "sale_discount", "advance", "check_receive", "check_return"].includes(t))
    return ["customer"];
  if (["payment", "purchase_cash", "purchase_credit", "purchase_return", "purchase_discount", "prepay", "check_pay"].includes(t))
    return ["supplier"];
  if (["draw", "capital_in"].includes(t)) return ["shareholder"];
  if (["payroll"].includes(t)) return ["employee"];
  return null;
}

export function OpForm({ initialType }: { initialType?: OpType }) {
  const nav = useNavigate();
  const boot = useBootstrap();
  const invalidate = useInvalidateBooks();
  const [opType, setOpType] = useState<OpType>(initialType ?? "receipt");
  const [date, setDate] = useState(todayIso());
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [partyId, setPartyId] = useState("");
  const [cashAccountId, setCashAccountId] = useState("");
  const [destCashAccountId, setDestCashAccountId] = useState("");
  const [expenseAccountId, setExpenseAccountId] = useState("");
  const [incomeAccountId, setIncomeAccountId] = useState("");
  const [cashPortion, setCashPortion] = useState("");
  const [checkNumber, setCheckNumber] = useState("");
  const [checkDueDate, setCheckDueDate] = useState("");
  const [checkBankName, setCheckBankName] = useState("");
  const [manual, setManual] = useState([{ accountId: "", debit: "", credit: "" }]);
  const [busy, setBusy] = useState(false);

  const books = useMemo(() => (boot.data ? booksFromBootstrap(boot.data) : null), [boot.data]);
  const parties = boot.data?.parties ?? [];
  const cash = boot.data?.cashAccounts ?? [];
  const postable = (boot.data?.accounts ?? []).filter((a) => a.isPostable);
  const expenses = postable.filter((a) => a.groupCode === "expense");
  const incomes = postable.filter((a) => a.groupCode === "income");

  const input: PostingInput = {
    opType,
    date,
    amount: parseFaNumber(amount),
    description,
    partyId: partyId || undefined,
    cashAccountId: cashAccountId || undefined,
    destCashAccountId: destCashAccountId || undefined,
    expenseAccountId: expenseAccountId || undefined,
    incomeAccountId: incomeAccountId || undefined,
    cashPortion: cashPortion ? parseFaNumber(cashPortion) : undefined,
    checkNumber: checkNumber || undefined,
    checkDueDate: checkDueDate || undefined,
    checkBankName: checkBankName || undefined,
    lines:
      opType === "manual" || opType === "adjustment"
        ? manual
            .filter((l) => l.accountId)
            .map((l) => ({
              accountId: l.accountId,
              debit: parseFaNumber(l.debit),
              credit: parseFaNumber(l.credit),
            }))
        : undefined,
  };

  let preview: { lines: ReturnType<typeof buildJournalLines>; error?: string } | null = null;
  if (books) {
    try {
      preview = { lines: buildJournalLines(input, books) };
    } catch (e) {
      preview = { lines: [], error: e instanceof Error ? e.message : "خطا" };
    }
  }

  const partyKinds = kindsFor(opType);
  const filteredParties = partyKinds ? parties.filter((p) => partyKinds.includes(p.kind)) : parties;
  const needsParty = partyKinds !== null;
  const needsCash = [
    "receipt",
    "receipt_other",
    "payment",
    "payment_other",
    "transfer",
    "sale_cash",
    "sale_mixed",
    "purchase_cash",
    "expense_cash",
    "income",
    "check_collect",
    "capital_in",
    "draw",
    "petty_fund",
    "prepay",
    "advance",
    "payroll",
  ].includes(opType);
  const needsDest = opType === "transfer";
  const needsExpense = ["expense_cash", "expense_payable", "payment_other", "petty_settle"].includes(opType);
  const needsIncome = ["income", "receipt_other"].includes(opType);
  const isManual = opType === "manual" || opType === "adjustment";
  const isCheck = opType.startsWith("check_");

  async function submit() {
    setBusy(true);
    try {
      const res = await postOperation({ data: input });
      toast.success(`ثبت شد — ${res.operationNumber} / ${res.journalNumber}`);
      invalidate();
      nav({ to: "/operations" });
    } catch (e) {
      const msg = e instanceof AccountingError || e instanceof Error ? e.message : "ثبت ناموفق بود";
      toast.error(msg);
    } finally {
      setBusy(false);
    }
  }

  if (boot.isLoading) return <div className="h-64 animate-pulse rounded-[24px] bg-secondary" />;

  return (
    <div className="grid gap-5 lg:grid-cols-[1.15fr_0.85fr]">
      <Card className="space-y-4">
        <Field label="نوع عملیات">
          <select
            value={opType}
            onChange={(e) => setOpType(e.target.value as OpType)}
            className="h-11 w-full rounded-[10px] border border-line bg-paper px-3 text-sm"
          >
            {Object.entries(OP_LABELS).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </select>
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="تاریخ">
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            <div className="mt-1 text-[11px] text-muted">{formatJalaliLong(date)}</div>
          </Field>
          {!isManual ? (
            <Field label="مبلغ (ریال)">
              <Input inputMode="numeric" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="مثلاً 25000000" />
            </Field>
          ) : null}
        </div>
        {needsParty ? (
          <Field label="شخص">
            <select
              value={partyId}
              onChange={(e) => setPartyId(e.target.value)}
              className="h-11 w-full rounded-[10px] border border-line bg-paper px-3 text-sm"
            >
              <option value="">انتخاب کنید</option>
              {filteredParties.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.code} — {p.name}
                </option>
              ))}
            </select>
          </Field>
        ) : null}
        {needsCash ? (
          <Field label={opType === "transfer" ? "مبدأ" : "منبع مالی"}>
            <select
              value={cashAccountId}
              onChange={(e) => setCashAccountId(e.target.value)}
              className="h-11 w-full rounded-[10px] border border-line bg-paper px-3 text-sm"
            >
              <option value="">انتخاب کنید</option>
              {cash.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </Field>
        ) : null}
        {needsDest ? (
          <Field label="مقصد">
            <select
              value={destCashAccountId}
              onChange={(e) => setDestCashAccountId(e.target.value)}
              className="h-11 w-full rounded-[10px] border border-line bg-paper px-3 text-sm"
            >
              <option value="">انتخاب کنید</option>
              {cash.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </Field>
        ) : null}
        {needsExpense ? (
          <Field label="حساب هزینه">
            <select
              value={expenseAccountId}
              onChange={(e) => setExpenseAccountId(e.target.value)}
              className="h-11 w-full rounded-[10px] border border-line bg-paper px-3 text-sm"
            >
              <option value="">انتخاب کنید</option>
              {expenses.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.code} {a.name}
                </option>
              ))}
            </select>
          </Field>
        ) : null}
        {needsIncome ? (
          <Field label="حساب درآمد">
            <select
              value={incomeAccountId}
              onChange={(e) => setIncomeAccountId(e.target.value)}
              className="h-11 w-full rounded-[10px] border border-line bg-paper px-3 text-sm"
            >
              <option value="">انتخاب کنید</option>
              {incomes.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.code} {a.name}
                </option>
              ))}
            </select>
          </Field>
        ) : null}
        {opType === "sale_mixed" ? (
          <Field label="سهم نقدی (ریال)">
            <Input inputMode="numeric" value={cashPortion} onChange={(e) => setCashPortion(e.target.value)} />
          </Field>
        ) : null}
        {isCheck ? (
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="شماره چک">
              <Input value={checkNumber} onChange={(e) => setCheckNumber(e.target.value)} />
            </Field>
            <Field label="سررسید">
              <Input type="date" value={checkDueDate} onChange={(e) => setCheckDueDate(e.target.value)} />
            </Field>
            <Field label="بانک عهده">
              <Input value={checkBankName} onChange={(e) => setCheckBankName(e.target.value)} />
            </Field>
          </div>
        ) : null}
        {isManual ? (
          <div className="space-y-2">
            <div className="text-xs font-medium text-muted">ردیف‌های سند</div>
            {manual.map((row, i) => (
              <div key={i} className="grid grid-cols-[1.4fr_0.7fr_0.7fr] gap-2">
                <select
                  value={row.accountId}
                  onChange={(e) => {
                    const next = [...manual];
                    next[i] = { ...row, accountId: e.target.value };
                    setManual(next);
                  }}
                  className="h-10 rounded-[10px] border border-line bg-paper px-2 text-xs"
                >
                  <option value="">حساب</option>
                  {postable.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.code} {a.name}
                    </option>
                  ))}
                </select>
                <Input
                  placeholder="بدهکار"
                  value={row.debit}
                  onChange={(e) => {
                    const next = [...manual];
                    next[i] = { ...row, debit: e.target.value };
                    setManual(next);
                  }}
                />
                <Input
                  placeholder="بستانکار"
                  value={row.credit}
                  onChange={(e) => {
                    const next = [...manual];
                    next[i] = { ...row, credit: e.target.value };
                    setManual(next);
                  }}
                />
              </div>
            ))}
            <Button type="button" variant="outline" size="sm" onClick={() => setManual([...manual, { accountId: "", debit: "", credit: "" }])}>
              ردیف جدید
            </Button>
          </div>
        ) : null}
        <Field label="شرح">
          <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} />
        </Field>
        <Button type="button" variant="gold" className="w-full" disabled={busy || !!preview?.error} onClick={submit}>
          {busy ? "در حال ثبت…" : "ثبت عملیات و صدور سند دوبل"}
        </Button>
      </Card>

      <Card className="h-fit">
        <div className="text-sm font-medium text-navy">پیش‌نمایش سند حسابداری</div>
        <p className="mt-1 text-xs text-muted">تا وقتی بدهکار با بستانکار برابر نباشد، ثبت نهایی متوقف می‌شود.</p>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-muted">
                <th className="pb-2 text-right font-medium">حساب</th>
                <th className="pb-2 text-left font-medium">بدهکار</th>
                <th className="pb-2 text-left font-medium">بستانکار</th>
              </tr>
            </thead>
            <tbody>
              {preview?.lines.map((l, i) => (
                <tr key={i} className="border-t border-line">
                  <td className="py-2">
                    <div>{l.accountName}</div>
                    <div className="text-[10px] text-muted">{l.accountCode}</div>
                  </td>
                  <td className="py-2 text-left tabular" dir="ltr">
                    {l.debit ? formatRial(l.debit) : ""}
                  </td>
                  <td className="py-2 text-left tabular" dir="ltr">
                    {l.credit ? formatRial(l.credit) : ""}
                  </td>
                </tr>
              ))}
            </tbody>
            {preview?.lines.length ? (
              <tfoot>
                <tr className="border-t border-navy/20 font-medium">
                  <td className="py-2">جمع</td>
                  <td className="py-2 text-left tabular" dir="ltr">
                    {formatRial(preview.lines.reduce((s, l) => s + l.debit, 0))}
                  </td>
                  <td className="py-2 text-left tabular" dir="ltr">
                    {formatRial(preview.lines.reduce((s, l) => s + l.credit, 0))}
                  </td>
                </tr>
              </tfoot>
            ) : null}
          </table>
        </div>
        {preview?.error ? (
          <div className="mt-3 rounded-[12px] bg-danger/10 px-3 py-2 text-xs text-danger">{preview.error}</div>
        ) : preview?.lines.length ? (
          <div className={cn("mt-3 rounded-[12px] px-3 py-2 text-xs", "bg-success/10 text-success")}>تراز برقرار است.</div>
        ) : null}
      </Card>
    </div>
  );
}
