import React from 'react';

interface ABLogoProps {
  size?: number;
  className?: string;
  glow?: boolean;
}

export const ABLogo: React.FC<ABLogoProps> = ({ size = 160, className = '', glow = true }) => {
  return (
    <div
      style={{ width: size, height: size }}
      className={`relative flex items-center justify-center ${className}`}
    >
      {/* Outer ambient glow */}
      {glow && (
        <div
          className="absolute inset-0 rounded-full blur-xl opacity-60 animate-pulse pointer-events-none"
          style={{
            background: 'radial-gradient(circle, rgba(226,192,103,0.45) 0%, rgba(184,146,48,0.15) 60%, transparent 80%)',
          }}
        />
      )}

      {/* SVG Emblem */}
      <svg
        viewBox="0 0 200 200"
        width={size}
        height={size}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="relative z-10 transition-transform duration-500 hover:scale-105"
      >
        <defs>
          {/* Metallic Gold Gradients */}
          <linearGradient id="abGoldGrad" x1="20" y1="20" x2="180" y2="180" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#FFF2B2" />
            <stop offset="25%" stopColor="#E2C067" />
            <stop offset="50%" stopColor="#B89230" />
            <stop offset="75%" stopColor="#F5DC8C" />
            <stop offset="100%" stopColor="#9E761E" />
          </linearGradient>

          <linearGradient id="abRingGrad" x1="0" y1="0" x2="200" y2="200" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#E2C067" />
            <stop offset="50%" stopColor="#1E3258" />
            <stop offset="100%" stopColor="#E2C067" />
          </linearGradient>

          <radialGradient id="abCenterAura" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#112244" />
            <stop offset="85%" stopColor="#081225" />
          </radialGradient>

          <filter id="abGlowFilter" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Center Base Circle */}
        <circle cx="100" cy="100" r="92" fill="url(#abCenterAura)" stroke="url(#abRingGrad)" strokeWidth="2.5" />

        {/* Inner Tech Ring with ticks */}
        <circle cx="100" cy="100" r="82" stroke="#E2C067" strokeWidth="1" strokeDasharray="6 8" opacity="0.4" />
        <circle cx="100" cy="100" r="72" stroke="#E2C067" strokeWidth="1.5" opacity="0.7" />

        {/* Monogram Crest "AB" */}
        <g filter="url(#abGlowFilter)">
          {/* Letter A */}
          <path
            d="M 64 146 L 96 54 L 110 54 L 138 146 L 121 146 L 114 122 L 78 122 L 72 146 Z M 83 108 L 109 108 L 96 68 Z"
            fill="url(#abGoldGrad)"
          />

          {/* Letter B overlaid & intertwined */}
          <path
            d="M 98 54 L 130 54 C 146 54 156 62 156 74 C 156 83 150 90 140 94 C 153 98 160 107 160 120 C 160 137 146 146 128 146 L 98 146 Z M 114 68 L 114 92 L 129 92 C 137 92 142 87 142 80 C 142 73 137 68 129 68 Z M 114 106 L 114 132 L 131 132 C 140 132 145 127 145 119 C 145 111 140 106 131 106 Z"
            fill="url(#abGoldGrad)"
            opacity="0.95"
          />

          {/* Stylized soundwave / microphone dot accent */}
          <circle cx="100" cy="34" r="3.5" fill="#FFF2B2" />
          <path d="M 88 34 C 88 27.37 93.37 22 100 22 C 106.63 22 112 27.37 112 34" stroke="#E2C067" strokeWidth="2" strokeLinecap="round" opacity="0.8" />
          <path d="M 80 34 C 80 22.95 88.95 14 100 14 C 111.05 14 120 22.95 120 34" stroke="#E2C067" strokeWidth="1.5" strokeLinecap="round" opacity="0.5" />
        </g>
      </svg>
    </div>
  );
};
