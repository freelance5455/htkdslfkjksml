import React, { useState, useMemo } from 'react';
import { 
  ShoppingBag, 
  Search, 
  Star, 
  X, 
  Plus, 
  Minus, 
  Check, 
  ShieldCheck, 
  Truck, 
  CreditCard, 
  ArrowRight,
  Phone,
  MapPin,
  Sparkles,
  ExternalLink,
  ChevronLeft,
  Play,
  Film,
  Eye,
  Video,
  Layers,
  Info
} from 'lucide-react';
import { Store, Product, CartItem, Order, Language, PaymentMethod, AbandonedCheckout, ShippingSettings } from '../../types';
import { calculateDeliveryCharge, ALL_BD_DISTRICTS, getStoreLocationDistrict, BDDistrict } from '../../utils/deliveryLocationService';

interface LiveStorefrontProps {
  activeStore: Store;
  products: Product[];
  language: Language;
  cart: CartItem[];
  isCartOpen: boolean;
  shippingSettings?: ShippingSettings | null;
  onCloseCart: () => void;
  onAddToCart: (product: Product) => void;
  onUpdateCartQuantity: (productId: string, qty: number) => void;
  onClearCart: () => void;
  onCreateOrder: (newOrder: Order) => void;
  onSaveAbandonedCheckout?: (session: AbandonedCheckout) => void;
  onBackToDashboard: () => void;
}

export const LiveStorefront: React.FC<LiveStorefrontProps> = ({
  activeStore,
  products,
  language,
  cart,
  isCartOpen,
  shippingSettings,
  onCloseCart,
  onAddToCart,
  onUpdateCartQuantity,
  onClearCart,
  onCreateOrder,
  onSaveAbandonedCheckout,
  onBackToDashboard,
}) => {
  const isBn = language === 'bn';
  const theme = activeStore.theme;

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [activeMediaTab, setActiveMediaTab] = useState<'photo' | 'video'>('photo');
  const [quickViewQty, setQuickViewQty] = useState<number>(1);

  // Checkout Modal State
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState<'details' | 'payment' | 'success'>('details');

  // Checkout form fields
  const [customerName, setCustomerName] = useState('Kamrul Hassan');
  const [customerPhone, setCustomerPhone] = useState('+880 1711-889900');
  const [customerEmail, setCustomerEmail] = useState('kamrul.h@example.com');
  const [customerAddress, setCustomerAddress] = useState('Flat 4B, Concord Tower, Road 18');
  const storeOriginDistrict = useMemo(() => {
    return getStoreLocationDistrict(activeStore);
  }, [activeStore]);

  const [customerCity, setCustomerCity] = useState<string>(() => {
    return getStoreLocationDistrict(activeStore) || 'Sylhet';
  });
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('bkash');
  const [couponCode, setCouponCode] = useState('');
  const [couponApplied, setCouponApplied] = useState(false);
  const [lastCreatedOrder, setLastCreatedOrder] = useState<Order | null>(null);

  // Store's active products
  const storeProducts = products.filter((p) => p.storeId === activeStore.id);
  const categories = ['All', ...Array.from(new Set(storeProducts.map((p) => p.category)))];

  const filteredProducts = storeProducts.filter((p) => {
    const matchesCat = selectedCategory === 'All' || p.category === selectedCategory;
    const matchesSearch = 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.nameBn.includes(searchQuery);
    return matchesCat && matchesSearch;
  });

  // Calculate cart totals with store-location dynamic delivery calculation
  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const discount = couponApplied ? Math.round(subtotal * 0.15) : 0;
  
  // DYNAMIC DELIVERY CALCULATION RELATIVE TO THIS STORE'S LOCATION
  const deliveryResult = useMemo(() => {
    return calculateDeliveryCharge(
      customerCity,
      activeStore,
      shippingSettings,
      subtotal
    );
  }, [customerCity, activeStore, shippingSettings, subtotal]);

  const shippingFee = subtotal > 0 ? deliveryResult.charge : 0;
  const totalAmount = Math.max(0, subtotal - discount + shippingFee);

  const handleCartClose = () => {
    if (cart.length > 0 && (customerName || customerPhone) && checkoutStep !== 'success') {
      if (onSaveAbandonedCheckout) {
        onSaveAbandonedCheckout({
          id: `ac-${Date.now()}`,
          storeId: activeStore.id,
          customerName: customerName.trim() || 'Visitor',
          customerPhone: customerPhone.trim(),
          customerEmail: customerEmail.trim(),
          deliveryAddress: customerAddress.trim(),
          city: customerCity,
          items: cart.map(i => ({
            productId: i.product.id,
            name: i.product.name,
            price: i.product.price,
            quantity: i.quantity,
            image: i.product.image
          })),
          cartTotal: totalAmount,
          recoveryStatus: 'incomplete',
          createdAt: new Date().toISOString()
        });
      }
    }
    onCloseCart();
  };

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (couponCode.toUpperCase() === 'AURA15' || couponCode.toUpperCase() === 'EID15' || couponCode.toUpperCase() === 'SAVE15') {
      setCouponApplied(true);
    } else {
      alert(isBn ? 'ভুল কুপন কোড! অনুগ্রহ করে AURA15 কোডটি ব্যবহার করুন।' : 'Invalid coupon code. Try AURA15 for 15% discount!');
    }
  };

  const handleConfirmOrder = () => {
    const newOrderNumber = `ORD-${Math.floor(10000 + Math.random() * 90000)}`;
    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderNumber: newOrderNumber,
      storeId: activeStore.id,
      customerName,
      customerPhone,
      customerEmail,
      items: cart.map((i) => ({
        productId: i.product.id,
        name: i.product.name,
        price: i.product.price,
        quantity: i.quantity,
        image: i.product.image,
      })),
      subtotal,
      discount,
      shippingFee,
      totalAmount,
      deliveryZone: deliveryResult.deliveryZone,
      deliveryCharge: shippingFee,
      storeLocationAtOrder: {
        district: deliveryResult.storeLocationSummary,
        city: deliveryResult.storeLocationSummary,
        division: activeStore.storeLocation?.division || 'Sylhet'
      },
      paymentMethod,
      paymentStatus: 'pending',
      orderStatus: 'pending',
      deliveryAddress: customerAddress,
      city: customerCity,
      createdAt: new Date().toISOString(),
    };

    onCreateOrder(newOrder);
    setLastCreatedOrder(newOrder);
    onClearCart();
    setCheckoutStep('success');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-16">
      {/* Top Merchant Switcher Banner for preview context */}
      <div className="bg-slate-900 text-white text-xs px-4 py-2 flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span className="font-semibold text-slate-300">
            {isBn ? 'লাইভ পাবলিক স্টোরফ্রন্ট প্রিভিউ' : 'Live Storefront View — How shoppers experience your store'}
          </span>
          <span className="font-mono text-emerald-400 font-bold">({activeStore.slug}.shanju.cloud)</span>
        </div>
        <button
          onClick={onBackToDashboard}
          className="flex items-center gap-1 text-xs font-bold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 px-3 py-1 rounded-lg transition-colors"
        >
          <ChevronLeft className="w-3.5 h-3.5" />
          <span>{isBn ? 'মার্চেন্ট কনসোলে ফিরে যান' : 'Back to Merchant Dashboard'}</span>
        </button>
      </div>

      {/* Store Announcement Bar */}
      {theme.showAnnouncement && (
        <div 
          className="py-2 px-4 text-xs font-bold text-white text-center tracking-wide transition-colors"
          style={{ backgroundColor: theme.primaryColor }}
        >
          {isBn ? theme.announcementTextBn : theme.announcementText}
        </div>
      )}

      {/* Storefront Navigation Bar */}
      <nav className="bg-white border-b border-slate-200 sticky top-16 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img 
              src={activeStore.logo} 
              alt={activeStore.name} 
              className="w-10 h-10 rounded-xl object-cover border border-slate-200 shadow-xs"
            />
            <div>
              <div className="font-extrabold text-lg tracking-tight text-slate-900">
                {activeStore.name}
              </div>
              <div className="text-[11px] text-slate-500 font-medium">
                {activeStore.category}
              </div>
            </div>
          </div>

          {/* Search bar */}
          <div className="hidden md:block relative w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={isBn ? 'পণ্য খুঁজুন...' : 'Search store catalog...'}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-100 border border-slate-200 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-slate-400"
            />
          </div>

          {/* Cart Icon */}
          <div className="flex items-center gap-3">
            <button
              id="store-header-cart-btn"
              onClick={() => onCloseCart()} // toggle handled in parent
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-white text-xs font-bold shadow-xs transition-transform hover:scale-105"
              style={{ backgroundColor: theme.primaryColor }}
            >
              <ShoppingBag className="w-4 h-4" />
              <span>{isBn ? 'ব্যাগ' : 'Bag'}</span>
              <span className="w-5 h-5 rounded-full bg-white text-slate-900 text-[11px] font-black flex items-center justify-center">
                {cart.reduce((a, b) => a + b.quantity, 0)}
              </span>
            </button>
          </div>
        </div>
      </nav>

      {/* Store Hero Banner */}
      <section className="relative overflow-hidden bg-slate-900 text-white min-h-[360px] flex items-center">
        <img
          src={theme.heroBannerImage}
          alt="Banner"
          className="absolute inset-0 w-full h-full object-cover brightness-[0.42] scale-105"
        />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 relative z-10 w-full">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur-sm text-white text-xs font-semibold mb-4 border border-white/20">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isBn ? 'নতুন কালেকশন লাইভ' : 'Curated New Arrivals'}</span>
            </div>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight leading-tight drop-shadow-md">
              {isBn ? theme.heroHeadlineBn : theme.heroHeadline}
            </h1>
            <p className="mt-4 text-sm sm:text-base text-slate-200 leading-relaxed drop-shadow">
              {isBn ? theme.heroSubheadlineBn : theme.heroSubheadline}
            </p>
            <div className="mt-6 flex items-center gap-3">
              <a
                href="#catalog-grid"
                className="px-6 py-3 rounded-xl text-xs font-bold text-white shadow-lg transition-transform hover:scale-105"
                style={{ backgroundColor: theme.primaryColor }}
              >
                {isBn ? 'কালেকশন দেখুন' : 'Explore Catalog'}
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Category Pills & Catalog Grid */}
      <main id="catalog-grid" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-6 border-b border-slate-200">
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
              {isBn ? 'সকল পণ্য ও কালেকশন' : 'Shop Collections'}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {filteredProducts.length} {isBn ? 'টি পণ্য পাওয়া গেছে' : 'products available'}
            </p>
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                  selectedCategory === cat
                    ? 'text-white shadow-xs'
                    : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                }`}
                style={selectedCategory === cat ? { backgroundColor: theme.primaryColor } : {}}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Product Cards Grid */}
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => {
            const discountPct = product.compareAtPrice 
              ? Math.round(((product.compareAtPrice - product.price) / product.compareAtPrice) * 100)
              : null;

            return (
              <div
                key={product.id}
                onClick={() => {
                  setQuickViewProduct(product);
                  setActiveMediaTab(product.videoUrl ? 'video' : 'photo');
                  setQuickViewQty(1);
                }}
                className="bg-white rounded-2xl border border-slate-200/90 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between group cursor-pointer"
              >
                <div className="relative aspect-square overflow-hidden bg-slate-100">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  {discountPct && (
                    <span className="absolute top-3 left-3 px-2 py-0.5 rounded-lg bg-rose-500 text-white font-bold text-[10px] shadow">
                      {discountPct}% OFF
                    </span>
                  )}
                  {product.isFeatured && (
                    <span className="absolute top-3 right-3 px-2 py-0.5 rounded-lg bg-amber-400 text-slate-950 font-bold text-[10px] shadow">
                      Featured
                    </span>
                  )}

                  {/* Video Play Badge Button */}
                  {product.videoUrl && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setQuickViewProduct(product);
                        setActiveMediaTab('video');
                        setQuickViewQty(1);
                      }}
                      className="absolute bottom-3 left-3 px-2.5 py-1 rounded-xl bg-slate-950/85 hover:bg-slate-950 text-white text-[11px] font-bold flex items-center gap-1.5 shadow-md backdrop-blur-xs transition-transform hover:scale-105 z-10"
                    >
                      <Play className="w-3 h-3 fill-emerald-400 text-emerald-400" />
                      <span>{isBn ? 'ভিডিও দেখুন' : 'Watch Video'}</span>
                    </button>
                  )}

                  {/* Quick View Button on Image */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setQuickViewProduct(product);
                      setActiveMediaTab(product.videoUrl ? 'video' : 'photo');
                      setQuickViewQty(1);
                    }}
                    className="absolute bottom-3 right-3 p-2 rounded-xl bg-white/90 hover:bg-white text-slate-700 hover:text-slate-900 shadow-md backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity z-10"
                    title={isBn ? 'বিস্তারিত দেখুন' : 'Quick View'}
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                </div>

                <div className="p-4 flex flex-col justify-between flex-1">
                  <div>
                    <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      {isBn ? product.categoryBn : product.category}
                    </span>
                    <h3 className="font-bold text-sm text-slate-900 mt-1 line-clamp-1 group-hover:text-emerald-700 transition-colors">
                      {isBn ? product.nameBn : product.name}
                    </h3>
                    <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                      {isBn ? product.descriptionBn : product.description}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between" onClick={(e) => e.stopPropagation()}>
                    <div>
                      <div className="text-base font-black text-slate-900">
                        ৳{product.price.toLocaleString()}
                      </div>
                      {product.compareAtPrice && (
                        <div className="text-xs text-slate-400 line-through">
                          ৳{product.compareAtPrice.toLocaleString()}
                        </div>
                      )}
                    </div>

                    <button
                      id={`add-to-cart-${product.id}`}
                      onClick={() => onAddToCart(product)}
                      className="px-3.5 py-2 rounded-xl text-white text-xs font-bold shadow-xs transition-transform hover:scale-105 flex items-center gap-1.5"
                      style={{ backgroundColor: theme.primaryColor }}
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>{isBn ? 'অর্ডার করুন' : 'Add to Bag'}</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </main>

      {/* Product Quick View & Media Modal (Video & Photo Player) */}
      {quickViewProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          <div 
            onClick={() => setQuickViewProduct(null)}
            className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs transition-opacity"
          />

          <div className="relative bg-white rounded-3xl max-w-3xl w-full overflow-hidden shadow-2xl border border-slate-200 z-10 my-auto flex flex-col md:flex-row max-h-[90vh]">
            {/* Close Button */}
            <button
              onClick={() => setQuickViewProduct(null)}
              className="absolute top-4 right-4 z-20 w-8 h-8 rounded-full bg-white/80 hover:bg-white text-slate-700 shadow-md backdrop-blur-xs flex items-center justify-center transition-transform hover:scale-105"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Left: Media Area (Photo or Video Player) */}
            <div className="md:w-1/2 bg-slate-950 flex flex-col justify-between p-3 relative">
              <div className="flex-1 flex items-center justify-center min-h-[280px] sm:min-h-[350px] overflow-hidden rounded-2xl bg-black">
                {activeMediaTab === 'video' && quickViewProduct.videoUrl ? (
                  <video
                    src={quickViewProduct.videoUrl}
                    controls
                    autoPlay
                    playsInline
                    className="w-full h-full object-contain max-h-[360px]"
                  />
                ) : (
                  <img
                    src={quickViewProduct.image}
                    alt={quickViewProduct.name}
                    className="w-full h-full object-cover max-h-[360px] rounded-2xl"
                  />
                )}
              </div>

              {/* Media Switcher Tab (Photo vs Video) */}
              {quickViewProduct.videoUrl && (
                <div className="pt-3 flex items-center justify-center gap-2">
                  <button
                    type="button"
                    onClick={() => setActiveMediaTab('photo')}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      activeMediaTab === 'photo'
                        ? 'bg-white text-slate-900 shadow'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    <span>📷 {isBn ? 'ফটো ভিউ' : 'Photo'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveMediaTab('video')}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                      activeMediaTab === 'video'
                        ? 'bg-purple-600 text-white shadow'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    <Play className="w-3 h-3 fill-current" />
                    <span>🎬 {isBn ? 'ভিডিও রিল প্লেয়ার' : 'Video Reel'}</span>
                  </button>
                </div>
              )}
            </div>

            {/* Right: Product Info & Add to Bag */}
            <div className="md:w-1/2 p-6 flex flex-col justify-between overflow-y-auto">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    {isBn ? quickViewProduct.categoryBn : quickViewProduct.category}
                  </span>
                  <span className="text-[11px] font-mono text-slate-400">
                    {quickViewProduct.sku}
                  </span>
                </div>

                <h2 className="text-xl font-black text-slate-900 mt-1">
                  {isBn ? quickViewProduct.nameBn : quickViewProduct.name}
                </h2>

                {/* Rating */}
                <div className="flex items-center gap-2 mt-2">
                  <div className="flex text-amber-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-current" />
                    ))}
                  </div>
                  <span className="text-xs font-bold text-slate-700">{quickViewProduct.rating || 4.9}</span>
                  <span className="text-xs text-slate-400">({quickViewProduct.reviewsCount || 24} {isBn ? 'রিভিউ' : 'reviews'})</span>
                </div>

                {/* Price Section */}
                <div className="flex items-baseline gap-3 mt-4">
                  <span className="text-2xl font-black text-slate-900">
                    ৳{quickViewProduct.price.toLocaleString()}
                  </span>
                  {quickViewProduct.compareAtPrice && (
                    <span className="text-sm text-slate-400 line-through">
                      ৳{quickViewProduct.compareAtPrice.toLocaleString()}
                    </span>
                  )}
                  {quickViewProduct.compareAtPrice && (
                    <span className="px-2 py-0.5 rounded-lg bg-rose-50 text-rose-600 font-bold text-[11px] border border-rose-200">
                      {Math.round(((quickViewProduct.compareAtPrice - quickViewProduct.price) / quickViewProduct.compareAtPrice) * 100)}% OFF
                    </span>
                  )}
                </div>

                {/* Description */}
                <div className="mt-4 pt-4 border-t border-slate-100">
                  <h4 className="text-xs font-bold text-slate-800 mb-1">
                    {isBn ? 'পণ্যের বিবরণ' : 'Product Details'}
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {isBn ? quickViewProduct.descriptionBn : quickViewProduct.description}
                  </p>
                </div>

                {/* Stock info */}
                <div className="mt-4 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-xs font-semibold text-slate-700">
                    {quickViewProduct.stock > 0 
                      ? (isBn ? `স্টকে রয়েছে (${quickViewProduct.stock} টি অবশিষ্ট)` : `In Stock (${quickViewProduct.stock} units ready to dispatch)`)
                      : (isBn ? 'স্টক শেষ' : 'Out of Stock')}
                  </span>
                </div>
              </div>

              {/* Action Box */}
              <div className="mt-6 pt-4 border-t border-slate-100 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="flex items-center border border-slate-200 rounded-xl bg-slate-50 p-1">
                    <button
                      type="button"
                      onClick={() => setQuickViewQty(Math.max(1, quickViewQty - 1))}
                      className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-white text-slate-600 font-bold text-sm"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-8 text-center text-xs font-bold text-slate-800">
                      {quickViewQty}
                    </span>
                    <button
                      type="button"
                      onClick={() => setQuickViewQty(quickViewQty + 1)}
                      className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-white text-slate-600 font-bold text-sm"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      for (let i = 0; i < quickViewQty; i++) {
                        onAddToCart(quickViewProduct);
                      }
                      setQuickViewProduct(null);
                    }}
                    className="flex-1 py-3 px-4 rounded-xl text-white font-bold text-xs shadow-md transition-all hover:opacity-95 flex items-center justify-center gap-2"
                    style={{ backgroundColor: theme.primaryColor }}
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>{isBn ? `ব্যাগে যোগ করুন (৳${(quickViewProduct.price * quickViewQty).toLocaleString()})` : `Add to Bag (৳${(quickViewProduct.price * quickViewQty).toLocaleString()})`}</span>
                  </button>
                </div>

                {/* Trust mini badges */}
                <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-500 pt-1">
                  <div className="flex items-center gap-1.5">
                    <Truck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>{isBn ? 'সারা বাংলাদেশে দ্রুত ডেলিভারি' : 'Nationwide fast delivery'}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>{isBn ? 'ক্যাশ অন ডেলিভারি সুবিধা' : 'Cash on Delivery eligible'}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Shopping Cart Drawer */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          <div 
            onClick={handleCartClose}
            className="absolute inset-0 bg-slate-950/60 backdrop-blur-xs transition-opacity"
          />
          <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
            <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col">
              {/* Cart Drawer Header */}
              <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-slate-800" />
                  <h2 className="text-base font-bold text-slate-900">
                    {isBn ? 'আপনার শপিং ব্যাগ' : 'Shopping Cart'} ({cart.length})
                  </h2>
                </div>
                <button onClick={handleCartClose} className="text-slate-400 hover:text-slate-700 p-1">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Cart Items List */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {cart.length === 0 ? (
                  <div className="text-center py-16 text-slate-400">
                    <ShoppingBag className="w-12 h-12 mx-auto stroke-1 text-slate-300 mb-3" />
                    <p className="text-sm font-semibold">{isBn ? 'আপনার ব্যাগটি খালি' : 'Your cart is empty'}</p>
                    <p className="text-xs mt-1">{isBn ? 'পণ্য পছন্দ করে ব্যাগে যোগ করুন।' : 'Add items from the store to proceed.'}</p>
                  </div>
                ) : (
                  cart.map((item) => (
                    <div key={item.product.id} className="flex items-center gap-3 p-3 bg-slate-50 rounded-2xl border border-slate-200">
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-14 h-14 rounded-xl object-cover border border-slate-200 shrink-0"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="font-bold text-xs text-slate-900 truncate">
                          {isBn ? item.product.nameBn : item.product.name}
                        </div>
                        <div className="text-xs font-black text-slate-900 mt-0.5">
                          ৳{item.product.price.toLocaleString()}
                        </div>

                        <div className="flex items-center gap-2 mt-2">
                          <button
                            onClick={() => onUpdateCartQuantity(item.product.id, item.quantity - 1)}
                            className="w-6 h-6 rounded-md bg-white border border-slate-200 text-slate-700 flex items-center justify-center text-xs hover:bg-slate-100"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-bold text-slate-900 w-4 text-center">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => onUpdateCartQuantity(item.product.id, item.quantity + 1)}
                            className="w-6 h-6 rounded-md bg-white border border-slate-200 text-slate-700 flex items-center justify-center text-xs hover:bg-slate-100"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-xs font-bold text-slate-900">
                          ৳{(item.product.price * item.quantity).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  ))
                )}

                {/* Promo Code Input */}
                {cart.length > 0 && (
                  <form onSubmit={handleApplyCoupon} className="pt-2">
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Coupon code (e.g. AURA15)"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value)}
                        className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs uppercase font-semibold focus:outline-none focus:border-slate-400"
                      />
                      <button
                        type="submit"
                        className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-colors"
                      >
                        Apply
                      </button>
                    </div>
                    {couponApplied && (
                      <span className="text-[11px] font-bold text-emerald-600 mt-1 block">
                        ✓ 15% promo discount applied!
                      </span>
                    )}
                  </form>
                )}
              </div>

              {/* Cart Footer */}
              {cart.length > 0 && (
                <div className="p-6 border-t border-slate-200 bg-slate-50 space-y-3">
                  <div className="space-y-1.5 text-xs text-slate-600">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span className="font-semibold text-slate-900">৳{subtotal.toLocaleString()}</span>
                    </div>
                    {discount > 0 && (
                      <div className="flex justify-between text-emerald-600 font-semibold">
                        <span>Discount (15%):</span>
                        <span>-৳{discount.toLocaleString()}</span>
                      </div>
                    )}
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-1.5">
                        <span>Delivery Fee:</span>
                        <span className={`text-[10px] px-1.5 py-0.2 rounded font-semibold ${
                          deliveryResult.isLocal 
                            ? 'bg-emerald-100 text-emerald-800' 
                            : 'bg-blue-100 text-blue-800'
                        }`}>
                          {deliveryResult.isLocal ? 'Local Rate' : 'Outside Rate'}
                        </span>
                      </div>
                      <span className="font-semibold text-slate-900">
                        {deliveryResult.isFreeShipping ? 'FREE' : `৳${shippingFee}`}
                      </span>
                    </div>
                    <div className="flex justify-between text-base font-black text-slate-900 pt-2 border-t border-slate-200">
                      <span>Total:</span>
                      <span>৳{totalAmount.toLocaleString()}</span>
                    </div>
                  </div>

                  <button
                    id="proceed-to-checkout-btn"
                    onClick={() => {
                      onCloseCart();
                      setIsCheckoutOpen(true);
                      setCheckoutStep('details');
                    }}
                    className="w-full py-3.5 rounded-xl text-white font-bold text-xs shadow-lg transition-transform hover:scale-[1.02] flex items-center justify-center gap-2"
                    style={{ backgroundColor: theme.primaryColor }}
                  >
                    <span>{isBn ? 'চেকআউট করুন' : 'Proceed to Checkout'}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Multi-step Checkout Modal */}
      {isCheckoutOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl max-h-[90vh] overflow-y-auto">
            {checkoutStep !== 'success' && (
              <div className="flex items-center justify-between pb-4 border-b border-slate-200">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-700 flex items-center justify-center font-bold">
                    <CreditCard className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-slate-900">
                      {isBn ? 'নিরাপদ চেকআউট' : 'Secure Multi-Channel Checkout'}
                    </h2>
                    <span className="text-[10px] text-slate-400">Step {checkoutStep === 'details' ? '1 of 2' : '2 of 2'}</span>
                  </div>
                </div>
                <button onClick={() => setIsCheckoutOpen(false)} className="text-slate-400 hover:text-slate-700 p-1">
                  <X className="w-5 h-5" />
                </button>
              </div>
            )}

            {/* Step 1: Customer Details */}
            {checkoutStep === 'details' && (
              <div className="space-y-4 mt-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isBn ? 'পূর্ণ নাম' : 'Full Name'}
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-slate-400"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {isBn ? 'মোবাইল নম্বর' : 'Phone Number'}
                    </label>
                    <input
                      type="text"
                      required
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-slate-400"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-bold text-slate-700">
                        {isBn ? 'শহর / জেলা' : 'City / District'}
                      </label>
                      <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                        {isBn ? `স্টোর: ${deliveryResult.storeLocationSummary}` : `Origin: ${deliveryResult.storeLocationSummary}`}
                      </span>
                    </div>
                    <select
                      value={customerCity}
                      onChange={(e) => setCustomerCity(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-900 focus:outline-none focus:border-slate-400"
                    >
                      {ALL_BD_DISTRICTS.map((dist: BDDistrict) => {
                        const preview = calculateDeliveryCharge(dist.name, activeStore, shippingSettings, subtotal);
                        return (
                          <option key={dist.name} value={dist.name}>
                            {dist.name} ({dist.nameBn}) — {preview.isFreeShipping ? 'Free' : `৳${preview.charge}`} ({preview.isLocal ? (isBn ? 'লোকাল' : 'Local') : (isBn ? 'আউটসাইড' : 'Outside')})
                          </option>
                        );
                      })}
                    </select>

                    {/* Dynamic zone indicator badge */}
                    <div className="mt-1.5 p-2 rounded-lg bg-emerald-50/80 border border-emerald-200/90 text-[11px] text-slate-700 flex items-center justify-between">
                      <span className="font-medium text-emerald-950">
                        {isBn ? deliveryResult.zoneDescriptionBn : deliveryResult.zoneDescription}
                      </span>
                      <span className="font-bold text-emerald-900">
                        {deliveryResult.isFreeShipping ? (isBn ? 'ফ্রি ডেলিভারি' : 'Free Delivery') : `৳${deliveryResult.charge}`}
                      </span>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isBn ? 'পূর্ণ ডেলিভারি ঠিকানা' : 'Complete Street Address'}
                  </label>
                  <textarea
                    rows={2}
                    required
                    value={customerAddress}
                    onChange={(e) => setCustomerAddress(e.target.value)}
                    className="w-full p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs focus:outline-none focus:border-slate-400"
                  />
                </div>

                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-600 flex justify-between font-bold">
                  <span>Payable Total:</span>
                  <span className="text-slate-900 font-black">৳{totalAmount.toLocaleString()}</span>
                </div>

                <button
                  id="checkout-step1-next-btn"
                  onClick={() => setCheckoutStep('payment')}
                  className="w-full py-3.5 rounded-xl text-white font-bold text-xs shadow transition-transform hover:scale-[1.01] flex items-center justify-center gap-2"
                  style={{ backgroundColor: theme.primaryColor }}
                >
                  <span>{isBn ? 'পেমেন্ট নির্বাচন করুন' : 'Continue to Payment Method'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* Step 2: Payment Gateway Selection */}
            {checkoutStep === 'payment' && (
              <div className="space-y-4 mt-4">
                <div className="space-y-2.5">
                  {/* bKash Option */}
                  <label 
                    onClick={() => setPaymentMethod('bkash')}
                    className={`p-3.5 rounded-2xl border-2 flex items-center justify-between cursor-pointer transition-all ${
                      paymentMethod === 'bkash' ? 'border-pink-500 bg-pink-50/20' : 'border-slate-200 bg-white'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-pink-600 text-white font-black text-xs flex items-center justify-center shadow-xs">
                        bKash
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-900">bKash Direct Gateway</div>
                        <div className="text-[11px] text-slate-500">Instant tokenized digital settlement</div>
                      </div>
                    </div>
                    <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                      paymentMethod === 'bkash' ? 'border-pink-600 bg-pink-600' : 'border-slate-300'
                    }`}>
                      {paymentMethod === 'bkash' && <div className="w-1.5 h-1.5 rounded-full bg-white"></div>}
                    </div>
                  </label>

                  {/* Nagad Option */}
                  <label 
                    onClick={() => setPaymentMethod('nagad')}
                    className={`p-3.5 rounded-2xl border-2 flex items-center justify-between cursor-pointer transition-all ${
                      paymentMethod === 'nagad' ? 'border-orange-500 bg-orange-50/20' : 'border-slate-200 bg-white'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-orange-600 text-white font-black text-xs flex items-center justify-center shadow-xs">
                        Nagad
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-900">Nagad Mobile Wallet</div>
                        <div className="text-[11px] text-slate-500">Fast one-tap OTP verification</div>
                      </div>
                    </div>
                    <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                      paymentMethod === 'nagad' ? 'border-orange-600 bg-orange-600' : 'border-slate-300'
                    }`}>
                      {paymentMethod === 'nagad' && <div className="w-1.5 h-1.5 rounded-full bg-white"></div>}
                    </div>
                  </label>

                  {/* Card Option */}
                  <label 
                    onClick={() => setPaymentMethod('card')}
                    className={`p-3.5 rounded-2xl border-2 flex items-center justify-between cursor-pointer transition-all ${
                      paymentMethod === 'card' ? 'border-blue-500 bg-blue-50/20' : 'border-slate-200 bg-white'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-blue-600 text-white font-bold text-xs flex items-center justify-center shadow-xs">
                        Cards
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-900">Visa / Mastercard / AMEX</div>
                        <div className="text-[11px] text-slate-500">Encrypted global debit & credit cards</div>
                      </div>
                    </div>
                    <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                      paymentMethod === 'card' ? 'border-blue-600 bg-blue-600' : 'border-slate-300'
                    }`}>
                      {paymentMethod === 'card' && <div className="w-1.5 h-1.5 rounded-full bg-white"></div>}
                    </div>
                  </label>

                  {/* COD Option */}
                  <label 
                    onClick={() => setPaymentMethod('cod')}
                    className={`p-3.5 rounded-2xl border-2 flex items-center justify-between cursor-pointer transition-all ${
                      paymentMethod === 'cod' ? 'border-slate-700 bg-slate-50' : 'border-slate-200 bg-white'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-slate-800 text-white font-bold text-xs flex items-center justify-center shadow-xs">
                        COD
                      </div>
                      <div>
                        <div className="text-xs font-bold text-slate-900">Cash on Delivery (ক্যাশ অন ডেলিভারি)</div>
                        <div className="text-[11px] text-slate-500">Pay when courier arrives at your door</div>
                      </div>
                    </div>
                    <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                      paymentMethod === 'cod' ? 'border-slate-700 bg-slate-700' : 'border-slate-300'
                    }`}>
                      {paymentMethod === 'cod' && <div className="w-1.5 h-1.5 rounded-full bg-white"></div>}
                    </div>
                  </label>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    onClick={() => setCheckoutStep('details')}
                    className="px-4 py-3 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold hover:bg-slate-200"
                  >
                    Back
                  </button>
                  <button
                    id="confirm-place-order-btn"
                    onClick={handleConfirmOrder}
                    className="flex-1 py-3 rounded-xl text-white font-bold text-xs shadow-lg transition-transform hover:scale-[1.01]"
                    style={{ backgroundColor: theme.primaryColor }}
                  >
                    {isBn ? `অর্ডার নিশ্চিত করুন (৳${totalAmount.toLocaleString()})` : `Place Order (৳${totalAmount.toLocaleString()})`}
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Success Confirmation */}
            {checkoutStep === 'success' && lastCreatedOrder && (
              <div className="text-center py-6 space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center">
                  <Check className="w-8 h-8 stroke-[3]" />
                </div>
                <h3 className="text-xl font-extrabold text-slate-900">
                  {isBn ? 'অর্ডার সফলভাবে গৃহীত হয়েছে!' : 'Order Successfully Placed!'}
                </h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  {isBn 
                    ? `ধন্যবাদ, ${lastCreatedOrder.customerName}। আপনার অর্ডারটি মার্চেন্ট কনসোলে রিয়েল-টাইমে যোগ করা হয়েছে।` 
                    : `Thank you, ${lastCreatedOrder.customerName}. Your order has been dispatched directly to the merchant's live dashboard.`}
                </p>

                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs text-left space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Order Number:</span>
                    <span className="font-bold font-mono text-slate-900">{lastCreatedOrder.orderNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Payment:</span>
                    <span className="font-bold text-slate-900 uppercase">
                      {lastCreatedOrder.paymentMethod} {lastCreatedOrder.paymentMethod === 'cod' ? '(Pay on Delivery)' : '(Pending Verification)'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">{lastCreatedOrder.paymentMethod === 'cod' ? 'Payable on Delivery:' : 'Amount:'}</span>
                    <span className="font-black text-slate-900">৳{lastCreatedOrder.totalAmount.toLocaleString()}</span>
                  </div>
                </div>

                <div className="pt-2 flex flex-col sm:flex-row gap-2">
                  <button
                    onClick={() => {
                      setIsCheckoutOpen(false);
                      onBackToDashboard();
                    }}
                    className="flex-1 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-colors"
                  >
                    {isBn ? 'মার্চেন্ট ড্যাশবোর্ডে অর্ডার দেখুন' : 'View in Merchant Dashboard'}
                  </button>
                  <button
                    onClick={() => setIsCheckoutOpen(false)}
                    className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-colors"
                  >
                    {isBn ? 'শপিং চালিয়ে যান' : 'Continue Shopping'}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
