import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { INITIAL_COLLEGES } from '../utils/mockData';
import { ConfessionCard } from './ConfessionCard';
import { 
  Compass, 
  Sparkles, 
  Flame, 
  GraduationCap, 
  Users, 
  TrendingUp, 
  MapPin,
  ArrowLeft 
} from 'lucide-react';

export const ExploreView: React.FC = () => {
  const { confessions, setSelectedCollege, user, setActiveTab, colleges } = useApp();
  const [activeCollegeFilter, setActiveCollegeFilter] = useState<string>('ALL');

  const trendingTags = [
    { tag: '#hostel-mess', count: '1.4k whispers' },
    { tag: '#exam-panic', count: '2.1k whispers' },
    { tag: '#library-crush', count: '980 whispers' },
    { tag: '#placement-stress', count: '1.8k whispers' },
    { tag: '#prof-memes', count: '740 whispers' },
  ];

  let exploreConfessions = confessions.filter(c => !c.isHidden);
  if (activeCollegeFilter !== 'ALL') {
    exploreConfessions = exploreConfessions.filter(c => c.collegeCode === activeCollegeFilter);
  }

  return (
    <div className="space-y-4 pb-20">
      
      {/* Top Back Navigation Bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveTab('feed')}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-cyan-500/50 text-cyan-300 text-xs font-semibold transition-all group active:scale-95"
        >
          <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" />
          <span>Back to Feeds</span>
        </button>
      </div>

      {/* Top Banner */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-indigo-950/40 via-cyan-950/30 to-slate-900 border border-indigo-500/30 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-indigo-400 font-semibold mb-1">
            <Compass className="w-3.5 h-3.5" />
            <span>Pan-Campus Radar</span>
          </div>
          <h2 className="font-display font-black text-lg sm:text-xl text-slate-100">
            Explore All Universities
          </h2>
          <p className="text-xs text-slate-400">
            Discover what students are secretly talking about nationwide.
          </p>
        </div>
        <div className="w-12 h-12 rounded-2xl bg-indigo-900/40 border border-indigo-500/40 flex items-center justify-center text-2xl shadow-lg neon-glow-cyan">
          🌐
        </div>
      </div>

      {/* College Directory Carousel */}
      <div>
        <h3 className="font-display font-bold text-sm text-slate-200 mb-2.5 flex items-center gap-1.5">
          <GraduationCap className="w-4 h-4 text-cyan-400" />
          <span>Active University Campuses</span>
        </h3>

        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          <button
            onClick={() => setActiveCollegeFilter('ALL')}
            className={`px-3.5 py-2 rounded-xl border text-xs font-semibold whitespace-nowrap transition-all ${
              activeCollegeFilter === 'ALL' 
                ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 shadow-sm' 
                : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            🌍 All Campuses
          </button>

          {colleges.map(col => (
            <button
              key={col.code}
              onClick={() => setActiveCollegeFilter(col.code)}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl border text-xs font-medium whitespace-nowrap transition-all ${
                activeCollegeFilter === col.code 
                  ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-semibold shadow-sm' 
                  : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>{col.badge}</span>
              <span>{col.name}</span>
              <span className="text-[10px] text-slate-500 font-mono">({col.studentsCount} students)</span>
            </button>
          ))}
        </div>
      </div>

      {/* Trending Topics / Hashtags */}
      <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
        <h3 className="font-display font-bold text-xs text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
          <TrendingUp className="w-3.5 h-3.5 text-purple-400" />
          <span>Trending Campus Topics</span>
        </h3>
        <div className="flex flex-wrap gap-2">
          {trendingTags.map((t, idx) => (
            <div
              key={idx}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800/80 text-xs text-slate-300 hover:border-cyan-500/40 cursor-pointer transition-all"
            >
              <span className="text-cyan-400 font-semibold">{t.tag}</span>
              <span className="text-[10px] text-slate-500 font-mono">{t.count}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Confession Cards */}
      <div className="space-y-4">
        <h3 className="font-display font-bold text-sm text-slate-200 flex items-center gap-1.5">
          <Flame className="w-4 h-4 text-rose-400" />
          <span>
            {activeCollegeFilter === 'ALL' ? 'Top Global Whispers' : `Whispers in ${activeCollegeFilter}`}
          </span>
        </h3>

        {exploreConfessions.map(c => (
          <ConfessionCard key={c.id} confession={c} />
        ))}
      </div>

    </div>
  );
};
