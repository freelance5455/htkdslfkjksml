import React from 'react';

interface LocationHistoryItem {
  username: string;
  lat: number;
  lng: number;
  timestamp: number;
}

export const LocationHistory: React.FC<{ history: LocationHistoryItem[] }> = ({ history }) => {
  return (
    <div className="w-full bg-black/40 border border-gray-800 rounded-xl p-4">
      <h3 className="text-sm font-black text-white uppercase tracking-widest mb-4">Historial de Ubicaciones</h3>
      <div className="max-h-60 overflow-y-auto space-y-2">
        {history.length === 0 ? (
          <p className="text-gray-500 text-xs text-center py-4">Sin datos recientes</p>
        ) : (
          history.map((item, index) => (
            <div key={index} className="flex justify-between items-center text-xs text-gray-300 border-b border-gray-800 pb-2">
              <span className="font-bold text-[#00ff88]">{item.username}</span>
              <span className="font-mono">{item.lat.toFixed(4)}, {item.lng.toFixed(4)}</span>
              <span className="text-gray-500">{new Date(item.timestamp).toLocaleTimeString()}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
