import React from 'react';
import { Wifi, BatteryMedium, Signal } from 'lucide-react';

interface AndroidSimulatorFrameProps {
  children: React.ReactNode;
  isSimulatedDevice: boolean;
}

export const AndroidSimulatorFrame: React.FC<AndroidSimulatorFrameProps> = ({
  children,
  isSimulatedDevice,
}) => {
  if (!isSimulatedDevice) {
    return <div className="w-full h-full min-h-screen flex flex-col">{children}</div>;
  }

  const now = new Date();
  const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });

  return (
    <div className="w-full min-h-screen flex items-center justify-center py-6 px-4 bg-[#050505]">
      {/* Device Body */}
      <div className="relative w-full max-w-[412px] h-[860px] bg-black rounded-[48px] border-[10px] border-[#1f1f1f] shadow-[0_25px_70px_rgba(0,0,0,0.9),0_0_0_1px_rgba(255,255,255,0.1)] flex flex-col overflow-hidden">
        {/* Status Bar */}
        <div className="w-full h-10 px-7 pt-2 flex items-center justify-between z-30 select-none bg-black text-white text-xs font-medium">
          <div className="font-mono text-[13px] tracking-tight">{timeString}</div>
          {/* Front Camera Hole-punch */}
          <div className="w-4 h-4 rounded-full bg-[#111111] border border-[#222222] shadow-inner" />
          <div className="flex items-center gap-1.5 opacity-80">
            <Signal className="w-3.5 h-3.5" />
            <Wifi className="w-3.5 h-3.5" />
            <BatteryMedium className="w-4 h-4" />
          </div>
        </div>

        {/* Screen Viewport */}
        <div className="flex-1 w-full overflow-y-auto overflow-x-hidden flex flex-col bg-black">
          {children}
        </div>

        {/* Android Navigation Home Bar */}
        <div className="w-full h-6 pb-2 bg-black flex items-center justify-center select-none z-30">
          <div className="w-32 h-1 bg-white/40 rounded-full" />
        </div>
      </div>
    </div>
  );
};
