import React, { useState } from 'react';
import { PhoneCall, AlertTriangle, ChevronDown, ChevronUp, ShieldAlert, Heart } from 'lucide-react';
import { useTranslation } from 'react-i18next';

interface EmergencyBannerProps {
  onOpenEmergencyModal: () => void;
}

export const EmergencyBanner: React.FC<EmergencyBannerProps> = ({
  onOpenEmergencyModal,
}) => {
  const { t } = useTranslation();
  const [isExpanded, setIsExpanded] = useState<boolean>(false);

  return (
    <aside aria-label="Urgence et assistance" className="bg-rose-50 dark:bg-rose-950/40 border-b border-rose-100 dark:border-rose-900/60 text-rose-950 dark:text-rose-100 transition-all">
      <div className="max-w-7xl mx-auto px-4 py-2 sm:py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
          <span className="font-bold text-rose-700 dark:text-rose-300">
            Besoin d’aide immédiate ?
          </span>
          <span className="hidden sm:inline text-slate-600 dark:text-slate-300">
            Ligne nationale gratuite 24/7 :
          </span>
          <a
            href="tel:3114"
            className="font-extrabold px-2.5 py-1 rounded-full bg-rose-600 hover:bg-rose-700 text-white flex items-center gap-1 shadow-2xs transition-colors"
          >
            <PhoneCall className="w-3 h-3" />
            <span>3114</span>
          </a>
          <span className="hidden md:inline text-slate-500 dark:text-slate-400">
            (France) • Europe 112 • US/Canada 988
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenEmergencyModal}
            className="text-xs font-semibold text-rose-700 dark:text-rose-300 underline hover:text-rose-900 dark:hover:text-rose-100"
          >
            Tous les numéros d'urgence
          </button>
        </div>
      </div>
    </aside>
  );
};
