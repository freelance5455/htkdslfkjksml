/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Plus,
  Trash2,
  Edit3,
  ChevronRight,
  ArrowUp,
  ArrowDown,
  GripVertical,
  Calendar,
  Repeat,
} from 'lucide-react';
import { RepeatConfig, RepeatType, TaskStatus, ToDoGroup, ToDoTask } from '../types.ts';
import {
  BENGALI_WEEKDAYS_SHORT,
  formatDateToBengali,
  getTodayDateString,
  toBengaliNum,
} from '../utils/dateUtils.ts';
import { MAX_GROUP_LIMIT } from '../utils/storage.ts';
import { ConfirmModal } from './ConfirmModal.tsx';
import { EmptyState } from './EmptyState.tsx';
import { TaskDetailPage } from './TaskDetailPage.tsx';

interface ToDoTabProps {
  groups: ToDoGroup[];
  selectedGroupId: string | null;
  selectedTaskId: string | null;
  isEditMode: boolean;
  onSelectGroup: (groupId: string | null) => void;
  onSelectTask: (taskId: string | null) => void;
  onAddGroup: (name: string, details?: string) => void;
  onUpdateGroup: (groupId: string, name: string, details?: string) => void;
  onDeleteGroup: (groupId: string) => void;
  onReorderGroups: (newGroups: ToDoGroup[]) => void;
  onAddTask: (groupId: string, name: string, details: string | undefined, repeat: RepeatConfig) => void;
  onUpdateTask: (
    groupId: string,
    taskId: string,
    name: string,
    details: string | undefined,
    repeat?: RepeatConfig
  ) => void;
  onDeleteTask: (groupId: string, taskId: string) => void;
  onReorderTasks: (groupId: string, newTasks: ToDoTask[]) => void;
  onUpdateTaskReport: (
    groupId: string,
    taskId: string,
    dateStr: string,
    status: TaskStatus | null,
    postponedTo?: string
  ) => void;
}

export const ToDoTab: React.FC<ToDoTabProps> = ({
  groups,
  selectedGroupId,
  selectedTaskId,
  isEditMode,
  onSelectGroup,
  onSelectTask,
  onAddGroup,
  onUpdateGroup,
  onDeleteGroup,
  onReorderGroups,
  onAddTask,
  onUpdateTask,
  onDeleteTask,
  onReorderTasks,
  onUpdateTaskReport,
}) => {
  const today = getTodayDateString();

  // Modals & form state
  const [showAddGroupModal, setShowAddGroupModal] = useState(false);
  const [showAddTaskModal, setShowAddTaskModal] = useState(false);
  const [editingGroup, setEditingGroup] = useState<ToDoGroup | null>(null);
  const [editingTask, setEditingTask] = useState<ToDoTask | null>(null);

  // Deletion confirm states
  const [groupToDelete, setGroupToDelete] = useState<ToDoGroup | null>(null);
  const [taskToDelete, setTaskToDelete] = useState<ToDoTask | null>(null);

  // Form input fields
  const [inputName, setInputName] = useState('');
  const [inputDetails, setInputDetails] = useState('');
  const [limitWarning, setLimitWarning] = useState<string | null>(null);

  // Repeat config form state
  const [repeatType, setRepeatType] = useState<RepeatType>('daily');
  const [selectedWeekdays, setSelectedWeekdays] = useState<number[]>([0, 1, 2, 3, 4, 5, 6]);
  const [intervalDays, setIntervalDays] = useState<number>(3);
  const [intervalStartDate, setIntervalStartDate] = useState<string>(today);
  const [customDates, setCustomDates] = useState<string[]>([]);
  const [customDateInput, setCustomDateInput] = useState<string>(today);

  const selectedGroup = groups.find((g) => g.id === selectedGroupId) ?? null;
  const selectedTask = selectedGroup?.tasks.find((t) => t.id === selectedTaskId) ?? null;

  // Handlers for Group CRUD
  const handleOpenAddGroup = () => {
    if (groups.length >= MAX_GROUP_LIMIT) {
      setLimitWarning(
        `টু ডু ট্যাবে সর্বোচ্চ ${toBengaliNum(MAX_GROUP_LIMIT)}টি গ্রুপ তৈরি করা সম্ভব। নতুন গ্রুপ যোগ করা যাবে না।`
      );
      return;
    }
    setInputName('');
    setInputDetails('');
    setShowAddGroupModal(true);
  };

  const handleSaveAddGroup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputName.trim()) return;
    onAddGroup(inputName.trim(), inputDetails.trim() || undefined);
    setInputName('');
    setInputDetails('');
    setShowAddGroupModal(false);
  };

  const handleOpenEditGroup = (group: ToDoGroup, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingGroup(group);
    setInputName(group.name);
    setInputDetails(group.details || '');
  };

  const handleSaveEditGroup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingGroup || !inputName.trim()) return;
    onUpdateGroup(editingGroup.id, inputName.trim(), inputDetails.trim() || undefined);
    setEditingGroup(null);
    setInputName('');
    setInputDetails('');
  };

  const handleMoveGroup = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= groups.length) return;
    const reordered = [...groups];
    const temp = reordered[index];
    reordered[index] = reordered[targetIndex];
    reordered[targetIndex] = temp;
    reordered.forEach((g, idx) => {
      g.order = idx;
    });
    onReorderGroups(reordered);
  };

  // Handlers for Task CRUD
  const handleOpenAddTask = () => {
    setInputName('');
    setInputDetails('');
    setRepeatType('daily');
    setSelectedWeekdays([0, 1, 2, 3, 4, 5, 6]);
    setIntervalDays(3);
    setIntervalStartDate(today);
    setCustomDates([]);
    setCustomDateInput(today);
    setShowAddTaskModal(true);
  };

  const handleAddCustomDate = () => {
    if (!customDateInput) return;
    if (!customDates.includes(customDateInput)) {
      setCustomDates([...customDates, customDateInput].sort());
    }
  };

  const handleRemoveCustomDate = (dateToRemove: string) => {
    setCustomDates(customDates.filter((d) => d !== dateToRemove));
  };

  const handleToggleWeekday = (dayIndex: number) => {
    if (selectedWeekdays.includes(dayIndex)) {
      if (selectedWeekdays.length > 1) {
        setSelectedWeekdays(selectedWeekdays.filter((d) => d !== dayIndex));
      }
    } else {
      setSelectedWeekdays([...selectedWeekdays, dayIndex].sort());
    }
  };

  const handleSaveAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGroup || !inputName.trim()) return;

    let repeatConfig: RepeatConfig = { type: 'daily' };
    if (repeatType === 'daily') {
      repeatConfig = { type: 'daily' };
    } else if (repeatType === 'weekly') {
      repeatConfig = {
        type: 'weekly',
        daysOfWeek: selectedWeekdays.length > 0 ? selectedWeekdays : [0, 1, 2, 3, 4, 5, 6],
      };
    } else if (repeatType === 'interval') {
      repeatConfig = {
        type: 'interval',
        intervalDays: Math.max(1, intervalDays),
        startDate: intervalStartDate || today,
      };
    } else if (repeatType === 'custom') {
      repeatConfig = {
        type: 'custom',
        dates: customDates.length > 0 ? customDates : [today],
      };
    }

    onAddTask(
      selectedGroup.id,
      inputName.trim(),
      inputDetails.trim() || undefined,
      repeatConfig
    );
    setShowAddTaskModal(false);
  };

  const handleOpenEditTask = (task: ToDoTask) => {
    setEditingTask(task);
    setInputName(task.name);
    setInputDetails(task.details || '');
    setRepeatType(task.repeat.type);
    setSelectedWeekdays(task.repeat.daysOfWeek || [0, 1, 2, 3, 4, 5, 6]);
    setIntervalDays(task.repeat.intervalDays || 3);
    setIntervalStartDate(task.repeat.startDate || today);
    setCustomDates(task.repeat.dates || []);
    setCustomDateInput(today);
  };

  const handleSaveEditTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGroup || !editingTask || !inputName.trim()) return;

    let repeatConfig: RepeatConfig = { type: 'daily' };
    if (repeatType === 'daily') {
      repeatConfig = { type: 'daily' };
    } else if (repeatType === 'weekly') {
      repeatConfig = {
        type: 'weekly',
        daysOfWeek: selectedWeekdays.length > 0 ? selectedWeekdays : [0, 1, 2, 3, 4, 5, 6],
      };
    } else if (repeatType === 'interval') {
      repeatConfig = {
        type: 'interval',
        intervalDays: Math.max(1, intervalDays),
        startDate: intervalStartDate || today,
      };
    } else if (repeatType === 'custom') {
      repeatConfig = {
        type: 'custom',
        dates: customDates.length > 0 ? customDates : [today],
      };
    }

    onUpdateTask(
      selectedGroup.id,
      editingTask.id,
      inputName.trim(),
      inputDetails.trim() || undefined,
      repeatConfig
    );
    setEditingTask(null);
  };

  const handleMoveTask = (index: number, direction: 'up' | 'down') => {
    if (!selectedGroup) return;
    const tasks = [...selectedGroup.tasks];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= tasks.length) return;
    const temp = tasks[index];
    tasks[index] = tasks[targetIndex];
    tasks[targetIndex] = temp;
    tasks.forEach((t, idx) => {
      t.order = idx;
    });
    onReorderTasks(selectedGroup.id, tasks);
  };

  // ================= VIEW: Task Detail Page (কাজের পাতা - 4.4) =================
  if (selectedGroup && selectedTask) {
    return (
      <TaskDetailPage
        task={selectedTask}
        groupName={selectedGroup.name}
        onUpdateReport={(dateStr, status, postponedTo) => {
          onUpdateTaskReport(selectedGroup.id, selectedTask.id, dateStr, status, postponedTo);
        }}
        onBack={() => onSelectTask(null)}
      />
    );
  }

  // ================= VIEW: Inside a Group (4.2) =================
  if (selectedGroup) {
    return (
      <div className="pb-28 max-w-md mx-auto px-4 pt-3">
        {selectedGroup.tasks.length === 0 ? (
          <EmptyState
            message="এই গ্রুপে এখনও কোনো কাজ নেই।"
            subMessage="নিচের + চেপে নাম, ডিটেলস ও রিপিট ডেট দিয়ে কাজ যোগ করুন।"
          />
        ) : (
          <div className="space-y-2.5">
            {selectedGroup.tasks.map((task, index) => {
              const repeatLabel = getRepeatLabel(task.repeat);

              return (
                <div
                  key={task.id}
                  onClick={() => {
                    if (!isEditMode) {
                      onSelectTask(task.id);
                    }
                  }}
                  className={`relative flex items-center justify-between p-3.5 rounded-2xl border transition-all duration-200 select-none ${
                    isEditMode
                      ? 'bg-amber-50/70 border-amber-200/80 shadow-xs'
                      : 'bg-white border-slate-200/80 shadow-xs hover:border-emerald-300 hover:shadow-sm active:scale-[0.99] cursor-pointer'
                  }`}
                >
                  {/* Left Section: Reorder or Drag handle + Task Name */}
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    {isEditMode ? (
                      <div className="flex items-center gap-1 shrink-0 text-slate-500">
                        <GripVertical className="w-5 h-5 text-amber-600" />
                        <div className="flex flex-col gap-0.5">
                          <button
                            type="button"
                            disabled={index === 0}
                            onClick={(e) => {
                              e.stopPropagation();
                              handleMoveTask(index, 'up');
                            }}
                            aria-label="উপরে নিন"
                            className="p-1 rounded bg-white border border-slate-200 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none active:bg-slate-200 text-slate-700"
                          >
                            <ArrowUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            disabled={index === selectedGroup.tasks.length - 1}
                            onClick={(e) => {
                              e.stopPropagation();
                              handleMoveTask(index, 'down');
                            }}
                            aria-label="নিচে নিন"
                            className="p-1 rounded bg-white border border-slate-200 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none active:bg-slate-200 text-slate-700"
                          >
                            <ArrowDown className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-700 border border-purple-100 flex items-center justify-center font-bold text-xs shrink-0">
                        {toBengaliNum(index + 1)}
                      </div>
                    )}

                    <div className="min-w-0 flex-1">
                      <h4 className="text-base font-bold text-slate-900 leading-snug break-words">
                        {task.name}
                      </h4>
                      {task.details && (
                        <p className="text-xs text-slate-500 mt-0.5 line-clamp-1 break-words">
                          {task.details}
                        </p>
                      )}
                      <div className="flex items-center gap-1 mt-1 text-[11px] font-semibold text-emerald-700">
                        <Repeat className="w-3 h-3 stroke-[2.2]" />
                        <span>{repeatLabel}</span>
                      </div>
                    </div>
                  </div>

                  {/* Right Section: Edit Mode actions OR Chevron */}
                  {isEditMode ? (
                    <div className="flex items-center gap-1.5 ml-2 shrink-0">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOpenEditTask(task);
                        }}
                        aria-label="কাজের তথ্য পরিবর্তন করুন"
                        className="p-2 rounded-xl bg-white border border-slate-200 text-blue-600 hover:bg-blue-50 active:scale-95 transition-all shadow-xs"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setTaskToDelete(task);
                        }}
                        aria-label="কাজ মুছুন"
                        className="p-2 rounded-xl bg-white border border-slate-200 text-rose-600 hover:bg-rose-50 active:scale-95 transition-all shadow-xs"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="text-slate-400 pl-2 shrink-0 flex items-center">
                      <ChevronRight className="w-5 h-5" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Floating Action Button (+) */}
        <button
          type="button"
          onClick={handleOpenAddTask}
          aria-label="নতুন কাজ যোগ করুন"
          className="fixed bottom-20 right-5 z-40 w-14 h-14 rounded-2xl bg-emerald-600 text-white shadow-xl shadow-emerald-600/30 flex items-center justify-center hover:bg-emerald-500 active:scale-95 transition-all"
        >
          <Plus className="w-7 h-7 stroke-[2.5]" />
        </button>

        {/* Add Task Modal (৩টি জিনিস: নাম, ডিটেলস, রিপিট ডেট) */}
        {showAddTaskModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
            <div className="w-full max-w-sm bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-150 my-6">
              <form onSubmit={handleSaveAddTask}>
                <div className="p-5 max-h-[75vh] overflow-y-auto space-y-4">
                  <h3 className="text-base font-bold text-slate-900">নতুন টু ডু কাজ যোগ করুন</h3>

                  {/* 1. Name */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      নাম <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      autoFocus
                      required
                      value={inputName}
                      onChange={(e) => setInputName(e.target.value)}
                      placeholder="যেমন: সমাজ, বিজ্ঞান"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                    />
                  </div>

                  {/* 2. Details */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      ডিটেলস (ঐচ্ছিক)
                    </label>
                    <textarea
                      rows={2}
                      value={inputDetails}
                      onChange={(e) => setInputDetails(e.target.value)}
                      placeholder="কাজের বিস্তারিত বিবরণ"
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 resize-none"
                    />
                  </div>

                  {/* 3. Repeat Date (4 options) */}
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-2">
                      রিপিট ডেট বাছুন <span className="text-rose-500">*</span>
                    </label>
                    <div className="space-y-2">
                      {/* Daily */}
                      <label
                        className={`flex items-center gap-2.5 p-2.5 rounded-xl border cursor-pointer transition-all ${
                          repeatType === 'daily'
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-950 font-bold'
                            : 'bg-slate-50 border-slate-200 text-slate-700'
                        }`}
                      >
                        <input
                          type="radio"
                          name="repeatType"
                          value="daily"
                          checked={repeatType === 'daily'}
                          onChange={() => setRepeatType('daily')}
                          className="accent-emerald-600"
                        />
                        <span className="text-xs">ডেইলি (প্রতিদিন)</span>
                      </label>

                      {/* Weekly */}
                      <label
                        className={`block p-2.5 rounded-xl border cursor-pointer transition-all ${
                          repeatType === 'weekly'
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-950 font-bold'
                            : 'bg-slate-50 border-slate-200 text-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 mb-2">
                          <input
                            type="radio"
                            name="repeatType"
                            value="weekly"
                            checked={repeatType === 'weekly'}
                            onChange={() => setRepeatType('weekly')}
                            className="accent-emerald-600"
                          />
                          <span className="text-xs">কোন কোন দিন (প্রতি সপ্তাহে)</span>
                        </div>

                        {repeatType === 'weekly' && (
                          <div className="flex items-center justify-between gap-1 mt-2 pt-2 border-t border-emerald-200/60">
                            {BENGALI_WEEKDAYS_SHORT.map((w, idx) => {
                              const isSelected = selectedWeekdays.includes(idx);
                              return (
                                <button
                                  key={idx}
                                  type="button"
                                  onClick={() => handleToggleWeekday(idx)}
                                  className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${
                                    isSelected
                                      ? 'bg-emerald-600 text-white shadow-xs'
                                      : 'bg-white text-slate-600 border border-slate-200'
                                  }`}
                                >
                                  {w}
                                </button>
                              );
                            })}
                          </div>
                        )}
                      </label>

                      {/* Interval */}
                      <label
                        className={`block p-2.5 rounded-xl border cursor-pointer transition-all ${
                          repeatType === 'interval'
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-950 font-bold'
                            : 'bg-slate-50 border-slate-200 text-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 mb-1">
                          <input
                            type="radio"
                            name="repeatType"
                            value="interval"
                            checked={repeatType === 'interval'}
                            onChange={() => setRepeatType('interval')}
                            className="accent-emerald-600"
                          />
                          <span className="text-xs">কয় দিন পর পর</span>
                        </div>

                        {repeatType === 'interval' && (
                          <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-emerald-200/60">
                            <div>
                              <span className="block text-[11px] text-slate-600 font-medium mb-1">
                                দিনের ব্যবধান
                              </span>
                              <input
                                type="number"
                                min={1}
                                value={intervalDays}
                                onChange={(e) => setIntervalDays(parseInt(e.target.value) || 1)}
                                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-semibold"
                              />
                            </div>
                            <div>
                              <span className="block text-[11px] text-slate-600 font-medium mb-1">
                                শুরুর তারিখ
                              </span>
                              <input
                                type="date"
                                value={intervalStartDate}
                                onChange={(e) => setIntervalStartDate(e.target.value)}
                                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-semibold"
                              />
                            </div>
                          </div>
                        )}
                      </label>

                      {/* Custom Dates */}
                      <label
                        className={`block p-2.5 rounded-xl border cursor-pointer transition-all ${
                          repeatType === 'custom'
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-950 font-bold'
                            : 'bg-slate-50 border-slate-200 text-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 mb-1">
                          <input
                            type="radio"
                            name="repeatType"
                            value="custom"
                            checked={repeatType === 'custom'}
                            onChange={() => setRepeatType('custom')}
                            className="accent-emerald-600"
                          />
                          <span className="text-xs">কাস্টম (নির্দিষ্ট তারিখসমূহ)</span>
                        </div>

                        {repeatType === 'custom' && (
                          <div className="mt-2 pt-2 border-t border-emerald-200/60 space-y-2">
                            <div className="flex items-center gap-1.5">
                              <input
                                type="date"
                                value={customDateInput}
                                onChange={(e) => setCustomDateInput(e.target.value)}
                                className="flex-1 px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-semibold"
                              />
                              <button
                                type="button"
                                onClick={handleAddCustomDate}
                                className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold shrink-0"
                              >
                                যোগ
                              </button>
                            </div>

                            {/* Chosen Custom Dates Chips */}
                            <div className="flex flex-wrap gap-1 max-h-24 overflow-y-auto">
                              {customDates.length === 0 ? (
                                <span className="text-[11px] text-slate-400">
                                  তারিখ নির্বাচন করে যোগ বাটন চাপুন।
                                </span>
                              ) : (
                                customDates.map((cd) => (
                                  <span
                                    key={cd}
                                    className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-white border border-emerald-200 text-[11px] font-semibold text-emerald-900"
                                  >
                                    <span>{formatDateToBengali(cd, false)}</span>
                                    <button
                                      type="button"
                                      onClick={() => handleRemoveCustomDate(cd)}
                                      className="text-rose-500 hover:text-rose-700 font-bold ml-1"
                                    >
                                      ✕
                                    </button>
                                  </span>
                                ))
                              )}
                            </div>
                          </div>
                        )}
                      </label>
                    </div>
                  </div>
                </div>

                <div className="flex border-t border-slate-100 bg-slate-50 p-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddTaskModal(false)}
                    className="flex-1 py-2.5 px-4 rounded-xl text-sm font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 active:scale-98 transition-all"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 px-4 rounded-xl text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-98 transition-all shadow-sm"
                  >
                    যোগ করুন
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Edit Task Modal */}
        {editingTask && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
            <div className="w-full max-w-sm bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-150 my-6">
              <form onSubmit={handleSaveEditTask}>
                <div className="p-5 max-h-[75vh] overflow-y-auto space-y-4">
                  <h3 className="text-base font-bold text-slate-900">কাজের তথ্য পরিবর্তন</h3>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      নাম <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      autoFocus
                      required
                      value={inputName}
                      onChange={(e) => setInputName(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      ডিটেলস (ঐচ্ছিক)
                    </label>
                    <textarea
                      rows={2}
                      value={inputDetails}
                      onChange={(e) => setInputDetails(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                    />
                  </div>

                  {/* Repeat configuration */}
                  <div>
                    <label className="block text-xs font-bold text-slate-800 mb-2">
                      রিপিট ডেট
                    </label>
                    <div className="space-y-2">
                      {/* Daily */}
                      <label
                        className={`flex items-center gap-2.5 p-2 rounded-xl border cursor-pointer text-xs ${
                          repeatType === 'daily'
                            ? 'bg-blue-50 border-blue-300 text-blue-950 font-bold'
                            : 'bg-slate-50 border-slate-200 text-slate-700'
                        }`}
                      >
                        <input
                          type="radio"
                          name="editRepeatType"
                          value="daily"
                          checked={repeatType === 'daily'}
                          onChange={() => setRepeatType('daily')}
                          className="accent-blue-600"
                        />
                        <span>ডেইলি (প্রতিদিন)</span>
                      </label>

                      {/* Weekly */}
                      <label
                        className={`block p-2 rounded-xl border cursor-pointer text-xs ${
                          repeatType === 'weekly'
                            ? 'bg-blue-50 border-blue-300 text-blue-950 font-bold'
                            : 'bg-slate-50 border-slate-200 text-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <input
                            type="radio"
                            name="editRepeatType"
                            value="weekly"
                            checked={repeatType === 'weekly'}
                            onChange={() => setRepeatType('weekly')}
                            className="accent-blue-600"
                          />
                          <span>কোন কোন দিন (প্রতি সপ্তাহে)</span>
                        </div>
                        {repeatType === 'weekly' && (
                          <div className="flex items-center justify-between gap-1 mt-2 pt-2 border-t border-blue-200/60">
                            {BENGALI_WEEKDAYS_SHORT.map((w, idx) => {
                              const isSelected = selectedWeekdays.includes(idx);
                              return (
                                <button
                                  key={idx}
                                  type="button"
                                  onClick={() => handleToggleWeekday(idx)}
                                  className={`w-7 h-7 rounded-lg text-xs font-bold transition-all ${
                                    isSelected
                                      ? 'bg-blue-600 text-white'
                                      : 'bg-white text-slate-600 border border-slate-200'
                                  }`}
                                >
                                  {w}
                                </button>
                              );
                            })}
                          </div>
                        )}
                      </label>

                      {/* Interval */}
                      <label
                        className={`block p-2 rounded-xl border cursor-pointer text-xs ${
                          repeatType === 'interval'
                            ? 'bg-blue-50 border-blue-300 text-blue-950 font-bold'
                            : 'bg-slate-50 border-slate-200 text-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <input
                            type="radio"
                            name="editRepeatType"
                            value="interval"
                            checked={repeatType === 'interval'}
                            onChange={() => setRepeatType('interval')}
                            className="accent-blue-600"
                          />
                          <span>কয় দিন পর পর</span>
                        </div>
                        {repeatType === 'interval' && (
                          <div className="grid grid-cols-2 gap-2 mt-2 pt-2 border-t border-blue-200/60">
                            <div>
                              <span className="block text-[11px] text-slate-600 font-medium mb-1">
                                দিনের ব্যবধান
                              </span>
                              <input
                                type="number"
                                min={1}
                                value={intervalDays}
                                onChange={(e) => setIntervalDays(parseInt(e.target.value) || 1)}
                                className="w-full px-2 py-1 rounded border border-slate-300 bg-white text-xs font-semibold"
                              />
                            </div>
                            <div>
                              <span className="block text-[11px] text-slate-600 font-medium mb-1">
                                শুরুর তারিখ
                              </span>
                              <input
                                type="date"
                                value={intervalStartDate}
                                onChange={(e) => setIntervalStartDate(e.target.value)}
                                className="w-full px-2 py-1 rounded border border-slate-300 bg-white text-xs font-semibold"
                              />
                            </div>
                          </div>
                        )}
                      </label>

                      {/* Custom */}
                      <label
                        className={`block p-2 rounded-xl border cursor-pointer text-xs ${
                          repeatType === 'custom'
                            ? 'bg-blue-50 border-blue-300 text-blue-950 font-bold'
                            : 'bg-slate-50 border-slate-200 text-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <input
                            type="radio"
                            name="editRepeatType"
                            value="custom"
                            checked={repeatType === 'custom'}
                            onChange={() => setRepeatType('custom')}
                            className="accent-blue-600"
                          />
                          <span>কাস্টম (নির্দিষ্ট তারিখসমূহ)</span>
                        </div>
                        {repeatType === 'custom' && (
                          <div className="mt-2 pt-2 border-t border-blue-200/60 space-y-2">
                            <div className="flex items-center gap-1.5">
                              <input
                                type="date"
                                value={customDateInput}
                                onChange={(e) => setCustomDateInput(e.target.value)}
                                className="flex-1 px-2 py-1 rounded border border-slate-300 bg-white text-xs font-semibold"
                              />
                              <button
                                type="button"
                                onClick={handleAddCustomDate}
                                className="px-2.5 py-1 rounded bg-blue-600 text-white text-xs font-bold shrink-0"
                              >
                                যোগ
                              </button>
                            </div>
                            <div className="flex flex-wrap gap-1 max-h-20 overflow-y-auto">
                              {customDates.map((cd) => (
                                <span
                                  key={cd}
                                  className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-white border border-blue-200 text-[11px] font-semibold text-blue-900"
                                >
                                  <span>{formatDateToBengali(cd, false)}</span>
                                  <button
                                    type="button"
                                    onClick={() => handleRemoveCustomDate(cd)}
                                    className="text-rose-500 hover:text-rose-700 font-bold ml-1"
                                  >
                                    ✕
                                  </button>
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </label>
                    </div>
                  </div>
                </div>

                <div className="flex border-t border-slate-100 bg-slate-50 p-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setEditingTask(null)}
                    className="flex-1 py-2.5 px-4 rounded-xl text-sm font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 active:scale-98 transition-all"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 px-4 rounded-xl text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 active:scale-98 transition-all shadow-sm"
                  >
                    সংরক্ষণ করুন
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Delete Task Confirmation Modal */}
        <ConfirmModal
          isOpen={taskToDelete !== null}
          title="কাজটি মুছে ফেলবেন?"
          message={`"${taskToDelete?.name}" কাজটি এবং এর ইতিহাস মুছে ফেলতে চান?`}
          confirmLabel="মুছে ফেলুন"
          cancelLabel="না"
          isDestructive={true}
          onConfirm={() => {
            if (taskToDelete && selectedGroup) {
              onDeleteTask(selectedGroup.id, taskToDelete.id);
              setTaskToDelete(null);
            }
          }}
          onCancel={() => setTaskToDelete(null)}
        />
      </div>
    );
  }

  // ================= VIEW: To Do Main Screen (Group List) =================
  return (
    <div className="pb-28 max-w-md mx-auto px-4 pt-3">
      {/* 100 Group Limit Warning */}
      {limitWarning && (
        <div className="mb-3 p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center justify-between">
          <span>{limitWarning}</span>
          <button
            type="button"
            onClick={() => setLimitWarning(null)}
            className="text-amber-800 font-bold ml-2"
          >
            ✕
          </button>
        </div>
      )}

      {groups.length === 0 ? (
        <EmptyState
          message="এখনও কোনো টু ডু গ্রুপ নেই।"
          subMessage="নিচের + চেপে গ্রুপ তৈরি করুন (যেমন: বিজ্ঞান, ধর্ম)।"
        />
      ) : (
        <div className="space-y-2.5">
          {groups.map((group, index) => {
            const count = group.tasks.length;

            return (
              <div
                key={group.id}
                onClick={() => {
                  if (!isEditMode) {
                    onSelectGroup(group.id);
                  }
                }}
                className={`relative flex items-center justify-between p-4 rounded-2xl border transition-all duration-200 select-none ${
                  isEditMode
                    ? 'bg-amber-50/70 border-amber-200/80 shadow-xs'
                    : 'bg-white border-slate-200/80 shadow-xs hover:border-emerald-300 hover:shadow-sm active:scale-[0.99] cursor-pointer'
                }`}
              >
                {/* Left Section: Reorder or Drag handle + Name */}
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  {isEditMode ? (
                    <div className="flex items-center gap-1 shrink-0 text-slate-500">
                      <GripVertical className="w-5 h-5 text-amber-600" />
                      <div className="flex flex-col gap-0.5">
                        <button
                          type="button"
                          disabled={index === 0}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleMoveGroup(index, 'up');
                          }}
                          aria-label="উপরে নিন"
                          className="p-1 rounded bg-white border border-slate-200 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none active:bg-slate-200 text-slate-700"
                        >
                          <ArrowUp className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          disabled={index === groups.length - 1}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleMoveGroup(index, 'down');
                          }}
                          aria-label="নিচে নিন"
                          className="p-1 rounded bg-white border border-slate-200 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none active:bg-slate-200 text-slate-700"
                        >
                          <ArrowDown className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-700 border border-purple-100 flex items-center justify-center font-bold text-sm shrink-0">
                      {toBengaliNum(index + 1)}
                    </div>
                  )}

                  <div className="min-w-0 flex-1">
                    <h3 className="text-base font-bold text-slate-900 leading-snug break-words">
                      {group.name}
                    </h3>
                    {group.details && (
                      <p className="text-xs text-slate-500 mt-0.5 line-clamp-1 break-words">
                        {group.details}
                      </p>
                    )}
                    <p className="text-xs text-slate-400 mt-0.5">
                      {count === 0 ? 'কোনো কাজ নেই' : `${toBengaliNum(count)}টি কাজ`}
                    </p>
                  </div>
                </div>

                {/* Right Section: Edit actions (✎ / 🗑) or Chevron */}
                {isEditMode ? (
                  <div className="flex items-center gap-1.5 ml-2 shrink-0">
                    <button
                      type="button"
                      onClick={(e) => handleOpenEditGroup(group, e)}
                      aria-label="নাম পরিবর্তন করুন"
                      className="p-2 rounded-xl bg-white border border-slate-200 text-blue-600 hover:bg-blue-50 active:scale-95 transition-all shadow-xs"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setGroupToDelete(group);
                      }}
                      aria-label="গ্রুপ মুছুন"
                      className="p-2 rounded-xl bg-white border border-slate-200 text-rose-600 hover:bg-rose-50 active:scale-95 transition-all shadow-xs"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div className="text-slate-400 pl-2 shrink-0">
                    <ChevronRight className="w-5 h-5" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Floating Action Button (+) */}
      <button
        type="button"
        onClick={handleOpenAddGroup}
        aria-label="নতুন গ্রুপ যোগ করুন"
        className="fixed bottom-20 right-5 z-40 w-14 h-14 rounded-2xl bg-emerald-600 text-white shadow-xl shadow-emerald-600/30 flex items-center justify-center hover:bg-emerald-500 active:scale-95 transition-all"
      >
        <Plus className="w-7 h-7 stroke-[2.5]" />
      </button>

      {/* Add Group Modal (২টি ঘর: নাম, ডিটেলস ঐচ্ছিক) */}
      {showAddGroupModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-150">
            <form onSubmit={handleSaveAddGroup}>
              <div className="p-5 space-y-3.5">
                <h3 className="text-base font-bold text-slate-900">নতুন টু ডু গ্রুপ তৈরি করুন</h3>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    নাম <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    autoFocus
                    required
                    value={inputName}
                    onChange={(e) => setInputName(e.target.value)}
                    placeholder="যেমন: বিজ্ঞান"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    ডিটেলস (ঐচ্ছিক)
                  </label>
                  <textarea
                    rows={2}
                    value={inputDetails}
                    onChange={(e) => setInputDetails(e.target.value)}
                    placeholder="গ্রুপের বিবরণ"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 resize-none"
                  />
                </div>
              </div>
              <div className="flex border-t border-slate-100 bg-slate-50 p-3 gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddGroupModal(false)}
                  className="flex-1 py-2.5 px-4 rounded-xl text-sm font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 active:scale-98 transition-all"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 rounded-xl text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-98 transition-all shadow-sm"
                >
                  তৈরি করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Group Modal */}
      {editingGroup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-150">
            <form onSubmit={handleSaveEditGroup}>
              <div className="p-5 space-y-3.5">
                <h3 className="text-base font-bold text-slate-900">গ্রুপের তথ্য পরিবর্তন</h3>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    নাম <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    autoFocus
                    required
                    value={inputName}
                    onChange={(e) => setInputName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    ডিটেলস (ঐচ্ছিক)
                  </label>
                  <textarea
                    rows={2}
                    value={inputDetails}
                    onChange={(e) => setInputDetails(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                  />
                </div>
              </div>
              <div className="flex border-t border-slate-100 bg-slate-50 p-3 gap-2">
                <button
                  type="button"
                  onClick={() => setEditingGroup(null)}
                  className="flex-1 py-2.5 px-4 rounded-xl text-sm font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 active:scale-98 transition-all"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 rounded-xl text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 active:scale-98 transition-all shadow-sm"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Group Confirmation Modal (Warns that all tasks and history inside will be deleted) */}
      <ConfirmModal
        isOpen={groupToDelete !== null}
        title="গ্রুপটি মুছে ফেলবেন?"
        message={`"${groupToDelete?.name}" গ্রুপ মুছলে তার ভেতরের সব কাজ ও ইতিহাসও মুছে যাবে। আপনি কি নিশ্চিত?`}
        confirmLabel="মুছে ফেলুন"
        cancelLabel="না, রাখুন"
        isDestructive={true}
        onConfirm={() => {
          if (groupToDelete) {
            onDeleteGroup(groupToDelete.id);
            setGroupToDelete(null);
          }
        }}
        onCancel={() => setGroupToDelete(null)}
      />
    </div>
  );
};

function getRepeatLabel(repeat: RepeatConfig): string {
  switch (repeat.type) {
    case 'daily':
      return 'প্রতিদিন';
    case 'weekly': {
      if (!repeat.daysOfWeek || repeat.daysOfWeek.length === 0) return 'কোনো বার নেই';
      if (repeat.daysOfWeek.length === 7) return 'সপ্তাহের প্রতিদিন';
      return repeat.daysOfWeek.map((d) => BENGALI_WEEKDAYS_SHORT[d]).join(', ');
    }
    case 'interval':
      return `প্রতি ${toBengaliNum(repeat.intervalDays || 1)} দিন পর পর`;
    case 'custom':
      return `কাস্টম (${toBengaliNum(repeat.dates?.length || 0)}টি নির্দিষ্ট দিন)`;
    default:
      return 'অজানা';
  }
}
