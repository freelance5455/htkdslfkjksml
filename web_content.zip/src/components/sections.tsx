import { useEffect, useState, type FormEvent } from "react";
import {
  beforeAfter,
  benefits,
  comparison,
  faqs,
  features,
  logos,
  plans,
  stats,
  testimonials,
} from "@/content";
import { useApp, type TabId } from "@/context";
import { CityRibbon, HeroStage, ShowcaseVisual, showcaseTabs } from "./product";
import {
  ArrowIcon,
  Avatar,
  Button,
  CheckIcon,
  CloseIcon,
  Eyebrow,
  Logo,
  MenuIcon,
  Reveal,
  initials,
  isEmail,
  useCountUp,
  useInView,
  useReducedMotion,
} from "./ui";
import { cn } from "@/utils/cn";

const navLinks = [
  { href: "#showcase", id: "showcase", label: "Product" },
  { href: "#features", id: "features", label: "Features" },
  { href: "#benefits", id: "benefits", label: "Benefits" },
  { href: "#pricing", id: "pricing", label: "Pricing" },
  { href: "#faq", id: "faq", label: "FAQ" },
];

export function ScrollProgress() {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const height = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(height > 0 ? window.scrollY / height : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <div className="fixed inset-x-0 top-0 z-[60] h-[2px]" aria-hidden="true">
      <div
        className="h-full origin-left bg-gradient-to-r from-copper via-paper to-teal"
        style={{ transform: `scaleX(${progress})` }}
      />
    </div>
  );
}

export function Navbar() {
  const { openTrial, openLogin, menuOpen, setMenuOpen } = useApp();
  const [scrolled, setScrolled] = useState(false);
  const [active, setActive] = useState("");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const nodes = navLinks
      .map((link) => document.getElementById(link.id))
      .filter((node): node is HTMLElement => Boolean(node));
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target.id) setActive(visible.target.id);
      },
      { rootMargin: "-42% 0px -48% 0px", threshold: [0.15, 0.4] },
    );
    nodes.forEach((node) => observer.observe(node));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMenuOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [menuOpen, setMenuOpen]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled || menuOpen ? "border-b border-white/10 bg-ink/80 backdrop-blur-xl" : "bg-transparent",
      )}
    >
      <div className="mx-auto flex h-16 max-w-[1180px] items-center justify-between px-5 sm:px-8">
        <a href="#top" className="relative z-10 rounded-full" aria-label="Nexus AI home">
          <Logo />
        </a>
        <nav className="absolute left-1/2 hidden -translate-x-1/2 items-center gap-1 lg:flex" aria-label="Primary">
          {navLinks.map((link) => (
            <a
              key={link.id}
              href={link.href}
              aria-current={active === link.id ? "true" : undefined}
              className={cn(
                "rounded-full px-3 py-1.5 text-sm transition",
                active === link.id ? "bg-white/8 text-paper" : "text-mist hover:text-paper",
              )}
            >
              {link.label}
            </a>
          ))}
        </nav>
        <div className="relative z-10 flex items-center gap-2">
          <button type="button" onClick={openLogin} className="hidden h-9 px-3 text-sm text-mist transition hover:text-paper sm:inline-flex">
            Log in
          </button>
          <Button size="sm" onClick={() => openTrial({ plan: "Team" })} className="hidden sm:inline-flex">
            Start free trial
          </Button>
          <Button size="sm" onClick={() => openTrial({ plan: "Team" })} className="sm:hidden">
            Trial
          </Button>
          <button
            type="button"
            className="grid size-10 place-items-center rounded-full border border-white/10 text-paper lg:hidden"
            aria-expanded={menuOpen}
            aria-controls="mobile-nav"
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <CloseIcon /> : <MenuIcon />}
          </button>
        </div>
      </div>
      {menuOpen ? (
        <div id="mobile-nav" className="fixed inset-0 top-16 z-40 bg-ink/95 backdrop-blur-xl lg:hidden">
          <nav className="flex h-full flex-col px-6 py-8" aria-label="Mobile">
            {navLinks.map((link, index) => (
              <a
                key={link.id}
                href={link.href}
                onClick={() => setMenuOpen(false)}
                className="rise border-b border-white/8 py-4 font-serif text-4xl tracking-[-0.03em]"
                style={{ animationDelay: `${index * 40}ms` }}
              >
                {link.label}
              </a>
            ))}
            <div className="mt-8 flex flex-col gap-3">
              <Button onClick={() => openTrial({ plan: "Team" })}>Start free trial</Button>
              <Button variant="ghost" onClick={openLogin}>
                Log in
              </Button>
            </div>
          </nav>
        </div>
      ) : null}
    </header>
  );
}

function PointerGlow() {
  const [pos, setPos] = useState({ x: 50, y: 18 });
  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce || window.matchMedia("(pointer: coarse)").matches) return;
    const onMove = (event: PointerEvent) => {
      const host = document.getElementById("hero");
      if (!host) return;
      const rect = host.getBoundingClientRect();
      setPos({
        x: event.clientX - rect.left,
        y: event.clientY - rect.top,
      });
    };
    window.addEventListener("pointermove", onMove);
    return () => window.removeEventListener("pointermove", onMove);
  }, []);
  return (
    <div
      className="pointer-events-none absolute inset-0"
      aria-hidden="true"
      style={{
        background: `radial-gradient(540px circle at ${pos.x}px ${pos.y}px, rgba(228,161,91,0.16), transparent 46%)`,
      }}
    />
  );
}

export function Hero() {
  const { openTrial, openDemo } = useApp();
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (!isEmail(email)) {
      setError("Enter a work email to open your trial.");
      return;
    }
    setError("");
    openTrial({ email, plan: "Team" });
  }

  return (
    <section id="hero" className="relative overflow-hidden pt-28 sm:pt-36">
      <div className="grid-fade pointer-events-none absolute inset-0" />
      <div className="orb -left-24 top-8 size-[28rem] bg-copper/25" />
      <div className="orb -right-16 top-40 size-[22rem] bg-teal/20" style={{ animationDelay: "-7s" }} />
      <div className="orb bottom-24 left-1/3 size-[18rem] bg-iris/20" style={{ animationDelay: "-12s" }} />
      <PointerGlow />
      <div className="relative mx-auto max-w-[1180px] px-5 sm:px-8">
        <div className="mx-auto max-w-4xl text-center">
          <p className="rise mb-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-mist">
            <span className="size-1.5 rounded-full bg-teal shadow-[0_0_10px_#7ee0c8]" />
            Public beta · Built for remote engineers
          </p>
          <h1 className="rise text-[clamp(3rem,7.4vw,6.15rem)] font-medium leading-[0.92] tracking-[-0.05em] text-paper" style={{ animationDelay: "70ms" }}>
            Code with a teammate
            <span className="mt-1 block bg-gradient-to-r from-paper via-[#f3d7b0] to-copper bg-clip-text pb-1 font-serif text-[0.92em] font-normal italic tracking-[-0.03em] text-transparent">
              who never clocks out.
            </span>
          </h1>
          <p className="rise mx-auto mt-6 max-w-2xl text-base leading-relaxed text-mist sm:text-lg" style={{ animationDelay: "140ms" }}>
            Nexus lives in your repository. It drafts the change, pre-reviews the pull request, and carries context across timezones — so you stay in the work, not in the archaeology.
          </p>
          <form className="rise mx-auto mt-8 max-w-xl" style={{ animationDelay: "200ms" }} noValidate onSubmit={onSubmit}>
            <div className="flex flex-col gap-2 rounded-2xl border border-white/10 bg-white/[0.04] p-2 shadow-[0_20px_80px_-40px_rgba(228,161,91,0.7)] backdrop-blur-md focus-within:border-copper/60 focus-within:ring-2 focus-within:ring-copper/30 sm:flex-row sm:rounded-full">
              <label htmlFor="hero-email" className="sr-only">
                Work email
              </label>
              <input
                id="hero-email"
                type="email"
                autoComplete="email"
                placeholder="you@company.com"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                aria-invalid={error ? true : undefined}
                aria-describedby={error ? "hero-email-error" : "hero-email-hint"}
                className="h-12 flex-1 bg-transparent px-4 text-paper outline-none placeholder:text-faint"
              />
              <Button type="submit" size="lg" className="w-full sm:w-auto">
                Start free trial <ArrowIcon />
              </Button>
            </div>
            {error ? (
              <p id="hero-email-error" className="mt-2 text-sm text-copper" role="alert">
                {error}
              </p>
            ) : (
              <p id="hero-email-hint" className="mt-3 text-xs text-faint">
                14 days of Team · No card · No training on your code · Press <kbd className="rounded border border-white/15 px-1.5 py-0.5 font-mono text-[10px] text-mist">T</kbd>
              </p>
            )}
          </form>
          <div className="rise mt-5 flex flex-wrap items-center justify-center gap-4" style={{ animationDelay: "260ms" }}>
            <button type="button" onClick={openDemo} className="inline-flex items-center gap-2 text-sm text-paper transition hover:text-copper">
              <span className="grid size-8 place-items-center rounded-full border border-white/15">
                <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true">
                  <path d="M3 1.8v8.4L10.2 6 3 1.8z" fill="currentColor" />
                </svg>
              </span>
              Watch the 90-second tour
            </button>
            <div className="flex items-center gap-3">
              <div className="flex -space-x-2" aria-hidden="true">
                {testimonials.map((person) => (
                  <Avatar
                    key={person.name}
                    src={person.photo}
                    alt=""
                    initials={initials(person.name)}
                    className="size-8 rounded-full ring-2 ring-ink"
                  />
                ))}
              </div>
              <p className="text-left text-xs leading-snug text-mist">
                <span className="text-paper">18,400 developers</span>
                <br />
                shipping from 64 countries
              </p>
            </div>
          </div>
        </div>
        <div className="rise relative mx-auto mt-14 max-w-5xl sm:mt-16" style={{ animationDelay: "320ms" }}>
          <HeroStage />
          <CityRibbon />
        </div>
      </div>
    </section>
  );
}

function Stat({ value, suffix, decimals, label }: { value: number; suffix: string; decimals: number; label: string }) {
  const { ref, shown } = useInView<HTMLDivElement>();
  const count = useCountUp(value, shown);
  const text = decimals ? count.toFixed(decimals) : Math.round(count).toString();
  return (
    <div ref={ref}>
      <p className="font-serif text-5xl tabular-nums tracking-[-0.04em] text-paper sm:text-6xl">
        {text}
        <span className="text-copper">{suffix}</span>
      </p>
      <p className="mt-3 max-w-[16rem] text-sm leading-relaxed text-mist">{label}</p>
    </div>
  );
}

export function SocialProof() {
  const { openPage } = useApp();
  const reduce = useReducedMotion();
  return (
    <section className="relative mx-auto mt-20 max-w-[1180px] px-5 sm:mt-28 sm:px-8" aria-labelledby="proof-title">
      <h2 id="proof-title" className="sr-only">
        Teams and outcomes
      </h2>
      <Reveal>
        <p className="text-center text-[11px] font-semibold uppercase tracking-[0.22em] text-faint">
          Trusted by engineers who got their mornings back
        </p>
        <p className="sr-only">{logos.join(", ")}</p>
        {reduce ? (
          <div className="mt-6 flex flex-wrap justify-center gap-x-10 gap-y-3">
            {logos.map((name) => (
              <span key={name} className="text-lg font-medium tracking-[-0.03em] text-paper/45">
                {name}
              </span>
            ))}
          </div>
        ) : (
          <div className="marquee mt-6 overflow-hidden">
            <div className="marquee-track flex w-max gap-14 pr-14">
              {[...logos, ...logos].map((name, index) => (
                <span key={`${name}-${index}`} className="text-lg font-medium tracking-[-0.03em] text-paper/40" aria-hidden="true">
                  {name}
                </span>
              ))}
            </div>
          </div>
        )}
      </Reveal>
      <div className="mt-14 grid gap-10 border-y border-white/10 py-12 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, index) => (
          <Reveal key={stat.label} delay={index * 80}>
            <Stat {...stat} />
          </Reveal>
        ))}
      </div>
      <Reveal>
        <div className="mt-8 flex flex-col items-start justify-between gap-5 rounded-3xl border border-white/10 bg-white/[0.03] p-6 sm:flex-row sm:items-center">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-copper">Halcyon · nine timezones</p>
            <p className="mt-2 max-w-xl font-serif text-2xl tracking-[-0.03em] sm:text-3xl">
              Review latency fell 64% without adding a standup.
            </p>
          </div>
          <Button variant="ghost" onClick={() => openPage("customers")}>
            Read customer stories <ArrowIcon />
          </Button>
        </div>
      </Reveal>
      <p className="mt-8 text-center text-[11px] font-semibold uppercase tracking-[0.18em] text-faint">In the tools you already live in</p>
      <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
        {["GitHub", "GitLab", "Bitbucket", "VS Code", "Cursor", "JetBrains", "Neovim", "Slack"].map((name) => (
          <span key={name} className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-xs text-mist">
            {name}
          </span>
        ))}
      </div>
      <p className="mt-4 text-center text-xs text-faint">Cohort of teams active 90+ days. Q1 2026.</p>
    </section>
  );
}

function MemorySketch() {
  const nodes = [
    { label: "ADR-014", x: "8%", y: "38%" },
    { label: "retry.ts", x: "38%", y: "22%" },
    { label: "incident-1102", x: "36%", y: "68%" },
    { label: "CODEOWNERS", x: "68%", y: "40%" },
  ];
  return (
    <div className="relative mt-8 h-52 overflow-hidden rounded-2xl border border-white/10 bg-ink/50">
      <svg className="absolute inset-0 h-full w-full" viewBox="0 0 600 200" aria-hidden="true">
        <path d="M90 90 C 180 90, 200 55, 250 55 M250 55 C 340 55, 360 90, 430 90 M90 90 C 180 90, 190 145, 250 145 M250 145 C 330 145, 360 90, 430 90" fill="none" stroke="rgba(228,161,91,0.45)" strokeWidth="1.2" />
        <circle cx="90" cy="90" r="4" fill="#e4a15b" />
        <circle cx="250" cy="55" r="4" fill="#f6f1e7" />
        <circle cx="250" cy="145" r="4" fill="#7ee0c8" />
        <circle cx="430" cy="90" r="4" fill="#c4b6ff" />
      </svg>
      {nodes.map((node) => (
        <span
          key={node.label}
          className="absolute rounded-full border border-white/10 bg-ink/80 px-2.5 py-1 font-mono text-[10px] text-mist backdrop-blur"
          style={{ left: node.x, top: node.y }}
        >
          {node.label}
        </span>
      ))}
    </div>
  );
}

export function Features() {
  const { setShowcase } = useApp();
  const open = (tab: TabId) => {
    setShowcase(tab);
    document.getElementById("showcase")?.scrollIntoView({ behavior: "smooth" });
  };
  const [lead, ...rest] = features;
  return (
    <section id="features" className="scroll-mt-24 mx-auto max-w-[1180px] px-5 py-24 sm:px-8 sm:py-32" aria-labelledby="features-title">
      <Reveal>
        <Eyebrow>The workspace</Eyebrow>
        <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <h2 id="features-title" className="max-w-xl font-serif text-[clamp(2.3rem,4.4vw,3.7rem)] leading-[1.02] tracking-[-0.035em]">
            Everything a distributed team loses between timezones, put back in the repo.
          </h2>
          <p className="max-w-sm text-mist">
            Not another chat window bolted onto your editor. A teammate that already read the files, the ADR, and the incident.
          </p>
        </div>
      </Reveal>
      <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-6">
        <Reveal className="md:col-span-2 lg:col-span-4 lg:row-span-2">
          <article className="glass lift flex h-full flex-col rounded-3xl p-6 sm:p-8">
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-copper">{lead.kicker}</p>
            <h3 className="mt-3 font-serif text-3xl tracking-[-0.03em]">{lead.title}</h3>
            <p className="mt-3 max-w-lg text-sm leading-relaxed text-mist sm:text-base">{lead.body}</p>
            <MemorySketch />
            <button type="button" onClick={() => open(lead.tab)} className="mt-6 inline-flex items-center gap-2 text-sm text-paper hover:text-copper">
              Explore memory <ArrowIcon />
            </button>
          </article>
        </Reveal>
        {rest.map((feature, index) => (
          <Reveal key={feature.title} delay={index * 70} className="lg:col-span-2">
            <article className="glass lift flex h-full flex-col rounded-3xl p-6">
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-copper">{feature.kicker}</p>
              <h3 className="mt-3 text-xl tracking-[-0.03em]">{feature.title}</h3>
              <p className="mt-2 flex-1 text-sm leading-relaxed text-mist">{feature.body}</p>
              <button type="button" onClick={() => open(feature.tab)} className="mt-5 inline-flex items-center gap-2 text-sm text-paper hover:text-copper">
                See it <ArrowIcon />
              </button>
            </article>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

export function Showcase() {
  const { showcase, setShowcase } = useApp();
  const reduce = useReducedMotion();
  useEffect(() => {
    if (reduce) return;
    const node = document.getElementById("showcase-tabs");
    if (!node) return;
    const onKey = (event: KeyboardEvent) => {
      if (!node.contains(document.activeElement)) return;
      const index = showcaseTabs.findIndex((tab) => tab.id === showcase);
      const move = (next: number) => {
        const id = showcaseTabs[next].id;
        setShowcase(id);
        document.getElementById(`tab-${id}`)?.focus();
      };
      if (event.key === "ArrowDown" || event.key === "ArrowRight") {
        event.preventDefault();
        move((index + 1) % showcaseTabs.length);
      }
      if (event.key === "ArrowUp" || event.key === "ArrowLeft") {
        event.preventDefault();
        move((index - 1 + showcaseTabs.length) % showcaseTabs.length);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [reduce, setShowcase, showcase]);

  return (
    <section id="showcase" className="scroll-mt-24 border-y border-white/10 bg-white/[0.02] py-24 sm:py-32" aria-labelledby="showcase-title">
      <div className="mx-auto grid max-w-[1180px] gap-10 px-5 sm:px-8 lg:grid-cols-[0.78fr_1.22fr] lg:items-start">
        <div className="lg:sticky lg:top-28">
          <Reveal>
            <Eyebrow>Product</Eyebrow>
            <h2 id="showcase-title" className="font-serif text-[clamp(2.3rem,4vw,3.5rem)] leading-[1.02] tracking-[-0.035em]">
              A workspace that feels like a teammate, not a chatbot.
            </h2>
            <p className="mt-4 text-mist">Four surfaces. One index. Use arrow keys when a tab is focused.</p>
          </Reveal>
          <div id="showcase-tabs" role="tablist" aria-orientation="vertical" aria-label="Product surfaces" className="mt-8 flex gap-2 overflow-x-auto lg:flex-col">
            {showcaseTabs.map((tab) => {
              const selected = showcase === tab.id;
              return (
                <button
                  key={tab.id}
                  id={`tab-${tab.id}`}
                  type="button"
                  role="tab"
                  aria-selected={selected}
                  aria-controls={`panel-${tab.id}`}
                  tabIndex={selected ? 0 : -1}
                  onClick={() => setShowcase(tab.id)}
                  className={cn(
                    "min-w-[12rem] rounded-2xl border px-4 py-4 text-left transition lg:min-w-0",
                    selected ? "border-copper/40 bg-copper/10" : "border-white/10 hover:border-white/20",
                  )}
                >
                  <span className="block text-sm font-medium text-paper">{tab.label}</span>
                  <span className={cn("mt-1 block text-sm leading-relaxed", selected ? "text-mist" : "hidden text-faint lg:block")}>
                    {tab.text}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
        <div role="tabpanel" id={`panel-${showcase}`} aria-labelledby={`tab-${showcase}`} className="min-w-0">
          <ShowcaseVisual tab={showcase} />
        </div>
      </div>
    </section>
  );
}

const photos = {
  studio:
    "https://images.pexels.com/photos/5473298/pexels-photo-5473298.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1100&w=900",
  code: "https://images.pexels.com/photos/4218883/pexels-photo-4218883.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=800",
  desk: "https://images.pexels.com/photos/34803994/pexels-photo-34803994.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=800",
};

export function Benefits() {
  const [mode, setMode] = useState<"before" | "after">("after");
  const rows = beforeAfter[mode];
  return (
    <section id="benefits" className="scroll-mt-24 mx-auto max-w-[1180px] px-5 py-24 sm:px-8 sm:py-32" aria-labelledby="benefits-title">
      <div className="grid items-start gap-12 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <Reveal>
            <div className="relative overflow-hidden rounded-[1.7rem]">
              <img
                src={photos.studio}
                alt="Engineer working across multiple screens in a home studio"
                className="h-[440px] w-full object-cover"
                width={900}
                height={1100}
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/25 to-ink/10" />
              <div className="absolute inset-x-0 bottom-0 p-6">
                <p className="text-[11px] uppercase tracking-[0.18em] text-copper">Lisbon · 21:14</p>
                <p className="mt-2 font-serif text-3xl tracking-[-0.03em]">The diff is already reviewed when Nairobi opens the laptop.</p>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-4">
              <img src={photos.code} alt="Warmly lit desk with code on screen" className="h-36 w-full rounded-2xl object-cover" width={400} height={240} loading="lazy" />
              <img src={photos.desk} alt="Laptop displaying source code in a dim workspace" className="h-36 w-full rounded-2xl object-cover" width={400} height={240} loading="lazy" />
            </div>
          </Reveal>
        </div>
        <div className="lg:col-span-7">
          <Reveal>
            <Eyebrow>Why remote teams switch</Eyebrow>
            <h2 id="benefits-title" className="font-serif text-[clamp(2.3rem,4vw,3.5rem)] leading-[1.02] tracking-[-0.035em]">
              Built around the way distributed engineers actually work.
            </h2>
          </Reveal>
          <div className="mt-8 space-y-6">
            {benefits.map((item, index) => (
              <Reveal key={item.n} delay={index * 60}>
                <div className="grid grid-cols-[auto_1fr] gap-4 border-t border-white/10 pt-6">
                  <span className="font-serif text-xl text-copper">{item.n}</span>
                  <div>
                    <h3 className="text-lg tracking-[-0.02em]">{item.title}</h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-mist">{item.body}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
          <Reveal>
            <div className="mt-8 rounded-3xl border border-white/10 p-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <p className="text-sm text-mist">A week on the billing squad</p>
                <div className="flex rounded-full border border-white/10 p-1" role="group" aria-label="Compare before and after Nexus">
                  {(["before", "after"] as const).map((key) => (
                    <button
                      key={key}
                      type="button"
                      aria-pressed={mode === key}
                      onClick={() => setMode(key)}
                      className={cn(
                        "h-8 rounded-full px-3 text-xs transition",
                        mode === key ? "bg-paper text-ink" : "text-mist hover:text-paper",
                      )}
                    >
                      {key === "before" ? "Before Nexus" : "With Nexus"}
                    </button>
                  ))}
                </div>
              </div>
              <dl className="mt-4 grid gap-3 sm:grid-cols-2">
                {rows.map((row) => (
                  <div key={row.k} className="rounded-2xl bg-white/[0.03] px-4 py-3">
                    <dt className="text-[11px] uppercase tracking-[0.14em] text-faint">{row.k}</dt>
                    <dd className="mt-1 text-paper">{row.v}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

export function Testimonials() {
  const reduce = useReducedMotion();
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const person = testimonials[index];

  useEffect(() => {
    if (paused || reduce) return;
    const id = window.setInterval(() => setIndex((value) => (value + 1) % testimonials.length), 7000);
    return () => window.clearInterval(id);
  }, [paused, reduce]);

  const go = (next: number) => setIndex((next + testimonials.length) % testimonials.length);

  return (
    <section id="stories" className="scroll-mt-24 border-t border-white/10 py-24 sm:py-32" aria-labelledby="stories-title" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
      <div className="mx-auto max-w-[1180px] px-5 sm:px-8">
        <Reveal>
          <Eyebrow>From the other office</Eyebrow>
          <h2 id="stories-title" className="max-w-2xl font-serif text-[clamp(2.3rem,4vw,3.5rem)] leading-[1.02] tracking-[-0.035em]">
            People who ship before the other office wakes up.
          </h2>
        </Reveal>
        <div
          className="mt-10 grid items-center gap-8 lg:grid-cols-[0.8fr_1.2fr]"
          tabIndex={0}
          aria-roledescription="carousel"
          aria-label="Customer stories"
          onFocus={() => setPaused(true)}
          onBlur={() => setPaused(false)}
          onKeyDown={(event) => {
            if (event.key === "ArrowRight") go(index + 1);
            if (event.key === "ArrowLeft") go(index - 1);
          }}
        >
          <div key={person.name} className="rise relative">
            <Avatar
              src={person.photo}
              alt={`Portrait of ${person.name}`}
              initials={initials(person.name)}
              className="h-72 w-full rounded-[1.7rem] object-cover sm:h-96 lg:aspect-[4/5] lg:h-auto"
            />
            <p className="absolute bottom-4 left-4 rounded-full bg-ink/80 px-3 py-1 text-xs text-paper backdrop-blur">
              {person.place}
            </p>
          </div>
          <div>
            <p className="font-serif text-5xl leading-none text-copper" aria-hidden="true">
              “
            </p>
            <blockquote key={person.quote} className="rise mt-2 font-serif text-[clamp(1.6rem,3vw,2.5rem)] leading-[1.2] tracking-[-0.03em] text-paper">
              {person.quote}
            </blockquote>
            <div className="mt-6 flex flex-wrap items-end justify-between gap-4">
              <div>
                <p className="font-medium">{person.name}</p>
                <p className="text-sm text-mist">{person.role}</p>
                <p className="mt-2 inline-flex rounded-full border border-teal/30 bg-teal/10 px-3 py-1 text-xs text-teal">{person.result}</p>
              </div>
              <div className="flex items-center gap-2">
                <button type="button" className="grid size-10 place-items-center rounded-full border border-white/10" aria-label="Previous story" onClick={() => go(index - 1)}>
                  <span aria-hidden="true">←</span>
                </button>
                <button type="button" className="grid size-10 place-items-center rounded-full border border-white/10" aria-label="Next story" onClick={() => go(index + 1)}>
                  <span aria-hidden="true">→</span>
                </button>
              </div>
            </div>
            <div className="mt-6 flex gap-2" role="tablist" aria-label="Choose a story">
              {testimonials.map((item, itemIndex) => (
                <button
                  key={item.name}
                  type="button"
                  role="tab"
                  aria-selected={itemIndex === index}
                  aria-label={item.name}
                  onClick={() => setIndex(itemIndex)}
                  className={cn("h-1.5 rounded-full transition-all", itemIndex === index ? "w-8 bg-copper" : "w-3 bg-white/20")}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function Pricing() {
  const { openTrial, openPage } = useApp();
  const [annual, setAnnual] = useState(true);
  const [seats, setSeats] = useState(8);
  const [compare, setCompare] = useState(false);
  const rate = annual ? 46 : 58;
  const yearlySave = (58 - 46) * seats * 12;

  return (
    <section id="pricing" className="scroll-mt-24 mx-auto max-w-[1180px] px-5 py-24 sm:px-8 sm:py-32" aria-labelledby="pricing-title">
      <Reveal>
        <div className="flex flex-col items-start justify-between gap-6 lg:flex-row lg:items-end">
          <div>
            <Eyebrow>Pricing</Eyebrow>
            <h2 id="pricing-title" className="max-w-xl font-serif text-[clamp(2.3rem,4vw,3.6rem)] leading-[1.02] tracking-[-0.035em]">
              Start free. Invite the team when it earns the seat.
            </h2>
          </div>
          <div className="flex items-center gap-3">
            <span className={cn("text-sm", annual ? "text-faint" : "text-paper")}>Monthly</span>
            <button
              type="button"
              role="switch"
              aria-checked={annual}
              aria-label="Bill annually"
              onClick={() => setAnnual((value) => !value)}
              className={cn("relative h-7 w-12 rounded-full transition", annual ? "bg-copper" : "bg-white/15")}
            >
              <span className={cn("absolute top-1 size-5 rounded-full bg-ink transition", annual ? "left-6" : "left-1")} />
            </button>
            <span className={cn("text-sm", annual ? "text-paper" : "text-faint")}>
              Annual <span className="text-copper">−20%</span>
            </span>
          </div>
        </div>
      </Reveal>
      <div className="mt-12 grid gap-4 lg:grid-cols-3">
        {plans.map((plan, index) => {
          const price = annual ? plan.annual : plan.monthly;
          return (
            <Reveal key={plan.id} delay={index * 80}>
              <article
                className={cn(
                  "relative flex h-full flex-col rounded-3xl p-6 sm:p-8",
                  plan.featured
                    ? "bg-ink-2 shadow-[0_30px_90px_-40px_rgba(228,161,91,0.55)] ring-1 ring-copper/60"
                    : "glass",
                )}
              >
                {plan.featured ? (
                  <span className="absolute -top-3 left-6 rounded-full bg-copper px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-ink">
                    Most loved
                  </span>
                ) : null}
                <h3 className="text-lg">{plan.name}</h3>
                <p className="mt-1 text-sm text-mist">{plan.blurb}</p>
                <p className="mt-6 flex items-end gap-2">
                  <span className="font-serif text-5xl tabular-nums tracking-[-0.04em]">
                    {price === 0 ? "Free" : `$${price}`}
                  </span>
                  {price > 0 ? <span className="mb-1 text-sm text-faint">/ dev / mo</span> : null}
                </p>
                {annual && plan.monthly > 0 ? (
                  <p className="mt-1 text-xs text-faint">
                    <span className="line-through">${plan.monthly}</span> · ${plan.annual * 12} billed yearly
                  </p>
                ) : (
                  <p className="mt-1 text-xs text-faint">{price === 0 ? "No card, no expiry theater" : "Billed monthly"}</p>
                )}
                <ul className="mt-6 flex-1 space-y-2.5">
                  {plan.features.map((item) => (
                    <li key={item} className="flex gap-2 text-sm text-mist">
                      <CheckIcon className="mt-0.5 shrink-0 text-teal" />
                      {item}
                    </li>
                  ))}
                </ul>
                <Button
                  className="mt-8 w-full"
                  variant={plan.featured ? "primary" : "ghost"}
                  onClick={() => openTrial({ plan: plan.id })}
                >
                  {plan.cta}
                </Button>
              </article>
            </Reveal>
          );
        })}
      </div>
      <Reveal>
        <div className="mt-4 grid gap-4 lg:grid-cols-[1.2fr_0.8fr]">
          <div className="rounded-3xl border border-white/10 p-6">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <p className="text-[11px] uppercase tracking-[0.16em] text-copper">Team estimate</p>
                <p className="mt-1 font-serif text-3xl tabular-nums tracking-[-0.03em]">
                  ${(rate * seats).toLocaleString()}
                  <span className="text-base text-faint"> / mo</span>
                </p>
              </div>
              <p className="text-sm text-mist">{seats} engineers on Team{annual ? ` · save $${yearlySave.toLocaleString()} / year` : ""}</p>
            </div>
            <label className="mt-4 block">
              <span className="sr-only">Number of engineers</span>
              <input type="range" min={2} max={80} value={seats} onChange={(event) => setSeats(Number(event.target.value))} />
            </label>
          </div>
          <div className="flex flex-col justify-between rounded-3xl border border-white/10 bg-[radial-gradient(circle_at_top_right,rgba(126,224,200,0.12),transparent_55%)] p-6">
            <div>
              <p className="text-[11px] uppercase tracking-[0.16em] text-teal">Enterprise</p>
              <p className="mt-2 font-serif text-2xl tracking-[-0.03em]">VPC, self-host, and a named architect.</p>
              <p className="mt-2 text-sm text-mist">Custom retention, private model gateway, procurement-friendly paperwork.</p>
            </div>
            <Button variant="ghost" className="mt-5" onClick={() => openTrial({ plan: "Enterprise" })}>
              Talk to us
            </Button>
          </div>
        </div>
      </Reveal>
      <div className="mt-6">
        <button type="button" className="text-sm text-mist hover:text-paper" aria-expanded={compare} onClick={() => setCompare((value) => !value)}>
          {compare ? "Hide comparison" : "Compare every seat"}
        </button>
        {compare ? (
          <div className="mt-4 overflow-x-auto rounded-3xl border border-white/10">
            <table className="w-full min-w-[640px] text-left text-sm">
              <caption className="sr-only">Plan comparison</caption>
              <thead className="text-faint">
                <tr className="border-b border-white/10">
                  <th className="px-4 py-3 font-medium">Capability</th>
                  <th className="px-4 py-3 font-medium">Starter</th>
                  <th className="px-4 py-3 font-medium text-paper">Pro</th>
                  <th className="px-4 py-3 font-medium">Team</th>
                </tr>
              </thead>
              <tbody>
                {comparison.map((row) => (
                  <tr key={row.name} className="border-b border-white/8 last:border-0">
                    <th className="px-4 py-3 font-normal text-mist">{row.name}</th>
                    <td className="px-4 py-3">{row.starter}</td>
                    <td className="px-4 py-3 text-paper">{row.pro}</td>
                    <td className="px-4 py-3">{row.team}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}
        <button type="button" onClick={() => openPage("security")} className="mt-4 block text-xs text-faint hover:text-paper">
          Security, SSO, and the no-training promise →
        </button>
      </div>
    </section>
  );
}

export function FAQ() {
  const { openTrial, openDemo } = useApp();
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState<number | null>(0);
  const needle = query.trim().toLowerCase();
  const filtered = faqs
    .map((item, index) => ({ ...item, index }))
    .filter((item) => !needle || `${item.q} ${item.a}`.toLowerCase().includes(needle));

  return (
    <section id="faq" className="scroll-mt-24 border-t border-white/10 py-24 sm:py-32" aria-labelledby="faq-title">
      <div className="mx-auto grid max-w-[1180px] gap-10 px-5 sm:px-8 lg:grid-cols-[0.8fr_1.2fr]">
        <div className="lg:sticky lg:top-28 lg:self-start">
          <Eyebrow>FAQ</Eyebrow>
          <h2 id="faq-title" className="font-serif text-[clamp(2.3rem,4vw,3.5rem)] leading-[1.02] tracking-[-0.035em]">
            Straight answers, before you connect a repo.
          </h2>
          <p className="mt-4 text-mist">If the policy question isn’t here, ask it on the trial form. A human reads those.</p>
          <label className="mt-6 block">
            <span className="sr-only">Search questions</span>
            <input
              className="input"
              placeholder="Search — training, SSO, trial…"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
            />
          </label>
          <button type="button" onClick={openDemo} className="mt-4 text-sm text-copper">
            Prefer to see it? Take the tour.
          </button>
        </div>
        <div>
          {filtered.length === 0 ? (
            <div className="rounded-3xl border border-white/10 p-6">
              <p className="text-paper">Nothing matches “{query}”.</p>
              <p className="mt-2 text-sm text-mist">Send it with the trial request and we’ll answer before you index anything.</p>
              <Button className="mt-4" onClick={() => openTrial({ plan: "Enterprise" })}>
                Ask us
              </Button>
            </div>
          ) : (
            <div className="divide-y divide-white/10 border-y border-white/10">
              {filtered.map((item) => {
                const expanded = needle ? true : open === item.index;
                return (
                  <div key={item.q}>
                    <h3>
                      <button
                        type="button"
                        className="flex w-full items-center justify-between gap-4 py-5 text-left"
                        aria-expanded={expanded}
                        onClick={() => setOpen(expanded && !needle ? null : item.index)}
                      >
                        <span className="text-base font-medium tracking-[-0.02em] sm:text-lg">{item.q}</span>
                        <span className={cn("text-copper transition", expanded && "rotate-45")} aria-hidden="true">
                          +
                        </span>
                      </button>
                    </h3>
                    <div className={cn("grid transition-[grid-template-rows] duration-300", expanded ? "grid-rows-[1fr]" : "grid-rows-[0fr]")}>
                      <div className="overflow-hidden">
                        <p className="max-w-2xl pb-5 text-sm leading-relaxed text-mist">{item.a}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

export function FinalCta() {
  const { openTrial } = useApp();
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (!isEmail(email)) {
      setError("Enter a work email to start.");
      return;
    }
    openTrial({ email, plan: "Team" });
  }

  return (
    <section id="cta" className="scroll-mt-24 px-5 pb-24 sm:px-8" aria-labelledby="cta-title">
      <div className="relative mx-auto max-w-[1180px] overflow-hidden rounded-[2rem] border border-white/10 bg-ink-2 px-6 py-16 sm:px-12 sm:py-20">
        <div className="pointer-events-none absolute -left-10 top-0 size-72 rounded-full bg-copper/20 blur-3xl" />
        <div className="pointer-events-none absolute -right-10 bottom-0 size-72 rounded-full bg-teal/15 blur-3xl" />
        <div className="relative mx-auto max-w-3xl text-center">
          <Eyebrow>Start this week</Eyebrow>
          <h2 id="cta-title" className="font-serif text-[clamp(2.6rem,5vw,4.4rem)] leading-[0.98] tracking-[-0.04em]">
            Your morning shouldn’t start with archaeology.
          </h2>
          <p className="mx-auto mt-5 max-w-xl text-mist">
            Fourteen days of Team. Bring a repo. Leave with a teammate who already read it — and a review that didn’t wait for sunrise.
          </p>
          <form className="mx-auto mt-8 flex max-w-xl flex-col gap-2 sm:flex-row" noValidate onSubmit={onSubmit}>
            <label htmlFor="cta-email" className="sr-only">
              Work email
            </label>
            <input
              id="cta-email"
              type="email"
              autoComplete="email"
              placeholder="you@company.com"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              aria-invalid={error ? true : undefined}
              aria-describedby={error ? "cta-error" : undefined}
              className="input h-12 sm:flex-1"
            />
            <Button type="submit" size="lg">
              Start free trial <ArrowIcon />
            </Button>
          </form>
          {error ? (
            <p id="cta-error" className="mt-2 text-sm text-copper" role="alert">
              {error}
            </p>
          ) : null}
          <ol className="mx-auto mt-10 grid max-w-3xl gap-4 text-left sm:grid-cols-3">
            {[
              ["01", "Connect a repo", "Two minutes. GitHub, GitLab, or Bitbucket."],
              ["02", "Ask why", "Get the ADR, the incident, and the file — cited."],
              ["03", "Accept or send it back", "A human still merges. Preferences stay in the repo."],
            ].map(([n, title, body]) => (
              <li key={n} className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
                <p className="font-serif text-copper">{n}</p>
                <p className="mt-2 text-sm font-medium">{title}</p>
                <p className="mt-1 text-xs leading-relaxed text-mist">{body}</p>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}

const footerColumns: { title: string; links: { label: string; href?: string; page?: Parameters<ReturnType<typeof useApp>["openPage"]>[0] }[] }[] = [
  {
    title: "Product",
    links: [
      { label: "Composer", href: "#showcase" },
      { label: "Review", href: "#showcase" },
      { label: "Pulse", href: "#showcase" },
      { label: "Memory", href: "#showcase" },
      { label: "Pricing", href: "#pricing" },
      { label: "Changelog", page: "changelog" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About", page: "about" },
      { label: "Customers", page: "customers" },
      { label: "Careers", page: "careers" },
      { label: "Press", page: "press" },
      { label: "Security", page: "security" },
    ],
  },
  {
    title: "Resources",
    links: [
      { label: "Docs", page: "docs" },
      { label: "Journal", page: "blog" },
      { label: "Status", page: "status" },
      { label: "Privacy", page: "privacy" },
      { label: "Terms", page: "terms" },
      { label: "DPA", page: "dpa" },
    ],
  },
];

export function Footer() {
  const { openPage, openTrial, setShowcase } = useApp();
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (!isEmail(email)) {
      setError("That doesn’t look like an email.");
      return;
    }
    setError("");
    setDone(true);
  }

  const productTabs: Record<string, TabId> = {
    Composer: "composer",
    Review: "review",
    Pulse: "pulse",
    Memory: "memory",
  };

  return (
    <footer id="footer" className="border-t border-white/10 px-5 py-16 sm:px-8">
      <div className="mx-auto grid max-w-[1180px] gap-12 lg:grid-cols-[1.2fr_2fr]">
        <div>
          <Logo />
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-mist">
            The AI workspace for remote software teams. Context that travels with the code.
          </p>
          <button type="button" onClick={() => openPage("status")} className="mt-5 inline-flex items-center gap-2 text-sm text-mist hover:text-paper">
            <span className="size-1.5 rounded-full bg-teal" />
            All systems operational
          </button>
          <form className="mt-6 max-w-sm" noValidate onSubmit={onSubmit}>
            <p className="text-xs uppercase tracking-[0.16em] text-faint">Engineering brief</p>
            {done ? (
              <p className="mt-2 text-sm text-paper" role="status">
                You’re on the list. One letter a month, written like an ADR.
              </p>
            ) : (
              <div className="mt-2 flex gap-2">
                <label htmlFor="brief-email" className="sr-only">
                  Email for the engineering brief
                </label>
                <input
                  id="brief-email"
                  type="email"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  placeholder="you@company.com"
                  className="input"
                  aria-invalid={error ? true : undefined}
                />
                <Button type="submit" variant="ghost">
                  Join
                </Button>
              </div>
            )}
            {error ? <p className="mt-1 text-xs text-copper">{error}</p> : null}
          </form>
        </div>
        <div className="grid grid-cols-2 gap-8 sm:grid-cols-3">
          {footerColumns.map((column) => (
            <div key={column.title}>
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-faint">{column.title}</p>
              <ul className="mt-4 space-y-2.5">
                {column.links.map((link) => (
                  <li key={link.label}>
                    {link.page ? (
                      <button type="button" className="text-sm text-mist hover:text-paper" onClick={() => openPage(link.page!)}>
                        {link.label}
                      </button>
                    ) : (
                      <a
                        href={link.href}
                        className="text-sm text-mist hover:text-paper"
                        onClick={() => {
                          const tab = productTabs[link.label];
                          if (tab) setShowcase(tab);
                        }}
                      >
                        {link.label}
                      </a>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
      <div className="mx-auto mt-12 flex max-w-[1180px] flex-col gap-3 border-t border-white/10 pt-6 text-xs text-faint sm:flex-row sm:items-center sm:justify-between">
        <p>© {new Date().getFullYear()} Nexus Labs. All rights reserved.</p>
        <p>
          Press <kbd className="rounded border border-white/15 px-1 font-mono">T</kbd> to start a trial ·{" "}
          <button type="button" className="hover:text-paper" onClick={() => openTrial()}>
            or just begin
          </button>
        </p>
      </div>
    </footer>
  );
}

export function MobileTrialBar() {
  const { openTrial, overlay, menuOpen } = useApp();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const hero = document.getElementById("hero");
    const cta = document.getElementById("cta");
    const footer = document.getElementById("footer");
    if (!hero) return;
    const state = { hero: true, cta: false, footer: false };
    const observer = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        if (entry.target.id === "hero") state.hero = entry.isIntersecting;
        if (entry.target.id === "cta") state.cta = entry.isIntersecting;
        if (entry.target.id === "footer") state.footer = entry.isIntersecting;
      }
      setVisible(!state.hero && !state.cta && !state.footer);
    });
    [hero, cta, footer].forEach((node) => node && observer.observe(node));
    return () => observer.disconnect();
  }, []);

  if (overlay || menuOpen) return null;

  return (
    <div
      className={cn(
        "fixed inset-x-0 bottom-0 z-40 border-t border-white/10 bg-ink/85 p-3 backdrop-blur-xl transition-transform duration-300 sm:hidden",
        visible ? "translate-y-0" : "translate-y-full",
      )}
      style={{ paddingBottom: "max(0.75rem, env(safe-area-inset-bottom))" }}
    >
      <Button className="w-full" onClick={() => openTrial({ plan: "Team" })}>
        Start free trial
      </Button>
    </div>
  );
}

export function SkipLink() {
  return (
    <a
      href="#main"
      className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[80] focus:rounded-full focus:bg-paper focus:px-4 focus:py-2 focus:text-sm focus:text-ink"
    >
      Skip to content
    </a>
  );
}

export function Grain() {
  return <div className="grain" aria-hidden="true" />;
}
