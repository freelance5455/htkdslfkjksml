import React, { useState } from "react";
import {
  StickyNote,
  FileText,
  Network,
  BookOpen,
  Mic,
  Shield,
  Sparkles,
  Sliders,
  GripVertical,
  ChevronDown,
  ChevronRight,
  Maximize2,
  ZoomIn,
  Type,
  Layers,
  Sparkle
} from "lucide-react";
import { ProfileInterfaceConfig, NavigationConcept, ToolSortMode } from "../types";
import { InterfaceToolItem, sortInterfaceTools } from "../utils/interfaceSorting";

interface DynamicToolMenuProps {
  config: ProfileInterfaceConfig;
  tools: InterfaceToolItem[];
  activeToolId?: string;
  onSelectTool?: (toolId: string) => void;
  onUpdateConfig?: (updated: Partial<ProfileInterfaceConfig>) => void;
  onReorderTools?: (newOrder: string[]) => void;
  isPreview?: boolean;
}

export const DynamicToolMenu: React.FC<DynamicToolMenuProps> = ({
  config,
  tools,
  activeToolId = "home",
  onSelectTool,
  onUpdateConfig,
  onReorderTools,
  isPreview = false,
}) => {
  const [isDockExpanded, setIsDockExpanded] = useState(false);
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);

  // Helper icon map
  const renderToolIcon = (id: string, className: string = "w-4 h-4") => {
    switch (id) {
      case "home":
        return <StickyNote className={className} />;
      case "docs":
        return <FileText className={className} />;
      case "mindmap":
        return <Network className={className} />;
      case "study":
        return <BookOpen className={className} />;
      case "voice_memo":
        return <Mic className={className} />;
      case "vault":
        return <Shield className={className} />;
      case "ai_chat":
        return <Sparkles className={className} />;
      case "settings":
        return <Sliders className={className} />;
      default:
        return <Layers className={className} />;
    }
  };

  const sortedTools = sortInterfaceTools(tools, config.toolSortMode, config.customToolOrder);

  // Drag and Drop handlers for reordering
  const handleDragStart = (e: React.DragEvent, index: number) => {
    if (config.toolSortMode !== "drag_drop") return;
    setDraggedIndex(index);
    e.dataTransfer.effectAllowed = "move";
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    if (config.toolSortMode !== "drag_drop" || draggedIndex === null || draggedIndex === index) return;
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, targetIndex: number) => {
    if (config.toolSortMode !== "drag_drop" || draggedIndex === null || !onReorderTools) return;
    e.preventDefault();
    const newTools = [...sortedTools];
    const [draggedItem] = newTools.splice(draggedIndex, 1);
    newTools.splice(targetIndex, 0, draggedItem);
    setDraggedIndex(null);
    onReorderTools(newTools.map((t) => t.id));
  };

  // Inline Controls Slider Component
  const renderInlineControls = () => {
    if (!config.showInlineControls) return null;
    return (
      <div className="mt-2.5 p-3 rounded-2xl bg-slate-100/80 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 space-y-2.5 animate-in fade-in duration-150">
        <div className="flex items-center justify-between text-[11px] font-bold text-slate-700 dark:text-slate-300">
          <span className="flex items-center gap-1.5">
            <ZoomIn className="w-3.5 h-3.5 text-teal-500" />
            <span>Arayüz Ölçeği:</span>
          </span>
          <span className="font-mono text-teal-600 dark:text-teal-400 font-extrabold">
            {Math.round(config.inlineUiScale * 100)}%
          </span>
        </div>
        <input
          type="range"
          min="0.8"
          max="1.4"
          step="0.05"
          value={config.inlineUiScale}
          onChange={(e) => onUpdateConfig && onUpdateConfig({ inlineUiScale: parseFloat(e.target.value) })}
          className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-teal-500"
        />

        <div className="flex items-center justify-between text-[11px] font-bold text-slate-700 dark:text-slate-300 pt-1">
          <span className="flex items-center gap-1.5">
            <Type className="w-3.5 h-3.5 text-indigo-500" />
            <span>Yazı Boyutu:</span>
          </span>
          <span className="font-mono text-indigo-600 dark:text-indigo-400 font-extrabold">
            {config.inlineFontSize}px
          </span>
        </div>
        <input
          type="range"
          min="12"
          max="24"
          step="1"
          value={config.inlineFontSize}
          onChange={(e) => onUpdateConfig && onUpdateConfig({ inlineFontSize: parseInt(e.target.value, 10) })}
          className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
        />
      </div>
    );
  };

  // ---------------------------------------------------------------------------
  // CONCEPT 1: KLASİK DÜZEN (Classic Top/Bottom Navigation Bar)
  // ---------------------------------------------------------------------------
  if (config.navigationConcept === "classic") {
    return (
      <div className="w-full p-2.5 sm:p-3.5 rounded-2xl sm:rounded-3xl bg-white/90 dark:bg-slate-900/90 border border-slate-200/90 dark:border-slate-800 shadow-md backdrop-blur-md space-y-3 transition-all duration-300">
        <div className="flex items-center justify-between overflow-x-auto gap-2 pb-1 scrollbar-none">
          {sortedTools.map((tool, idx) => {
            const isSelected = activeToolId === tool.id;
            return (
              <button
                key={tool.id}
                type="button"
                draggable={config.toolSortMode === "drag_drop"}
                onDragStart={(e) => handleDragStart(e, idx)}
                onDragOver={(e) => handleDragOver(e, idx)}
                onDrop={(e) => handleDrop(e, idx)}
                onClick={() => onSelectTool && onSelectTool(tool.id)}
                className={`flex items-center gap-2 px-3 py-2 rounded-2xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                  isSelected
                    ? "bg-teal-600 text-white shadow-md ring-2 ring-teal-500/30 scale-[1.02]"
                    : "bg-slate-100 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
                }`}
              >
                {config.toolSortMode === "drag_drop" && (
                  <GripVertical className="w-3.5 h-3.5 text-slate-400 cursor-grab" />
                )}
                {renderToolIcon(tool.id, "w-4 h-4")}
                <span className="whitespace-nowrap">{tool.title}</span>
                {tool.badgeText && (
                  <span
                    className={`text-[9px] px-1.5 py-0.2 rounded-full font-black text-white ${tool.badgeColor || "bg-teal-500"}`}
                  >
                    {tool.badgeText}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Inline Controls inside classic container if enabled */}
        {renderInlineControls()}
      </div>
    );
  }

  // ---------------------------------------------------------------------------
  // CONCEPT 2: DİKEY KATEGORİ KARTLARI (Vertical Scrollable Category Cards)
  // ---------------------------------------------------------------------------
  if (config.navigationConcept === "vertical_cards") {
    return (
      <div className="w-full space-y-2.5 transition-all duration-300">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-[380px] overflow-y-auto pr-1">
          {sortedTools.map((tool, idx) => {
            const isSelected = activeToolId === tool.id;
            return (
              <div
                key={tool.id}
                draggable={config.toolSortMode === "drag_drop"}
                onDragStart={(e) => handleDragStart(e, idx)}
                onDragOver={(e) => handleDragOver(e, idx)}
                onDrop={(e) => handleDrop(e, idx)}
                onClick={() => onSelectTool && onSelectTool(tool.id)}
                className={`group p-3 sm:p-3.5 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 relative ${
                  isSelected
                    ? "bg-gradient-to-r from-teal-500/15 via-white to-indigo-500/10 dark:from-teal-950/40 dark:via-slate-900 dark:to-indigo-950/30 border-teal-500 dark:border-teal-400 shadow-sm ring-1 ring-teal-500/30"
                    : "bg-white dark:bg-slate-900 border-slate-200/90 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700"
                }`}
              >
                {config.toolSortMode === "drag_drop" && (
                  <GripVertical className="w-4 h-4 text-slate-400 mt-1 cursor-grab shrink-0" />
                )}

                {/* Thumbnail Preview option */}
                {config.showThumbnails && tool.thumbnailUrl ? (
                  <div className="w-12 h-12 rounded-xl overflow-hidden shrink-0 border border-slate-200 dark:border-slate-700 shadow-xs relative">
                    <img
                      src={tool.thumbnailUrl}
                      alt={tool.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-slate-900/30 flex items-center justify-center text-white">
                      {renderToolIcon(tool.id, "w-4 h-4")}
                    </div>
                  </div>
                ) : (
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border shadow-xs ${
                      isSelected
                        ? "bg-teal-600 text-white border-teal-500"
                        : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200/80 dark:border-slate-700"
                    }`}
                  >
                    {renderToolIcon(tool.id, "w-5 h-5")}
                  </div>
                )}

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {tool.title}
                    </h4>
                    {tool.badgeText && (
                      <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-black text-white shrink-0 ${tool.badgeColor || "bg-teal-500"}`}>
                        {tool.badgeText}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                    {tool.description}
                  </p>
                  <span className="text-[9px] font-semibold text-teal-600 dark:text-teal-400 mt-1 block">
                    {tool.groupLabel}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {renderInlineControls()}
      </div>
    );
  }

  // ---------------------------------------------------------------------------
  // CONCEPT 3: DİNAMİK YÜZEN DOK (Adaptive Floating Dock - Modular Pill)
  // ---------------------------------------------------------------------------
  if (config.navigationConcept === "adaptive_dock") {
    return (
      <div className="w-full flex flex-col items-center justify-center py-2 transition-all duration-300">
        <div
          className={`p-2 sm:p-2.5 rounded-full bg-slate-900/90 dark:bg-slate-950/95 text-white border border-slate-700 shadow-2xl backdrop-blur-xl flex items-center gap-2 transition-all duration-300 ${
            isDockExpanded ? "rounded-3xl flex-col items-stretch max-w-sm w-full p-4" : "max-w-fit"
          }`}
        >
          {/* Main Pill Dock Toggle Header */}
          <div className="flex items-center justify-between gap-3 px-2">
            <button
              type="button"
              onClick={() => setIsDockExpanded(!isDockExpanded)}
              className="flex items-center gap-2 text-xs font-black tracking-wide text-teal-400 hover:text-teal-300 transition-colors cursor-pointer"
            >
              <Sparkle className="w-4 h-4 text-teal-400 animate-pulse" />
              <span>Dinamik Yüzen Dok (Adaptive)</span>
              {isDockExpanded ? (
                <ChevronDown className="w-4 h-4" />
              ) : (
                <ChevronRight className="w-4 h-4" />
              )}
            </button>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 font-bold border border-teal-500/40">
              Draggable / Spring
            </span>
          </div>

          {/* Expanded Vertical Action List */}
          {isDockExpanded && (
            <div className="space-y-2 pt-3 border-t border-slate-800 animate-in fade-in zoom-in-95 duration-200">
              <div className="grid grid-cols-1 gap-1.5 max-h-60 overflow-y-auto pr-1">
                {sortedTools.map((tool, idx) => (
                  <button
                    key={tool.id}
                    type="button"
                    draggable={config.toolSortMode === "drag_drop"}
                    onDragStart={(e) => handleDragStart(e, idx)}
                    onDragOver={(e) => handleDragOver(e, idx)}
                    onDrop={(e) => handleDrop(e, idx)}
                    onClick={() => {
                      if (onSelectTool) onSelectTool(tool.id);
                      if (isPreview) setIsDockExpanded(false);
                    }}
                    className={`flex items-center justify-between p-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      activeToolId === tool.id
                        ? "bg-teal-600 text-white shadow-md"
                        : "bg-slate-800/80 hover:bg-slate-700/80 text-slate-200"
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      {config.toolSortMode === "drag_drop" && (
                        <GripVertical className="w-3.5 h-3.5 text-slate-400 cursor-grab" />
                      )}
                      {renderToolIcon(tool.id, "w-4 h-4 text-teal-400")}
                      <span>{tool.title}</span>
                    </div>
                    {tool.badgeText && (
                      <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-teal-500/30 text-teal-300 font-bold">
                        {tool.badgeText}
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {renderInlineControls()}
      </div>
    );
  }

  // ---------------------------------------------------------------------------
  // CONCEPT 4: SADECE İKONLAR (Minimalist Icon-Only Mode)
  // ---------------------------------------------------------------------------
  return (
    <div className="w-full space-y-3 transition-all duration-300">
      <div className="p-2 sm:p-2.5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-center gap-2 flex-wrap">
        {sortedTools.map((tool, idx) => {
          const isSelected = activeToolId === tool.id;
          return (
            <button
              key={tool.id}
              type="button"
              title={tool.title}
              draggable={config.toolSortMode === "drag_drop"}
              onDragStart={(e) => handleDragStart(e, idx)}
              onDragOver={(e) => handleDragOver(e, idx)}
              onDrop={(e) => handleDrop(e, idx)}
              onClick={() => onSelectTool && onSelectTool(tool.id)}
              className={`p-3 rounded-xl transition-all cursor-pointer relative group ${
                isSelected
                  ? "bg-teal-600 text-white shadow-md ring-2 ring-teal-500/40 scale-105"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
              }`}
            >
              {renderToolIcon(tool.id, "w-5 h-5")}
              {/* Tooltip on hover */}
              <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-slate-900 text-white text-[10px] font-bold rounded-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-20 shadow-lg">
                {tool.title}
              </span>
            </button>
          );
        })}
      </div>

      {renderInlineControls()}
    </div>
  );
};
