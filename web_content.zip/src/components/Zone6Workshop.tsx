import React, { useState } from 'react';
import { useGame } from '../context/GameContext.tsx';
import { ALL_RECIPES, MACHINE_NAMES, RECIPES_MAP } from '../data/recipes.ts';
import type { MachineType, Tier, CraftingRecipe } from '../types/game.ts';
import { getBatchCraftWaitTime } from '../utils/gameLogic.ts';
import { Factory, Sparkles, Clock, CheckCircle2, ChevronRight } from 'lucide-react';

export const Zone6Workshop: React.FC = () => {
  const {
    player,
    inventory,
    activeCraftBatches,
    startCraftBatch,
    claimCraftBatch,
  } = useGame();

  const [selectedMachine, setSelectedMachine] = useState<MachineType>('feed_mixer');
  const [tierFilter, setTierFilter] = useState<Tier | 'all'>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Batch slider modal state
  const [selectedRecipe, setSelectedRecipe] = useState<CraftingRecipe | null>(null);
  const [craftQuantity, setCraftQuantity] = useState<number>(1);

  const machineList: MachineType[] = [
    'feed_mixer',
    'fertilizer_tower',
    'bakery',
    'juice_jam',
    'dairy',
    'loom',
    'brewery',
    'perfume',
    'alchemy',
    'jewelry',
    'gourmet',
  ];

  const filteredRecipes = ALL_RECIPES.filter((r) => {
    if (r.machineId !== selectedMachine) return false;
    if (tierFilter !== 'all' && r.tier !== tierFilter) return false;
    if (searchTerm && !r.name.toLowerCase().includes(searchTerm.toLowerCase())) return false;
    return true;
  });

  const now = Date.now();

  const calculateMaxCraftable = (recipe: CraftingRecipe): number => {
    let maxUnits = 999;
    for (const inp of recipe.inputs) {
      const invItem = inventory.find((i) => i.id === inp.itemId);
      const available = invItem ? invItem.count : 0;
      const possible = Math.floor(available / inp.count);
      if (possible < maxUnits) {
        maxUnits = possible;
      }
    }
    return maxUnits === 999 ? 0 : maxUnits;
  };

  const handleOpenCraftModal = (recipe: CraftingRecipe) => {
    setSelectedRecipe(recipe);
    setCraftQuantity(1);
  };

  return (
    <div className="space-y-4">
      {/* Action Bar */}
      <div className="bg-stone-900/90 border border-stone-800 rounded-xl p-3 shadow-md space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🏭</span>
            <div>
              <h2 className="text-base font-bold text-amber-300">
                Khu 6: Xưởng Chế Biến Thủ Công & Dây Chuyền Đặc Biệt
              </h2>
              <p className="text-xs text-stone-400">
                11 Dây chuyền sản xuất • Thanh trượt chế biến hàng loạt (Giảm 10% thời gian cho mẻ từ 10 đơn vị)
              </p>
            </div>
          </div>

          {/* Active batches count */}
          <div className="text-xs text-stone-300 bg-stone-800 px-3 py-1.5 rounded-lg border border-stone-700">
            Đang sản xuất: <strong className="text-amber-400">{activeCraftBatches.length}</strong> mẻ
          </div>
        </div>

        {/* Machine Selector Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 pt-1 border-t border-stone-800 scrollbar-thin">
          {machineList.map((m) => {
            const info = MACHINE_NAMES[m];
            const isSelected = selectedMachine === m;
            return (
              <button
                key={m}
                type="button"
                onClick={() => setSelectedMachine(m)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-bold whitespace-nowrap transition ${
                  isSelected
                    ? 'bg-amber-500/20 text-amber-300 border-amber-400 shadow ring-1 ring-amber-400/50'
                    : 'bg-stone-800 text-stone-300 border-stone-700 hover:bg-stone-750'
                }`}
              >
                <span>{info.icon}</span>
                <span>{info.name}</span>
              </button>
            );
          })}
        </div>

        {/* Filters and search */}
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs pt-1 border-t border-stone-800">
          <div className="flex items-center gap-1.5">
            <span className="text-stone-400 font-semibold">Bậc:</span>
            {(['all', 1, 2, 3, 4, 5] as const).map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setTierFilter(t as any)}
                className={`px-2 py-0.5 rounded border font-semibold ${
                  tierFilter === t
                    ? 'bg-amber-400 text-stone-950 border-amber-300'
                    : 'bg-stone-800 text-stone-400 border-stone-700 hover:text-stone-200'
                }`}
              >
                {t === 'all' ? 'Tất cả' : `Bậc ${t}`}
              </button>
            ))}
          </div>

          <input
            type="text"
            placeholder="Tìm công thức chế biến..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-stone-800 border border-stone-700 rounded-lg px-2.5 py-1 text-stone-200 placeholder-stone-500 text-xs w-48"
          />
        </div>
      </div>

      {/* Active Batches Section */}
      {activeCraftBatches.length > 0 && (
        <div className="bg-stone-900 border border-amber-500/30 rounded-2xl p-3 shadow-md space-y-2">
          <h3 className="font-bold text-amber-300 text-xs flex items-center gap-1.5">
            <Factory className="w-4 h-4 text-amber-400" />
            <span>Tiến Trình Dây Chuyền Đang Chế Biến ({activeCraftBatches.length})</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
            {activeCraftBatches.map((batch) => {
              const recipe = RECIPES_MAP.get(batch.recipeId);
              if (!recipe) return null;
              const isDone = now >= batch.finishAt;
              const remSec = Math.max(0, Math.ceil((batch.finishAt - now) / 1000));

              return (
                <div
                  key={batch.id}
                  className={`bg-stone-950 p-2.5 rounded-xl border flex items-center justify-between gap-2 text-xs ${
                    isDone ? 'border-emerald-500 bg-emerald-950/20 ring-1 ring-emerald-500' : 'border-stone-800'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{recipe.icon}</span>
                    <div>
                      <div className="font-bold text-stone-200">{recipe.name}</div>
                      <div className="text-[10px] text-stone-400">
                        Số lượng: <strong className="text-amber-400">{batch.quantity} mẻ</strong>
                      </div>
                    </div>
                  </div>

                  {isDone ? (
                    <button
                      type="button"
                      onClick={() => claimCraftBatch(batch.id)}
                      className="px-3 py-1 bg-emerald-500 hover:bg-emerald-400 text-stone-950 font-black rounded-lg text-xs shadow-md ring-1 ring-emerald-300"
                    >
                      Nhận Hàng!
                    </button>
                  ) : (
                    <div className="flex items-center gap-1 text-[11px] text-stone-400 font-semibold bg-stone-800 px-2 py-1 rounded-lg">
                      <Clock className="w-3 h-3 text-amber-400" />
                      <span>{remSec}s</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Recipes Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        {filteredRecipes.map((recipe) => {
          const maxCraft = calculateMaxCraftable(recipe);
          const isLevelOk = player.level >= recipe.unlockLevel;

          return (
            <div
              key={recipe.id}
              className={`bg-stone-900 border-2 rounded-2xl p-3.5 shadow-md flex flex-col justify-between space-y-3 ${
                recipe.isSpecial ? 'border-amber-500/50 bg-gradient-to-br from-stone-900 to-amber-950/20' : 'border-stone-800'
              }`}
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="text-3xl p-1 bg-stone-800 rounded-xl border border-stone-700">
                      {recipe.icon}
                    </span>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h4 className="font-bold text-stone-100 text-xs sm:text-sm">{recipe.name}</h4>
                        <span className="text-[9px] px-1.5 py-0.2 bg-stone-800 text-amber-400 rounded border border-amber-600/40 font-bold">
                          Bậc {recipe.tier}
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-400 mt-0.5">{recipe.description}</p>
                    </div>
                  </div>
                </div>

                {/* Ingredients list */}
                <div className="mt-3 bg-stone-950/70 p-2 rounded-xl border border-stone-800/80 space-y-1 text-[11px]">
                  <div className="text-stone-400 font-semibold mb-0.5">Nguyên liệu mỗi đơn vị:</div>
                  {recipe.inputs.map((inp, idx) => {
                    const invItem = inventory.find((i) => i.id === inp.itemId);
                    const hasEnough = (invItem ? invItem.count : 0) >= inp.count;
                    return (
                      <div key={idx} className="flex items-center justify-between">
                        <span className="text-stone-300">• {inp.itemId.replace('prod_', '').replace('honey_', 'Mật ').replace('item_', '')}: {inp.count}</span>
                        <span className={hasEnough ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'}>
                          (Có: {invItem ? invItem.count : 0})
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Action Button */}
              <button
                type="button"
                disabled={!isLevelOk || maxCraft <= 0}
                onClick={() => handleOpenCraftModal(recipe)}
                className={`w-full py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 ${
                  !isLevelOk
                    ? 'bg-stone-800 text-stone-500 border border-stone-700 cursor-not-allowed'
                    : maxCraft > 0
                    ? 'bg-amber-500 hover:bg-amber-400 text-stone-950 shadow'
                    : 'bg-stone-800 text-stone-500 border border-stone-700 cursor-not-allowed'
                }`}
              >
                {!isLevelOk ? (
                  <span>Mở ở Cấp {recipe.unlockLevel}</span>
                ) : maxCraft > 0 ? (
                  <>
                    <span>Chế Biến (Tối đa: {maxCraft})</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </>
                ) : (
                  <span>Thiếu Nguyên Liệu</span>
                )}
              </button>
            </div>
          );
        })}
      </div>

      {/* Modal: Batch Crafting Slider */}
      {selectedRecipe && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-stone-900 border-2 border-stone-700 rounded-2xl max-w-sm w-full p-4 shadow-2xl space-y-3">
            <div className="flex items-center justify-between border-b border-stone-800 pb-2">
              <h3 className="font-bold text-amber-300 text-sm flex items-center gap-1.5">
                <span>🏭</span> Chế Biến Hàng Loạt
              </h3>
              <button
                type="button"
                onClick={() => setSelectedRecipe(null)}
                className="text-stone-400 hover:text-stone-100 font-bold px-2 py-0.5 rounded bg-stone-800"
              >
                ✕ Đóng
              </button>
            </div>

            {(() => {
              const maxUnits = calculateMaxCraftable(selectedRecipe);
              const waitSeconds = getBatchCraftWaitTime(selectedRecipe.craftTimeSeconds, craftQuantity);
              const discountNotice = craftQuantity >= 10 ? '✨ Đã giảm -10% thời gian chờ!' : 'Mẹo: Sản xuất từ 10 đơn vị trở lên được giảm 10% thời gian!';

              return (
                <div className="space-y-3 text-xs">
                  <div className="flex items-center gap-2 bg-stone-950 p-2.5 rounded-xl border border-stone-800">
                    <span className="text-3xl">{selectedRecipe.icon}</span>
                    <div>
                      <div className="font-bold text-stone-200">{selectedRecipe.name}</div>
                      <div className="text-[10px] text-stone-400">
                        Thời gian cơ bản: {selectedRecipe.craftTimeSeconds}s/đơn vị
                      </div>
                    </div>
                  </div>

                  {/* Quantity Slider */}
                  <div>
                    <div className="flex justify-between items-center text-stone-300 font-semibold mb-1.5">
                      <span>Chọn Số Lượng Sản Xuất:</span>
                      <strong className="text-amber-400 text-sm">{craftQuantity} / {maxUnits}</strong>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setCraftQuantity(Math.max(1, craftQuantity - 1))}
                        className="w-8 h-8 rounded-lg bg-stone-800 font-bold text-base hover:bg-stone-700 text-stone-100"
                      >
                        -
                      </button>

                      <input
                        type="range"
                        min="1"
                        max={Math.max(1, maxUnits)}
                        value={craftQuantity}
                        onChange={(e) => setCraftQuantity(parseInt(e.target.value) || 1)}
                        className="flex-1 accent-amber-500 h-2 bg-stone-800 rounded-lg cursor-pointer"
                      />

                      <button
                        type="button"
                        onClick={() => setCraftQuantity(Math.min(maxUnits, craftQuantity + 1))}
                        className="w-8 h-8 rounded-lg bg-stone-800 font-bold text-base hover:bg-stone-700 text-stone-100"
                      >
                        +
                      </button>

                      <button
                        type="button"
                        onClick={() => setCraftQuantity(maxUnits)}
                        className="px-2 py-1 text-[11px] rounded bg-amber-600 hover:bg-amber-500 font-bold text-stone-950"
                      >
                        Tối Đa
                      </button>
                    </div>
                  </div>

                  <div className="p-2 bg-stone-950 rounded-xl border border-stone-800 space-y-1">
                    <div className="flex justify-between text-stone-300">
                      <span>Tổng thời gian chế biến:</span>
                      <strong className="text-amber-400">{waitSeconds} giây</strong>
                    </div>
                    <div className="text-[10px] text-emerald-400 italic">{discountNotice}</div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2 border-t border-stone-800">
                    <button
                      type="button"
                      onClick={() => setSelectedRecipe(null)}
                      className="px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 font-semibold"
                    >
                      Hủy
                    </button>
                    <button
                      type="button"
                      disabled={maxUnits <= 0}
                      onClick={() => {
                        startCraftBatch(selectedRecipe.id, craftQuantity);
                        setSelectedRecipe(null);
                      }}
                      className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold shadow"
                    >
                      Bắt Đầu Chế Biến
                    </button>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      )}
    </div>
  );
};
