import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Award, CheckCircle2, RotateCcw, Sparkles, Trophy, ArrowRight } from 'lucide-react';
import { DisciplineConfig } from '../types/game';
import { JUDGE_QUOTES } from '../data/disciplines';

interface RecordCertificateModalProps {
  discipline: DisciplineConfig;
  score: number;
  bestScore: number;
  isNewPersonalBest: boolean;
  onRetry: () => void;
  onNextDiscipline: () => void;
  onBackToHub: () => void;
}

export const RecordCertificateModal: React.FC<RecordCertificateModalProps> = ({
  discipline,
  score,
  bestScore,
  isNewPersonalBest,
  onRetry,
  onNextDiscipline,
  onBackToHub,
}) => {
  const isWorldRecord = score >= discipline.targetScore;

  useEffect(() => {
    if (isWorldRecord) {
      // Launch celebratory gold & crimson confetti cannon bursts!
      confetti({
        particleCount: 90,
        spread: 75,
        origin: { y: 0.6 },
        colors: ['#F59E0B', '#FDE047', '#10B981', '#E11D48', '#FFFBF5'],
      });
      const timer = setTimeout(() => {
        confetti({
          particleCount: 65,
          angle: 60,
          spread: 55,
          origin: { x: 0.1, y: 0.65 },
          colors: ['#F59E0B', '#FDE047', '#10B981'],
        });
        confetti({
          particleCount: 65,
          angle: 120,
          spread: 55,
          origin: { x: 0.9, y: 0.65 },
          colors: ['#F59E0B', '#FDE047', '#E11D48'],
        });
      }, 320);
      return () => clearTimeout(timer);
    }
  }, [isWorldRecord]);

  const quoteList = isWorldRecord ? JUDGE_QUOTES.recordBroken : JUDGE_QUOTES.almostThere;
  const judgeQuote = quoteList[Math.floor(score) % quoteList.length];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-2xl guinness-certificate rounded-3xl p-6 sm:p-8 overflow-hidden">
        {/* Decorative Corner Gold Rosettes */}
        <div className="absolute top-3 left-3 w-8 h-8 border-t-4 border-l-4 border-amber-700/60 rounded-tl-lg pointer-events-none" />
        <div className="absolute top-3 right-3 w-8 h-8 border-t-4 border-r-4 border-amber-700/60 rounded-tr-lg pointer-events-none" />
        <div className="absolute bottom-3 left-3 w-8 h-8 border-b-4 border-l-4 border-amber-700/60 rounded-bl-lg pointer-events-none" />
        <div className="absolute bottom-3 right-3 w-8 h-8 border-b-4 border-r-4 border-amber-700/60 rounded-br-lg pointer-events-none" />

        {/* Header Crest */}
        <div className="flex flex-col items-center text-center border-b-2 border-amber-800/20 pb-4">
          <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-amber-900 text-amber-200 text-xs font-extrabold tracking-widest uppercase mb-2 shadow">
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            КНИГА МИРОВЫХ РЕКОРДОВ ГИННЕССА • КОТО-ДИВИЗИОН
          </div>
          <h2 className="font-display text-2xl sm:text-4xl font-black uppercase tracking-tight text-amber-950">
            {isWorldRecord ? 'ОФИЦИАЛЬНЫЙ СЕРТИФИКАТ' : 'ПРОТОКОЛ ЗАМЕРА КОТОСТИ'}
          </h2>
          <p className="text-xs sm:text-sm font-bold text-amber-900/80 mt-0.5">
            Код дисциплины: {discipline.code} • Место фиксации: Дубовый Паркет Гостиной
          </p>
        </div>

        {/* Main Certificate Body */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-5 my-5 items-center">
          {/* Portrait of Kotost with Official Seal */}
          <div className="sm:col-span-4 flex flex-col items-center">
            <div className="relative w-32 h-32 sm:w-36 sm:h-36 rounded-full p-1.5 bg-gradient-to-b from-amber-300 via-amber-500 to-amber-700 shadow-xl">
              <img
                src="/images/kotost-portrait.jpg"
                alt="Его Сферическое Величество Котость"
                className="w-full h-full object-cover rounded-full border-2 border-amber-100"
              />
              <div className="absolute -bottom-2 -right-2 w-11 h-11 rounded-full bg-amber-500 border-2 border-amber-100 flex items-center justify-center shadow-lg">
                <Award className="w-6 h-6 text-amber-950" />
              </div>
            </div>
            <span className="mt-3 text-xs font-extrabold uppercase tracking-wider text-amber-900 bg-amber-200/80 px-3 py-1 rounded-full border border-amber-400">
              Атлет: КОТОСТЬ (Шар 100%)
            </span>
          </div>

          {/* Record Details & Score Readout */}
          <div className="sm:col-span-8 flex flex-col justify-between space-y-3 text-left">
            <div className="bg-amber-950/5 rounded-2xl p-3.5 border border-amber-900/15">
              <div className="text-xs font-bold uppercase tracking-wider text-amber-800">
                Категория мирового рекорда:
              </div>
              <div className="font-display text-base sm:text-lg font-extrabold text-amber-950 leading-snug">
                «{discipline.guinnessCategory}»
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="bg-amber-500/15 rounded-2xl p-3 border-2 border-amber-600/40">
                <div className="text-xs font-extrabold uppercase text-amber-900">
                  Результат Котости:
                </div>
                <div className="font-mono-num text-2xl sm:text-3xl font-extrabold text-amber-950 mt-0.5">
                  {score} <span className="text-sm font-bold">{discipline.unit}</span>
                </div>
                {isNewPersonalBest && (
                  <div className="inline-flex items-center gap-1 text-[11px] font-extrabold text-emerald-800 bg-emerald-200/80 px-2 py-0.5 rounded-full mt-1">
                    <Sparkles className="w-3 h-3" /> Личный рекорд!
                  </div>
                )}
              </div>

              <div className="bg-slate-900/5 rounded-2xl p-3 border border-amber-900/20">
                <div className="text-xs font-bold uppercase text-amber-900/75">
                  Норматив Гиннесса:
                </div>
                <div className="font-mono-num text-xl sm:text-2xl font-extrabold text-amber-900 mt-0.5">
                  {discipline.targetScore} <span className="text-xs font-bold">{discipline.unit}</span>
                </div>
                <div className="text-[11px] font-semibold text-amber-900/70 truncate mt-1">
                  Личный топ: {bestScore} {discipline.unit}
                </div>
              </div>
            </div>

            {/* Judge Quote */}
            <p className="text-xs sm:text-sm italic font-bold text-amber-950/85 bg-amber-100/70 px-3.5 py-2 rounded-xl border-l-4 border-amber-600">
              {judgeQuote}
            </p>
          </div>
        </div>

        {/* Animated Slamming Stamp Overlay */}
        <div className="flex items-center justify-between flex-wrap gap-3 border-t-2 border-amber-800/20 pt-4">
          <div
            className={`animate-stamp inline-flex items-center gap-2 px-4 py-1.5 rounded-xl border-4 font-display font-black text-sm sm:text-base uppercase tracking-wider shadow-md ${
              isWorldRecord
                ? 'border-emerald-600 text-emerald-800 bg-emerald-100/90'
                : 'border-rose-600 text-rose-800 bg-rose-100/90'
            }`}
          >
            <CheckCircle2 className="w-5 h-5" />
            {isWorldRecord
              ? 'НОВЫЙ МИРОВОЙ РЕКОРД ПОДТВЕРЖДЁН!'
              : `ДО РЕКОРДА ОСТАЛОСЬ ${(discipline.targetScore - score).toFixed(1)} ${discipline.unit}`}
          </div>

          <div className="text-right text-[11px] font-bold text-amber-900/70">
            Главный судья: Профессор Кусь-Круглов • Печать № 777-МЯУ
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-5">
          <button
            onClick={onRetry}
            className="btn-gold-arcade py-3 px-4 rounded-2xl font-display font-extrabold text-sm uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            Улучшить Рекорд
          </button>

          <button
            onClick={onNextDiscipline}
            className="btn-crimson-arcade py-3 px-4 rounded-2xl font-display font-extrabold text-sm uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer"
          >
            Следующий Рекорд
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={onBackToHub}
            className="py-3 px-4 rounded-2xl font-display font-extrabold text-sm uppercase tracking-wider bg-amber-950 text-amber-100 hover:bg-amber-900 transition flex items-center justify-center gap-2 cursor-pointer shadow"
          >
            На 3D-Подиум
          </button>
        </div>
      </div>
    </div>
  );
};
