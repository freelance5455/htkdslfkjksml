import React, { useState } from 'react';
import { SupportedLanguage } from '../types/tiktok';
import { translations } from '../translations';
import { SAMPLE_VIDEOS, cleanTikTokUrl } from '../services/tiktokService';
import { Link2, ClipboardPaste, ArrowRight, X, AlertCircle, Loader2, Sparkles, Check } from 'lucide-react';
import { AdBanner } from './AdBanner';

interface HeroDownloaderProps {
  currentLang: SupportedLanguage;
  isLoading: boolean;
  errorMessage: string | null;
  onDownload: (url: string) => void;
  onClearError: () => void;
}

export const HeroDownloader: React.FC<HeroDownloaderProps> = ({
  currentLang,
  isLoading,
  errorMessage,
  onDownload,
  onClearError,
}) => {
  const [inputUrl, setInputUrl] = useState('');
  const [pasteSuccess, setPasteSuccess] = useState(false);
  const [pasteNotice, setPasteNotice] = useState<string | null>(null);
  const t = translations[currentLang];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputUrl.trim()) return;
    onDownload(inputUrl.trim());
  };

  const handlePaste = async () => {
    setPasteNotice(null);
    try {
      const text = await navigator.clipboard.readText();
      if (text && text.trim().length > 0) {
        const cleaned = cleanTikTokUrl(text);
        setInputUrl(cleaned || text.trim());
        setPasteSuccess(true);
        setTimeout(() => setPasteSuccess(false), 2000);
        onClearError();
      } else {
        setPasteNotice('link not copy for this app Please Again Copy link And then past hear');
      }
    } catch {
      setPasteNotice('link not copy for this app Please Again Copy link And then past hear');
    }
  };

  const handleSampleClick = (url: string) => {
    setInputUrl(url);
    onClearError();
    onDownload(url);
  };

  return (
    <section className="relative pt-10 sm:pt-16 pb-12 sm:pb-20 px-4 sm:px-6 overflow-hidden">
      {/* Decorative radial glows */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-gradient-to-r from-cyan-600/15 via-sky-500/15 to-blue-600/15 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-10 right-10 w-72 h-72 bg-blue-600/10 rounded-full blur-[90px] pointer-events-none" />

      <div className="max-w-4xl mx-auto text-center relative z-10">
        {/* Top Developer Credit Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs sm:text-sm font-bold mb-6 shadow-xl shadow-cyan-950/60 backdrop-blur-md">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-500"></span>
          </span>
          <span className="text-white font-medium">This app developer: <strong className="text-cyan-400 font-extrabold tracking-wide">Saleem Zakhme</strong></span>
        </div>

        {/* Main Headline: SL Tik Tok Videos without watermark */}
        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.15] mb-5">
          SL Tik Tok Videos <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500">
            without watermark
          </span>
        </h1>

        {/* Subtitle */}
        <p className="text-slate-300 text-sm sm:text-lg max-w-2xl mx-auto mb-8 sm:mb-10 font-normal leading-relaxed">
          Download TikTok videos in High Quality HD MP4 & MP3 Audio &bull; Developer: <span className="text-cyan-400 font-bold">Saleem Zakhme</span>
        </p>

        {/* Main Search / Downloader Bar - Highlighted & Glowing */}
        <div className="bg-slate-900/95 border-2 border-cyan-400/80 rounded-2xl p-2.5 sm:p-3 shadow-[0_0_35px_rgba(6,182,212,0.35)] ring-4 ring-cyan-500/20 hover:border-cyan-300 max-w-2xl mx-auto transition-all duration-300 backdrop-blur-xl">
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2.5">
            <div className="relative flex-1 flex items-center">
              <Link2 className="w-5 h-5 text-cyan-400 absolute left-3.5 pointer-events-none" />
              <input
                type="text"
                value={inputUrl}
                onChange={(e) => {
                  setInputUrl(e.target.value);
                  if (errorMessage) onClearError();
                  if (pasteNotice) setPasteNotice(null);
                }}
                placeholder="Past link hear"
                className="w-full bg-slate-800/90 border-2 border-cyan-500/50 hover:border-cyan-400 focus:border-cyan-400 rounded-xl pl-11 pr-24 py-3.5 sm:py-4 text-sm sm:text-base text-white placeholder-slate-300 shadow-inner focus:outline-none focus:ring-2 focus:ring-cyan-400/30 transition"
                required
              />

              {/* Clear button if text */}
              {inputUrl && (
                <button
                  type="button"
                  onClick={() => setInputUrl('')}
                  className="absolute right-20 p-1 text-slate-400 hover:text-white transition"
                  title="Clear"
                >
                  <X className="w-4 h-4" />
                </button>
              )}

              {/* Paste button */}
              <button
                type="button"
                onClick={handlePaste}
                className="absolute right-2 px-3 py-1.5 sm:py-2 rounded-lg bg-slate-800/90 hover:bg-slate-700 text-xs font-semibold text-cyan-300 border border-slate-700 hover:border-cyan-500/40 transition flex items-center gap-1.5 cursor-pointer"
                title="Paste link from clipboard"
              >
                {pasteSuccess ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Pasted!</span>
                  </>
                ) : (
                  <>
                    <ClipboardPaste className="w-3.5 h-3.5 text-cyan-400" />
                    <span>{t.pasteBtn}</span>
                  </>
                )}
              </button>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading || !inputUrl.trim()}
              className="px-7 sm:px-9 py-3.5 sm:py-4 rounded-xl bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-600 hover:from-cyan-400 hover:via-sky-400 hover:to-blue-500 text-white font-black text-base flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/30 hover:shadow-cyan-500/50 transition-all duration-200 active:scale-98 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>{t.processing}</span>
                </>
              ) : (
                <>
                  <span>{t.downloadBtn}</span>
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>
          </form>
        </div>

        {/* Google Ad Unit 1: 3882999054 */}
        <AdBanner slotId="3882999054" client="ca-app-pub-9247061906860945" className="my-5" />

        {/* Quick Sample Links - Hidden as requested */}
        <div className="mt-5 flex flex-wrap items-center justify-center gap-2 text-xs text-slate-400 hidden">
          <span className="flex items-center gap-1 font-medium text-slate-400">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> {t.quickSample}
          </span>
          {SAMPLE_VIDEOS.map((sample, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => handleSampleClick(sample.url)}
              className="px-3 py-1 rounded-full bg-slate-900/80 hover:bg-slate-800 text-cyan-300 border border-slate-700/60 hover:border-cyan-500/50 transition flex items-center gap-1 cursor-pointer"
            >
              {sample.label}
            </button>
          ))}
        </div>

        {/* Paste Notice if link is not copied */}
        {pasteNotice && (
          <div className="mt-5 max-w-xl mx-auto p-4 rounded-xl bg-amber-950/90 border-2 border-amber-500/80 text-amber-100 text-sm flex items-center justify-between gap-3 text-left shadow-2xl backdrop-blur animate-in fade-in">
            <div className="flex items-center gap-2.5">
              <AlertCircle className="w-5 h-5 text-amber-400 shrink-0" />
              <span className="font-bold text-amber-200">{pasteNotice}</span>
            </div>
            <button
              onClick={() => setPasteNotice(null)}
              className="text-amber-400 hover:text-white p-1 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Error Notification Alert */}
        {errorMessage && (
          <div className="mt-6 max-w-xl mx-auto p-4 rounded-xl bg-red-950/70 border border-red-500/50 text-red-200 text-sm flex items-start gap-3 text-left shadow-lg backdrop-blur animate-in fade-in">
            <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="font-semibold text-red-300">Download Failed</p>
              <p className="text-red-200/90 text-xs mt-0.5">{errorMessage}</p>
            </div>
            <button
              onClick={onClearError}
              className="text-red-400 hover:text-white transition p-1 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
