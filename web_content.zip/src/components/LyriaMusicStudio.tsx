import React, { useState } from 'react';
import {
  Music,
  Play,
  Pause,
  Download,
  Sparkles,
  RefreshCw,
  Sliders,
  Check,
  AlertCircle,
  Radio,
  Disc,
} from 'lucide-react';
import { generatePromptForMusic } from '../utils/scriptUtils';

interface MusicPreset {
  id: string;
  nameBn: string;
  nameEn: string;
  tag: string;
  prompt: string;
  duration: string;
  styleKey: string;
}

const MUSIC_PRESETS: MusicPreset[] = [
  {
    id: 'tech-synth',
    nameBn: 'ফিউচারিস্টিক টেক অ্যাম্বিয়েন্ট (Tech Horizon)',
    nameEn: 'Futuristic Tech Ambient',
    tag: 'Reels / Tech Intro',
    prompt: 'Inspiring modern electronic background music with futuristic ambient synth pads, clean bassline, and subtle crisp beat, perfect for a tech career video.',
    duration: '30s',
    styleKey: 'tech',
  },
  {
    id: 'dynamic-drive',
    nameBn: 'ডায়নামিক সাইবারপাঙ্ক বিট (Dynamic Drive)',
    nameEn: 'Dynamic Cyberpunk Beat',
    tag: 'Shorts / High Energy',
    prompt: 'Dynamic high-energy electronic future bass with driving rhythm, subtle arpeggiated synths, and punchy modern beat suitable for fast-paced short-form reels.',
    duration: '30s',
    styleKey: 'dynamic',
  },
  {
    id: 'lofi-focus',
    nameBn: 'ডিপ ফোকাস লো-ফাই ও পিয়ানো (Deep Focus)',
    nameEn: 'Lo-Fi Chill & Piano',
    tag: 'Educational / Study',
    prompt: 'Mellow chillhop lo-fi instrumental with gentle warm acoustic piano chords, soft vinyl crackle, and relaxing smooth beat for educational storytelling.',
    duration: '30s',
    styleKey: 'chill',
  },
  {
    id: 'cinematic-strings',
    nameBn: 'সিনেমাটিক ইন্সপায়ারিং অরকেস্ট্রাল (Cinematic Swell)',
    nameEn: 'Cinematic Orchestral',
    tag: 'Documentary / Outro',
    prompt: 'Inspiring uplifting cinematic soundtrack with clean acoustic piano, emotional string swells, and progressive hopeful climax.',
    duration: '30s',
    styleKey: 'inspiring',
  },
];

interface LyriaMusicStudioProps {
  onMusicGenerated: (audioUrl: string, title: string) => void;
}

export const LyriaMusicStudio: React.FC<LyriaMusicStudioProps> = ({
  onMusicGenerated,
}) => {
  const [selectedModel, setSelectedModel] = useState<'lyria-3-clip-preview' | 'lyria-3-pro-preview'>('lyria-3-clip-preview');
  const [selectedPreset, setSelectedPreset] = useState<string>(MUSIC_PRESETS[0].id);
  const [musicPrompt, setMusicPrompt] = useState<string>(MUSIC_PRESETS[0].prompt);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generatedAudioUrl, setGeneratedAudioUrl] = useState<string | null>(null);
  const [generatedTitle, setGeneratedTitle] = useState<string>('');
  const [lyrics, setLyrics] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isPlayingLocal, setIsPlayingLocal] = useState<boolean>(false);

  const localAudioRef = React.useRef<HTMLAudioElement | null>(null);

  const handleSelectPreset = (preset: MusicPreset) => {
    setSelectedPreset(preset.id);
    setMusicPrompt(preset.prompt);
  };

  const handleGenerateMusic = async () => {
    if (!musicPrompt.trim()) {
      setErrorMsg('মিউজিক তৈরির জন্য প্রম্পট প্রদান করুন।');
      return;
    }

    setIsGenerating(true);
    setErrorMsg(null);

    try {
      const response = await fetch('/api/music', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: musicPrompt.trim(),
          model: selectedModel,
        }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || data.message || 'Lyria music generation failed');
      }

      const audioUrl = `data:${data.mimeType || 'audio/wav'};base64,${data.audioBase64}`;
      const presetMatch = MUSIC_PRESETS.find((p) => p.id === selectedPreset);
      const title = presetMatch ? presetMatch.nameBn : 'কাস্টম Lyria মিউজিক';

      setGeneratedAudioUrl(audioUrl);
      setGeneratedTitle(title);
      setLyrics(data.lyrics || '');
      onMusicGenerated(audioUrl, title);

      if (localAudioRef.current) {
        localAudioRef.current.src = audioUrl;
      }
    } catch (err: any) {
      console.error('Lyria error:', err);
      setErrorMsg(err.message || 'মিউজিক তৈরিতে সমস্যা হয়েছে। সার্ভার স্ট্যাটাস চেক করুন।');
    } finally {
      setIsGenerating(false);
    }
  };

  const toggleLocalPlay = () => {
    const audio = localAudioRef.current;
    if (!audio || !generatedAudioUrl) return;

    if (isPlayingLocal) {
      audio.pause();
      setIsPlayingLocal(false);
    } else {
      audio.play().catch(console.error);
      setIsPlayingLocal(true);
    }
  };

  return (
    <div className="space-y-6 pb-28">
      {/* Hidden local audio element */}
      <audio
        ref={localAudioRef}
        onEnded={() => setIsPlayingLocal(false)}
        preload="auto"
      />

      {/* Header Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-cyan-950/60 via-slate-900 to-slate-900 border border-cyan-800/40 p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-mono mb-2">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              Models: lyria-3-clip-preview & lyria-3-pro-preview
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-bengali">
              Lyria ব্যাকগ্রাউন্ড মিউজিক জেনারেটর
            </h1>
            <p className="mt-1 text-sm text-slate-300 font-bengali">
              Google-এর অত্যাধুনিক মিউজিক মডেল Lyria দিয়ে আপনার ভিডিওর জন্য পারফেক্ট ব্যাকগ্রাউন্ড সাউন্ডট্র্যাক তৈরি করুন।
            </p>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs bg-slate-950/60 p-3 rounded-xl border border-slate-800">
            <Disc className="w-5 h-5 text-cyan-400 animate-spin" />
            <div>
              <p className="text-slate-400 text-[10px]">Audio Format: WAV Stream</p>
              <p className="text-cyan-300 font-bold">{selectedModel}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Error Alert */}
      {errorMsg && (
        <div className="p-4 rounded-xl bg-red-950/40 border border-red-800/80 flex items-start gap-3 text-red-200 text-sm">
          <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
          <div className="flex-1 font-bengali">
            <strong className="block text-red-300">মিউজিক তৈরিতে ত্রুটি:</strong>
            {errorMsg}
          </div>
          <button
            onClick={() => setErrorMsg(null)}
            className="text-red-400 hover:text-red-200 text-xs font-mono"
          >
            বন্ধ
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Preset Cards & Generator Controls */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-5 sm:p-6 shadow-xl">
            {/* Model Selector */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
              <div>
                <span className="text-sm font-bold text-white font-bengali block">
                  Lyria মডেল নির্বাচন করুন:
                </span>
                <span className="text-xs text-slate-400">
                  শর্ট ক্লিপ বা ফুল-লেংথ ট্র্যাক
                </span>
              </div>

              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
                <button
                  onClick={() => setSelectedModel('lyria-3-clip-preview')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono transition cursor-pointer ${
                    selectedModel === 'lyria-3-clip-preview'
                      ? 'bg-cyan-600 text-white font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  lyria-3-clip (30s)
                </button>
                <button
                  onClick={() => setSelectedModel('lyria-3-pro-preview')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono transition cursor-pointer ${
                    selectedModel === 'lyria-3-pro-preview'
                      ? 'bg-cyan-600 text-white font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  lyria-3-pro (Full Track)
                </button>
              </div>
            </div>

            {/* Prompt input */}
            <div className="mt-4 space-y-2">
              <label className="text-xs font-bengali text-slate-300 flex items-center justify-between">
                <span>মিউজিক প্রম্পট (Prompt Instructions):</span>
                <span className="text-slate-500 font-mono text-[11px]">
                  {selectedModel === 'lyria-3-clip-preview' ? 'Up to 30 Seconds' : 'Full Length Production'}
                </span>
              </label>
              <textarea
                value={musicPrompt}
                onChange={(e) => setMusicPrompt(e.target.value)}
                rows={4}
                className="w-full p-3.5 rounded-xl bg-slate-950/80 border border-slate-700/80 text-slate-100 font-sans text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 transition resize-y"
                placeholder="যেমন: Generate a 30-second modern electronic background music with inspiring synth..."
              />
            </div>

            {/* Generate Button */}
            <div className="mt-5">
              <button
                onClick={handleGenerateMusic}
                disabled={isGenerating || !musicPrompt.trim()}
                className="w-full flex items-center justify-center gap-2.5 py-3.5 px-6 rounded-xl bg-gradient-to-r from-cyan-500 via-teal-500 to-emerald-500 text-slate-950 font-bold text-base shadow-xl shadow-cyan-500/20 hover:brightness-110 active:scale-[0.99] transition disabled:opacity-50 cursor-pointer"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    <span className="font-bengali">Lyria মিউজিক তৈরি হচ্ছে (কয়েক সেকেন্ড সময় দিন)...</span>
                  </>
                ) : (
                  <>
                    <Music className="w-5 h-5 fill-slate-950" />
                    <span className="font-bengali">Lyria AI দিয়ে মিউজিক জেনারেট করুন</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Generated Audio Card */}
          {generatedAudioUrl && (
            <div className="bg-slate-900/90 rounded-2xl border border-cyan-500/40 p-5 shadow-2xl space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-cyan-400">
                  <Check className="w-5 h-5" />
                  <span className="font-bengali font-bold text-sm">
                    ব্যাকগ্রাউন্ড মিউজিক প্রস্তুত!
                  </span>
                </div>
                <span className="text-xs font-mono text-slate-400">{generatedTitle}</span>
              </div>

              {/* Player */}
              <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-950 border border-slate-800">
                <button
                  onClick={toggleLocalPlay}
                  className="w-10 h-10 rounded-xl bg-cyan-500 text-slate-950 flex items-center justify-center hover:scale-105 active:scale-95 transition cursor-pointer"
                  aria-label={isPlayingLocal ? 'Pause' : 'Play'}
                >
                  {isPlayingLocal ? <Pause className="w-5 h-5 fill-slate-950" /> : <Play className="w-5 h-5 fill-slate-950 ml-0.5" />}
                </button>

                <div className="flex-1">
                  <div className="flex items-center justify-between text-xs text-slate-300 font-mono">
                    <span>Model: {selectedModel}</span>
                    <span className="text-cyan-400">WAV Audio Track</span>
                  </div>
                  <div className="h-2 rounded-full bg-slate-800 mt-2 overflow-hidden">
                    <div
                      className={`h-full bg-cyan-500 ${isPlayingLocal ? 'animate-pulse' : ''}`}
                      style={{ width: isPlayingLocal ? '80%' : '100%' }}
                    />
                  </div>
                </div>

                <a
                  href={generatedAudioUrl}
                  download="Skill2027_Lyria_Background_Music.wav"
                  className="p-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 transition cursor-pointer"
                  title="Download WAV Music"
                  aria-label="Download WAV Music"
                >
                  <Download className="w-4 h-4" />
                </a>
              </div>

              {lyrics && (
                <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-xs text-slate-300 font-mono">
                  <span className="text-cyan-400 block font-bold mb-1">Generated Lyrics/Metadata:</span>
                  <p className="whitespace-pre-line">{lyrics}</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Right Column: Video Sound Presets */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-5 shadow-xl">
            <h3 className="text-sm font-bold text-white font-bengali flex items-center gap-2">
              <Sliders className="w-4 h-4 text-cyan-400" />
              ভিডিওর জন্য কিউরেটেড মিউজিক প্রিসেট
            </h3>

            <div className="mt-3 space-y-2.5">
              {MUSIC_PRESETS.map((preset) => {
                const isSelected = selectedPreset === preset.id;
                return (
                  <button
                    key={preset.id}
                    onClick={() => handleSelectPreset(preset)}
                    className={`w-full p-3.5 rounded-xl text-left border transition cursor-pointer ${
                      isSelected
                        ? 'bg-slate-800 border-cyan-500 text-white ring-1 ring-cyan-500/50 shadow-md shadow-cyan-950/50'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs sm:text-sm font-bengali text-slate-100">
                        {preset.nameBn}
                      </span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                        {preset.tag}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 mt-1 italic font-sans line-clamp-2">
                      "{preset.prompt}"
                    </p>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
