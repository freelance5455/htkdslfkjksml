import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Book, Collection } from '../../types';
import { CoverImage } from '../common/CoverImage';
import { EmptyState } from '../common/EmptyState';
import {
  Shuffle,
  BookOpen,
  Sparkles,
  X,
  Play,
  RotateCcw,
  Square,
  CheckCircle,
} from 'lucide-react';

interface RandomBookViewProps {
  isOpen: boolean;
  onClose: () => void;
  books: Book[];
  collections: Collection[];
  onOpenBookDetail: (book: Book) => void;
  onOpenReader: (book: Book) => void;
}

export const RandomBookView: React.FC<RandomBookViewProps> = ({
  isOpen,
  onClose,
  books,
  collections,
  onOpenBookDetail,
  onOpenReader,
}) => {
  if (!isOpen) return null;

  // Filter sources (Screen 4: Toda la biblioteca | Por leer | Género | Colección | Serie | Estado)
  const [filterSource, setFilterSource] = useState<
    'ALL' | 'POR LEER' | 'GENRE' | 'COLLECTION' | 'SERIES' | 'STATUS'
  >('ALL');
  const [selectedGenre, setSelectedGenre] = useState<string>('ALL');
  const [selectedCollection, setSelectedCollection] = useState<string>('ALL');
  const [selectedSaga, setSelectedSaga] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('POR LEER');

  // Animation State (Requirement 10: 1. Varias portadas pasan rápidamente 2. Velocidad disminuye 3. Se detiene 4. Seleccionada queda grande y destacada)
  const [isSpinning, setIsSpinning] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [hasCompletedSelection, setHasCompletedSelection] = useState(false);

  const animationTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Available options
  const allGenres = useMemo(() => {
    const set = new Set<string>();
    books.forEach((b) => b.genres?.forEach((g) => set.add(g)));
    return Array.from(set).sort();
  }, [books]);

  const allSagas = useMemo(() => {
    const set = new Set<string>();
    books.forEach((b) => {
      if (b.saga) set.add(b.saga);
    });
    return Array.from(set).sort();
  }, [books]);

  // Candidate pool according to filters
  const candidateBooks = useMemo(() => {
    return books.filter((b) => {
      if (filterSource === 'POR LEER') return b.status === 'POR LEER';
      if (filterSource === 'STATUS') return b.status === selectedStatus;
      if (filterSource === 'GENRE') return selectedGenre === 'ALL' || b.genres?.includes(selectedGenre);
      if (filterSource === 'COLLECTION') return selectedCollection === 'ALL' || b.collections?.includes(selectedCollection);
      if (filterSource === 'SERIES') return selectedSaga === 'ALL' || b.saga === selectedSaga;
      return true;
    });
  }, [books, filterSource, selectedStatus, selectedGenre, selectedCollection, selectedSaga]);

  // Clean animation on unmount or candidate changes
  useEffect(() => {
    return () => {
      if (animationTimerRef.current) clearTimeout(animationTimerRef.current);
    };
  }, []);

  // Deceleration spin function (Requirement 10)
  const startRouletteSpin = () => {
    if (candidateBooks.length === 0) return;
    if (animationTimerRef.current) clearTimeout(animationTimerRef.current);

    setIsSpinning(true);
    setHasCompletedSelection(false);

    let speed = 60; // initial ms between steps (fast)
    let stepsRemaining = 18 + Math.floor(Math.random() * 8); // ~20-25 steps total

    const step = () => {
      setCurrentIndex((prev) => (prev + 1) % candidateBooks.length);
      stepsRemaining--;

      if (stepsRemaining > 0) {
        // Decelerate smoothly
        if (stepsRemaining < 10) speed += 35;
        else if (stepsRemaining < 5) speed += 70;
        else speed += 12;

        animationTimerRef.current = setTimeout(step, speed);
      } else {
        // Animation finished!
        setIsSpinning(false);
        setHasCompletedSelection(true);
      }
    };

    animationTimerRef.current = setTimeout(step, speed);
  };

  // Stop button immediately (Screen 4 in reference)
  const handleStopImmediately = () => {
    if (animationTimerRef.current) clearTimeout(animationTimerRef.current);
    setIsSpinning(false);
    setHasCompletedSelection(true);
  };

  // Trigger spin on initial open if not spun yet
  useEffect(() => {
    if (candidateBooks.length > 0 && !hasCompletedSelection && !isSpinning) {
      startRouletteSpin();
    }
  }, [candidateBooks.length]);

  const activeBook = candidateBooks[currentIndex] || candidateBooks[0] || null;
  const prevBook =
    candidateBooks.length > 1
      ? candidateBooks[(currentIndex - 1 + candidateBooks.length) % candidateBooks.length]
      : null;
  const nextBook =
    candidateBooks.length > 1
      ? candidateBooks[(currentIndex + 1) % candidateBooks.length]
      : null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-2xl animate-fadeIn">
      <div className="w-full max-w-xl glass-panel rounded-3xl p-5 sm:p-7 border border-white/15 shadow-2xl relative flex flex-col justify-between max-h-[94vh] overflow-y-auto space-y-5">
        {/* Header (Screen 4 in reference) */}
        <div className="flex items-center justify-between pb-2 border-b border-white/10">
          <div className="text-center w-full relative">
            <h2 className="text-base sm:text-lg font-bold text-white font-['Syne'] tracking-tight">
              Libro aleatorio
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              {isSpinning
                ? 'Seleccionando un libro...'
                : hasCompletedSelection
                ? '¡Lectura seleccionada para ti!'
                : 'Descubre qué leer a continuación'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-white/[0.05] hover:bg-white/15 flex items-center justify-center text-zinc-400 hover:text-white absolute right-0 top-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 3D Roulette Carousel Stage (Screen 4) */}
        {candidateBooks.length === 0 ? (
          <EmptyState
            icon={Shuffle}
            title="No hay libros con estos filtros"
            description="Prueba seleccionando 'Toda la biblioteca' o cambiando la fuente."
            actionLabel="Toda la biblioteca"
            onAction={() => setFilterSource('ALL')}
          />
        ) : (
          <div className="relative py-4 flex flex-col items-center justify-center">
            {/* Ambient Aura when selected */}
            <div
              className={`absolute w-64 h-64 rounded-full blur-3xl pointer-events-none transition-all duration-700 ${
                hasCompletedSelection
                  ? 'bg-white/10 scale-110'
                  : 'bg-white/5 scale-90'
              }`}
            />

            {/* Carousel Books Row with 3D Perspective */}
            <div className="relative flex items-center justify-center overflow-hidden w-full min-h-[300px] sm:min-h-[340px]">
              {/* Left peeking cover */}
              {prevBook && candidateBooks.length > 1 && (
                <div
                  className="w-24 sm:w-32 aspect-[2/3] shrink-0 opacity-35 scale-85 -mr-6 sm:-mr-8 z-0 filter blur-[0.5px] transition-all duration-200 pointer-events-none"
                  style={{ transform: 'perspective(400px) rotateY(18deg)' }}
                >
                  <CoverImage
                    url={prevBook.coverUrl}
                    title={prevBook.title}
                    author={prevBook.author}
                    className="rounded-xl shadow-2xl"
                  />
                </div>
              )}

              {/* Central Featured Cover */}
              {activeBook && (
                <div
                  onClick={() => {
                    if (!isSpinning) onOpenBookDetail(activeBook);
                  }}
                  className={`w-44 sm:w-52 aspect-[2/3] shrink-0 z-10 transition-all duration-300 relative select-none cursor-pointer ${
                    hasCompletedSelection
                      ? 'scale-105 ring-2 ring-white/60 shadow-[0_0_35px_rgba(255,255,255,0.2)]'
                      : 'scale-100 ring-1 ring-white/20 shadow-2xl'
                  } rounded-2xl overflow-hidden`}
                >
                  <CoverImage
                    url={activeBook.coverUrl}
                    title={activeBook.title}
                    author={activeBook.author}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}

              {/* Right peeking cover */}
              {nextBook && candidateBooks.length > 1 && (
                <div
                  className="w-24 sm:w-32 aspect-[2/3] shrink-0 opacity-35 scale-85 -ml-6 sm:-ml-8 z-0 filter blur-[0.5px] transition-all duration-200 pointer-events-none"
                  style={{ transform: 'perspective(400px) rotateY(-18deg)' }}
                >
                  <CoverImage
                    url={nextBook.coverUrl}
                    title={nextBook.title}
                    author={nextBook.author}
                    className="rounded-xl shadow-2xl"
                  />
                </div>
              )}
            </div>

            {/* Book Info underneath when selected */}
            {activeBook && (
              <div className="mt-3 text-center max-w-sm px-2 animate-fadeIn">
                <h3 className="text-base sm:text-lg font-bold text-white tracking-tight line-clamp-1">
                  {activeBook.title}
                </h3>
                <p className="text-xs text-zinc-400 line-clamp-1 mt-0.5">{activeBook.author}</p>
                {activeBook.genres && activeBook.genres.length > 0 && (
                  <span className="inline-block mt-1 px-2.5 py-0.5 rounded-full bg-white/[0.06] text-[10px] text-zinc-300 font-medium">
                    {activeBook.genres.slice(0, 2).join(' • ')}
                  </span>
                )}
              </div>
            )}
          </div>
        )}

        {/* Filter Source Pills (Screen 4 in reference: Toda la biblioteca | Por leer | Género | Colección | Serie | Estado) */}
        <div className="space-y-2 pt-2 border-t border-white/10 text-xs">
          <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block">
            Fuente
          </span>

          <div className="flex items-center gap-1.5 flex-wrap">
            {[
              { id: 'ALL', label: 'Toda la biblioteca' },
              { id: 'POR LEER', label: 'Por leer' },
              { id: 'GENRE', label: 'Género' },
              { id: 'COLLECTION', label: 'Colección' },
              { id: 'SERIES', label: 'Serie' },
              { id: 'STATUS', label: 'Estado' },
            ].map((pill) => {
              const isActive = filterSource === pill.id;
              return (
                <button
                  key={pill.id}
                  onClick={() => {
                    setFilterSource(pill.id as any);
                    setTimeout(() => startRouletteSpin(), 50);
                  }}
                  className={`px-3 py-1.5 rounded-xl font-medium transition-all ${
                    isActive
                      ? 'bg-white/15 text-white border border-white/20 shadow-sm'
                      : 'bg-white/[0.03] text-zinc-400 hover:text-white border border-white/[0.05]'
                  }`}
                >
                  {pill.label}
                </button>
              );
            })}
          </div>

          {/* Sub-selectors for Genre, Collection, Series, Status */}
          {filterSource === 'GENRE' && allGenres.length > 0 && (
            <select
              value={selectedGenre}
              onChange={(e) => {
                setSelectedGenre(e.target.value);
                setTimeout(() => startRouletteSpin(), 50);
              }}
              className="w-full bg-zinc-900 border border-white/15 rounded-xl px-3 py-1.5 text-white text-xs mt-1.5"
            >
              <option value="ALL">Cualquier género</option>
              {allGenres.map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </select>
          )}

          {filterSource === 'COLLECTION' && collections.length > 0 && (
            <select
              value={selectedCollection}
              onChange={(e) => {
                setSelectedCollection(e.target.value);
                setTimeout(() => startRouletteSpin(), 50);
              }}
              className="w-full bg-zinc-900 border border-white/15 rounded-xl px-3 py-1.5 text-white text-xs mt-1.5"
            >
              <option value="ALL">Cualquier colección</option>
              {collections.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          )}

          {filterSource === 'SERIES' && allSagas.length > 0 && (
            <select
              value={selectedSaga}
              onChange={(e) => {
                setSelectedSaga(e.target.value);
                setTimeout(() => startRouletteSpin(), 50);
              }}
              className="w-full bg-zinc-900 border border-white/15 rounded-xl px-3 py-1.5 text-white text-xs mt-1.5"
            >
              <option value="ALL">Cualquier saga</option>
              {allSagas.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          )}

          {filterSource === 'STATUS' && (
            <select
              value={selectedStatus}
              onChange={(e) => {
                setSelectedStatus(e.target.value);
                setTimeout(() => startRouletteSpin(), 50);
              }}
              className="w-full bg-zinc-900 border border-white/15 rounded-xl px-3 py-1.5 text-white text-xs mt-1.5"
            >
              <option value="POR LEER">Por leer</option>
              <option value="LEYENDO">Leyendo</option>
              <option value="TERMINADO">Terminado</option>
              <option value="ABANDONADO">Abandonado</option>
            </select>
          )}
        </div>

        {/* Primary Action Button (Screen 4: "Detener" during spin, or "Leer ahora" / "Girar de nuevo" when stopped) */}
        <div className="pt-2">
          {isSpinning ? (
            <button
              onClick={handleStopImmediately}
              className="w-full py-3 rounded-2xl bg-white/15 hover:bg-white/20 active:scale-[0.98] text-white font-bold text-xs flex items-center justify-center gap-2 border border-white/20 shadow-xl transition-all"
            >
              <Square className="w-4 h-4 fill-white" />
              <span>Detener</span>
            </button>
          ) : (
            <div className="flex items-center gap-2.5">
              <button
                onClick={startRouletteSpin}
                className="px-4 py-3 rounded-2xl bg-white/[0.06] hover:bg-white/15 active:scale-[0.98] text-zinc-200 text-xs font-semibold flex items-center justify-center gap-1.5 border border-white/10 transition-all"
                title="Girar de nuevo"
              >
                <RotateCcw className="w-4 h-4 text-zinc-300" />
                <span>Girar de nuevo</span>
              </button>

              {activeBook && (
                <>
                  <button
                    onClick={() => {
                      onOpenReader(activeBook);
                      onClose();
                    }}
                    className="flex-1 py-3 rounded-2xl bg-white hover:bg-zinc-200 active:scale-[0.98] text-zinc-950 font-bold text-xs shadow-lg flex items-center justify-center gap-1.5 transition-all"
                  >
                    <BookOpen className="w-4 h-4" />
                    <span>Leer ahora</span>
                  </button>
                  <button
                    onClick={() => {
                      onOpenBookDetail(activeBook);
                      onClose();
                    }}
                    className="px-4 py-3 rounded-2xl bg-white/[0.06] hover:bg-white/15 text-zinc-200 text-xs font-semibold transition-all border border-white/10"
                  >
                    Detalles
                  </button>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
