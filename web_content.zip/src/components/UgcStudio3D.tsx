import React, { useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import {
  ArrowLeft,
  Box,
  CheckCircle2,
  Circle,
  Coins,
  Copy,
  Cylinder,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';
import { AvatarConfig, CatalogItem, StudioPart, UgcSlot } from '../types/game';
import { createAvatarRig } from '../engine/avatar';

interface UgcStudio3DProps {
  creatorName: string;
  avatar: AvatarConfig;
  onPublishUgc: (item: CatalogItem) => void;
  onExit: () => void;
}

const UGC_COLORS = ['#ef4444', '#facc15', '#38bdf8', '#22c55e', '#a855f7', '#ec4899', '#f8fafc', '#18181b'];

const UGC_PRESETS: { name: string; slot: UgcSlot; parts: StudioPart[] }[] = [
  {
    name: 'Tanduk Naga Cyber',
    slot: 'head',
    parts: [
      { id: 'up-1', name: 'BandanaBase', shape: 'box', x: 0, y: 0.05, z: 0, sx: 0.94, sy: 0.16, sz: 0.94, color: '#18181b', kind: 'normal' },
      { id: 'up-2', name: 'TandukKiri', shape: 'cylinder', x: -0.34, y: 0.32, z: 0.12, sx: 0.16, sy: 0.55, sz: 0.16, rz: 24, rx: 12, color: '#ef4444', kind: 'normal' },
      { id: 'up-3', name: 'TandukKanan', shape: 'cylinder', x: 0.34, y: 0.32, z: 0.12, sx: 0.16, sy: 0.55, sz: 0.16, rz: -24, rx: 12, color: '#ef4444', kind: 'normal' },
      { id: 'up-4', name: 'PermataTengah', shape: 'sphere', x: 0, y: 0.12, z: 0.46, sx: 0.22, sy: 0.22, sz: 0.14, color: '#facc15', kind: 'normal' },
    ],
  },
  {
    name: 'Sayap Mecha Putih',
    slot: 'back',
    parts: [
      { id: 'uw-1', name: 'CorePunggung', shape: 'box', x: 0, y: 0.05, z: -0.05, sx: 0.45, sy: 0.55, sz: 0.22, color: '#18181b', kind: 'normal' },
      { id: 'uw-2', name: 'SayapKiriAtas', shape: 'box', x: -0.75, y: 0.35, z: -0.15, sx: 1.15, sy: 0.28, sz: 0.1, rz: 22, ry: 18, color: '#f8fafc', kind: 'normal' },
      { id: 'uw-3', name: 'SayapKananAtas', shape: 'box', x: 0.75, y: 0.35, z: -0.15, sx: 1.15, sy: 0.28, sz: 0.1, rz: -22, ry: -18, color: '#f8fafc', kind: 'normal' },
      { id: 'uw-4', name: 'BoosterKiri', shape: 'box', x: -0.62, y: 0.02, z: -0.15, sx: 0.85, sy: 0.22, sz: 0.1, rz: 10, ry: 15, color: '#38bdf8', kind: 'normal' },
      { id: 'uw-5', name: 'BoosterKanan', shape: 'box', x: 0.62, y: 0.02, z: -0.15, sx: 0.85, sy: 0.22, sz: 0.1, rz: -10, ry: -15, color: '#38bdf8', kind: 'normal' },
    ],
  },
  {
    name: 'Tongkat Bintang Emas',
    slot: 'hand',
    parts: [
      { id: 'uh-1', name: 'GagangTongkat', shape: 'cylinder', x: 0, y: 0, z: 0.42, sx: 0.1, sy: 0.1, sz: 1.1, rx: 90, color: '#18181b', kind: 'normal' },
      { id: 'uh-2', name: 'BolaBintang', shape: 'sphere', x: 0, y: 0.05, z: 0.96, sx: 0.34, sy: 0.34, sz: 0.34, color: '#facc15', kind: 'normal' },
    ],
  },
];

export const UgcStudio3D: React.FC<UgcStudio3DProps> = ({
  creatorName,
  avatar,
  onPublishUgc,
  onExit,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [slot, setSlot] = useState<UgcSlot>('head');
  const [parts, setParts] = useState<StudioPart[]>(() =>
    UGC_PRESETS[0].parts.map((p, idx) => ({ ...p, id: `ugc-${Date.now()}-${idx}` }))
  );
  const [selectedId, setSelectedId] = useState<string | null>(null);

  // Publish Modal State
  const [publishOpen, setPublishOpen] = useState(false);
  const [itemName, setItemName] = useState('');
  const [itemPrice, setItemPrice] = useState('2500');
  const [itemDesc, setItemDesc] = useState('');
  const [publishError, setPublishError] = useState<string | null>(null);

  const selectedPart = parts.find((p) => p.id === selectedId) ?? parts[0] ?? null;

  const previewAvatar = useMemo<AvatarConfig>(
    () => ({
      ...avatar,
      ugcAttachment: {
        id: 'preview-ugc',
        name: itemName || 'Karya UGC',
        slot,
        parts,
      },
    }),
    [avatar, slot, parts, itemName]
  );

  const rigRef = useRef<ReturnType<typeof createAvatarRig> | null>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(container.clientWidth || 640, container.clientHeight || 420);
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#18181b');
    const pmrem = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envTarget = pmrem.fromScene(roomEnv, 0.04);
    scene.environment = envTarget.texture;
    roomEnv.dispose();
    pmrem.dispose();

    const camera = new THREE.PerspectiveCamera(
      48,
      (container.clientWidth || 640) / (container.clientHeight || 420),
      0.1,
      100
    );
    camera.position.set(2.4, 2.5, 4.2);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.target.set(0, 1.85, 0);

    const hemi = new THREE.HemisphereLight(0xffffff, 0x27272a, 0.95);
    const key = new THREE.DirectionalLight(0xfff7ed, 1.5);
    key.position.set(5, 8, 6);
    scene.add(hemi, key);

    const pedestal = new THREE.Mesh(
      new THREE.CylinderGeometry(1.3, 1.4, 0.2, 32),
      new THREE.MeshStandardMaterial({ color: '#27272a', roughness: 0.4, metalness: 0.3 })
    );
    pedestal.position.y = -0.1;
    scene.add(pedestal);

    const grid = new THREE.GridHelper(12, 12, 0x3f3f46, 0x27272a);
    grid.position.y = -0.2;
    scene.add(grid);

    const rig = createAvatarRig(previewAvatar, creatorName);
    rigRef.current = rig;
    scene.add(rig.root);

    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth || 640;
      const h = container.clientHeight || 420;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    const clock = new THREE.Clock();
    let frameId = 0;
    let disposed = false;

    const animate = () => {
      if (disposed) return;
      const dt = Math.min(clock.getDelta(), 0.05);
      rig.updateAnimation(dt, 0, true, 0, 'default', 'default', null, 0, 'default');
      controls.update();
      renderer.render(scene, camera);
      frameId = requestAnimationFrame(animate);
    };
    animate();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      window.removeEventListener('resize', onResize);
      controls.dispose();
      rig.dispose();
      rigRef.current = null;
      pedestal.geometry.dispose();
      (pedestal.material as THREE.Material).dispose();
      envTarget.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [creatorName]);

  useEffect(() => {
    rigRef.current?.updateAppearance(previewAvatar);
  }, [previewAvatar]);

  const addShape = (shape: 'box' | 'cylinder' | 'sphere') => {
    const np: StudioPart = {
      id: `ugc-${Date.now()}-${Math.floor(Math.random() * 99)}`,
      name: `${shape === 'box' ? 'Kotak' : shape === 'cylinder' ? 'Tabung' : 'Bola'}_${parts.length + 1}`,
      shape,
      x: 0,
      y: slot === 'head' ? 0.15 : 0,
      z: slot === 'hand' ? 0.35 : 0,
      sx: 0.38,
      sy: 0.38,
      sz: 0.38,
      rx: 0,
      ry: 0,
      rz: 0,
      color: UGC_COLORS[parts.length % UGC_COLORS.length],
      kind: 'normal',
    };
    setParts((prev) => [...prev, np]);
    setSelectedId(np.id);
  };

  const updateSelected = (patch: Partial<StudioPart>) => {
    if (!selectedPart) return;
    setParts((prev) => prev.map((p) => (p.id === selectedPart.id ? { ...p, ...patch } : p)));
  };

  const duplicateSelected = () => {
    if (!selectedPart) return;
    const copy: StudioPart = {
      ...selectedPart,
      id: `ugc-${Date.now()}`,
      name: `${selectedPart.name}_copy`,
      x: +(selectedPart.x + 0.25).toFixed(2),
    };
    setParts((prev) => [...prev, copy]);
    setSelectedId(copy.id);
  };

  const deleteSelected = () => {
    if (!selectedPart || parts.length <= 1) return;
    const rest = parts.filter((p) => p.id !== selectedPart.id);
    setParts(rest);
    setSelectedId(rest[0]?.id ?? null);
  };

  const applyPreset = (preset: (typeof UGC_PRESETS)[number]) => {
    setSlot(preset.slot);
    const cloned = preset.parts.map((p, idx) => ({ ...p, id: `ugc-${Date.now()}-${idx}` }));
    setParts(cloned);
    setSelectedId(cloned[0]?.id ?? null);
  };

  const handleConfirmPublish = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = itemName.trim();
    const numericPrice = Math.round(Number(itemPrice));
    if (cleanName.length < 3) {
      setPublishError('Nama UGC minimal 3 karakter.');
      return;
    }
    if (!Number.isFinite(numericPrice) || numericPrice < 100 || numericPrice > 100000) {
      setPublishError('Harga harus antara 100 sampai 100.000 Slapbux.');
      return;
    }
    if (parts.length === 0) {
      setPublishError('Tambahkan minimal 1 bentuk 3D UGC.');
      return;
    }

    const ugcId = `ugc-item-${Date.now()}`;
    const attachment = {
      id: ugcId,
      name: cleanName,
      slot,
      parts: parts.map((p) => ({ ...p })),
    };

    const newCatalogItem: CatalogItem = {
      id: ugcId,
      name: cleanName,
      creator: creatorName,
      verified: true,
      price: numericPrice,
      category: 'ugc',
      letter: cleanName.slice(0, 2).toUpperCase(),
      accentColor: parts[0]?.color || '#38bdf8',
      badgeText: 'UGC KREATOR',
      description: itemDesc.trim() || `Item UGC buatan ${creatorName}`,
      applyPatch: { ugcAttachment: attachment },
      ugcAttachment: attachment,
      tradable: true,
    };

    onPublishUgc(newCatalogItem);
    setPublishOpen(false);
    setPublishError(null);
  };

  return (
    <div className="h-screen w-screen flex flex-col bg-[#09090b] text-zinc-100 overflow-hidden select-none">
      {/* Top Bar strictly for UGC Studio */}
      <header className="h-14 px-4 bg-black border-b border-zinc-800 flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onExit}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-900 border border-zinc-700 hover:bg-zinc-800 text-xs font-semibold text-white cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            Kembali
          </button>
          <div>
            <div className="font-display text-sm font-black tracking-tight text-white">
              SLAPBOX UGC STUDIO
            </div>
            <div className="text-[11px] text-zinc-400">
              Buat & Jual Aksesori Avatar 3D · Kreator: <strong className="text-white">{creatorName}</strong>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={() => {
            setPublishError(null);
            setPublishOpen(true);
          }}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white hover:bg-zinc-200 text-xs font-bold text-black cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5" />
          Publish & Jual UGC
        </button>
      </header>

      <div className="flex-1 min-h-0 flex flex-col md:flex-row">
        {/* Left: UGC Builder Tools */}
        <aside className="w-full md:w-64 bg-[#111113] border-b md:border-b-0 md:border-r border-zinc-800 p-3.5 space-y-4 overflow-y-auto shrink-0">
          <div>
            <div className="text-xs font-bold text-zinc-300 mb-2">1. Slot Pemakaian UGC</div>
            <div className="grid grid-cols-3 md:grid-cols-1 gap-1.5">
              {([
                { id: 'head', label: 'Kepala / Topi' },
                { id: 'back', label: 'Belakang / Sayap' },
                { id: 'hand', label: 'Tangan / Senjata' },
              ] as const).map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setSlot(s.id)}
                  className={`px-3 py-2 rounded-lg text-xs font-semibold text-left cursor-pointer border ${
                    slot === s.id
                      ? 'bg-white text-black border-white font-bold'
                      : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:bg-zinc-800'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="text-xs font-bold text-zinc-300 mb-2">2. Tambah Bentuk 3D</div>
            <div className="grid grid-cols-3 gap-1.5">
              <button
                type="button"
                onClick={() => addShape('box')}
                className="flex flex-col items-center gap-1 py-2.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-[11px] font-semibold cursor-pointer"
              >
                <Box className="w-4 h-4 text-sky-400" />
                Kotak
              </button>
              <button
                type="button"
                onClick={() => addShape('cylinder')}
                className="flex flex-col items-center gap-1 py-2.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-[11px] font-semibold cursor-pointer"
              >
                <Cylinder className="w-4 h-4 text-emerald-400" />
                Tabung
              </button>
              <button
                type="button"
                onClick={() => addShape('sphere')}
                className="flex flex-col items-center gap-1 py-2.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-[11px] font-semibold cursor-pointer"
              >
                <Circle className="w-4 h-4 text-amber-400" />
                Bola
              </button>
            </div>
          </div>

          <div>
            <div className="text-xs font-bold text-zinc-300 mb-2">3. Template UGC Cepat</div>
            <div className="space-y-1.5">
              {UGC_PRESETS.map((pr) => (
                <button
                  key={pr.name}
                  type="button"
                  onClick={() => applyPreset(pr)}
                  className="w-full px-3 py-2 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs font-semibold text-left text-zinc-200 cursor-pointer"
                >
                  {pr.name}
                </button>
              ))}
            </div>
          </div>
        </aside>

        {/* Center 3D Avatar Preview with Live UGC */}
        <div className="flex-1 min-h-[260px] relative">
          <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
          <div className="pointer-events-none absolute bottom-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-black/75 border border-white/15 text-[11px] text-zinc-300 whitespace-nowrap">
            Seret untuk memutar avatar · Perubahan UGC langsung tampil di avatar
          </div>
        </div>

        {/* Right: Part List & Transform Properties */}
        <aside className="w-full md:w-72 bg-[#111113] border-t md:border-t-0 md:border-l border-zinc-800 p-3.5 space-y-4 overflow-y-auto shrink-0">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-zinc-300">Bagian UGC ({parts.length})</span>
              <div className="flex gap-1">
                <button
                  type="button"
                  onClick={duplicateSelected}
                  disabled={!selectedPart}
                  title="Duplikat"
                  className="p-1.5 rounded bg-zinc-900 border border-zinc-700 text-zinc-300 hover:text-white disabled:opacity-40 cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={deleteSelected}
                  disabled={!selectedPart || parts.length <= 1}
                  title="Hapus"
                  className="p-1.5 rounded bg-zinc-900 border border-zinc-700 text-rose-400 hover:text-rose-300 disabled:opacity-40 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {parts.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setSelectedId(p.id)}
                  className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs font-medium cursor-pointer ${
                    selectedPart?.id === p.id
                      ? 'bg-white text-black font-bold'
                      : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-800'
                  }`}
                >
                  <span className="truncate">{p.name}</span>
                  <span
                    style={{ backgroundColor: p.color }}
                    className="w-3.5 h-3.5 rounded-full border border-black/30 shrink-0"
                  />
                </button>
              ))}
            </div>
          </div>

          {selectedPart && (
            <div className="space-y-3 border-t border-zinc-800 pt-3">
              <div>
                <label className="block text-[11px] font-semibold text-zinc-400 mb-1">Warna Bagian</label>
                <div className="flex flex-wrap gap-1.5">
                  {UGC_COLORS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => updateSelected({ color: c })}
                      style={{ backgroundColor: c }}
                      className={`w-6 h-6 rounded-md border border-zinc-600 cursor-pointer ${
                        selectedPart.color === c ? 'ring-2 ring-white scale-110' : ''
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div>
                <div className="text-[11px] font-semibold text-zinc-400 mb-1">Posisi (X / Y / Z)</div>
                <div className="space-y-1.5">
                  {(['x', 'y', 'z'] as const).map((axis) => (
                    <div key={axis} className="flex items-center gap-2 text-[11px]">
                      <span className="w-4 uppercase font-bold text-zinc-400">{axis}</span>
                      <input
                        type="range"
                        min={-1.6}
                        max={1.6}
                        step={0.05}
                        value={selectedPart[axis]}
                        onChange={(e) => updateSelected({ [axis]: Number(e.target.value) })}
                        className="flex-1 accent-white cursor-pointer"
                      />
                      <span className="w-10 text-right font-mono-num text-zinc-300">
                        {selectedPart[axis].toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-[11px] font-semibold text-zinc-400 mb-1">Ukuran (Lebar / Tinggi / Tebal)</div>
                <div className="space-y-1.5">
                  {(['sx', 'sy', 'sz'] as const).map((axis, idx) => (
                    <div key={axis} className="flex items-center gap-2 text-[11px]">
                      <span className="w-4 font-bold text-zinc-400">{['W', 'H', 'D'][idx]}</span>
                      <input
                        type="range"
                        min={0.08}
                        max={1.6}
                        step={0.04}
                        value={selectedPart[axis]}
                        onChange={(e) => updateSelected({ [axis]: Number(e.target.value) })}
                        className="flex-1 accent-white cursor-pointer"
                      />
                      <span className="w-10 text-right font-mono-num text-zinc-300">
                        {selectedPart[axis].toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-[11px] font-semibold text-zinc-400 mb-1">Rotasi (Derajat)</div>
                <div className="space-y-1.5">
                  {(['rx', 'ry', 'rz'] as const).map((axis, idx) => (
                    <div key={axis} className="flex items-center gap-2 text-[11px]">
                      <span className="w-4 font-bold text-zinc-400">{['RX', 'RY', 'RZ'][idx]}</span>
                      <input
                        type="range"
                        min={-180}
                        max={180}
                        step={5}
                        value={selectedPart[axis] ?? 0}
                        onChange={(e) => updateSelected({ [axis]: Number(e.target.value) })}
                        className="flex-1 accent-white cursor-pointer"
                      />
                      <span className="w-10 text-right font-mono-num text-zinc-300">
                        {selectedPart[axis] ?? 0}°
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </aside>
      </div>

      {/* Publish & Jual UGC Modal */}
      {publishOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
          <form
            onSubmit={handleConfirmPublish}
            className="w-[min(440px,95vw)] rounded-2xl bg-zinc-950 border border-white/20 p-5 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-bold text-white">Publish & Jual UGC</h3>
              <button
                type="button"
                onClick={() => setPublishOpen(false)}
                className="text-zinc-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-white/10 flex items-center justify-between text-xs">
              <span className="text-zinc-400">Nama Kreator UGC</span>
              <span className="font-bold text-white">{creatorName} ✓</span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">
                Nama Item UGC <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                minLength={3}
                maxLength={36}
                value={itemName}
                onChange={(e) => setItemName(e.target.value)}
                placeholder="Contoh: Tanduk Naga Api"
                className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-white/15 text-sm text-white focus:outline-none focus:border-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">
                Harga Jual (Slapbux) <span className="text-rose-400">*</span>
              </label>
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Coins className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="number"
                    required
                    min={100}
                    max={100000}
                    step={50}
                    value={itemPrice}
                    onChange={(e) => setItemPrice(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-zinc-900 border border-white/15 text-sm text-white font-mono-num focus:outline-none focus:border-white"
                  />
                </div>
              </div>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {[500, 1500, 2500, 5000, 10000].map((presetPrice) => (
                  <button
                    key={presetPrice}
                    type="button"
                    onClick={() => setItemPrice(String(presetPrice))}
                    className="px-2.5 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-[11px] font-mono-num text-zinc-200 cursor-pointer"
                  >
                    {presetPrice.toLocaleString('id-ID')}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1">Deskripsi UGC</label>
              <textarea
                rows={2}
                value={itemDesc}
                onChange={(e) => setItemDesc(e.target.value)}
                placeholder="Jelaskan keunikan item UGC buatanmu..."
                className="w-full px-3.5 py-2 rounded-xl bg-zinc-900 border border-white/15 text-xs text-white focus:outline-none focus:border-white resize-none"
              />
            </div>

            {publishError && (
              <div className="px-3 py-2 rounded-xl bg-rose-500/15 border border-rose-400/40 text-xs text-rose-200">
                {publishError}
              </div>
            )}

            <button
              type="submit"
              className="w-full inline-flex items-center justify-center gap-2 py-3 rounded-xl bg-white hover:bg-zinc-200 text-xs font-bold text-black cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              Publish & Jual di Avatar Marketplace
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
