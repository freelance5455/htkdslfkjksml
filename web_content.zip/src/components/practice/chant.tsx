import { Check } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import {
  allTotal,
  dayCounts,
  GOALS,
  MALA,
  MANTRAS,
  MAX_SAVED,
  mantraTotal,
  sumCounts,
  todayKey,
} from "@/lib/practice/model";
import { tapHaptic, woodClick } from "@/lib/practice/sound";
import { usePractice } from "@/lib/practice/store";
import { chip, field, primaryBtn, quietBtn } from "@/components/practice/ui";

function WoodenFish({ count, onCount }: { count: number; onCount: () => void }) {
  const [struck, setStruck] = useState(false);
  const timer = useRef(0);

  useEffect(() => () => window.clearTimeout(timer.current), []);

  function strike() {
    onCount();
    setStruck(true);
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setStruck(false), 140);
  }

  return (
    <button
      type="button"
      className={"muyu" + (struck ? " muyu-struck" : "")}
      aria-label={`木魚，點一下念一聲。目前 ${count} 聲`}
      onPointerDown={(event) => {
        if (event.button !== 0) return;
        strike();
      }}
      onKeyDown={(event) => {
        if (event.repeat) return;
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          strike();
        }
      }}
    >
      <svg viewBox="0 0 280 250" className="muyu-body" aria-hidden="true">
        <defs>
          <radialGradient id="muyuWood" cx="36%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#f3d7b4" />
            <stop offset="18%" stopColor="#d7a46a" />
            <stop offset="48%" stopColor="#a86b3c" />
            <stop offset="78%" stopColor="#6a381c" />
            <stop offset="100%" stopColor="#2e160e" />
          </radialGradient>
          <radialGradient id="muyuHead" cx="35%" cy="32%" r="70%">
            <stop offset="0%" stopColor="#f6e2c4" />
            <stop offset="45%" stopColor="#c48a4e" />
            <stop offset="100%" stopColor="#5c3018" />
          </radialGradient>
          <linearGradient id="muyuCushion" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#8a4036" />
            <stop offset="100%" stopColor="#2c1210" />
          </linearGradient>
          <filter id="muyuDrop" x="-30%" y="-30%" width="160%" height="160%">
            <feDropShadow dx="0" dy="7" stdDeviation="5" floodColor="#000" floodOpacity="0.4" />
          </filter>
        </defs>
        <ellipse cx="140" cy="228" rx="92" ry="8" fill="#000" opacity="0.3" />
        <ellipse cx="140" cy="214" rx="96" ry="18" fill="url(#muyuCushion)" />
        <ellipse cx="140" cy="206" rx="96" ry="12" fill="#9a4a3c" />
        <ellipse cx="118" cy="202" rx="36" ry="4" fill="#fff" opacity="0.12" />
        <g filter="url(#muyuDrop)">
          <ellipse cx="140" cy="148" rx="88" ry="70" fill="url(#muyuWood)" />
        </g>
        <path d="M74 112 Q140 100 204 116" fill="none" stroke="#5c3018" strokeWidth="0.7" opacity="0.3" />
        <ellipse cx="112" cy="96" rx="28" ry="10" fill="#fff" opacity="0.18" />
        <g className="muyu-mallet">
          <path d="M200 14 L156 46" stroke="#6a3c22" strokeWidth="5" strokeLinecap="round" />
          <path d="M202 12 L158 44" stroke="#c48a4e" strokeWidth="1.4" strokeLinecap="round" opacity="0.7" />
          <ellipse cx="148" cy="52" rx="15" ry="13" fill="url(#muyuHead)" />
          <ellipse cx="144" cy="48" rx="5" ry="3" fill="#fff" opacity="0.4" />
        </g>
      </svg>
    </button>
  );
}

export function Chant() {
  const today = todayKey();
  const selected = usePractice((s) => s.selectedMantra);
  const saved = usePractice((s) => s.savedMantras);
  const goal = usePractice((s) => s.dailyChantGoal);
  const woodOn = usePractice((s) => s.woodOn);
  const map = usePractice((s) => s.chantByDate);
  const addChant = usePractice((s) => s.addChant);
  const setSelected = usePractice((s) => s.setSelectedMantra);
  const addSaved = usePractice((s) => s.addSavedMantra);
  const removeSaved = usePractice((s) => s.removeSavedMantra);
  const setGoal = usePractice((s) => s.setGoal);
  const setWoodOn = usePractice((s) => s.setWoodOn);
  const [draft, setDraft] = useState("");

  const built = MANTRAS.find((item) => item.id === selected);
  const extra = saved.find((item) => item.id === selected);
  const spoken = extra?.text ?? built?.text ?? MANTRAS[0].text;
  const caption = extra ? "" : built && built.text !== built.name ? built.name : "";

  useEffect(() => {
    const known = Boolean(built || extra);
    if (!known) setSelected("amitabha");
  }, [built, extra, setSelected]);
  const mine = dayCounts(map, today)[selected] ?? 0;
  const totalToday = sumCounts(dayCounts(map, today));
  const round = mine === 0 ? 0 : mine % MALA === 0 ? MALA : mine % MALA;
  const lifetime = mantraTotal(map, selected);
  const lifeAll = allTotal(map);
  const weekKeys = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    return todayKey(d);
  });
  const weekMax = Math.max(1, ...weekKeys.map((key) => sumCounts(dayCounts(map, key))));

  function bump(n: number) {
    addChant(selected, n);
    if (n > 0 && woodOn) {
      woodClick();
      tapHaptic();
    }
  }

  return (
    <div className="rise flex flex-col gap-6">
      <div className="text-center">
        <h2 className="font-serif text-2xl leading-snug">{spoken}</h2>
        {caption ? <p className="mt-1 text-sm text-mute">{caption}</p> : null}
        <p className="mt-4 font-serif text-base leading-loose tracking-[0.2em] text-mute">
          我們在念佛
          <br />
          佛也在念我們
        </p>
      </div>

      <WoodenFish count={mine} onCount={() => bump(1)} />
      <p className="text-center text-xs tracking-wide text-mute">輕敲一下，便是一聲</p>
      <div className="text-center">
        <p className="text-sm text-mute tabular-nums">
          這一圈 {round} / {MALA}
          {mine > 0 && mine % MALA === 0 ? <span className="text-sage">　這一圈已圓</span> : null}
        </p>
        <div className="mx-auto mt-3 h-1 w-full max-w-xs overflow-hidden rounded-full bg-paper-2">
          <div
            className="h-full bg-cinnabar"
            style={{ width: `${Math.min(100, (totalToday / Math.max(goal, 1)) * 100)}%` }}
          />
        </div>
        <p className={"mt-2 text-sm " + (totalToday >= goal ? "text-sage" : "text-mute")}>
          今日合計 {totalToday.toLocaleString("zh-Hant")} / {goal.toLocaleString("zh-Hant")}
          {totalToday >= goal ? "　今日已滿" : ""}
        </p>
      </div>

      <div className="grid grid-cols-3 gap-2">
        <button type="button" className={quietBtn} onClick={() => bump(-10)} disabled={mine === 0}>
          退十聲
        </button>
        <button type="button" className={quietBtn} onClick={() => bump(-1)} disabled={mine === 0}>
          退一聲
        </button>
        <button type="button" className={quietBtn} onClick={() => bump(10)}>
          加十聲
        </button>
      </div>

      <div className="flex flex-wrap gap-2">
        {MANTRAS.map((item) => (
          <button
            key={item.id}
            type="button"
            className={chip(item.id === selected)}
            onClick={() => setSelected(item.id)}
          >
            {item.name}
          </button>
        ))}
        {saved.map((item) => (
          <button
            key={item.id}
            type="button"
            className={chip(item.id === selected)}
            onClick={() => setSelected(item.id)}
          >
            {item.text}
          </button>
        ))}
      </div>

      <section>
        <h3 className="mb-2 text-sm text-mute">
          自訂一句 · {saved.length} / {MAX_SAVED}
        </h3>
        {saved.length < MAX_SAVED ? (
          <form
            className="flex items-center gap-2"
            onSubmit={(event) => {
              event.preventDefault();
              const id = addSaved(draft);
              if (!id) return;
              setSelected(id);
              setDraft("");
            }}
          >
            <input
              className={field}
              value={draft}
              maxLength={40}
              placeholder="想念的那一句"
              onChange={(event) => setDraft(event.target.value)}
            />
            <button
              type="submit"
              aria-label="儲存這一句"
              disabled={!draft.trim()}
              className={primaryBtn + " size-12 shrink-0 px-0"}
            >
              <Check className="size-5" aria-hidden="true" />
            </button>
          </form>
        ) : (
          <p className="text-sm text-mute">四句都滿了。先拿掉一句，再添新的。</p>
        )}
        {extra ? (
          <button type="button" className={quietBtn + " mt-2"} onClick={() => removeSaved(extra.id)}>
            移去這一句
          </button>
        ) : null}
      </section>

      <section>
        <h3 className="mb-2 text-sm text-mute">每日目標</h3>
        <div className="flex flex-wrap gap-2">
          {GOALS.map((n) => (
            <button key={n} type="button" className={chip(n === goal)} onClick={() => setGoal(n)}>
              {n.toLocaleString("zh-Hant")}
            </button>
          ))}
        </div>
      </section>

      <button
        type="button"
        role="switch"
        aria-checked={woodOn}
        onClick={() => setWoodOn(!woodOn)}
        className="flex min-h-12 items-center justify-between border-y border-line py-3 text-left"
      >
        <span>木魚聲與震動</span>
        <span className={woodOn ? "text-sage" : "text-mute"}>{woodOn ? "開" : "關"}</span>
      </button>

      <section>
        <h3 className="mb-3 text-sm text-mute">近七日</h3>
        <div className="flex h-20 items-end gap-2">
          {weekKeys.map((key) => {
            const n = sumCounts(dayCounts(map, key));
            const height = n === 0 ? 4 : Math.max(12, Math.round((n / weekMax) * 100));
            const label = ["日", "一", "二", "三", "四", "五", "六"][new Date(key + "T12:00:00").getDay()];
            const isToday = key === today;
            return (
              <div key={key} className="flex h-full flex-1 flex-col items-center justify-end gap-1">
                <div className="flex h-14 w-full items-end">
                  <div
                    className={"w-full rounded-sm " + (n > 0 ? "bg-cinnabar" : "bg-line")}
                    style={{ height: `${height}%` }}
                  />
                </div>
                <span className={"text-xs " + (isToday ? "text-fg" : "text-mute")}>{label}</span>
              </div>
            );
          })}
        </div>
      </section>

      <p className="text-sm text-mute">
        此咒累計 {lifetime.toLocaleString("zh-Hant")}
        <span className="px-2">·</span>
        全部 {lifeAll.toLocaleString("zh-Hant")}
      </p>
    </div>
  );
}
