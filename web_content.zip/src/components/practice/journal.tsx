import {
  DEDICATION_PRESETS,
  EMPTY_GRATITUDE,
  VOW_PRESETS,
  gratitudeDone,
  labelOfKey,
  todayKey,
} from "@/lib/practice/model";
import { usePractice } from "@/lib/practice/store";
import { field } from "@/components/practice/ui";

export function VowPage() {
  const today = todayKey();
  const vow = usePractice((s) => s.vows[today] ?? "");
  const vows = usePractice((s) => s.vows);
  const setVow = usePractice((s) => s.setVow);
  const past = Object.keys(vows)
    .filter((date) => date !== today && (vows[date] ?? "").trim())
    .sort((a, b) => b.localeCompare(a));

  return (
    <div className="rise flex flex-col gap-8">
      <div>
        <h2 className="font-serif text-3xl">發願</h2>
        <p className="mt-2 text-mute">給今天一句方向。寫下，便留在這支手機裡。</p>
      </div>

      <section className="flex flex-col gap-3">
        {!vow.trim() ? (
          <div className="flex flex-col gap-2">
            {VOW_PRESETS.map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => setVow(today, preset)}
                className="rounded-md border border-line px-3 py-3 text-left text-sm leading-relaxed text-mute"
              >
                {preset}
              </button>
            ))}
          </div>
        ) : null}
        <textarea
          className={field + " min-h-28 resize-none font-serif text-lg leading-relaxed"}
          value={vow}
          maxLength={160}
          placeholder="或用自己的話說。"
          onChange={(event) => setVow(today, event.target.value)}
        />
        <p className="text-sm text-mute">{vow.trim() ? "已留在今天。" : "寫下即留，仍可再改。"}</p>
      </section>

      <section className="flex flex-col gap-4">
        <h3 className="font-serif text-xl">以前的發願</h3>
        {past.length === 0 ? (
          <p className="text-sm text-mute">往日的願，會留在這裡。</p>
        ) : (
          past.map((date) => (
            <article key={date} className="border-b border-line pb-4">
              <p className="text-sm text-mute">{labelOfKey(date)}</p>
              <p className="mt-2 font-serif text-lg leading-relaxed">{vows[date]}</p>
            </article>
          ))
        )}
      </section>
    </div>
  );
}

export function ThanksPage() {
  const today = todayKey();
  const gratitude = usePractice((s) => s.gratitudes[today] ?? EMPTY_GRATITUDE);
  const gratitudes = usePractice((s) => s.gratitudes);
  const setGratitude = usePractice((s) => s.setGratitude);

  const past = Object.keys(gratitudes)
    .filter((date) => date !== today)
    .filter(
      (date) =>
        gratitudeDone(gratitudes[date]) ||
        (gratitudes[date]?.dedication ?? "").trim() ||
        (gratitudes[date]?.reflection ?? "").trim(),
    )
    .sort((a, b) => b.localeCompare(a));

  function setItem(index: 0 | 1 | 2, value: string) {
    const items: [string, string, string] = [gratitude.items[0], gratitude.items[1], gratitude.items[2]];
    items[index] = value;
    setGratitude(today, { items });
  }

  return (
    <div className="rise flex flex-col gap-8">
      <div>
        <h2 className="font-serif text-3xl">感恩</h2>
        <p className="mt-2 text-mute">先記三件，再寫進今天的日記。</p>
      </div>

      <section className="flex flex-col gap-3">
        <h3 className="font-serif text-xl">今天感恩</h3>
        {(["一", "二", "三"] as const).map((mark, index) => (
          <label key={mark} className="flex flex-col gap-1">
            <span className="text-sm text-mute">{mark}</span>
            <input
              className={field}
              value={gratitude.items[index] ?? ""}
              maxLength={80}
              placeholder={index === 0 ? "今天想謝的一件事" : "還有一件"}
              onChange={(event) => setItem(index as 0 | 1 | 2, event.target.value)}
            />
          </label>
        ))}
      </section>

      <section className="flex flex-col gap-3">
        <h3 className="font-serif text-xl">感恩日記</h3>
        <textarea
          className={field + " min-h-32 resize-none font-serif text-lg leading-relaxed"}
          value={gratitude.reflection}
          maxLength={240}
          placeholder="哪一刻是好的，誰幫過我，心裡想留住什麼。"
          onChange={(event) => setGratitude(today, { reflection: event.target.value })}
        />
        <p className="text-sm text-mute">
          {gratitude.reflection.trim() ? "已寫進今天的日記。" : "可以寫長一點。只留在這支手機。"}
        </p>
        <h4 className="mt-2 text-sm text-mute">回向一句</h4>
        <div className="flex flex-col gap-2">
          {DEDICATION_PRESETS.map((preset) => (
            <button
              key={preset}
              type="button"
              onClick={() => setGratitude(today, { dedication: preset })}
              className="rounded-md border border-line px-3 py-3 text-left text-sm text-mute"
            >
              {preset}
            </button>
          ))}
        </div>
        <input
          className={field}
          value={gratitude.dedication}
          maxLength={80}
          placeholder="或寫自己的一句。"
          onChange={(event) => setGratitude(today, { dedication: event.target.value })}
        />
      </section>

      <section className="flex flex-col gap-4">
        <h3 className="font-serif text-xl">以前的日記</h3>
        {past.length === 0 ? (
          <p className="text-sm text-mute">往日的感恩，會留在這裡。今天先寫一句就好。</p>
        ) : (
          past.map((date) => {
            const g = gratitudes[date];
            const items = g?.items.filter((item) => item.trim()) ?? [];
            return (
              <article key={date} className="border-b border-line pb-4">
                <p className="text-sm text-mute">{labelOfKey(date)}</p>
                {items.length > 0 ? (
                  <ul className="mt-2 flex flex-col gap-1 text-sm">
                    {items.map((item, index) => (
                      <li key={`${date}-${index}`}>{item}</li>
                    ))}
                  </ul>
                ) : null}
                {g?.reflection.trim() ? <p className="mt-2 text-sm leading-relaxed">{g.reflection.trim()}</p> : null}
                {g?.dedication.trim() ? <p className="mt-2 text-sm text-sage">{g.dedication.trim()}</p> : null}
              </article>
            );
          })
        )}
      </section>
    </div>
  );
}
