import {
  dayPart,
  formatMinutes,
  formatNet,
  gratitudeDone,
  greeting,
  labelOfKey,
  lastDays,
  lineFor,
  netOf,
  streakOf,
  sumCounts,
  todayKey,
  type Tab,
} from "@/lib/practice/model";
import { usePractice } from "@/lib/practice/store";

const ROWS: { id: Tab; title: string; line: string }[] = [
  { id: "chant", title: "念佛", line: "一聲一聲，把心收回來" },
  { id: "abstain", title: "戒色", line: "念頭來了，不跟著走" },
  { id: "ledger", title: "功過", line: "功與過，只為看清" },
  { id: "vow", title: "發願", line: "給今天一句方向" },
  { id: "thanks", title: "感恩", line: "把被給過的記下來" },
  { id: "sit", title: "禪定", line: "坐一會兒，讓心歇一歇" },
];

export function Today({ onGo }: { onGo: (tab: Tab) => void }) {
  const today = todayKey();
  const part = dayPart();
  const greet = greeting(part);
  const chantByDate = usePractice((s) => s.chantByDate);
  const goal = usePractice((s) => s.dailyChantGoal);
  const vows = usePractice((s) => s.vows);
  const gratitudes = usePractice((s) => s.gratitudes);
  const sits = usePractice((s) => s.sits);
  const merits = usePractice((s) => s.merits);
  const abstainByDate = usePractice((s) => s.abstainByDate);

  const chant = sumCounts(chantByDate[today] ?? {});
  const todaySits = sits.filter((sit) => sit.date === today);
  const sitSeconds = todaySits.reduce((n, sit) => n + sit.seconds, 0);
  const todayMerits = merits.filter((entry) => entry.date === today);
  const kept = abstainByDate[today]?.mark;
  const vow = (vows[today] ?? "").trim();
  const thanked = gratitudeDone(gratitudes[today]) || Boolean((gratitudes[today]?.reflection ?? "").trim());
  const streak = streakOf({ chantByDate, vows, gratitudes, sits, merits, abstainByDate }, today);
  const week = lastDays(7, today);
  const weekChant = week.reduce((n, key) => n + sumCounts(chantByDate[key] ?? {}), 0);
  const weekSit = sits
    .filter((sit) => week.includes(sit.date))
    .reduce((n, sit) => n + sit.seconds, 0);
  const weekNet = netOf(merits.filter((entry) => week.includes(entry.date)));

  const status: Record<string, { done: boolean; label: string }> = {
    念佛: {
      done: chant > 0,
      label: chant > 0 ? `${chant.toLocaleString("zh-Hant")} / ${goal.toLocaleString("zh-Hant")}` : "未念",
    },
    戒色: {
      done: kept === "kept",
      label: kept === "kept" ? "守住了" : kept === "slipped" ? "沒守住" : "未記",
    },
    功過: {
      done: todayMerits.length > 0,
      label: todayMerits.length > 0 ? formatNet(netOf(todayMerits)) : "未記",
    },
    發願: {
      done: Boolean(vow),
      label: vow ? "已發願" : "未寫",
    },
    感恩: {
      done: thanked,
      label: thanked ? "已寫" : "未寫",
    },
    禪定: {
      done: sitSeconds >= 30,
      label: sitSeconds >= 30 ? formatMinutes(sitSeconds) : "未坐",
    },
  };

  const doneCount = Object.values(status).filter((item) => item.done).length;

  return (
    <div className="rise flex flex-col gap-8">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h2 className="font-serif text-3xl leading-tight">{greet.title}</h2>
          <p className="mt-2 text-mute">{greet.sub}</p>
        </div>
        <div className="text-right">
          <p className="font-serif text-3xl leading-none text-cinnabar tabular-nums">{streak}</p>
          <p className="mt-1 text-xs text-mute">{streak > 0 ? "連續天數" : "從今天起"}</p>
        </div>
      </div>

      <section>
        <div className="mb-2 flex items-baseline justify-between">
          <h3 className="font-serif text-lg">今日六事</h3>
          <p className="text-sm text-mute tabular-nums">
            {doneCount} / {ROWS.length}
          </p>
        </div>
        <ul>
          {ROWS.map((row) => {
            const item = status[row.title];
            return (
              <li key={row.title} className="border-b border-line">
                <button
                  type="button"
                  onClick={() => onGo(row.id)}
                  className="flex min-h-16 w-full items-center gap-3 py-3 text-left"
                >
                  <span
                    className={
                      "size-2.5 shrink-0 rounded-full " +
                      (item?.done ? "bg-sage" : "border border-mute")
                    }
                    aria-hidden="true"
                  />
                  <span className="min-w-0 flex-1">
                    <span className="block">{row.title}</span>
                    <span className="block text-sm text-mute">{row.line}</span>
                  </span>
                  <span className={"shrink-0 text-sm " + (item?.done ? "text-sage" : "text-mute")}>
                    {item?.label}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </section>

      <div className="grid grid-cols-3 gap-3 border-t border-line pt-5 text-center">
        <div>
          <p className="text-xs tracking-wide text-mute">本週念佛</p>
          <p className="mt-1 font-serif text-xl tabular-nums">{weekChant.toLocaleString("zh-Hant")}</p>
        </div>
        <div>
          <p className="text-xs tracking-wide text-mute">靜坐</p>
          <p className="mt-1 font-serif text-xl">{formatMinutes(weekSit)}</p>
        </div>
        <div>
          <p className="text-xs tracking-wide text-mute">功過</p>
          <p className="mt-1 font-serif text-xl tabular-nums">{formatNet(weekNet)}</p>
        </div>
      </div>

      <p className="border-l-2 border-cinnabar pl-4 font-serif text-lg leading-relaxed">{lineFor(today)}</p>
      <p className="text-sm text-mute">{labelOfKey(today)}的記錄，只留在這支手機裡，不會上傳。</p>
    </div>
  );
}
