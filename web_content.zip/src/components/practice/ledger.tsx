import { useState } from "react";
import {
  FAULTS,
  MERITS,
  formatNet,
  formatTime,
  labelOfKey,
  lastDays,
  netOf,
  todayKey,
  type Kind,
  type Rubric,
} from "@/lib/practice/model";
import { usePractice } from "@/lib/practice/store";
import { chip, field, primaryBtn } from "@/components/practice/ui";

type Span = "today" | "week" | "all";

export function Ledger() {
  const today = todayKey();
  const merits = usePractice((s) => s.merits);
  const addMerit = usePractice((s) => s.addMerit);
  const removeMerit = usePractice((s) => s.removeMerit);
  const [kind, setKind] = useState<Kind>("merit");
  const [picked, setPicked] = useState<Rubric | null>(null);
  const [note, setNote] = useState("");
  const [span, setSpan] = useState<Span>("today");
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);

  const list = kind === "merit" ? MERITS : FAULTS;
  const week = lastDays(7, today);
  const todayNet = netOf(merits.filter((entry) => entry.date === today));
  const weekNet = netOf(merits.filter((entry) => week.includes(entry.date)));
  const allNet = netOf(merits);
  const visible = merits.filter((entry) => {
    if (span === "today") return entry.date === today;
    if (span === "week") return week.includes(entry.date);
    return true;
  });

  function save() {
    if (!picked) return;
    addMerit({
      kind,
      categoryId: picked.id,
      label: picked.label,
      points: picked.points,
      note,
    });
    setPicked(null);
    setNote("");
  }

  return (
    <div className="rise flex flex-col gap-6">
      <div>
        <h2 className="font-serif text-3xl">功過簿</h2>
        <p className="mt-2 text-mute">記下來，是為了看清，不是為了責罰自己。</p>
      </div>

      <div className="grid grid-cols-3 gap-2 text-center">
        <Stat label="今日" value={todayNet} />
        <Stat label="近七日" value={weekNet} />
        <Stat label="累計" value={allNet} />
      </div>

      <div className="grid grid-cols-2 gap-2" role="tablist" aria-label="記功或記過">
        <button type="button" className={chip(kind === "merit")} onClick={() => { setKind("merit"); setPicked(null); }}>
          記一功
        </button>
        <button type="button" className={chip(kind === "fault")} onClick={() => { setKind("fault"); setPicked(null); }}>
          記一過
        </button>
      </div>

      <div className="grid grid-cols-2 gap-2">
        {list.map((item) => {
          const on = picked?.id === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setPicked(on ? null : item)}
              className={"min-h-14 rounded-md border px-3 py-2 text-left " + (on ? "border-cinnabar bg-paper-2" : "border-line")}
            >
              <span className="block">{item.label}</span>
              <span className={"block text-sm " + (kind === "merit" ? "text-sage" : "text-cinnabar")}>
                {kind === "merit" ? `+${item.points}` : `−${item.points}`}
              </span>
            </button>
          );
        })}
      </div>

      {picked ? (
        <div className="flex flex-col gap-3 rounded-md border border-line bg-paper p-4">
          <p className="text-sm text-mute">{picked.hint}</p>
          <input
            className={field}
            value={note}
            maxLength={80}
            placeholder="想補一句，也可以不寫"
            onChange={(event) => setNote(event.target.value)}
          />
          <button type="button" className={primaryBtn} onClick={save}>
            記下{picked.label}
          </button>
        </div>
      ) : null}

      <div className="flex gap-2">
        {(
          [
            ["today", "今日"],
            ["week", "近七日"],
            ["all", "全部"],
          ] as const
        ).map(([id, label]) => (
          <button key={id} type="button" className={chip(span === id)} onClick={() => setSpan(id)}>
            {label}
          </button>
        ))}
      </div>

      {visible.length === 0 ? (
        <p className="text-sm text-mute">還沒有記錄。功與過，都只是照見，不是審判。</p>
      ) : (
        <ul className="flex flex-col">
          {visible.map((entry) => (
            <li key={entry.id} className="border-b border-line py-3">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p>
                    {entry.label}
                    <span className="ml-2 text-sm text-mute">
                      {entry.date === today ? "今天" : labelOfKey(entry.date)} {formatTime(entry.at)}
                    </span>
                  </p>
                  {entry.note ? <p className="mt-1 text-sm text-mute">{entry.note}</p> : null}
                </div>
                <div className="flex shrink-0 flex-col items-end gap-1">
                  <span className={entry.kind === "merit" ? "text-sage" : "text-cinnabar"}>
                    {entry.kind === "merit" ? `+${entry.points}` : `−${entry.points}`}
                  </span>
                  {pendingDelete === entry.id ? (
                    <button
                      type="button"
                      className="min-h-11 text-sm text-cinnabar"
                      onClick={() => {
                        removeMerit(entry.id);
                        setPendingDelete(null);
                      }}
                    >
                      確定刪除
                    </button>
                  ) : (
                    <button
                      type="button"
                      className="min-h-11 text-sm text-mute"
                      onClick={() => setPendingDelete(entry.id)}
                    >
                      刪除
                    </button>
                  )}
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  const tone = value > 0 ? "text-sage" : value < 0 ? "text-cinnabar" : "text-mute";
  return (
    <div className="rounded-md border border-line bg-paper px-2 py-3">
      <p className="text-xs text-mute">{label}</p>
      <p className={"mt-1 font-serif text-2xl tabular-nums " + tone}>{formatNet(value)}</p>
    </div>
  );
}
