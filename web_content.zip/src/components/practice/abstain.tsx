import { useState } from "react";
import {
  ABSTAIN_WAYS,
  abstainStreak,
  labelOfKey,
  lastDays,
  todayKey,
  type AbstainDay,
} from "@/lib/practice/model";
import { ABSTAIN_QUOTES } from "@/lib/practice/quotes";
import { usePractice } from "@/lib/practice/store";
import { chip, field } from "@/components/practice/ui";

const EMPTY: AbstainDay = { mark: null, note: "", checks: [] };

export function Abstain() {
  const today = todayKey();
  const map = usePractice((s) => s.abstainByDate);
  const reason = usePractice((s) => s.abstainReason);
  const setDay = usePractice((s) => s.setAbstain);
  const setReason = usePractice((s) => s.setAbstainReason);
  const day = map[today] ?? EMPTY;
  const streak = abstainStreak(map, today);
  const days = lastDays(7, today);
  const [quoteAt, setQuoteAt] = useState(() => {
    const n = Number(today.replaceAll("-", ""));
    return Number.isFinite(n) ? n % ABSTAIN_QUOTES.length : 0;
  });

  function anotherQuote() {
    setQuoteAt((current) => {
      let next = current;
      while (next === current) next = Math.floor(Math.random() * ABSTAIN_QUOTES.length);
      return next;
    });
  }

  function toggle(id: string) {
    const checks = day.checks.includes(id) ? day.checks.filter((item) => item !== id) : [...day.checks, id];
    setDay(today, { checks });
  }

  return (
    <div className="rise flex flex-col gap-8">
      <div>
        <h2 className="font-serif text-3xl">戒色</h2>
        <p className="mt-2 text-mute">守的是這一念。來了，看見，不跟。</p>
      </div>

      <div>
        <p className="font-serif text-5xl leading-none text-cinnabar tabular-nums">{streak}</p>
        <p className="mt-2 text-sm text-mute">{streak > 0 ? "已守天數" : "從這一念開始"}</p>
      </div>

      <section>
        <div className="mb-2 flex items-baseline justify-between gap-3">
          <h3 className="font-serif text-xl">戒色格言</h3>
          <p className="text-sm text-mute tabular-nums">
            {quoteAt + 1} / {ABSTAIN_QUOTES.length}
          </p>
        </div>
        <button
          type="button"
          onClick={anotherQuote}
          className="w-full rounded-md border border-line bg-paper px-4 py-5 text-left"
        >
          <p className="font-serif text-lg leading-relaxed">{ABSTAIN_QUOTES[quoteAt]}</p>
          <p className="mt-4 text-sm tracking-wide text-mute">輕點，換一句</p>
        </button>
      </section>

      <section className="flex flex-col gap-3">
        <h3 className="font-serif text-xl">今日</h3>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            className={chip(day.mark === "kept")}
            onClick={() => setDay(today, { mark: day.mark === "kept" ? null : "kept" })}
          >
            守住了
          </button>
          <button
            type="button"
            className={chip(day.mark === "slipped")}
            onClick={() => setDay(today, { mark: day.mark === "slipped" ? null : "slipped" })}
          >
            沒守住
          </button>
        </div>
        {day.mark === "slipped" ? (
          <p className="text-sm text-mute">記下一筆就好。不必苛責，明天再守。</p>
        ) : null}
        <textarea
          className={field + " min-h-20 resize-none"}
          value={day.note}
          maxLength={80}
          placeholder="若想留一句，寫在這裡"
          onChange={(event) => setDay(today, { note: event.target.value })}
        />
      </section>

      <section>
        <h3 className="font-serif text-xl">守住的辦法</h3>
        <p className="mt-1 mb-2 text-sm text-mute">做到的點一下。不必項項都做。</p>
        <ul>
          {ABSTAIN_WAYS.map((way) => {
            const on = day.checks.includes(way.id);
            return (
              <li key={way.id} className="border-b border-line">
                <button
                  type="button"
                  role="checkbox"
                  aria-checked={on}
                  onClick={() => toggle(way.id)}
                  className="flex min-h-12 w-full items-center gap-3 py-3 text-left"
                >
                  <span
                    className={"size-2.5 shrink-0 rounded-full " + (on ? "bg-sage" : "border border-mute")}
                    aria-hidden="true"
                  />
                  <span>{way.label}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </section>

      <section className="flex flex-col gap-2">
        <h3 className="font-serif text-xl">我想守住，是因為</h3>
        <textarea
          className={field + " min-h-24 resize-none"}
          value={reason}
          maxLength={160}
          placeholder="寫給以後心亂的自己"
          onChange={(event) => setReason(event.target.value)}
        />
        <p className="text-sm text-mute">寫給心亂時的自己。它會留在這裡。</p>
      </section>

      <section>
        <h3 className="mb-3 text-sm text-mute">近七日</h3>
        <div className="grid grid-cols-7 gap-1 text-center">
          {days.map((key) => {
            const mark = map[key]?.mark;
            const word = ["日", "一", "二", "三", "四", "五", "六"][new Date(key + "T12:00:00").getDay()];
            return (
              <div key={key}>
                <p className={"font-serif text-lg " + (mark === "kept" ? "text-sage" : "text-mute")}>
                  {mark === "kept" ? "守" : mark === "slipped" ? "沒" : "·"}
                </p>
                <p className={"mt-1 text-xs " + (key === today ? "text-fg" : "text-mute")}>{word}</p>
              </div>
            );
          })}
        </div>
        <p className="mt-3 text-sm text-mute">{labelOfKey(today)}。這些記錄只留在這支手機。</p>
      </section>
    </div>
  );
}
