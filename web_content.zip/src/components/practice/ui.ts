export const field =
  "w-full rounded-md border border-line bg-paper px-3 py-3 text-base text-fg outline-none placeholder:text-mute focus:border-cinnabar";

export function chip(on: boolean) {
  return (
    "min-h-11 rounded-md border px-3 text-sm " +
    (on ? "border-cinnabar bg-paper-2 text-fg" : "border-line bg-transparent text-mute")
  );
}

export const primaryBtn =
  "inline-flex h-12 items-center justify-center rounded-md bg-cinnabar px-4 font-medium text-ink disabled:opacity-40";

export const quietBtn =
  "inline-flex min-h-11 items-center justify-center rounded-md border border-line bg-transparent px-3 text-sm text-fg disabled:opacity-40";
