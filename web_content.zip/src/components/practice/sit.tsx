import { useEffect, useRef, useState } from "react";
import {
  SIT_MINUTES,
  formatClock,
  formatMinutes,
  formatTime,
  labelOfKey,
  lastDays,
  todayKey,
} from "@/lib/practice/model";
import { bowlBell } from "@/lib/practice/sound";
import { usePractice, useSit } from "@/lib/practice/store";
import { chip, primaryBtn, quietBtn } from "@/components/practice/ui";

function useRemain() {
  const phase = useSit((s) => s.phase);
  const endsAt = useSit((s) => s.endsAt);
  const remainMs = useSit((s) => s.remainMs);
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    if (phase !== "running") return;
    const id = window.setInterval(() => setNow(Date.now()), 200);
    return () => window.clearInterval(id);
  }, [phase]);

  if (phase === "running" && endsAt != null) return Math.max(0, endsAt - now);
  if (phase === "paused") return remainMs;
  return 0;
}

function useReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const apply = () => setReduced(mq.matches);
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);
  return reduced;
}

export function SitOverlay() {
  const phase = useSit((s) => s.phase);
  const plannedSec = useSit((s) => s.plannedSec);
  const elapsedSec = useSit((s) => s.elapsedSec);
  const logged = useSit((s) => s.logged);
  const pause = useSit((s) => s.pause);
  const resume = useSit((s) => s.resume);
  const end = useSit((s) => s.end);
  const close = useSit((s) => s.close);
  const start = useSit((s) => s.start);
  const breathGuide = usePractice((s) => s.breathGuide);
  const bellOn = usePractice((s) => s.bellOn);
  const remain = useRemain();
  const reduced = useReducedMotion();
  const [confirming, setConfirming] = useState(false);
  const belled = useRef(false);
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (phase === "running" && remain <= 0) {
      if (!belled.current) {
        belled.current = true;
        end("complete");
        if (bellOn) bowlBell();
      }
    }
    if (phase === "idle") {
      belled.current = false;
      setConfirming(false);
    }
  }, [phase, remain, end, bellOn]);

  useEffect(() => {
    if (phase !== "idle") dialogRef.current?.focus();
  }, [phase]);

  if (phase === "idle") return null;

  const elapsedMs = phase === "done" ? elapsedSec * 1000 : plannedSec * 1000 - remain;
  const cycle = 10000;
  const t = ((elapsedMs % cycle) + cycle) % cycle;
  const inhaling = t < 4000;
  const p = inhaling ? t / 4000 : (t - 4000) / 6000;
  const smooth = p * p * (3 - 2 * p);
  const scale = !breathGuide || reduced || phase !== "running" ? 1 : inhaling ? 0.92 + 0.08 * smooth : 1 - 0.08 * smooth;
  const breathLabel = phase === "paused" ? "暫停" : !breathGuide ? "安住" : inhaling ? "吸氣" : "呼氣";
  const remainSec = Math.ceil(remain / 1000);

  return (
    <div
      ref={dialogRef}
      role="dialog"
      aria-modal="true"
      aria-label="禪定計時"
      tabIndex={-1}
      className="fixed inset-0 z-50 flex flex-col bg-ink px-6 text-fg outline-none"
    >
      <div className="mx-auto flex w-full max-w-lg flex-1 flex-col items-center justify-center">
        {phase === "done" ? (
          <div className="flex flex-col items-center text-center">
            <p className="text-sm text-mute">{logged ? "這一坐，已留下" : "坐得太短，這次未記"}</p>
            <h2 className="mt-3 font-serif text-4xl leading-tight">
              {logged ? `坐了 ${formatMinutes(elapsedSec)}` : "能坐下，就很好"}
            </h2>
            <p className="mt-4 max-w-xs text-mute">靜坐不是清空。是讓念頭自己走過去。</p>
            <div className="mt-8 flex w-full max-w-xs flex-col gap-2">
              <button type="button" className={primaryBtn} onClick={() => start(plannedSec / 60)}>
                再坐一次
              </button>
              <button type="button" className={quietBtn} onClick={close}>
                先到這裡
              </button>
            </div>
          </div>
        ) : (
          <>
            <div className="relative grid size-64 place-items-center">
              <div
                className="absolute inset-4 rounded-full border border-line"
                style={{ transform: `scale(${scale})` }}
              />
              <div className="absolute inset-0 rounded-full border border-cinnabar opacity-40" />
              <p className="font-serif text-6xl tabular-nums">{formatClock(remain)}</p>
            </div>
            <p className="mt-6 text-lg text-mute">{breathLabel}</p>
            <p className="mt-1 text-sm text-mute">{Math.round(plannedSec / 60)} 分鐘</p>

            {confirming ? (
              <div className="mt-10 flex w-full max-w-xs flex-col gap-2">
                <p className="mb-2 text-center text-sm text-mute">這一坐，要到這裡嗎？</p>
                {plannedSec - remainSec >= 30 ? (
                  <button type="button" className={primaryBtn} onClick={() => end("keep")}>
                    留下已坐的時間
                  </button>
                ) : null}
                <button type="button" className={quietBtn} onClick={() => end("discard")}>
                  這次不記
                </button>
                <button type="button" className={quietBtn} onClick={() => setConfirming(false)}>
                  繼續坐
                </button>
              </div>
            ) : (
              <div className="mt-10 flex w-full max-w-xs gap-2">
                {phase === "paused" ? (
                  <button type="button" className={primaryBtn + " flex-1"} onClick={resume}>
                    繼續
                  </button>
                ) : (
                  <button type="button" className={quietBtn + " flex-1"} onClick={pause}>
                    暫停
                  </button>
                )}
                <button type="button" className={quietBtn + " flex-1"} onClick={() => setConfirming(true)}>
                  結束
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

export function SitPage() {
  const [minutes, setMinutes] = useState<number>(10);
  const start = useSit((s) => s.start);
  const sits = usePractice((s) => s.sits);
  const breathGuide = usePractice((s) => s.breathGuide);
  const bellOn = usePractice((s) => s.bellOn);
  const setBreath = usePractice((s) => s.setBreathGuide);
  const setBell = usePractice((s) => s.setBellOn);
  const today = todayKey();
  const week = lastDays(7, today);
  const weekSeconds = sits.filter((sit) => week.includes(sit.date)).reduce((n, sit) => n + sit.seconds, 0);
  const weekCount = sits.filter((sit) => week.includes(sit.date)).length;

  return (
    <div className="rise flex flex-col gap-6">
      <div>
        <h2 className="font-serif text-3xl">禪定</h2>
        <p className="mt-2 text-mute">坐下來就好。久不久，是其次。</p>
      </div>

      <p className="text-sm text-mute">
        本週 {weekCount} 坐
        <span className="px-2">·</span>
        {formatMinutes(weekSeconds)}
      </p>

      <div className="flex flex-wrap gap-2">
        {SIT_MINUTES.map((n) => (
          <button key={n} type="button" className={chip(n === minutes)} onClick={() => setMinutes(n)}>
            {n} 分鐘
          </button>
        ))}
      </div>

      <button
        type="button"
        role="switch"
        aria-checked={breathGuide}
        onClick={() => setBreath(!breathGuide)}
        className="flex min-h-12 items-center justify-between border-y border-line py-3"
      >
        <span>
          呼吸引導
          <span className="mt-0.5 block text-sm text-mute">吸氣四秒，呼氣六秒</span>
        </span>
        <span className={breathGuide ? "text-sage" : "text-mute"}>{breathGuide ? "開" : "關"}</span>
      </button>

      <button
        type="button"
        role="switch"
        aria-checked={bellOn}
        onClick={() => setBell(!bellOn)}
        className="flex min-h-12 items-center justify-between border-b border-line py-3"
      >
        <span>結束時敲磬</span>
        <span className={bellOn ? "text-sage" : "text-mute"}>{bellOn ? "開" : "關"}</span>
      </button>

      <button type="button" className={primaryBtn} onClick={() => start(minutes)}>
        開始靜坐
      </button>

      <section>
        <h3 className="mb-2 font-serif text-lg">最近</h3>
        {sits.length === 0 ? (
          <p className="text-sm text-mute">還沒有坐過。五分鐘，也是一坐。</p>
        ) : (
          <ul>
            {sits.slice(0, 8).map((sit) => (
              <li key={sit.id} className="flex items-baseline justify-between border-b border-line py-3 text-sm">
                <span>
                  {sit.date === today ? "今天" : labelOfKey(sit.date)}{" "}
                  <span className="text-mute">{formatTime(sit.at)}</span>
                </span>
                <span className={sit.finished ? "text-sage" : "text-mute"}>
                  {formatMinutes(sit.seconds)}
                  {sit.finished ? "　圓滿" : ""}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
