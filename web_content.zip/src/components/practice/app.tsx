import { useEffect, useState } from "react";
import { CircleDot, Flower2, Heart, House, Scale, Shield, SunMedium } from "lucide-react";
import { formatChineseDate, type Tab } from "@/lib/practice/model";
import { usePractice, useSit } from "@/lib/practice/store";
import { Abstain } from "@/components/practice/abstain";
import { Chant } from "@/components/practice/chant";
import { ThanksPage, VowPage } from "@/components/practice/journal";
import { Ledger } from "@/components/practice/ledger";
import { SitOverlay, SitPage } from "@/components/practice/sit";
import { Today } from "@/components/practice/today";

const TABS: { id: Tab; label: string; icon: typeof House }[] = [
  { id: "today", label: "今日", icon: House },
  { id: "chant", label: "念佛", icon: CircleDot },
  { id: "ledger", label: "功過", icon: Scale },
  { id: "abstain", label: "戒色", icon: Shield },
  { id: "vow", label: "發願", icon: SunMedium },
  { id: "thanks", label: "感恩", icon: Heart },
  { id: "sit", label: "禪定", icon: Flower2 },
];

function useHydrated() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    let alive = true;
    const finish = () => {
      if (alive) setReady(true);
    };
    if (usePractice.persist.hasHydrated()) finish();
    const unsub = usePractice.persist.onFinishHydration(finish);
    void Promise.resolve(usePractice.persist.rehydrate()).then(finish, finish);
    return () => {
      alive = false;
      unsub();
    };
  }, []);
  return ready;
}

export function PracticeApp() {
  const ready = useHydrated();
  const [tab, setTab] = useState<Tab>("today");
  const sitting = useSit((s) => s.phase !== "idle");

  function open(next: Tab) {
    setTab(next);
  }

  return (
    <div className="min-h-dvh overflow-x-hidden bg-ink text-fg">
      <div className="mx-auto flex min-h-dvh w-full max-w-lg flex-col">
        <header className="flex items-end justify-between px-5 pt-6 pb-5">
          <div>
            <div className="flex items-center gap-2">
              <span className="grid size-8 place-items-center bg-cinnabar font-serif text-sm text-ink">心</span>
              <h1 className="font-serif text-2xl tracking-wide">心田</h1>
            </div>
            <p className="mt-1 text-sm text-mute">日日耕心</p>
          </div>
          <p className="text-right text-sm text-mute">{ready ? formatChineseDate() : "　"}</p>
        </header>
        <main inert={sitting} className="flex-1 px-5 pb-28">
          {ready ? (
            <>
              {tab === "today" ? <Today onGo={open} /> : null}
              {tab === "chant" ? <Chant /> : null}
              {tab === "ledger" ? <Ledger /> : null}
              {tab === "abstain" ? <Abstain /> : null}
              {tab === "vow" ? <VowPage /> : null}
              {tab === "thanks" ? <ThanksPage /> : null}
              {tab === "sit" ? <SitPage /> : null}
            </>
          ) : (
            <div className="flex flex-col gap-4 pt-2">
              <div className="h-8 w-24 rounded-sm bg-paper-2" />
              <div className="h-4 w-48 rounded-sm bg-paper" />
              <div className="mt-4 h-px bg-line" />
              <p className="text-sm text-mute">正在打開今天。</p>
            </div>
          )}
        </main>
        <nav inert={sitting} className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-ink" aria-label="功課">
          <div className="mx-auto grid max-w-lg grid-cols-7">
            {TABS.map((item) => {
              const active = tab === item.id;
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  type="button"
                  aria-current={active ? "page" : undefined}
                  onClick={() => open(item.id)}
                  className={
                    "relative flex h-16 flex-col items-center justify-center gap-1 text-xs " +
                    (active ? "text-fg" : "text-mute")
                  }
                >
                  <span
                    className={"absolute top-0 h-0.5 w-4 " + (active ? "bg-cinnabar" : "bg-transparent")}
                    aria-hidden="true"
                  />
                  <Icon size={18} strokeWidth={1.75} aria-hidden="true" />
                  {item.label}
                </button>
              );
            })}
          </div>
        </nav>
      </div>
      {ready ? <SitOverlay /> : null}
    </div>
  );
}
