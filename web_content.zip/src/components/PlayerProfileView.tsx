import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';

export const PlayerProfileView: React.FC = () => {
  const {
    ign,
    uid,
    guild,
    coins,
    diamonds,
    cashWon,
    upiId,
    setIsEditProfileOpen,
    setIsEditUpiOpen,
    openOtpModal,
    showToast,
  } = useApp();

  const [activePane, setActivePane] = useState<'match-history' | 'game-ids' | 'withdrawal'>('match-history');

  const copyUidToClipboard = () => {
    navigator.clipboard.writeText('2849104821');
    showToast(`Free Fire UID (2849104821) copied!`);
  };

  const handleCashout = () => {
    openOtpModal(8940, `UPI (${upiId || 'player@okaxis'})`);
  };

  return (
    <div className="flex flex-col w-full">
      {/* Hero Profile Banner Area */}
      <section className="relative w-full overflow-hidden bg-[#0b0e14]">
        {/* Ambient Cyber Glows */}
        <div className="absolute -top-32 -left-20 w-96 h-96 bg-primary-container/15 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute top-0 right-1/4 w-[32rem] h-64 bg-tertiary-container/10 rounded-full blur-3xl pointer-events-none"></div>

        {/* Editorial Header Graphic / Pattern */}
        <div className="w-full h-48 sm:h-64 relative bg-[#191c22] overflow-hidden">
          <svg className="absolute inset-0 w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern height="40" id="tacGrid" patternUnits="userSpaceOnUse" width="40">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#ab897d" strokeWidth="0.5"></path>
              </pattern>
            </defs>
            <rect fill="url(#tacGrid)" height="100%" width="100%"></rect>
            <line stroke="#ff5e00" strokeDasharray="4 8" strokeWidth="1" x1="20%" x2="20%" y1="0" y2="100%"></line>
            <line stroke="#7df4ff" strokeDasharray="2 6" strokeWidth="1" x1="80%" x2="80%" y1="0" y2="100%"></line>
          </svg>
          <div className="absolute inset-0 bg-gradient-to-t from-[#0b0e14] via-[#0b0e14]/60 to-transparent"></div>

          {/* Top Tactical Telemetry Watermark */}
          <div className="absolute top-4 left-4 sm:left-10 right-4 sm:right-10 flex items-center justify-between pointer-events-none">
            <div className="flex items-center gap-1.5 font-label-sm text-label-sm uppercase text-outline">
              <span className="w-1.5 h-1.5 bg-primary-container rounded-full animate-ping"></span>
              <span>ARENA NODE // SOUTH_ASIA_P01</span>
              <span>:: LATENCY 14MS</span>
            </div>
            <span className="font-label-sm text-label-sm uppercase text-tertiary tracking-widest hidden sm:inline-block font-bold">
              PROTOCOL: RANKED_BATTLE_ROYALE
            </span>
          </div>
        </div>

        {/* Profile Header Core Content */}
        <div className="px-4 sm:px-6 lg:px-10 -mt-20 pb-6 relative z-10 max-w-7xl mx-auto w-full">
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
            {/* Left: Avatar + Identity */}
            <div className="flex flex-col sm:flex-row items-start sm:items-end gap-6">
              <div className="relative group">
                <div className="w-32 h-32 sm:w-36 sm:h-36 rounded-xl overflow-hidden bg-surface-container shadow-2xl relative border-2 border-primary-container/30">
                  <img
                    alt="ALPHA_V7 Cyber Avatar"
                    className="w-full h-full object-cover"
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuC9zYtka30OJFJCZywUUT7H_O8UHMa9dUGVrz81Gyq5ojHWZZuyBcsqe49S5rUqaK-s1Yztco1pUz7Lv2k-iRJG9ptLhxXRMKeAeJ2eA6bkh9UlseNNjZ7JEhPpbrxNF0CZd81nTM2SyfynjuVQ8hNDUagGNByNnPKa8km6ELoXqqJHawOSEcGua1MT6iYDHhFn0WME2EQgcTbPHLzrMJlwWbiXFi7larHDVMX8sFjPxHwNX9W1fjj1zw"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0b0e14]/80 via-transparent to-transparent"></div>
                </div>

                <div className="absolute -bottom-2 -right-2 bg-[#ff5e00] text-[#531900] px-2.5 py-0.5 rounded shadow-lg flex items-center gap-1 font-label-md text-label-md uppercase font-bold">
                  <span className="text-xs">LVL</span>
                  <span>68</span>
                </div>
                <span className="absolute top-2 left-2 w-3 h-3 bg-[#00dbe9] rounded-full shadow-[0_0_8px_rgba(0,219,233,0.8)]"></span>
              </div>

              {/* Nameplate & Metadata */}
              <div className="flex flex-col gap-1.5">
                <div className="flex flex-wrap items-center gap-3">
                  <h1 className="font-display-xl text-3xl sm:text-5xl text-on-surface uppercase tracking-tight font-bold">
                    {ign}
                  </h1>
                  <div className="flex items-center gap-1 bg-surface-container-high px-2.5 py-1 rounded text-tertiary-fixed font-label-sm text-label-sm uppercase font-bold">
                    <span className="material-symbols-outlined text-sm">verified</span>
                    <span>PRO ATHLETE</span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-y-2 gap-x-4 text-on-surface-variant font-label-md text-label-md">
                  <div className="flex items-center gap-1 bg-surface-container px-2.5 py-1 rounded text-secondary font-bold">
                    <span className="material-symbols-outlined text-base">shield</span>
                    <span>{guild}</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-[#191c22] px-2.5 py-1 rounded">
                    <span className="text-outline uppercase text-xs font-semibold">FF UID:</span>
                    <span className="font-mono text-on-surface font-semibold" id="player-uid">
                      2849104821
                    </span>
                    <button
                      type="button"
                      onClick={copyUidToClipboard}
                      className="p-1 hover:text-primary-container transition-colors flex items-center justify-center text-on-surface-variant cursor-pointer"
                      title="Copy UID"
                    >
                      <span className="material-symbols-outlined text-base">content_copy</span>
                    </button>
                  </div>
                  <div className="flex items-center gap-1 text-[#00dbe9] font-semibold">
                    <span className="material-symbols-outlined text-base">military_tech</span>
                    <span className="uppercase">Grandmaster / Elite Hunter</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: Wallet & Edit Button */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <div className="flex items-center justify-around gap-4 bg-[#191c22] px-6 py-2.5 rounded shadow-inner">
                <div className="flex items-center gap-2">
                  <span className="text-lg">🪙</span>
                  <div className="flex flex-col">
                    <span className="font-headline-sm text-headline-sm text-secondary leading-none font-bold">
                      {coins}
                    </span>
                    <span className="font-label-sm text-label-sm uppercase text-outline font-semibold">
                      Gold Coins
                    </span>
                  </div>
                </div>
                <div className="w-px h-8 bg-surface-container-highest"></div>
                <div className="flex items-center gap-2">
                  <span className="text-lg">💎</span>
                  <div className="flex flex-col">
                    <span className="font-headline-sm text-headline-sm text-[#00dbe9] leading-none font-bold">
                      {diamonds}
                    </span>
                    <span className="font-label-sm text-label-sm uppercase text-outline font-semibold">
                      Diamonds
                    </span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsEditProfileOpen(true)}
                className="flex items-center justify-center gap-1.5 bg-[#ff5e00] hover:bg-[#ffa504] text-[#531900] px-6 py-2.5 rounded font-label-md text-label-md uppercase tracking-wider transition-all shadow-[0_0_16px_rgba(255,94,0,0.35)] font-bold cursor-pointer"
              >
                <span className="material-symbols-outlined text-lg">tune</span>
                <span>Edit Profile</span>
              </button>
            </div>
          </div>

          {/* Rank Progression Telemetry Bar */}
          <div className="mt-6 bg-surface-container p-4 rounded shadow-lg flex flex-col gap-1.5">
            <div className="flex items-center justify-between font-label-md text-label-md font-bold">
              <div className="flex items-center gap-2">
                <span className="text-primary-container uppercase">Rank Tier: Grandmaster V</span>
                <span className="text-outline">•</span>
                <span className="text-on-surface-variant font-normal">Score: 4,890 / 5,200 RP</span>
              </div>
              <span className="text-tertiary-fixed uppercase">310 RP To Global Elite</span>
            </div>
            <div className="w-full h-2.5 bg-[#0b0e14] rounded-full overflow-hidden flex">
              <div
                className="h-full bg-gradient-to-r from-primary-container via-secondary-container to-tertiary-fixed rounded-full"
                style={{ width: '78%' }}
              ></div>
            </div>
          </div>
        </div>
      </section>

      {/* Player Statistics Bento Matrix */}
      <section className="w-full px-4 sm:px-6 lg:px-10 py-8 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-6 bg-[#ff5e00] rounded-sm"></div>
            <h2 className="font-headline-md text-headline-md uppercase text-on-surface tracking-wider font-bold">
              Combat Analytics &amp; Bounty
            </h2>
          </div>
          <span className="font-label-sm text-label-sm uppercase text-outline font-semibold">
            SEASON 32 • ALL MODES
          </span>
        </div>

        {/* 4 Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Card 1: Matches Played */}
          <div className="bg-surface-container p-6 rounded shadow-md flex flex-col justify-between hover:bg-surface-container-high transition-colors">
            <div className="flex items-center justify-between mb-3">
              <span className="font-label-md text-label-md uppercase text-on-surface-variant tracking-wider font-semibold">
                Total Matches
              </span>
              <span className="p-2 rounded bg-surface-container-highest text-[#00dbe9] flex items-center justify-center">
                <span className="material-symbols-outlined text-lg">sports_esports</span>
              </span>
            </div>
            <div className="flex flex-col">
              <span className="font-headline-lg text-4xl text-on-surface font-bold leading-none">86</span>
              <span className="font-body-sm text-body-sm text-outline mt-1">Tournaments &amp; Scrims</span>
            </div>
            <div className="w-full h-8 mt-4">
              <svg className="w-full h-full text-[#00dbe9]" preserveAspectRatio="none" viewBox="0 0 100 24">
                <polyline
                  fill="none"
                  points="0,18 15,14 30,20 45,10 60,12 75,6 90,8 100,2"
                  stroke="currentColor"
                  strokeWidth="2"
                ></polyline>
              </svg>
            </div>
          </div>

          {/* Card 2: Total Solo Kills */}
          <div className="bg-surface-container p-6 rounded shadow-md flex flex-col justify-between hover:bg-surface-container-high transition-colors">
            <div className="flex items-center justify-between mb-3">
              <span className="font-label-md text-label-md uppercase text-on-surface-variant tracking-wider font-semibold">
                Total Kills
              </span>
              <span className="p-2 rounded bg-surface-container-highest text-primary-container flex items-center justify-center">
                <span className="material-symbols-outlined text-lg">gps_fixed</span>
              </span>
            </div>
            <div className="flex flex-col">
              <div className="flex items-baseline gap-2">
                <span className="font-headline-lg text-4xl text-on-surface font-bold leading-none">214</span>
                <span className="font-label-sm text-label-sm text-primary-container font-bold">2.48 K/D</span>
              </div>
              <div className="mt-2 bg-[#0b0e14] px-2 py-1 rounded inline-flex items-center justify-between">
                <span className="font-label-sm text-label-sm text-outline uppercase font-semibold">Bounty Won:</span>
                <span className="font-label-sm text-label-sm text-secondary font-bold">₹4,280</span>
              </div>
            </div>
            <div className="w-full h-1.5 bg-[#0b0e14] rounded-full mt-4 overflow-hidden">
              <div className="h-full bg-primary-container" style={{ width: '72%' }}></div>
            </div>
          </div>

          {/* Card 3: Booyah Wins */}
          <div className="bg-surface-container p-6 rounded shadow-md flex flex-col justify-between hover:bg-surface-container-high transition-colors">
            <div className="flex items-center justify-between mb-3">
              <span className="font-label-md text-label-md uppercase text-on-surface-variant tracking-wider font-semibold">
                Booyah Wins
              </span>
              <span className="p-2 rounded bg-surface-container-highest text-secondary flex items-center justify-center">
                <span className="material-symbols-outlined text-lg">emoji_events</span>
              </span>
            </div>
            <div className="flex flex-col">
              <div className="flex items-baseline gap-2">
                <span className="font-headline-lg text-4xl text-secondary font-bold leading-none">23</span>
                <span className="font-label-sm text-label-sm text-tertiary-fixed font-bold">#1 Champion</span>
              </div>
              <div className="mt-2 bg-[#0b0e14] px-2 py-1 rounded inline-flex items-center justify-between">
                <span className="font-label-sm text-label-sm text-outline uppercase font-semibold">Win Ratio:</span>
                <span className="font-label-sm text-label-sm text-[#00dbe9] font-bold">26.7%</span>
              </div>
            </div>
            <div className="w-full flex items-center justify-between mt-4 font-label-sm text-label-sm text-outline font-semibold">
              <span>Top 3 Rate: 48.2%</span>
              <span className="text-[#00dbe9]">High Apex</span>
            </div>
          </div>

          {/* Card 4: Total Cash Won */}
          <div className="bg-gradient-to-br from-surface-container to-surface-container-high p-6 rounded shadow-lg flex flex-col justify-between relative overflow-hidden">
            <div className="absolute -right-4 -bottom-4 w-24 h-24 bg-primary-container/10 rounded-full blur-xl pointer-events-none"></div>
            <div className="flex items-center justify-between mb-3">
              <span className="font-label-md text-label-md uppercase text-primary tracking-wider font-bold">
                Total Cash Won
              </span>
              <span className="p-2 rounded bg-primary-container/20 text-primary-container flex items-center justify-center">
                <span className="material-symbols-outlined text-lg">payments</span>
              </span>
            </div>
            <div className="flex flex-col">
              <span className="font-headline-lg text-4xl text-primary font-bold leading-none">
                ₹{cashWon.toLocaleString('en-IN')}
              </span>
              <span className="font-body-sm text-body-sm text-on-surface-variant mt-1">Direct Prize Disbursals</span>
            </div>
            <div className="mt-4 pt-1 flex items-center justify-between">
              <span className="font-label-sm text-label-sm uppercase text-outline font-semibold">Payout Status:</span>
              <span className="font-label-sm text-label-sm text-[#00dbe9] uppercase font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-[#00dbe9] rounded-full animate-pulse"></span>
                Instant Ready
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Multi-Tab Esports Section */}
      <section className="w-full px-4 sm:px-6 lg:px-10 pb-12 max-w-7xl mx-auto flex-1">
        {/* Tab Controls Bar */}
        <div className="flex flex-wrap items-center gap-1 bg-[#191c22] p-1.5 rounded mb-6">
          <button
            onClick={() => setActivePane('match-history')}
            className={`flex items-center gap-1.5 px-6 py-2 rounded font-label-md text-label-md uppercase tracking-wider transition-all cursor-pointer ${
              activePane === 'match-history'
                ? 'bg-[#ff5e00] text-[#531900] font-bold shadow-md'
                : 'text-on-surface-variant hover:text-on-surface hover:bg-surface-container'
            }`}
          >
            <span className="material-symbols-outlined text-lg">history_toggle_off</span>
            <span>Match History</span>
          </button>
          <button
            onClick={() => setActivePane('game-ids')}
            className={`flex items-center gap-1.5 px-6 py-2 rounded font-label-md text-label-md uppercase tracking-wider transition-all cursor-pointer ${
              activePane === 'game-ids'
                ? 'bg-[#ff5e00] text-[#531900] font-bold shadow-md'
                : 'text-on-surface-variant hover:text-on-surface hover:bg-surface-container'
            }`}
          >
            <span className="material-symbols-outlined text-lg">badge</span>
            <span>Game IDs &amp; Verification</span>
          </button>
          <button
            onClick={() => setActivePane('withdrawal')}
            className={`flex items-center gap-1.5 px-6 py-2 rounded font-label-md text-label-md uppercase tracking-wider transition-all cursor-pointer ${
              activePane === 'withdrawal'
                ? 'bg-[#ff5e00] text-[#531900] font-bold shadow-md'
                : 'text-on-surface-variant hover:text-on-surface hover:bg-surface-container'
            }`}
          >
            <span className="material-symbols-outlined text-lg">account_balance_wallet</span>
            <span>Withdrawal Settings</span>
          </button>
        </div>

        {/* PANE 1: Match History */}
        {activePane === 'match-history' && (
          <div className="flex flex-col gap-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-surface-container p-4 rounded">
              <div className="flex items-center gap-4">
                <span className="font-label-md text-label-md uppercase text-on-surface font-bold">
                  Recent Completed Encounters
                </span>
                <span className="bg-surface-container-highest px-2 py-0.5 rounded font-label-sm text-label-sm text-[#00dbe9] font-bold">
                  5 Verified Scrims
                </span>
              </div>
              <div className="flex items-center gap-1">
                <button className="px-4 py-1 rounded bg-surface-container-high text-on-surface font-label-sm text-label-sm uppercase font-bold cursor-pointer">
                  All Types
                </button>
                <button className="px-4 py-1 rounded bg-[#191c22] text-on-surface-variant font-label-sm text-label-sm uppercase hover:text-on-surface cursor-pointer">
                  Solo
                </button>
                <button className="px-4 py-1 rounded bg-[#191c22] text-on-surface-variant font-label-sm text-label-sm uppercase hover:text-on-surface cursor-pointer">
                  Squad
                </button>
              </div>
            </div>

            {/* Matches list */}
            <div className="flex flex-col gap-2">
              {/* Item 1 */}
              <div className="bg-surface-container hover:bg-surface-container-high transition-all p-4 rounded shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 relative overflow-hidden">
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-secondary-container"></div>
                <div className="flex items-center gap-4 pl-1">
                  <div className="w-12 h-12 rounded bg-secondary-container/20 flex flex-col items-center justify-center text-secondary">
                    <span className="font-headline-sm text-headline-sm leading-none font-bold">#1</span>
                    <span className="font-label-sm text-label-sm uppercase leading-none font-bold">Booyah</span>
                  </div>
                  <div className="flex flex-col">
                    <div className="flex items-center gap-2">
                      <span className="font-headline-sm text-headline-sm uppercase text-on-surface font-bold">
                        Squad #1030
                      </span>
                      <span className="bg-[#0b0e14] text-[#00dbe9] px-2 py-0.5 rounded font-label-sm text-label-sm uppercase font-semibold">
                        Bermuda Remastered
                      </span>
                    </div>
                    <div className="flex items-center gap-1 text-outline font-label-sm text-label-sm mt-1">
                      <span>Oct 24, 2025 • 21:40 IST</span>
                      <span>•</span>
                      <span>Room Host: IGNITE_SYSTEM</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-6">
                  <div className="flex flex-col">
                    <span className="font-label-sm text-label-sm uppercase text-outline font-semibold">Team Kills</span>
                    <span className="font-headline-sm text-headline-sm text-on-surface font-bold">14 Kills</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="font-label-sm text-label-sm uppercase text-outline font-semibold">Player Kills</span>
                    <span className="font-headline-sm text-headline-sm text-primary-container font-bold">6 Kills</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="font-label-sm text-label-sm uppercase text-outline font-semibold">Survival</span>
                    <span className="font-headline-sm text-headline-sm text-on-surface font-bold">18m 42s</span>
                  </div>
                </div>

                <div className="flex items-center justify-between md:justify-end gap-4">
                  <div className="flex flex-col md:text-right">
                    <span className="font-label-sm text-label-sm uppercase text-outline font-semibold">
                      Prize Money Disbursed
                    </span>
                    <span className="font-headline-md text-headline-md text-secondary font-bold">+₹200</span>
                  </div>
                  <button
                    onClick={() => showToast('Match #1030 verified kill telemetry report loaded.', 'info')}
                    className="p-2 rounded bg-surface-container-highest text-on-surface-variant hover:text-[#00dbe9] transition-colors cursor-pointer"
                    title="Download Combat Replay"
                  >
                    <span className="material-symbols-outlined text-xl">description</span>
                  </button>
                </div>
              </div>

              {/* Item 2 */}
              <div className="bg-surface-container hover:bg-surface-container-high transition-all p-4 rounded shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 relative overflow-hidden">
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary-container"></div>
                <div className="flex items-center gap-4 pl-1">
                  <div className="w-12 h-12 rounded bg-surface-container-highest flex flex-col items-center justify-center text-on-surface">
                    <span className="font-headline-sm text-headline-sm leading-none font-bold">#4</span>
                    <span className="font-label-sm text-label-sm uppercase leading-none text-outline font-bold">Top 5</span>
                  </div>
                  <div className="flex flex-col">
                    <div className="flex items-center gap-2">
                      <span className="font-headline-sm text-headline-sm uppercase text-on-surface font-bold">
                        Solo #1039
                      </span>
                      <span className="bg-[#0b0e14] text-on-surface-variant px-2 py-0.5 rounded font-label-sm text-label-sm uppercase font-semibold">
                        Purgatory Hardcore
                      </span>
                    </div>
                    <div className="flex items-center gap-1 text-outline font-label-sm text-label-sm mt-1">
                      <span>Oct 24, 2025 • 19:15 IST</span>
                      <span>•</span>
                      <span>Room Host: ARENA_BOT_2</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-6">
                  <div className="flex flex-col">
                    <span className="font-label-sm text-label-sm uppercase text-outline font-semibold">Combat Mode</span>
                    <span className="font-headline-sm text-headline-sm text-on-surface font-bold">Solo Bounty</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="font-label-sm text-label-sm uppercase text-outline font-semibold">Bounty Kills</span>
                    <span className="font-headline-sm text-headline-sm text-primary-container font-bold">4 Kills</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="font-label-sm text-label-sm uppercase text-outline font-semibold">Damage Dealt</span>
                    <span className="font-headline-sm text-headline-sm text-on-surface font-bold">1,480</span>
                  </div>
                </div>

                <div className="flex items-center justify-between md:justify-end gap-4">
                  <div className="flex flex-col md:text-right">
                    <span className="font-label-sm text-label-sm uppercase text-outline font-semibold">
                      Bounty Payout (₹20/Kill)
                    </span>
                    <span className="font-headline-md text-headline-md text-primary font-bold">+₹80</span>
                  </div>
                  <button
                    onClick={() => showToast('Match #1039 verified kill telemetry report loaded.', 'info')}
                    className="p-2 rounded bg-surface-container-highest text-on-surface-variant hover:text-[#00dbe9] transition-colors cursor-pointer"
                    title="Download Combat Replay"
                  >
                    <span className="material-symbols-outlined text-xl">description</span>
                  </button>
                </div>
              </div>

              {/* Item 3 */}
              <div className="bg-surface-container hover:bg-surface-container-high transition-all p-4 rounded shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4 relative overflow-hidden">
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-surface-variant"></div>
                <div className="flex items-center gap-4 pl-1">
                  <div className="w-12 h-12 rounded bg-surface-container-highest flex flex-col items-center justify-center text-on-surface">
                    <span className="font-headline-sm text-headline-sm leading-none font-bold">#2</span>
                    <span className="font-label-sm text-label-sm uppercase leading-none text-outline font-bold">Finalist</span>
                  </div>
                  <div className="flex flex-col">
                    <div className="flex items-center gap-2">
                      <span className="font-headline-sm text-headline-sm uppercase text-on-surface font-bold">
                        Squad #1024
                      </span>
                      <span className="bg-[#0b0e14] text-[#00dbe9] px-2 py-0.5 rounded font-label-sm text-label-sm uppercase font-semibold">
                        Kalahari Desolation
                      </span>
                    </div>
                    <div className="flex items-center gap-1 text-outline font-label-sm text-label-sm mt-1">
                      <span>Oct 23, 2025 • 22:30 IST</span>
                      <span>•</span>
                      <span>Room Host: VORTEX_MANAGER</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-6">
                  <div className="flex flex-col">
                    <span className="font-label-sm text-label-sm uppercase text-outline font-semibold">Team Kills</span>
                    <span className="font-headline-sm text-headline-sm text-on-surface font-bold">9 Kills</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="font-label-sm text-label-sm uppercase text-outline font-semibold">Player Kills</span>
                    <span className="font-headline-sm text-headline-sm text-primary-container font-bold">3 Kills</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="font-label-sm text-label-sm uppercase text-outline font-semibold">Placement</span>
                    <span className="font-headline-sm text-headline-sm text-on-surface font-bold">Runner Up</span>
                  </div>
                </div>

                <div className="flex items-center justify-between md:justify-end gap-4">
                  <div className="flex flex-col md:text-right">
                    <span className="font-label-sm text-label-sm uppercase text-outline font-semibold">
                      Runner Up Split
                    </span>
                    <span className="font-headline-md text-headline-md text-on-surface font-bold">+₹110</span>
                  </div>
                  <button
                    onClick={() => showToast('Match #1024 verified kill telemetry report loaded.', 'info')}
                    className="p-2 rounded bg-surface-container-highest text-on-surface-variant hover:text-[#00dbe9] transition-colors cursor-pointer"
                    title="Download Combat Replay"
                  >
                    <span className="material-symbols-outlined text-xl">description</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* PANE 2: Game IDs & Verification */}
        {activePane === 'game-ids' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-surface-container p-6 rounded shadow-md flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary-container text-2xl">sports_esports</span>
                  <h3 className="font-headline-sm text-headline-sm uppercase text-on-surface font-bold">
                    Bound Game Profile
                  </h3>
                </div>
                <span className="bg-tertiary-container/20 text-[#00dbe9] px-2.5 py-0.5 rounded font-label-sm text-label-sm uppercase font-bold">
                  Active Binding
                </span>
              </div>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                Your Garena Free Fire account is linked for automated room entry, live roster sync, and direct kill telemetry audits.
              </p>
              <div className="bg-[#191c22] p-4 rounded flex flex-col gap-2">
                <div className="flex items-center justify-between font-label-md text-label-md">
                  <span className="text-outline uppercase font-semibold">Registered In-Game Name (IGN)</span>
                  <span className="text-on-surface font-bold">{ign}</span>
                </div>
                <div className="h-px bg-surface-container-highest"></div>
                <div className="flex items-center justify-between font-label-md text-label-md">
                  <span className="text-outline uppercase font-semibold">Free Fire UID</span>
                  <span className="font-mono text-primary font-bold">2849104821</span>
                </div>
                <div className="h-px bg-surface-container-highest"></div>
                <div className="flex items-center justify-between font-label-md text-label-md">
                  <span className="text-outline uppercase font-semibold">Region Server</span>
                  <span className="text-on-surface font-semibold">India (IN) • South Asia</span>
                </div>
                <div className="h-px bg-surface-container-highest"></div>
                <div className="flex items-center justify-between font-label-md text-label-md">
                  <span className="text-outline uppercase font-semibold">Guild Link</span>
                  <span className="text-secondary font-bold">VORTEX_ESPORTS (#90214)</span>
                </div>
              </div>
              <div className="flex items-center justify-between pt-1">
                <span className="font-label-sm text-label-sm text-outline">Last In-Game Sync: 12 minutes ago</span>
                <button
                  type="button"
                  onClick={() => showToast('Free Fire in-game telemetry synchronized with Garena API.')}
                  className="px-4 py-1.5 rounded bg-surface-container-high text-on-surface font-label-sm text-label-sm uppercase hover:bg-surface-container-highest transition-colors font-bold cursor-pointer"
                >
                  Re-verify IGN
                </button>
              </div>
            </div>

            {/* Right: Anti-Cheat & Identity KYC */}
            <div className="bg-surface-container p-6 rounded shadow-md flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#00dbe9] text-2xl">verified_user</span>
                  <h3 className="font-headline-sm text-headline-sm uppercase text-on-surface font-bold">
                    Security &amp; Anti-Cheat KYC
                  </h3>
                </div>
                <div className="flex items-center gap-1 bg-[#00dbe9]/20 text-tertiary-fixed px-2.5 py-0.5 rounded font-label-sm text-label-sm uppercase font-bold">
                  <span className="material-symbols-outlined text-sm">check_circle</span>
                  <span>Verified Status</span>
                </div>
              </div>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                Player telemetry verified against Ignite Protocol anti-cheat standard V3.8. Authorized for cash tournaments and official regional qualifiers.
              </p>
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between bg-[#191c22] p-2.5 rounded">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[#00dbe9] text-xl">phonelink_lock</span>
                    <div className="flex flex-col">
                      <span className="font-label-md text-label-md text-on-surface font-bold">Hardware ID Lockdown</span>
                      <span className="font-label-sm text-label-sm text-outline">ROG Phone 6 (Verified Mobile Device)</span>
                    </div>
                  </div>
                  <span className="font-label-sm text-label-sm text-[#00dbe9] uppercase font-bold">Secured</span>
                </div>
                <div className="flex items-center justify-between bg-[#191c22] p-2.5 rounded">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[#00dbe9] text-xl">gavel</span>
                    <div className="flex flex-col">
                      <span className="font-label-md text-label-md text-on-surface font-bold">Fair Play Reputation</span>
                      <span className="font-label-sm text-label-sm text-outline">Zero penalty strikes • 100% Trust score</span>
                    </div>
                  </div>
                  <span className="font-label-sm text-label-sm text-secondary uppercase font-bold">100 / 100</span>
                </div>
                <div className="flex items-center justify-between bg-[#191c22] p-2.5 rounded">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-[#00dbe9] text-xl">credit_card</span>
                    <div className="flex flex-col">
                      <span className="font-label-md text-label-md text-on-surface font-bold">Government ID Verification</span>
                      <span className="font-label-sm text-label-sm text-outline">Aadhaar/PAN card verified for cash prizes</span>
                    </div>
                  </div>
                  <span className="font-label-sm text-label-sm text-tertiary-fixed uppercase font-bold">Approved</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* PANE 3: Withdrawal Settings */}
        {activePane === 'withdrawal' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-surface-container p-6 rounded shadow-md flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary-container text-2xl">account_balance</span>
                  <h3 className="font-headline-sm text-headline-sm uppercase text-on-surface font-bold">
                    Prize Withdrawal Channel
                  </h3>
                </div>
                <span className="bg-primary-container/20 text-primary-container px-2.5 py-0.5 rounded font-label-sm text-label-sm uppercase font-bold">
                  Instant UPI Gateway
                </span>
              </div>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                Tournament payouts and match kill bounties are transferred straight to your configured UPI address within 120 seconds of match arbiter settlement.
              </p>

              {/* Bound UPI Card */}
              <div className="bg-[#191c22] p-4 rounded flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded bg-surface-container flex items-center justify-center text-secondary">
                    <span className="material-symbols-outlined text-2xl">qr_code_2</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="font-label-sm text-label-sm uppercase text-outline font-semibold">Active Linked UPI VPA</span>
                    <span className="font-headline-sm text-headline-sm text-on-surface font-bold">
                      {upiId || 'player@okaxis'}
                    </span>
                    <span className="font-body-sm text-body-sm text-[#00dbe9]">Verified Name: ALPHA SHARMA</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsEditUpiOpen(true)}
                  className="px-4 py-2 rounded bg-surface-container-high text-on-surface hover:bg-surface-container-highest transition-colors font-label-md text-label-md uppercase font-bold cursor-pointer"
                >
                  Change UPI
                </button>
              </div>

              {/* Limits and Payout Rules */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                <div className="bg-[#191c22] p-2 rounded flex flex-col gap-1">
                  <span className="font-label-sm text-label-sm text-outline uppercase font-semibold">Min. Withdrawal</span>
                  <span className="font-headline-sm text-headline-sm text-on-surface font-bold">₹50</span>
                  <span className="font-body-sm text-body-sm text-on-surface-variant">Zero platform fees</span>
                </div>
                <div className="bg-[#191c22] p-2 rounded flex flex-col gap-1">
                  <span className="font-label-sm text-label-sm text-outline uppercase font-semibold">Max Daily Limit</span>
                  <span className="font-headline-sm text-headline-sm text-on-surface font-bold">₹25,000</span>
                  <span className="font-body-sm text-body-sm text-on-surface-variant">Tier 2 verified limit</span>
                </div>
                <div className="bg-[#191c22] p-2 rounded flex flex-col gap-1">
                  <span className="font-label-sm text-label-sm text-outline uppercase font-semibold">Transfer SLA</span>
                  <span className="font-headline-sm text-headline-sm text-[#00dbe9] font-bold">&lt; 2 Minutes</span>
                  <span className="font-body-sm text-body-sm text-on-surface-variant">Automated UPI IMPS</span>
                </div>
              </div>

              {/* Instant Cashout Action Bar */}
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4 bg-[#0b0e14] p-4 rounded">
                <div className="flex flex-col">
                  <span className="font-label-sm text-label-sm uppercase text-outline font-semibold">
                    Available Withdrawable Balance
                  </span>
                  <div className="flex items-baseline gap-2">
                    <span className="font-headline-lg text-headline-lg text-primary font-bold">₹8,940</span>
                    <span className="font-label-sm text-label-sm text-on-surface-variant">(No locks)</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleCashout}
                  className="w-full sm:w-auto px-8 py-2.5 rounded bg-[#ff5e00] hover:bg-[#ffa504] text-[#531900] font-label-md text-label-md uppercase font-bold tracking-wider transition-all shadow-[0_0_16px_rgba(255,94,0,0.35)] flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span className="material-symbols-outlined text-lg">bolt</span>
                  <span>Withdraw to UPI</span>
                </button>
              </div>
            </div>

            {/* Right: Recent Cashouts Feed */}
            <div className="bg-surface-container p-6 rounded shadow-md flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <h4 className="font-headline-sm text-headline-sm uppercase text-on-surface font-bold">
                  Recent Cashouts
                </h4>
                <span className="material-symbols-outlined text-outline">receipt_long</span>
              </div>
              <div className="flex flex-col gap-2">
                <div className="bg-[#191c22] p-2.5 rounded flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="font-label-md text-label-md text-on-surface font-bold">₹2,000 Payout</span>
                    <span className="font-label-sm text-label-sm text-outline">Oct 22 • UPI IMPS</span>
                  </div>
                  <span className="font-label-sm text-label-sm text-[#00dbe9] uppercase font-bold">Success</span>
                </div>
                <div className="bg-[#191c22] p-2.5 rounded flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="font-label-md text-label-md text-on-surface font-bold">₹1,500 Payout</span>
                    <span className="font-label-sm text-label-sm text-outline">Oct 19 • UPI IMPS</span>
                  </div>
                  <span className="font-label-sm text-label-sm text-[#00dbe9] uppercase font-bold">Success</span>
                </div>
                <div className="bg-[#191c22] p-2.5 rounded flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="font-label-md text-label-md text-on-surface font-bold">₹3,400 Payout</span>
                    <span className="font-label-sm text-label-sm text-outline">Oct 12 • UPI IMPS</span>
                  </div>
                  <span className="font-label-sm text-label-sm text-[#00dbe9] uppercase font-bold">Success</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => showToast('Financial statement generated. Dispatched to registered email.', 'info')}
                className="font-label-sm text-label-sm uppercase text-primary hover:underline text-center pt-1 block font-bold cursor-pointer"
              >
                Download Full Statement (PDF)
              </button>
            </div>
          </div>
        )}
      </section>
    </div>
  );
};
