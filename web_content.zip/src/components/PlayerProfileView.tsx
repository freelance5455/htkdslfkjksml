import React, { useState } from 'react';
import {
  User,
  Trophy,
  Award,
  Calendar,
  Flame,
  TrendingUp,
  Target,
  Edit2,
  Crown,
  Medal,
  CheckCircle,
  ChevronRight,
} from 'lucide-react';
import type { Player, Category, Season, DailyRecord, AppState } from '../types/index.ts';
import { EvolutionCharts } from './EvolutionCharts.tsx';
import { calculatePlayerAchievements } from '../utils/achievementsLogic.ts';

interface PlayerProfileViewProps {
  player: Player;
  categories: Category[];
  seasons: Season[];
  dailyRecords: DailyRecord[];
  state: AppState;
  onUpdatePhoto: (playerId: string, url: string) => void;
  onNavigateToAchievements: (playerId: string) => void;
  onSelectPastSeasonDetail: (season: Season) => void;
}

export const PlayerProfileView: React.FC<PlayerProfileViewProps> = ({
  player,
  categories,
  seasons,
  dailyRecords,
  state,
  onUpdatePhoto,
  onNavigateToAchievements,
  onSelectPastSeasonDetail,
}) => {
  const [isEditingPhoto, setIsEditingPhoto] = useState(false);
  const [photoInput, setPhotoInput] = useState(player.avatarUrl || '');

  // Active categories
  const activeCategories = categories.filter((c) => c.status === 'active');

  // Compute player records
  const playerDailyRecords = dailyRecords.filter((r) => r.playerId === player.id && r.trained);
  const totalDaysTrained = new Set(playerDailyRecords.map((r) => r.localDate)).size;
  const allTimeBestStreak = playerDailyRecords.length > 0 ? Math.max(...playerDailyRecords.map((r) => r.bestStreak)) : 0;

  // Trophies / titles
  let totalTitles = 0;
  for (const s of seasons) {
    if (s.snapshots) {
      for (const results of Object.values(s.snapshots)) {
        const res = results.find((r) => r.playerId === player.id);
        if (res?.isChampion) totalTitles++;
      }
    }
  }

  // Achievements calculation
  const achievements = calculatePlayerAchievements(player.id, state);
  const unlockedBadges = achievements.filter((a) => a.isUnlocked);

  const handleSavePhoto = () => {
    onUpdatePhoto(player.id, photoInput.trim());
    setIsEditingPhoto(false);
  };

  return (
    <div className="space-y-6">
      {/* Player Header Card */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5">
          {/* Avatar with edit button */}
          <div className="relative">
            {player.avatarUrl ? (
              <img
                src={player.avatarUrl}
                alt={player.name}
                className="w-24 h-24 rounded-2xl object-cover border-2 border-neutral-700 shadow-xl"
              />
            ) : (
              <div
                className="w-24 h-24 rounded-2xl flex items-center justify-center text-3xl font-black text-white shadow-xl"
                style={{ backgroundColor: player.color || '#10b981' }}
              >
                {player.name.charAt(0).toUpperCase()}
              </div>
            )}
            <button
              onClick={() => setIsEditingPhoto(!isEditingPhoto)}
              title="Alterar foto de perfil"
              aria-label="Alterar foto de perfil"
              className="absolute -bottom-2 -right-2 p-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-white shadow-lg transition-colors"
            >
              <Edit2 className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Profile details */}
          <div className="flex-1 text-center sm:text-left">
            <div className="flex flex-col sm:flex-row sm:items-center gap-2 mb-1">
              <h2 className="text-2xl font-black text-white">{player.name}</h2>
              {player.role === 'admin' ? (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950 border border-emerald-800 text-emerald-400 self-center sm:self-auto">
                  Organizador do Grupo
                </span>
              ) : (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-neutral-800 border border-neutral-700 text-neutral-400 self-center sm:self-auto">
                  Competidor Oficial
                </span>
              )}
            </div>

            <p className="text-xs text-neutral-400">
              Membro ativo desde outubro de 2026 · {totalDaysTrained} dias de treinos registrados
            </p>

            {/* Quick Badges row */}
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mt-4">
              {totalTitles > 0 && (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-950/80 border border-amber-800 text-amber-300 text-xs font-bold">
                  <Crown className="w-3.5 h-3.5 text-amber-400" />
                  <span>{totalTitles} {totalTitles === 1 ? 'Título Semanal' : 'Títulos Semanais'}</span>
                </span>
              )}
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-950/80 border border-emerald-800 text-emerald-300 text-xs font-bold">
                <Target className="w-3.5 h-3.5 text-emerald-400" />
                <span>Recorde Geral: {allTimeBestStreak}</span>
              </span>
              <button
                onClick={() => onNavigateToAchievements(player.id)}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-300 text-xs font-bold transition-colors"
              >
                <Award className="w-3.5 h-3.5 text-purple-400" />
                <span>{unlockedBadges.length} Conquistas</span>
                <ChevronRight className="w-3 h-3 text-neutral-500" />
              </button>
            </div>
          </div>
        </div>

        {/* Photo input dropdown if editing */}
        {isEditingPhoto && (
          <div className="mt-5 p-4 rounded-xl bg-neutral-950 border border-neutral-700/80">
            <label className="block text-xs font-bold text-neutral-300 mb-1">
              Link da Imagem / Foto de Perfil:
            </label>
            <div className="flex gap-2">
              <input
                type="url"
                value={photoInput}
                onChange={(e) => setPhotoInput(e.target.value)}
                placeholder="https://exemplo.com/minha-foto.jpg"
                className="flex-1 px-3 py-2 text-xs bg-neutral-900 border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-emerald-500"
              />
              <button
                onClick={handleSavePhoto}
                className="px-4 py-2 text-xs font-bold bg-emerald-500 text-neutral-950 rounded-lg hover:bg-emerald-400"
              >
                Salvar
              </button>
              <button
                onClick={() => setIsEditingPhoto(false)}
                className="px-3 py-2 text-xs font-bold bg-neutral-800 text-neutral-400 rounded-lg hover:bg-neutral-700"
              >
                Cancelar
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Detailed Evolution Charts */}
      <EvolutionCharts
        playerId={player.id}
        categories={categories}
        seasons={seasons}
        dailyRecords={dailyRecords}
      />

      {/* Unlocked Badges Preview */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-extrabold text-white">Distintivos & Conquistas Recentes</h3>
          </div>
          <button
            onClick={() => onNavigateToAchievements(player.id)}
            className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
          >
            <span>Ver Todas ({achievements.length})</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {unlockedBadges.length === 0 ? (
          <p className="text-xs text-neutral-500 py-3 text-center">
            Nenhuma conquista desbloqueada ainda. Complete treinos e registre sequências para ganhar distintivos!
          </p>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {unlockedBadges.slice(0, 4).map((badge) => (
              <div
                key={badge.id}
                className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 flex flex-col justify-between"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] font-extrabold uppercase px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                    {badge.rarity}
                  </span>
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <span className="text-xs font-bold text-white leading-tight">
                  {badge.title}
                </span>
                <span className="text-[10px] text-neutral-400 mt-1 line-clamp-2">
                  {badge.description}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Recent Daily Records Table */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5">
        <h3 className="text-sm font-extrabold text-white mb-3 flex items-center gap-2">
          <Calendar className="w-4 h-4 text-emerald-400" />
          <span>Registros Diários Recentes</span>
        </h3>

        {playerDailyRecords.length === 0 ? (
          <p className="text-xs text-neutral-500 py-4 text-center">
            Nenhum registro de treino encontrado para este jogador.
          </p>
        ) : (
          <div className="space-y-2">
            {playerDailyRecords.slice(-5).reverse().map((record) => {
              const cat = categories.find((c) => c.id === record.categoryId);
              return (
                <div
                  key={record.id}
                  className="flex items-center justify-between p-3 rounded-xl bg-neutral-950 border border-neutral-800/80 text-xs"
                >
                  <div className="flex items-center gap-3">
                    <span className="font-mono-numbers text-neutral-400 font-bold">
                      {record.localDate}
                    </span>
                    <span className="text-neutral-500">·</span>
                    <span className="font-medium text-neutral-300">
                      {cat ? cat.name : record.categoryId}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-neutral-500 text-[11px]">Melhor sequência:</span>
                    <span className="font-mono-numbers font-extrabold text-white text-sm bg-neutral-900 px-2 py-0.5 rounded border border-neutral-800">
                      {record.bestStreak}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
