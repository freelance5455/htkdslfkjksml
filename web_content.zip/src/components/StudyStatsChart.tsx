import React, { useMemo, useState } from 'react';
import type { DailyStudyBreakdown, Language } from '../types/study';

interface StudyStatsChartProps {
  lang: Language;
  breakdown: DailyStudyBreakdown;
  todayKey: string;
  dailyGoalMinutes: number;
}

const BN_DAYS = ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'];
const EN_DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

function formatDuration(totalSeconds: number, lang: Language): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const hours = Math.floor(safe / 3600);
  const mins = Math.floor((safe % 3600) / 60);
  const secs = safe % 60;
  if (lang === 'en') {
    if (hours === 0 && mins === 0) return `${secs}s`;
    if (hours === 0) return `${mins}m`;
    if (mins === 0) return `${hours}h`;
    return `${hours}h ${mins}m`;
  }
  if (hours === 0 && mins === 0) return `${secs} সে.`;
  if (hours === 0) return `${mins} মি.`;
  if (mins === 0) return `${hours} ঘণ্টা`;
  return `${hours} ঘ. ${mins} মি.`;
}

function formatShortLabel(totalSeconds: number, lang: Language): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  if (safe === 0) return lang === 'bn' ? '০ মি.' : '0m';
  if (safe < 60) return lang === 'bn' ? `${safe}সে` : `${safe}s`;
  const mins = Math.round(safe / 60);
  if (mins < 60) return lang === 'bn' ? `${mins}মি` : `${mins}m`;
  const hrs = (safe / 3600).toFixed(1);
  return lang === 'bn' ? `${hrs}ঘ` : `${hrs}h`;
}

function getDateKeyOffset(
  daysBack: number,
  lang: Language
): { key: string; dayLabel: string; dateLabel: string } {
  const d = new Date();
  d.setDate(d.getDate() - daysBack);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return {
    key: `${y}-${m}-${day}`,
    dayLabel:
      daysBack === 0
        ? lang === 'bn'
          ? 'আজ'
          : 'Today'
        : (lang === 'bn' ? BN_DAYS : EN_DAYS)[d.getDay()],
    dateLabel: `${day}/${m}`,
  };
}

export const StudyStatsChart: React.FC<StudyStatsChartProps> = ({
  lang,
  breakdown,
  todayKey,
  dailyGoalMinutes,
}) => {
  const [selectedDayKey, setSelectedDayKey] = useState<string>(todayKey);
  const isBn = lang === 'bn';

  const days = useMemo(() => {
    const list = [];
    for (let i = 6; i >= 0; i--) {
      const info = getDateKeyOffset(i, lang);
      const entry = breakdown[info.key] || { timer: 0, pomodoro: 0 };
      const timerSec = Math.max(0, entry.timer || 0);
      const pomodoroSec = Math.max(0, entry.pomodoro || 0);
      const totalSec = timerSec + pomodoroSec;
      list.push({
        ...info,
        timerSec,
        pomodoroSec,
        totalSec,
      });
    }
    return list;
  }, [breakdown, lang]);

  const maxSeconds = useMemo(() => {
    return Math.max(...days.map((d) => d.totalSec), dailyGoalMinutes * 60, 1800);
  }, [days, dailyGoalMinutes]);

  const todayEntry = days[days.length - 1];
  const weekTimerSec = days.reduce((acc, d) => acc + d.timerSec, 0);
  const weekPomodoroSec = days.reduce((acc, d) => acc + d.pomodoroSec, 0);
  const weekTotalSec = weekTimerSec + weekPomodoroSec;
  const selectedDay = days.find((d) => d.key === selectedDayKey) || todayEntry;

  return (
    <div className="mx-auto max-w-3xl">
      <section className="liquid-glass rounded-3xl p-5 sm:p-8">
        <div className="flex flex-col gap-3 border-b border-white/12 pb-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-lg font-semibold text-white">
              {isBn ? 'টাইমার ও পোমোডোরো গ্রাফ' : 'Timer & Pomodoro Graph'}
            </h2>
            <div className="mt-1.5 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-slate-300 tabular-nums">
              <span className="font-semibold text-white">
                {isBn ? 'আজ' : 'Today'}: {formatDuration(todayEntry.totalSec, lang)}
              </span>
              <span aria-hidden="true" className="text-slate-500">
                ·
              </span>
              <span className="text-violet-200">
                {isBn ? 'পোমোডোরো' : 'Pomodoro'}: {formatDuration(weekPomodoroSec, lang)}
              </span>
              <span aria-hidden="true" className="text-slate-500">
                ·
              </span>
              <span className="text-sky-200">
                {isBn ? 'টাইমার' : 'Timer'}: {formatDuration(weekTimerSec, lang)}
              </span>
              <span aria-hidden="true" className="text-slate-500">
                ·
              </span>
              <span>
                {isBn ? '৭ দিন' : '7 Days'}: {formatDuration(weekTotalSec, lang)}
              </span>
            </div>
          </div>

          {/* Clean Legend */}
          <div className="flex items-center gap-4 text-xs font-medium text-slate-200">
            <span className="inline-flex items-center gap-1.5 whitespace-nowrap">
              <span className="h-2.5 w-2.5 rounded-sm bg-violet-400" aria-hidden="true" />
              <span>{isBn ? 'পোমোডোরো' : 'Pomodoro'}</span>
            </span>
            <span className="inline-flex items-center gap-1.5 whitespace-nowrap">
              <span className="h-2.5 w-2.5 rounded-sm bg-sky-400" aria-hidden="true" />
              <span>{isBn ? 'টাইমার' : 'Timer'}</span>
            </span>
          </div>
        </div>

        {/* Selected Day Breakdown */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-300 tabular-nums">
          <span className="font-semibold text-white">
            {selectedDay.dayLabel} ({selectedDay.dateLabel})
          </span>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
            <span className="text-violet-200">
              {isBn ? 'পোমোডোরো' : 'Pomodoro'}: {formatDuration(selectedDay.pomodoroSec, lang)}
            </span>
            <span aria-hidden="true" className="text-slate-500">
              ·
            </span>
            <span className="text-sky-200">
              {isBn ? 'টাইমার' : 'Timer'}: {formatDuration(selectedDay.timerSec, lang)}
            </span>
          </div>
        </div>

        {/* 7-Day Stacked Liquid Glass Bar Chart (Pomodoro + Timer) */}
        <div
          className="mt-5 grid grid-cols-7 items-end gap-2 sm:gap-4"
          role="img"
          aria-label={isBn ? 'টাইমার ও পোমোডোরো গ্রাফ' : 'Timer and Pomodoro graph'}
        >
          {days.map((day) => {
            const totalPct =
              day.totalSec > 0 ? Math.max(8, Math.round((day.totalSec / maxSeconds) * 100)) : 4;
            const pomoShare = day.totalSec > 0 ? (day.pomodoroSec / day.totalSec) * 100 : 0;
            const timerShare = day.totalSec > 0 ? (day.timerSec / day.totalSec) * 100 : 0;
            const isSelected = day.key === selectedDay.key;
            const isToday = day.key === todayKey;

            return (
              <button
                key={day.key}
                type="button"
                onClick={() => setSelectedDayKey(day.key)}
                className="group flex flex-col items-center gap-2 text-center focus-visible:outline-none"
              >
                <span className="font-mono-tabular text-[11px] font-medium text-slate-300 transition group-hover:text-white">
                  {formatShortLabel(day.totalSec, lang)}
                </span>

                <div
                  className={`relative flex h-36 w-full max-w-[44px] items-end overflow-hidden rounded-2xl border p-1 transition ${
                    isSelected
                      ? 'border-white/35 bg-white/[0.09]'
                      : 'border-white/14 bg-white/[0.04]'
                  }`}
                >
                  {day.totalSec === 0 ? (
                    <div className="h-[4%] w-full rounded-xl bg-white/15" />
                  ) : (
                    <div
                      className="flex w-full flex-col justify-end overflow-hidden rounded-xl transition-all duration-300"
                      style={{ height: `${totalPct}%` }}
                    >
                      {day.pomodoroSec > 0 && (
                        <div
                          className="w-full bg-gradient-to-t from-violet-500 to-fuchsia-400"
                          style={{ height: `${pomoShare}%` }}
                        />
                      )}
                      {day.timerSec > 0 && (
                        <div
                          className="w-full bg-gradient-to-t from-sky-500 to-cyan-300"
                          style={{ height: `${timerShare}%` }}
                        />
                      )}
                    </div>
                  )}
                </div>

                <div className="leading-tight">
                  <span
                    className={`block text-xs font-semibold ${
                      isToday || isSelected ? 'text-white' : 'text-slate-300'
                    }`}
                  >
                    {day.dayLabel}
                  </span>
                  <span className="font-mono-tabular block text-[10px] text-slate-400">
                    {day.dateLabel}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </section>
    </div>
  );
};
