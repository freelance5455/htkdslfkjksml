import React, { useState, useEffect, useRef } from 'react';
import { X, Upload, Image as ImageIcon, Check, Sparkles, AlertCircle } from 'lucide-react';
import { Product, Category, Room, CurrencyCode } from '../types';
import { CURRENCIES, formatPrice } from '../utils/currency';

interface ProductFormModalProps {
  isOpen: boolean;
  productToEdit?: Product | null;
  activeCurrency: CurrencyCode;
  onClose: () => void;
  onSaveProduct: (product: Product) => void;
}

const CATEGORIES: Category[] = [
  'Bedding & Linens',
  'Kitchen & Dining',
  'Fragrance & Oud',
  'Bath & Wellness',
  'Living & Storage'
];

const ROOMS: Room[] = [
  'Bedroom',
  'Dining Room',
  'Kitchen',
  'Living Room',
  'Bathroom'
];

export const ProductFormModal: React.FC<ProductFormModalProps> = ({
  isOpen,
  productToEdit,
  activeCurrency,
  onClose,
  onSaveProduct
}) => {
  if (!isOpen) return null;

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form states
  const [name, setName] = useState('');
  const [arabicSubtitle, setArabicSubtitle] = useState('');
  const [category, setCategory] = useState<Category>('Living & Storage');
  const [room, setRoom] = useState<Room>('Living Room');
  const [priceInput, setPriceInput] = useState('');
  const [originalPriceInput, setOriginalPriceInput] = useState('');
  const [imagePreview, setImagePreview] = useState('');
  const [description, setDescription] = useState('');
  const [materials, setMaterials] = useState('');
  const [dimensions, setDimensions] = useState('');
  const [careInstructions, setCareInstructions] = useState('');
  const [stockCount, setStockCount] = useState('10');
  const [inStock, setInStock] = useState(true);
  const [badge, setBadge] = useState('New Arrival');
  const [featuresText, setFeaturesText] = useState('');
  const [error, setError] = useState('');

  const currencyConfig = CURRENCIES[activeCurrency] || CURRENCIES.USD;

  // Initialize form when opening for edit or new
  useEffect(() => {
    if (productToEdit) {
      setName(productToEdit.name);
      setArabicSubtitle(productToEdit.arabicSubtitle || '');
      setCategory(productToEdit.category);
      setRoom(productToEdit.room);
      // Show price in current currency
      const currentCurrPrice = Math.round(productToEdit.priceUsd * currencyConfig.rate);
      setPriceInput(currentCurrPrice.toString());
      if (productToEdit.originalPriceUsd) {
        setOriginalPriceInput(Math.round(productToEdit.originalPriceUsd * currencyConfig.rate).toString());
      } else {
        setOriginalPriceInput('');
      }
      setImagePreview(productToEdit.image);
      setDescription(productToEdit.description);
      setMaterials(productToEdit.materials);
      setDimensions(productToEdit.dimensions);
      setCareInstructions(productToEdit.careInstructions);
      setStockCount(productToEdit.stockCount.toString());
      setInStock(productToEdit.inStock);
      setBadge(productToEdit.badge || '');
      setFeaturesText(productToEdit.features.join('\n'));
    } else {
      // Reset for new product
      setName('');
      setArabicSubtitle('');
      setCategory('Living & Storage');
      setRoom('Living Room');
      setPriceInput('');
      setOriginalPriceInput('');
      setImagePreview('');
      setDescription('');
      setMaterials('');
      setDimensions('');
      setCareInstructions('');
      setStockCount('15');
      setInStock(true);
      setBadge('New Arrival');
      setFeaturesText('Handcrafted with premium materials\nTested for daily comfort\nHeirloom quality finish');
    }
    setError('');
  }, [productToEdit, isOpen, activeCurrency]);

  // Handle local image file upload from device
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setError('Please upload an image file (PNG, JPG, WebP, etc.)');
      return;
    }

    // Limit file size to 3MB for local storage optimization
    if (file.size > 4 * 1024 * 1024) {
      setError('Image file is larger than 4MB. Please choose a smaller photo.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setImagePreview(dataUrl);
      setError('');
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please enter a product title.');
      return;
    }

    const parsedPrice = parseFloat(priceInput);
    if (isNaN(parsedPrice) || parsedPrice <= 0) {
      setError(`Please enter a valid price in ${currencyConfig.code}.`);
      return;
    }

    if (!imagePreview) {
      setError('Please upload a product photo from your device.');
      return;
    }

    // Convert price back to base USD for consistent multi-currency exchange
    const priceUsd = parsedPrice / currencyConfig.rate;
    const parsedOriginalPrice = parseFloat(originalPriceInput);
    const originalPriceUsd = !isNaN(parsedOriginalPrice) && parsedOriginalPrice > 0
      ? parsedOriginalPrice / currencyConfig.rate
      : undefined;

    const featuresArray = featuresText
      .split('\n')
      .map((f) => f.trim())
      .filter((f) => f.length > 0);

    const newProduct: Product = {
      id: productToEdit ? productToEdit.id : `custom-${Date.now()}`,
      name: name.trim(),
      arabicSubtitle: arabicSubtitle.trim() || undefined,
      category,
      room,
      priceUsd: Math.round(priceUsd * 100) / 100,
      originalPriceUsd: originalPriceUsd ? Math.round(originalPriceUsd * 100) / 100 : undefined,
      rating: productToEdit ? productToEdit.rating : 5.0,
      reviewsCount: productToEdit ? productToEdit.reviewsCount : 0,
      image: imagePreview,
      description: description.trim() || 'Custom curated essential for modern sanctuaries.',
      materials: materials.trim() || 'Hand-selected natural artisanal materials',
      dimensions: dimensions.trim() || 'Standard artisanal sizing',
      inStock,
      stockCount: parseInt(stockCount, 10) || 10,
      careInstructions: careInstructions.trim() || 'Spot clean or hand wash gently with mild detergent.',
      features: featuresArray.length > 0 ? featuresArray : ['Handcrafted essential', 'Quality assured'],
      badge: badge.trim() || undefined
    };

    onSaveProduct(newProduct);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-stone-900/65 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-2xl max-w-3xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-stone-200 relative flex flex-col p-6 sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-stone-200">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-stone-100 rounded text-stone-800">
                <Upload className="w-4 h-4 text-stone-900" />
              </span>
              <h2 className="font-serif text-2xl font-semibold text-stone-900">
                {productToEdit ? 'Edit Product Details' : 'Upload Your Choice Product'}
              </h2>
            </div>
            <p className="text-xs text-stone-500 mt-1">
              Add your own custom products with photos from your phone or computer. Saved directly on your device.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-900 rounded-full hover:bg-stone-100 cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-center gap-2 font-medium">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="mt-6 space-y-6">
          {/* Section 1: Photo Upload */}
          <div>
            <label className="block text-xs font-semibold text-stone-800 mb-2">
              Product Photo (Upload from your device) *
            </label>

            <div className="flex flex-col sm:flex-row items-center gap-6">
              {/* Image Preview Box */}
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="w-full sm:w-44 h-44 rounded-xl border-2 border-dashed border-stone-300 hover:border-stone-500 bg-stone-50 flex flex-col items-center justify-center cursor-pointer overflow-hidden transition-all relative group"
              >
                {imagePreview ? (
                  <>
                    <img
                      src={imagePreview}
                      alt="Uploaded preview"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-stone-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white text-xs font-medium">
                      Change Photo
                    </div>
                  </>
                ) : (
                  <div className="text-center p-4">
                    <ImageIcon className="w-8 h-8 text-stone-400 mx-auto mb-2" />
                    <span className="text-xs font-semibold text-stone-700 block">Click to upload</span>
                    <span className="text-[10px] text-stone-400">JPG, PNG, or WebP</span>
                  </div>
                )}
              </div>

              {/* Actions & Preset buttons */}
              <div className="flex-1 space-y-3 w-full">
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  onChange={handleImageFileChange}
                  className="hidden"
                />

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-4 py-2 bg-stone-900 text-white rounded-lg text-xs font-medium hover:bg-stone-800 flex items-center gap-1.5 cursor-pointer shadow-2xs"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Choose Photo from Device</span>
                  </button>

                  {imagePreview && (
                    <button
                      type="button"
                      onClick={() => setImagePreview('')}
                      className="px-3 py-2 text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-lg text-xs font-medium cursor-pointer"
                    >
                      Remove Photo
                    </button>
                  )}
                </div>

                <div className="pt-2">
                  <p className="text-[11px] text-stone-500">Or use a sample image asset:</p>
                  <div className="flex flex-wrap gap-2 mt-1.5">
                    <button
                      type="button"
                      onClick={() => setImagePreview('/src/assets/images/product_linen_bedding_1792296361540.jpg')}
                      className="text-[11px] px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded border border-stone-200 cursor-pointer"
                    >
                      Linen Bedding
                    </button>
                    <button
                      type="button"
                      onClick={() => setImagePreview('/src/assets/images/product_ceramic_dinnerware_1792296362815.jpg')}
                      className="text-[11px] px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded border border-stone-200 cursor-pointer"
                    >
                      Ceramic Set
                    </button>
                    <button
                      type="button"
                      onClick={() => setImagePreview('/src/assets/images/product_oud_diffuser_1792296361488.jpg')}
                      className="text-[11px] px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded border border-stone-200 cursor-pointer"
                    >
                      Oud Diffuser
                    </button>
                    <button
                      type="button"
                      onClick={() => setImagePreview('/src/assets/images/hero_home_essentials_1792296360356.jpg')}
                      className="text-[11px] px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded border border-stone-200 cursor-pointer"
                    >
                      Living Table
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Product Titles & Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-stone-800 mb-1">Product Title *</label>
              <input
                type="text"
                required
                placeholder="e.g. Royal Cashmere Throw Blanket"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-800 mb-1">Arabic or Urdu Title (Optional)</label>
              <input
                type="text"
                placeholder="e.g. بطانية الكشمير الملكية"
                value={arabicSubtitle}
                onChange={(e) => setArabicSubtitle(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
              />
            </div>
          </div>

          {/* Section 3: Categories & Pricing */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-stone-800 mb-1">Category *</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as Category)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900 cursor-pointer"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-800 mb-1">Room Placement *</label>
              <select
                value={room}
                onChange={(e) => setRoom(e.target.value as Room)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900 cursor-pointer"
              >
                {ROOMS.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-800 mb-1">
                Selling Price ({currencyConfig.code}) *
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400 text-xs font-semibold">
                  {currencyConfig.symbol.trim()}
                </span>
                <input
                  type="number"
                  step="any"
                  required
                  placeholder="e.g. 85"
                  value={priceInput}
                  onChange={(e) => setPriceInput(e.target.value)}
                  className="w-full pl-8 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900 font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-800 mb-1">
                Original Price (Optional)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400 text-xs">
                  {currencyConfig.symbol.trim()}
                </span>
                <input
                  type="number"
                  step="any"
                  placeholder="e.g. 110"
                  value={originalPriceInput}
                  onChange={(e) => setOriginalPriceInput(e.target.value)}
                  className="w-full pl-8 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Stock & Badge */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-stone-800 mb-1">Stock Quantity</label>
              <input
                type="number"
                min="0"
                value={stockCount}
                onChange={(e) => setStockCount(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-800 mb-1">Promotional Badge</label>
              <input
                type="text"
                placeholder="e.g. Handmade, Exclusive, Bestseller"
                value={badge}
                onChange={(e) => setBadge(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
              />
            </div>

            <div className="flex items-center pt-5">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={inStock}
                  onChange={(e) => setInStock(e.target.checked)}
                  className="rounded border-stone-300 text-stone-900 focus:ring-0 cursor-pointer"
                />
                <span className="text-xs font-semibold text-stone-800">Available For Instant Order</span>
              </label>
            </div>
          </div>

          {/* Section 5: Description & Specs */}
          <div>
            <label className="block text-xs font-semibold text-stone-800 mb-1">Description</label>
            <textarea
              rows={2}
              placeholder="Tell customers about the craftsmanship, feel, and aesthetic qualities of this essential..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-stone-800 mb-1">Materials</label>
              <input
                type="text"
                placeholder="e.g. 100% Belgian Flax, Natural Walnut"
                value={materials}
                onChange={(e) => setMaterials(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-stone-800 mb-1">Dimensions / Sizing</label>
              <input
                type="text"
                placeholder="e.g. 200 × 150 cm | 1.8 kg"
                value={dimensions}
                onChange={(e) => setDimensions(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-stone-800 mb-1">Care Instructions</label>
              <input
                type="text"
                placeholder="e.g. Machine wash gentle, line dry in shade"
                value={careInstructions}
                onChange={(e) => setCareInstructions(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-stone-800 mb-1">
              Key Features / Highlights (One per line)
            </label>
            <textarea
              rows={2}
              placeholder="Features (one line per bullet)..."
              value={featuresText}
              onChange={(e) => setFeaturesText(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:bg-white focus:outline-none focus:border-stone-900 font-mono text-[11px]"
            />
          </div>

          {/* Footer Submit */}
          <div className="pt-4 border-t border-stone-200 flex items-center justify-between">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-stone-600 hover:text-stone-900 rounded-lg text-xs font-medium cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-stone-900 hover:bg-stone-800 text-white rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer shadow-sm"
            >
              <Check className="w-4 h-4" />
              <span>{productToEdit ? 'Save Changes' : 'Publish Product to Store'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
