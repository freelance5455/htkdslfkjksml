import React, { useState, useEffect } from 'react';
import { X, Sparkles, AlertCircle, Percent } from 'lucide-react';
import { Product, StoreData } from '../types';
import { feedback } from '../utils/haptics';

interface ProductFormModalProps {
  product?: Product | null;
  store: StoreData;
  isOpen: boolean;
  onClose: () => void;
  onSave: (productData: Omit<Product, 'id'>, existingId?: string) => void;
  soundEnabled?: boolean;
  hapticsEnabled?: boolean;
}

export const ProductFormModal: React.FC<ProductFormModalProps> = ({
  product,
  store,
  isOpen,
  onClose,
  onSave,
  soundEnabled = true,
  hapticsEnabled = true,
}) => {
  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [cat, setCat] = useState('');
  const [unit, setUnit] = useState('');
  const [open, setOpen] = useState('');
  const [cost, setCost] = useState('');
  const [price, setPrice] = useState('');
  const [min, setMin] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (product) {
      setName(product.name);
      setSku(product.sku || '');
      setCat(product.cat);
      setUnit(product.unit);
      setOpen(String(product.open));
      setCost(String(product.cost));
      setPrice(String(product.price));
      setMin(String(product.min));
    } else {
      setName('');
      setSku('');
      setCat(store.cats[0] || 'General');
      setUnit(store.units[0] || 'Pcs');
      setOpen('50');
      setCost('');
      setPrice('');
      setMin('10');
    }
    setError(null);
  }, [product, isOpen, store]);

  if (!isOpen) return null;

  const costNum = parseFloat(cost) || 0;
  const priceNum = parseFloat(price) || 0;
  const marginPct = priceNum > 0 ? ((priceNum - costNum) / priceNum) * 100 : 0;

  const handleGenerateSku = () => {
    const randomSku = '890' + Math.floor(100000 + Math.random() * 900000);
    setSku(randomSku);
    feedback.vibrateSoft(hapticsEnabled);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim()) {
      setError('Please enter a product name.');
      feedback.vibrateWarning(hapticsEnabled);
      return;
    }

    const openNum = parseFloat(open);
    if (isNaN(openNum) || openNum < 0) {
      setError('Opening stock must be 0 or more.');
      feedback.vibrateWarning(hapticsEnabled);
      return;
    }

    if (isNaN(costNum) || costNum < 0) {
      setError('Cost price must be 0 or more.');
      feedback.vibrateWarning(hapticsEnabled);
      return;
    }

    if (isNaN(priceNum) || priceNum < 0) {
      setError('Selling price must be 0 or more.');
      feedback.vibrateWarning(hapticsEnabled);
      return;
    }

    const minNum = parseFloat(min);
    if (isNaN(minNum) || minNum < 0) {
      setError('Reorder level must be 0 or more.');
      feedback.vibrateWarning(hapticsEnabled);
      return;
    }

    // Check duplicate name
    const isDuplicate = store.products.some(
      (p) => (!product || p.id !== product.id) && p.name.toLowerCase() === name.trim().toLowerCase()
    );
    if (isDuplicate) {
      setError('An item with this name already exists. You can edit it instead.');
      feedback.vibrateWarning(hapticsEnabled);
      return;
    }

    feedback.vibrateSuccess(hapticsEnabled);
    feedback.playSuccess(soundEnabled);

    onSave(
      {
        name: name.trim(),
        sku: sku.trim() || undefined,
        cat: cat.trim() || 'General',
        unit: unit.trim() || 'Pcs',
        open: openNum,
        cost: costNum,
        price: priceNum,
        min: minNum,
      },
      product?.id
    );

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
      <div className="bg-white dark:bg-slate-900 w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh] border border-slate-200 dark:border-slate-800 animate-in slide-in-from-bottom-6 duration-200">
        {/* Modal Top Bar */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
          <h3 className="font-bold text-sm tracking-tight">
            {product ? 'Edit Product' : 'Add New Product'}
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-full bg-slate-800 text-slate-300 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-3.5 text-xs">
          {error && (
            <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-400 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Product Name */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Product Name *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Basmati Rice 5kg"
              className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-red-500 focus:outline-hidden"
            />
          </div>

          {/* Barcode / SKU */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="font-semibold text-slate-700 dark:text-slate-300">
                Barcode / SKU (Optional)
              </label>
              <button
                type="button"
                onClick={handleGenerateSku}
                className="text-[11px] text-red-600 dark:text-red-400 hover:underline flex items-center gap-1 font-medium"
              >
                <Sparkles className="w-3 h-3" />
                Auto Generate
              </button>
            </div>
            <input
              type="text"
              value={sku}
              onChange={(e) => setSku(e.target.value)}
              placeholder="e.g. 890103001"
              className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-mono focus:ring-2 focus:ring-red-500 focus:outline-hidden"
            />
          </div>

          {/* Category & Unit */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Category
              </label>
              <input
                type="text"
                list="cats-list"
                value={cat}
                onChange={(e) => setCat(e.target.value)}
                placeholder="Category"
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-red-500 focus:outline-hidden"
              />
              <datalist id="cats-list">
                {store.cats.map((c) => (
                  <option key={c} value={c} />
                ))}
              </datalist>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Unit of Measure
              </label>
              <input
                type="text"
                list="units-list"
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                placeholder="e.g. Pcs, Kg"
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-red-500 focus:outline-hidden"
              />
              <datalist id="units-list">
                {store.units.map((u) => (
                  <option key={u} value={u} />
                ))}
              </datalist>
            </div>
          </div>

          {/* Cost Price & Selling Price */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Cost Price ({store.cur}) *
              </label>
              <input
                type="number"
                step="any"
                min="0"
                required
                value={cost}
                onChange={(e) => setCost(e.target.value)}
                placeholder="0.00"
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-red-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Selling Price ({store.cur}) *
              </label>
              <input
                type="number"
                step="any"
                min="0"
                required
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="0.00"
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-red-500 focus:outline-hidden"
              />
            </div>
          </div>

          {/* Live margin hint */}
          {priceNum > 0 && (
            <div className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-between text-[11px]">
              <span className="text-slate-500 flex items-center gap-1">
                <Percent className="w-3 h-3" /> Profit Margin:
              </span>
              <span className={`font-bold ${marginPct >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                {marginPct.toFixed(1)}% ({store.cur}{(priceNum - costNum).toFixed(2)} / {unit || 'unit'})
              </span>
            </div>
          )}

          {/* Opening Stock & Min Stock */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Opening Stock
              </label>
              <input
                type="number"
                step="any"
                min="0"
                required
                value={open}
                onChange={(e) => setOpen(e.target.value)}
                placeholder="0"
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-red-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Low Stock Alert At
              </label>
              <input
                type="number"
                step="any"
                min="0"
                required
                value={min}
                onChange={(e) => setMin(e.target.value)}
                placeholder="10"
                className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-red-500 focus:outline-hidden"
              />
            </div>
          </div>

          {/* Submit buttons */}
          <div className="pt-2 flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 rounded-xl bg-[#d9262c] hover:bg-red-700 text-white font-semibold shadow-sm transition active:scale-98"
            >
              {product ? 'Save Changes' : 'Create Product'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
