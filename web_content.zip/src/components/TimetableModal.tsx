import React, { useState } from 'react';
import { X, Calendar, Search, Check, Download, Printer } from 'lucide-react';
import { OCTOBER_2026_TIMETABLE } from '../data/october2026Timetable';
import { PrayerSettings } from '../types/prayer';
import { formatPrayerTime, calculateAlarmTime } from '../utils/prayerCalculator';

interface TimetableModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeDay: number;
  onSelectDay: (day: number) => void;
  settings: PrayerSettings;
}

export const TimetableModal: React.FC<TimetableModalProps> = ({
  isOpen,
  onClose,
  activeDay,
  onSelectDay,
  settings,
}) => {
  const [searchDay, setSearchDay] = useState('');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const filteredDays = OCTOBER_2026_TIMETABLE.filter(item => {
    if (!searchDay) return true;
    return (
      item.day.toString().includes(searchDay) ||
      `oct ${item.day}`.toLowerCase().includes(searchDay.toLowerCase()) ||
      `october ${item.day}`.toLowerCase().includes(searchDay.toLowerCase())
    );
  });

  const handleCopy = () => {
    const text = OCTOBER_2026_TIMETABLE.map(
      d =>
        `Oct ${d.day}: Fajr ${d.fajr} | Sunrise ${d.sunrise} | Dhuhr ${d.dhuhr} | Asr ${d.asr} | Maghrib ${d.maghrib} | Isha ${d.isha}`
    ).join('\n');
    navigator.clipboard.writeText(`Salat Sathi - October 2026 Dhaka Prayer Timetable (BST UTC+6)\n\n${text}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-3 sm:p-6 overflow-y-auto">
      <div className="relative w-full max-w-5xl rounded-3xl border border-emerald-900/60 bg-slate-900 shadow-2xl text-slate-100 flex flex-col max-h-[92vh] overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 px-6 py-4.5 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-950 border border-emerald-800 text-emerald-400">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                October 2026 Official Prayer Timetable
              </h2>
              <p className="text-xs text-slate-400">
                Bangladesh Standard Time (UTC+06:00) · Dhaka · Salah Alarms (+{settings.alarmDelayMinutes}m)
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="hidden sm:flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white transition cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Download className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy All'}</span>
            </button>
            <button
              onClick={handlePrint}
              className="hidden sm:flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white transition cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>
            <button
              onClick={onClose}
              className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-800 bg-slate-950 text-slate-400 hover:text-white transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="px-6 py-3 border-b border-slate-800 bg-slate-950/40 flex items-center justify-between gap-4">
          <div className="relative w-full max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search day (e.g. 8, Oct 15)..."
              value={searchDay}
              onChange={e => setSearchDay(e.target.value)}
              className="w-full rounded-xl border border-slate-700 bg-slate-900 py-1.5 pl-9 pr-3 text-xs text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
            />
          </div>
          <div className="text-xs text-slate-400 hidden sm:block">
            Click any row to view & sync with main dashboard
          </div>
        </div>

        {/* Table Content */}
        <div className="flex-1 overflow-y-auto px-6 py-4">
          <table className="w-full border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-semibold tracking-wider uppercase">
                <th className="py-3 px-3">Date</th>
                <th className="py-3 px-3 text-emerald-400">Fajr</th>
                <th className="py-3 px-3 text-amber-400">Sunrise</th>
                <th className="py-3 px-3 text-emerald-400">Dhuhr</th>
                <th className="py-3 px-3 text-emerald-400">Asr</th>
                <th className="py-3 px-3 text-emerald-400">Maghrib</th>
                <th className="py-3 px-3 text-emerald-400">Isha</th>
                <th className="py-3 px-3 text-slate-400 hidden lg:table-cell">Next Alarm (+{settings.alarmDelayMinutes}m)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono tabular-nums">
              {filteredDays.map(item => {
                const isSelected = item.day === activeDay;
                return (
                  <tr
                    key={item.day}
                    onClick={() => {
                      onSelectDay(item.day);
                      onClose();
                    }}
                    className={`transition-colors cursor-pointer group hover:bg-emerald-950/30 ${
                      isSelected ? 'bg-emerald-950/70 text-white font-semibold' : 'text-slate-300'
                    }`}
                  >
                    <td className="py-3 px-3 font-sans font-medium flex items-center gap-2">
                      <span className={isSelected ? 'text-emerald-300 font-bold' : ''}>
                        Oct {item.day}
                      </span>
                      {isSelected && (
                        <span className="text-[10px] uppercase font-bold text-emerald-400 bg-emerald-900/60 px-1.5 py-0.5 rounded">
                          Current
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-3">{formatPrayerTime(item.fajr, settings.timeFormat)}</td>
                    <td className="py-3 px-3 text-amber-400/90">{formatPrayerTime(item.sunrise, settings.timeFormat)}</td>
                    <td className="py-3 px-3">{formatPrayerTime(item.dhuhr, settings.timeFormat)}</td>
                    <td className="py-3 px-3">{formatPrayerTime(item.asr, settings.timeFormat)}</td>
                    <td className="py-3 px-3">{formatPrayerTime(item.maghrib, settings.timeFormat)}</td>
                    <td className="py-3 px-3">{formatPrayerTime(item.isha, settings.timeFormat)}</td>
                    <td className="py-3 px-3 text-slate-400 hidden lg:table-cell text-[11px] font-sans">
                      Fajr: {formatPrayerTime(calculateAlarmTime(item.fajr, settings.alarmDelayMinutes), settings.timeFormat)} ·
                      Dhuhr: {formatPrayerTime(calculateAlarmTime(item.dhuhr, settings.alarmDelayMinutes), settings.timeFormat)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Modal Footer */}
        <div className="border-t border-slate-800 bg-slate-950/80 px-6 py-3 flex items-center justify-between text-xs text-slate-400">
          <span>Total: 31 Days in October 2026</span>
          <button
            onClick={onClose}
            className="rounded-xl bg-slate-800 px-4 py-1.5 text-xs font-semibold text-white hover:bg-slate-700 transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
