import React from 'react';

// 1. Medicine Scanner: medicine tablets/capsules with a small scanning effect
export const MedicineScannerIllustration: React.FC<{ className?: string }> = ({ className = 'w-16 h-12' }) => (
  <svg viewBox="0 0 100 70" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    {/* Soft subtle background glow */}
    <rect x="10" y="8" width="80" height="54" rx="14" fill="#ECFDF5" />
    
    {/* Scanner target corners */}
    <path d="M 22 22 L 18 22 A 4 4 0 0 0 14 26 L 14 30" stroke="#059669" strokeWidth="2" strokeLinecap="round" />
    <path d="M 78 22 L 82 22 A 4 4 0 0 1 86 26 L 86 30" stroke="#059669" strokeWidth="2" strokeLinecap="round" />
    <path d="M 14 42 L 14 46 A 4 4 0 0 0 18 50 L 22 50" stroke="#059669" strokeWidth="2" strokeLinecap="round" />
    <path d="M 86 42 L 86 46 A 4 4 0 0 1 82 50 L 78 50" stroke="#059669" strokeWidth="2" strokeLinecap="round" />
    
    {/* Laser scan line with glow */}
    <line x1="16" y1="36" x2="84" y2="36" stroke="#10B981" strokeWidth="1.5" strokeDasharray="3 2" />
    <line x1="24" y1="36" x2="76" y2="36" stroke="#34D399" strokeWidth="2" strokeLinecap="round" opacity="0.9" />

    {/* Capsule pill (rotated) */}
    <g transform="translate(34, 18) rotate(32)">
      {/* Left half of capsule */}
      <rect x="0" y="0" width="14" height="24" rx="7" fill="#10B981" />
      {/* Right half of capsule */}
      <path d="M 0 12 L 14 12 L 14 17 A 7 7 0 0 1 0 17 Z" fill="#6EE7B7" />
      {/* Capsule shine highlight */}
      <path d="M 3 5 A 4 4 0 0 1 7 3" stroke="#FFFFFF" strokeWidth="1.2" strokeLinecap="round" opacity="0.8" />
    </g>

    {/* Round tablet pill */}
    <circle cx="64" cy="40" r="10" fill="#A7F3D0" stroke="#059669" strokeWidth="1.5" />
    <line x1="58" y1="40" x2="70" y2="40" stroke="#059669" strokeWidth="1.5" strokeLinecap="round" opacity="0.7" />
    <circle cx="61" cy="37" r="1.5" fill="#FFFFFF" opacity="0.8" />
  </svg>
);

// 2. Medical Report Analyzer: medical report/document with a magnifying glass or AI analysis symbol
export const MedicalReportIllustration: React.FC<{ className?: string }> = ({ className = 'w-16 h-12' }) => (
  <svg viewBox="0 0 100 70" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    {/* Soft subtle background glow */}
    <rect x="10" y="8" width="80" height="54" rx="14" fill="#F0FDFA" />

    {/* Document sheet */}
    <rect x="25" y="14" width="34" height="42" rx="4" fill="#FFFFFF" stroke="#0D9488" strokeWidth="1.5" />
    
    {/* Document lines / rows */}
    <rect x="30" y="20" width="16" height="3" rx="1.5" fill="#0D9488" />
    <rect x="30" y="26" width="24" height="2" rx="1" fill="#99F6E4" />
    <rect x="30" y="31" width="20" height="2" rx="1" fill="#99F6E4" />
    <rect x="30" y="36" width="22" height="2" rx="1" fill="#99F6E4" />
    <rect x="30" y="41" width="14" height="2" rx="1" fill="#99F6E4" />
    
    {/* Sparkle badge */}
    <path d="M 33 47 L 34.5 44 L 37.5 45.5 L 34.5 47 L 33 50 L 31.5 47 L 28.5 45.5 L 31.5 44 Z" fill="#14B8A6" />

    {/* Magnifying Glass with AI focal lens */}
    <circle cx="65" cy="33" r="13" fill="#CCFBF1" fillOpacity="0.85" stroke="#0F766E" strokeWidth="2" />
    {/* Lens checkmark / chart inside */}
    <path d="M 59 34 L 63 38 L 71 29" stroke="#0F766E" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    {/* Magnifier handle */}
    <path d="M 74 42 L 84 52" stroke="#0F766E" strokeWidth="3" strokeLinecap="round" />
  </svg>
);

// 3. Disease Progress Tracker: health progress chart with heartbeat/medical graph
export const DiseaseTrackerIllustration: React.FC<{ className?: string }> = ({ className = 'w-16 h-12' }) => (
  <svg viewBox="0 0 100 70" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    {/* Soft subtle background glow */}
    <rect x="10" y="8" width="80" height="54" rx="14" fill="#FAF5FF" />

    {/* Chart monitor canvas */}
    <rect x="18" y="14" width="64" height="42" rx="6" fill="#FFFFFF" stroke="#9333EA" strokeWidth="1.5" />

    {/* Grid guideline dots/lines */}
    <line x1="24" y1="26" x2="76" y2="26" stroke="#F3E8FF" strokeWidth="1" strokeDasharray="2 2" />
    <line x1="24" y1="36" x2="76" y2="36" stroke="#F3E8FF" strokeWidth="1" strokeDasharray="2 2" />
    <line x1="24" y1="46" x2="76" y2="46" stroke="#F3E8FF" strokeWidth="1" strokeDasharray="2 2" />

    {/* Pulse ECG wave line */}
    <path
      d="M 22 36 L 33 36 L 37 28 L 41 44 L 46 22 L 51 46 L 55 33 L 59 36 L 78 36"
      stroke="#A855F7"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />

    {/* Heartbeat pulse beacon icon */}
    <circle cx="46" cy="22" r="3" fill="#7E22CE" />
    <path
      d="M 68 18 C 66 18 64 20 64 22 C 64 25 68 28 68 28 C 68 28 72 25 72 22 C 72 20 70 18 68 18 Z"
      fill="#EC4899"
    />
  </svg>
);

// 5. Medicine Reminder: medicine bottle/tablet with a clock or reminder symbol
export const MedicineReminderIllustration: React.FC<{ className?: string }> = ({ className = 'w-16 h-12' }) => (
  <svg viewBox="0 0 100 70" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    {/* Soft subtle background glow */}
    <rect x="10" y="8" width="80" height="54" rx="14" fill="#FFFBEB" />

    {/* Medicine Bottle */}
    <rect x="25" y="16" width="18" height="6" rx="2" fill="#F59E0B" />
    <rect x="23" y="22" width="22" height="32" rx="4" fill="#FDE68A" stroke="#D97706" strokeWidth="1.5" />
    <rect x="26" y="28" width="16" height="14" rx="2" fill="#FFFFFF" />
    <path d="M 34 32 L 34 38 M 31 35 L 37 35" stroke="#D97706" strokeWidth="1.5" strokeLinecap="round" />

    {/* Clock Reminder Indicator */}
    <circle cx="65" cy="35" r="14" fill="#FFFFFF" stroke="#B45309" strokeWidth="2" />
    <circle cx="65" cy="35" r="11" fill="#FEF3C7" />
    {/* Clock hands showing on-time reminder */}
    <path d="M 65 35 L 65 29 M 65 35 L 71 35" stroke="#92400E" strokeWidth="2" strokeLinecap="round" />
    {/* Bell alarm alert top ring */}
    <path d="M 62 18 A 4 4 0 0 1 68 18" stroke="#D97706" strokeWidth="1.5" strokeLinecap="round" fill="none" />
  </svg>
);

// 6. Health Education: medical book/open book with healthcare symbols
export const HealthEducationIllustration: React.FC<{ className?: string }> = ({ className = 'w-16 h-12' }) => (
  <svg viewBox="0 0 100 70" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    {/* Soft subtle background glow */}
    <rect x="10" y="8" width="80" height="54" rx="14" fill="#ECFEFF" />

    {/* Open book spine & background pages */}
    <path
      d="M 50 25 C 40 22 26 23 20 25 L 20 52 C 26 50 40 49 50 53 C 60 49 74 50 80 52 L 80 25 C 74 23 60 22 50 25 Z"
      fill="#FFFFFF"
      stroke="#0891B2"
      strokeWidth="1.5"
    />
    {/* Center crease */}
    <line x1="50" y1="25" x2="50" y2="53" stroke="#0891B2" strokeWidth="1.5" />

    {/* Left page content lines */}
    <line x1="26" y1="31" x2="44" y2="31" stroke="#A5F3FC" strokeWidth="2" strokeLinecap="round" />
    <line x1="26" y1="37" x2="44" y2="37" stroke="#A5F3FC" strokeWidth="2" strokeLinecap="round" />
    <line x1="26" y1="43" x2="38" y2="43" stroke="#A5F3FC" strokeWidth="2" strokeLinecap="round" />

    {/* Right page medical cross badge */}
    <circle cx="65" cy="38" r="8" fill="#CFFAFE" />
    <path d="M 65 33 L 65 43 M 60 38 L 70 38" stroke="#0E7490" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

// 7. Emergency Services: emergency medical kit/phone with emergency symbol
export const EmergencyServicesIllustration: React.FC<{ className?: string }> = ({ className = 'w-16 h-12' }) => (
  <svg viewBox="0 0 100 70" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    {/* Soft subtle background glow */}
    <rect x="10" y="8" width="80" height="54" rx="14" fill="#FFF1F2" />

    {/* Emergency First-Aid Kit */}
    <rect x="22" y="24" width="44" height="30" rx="6" fill="#FFFFFF" stroke="#E11D48" strokeWidth="1.8" />
    {/* Kit Handle */}
    <path d="M 37 24 L 37 18 A 3 3 0 0 1 40 15 L 48 15 A 3 3 0 0 1 51 18 L 51 24" stroke="#BE123C" strokeWidth="2" fill="none" />
    
    {/* Red Medical Cross */}
    <rect x="41.5" y="32" width="5" height="14" rx="1.5" fill="#E11D48" />
    <rect x="37" y="36.5" width="14" height="5" rx="1.5" fill="#E11D48" />

    {/* Emergency Alert Phone / Siren Beacon on top right */}
    <circle cx="72" cy="24" r="9" fill="#FFE4E6" stroke="#E11D48" strokeWidth="1.5" />
    {/* Phone / SOS icon */}
    <path
      d="M 68 22 C 68 21 69 20 70 20 L 71 21 C 71.5 21.5 71.5 22 71 22.5 L 70.5 23 C 71 24 72 25 73 25.5 L 73.5 25 C 74 24.5 74.5 24.5 75 25 L 76 26 C 76 27 75 28 74 28 C 70.5 28 68 25.5 68 22 Z"
      fill="#BE123C"
    />
    <path d="M 77 17 A 8 8 0 0 1 82 22" stroke="#FB7185" strokeWidth="1.5" strokeLinecap="round" fill="none" />
  </svg>
);

// 8. Health Services: hospital/doctor/healthcare building
export const HealthServicesIllustration: React.FC<{ className?: string }> = ({ className = 'w-16 h-12' }) => (
  <svg viewBox="0 0 100 70" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    {/* Soft subtle background glow */}
    <rect x="10" y="8" width="80" height="54" rx="14" fill="#EFF6FF" />

    {/* Hospital clinic main building */}
    <rect x="30" y="16" width="40" height="38" rx="4" fill="#FFFFFF" stroke="#2563EB" strokeWidth="1.5" />
    
    {/* Top Medical Cross Roof Sign */}
    <circle cx="50" cy="24" r="5" fill="#DBEAFE" />
    <path d="M 50 21 L 50 27 M 47 24 L 53 24" stroke="#1D4ED8" strokeWidth="1.5" strokeLinecap="round" />

    {/* Hospital Windows */}
    <rect x="36" y="32" width="6" height="6" rx="1.5" fill="#93C5FD" />
    <rect x="47" y="32" width="6" height="6" rx="1.5" fill="#93C5FD" />
    <rect x="58" y="32" width="6" height="6" rx="1.5" fill="#93C5FD" />

    {/* Glass Entryway Door */}
    <rect x="46" y="42" width="8" height="12" rx="1" fill="#3B82F6" opacity="0.8" />
    <line x1="50" y1="42" x2="50" y2="54" stroke="#FFFFFF" strokeWidth="1" />

    {/* Side clinic wing */}
    <rect x="18" y="28" width="12" height="26" rx="2" fill="#E0F2FE" stroke="#3B82F6" strokeWidth="1.2" />
    <rect x="22" y="34" width="4" height="4" rx="1" fill="#BAE6FD" />
    <rect x="22" y="42" width="4" height="4" rx="1" fill="#BAE6FD" />
  </svg>
);

// 9. Symptom Guide: Clinical checklist board with pulse wave and guidance spark
export const SymptomGuideIllustration: React.FC<{ className?: string }> = ({ className = 'w-16 h-12' }) => (
  <svg viewBox="0 0 100 70" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    {/* Soft subtle background glow */}
    <rect x="10" y="8" width="80" height="54" rx="14" fill="#FFFBEB" />

    {/* Clipboard Base */}
    <rect x="26" y="14" width="48" height="46" rx="6" fill="#FFFFFF" stroke="#D97706" strokeWidth="1.5" />

    {/* Clipboard Top Clip */}
    <rect x="42" y="10" width="16" height="7" rx="2.5" fill="#F59E0B" stroke="#B45309" strokeWidth="1" />
    <circle cx="50" cy="13.5" r="1.5" fill="#FFFFFF" />

    {/* Symptom Checklist Items */}
    {/* Item 1 with checkmark */}
    <rect x="32" y="22" width="7" height="7" rx="1.5" fill="#FEF3C7" stroke="#D97706" strokeWidth="1" />
    <path d="M 33.5 25.5 L 35 27 L 38 23.5" stroke="#B45309" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
    <rect x="42" y="24" width="26" height="3" rx="1.5" fill="#FDE68A" />

    {/* Item 2 with checkmark */}
    <rect x="32" y="32" width="7" height="7" rx="1.5" fill="#FEF3C7" stroke="#D97706" strokeWidth="1" />
    <path d="M 33.5 35.5 L 35 37 L 38 33.5" stroke="#B45309" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
    <rect x="42" y="34" width="22" height="3" rx="1.5" fill="#FDE68A" />

    {/* Item 3 Pulse line */}
    <path d="M 32 46 L 40 46 L 43 41 L 46 51 L 49 44 L 51 48 L 54 46 L 68 46" stroke="#EF4444" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />

    {/* Guidance Sparkle Badge */}
    <circle cx="73" cy="21" r="7.5" fill="#F59E0B" />
    <path d="M 73 16.5 L 74.2 19.8 L 77.5 21 L 74.2 22.2 L 73 25.5 L 71.8 22.2 L 68.5 21 L 71.8 19.8 Z" fill="#FFFFFF" />
  </svg>
);

