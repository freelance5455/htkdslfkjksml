import React, { useState } from 'react';
import {
  Copy,
  Check,
  Download,
  Mic,
  AlertTriangle,
  Sparkles,
  ShieldCheck,
  ShieldAlert,
  HelpCircle,
  Activity,
  Sliders,
  Music2,
  FileText,
  Volume2,
} from 'lucide-react';
import { VoiceAnalysisReport } from '../types/audio';

interface VoiceAnalysisReportViewProps {
  report: VoiceAnalysisReport;
  fileName: string;
  onClose?: () => void;
  onReanalyze?: () => void;
  isAnalyzing?: boolean;
}

export function formatSectionForCopy(sectionKey: string, report: VoiceAnalysisReport): string {
  switch (sectionKey) {
    case 'A':
      return [
        'A. RESUMO VOCAL',
        `Visão Geral: ${report.sectionA_resumoVocal.overview}`,
        `Destaques Principais: ${report.sectionA_resumoVocal.keyHighlights.join(' · ')}`,
        `Síntese do Perfil Vocal: ${report.sectionA_resumoVocal.vocalProfileSummary}`,
      ].join('\n');

    case 'B':
      return [
        'B. TIMBRE E REGISTRO',
        `Classificação Perceptiva: ${report.sectionB_timbreRegistro.perceptualClassification}`,
        `Apresentação Vocal Percebida: ${report.sectionB_timbreRegistro.perceivedPresentation}`,
        `Descritores de Timbre: ${report.sectionB_timbreRegistro.timbreDescriptors.join(', ')}`,
        `Descrição do Timbre: ${report.sectionB_timbreRegistro.timbreDescription}`,
        `Ressonância e Projeção: ${report.sectionB_timbreRegistro.resonanceAndProjection}`,
        `Articulação e Clareza: ${report.sectionB_timbreRegistro.articulationAndClarity}`,
        `Altura Habitual vs Notas no Canto: ${report.sectionB_timbreRegistro.speechVsSingingPitchNote}`,
      ].join('\n');

    case 'C':
      return [
        'C. TEXTURA E ROUQUIDÃO',
        `Classificação da Rouquidão: ${report.sectionC_texturaRouquidao.roughnessClassification}`,
        `Textura e Intensidade Percebida: ${report.sectionC_texturaRouquidao.textureAndPerceivedIntensity}`,
        `Características Vocais vs Efeitos de Estúdio: ${report.sectionC_texturaRouquidao.vocalCharacteristicsVsEffects}`,
      ].join('\n');

    case 'D':
      return [
        'D. EMOÇÃO E INTERPRETAÇÃO',
        `Emoções Transmitidas: ${report.sectionD_emocaoInterpretacao.transmittedEmotions.join(', ')}`,
        `Dinâmica Vocal e Expressividade: ${report.sectionD_emocaoInterpretacao.vocalDynamicsAndExpressiveness}`,
        `Pausas e Respirações: ${report.sectionD_emocaoInterpretacao.pausesAndBreathing}`,
        `Vibrato e Articulação: ${report.sectionD_emocaoInterpretacao.vibratoAndArticulation}`,
        `Mudanças de Intensidade: ${report.sectionD_emocaoInterpretacao.intensityChanges}`,
      ].join('\n');

    case 'E':
      return [
        'E. NATURALIDADE E INDÍCIOS DE SÍNTESE ARTIFICIAL',
        `Classificação dos Indícios: ${report.sectionE_naturalidadeIndiciosIA.observableSignsClassification}`,
        `Explicação da Classificação: ${report.sectionE_naturalidadeIndiciosIA.classificationExplanation}`,
        `Variações de Timbre e Intensidade: ${report.sectionE_naturalidadeIndiciosIA.timbreAndIntensityVariations}`,
        `Respirações e Articulação: ${report.sectionE_naturalidadeIndiciosIA.breathingAndArticulationNaturalness}`,
        `Transições entre Notas e Continuidade: ${report.sectionE_naturalidadeIndiciosIA.noteTransitionsAndContinuity}`,
        `Uniformidade do Vibrato: ${report.sectionE_naturalidadeIndiciosIA.vibratoUniformity}`,
        `Pronúncias e Artefatos Digitais: ${report.sectionE_naturalidadeIndiciosIA.pronunciationAndArtifacts}`,
        `Impacto de Autotune e Efeitos: ${report.sectionE_naturalidadeIndiciosIA.autotuneAndStudioEffectsImpact}`,
        `Limitações e Fatores de Incerteza: ${report.sectionE_naturalidadeIndiciosIA.limitationsOfEvaluation}`,
      ].join('\n');

    case 'DSP':
      return [
        'ANÁLISE TÉCNICA COMPLEMENTAR (PROCESSAMENTO DE SINAL)',
        `Faixa de Frequência Fundamental (F0): ${report.sectionComplementar_dsp.f0RangeHz}`,
        `Média F0: ${report.sectionComplementar_dsp.f0AverageHz ? `${report.sectionComplementar_dsp.f0AverageHz} Hz` : 'N/A'}`,
        `Variação de Altura: ${report.sectionComplementar_dsp.pitchRangeSemitones}`,
        `Estabilidade Vocal / Jitter: ${report.sectionComplementar_dsp.vocalStabilityJitter}`,
        `Intensidade RMS: ${report.sectionComplementar_dsp.vocalIntensityRmsDb}`,
        `Características Espectrais: ${report.sectionComplementar_dsp.spectralCharacteristics}`,
        `Distinção com Taxa de Amostragem: ${report.sectionComplementar_dsp.sampleRateDistinctionNote}`,
      ].join('\n');

    case 'F':
      return [
        'F. CARACTERÍSTICAS VOCAIS RECOMENDADAS PARA RECRIAÇÃO (SUNO AI)',
        `Tipo de Timbre: ${report.sectionF_caracteristicasRecriacao.timbreType}`,
        `Textura e Nível de Rouquidão: ${report.sectionF_caracteristicasRecriacao.textureAndRoughness}`,
        `Região Vocal Pretendida: ${report.sectionF_caracteristicasRecriacao.perceivedVocalRegister}`,
        `Estilo de Interpretação e Emoção: ${report.sectionF_caracteristicasRecriacao.interpretationAndEmotion}`,
        `Fraseado e Articulação: ${report.sectionF_caracteristicasRecriacao.deliveryAndPhrasing}`,
        `Nível de Efeitos e Processamento Desejável: ${report.sectionF_caracteristicasRecriacao.desirableEffectsAndProcessingLevel}`,
      ].join('\n');

    case 'G':
      return [
        'G. PROMPT VOCAL COMPLETO EM INGLÊS (SUNO - STYLE OF MUSIC)',
        report.sectionG_promptCompletoIngles,
        '',
        '[Versão Traduzida em Português]:',
        report.promptsPortugues.promptCompleto,
      ].join('\n');

    case 'H':
      return [
        'H. PROMPT VOCAL CURTO EM INGLÊS (SUNO - STYLE OF MUSIC)',
        report.sectionH_promptCurtoIngles,
        '',
        '[Versão Traduzida em Português]:',
        report.promptsPortugues.promptCurto,
      ].join('\n');

    default:
      return '';
  }
}

export function formatFullVoiceReport(report: VoiceAnalysisReport, fileName: string): string {
  const header = [
    '========================================================================',
    'JF MUSIC ANALYZER IA — RELATÓRIO DE ANÁLISE VOCAL PROFISSIONAL',
    'FUNÇÃO: ANALISADOR DE VOZ / COMANDO: /analisarvoz',
    `Arquivo de Áudio: ${fileName}`,
    `Data do Processamento: ${new Date().toLocaleString('pt-BR')}`,
    '========================================================================',
    '',
  ].join('\n');

  const sections = ['A', 'B', 'C', 'D', 'E', 'DSP', 'F', 'G', 'H'].map((sec) =>
    formatSectionForCopy(sec, report)
  );

  return header + sections.join('\n\n------------------------------------------------------------------------\n\n');
}

export const VoiceAnalysisReportView: React.FC<VoiceAnalysisReportViewProps> = ({
  report,
  fileName,
  onReanalyze,
  isAnalyzing = false,
}) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleCopy = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 2000);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 2000);
    }
  };

  const handleDownloadTxt = () => {
    const text = formatFullVoiceReport(report, fileName);
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const cleanName = fileName.replace(/\.[^/.]+$/, '');
    a.href = url;
    a.download = `Relatorio_Vocal_${cleanName}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Status badge styling for AI Conclusion
  const getAiBadgeColor = (classification: string) => {
    if (classification.includes('Fracos')) {
      return {
        bg: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300',
        icon: <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />,
      };
    }
    if (classification.includes('Moderados')) {
      return {
        bg: 'bg-amber-500/10 border-amber-500/30 text-amber-300',
        icon: <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />,
      };
    }
    if (classification.includes('Fortes')) {
      return {
        bg: 'bg-rose-500/10 border-rose-500/30 text-rose-300',
        icon: <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />,
      };
    }
    return {
      bg: 'bg-sky-500/10 border-sky-500/30 text-sky-300',
      icon: <HelpCircle className="w-4 h-4 text-sky-400 shrink-0" />,
    };
  };

  const aiBadge = getAiBadgeColor(
    report.sectionE_naturalidadeIndiciosIA.observableSignsClassification
  );

  return (
    <div className="bg-[#111827] border border-slate-800/90 rounded-2xl p-4 sm:p-7 space-y-7 animate-in fade-in duration-200">
      {/* Master Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-slate-800/80">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400">
            <Mic className="w-4 h-4 text-amber-400" />
            <span>FUNÇÃO: ANALISAR VOZ · COMANDO: /analisarvoz</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-100 font-display mt-1">
            Relatório de Análise Vocal Profissional
          </h2>
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-400 font-mono tabular-nums mt-1">
            <span>Arquivo: <strong className="text-slate-200">{fileName}</strong></span>
            <span aria-hidden="true">·</span>
            <span>Status: <strong className="text-emerald-400">Seções A a H Concluídas</strong></span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => handleCopy('FULL', formatFullVoiceReport(report, fileName))}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shadow-md shadow-amber-500/10"
          >
            {copiedKey === 'FULL' ? (
              <>
                <Check className="w-4 h-4" />
                <span>Relatório Copiado!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Copiar Relatório Completo</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={handleDownloadTxt}
            className="min-h-[44px] px-3.5 py-2 rounded-xl bg-[#0B0F17] border border-slate-800 hover:border-slate-700 text-slate-200 font-medium text-xs sm:text-sm flex items-center gap-2 transition-colors cursor-pointer whitespace-nowrap"
          >
            <Download className="w-4 h-4 text-amber-400" />
            <span>Exportar .TXT</span>
          </button>

          {onReanalyze && (
            <button
              type="button"
              disabled={isAnalyzing}
              onClick={onReanalyze}
              className="min-h-[44px] px-3.5 py-2 rounded-xl bg-[#0B0F17] border border-slate-800 hover:border-slate-700 text-slate-300 font-medium text-xs flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap disabled:opacity-50"
            >
              <span>Reanalisar Voz</span>
            </button>
          )}
        </div>
      </div>

      {/* Limitation Notice if audio had issues */}
      {(!report.hasVoice || report.limitationNote) && (
        <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-500/30 text-amber-200 text-xs sm:text-sm flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-amber-300">Nota de Integridade Técnica: </span>
            <span>{report.limitationNote || 'Presença vocal reduzida na gravação.'}</span>
          </div>
        </div>
      )}

      {/* PROMPTS FINAIS PARA SUNO: SEÇÃO G (COMPLETO) & SEÇÃO H (CURTO) */}
      <div className="space-y-4">
        {/* SEÇÃO G: PROMPT VOCAL COMPLETO EM INGLÊS */}
        <div className="bg-[#0B0F17] border-2 border-amber-500/60 rounded-2xl p-5 sm:p-6 space-y-4 shadow-xl shadow-amber-500/5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[11px] font-mono text-amber-400 font-semibold">
                  G. PROMPT VOCAL COMPLETO EM INGLÊS
                </span>
                <h3 className="text-base sm:text-lg font-bold text-slate-100">
                  Prompt Vocal Detalhado para Suno (Style of Music)
                </h3>
              </div>
            </div>

            <button
              type="button"
              onClick={() => handleCopy('SEC_G_EN', report.sectionG_promptCompletoIngles)}
              className="min-h-[42px] px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shadow-md shadow-amber-500/20"
            >
              {copiedKey === 'SEC_G_EN' ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Copiado para Suno!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copiar Prompt Completo (EN)</span>
                </>
              )}
            </button>
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
              <span className="text-slate-300 font-medium">Pronto para colar no campo Style of Music:</span>
              <span className="text-amber-400">{report.sectionG_promptCompletoIngles.length} caracteres</span>
            </div>
            <div className="p-3.5 rounded-xl bg-[#111827] border border-slate-800 font-mono text-xs sm:text-sm text-slate-100 leading-relaxed select-all">
              {report.sectionG_promptCompletoIngles}
            </div>
          </div>

          {/* Versão em português espelho */}
          <div className="pt-2 border-t border-slate-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="text-xs text-slate-400">
              <span className="text-slate-300 font-medium">Tradução em Português: </span>
              <span className="text-slate-300">{report.promptsPortugues.promptCompleto}</span>
            </div>
            <button
              type="button"
              onClick={() => handleCopy('SEC_G_PT', report.promptsPortugues.promptCompleto)}
              className="text-amber-400 hover:underline text-xs flex items-center gap-1 cursor-pointer self-start sm:self-auto shrink-0"
            >
              <Copy className="w-3 h-3" />
              <span>{copiedKey === 'SEC_G_PT' ? 'Copiado!' : 'Copiar PT'}</span>
            </button>
          </div>
        </div>

        {/* SEÇÃO H: PROMPT VOCAL CURTO EM INGLÊS */}
        <div className="bg-[#0B0F17] border border-slate-800 rounded-2xl p-5 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-800/80">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                <Music2 className="w-3.5 h-3.5" />
              </div>
              <div>
                <span className="text-[11px] font-mono text-amber-400 font-semibold">
                  H. PROMPT VOCAL CURTO EM INGLÊS
                </span>
                <h3 className="text-sm sm:text-base font-bold text-slate-100">
                  Prompt Compacto / Resumido para Suno
                </h3>
              </div>
            </div>

            <button
              type="button"
              onClick={() => handleCopy('SEC_H_EN', report.sectionH_promptCurtoIngles)}
              className="min-h-[38px] px-3.5 py-1.5 rounded-lg bg-[#111827] border border-slate-800 hover:border-slate-700 text-slate-200 hover:text-amber-400 font-medium text-xs flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
            >
              {copiedKey === 'SEC_H_EN' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copiado!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copiar Prompt Curto (EN)</span>
                </>
              )}
            </button>
          </div>

          <div className="space-y-1">
            <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
              <span>Versão Concisa (Short Style):</span>
              <span className="text-amber-400">{report.sectionH_promptCurtoIngles.length} caracteres</span>
            </div>
            <div className="p-3 rounded-xl bg-[#111827] border border-slate-800/80 font-mono text-xs sm:text-sm text-slate-200 select-all">
              {report.sectionH_promptCurtoIngles}
            </div>
          </div>

          <div className="pt-2 border-t border-slate-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="text-xs text-slate-400">
              <span className="text-slate-300 font-medium">Versão em Português: </span>
              <span className="text-slate-300">{report.promptsPortugues.promptCurto}</span>
            </div>
            <button
              type="button"
              onClick={() => handleCopy('SEC_H_PT', report.promptsPortugues.promptCurto)}
              className="text-amber-400 hover:underline text-xs flex items-center gap-1 cursor-pointer self-start sm:self-auto shrink-0"
            >
              <Copy className="w-3 h-3" />
              <span>{copiedKey === 'SEC_H_PT' ? 'Copiado!' : 'Copiar PT'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* SEÇÕES TÉCNICAS A, B, C, D, E, DSP, F */}
      <div className="space-y-6">
        {/* A. RESUMO VOCAL */}
        <div className="p-5 rounded-2xl bg-[#0B0F17] border border-slate-800/90 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-amber-400" />
              <div>
                <span className="text-[11px] font-mono text-amber-400 font-semibold">SEÇÃO A</span>
                <h3 className="text-base font-bold text-slate-100">A. Resumo Vocal</h3>
              </div>
            </div>
            <button
              type="button"
              onClick={() => handleCopy('SEC_A', formatSectionForCopy('A', report))}
              className="min-h-[36px] px-2.5 py-1 rounded-lg border border-slate-800 hover:border-slate-700 text-xs text-slate-300 hover:text-amber-400 flex items-center gap-1 cursor-pointer transition-colors"
            >
              {copiedKey === 'SEC_A' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copiedKey === 'SEC_A' ? 'Copiado' : 'Copiar Seção A'}</span>
            </button>
          </div>

          <div className="space-y-3 text-xs sm:text-sm">
            <div>
              <span className="text-xs text-slate-400 font-medium">Visão Geral da Presença Vocal:</span>
              <p className="text-slate-200 mt-1 leading-relaxed">
                {report.sectionA_resumoVocal.overview}
              </p>
            </div>

            <div>
              <span className="text-xs text-slate-400 font-medium">Destaques do Perfil:</span>
              <div className="flex flex-wrap gap-1.5 mt-1.5">
                {report.sectionA_resumoVocal.keyHighlights.map((hl, idx) => (
                  <span
                    key={idx}
                    className="px-2.5 py-1 rounded-lg bg-[#111827] border border-slate-800 text-slate-200 text-xs"
                  >
                    {hl}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800/60">
              <span className="text-xs text-slate-400 font-medium">Síntese Concisa:</span>
              <p className="text-slate-300 mt-0.5 leading-relaxed font-mono text-xs">
                {report.sectionA_resumoVocal.vocalProfileSummary}
              </p>
            </div>
          </div>
        </div>

        {/* B. TIMBRE E REGISTRO & C. TEXTURA E ROUQUIDÃO (GRID) */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* B. TIMBRE E REGISTRO */}
          <div className="p-5 rounded-2xl bg-[#0B0F17] border border-slate-800/90 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-800/80">
                <div>
                  <span className="text-[11px] font-mono text-amber-400 font-semibold">SEÇÃO B</span>
                  <h3 className="text-base font-bold text-slate-100">B. Timbre e Registro</h3>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy('SEC_B', formatSectionForCopy('B', report))}
                  className="min-h-[36px] px-2.5 py-1 rounded-lg border border-slate-800 hover:border-slate-700 text-xs text-slate-300 hover:text-amber-400 flex items-center gap-1 cursor-pointer transition-colors"
                >
                  {copiedKey === 'SEC_B' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedKey === 'SEC_B' ? 'Copiado' : 'Copiar Seção B'}</span>
                </button>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-3 pb-3 border-b border-slate-800/60 text-xs">
                <div>
                  <span className="text-slate-400">Classificação Perceptiva:</span>
                  <div className="text-sm font-semibold text-slate-100 mt-0.5">
                    {report.sectionB_timbreRegistro.perceptualClassification}
                  </div>
                </div>
                <div>
                  <span className="text-slate-400">Apresentação Vocal:</span>
                  <div className="text-sm font-semibold text-slate-100 mt-0.5">
                    {report.sectionB_timbreRegistro.perceivedPresentation}
                  </div>
                </div>
              </div>

              <div className="mt-3 space-y-2.5 text-xs sm:text-sm">
                <div>
                  <span className="text-xs text-slate-400 font-medium">Descritores de Timbre:</span>
                  <div className="flex flex-wrap items-center gap-1.5 mt-1">
                    {report.sectionB_timbreRegistro.timbreDescriptors.map((desc, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded bg-[#111827] border border-slate-800 text-amber-400 font-mono text-xs"
                      >
                        {desc}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-1">
                  <span className="text-xs text-slate-400 font-medium">Descrição Detalhada do Timbre:</span>
                  <p className="text-slate-200 mt-0.5 leading-relaxed">
                    {report.sectionB_timbreRegistro.timbreDescription}
                  </p>
                </div>

                <div className="pt-1">
                  <span className="text-xs text-slate-400 font-medium">Ressonância, Projeção e Clareza:</span>
                  <p className="text-slate-300 mt-0.5 leading-relaxed">
                    {report.sectionB_timbreRegistro.resonanceAndProjection} · {report.sectionB_timbreRegistro.articulationAndClarity}
                  </p>
                </div>

                <div className="pt-1">
                  <span className="text-xs text-slate-400 font-medium">Altura Habitual vs Notas no Canto:</span>
                  <p className="text-slate-300 mt-0.5 leading-relaxed">
                    {report.sectionB_timbreRegistro.speechVsSingingPitchNote}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* C. TEXTURA E ROUQUIDÃO */}
          <div className="p-5 rounded-2xl bg-[#0B0F17] border border-slate-800/90 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-800/80">
                <div>
                  <span className="text-[11px] font-mono text-amber-400 font-semibold">SEÇÃO C</span>
                  <h3 className="text-base font-bold text-slate-100">C. Textura e Rouquidão</h3>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy('SEC_C', formatSectionForCopy('C', report))}
                  className="min-h-[36px] px-2.5 py-1 rounded-lg border border-slate-800 hover:border-slate-700 text-xs text-slate-300 hover:text-amber-400 flex items-center gap-1 cursor-pointer transition-colors"
                >
                  {copiedKey === 'SEC_C' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedKey === 'SEC_C' ? 'Copiado' : 'Copiar Seção C'}</span>
                </button>
              </div>

              <div className="mt-4 pb-3 border-b border-slate-800/60">
                <span className="text-xs text-slate-400">Classificação da Rouquidão:</span>
                <div className="text-sm font-semibold text-amber-400 mt-0.5">
                  {report.sectionC_texturaRouquidao.roughnessClassification}
                </div>
              </div>

              <div className="mt-3 space-y-2.5 text-xs sm:text-sm">
                <div>
                  <span className="text-xs text-slate-400 font-medium">Textura e Intensidade Percebida:</span>
                  <p className="text-slate-200 mt-0.5 leading-relaxed">
                    {report.sectionC_texturaRouquidao.textureAndPerceivedIntensity}
                  </p>
                </div>

                <div className="pt-2">
                  <span className="text-xs text-slate-400 font-medium">
                    Diferenciação: Características Vocais vs Efeitos de Estúdio:
                  </span>
                  <p className="text-slate-300 mt-0.5 leading-relaxed">
                    {report.sectionC_texturaRouquidao.vocalCharacteristicsVsEffects}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* D. EMOÇÃO E INTERPRETAÇÃO & E. NATURALIDADE E INDÍCIOS DE IA (GRID) */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* D. EMOÇÃO E INTERPRETAÇÃO */}
          <div className="p-5 rounded-2xl bg-[#0B0F17] border border-slate-800/90 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-800/80">
                <div>
                  <span className="text-[11px] font-mono text-amber-400 font-semibold">SEÇÃO D</span>
                  <h3 className="text-base font-bold text-slate-100">D. Emoção e Interpretação</h3>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy('SEC_D', formatSectionForCopy('D', report))}
                  className="min-h-[36px] px-2.5 py-1 rounded-lg border border-slate-800 hover:border-slate-700 text-xs text-slate-300 hover:text-amber-400 flex items-center gap-1 cursor-pointer transition-colors"
                >
                  {copiedKey === 'SEC_D' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedKey === 'SEC_D' ? 'Copiado' : 'Copiar Seção D'}</span>
                </button>
              </div>

              <div className="mt-4 pb-3 border-b border-slate-800/60">
                <span className="text-xs text-slate-400 font-medium">Emoções Transmitidas:</span>
                <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
                  {report.sectionD_emocaoInterpretacao.transmittedEmotions.map((emo, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-lg bg-[#111827] border border-slate-800 text-slate-200 text-xs font-medium"
                    >
                      {emo}
                    </span>
                  ))}
                </div>
              </div>

              <div className="mt-3 space-y-2.5 text-xs sm:text-sm">
                <div>
                  <span className="text-xs text-slate-400 font-medium">Dinâmica Vocal e Expressividade:</span>
                  <p className="text-slate-200 mt-0.5 leading-relaxed">
                    {report.sectionD_emocaoInterpretacao.vocalDynamicsAndExpressiveness}
                  </p>
                </div>

                <div className="pt-1">
                  <span className="text-xs text-slate-400 font-medium">Pausas, Respirações e Fraseado:</span>
                  <p className="text-slate-300 mt-0.5 leading-relaxed">
                    {report.sectionD_emocaoInterpretacao.pausesAndBreathing}
                  </p>
                </div>

                <div className="pt-1">
                  <span className="text-xs text-slate-400 font-medium">Vibrato, Articulação e Intensidade:</span>
                  <p className="text-slate-300 mt-0.5 leading-relaxed">
                    {report.sectionD_emocaoInterpretacao.vibratoAndArticulation} · {report.sectionD_emocaoInterpretacao.intensityChanges}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* E. NATURALIDADE E INDÍCIOS DE SÍNTESE ARTIFICIAL */}
          <div className="p-5 rounded-2xl bg-[#0B0F17] border border-slate-800/90 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-800/80">
                <div>
                  <span className="text-[11px] font-mono text-amber-400 font-semibold">SEÇÃO E</span>
                  <h3 className="text-base font-bold text-slate-100">E. Naturalidade &amp; Indícios de IA</h3>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy('SEC_E', formatSectionForCopy('E', report))}
                  className="min-h-[36px] px-2.5 py-1 rounded-lg border border-slate-800 hover:border-slate-700 text-xs text-slate-300 hover:text-amber-400 flex items-center gap-1 cursor-pointer transition-colors"
                >
                  {copiedKey === 'SEC_E' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedKey === 'SEC_E' ? 'Copiado' : 'Copiar Seção E'}</span>
                </button>
              </div>

              <div className="mt-4 flex items-center justify-between pb-3 border-b border-slate-800/60">
                <span className="text-xs text-slate-400">Classificação dos Indícios:</span>
                <div className={`px-3 py-1 rounded-xl border flex items-center gap-1.5 text-xs font-semibold ${aiBadge.bg}`}>
                  {aiBadge.icon}
                  <span>{report.sectionE_naturalidadeIndiciosIA.observableSignsClassification}</span>
                </div>
              </div>

              <div className="mt-3 space-y-2 text-xs sm:text-sm">
                <div>
                  <span className="text-xs text-slate-400 font-medium">Explicação da Classificação:</span>
                  <p className="text-slate-200 mt-0.5 leading-relaxed">
                    {report.sectionE_naturalidadeIndiciosIA.classificationExplanation}
                  </p>
                </div>

                <div className="pt-1">
                  <span className="text-xs text-slate-400 font-medium">Respirações, Articulação e Transições:</span>
                  <p className="text-slate-300 mt-0.5 leading-relaxed">
                    {report.sectionE_naturalidadeIndiciosIA.breathingAndArticulationNaturalness} · {report.sectionE_naturalidadeIndiciosIA.noteTransitionsAndContinuity}
                  </p>
                </div>

                <div className="pt-1">
                  <span className="text-xs text-slate-400 font-medium">Vibrato, Pronúncia e Artefatos:</span>
                  <p className="text-slate-300 mt-0.5 leading-relaxed">
                    {report.sectionE_naturalidadeIndiciosIA.vibratoUniformity} · {report.sectionE_naturalidadeIndiciosIA.pronunciationAndArtifacts}
                  </p>
                </div>

                <div className="pt-1">
                  <span className="text-xs text-slate-400 font-medium">Ponderação de Autotune / Efeitos &amp; Limitações:</span>
                  <p className="text-slate-400 mt-0.5 leading-relaxed italic text-xs">
                    {report.sectionE_naturalidadeIndiciosIA.autotuneAndStudioEffectsImpact} — {report.sectionE_naturalidadeIndiciosIA.limitationsOfEvaluation}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ANÁLISE TÉCNICA COMPLEMENTAR (F0, JITTER, SEMITONS, DISTINÇÃO COM TAXA DE AMOSTRAGEM) */}
        <div className="p-5 sm:p-6 rounded-2xl bg-[#0B0F17] border border-slate-800/90 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                <Activity className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[11px] font-mono text-amber-400 font-semibold">
                  ANÁLISE TÉCNICA COMPLEMENTAR
                </span>
                <h3 className="text-base sm:text-lg font-bold text-slate-100">
                  Frequência Fundamental (F0) &amp; Parâmetros de Sinal
                </h3>
              </div>
            </div>

            <button
              type="button"
              onClick={() => handleCopy('SEC_DSP', formatSectionForCopy('DSP', report))}
              className="min-h-[36px] px-2.5 py-1 rounded-lg border border-slate-800 hover:border-slate-700 text-xs text-slate-300 hover:text-amber-400 flex items-center gap-1 cursor-pointer transition-colors"
            >
              {copiedKey === 'SEC_DSP' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copiedKey === 'SEC_DSP' ? 'Copiado' : 'Copiar Análise Complementar'}</span>
            </button>
          </div>

          {/* Metric cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
            <div className="p-3.5 rounded-xl bg-[#111827] border border-slate-800/80">
              <span className="text-slate-400 font-medium">Frequência Fundamental F0:</span>
              <div className="text-sm font-bold text-slate-100 mt-1 font-mono">
                {report.sectionComplementar_dsp.f0RangeHz}
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#111827] border border-slate-800/80">
              <span className="text-slate-400 font-medium">Variação de Altura:</span>
              <div className="text-sm font-bold text-slate-100 mt-1 font-mono">
                {report.sectionComplementar_dsp.pitchRangeSemitones}
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#111827] border border-slate-800/80">
              <span className="text-slate-400 font-medium">Estabilidade Vocal / Jitter:</span>
              <div className="text-xs font-semibold text-amber-400 mt-1">
                {report.sectionComplementar_dsp.vocalStabilityJitter}
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#111827] border border-slate-800/80">
              <span className="text-slate-400 font-medium">Intensidade RMS Vocal:</span>
              <div className="text-sm font-bold text-slate-100 mt-1 font-mono">
                {report.sectionComplementar_dsp.vocalIntensityRmsDb}
              </div>
            </div>
          </div>

          <div className="space-y-2 text-xs sm:text-sm pt-1">
            <div>
              <span className="text-xs text-slate-400 font-medium">Características Espectrais &amp; Harmônicos:</span>
              <p className="text-slate-200 mt-0.5 leading-relaxed">
                {report.sectionComplementar_dsp.spectralCharacteristics}
              </p>
            </div>

            {/* Crucial distinction warning */}
            <div className="p-3 rounded-xl bg-amber-950/20 border border-amber-500/30 text-amber-200/90 text-xs">
              <strong className="text-amber-300 font-semibold">Distinção Rigorosa de Grandezas: </strong>
              <span>{report.sectionComplementar_dsp.sampleRateDistinctionNote}</span>
            </div>
          </div>
        </div>

        {/* F. CARACTERÍSTICAS VOCAIS RECOMENDADAS PARA RECRIAÇÃO NO SUNO */}
        <div className="p-5 sm:p-6 rounded-2xl bg-[#0B0F17] border border-slate-800/90 space-y-4">
          <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-amber-400" />
              <div>
                <span className="text-[11px] font-mono text-amber-400 font-semibold">SEÇÃO F</span>
                <h3 className="text-base sm:text-lg font-bold text-slate-100">
                  F. Características Vocais Recomendadas para Recriação (Suno AI)
                </h3>
              </div>
            </div>
            <button
              type="button"
              onClick={() => handleCopy('SEC_F', formatSectionForCopy('F', report))}
              className="min-h-[36px] px-2.5 py-1 rounded-lg border border-slate-800 hover:border-slate-700 text-xs text-slate-300 hover:text-amber-400 flex items-center gap-1 cursor-pointer transition-colors"
            >
              {copiedKey === 'SEC_F' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copiedKey === 'SEC_F' ? 'Copiado' : 'Copiar Seção F'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-[#111827] border border-slate-800/80">
              <span className="text-slate-400 font-medium">Tipo de Timbre:</span>
              <p className="text-slate-200 mt-1 leading-relaxed">
                {report.sectionF_caracteristicasRecriacao.timbreType}
              </p>
            </div>

            <div className="p-3 rounded-xl bg-[#111827] border border-slate-800/80">
              <span className="text-slate-400 font-medium">Textura e Nível de Rouquidão:</span>
              <p className="text-slate-200 mt-1 leading-relaxed">
                {report.sectionF_caracteristicasRecriacao.textureAndRoughness}
              </p>
            </div>

            <div className="p-3 rounded-xl bg-[#111827] border border-slate-800/80">
              <span className="text-slate-400 font-medium">Região Vocal Pretendida:</span>
              <p className="text-slate-200 mt-1 leading-relaxed">
                {report.sectionF_caracteristicasRecriacao.perceivedVocalRegister}
              </p>
            </div>

            <div className="p-3 rounded-xl bg-[#111827] border border-slate-800/80">
              <span className="text-slate-400 font-medium">Estilo de Interpretação e Emoção:</span>
              <p className="text-slate-200 mt-1 leading-relaxed">
                {report.sectionF_caracteristicasRecriacao.interpretationAndEmotion}
              </p>
            </div>

            <div className="p-3 rounded-xl bg-[#111827] border border-slate-800/80">
              <span className="text-slate-400 font-medium">Fraseado e Articulação:</span>
              <p className="text-slate-200 mt-1 leading-relaxed">
                {report.sectionF_caracteristicasRecriacao.deliveryAndPhrasing}
              </p>
            </div>

            <div className="p-3 rounded-xl bg-[#111827] border border-slate-800/80">
              <span className="text-slate-400 font-medium">Processamento &amp; Efeitos Desejáveis:</span>
              <p className="text-slate-200 mt-1 leading-relaxed">
                {report.sectionF_caracteristicasRecriacao.desirableEffectsAndProcessingLevel}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
