import {
  BatteryMedium,
  CircuitBoard,
  Cpu,
  HardDrive,
  Monitor,
  Smartphone,
  Thermometer,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardMeta, CardTitle } from "@/components/ui/card";
import { TIER_LABEL } from "@/lib/hardware/soc";
import { useCaliber } from "@/lib/store";

function fmtUnavailable(value: string | number | null | undefined, fallback: string) {
  if (value === null || value === undefined || value === "" || value === "Unavailable") return fallback;
  return String(value);
}

function mhzList(khz: number[]): string {
  if (!khz.length) return "";
  const mhz = [...new Set(khz.map((k) => Math.round(k / 1000)))].sort((a, b) => b - a);
  return mhz.map((m) => `${m} MHz`).join(" · ");
}

export function SpecsView() {
  const { dict, lang, hardware } = useCaliber();
  if (!hardware) return null;
  const h = hardware;
  const fallback = dict.unavailable;

  const rows = [
    {
      icon: Cpu,
      title: dict.cpu,
      body: h.socName,
      meta: `${h.cpuCores} ${dict.cores}${h.cpuMaxFreqKhz.length ? ` · ${mhzList(h.cpuMaxFreqKhz)}` : ` · ${dict.freq}: ${fallback}`}`,
      badge: TIER_LABEL[h.cpuTier][lang],
    },
    {
      icon: CircuitBoard,
      title: dict.gpu,
      body: h.gpuName,
      meta: `${h.abi === "Unavailable" ? fallback : h.abi}`,
      badge: TIER_LABEL[h.gpuTier][lang],
    },
    {
      icon: CircuitBoard,
      title: dict.ram,
      body: `${h.ramGb} GB${h.ramTypeEstimated ? ` · ${h.ramType} (${dict.estimated})` : ` · ${h.ramType}`}`,
      meta: `${h.ramAvailableGb.toFixed(1)} GB ${dict.available}`,
    },
    {
      icon: HardDrive,
      title: dict.storage,
      body: h.storageGb ? `${h.storageGb} GB · ${h.storageType}` : `${h.storageType}${h.storageTypeEstimated ? ` · ${dict.estimated}` : ""}`,
      meta: h.storageTypeEstimated ? dict.estimated : h.storageType,
    },
    {
      icon: Monitor,
      title: dict.display,
      body: `${h.displayWidth}×${h.displayHeight} · ${h.displayInches} ${dict.inches}${h.displayInchesEstimated ? ` · ${dict.estimated}` : ""}`,
      meta: `${h.refreshRate} Hz · ${dict.touchRate} ${h.touchSamplingHz} Hz${h.touchSamplingEstimated ? ` (${dict.estimated})` : ""} · ${h.densityDpi} dpi`,
    },
    {
      icon: BatteryMedium,
      title: dict.battery,
      body: h.batteryLevel === null ? fallback : `${h.batteryLevel}%`,
      meta: h.batteryTempC === null ? dict.thermal + ": " + fallback : `${h.batteryTempC}°C`,
    },
    {
      icon: Thermometer,
      title: dict.thermal,
      body: h.thermalStatus === "unavailable" ? fallback : h.thermalStatus,
      meta: dict.android,
    },
    {
      icon: Smartphone,
      title: dict.android,
      body: `${h.manufacturer} ${h.model}`,
      meta: `Android ${fmtUnavailable(h.androidVersion, fallback)} · ${dict.patch}: ${fmtUnavailable(h.securityPatch, fallback)}`,
    },
  ];

  return (
    <div className="stagger space-y-3">
      <p className="text-xs text-muted">{dict.catalogHint}</p>
      {rows.map((row) => (
        <Card key={row.title} className="rise flex items-start gap-3 p-3">
          <div className="grid size-10 shrink-0 place-items-center rounded-md bg-bg text-primary">
            <row.icon className="size-4" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <CardTitle className="text-xs uppercase tracking-[0.14em] text-subtle">{row.title}</CardTitle>
              {row.badge ? <Badge>{row.badge}</Badge> : null}
            </div>
            <p className="mt-0.5 truncate text-sm text-fg">{row.body}</p>
            <CardMeta className="truncate">{row.meta}</CardMeta>
          </div>
        </Card>
      ))}
      {h.notes.length ? (
        <ul className="space-y-1 px-1 text-[11px] leading-relaxed text-subtle">
          {h.notes.map((n) => (
            <li key={n}>{n}</li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}
