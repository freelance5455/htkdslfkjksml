import React from 'react';
import { ArrowLeft, Settings, Share2, HelpCircle, MoreVertical } from 'lucide-react';
import { ScreenType } from '../types';

interface TopAppBarProps {
  title: string;
  subtitle?: string;
  showBack?: boolean;
  onBack?: () => void;
  onSettingsClick?: () => void;
  badge?: string;
  badgeColor?: string;
}

export const TopAppBar: React.FC<TopAppBarProps> = ({
  title,
  subtitle,
  showBack = true,
  onBack,
  onSettingsClick,
  badge,
  badgeColor = 'bg-blue-100 text-blue-700 border-blue-200',
}) => {
  return (
    <div className="sticky top-0 bg-white/95 backdrop-blur-md z-30 border-b border-slate-200/80 px-4 py-3 flex items-center justify-between">
      <div className="flex items-center space-x-3">
        {showBack && (
          <button
            onClick={onBack}
            className="p-2 -ml-1 text-slate-700 hover:text-blue-600 hover:bg-slate-100 active:bg-slate-200 rounded-full transition-colors"
            title="Go Back"
          >
            <ArrowLeft className="w-5 h-5 stroke-[2.5]" />
          </button>
        )}
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-bold text-slate-900 tracking-tight leading-tight">
              {title}
            </h1>
            {badge && (
              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${badgeColor}`}>
                {badge}
              </span>
            )}
          </div>
          {subtitle && (
            <p className="text-xs text-slate-500 font-medium">{subtitle}</p>
          )}
        </div>
      </div>

      <div className="flex items-center space-x-1">
        {onSettingsClick && (
          <button
            onClick={onSettingsClick}
            className="p-2 text-slate-600 hover:text-blue-600 hover:bg-slate-100 rounded-full transition-colors"
            title="Settings"
          >
            <Settings className="w-5 h-5" />
          </button>
        )}
        <button
          onClick={() => alert("Feature preview shared with healthcare contacts!")}
          className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-full transition-colors"
          title="Share"
        >
          <Share2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
