import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Check, Coins, Redo2, Search, Sparkles, Undo2, UserPlus, X } from 'lucide-react';
import { AvatarConfig, CatalogCategory, CatalogItem, EmoteId } from '../types/game';
import {
  ACCESSORY_EFFECTS,
  BODY_SCALE_PRESETS,
  CATALOG_ITEMS,
  FACE_EXPRESSIONS,
  FOOT_TRAIL_STYLES,
  HAIR_STYLES,
  HAT_STYLES,
  IDLE_ANIMS,
  JUMP_ANIMS,
  MAKEUP_STYLES,
  SHOE_STYLES,
  WALK_ANIMS,
} from '../data/pickareData';
import { AvatarPreview3D } from './AvatarPreview3D';
import { MiniAvatarIcon } from './GameThumbnail';

interface AvatarPageProps {
  avatar: AvatarConfig;
  slapbux: number;
  ownedIds: string[];
  catalogItems?: CatalogItem[];
  playerName?: string;
  isPlus?: boolean;
  onUpdateAvatar: (next: AvatarConfig) => void;
  onBuyItem: (item: CatalogItem) => void;
  onOpenUgcStudio?: () => void;
  onBack: () => void;
}

const SKIN_SWATCHES = ['#fed7aa', '#fde047', '#d97706', '#92400e', '#f8fafc'];
const HAIR_SWATCHES = ['#18181b', '#451a03', '#facc15', '#dc2626', '#f8fafc', '#2563eb', '#ec4899'];
const SHIRT_SWATCHES = ['#111111', '#f8fafc', '#f472b6', '#2563eb', '#dc2626', '#16a34a', '#eab308'];
const PANTS_SWATCHES = ['#0f172a', '#e2e8f0', '#2563eb', '#3f6212', '#52525b'];
const SHOE_SWATCHES = ['#f8fafc', '#18181b', '#facc15', '#06b6d4', '#ea580c'];
const HAT_SWATCHES = ['#18181b', '#f8fafc', '#ef4444', '#eab308', '#ec4899'];

export const AvatarPage: React.FC<AvatarPageProps> = ({
  avatar,
  slapbux,
  ownedIds,
  catalogItems = CATALOG_ITEMS,
  playerName,
  isPlus = false,
  onUpdateAvatar,
  onBuyItem,
  onOpenUgcStudio,
  onBack,
}) => {
  const [mode, setMode] = useState<'marketplace' | 'customize'>('marketplace');
  const [catFilter, setCatFilter] = useState<'all' | CatalogCategory>('all');
  const [animMode, setAnimMode] = useState<'idle' | 'walk' | 'jump' | 'emote'>('idle');
  const [previewEmote, setPreviewEmote] = useState<EmoteId | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [bannerOpen, setBannerOpen] = useState(true);
  const [history, setHistory] = useState<AvatarConfig[]>([]);
  const [redoStack, setRedoStack] = useState<AvatarConfig[]>([]);
  const [previewItem, setPreviewItem] = useState<CatalogItem | null>(null);

  const commitAvatar = (next: AvatarConfig) => {
    setHistory((h) => [...h.slice(-15), avatar]);
    setRedoStack([]);
    onUpdateAvatar(next);
  };

  const handleUndo = () => {
    if (history.length === 0) return;
    const prev = history[history.length - 1];
    setHistory((h) => h.slice(0, -1));
    setRedoStack((r) => [avatar, ...r]);
    onUpdateAvatar(prev);
  };

  const handleRedo = () => {
    if (redoStack.length === 0) return;
    const next = redoStack[0];
    setRedoStack((r) => r.slice(1));
    setHistory((h) => [...h, avatar]);
    onUpdateAvatar(next);
  };

  const displayedAvatar = previewItem ? { ...avatar, ...previewItem.applyPatch } : avatar;

  const filteredCatalog = catalogItems.filter((item) => {
    if (catFilter !== 'all' && item.category !== catFilter) return false;
    if (
      query.trim() &&
      !item.name.toLowerCase().includes(query.trim().toLowerCase()) &&
      !item.creator.toLowerCase().includes(query.trim().toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  const handleSelectCatalogItem = (item: CatalogItem) => {
    setPreviewItem(item);
    if (item.previewMode === 'emote' && item.previewEmote) {
      setPreviewEmote(item.previewEmote);
      setAnimMode('emote');
    } else if (item.previewMode) {
      setPreviewEmote(null);
      setAnimMode(item.previewMode);
    } else {
      setPreviewEmote(null);
      setAnimMode('idle');
    }
  };

  const SHOP_TABS: { id: 'all' | CatalogCategory; label: string }[] = [
    { id: 'all', label: 'Semua' },
    { id: 'trail', label: 'Trail Kaki' },
    { id: 'expression', label: 'Ekspresi Wajah' },
    { id: 'ugc', label: 'UGC Kreator' },
    { id: 'hair', label: 'Rambut' },
    { id: 'hat', label: 'Topi' },
    { id: 'bundle', label: 'Avatar Jadi' },
    { id: 'idle', label: 'Animasi Idle' },
    { id: 'walk', label: 'Animasi Walk' },
    { id: 'jump', label: 'Animasi Jump' },
    { id: 'emote', label: 'Emote' },
    { id: 'makeup', label: 'Make Up' },
    { id: 'shirt', label: 'Baju' },
    { id: 'pants', label: 'Celana' },
    { id: 'shoes', label: 'Sepatu' },
    { id: 'accessory', label: 'Aksesoris Berefek' },
    { id: 'background', label: 'Latar Belakang' },
  ];

  return (
    <div className="flex-1 min-h-0 flex flex-col bg-white text-zinc-950 overflow-hidden">
      {/* Top 3D Viewport */}
      <div className="relative h-64 md:h-72 bg-zinc-100 shrink-0 border-b border-zinc-200">
        <AvatarPreview3D
          avatar={displayedAvatar}
          animMode={animMode}
          previewEmote={previewEmote}
          nameTag={playerName}
          isPlus={isPlus}
        />

        {/* Floating Top Controls */}
        <div className="absolute top-3 inset-x-3 flex items-center justify-between gap-2 pointer-events-none">
          <button
            type="button"
            onClick={onBack}
            aria-label="Kembali"
            className="pointer-events-auto p-2 rounded-full bg-white text-zinc-950 border border-zinc-300 shadow hover:bg-zinc-100 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>

          <div className="pointer-events-auto flex items-center p-1 rounded-full bg-white shadow border border-zinc-300">
            <button
              type="button"
              onClick={() => {
                setMode('marketplace');
                setPreviewItem(null);
                setPreviewEmote(null);
              }}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-full transition-colors cursor-pointer whitespace-nowrap ${
                mode === 'marketplace' ? 'bg-zinc-950 text-white' : 'text-zinc-600 hover:text-zinc-950'
              }`}
            >
              Marketplace
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('customize');
                setPreviewItem(null);
                setPreviewEmote(null);
              }}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-full transition-colors cursor-pointer whitespace-nowrap ${
                mode === 'customize' ? 'bg-zinc-950 text-white' : 'text-zinc-600 hover:text-zinc-950'
              }`}
            >
              Kustomisasi
            </button>
          </div>

          <button
            type="button"
            onClick={() => setSearchOpen((s) => !s)}
            aria-label="Cari item"
            className="pointer-events-auto p-2 rounded-full bg-white text-zinc-950 border border-zinc-300 shadow hover:bg-zinc-100 cursor-pointer"
          >
            <Search className="w-4 h-4" />
          </button>
        </div>

        {/* Left Mini Avatar + Right Slapbux Pill */}
        <div className="absolute left-3 top-14 flex flex-col items-center gap-1.5 bg-white border border-zinc-200 p-1.5 rounded-full shadow pointer-events-auto">
          <MiniAvatarIcon avatar={avatar} size={32} />
          <UserPlus className="w-4 h-4 text-zinc-800 mb-1" />
        </div>

        <div className="absolute right-3 top-14 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-zinc-950 text-white shadow text-xs font-bold font-mono-num">
          <Coins className="w-3.5 h-3.5 text-white" />
          {slapbux.toLocaleString('id-ID')}
        </div>

        {/* Bottom Left Undo / Redo + Animation Mode Toggle */}
        <div className="absolute left-3 bottom-3 flex items-center gap-2">
          <div className="flex items-center gap-1 bg-white border border-zinc-200 rounded-full px-2 py-1 shadow">
            <button
              type="button"
              onClick={handleUndo}
              disabled={history.length === 0}
              aria-label="Undo"
              className="p-1.5 text-zinc-800 disabled:opacity-35 cursor-pointer"
            >
              <Undo2 className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={handleRedo}
              disabled={redoStack.length === 0}
              aria-label="Redo"
              className="p-1.5 text-zinc-800 disabled:opacity-35 cursor-pointer"
            >
              <Redo2 className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-1 bg-white rounded-full p-1 shadow border border-zinc-300">
            {([
              { id: 'idle', label: 'Diam' },
              { id: 'walk', label: 'Jalan' },
              { id: 'jump', label: 'Lompat' },
            ] as const).map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => {
                  setPreviewEmote(null);
                  setAnimMode(m.id);
                }}
                className={`px-2.5 py-1 rounded-full text-[11px] font-bold cursor-pointer transition-colors ${
                  animMode === m.id ? 'bg-zinc-950 text-white' : 'text-zinc-600 hover:text-zinc-950'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
        </div>

        {/* Item Preview Floating Action */}
        {previewItem && (
          <motion.div
            initial={{ y: 12, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="absolute right-3 bottom-3 flex items-center gap-2 bg-zinc-950 text-white px-3.5 py-2 rounded-xl border border-white/15 shadow-lg max-w-[90vw]"
          >
            <div className="min-w-0">
              <div className="text-xs font-semibold truncate">{previewItem.name}</div>
              <div className="text-[10px] text-zinc-400 truncate">Oleh {previewItem.creator}</div>
            </div>
            {ownedIds.includes(previewItem.id) ? (
              <button
                type="button"
                onClick={() => {
                  if (previewItem.category !== 'emote') {
                    commitAvatar({ ...avatar, ...previewItem.applyPatch });
                  }
                  setPreviewItem(null);
                }}
                className="px-2.5 py-1 rounded-lg bg-white text-black text-xs font-bold cursor-pointer shrink-0"
              >
                {previewItem.category === 'emote' ? 'Dimiliki' : 'Pakai'}
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  onBuyItem(previewItem);
                  setPreviewItem(null);
                }}
                className="px-2.5 py-1 rounded-lg bg-white text-black text-xs font-bold cursor-pointer font-mono-num shrink-0"
              >
                Beli {previewItem.price.toLocaleString('id-ID')}
              </button>
            )}
          </motion.div>
        )}
      </div>

      {/* Bottom Sheet Content */}
      <div className="flex-1 min-h-0 overflow-y-auto px-4 md:px-6 py-4 space-y-4">
        {searchOpen && (
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Cari rambut, UGC kreator, topi, baju, celana, sepatu, animasi, emote..."
            className="w-full px-3.5 py-2 rounded-xl bg-zinc-100 border border-zinc-300 text-sm focus:outline-none focus:border-zinc-950"
          />
        )}

        {bannerOpen && mode === 'marketplace' && (
          <div className="flex flex-wrap items-center justify-between gap-3 px-3.5 py-2.5 rounded-xl bg-zinc-950 text-white text-xs">
            <span>
              Saldo kamu <strong className="font-mono-num">{slapbux.toLocaleString('id-ID')} Slapbux</strong>. Tersedia Rambut Keren, UGC Kreator, Topi, Make Up, Animasi & Emote!
            </span>
            <div className="flex items-center gap-2">
              {onOpenUgcStudio && (
                <button
                  type="button"
                  onClick={onOpenUgcStudio}
                  className="inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-white hover:bg-zinc-200 text-black text-[11px] font-bold cursor-pointer whitespace-nowrap"
                >
                  <Sparkles className="w-3 h-3" />
                  Buat & Jual UGC
                </button>
              )}
              <button type="button" onClick={() => setBannerOpen(false)} className="text-zinc-400 hover:text-white cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {mode === 'marketplace' ? (
          <>
            <div className="flex items-center gap-3 border-b border-zinc-200 pb-2 overflow-x-auto">
              {SHOP_TABS.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setCatFilter(t.id)}
                  className={`text-xs sm:text-sm font-semibold pb-1.5 border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    catFilter === t.id
                      ? 'text-zinc-950 border-zinc-950'
                      : 'text-zinc-500 border-transparent hover:text-zinc-900'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-display font-bold text-base text-zinc-950">
                  {SHOP_TABS.find((t) => t.id === catFilter)?.label} ({filteredCatalog.length})
                </h3>
                {catFilter === 'ugc' && onOpenUgcStudio && (
                  <button
                    type="button"
                    onClick={onOpenUgcStudio}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-zinc-950 text-white text-xs font-bold cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    Buka UGC Studio
                  </button>
                )}
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
                {filteredCatalog.map((item) => {
                  const owned = ownedIds.includes(item.id);
                  const selected = previewItem?.id === item.id;
                  const equipped =
                    (item.category === 'idle' && item.applyPatch.idleAnim && avatar.idleAnim === item.applyPatch.idleAnim) ||
                    (item.category === 'walk' && item.applyPatch.walkAnim && avatar.walkAnim === item.applyPatch.walkAnim) ||
                    (item.category === 'jump' && item.applyPatch.jumpAnim && avatar.jumpAnim === item.applyPatch.jumpAnim) ||
                    (item.category === 'shoes' && item.applyPatch.shoeStyle && avatar.shoeStyle === item.applyPatch.shoeStyle) ||
                    (item.category === 'makeup' && item.applyPatch.makeup && avatar.makeup === item.applyPatch.makeup) ||
                    (item.category === 'hair' && item.applyPatch.hairStyle && avatar.hairStyle === item.applyPatch.hairStyle) ||
                    (item.category === 'hat' && item.applyPatch.hatStyle && avatar.hatStyle === item.applyPatch.hatStyle) ||
                    (item.category === 'ugc' && item.ugcAttachment && avatar.ugcAttachment?.id === item.ugcAttachment.id) ||
                    (item.category === 'trail' && item.applyPatch.footTrail && (avatar.footTrail || 'none') === item.applyPatch.footTrail) ||
                    (item.category === 'expression' && item.applyPatch.faceExpression && (avatar.faceExpression || 'auto') === item.applyPatch.faceExpression) ||
                    (item.category === 'accessory' && item.applyPatch.effect && avatar.effect === item.applyPatch.effect && !item.applyPatch.hatStyle);
                  return (
                    <motion.button
                      key={item.id}
                      whileHover={{ y: -2 }}
                      whileTap={{ scale: 0.98 }}
                      type="button"
                      onClick={() => handleSelectCatalogItem(item)}
                      className={`text-left rounded-xl p-2 border transition-colors cursor-pointer ${
                        selected ? 'border-zinc-950 bg-zinc-100 ring-1 ring-zinc-950' : 'border-zinc-200 hover:border-zinc-400 bg-white'
                      }`}
                    >
                      <div
                        style={{ backgroundColor: `${item.accentColor}16` }}
                        className="h-24 rounded-lg flex items-center justify-center font-display text-2xl font-black text-zinc-950 relative border border-zinc-200/70"
                      >
                        {item.letter}
                        {item.badgeText && (
                          <span className="absolute top-1.5 left-1.5 px-1.5 py-0.5 rounded bg-zinc-950 text-white text-[9px] font-bold tracking-wider">
                            {item.badgeText}
                          </span>
                        )}
                        {owned && (
                          <span className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full bg-zinc-950 text-white flex items-center justify-center">
                            <Check className="w-3 h-3" />
                          </span>
                        )}
                      </div>
                      <div className="mt-2 text-xs font-bold text-zinc-950 truncate">{item.name}</div>
                      <div className="text-[11px] text-zinc-500 flex items-center gap-1 truncate">
                        <span>Oleh {item.creator}</span>
                        {item.verified && <span className="text-zinc-900 font-bold">✓</span>}
                      </div>
                      <div className="mt-1 text-xs font-bold text-zinc-900 font-mono-num">
                        {equipped ? 'Dipakai' : owned ? 'Dimiliki' : `${item.price.toLocaleString('id-ID')} Slapbux`}
                      </div>
                    </motion.button>
                  );
                })}
              </div>
            </div>
          </>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="space-y-3">
              <div>
                <div className="text-xs font-bold text-zinc-800 mb-1.5">Warna Kulit</div>
                <div className="flex flex-wrap gap-2">
                  {SKIN_SWATCHES.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => commitAvatar({ ...avatar, skinColor: c })}
                      style={{ backgroundColor: c }}
                      className={`w-8 h-8 rounded-lg border border-zinc-300 cursor-pointer ${
                        avatar.skinColor === c ? 'ring-2 ring-zinc-950 scale-105' : ''
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div>
                <div className="text-xs font-bold text-zinc-800 mb-1.5">Warna Baju</div>
                <div className="flex flex-wrap gap-2">
                  {SHIRT_SWATCHES.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => commitAvatar({ ...avatar, shirtColor: c })}
                      style={{ backgroundColor: c }}
                      className={`w-8 h-8 rounded-lg border border-zinc-300 cursor-pointer ${
                        avatar.shirtColor === c ? 'ring-2 ring-zinc-950 scale-105' : ''
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div>
                <div className="text-xs font-bold text-zinc-800 mb-1.5">Warna Celana</div>
                <div className="flex flex-wrap gap-2">
                  {PANTS_SWATCHES.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => commitAvatar({ ...avatar, pantsColor: c })}
                      style={{ backgroundColor: c }}
                      className={`w-8 h-8 rounded-lg border border-zinc-300 cursor-pointer ${
                        avatar.pantsColor === c ? 'ring-2 ring-zinc-950 scale-105' : ''
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-xs font-bold text-zinc-800 mb-1.5">
                  <span>Ukuran Tubuh (Bisa Dikecilin)</span>
                  <span className="font-mono-num text-zinc-600">{(avatar.bodyScale ?? 1).toFixed(2)}x</span>
                </div>
                <input
                  type="range"
                  min={0.5}
                  max={1.25}
                  step={0.05}
                  value={avatar.bodyScale ?? 1}
                  onChange={(e) => commitAvatar({ ...avatar, bodyScale: Number(e.target.value) })}
                  className="w-full accent-zinc-950 mb-2 cursor-pointer"
                />
                <div className="flex flex-wrap gap-1.5">
                  {BODY_SCALE_PRESETS.map((bp) => (
                    <button
                      key={bp.label}
                      type="button"
                      onClick={() => commitAvatar({ ...avatar, bodyScale: bp.scale })}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold border cursor-pointer ${
                        Math.abs((avatar.bodyScale ?? 1) - bp.scale) < 0.03
                          ? 'bg-zinc-950 text-white border-zinc-950'
                          : 'bg-zinc-100 text-zinc-800 border-zinc-200 hover:bg-zinc-200'
                      }`}
                    >
                      {bp.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-xs font-bold text-zinc-800 mb-1.5">Make Up Wajah</div>
                <div className="flex flex-wrap gap-1.5">
                  {MAKEUP_STYLES.map((mk) => (
                    <button
                      key={mk.id}
                      type="button"
                      onClick={() => commitAvatar({ ...avatar, makeup: mk.id })}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer ${
                        (avatar.makeup || 'none') === mk.id
                          ? 'bg-zinc-950 text-white border-zinc-950'
                          : 'bg-zinc-100 text-zinc-800 border-zinc-200 hover:bg-zinc-200'
                      }`}
                    >
                      {mk.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-xs font-bold text-zinc-800 mb-1.5">Face Expressions (Ekspresi Wajah)</div>
                <div className="flex flex-wrap gap-1.5">
                  {FACE_EXPRESSIONS.map((fe) => (
                    <button
                      key={fe.id}
                      type="button"
                      onClick={() => {
                        commitAvatar({ ...avatar, faceExpression: fe.id });
                        setPreviewEmote(null);
                        setAnimMode('idle');
                      }}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer ${
                        (avatar.faceExpression || 'auto') === fe.id
                          ? 'bg-zinc-950 text-white border-zinc-950'
                          : 'bg-zinc-100 text-zinc-800 border-zinc-200 hover:bg-zinc-200'
                      }`}
                    >
                      {fe.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-xs font-bold text-zinc-800 mb-1.5">Animasi Idle (Saat Diam)</div>
                <div className="flex flex-wrap gap-1.5">
                  {IDLE_ANIMS.map((ia) => (
                    <button
                      key={ia.id}
                      type="button"
                      onClick={() => {
                        commitAvatar({ ...avatar, idleAnim: ia.id });
                        setPreviewEmote(null);
                        setAnimMode('idle');
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer ${
                        (avatar.idleAnim || 'default') === ia.id
                          ? 'bg-zinc-950 text-white border-zinc-950'
                          : 'bg-zinc-100 text-zinc-800 border-zinc-200 hover:bg-zinc-200'
                      }`}
                    >
                      {ia.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-xs font-bold text-zinc-800 mb-1.5">Animasi Walk (Terpisah)</div>
                <div className="flex flex-wrap gap-1.5">
                  {WALK_ANIMS.map((wa) => (
                    <button
                      key={wa.id}
                      type="button"
                      onClick={() => {
                        commitAvatar({ ...avatar, walkAnim: wa.id });
                        setPreviewEmote(null);
                        setAnimMode('walk');
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer ${
                        avatar.walkAnim === wa.id
                          ? 'bg-zinc-950 text-white border-zinc-950'
                          : 'bg-zinc-100 text-zinc-800 border-zinc-200 hover:bg-zinc-200'
                      }`}
                    >
                      {wa.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-xs font-bold text-zinc-800 mb-1.5">Animasi Jump (Terpisah)</div>
                <div className="flex flex-wrap gap-1.5">
                  {JUMP_ANIMS.map((ja) => (
                    <button
                      key={ja.id}
                      type="button"
                      onClick={() => {
                        commitAvatar({ ...avatar, jumpAnim: ja.id });
                        setPreviewEmote(null);
                        setAnimMode('jump');
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer ${
                        avatar.jumpAnim === ja.id
                          ? 'bg-zinc-950 text-white border-zinc-950'
                          : 'bg-zinc-100 text-zinc-800 border-zinc-200 hover:bg-zinc-200'
                      }`}
                    >
                      {ja.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <div className="text-xs font-bold text-zinc-800 mb-1.5">Gaya Rambut & Warna Rambut</div>
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {HAIR_STYLES.map((hr) => (
                    <button
                      key={hr.id}
                      type="button"
                      onClick={() => commitAvatar({ ...avatar, hairStyle: hr.id })}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer ${
                        (avatar.hairStyle || 'none') === hr.id
                          ? 'bg-zinc-950 text-white border-zinc-950'
                          : 'bg-zinc-100 text-zinc-800 border-zinc-200 hover:bg-zinc-200'
                      }`}
                    >
                      {hr.label}
                    </button>
                  ))}
                </div>
                <div className="flex gap-2">
                  {HAIR_SWATCHES.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => commitAvatar({ ...avatar, hairColor: c })}
                      style={{ backgroundColor: c }}
                      className={`w-7 h-7 rounded-lg border border-zinc-300 cursor-pointer ${
                        (avatar.hairColor || '#18181b') === c ? 'ring-2 ring-zinc-950' : ''
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div>
                <div className="text-xs font-bold text-zinc-800 mb-1.5">Sepatu & Warna Sepatu</div>
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {SHOE_STYLES.map((sh) => (
                    <button
                      key={sh.id}
                      type="button"
                      onClick={() => commitAvatar({ ...avatar, shoeStyle: sh.id })}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer ${
                        avatar.shoeStyle === sh.id
                          ? 'bg-zinc-950 text-white border-zinc-950'
                          : 'bg-zinc-100 text-zinc-800 border-zinc-200 hover:bg-zinc-200'
                      }`}
                    >
                      {sh.label}
                    </button>
                  ))}
                </div>
                <div className="flex gap-2">
                  {SHOE_SWATCHES.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => commitAvatar({ ...avatar, shoeColor: c })}
                      style={{ backgroundColor: c }}
                      className={`w-7 h-7 rounded-lg border border-zinc-300 cursor-pointer ${
                        avatar.shoeColor === c ? 'ring-2 ring-zinc-950' : ''
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div>
                <div className="text-xs font-bold text-zinc-800 mb-1.5">Aksesoris Berefek</div>
                <div className="flex flex-wrap gap-1.5">
                  {ACCESSORY_EFFECTS.map((ef) => (
                    <button
                      key={ef.id}
                      type="button"
                      onClick={() => commitAvatar({ ...avatar, effect: ef.id })}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer ${
                        avatar.effect === ef.id
                          ? 'bg-zinc-950 text-white border-zinc-950'
                          : 'bg-zinc-100 text-zinc-800 border-zinc-200 hover:bg-zinc-200'
                      }`}
                    >
                      {ef.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-xs font-bold text-zinc-800 mb-1.5">Aura & Trail Kaki (Jejak Langkah)</div>
                <div className="flex flex-wrap gap-1.5">
                  {FOOT_TRAIL_STYLES.map((ft) => (
                    <button
                      key={ft.id}
                      type="button"
                      onClick={() => {
                        commitAvatar({ ...avatar, footTrail: ft.id });
                        setPreviewEmote(null);
                        if (ft.id !== 'none') setAnimMode('walk');
                      }}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer ${
                        (avatar.footTrail || 'none') === ft.id
                          ? 'bg-zinc-950 text-white border-zinc-950'
                          : 'bg-zinc-100 text-zinc-800 border-zinc-200 hover:bg-zinc-200'
                      }`}
                    >
                      {ft.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-xs font-bold text-zinc-800 mb-1.5">Aksesori Kepala & Pelengkap</div>
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {HAT_STYLES.map((hs) => (
                    <button
                      key={hs.id}
                      type="button"
                      onClick={() => commitAvatar({ ...avatar, hatStyle: hs.id })}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer ${
                        avatar.hatStyle === hs.id
                          ? 'bg-zinc-950 text-white border-zinc-950'
                          : 'bg-zinc-100 text-zinc-800 border-zinc-200'
                      }`}
                    >
                      {hs.label}
                    </button>
                  ))}
                </div>
                <div className="flex gap-2 mb-2.5">
                  {HAT_SWATCHES.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => commitAvatar({ ...avatar, hatColor: c })}
                      style={{ backgroundColor: c }}
                      className={`w-7 h-7 rounded-lg border border-zinc-300 cursor-pointer ${
                        avatar.hatColor === c ? 'ring-2 ring-zinc-950' : ''
                      }`}
                    />
                  ))}
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => commitAvatar({ ...avatar, hasWings: !avatar.hasWings })}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer ${
                      avatar.hasWings ? 'bg-zinc-950 text-white border-zinc-950' : 'bg-zinc-100 text-zinc-800 border-zinc-200'
                    }`}
                  >
                    Sayap: {avatar.hasWings ? 'Pakai' : 'Lepas'}
                  </button>
                  <button
                    type="button"
                    onClick={() => commitAvatar({ ...avatar, hasSword: !avatar.hasSword })}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer ${
                      avatar.hasSword ? 'bg-zinc-950 text-white border-zinc-950' : 'bg-zinc-100 text-zinc-800 border-zinc-200'
                    }`}
                  >
                    Pedang: {avatar.hasSword ? 'Pakai' : 'Lepas'}
                  </button>
                  <button
                    type="button"
                    onClick={() => commitAvatar({ ...avatar, headless: !avatar.headless })}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer ${
                      avatar.headless ? 'bg-zinc-950 text-white border-zinc-950' : 'bg-zinc-100 text-zinc-800 border-zinc-200'
                    }`}
                  >
                    Headless: {avatar.headless ? 'Aktif' : 'Normal'}
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      commitAvatar({ ...avatar, bgStyle: avatar.bgStyle === 'dark' ? 'studio' : 'dark' })
                    }
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold border cursor-pointer ${
                      avatar.bgStyle === 'dark'
                        ? 'bg-zinc-950 text-white border-zinc-950'
                        : 'bg-zinc-100 text-zinc-800 border-zinc-200'
                    }`}
                  >
                    Latar: {avatar.bgStyle === 'dark' ? 'Hitam' : 'Putih'}
                  </button>
                  {avatar.ugcAttachment && (
                    <button
                      type="button"
                      onClick={() => commitAvatar({ ...avatar, ugcAttachment: null })}
                      className="px-3 py-1.5 rounded-lg text-xs font-semibold border bg-zinc-950 text-white border-zinc-950 cursor-pointer"
                    >
                      Lepas UGC: {avatar.ugcAttachment.name}
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
