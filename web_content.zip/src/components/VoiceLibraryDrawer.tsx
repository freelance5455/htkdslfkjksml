import React, { useState } from 'react';
import { 
  X, 
  Play, 
  Volume2, 
  Sparkles, 
  Sliders, 
  Music, 
  Mic, 
  Tag, 
  Check, 
  PlusCircle,
  Bell,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Coins,
  Zap,
  Activity,
  Radio
} from 'lucide-react';
import { VoiceAlertPreset, SoundEffectType, AudioSettings, AssetData, AppLanguage } from '../types/market';
import { VOICE_ALERT_LIBRARY, SOUND_EFFECT_PRESETS, formatAlertScript } from '../services/voiceLibrary';
import { playChimeSound, speakText, executeVoiceAlert } from '../services/audioEngine';

interface VoiceLibraryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  audioSettings: AudioSettings;
  onUpdateAudioSettings: (settings: AudioSettings) => void;
  onSelectPresetForAlert: (preset: VoiceAlertPreset) => void;
  availableAssets: AssetData[];
}

export const VoiceLibraryDrawer: React.FC<VoiceLibraryDrawerProps> = ({
  isOpen,
  onClose,
  audioSettings,
  onUpdateAudioSettings,
  onSelectPresetForAlert,
  availableAssets,
}) => {
  const [activeTab, setActiveTab] = useState<'presets' | 'sounds' | 'settings'>('presets');
  const [selectedLanguage, setSelectedLanguage] = useState<'all' | AppLanguage>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [playingPresetId, setPlayingPresetId] = useState<string | null>(null);
  const [playingSoundId, setPlayingSoundId] = useState<string | null>(null);

  if (!isOpen) return null;

  // Filter presets
  const filteredPresets = VOICE_ALERT_LIBRARY.filter((preset) => {
    if (selectedLanguage !== 'all' && preset.language !== selectedLanguage) return false;
    if (selectedCategory !== 'all' && preset.category !== selectedCategory) return false;
    return true;
  });

  const handleTestPreset = async (preset: VoiceAlertPreset) => {
    setPlayingPresetId(preset.id);
    const demoAsset = availableAssets[0]?.symbol || 'BTC';
    const sampleScript = formatAlertScript(preset.script, demoAsset, 95500, 94520);
    
    await executeVoiceAlert(preset.defaultChime, sampleScript, audioSettings, preset.language);
    setPlayingPresetId(null);
  };

  const handleTestChime = async (soundId: SoundEffectType) => {
    setPlayingSoundId(soundId);
    await playChimeSound(soundId, audioSettings.volume);
    setTimeout(() => setPlayingSoundId(null), 600);
  };

  const handleTestVoiceConfig = async () => {
    const text = audioSettings.selectedPersona.startsWith('fr')
      ? 'Alerte MarketPulse validée. Volume et clarté vocale opérationnels.'
      : 'MarketPulse voice engine activated. Audio clarity and volume optimal.';
    await executeVoiceAlert('bell', text, audioSettings);
  };

  const getSoundIcon = (id: SoundEffectType) => {
    switch (id) {
      case 'bell': return <Bell className="w-4 h-4 text-amber-400" />;
      case 'bullish': return <TrendingUp className="w-4 h-4 text-emerald-400" />;
      case 'bearish': return <TrendingDown className="w-4 h-4 text-rose-400" />;
      case 'alarm': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'kaching': return <Coins className="w-4 h-4 text-yellow-400" />;
      case 'laser': return <Zap className="w-4 h-4 text-cyan-400" />;
      case 'pulsar': return <Activity className="w-4 h-4 text-purple-400" />;
      default: return <Radio className="w-4 h-4 text-blue-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-slate-950 border-l border-slate-800 flex flex-col h-full shadow-2xl">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
              <Mic className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h2 className="font-bold text-lg text-white font-['Chakra_Petch'] flex items-center gap-2">
                BIBLIOTHÈQUE D'ALERTES VOCALES
                <span className="text-[11px] font-mono font-semibold px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/20">
                  SOUNDBANK
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Catalogue de voix institutionnelles, carillons de trading et synthèse vocale
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-900/40 px-5 gap-2 pt-2">
          <button
            onClick={() => setActiveTab('presets')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold rounded-t-xl transition-all cursor-pointer border-b-2 ${
              activeTab === 'presets'
                ? 'bg-slate-950 text-amber-400 border-amber-500 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 border-transparent'
            }`}
          >
            <Mic className="w-4 h-4" />
            <span>Alertes Vocales ({VOICE_ALERT_LIBRARY.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('sounds')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold rounded-t-xl transition-all cursor-pointer border-b-2 ${
              activeTab === 'sounds'
                ? 'bg-slate-950 text-amber-400 border-amber-500 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 border-transparent'
            }`}
          >
            <Music className="w-4 h-4" />
            <span>Carillons & FX ({SOUND_EFFECT_PRESETS.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold rounded-t-xl transition-all cursor-pointer border-b-2 ${
              activeTab === 'settings'
                ? 'bg-slate-950 text-amber-400 border-amber-500 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 border-transparent'
            }`}
          >
            <Sliders className="w-4 h-4" />
            <span>Moteur Vocal</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          
          {/* TAB 1: PRESETS */}
          {activeTab === 'presets' && (
            <div className="space-y-4">
              
              {/* Filters */}
              <div className="flex flex-wrap items-center justify-between gap-2 p-3 rounded-xl bg-slate-900/60 border border-slate-800/80">
                {/* Language filter */}
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-xs text-slate-400 font-mono">LANGUE:</span>
                  {[
                    { code: 'all', label: 'Toutes' },
                    { code: 'fr', label: '🇫🇷 FR' },
                    { code: 'en', label: '🇬🇧 EN' },
                    { code: 'de', label: '🇩🇪 DE' },
                    { code: 'es', label: '🇪🇸 ES' },
                    { code: 'it', label: '🇮🇹 IT' },
                    { code: 'ar', label: '🇸🇦 العربية' },
                  ].map((btn) => (
                    <button
                      key={btn.code}
                      onClick={() => setSelectedLanguage(btn.code as any)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                        selectedLanguage === btn.code
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {btn.label}
                    </button>
                  ))}
                </div>

                {/* Category filter */}
                <div className="flex items-center gap-1.5 overflow-x-auto">
                  <span className="text-xs text-slate-400 font-mono">STYLE:</span>
                  {['all', 'breakout', 'profit', 'dump', 'whale', 'volatility'].map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-2 py-0.8 rounded-lg text-[11px] font-mono uppercase transition-colors cursor-pointer ${
                        selectedCategory === cat
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Presets List */}
              <div className="space-y-3">
                {filteredPresets.map((preset) => {
                  const isPlaying = playingPresetId === preset.id;
                  return (
                    <div
                      key={preset.id}
                      className="p-4 rounded-xl bg-slate-900/70 border border-slate-800 hover:border-slate-700 transition-all space-y-2.5"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-semibold text-sm text-white">{preset.title}</h4>
                            <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-slate-800 border border-slate-700 text-slate-300">
                              {preset.tag}
                            </span>
                            <span className="text-xs">
                              {preset.language === 'fr' ? '🇫🇷' : '🇺🇸'}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 mt-0.5">{preset.description}</p>
                        </div>

                        {/* Chime badge */}
                        <div className="flex items-center gap-1 text-[11px] font-mono px-2 py-1 rounded-lg bg-slate-800/80 border border-slate-700/60 text-slate-300">
                          {getSoundIcon(preset.defaultChime)}
                          <span className="capitalize">{preset.defaultChime}</span>
                        </div>
                      </div>

                      {/* Spoken Script Box */}
                      <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800/80 font-mono text-xs text-slate-300 italic flex items-center gap-2">
                        <span className="text-amber-400 font-bold not-italic">"</span>
                        <span className="flex-1">{preset.script}</span>
                        <span className="text-amber-400 font-bold not-italic">"</span>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center justify-end gap-2 pt-1">
                        <button
                          onClick={() => handleTestPreset(preset)}
                          disabled={isPlaying}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                            isPlaying
                              ? 'bg-amber-500 text-slate-950 animate-pulse'
                              : 'bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white'
                          }`}
                        >
                          <Play className={`w-3.5 h-3.5 ${isPlaying ? 'fill-slate-950' : 'fill-slate-200'}`} />
                          <span>{isPlaying ? 'Écoute en cours...' : 'Tester la Voix'}</span>
                        </button>

                        <button
                          onClick={() => onSelectPresetForAlert(preset)}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 text-xs font-semibold transition-all cursor-pointer"
                        >
                          <PlusCircle className="w-3.5 h-3.5" />
                          <span>Appliquer à un actif</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 2: SOUND EFFECTS */}
          {activeTab === 'sounds' && (
            <div className="space-y-4">
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400 leading-relaxed">
                Carillons et signaux d'alerte haute fidélité générés en temps réel par le synthétiseur Web Audio API. 
                Ces signaux précèdent les annonces vocales pour captiver l'attention du trader.
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {SOUND_EFFECT_PRESETS.map((sound) => {
                  const isPlaying = playingSoundId === sound.id;
                  return (
                    <div
                      key={sound.id}
                      className="p-4 rounded-xl bg-slate-900/80 border border-slate-800/90 hover:border-slate-700 flex flex-col justify-between transition-all"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2.5">
                          <div className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/60 flex items-center justify-center">
                            {getSoundIcon(sound.id)}
                          </div>
                          <div>
                            <h4 className="font-semibold text-sm text-white">{sound.name}</h4>
                            <span className="text-[10px] uppercase font-mono text-slate-400">
                              {sound.category}
                            </span>
                          </div>
                        </div>
                      </div>

                      <p className="text-xs text-slate-400 mb-3">{sound.description}</p>

                      <button
                        onClick={() => handleTestChime(sound.id)}
                        disabled={isPlaying}
                        className={`w-full py-2 rounded-lg flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer ${
                          isPlaying
                            ? 'bg-amber-400 text-slate-950 ring-2 ring-amber-400/50'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white'
                        }`}
                      >
                        <Play className={`w-3.5 h-3.5 ${isPlaying ? 'fill-slate-950' : 'fill-slate-200'}`} />
                        <span>{isPlaying ? 'Signal en cours...' : 'Écouter le Carillon'}</span>
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: VOICE SETTINGS */}
          {activeTab === 'settings' && (
            <div className="space-y-5">
              
              {/* Persona Selection */}
              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-3">
                <h3 className="font-semibold text-sm text-white flex items-center gap-2">
                  <Mic className="w-4 h-4 text-amber-400" />
                  <span>Persona Vocal & Accent</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {[
                    { id: 'fr-trader', name: '🇫🇷 Desk Parisien Pro', desc: 'Ton énergique et direct, idéal pour actions & crypto' },
                    { id: 'en-trader', name: '🇺🇸 US Trader Pro', desc: 'Punchy Wall Street style with high alert priority' },
                    { id: 'en-analyst', name: '🇬🇧 UK Financial Analyst', desc: 'Calm, measured, institutional executive tone' },
                    { id: 'cyber', name: '🤖 Cyber AI Sentinel', desc: 'Deep robotic synth modulation for automated triggers' },
                  ].map((p) => {
                    const isSelected = audioSettings.selectedPersona === p.id;
                    return (
                      <button
                        key={p.id}
                        onClick={() =>
                          onUpdateAudioSettings({
                            ...audioSettings,
                            selectedPersona: p.id as any,
                          })
                        }
                        className={`p-3 rounded-xl text-left border transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-amber-500/15 border-amber-500/50 text-white'
                            : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-semibold text-xs text-white">{p.name}</span>
                          {isSelected && <Check className="w-4 h-4 text-amber-400" />}
                        </div>
                        <p className="text-[11px] text-slate-400">{p.desc}</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Sliders: Rate, Pitch, Volume */}
              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-4">
                <h3 className="font-semibold text-sm text-white flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-amber-400" />
                  <span>Ajustements Audio & Débit</span>
                </h3>

                {/* Volume Slider */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-300">Volume Général</span>
                    <span className="font-mono text-amber-400 font-semibold">{Math.round(audioSettings.volume * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={audioSettings.volume}
                    onChange={(e) =>
                      onUpdateAudioSettings({
                        ...audioSettings,
                        volume: parseFloat(e.target.value),
                      })
                    }
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                {/* Speech Rate Slider */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-300">Vitesse de Parole (Débit)</span>
                    <span className="font-mono text-amber-400 font-semibold">{audioSettings.rate.toFixed(2)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.75"
                    max="1.4"
                    step="0.05"
                    value={audioSettings.rate}
                    onChange={(e) =>
                      onUpdateAudioSettings({
                        ...audioSettings,
                        rate: parseFloat(e.target.value),
                      })
                    }
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                {/* Pitch Slider */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-300">Tonalité (Pitch)</span>
                    <span className="font-mono text-amber-400 font-semibold">{audioSettings.pitch.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.8"
                    max="1.3"
                    step="0.05"
                    value={audioSettings.pitch}
                    onChange={(e) =>
                      onUpdateAudioSettings({
                        ...audioSettings,
                        pitch: parseFloat(e.target.value),
                      })
                    }
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                {/* Chime prefix toggle */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                  <div>
                    <span className="text-xs font-medium text-slate-200 block">
                      Jouer le carillon avant l'annonce vocale
                    </span>
                    <span className="text-[11px] text-slate-400">
                      Attire immédiatement l'attention dans la salle de marché
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={audioSettings.playChimeFirst}
                    onChange={(e) =>
                      onUpdateAudioSettings({
                        ...audioSettings,
                        playChimeFirst: e.target.checked,
                      })
                    }
                    className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
                  />
                </div>
              </div>

              {/* Test Audio Button */}
              <button
                onClick={handleTestVoiceConfig}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Volume2 className="w-4 h-4" />
                <span>Tester la Configuration Vocale</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
