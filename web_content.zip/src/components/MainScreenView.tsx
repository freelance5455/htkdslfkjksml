import React, { useState, useEffect, useRef } from 'react';
import { Settings, Play, Mic, MicOff, Volume2, PhoneCall, Cpu, ShieldCheck, AlertTriangle } from 'lucide-react';
import { JarvisSettings } from '../types';
import { playJarvisChime, playDiagnosticSweep, speakJarvis, stopSpeaking } from '../utils/audioSynthesizer';
import { performDeviceReadinessCheck } from '../utils/devicePermissions';

interface MainScreenViewProps {
  settings: JarvisSettings;
  onNavigateToSettings: () => void;
  onTriggerTestCall: () => void;
}

export const MainScreenView: React.FC<MainScreenViewProps> = ({
  settings,
  onNavigateToSettings,
  onTriggerTestCall,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [assistantMessage, setAssistantMessage] = useState(
    'At your service, Sir. Voice interface initialized.'
  );
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speechRecognized, setSpeechRecognized] = useState('');
  const recognitionRef = useRef<unknown>(null);

  // Initialize Web Speech API if supported
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognitionClass =
        (window as unknown as { SpeechRecognition?: unknown; webkitSpeechRecognition?: unknown })
          .SpeechRecognition ||
        (window as unknown as { SpeechRecognition?: unknown; webkitSpeechRecognition?: unknown })
          .webkitSpeechRecognition;

      if (SpeechRecognitionClass) {
        try {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          const recognition = new (SpeechRecognitionClass as any)();
          recognition.continuous = false;
          recognition.interimResults = true;
          recognition.lang = settings.voiceLanguage || 'en-US';

          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          recognition.onresult = (event: any) => {
            const transcript = Array.from(event.results)
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              .map((res: any) => res[0].transcript)
              .join('');
            setSpeechRecognized(transcript);
          };

          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          recognition.onend = () => {
            setIsListening(false);
            if (speechRecognized.trim()) {
              handleCommand(speechRecognized);
            }
          };

          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          recognition.onerror = () => {
            setIsListening(false);
          };

          recognitionRef.current = recognition;
        } catch {
          // SpeechRecognition fallback
        }
      }
    }
  }, [settings.voiceLanguage, speechRecognized]);

  const handleCommand = (command: string) => {
    const text = command.toLowerCase();
    let reply = `Understood, ${settings.userName}. Executing requested task.`;
    if (text.includes('time') || text.includes('clock')) {
      reply = `The current time is ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}, ${settings.userName}.`;
    } else if (text.includes('briefing') || text.includes('morning')) {
      reply = `Good morning, ${settings.userName}. Today's briefing is scheduled for ${settings.morningBriefingTime}. All systems nominal.`;
    } else if (text.includes('who are you') || text.includes('jarvis')) {
      reply = `I am JARVIS, your Personal Artificial Intelligence Voice Assistant, running locally on your device.`;
    }

    setAssistantMessage(reply);
    setIsSpeaking(true);
    speakJarvis(reply, settings.voicePitch, settings.voiceSpeed, settings.voicePersonality, () => {
      setIsSpeaking(false);
    });
  };

  const toggleMic = () => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
    }

    if (isListening) {
      setIsListening(false);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (recognitionRef.current as any)?.stop?.();
    } else {
      playJarvisChime();
      setIsListening(true);
      setSpeechRecognized('');
      setAssistantMessage(`Listening for your command, ${settings.userName}...`);

      if (recognitionRef.current) {
        try {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          (recognitionRef.current as any).start();
        } catch {
          simulateSpeechInteraction();
        }
      } else {
        simulateSpeechInteraction();
      }
    }
  };

  const simulateSpeechInteraction = () => {
    // Simulated voice loop if Web Speech Recognition isn't available or denied
    setTimeout(() => {
      setIsListening(false);
      const sampleQueries = [
        `Good morning, ${settings.userName}. Diagnostics complete. Core temperature 42°C, battery level 98%.`,
        `Briefing alert: Scheduled morning overview set for ${settings.morningBriefingTime}.`,
        `Encryption keys verified. Local data store synchronized with on-device preferences.`,
      ];
      const selected = sampleQueries[Math.floor(Math.random() * sampleQueries.length)];
      setAssistantMessage(selected);
      setIsSpeaking(true);
      speakJarvis(selected, settings.voicePitch, settings.voiceSpeed, settings.voicePersonality, () => {
        setIsSpeaking(false);
      });
    }, 2400);
  };

  const testJarvis = () => {
    playDiagnosticSweep();
    const testMsg = `Systems diagnostic complete. JARVIS audio and sensory matrix operating at peak efficiency, ${settings.userName}.`;
    setAssistantMessage(testMsg);
    setIsSpeaking(true);
    speakJarvis(testMsg, settings.voicePitch, settings.voiceSpeed, settings.voicePersonality, () => {
      setIsSpeaking(false);
    });
  };

  const waveActive = isListening || isSpeaking;

  return (
    <div className="w-full h-full flex flex-col justify-between p-5 bg-[#0A0E17] text-white relative select-none">
      {/* Background Subtle Tech Grid */}
      <div
        className="absolute inset-0 pointer-events-none opacity-5"
        style={{
          backgroundImage:
            'radial-gradient(#00E5FF 1px, transparent 1px), radial-gradient(#00E5FF 1px, #0A0E17 1px)',
          backgroundSize: '24px 24px',
          backgroundPosition: '0 0, 12px 12px',
        }}
      />

      {/* Top Header Bar */}
      <div className="flex items-center justify-between z-10 pt-1">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00E5FF] opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#00E676]"></span>
          </span>
          <span className="text-[11px] font-mono tracking-wider text-[#00E5FF] font-semibold">
            ONLINE // NOMINAL
          </span>
        </div>

        <button
          id="btn-nav-settings"
          onClick={onNavigateToSettings}
          className="w-10 h-10 rounded-full bg-[#131B2E] border border-white/10 flex items-center justify-center text-[#00E5FF] hover:bg-[#1C2640] transition-colors shadow-lg shadow-black/40"
          title="Open Settings"
        >
          <Settings className="w-5 h-5" />
        </button>
      </div>

      {/* Center HUD Section */}
      <div className="flex-1 flex flex-col items-center justify-center z-10 my-auto py-2">
        <div className="text-center mb-6">
          <h1 className="text-4xl font-bold tracking-[0.25em] text-white font-sans drop-shadow-[0_0_20px_rgba(0,229,255,0.4)]">
            JARVIS
          </h1>
          <p className="text-[10px] font-mono tracking-[0.25em] text-slate-400 mt-1 uppercase">
            Personal Artificial Intelligence
          </p>
        </div>

        {/* Large Arc-Reactor Microphone Button */}
        <div className="relative flex items-center justify-center my-3">
          {/* Pulsing Glow Rings */}
          <div
            className={`absolute w-52 h-52 rounded-full border border-[#00E5FF]/20 transition-all duration-1000 pointer-events-none ${
              waveActive ? 'scale-125 opacity-80 animate-pulse' : 'scale-100 opacity-30'
            }`}
          />
          <div
            className={`absolute w-44 h-44 rounded-full border-2 border-dashed border-[#00E5FF]/40 pointer-events-none ${
              waveActive ? 'animate-spin' : 'rotate-45'
            }`}
            style={{ animationDuration: waveActive ? '4s' : '20s' }}
          />

          {/* Reactor Center Clickable Core */}
          <button
            id="btn-arc-reactor-mic"
            onClick={toggleMic}
            className={`relative z-20 w-36 h-36 rounded-full flex flex-col items-center justify-center transition-all duration-300 shadow-2xl cursor-pointer ${
              isListening
                ? 'bg-gradient-to-b from-[#00E5FF] to-[#00838F] text-[#0A0E17] ring-8 ring-[#00E5FF]/30 scale-105'
                : 'bg-gradient-to-b from-[#162438] to-[#0F172A] text-white border border-[#00E5FF]/50 hover:border-[#00E5FF]'
            }`}
          >
            {isListening ? (
              <MicOff className="w-10 h-10 animate-bounce" />
            ) : (
              <Mic className="w-10 h-10 text-[#00E5FF]" />
            )}
            <span className="text-[10px] font-mono tracking-widest uppercase mt-1 font-semibold">
              {isListening ? 'LISTENING' : 'VOICE HUD'}
            </span>
          </button>
        </div>

        {/* Waveform Audio Visualizer */}
        <div className="w-full max-w-[280px] h-10 flex items-center justify-center gap-1.5 my-3 px-4">
          {Array.from({ length: 20 }).map((_, i) => {
            const delay = (i % 5) * 0.15;
            return (
              <div
                key={i}
                className={`w-1 rounded-full transition-all duration-150 ${
                  waveActive
                    ? 'bg-[#00E5FF] shadow-[0_0_8px_#00E5FF]'
                    : 'bg-[#00E5FF]/20 h-2'
                }`}
                style={{
                  height: waveActive ? `${Math.sin(i * 0.8 + Date.now() / 300) * 16 + 20}px` : '6px',
                  transitionDelay: `${delay}s`,
                }}
              />
            );
          })}
        </div>

        {/* Assistant Live Transcript / Feedback Card */}
        <div
          id="assistant-status-card"
          className="w-full max-w-[340px] bg-[#131B2E]/90 border border-slate-800 rounded-xl p-3.5 flex items-start gap-3 shadow-lg"
        >
          <div className="p-1.5 rounded-lg bg-[#00E5FF]/10 text-[#00E5FF] shrink-0 mt-0.5">
            <Volume2 className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 mb-0.5">
              <span>JARVIS CORE</span>
              <span className="text-[#00E5FF]">v1.0.0</span>
            </div>
            <p className="text-xs text-slate-200 leading-relaxed font-sans line-clamp-3">
              {assistantMessage}
            </p>
            {speechRecognized && (
              <p className="text-[11px] font-mono text-[#00E5FF] mt-1 border-t border-slate-800 pt-1">
                Voice Input: &quot;{speechRecognized}&quot;
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Bottom Actions Section */}
      <div className="flex flex-col gap-2.5 z-10 pb-1">
        {/* Test JARVIS Main Button */}
        <button
          id="btn-test-jarvis"
          onClick={testJarvis}
          className="w-full h-12 rounded-xl bg-[#00E5FF] hover:bg-[#00c4db] text-[#0A0E17] font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#00E5FF]/20 transition-transform active:scale-[0.98] tracking-wide"
        >
          <Play className="w-4 h-4 fill-current" />
          TEST JARVIS
        </button>

        {/* Test JARVIS Call Trigger */}
        <button
          id="btn-test-jarvis-call-main"
          onClick={onTriggerTestCall}
          className="w-full h-11 rounded-xl bg-[#131B2E] hover:bg-[#1C2640] border border-[#00E5FF]/30 text-[#00E5FF] font-mono text-xs flex items-center justify-center gap-2 transition-colors active:scale-[0.98]"
        >
          <PhoneCall className="w-3.5 h-3.5" />
          TEST JARVIS CALL (INCOMING)
        </button>

        {/* Telemetry Quick Bar */}
        {(() => {
          const audit = performDeviceReadinessCheck(settings);
          return (
            <div className="flex items-center justify-around py-1.5 px-3 rounded-lg bg-black/40 border border-white/5 text-[10px] font-mono text-slate-400">
              <div className="flex items-center gap-1">
                <Cpu className="w-3 h-3 text-[#00E5FF]" />
                <span>KOTLIN + COMPOSE</span>
              </div>
              <span className="text-slate-600">|</span>
              <button
                type="button"
                id="btn-hud-readiness"
                onClick={onNavigateToSettings}
                className="flex items-center gap-1 hover:text-cyan-300 transition-colors cursor-pointer"
                title="Click to open Permissions & Device Setup"
              >
                {audit.isFullyReady ? (
                  <ShieldCheck className="w-3 h-3 text-[#00E676]" />
                ) : (
                  <AlertTriangle className="w-3 h-3 text-amber-400" />
                )}
                <span>DEVICE: {audit.grantedCount}/8 READY</span>
              </button>
            </div>
          );
        })()}
      </div>
    </div>
  );
};
