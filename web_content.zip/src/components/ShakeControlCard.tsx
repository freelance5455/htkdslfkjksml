import React, { useEffect, useState } from 'react';
import { Smartphone, Check, Zap, AlertCircle } from 'lucide-react';
import { ShakeSensitivity, ShakeStatus, shakeService } from '../utils/shakeDetector';
import { soundService } from '../utils/sound';

interface ShakeControlCardProps {
  isOled: boolean;
  onSimulateShake: () => void;
}

export const ShakeControlCard: React.FC<ShakeControlCardProps> = ({
  isOled,
  onSimulateShake,
}) => {
  const [status, setStatus] = useState<ShakeStatus>(shakeService.getStatus());
  const [justShaken, setJustShaken] = useState(false);

  useEffect(() => {
    const unsub = shakeService.subscribeStatus(setStatus);
    shakeService.startListening();

    const unsubShake = shakeService.subscribeShake(() => {
      setJustShaken(true);
      setTimeout(() => setJustShaken(false), 800);
    });

    return () => {
      unsub();
      unsubShake();
    };
  }, []);

  const handleToggle = () => {
    soundService.playTick();
    const nextState = !status.enabled;
    shakeService.setEnabled(nextState);
    if (nextState && status.permissionState === 'unknown') {
      shakeService.requestPermission();
    }
  };

  const handleSensitivity = (sens: ShakeSensitivity) => {
    soundService.playTick();
    shakeService.setSensitivity(sens);
  };

  const handleRequestPermission = async () => {
    soundService.playTick();
    await shakeService.requestPermission();
  };

  const handleTestShake = () => {
    soundService.playTick();
    setJustShaken(true);
    setTimeout(() => setJustShaken(false), 800);
    onSimulateShake();
  };

  return (
    <div
      className={`rounded-2xl p-4 sm:p-5 border transition-all ${
        isOled
          ? 'bg-black border-neutral-800'
          : 'bg-slate-900/60 border-slate-800 backdrop-blur-sm'
      }`}
    >
      {/* Title & Enable Switch */}
      <div className="flex items-center justify-between gap-4 mb-3">
        <div className="flex items-center gap-3 min-w-0">
          <div
            className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${
              status.enabled
                ? 'bg-cyan-500/10 border-cyan-500/40 text-cyan-400 shadow-[0_0_12px_rgba(0,240,255,0.25)]'
                : 'bg-slate-800/40 border-slate-700 text-slate-400'
            }`}
          >
            <Smartphone
              className={`w-5 h-5 transition-transform ${
                justShaken ? 'rotate-12 scale-110 text-cyan-300' : ''
              }`}
            />
          </div>
          <div className="min-w-0">
            <h3 className="text-sm font-semibold text-white tracking-tight truncate">
              Zatřesení telefonem (Shake-to-Toggle)
            </h3>
            <p className="text-xs text-slate-400 truncate">
              {status.enabled
                ? 'Zatřesením rozsvítíte nebo zhasnete svítilnu'
                : 'Funkce zatřesení je vypnuta'}
            </p>
          </div>
        </div>

        {/* Custom Toggle Switch */}
        <button
          onClick={handleToggle}
          role="switch"
          aria-checked={status.enabled}
          aria-label="Zapnout ovládání zatřesením"
          className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
            status.enabled ? 'bg-cyan-500 shadow-[0_0_10px_#00F0FF]' : 'bg-slate-800'
          }`}
        >
          <span
            className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
              status.enabled ? 'translate-x-5' : 'translate-x-0'
            }`}
          />
        </button>
      </div>

      {/* Shake detector details when enabled */}
      {status.enabled && (
        <div className="space-y-3 pt-2 border-t border-slate-800/60">
          {/* iOS permission required banner */}
          {status.permissionState === 'unknown' && typeof window !== 'undefined' && 'DeviceMotionEvent' in window && (
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-cyan-950/40 border border-cyan-700/40 text-xs text-cyan-200">
              <span className="flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Povolit senzor akcelerometru pro zatřesení</span>
              </span>
              <button
                onClick={handleRequestPermission}
                className="px-2.5 py-1 rounded bg-cyan-500 text-slate-950 font-bold text-[11px] hover:bg-cyan-400 cursor-pointer shrink-0 ml-2"
              >
                Povolit
              </button>
            </div>
          )}

          {/* Real-time Shake Meter */}
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
              <span>Citlivost senzoru pohybu</span>
              <span className="text-cyan-400 font-mono text-[11px] tabular-nums">
                {justShaken ? 'ZATŘESENO!' : `Intenzita: ${status.currentIntensity}%`}
              </span>
            </div>
            {/* Intensity Progress Bar */}
            <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div
                className={`h-full transition-all duration-100 ${
                  justShaken
                    ? 'bg-cyan-400 shadow-[0_0_8px_#00F0FF]'
                    : status.currentIntensity > 50
                    ? 'bg-amber-400'
                    : 'bg-cyan-600'
                }`}
                style={{ width: `${Math.max(4, status.currentIntensity)}%` }}
              />
            </div>
          </div>

          {/* Sensitivity options selector */}
          <div className="flex items-center justify-between gap-2 pt-1">
            <span className="text-xs text-slate-400">Práh zatřesení:</span>
            <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-950/80 border border-slate-800">
              {(['high', 'medium', 'low'] as ShakeSensitivity[]).map((sens) => {
                const label = sens === 'high' ? 'Vysoká' : sens === 'medium' ? 'Střední' : 'Nízká';
                const isSelected = status.sensitivity === sens;
                return (
                  <button
                    key={sens}
                    onClick={() => handleSensitivity(sens)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-cyan-500 text-slate-950 font-semibold shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Simulation / Desktop test button */}
          <div className="flex items-center justify-between pt-1">
            <span className="text-[11px] text-slate-500">
              Testujete na počítači nebo v simulátoru?
            </span>
            <button
              onClick={handleTestShake}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-950 border border-slate-700/80 text-slate-200 hover:border-cyan-400 hover:text-cyan-300 transition-colors cursor-pointer active:scale-95"
            >
              <Zap className="w-3.5 h-3.5 text-cyan-400" />
              <span>Vyzkoušet zatřesení</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
