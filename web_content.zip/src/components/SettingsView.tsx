import React from 'react';
import { AppTheme, ThemeConfig, UserSettings } from '../types';
import { THEMES, THEME_CONFIGS, playChimeSound, toPersianDigits } from '../utils/tajrobiData';
import {
  Settings,
  Bell,
  Volume2,
  Moon,
  Sun,
  Target,
  RotateCcw,
  Palette,
  CheckCircle2,
  Calendar,
  Download,
} from 'lucide-react';

interface SettingsViewProps {
  settings: UserSettings;
  onUpdateSettings: (newSettings: Partial<UserSettings>) => void;
  onResetAllData: () => void;
  onResetOnlyParts?: () => void;
  onOpenTabCustomizer?: () => void;
  onDownloadOffline?: () => void;
  onShowToast: (message: string, type: 'success' | 'warning' | 'info') => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  onResetAllData,
  onResetOnlyParts,
  onOpenTabCustomizer,
  onDownloadOffline,
  onShowToast,
}) => {
  const currentTheme = THEME_CONFIGS[settings.theme || 'emerald'] || THEME_CONFIGS.emerald;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Top Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-2xs">
        <h2 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
          <Settings className="w-5 h-5 text-emerald-600" />
          <span>تنظیمات عمومی، تم رنگی و اهداف درسی</span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          شخصی‌سازی ظاهر برنامه، انتخاب پالت رنگی، اهداف روزانه تست و زنگ ملایم پایان مطالعه
        </p>
      </div>

      {/* Theme Picker Card */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-2xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Palette className="w-4 h-4 text-purple-500" />
              <span>پالت‌های رنگی و تم‌های اختصاصی کنکور</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              تم فعلی: <strong className="text-slate-800 dark:text-slate-200">{currentTheme.name}</strong>
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
          {THEMES.map((th) => {
            const isSelected = (settings.theme || 'emerald') === th.id;
            return (
              <button
                key={th.id}
                type="button"
                onClick={() => {
                  onUpdateSettings({ theme: th.id });
                  onShowToast(`تم «${th.name}» فعال شد ✨`, 'success');
                }}
                className={`p-3.5 rounded-2xl border text-right transition flex flex-col justify-between cursor-pointer ${
                  isSelected
                    ? 'border-2 border-slate-900 dark:border-white bg-slate-50 dark:bg-slate-800 shadow-sm'
                    : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span
                    className="w-5 h-5 rounded-full inline-block shadow-xs"
                    style={{ backgroundColor: th.accentColor }}
                  />
                  {isSelected && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                </div>
                <div className="mt-3">
                  <span className="text-xs font-black text-slate-900 dark:text-white block">
                    {th.name}
                  </span>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    {th.englishName}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Card 1: Exam & Goals */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-2xs space-y-4">
          <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
            <Target className="w-4 h-4 text-emerald-600" />
            <span>اهداف درسی و آزمون سراسری</span>
          </h3>

          <div>
            <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
              نام داوطلب:
            </label>
            <input
              type="text"
              value={settings.studentName}
              onChange={(e) => onUpdateSettings({ studentName: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
              عنوان آزمون اصلی:
            </label>
            <input
              type="text"
              value={settings.examTitle}
              onChange={(e) => onUpdateSettings({ examTitle: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                تعداد تست هدف روزانه:
              </label>
              <input
                type="number"
                min={10}
                max={500}
                step={10}
                value={settings.dailyTestGoal}
                onChange={(e) => onUpdateSettings({ dailyTestGoal: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-600 dark:text-slate-300 block mb-1">
                ساعت مطالعه هفتگی:
              </label>
              <input
                type="number"
                min={5}
                max={100}
                value={Math.round(settings.weeklyStudyMinutesGoal / 60)}
                onChange={(e) =>
                  onUpdateSettings({ weeklyStudyMinutesGoal: Number(e.target.value) * 60 })
                }
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200"
              />
            </div>
          </div>
        </div>

        {/* Card 2: Audio & System Preferences */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 shadow-2xs space-y-4">
          <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-emerald-600" />
            <span>تنظیمات صوتی و وضعیت سیستم</span>
          </h3>

          {/* Sound Chime */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
            <div>
              <div className="text-xs font-bold text-slate-900 dark:text-white">
                زنگ ملایم پایان پارت
              </div>
              <div className="text-[11px] text-slate-500">
                پخش صدای آرامش‌بخش پایان تایمر
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                playChimeSound();
                onShowToast('آکورد صوتی با موفقیت تست شد 🎵', 'info');
              }}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition cursor-pointer"
            >
              تست صدا 🔔
            </button>
          </div>

          {/* Theme Mode */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
            <div>
              <div className="text-xs font-bold text-slate-900 dark:text-white">
                حالت تاریک (Dark Mode)
              </div>
              <div className="text-[11px] text-slate-500">
                کاهش خستگی چشم هنگام مطالعه شب
              </div>
            </div>
            <button
              type="button"
              onClick={() => onUpdateSettings({ darkMode: !settings.darkMode })}
              className={`p-2 rounded-xl border transition cursor-pointer ${
                settings.darkMode
                  ? 'bg-amber-500 text-white border-amber-600'
                  : 'bg-white text-slate-700 border-slate-200'
              }`}
            >
              {settings.darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>

          {/* Tab Reordering */}
          {onOpenTabCustomizer && (
            <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <div>
                <div className="text-xs font-bold text-slate-900 dark:text-white">
                  ترتیب و جابجایی تب‌های بالای صفحه
                </div>
                <div className="text-[11px] text-slate-500">
                  تغییر ترتیب تب‌های داشبورد، استراتژی، برنامه هفتگی و پارت‌ها
                </div>
              </div>
              <button
                type="button"
                onClick={onOpenTabCustomizer}
                className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold transition cursor-pointer"
              >
                ⚙️ جابجایی تب‌ها
              </button>
            </div>
          )}

          {/* Download Offline HTML App */}
          {onDownloadOffline && (
            <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <div>
                <div className="text-xs font-bold text-slate-900 dark:text-white">
                  خروجی و دانلود فایل آفلاین برنامه
                </div>
                <div className="text-[11px] text-slate-500">
                  ذخیره فایل HTML مستقل جهت اجرا در تمام دستگاه‌ها بدون اینترنت
                </div>
              </div>
              <button
                type="button"
                onClick={onDownloadOffline}
                className="px-3.5 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>دانلود تک‌فایل</span>
              </button>
            </div>
          )}

          {/* Reset Only Parts */}
          {onResetOnlyParts && (
            <div className="pt-2">
              <button
                type="button"
                onClick={onResetOnlyParts}
                className="w-full py-2.5 rounded-xl border border-amber-300 text-amber-700 dark:text-amber-300 hover:bg-amber-50 dark:hover:bg-amber-950/40 text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>🧹 بازنشانی فقط پارت‌های مطالعه (حفظ آزمون‌ها و سوابق)</span>
              </button>
            </div>
          )}

          {/* Reset All Data */}
          <div className="pt-1">
            <button
              type="button"
              onClick={onResetAllData}
              className="w-full py-2.5 rounded-xl border border-rose-300 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>بازنشانی تمام داده‌ها به حالت اولیه</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
