import React, { useState } from 'react';
import { Monitor, Moon, ShieldCheck, Sun, UserRound } from 'lucide-react';
import { apiRequest } from '../lib/api';
import type { NavSection, ThemeMode, UserAccount } from '../types/studio';

interface SettingsViewProps {
  user: UserAccount;
  theme: ThemeMode;
  onSetTheme: (theme: ThemeMode) => void;
  onUserUpdated: (user: UserAccount) => void;
  onNavigate: (section: NavSection) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  user,
  theme,
  onSetTheme,
  onUserUpdated,
  onNavigate,
}) => {
  const [savingTheme, setSavingTheme] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleThemeChange = async (next: ThemeMode) => {
    onSetTheme(next);
    setSavingTheme(true);
    setFeedback(null);
    try {
      const res = await apiRequest<{ ok: boolean; user: UserAccount }>('/api/auth/profile', {
        method: 'PUT',
        body: JSON.stringify({ themePref: next }),
      });
      onUserUpdated({ ...user, ...res.user, themePref: next });
      setFeedback(
        `Tema tercihiniz "${next === 'dark' ? 'Koyu Mod' : 'Açık Mod'}" olarak kaydedildi.`
      );
    } catch {
      // Theme still applied locally
    } finally {
      setSavingTheme(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-[#F8FAFC]">
          Platform Ayarları
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-[#94A3B8]">
          Görünüm teması, hesap güvenliği ve derleme çalışma tercihlerinizi yönetin.
        </p>
      </div>

      {feedback && (
        <div className="px-4 py-3 rounded-xl bg-emerald-500/10 border border-emerald-500/25 text-xs text-emerald-700 dark:text-emerald-300">
          {feedback}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Theme Selector */}
        <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-6 space-y-4">
          <div className="flex items-center gap-2.5">
            <Monitor className="w-4 h-4 text-[#6366F1]" />
            <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
              Görünüm & Tema Desteği
            </h2>
          </div>
          <p className="text-xs text-slate-600 dark:text-[#94A3B8]">
            Açık veya koyu tema arasında geçiş yapın. Tercihiniz profilinizle senkronize edilir.
          </p>

          <div className="grid grid-cols-2 gap-3 pt-1">
            <button
              type="button"
              disabled={savingTheme}
              onClick={() => void handleThemeChange('dark')}
              className={`p-4 rounded-xl border text-left transition-colors ${
                theme === 'dark'
                  ? 'border-[#6366F1] bg-[#6366F1]/10'
                  : 'border-slate-200 dark:border-white/[0.08] bg-slate-50 dark:bg-[#0B1020]'
              }`}
            >
              <Moon className="w-4 h-4 text-[#6366F1] mb-2" />
              <div className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC]">
                Koyu Tema
              </div>
              <div className="mt-0.5 text-[11px] text-slate-500 dark:text-[#94A3B8]">
                #0B1020 Gece Stüdyo
              </div>
            </button>

            <button
              type="button"
              disabled={savingTheme}
              onClick={() => void handleThemeChange('light')}
              className={`p-4 rounded-xl border text-left transition-colors ${
                theme === 'light'
                  ? 'border-[#6366F1] bg-[#6366F1]/10'
                  : 'border-slate-200 dark:border-white/[0.08] bg-slate-50 dark:bg-[#0B1020]'
              }`}
            >
              <Sun className="w-4 h-4 text-[#EAB308] mb-2" />
              <div className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC]">
                Açık Tema
              </div>
              <div className="mt-0.5 text-[11px] text-slate-500 dark:text-[#94A3B8]">
                Yüksek Kontrast Gündüz
              </div>
            </button>
          </div>
        </div>

        {/* Security & Profile Shortcuts */}
        <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-6 space-y-4">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-4 h-4 text-[#22C55E]" />
            <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
              Hesap ve Güvenlik Kısayolları
            </h2>
          </div>
          <p className="text-xs text-slate-600 dark:text-[#94A3B8]">
            Profil bilgilerinizi, profil fotoğrafınızı ve şifrenizi Hesabım ekranından güncelleyin.
          </p>

          <div className="space-y-2.5 pt-1">
            <button
              type="button"
              onClick={() => onNavigate('account')}
              className="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-slate-200 dark:border-white/[0.08] bg-slate-50 dark:bg-[#0B1020] hover:border-[#6366F1] text-xs font-medium text-slate-900 dark:text-[#F8FAFC] transition-colors"
            >
              <span className="inline-flex items-center gap-2">
                <UserRound className="w-4 h-4 text-[#6366F1]" />
                <span>Profil Düzenle & Şifre Değiştir</span>
              </span>
              <span className="text-slate-400">Aç</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('settings')}
              className="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-slate-200 dark:border-white/[0.08] bg-slate-50 dark:bg-[#0B1020] hover:border-[#6366F1] text-xs font-medium text-slate-900 dark:text-[#F8FAFC] transition-colors"
            >
              <span>Varsayılan Proje APK Yapılandırması</span>
              <span className="text-slate-400">Aç</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
