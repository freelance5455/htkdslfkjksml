import React, { useCallback, useEffect, useState } from 'react';
import {
  BatteryLow,
  CheckCircle2,
  Mic,
  RotateCcw,
  ShieldCheck,
  Smartphone,
  Trash2,
  Volume2,
  XCircle,
} from 'lucide-react';
import type { BatteryStatus } from '../hooks/useBatteryMonitor';
import type {
  PreferredLanguage,
  ResponseLength,
  SpeechLanguage,
  ThemeBrightness,
  UserSettings,
} from '../types';
import { PWAInstallButton } from './PWAInstallButton';

interface SettingsViewProps {
  settings: UserSettings;
  batteryStatus: BatteryStatus;
  isLowPowerActive: boolean;
  onUpdateSettings: (patch: Partial<UserSettings>) => void;
  onResetSettings: () => void;
  onClearAllChats: () => void;
}

interface HealthStatus {
  loading: boolean;
  paused?: boolean;
  geminiConfigured: boolean;
  searchAvailable: boolean;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  batteryStatus,
  isLowPowerActive,
  onUpdateSettings,
  onResetSettings,
  onClearAllChats,
}) => {
  const [health, setHealth] = useState<HealthStatus>({
    loading: !isLowPowerActive,
    paused: isLowPowerActive,
    geminiConfigured: false,
    searchAvailable: false,
  });
  const [confirmClearChats, setConfirmClearChats] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  const checkHealthStatus = useCallback(() => {
    setHealth((prev) => ({ ...prev, loading: true, paused: false }));
    fetch('/api/health')
      .then((r) => r.json())
      .then((data: { geminiConfigured?: boolean; searchAvailable?: boolean }) => {
        setHealth({
          loading: false,
          paused: false,
          geminiConfigured: Boolean(data.geminiConfigured),
          searchAvailable: Boolean(data.searchAvailable),
        });
      })
      .catch(() => {
        setHealth({
          loading: false,
          paused: false,
          geminiConfigured: false,
          searchAvailable: false,
        });
      });
  }, []);

  useEffect(() => {
    if (isLowPowerActive) {
      setHealth((prev) => ({ ...prev, loading: false, paused: true }));
      return;
    }
    checkHealthStatus();
  }, [checkHealthStatus, isLowPowerActive]);

  const showNotice = (msg: string) => {
    setFeedbackMsg(msg);
    window.setTimeout(() => setFeedbackMsg(null), 2600);
  };

  return (
    <div className="flex-1 overflow-y-auto custom-scrollbar p-4">
      <div className="mx-auto max-w-2xl space-y-4 pb-8">
        {feedbackMsg && (
          <div className="rounded-xl border border-cyan-400/35 bg-cyan-500/15 px-4 py-2.5 text-xs font-medium text-cyan-200">
            {feedbackMsg}
          </div>
        )}

        {/* Identity & Language */}
        <section className="rounded-2xl border border-sky-400/20 bg-[#091326] p-4 space-y-4">
          <h2 className="font-display text-base font-semibold text-slate-100">
            Assistant & Language
          </h2>

          <div className="grid sm:grid-cols-2 gap-3">
            <label className="block text-xs text-slate-300">
              Assistant Name
              <input
                type="text"
                maxLength={24}
                value={settings.assistantName}
                onChange={(e) =>
                  onUpdateSettings({ assistantName: e.target.value })
                }
                placeholder="JARVIS"
                className="mt-1.5 w-full min-h-[44px] rounded-xl border border-sky-400/20 bg-[#050b18] px-3.5 text-sm text-slate-100 focus:border-cyan-400 focus:outline-none"
              />
            </label>

            <label className="block text-xs text-slate-300">
              Your Nickname (Optional)
              <input
                type="text"
                maxLength={24}
                value={settings.userNickname}
                onChange={(e) =>
                  onUpdateSettings({ userNickname: e.target.value })
                }
                placeholder="e.g. Nitish"
                className="mt-1.5 w-full min-h-[44px] rounded-xl border border-sky-400/20 bg-[#050b18] px-3.5 text-sm text-slate-100 focus:border-cyan-400 focus:outline-none"
              />
            </label>
          </div>

          <div className="grid sm:grid-cols-2 gap-3">
            <label className="block text-xs text-slate-300">
              Preferred AI Language
              <select
                value={settings.preferredLanguage}
                onChange={(e) =>
                  onUpdateSettings({
                    preferredLanguage: e.target.value as PreferredLanguage,
                  })
                }
                className="mt-1.5 w-full min-h-[44px] rounded-xl border border-sky-400/20 bg-[#050b18] px-3 text-sm text-slate-100 focus:border-cyan-400 focus:outline-none"
              >
                <option value="auto">Auto (Hindi / Hinglish / English)</option>
                <option value="hinglish">Hinglish (Conversational)</option>
                <option value="hi-IN">Hindi (हिन्दी)</option>
                <option value="en-IN">English (India)</option>
                <option value="en-US">English (US)</option>
              </select>
            </label>

            <label className="block text-xs text-slate-300">
              Voice Recognition Language
              <select
                value={settings.speechLanguage}
                onChange={(e) =>
                  onUpdateSettings({
                    speechLanguage: e.target.value as SpeechLanguage,
                  })
                }
                className="mt-1.5 w-full min-h-[44px] rounded-xl border border-sky-400/20 bg-[#050b18] px-3 text-sm text-slate-100 focus:border-cyan-400 focus:outline-none"
              >
                <option value="en-IN">English (India · en-IN)</option>
                <option value="hi-IN">Hindi (India · hi-IN)</option>
                <option value="en-US">English (US · en-US)</option>
              </select>
            </label>
          </div>
        </section>

        {/* Voice & Response Style */}
        <section className="rounded-2xl border border-sky-400/20 bg-[#091326] p-4 space-y-4">
          <h2 className="font-display text-base font-semibold text-slate-100">
            Voice & Response Preferences
          </h2>

          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <Volume2 className="h-5 w-5 text-cyan-300" />
              <div>
                <div className="text-sm font-medium text-slate-100">Voice Output</div>
                <div className="text-xs text-slate-400">
                  Speak AI replies aloud automatically
                </div>
              </div>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={settings.voiceEnabled}
              onClick={() => onUpdateSettings({ voiceEnabled: !settings.voiceEnabled })}
              className={`min-h-[44px] min-w-[68px] rounded-xl px-3 text-xs font-semibold transition-colors ${
                settings.voiceEnabled
                  ? 'bg-cyan-500 text-[#040812]'
                  : 'border border-sky-400/20 bg-[#050b18] text-slate-400'
              }`}
            >
              {settings.voiceEnabled ? 'ON' : 'OFF'}
            </button>
          </div>

          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <Mic className="h-5 w-5 text-cyan-300" />
              <div>
                <div className="text-sm font-medium text-slate-100">Hands-Free Mode</div>
                <div className="text-xs text-slate-400">
                  Auto-send voice after 1.2s pause &amp; keep listening
                </div>
              </div>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={settings.handsFreeMode}
              onClick={() => onUpdateSettings({ handsFreeMode: !settings.handsFreeMode })}
              className={`min-h-[44px] min-w-[68px] rounded-xl px-3 text-xs font-semibold transition-colors ${
                settings.handsFreeMode
                  ? 'bg-cyan-500 text-[#040812]'
                  : 'border border-sky-400/20 bg-[#050b18] text-slate-400'
              }`}
            >
              {settings.handsFreeMode ? 'ON' : 'OFF'}
            </button>
          </div>

          <label className="block text-xs text-slate-300">
            <div className="flex items-center justify-between mb-1.5">
              <span>Speaking Speed</span>
              <span className="font-mono text-cyan-200 tabular-nums">
                {settings.speechSpeed.toFixed(2)}x
              </span>
            </div>
            <input
              type="range"
              min={0.75}
              max={1.5}
              step={0.05}
              value={settings.speechSpeed}
              onChange={(e) =>
                onUpdateSettings({ speechSpeed: Number(e.target.value) })
              }
              className="w-full accent-cyan-400 h-8 cursor-pointer"
            />
          </label>

          <div>
            <div className="text-xs text-slate-300 mb-2">AI Response Length</div>
            <div className="grid grid-cols-3 gap-2">
              {(['concise', 'balanced', 'detailed'] as ResponseLength[]).map((len) => (
                <button
                  key={len}
                  type="button"
                  onClick={() => onUpdateSettings({ responseLength: len })}
                  className={`min-h-[44px] rounded-xl text-xs font-medium capitalize transition-colors ${
                    settings.responseLength === len
                      ? 'bg-cyan-500/20 border border-cyan-400/45 text-cyan-200'
                      : 'border border-sky-400/15 bg-[#050b18] text-slate-300'
                  }`}
                >
                  {len}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="text-xs text-slate-300 mb-2">Theme Brightness</div>
            <div className="grid grid-cols-3 gap-2">
              {(
                [
                  { id: 'dim', label: 'Dim' },
                  { id: 'standard', label: 'Standard' },
                  { id: 'high', label: 'Bright' },
                ] as Array<{ id: ThemeBrightness; label: string }>
              ).map((mode) => (
                <button
                  key={mode.id}
                  type="button"
                  onClick={() => onUpdateSettings({ themeBrightness: mode.id })}
                  className={`min-h-[44px] rounded-xl text-xs font-medium transition-colors ${
                    settings.themeBrightness === mode.id
                      ? 'bg-cyan-500/20 border border-cyan-400/45 text-cyan-200'
                      : 'border border-sky-400/15 bg-[#050b18] text-slate-300'
                  }`}
                >
                  {mode.label}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Power & Performance */}
        <section className="rounded-2xl border border-sky-400/20 bg-[#091326] p-4 space-y-3">
          <h2 className="font-display text-base font-semibold text-slate-100">
            Power & Performance
          </h2>

          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <BatteryLow
                className={`h-5 w-5 shrink-0 ${
                  isLowPowerActive ? 'text-amber-300' : 'text-cyan-300'
                }`}
              />
              <div>
                <div className="text-sm font-medium text-slate-100">Low Power Mode</div>
                <div className="text-xs text-slate-400">
                  Reduces AI core animation complexity &amp; stops background polling below 20% battery
                </div>
              </div>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={settings.lowPowerMode}
              onClick={() => onUpdateSettings({ lowPowerMode: !settings.lowPowerMode })}
              className={`min-h-[44px] min-w-[68px] shrink-0 rounded-xl px-3 text-xs font-semibold transition-colors ${
                settings.lowPowerMode
                  ? 'bg-cyan-500 text-[#040812]'
                  : 'border border-sky-400/20 bg-[#050b18] text-slate-400'
              }`}
            >
              {settings.lowPowerMode ? 'ON' : 'OFF'}
            </button>
          </div>

          <div
            className={`rounded-xl border px-3 py-2 text-xs ${
              isLowPowerActive
                ? 'border-amber-400/35 bg-amber-950/35 text-amber-200'
                : 'border-sky-400/15 bg-[#050b18] text-slate-300'
            }`}
          >
            {!settings.lowPowerMode ? (
              <span>
                Disabled — Full AI core animations and live background polling enabled
                {batteryStatus.supported && batteryStatus.level !== null
                  ? ` (Battery: ${batteryStatus.level}%${batteryStatus.charging ? ', Charging' : ''})`
                  : '.'}
              </span>
            ) : isLowPowerActive ? (
              <span>
                {batteryStatus.supported && batteryStatus.level !== null
                  ? `Active (Battery at ${batteryStatus.level}% — below 20%)`
                  : 'Active (Battery API unavailable on this browser)'}{' '}
                — Simplified AI core and background polling stopped.
              </span>
            ) : (
              <span>
                Armed (Battery at {batteryStatus.level}%
                {batteryStatus.charging ? ', Charging' : ''}) — Will automatically engage when battery drops below 20%.
              </span>
            )}
          </div>
        </section>

        {/* PWA & Android Installation */}
        <section className="rounded-2xl border border-sky-400/20 bg-[#091326] p-4 space-y-3">
          <div className="flex items-center gap-2.5">
            <Smartphone className="h-5 w-5 text-cyan-300" />
            <h2 className="font-display text-base font-semibold text-slate-100">
              Install on Android Phone (PWA)
            </h2>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Install {settings.assistantName || 'JARVIS'} as a standalone mobile app. On Android Chrome, tap the browser menu (⋮) and choose <strong>Add to Home screen</strong> or <strong>Install app</strong>.
          </p>
          <PWAInstallButton />
        </section>

        {/* Server API Status */}
        <section className="rounded-2xl border border-sky-400/20 bg-[#091326] p-4 space-y-3">
          <h2 className="font-display text-base font-semibold text-slate-100">
            API & Search Status
          </h2>
          {health.loading ? (
            <p className="text-xs text-slate-400">Checking server status…</p>
          ) : health.paused ? (
            <div className="flex items-center justify-between gap-3 text-xs">
              <span className="text-amber-200">
                Background health polling stopped in Low Power Mode.
              </span>
              <button
                type="button"
                onClick={checkHealthStatus}
                className="min-h-[36px] shrink-0 rounded-lg border border-sky-400/25 bg-[#0c1a33] px-3 font-medium text-cyan-200 hover:bg-[#112447]"
              >
                Check Now
              </button>
            </div>
          ) : (
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between py-1">
                <span className="text-slate-300">Gemini AI Service</span>
                <span className="inline-flex items-center gap-1.5 font-medium text-slate-100">
                  {health.geminiConfigured ? (
                    <>
                      <CheckCircle2 className="h-4 w-4 text-cyan-300" />
                      <span className="text-cyan-200">Configured</span>
                    </>
                  ) : (
                    <>
                      <XCircle className="h-4 w-4 text-amber-300" />
                      <span className="text-amber-200">Unavailable</span>
                    </>
                  )}
                </span>
              </div>
              <div className="flex items-center justify-between py-1">
                <span className="text-slate-300">Live Web Search Grounding</span>
                <span className="inline-flex items-center gap-1.5 font-medium text-slate-100">
                  {health.searchAvailable ? (
                    <>
                      <CheckCircle2 className="h-4 w-4 text-cyan-300" />
                      <span className="text-cyan-200">Available</span>
                    </>
                  ) : (
                    <>
                      <XCircle className="h-4 w-4 text-amber-300" />
                      <span className="text-amber-200">Unavailable</span>
                    </>
                  )}
                </span>
              </div>
            </div>
          )}
        </section>

        {/* Data Management & Privacy */}
        <section className="rounded-2xl border border-sky-400/20 bg-[#091326] p-4 space-y-3">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="h-5 w-5 text-cyan-300" />
            <h2 className="font-display text-base font-semibold text-slate-100">
              Privacy & Storage
            </h2>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Your chat history, notes, shortcuts, and assistant preferences are stored locally in your phone browser. No API keys or passwords are stored on your device. Messages sent to AI are processed securely through the server backend. Microphone, camera, and location are only accessed when you explicitly trigger them.
          </p>

          <div className="grid sm:grid-cols-2 gap-2.5 pt-2">
            {!confirmClearChats ? (
              <button
                type="button"
                onClick={() => setConfirmClearChats(true)}
                className="min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl border border-rose-400/30 bg-rose-950/30 px-4 text-xs font-semibold text-rose-200 hover:bg-rose-950/50"
              >
                <Trash2 className="h-4 w-4" />
                <span>Clear Chat History</span>
              </button>
            ) : (
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onClearAllChats();
                    setConfirmClearChats(false);
                    showNotice('All saved chat history cleared.');
                  }}
                  className="flex-1 min-h-[44px] rounded-xl bg-rose-500 px-3 text-xs font-semibold text-white"
                >
                  Confirm Clear
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmClearChats(false)}
                  className="min-h-[44px] rounded-xl border border-sky-400/20 px-3 text-xs text-slate-300"
                >
                  Cancel
                </button>
              </div>
            )}

            {!confirmReset ? (
              <button
                type="button"
                onClick={() => setConfirmReset(true)}
                className="min-h-[44px] inline-flex items-center justify-center gap-2 rounded-xl border border-sky-400/25 bg-[#0c1a33] px-4 text-xs font-semibold text-slate-200 hover:bg-[#112447]"
              >
                <RotateCcw className="h-4 w-4" />
                <span>Reset Settings</span>
              </button>
            ) : (
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onResetSettings();
                    setConfirmReset(false);
                    showNotice('Settings restored to defaults.');
                  }}
                  className="flex-1 min-h-[44px] rounded-xl bg-cyan-500 px-3 text-xs font-semibold text-[#040812]"
                >
                  Confirm Reset
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmReset(false)}
                  className="min-h-[44px] rounded-xl border border-sky-400/20 px-3 text-xs text-slate-300"
                >
                  Cancel
                </button>
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
};
