import React, { useState } from 'react';
import { 
  Settings, 
  User, 
  Globe, 
  Volume2, 
  Sparkles, 
  Trash2, 
  Save, 
  ShieldCheck, 
  Zap, 
  Sliders,
  Mic,
  Headphones
} from 'lucide-react';
import { SupportedLanguage } from '../types/assistant';

interface SettingsViewProps {
  userName: string;
  onUpdateUserName: (name: string) => void;
  language: SupportedLanguage;
  onToggleLanguage: () => void;
  autoSpeak: boolean;
  onToggleAutoSpeak: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  speechRate: number;
  onUpdateSpeechRate: (rate: number) => void;
  handsFreeVoice: boolean;
  onToggleHandsFreeVoice: () => void;
  onClearHistory: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  userName,
  onUpdateUserName,
  language,
  onToggleLanguage,
  autoSpeak,
  onToggleAutoSpeak,
  soundEnabled,
  onToggleSound,
  speechRate,
  onUpdateSpeechRate,
  handsFreeVoice,
  onToggleHandsFreeVoice,
  onClearHistory,
}) => {
  const [nameInput, setNameInput] = useState(userName);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSaveName = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim()) return;
    onUpdateUserName(nameInput.trim());
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-950 via-[#0d1629] to-[#1e1338] border border-cyan-500/30 p-6 shadow-xl">
        <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 text-xs font-mono-tech mb-1">
          <Settings className="w-3.5 h-3.5 text-cyan-400" />
          <span>PREFERENCES & IDENTITY MATRIX</span>
        </div>
        <h2 className="text-2xl font-orbitron font-extrabold tracking-wide text-white">
          ASSISTANT SETTINGS
        </h2>
        <p className="text-slate-400 text-xs sm:text-sm">
          Configure Boss call-sign identity, hands-free voice automation, speech synthesis, and language.
        </p>
      </div>

      {/* Hands-Free Direct Voice Automation (New requested feature) */}
      <div className="rounded-3xl bg-[#090f1f]/95 border border-cyan-500/40 p-5 md:p-6 space-y-4 shadow-xl">
        <div className="flex items-center gap-2 border-b border-cyan-900/40 pb-3">
          <Mic className="w-5 h-5 text-cyan-400" />
          <h3 className="font-orbitron font-bold text-sm text-cyan-300 tracking-wide">
            হ্যান্ডস-ফ্রি ও ডাইরেক্ট ভয়েস সিস্টেম (HANDS-FREE DIRECT VOICE)
          </h3>
        </div>

        <div className="flex items-center justify-between gap-4 p-3 bg-slate-950 rounded-2xl border border-slate-800">
          <div className="space-y-1">
            <span className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <Headphones className="w-4 h-4 text-fuchsia-400" />
              <span>অটো-কন্টিনিউয়াস ভয়েস মোড (Continuous Hands-Free Mode)</span>
            </span>
            <p className="text-xs text-slate-400">
              মাইক্রোফোনে বারবার ক্লিক না করেই একনাগাড়ে কথা বলুন। এআই উত্তর দেওয়ার পর সরাসরি আবার ভয়েস গ্রহণ করবে।
            </p>
          </div>

          <label className="relative inline-flex items-center cursor-pointer shrink-0">
            <input
              type="checkbox"
              checked={handsFreeVoice}
              onChange={onToggleHandsFreeVoice}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
          </label>
        </div>
      </div>

      {/* User Call-Sign Identity */}
      <div className="rounded-3xl bg-[#090f1f]/95 border border-cyan-900/40 p-5 md:p-6 space-y-4 shadow-xl">
        <div className="flex items-center gap-2 border-b border-cyan-900/40 pb-3">
          <User className="w-5 h-5 text-cyan-400" />
          <h3 className="font-orbitron font-bold text-sm text-white tracking-wide">
            BOSS CALL-SIGN & IDENTITY
          </h3>
        </div>

        <form onSubmit={handleSaveName} className="space-y-3">
          <div>
            <label className="text-xs font-mono-tech text-slate-400">
              What should Rubel Boss AI call you?
            </label>
            <div className="flex items-center gap-2 mt-1">
              <input
                type="text"
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                placeholder="e.g. Rubel Boss"
                className="flex-1 bg-slate-950 text-slate-100 text-sm px-4 py-2.5 rounded-xl border border-slate-700 focus:outline-none focus:border-cyan-400 font-sans"
              />
              <button
                type="submit"
                className="px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs tracking-wider font-orbitron transition-all flex items-center gap-1.5 shadow-md shadow-cyan-500/20"
              >
                <Save className="w-4 h-4" />
                <span>SAVE</span>
              </button>
            </div>
            {savedSuccess && (
              <p className="text-xs font-mono-tech text-emerald-400 mt-1.5">
                ✓ Identity updated and saved to local memory!
              </p>
            )}
          </div>
        </form>
      </div>

      {/* Language & Voice Synthesis Engine */}
      <div className="rounded-3xl bg-[#090f1f]/95 border border-cyan-900/40 p-5 md:p-6 space-y-5 shadow-xl">
        <div className="flex items-center gap-2 border-b border-cyan-900/40 pb-3">
          <Sliders className="w-5 h-5 text-fuchsia-400" />
          <h3 className="font-orbitron font-bold text-sm text-white tracking-wide">
            VOICE & AUDIO PARAMETERS
          </h3>
        </div>

        {/* Primary Language */}
        <div className="flex items-center justify-between gap-4 p-3 bg-slate-950 rounded-2xl border border-slate-800">
          <div className="space-y-0.5">
            <span className="text-sm font-semibold text-slate-200">Primary Language</span>
            <p className="text-xs text-slate-400">
              {language === 'bn' ? 'বাংলা (Bengali - bn-BD)' : 'English (en-US)'}
            </p>
          </div>

          <button
            onClick={onToggleLanguage}
            className="px-4 py-1.5 rounded-xl bg-slate-900 border border-cyan-500/40 text-cyan-300 font-mono-tech text-xs hover:bg-slate-800"
          >
            {language === 'bn' ? 'বাংলা ⇄ English' : 'English ⇄ বাংলা'}
          </button>
        </div>

        {/* Auto-Speak TTS */}
        <div className="flex items-center justify-between gap-4 p-3 bg-slate-950 rounded-2xl border border-slate-800">
          <div className="space-y-0.5">
            <span className="text-sm font-semibold text-slate-200">Auto-Speak Replies (TTS)</span>
            <p className="text-xs text-slate-400">
              Read responses aloud automatically with natural speech synthesis
            </p>
          </div>

          <label className="relative inline-flex items-center cursor-pointer shrink-0">
            <input
              type="checkbox"
              checked={autoSpeak}
              onChange={onToggleAutoSpeak}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-fuchsia-500"></div>
          </label>
        </div>

        {/* Speech Speed Slider */}
        <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs font-mono-tech">
            <span className="text-slate-300">Speech Rate / Speed:</span>
            <span className="text-cyan-400 font-bold">{speechRate.toFixed(2)}x</span>
          </div>
          <input
            type="range"
            min="0.75"
            max="1.3"
            step="0.05"
            value={speechRate}
            onChange={(e) => onUpdateSpeechRate(parseFloat(e.target.value))}
            className="w-full accent-cyan-400 cursor-pointer"
          />
        </div>

        {/* Cyber Sound FX */}
        <div className="flex items-center justify-between gap-4 p-3 bg-slate-950 rounded-2xl border border-slate-800">
          <div className="space-y-0.5">
            <span className="text-sm font-semibold text-slate-200">Cyber Acoustic Sound FX</span>
            <p className="text-xs text-slate-400">
              Futuristic holographic blips, activation chimes, and send effects
            </p>
          </div>

          <label className="relative inline-flex items-center cursor-pointer shrink-0">
            <input
              type="checkbox"
              checked={soundEnabled}
              onChange={onToggleSound}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
          </label>
        </div>
      </div>

      {/* Memory & Cache Management */}
      <div className="rounded-3xl bg-[#090f1f]/95 border border-red-900/30 p-5 md:p-6 space-y-4 shadow-xl">
        <div className="flex items-center gap-2 border-b border-red-900/30 pb-3">
          <Trash2 className="w-5 h-5 text-red-400" />
          <h3 className="font-orbitron font-bold text-sm text-white tracking-wide">
            RESET & CACHE CONTROLS
          </h3>
        </div>

        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-sm font-semibold text-slate-200">Clear Conversation Memory</p>
            <p className="text-xs text-slate-400">Reset chat history back to initial system welcome state.</p>
          </div>
          <button
            onClick={onClearHistory}
            className="px-4 py-2 rounded-xl bg-red-950/60 hover:bg-red-900 border border-red-500/40 text-red-300 text-xs font-mono-tech transition-all shrink-0"
          >
            Clear History
          </button>
        </div>
      </div>
    </div>
  );
};
