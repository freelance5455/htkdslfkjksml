import React, { useState, useEffect } from 'react';
import { androidBridge } from '../services/androidBridge';
import { voiceService } from '../services/voiceService';
import { getApiBaseUrl, setApiBaseUrl } from '../services/geminiService';
import { 
  Settings, 
  Smartphone, 
  ShieldAlert, 
  ShieldCheck, 
  Volume2, 
  Sparkles, 
  Code2, 
  Sliders, 
  ExternalLink,
  CheckCircle,
  HelpCircle,
  Cpu,
  Mic,
  MicOff,
  RefreshCw,
  AlertCircle,
  Lock,
  ArrowRight,
  Server,
  Download,
  Info,
  Check
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const [personality, setPersonality] = useState('playful');
  const [voiceVolume, setVoiceVolume] = useState(85);
  const [speechRate, setSpeechRate] = useState(1.05);
  const [bridgeResult, setBridgeResult] = useState<string | null>(null);

  // Real Microphone Permission States
  const [micPermissionState, setMicPermissionState] = useState<'checking' | 'granted' | 'denied' | 'prompt' | 'unsupported'>('checking');
  const [isRequestingMic, setIsRequestingMic] = useState(false);
  const [settingsGuidanceResult, setSettingsGuidanceResult] = useState<{
    showGuide: boolean;
    openedNative: boolean;
    message: string;
  } | null>(null);

  // Android APK Backend Endpoint state
  const [customBackendUrl, setCustomBackendUrl] = useState(() => getApiBaseUrl());
  const [isSavingUrl, setIsSavingUrl] = useState(false);
  const [urlSaveSuccess, setUrlSaveSuccess] = useState(false);

  const bridgeState = androidBridge.getBridgeState();
  const voiceCaps = voiceService.getCapabilities();

  // Query real browser permission on mount and attach change listener
  const refreshMicPermission = async () => {
    setMicPermissionState('checking');
    try {
      const res = await voiceService.queryMicrophonePermissionStatus();
      setMicPermissionState(res.state);
    } catch {
      setMicPermissionState('prompt');
    }
  };

  useEffect(() => {
    refreshMicPermission();

    // Listen for real browser permission changes if supported
    if (typeof navigator !== 'undefined' && navigator.permissions?.query) {
      navigator.permissions.query({ name: 'microphone' as PermissionName }).then((status) => {
        status.onchange = () => {
          setMicPermissionState(status.state as any);
        };
      }).catch(() => {});
    }
  }, []);

  // Request Microphone Access
  const handleRequestMicAccess = async () => {
    setIsRequestingMic(true);
    setSettingsGuidanceResult(null);
    try {
      const result = await voiceService.requestMicrophonePermission();
      if (result === 'granted') {
        setMicPermissionState('granted');
      } else if (result === 'denied') {
        setMicPermissionState('denied');
      } else {
        setMicPermissionState('unsupported');
      }
    } finally {
      setIsRequestingMic(false);
    }
  };

  // Open Permission Settings handler with honest capability detection
  const handleOpenPermissionSettings = () => {
    const check = voiceService.checkCanDirectlyOpenSettings();

    if (check.isNativeAndroid && check.canDirectlyOpen) {
      // True native Android container: call official ACTION_APPLICATION_DETAILS_SETTINGS
      const res = androidBridge.openAppPermissionSettings();
      setSettingsGuidanceResult({
        showGuide: false,
        openedNative: res.openedNative,
        message: res.message,
      });
    } else {
      // Standard Web Browser: direct navigation is blocked by browser security sandboxes
      // We NEVER use fake Android intent links or claim Android system settings were opened!
      setSettingsGuidanceResult({
        showGuide: true,
        openedNative: false,
        message: 'Browser Security Notice: Standard web pages are sandboxed and cannot directly launch device system settings or chrome:// schemes. Follow the official Chrome on Android steps below.',
      });
    }
  };

  // Save backend API URL for APK packaging
  const handleSaveBackendUrl = () => {
    setIsSavingUrl(true);
    setApiBaseUrl(customBackendUrl);
    setUrlSaveSuccess(true);
    setTimeout(() => {
      setIsSavingUrl(false);
      setTimeout(() => setUrlSaveSuccess(false), 2000);
    }, 400);
  };

  const handleTestVoice = () => {
    voiceService.speak("Darling, voice telemetry is operating at full bandwidth! I can hear you loud and clear.");
  };

  const handleTriggerAccessibilityConsent = () => {
    const res = androidBridge.requestAccessibilityConsentFlow();
    setBridgeResult(res.message);
  };

  return (
    <div className="flex-1 overflow-y-auto bg-[#07070e] p-4 pb-24 text-slate-200">
      <div className="max-w-xl mx-auto space-y-4">
        {/* Header */}
        <div className="flex items-center gap-2.5 pb-2 border-b border-[#ff2d78]/25">
          <div className="w-8 h-8 rounded-xl bg-[#ff2d78]/20 flex items-center justify-center text-[#ff2d78]">
            <Settings className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-cyber font-bold text-base text-white tracking-wide">SYSTEM SETTINGS</h1>
            <p className="text-xs text-slate-400 font-sans">Permissions, microphone access & Android APK configuration</p>
          </div>
        </div>

        {/* REAL MICROPHONE PERMISSION & BROWSER ACCESS PANEL */}
        <div className="bg-[#0f0f1e] border border-[#ff2d78]/35 rounded-2xl p-4 shadow-xl relative overflow-hidden">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Mic className="w-4 h-4 text-[#ff2d78]" />
              <h2 className="font-cyber font-bold text-xs tracking-wider text-white">
                MICROPHONE PERMISSION & BROWSER ACCESS
              </h2>
            </div>
            {/* Real Permission Badge */}
            <span className={`text-[10px] font-mono-code px-2 py-0.5 rounded font-semibold flex items-center gap-1 ${
              micPermissionState === 'granted'
                ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/50'
                : micPermissionState === 'denied'
                ? 'bg-rose-950/80 text-rose-300 border border-rose-500/50'
                : micPermissionState === 'checking'
                ? 'bg-slate-800 text-slate-300'
                : micPermissionState === 'unsupported'
                ? 'bg-slate-900 text-slate-400 border border-slate-700'
                : 'bg-amber-950/80 text-amber-300 border border-amber-500/40'
            }`}>
              {micPermissionState === 'granted' && <CheckCircle className="w-3 h-3 text-emerald-400" />}
              {micPermissionState === 'denied' && <ShieldAlert className="w-3 h-3 text-rose-400" />}
              {micPermissionState === 'checking' && <RefreshCw className="w-3 h-3 animate-spin text-slate-400" />}
              {micPermissionState === 'granted'
                ? 'PERMISSION: ALLOWED'
                : micPermissionState === 'denied'
                ? 'PERMISSION: BLOCKED'
                : micPermissionState === 'checking'
                ? 'CHECKING...'
                : micPermissionState === 'unsupported'
                ? 'UNSUPPORTED'
                : 'NOT REQUESTED YET'}
            </span>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed font-sans mb-3">
            002 uses browser microphone access for real-time speech recognition in Hindi, Hinglish, and English. Hardware access is verified using official Web APIs.
          </p>

          {/* Action Buttons Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-3">
            {/* Request Microphone Access Button */}
            <button
              onClick={handleRequestMicAccess}
              disabled={isRequestingMic}
              className="w-full bg-gradient-to-r from-[#ff2d78] to-[#9333ea] hover:brightness-110 disabled:opacity-50 text-white font-cyber text-xs py-2.5 px-3 rounded-xl flex items-center justify-center gap-2 shadow-md transition-all active:scale-98"
            >
              <Mic className="w-3.5 h-3.5" />
              <span>{isRequestingMic ? 'Prompting Browser...' : 'Request Microphone Access'}</span>
            </button>

            {/* Check/Refresh Status Button */}
            <button
              onClick={refreshMicPermission}
              className="w-full bg-[#151528] hover:bg-[#1e1e38] border border-slate-700 text-slate-200 hover:text-white font-cyber text-xs py-2.5 px-3 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-98"
            >
              <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
              <span>Check Permission Status</span>
            </button>
          </div>

          {/* If access is denied: Display Open Permission Settings Button */}
          {micPermissionState === 'denied' && (
            <div className="mt-3 p-3 rounded-xl bg-rose-950/40 border border-rose-500/50 space-y-3">
              <div className="flex items-start gap-2">
                <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-cyber font-bold text-xs text-white block">
                    Microphone Access is Currently Blocked
                  </span>
                  <p className="text-[11px] text-rose-200 mt-0.5 font-sans leading-normal">
                    The browser has blocked microphone input for this origin. You can re-enable it through your browser's site settings.
                  </p>
                </div>
              </div>

              {/* Open Permission Settings Button */}
              <button
                onClick={handleOpenPermissionSettings}
                className="w-full bg-rose-900/80 hover:bg-rose-800 border border-rose-400/60 text-white font-cyber text-xs py-2 px-3 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-98 shadow-sm"
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>Open Permission Settings</span>
              </button>
            </div>
          )}

          {/* Settings Guidance Result Display */}
          {settingsGuidanceResult && (
            <div className="mt-3 p-3 rounded-xl bg-[#0c0c1a] border border-slate-700 space-y-2.5">
              <div className="flex items-start gap-2">
                <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div className="text-xs text-slate-300 font-sans leading-relaxed">
                  {settingsGuidanceResult.message}
                </div>
              </div>

              {/* Step-by-Step Chrome on Android Instructions */}
              {settingsGuidanceResult.showGuide && (
                <div className="bg-[#121226] border border-slate-800 rounded-xl p-3 space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-cyber font-semibold text-white">
                    <Smartphone className="w-3.5 h-3.5 text-[#ff2d78]" />
                    <span>How to Allow Microphone in Chrome on Android:</span>
                  </div>

                  <ol className="text-[11px] text-slate-300 space-y-1.5 font-sans pl-2">
                    <li className="flex items-start gap-2">
                      <span className="w-4 h-4 rounded-full bg-[#ff2d78]/20 text-[#ff70a6] flex items-center justify-center text-[10px] font-mono-code shrink-0 mt-0.5 font-bold">1</span>
                      <span>Look at the top URL address bar in Chrome and tap the <strong>Tune / Lock icon (🔒 / ⚙️)</strong> on the left side of the website address.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-4 h-4 rounded-full bg-[#ff2d78]/20 text-[#ff70a6] flex items-center justify-center text-[10px] font-mono-code shrink-0 mt-0.5 font-bold">2</span>
                      <span>Tap <strong>Permissions</strong> (or <strong>Site settings</strong>).</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-4 h-4 rounded-full bg-[#ff2d78]/20 text-[#ff70a6] flex items-center justify-center text-[10px] font-mono-code shrink-0 mt-0.5 font-bold">3</span>
                      <span>Tap <strong>Microphone</strong> and toggle the switch to <strong>"Allow"</strong>.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="w-4 h-4 rounded-full bg-[#ff2d78]/20 text-[#ff70a6] flex items-center justify-center text-[10px] font-mono-code shrink-0 mt-0.5 font-bold">4</span>
                      <span>Return here and tap the <strong>"Check Permission Status"</strong> button above to confirm!</span>
                    </li>
                  </ol>
                </div>
              )}
            </div>
          )}

          {/* FUTURE NATIVE ANDROID SUPPORT: ACTION_APPLICATION_DETAILS_SETTINGS */}
          <div className="mt-4 pt-3 border-t border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-cyber font-semibold text-[#c084fc] flex items-center gap-1.5">
                <Code2 className="w-3.5 h-3.5" />
                FUTURE NATIVE ANDROID ARCHITECTURE NOTE
              </span>
              <span className="text-[9px] font-mono-code px-2 py-0.5 rounded bg-purple-950/70 border border-purple-500/40 text-purple-300">
                ACTION_APPLICATION_DETAILS_SETTINGS
              </span>
            </div>

            <p className="text-[11px] text-slate-400 font-sans leading-relaxed">
              When compiled into an official native Android APK, the app will directly trigger Android's system App Info settings so the user can manually enable microphone permission (<code className="text-slate-300 font-mono-code">Manifest.permission.RECORD_AUDIO</code>):
            </p>

            <div className="bg-[#080812] border border-slate-800 rounded-xl p-2.5 font-mono-code text-[10px] text-purple-200 overflow-x-auto">
              <div className="text-slate-500">// Official Android API to open App Details Settings</div>
              <div>val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply &#123;</div>
              <div className="pl-4">data = Uri.fromParts("package", context.packageName, null)</div>
              <div className="pl-4">flags = Intent.FLAG_ACTIVITY_NEW_TASK</div>
              <div>&#125;</div>
              <div>context.startActivity(intent)</div>
            </div>
          </div>
        </div>

        {/* ANDROID APK PACKAGING & BACKEND ENDPOINT CONFIGURATION */}
        <div className="bg-[#0f0f1e] border border-cyan-500/30 rounded-2xl p-4 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Server className="w-4 h-4 text-cyan-400" />
              <h2 className="font-cyber font-bold text-xs tracking-wider text-white">
                ANDROID APK WEBVIEW PACKAGING & BACKEND
              </h2>
            </div>
            <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-cyan-950/70 border border-cyan-500/40 text-cyan-300">
              Vite ./ base & Legacy Chunks
            </span>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed font-sans">
            The frontend is configured with relative assets (<code className="text-cyan-300 font-mono-code">base: './'</code>) and <code className="text-cyan-300 font-mono-code">@vitejs/plugin-legacy</code> to bundle standard JavaScript that loads reliably inside Android WebView (<code className="text-cyan-300 font-mono-code">file:///android_asset/</code>) without ES module CORS errors.
          </p>

          <div className="bg-[#0a0a14] border border-slate-800 rounded-xl p-3 space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-cyber font-semibold text-slate-200 text-[11px]">
                Configured Backend Server Endpoint:
              </span>
              <span className="text-[10px] font-mono-code text-emerald-400 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" />
                Zero API Key in Client
              </span>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="text"
                value={customBackendUrl}
                onChange={(e) => setCustomBackendUrl(e.target.value)}
                placeholder="https://your-deployed-server.run.app (Leave empty for relative web origin)"
                className="flex-1 bg-[#141424] border border-slate-800 focus:border-cyan-400 rounded-xl px-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none font-mono-code"
              />
              <button
                onClick={handleSaveBackendUrl}
                disabled={isSavingUrl}
                className="bg-cyan-900/80 hover:bg-cyan-800 border border-cyan-500/50 text-white font-cyber text-xs px-3 py-1.5 rounded-xl transition-all active:scale-95 shrink-0 flex items-center gap-1"
              >
                {urlSaveSuccess ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <ArrowRight className="w-3.5 h-3.5" />}
                <span>{urlSaveSuccess ? 'Saved' : 'Save'}</span>
              </button>
            </div>

            <p className="text-[10px] text-slate-400 font-sans leading-normal">
              When running as an Android APK, requests to <code className="font-mono-code text-slate-300">/api/chat</code> route securely to this endpoint over HTTPS with CORS enabled. The Gemini API key remains strictly on the server (<code className="font-mono-code text-slate-300">server.ts</code>) and is never bundled into the APK.
            </p>
          </div>

          <div className="bg-[#0b0b18] border border-slate-800 rounded-xl p-3 space-y-2 text-[11px] font-mono-code text-slate-300">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-cyan-300 font-cyber font-semibold">
                <Download className="w-3.5 h-3.5" />
                <span>Android APK Packaging Bundle:</span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-500/30">
                PROD DIST READY
              </span>
            </div>

            <p className="text-slate-400 font-sans text-[11px] leading-relaxed">
              Contains the production <code className="text-cyan-300 font-mono-code">dist/</code> folder with universal WebView bootloaders (preventing white screens on <code className="text-cyan-300 font-mono-code">file://</code>), plus reference <code className="text-cyan-300 font-mono-code">MainActivity.kt</code> and <code className="text-cyan-300 font-mono-code">AndroidManifest.xml</code>.
            </p>

            <a
              href="/api/download-apk-bundle"
              download="002-ai-android-apk-ready.zip"
              className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-cyber text-xs font-semibold flex items-center justify-center gap-2 shadow-lg shadow-cyan-950/50 transition-all active:scale-[0.98]"
            >
              <Download className="w-4 h-4" />
              <span>Download APK Bundle (.ZIP)</span>
            </a>

            <div className="p-2.5 rounded-lg bg-[#070712] border border-slate-800/80 text-[10px] space-y-1 font-sans text-slate-400">
              <div className="font-semibold text-slate-200">Android Studio Setup Steps:</div>
              <div>1. Unzip the downloaded file.</div>
              <div>2. Copy contents of <code className="text-cyan-300 font-mono-code">assets_dist/</code> into your project's <code className="text-cyan-300 font-mono-code">app/src/main/assets/</code>.</div>
              <div>3. In your <code className="text-cyan-300 font-mono-code">MainActivity.kt</code>, ensure <code className="text-cyan-300 font-mono-code">settings.domStorageEnabled = true</code> and <code className="text-cyan-300 font-mono-code">settings.allowFileAccess = true</code>.</div>
              <div>4. Load <code className="text-cyan-300 font-mono-code">webView.loadUrl("file:///android_asset/index.html")</code>.</div>
            </div>
          </div>
        </div>

        {/* 002 Persona Calibration */}
        <div className="bg-[#0f0f1e] border border-slate-800 rounded-2xl p-4 shadow-lg">
          <h2 className="font-cyber font-bold text-xs tracking-wider text-white mb-2.5 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#ff2d78]" />
            002 COMPANION PERSONA
          </h2>
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'playful', label: 'Playful & Darling', desc: 'Charming, affectionate, and witty' },
              { id: 'feisty', label: 'Combat Operative', desc: 'Sharp, focused, tactical instincts' },
              { id: 'sweet', label: 'Devoted & Sweet', desc: 'Caring, sweet-toothed, gentle' },
              { id: 'chill', label: 'Cyber Analyst', desc: 'Analytical, cool-headed diagnostics' },
            ].map((p) => (
              <button
                key={p.id}
                onClick={() => setPersonality(p.id)}
                className={`p-3 rounded-xl text-left border transition-all ${
                  personality === p.id
                    ? 'bg-[#1e1028] border-[#ff2d78] shadow-[0_0_12px_rgba(255,45,120,0.25)]'
                    : 'bg-[#141426] border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="font-cyber font-semibold text-xs text-white">{p.label}</div>
                <div className="text-[10px] text-slate-400 mt-0.5">{p.desc}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Voice & Audio Synthesizer */}
        <div className="bg-[#0f0f1e] border border-slate-800 rounded-2xl p-4 shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-cyber font-bold text-xs tracking-wider text-white flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-[#9333ea]" />
              SYNTHETIC VOICE ENGINE
            </h2>
            <span className="text-[10px] font-mono-code text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded">
              {voiceCaps.status}
            </span>
          </div>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs text-slate-300 mb-1 font-mono-code">
                <span>Speech Speed Rate</span>
                <span>{speechRate}x</span>
              </div>
              <input
                type="range"
                min="0.8"
                max="1.4"
                step="0.05"
                value={speechRate}
                onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
                className="w-full accent-[#ff2d78]"
              />
            </div>

            <button
              onClick={handleTestVoice}
              className="w-full bg-[#1b152d] hover:bg-[#251d40] border border-[#9333ea]/40 text-[#c084fc] hover:text-white font-cyber text-xs py-2 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-98"
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>Test 002 Voice Synthesis</span>
            </button>
          </div>
        </div>

        {/* PHASE 2 — FUTURE ANDROID VOICE ASSISTANT ARCHITECTURE */}
        <div className="bg-[#0f0f1e] border border-[#9333ea]/35 rounded-2xl p-4 shadow-xl relative overflow-hidden">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-[#c084fc]" />
              <h2 className="font-cyber font-bold text-xs tracking-wider text-white">
                ANDROID VOICE ASSISTANT ARCHITECTURE (PHASE 2)
              </h2>
            </div>
            <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-[#180f28] border border-[#9333ea]/40 text-[#c084fc]">
              Native Blueprint Ready
            </span>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed font-sans mb-3">
            Architectural framework for the future native Android companion app. Enforces strict compliance with Google Play policy, official Android background limits, and user privacy:
          </p>

          <div className="space-y-2 mb-3">
            <div className="bg-[#0b0b16] p-2.5 rounded-xl border border-slate-800 text-xs">
              <div className="flex items-center justify-between text-slate-200 font-cyber text-[11px] font-semibold mb-1">
                <span>1. User-Initiated Voice Commands Over Other Apps</span>
                <span className="text-[9px] font-mono-code text-[#ff70a6]">OVERLAY PERMISSION</span>
              </div>
              <p className="text-[11px] text-slate-400 font-sans leading-normal">
                Triggered via user-activated floating companion bubble or system Assist key. Requires explicit user opt-in in Android Settings (<code className="text-slate-300 font-mono-code">ACTION_MANAGE_OVERLAY_PERMISSION</code>).
              </p>
            </div>

            <div className="bg-[#0b0b16] p-2.5 rounded-xl border border-slate-800 text-xs">
              <div className="flex items-center justify-between text-slate-200 font-cyber text-[11px] font-semibold mb-1">
                <span>2. Official Background Voice Interaction</span>
                <span className="text-[9px] font-mono-code text-emerald-400">FOREGROUND SERVICE</span>
              </div>
              <p className="text-[11px] text-slate-400 font-sans leading-normal">
                Runs strictly as an official <code className="text-slate-300 font-mono-code">ForegroundService</code> with <code className="text-slate-300 font-mono-code">FOREGROUND_SERVICE_TYPE_MICROPHONE</code> and a persistent user notification with a 1-tap Stop control. Zero hidden listening.
              </p>
            </div>

            <div className="bg-[#0b0b16] p-2.5 rounded-xl border border-slate-800 text-xs">
              <div className="flex items-center justify-between text-slate-200 font-cyber text-[11px] font-semibold mb-1">
                <span>3. Hardware Privacy Indicator Compliance</span>
                <span className="text-[9px] font-mono-code text-emerald-400">ANDROID 12+ VERIFIED</span>
              </div>
              <p className="text-[11px] text-slate-400 font-sans leading-normal">
                Complies with Android 12+ green status bar microphone sensor dot. User has full instant visibility and control whenever the audio sensor is active.
              </p>
            </div>

            <div className="bg-[#0b0b16] p-2.5 rounded-xl border border-slate-800 text-xs">
              <div className="flex items-center justify-between text-slate-200 font-cyber text-[11px] font-semibold mb-1">
                <span>4. Audio Sharing & Multi-App Context</span>
                <span className="text-[9px] font-mono-code text-[#c084fc]">EXPLICIT CONSENT</span>
              </div>
              <p className="text-[11px] text-slate-400 font-sans leading-normal">
                Audio sharing with 002 is permitted only when technically supported by the device OS and explicitly authorized via user prompt.
              </p>
            </div>
          </div>

          <div className="bg-[#120b20] border border-[#9333ea]/30 rounded-xl p-2.5 text-[11px] text-[#c084fc] font-mono-code flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 shrink-0 text-[#ff2d78]" />
            <span>Strict Boundary: Background execution and native intents are not simulated in the web app. Only real web browser microphone is enabled in this build.</span>
          </div>
        </div>

        {/* PHASE 3 — FUTURE ANDROID APP LAUNCHER & INTENT ARCHITECTURE */}
        <div className="bg-[#0f0f1e] border border-[#ff2d78]/30 rounded-2xl p-4 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-[#ff2d78]/5 rounded-full blur-2xl pointer-events-none" />

          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-[#ff2d78]" />
              <h2 className="font-cyber font-bold text-xs tracking-wider text-white">
                ANDROID APP LAUNCHER ARCHITECTURE (PHASE 3)
              </h2>
            </div>
            <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-[#201020] border border-[#ff2d78]/40 text-[#ff70a6]">
              Official Intents
            </span>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed font-sans mb-3">
            Modular architecture for launching installed native Android applications using official Android <code className="text-[#ff70a6] font-mono-code">PackageManager.getLaunchIntentForPackage</code> and browser navigation via <code className="text-[#ff70a6] font-mono-code">Intent.ACTION_VIEW</code>.
          </p>

          {/* Official Android Security Policy Box */}
          <div className="bg-[#0a0a14] border border-slate-800 rounded-xl p-3 space-y-2 mb-3">
            <div className="flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <span className="text-xs font-cyber font-semibold text-emerald-400 block">
                  Official Android Security Policy Enforced
                </span>
                <p className="text-[11px] text-slate-400 leading-normal mt-0.5 font-sans">
                  The Android companion app strictly respects OS security boundaries:
                </p>
                <ul className="text-[11px] text-slate-300 list-disc list-inside space-y-1 mt-1 font-sans">
                  <li>Does NOT attempt to launch phone apps directly from standard web pages</li>
                  <li>Does NOT bypass native Android system permission dialogs</li>
                  <li>Does NOT implement hidden device control or background automation</li>
                  <li>Uses official system Intents with user visibility and consent</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Intent App Launcher Directory (Preview & Fallback Simulator) */}
          <div className="space-y-2">
            <span className="text-[11px] font-cyber font-semibold text-slate-300 block">
              OFFICIAL APP INTENT REGISTRY
            </span>

            <div className="grid grid-cols-2 gap-2">
              {[
                { name: 'YouTube', pkg: 'com.google.android.youtube', action: 'Video playback intent' },
                { name: 'Spotify', pkg: 'com.spotify.music', action: 'Audio stream intent' },
                { name: 'Google Maps', pkg: 'com.google.android.apps.maps', action: 'ACTION_VIEW coordinates' },
                { name: 'Chrome Browser', pkg: 'com.android.chrome', action: 'ACTION_VIEW web URLs' },
              ].map((app) => (
                <div key={app.name} className="p-2.5 rounded-xl bg-[#141426] border border-slate-800 text-left">
                  <div className="font-cyber font-semibold text-xs text-white flex items-center justify-between">
                    <span>{app.name}</span>
                    <span className="text-[9px] text-[#ff70a6] font-mono-code">OFFICIAL</span>
                  </div>
                  <div className="text-[9px] text-slate-400 font-mono-code truncate mt-0.5">
                    {app.pkg}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-1">
                    {app.action}
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-2">
              <button
                onClick={handleTriggerAccessibilityConsent}
                className="w-full bg-[#1b1b30] hover:bg-[#252545] border border-slate-700 text-slate-200 hover:text-white font-cyber text-xs py-2 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-98"
              >
                <ExternalLink className="w-3.5 h-3.5 text-[#ff2d78]" />
                <span>Simulate Informed User-Consent Flow (Native Bridge)</span>
              </button>
            </div>

            {bridgeResult && (
              <div className="p-2.5 rounded-xl bg-purple-950/40 border border-purple-500/40 text-purple-200 text-xs font-mono-code">
                {bridgeResult}
              </div>
            )}
          </div>
        </div>

        {/* Foundation Telemetry & Credits */}
        <div className="bg-[#0c0c17] border border-slate-800/80 rounded-2xl p-3 text-center text-xs text-slate-500 font-mono-code">
          <p className="text-slate-400">002 AI Companion Platform • Foundation v1.0</p>
          <p className="text-[10px] mt-0.5">Three.js 3D Engine • Server-Side Gemini Proxy • Responsive Android UI</p>
        </div>
      </div>
    </div>
  );
};
