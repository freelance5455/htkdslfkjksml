import React from 'react';
import {
  ArrowRight,
  Crown,
  Diamond,
  User,
  MessageSquare,
  Lightbulb,
  Palette,
  Globe,
  Bell,
  Share2,
  Trash2,
  FileText,
  Shield,
  UserX,
  LogOut,
  ChevronLeft,
  Sparkles
} from 'lucide-react';
import { AppThemeSettings, ModelSettings } from '../types';

interface SettingsViewProps {
  onBack: () => void;
  modelSettings: ModelSettings;
  themeSettings: AppThemeSettings;
  onUpdateTheme: (newTheme: Partial<AppThemeSettings>) => void;
  onOpenModelModal: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  onBack,
  modelSettings,
  themeSettings,
  onUpdateTheme,
  onOpenModelModal,
}) => {
  return (
    <div className="min-h-screen bg-slate-950 text-white pb-24 pt-3 px-4 max-w-lg mx-auto dir-rtl">
      {/* Top Header */}
      <div className="flex items-center justify-between mb-5 border-b border-slate-800 pb-3">
        <button
          onClick={onBack}
          className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
        >
          <ArrowRight className="w-5 h-5" />
        </button>
        <h2 className="text-base font-bold text-white">الإعدادات</h2>
        <div className="w-9" />
      </div>

      {/* "جاي برو" Pro Crown Banner matching Screenshot 5 */}
      <div className="bg-gradient-to-r from-pink-900/30 via-slate-900 to-purple-900/30 border border-pink-500/30 rounded-2xl p-4 mb-5 flex items-center justify-between shadow-lg">
        <div>
          <h3 className="font-bold text-white text-base flex items-center gap-1.5">
            <span>جاي برو</span>
            <Crown className="w-4 h-4 text-amber-400 fill-amber-400" />
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">احصل على المزايا الكاملة بدون حدود</p>
        </div>
        <button
          onClick={() => alert('اشتراك برو مفعل في هذه النسخة!')}
          className="bg-slate-100 hover:bg-white text-slate-900 font-bold px-4 py-2 rounded-xl text-xs shadow-md"
        >
          اشترك
        </button>
      </div>

      {/* Grid Cards (4 tiles) matching Screenshot 5 */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        {/* Card 1: Balance */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col items-center justify-center text-center shadow-sm hover:border-pink-500/40 transition-colors">
          <Diamond className="w-6 h-6 text-pink-400 mb-2" />
          <span className="text-xs text-slate-400">رصيدي</span>
          <span className="text-base font-bold text-white mt-0.5">0 💎</span>
        </div>

        {/* Card 2: Personal Info */}
        <div
          onClick={() => alert('المعلومات الشخصية: samrae bounadar')}
          className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col items-center justify-center text-center shadow-sm hover:border-pink-500/40 transition-colors cursor-pointer"
        >
          <User className="w-6 h-6 text-purple-400 mb-2" />
          <span className="text-xs text-slate-300 font-bold">المعلومات الشخصية</span>
        </div>

        {/* Card 3: Contact Us */}
        <div
          onClick={() => alert('تواصل معنا عبر البريد: support@pinkverse.ai')}
          className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col items-center justify-center text-center shadow-sm hover:border-pink-500/40 transition-colors cursor-pointer"
        >
          <MessageSquare className="w-6 h-6 text-blue-400 mb-2" />
          <span className="text-xs text-slate-300 font-bold">اتصل بنا</span>
        </div>

        {/* Card 4: What's New */}
        <div
          onClick={() => alert('إصدار PinkVerse AI 3.5: إضافة النماذج العالمية ودعم الصوت!')}
          className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col items-center justify-center text-center shadow-sm hover:border-pink-500/40 transition-colors cursor-pointer relative"
        >
          <span className="absolute top-2 right-2 w-2 h-2 bg-pink-500 rounded-full animate-ping" />
          <Lightbulb className="w-6 h-6 text-amber-400 mb-2" />
          <span className="text-xs text-slate-300 font-bold">ما الجديد</span>
        </div>
      </div>

      {/* Main Settings List with Toggles matching Screenshots 5 & 6 */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl divide-y divide-slate-800/80 mb-6 shadow-sm overflow-hidden text-xs">
        {/* Color Themes */}
        <div
          onClick={() => alert('تم تفعيل سمة الوردية والليلية المزدوجة!')}
          className="p-3.5 flex items-center justify-between hover:bg-slate-800/50 cursor-pointer transition-colors"
        >
          <div className="flex items-center space-x-3 space-x-reverse">
            <Palette className="w-4 h-4 text-pink-400" />
            <span className="font-semibold text-slate-200">سمات الألوان</span>
          </div>
          <ChevronLeft className="w-4 h-4 text-slate-500" />
        </div>

        {/* Global AI Model Selection */}
        <div
          onClick={onOpenModelModal}
          className="p-3.5 flex items-center justify-between hover:bg-slate-800/50 cursor-pointer transition-colors"
        >
          <div className="flex items-center space-x-3 space-x-reverse">
            <Globe className="w-4 h-4 text-purple-400" />
            <span className="font-semibold text-slate-200">النموذج العالمي</span>
          </div>
          <div className="flex items-center space-x-1 space-x-reverse text-pink-400 font-bold">
            <span>{modelSettings.chatModel}</span>
            <ChevronLeft className="w-4 h-4 text-slate-500" />
          </div>
        </div>

        {/* Background Toggle */}
        <div className="p-3.5 flex items-center justify-between">
          <span className="font-semibold text-slate-200">خلفية</span>
          <button
            onClick={() => onUpdateTheme({ showBackground: !themeSettings.showBackground })}
            className={`w-11 h-6 rounded-full transition-colors relative ${
              themeSettings.showBackground ? 'bg-pink-600' : 'bg-slate-700'
            }`}
          >
            <span
              className={`block w-4 h-4 rounded-full bg-white absolute top-1 transition-all ${
                themeSettings.showBackground ? 'right-6' : 'right-1'
              }`}
            />
          </button>
        </div>

        {/* Follow Button Toggle */}
        <div className="p-3.5 flex items-center justify-between">
          <span className="font-semibold text-slate-200">زر المتابعة</span>
          <button
            onClick={() => onUpdateTheme({ followButton: !themeSettings.followButton })}
            className={`w-11 h-6 rounded-full transition-colors relative ${
              themeSettings.followButton ? 'bg-pink-600' : 'bg-slate-700'
            }`}
          >
            <span
              className={`block w-4 h-4 rounded-full bg-white absolute top-1 transition-all ${
                themeSettings.followButton ? 'right-6' : 'right-1'
              }`}
            />
          </button>
        </div>

        {/* Push Notifications Toggle */}
        <div className="p-3.5 flex items-center justify-between">
          <div className="flex items-center space-x-3 space-x-reverse">
            <Bell className="w-4 h-4 text-blue-400" />
            <span className="font-semibold text-slate-200">إشعارات الدفع</span>
          </div>
          <button
            onClick={() => onUpdateTheme({ pushNotifications: !themeSettings.pushNotifications })}
            className={`w-11 h-6 rounded-full transition-colors relative ${
              themeSettings.pushNotifications ? 'bg-pink-600' : 'bg-slate-700'
            }`}
          >
            <span
              className={`block w-4 h-4 rounded-full bg-white absolute top-1 transition-all ${
                themeSettings.pushNotifications ? 'right-6' : 'right-1'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Additional Settings List matching Screenshot 6 */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl divide-y divide-slate-800/80 mb-6 shadow-sm overflow-hidden text-xs">
        <div
          onClick={() => alert('مشاركة التطبيق مع الأصدقاء!')}
          className="p-3.5 flex items-center justify-between hover:bg-slate-800/50 cursor-pointer"
        >
          <div className="flex items-center space-x-3 space-x-reverse">
            <Share2 className="w-4 h-4 text-green-400" />
            <span className="font-semibold text-slate-200">مشاركة التطبيق</span>
          </div>
        </div>

        <div
          onClick={() => alert('تم مسح ذاكرة التخزين المؤقت بنجاح!')}
          className="p-3.5 flex items-center justify-between hover:bg-slate-800/50 cursor-pointer"
        >
          <div className="flex items-center space-x-3 space-x-reverse">
            <Trash2 className="w-4 h-4 text-amber-400" />
            <span className="font-semibold text-slate-200">مسح ذاكرة التخزين المؤقت</span>
          </div>
        </div>

        <div
          onClick={() => alert('شروط الاستخدام: جميع الحقوق محفوظة لـ PinkVerse AI 2026.')}
          className="p-3.5 flex items-center justify-between hover:bg-slate-800/50 cursor-pointer"
        >
          <div className="flex items-center space-x-3 space-x-reverse">
            <FileText className="w-4 h-4 text-slate-400" />
            <span className="font-semibold text-slate-200">شروط الاستخدام</span>
          </div>
        </div>

        <div
          onClick={() => alert('سياسة الخصوصية: نحمي بياناتك ومحادثاتك بأقصى درجات الأمان.')}
          className="p-3.5 flex items-center justify-between hover:bg-slate-800/50 cursor-pointer"
        >
          <div className="flex items-center space-x-3 space-x-reverse">
            <Shield className="w-4 h-4 text-indigo-400" />
            <span className="font-semibold text-slate-200">سياسة الخصوصية</span>
          </div>
        </div>

        <div
          onClick={() => alert('إعداد اللغة: اللغة الحالية هي العربية')}
          className="p-3.5 flex items-center justify-between hover:bg-slate-800/50 cursor-pointer"
        >
          <div className="flex items-center space-x-3 space-x-reverse">
            <Globe className="w-4 h-4 text-pink-400" />
            <span className="font-semibold text-slate-200">إعداد اللغة</span>
          </div>
          <span className="text-slate-400 font-bold">العربية</span>
        </div>

        {/* NSFW Content Switch Toggle (+18) matching Screenshot 6 */}
        <div className="p-3.5 flex items-center justify-between">
          <div className="flex items-center space-x-3 space-x-reverse">
            <Shield className="w-4 h-4 text-red-400" />
            <span className="font-semibold text-slate-200">إظهار محتوى (+18) NSFW</span>
          </div>
          <button
            onClick={() => onUpdateTheme({ showNsfw: !themeSettings.showNsfw })}
            className={`w-11 h-6 rounded-full transition-colors relative ${
              themeSettings.showNsfw ? 'bg-pink-600' : 'bg-slate-700'
            }`}
          >
            <span
              className={`block w-4 h-4 rounded-full bg-white absolute top-1 transition-all ${
                themeSettings.showNsfw ? 'right-6' : 'right-1'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Logout Button matching Screenshot 6 */}
      <button
        onClick={() => alert('تم تسجيل الخروج بنجاح!')}
        className="w-full bg-slate-900 border border-slate-800 hover:border-red-500/50 text-slate-300 hover:text-red-400 font-bold py-3.5 rounded-2xl text-xs transition-colors shadow-sm"
      >
        تسجيل الخروج
      </button>
    </div>
  );
};
