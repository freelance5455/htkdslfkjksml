import React, { useRef, useState } from "react";
import {
  Settings as SettingsIcon,
  Download,
  Upload,
  Moon,
  Sun,
  Shield,
  Trash2,
  FileCode,
  RotateCcw,
  BarChart3,
  CheckCircle2,
  FileText,
  Palette,
  FileSpreadsheet,
  Globe,
  FileType,
  Sparkles,
  Check
} from "lucide-react";
import { Note, TrashItem, VaultMetadata, Flashcard, ThemeAccent } from "../types";
import {
  downloadFile,
  exportNotesAsCSV,
  exportNotesAsHTML,
  exportNotesAsTXT
} from "../utils/storage";

interface SettingsViewProps {
  notes: Note[];
  trash: TrashItem[];
  flashcards: Flashcard[];
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
  themeAccent: ThemeAccent;
  setThemeAccent: (accent: ThemeAccent) => void;
  onOpenTrash: () => void;
  onOpenDocumentHub?: () => void;
  onImportBackup: (importedData: any) => void;
  onImportCustomDocument?: (title: string, content: string, category: string) => void;
  onResetAllData: () => void;
}

const THEME_ACCENTS: Array<{ id: ThemeAccent; name: string; bg: string; border: string; preview: string }> = [
  { id: "teal", name: "Zümrüt Teal", bg: "bg-teal-600", border: "border-teal-500", preview: "#0d9488" },
  { id: "emerald", name: "Orman Yeşili", bg: "bg-emerald-600", border: "border-emerald-500", preview: "#059669" },
  { id: "blue", name: "Klasik Mavi", bg: "bg-blue-600", border: "border-blue-500", preview: "#2563eb" },
  { id: "ocean", name: "Derin Okyanus", bg: "bg-sky-600", border: "border-sky-500", preview: "#0284c7" },
  { id: "purple", name: "Ametist Moru", bg: "bg-purple-600", border: "border-purple-500", preview: "#9333ea" },
  { id: "rose", name: "Yakut Gül", bg: "bg-rose-600", border: "border-rose-500", preview: "#e11d48" },
  { id: "amber", name: "Sıcak Kehribar", bg: "bg-amber-600", border: "border-amber-500", preview: "#d97706" },
  { id: "slate", name: "Arduvaz Gri", bg: "bg-slate-600", border: "border-slate-500", preview: "#475569" },
];

export const SettingsView: React.FC<SettingsViewProps> = ({
  notes,
  trash,
  flashcards,
  darkMode,
  setDarkMode,
  themeAccent,
  setThemeAccent,
  onOpenTrash,
  onOpenDocumentHub,
  onImportBackup,
  onImportCustomDocument,
  onResetAllData,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [importStatus, setImportStatus] = useState<string | null>(null);

  // Calculate statistics
  const totalPublicNotes = notes.length;
  const totalTrashNotes = trash.length;
  const totalWords = notes.reduce(
    (acc, n) => acc + (n.content?.split(/\s+/).filter(Boolean).length || 0),
    0
  );

  const allTasks = notes.flatMap((n) => n.tasks || []);
  const totalTasks = allTasks.length;
  const completedTasks = allTasks.filter((t) => t.completed).length;

  // Export JSON Backup
  const handleExportJSON = () => {
    const backup = {
      app: "NoteFlow",
      version: "2.5",
      exportedAt: new Date().toISOString(),
      notes,
      trash,
      flashcards,
    };
    const jsonStr = JSON.stringify(backup, null, 2);
    downloadFile(
      `NoteFlow_Yedek_${new Date().toISOString().slice(0, 10)}.json`,
      jsonStr,
      "application/json"
    );
  };

  // Export Markdown
  const handleExportMarkdown = () => {
    let md = `# NoteFlow Not Arşivi\n*Tarih: ${new Date().toLocaleString("tr-TR")}*\n\n`;
    notes.forEach((n, idx) => {
      md += `## ${idx + 1}. ${n.title}\n`;
      md += `*Kategori: ${n.category} | Tarih: ${new Date(n.updatedAt).toLocaleString("tr-TR")}*\n`;
      if (n.tags?.length) md += `*Etiketler: ${n.tags.join(" ")}*\n`;
      md += `\n${n.content}\n\n`;
      if (n.tasks?.length) {
        md += `### Görevler:\n`;
        n.tasks.forEach((t) => {
          md += `- [${t.completed ? "x" : " "}] ${t.text}\n`;
        });
        md += `\n`;
      }
      md += `---\n\n`;
    });
    downloadFile(
      `NoteFlow_Tum_Notlar_${new Date().toISOString().slice(0, 10)}.md`,
      md,
      "text/markdown"
    );
  };

  // Universal Document Import Handler (Accepts JSON, TXT, MD, CSV, HTML)
  const handleUniversalFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const ext = file.name.split(".").pop()?.toLowerCase();
    const reader = new FileReader();

    reader.onload = (event) => {
      const text = event.target?.result as string;
      try {
        if (ext === "json") {
          // Parse NoteFlow JSON
          const parsed = JSON.parse(text);
          onImportBackup(parsed);
          setImportStatus("JSON sistem yedeği başarıyla geri yüklendi!");
        } else if (ext === "csv") {
          // Parse CSV
          const lines = text.split("\n").filter((l) => l.trim().length > 0);
          if (lines.length > 1 && onImportCustomDocument) {
            lines.slice(1).forEach((line) => {
              const parts = line.split(",").map((p) => p.replace(/^"|"$/g, "").trim());
              const [title, category, content] = parts;
              if (title || content) {
                onImportCustomDocument(title || "CSV İçe Aktarılan", content || "", category || "İçe Aktarılan");
              }
            });
            setImportStatus("CSV tablosundan notlar başarıyla içeri aktarıldı!");
          }
        } else if (ext === "html" || ext === "htm") {
          // Parse HTML text
          const doc = new DOMParser().parseFromString(text, "text/html");
          const title = doc.querySelector("h1, title")?.textContent || file.name.replace(/\.[^/.]+$/, "");
          const body = doc.body.innerHTML || text;
          if (onImportCustomDocument) {
            onImportCustomDocument(title, body, "İçe Aktarılan");
            setImportStatus("HTML belgesi başarıyla zengin not olarak eklendi!");
          }
        } else {
          // TXT or MD
          const title = file.name.replace(/\.[^/.]+$/, "");
          if (onImportCustomDocument) {
            onImportCustomDocument(title, text, "İçe Aktarılan");
            setImportStatus(`${file.name} belgesi başarıyla yeni not olarak eklendi!`);
          }
        }
      } catch (err: any) {
        console.error(err);
        alert("Belge okunurken bir hata oluştu: " + err.message);
      }
    };

    reader.readAsText(file);
    e.target.value = "";
  };

  return (
    <div className="max-w-3xl mx-auto py-6 px-4 space-y-6 animate-in fade-in">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-2xl bg-teal-100 dark:bg-teal-950/80 text-teal-600 dark:text-teal-400 flex items-center justify-center font-bold">
          <SettingsIcon className="w-5 h-5" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">Uygulama Ayarları</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Renk temaları, gece/gündüz modu, evrensel belge indirme/içe aktarma ve güvenlik.
          </p>
        </div>
      </div>

      {/* Stats Cards Bento */}
      <div className="grid grid-cols-3 gap-3">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center shadow-xs">
          <span className="text-2xl font-extrabold text-teal-600 dark:text-teal-400 block">
            {totalPublicNotes}
          </span>
          <span className="text-[11px] font-semibold text-slate-500">Açık Not</span>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center shadow-xs">
          <span className="text-2xl font-extrabold text-blue-600 dark:text-blue-400 block">
            {totalWords}
          </span>
          <span className="text-[11px] font-semibold text-slate-500">Toplam Kelime</span>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center shadow-xs">
          <span className="text-2xl font-extrabold text-amber-600 dark:text-amber-400 block">
            {completedTasks}/{totalTasks}
          </span>
          <span className="text-[11px] font-semibold text-slate-500">Tamamlanan Görev</span>
        </div>
      </div>

      {/* Import Status Alert */}
      {importStatus && (
        <div className="p-3 bg-emerald-100 dark:bg-emerald-950/70 border border-emerald-300 dark:border-emerald-800 rounded-2xl text-xs font-bold text-emerald-800 dark:text-emerald-200 flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4" />
            <span>{importStatus}</span>
          </div>
          <button
            onClick={() => setImportStatus(null)}
            className="text-emerald-700 dark:text-emerald-300 hover:text-emerald-900"
          >
            ✕
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. TEMA VE GÖRÜNÜM (Gece/Gündüz & 6 Canlı Tema Rengi)                       */}
      {/* ========================================================================= */}
      <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 p-5 space-y-4 shadow-xs">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-50 dark:bg-slate-700 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              {darkMode ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">Gece & Gündüz Modu</h4>
              <p className="text-[11px] text-slate-500">
                {darkMode ? "Karanlık gece modu aktif (Göz dostu)" : "Aydınlık gündüz modu aktif"}
              </p>
            </div>
          </div>

          <button
            onClick={() => setDarkMode(!darkMode)}
            className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 transition-colors"
          >
            {darkMode ? "☀️ Gündüz Moduna Geç" : "🌙 Gece Moduna Geç"}
          </button>
        </div>

        {/* Canlı Tema Renkleri (Tema Paleti) */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Palette className="w-4 h-4 text-teal-600 dark:text-teal-400" />
            <h4 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">
              Vurgu & Tema Rengi Seçimi
            </h4>
          </div>
          <p className="text-[11px] text-slate-500 mb-3">
            Uygulamanın genel vurgu rengini kişisel tarzınıza göre özelleştirin:
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {THEME_ACCENTS.map((t) => {
              const isSelected = themeAccent === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => setThemeAccent(t.id)}
                  className={`p-3 rounded-2xl border text-left flex items-center gap-3 transition-all ${
                    isSelected
                      ? "border-teal-500 ring-2 ring-teal-500/30 bg-teal-50/50 dark:bg-teal-950/30"
                      : "border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700/50"
                  }`}
                >
                  <div
                    className="w-5 h-5 rounded-full shadow-xs shrink-0 flex items-center justify-center text-white text-[10px]"
                    style={{ backgroundColor: t.preview }}
                  >
                    {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">
                    {t.name}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. EVRENSEL BELGE VE YEDEKLEME (JSON, HTML, CSV, TXT, MD)                  */}
      {/* ========================================================================= */}
      <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 p-5 space-y-4 shadow-xs">
        <div>
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-2">
              <Download className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                Evrensel Belge ve Format Merkezi
              </h4>
            </div>
            {onOpenDocumentHub && (
              <button
                onClick={onOpenDocumentHub}
                className="px-3 py-1 rounded-xl text-xs font-bold text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 hover:bg-teal-100 dark:hover:bg-teal-900/50 transition-colors flex items-center gap-1.5"
              >
                <span>Format Merkezini Aç (13+ Format)</span>
                <span>→</span>
              </button>
            )}
          </div>
          <p className="text-[11px] text-slate-500">
            Word (.docx), PDF, Excel (.xlsx), CSV, PowerPoint (.pptx), OpenDocument (.odt, .ods), TXT ve ZIP arşivleme:
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {/* JSON */}
          <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-teal-50 dark:bg-teal-950 text-teal-600 dark:text-teal-400">
                <FileCode className="w-4 h-4" />
              </div>
              <div>
                <h5 className="text-xs font-bold text-slate-800 dark:text-slate-200">Tam JSON Yedeği</h5>
                <p className="text-[10px] text-slate-400">Notlar, kasa ve kartlar</p>
              </div>
            </div>
            <button
              onClick={handleExportJSON}
              className="px-3 py-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
            >
              JSON İndir
            </button>
          </div>

          {/* HTML */}
          <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400">
                <Globe className="w-4 h-4" />
              </div>
              <div>
                <h5 className="text-xs font-bold text-slate-800 dark:text-slate-200">Tek Dosya HTML Web</h5>
                <p className="text-[10px] text-slate-400">Tüm tarayıcılarda açılır</p>
              </div>
            </div>
            <button
              onClick={() => exportNotesAsHTML(notes)}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
            >
              HTML İndir
            </button>
          </div>

          {/* CSV */}
          <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400">
                <FileSpreadsheet className="w-4 h-4" />
              </div>
              <div>
                <h5 className="text-xs font-bold text-slate-800 dark:text-slate-200">Excel / CSV Tablosu</h5>
                <p className="text-[10px] text-slate-400">E-tablo formatında liste</p>
              </div>
            </div>
            <button
              onClick={() => exportNotesAsCSV(notes)}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
            >
              CSV İndir
            </button>
          </div>

          {/* TXT */}
          <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                <FileType className="w-4 h-4" />
              </div>
              <div>
                <h5 className="text-xs font-bold text-slate-800 dark:text-slate-200">Düz Metin (TXT)</h5>
                <p className="text-[10px] text-slate-400">Sade metin belgesi</p>
              </div>
            </div>
            <button
              onClick={() => exportNotesAsTXT(notes)}
              className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
            >
              TXT İndir
            </button>
          </div>

          {/* Markdown */}
          <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center justify-between sm:col-span-2">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-purple-50 dark:bg-purple-950 text-purple-600 dark:text-purple-400">
                <FileText className="w-4 h-4" />
              </div>
              <div>
                <h5 className="text-xs font-bold text-slate-800 dark:text-slate-200">Markdown Arşivi (.md)</h5>
                <p className="text-[10px] text-slate-400">Biçimlendirilmiş profesyonel not defteri</p>
              </div>
            </div>
            <button
              onClick={handleExportMarkdown}
              className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
            >
              MD İndir
            </button>
          </div>
        </div>

        {/* UNIVERSAL DOCUMENT IMPORT */}
        <div className="pt-3 border-t border-slate-100 dark:border-slate-700/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h5 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
              <Upload className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              Her Türlü Belgeyi İçe Aktar (Geri Yükle)
            </h5>
            <p className="text-[11px] text-slate-500">
              JSON yedeği, TXT, Markdown (.md), CSV veya HTML belgelerinizi seçip içeri aktarabilirsiniz.
            </p>
          </div>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="px-4 py-2 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 border border-slate-200 dark:border-slate-600 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-200 transition-all shrink-0"
          >
            📂 Belge Dosyası Seç
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".json,.txt,.md,.csv,.html,.htm"
            className="hidden"
            onChange={handleUniversalFileImport}
          />
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. ÇÖP KUTUSU                                                             */}
      {/* ========================================================================= */}
      <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-xs">
        {/* Trash */}
        <div className="p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">Çöp Kutusu</h4>
              <p className="text-[11px] text-slate-500">
                {totalTrashNotes} adet silinmiş not saklanıyor
              </p>
            </div>
          </div>

          <button
            onClick={onOpenTrash}
            className="px-3.5 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 transition-colors"
          >
            Çöpü Görüntüle
          </button>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="p-5 rounded-3xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h4 className="text-xs sm:text-sm font-bold text-rose-900 dark:text-rose-200">Verileri Sıfırla</h4>
          <p className="text-[11px] text-rose-700 dark:text-rose-400">
            Tüm yerel notları, çalışma kartlarını ve kasa verilerini tamamen temizler.
          </p>
        </div>

        <button
          onClick={() => {
            if (
              confirm(
                "DİKKAT: Tüm notlarınız, kasanız ve ayarlarınız silinecek. Devam etmek istiyor musunuz?"
              )
            ) {
              onResetAllData();
            }
          }}
          className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-all"
        >
          Tüm Verileri Temizle
        </button>
      </div>

      {/* App Info Footer */}
      <div className="text-center text-xs text-slate-400 pt-2">
        <p>NoteFlow Pro v2.5 — Akıllı Not ve Yaşam Asistanı</p>
        <p className="text-[10px] mt-0.5 text-slate-400/80">
          Uçtan uca şifreleme, Word zengin metin desteği, evrensel dışa aktarma ve Google Gemini 3.8 Flash yapay zeka gücüyle.
        </p>
      </div>
    </div>
  );
};
