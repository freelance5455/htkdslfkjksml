import React, { useEffect, useMemo, useRef, useState } from 'react';
import { RotateCcw } from 'lucide-react';
import type { StoreData, StoreSettings } from '../types';
import { formatLiveClock, toDateKey, useNowMs } from '../utils';
import { Icon } from './Icon';
import { CustomSelect, Modal, ToggleSwitch } from './SharedUI';

const ClockPreviewPill: React.FC<{ settings: StoreSettings }> = ({ settings }) => {
  const nowMs = useNowMs(true, 1000);
  const preview = formatLiveClock(nowMs, settings);
  return (
    <div className="px-3.5 py-1.5 rounded-xl bg-slate-900 text-white font-mono text-sm font-bold tabular-nums flex items-center gap-2 shadow-sm">
      <Icon name="clock" className="w-4 h-4 text-blue-400" />
      <span>{preview.timeText}</span>
      {preview.dateText && <span className="text-xs font-sans font-medium text-slate-300">· {preview.dateText}</span>}
    </div>
  );
};

interface SettingsViewProps {
  data: StoreData;
  t: Record<string, string>;
  onSaveSettings: (newSettings: StoreSettings) => void;
  onRestoreBackup: (parsed: StoreData) => void;
  onResetStorage: (mode: 'empty' | 'demo') => void;
  notify: (msg: string, type?: 'success' | 'error') => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  data,
  t,
  onSaveSettings,
  onRestoreBackup,
  onResetStorage,
  notify,
}) => {
  const [form, setForm] = useState<StoreSettings>(data.settings);
  const [resetModalOpen, setResetModalOpen] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const logoRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setForm(data.settings);
  }, [data.settings]);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setForm((prev) => ({ ...prev, storeLogo: String(reader.result || '') }));
    reader.readAsDataURL(file);
  };

  const handleExportBackup = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mystore-backup-${toDateKey(new Date())}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result || ''));
        if (!parsed || !Array.isArray(parsed.products) || !Array.isArray(parsed.sales)) {
          notify(t.invalidBackup, 'error');
          return;
        }
        onRestoreBackup({ ...parsed, settings: { ...parsed.settings, language: 'en' } });
        notify(t.backupRestored, 'success');
      } catch {
        notify(t.invalidBackup, 'error');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const customerOptions = useMemo(
    () =>
      data.customers.map((c) => ({
        value: c.id,
        label: c.id === 'walk-in' ? form.defaultWalkInName || c.name : c.name,
        sublabel: c.phone && c.phone !== '-' ? c.phone : undefined,
      })),
    [data.customers, form.defaultWalkInName]
  );

  const inputClass =
    'w-full rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition';

  const adjustOffset = (deltaMin: number) => {
    setForm((prev) => ({ ...prev, clockOffsetMinutes: (prev.clockOffsetMinutes || 0) + deltaMin }));
  };

  return (
    <div className="max-w-3xl space-y-6">
      <form
        noValidate
        onSubmit={(e) => {
          e.preventDefault();
          onSaveSettings({ ...form, language: 'en' });
        }}
        className="space-y-6"
      >
        {/* 1. Store Information */}
        <section className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 space-y-5">
          <h3 className="font-bold text-slate-800 text-base border-b border-slate-100 pb-3">{t.storeSettings}</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.storeName}</label>
              <input value={form.storeName} onChange={(e) => setForm({ ...form, storeName: e.target.value })} className={inputClass} />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.storePhone}</label>
              <input
                value={form.storePhone || ''}
                onChange={(e) => setForm({ ...form, storePhone: e.target.value })}
                placeholder="+880 1XXX-XXXXXX"
                className={inputClass}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.defaultLowStockLimit}</label>
              <input
                type="number"
                min="0"
                value={form.defaultLowStockLimit}
                onChange={(e) => setForm({ ...form, defaultLowStockLimit: parseInt(e.target.value || '0', 10) })}
                className={`${inputClass} tabular-nums`}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.storeLogo}</label>
              <div className="flex flex-wrap items-center gap-3 p-2.5 rounded-xl bg-slate-50 border border-slate-200/80">
                {form.storeLogo ? (
                  <img src={form.storeLogo} alt="Store logo" className="h-10 w-10 rounded-xl object-contain border border-slate-200 bg-white p-1" />
                ) : (
                  <div className="h-10 w-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-extrabold text-base">
                    {(form.storeName || 'M')[0].toUpperCase()}
                  </div>
                )}
                <input ref={logoRef} type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
                <button
                  type="button"
                  onClick={() => logoRef.current?.click()}
                  className="px-3 py-1.5 rounded-lg bg-white border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-100 whitespace-nowrap transition"
                >
                  {t.uploadLogo}
                </button>
                {form.storeLogo && (
                  <button type="button" onClick={() => setForm({ ...form, storeLogo: '' })} className="text-xs font-bold text-rose-600 hover:underline whitespace-nowrap">
                    {t.removeLogo}
                  </button>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* 2. Live Clock & Time Customization */}
        <section className="surface-card p-5 sm:p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <h3 className="font-bold text-slate-800 text-base">{t.clockSettings}</h3>
            <ClockPreviewPill settings={form} />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="flex items-center justify-between gap-3 p-3.5 rounded-xl border border-slate-200/90 bg-slate-50/70">
              <span className="text-sm font-semibold text-slate-800">{t.showClock}</span>
              <ToggleSwitch
                checked={form.showClock !== false}
                onChange={(v) => setForm({ ...form, showClock: v })}
                label={t.showClock}
              />
            </div>

            <div className="p-3 rounded-xl border border-slate-200/90 bg-slate-50/70 flex items-center justify-between gap-2">
              <span className="text-sm font-semibold text-slate-800">{t.clockFormat}</span>
              <div className="segmented-bar">
                {(['12h', '24h'] as const).map((fmt) => (
                  <button
                    type="button"
                    key={fmt}
                    onClick={() => setForm({ ...form, clockFormat: fmt })}
                    className={`segmented-option !px-3 !py-1.5 text-xs ${
                      (form.clockFormat || '12h') === fmt ? 'segmented-option-active !text-blue-600' : ''
                    }`}
                  >
                    {fmt === '12h' ? '12H' : '24H'}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between gap-3 p-3.5 rounded-xl border border-slate-200/90 bg-slate-50/70">
              <span className="text-sm font-semibold text-slate-800">{t.clockShowSeconds}</span>
              <ToggleSwitch
                checked={form.clockShowSeconds !== false}
                onChange={(v) => setForm({ ...form, clockShowSeconds: v })}
                label={t.clockShowSeconds}
              />
            </div>

            <div className="flex items-center justify-between gap-3 p-3.5 rounded-xl border border-slate-200/90 bg-slate-50/70">
              <span className="text-sm font-semibold text-slate-800">{t.clockShowDate}</span>
              <ToggleSwitch
                checked={form.clockShowDate !== false}
                onChange={(v) => setForm({ ...form, clockShowDate: v })}
                label={t.clockShowDate}
              />
            </div>
          </div>

          {/* Time Adjustment / Forward Controls */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <label className="text-xs font-semibold text-slate-700">{t.clockOffsetMinutes}</label>
              <span className="text-xs font-mono font-bold text-indigo-600 tabular-nums">
                {(form.clockOffsetMinutes || 0) >= 0 ? `+${form.clockOffsetMinutes || 0}` : form.clockOffsetMinutes} min
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <input
                type="number"
                value={form.clockOffsetMinutes ?? 0}
                onChange={(e) => setForm({ ...form, clockOffsetMinutes: parseInt(e.target.value || '0', 10) || 0 })}
                className="w-28 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm font-bold tabular-nums outline-none focus:border-blue-500"
              />
              <button type="button" onClick={() => adjustOffset(-60)} className="btn-secondary px-3 py-2 text-xs">
                -1h
              </button>
              <button type="button" onClick={() => adjustOffset(-15)} className="btn-secondary px-3 py-2 text-xs">
                -15m
              </button>
              <button type="button" onClick={() => adjustOffset(15)} className="btn-secondary px-3 py-2 text-xs text-blue-700">
                +15m
              </button>
              <button type="button" onClick={() => adjustOffset(60)} className="btn-secondary px-3 py-2 text-xs text-blue-700">
                +1h
              </button>
              {(form.clockOffsetMinutes || 0) !== 0 && (
                <button
                  type="button"
                  onClick={() => setForm({ ...form, clockOffsetMinutes: 0 })}
                  className="px-3 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 border border-rose-200 text-xs font-bold text-rose-700 whitespace-nowrap"
                >
                  {t.resetTime}
                </button>
              )}
            </div>
          </div>
        </section>

        {/* 3. Customer & Checkout Settings */}
        <section className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 space-y-5">
          <h3 className="font-bold text-slate-800 text-base border-b border-slate-100 pb-3">{t.customerPosSettings}</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.defaultWalkInName}</label>
              <input
                value={form.defaultWalkInName ?? 'Walk-in Customer'}
                onChange={(e) => setForm({ ...form, defaultWalkInName: e.target.value })}
                className={inputClass}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.defaultPosCustomer}</label>
              <CustomSelect
                value={form.defaultCustomerId || 'walk-in'}
                onChange={(val) => setForm({ ...form, defaultCustomerId: val })}
                options={customerOptions}
                searchable
              />
            </div>
            <div className="flex items-center justify-between gap-3 p-3.5 rounded-xl border border-slate-200/90 bg-slate-50/70">
              <span className="text-sm font-semibold text-slate-800">{t.allowCreditSales}</span>
              <ToggleSwitch
                checked={form.allowCreditSales !== false}
                onChange={(v) => setForm({ ...form, allowCreditSales: v })}
                label={t.allowCreditSales}
              />
            </div>
            <div className="flex items-center justify-between gap-3 p-3.5 rounded-xl border border-slate-200/90 bg-slate-50/70">
              <span className="text-sm font-semibold text-slate-800">{t.showCustomerPhoneOnReceipt}</span>
              <ToggleSwitch
                checked={form.showCustomerPhoneOnReceipt !== false}
                onChange={(v) => setForm({ ...form, showCustomerPhoneOnReceipt: v })}
                label={t.showCustomerPhoneOnReceipt}
              />
            </div>
          </div>
        </section>

        {/* 4. Receipt Settings */}
        <section className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 space-y-5">
          <h3 className="font-bold text-slate-800 text-base border-b border-slate-100 pb-3">{t.receiptSettings}</h3>
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.receiptHeader}</label>
              <input value={form.receiptHeader} onChange={(e) => setForm({ ...form, receiptHeader: e.target.value })} className={inputClass} />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">{t.receiptFooter}</label>
              <textarea
                rows={2}
                value={form.receiptFooter}
                onChange={(e) => setForm({ ...form, receiptFooter: e.target.value })}
                className={inputClass}
              />
            </div>
          </div>

          <div className="pt-2">
            <button type="submit" className="btn-primary px-6 py-2.5 text-sm">
              {t.saveSettings}
            </button>
          </div>
        </section>
      </form>

      {/* 5. Backup, Restore & Storage Reset */}
      <div className="surface-card p-5 sm:p-6 space-y-4">
        <div>
          <h3 className="font-bold text-slate-800 text-base">{t.backupRestore}</h3>
          <p className="text-xs text-slate-500 mt-1">
            Download a full JSON backup file, upload an earlier backup to restore, or reset your local app storage.
          </p>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-200/80 text-center tabular-nums">
          <div>
            <p className="text-[11px] font-semibold text-slate-500">Products</p>
            <p className="text-sm font-extrabold text-slate-900">{data.products.length}</p>
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-500">Sales</p>
            <p className="text-sm font-extrabold text-blue-600">{data.sales.length}</p>
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-500">Customers</p>
            <p className="text-sm font-extrabold text-slate-900">{data.customers.length}</p>
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-500">Categories</p>
            <p className="text-sm font-extrabold text-slate-900">{data.categories.length}</p>
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-500">Expenses</p>
            <p className="text-sm font-extrabold text-slate-900">{(data.expenses || []).length}</p>
          </div>
          <div>
            <p className="text-[11px] font-semibold text-slate-500">Sessions</p>
            <p className="text-sm font-extrabold text-slate-900">{(data.shopSessions || []).length}</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="flex flex-wrap gap-2.5">
            <button type="button" onClick={handleExportBackup} className="btn-emerald px-4 py-2.5 text-sm">
              <Icon name="download" className="w-4 h-4" />
              <span>{t.exportBackup}</span>
            </button>
            <input ref={fileRef} type="file" accept=".json,application/json" onChange={handleImportBackup} className="hidden" />
            <button type="button" onClick={() => fileRef.current?.click()} className="btn-dark px-4 py-2.5 text-sm">
              <span>{t.importBackup}</span>
            </button>
          </div>

          <button
            type="button"
            onClick={() => setResetModalOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-bold text-sm"
          >
            <RotateCcw className="w-4 h-4" />
            <span>{t.resetStorage}</span>
          </button>
        </div>
      </div>

      {/* In-App Reset Storage Confirmation Modal */}
      <Modal open={resetModalOpen} onClose={() => setResetModalOpen(false)} title={t.resetStorage} maxWidth="max-w-md">
        <div className="space-y-4">
          <p className="text-sm text-slate-600 leading-relaxed">
            Choose how you want to reset your browser storage. Tip: Download a JSON backup first if you want to keep a copy of your current data.
          </p>
          <div className="space-y-2.5">
            <button
              type="button"
              onClick={() => {
                onResetStorage('empty');
                setResetModalOpen(false);
              }}
              className="w-full text-left p-3.5 rounded-xl border border-rose-200 bg-rose-50/70 hover:bg-rose-100/80 transition"
            >
              <p className="text-sm font-bold text-rose-800">Start Clean (Empty Store)</p>
              <p className="text-xs text-rose-600 mt-0.5">
                Clears all products, sales invoices, stock movements, expenses, and timers so you can enter fresh shop data.
              </p>
            </button>
            <button
              type="button"
              onClick={() => {
                onResetStorage('demo');
                setResetModalOpen(false);
              }}
              className="w-full text-left p-3.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 transition"
            >
              <p className="text-sm font-bold text-slate-900">Restore Starter Sample Data</p>
              <p className="text-xs text-slate-500 mt-0.5">
                Resets all data back to the initial starter categories and sample items.
              </p>
            </button>
          </div>
          <div className="flex justify-end pt-2 border-t border-slate-100">
            <button type="button" onClick={() => setResetModalOpen(false)} className="btn-secondary px-4 py-2 text-xs">
              {t.cancel}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
