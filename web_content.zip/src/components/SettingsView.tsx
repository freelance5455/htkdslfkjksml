import React, { useState, useRef } from 'react';
import {
  Store,
  DollarSign,
  Tag,
  Layers,
  LayoutGrid,
  Download,
  Upload,
  FileSpreadsheet,
  RotateCcw,
  Trash2,
  Volume2,
  VolumeX,
  Vibrate,
  Smartphone,
  Plus,
  ArrowUp,
  ArrowDown,
  Check,
  AlertTriangle,
} from 'lucide-react';
import { StoreData } from '../types';
import { CURRENCIES } from '../utils/formatters';
import { exportProductsCsv, exportTransactionsCsv, clearStorageData, createSeedData } from '../utils/storage';
import { feedback } from '../utils/haptics';
import { ConfirmModal } from './ConfirmModal';
import { PromptModal } from './PromptModal';

interface SettingsViewProps {
  store: StoreData;
  onUpdateStore: (updater: (prev: StoreData) => StoreData) => void;
  onResetSampleData: () => void;
  onClearAllData: (mode?: 'all' | 'txns-only') => void;
  isAndroidFrame: boolean;
  onToggleAndroidFrame: () => void;
  soundEnabled?: boolean;
  hapticsEnabled?: boolean;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  store,
  onUpdateStore,
  onResetSampleData,
  onClearAllData,
  isAndroidFrame,
  onToggleAndroidFrame,
  soundEnabled = true,
  hapticsEnabled = true,
}) => {
  const [newCat, setNewCat] = useState('');
  const [newUnit, setNewUnit] = useState('');
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // In-app modals state (replaces blocked window.confirm and window.prompt)
  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    confirmLabel: string;
    isDestructive: boolean;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    confirmLabel: 'Confirm',
    isDestructive: true,
    onConfirm: () => {},
  });

  const [promptConfig, setPromptConfig] = useState<{
    isOpen: boolean;
    title: string;
    label?: string;
    initialValue: string;
    placeholder?: string;
    onConfirm: (val: string) => void;
  }>({
    isOpen: false,
    title: '',
    label: '',
    initialValue: '',
    placeholder: '',
    onConfirm: () => {},
  });

  // Clear data sheet modal
  const [showClearOptions, setShowClearOptions] = useState(false);

  const showStatus = (msg: string) => {
    setStatusMsg(msg);
    setTimeout(() => setStatusMsg(null), 3500);
  };

  // Business Profile updates
  const handleProfileChange = (field: keyof StoreData, value: string) => {
    onUpdateStore((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  // Add category
  const handleAddCat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCat.trim()) return;
    const catName = newCat.trim();
    if (store.cats.some((c) => c.toLowerCase() === catName.toLowerCase())) {
      showStatus('Category already in list');
      return;
    }
    onUpdateStore((prev) => ({
      ...prev,
      cats: [...prev.cats, catName],
    }));
    setNewCat('');
    feedback.vibrateSoft(hapticsEnabled);
    showStatus(`Added category "${catName}"`);
  };

  // Rename category using in-app prompt modal
  const handleRenameCat = (oldCat: string) => {
    setPromptConfig({
      isOpen: true,
      title: 'Rename Category',
      label: `Update category name for "${oldCat}"`,
      initialValue: oldCat,
      placeholder: 'Enter new category name',
      onConfirm: (cleanName: string) => {
        if (!cleanName || cleanName.toLowerCase() === oldCat.toLowerCase()) return;
        onUpdateStore((prev) => ({
          ...prev,
          cats: prev.cats.map((c) => (c === oldCat ? cleanName : c)),
          products: prev.products.map((p) => (p.cat === oldCat ? { ...p, cat: cleanName } : p)),
        }));
        showStatus(`Renamed category to "${cleanName}"`);
      },
    });
  };

  // Delete category using in-app confirm modal
  const handleDeleteCat = (catName: string) => {
    setConfirmConfig({
      isOpen: true,
      title: 'Remove Category',
      message: `Remove "${catName}" from the category list? Existing products will keep their category.`,
      confirmLabel: 'Remove Category',
      isDestructive: true,
      onConfirm: () => {
        onUpdateStore((prev) => ({
          ...prev,
          cats: prev.cats.filter((c) => c !== catName),
        }));
        showStatus(`Removed category "${catName}"`);
      },
    });
  };

  // Add unit
  const handleAddUnit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUnit.trim()) return;
    const unitName = newUnit.trim();
    if (store.units.some((u) => u.toLowerCase() === unitName.toLowerCase())) {
      showStatus('Unit already in list');
      return;
    }
    onUpdateStore((prev) => ({
      ...prev,
      units: [...prev.units, unitName],
    }));
    setNewUnit('');
    feedback.vibrateSoft(hapticsEnabled);
    showStatus(`Added unit "${unitName}"`);
  };

  // Rename unit using in-app prompt modal
  const handleRenameUnit = (oldUnit: string) => {
    setPromptConfig({
      isOpen: true,
      title: 'Rename Unit',
      label: `Update unit of measure for "${oldUnit}"`,
      initialValue: oldUnit,
      placeholder: 'Enter new unit name (e.g. Box, Kg)',
      onConfirm: (cleanName: string) => {
        if (!cleanName || cleanName.toLowerCase() === oldUnit.toLowerCase()) return;
        onUpdateStore((prev) => ({
          ...prev,
          units: prev.units.map((u) => (u === oldUnit ? cleanName : u)),
          products: prev.products.map((p) => (p.unit === oldUnit ? { ...p, unit: cleanName } : p)),
        }));
        showStatus(`Renamed unit to "${cleanName}"`);
      },
    });
  };

  // Delete unit using in-app confirm modal
  const handleDeleteUnit = (unitName: string) => {
    setConfirmConfig({
      isOpen: true,
      title: 'Remove Unit',
      message: `Remove "${unitName}" from the unit list? Existing products will keep their unit.`,
      confirmLabel: 'Remove Unit',
      isDestructive: true,
      onConfirm: () => {
        onUpdateStore((prev) => ({
          ...prev,
          units: prev.units.filter((u) => u !== unitName),
        }));
        showStatus(`Removed unit "${unitName}"`);
      },
    });
  };

  // Widgets toggle & order
  const handleToggleWidget = (id: string) => {
    onUpdateStore((prev) => ({
      ...prev,
      widgets: prev.widgets.map((w) => (w.id === id ? { ...w, on: !w.on } : w)),
    }));
    feedback.vibrateSoft(hapticsEnabled);
  };

  const handleMoveWidget = (index: number, direction: 'up' | 'down') => {
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= store.widgets.length) return;

    onUpdateStore((prev) => {
      const newWidgets = [...prev.widgets];
      const temp = newWidgets[index];
      newWidgets[index] = newWidgets[targetIdx];
      newWidgets[targetIdx] = temp;
      return { ...prev, widgets: newWidgets };
    });
    feedback.vibrateSoft(hapticsEnabled);
  };

  // Backup & CSV downloads
  const handleExportJson = () => {
    const jsonStr = JSON.stringify(store, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `stockmgr_backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    feedback.vibrateSuccess(hapticsEnabled);
    showStatus('Backup JSON downloaded successfully');
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.products && Array.isArray(parsed.products)) {
          onUpdateStore(() => parsed);
          feedback.vibrateSuccess(hapticsEnabled);
          feedback.playSuccess(soundEnabled);
          showStatus('Backup restored successfully!');
        } else {
          showStatus('Invalid backup file format');
        }
      } catch {
        showStatus('Failed to parse JSON file');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleExportProductsCsv = () => {
    const csv = exportProductsCsv(store);
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `inventory_products_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    feedback.vibrateSuccess(hapticsEnabled);
    showStatus('Products CSV downloaded');
  };

  const handleExportTransactionsCsv = () => {
    const csv = exportTransactionsCsv(store);
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `inventory_transactions_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    feedback.vibrateSuccess(hapticsEnabled);
    showStatus('Transactions CSV downloaded');
  };

  // Clear data trigger with in-app confirmation modal
  const handleTriggerClearAll = () => {
    setShowClearOptions(true);
  };

  // Reset sample data trigger
  const handleTriggerResetSample = () => {
    setConfirmConfig({
      isOpen: true,
      title: 'Reload Sample Inventory',
      message: 'Replace current inventory with rich trading company sample data (Basmati rice, stationery, electronics, and transactions history)?',
      confirmLabel: 'Reload Sample Data',
      isDestructive: false,
      onConfirm: () => {
        onResetSampleData();
        showStatus('Sample trading inventory loaded!');
      },
    });
  };

  return (
    <div className="space-y-4 pb-20 text-xs">
      {statusMsg && (
        <div className="fixed top-14 left-4 right-4 z-50 max-w-sm mx-auto p-3 rounded-2xl bg-slate-900 text-white shadow-xl flex items-center gap-2 border border-slate-700 animate-in slide-in-from-top-4 duration-150">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="font-medium text-xs">{statusMsg}</span>
        </div>
      )}

      {/* Business Details Card */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300">
          <Store className="w-4 h-4 text-red-600" />
          Store Profile & Receipts
        </div>

        <div>
          <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Store / Company Name
          </label>
          <input
            type="text"
            value={store.co}
            onChange={(e) => handleProfileChange('co', e.target.value)}
            className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-red-500 focus:outline-hidden"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Contact Phone
            </label>
            <input
              type="text"
              value={store.phone || ''}
              onChange={(e) => handleProfileChange('phone', e.target.value)}
              placeholder="+91 98765 43210"
              className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-red-500 focus:outline-hidden"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Tagline
            </label>
            <input
              type="text"
              value={store.tagline || ''}
              onChange={(e) => handleProfileChange('tagline', e.target.value)}
              placeholder="e.g. Wholesale & Retail"
              className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-red-500 focus:outline-hidden"
            />
          </div>
        </div>

        <div>
          <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Address (Printed on receipts)
          </label>
          <input
            type="text"
            value={store.address || ''}
            onChange={(e) => handleProfileChange('address', e.target.value)}
            placeholder="Shop 12, Main Bazaar, City"
            className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-red-500 focus:outline-hidden"
          />
        </div>

        <div>
          <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Currency
          </label>
          <select
            value={store.cur}
            onChange={(e) => handleProfileChange('cur', e.target.value)}
            className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-red-500 focus:outline-hidden"
          >
            {CURRENCIES.map((c) => (
              <option key={c.symbol} value={c.symbol}>
                {c.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Categories Manager */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300">
          <Tag className="w-4 h-4 text-amber-500" />
          Product Categories ({store.cats.length})
        </div>

        <div className="flex flex-wrap gap-1.5">
          {store.cats.map((cat) => (
            <div
              key={cat}
              className="inline-flex items-center gap-1.5 pl-3 pr-1.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs border border-slate-200 dark:border-slate-700"
            >
              <button
                type="button"
                onClick={() => handleRenameCat(cat)}
                className="font-medium hover:underline text-left"
                title="Tap to rename"
              >
                {cat}
              </button>
              <button
                type="button"
                onClick={() => handleDeleteCat(cat)}
                className="w-4 h-4 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-red-500"
                title="Remove"
              >
                ✕
              </button>
            </div>
          ))}
        </div>

        <form onSubmit={handleAddCat} className="flex gap-2">
          <input
            type="text"
            value={newCat}
            onChange={(e) => setNewCat(e.target.value)}
            placeholder="Add new category (e.g. Hardware)"
            className="flex-1 p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-red-500 focus:outline-hidden"
          />
          <button
            type="submit"
            className="px-3.5 py-2 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-semibold text-xs flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            Add
          </button>
        </form>
        <div className="text-[10px] text-slate-400">
          Tap any category name to rename it across all inventory items.
        </div>
      </div>

      {/* Units Manager */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300">
          <Layers className="w-4 h-4 text-indigo-500" />
          Units of Measure ({store.units.length})
        </div>

        <div className="flex flex-wrap gap-1.5">
          {store.units.map((unit) => (
            <div
              key={unit}
              className="inline-flex items-center gap-1.5 pl-3 pr-1.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs border border-slate-200 dark:border-slate-700"
            >
              <button
                type="button"
                onClick={() => handleRenameUnit(unit)}
                className="font-medium hover:underline text-left"
                title="Tap to rename"
              >
                {unit}
              </button>
              <button
                type="button"
                onClick={() => handleDeleteUnit(unit)}
                className="w-4 h-4 rounded-full hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-red-500"
                title="Remove"
              >
                ✕
              </button>
            </div>
          ))}
        </div>

        <form onSubmit={handleAddUnit} className="flex gap-2">
          <input
            type="text"
            value={newUnit}
            onChange={(e) => setNewUnit(e.target.value)}
            placeholder="Add new unit (e.g. Bundle, Tray)"
            className="flex-1 p-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-red-500 focus:outline-hidden"
          />
          <button
            type="submit"
            className="px-3.5 py-2 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-semibold text-xs flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            Add
          </button>
        </form>
      </div>

      {/* Dashboard Widgets Customizer */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300">
          <LayoutGrid className="w-4 h-4 text-emerald-500" />
          Dashboard Metric Widgets
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-800">
          {store.widgets.map((w, idx) => (
            <div key={w.id} className="py-2 flex items-center justify-between">
              <label className="flex items-center gap-2.5 cursor-pointer text-slate-800 dark:text-slate-200 font-medium">
                <input
                  type="checkbox"
                  checked={w.on}
                  onChange={() => handleToggleWidget(w.id)}
                  className="rounded text-red-600 focus:ring-red-500 w-4 h-4"
                />
                <span>{w.title}</span>
              </label>

              <div className="flex items-center gap-1">
                <button
                  type="button"
                  disabled={idx === 0}
                  onClick={() => handleMoveWidget(idx, 'up')}
                  className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 disabled:opacity-20"
                  title="Move up"
                >
                  <ArrowUp className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  disabled={idx === store.widgets.length - 1}
                  onClick={() => handleMoveWidget(idx, 'down')}
                  className="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 disabled:opacity-20"
                  title="Move down"
                >
                  <ArrowDown className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Preferences (Haptics, Sounds, Android Phone Frame) */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <div className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300">
          Mobile Experience & Feedback
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between py-1">
            <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200">
              <Vibrate className="w-4 h-4 text-slate-500" />
              <span>Android Haptic Feedback</span>
            </div>
            <input
              type="checkbox"
              checked={store.hapticsEnabled !== false}
              onChange={(e) => handleProfileChange('hapticsEnabled' as any, e.target.checked as any)}
              className="w-4 h-4 text-red-600 rounded focus:ring-red-500"
            />
          </div>

          <div className="flex items-center justify-between py-1">
            <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200">
              <Volume2 className="w-4 h-4 text-slate-500" />
              <span>Acoustic Click & Register Sounds</span>
            </div>
            <input
              type="checkbox"
              checked={store.soundEnabled !== false}
              onChange={(e) => handleProfileChange('soundEnabled' as any, e.target.checked as any)}
              className="w-4 h-4 text-red-600 rounded focus:ring-red-500"
            />
          </div>

          <div className="flex items-center justify-between py-1 border-t border-slate-100 dark:border-slate-800 pt-2">
            <div className="flex items-center gap-2 text-slate-700 dark:text-slate-200">
              <Smartphone className="w-4 h-4 text-red-500" />
              <div>
                <div>Android Phone Shell Preview</div>
                <div className="text-[10px] text-slate-400">Wraps layout in a Pixel 8 frame on desktop screens</div>
              </div>
            </div>
            <button
              type="button"
              onClick={onToggleAndroidFrame}
              className={`px-3 py-1 rounded-xl text-[11px] font-semibold transition ${
                isAndroidFrame
                  ? 'bg-red-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              {isAndroidFrame ? 'Enabled' : 'Disabled'}
            </button>
          </div>
        </div>
      </div>

      {/* Data Backup & Excel CSV Exports */}
      <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <div className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300">
          Data Backup & Reports Export
        </div>

        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={handleExportJson}
            className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 border border-slate-200 dark:border-slate-700 flex items-center gap-2 text-slate-800 dark:text-slate-200 transition"
          >
            <Download className="w-4 h-4 text-blue-500 shrink-0" />
            <div className="text-left truncate">
              <div className="font-semibold truncate">Backup JSON</div>
              <div className="text-[10px] text-slate-400">Full data file</div>
            </div>
          </button>

          <label className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 border border-slate-200 dark:border-slate-700 flex items-center gap-2 text-slate-800 dark:text-slate-200 cursor-pointer transition">
            <Upload className="w-4 h-4 text-emerald-500 shrink-0" />
            <div className="text-left truncate">
              <div className="font-semibold truncate">Restore JSON</div>
              <div className="text-[10px] text-slate-400">From backup</div>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleImportJson}
              className="hidden"
            />
          </label>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={handleExportProductsCsv}
            className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 border border-slate-200 dark:border-slate-700 flex items-center gap-2 text-slate-800 dark:text-slate-200 transition"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600 shrink-0" />
            <div className="text-left truncate">
              <div className="font-semibold truncate">Items CSV</div>
              <div className="text-[10px] text-slate-400">Excel format</div>
            </div>
          </button>

          <button
            type="button"
            onClick={handleExportTransactionsCsv}
            className="p-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 border border-slate-200 dark:border-slate-700 flex items-center gap-2 text-slate-800 dark:text-slate-200 transition"
          >
            <FileSpreadsheet className="w-4 h-4 text-blue-600 shrink-0" />
            <div className="text-left truncate">
              <div className="font-semibold truncate">Entries CSV</div>
              <div className="text-[10px] text-slate-400">Excel format</div>
            </div>
          </button>
        </div>

        {/* Clear Data & Reset Sample Buttons */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={handleTriggerResetSample}
            className="py-3 px-2 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold hover:bg-slate-200 transition flex items-center justify-center gap-1.5 active:scale-95"
          >
            <RotateCcw className="w-4 h-4 text-blue-500" />
            <span>Reload Sample</span>
          </button>

          <button
            type="button"
            onClick={handleTriggerClearAll}
            className="py-3 px-2 rounded-2xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/60 text-red-600 dark:text-red-400 font-semibold hover:bg-red-100 dark:hover:bg-red-950 transition flex items-center justify-center gap-1.5 active:scale-95 shadow-xs"
          >
            <Trash2 className="w-4 h-4 text-red-600 dark:text-red-400" />
            <span>Clear All Data</span>
          </button>
        </div>
      </div>

      {/* Clear Data Action Sheet Modal */}
      {showClearOptions && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4 animate-in fade-in duration-150">
          <div className="bg-white dark:bg-slate-900 w-full sm:max-w-sm rounded-t-3xl sm:rounded-3xl p-5 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in slide-in-from-bottom-4 duration-150 space-y-3">
            <div className="flex items-center gap-2.5 text-red-600 dark:text-red-400">
              <div className="w-9 h-9 rounded-xl bg-red-100 dark:bg-red-950 flex items-center justify-center">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">Clear Store Data</h3>
                <p className="text-[11px] text-slate-500">Choose what you want to remove:</p>
              </div>
            </div>

            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  setShowClearOptions(false);
                  onClearAllData('all');
                  showStatus('All items and transaction records cleared!');
                }}
                className="w-full p-3 rounded-2xl bg-red-600 hover:bg-red-700 text-white font-semibold text-xs text-left flex items-center justify-between shadow-xs transition active:scale-98"
              >
                <div>
                  <div className="font-bold">Clear Everything</div>
                  <div className="text-[11px] text-red-100">Deletes all {store.products.length} products and {store.txns.length} entries</div>
                </div>
                <Trash2 className="w-4 h-4 shrink-0 ml-2" />
              </button>

              <button
                type="button"
                onClick={() => {
                  setShowClearOptions(false);
                  onClearAllData('txns-only');
                  showStatus('Transaction entries cleared (catalog preserved)!');
                }}
                className="w-full p-3 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 font-semibold text-xs text-left flex items-center justify-between transition active:scale-98"
              >
                <div>
                  <div className="font-bold">Clear Transactions Only</div>
                  <div className="text-[11px] text-slate-500">Keep product catalog & reset sales/purchases</div>
                </div>
                <RotateCcw className="w-4 h-4 text-slate-500 shrink-0 ml-2" />
              </button>
            </div>

            <button
              type="button"
              onClick={() => setShowClearOptions(false)}
              className="w-full py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 font-semibold text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      <ConfirmModal
        isOpen={confirmConfig.isOpen}
        title={confirmConfig.title}
        message={confirmConfig.message}
        confirmLabel={confirmConfig.confirmLabel}
        isDestructive={confirmConfig.isDestructive}
        onConfirm={confirmConfig.onConfirm}
        onClose={() => setConfirmConfig((prev) => ({ ...prev, isOpen: false }))}
        soundEnabled={soundEnabled}
        hapticsEnabled={hapticsEnabled}
      />

      {/* Prompt Modal */}
      <PromptModal
        isOpen={promptConfig.isOpen}
        title={promptConfig.title}
        label={promptConfig.label}
        initialValue={promptConfig.initialValue}
        placeholder={promptConfig.placeholder}
        onConfirm={promptConfig.onConfirm}
        onClose={() => setPromptConfig((prev) => ({ ...prev, isOpen: false }))}
        soundEnabled={soundEnabled}
        hapticsEnabled={hapticsEnabled}
      />
    </div>
  );
};
