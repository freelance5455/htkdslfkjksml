import { ScoreRing } from "@/components/ScoreRing";
import { Badge } from "@/components/ui/badge";
import { Card, CardMeta, CardTitle } from "@/components/ui/card";
import { ProgressBar } from "@/components/ui/progress";
import { TIER_LABEL } from "@/lib/hardware/soc";
import { useCaliber } from "@/lib/store";

export function SettingsView() {
  const { dict, lang, hardware, settings } = useCaliber();
  if (!hardware || !settings) return null;

  const items = [
    { label: dict.general, value: settings.sensitivity.general },
    { label: dict.redDot, value: settings.sensitivity.redDot },
    { label: dict.scope2x, value: settings.sensitivity.scope2x },
    { label: dict.scope4x, value: settings.sensitivity.scope4x },
    { label: dict.awm, value: settings.sensitivity.awm },
    { label: dict.freeLook, value: settings.sensitivity.freeLook },
  ];

  const b = settings.scoreBreakdown;
  const mix = [
    { k: dict.cpu, v: b.cpu, m: 28 },
    { k: dict.ram, v: b.ram + b.ramType, m: 24 },
    { k: dict.gpu, v: b.gpu, m: 18 },
    { k: dict.refresh, v: b.refresh, m: 14 },
    { k: dict.touchRate, v: b.touch, m: 10 },
    { k: dict.thermal, v: b.thermal, m: 6 },
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-col items-center">
        <ScoreRing score={settings.performanceScore} />
        <p className="mt-1 font-display text-lg font-semibold">
          {hardware.manufacturer} {hardware.model}
        </p>
        <p className="text-xs text-muted">
          {hardware.socName} · {TIER_LABEL[hardware.cpuTier][lang]}
        </p>
      </div>

      <Card>
        <CardTitle className="text-xs uppercase tracking-[0.16em] text-subtle">{dict.breakdown}</CardTitle>
        <div className="mt-3 grid grid-cols-2 gap-2">
          {mix.map((row) => (
            <div key={row.k} className="rounded-md bg-bg px-2.5 py-2">
              <div className="flex items-baseline justify-between text-[11px] text-muted">
                <span>{row.k}</span>
                <span className="tabular-nums text-fg">
                  {row.v}/{row.m}
                </span>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card>
        <CardTitle className="mb-3">{dict.sensitivity}</CardTitle>
        <div className="space-y-3">
          {items.map((item, idx) => (
            <div key={item.label}>
              <div className="mb-1 flex items-baseline justify-between">
                <span className="text-sm text-muted">{item.label}</span>
                <span className="font-display text-lg font-semibold tabular-nums text-fg">
                  {item.value}
                  <span className="text-xs font-normal text-subtle"> {dict.of200}</span>
                </span>
              </div>
              <ProgressBar value={item.value} delayMs={idx * 70} />
            </div>
          ))}
        </div>
      </Card>

      <div className="grid gap-3 sm:grid-cols-2">
        <Card className="border-0 p-4 shadow-[0_0_0_1px_rgb(249_115_22_/_0.45)]">
          <CardMeta className="uppercase tracking-[0.16em]">{dict.dpi}</CardMeta>
          <div className="mt-1 font-display text-4xl font-semibold tabular-nums text-primary">
            {settings.dpi.recommended}
          </div>
          <p className="mt-2 text-xs leading-relaxed text-muted">{dict.dpiWarn}</p>
          <p className="mt-2 text-xs text-subtle">
            {dict.originalDpi}: <span className="tabular-nums text-fg">{settings.dpi.originalDpi}</span>
          </p>
        </Card>
        <Card className="border-0 p-4 shadow-[0_0_0_1px_rgb(234_179_8_/_0.4)]">
          <CardMeta className="uppercase tracking-[0.16em]">{dict.fireBtn}</CardMeta>
          <div className="mt-1 font-display text-4xl font-semibold tabular-nums text-accent">
            {settings.fireButtonPercent}%
          </div>
          <p className="mt-2 text-xs text-muted">
            {hardware.displayInches}" · {hardware.ramGb} GB RAM
          </p>
        </Card>
      </div>

      <Card>
        <CardTitle className="text-sm">{dict.howToApply}</CardTitle>
        <ol className="mt-2 list-decimal space-y-1 ps-4 text-xs leading-relaxed text-muted">
          <li>{dict.stepAdb}</li>
          <li>
            {dict.stepManual} ({settings.dpi.smallestWidth})
          </li>
        </ol>
        <pre className="mt-3 overflow-x-auto rounded-md bg-bg px-3 py-2 font-mono text-[11px] text-accent">
          {settings.dpi.adbSet}
        </pre>
        <pre className="mt-2 overflow-x-auto rounded-md bg-bg px-3 py-2 font-mono text-[11px] text-muted">
          {settings.dpi.adbReset}
        </pre>
      </Card>

      <Card>
        <div className="flex flex-wrap gap-2">
          <Badge variant="mute">
            {dict.graphics}: {settings.graphics.preset}
          </Badge>
          <Badge variant="accent">
            {dict.fps}: {settings.graphics.fpsOption}
          </Badge>
          <Badge variant={settings.graphics.highFps ? "ok" : "mute"}>
            {dict.highFps}: {settings.graphics.highFps ? dict.on : dict.off}
          </Badge>
        </div>
        <CardTitle className="mt-4 text-sm">{dict.tips}</CardTitle>
        <ul className="mt-2 space-y-1.5 text-xs leading-relaxed text-muted">
          {settings.graphics.extras.map((tip) => (
            <li key={tip}>{tip}</li>
          ))}
        </ul>
      </Card>
    </div>
  );
}
