import React, { useState } from 'react';
import { StoreSettings, Product, SaleTransaction } from '../types';
import { soundEffects } from '../utils/audio';
import { 
  Settings as SettingsIcon, 
  Store, 
  Volume2, 
  VolumeX, 
  Receipt, 
  Database, 
  Trash2, 
  Sparkles, 
  Save, 
  FileJson,
  UploadCloud,
  CheckCircle2,
  BellRing,
  Eye,
  Building2,
  Mail,
  Phone,
  FileText
} from 'lucide-react';

interface SettingsViewProps {
  settings: StoreSettings;
  inventory: Product[];
  sales: SaleTransaction[];
  onUpdateSettings: (newSettings: StoreSettings) => void;
  onLoadSampleData: () => void;
  onResetData: () => void;
  onRestoreBackup: (backup: { settings?: StoreSettings; inventory?: Product[]; sales?: SaleTransaction[] }) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  inventory,
  sales,
  onUpdateSettings,
  onLoadSampleData,
  onResetData,
  onRestoreBackup
}) => {
  const [formData, setFormData] = useState<StoreSettings>({ ...settings });
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings(formData);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleTestBeep = () => {
    soundEffects.playScanBeep();
  };

  // Export full JSON backup
  const handleExportJSON = () => {
    const backup = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      settings: formData,
      inventory,
      sales
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tally-store-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Import JSON backup
  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (confirm('Restore backup? This will replace your current store inventory, sales logs, and settings.')) {
          onRestoreBackup(parsed);
          alert('Backup restored successfully!');
        }
      } catch (err) {
        alert('Invalid JSON backup file: ' + err);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const currencyOptions = ['₱', '$', '€', '£', '¥', '₹', 'Rp', 'R$', '₩', 'CHF'];

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-300">
      {/* Settings Form Card */}
      <div className="glass-card rounded-3xl p-6 sm:p-8 space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-black text-slate-100">Store Information & Receipt Configuration</h2>
              <p className="text-xs text-slate-400">
                Information entered here will be printed on all customer sales receipts and invoices
              </p>
            </div>
          </div>
          {savedSuccess && (
            <span className="text-xs text-emerald-400 font-bold flex items-center gap-1 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-xl animate-in fade-in">
              <CheckCircle2 className="w-4 h-4" /> Changes Saved
            </span>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Main Grid: Form fields (left) and Live Receipt Preview (right) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Input Fields (7 columns) */}
            <div className="lg:col-span-7 space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-cyan-400" />
                  Store / Business Name <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={formData.storeName}
                  onChange={e => setFormData({ ...formData, storeName: e.target.value })}
                  placeholder="e.g. TALLY STORE"
                  required
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 focus:outline-none focus:border-cyan-500 font-semibold"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Tagline / Business Subtitle
                </label>
                <input
                  type="text"
                  value={formData.tagline}
                  onChange={e => setFormData({ ...formData, tagline: e.target.value })}
                  placeholder="e.g. Sales & Barcode Inventory Register"
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-cyan-400" />
                  Receipt Header Note / Invoice Title
                </label>
                <input
                  type="text"
                  value={formData.receiptHeaderNote || ''}
                  onChange={e => setFormData({ ...formData, receiptHeaderNote: e.target.value })}
                  placeholder="e.g. Official Sales Invoice • Customer Copy"
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-500"
                />
                <p className="text-[11px] text-slate-500">Appears just below your store name on printed receipts</p>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Physical Store Address / Branch
                </label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={e => setFormData({ ...formData, address: e.target.value })}
                  placeholder="e.g. 108 Commercial Avenue, Metro Plaza"
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-cyan-400" />
                    Contact Phone
                  </label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="e.g. +63 (02) 8123-4567"
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-cyan-400" />
                    Email / Website
                  </label>
                  <input
                    type="text"
                    value={formData.email || ''}
                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                    placeholder="e.g. support@mystore.com"
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Tax Identification Number (TIN / Business Reg No.)
                </label>
                <input
                  type="text"
                  value={formData.tin || ''}
                  onChange={e => setFormData({ ...formData, tin: e.target.value })}
                  placeholder="e.g. TIN: 123-456-789-000"
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Receipt Footer & Return Policy
                </label>
                <textarea
                  rows={2}
                  value={formData.receiptFooter}
                  onChange={e => setFormData({ ...formData, receiptFooter: e.target.value })}
                  placeholder="e.g. Thank you for your business! Please come again."
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-500"
                />
                <p className="text-[11px] text-slate-500">Printed at the bottom of every receipt</p>
              </div>

              {/* Currency & Tax Rate */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">Currency Symbol</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={formData.currency}
                      onChange={e => setFormData({ ...formData, currency: e.target.value })}
                      maxLength={5}
                      className="w-20 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-sm text-center font-bold text-cyan-400 focus:outline-none focus:border-cyan-500"
                    />
                    <div className="flex-1 flex flex-wrap gap-1 items-center">
                      {currencyOptions.slice(0, 5).map(curr => (
                        <button
                          type="button"
                          key={curr}
                          onClick={() => setFormData({ ...formData, currency: curr })}
                          className={`px-2 py-1 text-xs rounded-lg border cursor-pointer ${
                            formData.currency === curr
                              ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 font-bold'
                              : 'bg-slate-900 text-slate-400 border-slate-800'
                          }`}
                        >
                          {curr}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">Sales Tax / VAT Rate (%)</label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={formData.taxRate}
                    onChange={e => setFormData({ ...formData, taxRate: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-sm text-slate-100 focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              {/* Sound Audio Toggle */}
              <div className="p-3 bg-slate-900/60 rounded-2xl border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  {formData.enableSound ? (
                    <Volume2 className="w-5 h-5 text-cyan-400" />
                  ) : (
                    <VolumeX className="w-5 h-5 text-slate-500" />
                  )}
                  <div>
                    <span className="text-xs font-bold text-slate-200 block">Scanner Audio Feedback</span>
                    <span className="text-[11px] text-slate-400">Play tone when barcode is scanned</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleTestBeep}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium flex items-center gap-1 cursor-pointer"
                  >
                    <BellRing className="w-3 h-3 text-cyan-400" />
                    Test Beep
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, enableSound: !formData.enableSound })}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                      formData.enableSound ? 'bg-cyan-500' : 'bg-slate-800'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        formData.enableSound ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>

            {/* Live Receipt Preview Card (5 columns) */}
            <div className="lg:col-span-5 space-y-2 sticky top-20">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <Eye className="w-3.5 h-3.5 text-cyan-400" />
                  Live Receipt Preview
                </span>
                <span className="text-[10px] text-slate-500 uppercase tracking-widest font-mono">
                  Thermal Style
                </span>
              </div>

              {/* Receipt mock box */}
              <div className="bg-white text-slate-900 font-mono p-4 rounded-2xl border border-slate-300 shadow-xl text-xs space-y-2.5 max-w-sm mx-auto">
                <div className="text-center space-y-1 pb-2 border-b border-dashed border-slate-400">
                  <h3 className="text-sm font-black uppercase tracking-wider text-slate-950 truncate">
                    {formData.storeName || 'YOUR STORE NAME'}
                  </h3>
                  {formData.tagline && (
                    <p className="text-[10px] text-slate-700 font-medium">{formData.tagline}</p>
                  )}
                  {formData.receiptHeaderNote && (
                    <p className="text-[9px] text-slate-500 uppercase tracking-widest border-y border-slate-200 py-0.5 my-0.5">
                      {formData.receiptHeaderNote}
                    </p>
                  )}
                  {formData.address && (
                    <p className="text-[9px] text-slate-600">{formData.address}</p>
                  )}
                  <div className="text-[9px] text-slate-600 flex flex-wrap justify-center gap-x-2">
                    {formData.phone && <span>Tel: {formData.phone}</span>}
                    {formData.email && <span>Email: {formData.email}</span>}
                  </div>
                  {formData.tin && (
                    <p className="text-[9px] text-slate-600 font-semibold">{formData.tin}</p>
                  )}
                  <div className="pt-1.5 text-[9px] text-slate-500 flex justify-between border-t border-slate-200">
                    <span>{new Date().toLocaleDateString()} {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    <span className="font-bold text-slate-700">TAL-20261019-1001</span>
                  </div>
                </div>

                {/* Sample items */}
                <div className="space-y-1.5 py-1 border-b border-dashed border-slate-400 text-[10px]">
                  <div className="flex justify-between font-bold text-slate-700">
                    <span>ITEM</span>
                    <span>TOTAL</span>
                  </div>
                  <div className="flex justify-between">
                    <div>
                      <span className="font-bold">Bottled Mineral Water</span>
                      <div className="text-[9px] text-slate-500">2 x {formData.currency}20.00</div>
                    </div>
                    <span className="font-bold">{formData.currency}40.00</span>
                  </div>
                  <div className="flex justify-between">
                    <div>
                      <span className="font-bold">Espresso Roast Coffee</span>
                      <div className="text-[9px] text-slate-500">1 x {formData.currency}85.00</div>
                    </div>
                    <span className="font-bold">{formData.currency}85.00</span>
                  </div>
                </div>

                {/* Sample totals */}
                <div className="space-y-0.5 text-[10px] pb-1 border-b border-dashed border-slate-400">
                  <div className="flex justify-between text-slate-600">
                    <span>Subtotal:</span>
                    <span>{formData.currency}125.00</span>
                  </div>
                  {formData.taxRate > 0 && (
                    <div className="flex justify-between text-slate-600">
                      <span>Tax ({formData.taxRate}%):</span>
                      <span>{formData.currency}{((125 * formData.taxRate) / 100).toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-xs font-black text-slate-950 pt-1">
                    <span>TOTAL:</span>
                    <span>{formData.currency}{(125 + (125 * formData.taxRate) / 100).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-[9px] text-slate-600 pt-0.5">
                    <span>Payment: CASH</span>
                    <span>Change: {formData.currency}0.00</span>
                  </div>
                </div>

                {/* Sample barcode */}
                <div className="text-center pt-1 space-y-1">
                  <div className="h-6 w-36 mx-auto bg-slate-900 rounded-sm opacity-80 flex items-center justify-center text-[8px] text-white font-mono tracking-widest">
                    ||| | |||| | ||| ||
                  </div>
                  <p className="text-[9px] text-slate-600 leading-tight">
                    {formData.receiptFooter || 'Thank you for your business!'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold rounded-2xl shadow-lg shadow-cyan-500/20 text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer transition"
          >
            <Save className="w-4 h-4" />
            Save Store & Receipt Information
          </button>
        </form>
      </div>

      {/* Utilities & Data Management */}
      <div className="glass-card rounded-3xl p-6 sm:p-8 space-y-4">
        <h3 className="font-bold text-sm text-slate-200 border-b border-slate-800 pb-3 flex items-center gap-2">
          <Database className="w-4 h-4 text-cyan-400" />
          Data Backup & Utilities
        </h3>

        <div className="space-y-3">
          {/* Backup / Export JSON */}
          <div className="p-4 bg-slate-900/80 rounded-2xl border border-slate-800 flex items-center justify-between gap-3">
            <div>
              <span className="text-sm font-bold text-slate-200 block">Backup Store Data (JSON)</span>
              <span className="text-xs text-slate-400">Save full inventory, store receipt info, and sales history</span>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleExportJSON}
                className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
              >
                <FileJson className="w-4 h-4 text-cyan-400" />
                Export JSON
              </button>
              <label className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer">
                <UploadCloud className="w-4 h-4 text-emerald-400" />
                Restore Backup
                <input type="file" accept=".json" onChange={handleImportJSON} className="hidden" />
              </label>
            </div>
          </div>

          {/* Sample Data */}
          <div className="p-4 bg-slate-900/80 rounded-2xl border border-slate-800 flex items-center justify-between gap-3">
            <div>
              <span className="text-sm font-bold text-slate-200 block">Load Demo Sample Products</span>
              <span className="text-xs text-slate-400">Populate realistic test grocery & retail items</span>
            </div>
            <button
              type="button"
              onClick={onLoadSampleData}
              className="px-4 py-2 bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/30 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              Load Data
            </button>
          </div>

          {/* Reset / Wipe Store */}
          <div className="p-4 bg-slate-900/80 rounded-2xl border border-rose-900/20 flex items-center justify-between gap-3">
            <div>
              <span className="text-sm font-bold text-rose-300 block">Reset Store Database</span>
              <span className="text-xs text-slate-400">Wipe all inventory products and sales transaction history</span>
            </div>
            <button
              type="button"
              onClick={onResetData}
              className="px-4 py-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              Reset All
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
