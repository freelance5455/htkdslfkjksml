import React, { useRef, useState } from 'react';
import { useApp } from '../context/AppContext';
import { formatNumber } from '../utils/formatters';
import { 
  Database, 
  Download, 
  Upload, 
  RotateCcw, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldCheck, 
  HardDrive, 
  FileText 
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const { 
    sites, 
    labours, 
    attendance, 
    advances, 
    engineerPayments, 
    messExpenses, 
    messCollections, 
    landlordPayments,
    exportDataToJson, 
    importDataFromJson, 
    resetToDemoData 
  } = useApp();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importStatus, setImportStatus] = useState<{ success?: boolean; message?: string } | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const success = importDataFromJson(content);
      if (success) {
        setImportStatus({ success: true, message: 'ডেটা ব্যাকআপ ফাইলটি সফলভাবে রিস্টোর হয়েছে!' });
      } else {
        setImportStatus({ success: false, message: 'ফাইলটি সঠিক ফরম্যাটে নেই। অনুগ্রহ করে সঠিক JSON ব্যাকআপ ফাইল দিন।' });
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      
      {/* হেডার */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-amber-50 text-amber-700">
            <Database className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">
              ডেটা ব্যাকআপ, রিস্টোর ও সিস্টেম সেটিংস
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
              আপনার সমস্ত সাইট, লেবার, মেস খরচ ও বাড়িওয়ালার ভাড়ার ডেটা নিরাপদে নিজের কম্পিউটারে বা ফোনে সেভ রাখুন
            </p>
          </div>
        </div>
      </div>

      {/* স্ট্যাটাস নোটিফিকেশন */}
      {importStatus && (
        <div className={`p-4 rounded-xl border flex items-center justify-between ${
          importStatus.success ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-rose-50 border-rose-200 text-rose-800'
        }`}>
          <div className="flex items-center gap-2 text-sm font-medium">
            {importStatus.success ? <CheckCircle2 className="w-5 h-5 text-emerald-600" /> : <AlertTriangle className="w-5 h-5 text-rose-600" />}
            <span>{importStatus.message}</span>
          </div>
          <button 
            onClick={() => setImportStatus(null)} 
            className="text-xs underline font-semibold"
          >
            বন্ধ করুন
          </button>
        </div>
      )}

      {/* ডেটা পরিসংখ্যান */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <h3 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
          <HardDrive className="w-4 h-4 text-slate-500" />
          <span>বর্তমানে সংরক্ষিত ডেটা পরিসংখ্যান</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-500">মোট সাইট:</span>
            <div className="text-base font-bold font-mono text-slate-900">{formatNumber(sites.length)} টি</div>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-500">মোট লেবার:</span>
            <div className="text-base font-bold font-mono text-slate-900">{formatNumber(labours.length)} জন</div>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-500">হাজিরা এন্ট্রি:</span>
            <div className="text-base font-bold font-mono text-slate-900">{formatNumber(attendance.length)} টি</div>
          </div>
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
            <span className="text-slate-500">মেস খরচ ভাউচার:</span>
            <div className="text-base font-bold font-mono text-slate-900">{formatNumber(messExpenses.length)} টি</div>
          </div>
        </div>
      </div>

      {/* ব্যাকআপ ও রিস্টোর একশন কার্ডস */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* এক্সপোর্ট / ডাউনলোড */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center mb-3">
              <Download className="w-5 h-5" />
            </div>
            <h4 className="text-base font-bold text-slate-900">সম্পূর্ণ ডেটা ডাউনলোড (Export JSON)</h4>
            <p className="text-xs text-slate-500 mt-1">
              এক ক্লিকে আপনার সমস্ত সাইট, হাজিরা, মেস বিল ও বাড়িওয়ালার ভাড়ার হিসাবের একটি সম্পূর্ণ ব্যাকআপ ফাইল (.json) ডাউনলোড করুন।
            </p>
          </div>

          <div className="mt-5">
            <button
              onClick={exportDataToJson}
              className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-semibold transition-colors flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" />
              <span>ব্যাকআপ ফাইল ডাউনলোড করুন</span>
            </button>
          </div>
        </div>

        {/* ইমপোর্ট / রিস্টোর */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center mb-3">
              <Upload className="w-5 h-5" />
            </div>
            <h4 className="text-base font-bold text-slate-900">ব্যাকআপ ফাইল রিস্টোর (Import JSON)</h4>
            <p className="text-xs text-slate-500 mt-1">
              পূর্বে ডাউনলোড করা কোনো JSON ব্যাকআপ ফাইল থাকলে সেটি আপলোড করে সমস্ত তথ্য ফেরত পান।
            </p>
          </div>

          <div className="mt-5">
            <input
              type="file"
              ref={fileInputRef}
              accept=".json"
              onChange={handleFileChange}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full py-2.5 px-4 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-sm font-semibold transition-colors flex items-center justify-center gap-2"
            >
              <Upload className="w-4 h-4" />
              <span>ব্যাকআপ ফাইল আপলোড করুন</span>
            </button>
          </div>
        </div>

      </div>

      {/* ডেমো ডেটা রিসেট সেকশন */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-amber-600" />
              <span>বাস্তবসম্মত ডেমো ডেটা রিসেট (Demo Data Reset)</span>
            </h4>
            <p className="text-xs text-slate-500 mt-1">
              অ্যাপ্লিকেশনের সমস্ত ফিচার সহজে বোঝার জন্য বাস্তব নির্মাণ সাইট ও মেসের নমুনা ডেটা পুনরায় লোড করতে পারেন।
            </p>
          </div>

          <button
            onClick={() => {
              if (window.confirm('আপনি কি নিশ্চিত যে ডেমো ডেটা দিয়ে বর্তমান ডেটা রিসেট করতে চান?')) {
                resetToDemoData();
                setImportStatus({ success: true, message: 'ডেমো ডেটা সফলভাবে রিস্টোর হয়েছে!' });
              }
            }}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap"
          >
            ডেমো ডেটা লোড করুন
          </button>
        </div>
      </div>

      {/* ব্যবহার বিধি ও গাইড */}
      <div className="bg-amber-50/60 p-5 rounded-xl border border-amber-200 text-xs text-amber-900 space-y-2">
        <h4 className="font-bold text-amber-950 text-sm flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-amber-700" />
          <span>ব্যবহারকারীর সুবিধার জন্য গুরুত্বপূর্ণ তথ্য ও টিপস:</span>
        </h4>
        <ul className="list-disc list-inside space-y-1 text-amber-800 pl-1 leading-relaxed">
          <li><strong>অফলাইন সাপোর্ট:</strong> অ্যাপ্লিকেশনটি লোকাল স্টোরেজে স্বয়ংক্রিয়ভাবে সেভ হয়, ইন্টারনেট সংযোগ না থাকলেও আপনার ফোনে বা ব্রাউজারে সুন্দরভাবে কাজ করবে।</li>
          <li><strong>ফ্ল্যাট কমিশন:</strong> সাইটের মোট কমিশন কোনো শতকরা বা % নয়, সরাসরি চুক্তিবদ্ধ টাকার অঙ্ক (যেমন: ₹৬৫,০০০)।</li>
          <li><strong>প্রোরোটা মেস ভাড়া:</strong> লেবারদের মেসে ওঠার এবং মেস ছাড়ার তারিখ অনুযায়ী বাড়িওয়ালার ভাড়া দিন গুনে (Pro-rata) নিখুঁতভাবে হিসাব হয়।</li>
          <li><strong>কাজের ধরন:</strong> কিছু লেবার মেসে থেকে বাইরে কাজ করতে পারে—তাদের শুধু মেস খরচ নেওয়া হবে, সাইটের মজুরিতে যুক্ত হবে না।</li>
        </ul>
      </div>

    </div>
  );
};
