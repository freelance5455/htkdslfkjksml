import React from 'react';
import {
  Calculator,
  DatabaseBackup,
  FileBarChart2,
  FlaskConical,
  FolderCog,
  GitMerge,
  HardDrive,
  Layers,
  LayoutGrid,
  ListChecks,
  Palette,
  Sliders,
  Type,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { BackupRestoreView } from './BackupRestoreView';
import { DashboardCardBuilderPanel, ReportsBuilderPanel } from './settings/CardAndReportBuilder';
import { DataManagementPanel } from './settings/DataManagementPanel';
import { FieldBuilderPanel, MasterListsPanel } from './settings/FieldAndListBuilder';
import { FieldMappingPanel, FormulaBuilderPanel } from './settings/FormulaAndMappingBuilder';
import { GeneralSettingsPanel, ThemeSettingsPanel } from './settings/GeneralAndThemeSettings';
import { ModuleManagementPanel, SubmoduleManagementPanel } from './settings/ModuleAndSubmoduleBuilder';
import { PreviewAndTestPanel } from './settings/PreviewAndTestPanel';

const SETTINGS_SECTIONS = [
  { id: 'general', label: '01. General Settings', icon: Sliders },
  { id: 'modules', label: '02. Module Management', icon: FolderCog },
  { id: 'submodules', label: '03. Submodule Management', icon: Layers },
  { id: 'fields', label: '04. Field Builder', icon: Type },
  { id: 'formulas', label: '05. Formula & Calculation Builder', icon: Calculator },
  { id: 'mappings', label: '06. Field / Cell Mapping', icon: GitMerge },
  { id: 'cards', label: '07. Dashboard Card Builder', icon: LayoutGrid },
  { id: 'lists', label: '08. Dropdown & Master Lists', icon: ListChecks },
  { id: 'reports', label: '09. Reports Builder', icon: FileBarChart2 },
  { id: 'theme', label: '10. Theme & Colours', icon: Palette },
  { id: 'backup', label: '11. Backup & Restore', icon: DatabaseBackup },
  { id: 'data', label: '12. Data Management', icon: HardDrive },
  { id: 'preview', label: '13. Preview & Test', icon: FlaskConical },
];

export const SettingsView: React.FC = () => {
  const { settingsSection, setSettingsSection } = useApp();

  return (
    <div className="flex flex-col lg:flex-row gap-6 items-start">
      {/* Settings 13-Section Menu */}
      <nav
        aria-label="Settings sections"
        className="w-full lg:w-72 shrink-0 rounded-xl border border-slate-200 bg-white p-2 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-1"
      >
        {SETTINGS_SECTIONS.map((sec) => {
          const Icon = sec.icon;
          const active = settingsSection === sec.id;
          return (
            <button
              key={sec.id}
              type="button"
              onClick={() => setSettingsSection(sec.id)}
              className={`flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs font-semibold text-left transition-colors cursor-pointer ${
                active
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span className="truncate">{sec.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Active Settings Section Content */}
      <div className="flex-1 min-w-0 w-full">
        {settingsSection === 'general' && <GeneralSettingsPanel />}
        {settingsSection === 'modules' && <ModuleManagementPanel />}
        {settingsSection === 'submodules' && <SubmoduleManagementPanel />}
        {settingsSection === 'fields' && <FieldBuilderPanel />}
        {settingsSection === 'formulas' && <FormulaBuilderPanel />}
        {settingsSection === 'mappings' && <FieldMappingPanel />}
        {settingsSection === 'cards' && <DashboardCardBuilderPanel />}
        {settingsSection === 'lists' && <MasterListsPanel />}
        {settingsSection === 'reports' && <ReportsBuilderPanel />}
        {settingsSection === 'theme' && <ThemeSettingsPanel />}
        {settingsSection === 'backup' && <BackupRestoreView />}
        {settingsSection === 'data' && <DataManagementPanel />}
        {settingsSection === 'preview' && (
          <PreviewAndTestPanel onJumpToSection={setSettingsSection} />
        )}
      </div>
    </div>
  );
};
