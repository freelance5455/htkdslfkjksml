import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Category, CategoryType, AppBackupData } from '../types';
import { t, formatCurrency } from '../utils/translations';
import {
  Tag,
  Plus,
  Edit2,
  Trash2,
  Users,
  Shield,
  Download,
  Upload,
  RefreshCw,
  Lock,
  Unlock,
  CheckCircle2,
  AlertTriangle,
  FileJson,
  KeyRound,
  Sparkles,
  Smartphone,
  Monitor
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const {
    language,
    categories,
    addCategory,
    updateCategory,
    deleteCategory,
    users,
    currentUser,
    setCurrentUserId,
    createUser,
    deleteUser,
    changeUserPin,
    backupData,
    restoreData,
    loadDemoData,
    resetAllData
  } = useApp();

  const [activeTab, setActiveTab] = useState<'categories' | 'security' | 'users' | 'backup'>('categories');

  // Categories state
  const [catType, setCatType] = useState<CategoryType>('income');
  const [isCatModalOpen, setIsCatModalOpen] = useState(false);
  const [editingCat, setEditingCat] = useState<Category | null>(null);
  const [catNameGu, setCatNameGu] = useState('');
  const [catNameEn, setCatNameEn] = useState('');

  // Security / PIN state
  const [pinEnabled, setPinEnabled] = useState(currentUser.pinEnabled || false);
  const [newPin, setNewPin] = useState(currentUser.pin || '');
  const [confirmPinVal, setConfirmPinVal] = useState(currentUser.pin || '');
  const [secQuestion, setSecQuestion] = useState(currentUser.securityQuestion || '');
  const [secAnswer, setSecAnswer] = useState(currentUser.securityAnswer || '');
  const [pinSavedNotice, setPinSavedNotice] = useState(false);

  // New User state
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);
  const [newUserName, setNewUserName] = useState('');
  const [newUserPin, setNewUserPin] = useState('');

  // Backup file upload state
  const [restoreStatus, setRestoreStatus] = useState<{ success?: boolean; message?: string } | null>(null);

  // 1. Categories Handlers
  const handleOpenAddCat = () => {
    setEditingCat(null);
    setCatNameGu('');
    setCatNameEn('');
    setIsCatModalOpen(true);
  };

  const handleOpenEditCat = (c: Category) => {
    setEditingCat(c);
    setCatNameGu(c.nameGu);
    setCatNameEn(c.nameEn);
    setCatType(c.type);
    setIsCatModalOpen(true);
  };

  const handleSaveCat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!catNameGu.trim() && !catNameEn.trim()) return;

    const gu = catNameGu.trim() || catNameEn.trim();
    const en = catNameEn.trim() || catNameGu.trim();

    if (editingCat) {
      updateCategory(editingCat.id, {
        nameGu: gu,
        nameEn: en,
        type: catType
      });
    } else {
      addCategory({
        nameGu: gu,
        nameEn: en,
        type: catType,
        icon: 'Tag',
        color: catType === 'income' ? 'emerald' : 'orange'
      });
    }
    setIsCatModalOpen(false);
  };

  const handleDeleteCat = (id: string) => {
    const confirmMsg =
      language === 'gu'
        ? 'શું તમે આ કેટેગરી કાઢી નાખવા માંગો છો?'
        : 'Are you sure you want to delete this category?';
    if (window.confirm(confirmMsg)) {
      deleteCategory(id);
    }
  };

  // 2. PIN Save
  const handleSaveSecurity = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinEnabled) {
      if (newPin.length !== 4) {
        alert(language === 'gu' ? 'પિન બરાબર ૪ અંકનો હોવો જોઈએ.' : 'PIN must be exactly 4 digits.');
        return;
      }
      if (newPin !== confirmPinVal) {
        alert(language === 'gu' ? 'પિન મેળ ખાતો નથી.' : 'PINs do not match.');
        return;
      }
    }

    changeUserPin(newPin, pinEnabled);
    setPinSavedNotice(true);
    setTimeout(() => setPinSavedNotice(false), 3000);
  };

  // 3. User Create
  const handleCreateUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName.trim()) return;
    createUser(newUserName.trim(), newUserPin.trim() || undefined);
    setNewUserName('');
    setNewUserPin('');
    setIsAddUserOpen(false);
  };

  // 4. Backup & Restore
  const handleDownloadBackup = () => {
    const data = backupData();
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const dateStr = new Date().toISOString().split('T')[0];
    a.download = `khatavahi_offline_backup_${dateStr}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        const res = restoreData(parsed as AppBackupData);
        if (res.success) {
          setRestoreStatus({
            success: true,
            message: t('restoreSuccess', language)
          });
        } else {
          setRestoreStatus({
            success: false,
            message: res.error || 'Failed to restore'
          });
        }
      } catch (err: any) {
        setRestoreStatus({
          success: false,
          message: err.message || 'Invalid JSON file'
        });
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleResetData = () => {
    const confirmMsg =
      language === 'gu'
        ? 'ચેતવણી: આ તમામ ડેટા ભૂંસી નાખશે! શું તમે આગળ વધવા માંગો છો?'
        : 'Warning: This will clear all data from this device! Are you sure?';
    if (window.confirm(confirmMsg)) {
      resetAllData();
      alert(language === 'gu' ? 'ડેટા સફળતાપૂર્વક રીસેટ થયો.' : 'Data reset complete.');
    }
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Settings Navigation Tabs */}
      <div className="bg-white p-1.5 rounded-2xl border border-stone-200 shadow-sm flex items-center gap-1 overflow-x-auto print-hide">
        <button
          type="button"
          onClick={() => setActiveTab('categories')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
            activeTab === 'categories'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <Tag className="w-4 h-4" />
          <span>{t('categoriesTitle', language)}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('security')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
            activeTab === 'security'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <Shield className="w-4 h-4" />
          <span>{t('securitySettings', language)}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('users')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
            activeTab === 'users'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>{t('multiUserTitle', language)}</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('backup')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
            activeTab === 'backup'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <FileJson className="w-4 h-4" />
          <span>{t('dataBackupTitle', language)}</span>
        </button>
      </div>

      {/* 1. CATEGORIES MANAGEMENT */}
      {activeTab === 'categories' && (
        <div className="rounded-2xl bg-white border border-stone-200 shadow-sm p-5 space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-stone-100">
            <div>
              <h3 className="text-base font-bold text-stone-900">{t('categoriesTitle', language)}</h3>
              <p className="text-xs text-stone-500">
                {language === 'gu'
                  ? 'આવક અને ખર્ચની કેટેગરીઝ ઉમેરો, બદલો કે કાઢી નાખો.'
                  : 'Add, edit, or delete custom income and expense categories.'}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex bg-stone-100 p-0.5 rounded-xl text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setCatType('income')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    catType === 'income' ? 'bg-emerald-600 text-white shadow-xs' : 'text-stone-600'
                  }`}
                >
                  {t('income', language)} ({categories.filter((c) => c.type === 'income').length})
                </button>
                <button
                  type="button"
                  onClick={() => setCatType('expense')}
                  className={`px-3 py-1.5 rounded-lg transition-all ${
                    catType === 'expense' ? 'bg-rose-700 text-white shadow-xs' : 'text-stone-600'
                  }`}
                >
                  {t('expense', language)} ({categories.filter((c) => c.type === 'expense').length})
                </button>
              </div>

              <button
                type="button"
                onClick={handleOpenAddCat}
                className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>{t('addCategory', language)}</span>
              </button>
            </div>
          </div>

          {/* Categories Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {categories
              .filter((c) => c.type === catType)
              .map((c) => (
                <div
                  key={c.id}
                  className="p-3 rounded-xl border border-stone-200 bg-stone-50/50 flex items-center justify-between hover:bg-stone-50 transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                        c.type === 'income' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      <Tag className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-stone-900">{c.nameGu}</h4>
                      <p className="text-[11px] text-stone-500">{c.nameEn}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleOpenEditCat(c)}
                      className="p-1 rounded text-stone-400 hover:text-amber-700"
                      title={t('edit', language)}
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteCat(c.id)}
                      className="p-1 rounded text-stone-400 hover:text-rose-600"
                      title={t('delete', language)}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* 2. SECURITY & PIN */}
      {activeTab === 'security' && (
        <div className="rounded-2xl bg-white border border-stone-200 shadow-sm p-5 space-y-4 max-w-xl">
          <div>
            <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
              <Shield className="w-5 h-5 text-amber-700" />
              <span>{t('securitySettings', language)}</span>
            </h3>
            <p className="text-xs text-stone-500 mt-0.5">
              {language === 'gu'
                ? 'તમારી ખાતાવહીને ૪-અંકના સુરક્ષિત પિનથી લોક કરો.'
                : 'Protect your Khatavahi with a 4-digit PIN lock.'}
            </p>
          </div>

          <form onSubmit={handleSaveSecurity} className="space-y-4 pt-2">
            <div className="flex items-center justify-between p-3 rounded-xl bg-amber-50/70 border border-amber-200">
              <div className="flex items-center gap-2">
                {pinEnabled ? (
                  <Lock className="w-5 h-5 text-amber-700" />
                ) : (
                  <Unlock className="w-5 h-5 text-stone-400" />
                )}
                <div>
                  <label className="text-xs font-bold text-stone-900 block cursor-pointer">
                    {t('enablePin', language)}
                  </label>
                  <span className="text-[11px] text-stone-500">
                    {pinEnabled
                      ? 'પિન સક્રિય છે (Khatavahi Secured)'
                      : 'પિન નિષ્ક્રિય છે (No PIN lock)'}
                  </span>
                </div>
              </div>

              <input
                type="checkbox"
                checked={pinEnabled}
                onChange={(e) => setPinEnabled(e.target.checked)}
                className="w-5 h-5 rounded text-amber-600 focus:ring-amber-500 cursor-pointer"
              />
            </div>

            {pinEnabled && (
              <div className="space-y-3 p-4 rounded-xl border border-stone-200 bg-stone-50">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      {t('setPin', language)} (૪ અંક)
                    </label>
                    <input
                      type="password"
                      maxLength={4}
                      value={newPin}
                      onChange={(e) => setNewPin(e.target.value)}
                      placeholder="••••"
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 text-center font-bold tracking-widest text-lg bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      {t('confirmPin', language)}
                    </label>
                    <input
                      type="password"
                      maxLength={4}
                      value={confirmPinVal}
                      onChange={(e) => setConfirmPinVal(e.target.value)}
                      placeholder="••••"
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 text-center font-bold tracking-widest text-lg bg-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    {t('securityQuestion', language)}
                  </label>
                  <input
                    type="text"
                    value={secQuestion}
                    onChange={(e) => setSecQuestion(e.target.value)}
                    placeholder="દા.ત. તમારું પ્રિય પુસ્તક અથવા જન્મસ્થળ?"
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    {t('securityAnswer', language)}
                  </label>
                  <input
                    type="text"
                    value={secAnswer}
                    onChange={(e) => setSecAnswer(e.target.value)}
                    placeholder="તમારો સુરક્ષિત જવાબ"
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs bg-white"
                  />
                </div>
              </div>
            )}

            {pinSavedNotice && (
              <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-700">
                <CheckCircle2 className="w-4 h-4" />
                <span>સુરક્ષા સેટિંગ્સ સાચવવામાં આવી! / Settings saved.</span>
              </div>
            )}

            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-md"
            >
              {t('save', language)}
            </button>
          </form>
        </div>
      )}

      {/* 3. MULTI-USER PROFILES */}
      {activeTab === 'users' && (
        <div className="rounded-2xl bg-white border border-stone-200 shadow-sm p-5 space-y-4 max-w-xl">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100">
            <div>
              <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                <Users className="w-5 h-5 text-amber-700" />
                <span>{t('multiUserTitle', language)}</span>
              </h3>
              <p className="text-xs text-stone-500 mt-0.5">
                {language === 'gu'
                  ? 'વ્યક્તિગત, ધંધા કે ખેતી માટે અલગ અલગ ખાતાવહી ચોપડા રાખો.'
                  : 'Manage multiple profiles (Personal, Business, Farming).'}
              </p>
            </div>

            <button
              type="button"
              onClick={() => setIsAddUserOpen(true)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>{t('addUser', language)}</span>
            </button>
          </div>

          <div className="space-y-2">
            {users.map((u) => (
              <div
                key={u.id}
                className={`p-3 rounded-xl border flex items-center justify-between transition-colors ${
                  u.id === currentUser.id
                    ? 'border-amber-500 bg-amber-50/50'
                    : 'border-stone-200 bg-white hover:bg-stone-50'
                }`}
              >
                <div>
                  <h4 className="text-xs font-bold text-stone-900 flex items-center gap-1.5">
                    <span>{u.name}</span>
                    {u.id === currentUser.id && (
                      <span className="px-2 py-0.2 rounded-full text-[10px] font-bold bg-amber-600 text-white">
                        સક્રિય ચોપડો
                      </span>
                    )}
                  </h4>
                  <p className="text-[10px] text-stone-400 mt-0.5">
                    પિન રક્ષણ: {u.pinEnabled ? 'હા' : 'ના'}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {u.id !== currentUser.id ? (
                    <button
                      type="button"
                      onClick={() => setCurrentUserId(u.id)}
                      className="px-3 py-1 rounded-lg border border-stone-300 hover:bg-stone-100 text-xs font-semibold text-stone-700"
                    >
                      {t('switchUser', language)}
                    </button>
                  ) : null}

                  {users.length > 1 && (
                    <button
                      type="button"
                      onClick={() => deleteUser(u.id)}
                      className="p-1 rounded text-stone-400 hover:text-rose-600"
                      title={t('delete', language)}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Add User Modal */}
          {isAddUserOpen && (
            <form onSubmit={handleCreateUserSubmit} className="p-4 rounded-xl border border-stone-200 bg-stone-50 space-y-3 mt-4">
              <h4 className="text-xs font-bold text-stone-800">{t('addUser', language)}</h4>
              <div>
                <label className="block text-xs font-medium text-stone-600 mb-1">
                  {t('profileName', language)} *
                </label>
                <input
                  type="text"
                  required
                  value={newUserName}
                  onChange={(e) => setNewUserName(e.target.value)}
                  placeholder="દા.ત. વ્યાપાર ખાતાવહી / Business Book"
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-stone-600 mb-1">
                  {language === 'gu' ? '૪-અંકનો પિન (વૈકલ્પિક)' : '4-Digit PIN (Optional)'}
                </label>
                <input
                  type="password"
                  maxLength={4}
                  value={newUserPin}
                  onChange={(e) => setNewUserPin(e.target.value)}
                  placeholder="••••"
                  className="w-32 px-3 py-2 rounded-lg border border-stone-300 text-xs bg-white text-center font-bold tracking-widest"
                />
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsAddUserOpen(false)}
                  className="px-3 py-1.5 rounded-lg border border-stone-300 text-xs font-semibold text-stone-700"
                >
                  {t('cancel', language)}
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold"
                >
                  {t('add', language)}
                </button>
              </div>
            </form>
          )}
        </div>
      )}

      {/* 4. 100% OFFLINE DATA BACKUP & RESTORE */}
      {activeTab === 'backup' && (
        <div className="rounded-2xl bg-white border border-stone-200 shadow-sm p-5 space-y-5 max-w-2xl">
          <div>
            <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
              <FileJson className="w-5 h-5 text-amber-700" />
              <span>{t('dataBackupTitle', language)}</span>
            </h3>
            <p className="text-xs text-stone-500 mt-1">
              {t('backupDescription', language)}
            </p>
          </div>

          {/* Privacy badge */}
          <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 flex items-center gap-2 font-medium">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
            <span>
              {language === 'gu'
                ? '૧૦૦% ઓફલાઇન અને શૂન્ય ટ્રેકિંગ: તમારો તમામ નાણાકીય ડેટા માત્ર તમારા ડિવાઇસમાં જ સુરક્ષિત રહે છે.'
                : '100% Offline with zero tracking: All financial data stays strictly on your device.'}
            </span>
          </div>

          {/* Backup Download */}
          <div className="p-4 rounded-xl border border-stone-200 bg-stone-50 space-y-2">
            <h4 className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
              <Download className="w-4 h-4 text-amber-600" />
              <span>{language === 'gu' ? '૧. ખાતાવહી બેકઅપ ડાઉનલોડ કરો' : '1. Download Ledger Backup'}</span>
            </h4>
            <p className="text-[11px] text-stone-500">
              {language === 'gu'
                ? 'તમામ દૈનિક આવક/ખર્ચ, લોન, વ્યાજની ગણતરીઓ, હપ્તાઓ અને બેંક ખાતાઓનો પૂર્ણ બેકઅપ એક ક્લિકમાં સેવ કરો.'
                : 'Save a timestamped JSON backup file containing all transactions, loans, and settings.'}
            </p>
            <button
              type="button"
              onClick={handleDownloadBackup}
              className="mt-1 flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-md"
            >
              <Download className="w-4 h-4" />
              <span>{t('downloadBackup', language)}</span>
            </button>
          </div>

          {/* Restore File */}
          <div className="p-4 rounded-xl border border-stone-200 bg-stone-50 space-y-2">
            <h4 className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
              <Upload className="w-4 h-4 text-blue-600" />
              <span>{language === 'gu' ? '૨. અગાઉના બેકઅપમાંથી ડેટા પુનઃસ્થાપિત કરો' : '2. Restore from Backup File'}</span>
            </h4>
            <p className="text-[11px] text-stone-500">
              {t('restoreWarning', language)}
            </p>

            <div className="pt-1">
              <label className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-900 text-white text-xs font-bold cursor-pointer transition-all shadow-xs">
                <Upload className="w-4 h-4" />
                <span>{language === 'gu' ? 'ફાઇલ પસંદ કરો (.json)' : 'Select Backup File (.json)'}</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>

            {restoreStatus && (
              <div
                className={`p-2.5 rounded-lg text-xs font-semibold mt-2 ${
                  restoreStatus.success
                    ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                    : 'bg-rose-100 text-rose-900 border border-rose-300'
                }`}
              >
                {restoreStatus.message}
              </div>
            )}
          </div>

          {/* 3. Native App Installers (APK & EXE) */}
          <div className="p-4 rounded-xl border border-stone-200 bg-stone-50 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-emerald-600" />
                <span>
                  {language === 'gu'
                    ? '૩. નેટિવ એપ્લિકેશન ફાઇલ્સ (APK અને EXE ડાઉનલોડ)'
                    : '3. Native Application Installers (APK & EXE Downloads)'}
                </span>
              </h4>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300">
                પ્રોજેક્ટ ફાઇલ્સમાં ઉપલબ્ધ
              </span>
            </div>

            <p className="text-[11px] text-stone-500">
              {language === 'gu'
                ? 'ખાતાવહી એપને તમારા મોબાઈલ અથવા કોમ્પ્યુટરમાં કાયમી ઇન્સ્ટોલ કરવા માટે નીચે આપેલ ફાઇલો ડાઉનલોડ કરો:'
                : 'Download standalone offline installer packages directly from project files:'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              {/* Android APK */}
              <div className="p-3 bg-white rounded-xl border border-emerald-200 space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-xs">
                    APK
                  </div>
                  <div>
                    <span className="text-xs font-bold text-stone-900 block">Android Mobile App</span>
                    <span className="text-[10px] text-stone-500">v2.0.0 • /downloads/Khatavahi-v2.0.0.apk</span>
                  </div>
                </div>
                <a
                  href="/downloads/Khatavahi-v2.0.0.apk"
                  download="Khatavahi-v2.0.0.apk"
                  className="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{t('downloadApkButton', language)}</span>
                </a>
              </div>

              {/* Windows EXE */}
              <div className="p-3 bg-white rounded-xl border border-blue-200 space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-800 flex items-center justify-center font-bold text-xs">
                    EXE
                  </div>
                  <div>
                    <span className="text-xs font-bold text-stone-900 block">Windows PC Setup (x64)</span>
                    <span className="text-[10px] text-stone-500">v2.0.0 • /downloads/Khatavahi-Windows-Setup-x64.exe</span>
                  </div>
                </div>
                <a
                  href="/downloads/Khatavahi-Windows-Setup-x64.exe"
                  download="Khatavahi-Windows-Setup-x64.exe"
                  className="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold transition-all shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{t('downloadExeButton', language)}</span>
                </a>
              </div>
            </div>
          </div>

          {/* Danger zone / Reset */}
          <div className="pt-3 border-t border-stone-200 flex items-center justify-between text-xs text-stone-500">
            <span>સંપૂર્ણ ડેટા ખાલી કરવો:</span>
            <button
              type="button"
              onClick={handleResetData}
              className="text-xs font-semibold text-rose-600 hover:text-rose-800 underline underline-offset-2"
            >
              {language === 'gu' ? 'તમામ ડેટા રીસેટ કરો (Clear Data)' : 'Reset All Ledger Data'}
            </button>
          </div>
        </div>
      )}

      {/* Add / Edit Category Modal */}
      {isCatModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white border border-stone-200 shadow-2xl overflow-hidden">
            <div className="bg-gradient-to-r from-red-950 to-red-900 text-white px-5 py-3.5 flex items-center justify-between border-b border-amber-500/50">
              <h2 className="text-base font-bold text-amber-100">
                {editingCat ? t('edit', language) : t('addCategory', language)}
              </h2>
              <button
                type="button"
                onClick={() => setIsCatModalOpen(false)}
                className="rounded-lg p-1 text-stone-300 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveCat} className="p-5 space-y-3">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  {t('categoryNameGu', language)} *
                </label>
                <input
                  type="text"
                  required
                  value={catNameGu}
                  onChange={(e) => setCatNameGu(e.target.value)}
                  placeholder="દા.ત. કરિયાણું, વાહન ખર્ચ"
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-sm font-semibold"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  {t('categoryNameEn', language)}
                </label>
                <input
                  type="text"
                  value={catNameEn}
                  onChange={(e) => setCatNameEn(e.target.value)}
                  placeholder="e.g. Groceries, Vehicle"
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-sm font-semibold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  {t('accountType', language)}
                </label>
                <select
                  value={catType}
                  onChange={(e) => setCatType(e.target.value as CategoryType)}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-semibold bg-white"
                >
                  <option value="income">{t('income', language)} (જમા)</option>
                  <option value="expense">{t('expense', language)} (ઉધાર)</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsCatModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-stone-300 text-xs font-semibold text-stone-700"
                >
                  {t('cancel', language)}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg text-xs font-bold text-white bg-amber-600 hover:bg-amber-700"
                >
                  {t('save', language)}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
