import React, { useState } from 'react';
import {
  AlertTriangle,
  Check,
  Database,
  KeyRound,
  RefreshCw,
  Trash2,
  Upload,
} from 'lucide-react';
import { CATEGORY_LABELS_RU, ClanDashboardState, VillageCategory } from '../shared/cocData';
import { formatDateTimeRu } from '../utils/formatters';
import { apiFetchJson } from '../utils/apiClient';

interface SettingsViewProps {
  state: ClanDashboardState;
  isSyncing: boolean;
  onSyncNow: () => void;
  onStateUpdated: (nextState: ClanDashboardState, notice?: string) => void;
  onOpenClanConnect: () => void;
}

interface PreviewResponse {
  parsed: {
    tag: string;
    townHallLevel: number;
    recognizedCount: number;
    progress: {
      overallPct: number;
      defensesPct: number;
      heroesPct: number;
      labPct: number;
      wallsPct: number;
    };
  };
  matchedPlayer: { tag: string; name: string; oldPct: number } | null;
  diffs: Array<{
    itemId: string;
    itemNameRu: string;
    category: VillageCategory | 'townhall';
    instanceNumber?: number;
    fromLevel: number;
    toLevel: number;
  }>;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  state,
  isSyncing,
  onSyncNow,
  onStateUpdated,
  onOpenClanConnect,
}) => {
  const [savingSyncCfg, setSavingSyncCfg] = useState(false);
  const [clearingCache, setClearingCache] = useState(false);
  const [testingApi, setTestingApi] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [settingsMsg, setSettingsMsg] = useState<string | null>(null);
  const [settingsErr, setSettingsErr] = useState<string | null>(null);

  // Village Data Export JSON Importer
  const [jsonText, setJsonText] = useState('');
  const [targetTag, setTargetTag] = useState('');
  const [playerName, setPlayerName] = useState('');
  const [preview, setPreview] = useState<PreviewResponse | null>(null);
  const [importLoading, setImportLoading] = useState(false);
  const [importErr, setImportErr] = useState<string | null>(null);
  const [importSuccess, setImportSuccess] = useState<string | null>(null);

  const updateSyncSettings = async (patch: {
    autoSyncEnabled?: boolean;
    intervalMinutes?: number;
  }) => {
    setSavingSyncCfg(true);
    setSettingsErr(null);
    setSettingsMsg(null);
    try {
      const data = await apiFetchJson<{ state?: ClanDashboardState }>('/api/settings/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(patch),
      });
      if (data.state) {
        onStateUpdated(data.state);
        setSettingsMsg('Настройки автосинхронизации сохранены');
      }
    } catch (err) {
      setSettingsErr(
        err instanceof Error ? err.message : 'Не удалось сохранить настройки автосинхронизации'
      );
    } finally {
      setSavingSyncCfg(false);
    }
  };

  const handleClearCache = async () => {
    setClearingCache(true);
    setSettingsErr(null);
    setSettingsMsg(null);
    try {
      const data = await apiFetchJson<{ state?: ClanDashboardState }>('/api/cache/clear', {
        method: 'POST',
      });
      if (data.state) {
        onStateUpdated(data.state);
        setSettingsMsg('Серверный кэш запросов к Supercell API очищен');
      }
    } catch (err) {
      setSettingsErr(err instanceof Error ? err.message : 'Не удалось очистить кэш');
    } finally {
      setClearingCache(false);
    }
  };

  const handleTestApiConnection = async () => {
    setTestingApi(true);
    setSettingsErr(null);
    setSettingsMsg(null);
    try {
      const data = await apiFetchJson<{ elapsedMs: number }>('/api/coc/test-connection');
      setSettingsMsg(
        `Подключение к https://api.clashofclans.com/v1/ успешно (${data.elapsedMs} мс)`
      );
    } catch (err) {
      setSettingsErr(
        err instanceof Error ? err.message : 'Не удалось выполнить проверку подключения к API'
      );
    } finally {
      setTestingApi(false);
    }
  };

  const handleDisconnectClan = async () => {
    setResetting(true);
    setSettingsErr(null);
    setSettingsMsg(null);
    try {
      const nextState = await apiFetchJson<ClanDashboardState>('/api/reset', { method: 'POST' });
      onStateUpdated(nextState, 'Текущий клан отключён и локальная база очищена');
    } catch (err) {
      setSettingsErr(err instanceof Error ? err.message : 'Ошибка при отключении клана');
    } finally {
      setResetting(false);
    }
  };

  const handlePreviewJson = async () => {
    setImportErr(null);
    setImportSuccess(null);
    if (!jsonText.trim()) {
      setImportErr('Вставьте JSON экспорта деревни из Clash of Clans.');
      return;
    }
    setImportLoading(true);
    try {
      const data = await apiFetchJson<PreviewResponse>('/api/import/preview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jsonText, targetTag: targetTag || undefined }),
      });
      setPreview(data);
    } catch (err) {
      setImportErr(err instanceof Error ? err.message : 'Не удалось разобрать JSON');
      setPreview(null);
    } finally {
      setImportLoading(false);
    }
  };

  const handleCommitImport = async () => {
    setImportErr(null);
    setImportSuccess(null);
    setImportLoading(true);
    try {
      const data = await apiFetchJson<{
        player: { name: string; tag: string };
        eventsCreated: number;
        state: ClanDashboardState;
      }>('/api/import/village', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonText,
          targetTag: targetTag || undefined,
          playerName: playerName || undefined,
        }),
      });
      setImportSuccess(
        `База ${data.player.name} (${data.player.tag}) обновлена. Зафиксировано новых улучшений: ${data.eventsCreated}.`
      );
      setPreview(null);
      onStateUpdated(data.state);
    } catch (err) {
      setImportErr(err instanceof Error ? err.message : 'Ошибка сохранения JSON-снимка');
    } finally {
      setImportLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <section className="border-b border-slate-800/90 pb-4">
        <h1 className="font-display text-2xl font-bold tracking-tight text-slate-100">
          Настройки и синхронизация
        </h1>
        <p className="mt-1 text-sm text-slate-400">
          Статус серверного секрета <span className="font-mono text-slate-300">SUPERCELL_API_KEY</span>, автосинхронизация, кэш API и импорт JSON-снимков базы
        </p>
      </section>

      {settingsErr && (
        <div className="rounded-md border border-rose-500/40 bg-rose-500/10 px-4 py-3 text-xs text-rose-300">
          {settingsErr}
        </div>
      )}
      {settingsMsg && (
        <div className="rounded-md border border-emerald-500/40 bg-emerald-500/10 px-4 py-3 text-xs text-emerald-300">
          {settingsMsg}
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Token Status & Setup Instructions */}
        <section className="rounded-lg border border-slate-800 bg-[#121824] p-5 lg:col-span-6 space-y-4">
          <div className="flex items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
            <div className="flex items-center gap-2">
              <KeyRound className="h-4 w-4 text-amber-400" />
              <h2 className="font-display text-base font-semibold text-slate-100">
                Supercell API Key (SUPERCELL_API_KEY)
              </h2>
            </div>
            <span
              className={`font-mono text-xs font-semibold ${
                state.hasApiToken ? 'text-emerald-400' : 'text-amber-400'
              }`}
            >
              {state.hasApiToken ? 'Настроен на сервере' : 'Не задан'}
            </span>
          </div>

          {!state.hasApiToken ? (
            <div className="rounded-md border border-amber-500/40 bg-amber-500/10 p-4 text-xs text-amber-200 space-y-2 leading-relaxed">
              <div className="flex items-center gap-2 font-semibold text-amber-300">
                <AlertTriangle className="h-4 w-4 shrink-0" />
                <span>Секрет SUPERCELL_API_KEY отсутствует</span>
              </div>
              <p>Для работы с официальным Clash of Clans API выполните настройку:</p>
              <ol className="list-decimal pl-4 space-y-1">
                <li>
                  Откройте портал <span className="font-mono">developer.clashofclans.com</span> и создайте новый API-ключ.
                </li>
                <li>
                  Укажите исходящий IP-адрес сервера в списке разрешённых IP этого ключа (Supercell блокирует запросы с других IP).
                </li>
                <li>
                  Добавьте полученный ключ в Secrets / переменные окружения сервера с точным именем{' '}
                  <span className="font-mono font-semibold">SUPERCELL_API_KEY</span>.
                </li>
                <li>Перезапустите сервер приложения.</li>
              </ol>
            </div>
          ) : (
            <div className="rounded-md border border-emerald-500/30 bg-emerald-500/10 p-4 text-xs text-emerald-200 leading-relaxed">
              Секрет <span className="font-mono font-semibold">SUPERCELL_API_KEY</span> обнаружен в серверном окружении. Все запросы к{' '}
              <span className="font-mono">https://api.clashofclans.com/v1/</span> выполняются строго через серверный прокси и никогда не передаются на клиент.
            </div>
          )}

          <div className="border-t border-slate-800/80 pt-3 text-xs text-slate-400 space-y-2">
            <div className="flex items-center justify-between">
              <span>Подключённый клан:</span>
              <span className="font-mono text-slate-200">
                {state.clan ? `${state.clan.name} (${state.clan.tag})` : 'Не выбран'}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span>Сохранённых снимков в БД:</span>
              <span className="font-mono tabular-nums text-slate-200">{state.snapshots.length}</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Записей в серверном кэше API:</span>
              <span className="font-mono tabular-nums text-slate-200">
                {state.syncConfig.cacheEntriesCount ?? 0} (TTL {state.syncConfig.cacheTtlSeconds ?? 60} с)
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 pt-1">
            <button
              type="button"
              onClick={onOpenClanConnect}
              className="rounded-md bg-amber-500 px-3.5 py-2 text-xs font-semibold text-slate-950 hover:bg-amber-400 transition-colors"
            >
              Выбрать / сменить клан
            </button>
            <button
              type="button"
              disabled={testingApi}
              onClick={handleTestApiConnection}
              className="inline-flex items-center gap-1.5 rounded-md border border-slate-700 bg-[#0B0F17] px-3.5 py-2 text-xs font-medium text-slate-200 hover:border-amber-500/60 transition-colors"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${testingApi ? 'animate-spin' : ''}`} />
              <span>{testingApi ? 'Проверка...' : 'Проверить API'}</span>
            </button>
            <button
              type="button"
              disabled={clearingCache}
              onClick={handleClearCache}
              className="inline-flex items-center gap-1.5 rounded-md border border-slate-700 bg-[#0B0F17] px-3.5 py-2 text-xs font-medium text-slate-200 hover:border-amber-500/60 transition-colors"
            >
              <Database className="h-3.5 w-3.5" />
              <span>{clearingCache ? 'Очистка...' : 'Очистить кэш API'}</span>
            </button>
            {state.clan && (
              <button
                type="button"
                disabled={resetting}
                onClick={handleDisconnectClan}
                className="inline-flex items-center gap-1.5 rounded-md border border-rose-500/40 bg-rose-500/10 px-3.5 py-2 text-xs font-medium text-rose-300 hover:bg-rose-500/20 transition-colors"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>{resetting ? 'Отключение...' : 'Отключить клан'}</span>
              </button>
            )}
          </div>
        </section>

        {/* Auto-sync Scheduler */}
        <section className="rounded-lg border border-slate-800 bg-[#121824] p-5 lg:col-span-6 space-y-4">
          <div className="flex items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
            <h2 className="font-display text-base font-semibold text-slate-100">
              Автосинхронизация и снимки
            </h2>
            <span className="font-mono text-xs text-slate-400">
              {state.syncConfig.autoSyncEnabled ? 'Включена' : 'Отключена'}
            </span>
          </div>

          <div className="space-y-4 text-xs">
            <label className="flex items-center justify-between gap-4 rounded-md border border-slate-800 bg-[#0B0F17] px-4 py-3 cursor-pointer">
              <div>
                <div className="font-medium text-slate-100">
                  Автоматически обновлять данные и сохранять снимки
                </div>
                <div className="mt-0.5 text-slate-400">
                  Сервер будет периодически запрашивать актуальные данные Supercell API по расписанию
                </div>
              </div>
              <input
                type="checkbox"
                checked={state.syncConfig.autoSyncEnabled}
                disabled={savingSyncCfg}
                onChange={(e) =>
                  updateSyncSettings({ autoSyncEnabled: e.target.checked })
                }
                className="h-4 w-4 accent-amber-500"
              />
            </label>

            <div className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-slate-800 bg-[#0B0F17] px-4 py-3">
              <div>
                <div className="font-medium text-slate-100">Интервал автосинхронизации</div>
                <div className="mt-0.5 text-slate-400 max-w-md">
                  По умолчанию — 6 часов. Встроенный планировщик работает пока активен сервер (плюс догоняющая синхронизация при старте; для serverless можно вызывать <span className="font-mono text-slate-300">POST /api/sync/tick</span>).
                </div>
              </div>
              <select
                value={state.syncConfig.intervalMinutes}
                disabled={savingSyncCfg}
                onChange={(e) =>
                  updateSyncSettings({ intervalMinutes: Number(e.target.value) })
                }
                className="rounded-md border border-slate-700 bg-[#121824] px-3 py-1.5 font-mono text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
              >
                <option value={15}>15 минут</option>
                <option value={30}>30 минут</option>
                <option value={60}>1 час (60 мин)</option>
                <option value={180}>3 часа (180 мин)</option>
                <option value={360}>6 часов (по умолчанию)</option>
                <option value={720}>12 часов (720 мин)</option>
                <option value={1440}>24 часа (1440 мин)</option>
              </select>
            </div>

            <div className="space-y-2 border-t border-slate-800/80 pt-3 text-slate-400">
              <div className="flex items-center justify-between">
                <span>Последняя успешная синхронизация:</span>
                <span className="font-mono text-slate-200">
                  {formatDateTimeRu(state.syncConfig.lastSyncAt)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span>Статус последнего запроса:</span>
                <span
                  className={`font-mono font-semibold ${
                    state.syncConfig.lastSyncStatus === 'ok'
                      ? 'text-emerald-400'
                      : state.syncConfig.lastSyncStatus === 'error'
                      ? 'text-rose-400'
                      : 'text-slate-400'
                  }`}
                >
                  {state.syncConfig.lastSyncStatus === 'ok'
                    ? 'Успешно'
                    : state.syncConfig.lastSyncStatus === 'error'
                    ? 'Ошибка'
                    : 'Ожидание'}
                </span>
              </div>
              {state.syncConfig.lastSyncError && (
                <div className="rounded border border-rose-500/40 bg-rose-500/10 p-2.5 text-rose-300">
                  {state.syncConfig.lastSyncError}
                </div>
              )}
            </div>

            <button
              type="button"
              disabled={isSyncing || !state.clan}
              onClick={onSyncNow}
              className="inline-flex items-center gap-2 rounded-md bg-amber-500 px-4 py-2 text-xs font-semibold text-slate-950 hover:bg-amber-400 disabled:opacity-50 transition-colors"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'Синхронизация...' : 'Обновить данные сейчас'}</span>
            </button>
          </div>
        </section>
      </div>

      {/* Optional In-Game JSON Data Export Importer */}
      <section className="rounded-lg border border-slate-800 bg-[#121824] p-5 space-y-4">
        <div className="border-b border-slate-800/80 pb-3">
          <h2 className="font-display text-base font-semibold text-slate-100">
            Дополнительно (необязательно): Импорт JSON деревни из игры (Data Export)
          </h2>
          <p className="mt-0.5 text-xs text-slate-400">
            Вся основная аналитика, профили игроков, рейтинги и журнал улучшений работают полностью автоматически через Supercell API без импорта JSON. Этот дополнительный инструмент нужен только при желании увидеть уровни отдельных защитных зданий, ловушек и стен из внутриигрового экспорта (Настройки → Ещё настройки → Экспорт данных).
          </p>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Привязать к игроку клана (необязательно)
            </label>
            <select
              value={targetTag}
              onChange={(e) => setTargetTag(e.target.value)}
              className="w-full rounded-md border border-slate-800 bg-[#0B0F17] px-3 py-2 text-xs text-slate-100 focus:border-amber-500 focus:outline-none"
            >
              <option value="">Определить автоматически по тегу в JSON</option>
              {state.players.map((p) => (
                <option key={p.tag} value={p.tag}>
                  {p.name} ({p.tag} · TH{p.townHallLevel})
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Имя игрока (если игрока нет в списке клана)
            </label>
            <input
              type="text"
              value={playerName}
              onChange={(e) => setPlayerName(e.target.value)}
              placeholder="Имя игрока..."
              className="w-full rounded-md border border-slate-800 bg-[#0B0F17] px-3 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
            />
          </div>
        </div>

        <textarea
          rows={6}
          value={jsonText}
          onChange={(e) => setJsonText(e.target.value)}
          placeholder="Вставьте скопированный из настроек Clash of Clans JSON деревни..."
          className="w-full rounded-md border border-slate-800 bg-[#0B0F17] p-3 font-mono text-xs text-slate-200 placeholder:text-slate-600 focus:border-amber-500 focus:outline-none"
        />

        {importErr && (
          <div className="rounded-md border border-rose-500/40 bg-rose-500/10 px-3.5 py-2.5 text-xs text-rose-300">
            {importErr}
          </div>
        )}
        {importSuccess && (
          <div className="rounded-md border border-emerald-500/40 bg-emerald-500/10 px-3.5 py-2.5 text-xs text-emerald-300">
            {importSuccess}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            disabled={importLoading}
            onClick={handlePreviewJson}
            className="inline-flex items-center gap-2 rounded-md border border-slate-700 bg-[#0B0F17] px-4 py-2 text-xs font-medium text-slate-200 hover:border-amber-500/60 transition-colors"
          >
            <Upload className="h-3.5 w-3.5" />
            <span>Проверить изменения</span>
          </button>

          <button
            type="button"
            disabled={importLoading || !jsonText.trim()}
            onClick={handleCommitImport}
            className="inline-flex items-center gap-2 rounded-md bg-amber-500 px-4 py-2 text-xs font-semibold text-slate-950 hover:bg-amber-400 disabled:opacity-50 transition-colors"
          >
            <Check className="h-3.5 w-3.5" />
            <span>Применить и сохранить</span>
          </button>
        </div>

        {preview && (
          <div className="mt-3 border-t border-slate-800 pt-3">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <span className="font-semibold text-slate-200">
                Предпросмотр: {preview.matchedPlayer ? `${preview.matchedPlayer.name} (${preview.parsed.tag})` : preview.parsed.tag} · Ратуша {preview.parsed.townHallLevel}
              </span>
              <span className="font-mono tabular-nums text-amber-400">
                Новый прогресс: {preview.parsed.progress.overallPct.toFixed(1)}%
              </span>
            </div>
            {preview.diffs.length > 0 ? (
              <div className="mt-2 max-h-48 divide-y divide-slate-800/70 overflow-y-auto rounded border border-slate-800 bg-[#0B0F17]">
                {preview.diffs.map((d, idx) => (
                  <div
                    key={`${d.itemId}-${idx}`}
                    className="flex items-center justify-between px-3 py-2 text-xs"
                  >
                    <span className="text-slate-200">
                      {d.itemNameRu}
                      {d.instanceNumber ? ` #${d.instanceNumber}` : ''}
                      <span className="ml-2 text-slate-500">{CATEGORY_LABELS_RU[d.category]}</span>
                    </span>
                    <span className="font-mono font-semibold tabular-nums text-emerald-400">
                      Ур. {d.fromLevel} → {d.toLevel}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="mt-2 text-xs text-slate-400">
                Распознано объектов: {preview.parsed.recognizedCount}. Новых повышений уровня не найдено.
              </div>
            )}
          </div>
        )}
      </section>
    </div>
  );
};
