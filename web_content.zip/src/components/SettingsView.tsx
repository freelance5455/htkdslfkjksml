import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Download, Upload, RotateCcw, Moon, Sun, Info } from "lucide-react";
import type { StudioApi } from "@/hooks/useStudio";
import { useRef } from "react";

interface Props {
  studio: StudioApi;
}

function toNumber(value: number | number[]): number {
  return Array.isArray(value) ? value[0] : value;
}

export function SettingsView({ studio }: Props) {
  const { settings, updateSettings, resetSettings, exportProject, importProject, persistent } =
    studio;
  const fileRef = useRef<HTMLInputElement>(null);

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto bg-slate-100 p-4 dark:bg-slate-950">
      {!persistent && (
        <Card className="border-amber-300 bg-amber-50 dark:border-amber-800 dark:bg-amber-950/40">
          <CardContent className="flex items-start gap-2 p-3">
            <Info className="mt-0.5 h-4 w-4 shrink-0 text-amber-600 dark:text-amber-400" />
            <p className="text-xs text-amber-800 dark:text-amber-200">
              التخزين الدائم (IndexedDB) غير متاح في هذه البيئة، لذا تُحفظ الملفات في الذاكرة
              فقط خلال هذه الجلسة. استخدم «تصدير المشروع» للاحتفاظ بنسخة.
            </p>
          </CardContent>
        </Card>
      )}

      <Card className="border-sky-200 dark:border-sky-900">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            {settings.theme === "dark" ? (
              <Moon className="h-4 w-4 text-sky-500" />
            ) : (
              <Sun className="h-4 w-4 text-amber-500" />
            )}
            المظهر واللغة
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <Label>الوضع الداكن</Label>
            <Switch
              checked={settings.theme === "dark"}
              onCheckedChange={(v) => updateSettings({ theme: v ? "dark" : "light" })}
            />
          </div>
          <div className="flex items-center justify-between">
            <Label>اللغة</Label>
            <Select
              value={settings.language}
              onValueChange={(v) => updateSettings({ language: v as "ar" | "en" })}
            >
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ar">العربية</SelectItem>
                <SelectItem value="en">English</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card className="border-slate-200 dark:border-slate-800">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">المحرر</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div>
            <div className="mb-2 flex items-center justify-between">
              <Label>حجم الخط</Label>
              <span className="text-sm text-muted-foreground">{settings.fontSize}px</span>
            </div>
            <Slider
              value={settings.fontSize}
              min={10}
              max={24}
              step={1}
              onValueChange={(v) => updateSettings({ fontSize: toNumber(v) })}
            />
          </div>

          <div>
            <div className="mb-2 flex items-center justify-between">
              <Label>ارتفاع الأسطر</Label>
              <span className="text-sm text-muted-foreground">
                {settings.lineHeight.toFixed(1)}
              </span>
            </div>
            <Slider
              value={settings.lineHeight * 10}
              min={12}
              max={24}
              step={1}
              onValueChange={(v) => updateSettings({ lineHeight: toNumber(v) / 10 })}
            />
          </div>

          <div>
            <div className="mb-2 flex items-center justify-between">
              <Label>حجم المسافة البادئة</Label>
              <span className="text-sm text-muted-foreground">{settings.tabSize}</span>
            </div>
            <Slider
              value={settings.tabSize}
              min={2}
              max={8}
              step={1}
              onValueChange={(v) => updateSettings({ tabSize: toNumber(v) })}
            />
          </div>

          <div className="flex items-center justify-between">
            <Label>إظهار أرقام الأسطر</Label>
            <Switch
              checked={settings.showLineNumbers}
              onCheckedChange={(v) => updateSettings({ showLineNumbers: v })}
            />
          </div>

          <div className="flex items-center justify-between">
            <Label>التفاف الأسطر</Label>
            <Switch
              checked={settings.wordWrap}
              onCheckedChange={(v) => updateSettings({ wordWrap: v })}
            />
          </div>
        </CardContent>
      </Card>

      <Card className="border-slate-200 dark:border-slate-800">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">الحفظ والمعاينة</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <Label>الحفظ التلقائي</Label>
            <Switch
              checked={settings.autoSave}
              onCheckedChange={(v) => updateSettings({ autoSave: v })}
            />
          </div>

          {settings.autoSave && (
            <div>
              <div className="mb-2 flex items-center justify-between">
                <Label>مدة الحفظ التلقائي</Label>
                <span className="text-sm text-muted-foreground">
                  {(settings.autoSaveDelay / 1000).toFixed(1)}s
                </span>
              </div>
              <Slider
                value={settings.autoSaveDelay}
                min={500}
                max={5000}
                step={250}
                onValueChange={(v) => updateSettings({ autoSaveDelay: toNumber(v) })}
              />
            </div>
          )}

          <div className="flex items-center justify-between">
            <Label>تحديث المعاينة بعد الحفظ</Label>
            <Switch
              checked={settings.previewOnSave}
              onCheckedChange={(v) => updateSettings({ previewOnSave: v })}
            />
          </div>
        </CardContent>
      </Card>

      <Card className="border-slate-200 dark:border-slate-800">
        <CardHeader className="pb-3">
          <CardTitle className="text-base">المشروع والنسخ الاحتياطي</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-3">
          <Button onClick={exportProject} variant="outline" className="justify-start gap-2">
            <Download className="h-4 w-4" />
            تصدير المشروع (JSON)
          </Button>
          <Button
            onClick={() => fileRef.current?.click()}
            variant="outline"
            className="justify-start gap-2"
          >
            <Upload className="h-4 w-4" />
            استيراد مشروع
          </Button>
          <input
            ref={fileRef}
            type="file"
            accept="application/json,.json"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) importProject(f);
              e.target.value = "";
            }}
          />
          <Button
            onClick={resetSettings}
            variant="outline"
            className="justify-start gap-2 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950"
          >
            <RotateCcw className="h-4 w-4" />
            إعادة ضبط الإعدادات
          </Button>
        </CardContent>
      </Card>

      <p className="px-2 pb-4 text-center text-[11px] text-muted-foreground">
        Mobile Code Studio · يعمل دون اتصال · البيانات محفوظة محليًا
      </p>
    </div>
  );
}