// JUHNKRIX MUSIKA - JM-GLOBAL-TRADE App Component
// Connects JM-CRYPTO miners with licensed third-party cryptocurrency trading platforms supporting JMC.

import React, { useState, useEffect } from 'react';
import { 
  Globe, 
  Search, 
  ExternalLink, 
  ShieldCheck, 
  Coins, 
  ArrowRight, 
  AlertCircle, 
  Sparkles, 
  CheckCircle,
  TrendingUp,
  Lock,
  Building2,
  RefreshCw,
  ShieldAlert,
  Shield
} from 'lucide-react';
import { cloudflareEventLogger } from '../lib/cloudflareEventLogger';
import { appDownloadEarningsEngine } from '../lib/appDownloadEarningsEngine';
import { tradeCrawler, CrawledTradingPlatform } from '../lib/tradeCrawler';
import { tradeSecurity, TradeSecurityAnalysis } from '../lib/tradeSecurity';
import { tradeHistoryTracker } from '../lib/tradeHistory';
import { exchangeHealthMonitor, ExchangeHealthStatus } from '../lib/exchangeHealthMonitor';
import { globalExchangeSecurityRegistry } from '../lib/globalExchangeSecurityRegistry';
import { TradingAcademyView } from './TradingAcademyView';

export const JMGlobalTradePageView: React.FC = () => {
  const [platforms, setPlatforms] = useState<CrawledTradingPlatform[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [tradeNotice, setTradeNotice] = useState<string | null>(null);
  const [isCrawling, setIsCrawling] = useState<boolean>(false);
  const [activeMainTab, setActiveMainTab] = useState<'exchanges' | 'academy'>('exchanges');
  const [healthStatuses, setHealthStatuses] = useState<Record<string, ExchangeHealthStatus>>({});

  useEffect(() => {
    // Load verified exchanges from Global Exchange Security Registry as single source of truth
    const registryExchanges = globalExchangeSecurityRegistry.getVerifiedExchanges();
    setPlatforms(registryExchanges as any);
    setHealthStatuses(exchangeHealthMonitor.getHealthStatuses());
  }, []);

  const handleRefreshCrawl = async () => {
    setIsCrawling(true);
    setTradeNotice('🔄 Running Global Exchange Security Registry sync & health monitor...');
    const registryExchanges = globalExchangeSecurityRegistry.getVerifiedExchanges();
    const refreshedHealth = exchangeHealthMonitor.refreshHealthStatuses();
    setPlatforms(registryExchanges as any);
    setHealthStatuses(refreshedHealth);
    setIsCrawling(false);
    setTradeNotice('✓ Global Exchange Security Registry validated: Zero ZJMC remnants, JMC verified!');
    setTimeout(() => setTradeNotice(null), 5000);
  };

  const filteredPlatforms = platforms.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.supportedPairs.some(pair => pair.toLowerCase().includes(searchQuery.toLowerCase())) ||
                          p.countryOrLicense.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = selectedCategory === 'ALL' || p.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const handlePlatformClick = async (platform: CrawledTradingPlatform) => {
    const security = tradeSecurity.analyzeExchangeSecurity(platform.url, platform.isVerifiedLicensed);
    
    // Check safety score threshold warning (< 95%)
    if (security.safetyScore < 95) {
      const confirmProceed = window.confirm(`⚠️ SECURITY WARNING: ${platform.name} has a Safety Score of ${security.safetyScore}% (Below 95% threshold). Proceed with caution or verify exchange license.`);
      if (!confirmProceed) return;
    }

    // 1. Log cryptographic telemetry event
    await cloudflareEventLogger.logAndSignEvent('TRADE_CLICK', platform.name);

    // 2. Record successful interaction in trade history tracker
    tradeHistoryTracker.recordTradeInteraction(platform.name, platform.url, security.safetyScore);

    // 3. Credit owner earnings for JM-GLOBAL-TRADE interaction
    appDownloadEarningsEngine.recordDownloadOrUpdate('ANDROID', 'UPDATE');

    setTradeNotice(`🔗 Securely connecting to ${platform.name} (${platform.url})... JMC cryptographic signature verified.`);
    setTimeout(() => setTradeNotice(null), 5000);

    // 4. Open third-party trading platform in new tab
    window.open(platform.url, '_blank');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8 animate-fadeIn text-amber-100">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/60 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full text-xs font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-400/40">
              <TrendingUp className="w-4 h-4 text-amber-400" />
              <span>JM-GLOBAL-TRADE PORTAL (JMC)</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black font-serif text-amber-100 tracking-tight">
              Global JMC Trading Directory & Security Hub
            </h1>
            <p className="text-sm text-slate-300 leading-relaxed">
              Welcome to <strong>JM-GLOBAL-TRADE</strong>. Powered by automated web crawling and heuristic safety analysis, all JM-CRYPTO miners can explore and trade JMC on verified, government-licensed cryptocurrency exchanges worldwide with real-time Safety Scores and health monitoring alerts.
            </p>
          </div>

          <div className="flex flex-col items-end gap-3 shrink-0">
            <button
              onClick={handleRefreshCrawl}
              disabled={isCrawling}
              className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs font-mono flex items-center space-x-2 shadow-lg cursor-pointer transition-transform hover:scale-102"
            >
              <RefreshCw className={`w-4 h-4 text-slate-950 ${isCrawling ? 'animate-spin' : ''}`} />
              <span>{isCrawling ? 'Syncing Health...' : 'Sync Health & Crawler'}</span>
            </button>
            <div className="bg-slate-950/80 p-3 rounded-2xl border border-amber-500/30 font-mono text-xs text-right space-y-1">
              <div className="text-emerald-400 font-bold flex items-center justify-end space-x-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Heuristic Security: Active</span>
              </div>
              <div className="text-slate-400">Tracked Platforms: <strong className="text-white">{platforms.length} Licensed</strong></div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation Tabs: Exchange Directory vs Trading Academy */}
      <div className="flex items-center space-x-3 border-b border-amber-500/30 pb-4">
        <button
          onClick={() => setActiveMainTab('exchanges')}
          className={`px-5 py-3 rounded-2xl text-sm font-mono font-bold flex items-center space-x-2 transition-all cursor-pointer ${
            activeMainTab === 'exchanges'
              ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/30 font-black'
              : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-700'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>Exchange Directory & Health</span>
        </button>
        <button
          onClick={() => setActiveMainTab('academy')}
          className={`px-5 py-3 rounded-2xl text-sm font-mono font-bold flex items-center space-x-2 transition-all cursor-pointer ${
            activeMainTab === 'academy'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/40 font-black'
              : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-700'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Trading Academy & Tutorials</span>
        </button>
      </div>

      {activeMainTab === 'academy' ? (
        <TradingAcademyView />
      ) : (
        <>
          {/* Important Disclaimer Notice */}
          <div className="bg-amber-950/40 border-2 border-amber-500/50 rounded-2xl p-4 sm:p-5 flex items-start space-x-3.5 text-xs sm:text-sm text-amber-200">
            <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="space-y-1 leading-relaxed">
              <strong className="block text-amber-100 font-bold uppercase tracking-wider text-xs">
                Important Disclaimer Regarding Third-Party Trading Platforms:
              </strong>
              <p className="text-slate-300 text-xs">
                <strong>JM-GLOBAL-TRADE</strong> is not a crypto trading platform itself and does not host or control any cryptocurrency trade. All trading platforms and markets listed here are third-party companies hosted and controlled by respective licensed corporations. Exchanges with a Safety Score below 95% trigger automatic warning alerts.
              </p>
            </div>
          </div>

      {tradeNotice && (
        <div className="p-4 rounded-2xl bg-emerald-950/90 border border-emerald-400 text-emerald-200 text-xs sm:text-sm flex items-center space-x-3 shadow-xl">
          <Sparkles className="w-5 h-5 text-yellow-300 animate-spin-slow shrink-0" />
          <span>{tradeNotice}</span>
        </div>
      )}

      {/* Enhanced Search Engine Box & Category Filter */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-amber-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by exchange name, pair (e.g. JMC, USDT, BTC), or regulatory license..."
            className="w-full bg-slate-900 border-2 border-amber-500/30 rounded-2xl pl-12 pr-4 py-3.5 text-sm text-white placeholder-slate-400 font-mono focus:border-amber-400 focus:outline-none shadow-inner"
          />
        </div>

        <div className="flex items-center space-x-2 overflow-x-auto pb-2 md:pb-0">
          {['ALL', 'Centralized Exchange (CEX)', 'Decentralized Exchange (DEX)', 'Global Spot & Derivatives'].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2.5 rounded-xl text-xs font-mono font-bold whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/30'
                  : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Clean Grid-Based Card Layout Highlighting Safety Scores & Threshold Alerts */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPlatforms.map((platform) => {
          const security: TradeSecurityAnalysis = tradeSecurity.analyzeExchangeSecurity(platform.url, platform.isVerifiedLicensed);
          const isBelowThreshold = security.safetyScore < 95;

          return (
            <div
              key={platform.id}
              className={`bg-slate-900/90 border-2 rounded-3xl p-6 flex flex-col justify-between space-y-4 shadow-xl transition-all hover:scale-[1.01] relative overflow-hidden group ${
                isBelowThreshold ? 'border-rose-500/50 shadow-rose-500/10' : 'border-amber-500/30 hover:border-amber-400'
              }`}
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-2xl group-hover:bg-amber-500/10 transition-colors" />

              <div className="space-y-3 relative z-10">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <span className="text-3xl p-2 rounded-2xl bg-slate-950 border border-amber-500/20 shadow-inner">
                      {platform.logo}
                    </span>
                    <div>
                      <h3 className="text-base font-bold text-amber-100 font-serif">{platform.name}</h3>
                      <span className="text-[10px] font-mono text-amber-300/85 block">{platform.category}</span>
                    </div>
                  </div>

                  {/* Safety Score Badge & Alert */}
                  <div className="text-right flex flex-col items-end gap-1">
                    <span className={`px-3 py-1 rounded-xl text-xs font-mono font-black flex items-center space-x-1 shadow-md ${
                      isBelowThreshold
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-400/50 animate-pulse'
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40'
                    }`}>
                      {isBelowThreshold ? <ShieldAlert className="w-3.5 h-3.5 text-rose-400" /> : <Shield className="w-3.5 h-3.5 text-emerald-400" />}
                      <span>{security.safetyScore}% Safety</span>
                    </span>
                  </div>
                </div>

                {isBelowThreshold && (
                  <div className="px-3 py-1.5 rounded-xl bg-rose-950/80 border border-rose-500/40 text-rose-200 text-[10px] font-mono flex items-center space-x-1.5">
                    <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                    <span>⚠️ Warning: Safety Score below 95% threshold!</span>
                  </div>
                )}

                <p className="text-xs text-slate-300 leading-relaxed">
                  {platform.description}
                </p>

                <div className="space-y-1.5 text-[11px] font-mono bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div className="text-slate-400">License / Reg: <strong className="text-slate-200">{platform.countryOrLicense}</strong></div>
                  <div className="text-slate-400">Security Audit: <strong className="text-emerald-400">{security.auditBadge}</strong></div>
                  <div className="flex flex-wrap gap-1 pt-1.5">
                    {platform.supportedPairs.map((pair) => (
                      <span key={pair} className="px-2 py-0.5 rounded-md bg-slate-900 text-amber-300 border border-amber-500/20 text-[10px] font-mono font-bold">
                        {pair}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 relative z-10">
                <button
                  onClick={() => handlePlatformClick(platform)}
                  className={`w-full py-3 rounded-xl font-black text-xs uppercase flex items-center justify-center space-x-2 shadow-lg transition-transform hover:scale-102 cursor-pointer ${
                    isBelowThreshold
                      ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/30'
                      : 'bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 shadow-amber-500/20'
                  }`}
                >
                  <span>TRADE JMC ON {platform.name.toUpperCase()}</span>
                  <ExternalLink className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filteredPlatforms.length === 0 && (
        <div className="text-center py-16 bg-slate-900 rounded-3xl border border-slate-800 space-y-3">
          <Building2 className="w-12 h-12 text-slate-600 mx-auto" />
          <h3 className="text-lg font-bold text-slate-300">No Trading Platforms Found</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            No exchange matches &quot;{searchQuery}&quot;. Try searching for JMC, USDT, or Bitcoin pairs.
          </p>
        </div>
      )}
        </>
      )}

      {/* Global Security & Compliance Footer Info */}
      <div className="bg-slate-950 p-6 rounded-3xl border border-amber-500/30 flex flex-col md:flex-row items-center justify-between gap-4 text-xs font-mono">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-400/30">
            <Lock className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <h4 className="text-amber-200 font-bold font-serif text-sm">Automated Trade Crawler & Safety Threshold Alerts</h4>
            <p className="text-slate-400 text-[11px]">Real-time SSL verification, safety scoring (&lt;95% threshold warnings), and JMC liquidity routing active.</p>
          </div>
        </div>
        <div className="text-right text-emerald-400 font-bold">
          ✓ 50,000,000 Miners Protected Globally
        </div>
      </div>
    </div>
  );
};
