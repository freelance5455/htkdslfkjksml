import React, { useState } from 'react';
import { Track } from '../types/audio';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  Heart,
  Sliders,
  Sparkles,
  Maximize2,
  Minimize2,
  X,
  Layers,
  Smartphone
} from 'lucide-react';

interface Props {
  currentTrack: Track | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  bpm: number;
  isBeat: boolean;
  onTogglePlay: () => void;
  onNext: () => void;
  onPrev: () => void;
  onSeek: (seconds: number) => void;
  onClose?: () => void;
}

export const WidgetSimulator: React.FC<Props> = ({
  currentTrack,
  isPlaying,
  currentTime,
  duration,
  bpm,
  isBeat,
  onTogglePlay,
  onNext,
  onPrev,
  onSeek,
  onClose,
}) => {
  const [activeWidgetStyle, setActiveWidgetStyle] = useState<'4x1' | '4x2' | '2x2'>('4x2');
  const [wallpaperIndex, setWallpaperIndex] = useState(0);

  const wallpapers = [
    'linear-gradient(135deg, #090a0f 0%, #1e1b4b 50%, #0f172a 100%)',
    'linear-gradient(135deg, #18181b 0%, #27272a 50%, #09090b 100%)',
    'linear-gradient(135deg, #022c22 0%, #064e3b 50%, #020617 100%)',
  ];

  const formatTime = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-indigo-400" />
            <span>Simulador de Widgets para Pantalla de Inicio (Android APK)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Previsualiza e interactúa con los widgets nativos que AuraSound añade a tu launcher móvil
          </p>
        </div>

        {/* Style selector */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-xl">
          <button
            onClick={() => setActiveWidgetStyle('4x2')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition ${
              activeWidgetStyle === '4x2'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Widget 4x2 Audiophile
          </button>
          <button
            onClick={() => setActiveWidgetStyle('4x1')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition ${
              activeWidgetStyle === '4x1'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Widget 4x1 Barra
          </button>
          <button
            onClick={() => setActiveWidgetStyle('2x2')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition ${
              activeWidgetStyle === '2x2'
                ? 'bg-indigo-600 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Widget 2x2 Mini Disco
          </button>
        </div>
      </div>

      {/* Simulated Phone Home Screen */}
      <div className="relative mx-auto max-w-sm rounded-[36px] p-4 border-[6px] border-slate-800 shadow-2xl overflow-hidden min-h-[580px] flex flex-col justify-between"
        style={{ background: wallpapers[wallpaperIndex] }}
      >
        {/* Android Status Bar */}
        <div className="flex items-center justify-between text-[11px] font-medium text-slate-300 px-3 pt-1 pb-4">
          <span>12:45</span>
          <div className="w-16 h-4 bg-black/80 rounded-full mx-auto" /> {/* Camera cutout */}
          <div className="flex items-center gap-1.5">
            <span>5G</span>
            <span>100%</span>
          </div>
        </div>

        {/* Home Screen Clock & Weather */}
        <div className="text-center my-auto py-2">
          <div className="text-5xl font-light tracking-tight text-white/90">12:45</div>
          <div className="text-xs text-slate-300 mt-1 font-medium">Sábado, 24 de Octubre · 22°C</div>
        </div>

        {/* ================== THE INTERACTIVE WIDGET ================== */}
        <div className="my-auto px-1">
          {/* WIDGET 4x2 AUDIOPHILE */}
          {activeWidgetStyle === '4x2' && (
            <div className="p-4 rounded-3xl bg-slate-900/85 backdrop-blur-xl border border-white/10 shadow-2xl text-left space-y-3 relative overflow-hidden">
              {/* Beat glow aura inside widget */}
              <div
                className={`absolute -top-12 -right-12 w-32 h-32 rounded-full blur-2xl transition-opacity duration-150 pointer-events-none ${
                  isBeat ? 'bg-indigo-500/30 opacity-100' : 'bg-transparent opacity-0'
                }`}
              />

              <div className="flex items-center gap-3">
                {/* Album Cover */}
                <div className="relative w-14 h-14 rounded-2xl overflow-hidden shrink-0 border border-white/10 shadow-md">
                  <img
                    src={currentTrack?.coverUrl || '/icon.svg'}
                    alt={currentTrack?.title || 'Track'}
                    className={`w-full h-full object-cover ${isPlaying ? 'scale-105' : 'scale-100'} transition-transform duration-700`}
                  />
                  {isPlaying && (
                    <div className="absolute inset-0 bg-indigo-500/10 pointer-events-none" />
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold text-white truncate">
                    {currentTrack?.title || 'Sin reproducción'}
                  </p>
                  <p className="text-[11px] text-slate-400 truncate mt-0.5">
                    {currentTrack?.artist || 'Selecciona una canción'}
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[9px] font-mono px-1.5 py-0.2 bg-white/10 text-indigo-300 rounded font-semibold uppercase">
                      {currentTrack?.format || 'Hi-Fi'}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono tabular-nums">
                      {bpm} BPM
                    </span>
                  </div>
                </div>
              </div>

              {/* Progress Slider */}
              <div className="space-y-1">
                <input
                  type="range"
                  min="0"
                  max={duration || 100}
                  value={currentTime}
                  onChange={(e) => onSeek(Number(e.target.value))}
                  className="w-full accent-indigo-400 h-1 bg-white/20 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] font-mono tabular-nums text-slate-400">
                  <span>{formatTime(currentTime)}</span>
                  <span>{formatTime(duration)}</span>
                </div>
              </div>

              {/* Controls */}
              <div className="flex items-center justify-between pt-1">
                <button
                  onClick={onPrev}
                  className="p-2 text-slate-300 hover:text-white rounded-xl hover:bg-white/10 transition active:scale-95"
                >
                  <SkipBack className="w-4 h-4" />
                </button>

                <button
                  onClick={onTogglePlay}
                  className="w-11 h-11 rounded-2xl bg-gradient-to-r from-indigo-500 to-purple-600 text-white flex items-center justify-center shadow-lg shadow-indigo-500/30 hover:scale-105 active:scale-95 transition"
                >
                  {isPlaying ? (
                    <Pause className="w-5 h-5 fill-current" />
                  ) : (
                    <Play className="w-5 h-5 fill-current ml-0.5" />
                  )}
                </button>

                <button
                  onClick={onNext}
                  className="p-2 text-slate-300 hover:text-white rounded-xl hover:bg-white/10 transition active:scale-95"
                >
                  <SkipForward className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* WIDGET 4x1 SLIM BAR */}
          {activeWidgetStyle === '4x1' && (
            <div className="p-3 rounded-2xl bg-slate-900/85 backdrop-blur-xl border border-white/10 shadow-xl flex items-center justify-between gap-3 text-left">
              <div className="w-10 h-10 rounded-xl overflow-hidden shrink-0 border border-white/10">
                <img
                  src={currentTrack?.coverUrl || '/icon.svg'}
                  alt={currentTrack?.title}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="min-w-0 flex-1">
                <p className="text-xs font-bold text-white truncate">
                  {currentTrack?.title || 'AuraSound'}
                </p>
                <p className="text-[10px] text-slate-400 truncate">
                  {currentTrack?.artist || 'Listo para reproducir'}
                </p>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <button
                  onClick={onPrev}
                  className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-white/10"
                >
                  <SkipBack className="w-4 h-4" />
                </button>

                <button
                  onClick={onTogglePlay}
                  className="p-2 rounded-xl bg-indigo-600 text-white hover:bg-indigo-500 transition shadow-sm"
                >
                  {isPlaying ? (
                    <Pause className="w-4 h-4 fill-current" />
                  ) : (
                    <Play className="w-4 h-4 fill-current ml-0.5" />
                  )}
                </button>

                <button
                  onClick={onNext}
                  className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-white/10"
                >
                  <SkipForward className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* WIDGET 2x2 MINI DISK */}
          {activeWidgetStyle === '2x2' && (
            <div className="w-48 mx-auto p-4 rounded-3xl bg-slate-900/85 backdrop-blur-xl border border-white/10 shadow-xl text-center space-y-3">
              <div className="relative w-24 h-24 mx-auto rounded-full overflow-hidden border-2 border-indigo-500/40 shadow-inner">
                <img
                  src={currentTrack?.coverUrl || '/icon.svg'}
                  alt={currentTrack?.title}
                  className={`w-full h-full object-cover ${
                    isPlaying ? 'animate-spin' : ''
                  }`}
                  style={{ animationDuration: '6s' }}
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-6 h-6 rounded-full bg-slate-900 border border-slate-700" />
                </div>
              </div>

              <div className="min-w-0">
                <p className="text-xs font-bold text-white truncate">
                  {currentTrack?.title || 'AuraSound'}
                </p>
                <p className="text-[10px] text-slate-400 truncate">
                  {currentTrack?.artist || 'Música'}
                </p>
              </div>

              <div className="flex items-center justify-center gap-3">
                <button
                  onClick={onPrev}
                  className="p-1.5 text-slate-300 hover:text-white rounded-lg"
                >
                  <SkipBack className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={onTogglePlay}
                  className="p-2 rounded-xl bg-indigo-600 text-white hover:bg-indigo-500"
                >
                  {isPlaying ? (
                    <Pause className="w-4 h-4 fill-current" />
                  ) : (
                    <Play className="w-4 h-4 fill-current ml-0.5" />
                  )}
                </button>
                <button
                  onClick={onNext}
                  className="p-1.5 text-slate-300 hover:text-white rounded-lg"
                >
                  <SkipForward className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Android Bottom App Dock & Navigation Bar */}
        <div className="space-y-3 pt-6">
          <div className="flex items-center justify-around px-2 py-2 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10">
            {['Teléfono', 'Mensajes', 'Chrome', 'AuraSound'].map((app, i) => (
              <div key={app} className="flex flex-col items-center gap-1">
                <div
                  className={`w-10 h-10 rounded-2xl flex items-center justify-center text-xs font-bold text-white shadow-md ${
                    i === 3
                      ? 'bg-gradient-to-tr from-indigo-500 to-pink-500'
                      : 'bg-slate-700/80'
                  }`}
                >
                  {i === 3 ? 'AS' : app[0]}
                </div>
                <span className="text-[9px] text-white/80 font-medium">{app}</span>
              </div>
            ))}
          </div>

          {/* Android pill gesture bar */}
          <div className="w-28 h-1 bg-white/60 rounded-full mx-auto mb-1" />
        </div>
      </div>
    </div>
  );
};
