import React from 'react';
import { motion } from 'motion/react';
import { Trophy, Flame, Target, Edit3, Award } from 'lucide-react';
import { Player } from '../types';
import { toPersianDigits } from '../utils/snooker';

interface PlayerCardProps {
  player: Player;
  rank: number;
  isActive: boolean;
  onSelect: () => void;
  onEdit: (e: React.MouseEvent) => void;
  isLeader: boolean;
  snookersNeeded?: number;
}

export const PlayerCard: React.FC<PlayerCardProps> = ({
  player,
  rank,
  isActive,
  onSelect,
  onEdit,
  isLeader,
  snookersNeeded = 0,
}) => {
  const totalShots = player.hits + player.misses;
  const accuracy = totalShots > 0 ? Math.round((player.hits / totalShots) * 100) : 0;

  // Rank badge styling
  let rankBadgeStyle = 'bg-slate-800 text-slate-400 border-slate-700';
  let rankIcon = null;
  if (rank === 1) {
    rankBadgeStyle = 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow-sm shadow-amber-500/20';
    rankIcon = <Trophy className="w-3 h-3 text-amber-400 inline ml-1" />;
  } else if (rank === 2) {
    rankBadgeStyle = 'bg-slate-300/20 text-slate-200 border-slate-400/40';
  } else if (rank === 3) {
    rankBadgeStyle = 'bg-amber-700/20 text-amber-600 border-amber-700/40';
  }

  return (
    <motion.div
      layout
      transition={{ type: 'spring', stiffness: 400, damping: 30 }}
      onClick={onSelect}
      className={`relative overflow-hidden rounded-2xl p-3.5 sm:p-4 transition-all duration-200 cursor-pointer select-none border ${
        isActive
          ? 'bg-gradient-to-br from-slate-900/95 via-slate-900 to-emerald-950/40 border-emerald-500/70 shadow-[0_0_24px_rgba(16,185,129,0.22)]'
          : 'bg-slate-900/70 hover:bg-slate-800/80 border-slate-800/80 hover:border-slate-700/80 shadow-md'
      }`}
    >
      {/* Active Cue Glow bar indicator */}
      {isActive && (
        <div className="absolute top-0 right-0 left-0 h-1 bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-500 animate-pulse" />
      )}

      {/* Card Header: Identity, Rank, Name, Frames & Score */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Rank Badge */}
          <span
            className={`flex items-center justify-center text-xs font-black px-2 py-0.5 rounded-lg border ${rankBadgeStyle}`}
          >
            {rankIcon}
            #{toPersianDigits(rank)}
          </span>

          {/* Player Name and Quick Edit */}
          <div className="flex items-center gap-1.5 group">
            <h3 className="font-bold text-slate-100 text-sm sm:text-base tracking-tight truncate max-w-[140px] sm:max-w-[200px]">
              {player.name}
            </h3>
            <button
              type="button"
              onClick={onEdit}
              aria-label="ویرایش نام بازیکن"
              className="opacity-60 hover:opacity-100 p-1 text-slate-400 hover:text-emerald-400 rounded-md transition-colors"
            >
              <Edit3 className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Frames won badge if any */}
          {player.framesWon > 0 && (
            <span className="hidden xs:inline-flex items-center gap-1 text-[11px] font-semibold bg-blue-950/70 text-blue-300 border border-blue-800/60 px-1.5 py-0.5 rounded-md">
              <Award className="w-3 h-3 text-blue-400" />
              {toPersianDigits(player.framesWon)} فریم
            </span>
          )}
        </div>

        {/* Big Score Display */}
        <div className="flex items-baseline gap-2 text-left">
          {player.currentBreak > 0 && (
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="flex items-center gap-1 text-xs font-bold text-amber-400 bg-amber-950/50 border border-amber-500/40 px-2 py-0.5 rounded-full"
            >
              <Flame className="w-3 h-3 text-amber-400 animate-bounce" />
              <span>بریک {toPersianDigits(player.currentBreak)}</span>
            </motion.div>
          )}
          <div
            dir="ltr"
            className={`text-2xl sm:text-3xl font-black tracking-tight drop-shadow-sm ${
              player.score < 0 ? 'text-rose-400' : 'text-amber-400'
            }`}
          >
            {toPersianDigits(player.score)}
          </div>
        </div>
      </div>

      {/* Snooker needed alert if trailing heavily */}
      {!isLeader && snookersNeeded > 0 && (
        <div className="mb-2 text-[11px] bg-rose-950/40 border border-rose-800/40 text-rose-300 px-2.5 py-1 rounded-lg flex items-center justify-between">
          <span>نیاز به اسنوکر (خطای حریف):</span>
          <span className="font-bold text-rose-200">{toPersianDigits(snookersNeeded)} خطا</span>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-4 gap-1.5 sm:gap-2 bg-slate-950/50 border border-slate-800/60 rounded-xl p-2 text-center text-xs">
        {/* Highest Break */}
        <div className="flex flex-col items-center">
          <span className="text-[10px] sm:text-[11px] text-slate-400 font-medium">بریک برتر</span>
          <span className="font-extrabold text-emerald-400 text-xs sm:text-sm">
            {toPersianDigits(player.highestBreak)}
          </span>
        </div>

        {/* Accuracy */}
        <div className="flex flex-col items-center">
          <div className="flex items-center gap-0.5 text-[10px] sm:text-[11px] text-slate-400 font-medium">
            <Target className="w-2.5 h-2.5 text-blue-400" />
            <span>دقت</span>
          </div>
          <span className="font-extrabold text-blue-400 text-xs sm:text-sm">
            %{toPersianDigits(accuracy)}
          </span>
        </div>

        {/* Hits */}
        <div className="flex flex-col items-center">
          <span className="text-[10px] sm:text-[11px] text-slate-400 font-medium">پاکت</span>
          <span className="font-extrabold text-emerald-300 text-xs sm:text-sm">
            {toPersianDigits(player.hits)}
          </span>
        </div>

        {/* Misses */}
        <div className="flex flex-col items-center">
          <span className="text-[10px] sm:text-[11px] text-slate-400 font-medium">خطا / ناموفق</span>
          <span className="font-extrabold text-rose-400 text-xs sm:text-sm">
            {toPersianDigits(player.misses)}
          </span>
        </div>
      </div>
    </motion.div>
  );
};
