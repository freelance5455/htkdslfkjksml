import React, { useState } from 'react';
import { Player } from '../types.ts';
import { PlayerHead } from './PlayerHead.tsx';
import { Check, Copy } from 'lucide-react';

interface PlayerCardProps {
  player: Player;
}

export const PlayerCard: React.FC<PlayerCardProps> = ({ player }) => {
  const [copied, setCopied] = useState(false);
  const playerName = player.displayName || player.name || 'Unbekannt';
  const isBedrock = playerName.startsWith('.');
  const platform = isBedrock ? 'Bedrock' : 'Java';

  const handleCopy = () => {
    navigator.clipboard.writeText(playerName);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      onClick={handleCopy}
      role="button"
      tabIndex={0}
      title="Klicken zum Kopieren des Spielernamens"
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          handleCopy();
        }
      }}
      className="group relative flex items-center justify-between p-3.5 sm:p-4 rounded-xl bg-zinc-900/80 hover:bg-zinc-800/90 border border-zinc-800/80 hover:border-zinc-700/80 shadow-sm transition-all duration-150 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
    >
      {/* Spielerkopf und daneben der Spielername mit Bedrock/Java Angabe */}
      <div className="flex items-center gap-3.5 min-w-0">
        <PlayerHead
          identifier={playerName}
          uuid={player.uuid}
          size="md"
          className="group-hover:scale-105 transition-transform duration-150 shadow-md ring-1 ring-zinc-700/50"
        />

        <div className="flex flex-col min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-base sm:text-lg text-zinc-100 group-hover:text-emerald-300 transition-colors truncate">
              {playerName}
            </span>
            <span
              className={`inline-flex items-center px-1.5 py-0.5 rounded text-[11px] font-semibold tracking-wide shrink-0 ${
                isBedrock
                  ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                  : 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
              }`}
            >
              {platform}
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span>Online</span>
          </div>
        </div>
      </div>

      {/* Dezentes Kopier-Feedback */}
      {copied && (
        <span className="flex items-center gap-1 text-xs text-emerald-400 font-medium animate-in fade-in shrink-0">
          <Check className="w-3.5 h-3.5 text-emerald-400" />
          <span>Kopiert</span>
        </span>
      )}
    </div>
  );
};
