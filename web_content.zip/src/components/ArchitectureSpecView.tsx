import React from 'react';
import { 
  Layers, 
  Compass, 
  Smartphone, 
  ArrowRight, 
  ShieldCheck, 
  Zap, 
  ShoppingBag, 
  CheckCircle2, 
  Store,
  User,
  CreditCard,
  Grid
} from 'lucide-react';

export const ArchitectureSpecView: React.FC = () => {
  const screens = [
    {
      name: '1. Home Screen (Discovery Hub)',
      purpose: 'Drive immediate engagement, high-conversion flash deal discovery, and deep category browsing.',
      darazElements: [
        'Sticky multi-modal search bar with Voice Search (waveform simulation) & Visual Camera/Lens search.',
        'High-impact 16:9 campaign banner carousel featuring mega-deals and brand launches.',
        '8-item quick-category grid for 1-tap navigation into core verticals (Fashion, Gadgets, Beauty, Groceries).',
        'Real-time Flash Sale section with digital countdown timer (HH:MM:SS), percentage sold progress bars, and high-urgency deal cards.',
        'Infinite-scroll "Just For You" personalized recommendation feed with dual-column grid and dynamic category pills.'
      ]
    },
    {
      name: '2. Category & Faceted Search Page',
      purpose: 'Empower rapid product filtering with zero friction and high precision.',
      darazElements: [
        'Horizontal scrollable category pill rail with instant responsive filtering.',
        'Quick facet chips: Sewora Mall (Official brands only), Free Shipping, 4.8★ & up, Price brackets.',
        'Sort options: Top Match (relevance algorithm), Price: Low to High, Price: High to Low, Most Popular.',
        'Clean product cards with uniform aspect ratio, verified badge, and discount percent tag.'
      ]
    },
    {
      name: '3. Product Detail Page (PDP)',
      purpose: 'Maximize buyer confidence, eliminate purchase hesitation, and provide complete vendor transparency.',
      darazElements: [
        'Multi-image & video gallery carousel with thumbnail indicators and full-bleed viewing.',
        'Transparent price breakdown: promotional deal price, strikethrough retail MSRP, discount percentage, and Sewora Coins reward tag.',
        'Interactive Variant Matrix: color family swatches + size selectors with real-time stock availability indicators.',
        'Localized Shipping Fee & Delivery Estimator: city dropdown (Colombo, Kandy, Galle, Gampaha) calculating exact fees and standard vs. express next-day delivery dates.',
        'Vendor Trust Module: Seller badge ("Sewora Mall"), positive review percentage (98%), on-time dispatch rate (99%), and instant "Chat with Seller" drawer.',
        'Customer Reviews: verified buyer badges, user upload photo carousel, star rating breakdown, and helpful upvote buttons.',
        'Fixed thumb-friendly bottom purchase bar: Chat, Store, Add to Cart, and Buy Now buttons within the natural thumb reach zone.'
      ]
    },
    {
      name: '4. Shopping Cart & Voucher Wallet',
      purpose: 'Enable seamless multi-vendor order consolidation, promo code stacking, and price clarity.',
      darazElements: [
        'Multi-vendor card grouping: items segregated by vendor store with individual vendor coupon opportunities.',
        'Select all / item-level checkboxes with instant live subtotal re-computation.',
        'Promotional coupon & voucher input field (e.g., "SEWORA50" for 15% off, "FREESHIP").',
        'Transparent cost summary separating items subtotal, shipping cost, and voucher deduction.'
      ]
    },
    {
      name: '5. Seamless Checkout & Payment Gateways',
      purpose: 'Frictionless final order placement tailored to emerging market localized payment habits.',
      darazElements: [
        'Saved delivery address selector with 1-tap default address selection and inline "Add New Address" modal.',
        'Delivery speed toggle: Standard Islandwide Delivery vs. Express Next-Day Courier.',
        'Comprehensive Payment Gateways:',
        '• Credit & Debit Cards (Visa, MasterCard, Amex) with 256-bit encryption.',
        '• Cash on Delivery (COD) with verification notice.',
        '• Local Mobile Wallets (eZ Cash, FriMi, Genie, Apple Pay) for 1-tap checkout.',
        '• Buy Now, Pay Later (BNPL) 3-month interest-free installments via Koko / Mintpay.'
      ]
    },
    {
      name: '6. Order Confirmation & Live Tracking',
      purpose: 'Post-purchase reassurance and package tracking transparency.',
      darazElements: [
        'Order reference number and instant receipt summary.',
        'Interactive 4-step tracking timeline: Order Placed → Warehouse Packed → Dispatched → Delivered.',
        'Copyable courier tracking ID with estimated arrival dates.'
      ]
    },
    {
      name: '7. User Account & Profile Center',
      purpose: 'Centralized customer retention hub, order lifecycle management, and rewards dashboard.',
      darazElements: [
        'User membership level card ("Sewora Gold VIP") with customer email and profile avatar.',
        'My Orders 4-bucket status strip with active order counters: To Pay (1), To Ship (2), To Receive (1), To Review.',
        'Digital Wallet assets: Sewora Pay balance, Sewora Coins counter, and active Voucher coupons count.',
        'Direct access to Wishlist, Address Book, and 24/7 Live Customer Support.'
      ]
    },
    {
      name: '8. Vendor Store Page ("Official Mall")',
      purpose: 'Dedicated storefront empowering brand identity and merchant autonomy.',
      darazElements: [
        'Custom brand banner and avatar with official Mall verification mark.',
        'Merchant credibility metrics: follower count, positive feedback rate, average chat response time.',
        'Exclusive store vouchers that can be collected directly into the customer wallet.',
        'Tabbed store catalog (All Products, Best Sellers, New Arrivals).'
      ]
    }
  ];

  const userJourneySteps = [
    { stage: '1. Discovery', action: 'User opens Sewora, sees personalized banner, checks Flash Sale countdown, or searches via voice/camera.', metric: 'CTR > 22%' },
    { stage: '2. Evaluation', action: 'User views PDP, selects color/size variant, checks delivery time to Colombo, and asks seller a quick question in live chat.', metric: 'PDP to Cart > 14%' },
    { stage: '3. Conversion', action: 'User checks cart, applies voucher "SEWORA50", selects Cash on Delivery or Card, and places order.', metric: 'Checkout Completion > 85%' },
    { stage: '4. Post-Purchase', action: 'User monitors tracking timeline, receives notification on delivery, and earns Sewora Coins by reviewing item with photos.', metric: 'Repeat Purchase > 40%' }
  ];

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 space-y-6">
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
        <div className="flex items-center gap-2 text-xs font-bold text-[#FF6600] uppercase tracking-wider mb-1">
          <Compass className="w-4 h-4" />
          <span>Product Architecture & Screen Flow Specification</span>
        </div>
        <h1 className="text-2xl font-black text-slate-900 tracking-tight">
          Sewora Mobile E-Commerce Ecosystem
        </h1>
        <p className="text-xs text-slate-600 mt-2 leading-relaxed">
          Designed by Lead UI/UX Designer & Senior PM for high-velocity multi-vendor e-commerce. 
          Sewora adapts the battle-tested conversion mechanics of Daraz (multi-tiered trust badges, 
          gamified flash sales, localized payment options, and vendor chat) into a clean, modern aesthetic.
        </p>
      </div>

      {/* Screen Flow Architecture Breakdown */}
      <div className="space-y-4">
        <h2 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
          <Layers className="w-4 h-4 text-[#FF6600]" />
          <span>Core Screens & Feature Architecture</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {screens.map((sc, i) => (
            <div key={i} className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs space-y-2">
              <h3 className="text-xs font-black text-slate-900">{sc.name}</h3>
              <p className="text-[11px] text-slate-500 italic">{sc.purpose}</p>
              <ul className="text-xs text-slate-700 space-y-1 pt-1 border-t border-slate-100">
                {sc.darazElements.map((el, j) => (
                  <li key={j} className="flex items-start gap-1.5 leading-snug">
                    <span className="text-[#FF6600] font-bold mt-0.5">•</span>
                    <span>{el}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* User Journey & Conversion Funnel */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
        <h2 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
          <Zap className="w-4 h-4 text-[#FF6600]" />
          <span>End-to-End User Conversion Journey</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {userJourneySteps.map((step, idx) => (
            <div key={idx} className="bg-slate-50 rounded-2xl p-3.5 border border-slate-200/80 flex flex-col justify-between">
              <div>
                <span className="text-xs font-black text-[#FF6600] block mb-1">{step.stage}</span>
                <p className="text-[11px] text-slate-600 leading-relaxed">{step.action}</p>
              </div>
              <div className="mt-3 pt-2 border-t border-slate-200 text-[10px] font-bold text-slate-700">
                Target KPI: <span className="text-emerald-600">{step.metric}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
