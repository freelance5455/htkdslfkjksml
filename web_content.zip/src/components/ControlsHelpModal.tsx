import React from 'react';
import { HelpCircle, Keyboard, MousePointer, Sparkles, X } from 'lucide-react';

interface ControlsHelpModalProps {
  onClose: () => void;
}

export const ControlsHelpModal: React.FC<ControlsHelpModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">Controls & Pirate Codex</h2>
              <p className="text-xs text-slate-400">Master movement, Devil Fruits, Haki, and Sailing</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs">
          {/* Movement & Camera */}
          <div>
            <div className="flex items-center gap-2 text-slate-300 font-bold mb-2">
              <Keyboard className="w-4 h-4 text-sky-400" />
              <span className="uppercase tracking-wider">Movement & Navigation</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-slate-300">
              <div className="bg-slate-950/60 border border-slate-800 rounded-lg p-2.5">
                <span className="font-mono text-amber-400 font-bold block mb-0.5">W / A / S / D</span>
                <span>Move character / Steer boat</span>
              </div>
              <div className="bg-slate-950/60 border border-slate-800 rounded-lg p-2.5">
                <span className="font-mono text-amber-400 font-bold block mb-0.5">Space</span>
                <span>Jump / Sky Leap (Geppo 4x)</span>
              </div>
              <div className="bg-slate-950/60 border border-slate-800 rounded-lg p-2.5">
                <span className="font-mono text-amber-400 font-bold block mb-0.5">Q</span>
                <span>Soru / Flash Step Dash</span>
              </div>
              <div className="bg-slate-950/60 border border-slate-800 rounded-lg p-2.5">
                <span className="font-mono text-amber-400 font-bold block mb-0.5">Right Mouse Drag</span>
                <span>Rotate 360° 3D Camera</span>
              </div>
            </div>
          </div>

          {/* Combat & Powers */}
          <div>
            <div className="flex items-center gap-2 text-slate-300 font-bold mb-2">
              <MousePointer className="w-4 h-4 text-red-400" />
              <span className="uppercase tracking-wider">Combat & Devil Fruits</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-slate-300">
              <div className="bg-slate-950/60 border border-slate-800 rounded-lg p-2.5">
                <span className="font-mono text-amber-400 font-bold block mb-0.5">Left Click (M1)</span>
                <span>Attack with Punch / Sword</span>
              </div>
              <div className="bg-slate-950/60 border border-slate-800 rounded-lg p-2.5">
                <span className="font-mono text-amber-400 font-bold block mb-0.5">Z / X / C / V</span>
                <span>Devil Fruit abilities (Mastery unlocks)</span>
              </div>
              <div className="bg-slate-950/60 border border-slate-800 rounded-lg p-2.5">
                <span className="font-mono text-amber-400 font-bold block mb-0.5">J</span>
                <span>Busoshoku Haki (Aura +35% DMG)</span>
              </div>
              <div className="bg-slate-950/60 border border-slate-800 rounded-lg p-2.5">
                <span className="font-mono text-amber-400 font-bold block mb-0.5">E</span>
                <span>Kenbunshoku Haki (Auto-Dodge)</span>
              </div>
            </div>
          </div>

          {/* Android Mobile Touch Controls */}
          <div>
            <div className="flex items-center gap-2 text-emerald-400 font-bold mb-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span className="uppercase tracking-wider">Android Phone & Touch Mode</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-slate-300">
              <div className="bg-slate-950/60 border border-slate-800 rounded-lg p-2.5">
                <span className="font-mono text-emerald-400 font-bold block mb-0.5">Left Thumb Joystick</span>
                <span>Smooth 360° walking & boat steering</span>
              </div>
              <div className="bg-slate-950/60 border border-slate-800 rounded-lg p-2.5">
                <span className="font-mono text-emerald-400 font-bold block mb-0.5">Swipe on Screen</span>
                <span>Rotate 3D camera freely anywhere</span>
              </div>
              <div className="bg-slate-950/60 border border-slate-800 rounded-lg p-2.5">
                <span className="font-mono text-emerald-400 font-bold block mb-0.5">Pinch Screen</span>
                <span>Zoom camera in or out</span>
              </div>
              <div className="bg-slate-950/60 border border-slate-800 rounded-lg p-2.5">
                <span className="font-mono text-emerald-400 font-bold block mb-0.5">Touch Action Buttons</span>
                <span>Right thumb Attack, Jump, Soru, & Z/X/C/V skills</span>
              </div>
            </div>
          </div>

          {/* Pro Tips */}
          <div className="bg-purple-950/40 border border-purple-800/60 rounded-xl p-3.5 space-y-1.5 text-slate-300">
            <div className="flex items-center gap-1.5 text-purple-300 font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Grand Sea Pro Tips</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-slate-400">
              <li>Devil Fruit users take drowning damage if swimming in the sea. Use boats, Ice skate, or Flame flight!</li>
              <li>Leveling up grants 3 Stat Points. Spend them in the Stats menu to boost Health, Energy, and Damage.</li>
              <li>Spin random fruits at the Fruit Dealer for 25,000 Beli, or search for fruit spawns under island trees.</li>
              <li>The Buddha Fruit [V] turns you into a giant golden deity with massive attack range and defense!</li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/40 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold cursor-pointer transition-colors"
          >
            Got It!
          </button>
        </div>
      </div>
    </div>
  );
};
