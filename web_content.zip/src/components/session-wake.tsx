import { useEffect } from "react";
import { useAppStore, useRuntime } from "@/lib/store";

export function SessionWake() {
  const running = useAppStore((state) => state.session.running);
  const keepAwake = useAppStore((state) => state.keepAwake);

  useEffect(() => {
    let cancelled = false;
    let lock: WakeLockSentinel | null = null;

    async function sync() {
      const shouldHold = useAppStore.getState().session.running && useAppStore.getState().keepAwake && document.visibilityState === "visible";
      if (!shouldHold) {
        try {
          await lock?.release();
        } catch {
          /* already released */
        }
        lock = null;
        if (!("wakeLock" in navigator) && useAppStore.getState().keepAwake) {
          useRuntime.getState().setWake("unsupported");
        } else if (useRuntime.getState().wake !== "denied") {
          useRuntime.getState().setWake("off");
        }
        return;
      }
      if (!("wakeLock" in navigator)) {
        useRuntime.getState().setWake("unsupported");
        return;
      }
      try {
        const next = await navigator.wakeLock.request("screen");
        if (cancelled) {
          await next.release();
          return;
        }
        lock = next;
        useRuntime.getState().setWake("on");
        next.addEventListener("release", () => {
          if (lock === next) lock = null;
        });
      } catch {
        if (!cancelled) useRuntime.getState().setWake("denied");
      }
    }

    void sync();
    const onVisible = () => void sync();
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      cancelled = true;
      document.removeEventListener("visibilitychange", onVisible);
      void lock?.release().catch(() => undefined);
    };
  }, [running, keepAwake]);

  return null;
}
