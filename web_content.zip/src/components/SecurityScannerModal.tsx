import React, { useState } from 'react';
import { Shield, ShieldAlert, ShieldCheck, AlertTriangle, Search, X, Lock, Unlock, Globe } from 'lucide-react';
import { SecurityScanResult } from '../types';
import { safeFetchJson } from '../services/apiClient';

interface SecurityScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialUrl?: string;
}

export const SecurityScannerModal: React.FC<SecurityScannerModalProps> = ({
  isOpen,
  onClose,
  initialUrl = '',
}) => {
  const [urlInput, setUrlInput] = useState(initialUrl);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<SecurityScanResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleScan = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!urlInput.trim()) return;

    setLoading(true);
    setResult(null);
    setErrorMsg(null);

    try {
      const data = await safeFetchJson<SecurityScanResult>('/api/security/check-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: urlInput.trim() }),
      });

      setResult(data);
    } catch (err: any) {
      setErrorMsg(err.message || 'Website security audit failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-950/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg bg-gray-900 border border-cyan-500/40 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-gray-950/90 border-b border-cyan-500/30">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-cyan-400" />
            <h3 className="font-tech text-base tracking-wide uppercase text-cyan-100">
              JARVIS WEB THREAT & PHISHING SHIELD
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-cyan-400 hover:bg-cyan-500/20"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search input */}
        <form onSubmit={handleScan} className="p-4 bg-gray-950/40 border-b border-cyan-500/20">
          <div className="text-xs font-tech text-cyan-300 uppercase mb-2">Inspect URL or Domain</div>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Globe className="w-4 h-4 absolute left-3 top-3 text-cyan-500" />
              <input
                type="text"
                placeholder="Enter URL (e.g. secure-login-bank.xyz or google.com)"
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-gray-950 border border-cyan-500/40 rounded-xl text-cyan-100 text-xs focus:outline-none focus:border-cyan-400"
                required
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-gray-950 font-tech font-bold uppercase text-xs rounded-xl flex items-center gap-1 glow-cyan-sm transition-colors cursor-pointer"
            >
              {loading ? 'Analyzing...' : <><Search className="w-3.5 h-3.5" /> Scan</>}
            </button>
          </div>
        </form>

        {/* Results */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4">
          {errorMsg && (
            <div className="p-3 bg-red-950/50 border border-red-500/40 rounded-xl flex items-center gap-2 text-xs text-red-200">
              <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {result && (
            <div className="space-y-3">
              {/* Verdict Banner */}
              <div className={`p-4 rounded-xl border flex items-center gap-3.5 ${
                result.status === 'SAFE'
                  ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300'
                  : result.status === 'CAUTION'
                  ? 'bg-amber-950/40 border-amber-500/50 text-amber-300'
                  : 'bg-red-950/50 border-red-500/60 text-red-300 glow-red'
              }`}>
                {result.status === 'SAFE' ? (
                  <ShieldCheck className="w-8 h-8 text-emerald-400 flex-shrink-0" />
                ) : result.status === 'CAUTION' ? (
                  <AlertTriangle className="w-8 h-8 text-amber-400 flex-shrink-0" />
                ) : (
                  <ShieldAlert className="w-8 h-8 text-red-400 flex-shrink-0 animate-pulse" />
                )}
                <div>
                  <div className="font-tech text-base font-bold uppercase tracking-wide">
                    {result.status === 'SAFE' ? 'VERIFIED SECURE' : result.status === 'CAUTION' ? 'POTENTIAL RISK DETECTED' : 'DANGEROUS // THREAT FLAGGED'}
                  </div>
                  <p className="text-xs mt-0.5 opacity-90 leading-relaxed">
                    {result.verdict}
                  </p>
                </div>
              </div>

              {/* Security Metrics Breakdown */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-3 bg-gray-950/70 rounded-xl border border-cyan-500/20">
                  <span className="text-cyan-400/70 font-mono-tech block">ENCRYPTION PROTOCOL</span>
                  <div className="flex items-center gap-1.5 mt-1 font-semibold text-cyan-100">
                    {result.isHttps ? (
                      <>
                        <Lock className="w-3.5 h-3.5 text-emerald-400" />
                        HTTPS Encrypted
                      </>
                    ) : (
                      <>
                        <Unlock className="w-3.5 h-3.5 text-red-400" />
                        Insecure HTTP
                      </>
                    )}
                  </div>
                </div>

                <div className="p-3 bg-gray-950/70 rounded-xl border border-cyan-500/20">
                  <span className="text-cyan-400/70 font-mono-tech block">CALCULATED THREAT INDEX</span>
                  <div className="flex items-center gap-1.5 mt-1 font-semibold">
                    <span className={`font-mono-tech ${result.riskScore > 30 ? 'text-red-400' : 'text-emerald-400'}`}>
                      {result.riskScore}/100 Risk Score
                    </span>
                  </div>
                </div>
              </div>

              {/* Technical Audit Findings */}
              <div className="p-3 bg-gray-950/60 rounded-xl border border-cyan-500/20 space-y-1.5">
                <div className="text-xs font-tech text-cyan-300 uppercase mb-1">Audit Findings & Indicators:</div>
                {result.reasons.map((r, i) => (
                  <div key={i} className="text-xs text-cyan-200/90 flex items-start gap-2">
                    <span className="text-cyan-400 mt-0.5">•</span>
                    <span>{r}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {!result && !errorMsg && (
            <div className="text-center py-6 text-cyan-400/60 text-xs leading-relaxed">
              Before opening unfamiliar links, bank login portals, or prize draws, request: <br />
              <span className="text-cyan-300 font-semibold">"Jarvis, is this website safe &lt;URL&gt;"</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-gray-950/90 border-t border-cyan-500/20 text-[11px] text-cyan-300/60">
          Analysis verifies SSL integrity, Punycode/IDN spoofing, suspicious TLDs, and domain heuristic indicators. Never submit credentials on unverified websites.
        </div>
      </div>
    </div>
  );
};
