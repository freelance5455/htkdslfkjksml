import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Camera, 
  Mic, 
  MicOff, 
  RefreshCw, 
  Volume2, 
  VolumeX, 
  Send, 
  Sparkles, 
  Eye, 
  Bot, 
  CornerDownLeft, 
  ArrowRight,
  Maximize2,
  Minimize2,
  Upload,
  ExternalLink,
  Image as ImageIcon
} from 'lucide-react';
import { streamChatResponse, ChatMessage } from '../services/gemini';
import { parseAndExecuteVoiceCommand } from '../utils/voiceCommands';
import { cn } from '../utils/cn';

interface LiveCameraModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveToChat?: (messages: ChatMessage[]) => void;
  userName?: string;
  persona?: 'Male' | 'Female';
  language?: string;
}

interface VisionExchange {
  id: string;
  userQuestion: string;
  frameUrl: string;
  aiResponse: string;
  timestamp: Date;
}

export function LiveCameraModal({
  isOpen,
  onClose,
  onSaveToChat,
  userName = 'Dost',
  persona = 'Female',
  language = 'Hinglish'
}: LiveCameraModalProps) {
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isThinking, setIsThinking] = useState(false);
  const isThinkingRef = useRef(false);
  const lastRequestTimeRef = useRef<number>(0);
  const [isMuted, setIsMuted] = useState(false);
  const [textInput, setTextInput] = useState('');
  const [transcript, setTranscript] = useState('');
  const [activeVoice, setActiveVoice] = useState<'Female' | 'Male'>(persona);
  const [exchanges, setExchanges] = useState<VisionExchange[]>([]);
  const [currentAiSpeech, setCurrentAiSpeech] = useState<string>('');
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [capturedFlash, setCapturedFlash] = useState(false);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const recognitionRef = useRef<any>(null);
  const modalContainerRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const quickPrompts = [
    { label: "Yeh kya hai?", prompt: "Yeh kya hai? Is object ko identify karke batao." },
    { label: "Kaun sa mobile/device hai?", prompt: "Yeh kaun sa mobile ya device hai? Iska brand aur model batao." },
    { label: "Isme kya likha hai?", prompt: "Camera mein dikh rahe text ko padh kar Hindi mein explain karo." },
    { label: "Iska colour & design", prompt: "Iska exact colour, build material aur design details batao." },
    { label: "Iski price & specs", prompt: "Iski approximate market price aur main specifications kya hain?" }
  ];

  // Start / Stop camera when open state changes or facingMode changes
  useEffect(() => {
    if (isOpen) {
      startCamera();
      initSpeechRecognition();
    } else {
      stopAllMedia();
      setExchanges([]);
      setChatHistory([]);
      setCurrentAiSpeech('');
      setTranscript('');
      setUploadedImage(null);
    }
    return () => {
      stopAllMedia();
    };
  }, [isOpen, facingMode]);

  const stopAllMedia = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (_) {}
      recognitionRef.current = null;
    }
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    setIsCameraActive(false);
    setIsListening(false);
    setIsSpeaking(false);
  };

  const startCamera = async (isRetry = false) => {
    setCameraError(null);
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraError("Camera device ya permission uplabdh nahi hai. Aap niche Photo Upload button se direct image analyze karwa sakte hain.");
      setIsCameraActive(false);
      return;
    }

    try {
      const constraints: MediaStreamConstraints = isRetry 
        ? { video: true, audio: false }
        : {
            video: {
              facingMode: { ideal: facingMode },
              width: { ideal: 1280 },
              height: { ideal: 720 }
            },
            audio: false
          };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          videoRef.current?.play().catch(console.warn);
          setIsCameraActive(true);
          setUploadedImage(null);
        };
      }
    } catch (err: any) {
      if (!isRetry && (err?.name === 'OverconstrainedError' || err?.name === 'ConstraintNotSatisfiedError')) {
        return startCamera(true);
      }
      console.warn("Camera access state:", err?.name, err?.message);
      if (err?.name === 'NotAllowedError' || err?.message?.includes('Permission') || err?.name === 'PermissionDeniedError') {
        setCameraError("Camera permission deny hui hai. Browser settings se Camera allow karein, new tab mein open karein, ya photo upload karein.");
      } else if (err?.name === 'NotFoundError' || err?.name === 'DevicesNotFoundError') {
        setCameraError("Aapke system mein camera detect nahi hua. Photo upload karke AI se analysis karwayein.");
      } else {
        setCameraError("Camera shuru nahi ho paaya. Kripya new tab mein try karein ya direct photo upload karein.");
      }
      setIsCameraActive(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      if (base64) {
        setUploadedImage(base64);
        setIsCameraActive(true);
        setCameraError(null);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const flipCamera = () => {
    setFacingMode(prev => prev === 'environment' ? 'user' : 'environment');
  };

  // Speech Recognition Setup
  const initSpeechRecognition = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'hi-IN';

    recognition.onresult = (event: any) => {
      let current = '';
      let isFinal = false;

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const item = event.results[i][0].transcript;
        current += item;
        if (event.results[i].isFinal) {
          isFinal = true;
        }
      }

      setTranscript(current);

      if (isFinal && current.trim().length > 1 && !isThinkingRef.current) {
        handleCaptureAndAsk(current.trim());
      }
    };

    recognition.onerror = (event: any) => {
      if (event.error !== 'no-speech') {
        console.warn("Speech error:", event.error);
      }
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;
  };

  const toggleVoiceListening = () => {
    if (isListening) {
      try {
        recognitionRef.current?.stop();
      } catch (_) {}
      setIsListening(false);
    } else {
      if (!recognitionRef.current) {
        initSpeechRecognition();
      }
      try {
        if (window.speechSynthesis) window.speechSynthesis.cancel();
        recognitionRef.current?.start();
        setIsListening(true);
        setTranscript('');
      } catch (e) {
        console.warn("Could not start speech recognition:", e);
      }
    }
  };

  // Text-To-Speech (TTS)
  const speakVoiceReply = (text: string) => {
    if (!('speechSynthesis' in window) || isMuted) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'hi-IN';
      utterance.rate = 1.0;
      utterance.pitch = activeVoice === 'Female' ? 1.1 : 0.85;

      const voices = window.speechSynthesis.getVoices();
      const preferred = voices.find(v => 
        activeVoice === 'Female'
          ? (v.name.includes('Female') || v.name.includes('Google हिन्दी') || v.lang.includes('hi') || v.lang.includes('en-IN'))
          : (v.name.includes('Male') || v.name.includes('David') || v.lang.includes('hi') || v.lang.includes('en-IN'))
      );
      if (preferred) utterance.voice = preferred;

      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn("TTS error:", e);
    }
  };

  // Grab Current Video Frame or Uploaded Image
  const captureCurrentFrame = (): string | null => {
    if (uploadedImage) {
      setCapturedFlash(true);
      setTimeout(() => setCapturedFlash(false), 200);
      return uploadedImage;
    }
    if (!videoRef.current || !canvasRef.current) return null;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    const width = video.videoWidth || 640;
    const height = video.videoHeight || 480;

    canvas.width = width;
    canvas.height = height;

    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    // Flash animation effect
    setCapturedFlash(true);
    setTimeout(() => setCapturedFlash(false), 200);

    ctx.drawImage(video, 0, 0, width, height);
    return canvas.toDataURL('image/jpeg', 0.75);
  };

  // Main Action: Capture Frame & Ask Gemini
  const handleCaptureAndAsk = async (questionText: string) => {
    const trimmed = questionText.trim();
    const now = Date.now();
    if (!trimmed || isThinkingRef.current || (now - lastRequestTimeRef.current < 1200)) return;
    lastRequestTimeRef.current = now;
    isThinkingRef.current = true;
    setIsThinking(true);

    // Stop ongoing speech
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    if (isListening && recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (_) {}
      setIsListening(false);
    }

    // Check voice command for apps (WhatsApp, YouTube, Google, etc.)
    const voiceAction = parseAndExecuteVoiceCommand(trimmed);
    if (voiceAction) {
      const exchangeId = Date.now().toString();
      const actionMsg = `${voiceAction.spokenReply}\n\n👉 [${voiceAction.actionName} Open Karein](${voiceAction.url})`;
      const newExchange: VisionExchange = {
        id: exchangeId,
        userQuestion: trimmed,
        frameUrl: '',
        aiResponse: actionMsg,
        timestamp: new Date()
      };
      setExchanges(prev => [newExchange, ...prev]);
      setCurrentAiSpeech(voiceAction.spokenReply);
      setTextInput('');
      setTranscript('');
      speakVoiceReply(voiceAction.spokenReply);
      isThinkingRef.current = false;
      setIsThinking(false);
      return;
    }

    const frame = captureCurrentFrame();
    if (!frame) {
      console.warn("No frame captured from camera");
      isThinkingRef.current = false;
      setIsThinking(false);
      return;
    }

    setTextInput('');
    setTranscript('');
    setCurrentAiSpeech('');

    const exchangeId = Date.now().toString();
    const newExchange: VisionExchange = {
      id: exchangeId,
      userQuestion: trimmed,
      frameUrl: frame,
      aiResponse: '',
      timestamp: new Date()
    };

    setExchanges(prev => [newExchange, ...prev]);

    // Construct image payload
    const imagePayload = [frame];

    try {
      const stream = streamChatResponse(
        chatHistory,
        trimmed,
        imagePayload,
        'gemini-3.1-flash-lite',
        activeVoice,
        userName,
        language
      );

      let accumulatedText = '';
      for await (const chunk of stream) {
        if (chunk.error) {
          throw new Error(chunk.error);
        }
        accumulatedText += chunk.text || '';
        setCurrentAiSpeech(accumulatedText);
        setExchanges(prev => prev.map(ex => 
          ex.id === exchangeId ? { ...ex, aiResponse: accumulatedText } : ex
        ));
      }

      // Update chat history for continuous context (e.g. "Yeh kya hai?" -> "Kaun sa mobile hai?")
      const updatedHistory: ChatMessage[] = [
        ...chatHistory,
        { role: 'user', content: trimmed, images: imagePayload },
        { role: 'model', content: accumulatedText }
      ];
      setChatHistory(updatedHistory);

      // Speak response aloud
      speakVoiceReply(accumulatedText);
    } catch (err: any) {
      console.error("Live Camera Gemini error:", err);
      const isRateLimit = err?.message?.includes('429') || err?.message?.toLowerCase()?.includes('rate') || err?.message?.toLowerCase()?.includes('quota');
      const fallbackMsg = isRateLimit
        ? "Bohot saare requests aa rahe hain. Kripya 5 second baad dubara prayaas karein."
        : "Maaf kijiye, main is image ko clearly dekh nahi paaya. Kripya thoda paas se ya achhi roshni mein dubara dikhayein.";
      setCurrentAiSpeech(fallbackMsg);
      setExchanges(prev => prev.map(ex => 
        ex.id === exchangeId ? { ...ex, aiResponse: fallbackMsg } : ex
      ));
      speakVoiceReply(fallbackMsg);
    } finally {
      isThinkingRef.current = false;
      setIsThinking(false);
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (textInput.trim()) {
      handleCaptureAndAsk(textInput);
    }
  };

  const handleSaveAndClose = () => {
    if (onSaveToChat && chatHistory.length > 0) {
      onSaveToChat(chatHistory);
    }
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center bg-black/95 backdrop-blur-md p-2 sm:p-4 animate-fade-in select-none">
      <div 
        ref={modalContainerRef}
        className={cn(
          "w-full max-w-4xl bg-slate-950 rounded-3xl overflow-hidden shadow-2xl border border-slate-800 flex flex-col relative transition-all duration-300",
          isFullscreen ? "h-full max-w-none rounded-none border-none" : "h-[94vh] max-h-[860px]"
        )}
      >
        {/* Hidden Canvas for High-Res Capture */}
        <canvas ref={canvasRef} className="hidden" />
        {/* Hidden File Input for Image Upload Fallback */}
        <input 
          ref={fileInputRef} 
          type="file" 
          accept="image/*" 
          className="hidden" 
          onChange={handleFileUpload} 
        />

        {/* TOP BAR / CONTROLS */}
        <div className="w-full bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 py-3 flex items-center justify-between z-20">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-orange-500 to-amber-500 flex items-center justify-center text-white shadow-lg shadow-orange-500/20">
              <Camera size={20} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-white font-bold text-base sm:text-lg tracking-tight">Live Camera Vision</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-green-500/20 text-green-400 border border-green-500/30 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></span>
                  Gemini Live
                </span>
              </div>
              <p className="text-slate-400 text-xs hidden sm:block">
                Camera mein koi bhi chij dikhao aur pucho — jaise "Yeh kya hai?" ya "Kaun sa phone hai?"
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Upload Photo Button */}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="p-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors border border-slate-700/60 flex items-center gap-1 text-xs"
              title="Photo / Gallery se upload karein"
            >
              <Upload size={18} />
              <span className="hidden md:inline">Photo</span>
            </button>

            {/* Flip Camera */}
            <button
              onClick={flipCamera}
              className="p-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors border border-slate-700/60"
              title="Camera switch karein (Front / Back)"
            >
              <RefreshCw size={18} />
            </button>

            {/* Mute Voice Toggle */}
            <button
              onClick={() => {
                setIsMuted(!isMuted);
                if (!isMuted && window.speechSynthesis) window.speechSynthesis.cancel();
              }}
              className={cn(
                "p-2.5 rounded-xl transition-colors border",
                isMuted 
                  ? "bg-red-500/20 text-red-400 border-red-500/30 hover:bg-red-500/30" 
                  : "bg-slate-800 text-slate-300 border-slate-700/60 hover:text-white hover:bg-slate-700"
              )}
              title={isMuted ? "Awaaz chalu karein" : "Awaaz band karein"}
            >
              {isMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
            </button>

            {/* Fullscreen Toggle */}
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors border border-slate-700/60 hidden sm:flex"
              title="Fullscreen"
            >
              {isFullscreen ? <Minimize2 size={18} /> : <Maximize2 size={18} />}
            </button>

            {/* Close */}
            <button
              onClick={handleSaveAndClose}
              className="p-2.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-red-600 transition-all border border-slate-700/60 ml-1"
              title="Close"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* MAIN VIEWFINDER & OVERLAY AREA */}
        <div className="flex-1 relative bg-black flex flex-col overflow-hidden">
          {/* CAMERA FEED */}
          <div className="absolute inset-0 w-full h-full flex items-center justify-center overflow-hidden">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className={cn(
                "w-full h-full object-cover transition-opacity duration-300",
                facingMode === 'user' && "transform -scale-x-100",
                isCameraActive && !uploadedImage ? "opacity-100" : "opacity-0"
              )}
            />

            {/* Display uploaded photo if user uploaded one */}
            {uploadedImage && (
              <div className="absolute inset-0 z-10 flex items-center justify-center bg-black">
                <img src={uploadedImage} alt="Uploaded Frame" className="w-full h-full object-contain" />
                <button
                  type="button"
                  onClick={() => { setUploadedImage(null); startCamera(); }}
                  className="absolute top-4 left-4 z-20 px-3 py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-xs font-semibold text-white border border-white/20 backdrop-blur-md flex items-center gap-1.5 shadow-lg"
                >
                  <Camera size={14} />
                  Live Camera par wapas jayein
                </button>
              </div>
            )}

            {/* Shutter flash effect */}
            {capturedFlash && (
              <div className="absolute inset-0 bg-white opacity-80 z-30 pointer-events-none transition-opacity duration-150" />
            )}

            {/* Camera Error / Fallback state */}
            {cameraError && !uploadedImage && (
              <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-slate-950/95 z-20 overflow-y-auto">
                <div className="w-16 h-16 rounded-full bg-orange-500/20 text-orange-400 flex items-center justify-center mb-4 border border-orange-500/30">
                  <Camera size={32} />
                </div>
                <h3 className="text-white font-bold text-lg mb-2">Camera Access Notice</h3>
                <p className="text-slate-300 text-sm max-w-md mb-6 leading-relaxed">
                  {cameraError}
                </p>

                <div className="flex flex-col sm:flex-row gap-3 w-full max-w-sm">
                  <button
                    onClick={() => startCamera()}
                    className="flex-1 px-4 py-3 bg-orange-600 hover:bg-orange-700 text-white font-semibold rounded-xl transition-all shadow-lg shadow-orange-600/30 text-sm flex items-center justify-center gap-2"
                  >
                    <RefreshCw size={16} />
                    Dubara Allow Karein
                  </button>

                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="flex-1 px-4 py-3 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-xl transition-all border border-slate-700 text-sm flex items-center justify-center gap-2"
                  >
                    <Upload size={16} />
                    Photo Upload Karein
                  </button>
                </div>

                <button
                  onClick={() => window.open(window.location.href, '_blank')}
                  className="mt-4 text-xs text-orange-400 hover:text-orange-300 font-medium flex items-center gap-1.5 underline underline-offset-4"
                >
                  <ExternalLink size={13} />
                  New Tab Mein Kholein (Camera Auto-Allow)
                </button>
              </div>
            )}

            {!isCameraActive && !cameraError && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950 z-10 text-slate-400">
                <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin mb-4" />
                <p className="text-sm font-medium text-slate-300">Live Camera shuru ho raha hai...</p>
              </div>
            )}

            {/* AR Scanning Target Reticle (Gemini Vision Style) */}
            {isCameraActive && (
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center z-10">
                <div className="w-64 h-64 sm:w-80 sm:h-80 border-2 border-dashed border-orange-500/40 rounded-3xl relative flex items-center justify-center">
                  {/* Corner brackets */}
                  <div className="absolute -top-1 -left-1 w-6 h-6 border-t-4 border-l-4 border-orange-500 rounded-tl-xl" />
                  <div className="absolute -top-1 -right-1 w-6 h-6 border-t-4 border-r-4 border-orange-500 rounded-tr-xl" />
                  <div className="absolute -bottom-1 -left-1 w-6 h-6 border-b-4 border-l-4 border-orange-500 rounded-bl-xl" />
                  <div className="absolute -bottom-1 -right-1 w-6 h-6 border-b-4 border-r-4 border-orange-500 rounded-br-xl" />

                  {/* Scanning beam animation */}
                  {isThinking && (
                    <div className="absolute inset-x-2 h-1 bg-gradient-to-r from-transparent via-orange-400 to-transparent shadow-lg shadow-orange-500 animate-pulse animate-bounce" />
                  )}

                  <div className="text-center px-4 py-1.5 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-slate-200 text-xs font-medium tracking-wide flex items-center gap-1.5 shadow-lg">
                    <Sparkles size={13} className="text-orange-400 animate-spin" />
                    <span>{isThinking ? "AI dekh raha hai aur soch raha hai..." : "Object ko frame mein layein"}</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* AI LIVE SPEECH / LATEST RESULT OVERLAY (Floating Card) */}
          <div className="absolute top-4 inset-x-3 sm:inset-x-6 z-20 pointer-events-auto">
            {(currentAiSpeech || isThinking || transcript) && (
              <div className="bg-slate-900/90 backdrop-blur-xl border border-slate-700/80 rounded-2xl p-4 shadow-2xl animate-fade-in max-w-2xl mx-auto">
                {/* Status indicator */}
                <div className="flex items-center justify-between pb-2 border-b border-slate-800/80 mb-2">
                  <div className="flex items-center gap-2">
                    <div className={cn(
                      "w-2.5 h-2.5 rounded-full animate-pulse",
                      isThinking ? "bg-amber-400" : isSpeaking ? "bg-orange-500" : "bg-green-400"
                    )} />
                    <span className="text-xs font-semibold uppercase tracking-wider text-slate-300">
                      {isThinking ? "Analyzing Camera..." : isSpeaking ? "India GPT bol rahi hai..." : "AI Response"}
                    </span>
                  </div>
                  {currentAiSpeech && (
                    <button
                      onClick={() => speakVoiceReply(currentAiSpeech)}
                      className="text-xs text-orange-400 hover:text-orange-300 flex items-center gap-1 font-medium transition-colors"
                      title="Dubara sunein"
                    >
                      <Volume2 size={14} /> Dubara bole
                    </button>
                  )}
                </div>

                {transcript && !currentAiSpeech && (
                  <p className="text-slate-300 text-sm italic mb-1">
                    "{transcript}"
                  </p>
                )}

                {currentAiSpeech ? (
                  <p className="text-white text-sm sm:text-base font-medium leading-relaxed">
                    {currentAiSpeech}
                  </p>
                ) : isThinking ? (
                  <div className="flex items-center gap-2 text-slate-400 text-sm py-1">
                    <div className="w-4 h-4 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" />
                    <span>Camera view dekh kar jawab taiyaar ho raha hai...</span>
                  </div>
                ) : null}
              </div>
            )}
          </div>

          {/* PREVIOUS EXCHANGES PILL (If any) */}
          {exchanges.length > 1 && (
            <div className="absolute left-3 top-28 z-20 hidden md:flex flex-col gap-2 max-w-[260px] pointer-events-auto">
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 bg-black/60 backdrop-blur-md px-3 py-1 rounded-lg border border-white/10 w-fit">
                Pichle Sawaal ({exchanges.length})
              </div>
              <div className="max-h-52 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
                {exchanges.slice(1, 4).map(ex => (
                  <div key={ex.id} className="bg-slate-900/80 backdrop-blur-md p-2.5 rounded-xl border border-slate-800 text-xs text-slate-300 shadow-md">
                    <p className="font-semibold text-orange-400 truncate">Q: {ex.userQuestion}</p>
                    <p className="text-slate-300 line-clamp-2 mt-0.5">{ex.aiResponse}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* BOTTOM INTERACTION BAR */}
        <div className="w-full bg-slate-900/95 backdrop-blur-xl border-t border-slate-800 px-3 sm:px-6 py-3.5 z-20 flex flex-col gap-2.5">
          {/* QUICK QUESTIONS (Chips) */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            <span className="text-xs font-semibold text-slate-400 whitespace-nowrap flex items-center gap-1">
              <Sparkles size={13} className="text-orange-400" /> Pucho:
            </span>
            {quickPrompts.map((item, idx) => (
              <button
                key={idx}
                disabled={isThinking}
                onClick={() => handleCaptureAndAsk(item.prompt)}
                className="whitespace-nowrap px-3 py-1.5 bg-slate-800 hover:bg-orange-600/20 hover:border-orange-500/50 text-slate-200 hover:text-white rounded-full text-xs font-medium border border-slate-700 transition-all disabled:opacity-50 active:scale-95 flex-shrink-0"
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* CONTROLS: MIC BUTTON, TEXT INPUT, SEND */}
          <form onSubmit={handleManualSubmit} className="flex items-center gap-2 w-full">
            {/* BIG VOICE BUTTON */}
            <button
              type="button"
              onClick={toggleVoiceListening}
              disabled={isThinking}
              className={cn(
                "p-3.5 rounded-2xl flex items-center justify-center transition-all shadow-lg flex-shrink-0 active:scale-95",
                isListening 
                  ? "bg-red-600 text-white animate-pulse shadow-red-600/40 ring-4 ring-red-500/30" 
                  : "bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white shadow-orange-600/25"
              )}
              title={isListening ? "Listening... bolna band karein" : "Bol kar pucho (Voice Mic)"}
            >
              {isListening ? <MicOff size={22} /> : <Mic size={22} />}
            </button>

            {/* DIRECT CAPTURE & ASK BUTTON */}
            <button
              type="button"
              disabled={isThinking}
              onClick={() => handleCaptureAndAsk("Yeh kya hai? Dhyan se dekhkar details batao.")}
              className="hidden sm:flex items-center gap-1.5 px-3.5 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold transition-all shadow-sm active:scale-95 flex-shrink-0"
              title="Camera view scan karein"
            >
              <Eye size={16} className="text-orange-400" />
              <span>Yeh Kya Hai?</span>
            </button>

            {/* TEXT INPUT */}
            <div className="flex-1 relative flex items-center bg-slate-800/90 border border-slate-700/80 rounded-2xl px-3 py-1 focus-within:border-orange-500 transition-all">
              <input
                type="text"
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                placeholder={isListening ? "Aapki awaaz sun raha hai..." : "Camera dikhakar yahan likhein (e.g. Kaun sa phone hai?)..."}
                disabled={isThinking}
                className="w-full bg-transparent border-none outline-none py-2 text-sm text-white placeholder:text-slate-400"
              />
              {textInput.trim() && (
                <button
                  type="submit"
                  disabled={isThinking}
                  className="p-1.5 bg-orange-600 hover:bg-orange-500 text-white rounded-xl transition-all shadow-sm ml-1"
                >
                  <Send size={16} />
                </button>
              )}
            </div>

            {/* FINISH / SAVE TO CHAT BUTTON */}
            {chatHistory.length > 0 && (
              <button
                type="button"
                onClick={handleSaveAndClose}
                className="px-3.5 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs font-semibold transition-all flex items-center gap-1.5 flex-shrink-0"
                title="Chat mein continue karein"
              >
                <span>Chat Mein Le Jao</span>
                <ArrowRight size={14} />
              </button>
            )}
          </form>
        </div>
      </div>
    </div>
  );
}
