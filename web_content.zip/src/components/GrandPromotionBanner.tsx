import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Trophy,
  Sparkles,
  Car,
  Plane,
  Gift,
  ArrowRight,
  CheckCircle2,
  X,
  Users,
  Calendar,
  Flame,
  Ticket,
  ChevronRight,
  ShieldCheck,
  ShoppingCart,
  Send,
} from 'lucide-react';
import { Language, UserProfile } from '../types';
import { playKeyTap, playSuccessChime } from '../utils/audio';

// Reference to the generated Range Rover & Dubai ticket artwork
import rangeRoverDubaiImg from '../assets/images/range_rover_dubai_1789732067443.jpg';

interface GrandPromotionBannerProps {
  language: Language;
  user: UserProfile;
  onNavigateToWalletBuy?: () => void;
  onNavigateToSendMoney?: () => void;
}

export default function GrandPromotionBanner({
  language,
  user,
  onNavigateToWalletBuy,
  onNavigateToSendMoney,
}: GrandPromotionBannerProps) {
  const isSw = language === 'sw';
  const [showModal, setShowModal] = useState(false);

  // User's current competition tickets and rank
  const userTickets = 18;
  const userRank = 2;

  const leaderboard = [
    { rank: 1, name: 'Mama Baraka', region: 'Mufindi, Iringa', tickets: 42, badge: '🥇' },
    { rank: 2, name: `${user.name} (Wewe)`, region: `${user.region}`, tickets: userTickets, badge: '🥈' },
    { rank: 3, name: 'David Mwita', region: 'Kilolo, Iringa', tickets: 16, badge: '🥉' },
    { rank: 4, name: 'Amina Rashid', region: 'Monduli, Arusha', tickets: 14, badge: '⭐' },
    { rank: 5, name: 'Mzee Omari', region: 'Lushoto, Tanga', tickets: 11, badge: '⭐' },
  ];

  return (
    <>
      {/* Banner Card */}
      <div
        id="grand-promotion-banner"
        className="rounded-3xl p-4 sm:p-5 text-[#F7F4E9] shadow-xl relative overflow-hidden transition-all border border-amber-400/40"
        style={{
          background:
            'linear-gradient(135deg, #1C3325 0%, #2A4837 40%, #5E461A 100%)',
        }}
      >
        {/* Subtle decorative glow */}
        <div className="absolute top-0 right-0 w-44 h-44 bg-amber-400/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row items-center gap-4">
          {/* Promo Visual Image */}
          <div className="w-full sm:w-44 h-28 sm:h-32 rounded-2xl overflow-hidden shadow-lg border border-amber-300/30 flex-shrink-0 relative group">
            <img
              src={rangeRoverDubaiImg}
              alt="Range Rover & Dubai Prize"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-md text-amber-300 text-[10px] font-bold flex items-center gap-1">
              <Trophy className="w-3 h-3 text-amber-400" />
              <span>{isSw ? 'Droo Kubwa' : 'Mega Prize'}</span>
            </div>
          </div>

          {/* Text Content */}
          <div className="flex-1 min-w-0 text-center sm:text-left">
            <div className="flex items-center justify-center sm:justify-start gap-1.5 text-amber-300 text-[11px] font-bold uppercase tracking-wider mb-1">
              <Flame className="w-3.5 h-3.5 text-orange-400 animate-pulse" />
              <span>
                {isSw
                  ? 'Ofa Kabambe ya Mkulima Hodari 2026'
                  : 'Ardhi Champion Farmer Grand Promo'}
              </span>
            </div>

            <h3 className="font-display text-lg sm:text-xl font-bold leading-snug text-white">
              {isSw
                ? 'Shinda Range Rover Mpya & Tiketi ya Kwenda Dubai! 🚗✈️'
                : 'Win a New Range Rover Defender & Dubai Trip! 🚗✈️'}
            </h3>

            <p className="text-xs text-amber-100/85 mt-1 leading-relaxed line-clamp-2">
              {isSw
                ? 'Fanya miamala kwenye pochi au agiza pembejeo za kilimo ujikusanyie tiketi za bahati nasibu. Kadiri unavyoagiza ndivyo nafasi inavyoongezeka!'
                : 'Order farm inputs or transfer via your Ardhi wallet to collect raffle tickets. The more you transact, the closer you get to Dubai!'}
            </p>

            {/* Quick Stats & Trigger */}
            <div className="mt-3 flex items-center justify-between gap-2 flex-wrap pt-2 border-t border-white/15">
              <div className="flex items-center gap-2 text-xs">
                <span className="px-2.5 py-1 rounded-full bg-amber-400/20 text-amber-200 border border-amber-400/30 font-bold flex items-center gap-1 text-[11px]">
                  <Ticket className="w-3.5 h-3.5" />
                  <span>{userTickets} {isSw ? 'Tiketi Zako' : 'Your Tickets'}</span>
                </span>
                <span className="text-[11px] text-emerald-200 font-medium">
                  {isSw ? `Nafasi ya #${userRank} Morogoro` : `Rank #${userRank} Morogoro`}
                </span>
              </div>

              <button
                id="view-grand-promo-details-btn"
                onClick={() => {
                  playKeyTap();
                  setShowModal(true);
                }}
                className="py-1.5 px-3.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#1C3325] font-bold text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition-all cursor-pointer"
              >
                <span>{isSw ? 'Tazama Nafasi & Vigezo' : 'View Standings & Rules'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* DETAILED PROMOTION MODAL */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-sm overflow-y-auto">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-md bg-[var(--paper)] rounded-3xl p-5 border border-[var(--line)] shadow-2xl relative my-6 text-[var(--ink)]"
            >
              <button
                onClick={() => setShowModal(false)}
                className="absolute top-4 right-4 p-1.5 rounded-full text-[var(--ink-soft)] hover:bg-[var(--bg)]"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Modal Hero Banner */}
              <div className="w-full h-36 rounded-2xl overflow-hidden relative mb-3.5 border border-amber-300/40">
                <img
                  src={rangeRoverDubaiImg}
                  alt="Range Rover Defender and Dubai"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-3 text-white">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-amber-300">
                    {isSw ? 'Tuzo Kuu ya Mwaka 2026' : 'Grand Annual Prize 2026'}
                  </span>
                  <h3 className="font-display text-base sm:text-lg font-bold">
                    {isSw
                      ? 'Range Rover Defender Mpya + Tiketi ya Dubai'
                      : 'Brand New Range Rover Defender + Dubai Ticket'}
                  </h3>
                </div>
              </div>

              {/* User Progress Pill */}
              <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/25 flex items-center justify-between mb-3.5 text-xs">
                <div>
                  <div className="font-bold text-[var(--ink)] flex items-center gap-1.5">
                    <Trophy className="w-4 h-4 text-amber-500" />
                    <span>{user.name}</span>
                  </div>
                  <div className="text-[10px] text-[var(--ink-soft)] mt-0.5">
                    {isSw
                      ? 'Una jumla ya tiketi 18 kwenye droo'
                      : 'You hold 18 entry tickets in the grand draw'}
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-display font-bold text-lg text-amber-600 dark:text-amber-400">
                    {userTickets}
                  </span>
                  <span className="text-[10px] text-[var(--ink-soft)] block uppercase">
                    {isSw ? 'Tiketi' : 'Tickets'}
                  </span>
                </div>
              </div>

              {/* How to Earn Tickets */}
              <div className="space-y-2 mb-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[var(--ink-soft)]">
                  {isSw ? 'Jinsi ya Kupata Tiketi Nyingi:' : 'How to Collect More Tickets:'}
                </h4>

                <div className="grid grid-cols-1 gap-2 text-xs">
                  <div className="p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] flex items-start gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 flex items-center justify-center font-bold flex-shrink-0">
                      +3
                    </div>
                    <div>
                      <div className="font-semibold text-[var(--ink)]">
                        {isSw ? 'Agiza Pembejeo za Kilimo' : 'Order Farm Inputs'}
                      </div>
                      <div className="text-[11px] text-[var(--ink-soft)]">
                        {isSw
                          ? 'Kila ununuzi wa mbegu, mbolea au vifaa unapata tiketi 3 za papo hapo.'
                          : 'Receive 3 instant raffle tickets with each certified seed or fertilizer purchase.'}
                      </div>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] flex items-start gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-amber-500/15 text-amber-700 dark:text-amber-300 flex items-center justify-center font-bold flex-shrink-0">
                      +1
                    </div>
                    <div>
                      <div className="font-semibold text-[var(--ink)]">
                        {isSw ? 'Miamala ya Pochi (Tsh 20,000+)' : 'Wallet Transactions (Tsh 20k+)'}
                      </div>
                      <div className="text-[11px] text-[var(--ink-soft)]">
                        {isSw
                          ? 'Kutuma pesa, kulipia vibarua, au kupokea mauzo ya mavuno.'
                          : 'Send money to helpers, pay suppliers, or receive crop payouts.'}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Regional Leaderboard */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-[var(--ink-soft)]">
                    {isSw ? 'Wanaoongoza Kanda ya Mashariki:' : 'Eastern Region Leaderboard:'}
                  </h4>
                  <span className="text-[10px] text-[var(--forest)] font-medium">
                    {isSw ? 'Inasasishwa kila saa' : 'Updated hourly'}
                  </span>
                </div>

                <div className="space-y-1.5 bg-[var(--bg)] p-2.5 rounded-2xl border border-[var(--line)] text-xs">
                  {leaderboard.map((item) => (
                    <div
                      key={item.rank}
                      className={`p-2 rounded-xl flex items-center justify-between ${
                        item.rank === 2
                          ? 'bg-[var(--forest)]/10 font-bold border border-[var(--forest)]/20'
                          : 'hover:bg-[var(--paper)]'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-sm">{item.badge}</span>
                        <div>
                          <div className="font-semibold text-[var(--ink)]">{item.name}</div>
                          <div className="text-[10px] text-[var(--ink-soft)]">{item.region}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="font-display font-bold text-xs text-[var(--forest)]">
                          {item.tickets}
                        </span>
                        <span className="text-[9px] text-[var(--ink-soft)] block">
                          {isSw ? 'tiketi' : 'tickets'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-[var(--line)]">
                {onNavigateToWalletBuy && (
                  <button
                    onClick={() => {
                      setShowModal(false);
                      onNavigateToWalletBuy();
                    }}
                    className="py-2.5 px-3 rounded-xl bg-[var(--forest)] hover:bg-[var(--forest-dark)] text-[#F7F4E9] font-bold text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all cursor-pointer"
                  >
                    <ShoppingCart className="w-3.5 h-3.5" />
                    <span>{isSw ? 'Agiza Pembejeo' : 'Order Inputs'}</span>
                  </button>
                )}

                {onNavigateToSendMoney && (
                  <button
                    onClick={() => {
                      setShowModal(false);
                      onNavigateToSendMoney();
                    }}
                    className="py-2.5 px-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-[#1C3325] font-bold text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isSw ? 'Tuma Pesa Pochi' : 'Transfer Funds'}</span>
                  </button>
                )}
              </div>

              {/* Terms footer */}
              <div className="mt-3 text-center text-[10px] text-[var(--ink-soft)] opacity-80 flex items-center justify-center gap-1">
                <ShieldCheck className="w-3 h-3 text-[var(--forest)]" />
                <span>
                  {isSw
                    ? 'Droo itafanyika 31 Desemba 2026. Imeidhinishwa kisheria.'
                    : 'Grand draw takes place 31 Dec 2026. Regulated and audited.'}
                </span>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
