import React, { useState } from 'react';
import { Search, Play, Pause, SkipForward, Music, Radio, Volume2, RadioReceiver, ExternalLink, Disc } from 'lucide-react';

interface Track {
  id: string;
  title: string;
  artist: string;
  duration: string;
  thumbnail: string;
}

export const YouTubeMusicPlayer: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [tracks, setTracks] = useState<Track[]>([
    { id: 'dQw4w9WgXcQ', title: 'Cyberpunk Synthwave 2077 (Radio Edit)', artist: 'Sonó Records', duration: '3:45', thumbnail: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&q=80' },
    { id: 'jfKfPfyJRdk', title: 'Lo-Fi Chill Beats to Transmit To', artist: 'Radio Underground', duration: '2:50', thumbnail: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&q=80' },
    { id: '5qap5aO4i9A', title: 'Deep Space Frequency 09', artist: 'Signal Echo', duration: '4:12', thumbnail: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&q=80' }
  ]);
  const [currentTrack, setCurrentTrack] = useState<Track | null>(tracks[0]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [loading, setLoading] = useState(false);
  const [activeEmbedUrl, setActiveEmbedUrl] = useState<string | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    setLoading(true);
    try {
      const res = await fetch('/api/music/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: searchQuery })
      });
      const data = await res.json();
      if (data.tracks && data.tracks.length > 0) {
        setTracks(data.tracks);
      }
    } catch (err) {
      console.error('Error searching YouTube Music:', err);
    } finally {
      setLoading(false);
    }
  };

  const playTrack = (track: Track) => {
    setCurrentTrack(track);
    setIsPlaying(true);
    setActiveEmbedUrl(`https://www.youtube.com/embed/${track.id}?autoplay=1`);
  };

  return (
    <div className="space-y-6">
      <div className="bg-[#0f0728]/80 backdrop-blur-xl border border-[#ff0055]/30 rounded-2xl p-6 shadow-[0_0_30px_rgba(255,0,85,0.15)]">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-[#ff0055]/20 rounded-xl border border-[#ff0055]/50 text-[#ff0055]">
              <RadioReceiver className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white tracking-wider">YouTube Music & Audio Browser</h2>
              <p className="text-xs text-gray-400">Transmisión de música, exploración de pistas en vivo y búsqueda en la web</p>
            </div>
          </div>
          <div className="flex items-center gap-2 px-3 py-1 bg-black/40 border border-[#ff0055]/40 rounded-full text-xs font-mono text-[#ff0055]">
            <span className="w-2 h-2 rounded-full bg-[#ff0055] animate-pulse"></span>
            YT-MUSIC ACTIVE
          </div>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="flex gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar artista, álbum o canción en YouTube Music..."
              className="w-full bg-black/60 border border-[#ff0055]/40 rounded-xl py-3 pl-11 pr-4 text-sm text-white placeholder-gray-500 focus:outline-none focus:border-[#ff0055] transition shadow-[inset_0_0_15px_rgba(255,0,85,0.1)]"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-3 bg-gradient-to-r from-[#ff0055] to-[#9d00ff] text-white font-black text-xs uppercase tracking-widest rounded-xl shadow-[0_0_20px_rgba(255,0,85,0.4)] hover:opacity-95 transition flex items-center gap-2"
          >
            {loading ? <Disc className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
            Buscar
          </button>
        </form>

        {/* Now Playing Bar / Embedded Player */}
        {currentTrack && (
          <div className="bg-gradient-to-r from-[#1a0b36] to-[#0d041a] border border-[#ff0055]/40 rounded-2xl p-4 mb-6 flex flex-col md:flex-row items-center gap-4 shadow-[0_0_25px_rgba(255,0,85,0.2)]">
            <div className="relative w-20 h-20 rounded-xl overflow-hidden border border-[#ff0055]/50 flex-shrink-0">
              <img src={currentTrack.thumbnail} alt={currentTrack.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                <Disc className={`w-8 h-8 text-[#ff0055] ${isPlaying ? 'animate-spin' : ''}`} />
              </div>
            </div>
            <div className="flex-1 text-center md:text-left">
              <div className="text-[10px] uppercase font-mono tracking-widest text-[#ff0055] mb-1">Reproduciendo en Sonó Radio Stream</div>
              <h3 className="text-white font-bold text-base line-clamp-1">{currentTrack.title}</h3>
              <p className="text-gray-400 text-xs">{currentTrack.artist} • {currentTrack.duration}</p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="p-3 bg-[#ff0055] text-white rounded-xl shadow-[0_0_15px_rgba(255,0,85,0.5)] hover:scale-105 transition"
              >
                {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              </button>
            </div>
          </div>
        )}

        {/* Active YouTube Embed / Audio Container */}
        {activeEmbedUrl && (
          <div className="mb-6 rounded-2xl overflow-hidden border border-[#ff0055]/30 bg-black aspect-video max-h-[300px]">
            <iframe
              src={activeEmbedUrl}
              title="YouTube Music Player"
              className="w-full h-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
          </div>
        )}

        {/* Tracks Grid */}
        <h4 className="text-xs font-mono text-gray-400 uppercase tracking-widest mb-4">Pistas Disponibles ({tracks.length})</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {tracks.map((track) => (
            <div
              key={track.id}
              onClick={() => playTrack(track)}
              className={`bg-black/50 border rounded-2xl p-4 cursor-pointer transition-all transform hover:-translate-y-1 group ${currentTrack?.id === track.id ? 'border-[#ff0055] shadow-[0_0_20px_rgba(255,0,85,0.3)] bg-[#ff0055]/10' : 'border-[#9d00ff]/30 hover:border-[#ff0055]/60'}`}
            >
              <div className="relative aspect-video rounded-xl overflow-hidden mb-3">
                <img src={track.thumbnail} alt={track.title} className="w-full h-full object-cover group-hover:scale-110 transition duration-500" referrerPolicy="no-referrer" />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                  <span className="px-3 py-1.5 bg-[#ff0055] text-white font-black text-xs rounded-lg shadow-lg flex items-center gap-1.5">
                    <Play className="w-3.5 h-3.5 fill-white" /> Reproducir
                  </span>
                </div>
              </div>
              <h5 className="text-white font-bold text-sm line-clamp-1 mb-1">{track.title}</h5>
              <div className="flex justify-between items-center text-xs text-gray-400">
                <span>{track.artist}</span>
                <span className="font-mono text-[#ff0055]">{track.duration}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
