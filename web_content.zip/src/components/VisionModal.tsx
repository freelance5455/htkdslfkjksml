import React, { useRef, useState, useEffect } from 'react';
import { Camera, RefreshCw, X, Sparkles, AlertCircle, Scan, Upload } from 'lucide-react';
import { safeFetchJson } from '../services/apiClient';

interface VisionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAnalysisResult: (text: string) => void;
}

export const VisionModal: React.FC<VisionModalProps> = ({
  isOpen,
  onClose,
  onAnalysisResult,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [stream, setStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisText, setAnalysisText] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [customPrompt, setCustomPrompt] = useState('');

  // Start camera stream when modal opens
  useEffect(() => {
    if (isOpen && !capturedImage) {
      startCamera(facingMode);
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, facingMode]);

  const startCamera = async (mode: 'environment' | 'user') => {
    setErrorMsg(null);
    try {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }

      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: mode,
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      });

      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err: any) {
      console.warn('Camera access denied or unavailable:', err);
      setErrorMsg('Camera permission denied or camera device not accessible on this device.');
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const toggleCameraFacing = () => {
    const nextMode = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextMode);
  };

  const handleCaptureSnapshot = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current || document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;

    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      setCapturedImage(dataUrl);
      stopCamera();
      // Auto analyze captured frame
      analyzeImage(dataUrl);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        setCapturedImage(result);
        stopCamera();
        analyzeImage(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const analyzeImage = async (imageData: string, promptOverride?: string) => {
    setIsAnalyzing(true);
    setAnalysisText(null);
    setErrorMsg(null);

    const prompt = promptOverride || customPrompt || 'Recognize this object, identify product brand, model, visible text, approximate price in India/world, and technical specifications.';

    try {
      const data = await safeFetchJson<{ analysis: string }>('/api/gemini/vision', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: imageData,
          prompt,
        }),
      });

      setAnalysisText(data.analysis);
      onAnalysisResult(data.analysis);
    } catch (err: any) {
      console.error('Vision analysis error:', err);
      setErrorMsg(err.message || 'Vision inspection failed. Please check internet connection.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleReset = () => {
    setCapturedImage(null);
    setAnalysisText(null);
    setErrorMsg(null);
    startCamera(facingMode);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-gray-950/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg bg-gray-900 border border-cyan-500/50 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-gray-950/90 border-b border-cyan-500/30">
          <div className="flex items-center gap-2">
            <Scan className="w-5 h-5 text-cyan-400 animate-pulse" />
            <h3 className="font-tech text-base tracking-wide uppercase text-cyan-200">
              JARVIS VISION CORE // LENS SCANNER
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-cyan-400 hover:bg-cyan-500/20 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Viewport / Camera Preview */}
        <div className="relative bg-black aspect-video sm:aspect-4/3 flex items-center justify-center overflow-hidden">
          {!capturedImage ? (
            <>
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />

              {/* Holographic targeting reticle HUD overlay */}
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                <div className="w-48 h-48 border border-dashed border-cyan-400/50 rounded-2xl relative">
                  <div className="absolute -top-1 -left-1 w-4 h-4 border-t-2 border-l-2 border-cyan-400" />
                  <div className="absolute -top-1 -right-1 w-4 h-4 border-t-2 border-r-2 border-cyan-400" />
                  <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b-2 border-l-2 border-cyan-400" />
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-2 border-r-2 border-cyan-400" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-2 h-2 bg-cyan-400/60 rounded-full animate-ping" />
                  </div>
                </div>
              </div>

              {/* Flip camera control */}
              <button
                onClick={toggleCameraFacing}
                title="Switch Camera (Front/Back)"
                className="absolute top-3 right-3 p-2 bg-gray-950/70 border border-cyan-500/40 text-cyan-300 rounded-full backdrop-blur-sm hover:bg-cyan-500/30"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </>
          ) : (
            <img
              src={capturedImage}
              alt="Snapshot"
              className="w-full h-full object-contain bg-gray-950"
            />
          )}

          {/* Analysis scanning overlay */}
          {isAnalyzing && (
            <div className="absolute inset-0 bg-gray-950/70 backdrop-blur-xs flex flex-col items-center justify-center gap-3">
              <div className="w-12 h-12 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
              <div className="text-center">
                <p className="font-tech text-cyan-300 text-sm tracking-wider uppercase">
                  Analyzing Optical Feed...
                </p>
                <p className="text-xs text-cyan-400/70">
                  Identifying product models, specs & market value
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Error message */}
        {errorMsg && (
          <div className="mx-4 mt-3 p-2.5 bg-red-950/50 border border-red-500/40 rounded-xl flex items-center gap-2 text-xs text-red-200">
            <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
            <span className="flex-1">{errorMsg}</span>
          </div>
        )}

        {/* Results Scroll Area */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 max-h-60 text-sm">
          {analysisText ? (
            <div className="p-3 rounded-xl bg-gray-950/70 border border-cyan-500/30 font-mono-tech text-xs text-cyan-100 whitespace-pre-wrap leading-relaxed">
              {analysisText}
            </div>
          ) : !isAnalyzing && (
            <div className="text-xs text-cyan-300/70 text-center py-2">
              Point your camera at any object, product, barcode, text, or device and tap <span className="text-cyan-200 font-semibold">Inspect Frame</span>.
            </div>
          )}
        </div>

        {/* Footer Action Buttons */}
        <div className="p-3 bg-gray-950/90 border-t border-cyan-500/30 flex items-center gap-2">
          {!capturedImage ? (
            <>
              <button
                onClick={handleCaptureSnapshot}
                className="flex-1 py-2.5 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-gray-950 font-tech font-bold tracking-wider uppercase text-sm flex items-center justify-center gap-2 transition-colors glow-cyan-sm cursor-pointer"
              >
                <Camera className="w-4 h-4" />
                Inspect Frame
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleFileUpload}
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                title="Upload Photo"
                className="p-2.5 rounded-xl border border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/20 transition-colors"
              >
                <Upload className="w-4 h-4" />
              </button>
            </>
          ) : (
            <>
              <button
                onClick={handleReset}
                className="flex-1 py-2.5 px-4 rounded-xl border border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/20 font-tech uppercase text-xs transition-colors"
              >
                Scan Another
              </button>
              <button
                onClick={() => analyzeImage(capturedImage)}
                disabled={isAnalyzing}
                className="flex-1 py-2.5 px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-gray-950 font-tech font-bold uppercase text-xs flex items-center justify-center gap-1 transition-colors"
              >
                <Sparkles className="w-4 h-4" />
                Re-Analyze
              </button>
            </>
          )}
        </div>
      </div>
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
};
