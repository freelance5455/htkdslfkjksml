import React, { useState, useEffect, useRef } from "react";
import {
  Mic,
  Square,
  Play,
  Pause,
  Trash2,
  Check,
  Upload,
  AlertCircle,
  RefreshCw,
  Sparkles,
  FileText,
  Volume2,
  VolumeX,
  Gauge,
  Edit3
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { AudioNote } from "../types";

interface AudioRecorderProps {
  onSaveAudio: (audioNote: AudioNote) => void;
  onInsertTranscriptToNote?: (transcript: string) => void;
  onClose: () => void;
}

function getSupportedMimeType(): string {
  if (typeof MediaRecorder === "undefined" || !MediaRecorder.isTypeSupported) {
    return "";
  }
  const types = [
    "audio/webm;codecs=opus",
    "audio/webm",
    "audio/mp4",
    "audio/aac",
    "audio/ogg;codecs=opus",
    "audio/ogg",
  ];
  for (const t of types) {
    if (MediaRecorder.isTypeSupported(t)) {
      return t;
    }
  }
  return "";
}

export const AudioRecorder: React.FC<AudioRecorderProps> = ({
  onSaveAudio,
  onInsertTranscriptToNote,
  onClose,
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isPermissionDenied, setIsPermissionDenied] = useState(false);
  
  // Audio Custom Name
  const [customAudioName, setCustomAudioName] = useState<string>(
    `Ses Notu ${new Date().toLocaleDateString("tr-TR")} ${new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" })}`
  );

  // Live Speech Recognition & AI Transcribe State
  const [liveTranscript, setLiveTranscript] = useState<string>("");
  const [isTranscribingWithAi, setIsTranscribingWithAi] = useState(false);
  const [aiTranscribedText, setAiTranscribedText] = useState<string | null>(null);
  const [audioLevels, setAudioLevels] = useState<number[]>([15, 25, 40, 60, 45, 30, 20, 10]);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const activeStreamRef = useRef<MediaStream | null>(null);
  const mimeTypeRef = useRef<string>("");
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const speechRecognitionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Trigger Android & Mobile Haptic Vibration
  const triggerHaptic = (duration = 15) => {
    if (typeof navigator !== "undefined" && "vibrate" in navigator) {
      try {
        navigator.vibrate(duration);
      } catch (e) {}
    }
  };

  // Start Realtime Audio Visualizer
  const setupAudioVisualizer = (stream: MediaStream) => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const audioCtx = new AudioCtx();
      audioContextRef.current = audioCtx;

      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 32;
      source.connect(analyser);
      analyserRef.current = analyser;

      const dataArray = new Uint8Array(analyser.frequencyBinCount);

      const updateLevels = () => {
        if (!analyserRef.current) return;
        analyserRef.current.getByteFrequencyData(dataArray);
        
        // Sample 8 frequency bar heights
        const bars: number[] = [];
        const step = Math.max(1, Math.floor(dataArray.length / 8));
        for (let i = 0; i < 8; i++) {
          const val = dataArray[i * step] || 0;
          const heightPct = Math.max(12, Math.min(100, Math.round((val / 255) * 100)));
          bars.push(heightPct);
        }
        setAudioLevels(bars);
        animationFrameRef.current = requestAnimationFrame(updateLevels);
      };

      updateLevels();
    } catch (err) {
      console.warn("Audio visualizer setup note:", err);
    }
  };

  // Start Realtime Speech Recognition (Web Speech API)
  const startLiveSpeechRecognition = () => {
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) return;

    try {
      const recognition = new SpeechRec();
      recognition.lang = "tr-TR";
      recognition.continuous = true;
      recognition.interimResults = true;

      recognition.onresult = (event: any) => {
        let interim = "";
        let final = "";
        for (let i = 0; i < event.results.length; i++) {
          const trans = event.results[i][0]?.transcript || "";
          if (event.results[i].isFinal) {
            final += trans + " ";
          } else {
            interim += trans;
          }
        }
        setLiveTranscript((final + interim).trim());
      };

      recognition.onerror = () => {};
      recognition.onend = () => {};

      speechRecognitionRef.current = recognition;
      recognition.start();
    } catch (e) {
      console.warn("Live speech recognition not active:", e);
    }
  };

  const stopLiveSpeechRecognition = () => {
    if (speechRecognitionRef.current) {
      try {
        speechRecognitionRef.current.stop();
      } catch (_) {}
      speechRecognitionRef.current = null;
    }
  };

  const startRecording = async () => {
    try {
      triggerHaptic(25);
      setErrorMessage(null);
      setIsPermissionDenied(false);
      setLiveTranscript("");
      setAiTranscribedText(null);

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setErrorMessage("Cihazınızda doğrudan ses kaydı (getUserMedia) desteklenmiyor. Ses dosyası yükleyebilirsiniz.");
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      activeStreamRef.current = stream;
      audioChunksRef.current = [];

      const bestMime = getSupportedMimeType();
      mimeTypeRef.current = bestMime;

      const mediaRecorder = bestMime
        ? new MediaRecorder(stream, { mimeType: bestMime })
        : new MediaRecorder(stream);

      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, {
          type: mimeTypeRef.current || "audio/webm",
        });
        setRecordedBlob(audioBlob);
        const url = URL.createObjectURL(audioBlob);
        setAudioUrl(url);

        // Stop all tracks cleanly
        if (activeStreamRef.current) {
          activeStreamRef.current.getTracks().forEach((track) => track.stop());
          activeStreamRef.current = null;
        }

        // Clean visualizer
        if (animationFrameRef.current) {
          cancelAnimationFrame(animationFrameRef.current);
          animationFrameRef.current = null;
        }
        if (audioContextRef.current) {
          audioContextRef.current.close().catch(() => {});
          audioContextRef.current = null;
        }
      };

      mediaRecorder.start(250);
      setIsRecording(true);
      setIsPaused(false);
      setRecordingSeconds(0);

      // Start Visualizer & Live Speech
      setupAudioVisualizer(stream);
      startLiveSpeechRecognition();

      timerRef.current = setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      const isDenied =
        err?.name === "NotAllowedError" ||
        err?.name === "PermissionDeniedError" ||
        (typeof err?.message === "string" && err.message.toLowerCase().includes("permission denied"));

      if (isDenied) {
        setIsPermissionDenied(true);
        setErrorMessage(
          "Mikrofon izni verilmedi. Tarayıcı adres çubuğundaki kilit simgesine tıklayıp mikrofona izin verebilir veya doğrudan bir ses dosyası yükleyebilirsiniz."
        );
      } else if (err?.name === "NotFoundError" || err?.name === "DevicesNotFoundError") {
        setErrorMessage("Bağlı bir mikrofon aygıtı bulunamadı. Lütfen mikrofonunuzu bağlayın.");
      } else {
        setErrorMessage("Mikrofona erişilemedi. Lütfen izinleri kontrol edin.");
      }
    }
  };

  const pauseRecording = () => {
    triggerHaptic(15);
    if (mediaRecorderRef.current && isRecording) {
      if (isPaused) {
        mediaRecorderRef.current.resume();
        setIsPaused(false);
        timerRef.current = setInterval(() => {
          setRecordingSeconds((prev) => prev + 1);
        }, 1000);
      } else {
        mediaRecorderRef.current.pause();
        setIsPaused(true);
        if (timerRef.current) clearInterval(timerRef.current);
      }
    }
  };

  const stopRecording = () => {
    triggerHaptic(30);
    stopLiveSpeechRecognition();
    if (mediaRecorderRef.current && isRecording) {
      try {
        if (mediaRecorderRef.current.state !== "inactive") {
          mediaRecorderRef.current.stop();
        }
      } catch (_) {}
      setIsRecording(false);
      setIsPaused(false);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  };

  const togglePlayback = () => {
    triggerHaptic(15);
    if (!audioPlayerRef.current && audioUrl) {
      const audio = new Audio(audioUrl);
      audioPlayerRef.current = audio;
      audio.playbackRate = playbackSpeed;
      audio.onended = () => setIsPlaying(false);
      audio.onerror = () => {
        setIsPlaying(false);
        setErrorMessage("Ses oynatılamadı.");
      };
    }

    if (audioPlayerRef.current) {
      audioPlayerRef.current.playbackRate = playbackSpeed;
      if (isPlaying) {
        audioPlayerRef.current.pause();
        setIsPlaying(false);
      } else {
        audioPlayerRef.current
          .play()
          .then(() => setIsPlaying(true))
          .catch(() => setIsPlaying(false));
      }
    }
  };

  const changePlaybackSpeed = () => {
    triggerHaptic(10);
    const speeds = [1, 1.25, 1.5, 2];
    const nextIdx = (speeds.indexOf(playbackSpeed) + 1) % speeds.length;
    const newSpeed = speeds[nextIdx];
    setPlaybackSpeed(newSpeed);
    if (audioPlayerRef.current) {
      audioPlayerRef.current.playbackRate = newSpeed;
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setErrorMessage(null);
    setIsPermissionDenied(false);

    const reader = new FileReader();
    reader.onload = () => {
      const url = URL.createObjectURL(file);
      setRecordedBlob(file);
      setAudioUrl(url);
      setRecordingSeconds(0);
      setCustomAudioName(file.name.replace(/\.[^/.]+$/, "") || "Yüklenen Ses Dosyası");
    };
    reader.readAsArrayBuffer(file);
  };

  // AI Audio Transcription via Gemini Multimodal API
  const handleAiTranscribe = async () => {
    if (!recordedBlob) return;
    triggerHaptic(20);
    setIsTranscribingWithAi(true);

    const reader = new FileReader();
    reader.onloadend = async () => {
      try {
        const base64Audio = reader.result as string;
        const res = await fetch("/api/gemini/transcribe-audio", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            audioBase64: base64Audio,
            mimeType: recordedBlob.type || mimeTypeRef.current || "audio/webm",
          }),
        });
        const data = await res.json();
        if (data.transcript) {
          setAiTranscribedText(data.transcript);
          triggerHaptic(40);
        } else {
          setAiTranscribedText(liveTranscript || "Ses kaydından net bir metin ayrıştırılamadı.");
        }
      } catch (err) {
        console.error(err);
        setAiTranscribedText(liveTranscript || "Transkripsiyon bağlantı hatası.");
      } finally {
        setIsTranscribingWithAi(false);
      }
    };
    reader.readAsDataURL(recordedBlob);
  };

  // Save Audio to note
  const handleSave = () => {
    if (!recordedBlob) return;
    triggerHaptic(25);

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64Data = reader.result as string;
      const newAudioNote: AudioNote = {
        id: `audio-${Date.now()}`,
        name: customAudioName.trim() || `Ses Notu ${new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" })}`,
        duration: recordingSeconds || 0,
        data: base64Data,
        createdAt: new Date().toISOString(),
      };
      onSaveAudio(newAudioNote);

      // If user has transcribed text and callback exists, append to note
      const transcriptToAppend = aiTranscribedText || liveTranscript;
      if (transcriptToAppend && onInsertTranscriptToNote) {
        onInsertTranscriptToNote(transcriptToAppend);
      }

      onClose();
    };
    reader.readAsDataURL(recordedBlob);
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (audioPlayerRef.current) {
        audioPlayerRef.current.pause();
      }
      if (activeStreamRef.current) {
        activeStreamRef.current.getTracks().forEach((track) => track.stop());
      }
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      if (audioContextRef.current) {
        audioContextRef.current.close().catch(() => {});
      }
      stopLiveSpeechRecognition();
      if (audioUrl) {
        URL.revokeObjectURL(audioUrl);
      }
    };
  }, [audioUrl]);

  const formatSeconds = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m < 10 ? "0" : ""}${m}:${s < 10 ? "0" : ""}${s}`;
  };

  return (
    <div className="bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-800/95 dark:to-slate-900 border border-slate-200 dark:border-slate-700 rounded-3xl p-4 sm:p-5 my-2 shadow-xl animate-in fade-in space-y-3.5">
      <input
        ref={fileInputRef}
        type="file"
        accept="audio/*"
        onChange={handleFileUpload}
        className="hidden"
      />

      {/* Top Header & Status */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div
            className={`w-3.5 h-3.5 rounded-full transition-all ${
              isRecording
                ? isPaused
                  ? "bg-amber-500 ring-4 ring-amber-500/20"
                  : "bg-rose-500 ring-4 ring-rose-500/20 animate-pulse"
                : recordedBlob
                ? "bg-emerald-500 ring-4 ring-emerald-500/20"
                : "bg-blue-500"
            }`}
          />
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <span>
                {isRecording
                  ? isPaused
                    ? "Kayıt Duraklatıldı"
                    : "Canlı Ses Kaydediliyor..."
                  : recordedBlob
                  ? "Ses Kaydı Hazır"
                  : "Sesli Not & Canlı Metne Çevirici"}
              </span>
            </h4>
          </div>
        </div>

        {recordingSeconds > 0 && (
          <div className="flex items-center gap-1.5 bg-slate-200/80 dark:bg-slate-700/80 px-2.5 py-1 rounded-xl">
            <span className="text-xs font-mono font-black text-rose-600 dark:text-rose-400">
              {formatSeconds(recordingSeconds)}
            </span>
          </div>
        )}
      </div>

      {/* Error notification banner */}
      {errorMessage && (
        <div className="flex items-start gap-2 p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 rounded-2xl text-xs text-rose-700 dark:text-rose-300">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="leading-relaxed font-semibold">{errorMessage}</p>
            {isPermissionDenied && (
              <p className="mt-1 text-[11px] text-rose-600/80 dark:text-rose-400/80">
                İpucu: Sayfayı yeni sekmede açarak mikrofon iznini doğrudan tarayıcıdan da verebilirsiniz.
              </p>
            )}
          </div>
        </div>
      )}

      {/* Dynamic Sound Wave Visualizer */}
      {isRecording && (
        <div className="p-3 bg-slate-900/90 dark:bg-slate-950 rounded-2xl border border-slate-700 flex items-center justify-center gap-1.5 h-14 overflow-hidden">
          {audioLevels.map((lvl, idx) => (
            <motion.div
              key={idx}
              animate={{ height: `${isPaused ? 8 : lvl}%` }}
              transition={{ duration: 0.1 }}
              className={`w-1.5 sm:w-2 rounded-full ${
                isPaused ? "bg-amber-500/60" : "bg-gradient-to-t from-rose-500 via-indigo-400 to-teal-400"
              }`}
              style={{ minHeight: "4px", maxHeight: "100%" }}
            />
          ))}
        </div>
      )}

      {/* Live Speech to Text transcription stream (During Recording) */}
      {isRecording && liveTranscript && (
        <div className="p-3 bg-white dark:bg-slate-800/80 rounded-2xl border border-blue-200 dark:border-blue-900/50 space-y-1 animate-in fade-in">
          <div className="flex items-center gap-1.5 text-[10px] font-bold text-blue-600 dark:text-blue-400">
            <Sparkles className="w-3 h-3" />
            <span>Canlı Konuşma Transkripsiyonu:</span>
          </div>
          <p className="text-xs text-slate-800 dark:text-slate-200 font-medium italic line-clamp-3">
            "{liveTranscript}"
          </p>
        </div>
      )}

      {/* Recorded File Title Editor */}
      {recordedBlob && (
        <div className="space-y-2">
          <div className="relative">
            <Edit3 className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={customAudioName}
              onChange={(e) => setCustomAudioName(e.target.value)}
              placeholder="Ses notu başlığı..."
              className="w-full pl-8 pr-3 py-1.5 rounded-xl text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* AI Transcribe Section */}
          <div className="p-3 bg-gradient-to-r from-purple-50 to-indigo-50 dark:from-purple-950/30 dark:to-indigo-950/20 rounded-2xl border border-purple-200/80 dark:border-purple-800/60 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-purple-900 dark:text-purple-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
                <span>Yapay Zeka Sesi Metne Çevirme</span>
              </span>

              {!aiTranscribedText && (
                <button
                  type="button"
                  onClick={handleAiTranscribe}
                  disabled={isTranscribingWithAi}
                  className="px-2.5 py-1 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white rounded-lg text-[11px] font-bold shadow-xs active:scale-95 transition-all cursor-pointer flex items-center gap-1"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>{isTranscribingWithAi ? "Çözümleniyor..." : "Metne Dök"}</span>
                </button>
              )}
            </div>

            {aiTranscribedText ? (
              <div className="space-y-1.5 pt-1">
                <div className="p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-purple-200 dark:border-purple-800 text-xs text-slate-800 dark:text-slate-200 max-h-24 overflow-y-auto">
                  {aiTranscribedText}
                </div>
                <div className="flex items-center justify-between text-[10px] text-purple-700 dark:text-purple-300 font-semibold">
                  <span>✓ Kaydettiğinizde metin nota otomatik eklenecektir</span>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(aiTranscribedText);
                      triggerHaptic(10);
                    }}
                    className="hover:underline cursor-pointer"
                  >
                    Kopyala
                  </button>
                </div>
              </div>
            ) : liveTranscript ? (
              <p className="text-[11px] text-slate-600 dark:text-slate-400 line-clamp-2">
                Canlı önizleme: "{liveTranscript}"
              </p>
            ) : null}
          </div>
        </div>
      )}

      {/* Action Buttons Toolbar */}
      <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
        {!isRecording && !recordedBlob && (
          <>
            <button
              type="button"
              onClick={startRecording}
              className="flex items-center gap-2 px-5 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-2xl text-xs font-bold shadow-md shadow-rose-600/20 active:scale-95 transition-all cursor-pointer"
            >
              {isPermissionDenied ? <RefreshCw className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              <span>{isPermissionDenied ? "İzni Tekrar Dene" : "Kaydı Başlat"}</span>
            </button>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1.5 px-3.5 py-2.5 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 rounded-2xl text-xs font-semibold active:scale-95 transition-all cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Ses Dosyası Yükle</span>
            </button>
          </>
        )}

        {isRecording && (
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={pauseRecording}
              className="flex items-center gap-1.5 px-3.5 py-2.5 bg-amber-500 hover:bg-amber-400 text-white rounded-2xl text-xs font-bold active:scale-95 transition-all shadow-md cursor-pointer"
            >
              {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
              <span>{isPaused ? "Devam Et" : "Duraklat"}</span>
            </button>

            <button
              type="button"
              onClick={stopRecording}
              className="flex items-center gap-2 px-5 py-2.5 bg-slate-900 hover:bg-slate-800 dark:bg-rose-600 dark:hover:bg-rose-500 text-white rounded-2xl text-xs font-bold active:scale-95 transition-all shadow-md cursor-pointer"
            >
              <Square className="w-4 h-4 fill-current" />
              <span>Kaydı Bitir</span>
            </button>
          </div>
        )}

        {recordedBlob && (
          <>
            <button
              type="button"
              onClick={togglePlayback}
              className="flex items-center gap-1.5 px-4 py-2 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-100 rounded-xl text-xs font-bold transition-all cursor-pointer"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span>{isPlaying ? "Durdur" : "Dinle"}</span>
            </button>

            <button
              type="button"
              onClick={changePlaybackSpeed}
              className="px-2.5 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-xl text-[11px] font-mono font-bold transition-all cursor-pointer"
              title="Oynatma Hızını Değiştir"
            >
              {playbackSpeed}x
            </button>

            <button
              type="button"
              onClick={() => {
                triggerHaptic(15);
                setRecordedBlob(null);
                setAudioUrl(null);
                setRecordingSeconds(0);
                setLiveTranscript("");
                setAiTranscribedText(null);
              }}
              className="p-2 rounded-xl text-rose-500 hover:bg-rose-100/50 dark:hover:bg-rose-950/40 transition-all cursor-pointer"
              title="Yeniden Kaydet"
            >
              <Trash2 className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={handleSave}
              className="flex items-center gap-1.5 px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold shadow-md shadow-teal-600/20 active:scale-95 transition-all cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>Nota Kaydet</span>
            </button>
          </>
        )}

        <button
          type="button"
          onClick={onClose}
          className="text-xs text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 px-3 py-2 cursor-pointer"
        >
          Kapat
        </button>
      </div>
    </div>
  );
};
