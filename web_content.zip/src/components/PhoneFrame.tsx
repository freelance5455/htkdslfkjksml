import React, { useState } from 'react';
import { Wifi, Battery, Bell, Shield, Smartphone, Maximize2, Minimize2, Sparkles, Download } from 'lucide-react';
import { SupportedLanguage } from '../types';
import { APKDownloadModal } from './APKDownloadModal';

interface PhoneFrameProps {
  children: React.ReactNode;
  activeTab: string;
  onTabChange: (tab: string) => void;
  language: SupportedLanguage;
  onLanguageChange: (lang: SupportedLanguage) => void;
  isForegroundActive: boolean;
  onToggleForeground: () => void;
  isAPKModalOpen?: boolean;
  onOpenAPKModal?: () => void;
  onCloseAPKModal?: () => void;
}

export const PhoneFrame: React.FC<PhoneFrameProps> = ({
  children,
  activeTab,
  onTabChange,
  language,
  onLanguageChange,
  isForegroundActive,
  onToggleForeground,
  isAPKModalOpen,
  onOpenAPKModal,
  onCloseAPKModal,
}) => {
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [showNotificationShade, setShowNotificationShade] = useState(false);
  const [internalAPKModalOpen, setInternalAPKModalOpen] = useState(false);

  const isModalOpen = isAPKModalOpen !== undefined ? isAPKModalOpen : internalAPKModalOpen;
  const handleOpenModal = onOpenAPKModal || (() => setInternalAPKModalOpen(true));
  const handleCloseModal = onCloseAPKModal || (() => setInternalAPKModalOpen(false));

  const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start py-4 px-2 sm:px-4 selection:bg-cyan-500/30">
      {/* Top Controller Bar */}
      <header className="w-full max-w-5xl flex items-center justify-between mb-4 px-4 py-2 bg-slate-900/80 backdrop-blur-md border border-slate-800 rounded-xl shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-600 to-emerald-500 flex items-center justify-center font-black text-slate-950 text-sm shadow-md shadow-cyan-500/20">
            D
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold tracking-tight text-white">DOST AI</span>
              <span className="text-[10px] uppercase font-semibold px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                Android Agent
              </span>
            </div>
            <p className="text-xs text-slate-400">Kotlin & Jetpack Compose Native Architecture</p>
          </div>
        </div>

        {/* Global Controls */}
        <div className="flex items-center gap-2 sm:gap-4">
          {/* Language Selector */}
          <div className="flex items-center bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => onLanguageChange('roman_urdu')}
              className={`px-2.5 py-1 rounded transition-colors ${
                language === 'roman_urdu' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Roman Urdu
            </button>
            <button
              onClick={() => onLanguageChange('urdu')}
              className={`px-2.5 py-1 rounded transition-colors font-arabic ${
                language === 'urdu' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              اردو
            </button>
            <button
              onClick={() => onLanguageChange('english')}
              className={`px-2.5 py-1 rounded transition-colors ${
                language === 'english' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              English
            </button>
          </div>

          {/* Install APK / Mobile App Button */}
          <button
            onClick={handleOpenModal}
            className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500 to-emerald-400 hover:from-cyan-400 hover:to-emerald-300 text-slate-950 font-bold transition-all flex items-center gap-1.5 text-xs shadow-md shadow-cyan-500/20 active:scale-95"
            title="Download APK / Install on Mobile"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="font-extrabold">📱 Install APK</span>
          </button>

          {/* Toggle Device Frame vs Desktop Fullscreen */}
          <button
            onClick={() => setIsFullScreen(!isFullScreen)}
            title={isFullScreen ? 'Switch to Phone Mockup' : 'Switch to Full Screen'}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors flex items-center gap-1.5 text-xs"
          >
            {isFullScreen ? (
              <>
                <Smartphone className="w-4 h-4 text-cyan-400" />
                <span className="hidden sm:inline">Phone View</span>
              </>
            ) : (
              <>
                <Maximize2 className="w-4 h-4 text-emerald-400" />
                <span className="hidden sm:inline">Wide View</span>
              </>
            )}
          </button>
        </div>
      </header>

      {/* Main Container: Either Phone Shell or Wide Dashboard */}
      <div
        className={`w-full transition-all duration-300 ${
          isFullScreen
            ? 'max-w-6xl min-h-[820px] bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col'
            : 'max-w-[420px] h-[850px] bg-slate-950 border-[10px] border-slate-900 rounded-[48px] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] overflow-hidden flex flex-col relative ring-1 ring-slate-800'
        }`}
      >
        {/* Status Bar */}
        <div className="w-full bg-slate-950/90 backdrop-blur px-5 py-2.5 flex items-center justify-between text-xs select-none border-b border-slate-800/60 z-20">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-200">{currentTime}</span>
            {isForegroundActive && (
              <button
                onClick={() => setShowNotificationShade(!showNotificationShade)}
                className="flex items-center gap-1 bg-cyan-950/80 text-cyan-300 px-1.5 py-0.5 rounded text-[10px] border border-cyan-700/50 hover:bg-cyan-900/80"
                title="Tap to toggle Notification Shade"
              >
                <Sparkles className="w-2.5 h-2.5 text-cyan-400" />
                <span>DOST Active</span>
              </button>
            )}
          </div>

          {/* Device Punchhole Camera (when in phone frame) */}
          {!isFullScreen && (
            <div className="w-3.5 h-3.5 rounded-full bg-slate-900 border border-slate-800 shadow-inner flex items-center justify-center">
              <div className="w-1.5 h-1.5 rounded-full bg-slate-950" />
            </div>
          )}

          <div className="flex items-center gap-2 text-slate-400">
            <Wifi className="w-3.5 h-3.5 text-slate-300" />
            <div className="flex items-center gap-1 text-[11px]">
              <span className="text-slate-300 font-mono">92%</span>
              <Battery className="w-4 h-4 text-emerald-400" />
            </div>
          </div>
        </div>

        {/* Pull-down Notification Shade Simulator */}
        {showNotificationShade && (
          <div className="absolute top-10 inset-x-0 z-30 bg-slate-900/95 border-b border-slate-800 p-4 shadow-2xl backdrop-blur-md animate-in slide-in-from-top duration-200">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded bg-cyan-500/20 text-cyan-400 flex items-center justify-center text-xs font-bold">
                  D
                </div>
                <span className="text-xs font-semibold text-slate-200">DOST AI Foreground Service</span>
              </div>
              <span className="text-[10px] text-slate-500">Persistent Notification</span>
            </div>
            <p className="text-xs text-slate-300 mb-3">
              DOST AI background agent tayyar hai. Tap quick action to wake assistant:
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  onTabChange('voice');
                  setShowNotificationShade(false);
                }}
                className="flex-1 py-1.5 px-2 rounded-lg bg-cyan-500 text-slate-950 text-xs font-semibold hover:bg-cyan-400 text-center"
              >
                🎙️ Quick Talk
              </button>
              <button
                onClick={() => {
                  onTabChange('crypto');
                  setShowNotificationShade(false);
                }}
                className="flex-1 py-1.5 px-2 rounded-lg bg-slate-800 text-slate-200 text-xs font-medium hover:bg-slate-700 text-center border border-slate-700"
              >
                📊 Crypto Scan
              </button>
              <button
                onClick={() => {
                  onToggleForeground();
                  setShowNotificationShade(false);
                }}
                className="py-1.5 px-2.5 rounded-lg bg-red-950/60 text-red-300 text-xs font-medium hover:bg-red-900 border border-red-800/40"
              >
                Stop
              </button>
            </div>
          </div>
        )}

        {/* Tab Content Body */}
        <main className="flex-1 overflow-y-auto bg-slate-950 relative">{children}</main>

        {/* Android Bottom Navigation Bar */}
        <nav className="w-full bg-slate-950/95 border-t border-slate-800/80 px-2 py-2 flex items-center justify-around z-20">
          <button
            onClick={() => onTabChange('chat')}
            className={`flex flex-col items-center gap-1 py-1 px-2.5 rounded-xl transition-all ${
              activeTab === 'chat'
                ? 'text-cyan-400 bg-cyan-950/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="text-lg">💬</span>
            <span className="text-[10px]">DOST Brain</span>
          </button>

          <button
            onClick={() => onTabChange('voice')}
            className={`flex flex-col items-center gap-1 py-1 px-2.5 rounded-xl transition-all ${
              activeTab === 'voice'
                ? 'text-cyan-400 bg-cyan-950/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="text-lg">🎙️</span>
            <span className="text-[10px]">Voice</span>
          </button>

          <button
            onClick={() => onTabChange('phone_tools')}
            className={`flex flex-col items-center gap-1 py-1 px-2.5 rounded-xl transition-all ${
              activeTab === 'phone_tools'
                ? 'text-cyan-400 bg-cyan-950/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="text-lg">📱</span>
            <span className="text-[10px]">Phone Tools</span>
          </button>

          <button
            onClick={() => onTabChange('crypto')}
            className={`flex flex-col items-center gap-1 py-1 px-2.5 rounded-xl transition-all ${
              activeTab === 'crypto'
                ? 'text-cyan-400 bg-cyan-950/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="text-lg">📈</span>
            <span className="text-[10px]">Crypto Hub</span>
          </button>

          <button
            onClick={() => onTabChange('memory')}
            className={`flex flex-col items-center gap-1 py-1 px-2.5 rounded-xl transition-all ${
              activeTab === 'memory'
                ? 'text-purple-400 bg-purple-950/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="text-lg">🧠</span>
            <span className="text-[10px]">DOST Mind</span>
          </button>

          <button
            onClick={() => onTabChange('app_studio')}
            className={`flex flex-col items-center gap-1 py-1 px-2.5 rounded-xl transition-all ${
              activeTab === 'app_studio'
                ? 'text-cyan-400 bg-cyan-950/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="text-lg">⚡</span>
            <span className="text-[10px]">App Studio</span>
          </button>

          <button
            onClick={() => onTabChange('android_code')}
            className={`flex flex-col items-center gap-1 py-1 px-2.5 rounded-xl transition-all ${
              activeTab === 'android_code'
                ? 'text-emerald-400 bg-emerald-950/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="text-lg">🤖</span>
            <span className="text-[10px]">Kotlin Code</span>
          </button>

          <button
            onClick={() => onTabChange('settings')}
            className={`flex flex-col items-center gap-1 py-1 px-2 rounded-xl transition-all ${
              activeTab === 'settings'
                ? 'text-cyan-400 bg-cyan-950/40 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="text-lg">⚙️</span>
            <span className="text-[10px]">Settings</span>
          </button>
        </nav>

        {/* Interactive Floating Assistant Overlay Head (Simulating Android SYSTEM_ALERT_WINDOW) */}
        {isForegroundActive && activeTab !== 'voice' && (
          <button
            onClick={() => onTabChange('voice')}
            className="absolute bottom-20 right-4 z-40 w-12 h-12 rounded-full bg-gradient-to-tr from-cyan-500 via-teal-400 to-emerald-400 text-slate-950 flex items-center justify-center shadow-2xl shadow-cyan-500/50 hover:scale-110 active:scale-95 transition-all group ring-2 ring-white/20"
            title="Tap to speak to DOST (Floating Shortcut)"
          >
            <span className="text-xl group-hover:scale-110 transition-transform">🎙️</span>
            <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-400 rounded-full border-2 border-slate-950 animate-ping" />
            <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-400 rounded-full border-2 border-slate-950" />
          </button>
        )}
      </div>

      {/* APK & Mobile Installation Modal */}
      <APKDownloadModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        language={language}
      />
    </div>
  );
};

