import { useMemo, useState } from 'react';
import {
  BookmarkPlus,
  Check,
  CheckCircle2,
  Circle,
  Pencil,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import type { MemoryCategory, UserMemoryItem } from '../lib/jarvisTypes';
import { formatMemoryCategoryLabel } from '../lib/memoryLogic';

interface MemoryViewProps {
  memories: UserMemoryItem[];
  onAddMemory: (input: { category: MemoryCategory; content: string }) => Promise<void>;
  onUpdateMemory: (
    id: string,
    patch: { content?: string; category?: MemoryCategory; completed?: boolean },
  ) => Promise<void>;
  onDeleteMemory: (id: string) => Promise<void>;
  onClearMemories: () => Promise<void>;
}

const CATEGORIES: Array<{ id: 'all' | MemoryCategory; label: string }> = [
  { id: 'all', label: 'All' },
  { id: 'preference', label: 'Preferences' },
  { id: 'project', label: 'Projects' },
  { id: 'decision', label: 'Decisions' },
  { id: 'task', label: 'Tasks' },
  { id: 'fact', label: 'Facts' },
];

export function MemoryView({
  memories,
  onAddMemory,
  onUpdateMemory,
  onDeleteMemory,
  onClearMemories,
}: MemoryViewProps) {
  const [filter, setFilter] = useState<'all' | MemoryCategory>('all');
  const [search, setSearch] = useState('');
  const [newCategory, setNewCategory] = useState<MemoryCategory>('project');
  const [newContent, setNewContent] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const [editCategory, setEditCategory] = useState<MemoryCategory>('fact');
  const [confirmClear, setConfirmClear] = useState(false);
  const [busy, setBusy] = useState(false);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return memories.filter((m) => {
      if (filter !== 'all' && m.category !== filter) return false;
      if (q && !m.content.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [memories, filter, search]);

  const openTasksCount = useMemo(
    () => memories.filter((m) => m.category === 'task' && !m.completed).length,
    [memories],
  );
  const projectsCount = useMemo(
    () => memories.filter((m) => m.category === 'project').length,
    [memories],
  );

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContent.trim() || busy) return;
    setBusy(true);
    try {
      await onAddMemory({ category: newCategory, content: newContent.trim() });
      setNewContent('');
    } finally {
      setBusy(false);
    }
  };

  const handleSaveEdit = async (id: string) => {
    if (!editText.trim() || busy) return;
    setBusy(true);
    try {
      await onUpdateMemory(id, { content: editText.trim(), category: editCategory });
      setEditingId(null);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-7 sm:px-6" data-testid="memory-view">
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-white/8 pb-5">
        <div>
          <h1 className="font-display text-2xl font-semibold text-slate-50 sm:text-3xl">
            Long-Term Memory Vault
          </h1>
          <p className="mt-1.5 max-w-2xl text-sm text-slate-400">
            JARVIS only recalls facts saved here or in active chat history. Review, edit, or delete memories anytime.
          </p>
        </div>

        <div className="flex items-center gap-5 text-xs">
          <div>
            <div className="text-slate-400">Saved</div>
            <div className="font-mono text-base font-semibold text-amber-300 tabular-nums">
              {memories.length}
            </div>
          </div>
          <div>
            <div className="text-slate-400">Projects</div>
            <div className="font-mono text-base font-semibold text-sky-300 tabular-nums">
              {projectsCount}
            </div>
          </div>
          <div>
            <div className="text-slate-400">Open Tasks</div>
            <div className="font-mono text-base font-semibold text-slate-100 tabular-nums">
              {openTasksCount}
            </div>
          </div>
        </div>
      </div>

      {/* Add Memory Form */}
      <form
        onSubmit={handleAdd}
        className="mt-6 rounded-2xl border border-amber-400/20 bg-[#0B1018] p-4"
      >
        <div className="mb-2.5 flex items-center gap-2 text-xs font-medium text-amber-300">
          <BookmarkPlus className="h-4 w-4" />
          <span>Save a preference, project, decision, or task</span>
        </div>
        <div className="flex flex-col gap-2.5 sm:flex-row">
          <label htmlFor="new-memory-category" className="sr-only">
            Memory category
          </label>
          <select
            id="new-memory-category"
            value={newCategory}
            onChange={(e) => setNewCategory(e.target.value as MemoryCategory)}
            className="min-h-[42px] rounded-xl border border-white/10 bg-[#05070B] px-3 py-2 text-sm text-slate-100 sm:w-40"
          >
            <option value="project">Project</option>
            <option value="preference">Preference</option>
            <option value="decision">Decision</option>
            <option value="task">Task</option>
            <option value="fact">Fact</option>
          </select>

          <label htmlFor="new-memory-input" className="sr-only">
            Memory details
          </label>
          <input
            id="new-memory-input"
            type="text"
            value={newContent}
            onChange={(e) => setNewContent(e.target.value)}
            placeholder="e.g. Building an Android companion app for JARVIS using Kotlin"
            className="min-h-[42px] flex-1 rounded-xl border border-white/10 bg-[#05070B] px-3.5 py-2 text-sm text-slate-100 placeholder:text-slate-500 focus:border-sky-400/50 focus:outline-none"
          />

          <button
            type="submit"
            disabled={!newContent.trim() || busy}
            className="min-h-[42px] rounded-xl bg-sky-500 px-4 py-2 text-sm font-semibold text-slate-950 transition-colors hover:bg-sky-400 disabled:cursor-not-allowed disabled:bg-slate-800 disabled:text-slate-500 whitespace-nowrap shrink-0"
          >
            Save Memory
          </button>
        </div>
      </form>

      {/* Filter & Search Bar */}
      <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1 rounded-xl border border-white/8 bg-[#0B1018] p-1">
          {CATEGORIES.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setFilter(c.id)}
              className={`min-h-[34px] rounded-lg px-3 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                filter === c.id
                  ? 'bg-sky-500/20 text-sky-200'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search memories…"
              aria-label="Search saved memories"
              className="min-h-[38px] w-48 rounded-xl border border-white/10 bg-[#0B1018] pl-8 pr-3 text-xs text-slate-100 placeholder:text-slate-500 focus:border-sky-400/50 focus:outline-none sm:w-56"
            />
          </div>

          {memories.length > 0 && !confirmClear && (
            <button
              type="button"
              onClick={() => setConfirmClear(true)}
              className="min-h-[38px] rounded-xl border border-white/10 px-3 py-1.5 text-xs font-medium text-slate-400 hover:border-rose-500/40 hover:text-rose-300 whitespace-nowrap shrink-0"
            >
              Clear All
            </button>
          )}

          {confirmClear && (
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={async () => {
                  await onClearMemories();
                  setConfirmClear(false);
                }}
                className="min-h-[38px] rounded-xl bg-rose-500 px-3 py-1.5 text-xs font-semibold text-white hover:bg-rose-400 whitespace-nowrap"
              >
                Confirm Clear
              </button>
              <button
                type="button"
                onClick={() => setConfirmClear(false)}
                className="min-h-[38px] rounded-xl border border-white/10 px-2.5 py-1.5 text-xs text-slate-300 hover:bg-white/5"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Memory Items */}
      <div className="mt-5 space-y-2.5" data-testid="memory-list">
        {filtered.length === 0 ? (
          <div className="rounded-2xl border border-white/8 bg-[#0B1018] px-6 py-10 text-center">
            <p className="text-sm font-medium text-slate-300">
              {memories.length === 0
                ? 'No saved memories yet.'
                : 'No memories match this filter.'}
            </p>
            <p className="mt-1 text-xs text-slate-400">
              Add a memory above, click &quot;Remember&quot; on any chat message, or ask JARVIS in chat to remember something.
            </p>
          </div>
        ) : (
          filtered.map((item) => {
            const isEditing = editingId === item.id;
            const dateStr = new Date(item.updatedAt).toLocaleDateString([], {
              month: 'short',
              day: 'numeric',
            });

            return (
              <div
                key={item.id}
                className="rounded-2xl border border-white/8 bg-[#0B1018] p-4 transition-colors hover:border-white/14"
              >
                {isEditing ? (
                  <div className="flex flex-col gap-2.5 sm:flex-row sm:items-center">
                    <select
                      aria-label="Edit memory category"
                      value={editCategory}
                      onChange={(e) => setEditCategory(e.target.value as MemoryCategory)}
                      className="min-h-[38px] rounded-lg border border-white/10 bg-[#05070B] px-2.5 py-1 text-xs text-slate-100"
                    >
                      <option value="project">Project</option>
                      <option value="preference">Preference</option>
                      <option value="decision">Decision</option>
                      <option value="task">Task</option>
                      <option value="fact">Fact</option>
                    </select>
                    <input
                      type="text"
                      aria-label="Edit memory text"
                      value={editText}
                      onChange={(e) => setEditText(e.target.value)}
                      className="min-h-[38px] flex-1 rounded-lg border border-sky-400/40 bg-[#05070B] px-3 py-1.5 text-sm text-slate-100 focus:outline-none"
                    />
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleSaveEdit(item.id)}
                        aria-label="Save edited memory"
                        className="inline-flex min-h-[36px] items-center gap-1 rounded-lg bg-sky-500 px-3 py-1 text-xs font-semibold text-slate-950 hover:bg-sky-400"
                      >
                        <Check className="h-3.5 w-3.5" />
                        <span>Save</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingId(null)}
                        aria-label="Cancel editing memory"
                        className="inline-flex min-h-[36px] items-center gap-1 rounded-lg border border-white/10 px-2.5 py-1 text-xs text-slate-300 hover:bg-white/5"
                      >
                        <X className="h-3.5 w-3.5" />
                        <span>Cancel</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex min-w-0 flex-1 items-start gap-3">
                      {item.category === 'task' && (
                        <button
                          type="button"
                          onClick={() =>
                            onUpdateMemory(item.id, { completed: !item.completed })
                          }
                          aria-label={
                            item.completed ? 'Mark task incomplete' : 'Mark task complete'
                          }
                          className="mt-0.5 shrink-0 text-sky-400 hover:text-sky-300"
                        >
                          {item.completed ? (
                            <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                          ) : (
                            <Circle className="h-4 w-4" />
                          )}
                        </button>
                      )}
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 text-xs text-slate-400">
                          <span
                            className={
                              item.category === 'project' || item.category === 'decision'
                                ? 'font-medium text-amber-300'
                                : 'font-medium text-sky-300'
                            }
                          >
                            {formatMemoryCategoryLabel(item.category)}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono tabular-nums">{dateStr}</span>
                          {item.category === 'task' && item.completed && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="text-emerald-400">Done</span>
                            </>
                          )}
                        </div>
                        <p
                          className={`mt-1 text-sm leading-relaxed ${
                            item.completed ? 'text-slate-500 line-through' : 'text-slate-100'
                          }`}
                        >
                          {item.content}
                        </p>
                      </div>
                    </div>

                    <div className="flex shrink-0 items-center gap-1">
                      <button
                        type="button"
                        onClick={() => {
                          setEditingId(item.id);
                          setEditText(item.content);
                          setEditCategory(item.category);
                        }}
                        aria-label={`Edit memory ${item.content}`}
                        className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 hover:bg-white/6 hover:text-sky-300"
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onDeleteMemory(item.id)}
                        aria-label={`Delete memory ${item.content}`}
                        className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 hover:bg-white/6 hover:text-rose-400"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
