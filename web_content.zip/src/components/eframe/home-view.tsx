import { Cpu, FileArchive, FileText, Image, Monitor, Plus, StickyNote, Table } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { CpuChart } from "@/components/eframe/cpu-chart";
import { OS, formatWhen, osLabel, type FileKind } from "@/lib/eframe/catalog";
import { readHardware, type Hardware } from "@/lib/eframe/hardware";
import { useEframe } from "@/lib/eframe/store";
import { Badge, Button, Field, Panel } from "@/components/eframe/ui";

const KIND_ICON = {
  note: StickyNote,
  sheet: Table,
  image: Image,
  archive: FileArchive,
} as const;

function useLoad(running: number) {
  const runningRef = useRef(running);
  runningRef.current = running;
  const [points, setPoints] = useState<number[]>(() => Array.from({ length: 32 }, () => 12));
  const [cores, setCores] = useState<number[]>(() => Array.from({ length: 8 }, () => 12));

  useEffect(() => {
    const count = Math.min(navigator.hardwareConcurrency || 4, 16);
    let load = 10;
    const id = window.setInterval(() => {
      const target = 7 + runningRef.current * 11;
      load = Math.max(3, Math.min(97, load * 0.7 + target * 0.3 + (Math.random() - 0.48) * 5));
      const rounded = Math.round(load);
      setPoints((prev) => [...prev.slice(-31), rounded]);
      setCores(
        Array.from({ length: count }, (_, index) => {
          const wobble = Math.sin(Date.now() / 700 + index) * 7;
          return Math.max(2, Math.min(99, Math.round(load + wobble)));
        }),
      );
    }, 1000);
    return () => window.clearInterval(id);
  }, []);

  return { points, cores, load: points[points.length - 1] ?? 0 };
}

export function HomeView() {
  const machineName = useEframe((state) => state.machineName);
  const rename = useEframe((state) => state.rename);
  const currentOs = useEframe((state) => state.currentOs);
  const previousOs = useEframe((state) => state.previousOs);
  const files = useEframe((state) => state.files);
  const apps = useEframe((state) => state.apps);
  const touchFile = useEframe((state) => state.touchFile);
  const addFile = useEframe((state) => state.addFile);
  const removeFile = useEframe((state) => state.removeFile);
  const launchApp = useEframe((state) => state.launchApp);
  const quitApp = useEframe((state) => state.quitApp);
  const addApp = useEframe((state) => state.addApp);
  const log = useEframe((state) => state.log);

  const running = apps.filter((app) => app.running).length;
  const { points, cores, load } = useLoad(running);
  const [hardware, setHardware] = useState<Hardware | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);
  const [draftName, setDraftName] = useState(machineName);
  const [fileName, setFileName] = useState("");
  const [fileKind, setFileKind] = useState<FileKind>("note");
  const [appName, setAppName] = useState("");
  const [showFileForm, setShowFileForm] = useState(false);
  const [showAppForm, setShowAppForm] = useState(false);

  useEffect(() => {
    setDraftName(machineName);
  }, [machineName]);

  useEffect(() => {
    let alive = true;
    void readHardware().then((next) => {
      if (alive) setHardware(next);
    });
    return () => {
      alive = false;
    };
  }, []);

  const openFile = files.find((file) => file.id === openId) ?? null;
  const os = OS[currentOs];

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="min-w-0">
          <p className="text-sm text-muted">Home</p>
          <h1 className="text-2xl font-medium tracking-tight text-fg">
            <label className="sr-only" htmlFor="machine-name">
              Computer name
            </label>
            <input
              id="machine-name"
              value={draftName}
              onChange={(event) => setDraftName(event.target.value)}
              onBlur={() => rename(draftName)}
              className="w-full max-w-xs rounded-lg border border-transparent bg-transparent px-1 text-2xl font-medium tracking-tight text-fg hover:border-line focus:border-line"
            />
          </h1>
        </div>
        <div className="text-sm">
          <p className="text-fg">{osLabel(currentOs)}</p>
          <p className="text-muted">
            {previousOs ? `Previous system: ${OS[previousOs].name}` : "No previous system saved"}
          </p>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        <Panel
          className="lg:col-span-3"
          title="Processor"
          aside={
            <span className="inline-flex items-center gap-2 text-sm text-muted">
              <Cpu className="size-4" aria-hidden="true" />
              Live
            </span>
          }
        >
          <div className="flex items-end justify-between gap-4">
            <p className="text-4xl font-medium tabular-nums tracking-tight text-fg">{load}%</p>
            <p className="max-w-xs text-sm text-muted">
              Load rises while apps on this record are running. The count of processors is what this browser reports.
            </p>
          </div>
          <CpuChart points={points} />
          <div className="mt-3 grid grid-cols-4 gap-2 sm:grid-cols-8">
            {cores.map((value, index) => (
              <div key={index} className="min-w-0">
                <div className="flex h-16 items-end rounded-lg bg-raised px-1">
                  <div className="w-full rounded-sm bg-fg/80" style={{ height: `${Math.max(value, 4)}%` }} />
                </div>
                <p className="mt-1 text-center text-xs tabular-nums text-faint">{value}%</p>
              </div>
            ))}
          </div>
          <dl className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
            <Field label="Logical processors" value={hardware ? String(hardware.cores || "Not reported") : "Reading"} />
            <Field
              label="Memory"
              value={hardware ? (hardware.memoryGb != null ? `${hardware.memoryGb} GB reported` : "Not reported") : "Reading"}
            />
            <Field
              label="Architecture"
              value={
                hardware
                  ? [hardware.architecture, hardware.bitness && `${hardware.bitness}-bit`].filter(Boolean).join(" · ")
                  : "Reading"
              }
            />
          </dl>
        </Panel>

        <Panel
          className="lg:col-span-2"
          title="This computer"
          aside={
            <span className="inline-flex items-center gap-2 text-sm text-muted">
              <Monitor className="size-4" aria-hidden="true" />
              Browser
            </span>
          }
        >
          <dl className="grid grid-cols-2 gap-3">
            <Field label="Platform" value={hardware?.platform ?? "Reading"} />
            <Field label="System on record" value={os.name} />
            <Field label="Edition" value={os.edition} />
            <Field label="Build" value={os.build} />
            <Field label="Screen" value={hardware?.screen ?? "Reading"} />
            <Field label="Pixel ratio" value={hardware ? String(hardware.dpr) : "Reading"} />
            <Field label="Color depth" value={hardware ? `${hardware.colorDepth}-bit` : "Reading"} />
            <Field label="Touch points" value={hardware ? String(hardware.touch) : "Reading"} />
            <Field label="Languages" value={hardware?.languages ?? "Reading"} />
            <Field label="Time zone" value={hardware?.timezone ?? "Reading"} />
            <Field label="Network" value={hardware ? (hardware.online ? hardware.link || "Online" : "Offline") : "Reading"} />
            <Field label="Model" value={hardware?.model || "Not exposed"} />
          </dl>
          <p className="mt-4 text-xs leading-5 break-words text-faint">{hardware?.ua ?? "Reading the user agent."}</p>
          {hardware?.platformVersion ? (
            <p className="mt-2 text-xs text-faint">Platform version {hardware.platformVersion}</p>
          ) : null}
          {hardware?.brands ? <p className="mt-1 text-xs text-faint">{hardware.brands}</p> : null}
        </Panel>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Panel
          title="Recent apps"
          aside={
            <Button variant="quiet" type="button" onClick={() => setShowAppForm((open) => !open)}>
              <Plus className="size-4" aria-hidden="true" />
              Add
            </Button>
          }
        >
          {showAppForm ? (
            <form
              className="mb-3 flex flex-col gap-2 sm:flex-row"
              onSubmit={(event) => {
                event.preventDefault();
                addApp(appName);
                setAppName("");
                setShowAppForm(false);
              }}
            >
              <input
                value={appName}
                onChange={(event) => setAppName(event.target.value)}
                placeholder="Program name"
                className="h-11 min-w-0 flex-1 rounded-lg border border-line bg-raised px-3 text-sm text-fg"
              />
              <Button type="submit">Save</Button>
            </form>
          ) : null}
          <ul className="flex flex-col gap-2">
            {apps.map((app) => (
              <li key={app.id} className="flex items-center gap-3 rounded-lg bg-raised px-3 py-2">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm text-fg">{app.name}</p>
                  <p className="truncate text-xs text-faint">
                    {app.publisher} · {formatWhen(app.openedAt)}
                  </p>
                </div>
                {app.running ? <Badge tone="ok">Running</Badge> : null}
                {app.running ? (
                  <Button variant="quiet" type="button" onClick={() => quitApp(app.id)}>
                    Quit
                  </Button>
                ) : (
                  <Button variant="quiet" type="button" onClick={() => launchApp(app.id)}>
                    Open
                  </Button>
                )}
              </li>
            ))}
          </ul>
        </Panel>

        <Panel
          title="Recent files"
          aside={
            <Button variant="quiet" type="button" onClick={() => setShowFileForm((open) => !open)}>
              <Plus className="size-4" aria-hidden="true" />
              Add
            </Button>
          }
        >
          {showFileForm ? (
            <form
              className="mb-3 flex flex-col gap-2"
              onSubmit={(event) => {
                event.preventDefault();
                addFile({ name: fileName, kind: fileKind });
                setFileName("");
                setShowFileForm(false);
              }}
            >
              <input
                value={fileName}
                onChange={(event) => setFileName(event.target.value)}
                placeholder="File name"
                className="h-11 rounded-lg border border-line bg-raised px-3 text-sm text-fg"
              />
              <div className="flex flex-wrap gap-2">
                {(["note", "sheet", "image", "archive"] as const).map((kind) => (
                  <Button
                    key={kind}
                    type="button"
                    variant={fileKind === kind ? "primary" : "quiet"}
                    onClick={() => setFileKind(kind)}
                  >
                    {kind}
                  </Button>
                ))}
                <Button type="submit">Save</Button>
              </div>
            </form>
          ) : null}
          {files.length === 0 ? <p className="text-sm text-muted">No recent files on this record.</p> : null}
          <ul className="flex flex-col gap-2">
            {files.map((file) => {
              const Icon = KIND_ICON[file.kind] ?? FileText;
              const selected = file.id === openId;
              return (
                <li key={file.id} className="rounded-lg bg-raised">
                  <div className="flex items-center gap-3 px-3 py-2">
                    <Icon className="size-4 shrink-0 text-muted" aria-hidden="true" />
                    <button
                      type="button"
                      className="min-w-0 flex-1 text-left"
                      onClick={() => {
                        setOpenId(selected ? null : file.id);
                        if (!selected) touchFile(file.id);
                      }}
                    >
                      <p className="truncate text-sm text-fg">{file.name}</p>
                      <p className="truncate text-xs text-faint">
                        {file.size} · {formatWhen(file.modifiedAt)}
                      </p>
                    </button>
                    <Button variant="quiet" type="button" onClick={() => removeFile(file.id)}>
                      Remove
                    </Button>
                  </div>
                  {selected && openFile ? (
                    <div className="border-t border-line px-3 py-3">
                      <p className="font-mono text-xs break-all text-faint">{openFile.path}</p>
                      <p className="mt-2 text-sm text-fg">{openFile.body}</p>
                    </div>
                  ) : null}
                </li>
              );
            })}
          </ul>
        </Panel>
      </div>

      <Panel title="Record">
        <ul className="flex flex-col gap-2">
          {log.slice(0, 6).map((entry) => (
            <li key={entry.id} className="flex flex-wrap items-baseline justify-between gap-2 text-sm">
              <span className="text-fg">{entry.text}</span>
              <span className="text-xs text-faint">{formatWhen(entry.at)}</span>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}
