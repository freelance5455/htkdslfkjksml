import { useMemo, useState } from "react";
import { OS, UPDATE_OS, UPDATES, type OsId } from "@/lib/eframe/catalog";
import { useEframe } from "@/lib/eframe/store";
import { Badge, Button, Panel, ProgressMeter, useJob } from "@/components/eframe/ui";

export function UpdatesView({ onUpgrade }: { onUpgrade: () => void }) {
  const currentOs = useEframe((state) => state.currentOs);
  const tracked = useEframe((state) => state.updates);
  const trackUpdate = useEframe((state) => state.trackUpdate);
  const clearUpdate = useEframe((state) => state.clearUpdate);
  const [os, setOs] = useState<OsId>(currentOs === "win11" ? "win10" : currentOs);
  const { job, busy, start } = useJob();

  const selected = UPDATE_OS.includes(os) ? os : "win10";
  const rows = useMemo(() => UPDATES.filter((item) => item.os === selected), [selected]);
  const info = OS[selected];
  const matches = selected === currentOs;

  return (
    <div className="flex flex-col gap-4">
      <div>
        <p className="text-sm text-muted">Updates</p>
        <h1 className="text-2xl font-medium tracking-tight">Windows XP through 10</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted">
          Microsoft updates for versions that are out of standard support, including the out-of-band fixes published
          after end of life. Eframe records the plan. The packages themselves come from the{" "}
          <a
            className="text-fg underline decoration-line underline-offset-2"
            href="https://www.catalog.update.microsoft.com/"
            target="_blank"
            rel="noreferrer"
          >
            Microsoft Update Catalog
          </a>
          .
        </p>
      </div>

      <Panel title="Certificate cutoff in 2027">
        <p className="text-sm text-muted">
          Microsoft has said Windows Update certificates expire on May 17, 2027 and June 19, 2027. After those dates,
          unsupported Windows versions stop receiving updates entirely. Supported releases need a recent cumulative
          update before then. Everything older needs an upgrade.
        </p>
      </Panel>

      {job ? <ProgressMeter label={job.label} value={job.progress} /> : null}

      <div className="flex gap-2 overflow-x-auto pb-1">
        {UPDATE_OS.map((id) => (
          <Button key={id} type="button" variant={selected === id ? "primary" : "quiet"} onClick={() => setOs(id)}>
            {OS[id].name.replace("Windows ", "")}
          </Button>
        ))}
      </div>

      <p className="text-sm text-muted">
        {info.note}{" "}
        {matches
          ? "This record is running that system, so packages can be marked installed."
          : `This record is running ${OS[currentOs].name}, so these stay on the plan until that system is restored.`}
      </p>

      {selected === "win8" ? (
        <Panel title="No servicing left for Windows 8">
          <p className="text-sm text-muted">
            Windows 8 itself has no current Microsoft security updates. The supported move is the in-place update to
            Windows 8.1, which then has its own package.
          </p>
          <div className="mt-4">
            <Button type="button" onClick={onUpgrade}>
              Open upgrades
            </Button>
          </div>
        </Panel>
      ) : null}

      <div className="grid gap-3">
        {rows.map((item) => {
          const state = tracked[item.id];
          return (
            <Panel
              key={item.id}
              title={item.title}
              aside={
                state === "installed" ? (
                  <Badge tone="ok">Installed</Badge>
                ) : state === "planned" ? (
                  <Badge>Planned</Badge>
                ) : (
                  <Badge tone={item.severity === "Critical" ? "danger" : "muted"}>{item.severity}</Badge>
                )
              }
            >
              <p className="text-sm text-muted">{item.summary}</p>
              <p className="mt-3 text-xs text-faint">
                {item.kb} · {item.released} · {OS[item.os].name}
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                {state === "installed" ? (
                  <Button type="button" variant="quiet" disabled={busy} onClick={() => clearUpdate(item.id)}>
                    Remove from record
                  </Button>
                ) : matches ? (
                  <Button
                    type="button"
                    disabled={busy}
                    onClick={() => start(`Installing ${item.kb}`, () => trackUpdate(item.id, "installed"))}
                  >
                    Install on this PC
                  </Button>
                ) : (
                  <Button
                    type="button"
                    disabled={busy || state === "planned"}
                    onClick={() => start(`Saving ${item.kb}`, () => trackUpdate(item.id, "planned"))}
                  >
                    {state === "planned" ? "On the plan" : "Save to plan"}
                  </Button>
                )}
                {state === "planned" && matches ? (
                  <Button
                    type="button"
                    disabled={busy}
                    onClick={() => start(`Installing ${item.kb}`, () => trackUpdate(item.id, "installed"))}
                  >
                    Install on this PC
                  </Button>
                ) : null}
              </div>
            </Panel>
          );
        })}
      </div>
    </div>
  );
}
