import { useState } from "react";
import { OS, formatWhen, osLabel } from "@/lib/eframe/catalog";
import { useEframe } from "@/lib/eframe/store";
import { Badge, Button, Panel, ProgressMeter, useConfirm, useJob } from "@/components/eframe/ui";

export function BackupView() {
  const currentOs = useEframe((state) => state.currentOs);
  const previousOs = useEframe((state) => state.previousOs);
  const backups = useEframe((state) => state.backups);
  const log = useEframe((state) => state.log);
  const createBackup = useEframe((state) => state.createBackup);
  const deleteBackup = useEframe((state) => state.deleteBackup);
  const restoreBackup = useEframe((state) => state.restoreBackup);
  const restorePrevious = useEframe((state) => state.restorePrevious);
  const reset = useEframe((state) => state.reset);
  const [name, setName] = useState("");
  const { job, busy, start } = useJob();
  const { confirm, dialog } = useConfirm();

  const previous = previousOs ? OS[previousOs] : null;
  const current = OS[currentOs];

  return (
    <div className="flex flex-col gap-4">
      {dialog}
      <div>
        <p className="text-sm text-muted">Backup and restore</p>
        <h1 className="text-2xl font-medium tracking-tight">The system before this one</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted">
          Eframe keeps the operating system this record replaced, plus backup images of frameworks and updates.
          Restoring changes the record. It does not rewrite a disk.
        </p>
      </div>

      {job ? <ProgressMeter label={job.label} value={job.progress} /> : null}

      <Panel title={previous ? previous.name : "No previous system"} aside={<Badge tone="solid">Before this OS</Badge>}>
        {previous && previousOs ? (
          <>
            <p className="text-sm text-muted">{previous.note}</p>
            <dl className="mt-4 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
              <div>
                <dt className="text-xs text-faint">Edition</dt>
                <dd>{previous.edition}</dd>
              </div>
              <div>
                <dt className="text-xs text-faint">Build</dt>
                <dd className="tabular-nums">{previous.build}</dd>
              </div>
              <div>
                <dt className="text-xs text-faint">Support</dt>
                <dd>{previous.support}</dd>
              </div>
              <div>
                <dt className="text-xs text-faint">Now running</dt>
                <dd>{current.name}</dd>
              </div>
            </dl>
            <div className="mt-4">
              <Button
                type="button"
                disabled={busy}
                onClick={() =>
                  confirm({
                    title: `Restore ${previous.name}?`,
                    body: `${osLabel(currentOs)} becomes the previous system. ${osLabel(previousOs)} becomes the one this record is running. Frameworks that ${previous.name} cannot use stay listed, but you cannot install new copies of them until you switch back.`,
                    confirm: "Restore",
                    danger: true,
                    run: () => start(`Restoring ${previous.name}`, () => restorePrevious()),
                  })
                }
              >
                Restore this operating system
              </Button>
            </div>
          </>
        ) : (
          <p className="text-sm text-muted">
            This record has no system stored before the current one. Upgrade, or restore a backup that still has one.
          </p>
        )}
      </Panel>

      <Panel title="Backup images">
        <form
          className="mb-4 flex flex-col gap-2 sm:flex-row"
          onSubmit={(event) => {
            event.preventDefault();
            const label = name.trim() || `Backup of ${current.name}`;
            start(`Saving ${label}`, () => {
              createBackup(label);
              setName("");
            });
          }}
        >
          <input
            value={name}
            onChange={(event) => setName(event.target.value)}
            placeholder={`Backup of ${current.name}`}
            className="h-11 min-w-0 flex-1 rounded-lg border border-line bg-raised px-3 text-sm text-fg"
          />
          <Button type="submit" disabled={busy}>
            Save backup
          </Button>
        </form>
        {backups.length === 0 ? <p className="text-sm text-muted">No images yet.</p> : null}
        <ul className="flex flex-col gap-2">
          {backups.map((backup) => (
            <li key={backup.id} className="rounded-lg bg-raised p-3">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-fg">{backup.name}</p>
                  <p className="text-xs text-faint">
                    {formatWhen(backup.createdAt)} · {osLabel(backup.os)}
                    {backup.previous ? ` · before that, ${OS[backup.previous].name}` : ""}
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button
                    type="button"
                    variant="quiet"
                    disabled={busy}
                    onClick={() =>
                      confirm({
                        title: `Restore “${backup.name}”?`,
                        body: `The running system becomes ${osLabel(backup.os)}. Installed frameworks and the update plan are replaced with this image. Recent files stay.`,
                        confirm: "Restore image",
                        danger: true,
                        run: () => start(`Restoring ${backup.name}`, () => restoreBackup(backup.id)),
                      })
                    }
                  >
                    Restore
                  </Button>
                  <Button
                    type="button"
                    variant="danger"
                    disabled={busy}
                    onClick={() =>
                      confirm({
                        title: `Delete “${backup.name}”?`,
                        body: "The image is removed from this record. The running system is left as it is.",
                        confirm: "Delete",
                        danger: true,
                        run: () => deleteBackup(backup.id),
                      })
                    }
                  >
                    Delete
                  </Button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </Panel>

      <Panel title="History">
        <ul className="flex flex-col gap-2">
          {log.map((entry) => (
            <li key={entry.id} className="flex flex-wrap items-baseline justify-between gap-2 text-sm">
              <span>{entry.text}</span>
              <span className="text-xs text-faint">{formatWhen(entry.at)}</span>
            </li>
          ))}
        </ul>
        <div className="mt-4">
          <Button
            type="button"
            variant="quiet"
            onClick={() =>
              confirm({
                title: "Reset this record?",
                body: "Returns the sample desk: Windows 11 running, Windows 10 previous, and the original files, apps, and backup.",
                confirm: "Reset",
                danger: true,
                run: () => reset(),
              })
            }
          >
            Reset record
          </Button>
        </div>
      </Panel>
    </div>
  );
}
