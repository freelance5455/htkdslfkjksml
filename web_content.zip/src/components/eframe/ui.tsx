import * as AlertDialog from "@radix-ui/react-alert-dialog";
import type { ComponentProps, ReactNode } from "react";
import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

export function Button({
  variant = "primary",
  className,
  ...props
}: ComponentProps<"button"> & {
  variant?: "primary" | "quiet" | "danger";
}) {
  return (
    <button
      className={cn(
        "inline-flex h-11 items-center justify-center gap-2 rounded-lg px-4 text-sm font-medium transition-opacity duration-150 disabled:pointer-events-none disabled:opacity-40",
        variant === "primary" && "bg-accent text-ink hover:opacity-90",
        variant === "quiet" && "border border-line bg-raised text-fg hover:opacity-90",
        variant === "danger" && "border border-line bg-transparent text-danger hover:opacity-90",
        className,
      )}
      {...props}
    />
  );
}

export function Panel({
  title,
  aside,
  children,
  className,
}: {
  title: string;
  aside?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={cn("rounded-3xl border border-line bg-surface p-4", className)}>
      <div className="mb-4 flex items-start justify-between gap-3">
        <h2 className="text-base font-medium text-fg">{title}</h2>
        {aside}
      </div>
      {children}
    </section>
  );
}

export function Badge({
  tone = "muted",
  children,
}: {
  tone?: "muted" | "ok" | "danger" | "solid";
  children: ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex h-6 items-center rounded-md px-2 text-xs font-medium",
        tone === "muted" && "bg-raised text-muted",
        tone === "ok" && "bg-raised text-ok",
        tone === "danger" && "bg-raised text-danger",
        tone === "solid" && "bg-accent text-ink",
      )}
    >
      {children}
    </span>
  );
}

export function Field({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div className="min-w-0">
      <dt className="text-xs text-faint">{label}</dt>
      <dd className="text-sm break-words text-fg">{value}</dd>
    </div>
  );
}

export function ProgressMeter({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="mb-2 flex items-center justify-between gap-3 text-sm">
        <span className="text-fg">{label}</span>
        <span className="tabular-nums text-muted">{Math.round(value)}%</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-raised" role="progressbar" aria-valuenow={Math.round(value)} aria-valuemin={0} aria-valuemax={100}>
        <div className="h-full bg-accent" style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
      </div>
    </div>
  );
}

type Ask = {
  title: string;
  body: string;
  confirm: string;
  danger?: boolean;
  run: () => void;
};

export function useConfirm() {
  const [ask, setAsk] = useState<Ask | null>(null);
  const node = (
    <AlertDialog.Root open={ask !== null} onOpenChange={(open) => !open && setAsk(null)}>
      <AlertDialog.Portal>
        <AlertDialog.Overlay className="fixed inset-0 z-40 bg-canvas/80" />
        <AlertDialog.Content className="fixed top-1/2 left-1/2 z-50 w-11/12 max-w-md -translate-x-1/2 -translate-y-1/2 rounded-3xl border border-line bg-surface p-5">
          <AlertDialog.Title className="text-lg font-medium text-fg">{ask?.title}</AlertDialog.Title>
          <AlertDialog.Description className="mt-2 text-sm text-muted">{ask?.body}</AlertDialog.Description>
          <div className="mt-5 flex flex-wrap justify-end gap-2">
            <AlertDialog.Cancel asChild>
              <Button variant="quiet" type="button">
                Cancel
              </Button>
            </AlertDialog.Cancel>
            <AlertDialog.Action asChild>
              <Button
                variant={ask?.danger ? "danger" : "primary"}
                type="button"
                onClick={() => ask?.run()}
              >
                {ask?.confirm ?? "Continue"}
              </Button>
            </AlertDialog.Action>
          </div>
        </AlertDialog.Content>
      </AlertDialog.Portal>
    </AlertDialog.Root>
  );
  return {
    confirm: (next: Ask) => setAsk(next),
    dialog: node,
  };
}

export function useJob() {
  const [job, setJob] = useState<{ label: string; progress: number } | null>(null);
  const timer = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (timer.current) window.clearInterval(timer.current);
    };
  }, []);

  function start(label: string, done: () => void) {
    if (timer.current) window.clearInterval(timer.current);
    setJob({ label, progress: 8 });
    timer.current = window.setInterval(() => {
      setJob((current) => {
        if (!current) return current;
        const progress = Math.min(100, current.progress + 8 + Math.round(Math.random() * 10));
        if (progress >= 100) {
          if (timer.current) window.clearInterval(timer.current);
          timer.current = null;
          window.setTimeout(done, 0);
          return null;
        }
        return { label: current.label, progress };
      });
    }, 160);
  }

  return { job, busy: job !== null, start };
}
