import { useEffect, useState } from "react";
import { OS, UPGRADES, osLabel } from "@/lib/eframe/catalog";
import { readHardware, type Hardware } from "@/lib/eframe/hardware";
import { useEframe } from "@/lib/eframe/store";
import { Badge, Button, Panel, ProgressMeter, useConfirm, useJob } from "@/components/eframe/ui";

export function UpgradesView() {
  const currentOs = useEframe((state) => state.currentOs);
  const upgradeTo = useEframe((state) => state.upgradeTo);
  const paths = UPGRADES.filter((item) => item.from === currentOs);
  const [hardware, setHardware] = useState<Hardware | null>(null);
  const [picked, setPicked] = useState("");
  const { job, busy, start } = useJob();
  const { confirm, dialog } = useConfirm();
  const path = paths.find((item) => item.id === picked) ?? paths[0];

  useEffect(() => {
    let alive = true;
    void readHardware().then((next) => {
      if (alive) setHardware(next);
    });
    return () => {
      alive = false;
    };
  }, []);

  const memory = hardware?.memoryGb ?? null;
  const cores = hardware?.cores ?? 0;
  const memoryOk = !path?.needsMemory || memory == null || memory >= 4;
  const coresOk = cores === 0 || cores >= 2;

  return (
    <div className="flex flex-col gap-4">
      {dialog}
      <div>
        <p className="text-sm text-muted">Upgrades</p>
        <h1 className="text-2xl font-medium tracking-tight">From {OS[currentOs].name}</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted">
          Paths Microsoft actually offered, marked in place or clean install. Applying one updates this record and
          keeps the system you leave as the previous operating system.
        </p>
      </div>

      {job ? <ProgressMeter label={job.label} value={job.progress} /> : null}

      {paths.length === 0 ? (
        <Panel title="Nothing newer in this record">
          <p className="text-sm text-muted">
            {osLabel(currentOs)} is the newest system Eframe tracks. Restore an older one from Backup if you need a
            different path.
          </p>
        </Panel>
      ) : (
        <div className="grid gap-3 lg:grid-cols-5">
          <div className="grid gap-3 lg:col-span-3">
            {paths.map((item) => {
              const on = item.id === path?.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setPicked(item.id)}
                  className={`rounded-3xl border p-4 text-left ${on ? "border-accent bg-raised" : "border-line bg-surface"}`}
                >
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-base font-medium">{item.title}</span>
                    <Badge tone={item.kind === "In place" ? "ok" : "muted"}>{item.kind}</Badge>
                  </div>
                  <p className="mt-2 text-sm text-muted">{item.detail}</p>
                  <p className="mt-2 text-xs text-faint">
                    {OS[item.from].name} to {osLabel(item.to)}
                  </p>
                </button>
              );
            })}
          </div>
          {path ? (
            <Panel title="Check" className="lg:col-span-2">
              <ul className="flex flex-col gap-3 text-sm">
                <li className="flex items-start justify-between gap-3">
                  <span>Two or more processors</span>
                  <Badge tone={coresOk ? "ok" : "danger"}>{cores ? `${cores} reported` : "Not reported"}</Badge>
                </li>
                <li className="flex items-start justify-between gap-3">
                  <span>4 GB memory</span>
                  <Badge tone={!path.needsMemory || memoryOk ? "ok" : "danger"}>
                    {!path.needsMemory ? "Not required" : memory == null ? "Not reported" : `${memory} GB`}
                  </Badge>
                </li>
                <li className="flex items-start justify-between gap-3">
                  <span>TPM 2.0 and Secure Boot</span>
                  <Badge>{path.needsTpm ? "Not visible here" : "Not required"}</Badge>
                </li>
              </ul>
              <p className="mt-3 text-xs text-faint">
                A browser cannot see TPM, Secure Boot, or the real CPU model. Check those on the PC before a real
                installer.
              </p>
              <Button
                className="mt-4 w-full"
                type="button"
                disabled={busy}
                onClick={() =>
                  confirm({
                    title: path.title,
                    body: `${path.detail} ${OS[currentOs].name} will be kept as the previous system so you can restore it.`,
                    confirm: "Update this record",
                    run: () => start(path.title, () => upgradeTo(path.to, path.title)),
                  })
                }
              >
                Update this record
              </Button>
            </Panel>
          ) : null}
        </div>
      )}

      <Panel title="Every path">
        <ul className="flex flex-col gap-2">
          {UPGRADES.map((item) => (
            <li key={item.id} className="flex flex-wrap items-baseline justify-between gap-2 text-sm">
              <span>
                {OS[item.from].name} to {OS[item.to].name}
              </span>
              <span className="text-xs text-faint">{item.kind}</span>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}
