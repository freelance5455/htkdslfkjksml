import { useMemo, useState } from "react";
import { FRAMEWORKS, OS } from "@/lib/eframe/catalog";
import { useEframe } from "@/lib/eframe/store";
import { Badge, Button, Panel, ProgressMeter, useJob } from "@/components/eframe/ui";

export function FrameworksView() {
  const currentOs = useEframe((state) => state.currentOs);
  const installed = useEframe((state) => state.frameworks);
  const installFramework = useEframe((state) => state.installFramework);
  const removeFramework = useEframe((state) => state.removeFramework);
  const { job, busy, start } = useJob();
  const [query, setQuery] = useState("");
  const [onlyFit, setOnlyFit] = useState(false);

  const rows = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return FRAMEWORKS.filter((item) => {
      if (onlyFit && !item.supports.includes(currentOs)) return false;
      if (!needle) return true;
      return `${item.name} ${item.version} ${item.summary}`.toLowerCase().includes(needle);
    });
  }, [currentOs, onlyFit, query]);

  return (
    <div className="flex flex-col gap-4">
      <div>
        <p className="text-sm text-muted">Frameworks</p>
        <h1 className="text-2xl font-medium tracking-tight">Runtimes for {OS[currentOs].name}</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted">
          Install or remove the frameworks this record is allowed to use. A package stays listed when you change
          operating systems, and is blocked if that system cannot run it.
        </p>
      </div>

      {job ? <ProgressMeter label={job.label} value={job.progress} /> : null}

      <div className="flex flex-col gap-2 sm:flex-row">
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search frameworks"
          className="h-11 min-w-0 flex-1 rounded-lg border border-line bg-surface px-3 text-sm text-fg"
        />
        <Button type="button" variant={onlyFit ? "primary" : "quiet"} onClick={() => setOnlyFit((value) => !value)}>
          {onlyFit ? "Showing fits" : "Fits this system"}
        </Button>
      </div>

      <div className="grid gap-3">
        {rows.length === 0 ? (
          <Panel title="Nothing matches">
            <p className="text-sm text-muted">Clear the search or turn off the filter.</p>
          </Panel>
        ) : null}
        {rows.map((item) => {
          const on = installed.includes(item.id);
          const fits = item.supports.includes(currentOs);
          return (
            <Panel
              key={item.id}
              title={item.name}
              aside={on ? <Badge tone="ok">Installed</Badge> : <Badge>Not installed</Badge>}
            >
              <p className="text-sm text-muted">{item.summary}</p>
              <dl className="mt-3 grid grid-cols-2 gap-2 text-sm sm:grid-cols-3">
                <div>
                  <dt className="text-xs text-faint">Version</dt>
                  <dd>{item.version}</dd>
                </div>
                <div>
                  <dt className="text-xs text-faint">Publisher</dt>
                  <dd>{item.publisher}</dd>
                </div>
                <div>
                  <dt className="text-xs text-faint">Download size</dt>
                  <dd className="tabular-nums">{item.size}</dd>
                </div>
              </dl>
              <div className="mt-4 flex flex-wrap items-center gap-2">
                {on ? (
                  <Button
                    type="button"
                    variant="danger"
                    disabled={busy}
                    onClick={() => start(`Removing ${item.name}`, () => removeFramework(item.id))}
                  >
                    Remove
                  </Button>
                ) : (
                  <Button
                    type="button"
                    disabled={busy || !fits}
                    onClick={() => start(`Installing ${item.name}`, () => installFramework(item.id))}
                  >
                    Install
                  </Button>
                )}
                {!fits ? <span className="text-sm text-muted">Not supported on {OS[currentOs].name}.</span> : null}
              </div>
            </Panel>
          );
        })}
      </div>
    </div>
  );
}
