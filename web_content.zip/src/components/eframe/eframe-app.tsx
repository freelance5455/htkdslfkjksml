import { ArchiveRestore, ArrowUpCircle, Boxes, House, ShieldCheck } from "lucide-react";
import { useEffect, useState } from "react";
import { OS } from "@/lib/eframe/catalog";
import { useEframe } from "@/lib/eframe/store";
import { BackupView } from "@/components/eframe/backup-view";
import { FrameworksView } from "@/components/eframe/frameworks-view";
import { HomeView } from "@/components/eframe/home-view";
import { UpdatesView } from "@/components/eframe/updates-view";
import { UpgradesView } from "@/components/eframe/upgrades-view";
import { cn } from "@/lib/utils";

const NAV = [
  { id: "home", label: "Home", icon: House },
  { id: "frameworks", label: "Frameworks", icon: Boxes },
  { id: "backup", label: "Backup", icon: ArchiveRestore },
  { id: "updates", label: "Updates", icon: ShieldCheck },
  { id: "upgrades", label: "Upgrades", icon: ArrowUpCircle },
] as const;

type Section = (typeof NAV)[number]["id"];

export function EframeApp() {
  const [section, setSection] = useState<Section>("home");
  const currentOs = useEframe((state) => state.currentOs);
  const machineName = useEframe((state) => state.machineName);

  useEffect(() => {
    void useEframe.persist.rehydrate();
  }, []);

  return (
    <div className="min-h-screen bg-canvas text-fg md:grid md:grid-cols-[15rem_minmax(0,1fr)]">
      <aside className="sticky top-0 hidden h-screen flex-col border-r border-line px-3 py-5 md:flex">
        <div className="px-2">
          <p className="text-lg font-medium tracking-tight">Eframe</p>
          <p className="text-xs text-faint">{machineName}</p>
        </div>
        <nav className="mt-6 flex flex-col gap-1" aria-label="Sections">
          {NAV.map((item) => {
            const Icon = item.icon;
            const on = section === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setSection(item.id)}
                className={cn(
                  "flex h-11 items-center gap-3 rounded-lg px-3 text-left text-sm",
                  on ? "bg-raised text-fg" : "text-muted",
                )}
                aria-current={on ? "page" : undefined}
              >
                <Icon className="size-4" aria-hidden="true" />
                {item.label}
              </button>
            );
          })}
        </nav>
        <p className="mt-auto px-2 text-xs text-faint">{OS[currentOs].name}</p>
      </aside>

      <div className="min-w-0 pb-24 md:pb-10">
        <header className="sticky top-0 z-10 flex items-center justify-between gap-3 border-b border-line bg-canvas px-4 py-3 md:px-8">
          <div className="min-w-0 md:hidden">
            <p className="text-sm font-medium">Eframe</p>
            <p className="truncate text-xs text-faint">{NAV.find((item) => item.id === section)?.label}</p>
          </div>
          <p className="hidden text-sm text-muted md:block">PC record</p>
          <p className="truncate text-sm text-fg">
            {OS[currentOs].name}
            <span className="text-faint"> · {OS[currentOs].edition}</span>
          </p>
        </header>
        <main className="px-4 py-5 md:px-8 md:py-6">
          {section === "home" ? <HomeView /> : null}
          {section === "frameworks" ? <FrameworksView /> : null}
          {section === "backup" ? <BackupView /> : null}
          {section === "updates" ? <UpdatesView onUpgrade={() => setSection("upgrades")} /> : null}
          {section === "upgrades" ? <UpgradesView /> : null}
        </main>
      </div>

      <nav
        className="fixed inset-x-0 bottom-0 z-20 grid grid-cols-5 border-t border-line bg-canvas px-1 pt-1 pb-2 md:hidden"
        aria-label="Sections"
      >
        {NAV.map((item) => {
          const Icon = item.icon;
          const on = section === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setSection(item.id)}
              className={cn(
                "flex min-h-14 flex-col items-center justify-center gap-1 rounded-lg text-xs",
                on ? "text-fg" : "text-faint",
              )}
              aria-current={on ? "page" : undefined}
            >
              <Icon className="size-5" aria-hidden="true" />
              {item.label}
            </button>
          );
        })}
      </nav>
    </div>
  );
}
