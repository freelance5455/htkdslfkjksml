export function CpuChart({ points }: { points: number[] }) {
  const width = 320;
  const height = 112;
  const step = width / Math.max(points.length - 1, 1);
  const yFor = (value: number) => height - 8 - (Math.max(0, Math.min(100, value)) / 100) * (height - 16);
  const coords = points.map((value, index) => `${(index * step).toFixed(1)},${yFor(value).toFixed(1)}`);
  const line = `M${coords.join(" L")}`;
  const area = `${line} L${width},${height} L0,${height} Z`;

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="mt-3 h-36 w-full text-fg" role="img" aria-label="Processor load">
      {[0, 25, 50, 75, 100].map((mark) => (
        <line
          key={mark}
          x1="0"
          x2={width}
          y1={yFor(mark)}
          y2={yFor(mark)}
          stroke="currentColor"
          strokeOpacity="0.16"
        />
      ))}
      <path d={area} fill="currentColor" opacity="0.16" />
      <path d={line} fill="none" stroke="currentColor" strokeWidth="2" />
    </svg>
  );
}
