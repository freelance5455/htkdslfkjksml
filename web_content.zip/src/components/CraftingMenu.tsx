import React, { useState } from "react";
import { Item, Recipe } from "../types";
import { CRAFTING_RECIPES } from "../game/constants";
import { sound } from "../audio";
import { X, Hammer, Shield, Sparkles, Check, ArrowRight } from "lucide-react";

interface CraftingMenuProps {
  isOpen: boolean;
  onClose: () => void;
  inventory: Item[];
  onCraftRecipe: (recipe: Recipe) => void;
}

export const CraftingMenu: React.FC<CraftingMenuProps> = ({
  isOpen,
  onClose,
  inventory,
  onCraftRecipe,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<"all" | "tools" | "agriculture" | "special">("all");
  const [justCraftedId, setJustCraftedId] = useState<string | null>(null);

  if (!isOpen) return null;

  // Helper to count item quantity in player's inventory
  const getItemCount = (itemId: string): number => {
    return inventory
      .filter((item) => item.id === itemId)
      .reduce((sum, item) => sum + item.count, 0);
  };

  // Check if player has all ingredients for a recipe
  const canCraft = (recipe: Recipe): boolean => {
    return recipe.ingredients.every((ing) => getItemCount(ing.itemId) >= ing.count);
  };

  const filteredRecipes = CRAFTING_RECIPES.filter((r) => {
    if (selectedCategory === "all") return true;
    return r.category === selectedCategory;
  });

  const handleCraft = (recipe: Recipe) => {
    if (!canCraft(recipe)) return;
    sound.playCraftSuccess();
    onCraftRecipe(recipe);
    setJustCraftedId(recipe.id);
    setTimeout(() => setJustCraftedId(null), 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="relative w-full max-w-2xl bg-stone-900 border-2 border-amber-600/70 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-stone-950 via-amber-950/60 to-stone-950 p-4 border-b border-amber-700/50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-amber-600/20 text-amber-400 rounded-lg border border-amber-500/30">
              <Hammer className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-amber-200 font-['Hind_Siliguri']">
                তোজোর ক্রাফটিং ও টুল আপগ্রেড কামারশালা
              </h2>
              <p className="text-xs text-stone-400">
                Craft upgrades for self-defense stick, chopping axe, and village items
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-stone-800 text-stone-400 hover:text-white hover:bg-stone-700 cursor-pointer transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-2 px-4 py-2.5 bg-stone-950/60 border-b border-stone-800 text-xs">
          <button
            onClick={() => setSelectedCategory("all")}
            className={`px-3 py-1 rounded-lg font-medium cursor-pointer transition ${
              selectedCategory === "all"
                ? "bg-amber-600 text-white"
                : "bg-stone-800 text-stone-300 hover:bg-stone-700"
            }`}
          >
            সব রেসিপি (All)
          </button>
          <button
            onClick={() => setSelectedCategory("tools")}
            className={`px-3 py-1 rounded-lg font-medium cursor-pointer transition ${
              selectedCategory === "tools"
                ? "bg-amber-600 text-white"
                : "bg-stone-800 text-stone-300 hover:bg-stone-700"
            }`}
          >
            টুলস আপগ্রেড (Tools)
          </button>
          <button
            onClick={() => setSelectedCategory("agriculture")}
            className={`px-3 py-1 rounded-lg font-medium cursor-pointer transition ${
              selectedCategory === "agriculture"
                ? "bg-amber-600 text-white"
                : "bg-stone-800 text-stone-300 hover:bg-stone-700"
            }`}
          >
            কৃষি ও সার (Farming)
          </button>
          <button
            onClick={() => setSelectedCategory("special")}
            className={`px-3 py-1 rounded-lg font-medium cursor-pointer transition ${
              selectedCategory === "special"
                ? "bg-amber-600 text-white"
                : "bg-stone-800 text-stone-300 hover:bg-stone-700"
            }`}
          >
            কুকুর শান্তিকর পিঠা (Treats)
          </button>
        </div>

        {/* Recipes Grid */}
        <div className="p-4 overflow-y-auto space-y-3 flex-1">
          {filteredRecipes.map((recipe) => {
            const affordable = canCraft(recipe);
            const isJustCrafted = justCraftedId === recipe.id;

            return (
              <div
                key={recipe.id}
                className={`p-3.5 rounded-xl border transition flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
                  affordable
                    ? "bg-stone-800/80 border-amber-500/40 hover:border-amber-400"
                    : "bg-stone-950/40 border-stone-800 opacity-80"
                }`}
              >
                {/* Result Item Info */}
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 rounded-xl bg-stone-900 border border-stone-700 flex items-center justify-center text-2xl shrink-0 shadow-inner">
                    {recipe.resultItem.icon}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-stone-100 font-['Hind_Siliguri'] text-base">
                        {recipe.bengaliName}
                      </span>
                      {recipe.resultItem.tier && (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-900/60 text-amber-300 border border-amber-600/40">
                          Tier {recipe.resultItem.tier}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-stone-300 mt-0.5">
                      {recipe.description}
                    </p>

                    {/* Required Ingredients */}
                    <div className="flex items-center gap-2 mt-2 flex-wrap">
                      <span className="text-[11px] text-stone-400 font-medium">উপকরণ:</span>
                      {recipe.ingredients.map((ing) => {
                        const have = getItemCount(ing.itemId);
                        const hasEnough = have >= ing.count;

                        return (
                          <span
                            key={ing.itemId}
                            className={`text-[11px] px-2 py-0.5 rounded border font-mono ${
                              hasEnough
                                ? "bg-emerald-950/60 text-emerald-300 border-emerald-700/60"
                                : "bg-red-950/50 text-red-300 border-red-800/50"
                            }`}
                          >
                            {ing.name}: {have}/{ing.count}
                          </span>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Craft Action Button */}
                <div className="shrink-0 w-full sm:w-auto">
                  <button
                    onClick={() => handleCraft(recipe)}
                    disabled={!affordable}
                    className={`w-full sm:w-auto px-4 py-2 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition ${
                      isJustCrafted
                        ? "bg-emerald-600 text-white"
                        : affordable
                        ? "bg-amber-600 hover:bg-amber-500 text-white shadow-lg shadow-amber-900/30"
                        : "bg-stone-800 text-stone-500 cursor-not-allowed border border-stone-700"
                    }`}
                  >
                    {isJustCrafted ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-200" />
                        <span>আপগ্রেড সম্পন্ন!</span>
                      </>
                    ) : (
                      <>
                        <Hammer className="w-4 h-4" />
                        <span>ক্রাফট করো</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer Info */}
        <div className="p-3 bg-stone-950 border-t border-stone-800 text-xs text-stone-400 flex items-center justify-between">
          <span>💡 কুঠার দিয়ে কাঠ ও কচুবন থেকে কচুর আঁশ সংগ্রহ করো।</span>
          <span className="text-amber-400 font-semibold font-mono">
            তোজো ক্রাফটিং ডেক
          </span>
        </div>
      </div>
    </div>
  );
};
