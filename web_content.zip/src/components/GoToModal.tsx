import React, { useState, useEffect, useRef } from 'react';
import { Search, X, BookOpen, Scale, PieChart, Users, Package, Plus, Receipt, FileSpreadsheet } from 'lucide-react';
import { ActiveScreen, VoucherType, Ledger } from '../types/tally';
import { triggerHaptic, soundManager } from '../utils/haptics';

interface GoToModalProps {
  isOpen: boolean;
  ledgers: Ledger[];
  onClose: () => void;
  onNavigateScreen: (screen: ActiveScreen) => void;
  onCreateVoucher: (type: VoucherType) => void;
  onSelectLedger: (ledger: Ledger) => void;
}

export const GoToModal: React.FC<GoToModalProps> = ({
  isOpen,
  ledgers,
  onClose,
  onNavigateScreen,
  onCreateVoucher,
  onSelectLedger,
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
      setQuery('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const quickLinks = [
    { label: 'Day Book (Register)', screen: 'daybook' as ActiveScreen, icon: BookOpen, type: 'nav' },
    { label: 'Balance Sheet (Final Accounts)', screen: 'balancesheet' as ActiveScreen, icon: Scale, type: 'nav' },
    { label: 'Profit & Loss Account', screen: 'profitloss' as ActiveScreen, icon: PieChart, type: 'nav' },
    { label: 'Trial Balance', screen: 'trialbalance' as ActiveScreen, icon: FileSpreadsheet, type: 'nav' },
    { label: 'Stock Summary (Inventory)', screen: 'stocksummary' as ActiveScreen, icon: Package, type: 'nav' },
    { label: 'GST Reports (GSTR-1 & 3B)', screen: 'gst_reports' as ActiveScreen, icon: Receipt, type: 'nav' },
    { label: 'Ledgers & Chart of Accounts', screen: 'ledgers' as ActiveScreen, icon: Users, type: 'nav' },
    { label: 'Create Sales Voucher (F8)', voucherType: 'sales' as VoucherType, icon: Plus, type: 'voucher' },
    { label: 'Create Payment Voucher (F5)', voucherType: 'payment' as VoucherType, icon: Plus, type: 'voucher' },
    { label: 'Create Receipt Voucher (F6)', voucherType: 'receipt' as VoucherType, icon: Plus, type: 'voucher' },
    { label: 'Create Purchase Bill (F9)', voucherType: 'purchase' as VoucherType, icon: Plus, type: 'voucher' },
    { label: 'Create Contra Voucher (F4)', voucherType: 'contra' as VoucherType, icon: Plus, type: 'voucher' },
  ];

  const filteredLinks = quickLinks.filter((item) =>
    item.label.toLowerCase().includes(query.toLowerCase())
  );

  const filteredLedgers = query.trim()
    ? ledgers.filter((l) => l.name.toLowerCase().includes(query.toLowerCase())).slice(0, 5)
    : [];

  const handleSelectNav = (screen: ActiveScreen) => {
    triggerHaptic('light');
    soundManager.playKeyClick();
    onNavigateScreen(screen);
    onClose();
  };

  const handleSelectVoucher = (vType: VoucherType) => {
    triggerHaptic('light');
    soundManager.playKeyClick();
    onCreateVoucher(vType);
    onClose();
  };

  const handleSelectLedgerItem = (ledger: Ledger) => {
    triggerHaptic('light');
    soundManager.playKeyClick();
    onSelectLedger(ledger);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-start justify-center p-3 pt-12 sm:pt-16">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 text-slate-800 dark:text-slate-100 flex flex-col max-h-[80vh]">
        {/* Search Header */}
        <div className="p-3 bg-emerald-950 text-white flex items-center gap-2">
          <Search className="w-4 h-4 text-emerald-400" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Go To (Alt+G): Type report, voucher, or party..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 bg-transparent text-sm text-white placeholder-emerald-300/60 focus:outline-none"
          />
          <button
            onClick={onClose}
            className="p-1 rounded text-emerald-300 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results List */}
        <div className="flex-1 overflow-y-auto p-2 divide-y divide-slate-100 dark:divide-slate-800 text-xs">
          {/* Ledgers Matches if query */}
          {filteredLedgers.length > 0 && (
            <div className="py-2">
              <div className="px-2 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
                Party Ledgers
              </div>
              {filteredLedgers.map((l) => (
                <button
                  key={l.id}
                  onClick={() => handleSelectLedgerItem(l)}
                  className="w-full px-2.5 py-2 flex items-center justify-between rounded-xl hover:bg-emerald-50 dark:hover:bg-slate-800 text-left transition-colors"
                >
                  <div>
                    <span className="font-semibold text-slate-900 dark:text-white">{l.name}</span>
                    <span className="text-[10px] text-slate-400 block font-mono">{l.group}</span>
                  </div>
                  <span className="text-[10px] text-emerald-600 font-mono">View Statement →</span>
                </button>
              ))}
            </div>
          )}

          {/* Quick Actions / Navigation */}
          <div className="py-2">
            <div className="px-2 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Reports & Actions
            </div>
            {filteredLinks.map((item, idx) => {
              const Icon = item.icon;
              return (
                <button
                  key={idx}
                  onClick={() => {
                    if (item.type === 'nav' && item.screen) handleSelectNav(item.screen);
                    else if (item.type === 'voucher' && item.voucherType) handleSelectVoucher(item.voucherType);
                  }}
                  className="w-full px-2.5 py-2 flex items-center gap-2.5 rounded-xl hover:bg-emerald-50 dark:hover:bg-slate-800 text-left transition-colors"
                >
                  <div className="w-6 h-6 rounded-lg bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center">
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                  <span className="font-medium text-slate-800 dark:text-slate-200">
                    {item.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
