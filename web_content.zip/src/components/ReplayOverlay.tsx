import React, { useEffect } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  SkipBack,
  SkipForward,
  Video,
  Eye,
  Camera,
  X,
  Compass,
  Tv,
} from 'lucide-react';
import {
  AUTOMATED_LEVELS,
  CinematicCameraAngle,
  ReplayPlaybackState,
} from '../types/game';

interface ReplayOverlayProps {
  levelIndex: number;
  replayState: ReplayPlaybackState;
  onTogglePlay: () => void;
  onSeek: (time: number) => void;
  onChangeSpeed: (speed: number) => void;
  onChangeCameraAngle: (angle: CinematicCameraAngle) => void;
  onExitReplay: () => void;
}

const CAMERA_ANGLES: Array<{
  id: CinematicCameraAngle;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
}> = [
  {
    id: 'broadcast',
    label: 'TV Broadcast',
    icon: Tv,
    description: 'Trackside telephoto broadcast towers',
  },
  {
    id: 'drone',
    label: 'Aerial Drone',
    icon: Video,
    description: 'Dynamic sweeping helicopter chase',
  },
  {
    id: 'bumper',
    label: 'Bumper Rush',
    icon: Camera,
    description: 'Ultra-low asphalt splitter view',
  },
  {
    id: 'orbit',
    label: 'Dynamic Arc',
    icon: Compass,
    description: 'Smooth 360 cinematic dolly orbit',
  },
  {
    id: 'wheel',
    label: 'Wheel Cam',
    icon: Eye,
    description: 'Rocker panel front-tire steering view',
  },
];

const SPEED_OPTIONS = [0.5, 1.0, 2.0];

function formatTimecode(seconds: number): string {
  const clamped = Math.max(0, seconds);
  const mins = Math.floor(clamped / 60);
  const secs = Math.floor(clamped % 60);
  const tenths = Math.floor((clamped * 10) % 10);
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}.${tenths}`;
}

export const ReplayOverlay: React.FC<ReplayOverlayProps> = ({
  levelIndex,
  replayState,
  onTogglePlay,
  onSeek,
  onChangeSpeed,
  onChangeCameraAngle,
  onExitReplay,
}) => {
  const currentLevel = AUTOMATED_LEVELS[levelIndex] || AUTOMATED_LEVELS[0];
  const { isPlaying, currentTime, duration, playbackSpeed, cameraAngle } = replayState;

  // Keyboard controls for replay
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLSelectElement) return;

      if (e.code === 'Space') {
        e.preventDefault();
        onTogglePlay();
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        onSeek(Math.max(0, currentTime - 2));
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        onSeek(Math.min(duration, currentTime + 2));
      } else if (e.code === 'KeyC') {
        e.preventDefault();
        const currentIdx = CAMERA_ANGLES.findIndex((a) => a.id === cameraAngle);
        const nextIdx = (currentIdx + 1) % CAMERA_ANGLES.length;
        onChangeCameraAngle(CAMERA_ANGLES[nextIdx].id);
      } else if (e.code === 'Escape') {
        e.preventDefault();
        onExitReplay();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentTime, duration, cameraAngle, onTogglePlay, onSeek, onChangeCameraAngle, onExitReplay]);

  const currentCam = CAMERA_ANGLES.find((c) => c.id === cameraAngle) || CAMERA_ANGLES[0];
  const progressRatio = duration > 0 ? Math.min(1, Math.max(0, currentTime / duration)) : 0;

  return (
    <div className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between overflow-hidden select-none">
      {/* Top Cinematic Letterbox Bar + Telemetry Broadcast Strip */}
      <div className="w-full bg-gradient-to-b from-black/95 via-black/80 to-transparent pt-3 pb-8 px-6 pointer-events-auto">
        <div className="max-w-5xl mx-auto flex items-center justify-between gap-4">
          {/* Left: Replay Mode Badge & Level Identity */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-2.5 py-1 rounded bg-red-600/25 border border-red-500/40 text-red-400 text-xs font-mono font-bold tracking-wider">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              <span>REPLAY (30S)</span>
            </div>
            <div>
              <div className="font-display text-sm font-bold text-white tracking-wide">
                {currentLevel.name}
              </div>
              <div className="text-[11px] text-slate-400">
                Camera: <span className="text-amber-400 font-semibold">{currentCam.label}</span> · {currentCam.description}
              </div>
            </div>
          </div>

          {/* Center: Live Timecode Readout */}
          <div className="hidden sm:flex items-center gap-2 px-3 py-1 rounded-lg bg-[#090d16]/90 border border-white/10 font-mono-tabular text-sm">
            <span className="text-white font-bold">{formatTimecode(currentTime)}</span>
            <span className="text-slate-500">/</span>
            <span className="text-slate-400">{formatTimecode(duration)}</span>
            <span className="ml-2 text-xs text-amber-400 font-semibold">{playbackSpeed}x</span>
          </div>

          {/* Right: Exit Replay Button */}
          <button
            onClick={onExitReplay}
            className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-white/10 transition-colors cursor-pointer"
            title="Exit Replay (Esc)"
          >
            <X className="w-3.5 h-3.5" />
            <span>Exit Replay</span>
          </button>
        </div>
      </div>

      {/* Center 3D viewport is 100% unobstructed */}
      <div />

      {/* Bottom Cinematic Letterbox Bar + Replay Controls Dock */}
      <div className="w-full bg-gradient-to-t from-black/95 via-black/85 to-transparent pb-4 pt-8 px-6 pointer-events-auto">
        <div className="max-w-4xl mx-auto rounded-2xl bg-[#090d16]/95 border border-white/15 p-3.5 shadow-2xl space-y-3">
          {/* Interactive Scrubbing Timeline */}
          <div className="space-y-1">
            <div className="flex justify-between text-[11px] font-mono-tabular text-slate-400 px-1">
              <span>-{formatTimecode(Math.max(0, duration - currentTime))}</span>
              <span className="text-amber-400 font-semibold">
                {formatTimecode(currentTime)} / {formatTimecode(duration)}
              </span>
              <span className="text-emerald-400 font-semibold">FINISH</span>
            </div>

            <div className="relative group w-full h-6 flex items-center cursor-pointer">
              {/* Track Background */}
              <input
                type="range"
                min={0}
                max={Math.max(0.1, duration)}
                step={0.05}
                value={currentTime}
                onChange={(e) => onSeek(parseFloat(e.target.value))}
                aria-label="Seek Replay Timeline"
                className="w-full h-2 rounded-lg bg-slate-800 accent-amber-500 cursor-pointer focus:outline-none"
              />
            </div>
          </div>

          {/* Action Toolbar: Playback Controls, Speed & Camera Angle Selector */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-white/10">
            {/* Playback Transport Buttons */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => onSeek(Math.max(0, currentTime - 5))}
                className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                title="Rewind 5s (Left Arrow)"
              >
                <SkipBack className="w-4 h-4" />
              </button>

              <button
                onClick={onTogglePlay}
                className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                title={isPlaying ? 'Pause (Space)' : 'Play (Space)'}
              >
                {isPlaying ? (
                  <>
                    <Pause className="w-4 h-4 fill-current" />
                    <span>Pause</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    <span>Play</span>
                  </>
                )}
              </button>

              <button
                onClick={() => onSeek(Math.min(duration, currentTime + 5))}
                className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                title="Skip Forward 5s (Right Arrow)"
              >
                <SkipForward className="w-4 h-4" />
              </button>

              <button
                onClick={() => onSeek(0)}
                className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                title="Restart Replay"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              {/* Speed Buttons */}
              <div className="flex items-center gap-1 ml-2 pl-2 border-l border-white/10">
                {SPEED_OPTIONS.map((speed) => (
                  <button
                    key={speed}
                    onClick={() => onChangeSpeed(speed)}
                    className={`px-2 py-1 rounded text-[11px] font-mono-tabular font-semibold transition-colors ${
                      playbackSpeed === speed
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-slate-800 text-slate-300 hover:text-white'
                    }`}
                  >
                    {speed}x
                  </button>
                ))}
              </div>
            </div>

            {/* Cinematic Camera Angles */}
            <div className="flex items-center gap-1 overflow-x-auto">
              <span className="text-[11px] text-slate-400 mr-1 hidden md:inline">Camera (C):</span>
              {CAMERA_ANGLES.map((cam) => {
                const Icon = cam.icon;
                const isSelected = cam.id === cameraAngle;
                return (
                  <button
                    key={cam.id}
                    onClick={() => onChangeCameraAngle(cam.id)}
                    className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
                      isSelected
                        ? 'bg-cyan-500 text-slate-950 shadow-sm'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
                    }`}
                    title={cam.description}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{cam.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
