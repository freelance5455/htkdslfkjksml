import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";

const KEY = "stardex-18";

export function AgeGate({ children }: { children: React.ReactNode }) {
  const [blocked, setBlocked] = useState<boolean | null>(null);

  useEffect(() => {
    setBlocked(localStorage.getItem(KEY) !== "1");
  }, []);

  if (blocked === null) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-background text-foreground">
        <p className="font-display text-4xl tracking-tight">STARDEX</p>
      </div>
    );
  }

  if (!blocked) return children;

  return (
    <div className="flex min-h-dvh flex-col items-center justify-center bg-background px-6 text-center text-foreground">
      <p className="text-xs font-medium uppercase tracking-[0.22em] text-muted-foreground">Private library</p>
      <h1 className="mt-4 font-display text-5xl font-medium tracking-tight">STARDEX</h1>
      <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground">
        This library is for adults only. Confirm you are 18 or older to continue. Media stays on this device.
      </p>
      <div className="mt-8 flex w-full max-w-xs flex-col gap-2">
        <Button
          className="w-full"
          onClick={() => {
            localStorage.setItem(KEY, "1");
            setBlocked(false);
          }}
        >
          I am 18 or older
        </Button>
        <Button
          variant="ghost"
          className="w-full text-muted-foreground"
          onClick={() => {
            window.location.href = "https://www.google.com";
          }}
        >
          Leave
        </Button>
      </div>
    </div>
  );
}
