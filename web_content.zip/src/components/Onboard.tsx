"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Dices, Zap } from "lucide-react";
import { useMindStore, type MindState } from "@/lib/store";
import { sfx } from "@/lib/sound";

const NAME_A = ["IRON", "NULL", "CIPHER", "VOID", "APEX", "SIGMA", "KOAN", "DARK", "QUIET", "HELIX", "FERMAT", "GOEDEL", "TESLA", "MONAD", "EVENT", "ENTROPY"];
const NAME_B = ["LATTICE", "WRAITH", "SAGE", "ORACLE", "VECTOR", "ENGINE", "SCHOLAR", "GHOST", "LOOP", "SPARK", "SEER", "FORGE", "NODE", "FATHOM", "PRISM", "DRIVE"];

function suggest() {
  const a = NAME_A[Math.floor(Math.random() * NAME_A.length)];
  const b = NAME_B[Math.floor(Math.random() * NAME_B.length)];
  const n = Math.floor(Math.random() * 900) + 100;
  return `${a} ${b} ${n}`;
}

export default function Onboard({ onDone }: { onDone: (m: MindState) => void }) {
  const [alias, setAlias] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const setMind = useMindStore((s) => s.setMind);

  useEffect(() => setAlias(suggest()), []);

  async function submit() {
    const name = alias.trim();
    if (name.length < 2) {
      setErr("The Crucible requires a name — two characters minimum.");
      return;
    }
    setBusy(true);
    setErr("");
    try {
      const res = await fetch("/api/minds", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ alias: name }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed");
      const m: MindState = {
        id: data.mind.id,
        alias: data.mind.alias,
        creativity: 0,
        imagination: 0,
        pattern: 0,
        mindIndex: 0,
        bestRing: 0,
        streak: 0,
        bestStreak: 0,
        title: "The Unformed",
      };
      setMind(m);
      sfx.ascend();
      onDone(m);
    } catch {
      setErr("The chamber rejected the request. Retry.");
      setBusy(false);
    }
  }

  return (
    <div className="relative z-10 flex min-h-screen items-center justify-center px-5">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
        className="panel panel-hot w-full max-w-lg p-10"
      >
        <p className="font-mono text-[10px] tracking-[0.4em] text-violet-x">ONE STEP. NO FORMS. NO ACCOUNTS.</p>
        <h2 className="mt-4 font-display text-4xl leading-tight">
          This is the <em className="text-glow-gold not-italic text-amber-x">only</em> gate
        </h2>
        <p className="mt-4 text-sm leading-relaxed text-ash">
          Press <span className="text-ivory">ENTER</span> — your mind is registered and Ring 1 detonates
          immediately. Every verdict is archived under the name below.
        </p>

        <div className="mt-8 flex gap-2">
          <input
            value={alias}
            onChange={(e) => setAlias(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !busy && submit()}
            placeholder="NAME YOUR MIND"
            maxLength={24}
            autoFocus
            className="w-full border hairline bg-void/70 px-4 py-3 font-mono text-sm tracking-[0.25em] text-ivory placeholder:text-ash/50 focus:border-violet-x focus:outline-none"
          />
          <button
            onClick={() => { sfx.click(); setAlias(suggest()); }}
            title="Reroll name"
            className="border hairline px-4 text-ash transition-colors hover:border-violet-x/60 hover:text-violet-x"
          >
            <Dices className="h-4 w-4" />
          </button>
        </div>
        {err && <p className="mt-3 font-mono text-[11px] tracking-widest text-blood">{err}</p>}
        <button
          onClick={submit}
          disabled={busy}
          className="btn-crucible mt-6 flex w-full items-center justify-center gap-3 border border-violet-x/60 px-6 py-4 font-mono text-xs tracking-[0.3em] text-ivory disabled:opacity-40"
        >
          <Zap className="h-4 w-4" />
          {busy ? "ARMING…" : "ENTER — TRIALS FIRE INSTANTLY"}
        </button>
        <p className="mt-4 text-center font-mono text-[10px] tracking-[0.25em] text-ash/60">
          KEYS 1–4 ANSWER · ENTER ADVANCES
        </p>
      </motion.div>
    </div>
  );
}
