// JUHNKRIX MUSIKA - JMEarningsLedger Component
// Displays a detailed transaction-style table showing JMC earned from listening, sharing, mining, and staking.

import React, { useState, useEffect } from 'react';
import { Coins, Download, Sparkles, TrendingUp, Activity, CheckCircle2, Calendar } from 'lucide-react';

export interface EarningsLedgerItem {
  id: string;
  activityType: 'MOBILE_MINING' | 'STAKING_REWARD' | 'ANNOINTED_LISTENING' | 'PROPHECY_SHARING' | 'APP_INSTALL';
  amountJmc: number;
  fiatValueNgn: number;
  timestamp: string;
  status: 'SETTLED' | 'CONFIRMED';
  txHash: string;
}

const EARNINGS_LEDGER_STORAGE_KEY = 'jm_earnings_transaction_ledger_v1';

export const JMEarningsLedger: React.FC = () => {
  const [ledgerItems, setLedgerItems] = useState<EarningsLedgerItem[]>(() => {
    try {
      const stored = localStorage.getItem(EARNINGS_LEDGER_STORAGE_KEY);
      if (stored) return JSON.parse(stored);
    } catch {}

    // Seeded initial records
    return [
      {
        id: 'earn-001',
        activityType: 'MOBILE_MINING',
        amountJmc: 0.0450,
        fiatValueNgn: 2394,
        timestamp: new Date().toLocaleDateString() + ', 10:30 AM',
        status: 'CONFIRMED',
        txHash: '0x8f7a93c4e2b109786543d2e1f0a9b8c7d6e5f4a3'
      },
      {
        id: 'earn-002',
        activityType: 'ANNOINTED_LISTENING',
        amountJmc: 0.0210,
        fiatValueNgn: 1117,
        timestamp: new Date().toLocaleDateString() + ', 09:15 AM',
        status: 'SETTLED',
        txHash: '0x71cB31aB4983df50201Cd98246eD427e02914Ab5'
      },
      {
        id: 'earn-003',
        activityType: 'STAKING_REWARD',
        amountJmc: 0.0840,
        fiatValueNgn: 4468,
        timestamp: new Date().toLocaleDateString() + ', 08:00 AM',
        status: 'CONFIRMED',
        txHash: '0x3a2b1c0f9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b'
      },
      {
        id: 'earn-004',
        activityType: 'PROPHECY_SHARING',
        amountJmc: 0.0150,
        fiatValueNgn: 798,
        timestamp: new Date().toLocaleDateString() + ', 07:45 AM',
        status: 'SETTLED',
        txHash: '0x11223344556677889900aabbccddeeff00112233'
      }
    ];
  });

  const handleExportCsv = () => {
    try {
      let csv = 'ID,Activity Type,Amount JMC,Value NGN,Timestamp,Status,TxHash\n';
      ledgerItems.forEach(item => {
        csv += `"${item.id}","${item.activityType}",${item.amountJmc},${item.fiatValueNgn},"${item.timestamp}","${item.status}","${item.txHash}"\n`;
      });
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `JUHNKRIX_EARNINGS_LEDGER_${Date.now()}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="bg-slate-900/90 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-amber-100">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-amber-500/20 pb-5">
        <div className="flex items-center space-x-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-700 text-slate-950 flex items-center justify-center font-bold text-2xl shadow-lg shadow-emerald-500/30">
            📜
          </div>
          <div>
            <h3 className="text-xl font-black font-serif text-amber-100">
              DETAILED JMC EARNINGS TRANSACTION LEDGER
            </h3>
            <p className="text-xs text-slate-400">
              Transparent breakdown of every JMC fraction earned from listening, sharing, mining, and staking.
            </p>
          </div>
        </div>

        <button
          onClick={handleExportCsv}
          className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center space-x-2 transition-all cursor-pointer shadow-md"
        >
          <Download className="w-4 h-4 text-amber-400" />
          <span>Export Earnings CSV</span>
        </button>
      </div>

      {/* Transaction Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs font-mono">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400">
              <th className="pb-3 font-bold">Activity Type</th>
              <th className="pb-3 font-bold">Earned JMC</th>
              <th className="pb-3 font-bold">Fiat Value (NGN)</th>
              <th className="pb-3 font-bold">Timestamp</th>
              <th className="pb-3 font-bold">Status</th>
              <th className="pb-3 font-bold text-right">Verification Hash</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {ledgerItems.map((item) => (
              <tr key={item.id} className="hover:bg-slate-950/50 transition-colors">
                <td className="py-3.5 font-bold text-amber-200">
                  <span className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-xs">
                    <span>⚡</span>
                    <span>{item.activityType.replace('_', ' ')}</span>
                  </span>
                </td>
                <td className="py-3.5 text-emerald-400 font-black">
                  +{item.amountJmc.toFixed(4)} JMC
                </td>
                <td className="py-3.5 text-amber-300">
                  ₦{item.fiatValueNgn.toLocaleString()}
                </td>
                <td className="py-3.5 text-slate-400 text-[11px]">
                  {item.timestamp}
                </td>
                <td className="py-3.5">
                  <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-400/30">
                    {item.status}
                  </span>
                </td>
                <td className="py-3.5 text-right text-[10px] text-slate-500 truncate max-w-[120px]">
                  {item.txHash}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
