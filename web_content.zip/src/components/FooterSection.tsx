import React from "react";
import { ArrowRight, Navigation, MapPin, Phone, MessageCircle, Instagram, ExternalLink } from "lucide-react";
import { RESTAURANT_INFO } from "../data/restaurantInfo";

interface FooterSectionProps {
  onOpenMenu: () => void;
  onOrderOnline: () => void;
}

export const FooterSection: React.FC<FooterSectionProps> = ({
  onOpenMenu,
  onOrderOnline,
}) => {
  const scrollToSection = (id: string) => {
    const elem = document.getElementById(id);
    if (elem) elem.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <footer className="bg-[#17201C] text-[#F4F0E7]">
      {/* Editorial Final CTA Section */}
      <section className="py-20 sm:py-28 px-6 border-b border-[#D8D0C2]/20">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <div className="text-xs font-semibold tracking-[0.25em] uppercase text-[#9BAF82]">
            TABLES RESERVED & PARCELS PREPARED
          </div>

          <h2 className="font-serif text-4xl sm:text-6xl lg:text-7xl leading-[1.05] tracking-tight text-[#F4F0E7]">
            COME EAT WITH US.
            <br />
            <span className="italic font-light text-[#D8D0C2]">OR BRING KAL O R E E Z HOME.</span>
          </h2>

          <p className="text-sm sm:text-base text-[#D8D0C2]/80 font-sans max-w-xl mx-auto leading-relaxed">
            Whether taking an unhurried morning seat on our veranda or enjoying clean cooking delivered across Vizag, wholesome dining is always ready.
          </p>

          <div className="pt-4 flex flex-wrap items-center justify-center gap-4">
            <button
              type="button"
              onClick={onOpenMenu}
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-[#F4F0E7] text-[#17201C] text-xs font-semibold tracking-[0.2em] uppercase hover:bg-[#9BAF82] transition-colors cursor-pointer"
            >
              <span>EXPLORE MENU</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            {/* Direct Call Symbol Button */}
            <a
              href={`tel:${RESTAURANT_INFO.phone}`}
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-[#9BAF82] text-[#17201C] text-xs font-semibold tracking-[0.18em] uppercase hover:bg-white transition-colors cursor-pointer"
              title="Direct call to Kaloreez desk"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>CALL DIRECTLY: {RESTAURANT_INFO.phoneDisplay}</span>
            </a>

            <a
              href={RESTAURANT_INFO.links.googleMapsDirect}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-[#D8D0C2]/40 text-[#D8D0C2] hover:text-[#F4F0E7] hover:border-[#F4F0E7] text-xs font-semibold tracking-[0.18em] uppercase transition-colors"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>LIVE GOOGLE MAPS</span>
            </a>
          </div>
        </div>
      </section>

      {/* Primary Footer Content */}
      <div className="max-w-7xl mx-auto px-6 py-16 sm:py-20">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 sm:gap-12 pb-16 border-b border-[#D8D0C2]/15">
          {/* Brand Column */}
          <div className="md:col-span-5 space-y-4">
            <div className="font-serif text-3xl sm:text-4xl tracking-[0.15em] text-[#F4F0E7]">
              KAL O R E E Z
            </div>
            <div className="text-xs uppercase tracking-[0.25em] text-[#9BAF82]">
              THE WHOLESOME EATERY · VISAKHAPATNAM, INDIA
            </div>
            <p className="text-xs sm:text-sm text-[#D8D0C2]/70 font-sans max-w-sm leading-relaxed">
              Quiet luxury hospitality and nourishing food prepared with unrefined oils, single-origin Araku coffee, and honest culinary discipline in Daspalla Hills.
            </p>

            <div className="pt-2 space-y-2 text-xs text-[#D8D0C2]/80">
              <div className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#9BAF82] shrink-0 mt-0.5" />
                <span>{RESTAURANT_INFO.address.fullText}</span>
              </div>
              {/* Direct clickable phone number */}
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-[#9BAF82] shrink-0" />
                <a
                  href={`tel:${RESTAURANT_INFO.phone}`}
                  className="hover:text-[#9BAF82] transition-colors font-mono"
                  title="Direct Call"
                >
                  {RESTAURANT_INFO.phoneDisplay}
                </a>
                <span className="text-[10px] text-[#9BAF82] font-semibold">(Tap to call)</span>
              </div>
            </div>

            {/* Social & Platform links */}
            <div className="pt-3 flex flex-wrap items-center gap-3">
              <a
                href={RESTAURANT_INFO.links.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-[#D8D0C2]/30 text-xs text-[#D8D0C2] hover:text-[#F4F0E7] hover:border-[#F4F0E7] transition-colors"
              >
                <Instagram className="w-3.5 h-3.5 text-[#9BAF82]" />
                <span>Instagram</span>
              </a>
              <a
                href={RESTAURANT_INFO.links.whatsapp}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-[#D8D0C2]/30 text-xs text-[#D8D0C2] hover:text-[#F4F0E7] hover:border-[#F4F0E7] transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5 text-[#9BAF82]" />
                <span>WhatsApp</span>
              </a>
              <a
                href={RESTAURANT_INFO.links.zomato}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-[#D8D0C2]/30 text-xs text-[#D8D0C2] hover:text-[#F4F0E7] hover:border-[#F4F0E7] transition-colors"
              >
                <span>Zomato</span>
              </a>
              <a
                href={RESTAURANT_INFO.links.swiggy}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-[#D8D0C2]/30 text-xs text-[#D8D0C2] hover:text-[#F4F0E7] hover:border-[#F4F0E7] transition-colors"
              >
                <span>Swiggy</span>
              </a>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="md:col-span-3 space-y-3">
            <div className="text-xs uppercase tracking-widest text-[#D8D0C2]/50 font-semibold mb-2">
              Exploration
            </div>
            <ul className="space-y-2 text-xs uppercase tracking-wider font-sans text-[#D8D0C2]/80">
              <li>
                <button
                  onClick={onOpenMenu}
                  className="hover:text-[#9BAF82] transition-colors cursor-pointer"
                >
                  The Full Digital Menu
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("visit")}
                  className="hover:text-[#9BAF82] transition-colors cursor-pointer text-[#9BAF82]"
                >
                  Live Map & Directions
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("philosophy")}
                  className="hover:text-[#9BAF82] transition-colors cursor-pointer"
                >
                  Our Philosophy
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("space")}
                  className="hover:text-[#9BAF82] transition-colors cursor-pointer"
                >
                  The Space & Veranda
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("nutrition")}
                  className="hover:text-[#9BAF82] transition-colors cursor-pointer"
                >
                  Verified Nutrition
                </button>
              </li>
            </ul>
          </div>

          {/* Direct Kitchen Info */}
          <div className="md:col-span-4 space-y-3">
            <div className="text-xs uppercase tracking-widest text-[#D8D0C2]/50 font-semibold mb-2">
              Kitchen Hours & Inquiries
            </div>
            <p className="text-xs text-[#D8D0C2]/70 font-sans leading-relaxed">
              Dine-in: {RESTAURANT_INFO.hours.dineIn}.<br />
              All food prepared fresh to order using honest cold-pressed oils, oats flour, and unrefined grains.
            </p>
            <div className="pt-3 space-y-1.5">
              <div className="text-[11px] uppercase tracking-wider text-[#9BAF82]">Direct Telephone Line</div>
              <a
                href={`tel:${RESTAURANT_INFO.phone}`}
                className="block text-sm font-mono text-[#F4F0E7] hover:text-[#9BAF82] transition-colors font-bold"
              >
                {RESTAURANT_INFO.phoneDisplay}
              </a>
              <div className="text-xs text-[#D8D0C2]/60 font-mono">{RESTAURANT_INFO.email}</div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#D8D0C2]/50 font-sans">
          <div>
            © {new Date().getFullYear()} Kaloreez Wholesome Eatery. All rights reserved.
          </div>
          <div className="flex items-center gap-6">
            <span>Visakhapatnam, Andhra Pradesh</span>
            <span>·</span>
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="hover:text-[#F4F0E7] transition-colors cursor-pointer uppercase tracking-wider text-[11px]"
            >
              Back to Top ↑
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
