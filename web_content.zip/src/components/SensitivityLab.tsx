import React, { useState } from 'react';
import { 
  Crosshair, 
  Smartphone, 
  Copy, 
  Check, 
  Flame, 
  HelpCircle, 
  TrendingUp, 
  Zap, 
  Sliders, 
  Info,
  Maximize2
} from 'lucide-react';
import { DEVICE_PRESETS } from '../data/freeFireData';
import { DeviceSensPreset } from '../types';
import { sounds } from '../utils/soundEffects';

export const SensitivityLab: React.FC = () => {
  const [selectedPreset, setSelectedPreset] = useState<DeviceSensPreset>(DEVICE_PRESETS[0]);
  const [general, setGeneral] = useState<number>(DEVICE_PRESETS[0].general);
  const [redDot, setRedDot] = useState<number>(DEVICE_PRESETS[0].redDot);
  const [scope2x, setScope2x] = useState<number>(DEVICE_PRESETS[0].scope2x);
  const [scope4x, setScope4x] = useState<number>(DEVICE_PRESETS[0].scope4x);
  const [sniperScope, setSniperScope] = useState<number>(DEVICE_PRESETS[0].sniperScope);
  const [freeLook, setFreeLook] = useState<number>(DEVICE_PRESETS[0].freeLook);
  const [fireBtnSize, setFireBtnSize] = useState<number>(DEVICE_PRESETS[0].fireButtonSize);
  const [copiedCode, setCopiedCode] = useState(false);
  const [activeDragStyle, setActiveDragStyle] = useState<'j-drag' | 'straight' | 'rotation'>('j-drag');

  const applyDevicePreset = (preset: DeviceSensPreset) => {
    sounds.playClick();
    setSelectedPreset(preset);
    setGeneral(preset.general);
    setRedDot(preset.redDot);
    setScope2x(preset.scope2x);
    setScope4x(preset.scope4x);
    setSniperScope(preset.sniperScope);
    setFreeLook(preset.freeLook);
    setFireBtnSize(preset.fireButtonSize);
  };

  const applyPlaystylePreset = (type: 'onetap' | 'gloowall' | 'spray' | 'sniper') => {
    sounds.playClick();
    if (type === 'onetap') {
      setGeneral(100);
      setRedDot(98);
      setScope2x(94);
      setScope4x(90);
      setSniperScope(58);
      setFireBtnSize(44);
      setActiveDragStyle('j-drag');
    } else if (type === 'gloowall') {
      setGeneral(100);
      setRedDot(100);
      setScope2x(96);
      setScope4x(92);
      setSniperScope(62);
      setFireBtnSize(48);
      setActiveDragStyle('rotation');
    } else if (type === 'spray') {
      setGeneral(92);
      setRedDot(88);
      setScope2x(84);
      setScope4x(80);
      setSniperScope(50);
      setFireBtnSize(52);
      setActiveDragStyle('straight');
    } else if (type === 'sniper') {
      setGeneral(88);
      setRedDot(85);
      setScope2x(80);
      setScope4x(75);
      setSniperScope(42);
      setFireBtnSize(46);
      setActiveDragStyle('straight');
    }
  };

  const copySensCode = () => {
    const code = `FF-SENS://GEN=${general}&RD=${redDot}&2X=${scope2x}&4X=${scope4x}&SN=${sniperScope}&FL=${freeLook}&BTN=${fireBtnSize}%&DPI=${selectedPreset.recommendedDpi}`;
    navigator.clipboard.writeText(code);
    setCopiedCode(true);
    sounds.playClick();
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header Overview Card */}
      <div className="bg-gradient-to-r from-[#14192b] via-[#1c223c] to-[#14192b] border border-orange-500/30 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 font-rajdhani">
                CALIBRATION LAB
              </span>
              <span className="text-xs text-orange-400 font-bold flex items-center gap-1">
                <Flame className="w-3.5 h-3.5" /> Auto-Lock Headshot Tuning
              </span>
            </div>
            <h2 className="text-2xl font-bold font-heading text-white">
              Device Sensitivity & DPI Optimizer
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
              Calibrated settings specifically tuned to eliminate screen drag friction, lock crosshairs to enemy neck height, and accelerate drag speed for instant red numbers.
            </p>
          </div>

          <button
            onClick={copySensCode}
            className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white text-xs sm:text-sm font-bold rounded-xl shadow-lg shadow-orange-600/30 transition-all cursor-pointer"
          >
            {copiedCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            <span>{copiedCode ? 'Config Code Copied!' : 'Copy Sensitivity Code'}</span>
          </button>
        </div>

        {/* Playstyle Quick Loaders */}
        <div className="mt-5 pt-4 border-t border-slate-700/60 flex flex-wrap items-center gap-2">
          <span className="text-xs text-slate-400 font-semibold mr-1">One-Click Presets:</span>
          <button
            onClick={() => applyPlaystylePreset('onetap')}
            className="px-3 py-1 bg-[#1a2138] hover:bg-orange-600/30 text-amber-300 hover:text-white border border-amber-500/30 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Zap className="w-3 h-3 text-yellow-400" />
            <span>Red-Number One-Tap Drag</span>
          </button>
          <button
            onClick={() => applyPlaystylePreset('gloowall')}
            className="px-3 py-1 bg-[#1a2138] hover:bg-orange-600/30 text-cyan-300 hover:text-white border border-cyan-500/30 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Zap className="w-3 h-3 text-cyan-400" />
            <span>Fast Sit-Up Gloo Wall (360°)</span>
          </button>
          <button
            onClick={() => applyPlaystylePreset('spray')}
            className="px-3 py-1 bg-[#1a2138] hover:bg-orange-600/30 text-emerald-300 hover:text-white border border-emerald-500/30 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Zap className="w-3 h-3 text-emerald-400" />
            <span>Mid-Range Spray Lock (AR)</span>
          </button>
          <button
            onClick={() => applyPlaystylePreset('sniper')}
            className="px-3 py-1 bg-[#1a2138] hover:bg-orange-600/30 text-purple-300 hover:text-white border border-purple-500/30 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Zap className="w-3 h-3 text-purple-400" />
            <span>Double AWM Quick Scope</span>
          </button>
        </div>
      </div>

      {/* Device Profile Selector Grid */}
      <div className="space-y-2">
        <label className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
          <Smartphone className="w-4 h-4 text-orange-400" />
          Select Target Device Model
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {DEVICE_PRESETS.map((device) => {
            const isSelected = selectedPreset.id === device.id;
            return (
              <div
                key={device.id}
                onClick={() => applyDevicePreset(device)}
                className={`p-4 rounded-xl border transition-all cursor-pointer text-left ${
                  isSelected
                    ? 'bg-gradient-to-br from-[#1d243d] to-[#161c30] border-orange-500 shadow-lg shadow-orange-500/10'
                    : 'bg-[#101422] border-slate-800 hover:border-slate-700 hover:bg-[#14192a]'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-orange-500/20 text-orange-400 uppercase font-mono">
                    {device.category}
                  </span>
                  <span className="text-[11px] font-mono text-amber-300 font-bold">
                    DPI: {device.recommendedDpi}
                  </span>
                </div>
                <div className="font-bold text-white text-sm line-clamp-1">
                  {device.deviceName}
                </div>
                <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                  {device.description}
                </p>
                <div className="mt-3 pt-2.5 border-t border-slate-800 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400">Btn Size: <strong className="text-white">{device.fireButtonSize}%</strong></span>
                  <span className="text-slate-400">Drag: <strong className="text-orange-400">{device.dragTechnique}</strong></span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Sliders and Visual Drag Simulator Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sliders Column (7 cols) */}
        <div className="lg:col-span-7 bg-[#101423] border border-slate-800 rounded-2xl p-5 space-y-5 shadow-xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="font-heading font-bold text-base text-white flex items-center gap-2">
              <Sliders className="w-4 h-4 text-orange-400" />
              In-Game Sensitivity Sliders
            </h3>
            <span className="text-xs text-slate-400 font-mono">Game Version: OB44 Pro</span>
          </div>

          <div className="space-y-4">
            {/* General */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-200">General Sensitivity (Free Movement & Drag)</span>
                <span className="font-mono font-bold text-orange-400 text-sm">{general}</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={general}
                onChange={e => setGeneral(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-orange-500"
              />
              <p className="text-[11px] text-slate-400">Controls screen swipe sensitivity. 95-100 gives immediate upward drag acceleration.</p>
            </div>

            {/* Red Dot */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-200">Red Dot Sight (Iron Sight & Hip-Fire Lock)</span>
                <span className="font-mono font-bold text-amber-400 text-sm">{redDot}</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={redDot}
                onChange={e => setRedDot(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
              <p className="text-[11px] text-slate-400">Crucial for M1887, Desert Eagle and Woodpecker one-taps without scoping in.</p>
            </div>

            {/* 2X Scope */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-200">2X Scope Sensitivity</span>
                <span className="font-mono font-bold text-yellow-400 text-sm">{scope2x}</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={scope2x}
                onChange={e => setScope2x(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-yellow-500"
              />
              <p className="text-[11px] text-slate-400">Ideal for UMP, SCAR and MP5 mid-range rapid drag headshots.</p>
            </div>

            {/* 4X Scope */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-200">4X Scope Sensitivity</span>
                <span className="font-mono font-bold text-emerald-400 text-sm">{scope4x}</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={scope4x}
                onChange={e => setScope4x(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
              />
              <p className="text-[11px] text-slate-400">For AC80, Woodpecker and Groza long-range tap taps.</p>
            </div>

            {/* Sniper Scope */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-200">Sniper Scope (AWM / Kar98k / M82B)</span>
                <span className="font-mono font-bold text-cyan-400 text-sm">{sniperScope}</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={sniperScope}
                onChange={e => setSniperScope(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
              />
              <p className="text-[11px] text-slate-400">Lower sensitivity (45-65) ensures crosshair stabilizes on target without overshooting.</p>
            </div>

            {/* Free Look */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-200">Free Look (Eye Button Camera)</span>
                <span className="font-mono font-bold text-purple-400 text-sm">{freeLook}</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={freeLook}
                onChange={e => setFreeLook(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-500"
              />
            </div>
          </div>
        </div>

        {/* Fire Button & Drag Technique Visual Lab (5 cols) */}
        <div className="lg:col-span-5 space-y-5">
          {/* Fire Button Size Optimizer Card */}
          <div className="bg-[#101423] border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-heading font-bold text-base text-white flex items-center gap-2">
                <Crosshair className="w-4 h-4 text-red-500" />
                Fire Button Size & Placement
              </h3>
              <span className="font-mono text-sm font-bold text-amber-400">{fireBtnSize}%</span>
            </div>

            <div className="space-y-1">
              <input
                type="range"
                min="35"
                max="70"
                value={fireBtnSize}
                onChange={e => setFireBtnSize(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-red-500"
              />
              <div className="flex justify-between text-[11px] text-slate-500 font-mono">
                <span>35% (Max Drag)</span>
                <span>46-52% (Pro Ideal)</span>
                <span>70% (Big Thumb)</span>
              </div>
            </div>

            {/* Interactive Visual Phone Display with Fire Button */}
            <div className="relative w-full h-48 bg-[#090b14] border border-slate-800 rounded-xl overflow-hidden flex items-center justify-center select-none">
              {/* Screen crosshair grid */}
              <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 opacity-15 pointer-events-none">
                <div className="border-r border-b border-slate-500"></div>
                <div className="border-r border-b border-slate-500"></div>
                <div className="border-b border-slate-500"></div>
                <div className="border-r border-b border-slate-500"></div>
                <div className="border-r border-b border-slate-500"></div>
                <div className="border-b border-slate-500"></div>
                <div className="border-r border-slate-500"></div>
                <div className="border-r border-slate-500"></div>
                <div></div>
              </div>

              {/* Enemy head silhouette for drag target */}
              <div className="absolute top-6 right-16 flex flex-col items-center opacity-40">
                <div className="w-8 h-8 rounded-full border-2 border-red-500/80 bg-red-500/20 flex items-center justify-center text-[10px] text-red-300 font-bold">
                  HEAD
                </div>
                <div className="w-12 h-14 bg-slate-700/50 rounded-t-lg mt-0.5"></div>
              </div>

              {/* Drag Trajectory Arrow depending on technique */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none">
                <defs>
                  <marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                    <path d="M 0 0 L 10 5 L 0 10 z" fill="#ef4444" />
                  </marker>
                </defs>
                {activeDragStyle === 'straight' && (
                  <path
                    d="M 230 140 L 230 45"
                    stroke="#ef4444"
                    strokeWidth="3"
                    strokeDasharray="4 4"
                    markerEnd="url(#arrow)"
                    className="animate-pulse"
                  />
                )}
                {activeDragStyle === 'j-drag' && (
                  <path
                    d="M 230 140 Q 210 160 215 130 T 235 45"
                    stroke="#f97316"
                    strokeWidth="3"
                    fill="none"
                    markerEnd="url(#arrow)"
                    className="animate-pulse"
                  />
                )}
                {activeDragStyle === 'rotation' && (
                  <path
                    d="M 230 140 C 265 140, 265 90, 235 45"
                    stroke="#eab308"
                    strokeWidth="3"
                    fill="none"
                    markerEnd="url(#arrow)"
                  />
                )}
              </svg>

              {/* Fire Button Simulation Target */}
              <div 
                style={{ width: `${fireBtnSize * 1.5}px`, height: `${fireBtnSize * 1.5}px` }}
                className="absolute bottom-5 right-12 rounded-full border-2 border-red-500 bg-red-600/30 flex items-center justify-center shadow-lg shadow-red-500/30 transition-all duration-150"
              >
                <div className="w-4 h-4 rounded-full bg-red-500 animate-ping opacity-75"></div>
                <span className="absolute text-[10px] font-bold text-white font-mono">FIRE</span>
              </div>

              <div className="absolute top-2 left-3 text-[10px] text-slate-400 font-mono">
                Placement: Lower Right Quadrant
              </div>
            </div>

            {/* Drag Technique Switcher */}
            <div className="space-y-1.5 pt-1">
              <div className="text-xs font-semibold text-slate-300">Drag Trajectory Method:</div>
              <div className="grid grid-cols-3 gap-1.5 text-xs">
                <button
                  onClick={() => { setActiveDragStyle('j-drag'); sounds.playClick(); }}
                  className={`py-1.5 px-2 rounded-lg font-bold border transition-all cursor-pointer ${
                    activeDragStyle === 'j-drag'
                      ? 'bg-orange-600/30 border-orange-500 text-orange-300'
                      : 'bg-[#151a2d] border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  J-Shape Drag
                </button>
                <button
                  onClick={() => { setActiveDragStyle('straight'); sounds.playClick(); }}
                  className={`py-1.5 px-2 rounded-lg font-bold border transition-all cursor-pointer ${
                    activeDragStyle === 'straight'
                      ? 'bg-red-600/30 border-red-500 text-red-300'
                      : 'bg-[#151a2d] border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Straight Drag
                </button>
                <button
                  onClick={() => { setActiveDragStyle('rotation'); sounds.playClick(); }}
                  className={`py-1.5 px-2 rounded-lg font-bold border transition-all cursor-pointer ${
                    activeDragStyle === 'rotation'
                      ? 'bg-amber-600/30 border-amber-500 text-amber-300'
                      : 'bg-[#151a2d] border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Rotation Drag
                </button>
              </div>
              <p className="text-[11px] text-slate-400 mt-2">
                {activeDragStyle === 'j-drag' && '🎯 J-Drag: Pull down slightly then snap up in a curve. Best for enemies moving horizontally.'}
                {activeDragStyle === 'straight' && '⚡ Straight Drag: Direct explosive upward flick. Best for standing or close-range stationary targets.'}
                {activeDragStyle === 'rotation' && '🔄 Rotation Drag: Curve swipe matching enemy jump arc. Keeps aim locked during mid-air duels.'}
              </p>
            </div>
          </div>

          {/* Android Developer Options & DPI Recommendation Card */}
          <div className="bg-[#101423] border border-slate-800 rounded-2xl p-4 text-xs space-y-2">
            <div className="flex items-center gap-2 text-amber-400 font-bold">
              <Info className="w-4 h-4" />
              <span>Recommended OS Settings for {selectedPreset.category}:</span>
            </div>
            <ul className="text-slate-300 space-y-1 list-disc list-inside">
              <li>Smallest Width (DPI): <strong className="text-white font-mono">{selectedPreset.recommendedDpi}</strong></li>
              <li>Pointer Speed: <strong className="text-orange-400">{selectedPreset.pointerSpeed}</strong></li>
              <li>Touch & Hold Delay: <strong className="text-white">Short (0.5s)</strong></li>
              <li>Disable 'Pointer Precision Enhancement' (PC Emulator)</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
