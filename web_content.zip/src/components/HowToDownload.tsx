import React from 'react';
import { SupportedLanguage } from '../types/tiktok';
import { translations } from '../translations';
import { Share2, Clipboard, Download, CheckCircle2 } from 'lucide-react';

interface HowToDownloadProps {
  currentLang: SupportedLanguage;
}

export const HowToDownload: React.FC<HowToDownloadProps> = ({ currentLang }) => {
  const t = translations[currentLang];

  const steps = [
    {
      num: '01',
      title: t.step1Title,
      desc: t.step1Desc,
      icon: Share2,
      badge: 'Step 1'
    },
    {
      num: '02',
      title: t.step2Title,
      desc: t.step2Desc,
      icon: Clipboard,
      badge: 'Step 2'
    },
    {
      num: '03',
      title: t.step3Title,
      desc: t.step3Desc,
      icon: Download,
      badge: 'Step 3'
    }
  ];

  return (
    <section id="how-to" className="hidden py-16 sm:py-24 px-4 sm:px-6 bg-slate-950/60 border-t border-slate-800/80">
      <div className="max-w-6xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-6">
          <div className="hidden items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/60 text-cyan-400 border border-cyan-800/50 text-xs font-semibold mb-3">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Simple 3-Step Process
          </div>
          <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
            {t.howToTitle}
          </h2>
          <p className="text-slate-400 text-sm sm:text-base mt-3">
            {t.howToSubtitle}
          </p>
        </div>

        <div className="hidden grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          {steps.map((step, idx) => {
            const Icon = step.icon;
            return (
              <div
                key={idx}
                className="group relative bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-cyan-500/50 p-6 sm:p-8 rounded-3xl transition-all duration-300 shadow-xl hover:shadow-cyan-950/30 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 flex items-center justify-center group-hover:scale-110 group-hover:bg-cyan-500 group-hover:text-slate-950 transition-all duration-300 shadow-md">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-3xl font-black text-slate-700 group-hover:text-cyan-400/30 transition-colors">
                      {step.num}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white mb-2.5">
                    {step.title}
                  </h3>
                  <p className="text-slate-400 text-sm leading-relaxed">
                    {step.desc}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center gap-2 text-xs font-semibold text-cyan-400">
                  <span>Learn more</span>
                  <span className="group-hover:translate-x-1 transition-transform">&rarr;</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
