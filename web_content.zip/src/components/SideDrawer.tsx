import React from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  BookOpen,
  FileText,
  Calendar,
  Layers,
  Sparkles,
  HelpCircle,
  Shield,
  Settings,
  ChevronRight,
  Landmark,
  ShieldAlert,
  Award,
  Train,
  Briefcase,
  Crosshair,
  FileCheck2,
  PhoneCall
} from 'lucide-react';

export const SideDrawer: React.FC = () => {
  const {
    sideDrawerOpen,
    setSideDrawerOpen,
    setActiveTab,
    setSelectedCategory,
    setMockTestOpen,
    categories,
    userProfile,
    isLoggedIn,
    setAuthModalOpen,
    showToast
  } = useApp();

  if (!sideDrawerOpen) return null;

  const navigateTo = (tab: string, categoryId: string | null = null) => {
    setActiveTab(tab);
    if (categoryId) {
      setSelectedCategory(categoryId);
    }
    setSideDrawerOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const getCategoryIcon = (id: string) => {
    switch (id) {
      case 'railway': return Train;
      case 'assam-police': return ShieldAlert;
      case 'assam-govt-jobs': return Landmark;
      case 'ssc-central': return Award;
      case 'banking-finance': return Briefcase;
      case 'defence-tech': return Crosshair;
      default: return BookOpen;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm transition-opacity"
        onClick={() => setSideDrawerOpen(false)}
      />

      {/* Slide-out Menu */}
      <div className="relative w-80 max-w-[85vw] bg-[#0B192C] text-white h-full flex flex-col shadow-2xl z-10 border-r border-[#1E3E62] overflow-hidden">
        {/* Drawer Header */}
        <div className="p-4 bg-gradient-to-b from-[#07111E] to-[#0B192C] border-b border-[#1E3E62] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-400 flex items-center justify-center shadow-md">
              <BookOpen className="w-6 h-6 text-[#0B192C]" strokeWidth={2.5} />
            </div>
            <div>
              <div className="flex items-center gap-1.5 font-extrabold text-lg text-white">
                <span>NEXA</span>
                <span className="text-amber-400 text-xs px-1.5 py-0.5 rounded bg-amber-400/10 border border-amber-400/20">
                  EXAM BOOKS
                </span>
              </div>
              <p className="text-[11px] text-slate-400">Target Your Dream Govt Job</p>
            </div>
          </div>
          <button
            onClick={() => setSideDrawerOpen(false)}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User Status Bar */}
        <div className="px-4 py-3 bg-[#0E223D] border-b border-[#1E3E62] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-amber-400/20 text-amber-400 flex items-center justify-center font-bold text-sm">
              {isLoggedIn ? userProfile.name.charAt(0).toUpperCase() : 'G'}
            </div>
            <div>
              <p className="text-xs font-bold text-white">
                {isLoggedIn ? userProfile.name : 'Guest Student'}
              </p>
              <p className="text-[10px] text-slate-400 truncate max-w-[140px]">
                {isLoggedIn ? userProfile.targetExam : 'Sign in to sync books'}
              </p>
            </div>
          </div>
          {!isLoggedIn ? (
            <button
              onClick={() => {
                setSideDrawerOpen(false);
                setAuthModalOpen(true);
              }}
              className="text-[11px] font-bold text-slate-900 bg-amber-400 hover:bg-amber-300 px-2.5 py-1 rounded-md transition-colors"
            >
              Sign In
            </button>
          ) : (
            <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-full">
              PRO Student
            </span>
          )}
        </div>

        {/* Scrollable Navigation Items */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
          {/* Quick Exam Features */}
          <div>
            <div className="px-3 text-[11px] font-bold uppercase tracking-wider text-amber-400/90 mb-2">
              Exam Learning Sections
            </div>
            <div className="space-y-1">
              <button
                onClick={() => navigateTo('home')}
                className="w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium text-slate-200 hover:bg-slate-800 hover:text-amber-400 transition-colors text-left"
              >
                <span className="flex items-center gap-3">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  Home & Featured Books
                </span>
                <ChevronRight className="w-4 h-4 text-slate-600" />
              </button>

              <button
                onClick={() => navigateTo('free-pdfs')}
                className="w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium text-slate-200 hover:bg-slate-800 hover:text-emerald-400 transition-colors text-left"
              >
                <span className="flex items-center gap-3">
                  <FileText className="w-4 h-4 text-emerald-400" />
                  Free PDF Library (No Cost)
                </span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-400 font-bold px-1.5 py-0.5 rounded">
                  FREE
                </span>
              </button>

              <button
                onClick={() => {
                  setSideDrawerOpen(false);
                  setMockTestOpen(true);
                }}
                className="w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium text-slate-200 hover:bg-slate-800 hover:text-amber-400 transition-colors text-left"
              >
                <span className="flex items-center gap-3">
                  <FileCheck2 className="w-4 h-4 text-amber-400" />
                  Live Mock Tests Hub (10 MCQs)
                </span>
                <span className="text-[10px] bg-amber-500/20 text-amber-400 font-bold px-1.5 py-0.5 rounded">
                  LIVE
                </span>
              </button>

              <button
                onClick={() => navigateTo('exam-updates')}
                className="w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium text-slate-200 hover:bg-slate-800 hover:text-sky-400 transition-colors text-left"
              >
                <span className="flex items-center gap-3">
                  <Calendar className="w-4 h-4 text-sky-400" />
                  Official Exam Notifications & Calendar
                </span>
                <ChevronRight className="w-4 h-4 text-slate-600" />
              </button>

              <button
                onClick={() => navigateTo('current-affairs')}
                className="w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium text-slate-200 hover:bg-slate-800 hover:text-amber-400 transition-colors text-left"
              >
                <span className="flex items-center gap-3">
                  <Layers className="w-4 h-4 text-amber-400" />
                  Daily & Monthly Current Affairs
                </span>
                <ChevronRight className="w-4 h-4 text-slate-600" />
              </button>
            </div>
          </div>

          {/* Exam Categories */}
          <div>
            <div className="px-3 text-[11px] font-bold uppercase tracking-wider text-amber-400/90 mb-2">
              Exam Categories
            </div>
            <div className="space-y-1">
              {categories.map((cat) => {
                const Icon = getCategoryIcon(cat.id);
                return (
                  <button
                    key={cat.id}
                    onClick={() => navigateTo('categories', cat.id)}
                    className="w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium text-slate-200 hover:bg-slate-800 hover:text-amber-400 transition-colors text-left"
                  >
                    <span className="flex items-center gap-3">
                      <Icon className="w-4 h-4 text-amber-400" />
                      {cat.name}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {cat.count} books
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Admin & System */}
          <div>
            <div className="px-3 text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
              Management & Support
            </div>
            <div className="space-y-1">
              <button
                onClick={() => navigateTo('admin')}
                className="w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium text-amber-300 hover:bg-amber-400/10 transition-colors text-left border border-amber-400/20"
              >
                <span className="flex items-center gap-3">
                  <Settings className="w-4 h-4 text-amber-400" />
                  Admin Panel (Manage Store)
                </span>
                <span className="text-[10px] bg-amber-400 text-slate-950 font-bold px-1.5 py-0.5 rounded">
                  PORTAL
                </span>
              </button>

              <button
                onClick={() => {
                  setSideDrawerOpen(false);
                  showToast('Support Helpline: WhatsApp +91 98640 12345 (Mon-Sat 9 AM - 7 PM)', 'info');
                }}
                className="w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium text-slate-300 hover:bg-slate-800 transition-colors text-left"
              >
                <span className="flex items-center gap-3">
                  <PhoneCall className="w-4 h-4 text-emerald-400" />
                  WhatsApp Student Support
                </span>
                <ChevronRight className="w-4 h-4 text-slate-600" />
              </button>

              <button
                onClick={() => {
                  setSideDrawerOpen(false);
                  showToast('100% Genuine Exam Syllabus Guaranteed. Verified from official state portals.', 'info');
                }}
                className="w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium text-slate-300 hover:bg-slate-800 transition-colors text-left"
              >
                <span className="flex items-center gap-3">
                  <Shield className="w-4 h-4 text-sky-400" />
                  Official Source Policy
                </span>
                <ChevronRight className="w-4 h-4 text-slate-600" />
              </button>

              <button
                onClick={() => {
                  setSideDrawerOpen(false);
                  showToast('Contact us at support@nexaexambooks.com for bulk institute purchase.', 'info');
                }}
                className="w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium text-slate-300 hover:bg-slate-800 transition-colors text-left"
              >
                <span className="flex items-center gap-3">
                  <HelpCircle className="w-4 h-4 text-amber-400" />
                  Help Center & FAQs
                </span>
                <ChevronRight className="w-4 h-4 text-slate-600" />
              </button>
            </div>
          </div>
        </div>

        {/* Drawer Footer */}
        <div className="p-3 bg-[#07111E] border-t border-[#1E3E62] text-center text-[10px] text-slate-400">
          <p>© 2026 NEXA EXAM BOOKS</p>
          <p className="text-slate-400 text-[10px]">Guwahati & New Delhi • v2.4 Professional</p>
        </div>
      </div>
    </div>
  );
};
