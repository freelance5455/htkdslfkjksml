import React, { useState } from 'react';
import { Play, RotateCcw, Volume2, Plus, Trash2, Clock, Sparkles } from 'lucide-react';
import { SentenceItem } from '../types/tts';
import { splitIntoTeluguSentences } from '../utils/textProcessor';

interface SentenceEditorProps {
  fullText: string;
  sentences: SentenceItem[];
  onChangeSentences: (sentences: SentenceItem[]) => void;
  onPreviewSentence: (sentence: SentenceItem) => void;
  onApplyBackToText: (newText: string) => void;
  previewingSentenceId?: string | null;
}

export const SentenceEditor: React.FC<SentenceEditorProps> = ({
  fullText,
  sentences,
  onChangeSentences,
  onPreviewSentence,
  onApplyBackToText,
  previewingSentenceId,
}) => {
  const handleSplitFromMainText = () => {
    const split = splitIntoTeluguSentences(fullText);
    onChangeSentences(split);
  };

  const handleUpdateSentence = (id: string, updates: Partial<SentenceItem>) => {
    const next = sentences.map((s) => (s.id === id ? { ...s, ...updates } : s));
    onChangeSentences(next);
  };

  const handleDeleteSentence = (id: string) => {
    const next = sentences.filter((s) => s.id !== id);
    onChangeSentences(next);
  };

  const handleAddSentence = () => {
    const newItem: SentenceItem = {
      id: `sentence-${sentences.length + 1}-${Date.now().toString(36)}`,
      text: '',
      pauseAfter: 0.4,
      emphasis: 'normal',
    };
    onChangeSentences([...sentences, newItem]);
  };

  const handleSyncToMainText = () => {
    const combined = sentences.map((s) => s.text.trim()).filter(Boolean).join(' ');
    onApplyBackToText(combined);
  };

  return (
    <div className="w-full bg-[#101522] border border-slate-800/90 rounded-2xl p-4 sm:p-5 shadow-xl shadow-black/40">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <div>
          <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <span>వాక్యాల స్థాయి నియంత్రణ</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
              Sentence-Level Controls ({sentences.length})
            </span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            ప్రతి వాక్యానికి ప్రత్యేక విరామ సమయం, ఒత్తిడి (Emphasis), మరియు ప్రివ్యూ కేటాయించండి
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleSplitFromMainText}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 hover:bg-cyan-500/25 transition-all cursor-pointer"
            title="Split main text box into sentences"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>టెక్స్ట్ నుండి విభజించు (Auto Split)</span>
          </button>

          <button
            type="button"
            onClick={handleSyncToMainText}
            disabled={sentences.length === 0}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 text-slate-200 border border-slate-700 hover:bg-slate-700 disabled:opacity-40 transition-all cursor-pointer"
            title="Combine sentences back to main editor"
          >
            <span>ఎడిటర్‌కు సమకాలీకరించు (Sync)</span>
          </button>
        </div>
      </div>

      {/* Sentences List */}
      {sentences.length === 0 ? (
        <div className="p-8 text-center rounded-xl bg-slate-900/50 border border-dashed border-slate-800">
          <p className="text-sm text-slate-400">
            ఇంకా ఏ వాక్యాలు విభజించబడలేదు. ప్రధాన ఎడిటర్‌లో ఉన్న టెక్స్ట్‌ను వాక్యాలుగా విభజించడానికి{' '}
            <span className="text-cyan-400 font-semibold cursor-pointer" onClick={handleSplitFromMainText}>
              ఇక్కడ క్లిక్ చేయండి
            </span>
            .
          </p>
        </div>
      ) : (
        <div className="space-y-3 max-h-[480px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-slate-800">
          {sentences.map((item, index) => {
            const isPlaying = previewingSentenceId === item.id;
            return (
              <div
                key={item.id}
                className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all"
              >
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-xs font-mono font-bold text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-500/30">
                    వాక్యం {index + 1}
                  </span>

                  <div className="flex items-center gap-2">
                    {/* Emphasis Selector */}
                    <div className="flex items-center gap-1 text-xs">
                      <span className="text-slate-400 text-[11px] hidden sm:inline">ఒత్తిడి:</span>
                      <select
                        value={item.emphasis}
                        onChange={(e) =>
                          handleUpdateSentence(item.id, { emphasis: e.target.value as any })
                        }
                        className="bg-slate-800 border border-slate-700 rounded-lg px-2 py-1 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                      >
                        <option value="normal">సాధారణం (Normal)</option>
                        <option value="high">తీవ్ర ఒత్తిడి (High)</option>
                        <option value="dramatic">డ్రమాటిక్ (Dramatic)</option>
                        <option value="soft">మృదువుగా (Soft)</option>
                        <option value="urgent">సత్వరంగా (Urgent)</option>
                      </select>
                    </div>

                    {/* Pause control per sentence */}
                    <div className="flex items-center gap-1 text-xs">
                      <Clock className="w-3.5 h-3.5 text-purple-400" />
                      <span className="text-[11px] text-slate-400 hidden sm:inline">విరామం:</span>
                      <input
                        type="number"
                        min="0"
                        max="3"
                        step="0.1"
                        value={item.pauseAfter}
                        onChange={(e) =>
                          handleUpdateSentence(item.id, {
                            pauseAfter: parseFloat(e.target.value) || 0,
                          })
                        }
                        className="w-14 bg-slate-800 border border-slate-700 rounded-lg px-2 py-1 text-xs font-mono text-slate-200 text-center"
                      />
                      <span className="text-[10px] text-slate-500">సెక</span>
                    </div>

                    {/* Preview Button */}
                    <button
                      type="button"
                      onClick={() => onPreviewSentence(item)}
                      disabled={!item.text.trim()}
                      className={`p-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer ${
                        isPlaying
                          ? 'bg-cyan-500 text-slate-950 font-bold'
                          : 'bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                      }`}
                      title="Preview this single sentence"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span className="hidden sm:inline">వినండి</span>
                    </button>

                    {/* Delete sentence */}
                    <button
                      type="button"
                      onClick={() => handleDeleteSentence(item.id)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                      title="Remove sentence"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Sentence text input */}
                <textarea
                  rows={2}
                  value={item.text}
                  onChange={(e) => handleUpdateSentence(item.id, { text: e.target.value })}
                  className="w-full bg-[#0a0d14]/70 border border-slate-800/90 rounded-lg p-2.5 text-sm sm:text-base font-telugu text-slate-100 placeholder-slate-600 focus:outline-none focus:border-cyan-500"
                  placeholder="వాక్యాన్ని నమోదు చేయండి..."
                />
              </div>
            );
          })}
        </div>
      )}

      {/* Add sentence button */}
      <div className="mt-3 flex justify-end">
        <button
          type="button"
          onClick={handleAddSentence}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 bg-slate-900 border border-slate-800 hover:border-slate-700 hover:bg-slate-800 transition-all cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5 text-cyan-400" />
          <span>వాక్యాన్ని జోడించు (Add Sentence)</span>
        </button>
      </div>
    </div>
  );
};
