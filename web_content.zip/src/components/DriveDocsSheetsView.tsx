import React, { useCallback, useEffect, useState } from 'react';
import { motion } from 'motion/react';
import {
  Bookmark,
  ExternalLink,
  FileSpreadsheet,
  FileText,
  FolderOpen,
  Plus,
  RefreshCw,
  Search,
  Trash2,
} from 'lucide-react';
import {
  ComplaintRecord,
  ConfirmDialogState,
  InventoryItem,
  WorkspaceLink,
} from '../types/ops';
import {
  appendGoogleDocText,
  createGoogleDoc,
  createSpreadsheet,
  deleteDriveFile,
  DriveFile,
  getGoogleDoc,
  getSheetValues,
  getSpreadsheetMeta,
  GoogleDocDetail,
  listDriveFiles,
  overwriteSheetValues,
  SpreadsheetMeta,
} from '../lib/workspaceApi';
import { pinWorkspaceLink, unpinWorkspaceLink } from '../lib/firestoreOps';
import { WorkspaceTokenGate } from './WorkspaceTokenGate';

interface DriveDocsSheetsViewProps {
  ownerId: string;
  accessToken: string | null;
  isLoggingIn: boolean;
  complaints: ComplaintRecord[];
  inventory: InventoryItem[];
  pinnedLinks: WorkspaceLink[];
  onReconnectWorkspace: () => void;
  onRequestConfirm: (dialog: ConfirmDialogState) => void;
  onNotify: (msg: string, type?: 'success' | 'error') => void;
}

type SubTab = 'drive' | 'sheets' | 'docs';

export const DriveDocsSheetsView: React.FC<DriveDocsSheetsViewProps> = ({
  ownerId,
  accessToken,
  isLoggingIn,
  complaints,
  inventory,
  pinnedLinks,
  onReconnectWorkspace,
  onRequestConfirm,
  onNotify,
}) => {
  const [activeTab, setActiveTab] = useState<SubTab>('drive');
  const [driveFiles, setDriveFiles] = useState<DriveFile[]>([]);
  const [driveSearch, setDriveSearch] = useState('');
  const [driveMimeFilter, setDriveMimeFilter] = useState('all');
  const [loadingDrive, setLoadingDrive] = useState(false);

  // Sheets state
  const [selectedSheetId, setSelectedSheetId] = useState('');
  const [sheetMeta, setSheetMeta] = useState<SpreadsheetMeta | null>(null);
  const [selectedSheetTab, setSelectedSheetTab] = useState('');
  const [sheetValues, setSheetValues] = useState<string[][]>([]);
  const [loadingSheet, setLoadingSheet] = useState(false);
  const [newSheetTitle, setNewSheetTitle] = useState('');

  // Docs state
  const [selectedDocId, setSelectedDocId] = useState('');
  const [docDetail, setDocDetail] = useState<GoogleDocDetail | null>(null);
  const [loadingDoc, setLoadingDoc] = useState(false);
  const [newDocTitle, setNewDocTitle] = useState('');
  const [appendText, setAppendText] = useState('');

  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const loadDriveFiles = useCallback(async () => {
    if (!accessToken) return;
    setLoadingDrive(true);
    setErrorMsg(null);
    try {
      const files = await listDriveFiles(accessToken, {
        queryText: driveSearch,
        mimeTypeFilter: driveMimeFilter,
      });
      setDriveFiles(files);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Gagal memuat daftar berkas Google Drive.');
    } finally {
      setLoadingDrive(false);
    }
  }, [accessToken, driveSearch, driveMimeFilter]);

  useEffect(() => {
    loadDriveFiles();
  }, [loadDriveFiles]);

  const handleOpenSheet = async (spreadsheetId: string) => {
    if (!accessToken || !spreadsheetId.trim()) return;
    setSelectedSheetId(spreadsheetId.trim());
    setActiveTab('sheets');
    setLoadingSheet(true);
    setErrorMsg(null);
    try {
      const meta = await getSpreadsheetMeta(accessToken, spreadsheetId.trim());
      setSheetMeta(meta);
      const firstTab = meta.sheets[0]?.properties?.title || '';
      setSelectedSheetTab(firstTab);
      if (firstTab) {
        const vals = await getSheetValues(accessToken, spreadsheetId.trim(), firstTab);
        setSheetValues(vals);
      } else {
        setSheetValues([]);
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Gagal membaca Google Sheets.');
    } finally {
      setLoadingSheet(false);
    }
  };

  const handleSwitchSheetTab = async (tabTitle: string) => {
    if (!accessToken || !selectedSheetId) return;
    setSelectedSheetTab(tabTitle);
    setLoadingSheet(true);
    try {
      const vals = await getSheetValues(accessToken, selectedSheetId, tabTitle);
      setSheetValues(vals);
    } catch (err) {
      onNotify(err instanceof Error ? err.message : 'Gagal membaca tab spreadsheet.', 'error');
    } finally {
      setLoadingSheet(false);
    }
  };

  const handleCreateNewSheet = (e: React.FormEvent) => {
    e.preventDefault();
    if (!accessToken || !newSheetTitle.trim()) return;
    const title = newSheetTitle.trim();
    onRequestConfirm({
      open: true,
      title: 'Buat Spreadsheet Operasional Baru?',
      description: `Aplikasi akan membuat berkas Google Sheets baru bernama "${title}" di Google Drive Anda.`,
      confirmLabel: 'Buat Spreadsheet',
      onConfirm: async () => {
        const meta = await createSpreadsheet(accessToken, title, 'Data Operasional');
        setNewSheetTitle('');
        await pinWorkspaceLink(ownerId, {
          resourceType: 'sheet',
          externalId: meta.spreadsheetId,
          title: meta.properties.title,
          url: meta.spreadsheetUrl,
        });
        onNotify(`Spreadsheet "${title}" berhasil dibuat.`, 'success');
        await handleOpenSheet(meta.spreadsheetId);
        await loadDriveFiles();
      },
    });
  };

  const handleWriteComplaintsToCurrentSheet = () => {
    if (!accessToken || !sheetMeta || !selectedSheetTab) return;
    onRequestConfirm({
      open: true,
      title: `Timpa Tab "${selectedSheetTab}" dengan Data Komplain Pesanan?`,
      description: `Operasi ini akan menulis ${complaints.length} baris catatan komplain pesanan ke tab "${selectedSheetTab}" pada spreadsheet "${sheetMeta.properties.title}" mulai sel A1.`,
      confirmLabel: 'Tulis Data ke Sheets',
      variant: 'danger',
      details: [
        `Spreadsheet: ${sheetMeta.properties.title}`,
        `Tab tujuan: ${selectedSheetTab}`,
        `Jumlah komplain: ${complaints.length} baris`,
      ],
      onConfirm: async () => {
        const rows: (string | number)[][] = [
          ['No. Pesanan', 'Toko', 'Pembeli', 'Jenis Komplain', 'Kronologi', 'Status', 'PIC', 'Solusi'],
          ...complaints.map((c) => [
            c.orderCode,
            c.store,
            c.customerName,
            c.complaintType,
            c.description,
            c.status,
            c.picName || '-',
            c.resolutionNotes || '',
          ]),
        ];
        await overwriteSheetValues(accessToken, sheetMeta.spreadsheetId, selectedSheetTab, rows);
        const updatedVals = await getSheetValues(
          accessToken,
          sheetMeta.spreadsheetId,
          selectedSheetTab
        );
        setSheetValues(updatedVals);
        onNotify('Data komplain pesanan berhasil ditulis ke Google Sheets.', 'success');
      },
    });
  };

  const handleWriteInventoryToCurrentSheet = () => {
    if (!accessToken || !sheetMeta || !selectedSheetTab) return;
    onRequestConfirm({
      open: true,
      title: `Timpa Tab "${selectedSheetTab}" dengan Data Stok SKU?`,
      description: `Operasi ini akan menulis ${inventory.length} SKU gudang (semua toko) ke tab "${selectedSheetTab}" pada spreadsheet "${sheetMeta.properties.title}" mulai sel A1.`,
      confirmLabel: 'Tulis Stok ke Sheets',
      variant: 'danger',
      details: [
        `Spreadsheet: ${sheetMeta.properties.title}`,
        `Tab tujuan: ${selectedSheetTab}`,
        `Jumlah SKU: ${inventory.length} baris`,
      ],
      onConfirm: async () => {
        const rows: (string | number)[][] = [
          ['Toko', 'SKU', 'Nama Produk', 'Kategori', 'Stok', 'Min Stok', 'Harga (IDR)', 'Lokasi'],
          ...inventory.map((i) => [
            i.store,
            i.sku,
            i.productName,
            i.category,
            i.stock,
            i.minStock,
            i.unitPrice,
            i.warehouseLocation || '',
          ]),
        ];
        await overwriteSheetValues(accessToken, sheetMeta.spreadsheetId, selectedSheetTab, rows);
        const updatedVals = await getSheetValues(
          accessToken,
          sheetMeta.spreadsheetId,
          selectedSheetTab
        );
        setSheetValues(updatedVals);
        onNotify('Data stok SKU berhasil ditulis ke Google Sheets.', 'success');
      },
    });
  };

  const handleOpenDoc = async (documentId: string) => {
    if (!accessToken || !documentId.trim()) return;
    setSelectedDocId(documentId.trim());
    setActiveTab('docs');
    setLoadingDoc(true);
    setErrorMsg(null);
    try {
      const detail = await getGoogleDoc(accessToken, documentId.trim());
      setDocDetail(detail);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Gagal membaca Google Docs.');
    } finally {
      setLoadingDoc(false);
    }
  };

  const handleCreateDoc = (e: React.FormEvent) => {
    e.preventDefault();
    if (!accessToken || !newDocTitle.trim()) return;
    const title = newDocTitle.trim();
    onRequestConfirm({
      open: true,
      title: 'Buat Dokumen SOP Baru di Google Docs?',
      description: `Aplikasi akan membuat dokumen Google Docs baru berjudul "${title}" di Google Drive Anda.`,
      confirmLabel: 'Buat Dokumen',
      onConfirm: async () => {
        const created = await createGoogleDoc(accessToken, title);
        setNewDocTitle('');
        await pinWorkspaceLink(ownerId, {
          resourceType: 'doc',
          externalId: created.documentId,
          title: created.title,
          url: `https://docs.google.com/document/d/${created.documentId}/edit`,
        });
        onNotify(`Dokumen "${title}" berhasil dibuat.`, 'success');
        await handleOpenDoc(created.documentId);
        await loadDriveFiles();
      },
    });
  };

  const handleAppendDoc = (e: React.FormEvent) => {
    e.preventDefault();
    if (!accessToken || !docDetail || !appendText.trim()) return;
    const textToAdd = appendText.trim();
    onRequestConfirm({
      open: true,
      title: `Tambahkan Catatan ke "${docDetail.title}"?`,
      description: 'Teks baru akan disisipkan pada akhir dokumen Google Docs tersebut.',
      confirmLabel: 'Simpan ke Google Docs',
      details: [`Dokumen: ${docDetail.title}`, `Cuplikan: ${textToAdd.slice(0, 80)}`],
      onConfirm: async () => {
        await appendGoogleDocText(accessToken, docDetail.documentId, textToAdd);
        setAppendText('');
        const refreshed = await getGoogleDoc(accessToken, docDetail.documentId);
        setDocDetail(refreshed);
        onNotify('Teks berhasil ditambahkan ke Google Docs.', 'success');
      },
    });
  };

  const handlePinDriveFile = async (file: DriveFile) => {
    const type =
      file.mimeType === 'application/vnd.google-apps.spreadsheet'
        ? 'sheet'
        : file.mimeType === 'application/vnd.google-apps.document'
        ? 'doc'
        : 'drive';
    await pinWorkspaceLink(ownerId, {
      resourceType: type,
      externalId: file.id,
      title: file.name,
      url: file.webViewLink || `https://drive.google.com/file/d/${file.id}/view`,
    });
    onNotify(`"${file.name}" disematkan ke pintasan Workspace.`, 'success');
  };

  const handleDeleteDriveFile = (file: DriveFile) => {
    if (!accessToken) return;
    onRequestConfirm({
      open: true,
      title: `Hapus "${file.name}" dari Google Drive?`,
      description:
        'Berkas ini akan dihapus secara permanen dari Google Drive Anda. Pastikan berkas tidak lagi dibutuhkan tim.',
      confirmLabel: 'Hapus Permanen',
      variant: 'danger',
      onConfirm: async () => {
        await deleteDriveFile(accessToken, file.id);
        setDriveFiles((prev) => prev.filter((f) => f.id !== file.id));
        onNotify(`Berkas "${file.name}" telah dihapus.`, 'success');
      },
    });
  };

  const spreadsheetFiles = driveFiles.filter(
    (f) => f.mimeType === 'application/vnd.google-apps.spreadsheet'
  );
  const docFiles = driveFiles.filter(
    (f) => f.mimeType === 'application/vnd.google-apps.document'
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-5 border-b border-stone-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-stone-900 tracking-tight">
            Google Drive, Sheets & Docs
          </h1>
          <p className="text-sm text-stone-600 mt-1">
            Telusuri berkas kerja Tiga Rekan ID di Google Drive, ekspor laporan stok dan komplain ke Google Sheets, serta sunting SOP tim di Google Docs.
          </p>
        </div>
        {accessToken && (
          <div className="grid grid-cols-3 sm:inline-flex items-center gap-1 p-1 bg-stone-100 rounded-lg w-full sm:w-auto self-start">
            {(['drive', 'sheets', 'docs'] as const).map((tab) => {
              const label =
                tab === 'drive'
                  ? 'Google Drive'
                  : tab === 'sheets'
                  ? 'Google Sheets'
                  : 'Google Docs';
              const active = activeTab === tab;
              return (
                <motion.button
                  key={tab}
                  type="button"
                  whileTap={{ scale: 0.96 }}
                  onClick={() => setActiveTab(tab)}
                  className={`relative px-2 sm:px-3 py-2 sm:py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap text-center ${
                    active ? 'text-orange-700' : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  {active && (
                    <motion.span
                      layoutId="driveSubTabBg"
                      className="absolute inset-0 bg-white rounded-md shadow-sm border border-orange-200"
                      transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                    />
                  )}
                  <span className="relative z-10">{label}</span>
                </motion.button>
              );
            })}
          </div>
        )}
      </div>

      {!accessToken ? (
        <WorkspaceTokenGate
          serviceName="Google Drive, Sheets & Docs"
          onReconnect={onReconnectWorkspace}
          isLoggingIn={isLoggingIn}
        />
      ) : (
        <>
          {errorMsg && (
            <div className="p-4 text-sm text-red-700 bg-red-50 border border-red-200 rounded-xl">
              {errorMsg}
            </div>
          )}

          {/* TAB 1: GOOGLE DRIVE */}
          {activeTab === 'drive' && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.18 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start"
            >
              <section className="lg:col-span-8 bg-white border border-stone-200 rounded-xl overflow-hidden">
                <div className="p-4 border-b border-stone-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 sm:gap-3">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2 flex-1">
                    <div className="relative flex-1">
                      <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={driveSearch}
                        onChange={(e) => setDriveSearch(e.target.value)}
                        placeholder="Cari nama berkas di Google Drive..."
                        className="pl-9 pr-3 py-2 text-sm border border-stone-300 rounded-lg w-full focus:outline-none focus:border-orange-600"
                      />
                    </div>
                    <select
                      value={driveMimeFilter}
                      onChange={(e) => setDriveMimeFilter(e.target.value)}
                      className="w-full sm:w-auto px-3 py-2 text-sm border border-stone-300 rounded-lg bg-white"
                    >
                      <option value="all">Semua Tipe</option>
                      <option value="application/vnd.google-apps.spreadsheet">Google Sheets</option>
                      <option value="application/vnd.google-apps.document">Google Docs</option>
                    </select>
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.97 }}
                    type="button"
                    onClick={loadDriveFiles}
                    className="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium text-stone-700 border border-stone-300 rounded-lg hover:bg-stone-50 shrink-0"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${loadingDrive ? 'animate-spin' : ''}`} />
                    Muat Ulang
                  </motion.button>
                </div>

                {loadingDrive ? (
                  <div className="p-6 space-y-3">
                    <div className="h-10 bg-stone-100 rounded-lg" />
                    <div className="h-10 bg-stone-100 rounded-lg" />
                    <div className="h-10 bg-stone-100 rounded-lg" />
                  </div>
                ) : driveFiles.length === 0 ? (
                  <div className="p-10 text-center text-sm text-stone-600">
                    Tidak ada berkas yang ditemukan di Google Drive.
                  </div>
                ) : (
                  <div className="divide-y divide-stone-100">
                    {driveFiles.map((file) => {
                      const isSheet = file.mimeType === 'application/vnd.google-apps.spreadsheet';
                      const isDoc = file.mimeType === 'application/vnd.google-apps.document';
                      return (
                        <div
                          key={file.id}
                          className="px-4 sm:px-5 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 sm:gap-4 hover:bg-orange-50/30 transition-colors"
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            {isSheet ? (
                              <FileSpreadsheet className="w-4 h-4 text-emerald-700 shrink-0" />
                            ) : isDoc ? (
                              <FileText className="w-4 h-4 text-orange-600 shrink-0" />
                            ) : (
                              <FolderOpen className="w-4 h-4 text-stone-500 shrink-0" />
                            )}
                            <div className="min-w-0">
                              <p className="text-sm font-medium text-stone-900 truncate">
                                {file.name}
                              </p>
                              <p className="text-xs text-stone-500 font-mono truncate">
                                {isSheet ? 'Google Sheets' : isDoc ? 'Google Docs' : 'Drive File'}
                                {file.modifiedTime
                                  ? ` · Diubah ${new Date(file.modifiedTime).toLocaleDateString('id-ID')}`
                                  : ''}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center justify-end gap-1 shrink-0">
                            {isSheet && (
                              <button
                                type="button"
                                onClick={() => handleOpenSheet(file.id)}
                                className="px-2.5 py-1.5 text-xs font-medium text-emerald-700 hover:bg-emerald-50 rounded-md"
                              >
                                Buka Sheet
                              </button>
                            )}
                            {isDoc && (
                              <button
                                type="button"
                                onClick={() => handleOpenDoc(file.id)}
                                className="px-2.5 py-1.5 text-xs font-medium text-orange-700 hover:bg-orange-50 rounded-md"
                              >
                                Baca Doc
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => handlePinDriveFile(file)}
                              title="Sematkan ke pintasan"
                              className="p-2 text-stone-400 hover:text-orange-600 rounded-md"
                            >
                              <Bookmark className="w-4 h-4" />
                            </button>
                            {file.webViewLink && (
                              <a
                                href={file.webViewLink}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="p-2 text-stone-400 hover:text-stone-700 rounded-md"
                                title="Buka di tab baru"
                              >
                                <ExternalLink className="w-4 h-4" />
                              </a>
                            )}
                            <button
                              type="button"
                              onClick={() => handleDeleteDriveFile(file)}
                              title="Hapus dari Drive"
                              className="p-2 text-stone-400 hover:text-red-700 rounded-md"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </section>

              <section className="lg:col-span-4 bg-white border border-stone-200 rounded-xl overflow-hidden">
                <div className="px-5 py-4 border-b border-stone-200">
                  <h2 className="text-base font-semibold text-stone-900">Berkas Tersemat</h2>
                  <p className="text-xs text-stone-500 mt-0.5">
                    Tersimpan permanen di akun operasional Anda
                  </p>
                </div>
                {pinnedLinks.length === 0 ? (
                  <div className="p-6 text-sm text-stone-600">
                    Klik ikon penanda pada berkas Drive untuk menyematkannya di sini.
                  </div>
                ) : (
                  <div className="divide-y divide-stone-100">
                    {pinnedLinks.map((link) => (
                      <div
                        key={link.id}
                        className="px-5 py-3 flex items-center justify-between gap-3"
                      >
                        <a
                          href={link.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm font-medium text-orange-700 hover:underline truncate"
                        >
                          {link.title}
                        </a>
                        <button
                          type="button"
                          onClick={() => unpinWorkspaceLink(link.id)}
                          className="p-1 text-stone-400 hover:text-red-700 rounded shrink-0"
                          title="Lepas sematan"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </section>
            </motion.div>
          )}

          {/* TAB 2: GOOGLE SHEETS */}
          {activeTab === 'sheets' && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.18 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="bg-white border border-stone-200 rounded-xl p-5 space-y-3">
                  <h2 className="text-sm font-semibold text-stone-900">Pilih Spreadsheet dari Drive</h2>
                  <div className="flex gap-2">
                    <select
                      value={selectedSheetId}
                      onChange={(e) => handleOpenSheet(e.target.value)}
                      className="flex-1 px-3 py-2 text-sm border border-stone-300 rounded-lg bg-white"
                    >
                      <option value="">-- Pilih Google Sheets --</option>
                      {spreadsheetFiles.map((f) => (
                        <option key={f.id} value={f.id}>
                          {f.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <form
                  onSubmit={handleCreateNewSheet}
                  className="bg-white border border-stone-200 rounded-xl p-5 space-y-3"
                >
                  <h2 className="text-sm font-semibold text-stone-900">Buat Spreadsheet Baru</h2>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      required
                      value={newSheetTitle}
                      onChange={(e) => setNewSheetTitle(e.target.value)}
                      placeholder="Judul spreadsheet (misal: Rekap Stok Tiga Rekan)"
                      className="flex-1 px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                    />
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.97 }}
                      type="submit"
                      className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 whitespace-nowrap shrink-0"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Buat
                    </motion.button>
                  </div>
                </form>
              </div>

              {sheetMeta && (
                <div className="bg-white border border-stone-200 rounded-xl overflow-hidden">
                  <div className="px-5 py-4 border-b border-stone-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <h3 className="text-base font-semibold text-stone-900">
                        {sheetMeta.properties.title}
                      </h3>
                      <div className="flex flex-wrap items-center gap-2 mt-2">
                        {sheetMeta.sheets.map((s) => (
                          <button
                            key={s.properties.sheetId}
                            type="button"
                            onClick={() => handleSwitchSheetTab(s.properties.title)}
                            className={`px-3 py-1 text-xs font-medium rounded-md border transition-colors ${
                              selectedSheetTab === s.properties.title
                                ? 'bg-orange-50 border-orange-200 text-orange-700'
                                : 'bg-white border-stone-200 text-stone-600 hover:bg-stone-50'
                            }`}
                          >
                            {s.properties.title}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={handleWriteComplaintsToCurrentSheet}
                        className="px-3 py-2 text-xs font-medium text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-orange-50 hover:border-orange-200 hover:text-orange-700 whitespace-nowrap transition-colors"
                      >
                        Tulis Data Komplain ({complaints.length})
                      </button>
                      <button
                        type="button"
                        onClick={handleWriteInventoryToCurrentSheet}
                        className="px-3 py-2 text-xs font-medium text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-orange-50 hover:border-orange-200 hover:text-orange-700 whitespace-nowrap transition-colors"
                      >
                        Tulis Data SKU ({inventory.length})
                      </button>
                      <a
                        href={sheetMeta.spreadsheetUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-orange-700 border border-orange-200 rounded-lg hover:bg-orange-50 whitespace-nowrap"
                      >
                        Buka di Sheets
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>

                  {loadingSheet ? (
                    <div className="p-6 text-sm text-stone-500">Memuat isi spreadsheet...</div>
                  ) : sheetValues.length === 0 ? (
                    <div className="p-8 text-center text-sm text-stone-600">
                      Tab "{selectedSheetTab}" masih kosong. Gunakan tombol di kanan atas untuk menulis data komplain atau SKU.
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse text-xs">
                        <tbody>
                          {sheetValues.map((row, rIdx) => (
                            <tr
                              key={rIdx}
                              className={
                                rIdx === 0
                                  ? 'bg-stone-50 font-semibold text-stone-700 border-b border-stone-200'
                                  : 'border-b border-stone-100 hover:bg-orange-50/20'
                              }
                            >
                              {row.map((cell, cIdx) => (
                                <td
                                  key={cIdx}
                                  className="py-2.5 px-4 font-mono tabular-nums whitespace-nowrap"
                                >
                                  {cell}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          )}

          {/* TAB 3: GOOGLE DOCS */}
          {activeTab === 'docs' && (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.18 }}
              className="space-y-6"
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="bg-white border border-stone-200 rounded-xl p-5 space-y-3">
                  <h2 className="text-sm font-semibold text-stone-900">Buka Dokumen SOP / Laporan</h2>
                  <select
                    value={selectedDocId}
                    onChange={(e) => handleOpenDoc(e.target.value)}
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg bg-white"
                  >
                    <option value="">-- Pilih Google Docs --</option>
                    {docFiles.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.name}
                      </option>
                    ))}
                  </select>
                </div>

                <form
                  onSubmit={handleCreateDoc}
                  className="bg-white border border-stone-200 rounded-xl p-5 space-y-3"
                >
                  <h2 className="text-sm font-semibold text-stone-900">Buat Dokumen SOP Baru</h2>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      required
                      value={newDocTitle}
                      onChange={(e) => setNewDocTitle(e.target.value)}
                      placeholder="Judul dokumen (misal: SOP Penanganan Retur)"
                      className="flex-1 px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                    />
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.97 }}
                      type="submit"
                      className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 whitespace-nowrap shrink-0"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Buat
                    </motion.button>
                  </div>
                </form>
              </div>

              {docDetail && (
                <div className="bg-white border border-stone-200 rounded-xl overflow-hidden">
                  <div className="px-5 py-4 border-b border-stone-200 flex items-center justify-between gap-4">
                    <h3 className="text-base font-semibold text-stone-900">{docDetail.title}</h3>
                    <a
                      href={`https://docs.google.com/document/d/${docDetail.documentId}/edit`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-orange-700 border border-orange-200 rounded-lg hover:bg-orange-50 whitespace-nowrap"
                    >
                      Sunting di Google Docs
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>

                  {loadingDoc ? (
                    <div className="p-6 text-sm text-stone-500">Memuat isi dokumen...</div>
                  ) : (
                    <div className="p-6 space-y-6">
                      <div className="bg-stone-50 border border-stone-200 rounded-lg p-5 text-sm text-stone-800 whitespace-pre-wrap leading-relaxed min-h-[160px]">
                        {docDetail.bodyText.trim() || '(Dokumen ini masih kosong)'}
                      </div>

                      <form onSubmit={handleAppendDoc} className="space-y-3">
                        <label className="block text-xs font-semibold text-stone-700">
                          Tambahkan Log Operasional / Pembaruan SOP ke Dokumen
                        </label>
                        <textarea
                          rows={3}
                          required
                          value={appendText}
                          onChange={(e) => setAppendText(e.target.value)}
                          placeholder="Tulis catatan serah terima shift, revisi SOP, atau ringkasan insiden pengiriman..."
                          className="w-full px-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                        />
                        <motion.button
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.97 }}
                          type="submit"
                          className="px-4 py-2 text-xs font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700"
                        >
                          Sisipkan ke Google Docs
                        </motion.button>
                      </form>
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          )}
        </>
      )}
    </div>
  );
};
