import React, { useState } from 'react';
import {
  Play,
  Volume2,
  Trash2,
  Sparkles,
  Zap,
  RotateCcw,
  Plus
} from 'lucide-react';
import { Project, Track, Clip, DrumStep, DrumSoundType, DRUM_VOICES } from '../types/daw';
import { engine, PlayheadState } from '../audio/engine';
import { Knob } from './Knob';

interface StepSequencerViewProps {
  project: Project;
  playhead: PlayheadState;
  selectedTrackId: string | null;
  selectedClipId: string | null;
  onSelectTrack: (trackId: string) => void;
  onSelectClip: (clipId: string) => void;
  onUpdateProject: (updater: (prev: Project) => Project) => void;
}

export const StepSequencerView: React.FC<StepSequencerViewProps> = ({
  project,
  playhead,
  selectedTrackId,
  selectedClipId,
  onSelectTrack,
  onSelectClip,
  onUpdateProject,
}) => {
  // Find currently active drum track (or first drums track)
  const track = project.tracks.find(t => t.id === selectedTrackId && t.type === 'drums') ||
    project.tracks.find(t => t.type === 'drums') ||
    project.tracks[0];

  const clip = track.clips.find(c => c.id === selectedClipId) || track.clips[0];

  const numSteps = 16;
  const currentStep = Math.floor((playhead.currentBeat % 4) * 4);

  // Audition drum sound
  const handleAudition = (drum: DrumSoundType) => {
    engine.playTrackDrumLive(track, drum, 0.9);
  };

  // Toggle step on/off
  const handleToggleStep = (drum: DrumSoundType, stepIdx: number) => {
    if (!clip) return;
    const existing = (clip.drumSteps || []).find(
      s => s.drum === drum && s.step === stepIdx
    );

    // Audition sound
    if (!existing) {
      engine.playTrackDrumLive(track, drum, 0.85);
    }

    onUpdateProject(p => ({
      ...p,
      tracks: p.tracks.map(t =>
        t.id === track.id
          ? {
              ...t,
              clips: t.clips.map(c =>
                c.id === clip.id
                  ? {
                      ...c,
                      drumSteps: existing
                        ? (c.drumSteps || []).filter(s => !(s.drum === drum && s.step === stepIdx))
                        : [...(c.drumSteps || []), { step: stepIdx, drum, velocity: 0.9 }],
                    }
                  : c
              ),
            }
          : t
      ),
    }));
  };

  // Quick fill row
  const handleFillRow = (drum: DrumSoundType, interval: number) => {
    if (!clip) return;
    const newSteps: DrumStep[] = [];
    for (let i = 0; i < numSteps; i += interval) {
      newSteps.push({ step: i, drum, velocity: 0.9 });
    }

    onUpdateProject(p => ({
      ...p,
      tracks: p.tracks.map(t =>
        t.id === track.id
          ? {
              ...t,
              clips: t.clips.map(c =>
                c.id === clip.id
                  ? {
                      ...c,
                      drumSteps: [
                        ...(c.drumSteps || []).filter(s => s.drum !== drum),
                        ...newSteps,
                      ],
                    }
                  : c
              ),
            }
          : t
      ),
    }));
  };

  // Clear single drum voice row
  const handleClearRow = (drum: DrumSoundType) => {
    if (!clip) return;
    onUpdateProject(p => ({
      ...p,
      tracks: p.tracks.map(t =>
        t.id === track.id
          ? {
              ...t,
              clips: t.clips.map(c =>
                c.id === clip.id
                  ? {
                      ...c,
                      drumSteps: (c.drumSteps || []).filter(s => s.drum !== drum),
                    }
                  : c
              ),
            }
          : t
      ),
    }));
  };

  // Clear entire pattern
  const handleClearAll = () => {
    if (!clip) return;
    onUpdateProject(p => ({
      ...p,
      tracks: p.tracks.map(t =>
        t.id === track.id
          ? {
              ...t,
              clips: t.clips.map(c => (c.id === clip.id ? { ...c, drumSteps: [] } : c)),
            }
          : t
      ),
    }));
  };

  // Presets: Classic 808 Trap beat
  const handleLoadTrapPreset = () => {
    if (!clip) return;
    const trapSteps: DrumStep[] = [
      { step: 0, drum: 'kick', velocity: 1.0 },
      { step: 6, drum: 'kick', velocity: 0.9 },
      { step: 10, drum: 'kick', velocity: 0.95 },
      { step: 4, drum: 'snare', velocity: 0.9 },
      { step: 12, drum: 'snare', velocity: 1.0 },
      { step: 12, drum: 'clap', velocity: 0.8 },
      // 16th hats
      ...Array.from({ length: 16 }).map((_, i) => ({
        step: i,
        drum: 'hihat_closed' as DrumSoundType,
        velocity: i % 2 === 0 ? 0.85 : 0.6,
      })),
      { step: 2, drum: 'hihat_open', velocity: 0.7 },
      { step: 10, drum: 'hihat_open', velocity: 0.7 },
      { step: 15, drum: 'perc', velocity: 0.6 },
    ];

    onUpdateProject(p => ({
      ...p,
      tracks: p.tracks.map(t =>
        t.id === track.id
          ? {
              ...t,
              clips: t.clips.map(c =>
                c.id === clip.id ? { ...c, drumSteps: trapSteps } : c
              ),
            }
          : t
      ),
    }));
  };

  return (
    <div className="flex-1 flex flex-col bg-[#11141b] overflow-hidden select-none">
      {/* Sequencer Toolbar */}
      <div className="h-11 bg-[#161922] border-b border-[#252b37] px-4 flex items-center justify-between gap-3 shrink-0 flex-wrap">
        <div className="flex items-center gap-2">
          {/* Track selector */}
          <div className="flex items-center gap-1.5 bg-[#1e232e] border border-[#2f3747] rounded-lg px-2.5 py-1 text-xs">
            <span className="text-slate-400 font-medium">Drum Track:</span>
            <select
              value={track.id}
              onChange={e => {
                onSelectTrack(e.target.value);
                const sel = project.tracks.find(t => t.id === e.target.value);
                if (sel && sel.clips.length > 0) onSelectClip(sel.clips[0].id);
              }}
              className="bg-transparent text-[#ff7700] font-semibold focus:outline-none cursor-pointer"
            >
              {project.tracks
                .filter(t => t.type === 'drums')
                .map(t => (
                  <option key={t.id} value={t.id} className="bg-[#1e232e]">
                    {t.name}
                  </option>
                ))}
            </select>
          </div>

          {/* Pattern name */}
          <div className="hidden sm:flex items-center gap-1 px-2 py-1 bg-[#1a1f29] rounded text-xs text-slate-300 border border-[#2b3240]">
            <span className="text-slate-400 font-medium">Clip:</span>
            <span className="font-semibold text-slate-100">{clip ? clip.name : 'Pattern'}</span>
          </div>
        </div>

        {/* Action presets & swing */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleLoadTrapPreset}
            className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-[#242b38] hover:bg-[#313a4c] text-xs font-semibold text-[#ffca28] transition-colors"
            title="Load 808 Trap Beat Preset"
          >
            <Zap className="w-3.5 h-3.5 fill-current" />
            <span>Trap Preset</span>
          </button>

          <button
            onClick={handleClearAll}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-red-500/15 hover:bg-red-500/25 border border-red-500/30 text-red-400 text-xs font-medium transition-colors"
            title="Clear Pattern"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Clear</span>
          </button>
        </div>
      </div>

      {/* Main Step Sequencer Grid (Scrollable) */}
      <div className="flex-1 overflow-x-auto overflow-y-auto p-3 sm:p-5 flex flex-col gap-2 bg-[#0e1015]">
        {/* Step Indicator Header with Light/Dark Bar grouping */}
        <div className="flex items-center gap-2 pl-40 sm:pl-48 shrink-0">
          {Array.from({ length: 4 }).map((_, barIdx) => (
            <div
              key={barIdx}
              className="flex items-center gap-1.5 flex-1"
            >
              {Array.from({ length: 4 }).map((_, stepIdxInBar) => {
                const step = barIdx * 4 + stepIdxInBar;
                const isCurrent = playhead.isPlaying && currentStep === step;

                return (
                  <div
                    key={step}
                    className={`flex-1 h-5 rounded-md flex items-center justify-center text-[10px] font-mono font-bold transition-all ${
                      isCurrent
                        ? 'bg-[#00e676] text-black shadow-md shadow-[#00e676]/30'
                        : barIdx % 2 === 0
                        ? 'bg-[#1e232e] text-slate-400'
                        : 'bg-[#181c25] text-slate-500'
                    }`}
                  >
                    {step + 1}
                  </div>
                );
              })}
            </div>
          ))}
        </div>

        {/* Drum Channel Rows */}
        {DRUM_VOICES.map((voice) => {
          const isRowActive = clip?.drumSteps?.some(s => s.drum === voice.id);

          return (
            <div
              key={voice.id}
              className="flex items-center gap-2 h-12 bg-[#151820] border border-[#232835] rounded-xl px-2 sm:px-3 hover:border-[#32394a] transition-colors shrink-0 group"
            >
              {/* Voice Header on Left */}
              <div className="w-36 sm:w-44 flex items-center justify-between gap-1.5 shrink-0">
                <button
                  onClick={() => handleAudition(voice.id)}
                  className="flex items-center gap-2 text-left hover:brightness-125 transition-all truncate"
                  title="Audition sound"
                >
                  <div
                    className="w-3.5 h-3.5 rounded-full flex items-center justify-center shrink-0 shadow-sm"
                    style={{ backgroundColor: voice.color }}
                  >
                    <Play className="w-2 h-2 fill-black text-black ml-0.5" />
                  </div>
                  <span className="text-xs font-semibold text-slate-100 truncate">
                    {voice.name}
                  </span>
                </button>

                {/* Quick Fill Dropdown / Row Clear */}
                <div className="flex items-center gap-0.5 opacity-60 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => handleFillRow(voice.id, 2)}
                    className="px-1 py-0.5 rounded text-[9px] font-mono bg-[#212634] text-slate-400 hover:text-white"
                    title="Fill every 2 steps (8th notes)"
                  >
                    /2
                  </button>
                  <button
                    onClick={() => handleFillRow(voice.id, 4)}
                    className="px-1 py-0.5 rounded text-[9px] font-mono bg-[#212634] text-slate-400 hover:text-white"
                    title="Fill every 4 steps (quarter notes)"
                  >
                    /4
                  </button>
                  <button
                    onClick={() => handleClearRow(voice.id)}
                    className="p-1 rounded text-slate-500 hover:text-red-400"
                    title="Clear row"
                  >
                    <Trash2 className="w-2.5 h-2.5" />
                  </button>
                </div>
              </div>

              {/* 16 Step Buttons grouped in 4 beats */}
              <div className="flex items-center gap-2 flex-1">
                {Array.from({ length: 4 }).map((_, barIdx) => (
                  <div key={barIdx} className="flex items-center gap-1.5 flex-1">
                    {Array.from({ length: 4 }).map((_, stepIdxInBar) => {
                      const stepIdx = barIdx * 4 + stepIdxInBar;
                      const activeStep = (clip?.drumSteps || []).find(
                        s => s.drum === voice.id && s.step === stepIdx
                      );
                      const isCurrent = playhead.isPlaying && currentStep === stepIdx;

                      return (
                        <button
                          key={stepIdx}
                          onClick={() => handleToggleStep(voice.id, stepIdx)}
                          style={{
                            backgroundColor: activeStep ? voice.color : undefined,
                            boxShadow: activeStep
                              ? `0 0 10px ${voice.color}66`
                              : undefined,
                          }}
                          className={`flex-1 h-9 rounded-lg border transition-all active:scale-95 flex items-center justify-center relative ${
                            activeStep
                              ? 'border-white/40 text-black font-bold'
                              : barIdx % 2 === 0
                              ? 'bg-[#222836] border-[#31394c] hover:bg-[#2b3344]'
                              : 'bg-[#1a1e29] border-[#293040] hover:bg-[#232936]'
                          } ${isCurrent ? 'ring-2 ring-white/80' : ''}`}
                          title={`${voice.name} - Step ${stepIdx + 1}`}
                        >
                          {/* Inner LED pip */}
                          {activeStep && (
                            <div className="w-2 h-2 rounded-full bg-white/90 shadow-sm" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
