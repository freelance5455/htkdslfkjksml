import React, { useState } from 'react';
import {
  X,
  ArrowRightLeft,
  Calendar as CalendarIcon,
  Sparkles,
  BookOpen,
  Sun,
} from 'lucide-react';
import { LocationPreset } from '../types';
import {
  HEBREW_MONTH_NAMES_LIST,
  convertGregorianToHebrew,
  convertHebrewToGregorian,
  calculateZmanim,
  getCalendarDay,
  getHebrewNumberGematriya,
  getHebrewYearGematriya,
} from '../services/hebrewCalendarService';

interface DateConverterModalProps {
  isOpen: boolean;
  onClose: () => void;
  location: LocationPreset;
  onSelectDate: (date: Date) => void;
}

export const DateConverterModal: React.FC<DateConverterModalProps> = ({
  isOpen,
  onClose,
  location,
  onSelectDate,
}) => {
  const [conversionDirection, setConversionDirection] = useState<'greg-to-heb' | 'heb-to-greg'>(
    'greg-to-heb'
  );

  const [gregDateStr, setGregDateStr] = useState<string>(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
      d.getDate()
    ).padStart(2, '0')}`;
  });

  const todayHeb = convertGregorianToHebrew(new Date());
  const [hebDay, setHebDay] = useState<number>(todayHeb.day);
  const [hebMonth, setHebMonth] = useState<number>(todayHeb.month);
  const [hebYear, setHebYear] = useState<number>(todayHeb.year);

  if (!isOpen) return null;

  let convertedDayDetails: any = null;
  let targetDate: Date = new Date();

  if (conversionDirection === 'greg-to-heb') {
    targetDate = new Date(gregDateStr + 'T12:00:00');
    convertedDayDetails = getCalendarDay(targetDate, location);
  } else {
    try {
      targetDate = convertHebrewToGregorian(hebDay, hebMonth, hebYear);
      convertedDayDetails = getCalendarDay(targetDate, location);
    } catch {
      //
    }
  }

  const handleJumpToCalendar = () => {
    onSelectDate(targetDate);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-[#121212] rounded-2xl max-w-xl w-full border border-[#2A2A2A] shadow-2xl overflow-hidden my-8 flex flex-col text-[#D1D1D1]">
        {/* Header */}
        <div className="p-5 border-b border-[#2A2A2A] flex items-center justify-between bg-[#161616]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#252525] border border-[#3A3A3A] text-[#C5A267] flex items-center justify-center text-lg">
              <ArrowRightLeft className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-[#EAEAEA]">
                Hebrew ⇄ Gregorian Date Converter
              </h3>
              <p className="text-xs text-[#888888]">
                Instant bidirectional conversion, Parasha, and Zmanim lookup
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#888888] hover:text-[#EAEAEA] hover:bg-[#252525] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Toggle Direction */}
          <div className="flex rounded-xl bg-[#1A1A1A] p-1 border border-[#2A2A2A]">
            <button
              onClick={() => setConversionDirection('greg-to-heb')}
              className={`flex-1 py-2 rounded-lg text-xs font-semibold transition-colors ${
                conversionDirection === 'greg-to-heb'
                  ? 'bg-[#252525] text-[#C5A267] border border-[#3A3A3A]'
                  : 'text-[#666666] hover:text-[#888888]'
              }`}
            >
              Gregorian ➔ Hebrew
            </button>
            <button
              onClick={() => setConversionDirection('heb-to-greg')}
              className={`flex-1 py-2 rounded-lg text-xs font-semibold transition-colors ${
                conversionDirection === 'heb-to-greg'
                  ? 'bg-[#252525] text-[#C5A267] border border-[#3A3A3A]'
                  : 'text-[#666666] hover:text-[#888888]'
              }`}
            >
              Hebrew ➔ Gregorian
            </button>
          </div>

          {/* Inputs */}
          {conversionDirection === 'greg-to-heb' ? (
            <div>
              <label className="block text-xs font-bold text-[#888888] uppercase tracking-wider mb-1.5">
                Select Gregorian Date
              </label>
              <input
                type="date"
                value={gregDateStr}
                onChange={(e) => setGregDateStr(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-[#2A2A2A] bg-[#1A1A1A] text-sm text-[#EAEAEA] focus:border-[#C5A267] focus:outline-hidden"
              />
            </div>
          ) : (
            <div className="space-y-3">
              <label className="block text-xs font-bold text-[#888888] uppercase tracking-wider">
                Select Hebrew Date
              </label>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[10px] text-[#666666] mb-1">Day</label>
                  <select
                    value={hebDay}
                    onChange={(e) => setHebDay(parseInt(e.target.value, 10))}
                    className="w-full px-2.5 py-2 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] focus:border-[#C5A267] focus:outline-hidden"
                  >
                    {Array.from({ length: 30 }, (_, i) => i + 1).map((d) => (
                      <option key={d} value={d}>
                        {d} ({getHebrewNumberGematriya(d)})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] text-[#666666] mb-1">Month</label>
                  <select
                    value={hebMonth}
                    onChange={(e) => setHebMonth(parseInt(e.target.value, 10))}
                    className="w-full px-2.5 py-2 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] focus:border-[#C5A267] focus:outline-hidden"
                  >
                    {HEBREW_MONTH_NAMES_LIST.map((m) => (
                      <option key={m.num} value={m.num}>
                        {m.name} ({m.nameHe})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] text-[#666666] mb-1">Year</label>
                  <input
                    type="number"
                    value={hebYear}
                    onChange={(e) => setHebYear(parseInt(e.target.value, 10))}
                    className="w-full px-2.5 py-2 rounded-lg border border-[#2A2A2A] bg-[#1A1A1A] text-xs text-[#EAEAEA] focus:border-[#C5A267] focus:outline-hidden"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Results Box matching Elegant Dark */}
          {convertedDayDetails && (
            <div className="p-5 rounded-2xl bg-[#161616] border border-[#2A2A2A] space-y-3">
              <div className="text-center pb-3 border-b border-[#2A2A2A]">
                <div className="text-2xl sm:text-3xl font-bold font-serif-hebrew text-[#C5A267]" dir="rtl">
                  {convertedDayDetails.hebrewDateStrHe}
                </div>
                <div className="text-sm font-semibold text-[#EAEAEA] mt-1">
                  {convertedDayDetails.hebrewDateStr}
                </div>
                <div className="text-xs text-[#888888] mt-0.5">
                  {targetDate.toLocaleDateString('en-US', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </div>
              </div>

              {/* Highlights */}
              <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                <div className="p-2.5 rounded-xl bg-[#1A1A1A] border border-[#2A2A2A]">
                  <span className="text-[10px] text-[#888888] font-bold uppercase">Torah Portion</span>
                  <div className="font-bold text-[#EAEAEA] mt-0.5">
                    {convertedDayDetails.parasha?.name || '—'}
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-[#1A1A1A] border border-[#2A2A2A]">
                  <span className="text-[10px] text-[#888888] font-bold uppercase">Holidays</span>
                  <div className="font-bold text-[#C5A267] mt-0.5 truncate">
                    {convertedDayDetails.holidays.length > 0
                      ? convertedDayDetails.holidays.map((h: any) => h.name).join(', ')
                      : 'None'}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#2A2A2A] bg-[#161616] flex justify-between items-center">
          <button
            onClick={handleJumpToCalendar}
            className="text-xs text-[#C5A267] hover:underline font-bold"
          >
            Open in Calendar View →
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#C5A267] hover:bg-[#b59257] text-[#0F0F0F] text-xs font-bold transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
