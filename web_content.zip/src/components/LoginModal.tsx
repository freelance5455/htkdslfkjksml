import React, { useState } from 'react';
import {
  X,
  User,
  Mail,
  ShieldCheck,
  Sparkles,
  LogOut,
  LogIn,
  CheckCircle2,
  Globe
} from 'lucide-react';
import { UserProfile } from '../types';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
  onSaveProfile: (profile: UserProfile) => void;
}

const AVATAR_OPTIONS = ['⚡', '🤖', '🚀', '👤', '🔥', '👑', '💻', '🎯', '✨', '🎧'];

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  userProfile,
  onSaveProfile,
}) => {
  const [name, setName] = useState(userProfile.name);
  const [email, setEmail] = useState(userProfile.email || '');
  const [avatar, setAvatar] = useState(userProfile.avatar || '⚡');
  const [lang, setLang] = useState<'hinglish' | 'hindi' | 'english'>(userProfile.preferredLanguage || 'hinglish');
  const [statusMsg, setStatusMsg] = useState('');

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: UserProfile = {
      ...userProfile,
      name: name.trim() || 'Nova User',
      email: email.trim() || 'user@novamast.ai',
      avatar,
      isLoggedIn: true,
      preferredLanguage: lang,
    };
    onSaveProfile(updated);
    setStatusMsg('Profile successfully updated! ✨');
    setTimeout(() => {
      setStatusMsg('');
      onClose();
    }, 600);
  };

  const handleQuickLogin = (demoName: string, demoEmail: string, demoAvatar: string) => {
    const updated: UserProfile = {
      ...userProfile,
      name: demoName,
      email: demoEmail,
      avatar: demoAvatar,
      isLoggedIn: true,
      preferredLanguage: lang,
    };
    onSaveProfile(updated);
    setStatusMsg(`Logged in as ${demoName}! 🚀`);
    setTimeout(() => {
      setStatusMsg('');
      onClose();
    }, 600);
  };

  const handleLogout = () => {
    const guest: UserProfile = {
      id: 'guest',
      name: 'Guest User',
      email: 'guest@novamast.ai',
      avatar: '👤',
      isLoggedIn: false,
      joinedAt: Date.now(),
      preferredLanguage: 'hinglish',
    };
    onSaveProfile(guest);
    setName('Guest User');
    setEmail('guest@novamast.ai');
    setAvatar('👤');
    setStatusMsg('Switched to Guest Mode');
    setTimeout(() => {
      setStatusMsg('');
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-md bg-slate-950 border border-cyan-500/30 rounded-3xl p-5 sm:p-6 shadow-2xl shadow-cyan-950/60 overflow-hidden text-slate-100">
        
        {/* Top Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <User className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">User Account &amp; Profile</h3>
              <p className="text-[11px] text-slate-400">Personalize your Nova AI experience</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Current Status Banner */}
        <div className="my-4 p-3 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-cyan-500 to-violet-600 flex items-center justify-center text-2xl shadow-md">
              {avatar}
            </div>
            <div>
              <div className="font-bold text-sm text-slate-100">{name || 'Guest User'}</div>
              <div className="text-[11px] text-slate-400 truncate max-w-[180px]">{email}</div>
            </div>
          </div>

          <span className={`text-[10px] px-2.5 py-1 rounded-full font-mono font-bold ${
            userProfile.isLoggedIn
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
              : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
          }`}>
            {userProfile.isLoggedIn ? 'Active' : 'Guest'}
          </span>
        </div>

        {/* Status Toast */}
        {statusMsg && (
          <div className="mb-3 p-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>{statusMsg}</span>
          </div>
        )}

        {/* Quick One-Tap Sign In */}
        {!userProfile.isLoggedIn && (
          <div className="mb-4 space-y-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Quick 1-Tap Sign In:
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleQuickLogin('Arjun Sharma', 'arjun.sharma@gmail.com', '⚡')}
                className="flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-500/30 text-cyan-300 text-xs font-semibold transition cursor-pointer"
              >
                <span>⚡ Arjun (Pro)</span>
              </button>
              <button
                type="button"
                onClick={() => handleQuickLogin('Priya Verma', 'priya.v@gmail.com', '✨')}
                className="flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-violet-950/40 hover:bg-violet-900/50 border border-violet-500/30 text-violet-300 text-xs font-semibold transition cursor-pointer"
              >
                <span>✨ Priya (Creator)</span>
              </button>
            </div>
          </div>
        )}

        {/* Form to Edit / Custom Login */}
        <form onSubmit={handleSave} className="space-y-3">
          <div>
            <label className="block text-[11px] font-semibold text-slate-300 mb-1">
              Your Name
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Apna naam daalein (e.g. Arjun)"
                className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-300 mb-1">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@domain.com"
                className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          {/* Avatar Selector */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-300 mb-1">
              Choose Avatar
            </label>
            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
              {AVATAR_OPTIONS.map((em) => (
                <button
                  key={em}
                  type="button"
                  onClick={() => setAvatar(em)}
                  className={`w-8 h-8 rounded-xl flex items-center justify-center text-sm border transition cursor-pointer shrink-0 ${
                    avatar === em
                      ? 'bg-cyan-500/20 border-cyan-400 scale-110 shadow-sm shadow-cyan-500/40'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {em}
                </button>
              ))}
            </div>
          </div>

          {/* Preferred Language */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-300 mb-1 flex items-center gap-1">
              <Globe className="w-3.5 h-3.5 text-cyan-400" />
              AI Reply Language
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(
                [
                  { id: 'hinglish', label: 'Hinglish Desi' },
                  { id: 'hindi', label: 'Hindi' },
                  { id: 'english', label: 'English' },
                ] as const
              ).map((l) => (
                <button
                  key={l.id}
                  type="button"
                  onClick={() => setLang(l.id)}
                  className={`py-1.5 px-2 rounded-xl text-xs border transition cursor-pointer text-center ${
                    lang === l.id
                      ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-300 font-bold'
                      : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  {l.label}
                </button>
              ))}
            </div>
          </div>

          {/* Form Actions */}
          <div className="pt-2 flex items-center gap-2">
            <button
              type="submit"
              className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs shadow-md shadow-cyan-500/20 transition cursor-pointer hover:scale-[1.01] active:scale-95"
            >
              Save &amp; Log In
            </button>

            {userProfile.isLoggedIn && (
              <button
                type="button"
                onClick={handleLogout}
                className="py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-red-500/10 text-slate-400 hover:text-red-400 border border-slate-800 transition cursor-pointer text-xs flex items-center gap-1.5"
                title="Switch to Guest Mode"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log Out</span>
              </button>
            )}
          </div>
        </form>

      </div>
    </div>
  );
};
