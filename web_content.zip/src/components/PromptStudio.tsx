import React, { useState, useRef } from "react";
import {
  Sparkles,
  Wand2,
  SlidersHorizontal,
  Layers,
  Square,
  RectangleHorizontal,
  RectangleVertical,
  Dice5,
  X,
  Loader2,
  ChevronDown,
  ChevronUp,
  Download,
  Eye,
  Heart,
  RotateCcw,
  Maximize2,
  AlertCircle,
  Copy,
  Check,
  Upload,
  Image as ImageIcon,
  FileImage,
  ArrowRight,
  RefreshCw,
  Cpu,
  Globe,
  Server,
  HardDrive,
  FolderUp,
  Radio,
  CheckCircle2,
  XCircle,
} from "lucide-react";
import { AspectRatio, GeneratedImage, StylePreset } from "../types";
import { STYLE_PRESETS, SAMPLE_PROMPTS } from "../data/presets";
import { SmartImage } from "./SmartImage";
import { generateLocalCanvasImage } from "../utils/localImageGenerator";
import { downloadImage } from "../utils/downloadImage";

interface PromptStudioProps {
  onGenerateSuccess: (images: GeneratedImage[]) => void;
  onOpenImageModal: (image: GeneratedImage) => void;
  onSendToEditor: (image: GeneratedImage) => void;
  favorites: string[];
  onToggleFavorite: (id: string) => void;
  hasApiKey: boolean | null;
  userApiKey: string;
  onOpenKeyModal: () => void;
}

const SAMPLE_REFERENCE_IMAGES = [
  {
    name: "Cybernetic Fox",
    url: "https://picsum.photos/seed/cyberfox/800/800",
  },
  {
    name: "Floating Castle",
    url: "https://picsum.photos/seed/cloudcastle/800/800",
  },
  {
    name: "Astronaut Coffee",
    url: "https://picsum.photos/seed/astronautcoffee/800/800",
  },
];

const ASPECT_RATIOS: Array<{
  value: AspectRatio;
  label: string;
  sub: string;
  icon: React.ReactNode;
}> = [
  {
    value: "1:1",
    label: "1:1",
    sub: "Square",
    icon: <Square className="w-4 h-4" />,
  },
  {
    value: "16:9",
    label: "16:9",
    sub: "Landscape",
    icon: <RectangleHorizontal className="w-5 h-3.5" />,
  },
  {
    value: "9:16",
    label: "9:16",
    sub: "Mobile Story",
    icon: <RectangleVertical className="w-3.5 h-5" />,
  },
  {
    value: "4:3",
    label: "4:3",
    sub: "Classic",
    icon: <RectangleHorizontal className="w-4 h-3" />,
  },
  {
    value: "3:4",
    label: "3:4",
    sub: "Portrait",
    icon: <RectangleVertical className="w-3 h-4" />,
  },
];

export const PromptStudio: React.FC<PromptStudioProps> = ({
  onGenerateSuccess,
  onOpenImageModal,
  onSendToEditor,
  favorites,
  onToggleFavorite,
  hasApiKey,
  userApiKey,
  onOpenKeyModal,
}) => {
  const [generationMode, setGenerationMode] = useState<"text2img" | "img2img">("text2img");
  const [referenceImage, setReferenceImage] = useState<string | null>(null);
  const [referenceImageName, setReferenceImageName] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [prompt, setPrompt] = useState("");
  const [selectedModel, setSelectedModel] = useState<
    "gemini-3.1-flash-lite-image" | "local-stable-diffusion" | "local-offline-canvas"
  >("gemini-3.1-flash-lite-image");
  const [localSdEndpoint, setLocalSdEndpoint] = useState("http://127.0.0.1:7860");
  const [localModelName, setLocalModelName] = useState("v1-5-pruned-emaonly.safetensors");
  const [localModelFile, setLocalModelFile] = useState<File | null>(null);
  const [localSampler, setLocalSampler] = useState("DPM++ 2M Karras");
  const [localSteps, setLocalSteps] = useState(20);
  const [localCfgScale, setLocalCfgScale] = useState(7.5);
  const [testingLocalSd, setTestingLocalSd] = useState(false);
  const [localSdStatus, setLocalSdStatus] = useState<string | null>(null);

  const modelFileInputRef = useRef<HTMLInputElement>(null);
  const [selectedStyle, setSelectedStyle] = useState<StylePreset>(STYLE_PRESETS[0]);
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>("1:1");
  const [negativePrompt, setNegativePrompt] = useState("");
  const [variations, setVariations] = useState<number>(1);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatingMessage, setGeneratingMessage] = useState("");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [recentGenerated, setRecentGenerated] = useState<GeneratedImage[]>([]);
  const [copiedPromptId, setCopiedPromptId] = useState<string | null>(null);

  const handleTestLocalSd = async () => {
    setTestingLocalSd(true);
    setLocalSdStatus(null);
    try {
      const res = await fetch("/api/test-local-sd", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ endpoint: localSdEndpoint }),
      });
      const data = await res.json();
      if (data.online) {
        setLocalSdStatus(`Connected! ${data.info || "Local SD WebUI Active"}`);
      } else {
        setLocalSdStatus("Server unreachable. Launch WebUI with '--api --cors-allow-origins=*'");
      }
    } catch (err: any) {
      setLocalSdStatus("Connection test failed. Check endpoint host and port.");
    } finally {
      setTestingLocalSd(false);
    }
  };

  const handleLocalModelUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setLocalModelFile(file);
      setLocalModelName(file.name);
    }
  };

  const getHeaders = () => {
    const headers: Record<string, string> = { "Content-Type": "application/json" };
    const activeKey = userApiKey || localStorage.getItem("custom_gemini_api_key") || "";
    if (activeKey.trim()) {
      headers["x-gemini-api-key"] = activeKey.trim();
    }
    return headers;
  };

  const handleReferenceUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setErrorMsg("Please select a valid image file (PNG, JPG, WebP).");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setReferenceImage(event.target.result as string);
        setReferenceImageName(file.name);
        setGenerationMode("img2img");
        setErrorMsg(null);
      }
    };
    reader.readAsDataURL(file);
  };

  const loadSampleReference = (sample: { name: string; url: string }) => {
    setReferenceImage(sample.url);
    setReferenceImageName(sample.name);
    setGenerationMode("img2img");
    setErrorMsg(null);
  };

  // Magic Prompt Enhancement
  const handleEnhancePrompt = async () => {
    if (!prompt.trim() || isEnhancing) return;
    setIsEnhancing(true);
    setErrorMsg(null);
    try {
      const res = await fetch("/api/enhance-prompt", {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify({ prompt }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to enhance prompt");
      if (data.enhancedPrompt) {
        setPrompt(data.enhancedPrompt);
      }
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to enhance prompt.");
    } finally {
      setIsEnhancing(false);
    }
  };

  // Random Prompt Generator
  const handleRandomPrompt = () => {
    const randomIndex = Math.floor(Math.random() * SAMPLE_PROMPTS.length);
    const sample = SAMPLE_PROMPTS[randomIndex];
    setPrompt(sample.prompt);
    setAspectRatio(sample.aspectRatio);
    const styleObj = STYLE_PRESETS.find((s) => s.id === sample.styleId);
    if (styleObj) setSelectedStyle(styleObj);
  };

  // Generate Image API Call (Gemini AI Cloud, Local SD WebUI, or Local Offline Canvas)
  const handleGenerate = async () => {
    if (!prompt.trim() || isGenerating) return;

    setIsGenerating(true);
    setErrorMsg(null);
    const count = Math.min(Math.max(1, variations), 4);

    // 1. OFFLINE LOCAL CANVAS MODEL PATH
    if (selectedModel === "local-offline-canvas") {
      setGeneratingMessage(`Synthesizing ${count} high-res local canvas image(s)...`);
      try {
        const generatedList: GeneratedImage[] = [];
        for (let i = 0; i < count; i++) {
          const url = await generateLocalCanvasImage({
            prompt: prompt.trim(),
            style: selectedStyle.name,
            aspectRatio,
            referenceImage: generationMode === "img2img" ? referenceImage : null,
            seed: Date.now() + i * 137,
          });

          generatedList.push({
            id: `img_local_${Date.now()}_${i}_${Math.random().toString(36).substring(2, 6)}`,
            url,
            prompt: prompt.trim(),
            compiledPrompt: `${prompt.trim()}, ${selectedStyle.name} style`,
            aspectRatio,
            style: selectedStyle.name,
            timestamp: Date.now(),
            negativePrompt,
            model: "Local Offline Canvas Model",
            isImg2Img: Boolean(generationMode === "img2img" && referenceImage),
          });
        }

        setRecentGenerated(generatedList);
        onGenerateSuccess(generatedList);
      } catch (err: any) {
        console.error("Local generation error:", err);
        setErrorMsg("Failed to synthesize local canvas images.");
      } finally {
        setIsGenerating(false);
      }
      return;
    }

    // 2. LOCAL STABLE DIFFUSION OR CLOUD AI MODEL PATH
    const modelDisplayName =
      selectedModel === "local-stable-diffusion"
        ? `Local Stable Diffusion (${localModelName})`
        : "Gemini Image Engine";

    setGeneratingMessage(
      `Synthesizing ${count} variation(s) using ${modelDisplayName}...`
    );

    const progressMessages = [
      `Initializing ${selectedModel === "local-stable-diffusion" ? "Local SD WebUI" : "Gemini Engine"}...`,
      "Synthesizing visual textures & lighting...",
      "Rendering high-resolution details...",
      "Finalizing batch output...",
    ];

    let step = 0;
    const interval = setInterval(() => {
      if (step < progressMessages.length) {
        setGeneratingMessage(progressMessages[step]);
        step++;
      }
    }, 1800);

    try {
      const response = await fetch("/api/generate-image", {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify({
          prompt: prompt.trim(),
          aspectRatio,
          style: selectedStyle.name,
          negativePrompt: negativePrompt.trim(),
          count: variations,
          model: selectedModel,
          localSdEndpoint,
          localModelName,
          localSampler,
          localSteps,
          localCfgScale,
          referenceImage: generationMode === "img2img" ? referenceImage : null,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Image generation failed.");
      }

      if (data.images && data.images.length > 0) {
        const newImages: GeneratedImage[] = data.images.map((img: any) => ({
          id: img.id || `img_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          url: img.url,
          prompt: img.prompt || prompt,
          compiledPrompt: img.compiledPrompt,
          aspectRatio: img.aspectRatio || aspectRatio,
          style: img.style || selectedStyle.name,
          timestamp: img.timestamp || Date.now(),
          negativePrompt,
          model: img.model || selectedModel,
          isImg2Img: Boolean(generationMode === "img2img" && referenceImage),
        }));

        setRecentGenerated(newImages);
        onGenerateSuccess(newImages);
      } else {
        throw new Error("No image data received from server.");
      }
    } catch (err: any) {
      console.error("Generate error:", err);
      // Fallback: Generate full batch count locally so requested variation count is strictly preserved
      try {
        const fallbackList: GeneratedImage[] = [];
        for (let i = 0; i < count; i++) {
          const url = await generateLocalCanvasImage({
            prompt: prompt.trim(),
            style: selectedStyle.name,
            aspectRatio,
            referenceImage: generationMode === "img2img" ? referenceImage : null,
            seed: Date.now() + i * 211,
          });
          fallbackList.push({
            id: `img_fallback_${Date.now()}_${i}`,
            url,
            prompt: prompt.trim(),
            aspectRatio,
            style: selectedStyle.name,
            timestamp: Date.now(),
            model: "Offline Local Fallback",
            isImg2Img: Boolean(generationMode === "img2img" && referenceImage),
          });
        }
        setRecentGenerated(fallbackList);
        onGenerateSuccess(fallbackList);
      } catch (fbErr) {
        setErrorMsg(err.message || "Failed to generate image batch.");
      }
    } finally {
      clearInterval(interval);
      setIsGenerating(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
      e.preventDefault();
      handleGenerate();
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedPromptId(id);
    setTimeout(() => setCopiedPromptId(null), 2000);
  };

  return (
    <div className="space-y-6">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleReferenceUpload}
        accept="image/*"
        className="hidden"
      />

      {/* Top Banner Info if API Key is not configured on server */}
      {hasApiKey === false && !userApiKey && (
        <div className="p-4 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-300 text-xs flex items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-purple-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-semibold text-purple-200">Free Gemini API Key Setup Available</p>
              <p className="text-purple-300/80">
                You can use prompt-matched generation or add your own free Gemini API key for direct AI synthesis.
              </p>
            </div>
          </div>
          <button
            onClick={onOpenKeyModal}
            className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs shrink-0 transition shadow-md shadow-purple-600/20"
          >
            Setup Free Key
          </button>
        </div>
      )}

      {/* Main Creation Card */}
      <div className="p-5 sm:p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 shadow-2xl backdrop-blur-md space-y-5">
        
        {/* Mode Selector Tabs */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-2 p-1 rounded-xl bg-slate-950 border border-slate-800">
            <button
              type="button"
              onClick={() => setGenerationMode("text2img")}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
                generationMode === "text2img"
                  ? "bg-purple-600 text-white shadow-md shadow-purple-600/30"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Text to Image</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setGenerationMode("img2img");
                if (!referenceImage && fileInputRef.current) {
                  fileInputRef.current.click();
                }
              }}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition ${
                generationMode === "img2img"
                  ? "bg-purple-600 text-white shadow-md shadow-purple-600/30"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>Image to Image (Img2Img)</span>
              <span className="px-1.5 py-0.5 rounded text-[9px] bg-pink-500/20 text-pink-300 font-mono border border-pink-500/30">
                Active
              </span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleRandomPrompt}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition"
              title="Surprise me with a random prompt"
            >
              <Dice5 className="w-3.5 h-3.5 text-indigo-400" />
              <span>Random</span>
            </button>

            <button
              onClick={handleEnhancePrompt}
              disabled={isEnhancing || !prompt.trim()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-purple-600/30 to-pink-600/30 hover:from-purple-600/40 hover:to-pink-600/40 border border-purple-500/40 text-purple-300 text-xs font-semibold transition disabled:opacity-50"
              title="Enhance prompt with Gemini AI"
            >
              {isEnhancing ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin text-purple-300" />
              ) : (
                <Wand2 className="w-3.5 h-3.5 text-pink-400 animate-pulse" />
              )}
              <span>{isEnhancing ? "Enhancing..." : "Magic Enhance"}</span>
            </button>
          </div>
        </div>

        {/* Model Engine Selector */}
        <div className="space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3 rounded-xl bg-slate-950/70 border border-slate-800">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-purple-400" />
              <span className="text-xs font-semibold text-slate-300">AI Model Engine:</span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setSelectedModel("gemini-3.1-flash-lite-image")}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition border ${
                  selectedModel === "gemini-3.1-flash-lite-image"
                    ? "bg-purple-600/20 border-purple-500 text-purple-200 shadow-sm"
                    : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200"
                }`}
              >
                <Globe className="w-3.5 h-3.5 text-indigo-400" />
                <span>Gemini AI Cloud</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedModel("local-stable-diffusion")}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition border ${
                  selectedModel === "local-stable-diffusion"
                    ? "bg-cyan-600/20 border-cyan-500 text-cyan-200 shadow-sm"
                    : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200"
                }`}
              >
                <Server className="w-3.5 h-3.5 text-cyan-400" />
                <span>Local Stable Diffusion</span>
                <span className="px-1.5 py-0.2 rounded text-[9px] bg-cyan-500/20 text-cyan-300 font-mono border border-cyan-500/30">
                  WebUI / SD Models
                </span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedModel("local-offline-canvas")}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition border ${
                  selectedModel === "local-offline-canvas"
                    ? "bg-emerald-600/20 border-emerald-500 text-emerald-200 shadow-sm"
                    : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200"
                }`}
              >
                <Cpu className="w-3.5 h-3.5 text-emerald-400" />
                <span>Offline Canvas Engine</span>
                <span className="px-1.5 py-0.2 rounded text-[9px] bg-emerald-500/20 text-emerald-300 font-mono border border-emerald-500/30">
                  100% Offline
                </span>
              </button>
            </div>
          </div>

          {/* Local Stable Diffusion Model Upload & Endpoint Setup Panel */}
          {selectedModel === "local-stable-diffusion" && (
            <div className="p-4 rounded-xl bg-slate-950/90 border border-cyan-500/40 space-y-4">
              <input
                type="file"
                ref={modelFileInputRef}
                onChange={handleLocalModelUpload}
                accept=".safetensors,.ckpt,.pt"
                className="hidden"
              />

              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2">
                  <HardDrive className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs font-bold text-cyan-200">
                    Local Stable Diffusion Model & Endpoint Settings
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">
                  AUTOMATIC1111 / ComfyUI / SD.Next / Diffusers
                </span>
              </div>

              {/* Local Model File Upload Section */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label className="text-[11px] font-semibold text-slate-300 flex items-center justify-between">
                    <span>Select or Upload Local Model (.safetensors)</span>
                    <span className="text-[10px] text-cyan-400 font-mono">Safetensors / Checkpoint</span>
                  </label>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => modelFileInputRef.current?.click()}
                      className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-cyan-950/80 hover:bg-cyan-900/80 border border-cyan-500/40 text-cyan-200 text-xs font-semibold transition shrink-0"
                    >
                      <FolderUp className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{localModelFile ? "Uploaded Model" : "Upload Local .safetensors"}</span>
                    </button>
                    <input
                      type="text"
                      value={localModelName}
                      onChange={(e) => setLocalModelName(e.target.value)}
                      placeholder="v1-5-pruned-emaonly.safetensors or sd_xl_base_1.0.safetensors"
                      className="flex-1 px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-200 text-xs placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                    />
                  </div>
                  {localModelFile && (
                    <p className="text-[11px] text-emerald-400 flex items-center gap-1 font-mono">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Loaded local checkpoint file: {localModelFile.name} ({(localModelFile.size / (1024 * 1024)).toFixed(1)} MB)</span>
                    </p>
                  )}
                </div>

                {/* Local WebUI Server Endpoint */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-semibold text-slate-300 flex items-center justify-between">
                    <span>Local WebUI Server API Base URL</span>
                    <span className="text-[10px] text-slate-400 font-mono">Default: http://127.0.0.1:7860</span>
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={localSdEndpoint}
                      onChange={(e) => setLocalSdEndpoint(e.target.value)}
                      placeholder="http://127.0.0.1:7860"
                      className="flex-1 px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-200 text-xs font-mono focus:outline-none focus:ring-1 focus:ring-cyan-500"
                    />
                    <button
                      type="button"
                      onClick={handleTestLocalSd}
                      disabled={testingLocalSd}
                      className="flex items-center gap-1 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition shrink-0 disabled:opacity-50"
                    >
                      {testingLocalSd ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin text-cyan-400" />
                      ) : (
                        <Radio className="w-3.5 h-3.5 text-cyan-400" />
                      )}
                      <span>Test Ping</span>
                    </button>
                  </div>
                  {localSdStatus && (
                    <p
                      className={`text-[11px] font-mono flex items-center gap-1 ${
                        localSdStatus.includes("Connected") ? "text-emerald-400" : "text-amber-400"
                      }`}
                    >
                      {localSdStatus.includes("Connected") ? (
                        <CheckCircle2 className="w-3 h-3 shrink-0" />
                      ) : (
                        <XCircle className="w-3 h-3 shrink-0" />
                      )}
                      <span>{localSdStatus}</span>
                    </p>
                  )}
                </div>
              </div>

              {/* Sampler & Sampling Parameters */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1 border-t border-slate-900">
                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-slate-300">Sampler Method</label>
                  <select
                    value={localSampler}
                    onChange={(e) => setLocalSampler(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-200 text-xs focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  >
                    <option value="DPM++ 2M Karras">DPM++ 2M Karras</option>
                    <option value="Euler a">Euler a</option>
                    <option value="DDIM">DDIM</option>
                    <option value="UniPC">UniPC</option>
                    <option value="LMS">LMS</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <label className="font-semibold text-slate-300">Sampling Steps</label>
                    <span className="text-cyan-300 font-mono">{localSteps}</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="50"
                    value={localSteps}
                    onChange={(e) => setLocalSteps(Number(e.target.value))}
                    className="w-full accent-cyan-500"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <label className="font-semibold text-slate-300">CFG Scale</label>
                    <span className="text-cyan-300 font-mono">{localCfgScale}</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="20"
                    step="0.5"
                    value={localCfgScale}
                    onChange={(e) => setLocalCfgScale(Number(e.target.value))}
                    className="w-full accent-cyan-500"
                  />
                </div>
              </div>

              <div className="p-2.5 rounded-lg bg-cyan-950/40 border border-cyan-800/40 text-[11px] text-cyan-300/90 leading-relaxed">
                💡 <strong>How to connect local Stable Diffusion:</strong> Launch your local AUTOMATIC1111 / WebUI instance with API enabled: <code className="bg-slate-900 px-1.5 py-0.5 rounded text-cyan-200 font-mono text-[10px]">./webui.sh --api --cors-allow-origins=*</code>.
              </div>
            </div>
          )}
        </div>

        {/* Reference Image Container (Image to Image Mode) */}
        {generationMode === "img2img" && (
          <div className="p-4 rounded-xl bg-slate-950/90 border border-purple-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-purple-300 flex items-center gap-1.5">
                <FileImage className="w-4 h-4 text-purple-400" />
                <span>Reference Source Image</span>
              </span>
              {referenceImage && (
                <button
                  onClick={() => {
                    setReferenceImage(null);
                    setReferenceImageName("");
                  }}
                  className="text-[11px] text-rose-400 hover:underline flex items-center gap-1"
                >
                  <X className="w-3 h-3" />
                  <span>Remove Reference</span>
                </button>
              )}
            </div>

            {referenceImage ? (
              <div className="flex items-center gap-4 p-3 rounded-xl bg-slate-900 border border-slate-800">
                <img
                  src={referenceImage}
                  alt="Reference"
                  className="w-16 h-16 object-cover rounded-lg border border-purple-500/40 shrink-0"
                />
                <div className="flex-1 min-w-0 space-y-1">
                  <p className="text-xs font-bold text-slate-200 truncate">
                    {referenceImageName || "Uploaded Reference Image"}
                  </p>
                  <p className="text-[11px] text-emerald-400 flex items-center gap-1">
                    <Check className="w-3 h-3" />
                    <span>Image input ready for AI transformation</span>
                  </p>
                </div>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition flex items-center gap-1"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Replace</span>
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="p-6 border-2 border-dashed border-slate-800 hover:border-purple-500/60 rounded-xl bg-slate-900/50 hover:bg-slate-900 transition text-center cursor-pointer group space-y-2"
                >
                  <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center mx-auto group-hover:scale-110 transition">
                    <Upload className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-200">Click or Drag & Drop Reference Image</p>
                    <p className="text-[11px] text-slate-400">Upload your own photo to modify with text prompt</p>
                  </div>
                </div>

                {/* Sample Reference Pill Quick Selector */}
                <div className="space-y-1.5">
                  <span className="text-[11px] text-slate-400">Or pick a sample reference image:</span>
                  <div className="flex items-center gap-2 overflow-x-auto pb-1">
                    {SAMPLE_REFERENCE_IMAGES.map((sample, idx) => (
                      <button
                        key={idx}
                        onClick={() => loadSampleReference(sample)}
                        className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-purple-500/40 text-slate-300 text-xs font-medium transition shrink-0"
                      >
                        <img src={sample.url} className="w-5 h-5 rounded object-cover" alt="" />
                        <span>{sample.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Textarea Input */}
        <div className="relative group space-y-1.5">
          <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>
              {generationMode === "img2img"
                ? "Describe Image-to-Image Transformation"
                : "Prompt Description"}
            </span>
          </label>
          <div className="relative">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={
                generationMode === "img2img"
                  ? "e.g. Transform this image into a cyberpunk anime style with glowing neon blue highlights and rainy reflections..."
                  : "e.g. A serene cybernetic cat sitting on a neon rooftop under rainy Tokyo night sky, hyperrealistic 8k details..."
              }
              rows={3}
              className="w-full p-4 rounded-xl bg-slate-950/90 border border-slate-800 text-slate-100 placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition resize-none"
            />
            {prompt && (
              <button
                onClick={() => setPrompt("")}
                className="absolute top-3 right-3 p-1 rounded-lg bg-slate-800/80 text-slate-400 hover:text-white transition"
                title="Clear text"
              >
                <X className="w-4 h-4" />
              </button>
            )}
            <div className="absolute bottom-3 right-3 text-[10px] text-slate-500 font-mono pointer-events-none">
              Ctrl + Enter to generate
            </div>
          </div>
        </div>

        {/* Style Preset Selector */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-indigo-400" />
              <span>Artistic Style</span>
            </span>
            <span className="text-[11px] text-slate-400 font-mono">
              Selected: <strong className="text-purple-300">{selectedStyle.name}</strong>
            </span>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-slate-800">
            {STYLE_PRESETS.map((style) => {
              const isSelected = selectedStyle.id === style.id;
              return (
                <button
                  key={style.id}
                  onClick={() => setSelectedStyle(style)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all border ${
                    isSelected
                      ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white border-purple-400 shadow-md shadow-purple-500/20"
                      : "bg-slate-950/60 border-slate-800/80 text-slate-400 hover:text-slate-200 hover:border-slate-700"
                  }`}
                >
                  <div className={`w-2 h-2 rounded-full ${isSelected ? "bg-white" : "bg-slate-600"}`} />
                  <span>{style.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Aspect Ratio Picker */}
        <div className="space-y-2">
          <span className="text-xs font-semibold text-slate-300">Aspect Ratio</span>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {ASPECT_RATIOS.map((ratio) => {
              const isSelected = aspectRatio === ratio.value;
              return (
                <button
                  key={ratio.value}
                  onClick={() => setAspectRatio(ratio.value)}
                  className={`flex flex-col items-center justify-center p-2.5 rounded-xl border text-xs transition ${
                    isSelected
                      ? "bg-indigo-600/20 border-indigo-500 text-indigo-200 shadow-inner"
                      : "bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-800/50 hover:text-slate-200"
                  }`}
                >
                  <div className="mb-1">{ratio.icon}</div>
                  <span className="font-bold">{ratio.label}</span>
                  <span className="text-[10px] text-slate-500">{ratio.sub}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Expandable Advanced Options */}
        <div className="border-t border-slate-800/80 pt-3">
          <button
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="flex items-center justify-between w-full py-1 text-xs font-medium text-slate-400 hover:text-slate-200 transition"
          >
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="w-3.5 h-3.5 text-purple-400" />
              <span>Advanced Parameters (Negative prompt, Variations)</span>
            </div>
            {showAdvanced ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>

          {showAdvanced && (
            <div className="mt-3 p-4 rounded-xl bg-slate-950/80 border border-slate-800/80 space-y-4 text-xs">
              {/* Negative Prompt */}
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Negative Prompt (What to exclude)</label>
                <input
                  type="text"
                  value={negativePrompt}
                  onChange={(e) => setNegativePrompt(e.target.value)}
                  placeholder="e.g. blur, low quality, distorted hands, extra limbs, ugly text"
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-purple-500"
                />
              </div>

              {/* Variations Count */}
              <div className="flex items-center justify-between gap-4">
                <div>
                  <span className="text-slate-300 font-medium block">Image Variations</span>
                  <span className="text-[11px] text-slate-500">Number of image variations to generate (1 to 4)</span>
                </div>
                <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-lg p-1">
                  {[1, 2, 3, 4].map((num) => (
                    <button
                      key={num}
                      onClick={() => setVariations(num)}
                      className={`w-7 h-7 rounded-md font-bold text-xs transition ${
                        variations === num
                          ? "bg-purple-600 text-white"
                          : "text-slate-400 hover:text-slate-200 hover:bg-slate-800"
                      }`}
                    >
                      {num}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Generate Button */}
        <button
          onClick={handleGenerate}
          disabled={isGenerating || !prompt.trim()}
          className="relative w-full py-4 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:via-purple-500 hover:to-pink-500 text-white font-bold text-sm shadow-xl shadow-purple-600/25 transition-all transform active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 overflow-hidden"
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>Generating AI Artwork...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5 animate-bounce" />
              <span>Generate Image</span>
            </>
          )}
        </button>

        {/* Error Message Display */}
        {errorMsg && (
          <div className="p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs flex items-center gap-3">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <div className="flex-1">{errorMsg}</div>
            <button onClick={() => setErrorMsg(null)} className="text-red-400 hover:text-red-200">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Loading Skeleton & Generation Display State */}
      {isGenerating && (
        <div className="p-8 rounded-2xl bg-slate-900/60 border border-slate-800/80 text-center space-y-4">
          <div className="relative w-20 h-20 mx-auto flex items-center justify-center">
            <div className="absolute inset-0 rounded-full border-4 border-purple-500/20 border-t-purple-500 animate-spin" />
            <Sparkles className="w-8 h-8 text-purple-400 animate-pulse" />
          </div>
          <div className="space-y-1">
            <h3 className="text-sm font-semibold text-slate-200">Creating Your Masterpiece</h3>
            <p className="text-xs text-purple-300 font-mono animate-pulse">{generatingMessage}</p>
          </div>
        </div>
      )}

      {/* Recent Output Section */}
      {recentGenerated.length > 0 && !isGenerating && (
        <div className="space-y-4 pt-2">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>Generated Creation{recentGenerated.length > 1 ? "s" : ""}</span>
            </h2>
            <span className="text-xs text-slate-400 font-mono">{recentGenerated.length} Result(s)</span>
          </div>

          <div
            className={`grid gap-4 ${
              recentGenerated.length === 1
                ? "grid-cols-1"
                : recentGenerated.length === 2
                ? "grid-cols-1 sm:grid-cols-2"
                : "grid-cols-1 sm:grid-cols-2 lg:grid-cols-4"
            }`}
          >
            {recentGenerated.map((img) => {
              const isFav = favorites.includes(img.id);
              return (
                <div
                  key={img.id}
                  className="group relative rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl transition-all duration-300 hover:border-purple-500/50"
                >
                  {/* Image Container */}
                  <div className="relative aspect-square sm:aspect-auto w-full max-h-[480px] bg-slate-950 flex items-center justify-center overflow-hidden">
                    <SmartImage
                      src={img.url}
                      alt={img.prompt}
                      prompt={img.prompt}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-contain transition-transform duration-500 group-hover:scale-105"
                    />

                    {/* Quick Overlay Action Bar */}
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 p-4 flex flex-col justify-between">
                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => onToggleFavorite(img.id)}
                          className={`p-2 rounded-full backdrop-blur-md transition ${
                            isFav ? "bg-red-500/80 text-white" : "bg-slate-900/80 text-slate-300 hover:text-white"
                          }`}
                          title={isFav ? "Remove Favorite" : "Favorite Image"}
                        >
                          <Heart className={`w-4 h-4 ${isFav ? "fill-white" : ""}`} />
                        </button>
                      </div>

                      <div className="space-y-3">
                        <p className="text-xs text-slate-200 line-clamp-2 bg-slate-900/80 p-2 rounded-lg backdrop-blur-md border border-slate-800/80">
                          {img.prompt}
                        </p>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => onOpenImageModal(img)}
                            className="flex-1 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-md"
                          >
                            <Maximize2 className="w-3.5 h-3.5" />
                            <span>View Full HD</span>
                          </button>

                          <button
                            onClick={() => onSendToEditor(img)}
                            className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1"
                            title="Edit / Modify with AI"
                          >
                            <Wand2 className="w-3.5 h-3.5 text-pink-400" />
                            <span>Edit</span>
                          </button>

                          <button
                            onClick={() => downloadImage(img.url, `scientific_ai_artwork_${img.id}.png`)}
                            className="px-3 py-2 rounded-lg bg-emerald-600/90 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1 shadow-md transition"
                            title="Save Image to Device"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>Save Image</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Card Bottom Meta */}
                  <div className="p-3 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                    <span className="truncate font-mono">{img.prompt}</span>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-purple-300 font-semibold">
                        {img.style}
                      </span>
                      <button
                        onClick={() => copyToClipboard(img.prompt, img.id)}
                        className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition"
                        title="Copy prompt text"
                      >
                        {copiedPromptId === img.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
