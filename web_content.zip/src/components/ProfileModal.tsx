import React, { useState } from 'react';
import { PlayerProfile, GameStats, Achievement } from '../types';
import { X, Trophy, Coins, Award, LogOut, Check, Edit2 } from 'lucide-react';

interface ProfileModalProps {
  profile: PlayerProfile;
  stats: GameStats;
  achievements: Achievement[];
  onUpdateProfile: (updated: Partial<PlayerProfile>) => void;
  onGoogleSignIn: () => Promise<void>;
  onGoogleSignOut: () => Promise<void>;
  onClose: () => void;
}

const AVATAR_OPTIONS = ['🦊', '🥷', '🤖', '🐱', '🐻', '👽', '🦁', '⚡'];

export const ProfileModal: React.FC<ProfileModalProps> = ({
  profile,
  stats,
  achievements,
  onUpdateProfile,
  onGoogleSignIn,
  onGoogleSignOut,
  onClose,
}) => {
  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(profile.name);
  const [isLoadingAuth, setIsLoadingAuth] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const handleSaveName = () => {
    const trimmed = nameInput.trim() || 'Runner';
    onUpdateProfile({ name: trimmed });
    setIsEditingName(false);
  };

  const handleSignIn = async () => {
    setIsLoadingAuth(true);
    setAuthError(null);
    try {
      await onGoogleSignIn();
    } catch (err: unknown) {
      const e = err as { message?: string };
      setAuthError(e?.message || 'Sign in failed');
    } finally {
      setIsLoadingAuth(false);
    }
  };

  const handleSignOut = async () => {
    setIsLoadingAuth(true);
    try {
      await onGoogleSignOut();
    } finally {
      setIsLoadingAuth(false);
    }
  };

  const unlockedCount = achievements.filter((a) => a.unlocked).length;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/85 backdrop-blur-md px-4 py-4 select-none animate-in fade-in duration-150">
      <div className="flex w-full max-w-sm flex-col max-h-[92vh] rounded-3xl bg-slate-900 border border-slate-800 p-5 shadow-2xl overflow-y-auto no-scrollbar">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h2 className="text-lg font-black text-white">PLAYER PROFILE</h2>
          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Profile Card */}
        <div className="my-4 flex flex-col items-center rounded-2xl bg-slate-950/80 p-4 border border-slate-800 text-center">
          {/* Avatar Icon */}
          <div className="relative mb-2 flex h-16 w-16 items-center justify-center rounded-2xl bg-slate-800/90 text-3xl shadow-inner border border-slate-700">
            {profile.avatar}
          </div>

          {/* Avatar Picker */}
          <div className="flex flex-wrap justify-center gap-1.5 mb-3">
            {AVATAR_OPTIONS.map((emoji) => (
              <button
                key={emoji}
                onClick={() => onUpdateProfile({ avatar: emoji })}
                className={`flex h-8 w-8 items-center justify-center rounded-lg text-lg transition-transform active:scale-95 ${
                  profile.avatar === emoji
                    ? 'bg-indigo-600/40 ring-2 ring-indigo-400'
                    : 'bg-slate-900/80 hover:bg-slate-800'
                }`}
              >
                {emoji}
              </button>
            ))}
          </div>

          {/* Name & Edit */}
          {isEditingName ? (
            <div className="flex items-center gap-1.5 w-full max-w-[200px]">
              <input
                type="text"
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                maxLength={14}
                className="w-full rounded-xl bg-slate-900 px-3 py-1 text-center font-bold text-sm text-white border border-indigo-500 focus:outline-none"
                autoFocus
              />
              <button
                onClick={handleSaveName}
                className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-500 text-white"
              >
                <Check className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-1.5">
              <span className="text-base font-black text-white">{profile.name}</span>
              <button
                onClick={() => setIsEditingName(true)}
                className="text-slate-400 hover:text-white"
              >
                <Edit2 className="h-3.5 w-3.5" />
              </button>
            </div>
          )}

          {/* Account status badge */}
          <div className="mt-1 flex items-center gap-1 text-[11px] text-slate-400">
            {profile.isGoogleUser ? (
              <span className="text-emerald-400 font-medium">
                ✓ Google Account Connected
              </span>
            ) : (
              <span className="text-slate-500">Playing as Guest</span>
            )}
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-2 mb-4">
          <div className="flex flex-col items-center rounded-xl bg-slate-950/60 p-2.5 border border-slate-800">
            <div className="flex items-center gap-1 text-amber-400 text-[10px] font-bold">
              <Trophy className="h-3 w-3 fill-amber-400" />
              <span>BEST SCORE</span>
            </div>
            <span className="font-mono text-lg font-black text-amber-300 tabular-nums">
              {stats.highScore}
            </span>
          </div>

          <div className="flex flex-col items-center rounded-xl bg-slate-950/60 p-2.5 border border-slate-800">
            <div className="flex items-center gap-1 text-amber-400 text-[10px] font-bold">
              <Coins className="h-3 w-3 fill-amber-400/20" />
              <span>TOTAL COINS</span>
            </div>
            <span className="font-mono text-lg font-black text-amber-300 tabular-nums">
              {stats.coins}
            </span>
          </div>

          <div className="flex flex-col items-center rounded-xl bg-slate-950/60 p-2.5 border border-slate-800">
            <span className="text-[10px] font-bold text-slate-400">TOTAL GAMES</span>
            <span className="font-mono text-lg font-black text-white tabular-nums">
              {stats.gamesPlayed}
            </span>
          </div>

          <div className="flex flex-col items-center rounded-xl bg-slate-950/60 p-2.5 border border-slate-800">
            <div className="flex items-center gap-1 text-rose-400 text-[10px] font-bold">
              <Award className="h-3 w-3" />
              <span>AWARDS</span>
            </div>
            <span className="font-mono text-lg font-black text-white tabular-nums">
              {unlockedCount} / {achievements.length}
            </span>
          </div>
        </div>

        {/* Google Authentication Section */}
        <div className="flex flex-col gap-2 pt-2 border-t border-slate-800">
          {profile.isGoogleUser ? (
            <button
              onClick={handleSignOut}
              disabled={isLoadingAuth}
              className="flex h-11 w-full cursor-pointer items-center justify-center gap-2 rounded-xl bg-slate-800/80 font-bold text-xs text-rose-400 hover:bg-slate-700 active:scale-95 transition-all"
            >
              <LogOut className="h-4 w-4" />
              <span>Sign Out of Google</span>
            </button>
          ) : (
            <button
              onClick={handleSignIn}
              disabled={isLoadingAuth}
              className="flex h-12 w-full cursor-pointer items-center justify-center gap-3 rounded-2xl bg-white text-slate-900 font-black text-xs shadow-md active:scale-95 hover:bg-slate-100 transition-all"
            >
              {/* Official Google 'G' Logo SVG */}
              <svg className="h-4 w-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.65v3.03h3.88c2.27-2.09 3.665-5.17 3.665-9.12z"
                />
                <path
                  fill="#34A853"
                  d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.03c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.24v3.13C3.26 21.41 7.36 24 12 24z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.28 14.29c-.25-.72-.38-1.49-.38-2.29s.13-1.57.38-2.29V6.58H1.24C.45 8.15 0 9.92 0 12s.45 3.85 1.24 5.42l4.04-3.13z"
                />
                <path
                  fill="#EA4335"
                  d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.36 0 3.26 2.59 1.24 6.58l4.04 3.13c.95-2.83 3.6-4.96 6.72-4.96z"
                />
              </svg>
              <span>{isLoadingAuth ? 'Connecting...' : 'Continue with Google'}</span>
            </button>
          )}

          {authError && (
            <span className="text-[10px] text-rose-400 text-center">{authError}</span>
          )}

          <p className="text-[10px] text-slate-500 text-center leading-tight">
            Guest players can play without logging in. Sign in anytime to submit high scores to the Global Leaderboard.
          </p>
        </div>
      </div>
    </div>
  );
};
