import React, { useState } from 'react';
import { User as UserType } from '../types';
import { X, Check, Lock, LogOut, MessageSquare, Calendar, Award } from 'lucide-react';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserType;
  onUpdateUser: (updated: UserType) => void;
  onLogout: () => void;
}

const AVATAR_OPTIONS = ['✦', '🧠', '⚡', '🚀', '🐱', '🦊', '🤖', '👑', '🔥', '🎯', '🥑', '👾'];

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  user,
  onUpdateUser,
  onLogout,
}) => {
  const [displayName, setDisplayName] = useState(user.displayName);
  const [avatar, setAvatar] = useState(user.avatar || '👤');
  const [bio, setBio] = useState(user.bio || '');
  const [newPassword, setNewPassword] = useState('');
  const [saving, setSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSuccessMsg(null);
    setErrorMsg(null);

    try {
      const token = localStorage.getItem('sosiska_token');
      const res = await fetch('/api/auth/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          displayName: displayName.trim(),
          avatar,
          bio: bio.trim(),
          newPassword: newPassword.trim() || undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Ошибка при обновлении профиля');
      }

      onUpdateUser({ ...user, ...data.user });
      setSuccessMsg('Профиль успешно обновлен!');
      setNewPassword('');
      setTimeout(() => setSuccessMsg(null), 3000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Ошибка обновления профиля');
    } finally {
      setSaving(false);
    }
  };

  const formattedDate = new Date(user.createdAt).toLocaleDateString('ru-RU', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md">
      <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl p-6 sm:p-7 max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-neutral-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-4 pb-5 border-b border-neutral-800">
          <div className="w-16 h-16 rounded-2xl bg-orange-500/10 border-2 border-orange-500/30 flex items-center justify-center text-3xl shadow-inner">
            {avatar}
          </div>
          <div>
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              {displayName}
            </h3>
            <p className="text-xs text-neutral-400 font-mono">@{user.username}</p>
            <p className="text-xs text-orange-400/90 mt-0.5">{user.email}</p>
          </div>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-3 gap-2.5 my-5">
          <div className="p-3 bg-neutral-950/70 border border-neutral-800 rounded-xl text-center">
            <MessageSquare className="w-4 h-4 mx-auto text-orange-400 mb-1" />
            <div className="text-lg font-bold text-white">
              {user.stats?.totalChats ?? 0}
            </div>
            <div className="text-[10px] text-neutral-400 uppercase tracking-wider">Диалогов</div>
          </div>
          <div className="p-3 bg-neutral-950/70 border border-neutral-800 rounded-xl text-center">
            <Award className="w-4 h-4 mx-auto text-amber-400 mb-1" />
            <div className="text-lg font-bold text-white">
              {user.stats?.totalMessages ?? 0}
            </div>
            <div className="text-[10px] text-neutral-400 uppercase tracking-wider">Сообщений</div>
          </div>
          <div className="p-3 bg-neutral-950/70 border border-neutral-800 rounded-xl text-center">
            <Calendar className="w-4 h-4 mx-auto text-emerald-400 mb-1" />
            <div className="text-xs font-semibold text-white mt-1">{formattedDate}</div>
            <div className="text-[10px] text-neutral-400 uppercase tracking-wider mt-0.5">Регистрация</div>
          </div>
        </div>

        {/* Feedback alerts */}
        {successMsg && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/60 text-emerald-300 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>{successMsg}</span>
          </div>
        )}
        {errorMsg && (
          <div className="mb-4 p-3 rounded-xl bg-rose-950/40 border border-rose-800/60 text-rose-300 text-xs">
            {errorMsg}
          </div>
        )}

        {/* Edit Form */}
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1.5">
              Сменить аватар:
            </label>
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              {AVATAR_OPTIONS.map((av) => (
                <button
                  key={av}
                  type="button"
                  onClick={() => setAvatar(av)}
                  className={`w-9 h-9 shrink-0 flex items-center justify-center text-lg rounded-xl transition-all cursor-pointer ${
                    avatar === av
                      ? 'bg-orange-500/20 border-2 border-orange-500 scale-110 shadow-md'
                      : 'bg-neutral-800/80 hover:bg-neutral-700/80 border border-neutral-700/50'
                  }`}
                >
                  {av}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1">
              Отображаемое имя
            </label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="w-full px-3 py-2 bg-neutral-950/80 border border-neutral-800 rounded-xl text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1">
              О себе / Статус
            </label>
            <textarea
              rows={2}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Пара слов о ваших интересах или сфере деятельности"
              className="w-full px-3 py-2 bg-neutral-950/80 border border-neutral-800 rounded-xl text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500 resize-none"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1">
              Сменить пароль (оставьте пустым, если не меняете)
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-neutral-500">
                <Lock className="w-4 h-4" />
              </div>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Новый пароль (мин. 4 символа)"
                className="w-full pl-9 pr-3 py-2 bg-neutral-950/80 border border-neutral-800 rounded-xl text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={onLogout}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium text-rose-400 hover:text-rose-300 hover:bg-rose-950/30 border border-rose-900/40 transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Выйти из аккаунта</span>
            </button>

            <button
              type="submit"
              disabled={saving}
              className="py-2 px-5 bg-orange-500 hover:bg-orange-600 text-white font-medium text-xs rounded-xl shadow-lg shadow-orange-500/20 focus:outline-none focus:ring-2 focus:ring-orange-500 disabled:opacity-50 transition-all cursor-pointer"
            >
              {saving ? 'Сохранение...' : 'Сохранить изменения'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
