import React, { useState } from 'react';
import { X, Check } from 'lucide-react';
import { Product } from '../db/indexedDB';
import { sound } from '../utils/sound';

interface ProductModalProps {
  product: Product | null;
  groups: string[];
  isOpen: boolean;
  onClose: () => void;
  onSave: (product: Product) => Promise<void>;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  groups,
  isOpen,
  onClose,
  onSave,
}) => {
  const isNew = !product?.id;
  const [code, setCode] = useState(product?.code || '');
  const [barcode, setBarcode] = useState(product?.barcode || '');
  const [name, setName] = useState(product?.name || '');
  const [group, setGroup] = useState(product?.group || groups[0] || 'عام');
  const [price, setPrice] = useState(product?.price || 0);
  const [cost, setCost] = useState(product?.cost || 0);
  const [minQty, setMinQty] = useState(product?.minQty || 10);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('اسم الصنف مطلوب');
      sound.playError();
      return;
    }

    try {
      setLoading(true);
      const updated: Product = {
        id: product?.id || `PROD-${Date.now()}`,
        code: code.trim(),
        barcode: barcode.trim(),
        name: name.trim(),
        group: group.trim() || 'عام',
        price: Math.max(0, Number(price) || 0),
        cost: Math.max(0, Number(cost) || 0),
        minQty: Math.max(0, Number(minQty) || 0),
      };

      await onSave(updated);
      sound.playSuccess();
      onClose();
    } catch {
      setError('حدث خطأ أثناء حفظ الصنف');
      sound.playError();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden text-right flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 bg-slate-800/80 border-b border-slate-700/60 flex items-center justify-between">
          <h3 className="font-bold text-white text-sm">
            {isNew ? '➕ إضافة صنف جديد' : '✏️ تعديل بيانات الصنف'}
          </h3>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-slate-700/60 text-slate-300 hover:text-white flex items-center justify-center active:scale-95 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 space-y-3 overflow-y-auto no-scrollbar">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">كود الصنف</label>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="PROD-..."
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">الباركود</label>
              <input
                type="text"
                value={barcode}
                onChange={(e) => setBarcode(e.target.value)}
                placeholder="6220..."
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">اسم الصنف *</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="مثال: زيت طعام 1 لتر"
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">مجموعة الأصناف</label>
            <select
              value={group}
              onChange={(e) => setGroup(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
            >
              {groups.map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">سعر البيع (ج.م) *</label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={price}
                onChange={(e) => setPrice(Number(e.target.value) || 0)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-amber-500"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">سعر التكلفة (ج.م)</label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={cost}
                onChange={(e) => setCost(Number(e.target.value) || 0)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">حد التنبيه الأدنى في السيارة</label>
            <input
              type="number"
              min="0"
              value={minQty}
              onChange={(e) => setMinQty(Number(e.target.value) || 0)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-amber-500"
            />
          </div>

          {error && (
            <p className="text-xs text-rose-400 bg-rose-500/10 p-2 rounded-lg border border-rose-500/20">
              {error}
            </p>
          )}

          <div className="flex gap-2 pt-2">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 active:scale-95 transition"
            >
              <Check className="w-4 h-4" />
              <span>{loading ? 'جاري الحفظ…' : 'حفظ بيانات الصنف'}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs active:scale-95 transition"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
