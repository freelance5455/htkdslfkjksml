import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, ShoppingCart, MessageCircle, ShieldCheck, Check, Truck, ArrowLeft } from 'lucide-react';

export const ProductModal: React.FC = () => {
  const { 
    selectedProductForModal, 
    setSelectedProductForModal, 
    language, 
    t, 
    addToCart, 
    setIsCartOpen,
    shopSettings 
  } = useApp();

  const [quantity, setQuantity] = useState(1);

  if (!selectedProductForModal) return null;

  const product = selectedProductForModal;
  const discount = Math.round(
    ((product.originalPrice - product.price) / product.originalPrice) * 100
  );

  const handleAddToCart = () => {
    addToCart(product, quantity);
    setSelectedProductForModal(null);
  };

  const handleBuyNow = () => {
    addToCart(product, quantity);
    setSelectedProductForModal(null);
    setIsCartOpen(true);
  };

  const handleDirectWhatsApp = () => {
    const text = encodeURIComponent(
      `नमस्ते A K Golu Computer! मुझे इस प्रोडक्ट के बारे में जानना व ऑर्डर करना है:\n*${product.name.en}*\nकीमत: ₹${product.price.toLocaleString('en-IN')}\nक्वांटिटी: ${quantity}\nकृपया उपलब्धता और डिलीवरी बताएं।`
    );
    window.open(`https://wa.me/91${shopSettings.phone1}?text=${text}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-3xl rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-5 sm:p-7 my-6">
        {/* Close Button */}
        <button
          onClick={() => setSelectedProductForModal(null)}
          className="absolute top-4 right-4 rounded-full p-2 text-slate-400 hover:text-white hover:bg-slate-800 transition"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Left Column: Image */}
          <div className="md:col-span-5 flex flex-col justify-between">
            <div className="aspect-[4/3] rounded-xl overflow-hidden bg-slate-950 border border-slate-800 relative">
              <img
                src={product.image}
                alt={product.name[language] || product.name.en}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-3 left-3">
                <span className="px-2.5 py-1 rounded-md text-xs font-bold bg-blue-600 text-white shadow-md">
                  {product.condition === 'refurbished' ? t.productCard.refurbishedBadge : t.productCard.newBadge}
                </span>
              </div>
            </div>

            {/* Quick Guarantees */}
            <div className="mt-4 p-3.5 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2 text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>{product.warranty[language] || product.warranty.en}</span>
              </div>
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-blue-400 flex-shrink-0" />
                <span>
                  {language === 'hi' ? 'दुकान से पिकअप या होम डिलीवरी' : 'Store Pickup or Local Delivery'}
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Specs & Actions */}
          <div className="md:col-span-7 flex flex-col justify-between space-y-4">
            <div>
              <div className="text-xs font-semibold text-blue-400 tracking-wider uppercase mb-1">
                {product.brand}
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-white leading-snug">
                {product.name[language] || product.name.en}
              </h2>

              {/* Price Banner */}
              <div className="mt-3 flex items-baseline gap-3 flex-wrap">
                <span className="text-2xl sm:text-3xl font-extrabold text-white">
                  ₹{product.price.toLocaleString('en-IN')}
                </span>
                {product.originalPrice > product.price && (
                  <>
                    <span className="text-sm text-slate-400 line-through">
                      MRP ₹{product.originalPrice.toLocaleString('en-IN')}
                    </span>
                    <span className="text-xs font-bold bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-md">
                      {discount}% OFF
                    </span>
                  </>
                )}
              </div>

              {/* Specifications */}
              <div className="mt-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  {language === 'hi' ? 'मुख्य विशेषताएं (Specifications):' : 'Key Specifications:'}
                </h4>
                <ul className="space-y-1.5 text-xs sm:text-sm text-slate-300">
                  {(product.specs[language] || product.specs.en).map((spec, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <span className="text-blue-400 mt-1 font-bold">✓</span>
                      <span>{spec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Quantity and Actions */}
            <div className="pt-4 border-t border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-300 font-medium">
                  {language === 'hi' ? 'मात्रा (Quantity):' : 'Quantity:'}
                </span>
                <div className="flex items-center border border-slate-700 rounded-lg bg-slate-800">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-1 text-slate-300 hover:text-white text-sm font-bold"
                  >
                    -
                  </button>
                  <span className="px-3 py-1 text-sm font-bold text-white min-w-[2rem] text-center">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-1 text-slate-300 hover:text-white text-sm font-bold"
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  onClick={handleAddToCart}
                  className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs sm:text-sm font-semibold border border-slate-700 transition flex items-center justify-center gap-2"
                >
                  <ShoppingCart className="w-4 h-4 text-blue-400" />
                  <span>{t.productCard.addToCart}</span>
                </button>

                <button
                  onClick={handleBuyNow}
                  className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-blue-600/30 transition flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>{language === 'hi' ? 'व्हाट्सएप से खरीदें' : 'Buy on WhatsApp'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
