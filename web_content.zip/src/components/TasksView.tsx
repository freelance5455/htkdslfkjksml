import React, { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Check, Plus, RotateCcw, Trash2 } from 'lucide-react';
import { Client, TaskItem, TaskStage } from '../types';
import { formatDateShort } from '../utils/formatters';

interface TasksViewProps {
  tasks: TaskItem[];
  clients: Client[];
  onMoveTask: (taskId: string, stage: TaskStage) => void;
  onDeleteTask: (taskId: string) => void;
  onAddTaskClick: () => void;
}

export const TasksView: React.FC<TasksViewProps> = ({
  tasks,
  clients,
  onMoveTask,
  onDeleteTask,
  onAddTaskClick,
}) => {
  const [activeStage, setActiveStage] = useState<TaskStage>('todo');

  const clientMap = useMemo(() => {
    const m = new Map<string, Client>();
    clients.forEach((c) => m.set(c.id, c));
    return m;
  }, [clients]);

  const counts = useMemo(
    () => ({
      todo: tasks.filter((t) => t.stage === 'todo').length,
      doing: tasks.filter((t) => t.stage === 'doing').length,
      done: tasks.filter((t) => t.stage === 'done').length,
    }),
    [tasks]
  );

  const visibleTasks = useMemo(
    () => tasks.filter((t) => t.stage === activeStage),
    [tasks, activeStage]
  );

  const priorityMeta = (p: TaskItem['priority']) => {
    if (p === 'high') {
      return { label: 'High Priority', style: 'text-red-700 bg-red-50 border-red-200' };
    }
    if (p === 'medium') {
      return { label: 'Medium', style: 'text-amber-700 bg-amber-50 border-amber-200' };
    }
    return { label: 'Low', style: 'text-emerald-700 bg-emerald-50 border-emerald-200' };
  };

  const renderTaskRow = (task: TaskItem) => {
    const client = clientMap.get(task.clientId);
    const meta = priorityMeta(task.priority);

    return (
      <motion.div
        key={task.id}
        layout
        drag="x"
        dragConstraints={{ left: 0, right: 0 }}
        dragElastic={0.25}
        transition={{ duration: 0.18, ease: 'easeOut' }}
        onDragEnd={(_, info) => {
          if (info.offset.x > 85 && task.stage !== 'done') {
            onMoveTask(task.id, 'done');
          } else if (info.offset.x < -85 && task.stage === 'done') {
            onMoveTask(task.id, 'doing');
          }
        }}
        className="p-4 sm:p-5 space-y-3 cursor-grab active:cursor-grabbing select-none bg-white"
      >
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0 space-y-1">
            <span
              className={`inline-block px-2 py-0.5 rounded-[6px] border text-[11px] font-semibold ${meta.style}`}
            >
              {meta.label}
            </span>
            <h3
              className={`font-display text-sm sm:text-base font-bold ${
                task.stage === 'done' ? 'line-through text-slate-400' : 'text-[#0F172A]'
              }`}
            >
              {task.title}
            </h3>
            <p className="text-xs text-slate-500">
              {client?.name ?? 'CoderStudios'} · Due {formatDateShort(task.deadline)}
            </p>
          </div>

          <button
            type="button"
            onClick={() => onDeleteTask(task.id)}
            aria-label="Delete task"
            className="w-8 h-8 rounded-[8px] hover:bg-slate-100 text-slate-400 hover:text-red-600 flex items-center justify-center transition-colors duration-150 shrink-0 cursor-pointer"
          >
            <Trash2 className="w-4 h-4" strokeWidth={1.75} />
          </button>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
          <span className="text-[11px] text-slate-400">
            {task.stage !== 'done' ? 'Swipe right to complete' : 'Swipe left to reopen'}
          </span>

          <div className="flex items-center gap-2">
            {task.stage === 'todo' && (
              <button
                type="button"
                onClick={() => onMoveTask(task.id, 'doing')}
                className="btn-secondary h-8 px-2.5 text-xs font-semibold inline-flex items-center gap-1 cursor-pointer"
              >
                <span>Doing</span>
                <ArrowRight className="w-4 h-4" strokeWidth={1.75} />
              </button>
            )}
            {task.stage !== 'done' ? (
              <button
                type="button"
                onClick={() => onMoveTask(task.id, 'done')}
                className="btn-primary h-8 px-2.5 text-xs font-semibold inline-flex items-center gap-1 cursor-pointer"
              >
                <Check className="w-4 h-4" strokeWidth={1.75} />
                <span>Mark Done</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => onMoveTask(task.id, 'todo')}
                className="btn-secondary h-8 px-2.5 text-xs font-semibold inline-flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" strokeWidth={1.75} />
                <span>Reopen</span>
              </button>
            )}
          </div>
        </div>
      </motion.div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-0.5">
          <h1 className="font-display text-2xl font-bold text-[#0F172A]">Task Manager</h1>
          <p className="text-xs sm:text-sm text-slate-500">
            Kanban workflow · Drag right on any task to mark done
          </p>
        </div>

        <button
          type="button"
          onClick={onAddTaskClick}
          className="btn-primary h-11 px-4 text-sm font-semibold inline-flex items-center gap-2 whitespace-nowrap cursor-pointer"
        >
          <Plus className="w-4 h-4" strokeWidth={1.75} />
          <span>Add Task</span>
        </button>
      </div>

      {/* Mobile & Tablet Segmented Tabs (12px outer, 4px padding -> 8px inner) */}
      <div className="flex lg:hidden w-full p-1 rounded-[12px] border border-slate-200 bg-white gap-1">
        {(['todo', 'doing', 'done'] as TaskStage[]).map((stage) => {
          const label = stage === 'todo' ? 'To Do' : stage === 'doing' ? 'Doing' : 'Done';
          return (
            <button
              key={stage}
              type="button"
              onClick={() => setActiveStage(stage)}
              className={`flex-1 px-3.5 py-2.5 rounded-[8px] text-xs font-semibold whitespace-nowrap transition-colors duration-150 ease-out cursor-pointer ${
                activeStage === stage
                  ? 'bg-[#0F172A] text-white'
                  : 'text-slate-600 hover:text-[#0F172A]'
              }`}
            >
              {label} ({counts[stage]})
            </button>
          );
        })}
      </div>

      {/* Mobile Single Surface List with 1px Dividers */}
      <section className="lg:hidden surface-card overflow-hidden">
        {visibleTasks.length === 0 ? (
          <div className="p-10 text-center space-y-3">
            <p className="text-sm text-slate-500">No tasks in this stage.</p>
            <button
              type="button"
              onClick={onAddTaskClick}
              className="btn-primary px-4 py-2.5 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" strokeWidth={1.75} />
              <span>Add Task</span>
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-200">{visibleTasks.map(renderTaskRow)}</div>
        )}
      </section>

      {/* Desktop 3-Column Kanban Board (One flat surface per column, 1px dividers inside) */}
      <section className="hidden lg:grid lg:grid-cols-3 gap-6 items-start">
        {(['todo', 'doing', 'done'] as TaskStage[]).map((stage) => {
          const title = stage === 'todo' ? 'To Do' : stage === 'doing' ? 'Doing' : 'Done';
          const stageTasks = tasks.filter((t) => t.stage === stage);
          return (
            <div key={stage} className="surface-card overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
                <h2 className="font-display text-sm font-bold text-[#0F172A]">{title}</h2>
                <span className="text-xs font-mono font-semibold text-slate-500">
                  {stageTasks.length}
                </span>
              </div>
              {stageTasks.length === 0 ? (
                <p className="text-xs text-slate-400 py-10 text-center">No tasks here</p>
              ) : (
                <div className="divide-y divide-slate-200">{stageTasks.map(renderTaskRow)}</div>
              )}
            </div>
          );
        })}
      </section>
    </div>
  );
};
