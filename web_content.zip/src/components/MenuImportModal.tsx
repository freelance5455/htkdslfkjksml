import React, { useState, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, UploadCloud, FileText, CheckCircle2, AlertCircle, RefreshCw, Sparkles, Image as ImageIcon } from "lucide-react";
import { MenuCategory } from "../types";

interface MenuImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyMenu: (newCategories: MenuCategory[]) => void;
  onResetToDefault: () => void;
}

export const MenuImportModal: React.FC<MenuImportModalProps> = ({
  isOpen,
  onClose,
  onApplyMenu,
  onResetToDefault,
}) => {
  const [uploadedFiles, setUploadedFiles] = useState<{ data: string; mimeType: string; name: string }[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [analyzedCategories, setAnalyzedCategories] = useState<MenuCategory[] | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = () => {
        const base64Data = reader.result as string;
        setUploadedFiles((prev) => [
          ...prev,
          {
            data: base64Data,
            mimeType: file.type || "image/jpeg",
            name: file.name,
          },
        ]);
      };
      reader.readAsDataURL(file);
    });
  };

  // Load a realistic pre-configured menu scan for testing
  const handleLoadSampleScan = () => {
    // A sample base64 simulated scan image
    setUploadedFiles([
      {
        name: "kaloreez_menu_scan_page_1.jpg",
        mimeType: "image/jpeg",
        data: "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=1000&q=80",
      },
    ]);
  };

  // Call server OCR
  const handleRunOcr = async () => {
    if (uploadedFiles.length === 0) {
      setErrorMsg("Please upload at least one menu photo or select the sample scan.");
      return;
    }

    setIsAnalyzing(true);
    setErrorMsg(null);

    try {
      // If the image is a remote sample url, convert to base64 or send url context
      const preparedImages = await Promise.all(
        uploadedFiles.map(async (f) => {
          if (f.data.startsWith("http")) {
            const res = await fetch(f.data);
            const blob = await res.blob();
            return new Promise<{ data: string; mimeType: string }>((resolve) => {
              const reader = new FileReader();
              reader.onloadend = () => {
                resolve({
                  data: reader.result as string,
                  mimeType: blob.type || "image/jpeg",
                });
              };
              reader.readAsDataURL(blob);
            });
          }
          return { data: f.data, mimeType: f.mimeType };
        })
      );

      const response = await fetch("/api/menu/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          images: preparedImages,
          textContext: "Kaloreez eatery menu pages uploaded by owner.",
        }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || "Failed to analyze menu images.");
      }

      setAnalyzedCategories(data.categories);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "An error occurred during menu analysis.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleApply = () => {
    if (analyzedCategories && analyzedCategories.length > 0) {
      onApplyMenu(analyzedCategories);
      onClose();
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-[#17201C]/75 backdrop-blur-xs"
        />

        {/* Modal Container */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 20 }}
          className="relative w-full max-w-4xl bg-[#FDFBF7] text-[#17201C] rounded-sm border border-[#D8D0C2] paper-frame overflow-hidden z-10 my-auto shadow-2xl flex flex-col max-h-[90vh]"
        >
          {/* Header */}
          <div className="px-6 py-5 border-b border-[#D8D0C2] flex items-center justify-between bg-[#F4F0E7]">
            <div>
              <div className="text-[10px] tracking-widest uppercase text-[#17201C]/60 font-semibold flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#9BAF82]" />
                Menu Image Import & OCR Reconstruction
              </div>
              <h3 className="font-serif text-2xl text-[#17201C] leading-snug">
                Import Real Kaloreez Menu Photographs
              </h3>
            </div>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-white/70 border border-[#D8D0C2] flex items-center justify-center text-[#17201C] hover:bg-[#17201C] hover:text-[#F4F0E7] transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body */}
          <div className="p-6 sm:p-8 overflow-y-auto flex-grow space-y-6">
            <p className="text-sm text-[#17201C]/75 leading-relaxed">
              Upload photographs, scans, or snapshots of the actual Kaloreez printed menu. We extract exactly what you need: <strong>Dish Name</strong>, <strong>Price</strong>, and a <strong>Short Description</strong> for every dish to instantly update your website and navigation.
            </p>

            {/* Upload Area */}
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-[#D8D0C2] hover:border-[#9BAF82] rounded-xs p-8 text-center cursor-pointer bg-[#F4F0E7]/40 transition-colors"
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*"
                multiple
                className="hidden"
              />
              <UploadCloud className="w-10 h-10 mx-auto mb-3 text-[#9BAF82] stroke-1" />
              <div className="font-serif text-lg text-[#17201C] mb-1">
                Drop menu photographs here, or browse files
              </div>
              <p className="text-xs text-[#17201C]/60">
                Supports JPG, PNG, WEBP (multiple menu sheets or double-sided scans)
              </p>
            </div>

            {/* Uploaded files list */}
            {uploadedFiles.length > 0 && (
              <div>
                <div className="text-xs uppercase tracking-wider text-[#17201C]/70 font-semibold mb-2 flex items-center justify-between">
                  <span>Selected Menu Pages ({uploadedFiles.length})</span>
                  <button
                    onClick={() => setUploadedFiles([])}
                    className="text-[11px] text-[#B96D52] hover:underline"
                  >
                    Clear all
                  </button>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {uploadedFiles.map((file, i) => (
                    <div
                      key={i}
                      className="relative p-2 rounded-xs border border-[#D8D0C2] bg-white text-xs flex flex-col items-center text-center overflow-hidden"
                    >
                      <ImageIcon className="w-6 h-6 text-[#9BAF82] mb-1" />
                      <span className="truncate w-full font-mono text-[11px]">{file.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Sample Button if no files */}
            {uploadedFiles.length === 0 && (
              <div className="flex items-center gap-3 pt-2">
                <span className="text-xs text-[#17201C]/60">Don&apos;t have menu photos on this device?</span>
                <button
                  type="button"
                  onClick={handleLoadSampleScan}
                  className="text-xs font-medium text-[#17201C] underline hover:text-[#9BAF82]"
                >
                  Load Sample Menu Page
                </button>
              </div>
            )}

            {errorMsg && (
              <div className="p-3.5 bg-[#B96D52]/10 border border-[#B96D52]/30 rounded-xs text-xs text-[#B96D52] flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Analyzed Results Preview */}
            {analyzedCategories && (
              <div className="border border-[#9BAF82]/50 bg-[#9BAF82]/10 p-5 rounded-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm font-medium text-[#17201C]">
                    <CheckCircle2 className="w-4 h-4 text-[#9BAF82]" />
                    <span>OCR Successfully Extracted {analyzedCategories.length} Categories</span>
                  </div>
                  <span className="text-xs text-[#17201C]/70 font-mono">
                    {analyzedCategories.reduce((acc, cat) => acc + cat.dishes.length, 0)} Total Dishes
                  </span>
                </div>

                <div className="max-h-72 overflow-y-auto space-y-3 pr-2">
                  {analyzedCategories.map((cat, idx) => (
                    <div key={idx} className="p-3.5 bg-white border border-[#D8D0C2] rounded-xs shadow-2xs">
                      <div className="flex items-center justify-between border-b border-[#D8D0C2]/50 pb-2 mb-2.5">
                        <div className="font-serif font-medium text-[#17201C] text-base">{cat.name}</div>
                        <span className="text-[11px] text-[#17201C]/50 font-mono uppercase">{cat.dishes.length} dishes</span>
                      </div>
                      <div className="space-y-2.5">
                        {cat.dishes.slice(0, 4).map((d, dIdx) => (
                          <div key={dIdx} className="bg-[#FDFBF7] p-2.5 rounded-xs border border-[#D8D0C2]/40">
                            <div className="flex items-baseline justify-between gap-2">
                              <span className="font-serif font-medium text-sm text-[#17201C]">{d.name}</span>
                              <span className="font-mono text-xs font-semibold text-[#B96D52] shrink-0">
                                {d.price || "[VERIFY MENU TEXT]"}
                              </span>
                            </div>
                            {d.description && (
                              <p className="text-xs text-[#17201C]/70 mt-1 line-clamp-2 leading-relaxed">
                                {d.description}
                              </p>
                            )}
                          </div>
                        ))}
                        {cat.dishes.length > 4 && (
                          <div className="text-[11px] text-[#17201C]/50 italic pt-1">
                            + {cat.dishes.length - 4} more dishes extracted in this category...
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Footer Actions */}
          <div className="px-6 py-4 border-t border-[#D8D0C2] bg-[#F4F0E7] flex flex-wrap items-center justify-between gap-3">
            <button
              type="button"
              onClick={onResetToDefault}
              className="text-xs uppercase tracking-wider text-[#17201C]/60 hover:text-[#17201C] transition-colors"
            >
              Restore Standard Kaloreez Menu
            </button>

            <div className="flex items-center gap-3">
              {!analyzedCategories ? (
                <button
                  type="button"
                  disabled={isAnalyzing || uploadedFiles.length === 0}
                  onClick={handleRunOcr}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#17201C] text-[#F4F0E7] text-xs font-medium uppercase tracking-widest hover:bg-[#9BAF82] hover:text-[#17201C] disabled:opacity-50 transition-colors cursor-pointer"
                >
                  {isAnalyzing ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Inspecting Menu Pages...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5 text-[#9BAF82]" />
                      <span>Analyze & Extract Menu</span>
                    </>
                  )}
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleApply}
                  className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#9BAF82] text-[#17201C] text-xs font-semibold uppercase tracking-widest hover:bg-[#17201C] hover:text-[#F4F0E7] transition-colors cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Apply to Live Website</span>
                </button>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
