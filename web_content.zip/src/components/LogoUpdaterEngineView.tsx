import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Upload,
  Image as ImageIcon,
  Camera,
  CheckCircle2,
  RefreshCw,
  Sparkles,
  Sliders,
  Eye,
  Sun,
  Crown,
  Laptop,
  Smartphone
} from 'lucide-react';
import { offlineCache } from '../lib/offlineCache';

interface LogoUpdaterEngineViewProps {
  onShowToast?: (msg: string) => void;
}

const PRESET_EMBLEMS = [
  {
    id: 'preset-sun',
    name: 'Prophetic Golden Sun',
    description: 'Original Sacred Anointing Emblem',
    url: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'preset-glory',
    name: 'Celestial Glory Light',
    description: 'Golden Ethereal Sanctuary Presence',
    url: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'preset-flame',
    name: 'Fire of Pentecost',
    description: 'Anointed Revival Flame',
    url: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'preset-altar',
    name: 'Sovereign Throne Altar',
    description: 'Spiritual Breakthrough Crown',
    url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=400&q=80'
  }
];

export const LogoUpdaterEngineView: React.FC<LogoUpdaterEngineViewProps> = ({ onShowToast }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const [currentGlobalLogo, setCurrentGlobalLogo] = useState<string | null>(() => offlineCache.getCustomAppLogo());
  const [selectedImagePreview, setSelectedImagePreview] = useState<string | null>(() => offlineCache.getCustomAppLogo());
  const [fileDetails, setFileDetails] = useState<{ name: string; size: string; type: string; dimensions?: string } | null>(null);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [activePreviewTab, setActivePreviewTab] = useState<'navbar' | 'appIcon' | 'splash'>('navbar');
  const [haloGlowColor, setHaloGlowColor] = useState<'gold' | 'purple' | 'amber' | 'emerald'>('gold');
  const [borderStyle, setBorderStyle] = useState<'squircle' | 'circle' | 'rounded'>('squircle');

  useEffect(() => {
    const handleLogoSync = () => {
      const active = offlineCache.getCustomAppLogo();
      setCurrentGlobalLogo(active);
      if (!selectedImagePreview) {
        setSelectedImagePreview(active);
      }
    };
    const unsubscribe = offlineCache.subscribe(handleLogoSync);
    window.addEventListener('juhnkrix_logo_updated', handleLogoSync);
    return () => {
      unsubscribe();
      window.removeEventListener('juhnkrix_logo_updated', handleLogoSync);
    };
  }, [selectedImagePreview]);

  const processImageFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      if (onShowToast) onShowToast('❌ Please select a valid image file (PNG, JPG, WEBP, GIF, SVG).');
      return;
    }

    setIsProcessing(true);
    const reader = new FileReader();

    reader.onload = (event) => {
      const rawDataUrl = event.target?.result as string;
      if (!rawDataUrl) {
        setIsProcessing(false);
        return;
      }

      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 600;
        const MAX_HEIGHT = 600;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const optimizedDataUrl = canvas.toDataURL('image/png', 0.95);
          setSelectedImagePreview(optimizedDataUrl);
          setFileDetails({
            name: file.name,
            size: `${(file.size / 1024).toFixed(1)} KB`,
            type: file.type || 'image/png',
            dimensions: `${Math.round(width)} × ${Math.round(height)} px`
          });
        } else {
          setSelectedImagePreview(rawDataUrl);
          setFileDetails({
            name: file.name,
            size: `${(file.size / 1024).toFixed(1)} KB`,
            type: file.type || 'image/png',
            dimensions: `${img.width} × ${img.height} px`
          });
        }
        setIsProcessing(false);
        if (onShowToast) onShowToast(`✓ Selected "${file.name}" ready for logo replacement!`);
      };

      img.onerror = () => {
        setSelectedImagePreview(rawDataUrl);
        setIsProcessing(false);
      };

      img.src = rawDataUrl;
    };

    reader.onerror = () => {
      setIsProcessing(false);
      if (onShowToast) onShowToast('❌ Error reading image from device storage.');
    };

    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processImageFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processImageFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleApplyLogoGlobally = () => {
    if (!selectedImagePreview) {
      if (onShowToast) onShowToast('❌ Please select an image or photo first.');
      return;
    }

    try {
      offlineCache.setCustomAppLogo(selectedImagePreview);
      setCurrentGlobalLogo(selectedImagePreview);

      window.dispatchEvent(
        new CustomEvent('juhnkrix_logo_updated', {
          detail: selectedImagePreview
        })
      );

      const favicon = document.querySelector("link[rel*='icon']") as HTMLLinkElement;
      if (favicon) {
        favicon.href = selectedImagePreview;
      }

      if (onShowToast) {
        onShowToast('✓ JUHNKRIX MUSIKA APP Logo replaced globally across all pages & navigation bars!');
      }
    } catch (err) {
      console.error('Failed to update app logo:', err);
      if (onShowToast) onShowToast('❌ Failed to persist logo.');
    }
  };

  const handleResetToDefault = () => {
    offlineCache.setCustomAppLogo(null);
    setCurrentGlobalLogo(null);
    setSelectedImagePreview(null);
    setFileDetails(null);

    window.dispatchEvent(
      new CustomEvent('juhnkrix_logo_updated', {
        detail: null
      })
    );

    if (onShowToast) {
      onShowToast('✓ Reset JUHNKRIX MUSIKA Logo to sacred default golden sun emblem.');
    }
  };

  const handleSelectPreset = (url: string, name: string) => {
    setSelectedImagePreview(url);
    setFileDetails({
      name,
      size: 'Optimized Preset',
      type: 'image/jpeg',
      dimensions: '400 × 400 px'
    });
    if (onShowToast) onShowToast(`✓ Selected "${name}" preset! Click "Replace App Logo Globally" to save.`);
  };

  return (
    <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/40 border-2 border-amber-500/50 rounded-3xl p-6 sm:p-10 shadow-2xl space-y-8 animate-fadeIn">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-6 border-b border-amber-500/20 pb-6">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 via-amber-600 to-amber-900 p-0.5 shadow-xl shadow-amber-500/30 flex items-center justify-center">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center overflow-hidden">
              {selectedImagePreview ? (
                <img
                  src={selectedImagePreview}
                  alt="Logo Engine Preview"
                  className="w-full h-full object-cover"
                />
              ) : (
                <Sun className="w-8 h-8 text-amber-400 animate-spin-slow" />
              )}
            </div>
          </div>

          <div>
            <div className="flex items-center space-x-2">
              <span className="px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-400/40">
                <Sparkles className="w-3 h-3 inline mr-1 text-amber-400 animate-pulse" />
                OWNER APP LOGO & BRANDING ENGINE
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold font-serif text-amber-100 mt-1">
              JUHNKRIX MUSIKA Logo Machine & Updator
            </h2>
            <p className="text-xs sm:text-sm text-amber-200/70 max-w-2xl mt-1">
              Upload, customize, frame, and instantly deploy custom app emblems, ministry photos, and logos across all navigation headers and PWA mobile views.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 text-slate-950 text-xs sm:text-sm font-black flex items-center space-x-2 shadow-xl shadow-amber-500/25 border border-amber-300 hover:scale-105 active:scale-95 transition-all cursor-pointer shrink-0"
        >
          <Sparkles className="w-4 h-4 text-slate-950 fill-slate-950" />
          <span>OPEN LOGO ENGINE SELECTOR</span>
        </button>
      </div>

      {/* Main Split Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Device File Uploader & Presets (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          <input
            type="file"
            ref={fileInputRef}
            accept="image/*"
            className="hidden"
            onChange={handleFileChange}
          />
          <input
            type="file"
            ref={cameraInputRef}
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={handleFileChange}
          />

          {/* Drag & Drop Box */}
          <div
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-3xl p-8 sm:p-10 flex flex-col items-center justify-center text-center cursor-pointer transition-all duration-300 relative overflow-hidden group ${
              isDragging
                ? 'border-amber-400 bg-amber-500/20 scale-[1.01]'
                : 'border-amber-500/40 bg-slate-950/60 hover:bg-slate-900/80 hover:border-amber-400'
            }`}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 via-transparent to-purple-500/5 pointer-events-none" />

            <div className="w-18 h-18 rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-700/20 border border-amber-400/30 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-lg shadow-amber-500/10">
              <Upload className="w-9 h-9 text-amber-400 animate-pulse" />
            </div>

            <h3 className="text-lg sm:text-xl font-bold text-amber-100 font-serif">
              Upload Custom Logo from Device Storage
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 max-w-md mt-1 mb-5">
              Select image files from your phone gallery, tablet storage, or computer files to instantly replace the JUHNKRIX MUSIKA app emblem.
            </p>

            <div className="flex flex-wrap items-center justify-center gap-3">
              <span className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 text-xs font-black flex items-center space-x-2 shadow-md shadow-amber-500/30">
                <ImageIcon className="w-4 h-4" />
                <span>Browse Files</span>
              </span>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  cameraInputRef.current?.click();
                }}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-200 text-xs font-bold border border-amber-500/30 flex items-center space-x-2 transition-colors"
              >
                <Camera className="w-4 h-4 text-amber-400" />
                <span>Take Photo</span>
              </button>
            </div>

            <span className="text-[11px] text-slate-400 mt-4">
              Supports PNG, JPG, WEBP, SVG, HEIC, GIF (High-Resolution Auto-Scaling)
            </span>
          </div>

          {/* Selected File Details Bar */}
          {fileDetails && (
            <div className="bg-slate-950/80 border border-amber-500/30 rounded-2xl p-4 flex items-center justify-between text-xs">
              <div className="flex items-center space-x-3 truncate">
                <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-300">
                  <ImageIcon className="w-5 h-5" />
                </div>
                <div className="truncate">
                  <p className="font-bold text-amber-200 truncate text-sm">{fileDetails.name}</p>
                  <p className="text-xs text-slate-400">
                    {fileDetails.size} • {fileDetails.dimensions || fileDetails.type}
                  </p>
                </div>
              </div>

              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-semibold border border-amber-500/20 shrink-0"
              >
                Change File
              </button>
            </div>
          )}

          {/* Preset Emblems Gallery */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center space-x-1.5">
                <Crown className="w-4 h-4 text-amber-400" />
                <span>Or Select Anointed Ministry Emblems</span>
              </span>
              <span className="text-[10px] text-slate-400 font-mono">Curated Presets</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {PRESET_EMBLEMS.map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => handleSelectPreset(preset.url, preset.name)}
                  className="p-3 rounded-2xl bg-slate-950/60 hover:bg-slate-900 border border-amber-500/20 hover:border-amber-400 transition-all flex flex-col items-center text-center group cursor-pointer"
                >
                  <div className="w-14 h-14 rounded-xl overflow-hidden border border-amber-500/30 mb-2.5 group-hover:scale-105 transition-transform shadow-md">
                    <img
                      src={preset.url}
                      alt={preset.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <span className="text-xs font-bold text-amber-200 group-hover:text-amber-100 truncate w-full">
                    {preset.name}
                  </span>
                  <span className="text-[10px] text-slate-400 truncate w-full mt-0.5">
                    {preset.description}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Framing & Halo Settings */}
          <div className="bg-slate-950/80 border border-amber-500/20 rounded-2xl p-5 space-y-4">
            <span className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center space-x-2">
              <Sliders className="w-4 h-4 text-amber-400" />
              <span>Emblem Framing & Golden Glow Calibration</span>
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="text-[11px] font-semibold text-slate-300 block mb-1.5">
                  Frame Geometry
                </label>
                <div className="flex rounded-xl bg-slate-900 p-1 border border-slate-800">
                  {(['squircle', 'circle', 'rounded'] as const).map((shape) => (
                    <button
                      key={shape}
                      type="button"
                      onClick={() => setBorderStyle(shape)}
                      className={`flex-1 py-1.5 text-xs font-bold rounded-lg capitalize transition-all ${
                        borderStyle === shape
                          ? 'bg-amber-500 text-slate-950 shadow'
                          : 'text-slate-400 hover:text-amber-200'
                      }`}
                    >
                      {shape}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-300 block mb-1.5">
                  Divine Halo Glow
                </label>
                <div className="flex rounded-xl bg-slate-900 p-1 border border-slate-800">
                  {(['gold', 'purple', 'amber', 'emerald'] as const).map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setHaloGlowColor(color)}
                      className={`flex-1 py-1.5 text-xs font-bold rounded-lg capitalize transition-all ${
                        haloGlowColor === color
                          ? 'bg-amber-500 text-slate-950 shadow'
                          : 'text-slate-400 hover:text-amber-200'
                      }`}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Live Previews & Actions (5 Cols) */}
        <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center space-x-1.5">
                <Eye className="w-4 h-4 text-amber-400" />
                <span>Real-time Live Preview</span>
              </span>
              <span className="text-xs text-emerald-400 font-mono flex items-center">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping mr-1.5" />
                Live Sync Active
              </span>
            </div>

            {/* Preview Tabs */}
            <div className="flex rounded-2xl bg-slate-950 p-1.5 border border-amber-500/20 text-xs">
              {[
                { id: 'navbar', label: 'Navbar Badge', icon: Laptop },
                { id: 'appIcon', label: 'App Icon', icon: Smartphone },
                { id: 'splash', label: 'Splash Screen', icon: Sparkles }
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActivePreviewTab(item.id as any)}
                    className={`flex-1 py-2 rounded-xl font-bold flex items-center justify-center space-x-1.5 transition-all ${
                      activePreviewTab === item.id
                        ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md font-extrabold'
                        : 'text-slate-400 hover:text-amber-200'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Preview Box */}
            <div className="bg-slate-950 border border-amber-500/30 rounded-3xl p-6 flex flex-col items-center justify-center min-h-[240px] relative overflow-hidden shadow-inner">
              <div className="absolute inset-0 bg-gradient-to-b from-amber-500/5 via-transparent to-purple-500/10 pointer-events-none" />

              {activePreviewTab === 'navbar' && (
                <div className="w-full bg-slate-900/90 border border-amber-500/30 rounded-2xl p-4 flex items-center space-x-3.5 shadow-xl">
                  <div
                    className={`relative flex items-center justify-center w-12 h-12 p-0.5 shadow-lg ${
                      borderStyle === 'circle'
                        ? 'rounded-full'
                        : borderStyle === 'rounded'
                        ? 'rounded-xl'
                        : 'rounded-2xl'
                    } ${
                      haloGlowColor === 'gold'
                        ? 'bg-gradient-to-br from-amber-300 via-amber-500 to-amber-800 shadow-amber-500/30'
                        : haloGlowColor === 'purple'
                        ? 'bg-gradient-to-br from-purple-400 via-purple-600 to-indigo-900 shadow-purple-500/30'
                        : haloGlowColor === 'emerald'
                        ? 'bg-gradient-to-br from-emerald-400 via-emerald-600 to-teal-900 shadow-emerald-500/30'
                        : 'bg-gradient-to-br from-amber-400 via-amber-600 to-yellow-900 shadow-amber-500/30'
                    }`}
                  >
                    <div
                      className={`w-full h-full bg-slate-950 flex items-center justify-center overflow-hidden ${
                        borderStyle === 'circle'
                          ? 'rounded-full'
                          : borderStyle === 'rounded'
                          ? 'rounded-[10px]'
                          : 'rounded-[14px]'
                      }`}
                    >
                      {selectedImagePreview ? (
                        <img
                          src={selectedImagePreview}
                          alt="Navbar Logo"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <Sun className="w-6 h-6 text-amber-400 animate-spin-slow" />
                      )}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-bold bg-gradient-to-r from-amber-200 via-amber-400 to-yellow-100 bg-clip-text text-transparent font-serif">
                      JUHNKRIX MUSIKA
                    </h4>
                    <p className="text-[10px] tracking-widest text-amber-300/70 uppercase font-medium">
                      Owner Sanctuary & Logo Gateway
                    </p>
                  </div>
                </div>
              )}

              {activePreviewTab === 'appIcon' && (
                <div className="flex flex-col items-center space-y-3">
                  <div
                    className={`w-28 h-28 p-1 shadow-2xl ${
                      borderStyle === 'circle'
                        ? 'rounded-full'
                        : borderStyle === 'rounded'
                        ? 'rounded-2xl'
                        : 'rounded-3xl'
                    } ${
                      haloGlowColor === 'gold'
                        ? 'bg-gradient-to-br from-amber-300 via-amber-500 to-amber-900 shadow-amber-500/40'
                        : haloGlowColor === 'purple'
                        ? 'bg-gradient-to-br from-purple-400 via-purple-600 to-indigo-900 shadow-purple-500/40'
                        : 'bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-800 shadow-amber-500/40'
                    }`}
                  >
                    <div
                      className={`w-full h-full bg-slate-950 flex items-center justify-center overflow-hidden ${
                        borderStyle === 'circle'
                          ? 'rounded-full'
                          : borderStyle === 'rounded'
                          ? 'rounded-[14px]'
                          : 'rounded-[20px]'
                      }`}
                    >
                      {selectedImagePreview ? (
                        <img
                          src={selectedImagePreview}
                          alt="Mobile App Icon"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <Sun className="w-12 h-12 text-amber-400 animate-spin-slow" />
                      )}
                    </div>
                  </div>
                  <span className="text-xs font-bold text-amber-200">JUHNKRIX MUSIKA App</span>
                  <span className="text-[10px] text-slate-400">Android & PWA Home Screen Icon</span>
                </div>
              )}

              {activePreviewTab === 'splash' && (
                <div className="w-full bg-gradient-to-b from-slate-900 to-slate-950 border border-amber-500/20 rounded-2xl p-5 flex flex-col items-center text-center space-y-2.5">
                  <div className="w-18 h-18 rounded-2xl overflow-hidden border-2 border-amber-400 shadow-xl shadow-amber-500/30">
                    {selectedImagePreview ? (
                      <img
                        src={selectedImagePreview}
                        alt="Splash Emblem"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <Sun className="w-9 h-9 text-amber-400 m-auto" />
                    )}
                  </div>
                  <h5 className="text-sm font-bold text-amber-100 font-serif">JUHNKRIX MUSIKA</h5>
                  <p className="text-[10px] text-slate-400">World's Powerful Spiritual Gospel Experience</p>
                </div>
              )}
            </div>

            {/* Status Indicator */}
            <div className="bg-slate-950/60 p-3.5 rounded-2xl border border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-400">Active App Logo State:</span>
              <span className="font-bold text-amber-300 font-mono">
                {currentGlobalLogo ? 'Custom Photo Active' : 'Sacred Golden Sun (Default)'}
              </span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3 pt-4 border-t border-slate-800">
            <button
              onClick={handleApplyLogoGlobally}
              disabled={isProcessing || !selectedImagePreview}
              className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 text-slate-950 text-sm font-black flex items-center justify-center space-x-2 shadow-2xl shadow-amber-500/30 transition-all hover:scale-[1.02] active:scale-[0.98] border border-amber-200 cursor-pointer disabled:opacity-50"
            >
              <CheckCircle2 className="w-5 h-5 text-slate-950" />
              <span>REPLACE APP LOGO GLOBALLY</span>
            </button>

            <button
              type="button"
              onClick={handleResetToDefault}
              className="w-full py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-rose-300 hover:text-rose-200 text-xs font-bold border border-rose-500/30 flex items-center justify-center space-x-2 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Reset Logo to Default Golden Sun</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
