import React, { useState } from 'react';
import {
  ChevronDown,
  Heart,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Shuffle,
  Repeat,
  Repeat1,
  ListMusic,
  Moon,
  FolderPlus,
  Trash2,
} from 'lucide-react';
import { Song, RepeatMode } from '../types';
import { ArtworkImage } from './ArtworkImage';

interface NowPlayingOverlayProps {
  song: Song;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  queue: Song[];
  currentIndex: number;
  isShuffle: boolean;
  repeatMode: RepeatMode;
  sleepTimerMinutes: number | null;
  onClose: () => void;
  onPlayPause: () => void;
  onSeek: (timeSec: number) => void;
  onSkipNext: () => void;
  onSkipPrevious: () => void;
  onToggleShuffle: () => void;
  onCycleRepeat: () => void;
  onToggleFavorite: (song: Song) => void;
  onPlayFromQueue: (index: number) => void;
  onRemoveFromQueue: (index: number) => void;
  onOpenSleepTimer: () => void;
  onAddToPlaylist: (song: Song) => void;
}

export const NowPlayingOverlay: React.FC<NowPlayingOverlayProps> = ({
  song,
  isPlaying,
  currentTime,
  duration,
  queue,
  currentIndex,
  isShuffle,
  repeatMode,
  sleepTimerMinutes,
  onClose,
  onPlayPause,
  onSeek,
  onSkipNext,
  onSkipPrevious,
  onToggleShuffle,
  onCycleRepeat,
  onToggleFavorite,
  onPlayFromQueue,
  onRemoveFromQueue,
  onOpenSleepTimer,
  onAddToPlaylist,
}) => {
  const [showQueue, setShowQueue] = useState(false);
  const [isSeeking, setIsSeeking] = useState(false);
  const [seekValue, setSeekValue] = useState(currentTime);

  const formatTime = (seconds: number) => {
    if (isNaN(seconds) || seconds < 0) return '0:00';
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setIsSeeking(true);
    setSeekValue(parseFloat(e.target.value));
  };

  const handleSliderCommit = () => {
    setIsSeeking(false);
    onSeek(seekValue);
  };

  const displayedTime = isSeeking ? seekValue : currentTime;
  const progressRatio = duration > 0 ? (displayedTime / duration) * 100 : 0;

  return (
    <div className="fixed inset-0 z-50 bg-[#090D10]/95 backdrop-blur-2xl flex flex-col justify-between p-6 sm:p-8 animate-in slide-in-from-bottom duration-300 overflow-y-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between w-full max-w-md mx-auto">
        <button
          onClick={onClose}
          className="p-2 -ml-2 text-slate-400 hover:text-slate-100 hover:bg-slate-800/50 rounded-full transition-colors"
          title="Minimize player"
        >
          <ChevronDown size={28} />
        </button>

        <div className="text-center">
          <span className="text-[11px] uppercase tracking-wider font-semibold text-emerald-400">
            Now Playing
          </span>
          <p className="text-xs text-slate-400 truncate max-w-[200px]">
            {song.album || 'Single Track'}
          </p>
        </div>

        <button
          onClick={() => setShowQueue(!showQueue)}
          className={`p-2 -mr-2 rounded-full transition-colors ${
            showQueue
              ? 'text-emerald-400 bg-emerald-950/60 border border-emerald-500/40'
              : 'text-slate-400 hover:text-slate-100'
          }`}
          title="Play Queue"
        >
          <ListMusic size={24} />
        </button>
      </div>

      {/* Main Content: Artwork or Queue */}
      <div className="w-full max-w-md mx-auto my-auto py-4">
        {!showQueue ? (
          <div className="flex flex-col items-center">
            {/* Album Cover Art */}
            <div className="relative group w-64 h-64 sm:w-80 sm:h-80 shadow-2xl rounded-2xl overflow-hidden border border-slate-700/50">
              <ArtworkImage
                artworkUrl={song.artworkUrl}
                alt={song.title}
                className="w-full h-full object-cover"
                iconSize={80}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>

            {/* Track Info */}
            <div className="w-full mt-6 flex items-start justify-between">
              <div className="min-w-0 pr-4">
                <h2 className="text-2xl font-bold text-slate-100 truncate">
                  {song.title}
                </h2>
                <p className="text-base text-slate-400 truncate mt-0.5">
                  {song.artist}
                </p>
                {song.genre && (
                  <span className="inline-block mt-2 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-emerald-950/80 text-emerald-300 border border-emerald-800/40">
                    {song.genre}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1.5 flex-shrink-0">
                <button
                  onClick={() => onToggleFavorite(song)}
                  className="p-2 text-slate-400 hover:text-emerald-400 transition-colors"
                  title="Favorite"
                >
                  <Heart
                    size={24}
                    className={
                      song.isFavorite
                        ? 'fill-emerald-500 text-emerald-500'
                        : ''
                    }
                  />
                </button>
                <button
                  onClick={() => onAddToPlaylist(song)}
                  className="p-2 text-slate-400 hover:text-emerald-400 transition-colors"
                  title="Add to Playlist"
                >
                  <FolderPlus size={24} />
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="h-80 w-full bg-[#12181F] rounded-2xl border border-slate-800 p-4 flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="text-sm font-semibold text-slate-200">
                Queue ({queue.length} songs)
              </span>
              <button
                onClick={() => setShowQueue(false)}
                className="text-xs text-emerald-400 hover:underline"
              >
                Close Queue
              </button>
            </div>
            <div className="flex-1 overflow-y-auto space-y-1 mt-2 pr-1">
              {queue.map((track, idx) => (
                <div
                  key={`${track.id}-${idx}`}
                  onClick={() => onPlayFromQueue(idx)}
                  className={`flex items-center justify-between p-2 rounded-lg cursor-pointer transition-colors ${
                    idx === currentIndex
                      ? 'bg-emerald-950/60 border border-emerald-500/30 text-emerald-400'
                      : 'hover:bg-slate-800/50 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="text-xs font-mono text-slate-500 w-4">
                      {idx + 1}
                    </span>
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{track.title}</p>
                      <p className="text-xs text-slate-400 truncate">{track.artist}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500">
                      {formatTime(track.duration)}
                    </span>
                    {queue.length > 1 && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onRemoveFromQueue(idx);
                        }}
                        className="p-1 text-slate-500 hover:text-red-400"
                        title="Remove from queue"
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Progress Scrubber */}
        <div className="w-full mt-6">
          <div className="relative group flex items-center">
            <input
              type="range"
              min={0}
              max={duration || 1}
              step={0.5}
              value={displayedTime}
              onChange={handleSliderChange}
              onMouseUp={handleSliderCommit}
              onTouchEnd={handleSliderCommit}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500 focus:outline-none"
            />
          </div>
          <div className="flex justify-between text-xs text-slate-400 font-mono mt-2">
            <span>{formatTime(displayedTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-between w-full mt-6">
          <button
            onClick={onToggleShuffle}
            className={`p-3 rounded-full transition-colors ${
              isShuffle
                ? 'text-emerald-400 bg-emerald-950/60'
                : 'text-slate-500 hover:text-slate-300'
            }`}
            title={`Shuffle: ${isShuffle ? 'On' : 'Off'}`}
          >
            <Shuffle size={20} />
          </button>

          <button
            onClick={onSkipPrevious}
            className="p-3 text-slate-300 hover:text-slate-100 active:scale-95 transition-all"
            title="Previous track"
          >
            <SkipBack size={26} />
          </button>

          <button
            onClick={onPlayPause}
            className="w-16 h-16 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center hover:bg-emerald-400 active:scale-95 shadow-lg shadow-emerald-500/20 transition-all"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? (
              <Pause size={28} fill="currentColor" />
            ) : (
              <Play size={28} className="ml-1" fill="currentColor" />
            )}
          </button>

          <button
            onClick={onSkipNext}
            className="p-3 text-slate-300 hover:text-slate-100 active:scale-95 transition-all"
            title="Next track"
          >
            <SkipForward size={26} />
          </button>

          <button
            onClick={onCycleRepeat}
            className={`p-3 rounded-full transition-colors ${
              repeatMode !== 'off'
                ? 'text-emerald-400 bg-emerald-950/60'
                : 'text-slate-500 hover:text-slate-300'
            }`}
            title={`Repeat: ${repeatMode}`}
          >
            {repeatMode === 'one' ? <Repeat1 size={20} /> : <Repeat size={20} />}
          </button>
        </div>

        {/* Bottom Utility Bar */}
        <div className="flex items-center justify-center gap-6 mt-8 pt-4 border-t border-slate-800/60">
          <button
            onClick={onOpenSleepTimer}
            className="flex items-center gap-2 text-xs font-medium text-slate-400 hover:text-emerald-400 transition-colors"
          >
            <Moon size={16} />
            <span>
              {sleepTimerMinutes !== null
                ? `Timer: ${sleepTimerMinutes}m left`
                : 'Sleep Timer'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
