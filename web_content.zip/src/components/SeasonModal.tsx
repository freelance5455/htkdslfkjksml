import React from 'react';
import { useKingdom } from '../context/KingdomContext';
import {
  Trophy,
  X,
  Crown,
  Calendar,
  Sparkles,
} from 'lucide-react';

interface SeasonModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface RivalLord {
  rank: number;
  name: string;
  castle: string;
  civilization: string;
  glory: number;
  isPlayer?: boolean;
}

export const SeasonModal: React.FC<SeasonModalProps> = ({ isOpen, onClose }) => {
  const { kingdom } = useKingdom();
  if (!isOpen || !kingdom) return null;

  const playerGlory = kingdom.gloryPoints;

  const baselineLords: Omit<RivalLord, 'rank'>[] = [
    { name: 'Don Rodrigo Díaz de Vivar', castle: 'Castillo de Vivar', civilization: 'Visigodos', glory: 8450 },
    { name: 'Barón Roderico de Montefrío', castle: 'Fortaleza Nevada', civilization: 'Íberos', glory: 6200 },
    { name: 'Conde Bermudo de Sobrarbe', castle: 'Alcázar Pirenaico', civilization: 'Celtas', glory: 4890 },
    { name: 'Emir Al-Mansur de Medina', castle: 'Alhambra Califal', civilization: 'Romanos', glory: 3740 },
    { name: 'Señor de Albarracín', castle: 'Muralla Roja', civilization: 'Íberos', glory: 2900 },
    { name: 'Vizconde de Cardona', castle: 'Torre de la Sal', civilization: 'Celtas', glory: 1850 },
  ];

  const playerEntry: Omit<RivalLord, 'rank'> = {
    name: kingdom.kingdomName,
    castle: kingdom.castleName,
    civilization: kingdom.civilization.toUpperCase(),
    glory: playerGlory,
    isPlayer: true,
  };

  const combined = [...baselineLords, playerEntry].sort((a, b) => b.glory - a.glory);
  const rankedLords: RivalLord[] = combined.map((item, idx) => ({
    ...item,
    rank: idx + 1,
  }));

  const playerRank = rankedLords.find((l) => l.isPlayer)?.rank || 4;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-stone-900 border border-stone-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-800 pb-4 mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-950/50 border border-amber-800/60 text-amber-400">
              <Trophy className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-bold font-serif text-stone-100">
                  Temporada I: El Despertar de la Corona
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-600 text-stone-950">
                  ACTIVA
                </span>
              </div>
              <p className="text-xs text-stone-400">
                Clasificación general de señores feudales y puntos de gloria
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-stone-800 text-stone-400 hover:text-stone-200 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Season Info Banner */}
        <div className="p-4 rounded-2xl bg-stone-950 border border-stone-800 mb-5 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-stone-300">
            <Calendar className="w-4 h-4 text-amber-500" />
            <span>Tiempo restante de temporada: <strong className="text-amber-400">14 días</strong></span>
          </div>
          <div className="flex items-center gap-2 text-stone-300">
            <Crown className="w-4 h-4 text-yellow-500" />
            <span>Tu Puesto Actual: <strong className="text-yellow-400 font-mono text-sm">#{playerRank}</strong></span>
          </div>
        </div>

        {/* Table of Lords */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-2 mb-4">
          {rankedLords.map((lord) => {
            const isUser = lord.isPlayer;
            return (
              <div
                key={lord.name}
                className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 transition ${
                  isUser
                    ? 'bg-amber-950/40 border-amber-500 shadow-lg shadow-amber-950/40'
                    : 'bg-stone-950/60 border-stone-800/80 hover:border-stone-700'
                }`}
              >
                <div className="flex items-center gap-3 min-w-[200px]">
                  <div
                    className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold text-xs font-mono ${
                      lord.rank === 1
                        ? 'bg-amber-500 text-stone-950'
                        : lord.rank === 2
                        ? 'bg-slate-300 text-stone-950'
                        : lord.rank === 3
                        ? 'bg-amber-700 text-stone-100'
                        : 'bg-stone-800 text-stone-400'
                    }`}
                  >
                    {lord.rank}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-stone-100 text-sm font-serif">
                        {lord.name}
                      </span>
                      {isUser && (
                        <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-amber-600 text-stone-950">
                          Tú
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-stone-400">
                      {lord.castle} • {lord.civilization}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="text-right">
                    <div className="text-sm font-bold font-mono text-amber-300">
                      {lord.glory.toLocaleString()}
                    </div>
                    <div className="text-[10px] text-stone-500 uppercase font-semibold">
                      Gloria
                    </div>
                  </div>
                  {lord.rank <= 3 && (
                    <Trophy className="w-4 h-4 text-amber-400" />
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Rewards Preview */}
        <div className="p-3.5 rounded-xl bg-amber-950/20 border border-amber-800/40 text-xs text-amber-200/90 flex items-center gap-2.5">
          <Sparkles className="w-4 h-4 shrink-0 text-amber-400" />
          <span>
            Al concluir la temporada, el Top 3 recibirá la <strong>Corona de Laurel Imperial</strong> y botín de 50.000 Oro para la próxima campaña.
          </span>
        </div>

        {/* Footer */}
        <div className="mt-5 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold transition cursor-pointer"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
