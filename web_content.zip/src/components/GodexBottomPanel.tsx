/**
 * GODEX Phase 0 - Bottom Engineering Panel
 * Tabbed developer drawer: Terminal, Tests, Logs, Diff, Agents, Verification Matrix
 */

import React, { useState, useEffect } from 'react';
import { 
  Terminal, 
  CheckCircle2, 
  Activity, 
  GitCompare, 
  Users, 
  ShieldCheck, 
  ChevronUp, 
  ChevronDown, 
  X, 
  RotateCcw, 
  Play, 
  AlertCircle,
  FileCode,
  Sparkles,
  Info,
  Cpu,
  Globe,
  Radio,
  Clock,
  Ban,
  Wrench,
  HelpCircle,
  Check,
  RefreshCw,
  Search
} from 'lucide-react';
import { 
  EngineeringBottomTab, 
  TerminalLog, 
  VerificationReport, 
  ActivityLogItem, 
  TaskState 
} from '../types';
import { ExecutionRegistry } from '../execution/executionRegistry';
import { PortManager } from '../execution/portManager';
import { ExecutionEngine } from '../execution/executor';
import { SimulationExecutionTestSuite, ExecutionTestSuiteResult } from '../execution/simulationExecutionTest';
import { SelfHealingEngine } from '../debugger/selfHealingEngine';
import { SimulationDebuggerTestSuite, DebuggerTestSuiteResult } from '../debugger/simulationDebuggerTest';
import { DebuggerSession } from '../debugger/debuggerTypes';
import { runUniversalAppBuilderP21TestSuite, P21TestSuiteResult } from '../builder/universalAppBuilderP21Test';
import { runUniversalAppBuilderP22TestSuite, P22TestSuiteResult } from '../builder/universalAppBuilderP22Test';
import { UniversalAppBuilderP23TestSuite, P23TestSuiteReport } from '../builder/universalAppBuilderP23Test';
import { UniversalAppBuilderP24TestSuite, P24TestSuiteReport } from '../builder/universalAppBuilderP24Test';
import { UniversalAppBuilderP25Test, P25TestSuiteReport } from '../builder/universalAppBuilderP25Test';
import { UniversalAppBuilderP26Test, P26TestSuiteReport } from '../builder/universalAppBuilderP26Test';
import { UniversalAppBuilderP27Test, P27TestSuiteSummary } from '../builder/universalAppBuilderP27Test';
import { UniversalAppBuilderP28Test, P28TestSuiteSummary } from '../builder/universalAppBuilderP28Test';
import { UniversalAppBuilderP30Test, P30TestCaseResult } from '../builder/universalAppBuilderP30Test';
import { UniversalAppBuilderP31Test, P31TestCaseResult } from '../builder/universalAppBuilderP31Test';
import { UniversalAppBuilderP36Test, P36SuiteSummary } from '../builder/universalAppBuilderP36Test';

interface GodexBottomPanelProps {
  isOpen: boolean;
  onToggle: () => void;
  activeTab: EngineeringBottomTab;
  onSelectTab: (tab: EngineeringBottomTab) => void;
  terminalLogs: TerminalLog[];
  onExecuteTerminalCommand: (cmd: string) => void;
  onClearTerminal: () => void;
  verificationReport: VerificationReport | null;
  onRunVerification: () => void;
  activityLogs: ActivityLogItem[];
  taskState: TaskState;
}

export const GodexBottomPanel: React.FC<GodexBottomPanelProps> = ({
  isOpen,
  onToggle,
  activeTab,
  onSelectTab,
  terminalLogs,
  onExecuteTerminalCommand,
  onClearTerminal,
  verificationReport,
  onRunVerification,
  activityLogs,
  taskState
}) => {
  const [terminalInput, setTerminalInput] = useState('');
  const [testSuiteResult, setTestSuiteResult] = useState<ExecutionTestSuiteResult | null>(null);
  const [isRunningSuite, setIsRunningSuite] = useState(false);
  const [debuggerSuiteResult, setDebuggerSuiteResult] = useState<DebuggerTestSuiteResult | null>(null);
  const [isRunningDebuggerSuite, setIsRunningDebuggerSuite] = useState(false);
  const [activePorts, setActivePorts] = useState(PortManager.getActivePorts());
  const [recentExecutions, setRecentExecutions] = useState(ExecutionRegistry.getRecent(10));
  const [debuggerSession, setDebuggerSession] = useState<DebuggerSession | null>(SelfHealingEngine.getInstance().getSession());

  const [p21SuiteResult, setP21SuiteResult] = useState<P21TestSuiteResult | null>(null);
  const [isRunningP21Suite, setIsRunningP21Suite] = useState(false);
  const [p22SuiteResult, setP22SuiteResult] = useState<P22TestSuiteResult | null>(null);
  const [isRunningP22Suite, setIsRunningP22Suite] = useState(false);
  const [p23SuiteResult, setP23SuiteResult] = useState<P23TestSuiteReport | null>(null);
  const [isRunningP23Suite, setIsRunningP23Suite] = useState(false);
  const [p24SuiteResult, setP24SuiteResult] = useState<P24TestSuiteReport | null>(null);
  const [isRunningP24Suite, setIsRunningP24Suite] = useState(false);
  const [p25SuiteResult, setP25SuiteResult] = useState<P25TestSuiteReport | null>(null);
  const [isRunningP25Suite, setIsRunningP25Suite] = useState(false);
  const [p26SuiteResult, setP26SuiteResult] = useState<P26TestSuiteReport | null>(null);
  const [isRunningP26Suite, setIsRunningP26Suite] = useState(false);
  const [p27SuiteResult, setP27SuiteResult] = useState<P27TestSuiteSummary | null>(null);
  const [isRunningP27Suite, setIsRunningP27Suite] = useState(false);
  const [p28SuiteResult, setP28SuiteResult] = useState<P28TestSuiteSummary | null>(null);
  const [isRunningP28Suite, setIsRunningP28Suite] = useState(false);
  const [p30SuiteResult, setP30SuiteResult] = useState<{ totalTests: number; passedTests: number; failedTests: number; results: P30TestCaseResult[] } | null>(null);
  const [isRunningP30Suite, setIsRunningP30Suite] = useState(false);
  const [p31SuiteResult, setP31SuiteResult] = useState<{ totalTests: number; passedTests: number; failedTests: number; results: P31TestCaseResult[] } | null>(null);
  const [isRunningP31Suite, setIsRunningP31Suite] = useState(false);
  const [p36SuiteResult, setP36SuiteResult] = useState<P36SuiteSummary | null>(null);
  const [isRunningP36Suite, setIsRunningP36Suite] = useState(false);

  useEffect(() => {
    const unsub = SelfHealingEngine.getInstance().subscribe(() => {
      setDebuggerSession(SelfHealingEngine.getInstance().getSession());
    });

    const interval = setInterval(() => {
      setActivePorts(PortManager.getActivePorts());
      setRecentExecutions(ExecutionRegistry.getRecent(10));
      setDebuggerSession(SelfHealingEngine.getInstance().getSession());
    }, 1000);

    return () => {
      unsub();
      clearInterval(interval);
    };
  }, []);

  const handleRunP21Suite = async () => {
    setIsRunningP21Suite(true);
    try {
      const res = await runUniversalAppBuilderP21TestSuite();
      setP21SuiteResult(res);
    } finally {
      setIsRunningP21Suite(false);
    }
  };

  const handleRunP22Suite = async () => {
    setIsRunningP22Suite(true);
    try {
      const res = await runUniversalAppBuilderP22TestSuite();
      setP22SuiteResult(res);
    } finally {
      setIsRunningP22Suite(false);
    }
  };

  const handleRunP23Suite = async () => {
    setIsRunningP23Suite(true);
    try {
      const res = await UniversalAppBuilderP23TestSuite.runAllTests();
      setP23SuiteResult(res);
    } finally {
      setIsRunningP23Suite(false);
    }
  };

  const handleRunP24Suite = async () => {
    setIsRunningP24Suite(true);
    try {
      const res = await UniversalAppBuilderP24TestSuite.runAllTests();
      setP24SuiteResult(res);
    } finally {
      setIsRunningP24Suite(false);
    }
  };

  const handleRunP25Suite = async () => {
    setIsRunningP25Suite(true);
    try {
      const res = await UniversalAppBuilderP25Test.runAllTests();
      setP25SuiteResult(res);
    } finally {
      setIsRunningP25Suite(false);
    }
  };

  const handleRunP26Suite = async () => {
    setIsRunningP26Suite(true);
    try {
      const res = await UniversalAppBuilderP26Test.runAllTests();
      setP26SuiteResult(res);
    } finally {
      setIsRunningP26Suite(false);
    }
  };

  const handleRunP36Suite = async () => {
    setIsRunningP36Suite(true);
    try {
      const res = await UniversalAppBuilderP36Test.runAllTests();
      setP36SuiteResult(res);
    } finally {
      setIsRunningP36Suite(false);
    }
  };

  const handleRunP31Suite = async () => {
    setIsRunningP31Suite(true);
    try {
      const res = await UniversalAppBuilderP31Test.runAllTests();
      setP31SuiteResult(res);
    } finally {
      setIsRunningP31Suite(false);
    }
  };

  const handleRunP30Suite = async () => {
    setIsRunningP30Suite(true);
    try {
      const res = await UniversalAppBuilderP30Test.runAllTests();
      setP30SuiteResult(res);
    } finally {
      setIsRunningP30Suite(false);
    }
  };

  const handleRunP28Suite = async () => {
    setIsRunningP28Suite(true);
    try {
      const res = await UniversalAppBuilderP28Test.runAllTests();
      setP28SuiteResult(res);
    } finally {
      setIsRunningP28Suite(false);
    }
  };

  const handleRunP27Suite = async () => {
    setIsRunningP27Suite(true);
    try {
      const res = await UniversalAppBuilderP27Test.runAllTests();
      setP27SuiteResult(res);
    } finally {
      setIsRunningP27Suite(false);
    }
  };

  const handleRunExecutionSuite = async () => {
    setIsRunningSuite(true);
    try {
      const res = await SimulationExecutionTestSuite.runSuite();
      setTestSuiteResult(res);
    } finally {
      setIsRunningSuite(false);
    }
  };

  const handleRunDebuggerSuite = async () => {
    setIsRunningDebuggerSuite(true);
    try {
      const res = await SimulationDebuggerTestSuite.runSuite();
      setDebuggerSuiteResult(res);
    } finally {
      setIsRunningDebuggerSuite(false);
    }
  };

  const handleCommandSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!terminalInput.trim()) return;
    onExecuteTerminalCommand(terminalInput.trim());
    setTerminalInput('');
  };

  const tabs: Array<{ id: EngineeringBottomTab; label: string; icon: React.ReactNode }> = [
    { id: 'terminal', label: 'TERMINAL', icon: <Terminal className="w-3.5 h-3.5 text-cyan-400" /> },
    { id: 'execution', label: 'EXECUTION ENGINE', icon: <Cpu className="w-3.5 h-3.5 text-amber-400" /> },
    { id: 'debugger', label: 'SELF-HEALING DEBUGGER', icon: <Wrench className="w-3.5 h-3.5 text-rose-400" /> },
    { id: 'tests', label: 'TESTS', icon: <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> },
    { id: 'logs', label: 'SYSTEM LOGS', icon: <Activity className="w-3.5 h-3.5 text-purple-400" /> },
    { id: 'diff', label: 'DIFF INSPECTOR', icon: <GitCompare className="w-3.5 h-3.5 text-blue-400" /> },
    { id: 'verification', label: 'VERIFICATION', icon: <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> },
  ];

  if (!isOpen) {
    return (
      <div className="h-7 border-t border-[#1C2230] bg-[#0A0D14] px-3 flex items-center justify-between text-xs select-none shrink-0 font-mono">
        <div className="flex items-center gap-2">
          <button
            onClick={onToggle}
            className="flex items-center gap-1.5 px-2 py-0.5 rounded hover:bg-[#151D2C] text-neutral-300 transition-colors"
          >
            <ChevronUp className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-bold text-[11px]">ENGINEERING PANEL</span>
          </button>

          <span className="text-neutral-600">|</span>

          <span className="text-[10px] text-neutral-500">
            Sandbox Terminal & Verification Gate
          </span>
        </div>

        <div className="flex items-center gap-3 text-[10px] text-neutral-400">
          <span className="text-emerald-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            Sandbox Connected
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="h-64 sm:h-56 md:h-64 border-t border-[#1C2230] bg-[#07090E] flex flex-col shrink-0 select-none font-sans z-10">
      {/* Panel Top Bar */}
      <div className="h-8 border-b border-[#181F2E] bg-[#0A0D14] px-2 sm:px-3 flex items-center justify-between shrink-0 font-mono text-xs">
        {/* Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`flex items-center gap-1.5 px-2 sm:px-2.5 py-1 rounded transition-colors text-[10px] sm:text-[11px] font-bold whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-[#151D2C] text-cyan-300 border border-cyan-500/40'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {activeTab === 'terminal' && (
            <button
              onClick={onClearTerminal}
              className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#121824] hover:bg-[#1A2334] text-neutral-400 hover:text-neutral-200 transition-colors"
            >
              Clear
            </button>
          )}

          <button
            onClick={onToggle}
            className="p-1 rounded hover:bg-[#151D2C] text-neutral-400 hover:text-neutral-200 transition-colors"
            title="Minimize Panel"
          >
            <ChevronDown className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-hidden relative">
        {/* TAB 1: TERMINAL */}
        {activeTab === 'terminal' && (
          <div className="h-full flex flex-col bg-[#06070B] p-3 font-mono text-xs select-text">
            {/* Truthful environment banner */}
            <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#151B28] text-[10px] text-neutral-500">
              <span className="text-cyan-400 font-semibold">GODEX Virtual Execution Sandbox v0.9 (WebAssembly AST + React 19)</span>
              <span>Host: isolated-sandbox</span>
            </div>

            {/* Logs output */}
            <div className="flex-1 overflow-y-auto space-y-1">
              {terminalLogs.map((log, idx) => (
                <div
                  key={log.id ? `${log.id}-${idx}` : `log-${idx}`}
                  className={`leading-relaxed ${
                    log.type === 'command'
                      ? 'text-cyan-300 font-bold'
                      : log.type === 'stderr'
                      ? 'text-rose-400'
                      : log.type === 'test'
                      ? 'text-emerald-300'
                      : 'text-neutral-300'
                  }`}
                >
                  {log.type === 'command' ? `$ ${log.text}` : log.text}
                </div>
              ))}
            </div>

            {/* Input line */}
            <form onSubmit={handleCommandSubmit} className="flex items-center gap-2 pt-2 border-t border-[#151B28]">
              <span className="text-cyan-400 font-bold">$</span>
              <input
                type="text"
                value={terminalInput}
                onChange={e => setTerminalInput(e.target.value)}
                placeholder="Type command... (e.g. 'npm test', 'verify', 'build', 'ls', 'help')"
                className="flex-1 bg-transparent text-neutral-200 placeholder-neutral-600 outline-none text-xs font-mono"
              />
            </form>
          </div>
        )}

        {/* TAB: EXECUTION ENGINE (Phase 4 Controlled Sandbox) */}
        {activeTab === 'execution' && (
          <div className="h-full overflow-y-auto p-4 space-y-4 font-sans text-xs bg-[#06070B] select-text">
            {/* Header with Test Suite Trigger & Policy status */}
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#181F2E] pb-3">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-amber-400" />
                <span className="font-bold text-white text-sm">Controlled Execution & Sandbox Engine</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/70 text-emerald-400 border border-emerald-800/60">
                  POLICY ENFORCED
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-950/70 text-blue-400 border border-blue-800/60">
                  SECRET REDACTION ACTIVE
                </span>
              </div>

              <button
                onClick={handleRunExecutionSuite}
                disabled={isRunningSuite}
                className="flex items-center gap-1.5 px-3 py-1 rounded bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-mono text-[11px] font-bold shadow-sm transition-all"
              >
                <Play className="w-3 h-3 fill-current" />
                <span>{isRunningSuite ? 'Running 10 Test Cases...' : 'Run Phase 4 Test Suite'}</span>
              </button>
            </div>

            {/* Test Suite Run Results */}
            {testSuiteResult && (
              <div className="p-3 rounded-lg bg-[#0E131F] border border-amber-500/30 font-mono text-xs space-y-2">
                <div className="flex items-center justify-between text-amber-300 font-bold border-b border-amber-500/20 pb-1.5">
                  <span>Phase 4 Automated Quality Gate ({testSuiteResult.passedTests}/{testSuiteResult.totalTests} Passed)</span>
                  <span className="text-[10px] text-neutral-400">Duration: {testSuiteResult.durationMs}ms</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
                  {testSuiteResult.cases.map((c, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-1.5 rounded bg-[#070A10] border border-[#161D2B]">
                      {c.passed ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                      )}
                      <div className="overflow-hidden">
                        <div className="font-semibold text-neutral-200 truncate">{c.name}</div>
                        <div className="text-[10px] text-neutral-400 truncate">{c.details}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Two Column Layout: Active Network Ports & Recent Execution Evidence */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 font-mono">
              {/* Active Network Bindings / Ports */}
              <div className="p-3 rounded-lg bg-[#0C1018] border border-[#1A2230] space-y-2">
                <div className="flex items-center justify-between border-b border-[#1A2230] pb-1 text-neutral-300 font-bold text-[11px]">
                  <div className="flex items-center gap-1.5 text-cyan-400">
                    <Radio className="w-3.5 h-3.5" />
                    <span>PORT BINDINGS</span>
                  </div>
                  <span className="text-[10px] text-neutral-500">{activePorts.length} Active</span>
                </div>

                {activePorts.length === 0 ? (
                  <div className="text-neutral-500 text-[10px] italic py-2">
                    No active listening ports detected.
                  </div>
                ) : (
                  activePorts.map((p, idx) => (
                    <div key={idx} className="flex items-center justify-between p-1.5 rounded bg-[#06080E] border border-[#151D2C] text-[11px]">
                      <div>
                        <span className="text-emerald-400 font-bold">Port {p.port}</span>
                        <span className="text-neutral-500 text-[10px] block">{p.purpose}</span>
                      </div>
                      <span className="text-[10px] text-cyan-300 underline">{p.url}</span>
                    </div>
                  ))
                )}
              </div>

              {/* Recent Execution Evidence Log */}
              <div className="md:col-span-2 p-3 rounded-lg bg-[#0C1018] border border-[#1A2230] space-y-2">
                <div className="flex items-center justify-between border-b border-[#1A2230] pb-1 text-neutral-300 font-bold text-[11px]">
                  <div className="flex items-center gap-1.5 text-emerald-400">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>CONTROLLED EXECUTION HISTORY & EVIDENCE</span>
                  </div>
                  <span className="text-[10px] text-neutral-500">{recentExecutions.length} Recorded</span>
                </div>

                {recentExecutions.length === 0 ? (
                  <div className="text-neutral-500 text-[10px] italic py-2">
                    No executions recorded yet. Run a command from the terminal or test suite.
                  </div>
                ) : (
                  <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                    {recentExecutions.map((exec) => (
                      <div key={exec.id} className="p-2 rounded bg-[#06080E] border border-[#151D2C] text-[11px] space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-cyan-300 font-bold truncate max-w-[200px]">$ {exec.command}</span>
                          <span className={`text-[9px] px-1.5 py-0.2 rounded font-bold ${
                            exec.status === 'COMPLETED'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                              : exec.status === 'BLOCKED'
                              ? 'bg-rose-950 text-rose-400 border border-rose-800'
                              : 'bg-amber-950 text-amber-400 border border-amber-800'
                          }`}>
                            {exec.status} (exit {exec.exitCode})
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-[10px] text-neutral-400">
                          <span>By: {exec.evidence.requestedBy}</span>
                          <span>Duration: {exec.durationMs}ms</span>
                        </div>
                        {exec.evidence.outputSummary && (
                          <div className="text-[10px] text-neutral-300 bg-[#0A0E17] p-1 rounded font-mono truncate">
                            {exec.evidence.outputSummary}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* TAB: SELF-HEALING DEBUGGER (Phase 5 Evidence-Driven Orchestration) */}
        {activeTab === 'debugger' && (
          <div className="h-full overflow-y-auto p-4 space-y-4 font-sans text-xs bg-[#06070B] select-text">
            {/* Debugger Banner & Action Header */}
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#181F2E] pb-3">
              <div className="flex items-center gap-2">
                <Wrench className="w-4 h-4 text-rose-400" />
                <span className="font-bold text-white text-sm">Evidence-Driven Self-Healing Debugger</span>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                  debuggerSession?.state === 'RECOVERED'
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    : debuggerSession?.state === 'AWAITING_APPROVAL'
                    ? 'bg-amber-950 text-amber-300 border border-amber-600 animate-pulse'
                    : debuggerSession?.state === 'FAILED' || debuggerSession?.state === 'BLOCKED'
                    ? 'bg-rose-950 text-rose-300 border border-rose-800'
                    : 'bg-cyan-950/70 text-cyan-300 border border-cyan-800/60'
                }`}>
                  STATE: {debuggerSession?.state || 'IDLE'}
                </span>
                {debuggerSession?.attempts && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#101726] text-neutral-300 border border-[#1E293B]">
                    Attempts: {debuggerSession.attempts.length} / {debuggerSession.maxRepairAttempts || 3}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleRunDebuggerSuite}
                  disabled={isRunningDebuggerSuite}
                  className="flex items-center gap-1.5 px-3 py-1 rounded bg-rose-700 hover:bg-rose-600 disabled:opacity-50 text-white font-mono text-[11px] font-bold shadow-sm transition-all"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>{isRunningDebuggerSuite ? 'Running 12 Test Cases...' : 'Run Phase 5 Test Suite'}</span>
                </button>
              </div>
            </div>

            {/* Test Suite Run Results */}
            {debuggerSuiteResult && (
              <div className="p-3 rounded-lg bg-[#140C12] border border-rose-500/30 font-mono text-xs space-y-2">
                <div className="flex items-center justify-between text-rose-300 font-bold border-b border-rose-500/20 pb-1.5">
                  <span>Phase 5 Automated Quality Gate ({debuggerSuiteResult.passedTests}/{debuggerSuiteResult.totalTests} Passed)</span>
                  <span className="text-[10px] text-neutral-400">Duration: {debuggerSuiteResult.durationMs}ms</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
                  {debuggerSuiteResult.cases.map((c, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-1.5 rounded bg-[#0A0609] border border-[#21141D]">
                      {c.passed ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                      )}
                      <div className="overflow-hidden">
                        <div className="font-semibold text-neutral-200 truncate">{c.name}</div>
                        <div className="text-[10px] text-neutral-400 truncate">{c.details}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Live Active Session Inspector */}
            {debuggerSession ? (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 font-mono">
                {/* Column 1: Failure Diagnostic & Localization */}
                <div className="p-3 rounded-lg bg-[#0C1018] border border-[#1A2230] space-y-2.5">
                  <div className="flex items-center justify-between border-b border-[#1A2230] pb-1 text-rose-400 font-bold text-[11px]">
                    <div className="flex items-center gap-1.5">
                      <AlertCircle className="w-3.5 h-3.5" />
                      <span>FAILURE DIAGNOSTIC</span>
                    </div>
                    <span className="text-[10px] text-neutral-500">Exit {debuggerSession.currentFailure?.exitCode ?? 0}</span>
                  </div>

                  <div className="space-y-1.5 text-[11px]">
                    <div>
                      <span className="text-neutral-500 text-[10px] block">TYPE</span>
                      <span className="text-rose-300 font-bold">{debuggerSession.currentFailure?.type || 'UNKNOWN'}</span>
                    </div>

                    <div>
                      <span className="text-neutral-500 text-[10px] block">LOCATION</span>
                      <span className="text-neutral-200">
                        {debuggerSession.currentFailure?.location.file}:{debuggerSession.currentFailure?.location.line ?? '?'}:{debuggerSession.currentFailure?.location.column ?? '?'}
                      </span>
                    </div>

                    {debuggerSession.currentFailure?.symbol && (
                      <div>
                        <span className="text-neutral-500 text-[10px] block">SYMBOL</span>
                        <span className="text-cyan-300 font-bold">{debuggerSession.currentFailure.symbol}</span>
                      </div>
                    )}

                    <div>
                      <span className="text-neutral-500 text-[10px] block">DIAGNOSTIC MESSAGE</span>
                      <div className="p-1.5 rounded bg-[#06080E] text-rose-300 text-[10px] border border-[#151D2C] max-h-20 overflow-y-auto">
                        {debuggerSession.currentFailure?.message}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Column 2: Root Cause & Epistemic Facts */}
                <div className="p-3 rounded-lg bg-[#0C1018] border border-[#1A2230] space-y-2.5">
                  <div className="flex items-center justify-between border-b border-[#1A2230] pb-1 text-amber-400 font-bold text-[11px]">
                    <div className="flex items-center gap-1.5">
                      <Search className="w-3.5 h-3.5" />
                      <span>ROOT CAUSE & EPISTEMIC</span>
                    </div>
                    {debuggerSession.rootCause?.isSecuritySensitive && (
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-rose-950 text-rose-300 border border-rose-800">
                        SECURITY CRITICAL
                      </span>
                    )}
                  </div>

                  <div className="space-y-2 text-[11px]">
                    <div>
                      <span className="text-neutral-500 text-[10px] block">PRIMARY HYPOTHESIS</span>
                      <span className="text-amber-200">
                        {debuggerSession.rootCause?.primaryHypothesis.cause || 'Analyzing root cause...'}
                      </span>
                    </div>

                    {debuggerSession.rootCause?.epistemic && (
                      <div className="space-y-1 text-[10px]">
                        <div className="p-1 rounded bg-[#06080E] border border-[#151D2C]">
                          <span className="text-emerald-400 font-bold block">KNOWN FACTS:</span>
                          <span className="text-neutral-300">{debuggerSession.rootCause.epistemic.known.join('; ') || 'None'}</span>
                        </div>

                        <div className="p-1 rounded bg-[#06080E] border border-[#151D2C]">
                          <span className="text-amber-400 font-bold block">LIKELY INFERENCES:</span>
                          <span className="text-neutral-300">{debuggerSession.rootCause.epistemic.likely.join('; ') || 'None'}</span>
                        </div>

                        <div className="p-1 rounded bg-[#06080E] border border-[#151D2C]">
                          <span className="text-neutral-400 font-bold block">UNKNOWN FACTORS:</span>
                          <span className="text-neutral-500">{debuggerSession.rootCause.epistemic.unknown.join('; ') || 'None'}</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Column 3: Repair Plan & Verification Outcome */}
                <div className="p-3 rounded-lg bg-[#0C1018] border border-[#1A2230] space-y-2.5">
                  <div className="flex items-center justify-between border-b border-[#1A2230] pb-1 text-cyan-400 font-bold text-[11px]">
                    <div className="flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>REPAIR PLAN & OUTCOME</span>
                    </div>
                    <span className="text-[10px] text-neutral-400">
                      {debuggerSession.currentPlan?.approvalRequired ? 'Review Required' : 'Auto-executable'}
                    </span>
                  </div>

                  <div className="space-y-2 text-[11px]">
                    <div>
                      <span className="text-neutral-500 text-[10px] block">PROPOSED FIX</span>
                      <span className="text-cyan-200">
                        {debuggerSession.currentPlan?.proposedFix || 'No pending repair plan'}
                      </span>
                    </div>

                    <div>
                      <span className="text-neutral-500 text-[10px] block">STATUS MESSAGE</span>
                      <span className="text-neutral-300 text-[10px]">
                        {debuggerSession.statusMessage}
                      </span>
                    </div>

                    {debuggerSession.attempts.length > 0 && (
                      <div className="p-2 rounded bg-[#06080E] border border-[#151D2C] space-y-1 text-[10px]">
                        <span className="text-neutral-400 font-bold block">LAST ATTEMPT OUTCOME:</span>
                        {debuggerSession.attempts.map((att, i) => (
                          <div key={i} className="flex items-center justify-between">
                            <span className="text-neutral-300">Attempt {att.attemptNumber}: {att.comparison?.outcome || att.status}</span>
                            <span className={`font-bold ${
                              att.status === 'PASSED' ? 'text-emerald-400' : att.status === 'REGRESSED' ? 'text-rose-400' : 'text-amber-400'
                            }`}>
                              {att.status} ({att.durationMs}ms)
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-4 rounded-lg bg-[#0C1018] border border-[#1A2230] font-mono text-xs text-neutral-400 text-center space-y-2">
                <div>No active self-healing session. Debugger is in IDLE observing mode.</div>
                <div className="text-[10px] text-neutral-500">
                  Run a failing command in the Terminal or trigger the Phase 5 test suite above to initiate diagnosis.
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: TESTS */}
        {activeTab === 'tests' && (
          <div className="h-full overflow-y-auto p-4 space-y-4 font-sans text-xs bg-[#06070B] select-text">
            {/* Top Suite Controls */}
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#181F2E] pb-3">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span className="font-bold text-white text-sm">Automated Universal Verification Suites</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
                  P2.2 READY
                </span>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={handleRunP36Suite}
                  disabled={isRunningP36Suite}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-gradient-to-r from-violet-600 via-indigo-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 disabled:opacity-50 text-white font-mono text-[11px] font-bold shadow-md transition-all ring-1 ring-white/20"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>{isRunningP36Suite ? 'Running P3.6 Suite...' : 'Run P3.6 Real Creative Validation (26 Tests)'}</span>
                </button>

                <button
                  onClick={handleRunP31Suite}
                  disabled={isRunningP31Suite}
                  className="flex items-center gap-1.5 px-3 py-1 rounded bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 disabled:opacity-50 text-white font-mono text-[11px] font-bold shadow-sm transition-all"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>{isRunningP31Suite ? 'Running P3.1 Suite...' : 'Run P3.1 Execution & Proof Core (28 Tests)'}</span>
                </button>

                <button
                  onClick={handleRunP30Suite}
                  disabled={isRunningP30Suite}
                  className="flex items-center gap-1.5 px-3 py-1 rounded bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:opacity-50 text-white font-mono text-[11px] font-bold shadow-sm transition-all"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>{isRunningP30Suite ? 'Running P3.0 Suite...' : 'Run P3.0 Autonomous Core (24 Tests)'}</span>
                </button>

                <button
                  onClick={handleRunP28Suite}
                  disabled={isRunningP28Suite}
                  className="flex items-center gap-1.5 px-3 py-1 rounded bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-mono text-[11px] font-bold shadow-sm transition-all"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>{isRunningP28Suite ? 'Running P2.8 Execution Suite...' : 'Run P2.8 Execution (24 Tests)'}</span>
                </button>

                <button
                  onClick={handleRunP27Suite}
                  disabled={isRunningP27Suite}
                  className="flex items-center gap-1.5 px-3 py-1 rounded bg-teal-600 hover:bg-teal-500 disabled:opacity-50 text-white font-mono text-[11px] font-bold shadow-sm transition-all"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>{isRunningP27Suite ? 'Running P2.7 Suite...' : 'Run P2.7 (24 Tests)'}</span>
                </button>

                <button
                  onClick={handleRunP26Suite}
                  disabled={isRunningP26Suite}
                  className="flex items-center gap-1.5 px-3 py-1 rounded bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white font-mono text-[11px] font-bold shadow-sm transition-all"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>{isRunningP26Suite ? 'Running P2.6 Suite...' : 'Run P2.6 Reality Gate (20 Tests)'}</span>
                </button>

                <button
                  onClick={handleRunP25Suite}
                  disabled={isRunningP25Suite}
                  className="flex items-center gap-1.5 px-3 py-1 rounded bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-mono text-[11px] font-bold shadow-sm transition-all"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>{isRunningP25Suite ? 'Running P2.5 Suite...' : 'Run P2.5 Media (20 Tests)'}</span>
                </button>

                <button
                  onClick={handleRunP24Suite}
                  disabled={isRunningP24Suite}
                  className="flex items-center gap-1.5 px-3 py-1 rounded bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-mono text-[11px] font-bold shadow-sm transition-all"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>{isRunningP24Suite ? 'Running P2.4 Suite...' : 'Run P2.4 Creative Suite (20 Tests)'}</span>
                </button>

                <button
                  onClick={handleRunP23Suite}
                  disabled={isRunningP23Suite}
                  className="flex items-center gap-1.5 px-3 py-1 rounded bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-mono text-[11px] font-bold shadow-sm transition-all"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>{isRunningP23Suite ? 'Running P2.3 Suite...' : 'Run P2.3 (20 Tests)'}</span>
                </button>

                <button
                  onClick={handleRunP22Suite}
                  disabled={isRunningP22Suite}
                  className="flex items-center gap-1.5 px-3 py-1 rounded bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-mono text-[11px] font-bold shadow-sm transition-all"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>{isRunningP22Suite ? 'Running P2.2...' : 'Run P2.2'}</span>
                </button>

                <button
                  onClick={handleRunP21Suite}
                  disabled={isRunningP21Suite}
                  className="flex items-center gap-1.5 px-3 py-1 rounded bg-cyan-700 hover:bg-cyan-600 disabled:opacity-50 text-white font-mono text-[11px] font-bold shadow-sm transition-all"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>{isRunningP21Suite ? 'Running P2.1...' : 'Run P2.1'}</span>
                </button>
              </div>
            </div>

            {/* P3.6 Test Suite Results */}
            {p36SuiteResult && (
              <div className="p-4 rounded-xl bg-[#0F0D1E] border border-violet-500/40 font-mono text-xs space-y-3 shadow-xl">
                <div className="flex items-center justify-between text-violet-300 font-bold border-b border-violet-500/30 pb-2.5">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-violet-400" />
                    <span>GODEX P3.6 Real Creative Validation & Pipeline ({p36SuiteResult.passedTests}/{p36SuiteResult.totalTests} Passed)</span>
                  </div>
                  <div className="flex items-center gap-3 text-[10px] text-neutral-400">
                    <span>Duration: {p36SuiteResult.durationMs}ms</span>
                    <span>Pass Rate: {((p36SuiteResult.passedTests / p36SuiteResult.totalTests) * 100).toFixed(0)}%</span>
                    <span className={`px-2.5 py-0.5 rounded-full font-bold ${p36SuiteResult.allPassed ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300 border border-rose-800'}`}>
                      {p36SuiteResult.allPassed ? '100% PRODUCTION READY' : 'TESTS FAILED'}
                    </span>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
                  {p36SuiteResult.results.map((c, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-2 rounded-lg bg-[#080612] border border-[#1E1738]">
                      {c.passed ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                      )}
                      <div className="overflow-hidden w-full">
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-neutral-200 truncate">{c.id}: {c.name}</span>
                          <span className="text-[9px] text-violet-400 font-mono shrink-0 ml-1">{c.durationMs}ms</span>
                        </div>
                        <div className="text-[10px] text-neutral-400 truncate">{c.details}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* P3.1 Test Suite Results */}
            {p31SuiteResult && (
              <div className="p-3.5 rounded-xl bg-[#071915] border border-emerald-500/40 font-mono text-xs space-y-2.5 shadow-lg">
                <div className="flex items-center justify-between text-emerald-300 font-bold border-b border-emerald-500/30 pb-2">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>P3.1 Real-World Project Execution & Proof Suite ({p31SuiteResult.passedTests}/{p31SuiteResult.totalTests} Passed)</span>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-neutral-400">
                    <span>Success Rate: {((p31SuiteResult.passedTests / p31SuiteResult.totalTests) * 100).toFixed(0)}%</span>
                    <span className={`px-2 py-0.5 rounded font-bold ${p31SuiteResult.passedTests === p31SuiteResult.totalTests ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300 border border-rose-800'}`}>
                      {p31SuiteResult.passedTests === p31SuiteResult.totalTests ? '100% VERIFIED' : 'TESTS FAILED'}
                    </span>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
                  {p31SuiteResult.results.map((c, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-2 rounded-lg bg-[#030E0B] border border-[#0D2E24]">
                      {c.passed ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                      )}
                      <div className="overflow-hidden">
                        <div className="font-semibold text-neutral-200 truncate">{c.id}: {c.name}</div>
                        <div className="text-[10px] text-neutral-400 truncate">{c.evidence}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* P3.0 Test Suite Results */}
            {p30SuiteResult && (
              <div className="p-3.5 rounded-xl bg-[#091522] border border-cyan-500/40 font-mono text-xs space-y-2.5 shadow-lg">
                <div className="flex items-center justify-between text-cyan-300 font-bold border-b border-cyan-500/30 pb-2">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-cyan-400" />
                    <span>P3.0 Autonomous Software Engineering Core ({p30SuiteResult.passedTests}/{p30SuiteResult.totalTests} Passed)</span>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-neutral-400">
                    <span>Success Rate: {((p30SuiteResult.passedTests / p30SuiteResult.totalTests) * 100).toFixed(0)}%</span>
                    <span className={`px-2 py-0.5 rounded font-bold ${p30SuiteResult.passedTests === p30SuiteResult.totalTests ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300 border border-rose-800'}`}>
                      {p30SuiteResult.passedTests === p30SuiteResult.totalTests ? '100% VERIFIED' : 'TESTS FAILED'}
                    </span>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
                  {p30SuiteResult.results.map((c, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-2 rounded-lg bg-[#040A12] border border-[#13283E]">
                      {c.passed ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                      )}
                      <div className="overflow-hidden">
                        <div className="font-semibold text-neutral-200 truncate">{c.id}: {c.name}</div>
                        <div className="text-[10px] text-neutral-400 truncate">{c.evidence}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* P2.8 Test Suite Results */}
            {p28SuiteResult && (
              <div className="p-3.5 rounded-xl bg-[#0A111C] border border-blue-500/30 font-mono text-xs space-y-2.5">
                <div className="flex items-center justify-between text-blue-300 font-bold border-b border-blue-500/20 pb-2">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-blue-400" />
                    <span>P2.8 Universal AI Application Execution & Real Engine Integration ({p28SuiteResult.passedTests}/{p28SuiteResult.totalTests} Passed)</span>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-neutral-400">
                    <span>Success Rate: {p28SuiteResult.passRate.toFixed(0)}%</span>
                    <span className={`px-2 py-0.5 rounded font-bold ${p28SuiteResult.passedTests === p28SuiteResult.totalTests ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300 border border-rose-800'}`}>
                      {p28SuiteResult.passedTests === p28SuiteResult.totalTests ? '100% VERIFIED' : 'TESTS FAILED'}
                    </span>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
                  {p28SuiteResult.results.map((c, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-2 rounded-lg bg-[#050910] border border-[#14223A]">
                      {c.passed ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                      )}
                      <div className="overflow-hidden">
                        <div className="font-semibold text-neutral-200 truncate">{c.id}: {c.name} ({c.durationMs}ms)</div>
                        <div className="text-[10px] text-neutral-400 truncate">{c.evidence}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* P2.7 Test Suite Results */}
            {p27SuiteResult && (
              <div className="p-3.5 rounded-xl bg-[#0A1816] border border-teal-500/30 font-mono text-xs space-y-2.5">
                <div className="flex items-center justify-between text-teal-300 font-bold border-b border-teal-500/20 pb-2">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-teal-400" />
                    <span>P2.7 Free-First Local Creative & Media Orchestration ({p27SuiteResult.passedTests}/{p27SuiteResult.totalTests} Passed)</span>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-neutral-400">
                    <span>Success Rate: {p27SuiteResult.passRate.toFixed(0)}%</span>
                    <span className={`px-2 py-0.5 rounded font-bold ${p27SuiteResult.passedTests === p27SuiteResult.totalTests ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300 border border-rose-800'}`}>
                      {p27SuiteResult.passedTests === p27SuiteResult.totalTests ? '100% VERIFIED' : 'TESTS FAILED'}
                    </span>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
                  {p27SuiteResult.results.map((c, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-2 rounded-lg bg-[#05100E] border border-[#14302C]">
                      {c.passed ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                      )}
                      <div className="overflow-hidden">
                        <div className="font-semibold text-neutral-200 truncate">{c.id}: {c.name} ({c.durationMs}ms)</div>
                        <div className="text-[10px] text-neutral-400 truncate">{c.evidence}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* P2.6 Test Suite Results */}
            {p26SuiteResult && (
              <div className="p-3.5 rounded-xl bg-[#1A0C10] border border-rose-500/30 font-mono text-xs space-y-2.5">
                <div className="flex items-center justify-between text-rose-300 font-bold border-b border-rose-500/20 pb-2">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-rose-400" />
                    <span>P2.6 AI Creative Engine Reality & Regression Gate ({p26SuiteResult.passedTests}/{p26SuiteResult.totalTests} Passed)</span>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-neutral-400">
                    <span>Success Rate: {p26SuiteResult.successRate.toFixed(0)}%</span>
                    <span className={`px-2 py-0.5 rounded font-bold ${p26SuiteResult.allPassed ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300 border border-rose-800'}`}>
                      {p26SuiteResult.allPassed ? '100% VERIFIED' : 'TESTS FAILED'}
                    </span>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
                  {p26SuiteResult.results.map((c, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-2 rounded-lg bg-[#0E0608] border border-[#2A1014]">
                      {c.passed ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                      )}
                      <div className="overflow-hidden">
                        <div className="font-semibold text-neutral-200 truncate">{c.id}: {c.name} ({c.durationMs}ms)</div>
                        <div className="text-[10px] text-neutral-400 truncate">{c.evidence}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* P2.5 Test Suite Results */}
            {p25SuiteResult && (
              <div className="p-3.5 rounded-xl bg-[#141008] border border-amber-500/30 font-mono text-xs space-y-2.5">
                <div className="flex items-center justify-between text-amber-300 font-bold border-b border-amber-500/20 pb-2">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span>P2.5 Real Creative Media Runtime Suite ({p25SuiteResult.passedTests}/{p25SuiteResult.totalTests} Passed)</span>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-neutral-400">
                    <span>Success Rate: {p25SuiteResult.successRate.toFixed(0)}%</span>
                    <span className={`px-2 py-0.5 rounded font-bold ${p25SuiteResult.allPassed ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300 border border-rose-800'}`}>
                      {p25SuiteResult.allPassed ? '100% VERIFIED' : 'TESTS FAILED'}
                    </span>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
                  {p25SuiteResult.results.map((c, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-2 rounded-lg bg-[#0C0A04] border border-[#2A200E]">
                      {c.passed ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                      )}
                      <div className="overflow-hidden">
                        <div className="font-semibold text-neutral-200 truncate">{c.id}: {c.name} ({c.durationMs}ms)</div>
                        <div className="text-[10px] text-neutral-400 truncate">{c.evidence}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* P2.4 Test Suite Results */}
            {p24SuiteResult && (
              <div className="p-3.5 rounded-xl bg-[#120D1A] border border-purple-500/30 font-mono text-xs space-y-2.5">
                <div className="flex items-center justify-between text-purple-300 font-bold border-b border-purple-500/20 pb-2">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-purple-400" />
                    <span>P2.4 Creative & Media Application Builder Suite ({p24SuiteResult.passedTests}/{p24SuiteResult.totalTests} Passed)</span>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-neutral-400">
                    <span>Success Rate: {p24SuiteResult.successRate.toFixed(0)}%</span>
                    <span className={`px-2 py-0.5 rounded font-bold ${p24SuiteResult.allPassed ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300 border border-rose-800'}`}>
                      {p24SuiteResult.allPassed ? '100% VERIFIED' : 'TESTS FAILED'}
                    </span>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
                  {p24SuiteResult.results.map((c, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-2 rounded-lg bg-[#0B0711] border border-[#231533]">
                      {c.passed ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                      )}
                      <div className="overflow-hidden">
                        <div className="font-semibold text-neutral-200 truncate">{c.id}: {c.name} ({c.durationMs}ms)</div>
                        <div className="text-[10px] text-neutral-400 truncate">{c.evidence}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* P2.3 Test Suite Results */}
            {p23SuiteResult && (
              <div className="p-3.5 rounded-xl bg-[#091410] border border-emerald-500/30 font-mono text-xs space-y-2.5">
                <div className="flex items-center justify-between text-emerald-300 font-bold border-b border-emerald-500/20 pb-2">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>P2.3 Universal Runtime & Execution Suite ({p23SuiteResult.passedTests}/{p23SuiteResult.totalTests} Passed)</span>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-neutral-400">
                    <span>Success Rate: {p23SuiteResult.successRate.toFixed(0)}%</span>
                    <span className={`px-2 py-0.5 rounded font-bold ${p23SuiteResult.allPassed ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300 border border-rose-800'}`}>
                      {p23SuiteResult.allPassed ? '100% VERIFIED' : 'TESTS FAILED'}
                    </span>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
                  {p23SuiteResult.results.map((c, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-2 rounded-lg bg-[#050C0A] border border-[#0F261E]">
                      {c.passed ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                      )}
                      <div className="overflow-hidden">
                        <div className="font-semibold text-neutral-200 truncate">{c.id}: {c.name} ({c.durationMs}ms)</div>
                        <div className="text-[10px] text-neutral-400 truncate">{c.evidence}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* P2.2 Test Suite Results */}
            {p22SuiteResult && (
              <div className="p-3.5 rounded-xl bg-[#0D101C] border border-indigo-500/30 font-mono text-xs space-y-2.5">
                <div className="flex items-center justify-between text-indigo-300 font-bold border-b border-indigo-500/20 pb-2">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-indigo-400" />
                    <span>P2.2 General-Purpose Synthesis Suite ({p22SuiteResult.passedTests}/{p22SuiteResult.totalTests} Passed)</span>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-neutral-400">
                    <span>Duration: {p22SuiteResult.durationMs}ms</span>
                    <span className={`px-2 py-0.5 rounded font-bold ${p22SuiteResult.passed ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300 border border-rose-800'}`}>
                      {p22SuiteResult.passed ? '100% VERIFIED' : 'TESTS FAILED'}
                    </span>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
                  {p22SuiteResult.cases.map((c, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-2 rounded-lg bg-[#070912] border border-[#171D30]">
                      {c.passed ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                      )}
                      <div className="overflow-hidden">
                        <div className="font-semibold text-neutral-200 truncate">{c.name}</div>
                        <div className="text-[10px] text-neutral-400 truncate">{c.details}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* P2.1 Test Suite Results */}
            {p21SuiteResult && (
              <div className="p-3.5 rounded-xl bg-[#091118] border border-cyan-500/30 font-mono text-xs space-y-2.5">
                <div className="flex items-center justify-between text-cyan-300 font-bold border-b border-cyan-500/20 pb-2">
                  <span>P2.1 Real App Generation Suite ({p21SuiteResult.passedTests}/{p21SuiteResult.totalTests} Passed)</span>
                  <div className="flex items-center gap-2 text-[10px] text-neutral-400">
                    <span>Duration: {p21SuiteResult.durationMs}ms</span>
                    <span className={`px-2 py-0.5 rounded font-bold ${p21SuiteResult.passed ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300 border border-rose-800'}`}>
                      {p21SuiteResult.passed ? '100% VERIFIED' : 'TESTS FAILED'}
                    </span>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
                  {p21SuiteResult.cases.map((c, idx) => (
                    <div key={idx} className="flex items-start gap-2 p-2 rounded-lg bg-[#050B10] border border-[#11202E]">
                      {c.passed ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0 mt-0.5" />
                      )}
                      <div className="overflow-hidden">
                        <div className="font-semibold text-neutral-200 truncate">{c.name}</div>
                        <div className="text-[10px] text-neutral-400 truncate">{c.details}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Baseline Suites */}
            <div className="space-y-2 font-mono text-xs">
              <div className="p-2.5 rounded-lg bg-[#0C1018] border border-[#1A2230] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span className="text-neutral-200 font-bold">suite/ast-syntax.test.ts</span>
                </div>
                <span className="text-emerald-400 text-[11px]">5 passed (12ms)</span>
              </div>

              <div className="p-2.5 rounded-lg bg-[#0C1018] border border-[#1A2230] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span className="text-neutral-200 font-bold">suite/component-mounting.test.ts</span>
                </div>
                <span className="text-emerald-400 text-[11px]">8 passed (24ms)</span>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: SYSTEM LOGS */}
        {activeTab === 'logs' && (
          <div className="h-full overflow-y-auto p-3 space-y-1 font-mono text-[11px] bg-[#06070B]">
            {activityLogs.map((log) => (
              <div key={log.id} className="text-neutral-300 flex items-center gap-2">
                <span className="text-neutral-600">[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                <span className="text-purple-400 font-bold">[{log.role}]</span>
                <span className="text-neutral-200">{log.action}</span>
                {log.details && <span className="text-neutral-500 truncate">- {log.details}</span>}
              </div>
            ))}
          </div>
        )}

        {/* TAB 4: DIFF INSPECTOR */}
        {activeTab === 'diff' && (
          <div className="h-full overflow-y-auto p-4 space-y-3 font-sans text-xs bg-[#06070B]">
            <div className="font-mono text-xs text-neutral-300 font-bold border-b border-[#181F2E] pb-2">
              Workspace Modification Diffs
            </div>
            <div className="p-3 rounded-lg bg-[#0C1018] border border-[#1A2230] font-mono text-xs text-neutral-400">
              Files are tracked authoritatively. Click any activity log item or checkpoint to view exact additions and deletions.
            </div>
          </div>
        )}

        {/* TAB 5: VERIFICATION */}
        {activeTab === 'verification' && (
          <div className="h-full overflow-y-auto p-4 space-y-3 font-sans text-xs bg-[#06070B]">
            <div className="flex items-center justify-between border-b border-[#181F2E] pb-2">
              <div className="flex items-center gap-2">
                <span className="font-bold text-white">5-Pillar Verification Status</span>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                  verificationReport?.passed
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    : 'bg-neutral-900 text-neutral-400 border border-neutral-700'
                }`}>
                  {verificationReport?.passed ? '5/5 VERIFIED' : (verificationReport ? 'FAILED' : 'READY')}
                </span>
              </div>

              <button
                onClick={onRunVerification}
                className="px-2.5 py-1 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-mono text-[10px] font-semibold"
              >
                Trigger Matrix Check
              </button>
            </div>

            {verificationReport?.checks ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {verificationReport.checks.map((chk) => (
                  <div
                    key={chk.id}
                    className="p-2.5 rounded-lg bg-[#0C1018] border border-[#1A2230] flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2">
                      {chk.status === 'passed' ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                      )}
                      <span className="font-semibold text-neutral-200">{chk.name}</span>
                    </div>
                    <span className="text-[10px] font-mono text-neutral-400">{chk.message}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-neutral-500 font-mono text-xs">
                Run the verification matrix to validate code AST, build transpilation, DOM root, and runtime safety.
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
