import React, { useState, useEffect } from 'react';
import { X, Star, Trash2, Loader2, MessageSquare } from 'lucide-react';
import { Message } from '../../types';
import { getStarredMessages, toggleStarMessage } from '../../services/chatService';
import { useAuth } from '../../contexts/AuthContext';

type StarredMessagesModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

export const StarredMessagesModal: React.FC<StarredMessagesModalProps> = ({ isOpen, onClose }) => {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);

  const currentUserId = user?.id || '';

  const loadStarred = async () => {
    if (!currentUserId) return;
    setLoading(true);
    try {
      const data = await getStarredMessages(currentUserId);
      setMessages(data);
    } catch (err) {
      console.error('Failed to load starred messages:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadStarred();
    }
  }, [isOpen, currentUserId]);

  if (!isOpen) return null;

  const handleUnstar = async (msgId: string) => {
    await toggleStarMessage(msgId, currentUserId, true);
    setMessages((prev) => prev.filter((m) => m.id !== msgId));
  };

  return (
    <div
      id="starred-messages-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4 animate-in fade-in"
    >
      <div
        id="starred-messages-dialog"
        className="w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh] text-white"
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-950/40">
          <div className="flex items-center space-x-2">
            <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
            <h3 className="text-base font-semibold">Starred Messages</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {loading ? (
            <div className="py-16 flex flex-col items-center justify-center space-y-2 text-neutral-500">
              <Loader2 className="w-6 h-6 animate-spin text-emerald-500" />
              <span className="text-xs">Loading saved messages...</span>
            </div>
          ) : messages.length === 0 ? (
            <div className="py-16 text-center text-xs text-neutral-500 flex flex-col items-center space-y-2">
              <Star className="w-8 h-8 text-neutral-600" />
              <span>No starred messages yet. Star important messages in any chat to save them here.</span>
            </div>
          ) : (
            messages.map((msg) => (
              <div
                key={msg.id}
                className="p-3.5 rounded-2xl bg-neutral-950/60 border border-neutral-800 flex items-start justify-between space-x-3 group"
              >
                <div className="min-w-0 flex-1">
                  <p className="text-xs text-neutral-200 whitespace-pre-wrap break-words">{msg.content}</p>
                  <p className="text-[10px] text-neutral-500 mt-1">
                    {new Date(msg.created_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                  </p>
                </div>

                <button
                  onClick={() => handleUnstar(msg.id)}
                  className="p-1.5 text-neutral-500 hover:text-amber-400 rounded-lg hover:bg-neutral-800 transition-colors"
                  title="Unstar"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
