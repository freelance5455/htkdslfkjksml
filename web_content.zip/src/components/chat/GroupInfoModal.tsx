import React, { useState, useEffect } from 'react';
import { X, Users, UserPlus, LogOut, Shield, Trash2, Check, Loader2 } from 'lucide-react';
import { ConversationWithDetails, Profile } from '../../types';
import { getFriends } from '../../services/friendService';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';

type GroupInfoModalProps = {
  isOpen: boolean;
  conversation: ConversationWithDetails;
  onClose: () => void;
  onUpdated: () => void;
};

export const GroupInfoModal: React.FC<GroupInfoModalProps> = ({
  isOpen,
  conversation,
  onClose,
  onUpdated,
}) => {
  const { user } = useAuth();
  const [friends, setFriends] = useState<Profile[]>([]);
  const [showAddMember, setShowAddMember] = useState(false);
  const [selectedFriendId, setSelectedFriendId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!isOpen || !user) return;
    getFriends(user.id).then(setFriends).catch(console.error);
  }, [isOpen, user]);

  if (!isOpen) return null;

  const members = conversation.members || [];
  const currentUserId = user?.id || '';

  // Non-member friends eligible to be added
  const existingMemberIds = new Set(members.map((m) => m.id));
  const eligibleFriends = friends.filter((f) => !existingMemberIds.has(f.id));

  const handleAddMember = async () => {
    if (!selectedFriendId) return;
    setLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.access_token) {
        await fetch(`/api/chat/group/${conversation.id}/members`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({ action: 'add', userId: selectedFriendId }),
        });
      }

      // Also insert in DB
      await supabase.from('conversation_members').insert({
        conversation_id: conversation.id,
        user_id: selectedFriendId,
      });

      setShowAddMember(false);
      setSelectedFriendId(null);
      onUpdated();
    } catch (err) {
      console.error('Failed to add member:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleLeaveGroup = async () => {
    if (!confirm('Are you sure you want to leave this group?')) return;
    setLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.access_token) {
        await fetch(`/api/chat/group/${conversation.id}/members`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({ action: 'leave', userId: currentUserId }),
        });
      }

      await supabase
        .from('conversation_members')
        .delete()
        .eq('conversation_id', conversation.id)
        .eq('user_id', currentUserId);

      onClose();
      onUpdated();
    } catch (err) {
      console.error('Failed to leave group:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white truncate max-w-[200px]">
                {conversation.name || 'Group Info'}
              </h3>
              <p className="text-[11px] text-neutral-400">
                {members.length} {members.length === 1 ? 'participant' : 'participants'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-xl hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4 flex-1 overflow-y-auto">
          {/* Actions Bar */}
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setShowAddMember(!showAddMember)}
              className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center justify-center space-x-1.5 transition-colors"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Add Member</span>
            </button>
            <button
              onClick={handleLeaveGroup}
              disabled={loading}
              className="py-2 px-3 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Leave</span>
            </button>
          </div>

          {/* Add member inline dropdown */}
          {showAddMember && (
            <div className="p-3 bg-neutral-950 border border-neutral-800 rounded-2xl space-y-2 animate-in slide-in-from-top-2">
              <h4 className="text-xs font-semibold text-neutral-300">Select Friend to Add</h4>
              {eligibleFriends.length === 0 ? (
                <p className="text-xs text-neutral-500 py-2">No other friends to add.</p>
              ) : (
                <div className="max-h-40 overflow-y-auto space-y-1">
                  {eligibleFriends.map((f) => (
                    <div
                      key={f.id}
                      onClick={() => setSelectedFriendId(f.id)}
                      className={`p-2 rounded-xl flex items-center justify-between cursor-pointer transition-colors ${
                        selectedFriendId === f.id
                          ? 'bg-emerald-600 text-white'
                          : 'hover:bg-neutral-800 text-neutral-300'
                      }`}
                    >
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 rounded-full bg-neutral-700 overflow-hidden flex items-center justify-center text-[10px] font-bold">
                          {f.avatar_url ? (
                            <img src={f.avatar_url} alt="" className="w-full h-full object-cover" />
                          ) : (
                            f.display_name.charAt(0).toUpperCase()
                          )}
                        </div>
                        <span className="text-xs font-medium">{f.display_name}</span>
                      </div>
                      {selectedFriendId === f.id && <Check className="w-3.5 h-3.5 text-white" />}
                    </div>
                  ))}
                </div>
              )}

              {eligibleFriends.length > 0 && (
                <button
                  onClick={handleAddMember}
                  disabled={!selectedFriendId || loading}
                  className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white rounded-lg text-xs font-semibold transition-colors mt-2"
                >
                  {loading ? 'Adding...' : 'Confirm Add'}
                </button>
              )}
            </div>
          )}

          {/* Participants List */}
          <div>
            <h4 className="text-xs font-bold text-neutral-400 uppercase tracking-wider px-1 mb-2">
              Participants ({members.length})
            </h4>
            <div className="space-y-1.5 divide-y divide-neutral-800/40">
              {members.map((member) => {
                const isMe = member.id === currentUserId;
                return (
                  <div
                    key={member.id}
                    className="pt-2 first:pt-0 flex items-center justify-between p-2 rounded-xl hover:bg-neutral-800/40"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-9 h-9 rounded-full bg-neutral-800 border border-neutral-700 overflow-hidden flex items-center justify-center text-xs font-bold text-neutral-300">
                        {member.avatar_url ? (
                          <img
                            src={member.avatar_url}
                            alt=""
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          member.display_name?.charAt(0).toUpperCase() || 'U'
                        )}
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-white flex items-center space-x-1.5">
                          <span>{member.display_name}</span>
                          {isMe && (
                            <span className="px-1.5 py-0.5 bg-neutral-800 text-[9px] text-neutral-400 rounded-md font-mono">
                              You
                            </span>
                          )}
                        </p>
                        <p className="text-[10px] text-neutral-400">@{member.username}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
