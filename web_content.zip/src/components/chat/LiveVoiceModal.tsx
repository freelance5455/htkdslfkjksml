import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, X, Sparkles, Volume2, ShieldCheck, Zap } from 'lucide-react';

interface LiveVoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVoiceMessage: (text: string) => Promise<string | undefined>;
  activeTaskDesc?: string;
}

export const LiveVoiceModal: React.FC<LiveVoiceModalProps> = ({
  isOpen,
  onClose,
  onVoiceMessage,
  activeTaskDesc,
}) => {
  const [status, setStatus] = useState<'idle' | 'listening' | 'thinking' | 'speaking'>('idle');
  const [transcript, setTranscript] = useState('');
  const [lastAiResponse, setLastAiResponse] = useState('');
  const [isMicEnabled, setIsMicEnabled] = useState(true);

  const recognitionRef = useRef<any>(null);
  const isComponentMounted = useRef(true);

  // Initialize Speech Recognition
  useEffect(() => {
    isComponentMounted.current = true;
    if (!isOpen) {
      cleanupSpeech();
      return;
    }

    startListening();

    return () => {
      isComponentMounted.current = false;
      cleanupSpeech();
    };
  }, [isOpen]);

  const cleanupSpeech = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.onend = null;
        recognitionRef.current.abort();
      } catch {}
      recognitionRef.current = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  };

  const startListening = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('Speech Recognition is not supported in this browser. Please use Google Chrome or Edge.');
      return;
    }

    cleanupSpeech();

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'en-US';
      recognition.interimResults = true;
      recognition.continuous = false;

      recognition.onstart = () => {
        if (!isComponentMounted.current) return;
        setStatus('listening');
      };

      recognition.onresult = (event: any) => {
        if (!isComponentMounted.current) return;
        let interim = '';
        let final = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }

        const currentText = final || interim;
        setTranscript(currentText);

        if (final && final.trim().length > 1) {
          handleUserUtterance(final.trim());
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        if (event.error !== 'no-speech' && isComponentMounted.current) {
          // Restart after short delay
          setTimeout(() => {
            if (isComponentMounted.current && isMicEnabled && status !== 'speaking') {
              startListening();
            }
          }, 1000);
        }
      };

      recognition.onend = () => {
        if (isComponentMounted.current && isMicEnabled && status === 'listening') {
          // If stopped without result, restart listening
          try {
            recognition.start();
          } catch {}
        }
      };

      recognition.start();
      recognitionRef.current = recognition;
    } catch (e) {
      console.error('Failed to start speech recognition:', e);
    }
  };

  const handleUserUtterance = async (utterance: string) => {
    cleanupSpeech();
    setStatus('thinking');

    try {
      const aiReply = await onVoiceMessage(utterance);
      if (isComponentMounted.current && aiReply) {
        setLastAiResponse(aiReply);
        speakAiResponse(aiReply);
      } else {
        if (isComponentMounted.current) {
          startListening();
        }
      }
    } catch {
      if (isComponentMounted.current) {
        startListening();
      }
    }
  };

  const speakAiResponse = (text: string) => {
    if (!('speechSynthesis' in window)) {
      startListening();
      return;
    }

    window.speechSynthesis.cancel();
    setStatus('speaking');

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    utterance.rate = 1.05;
    utterance.pitch = 1.0;

    // Pick best natural English voice if available
    const voices = window.speechSynthesis.getVoices();
    const naturalVoice = voices.find(
      (v) => v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Samantha') || v.name.includes('Alex'))
    ) || voices.find((v) => v.lang.startsWith('en'));

    if (naturalVoice) {
      utterance.voice = naturalVoice;
    }

    utterance.onend = () => {
      if (!isComponentMounted.current) return;
      setStatus('listening');
      setTranscript('');
      startListening();
    };

    utterance.onerror = () => {
      if (!isComponentMounted.current) return;
      setStatus('listening');
      startListening();
    };

    window.speechSynthesis.speak(utterance);
  };

  const toggleMic = () => {
    if (isMicEnabled) {
      setIsMicEnabled(false);
      cleanupSpeech();
      setStatus('idle');
    } else {
      setIsMicEnabled(true);
      startListening();
    }
  };

  if (!isOpen) return null;

  return (
    <div
      id="live-voice-overlay"
      className="fixed inset-0 z-50 bg-gray-950/95 backdrop-blur-xl text-white flex flex-col justify-between p-6 sm:p-10 select-none animate-in fade-in duration-300"
    >
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center border border-white/10">
            <Sparkles className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-sm tracking-tight text-white">Live Voice Mode</span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-semibold border border-emerald-500/30">
                Autonomous
              </span>
            </div>
            <p className="text-xs text-gray-400">Hands-free real-time conversation & device actions</p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white transition-colors"
          title="Exit Live Voice"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Center Interactive Orb & Transcript */}
      <div className="flex flex-col items-center justify-center max-w-lg mx-auto w-full text-center space-y-8 my-auto">
        {/* Animated Glow Orb */}
        <div className="relative flex items-center justify-center">
          {/* Pulsing Outer Rings */}
          <div
            className={`absolute w-44 h-44 sm:w-56 sm:h-56 rounded-full transition-all duration-700 blur-2xl ${
              status === 'listening'
                ? 'bg-emerald-500/30 animate-pulse scale-110'
                : status === 'thinking'
                ? 'bg-purple-500/40 animate-spin scale-105'
                : status === 'speaking'
                ? 'bg-cyan-500/40 animate-pulse scale-120'
                : 'bg-white/10 scale-95'
            }`}
          />

          {/* Inner Glowing Core */}
          <div
            className={`w-28 h-28 sm:w-36 sm:h-36 rounded-full shadow-2xl flex items-center justify-center border transition-all duration-500 relative z-10 ${
              status === 'listening'
                ? 'bg-gradient-to-tr from-emerald-600 to-teal-400 border-emerald-300/40 shadow-emerald-500/30'
                : status === 'thinking'
                ? 'bg-gradient-to-tr from-purple-600 to-indigo-500 border-purple-300/40 shadow-purple-500/30'
                : status === 'speaking'
                ? 'bg-gradient-to-tr from-cyan-600 to-blue-500 border-cyan-300/40 shadow-cyan-500/30'
                : 'bg-gray-800 border-gray-700 shadow-black'
            }`}
          >
            {status === 'listening' && <Mic className="w-10 h-10 text-white animate-bounce" />}
            {status === 'thinking' && <Sparkles className="w-10 h-10 text-white animate-spin" />}
            {status === 'speaking' && <Volume2 className="w-10 h-10 text-white animate-pulse" />}
            {status === 'idle' && <MicOff className="w-10 h-10 text-gray-400" />}
          </div>
        </div>

        {/* Status Indicator Pill */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 border border-white/15 text-xs font-medium text-white shadow-lg">
          <span
            className={`w-2 h-2 rounded-full ${
              status === 'listening'
                ? 'bg-emerald-400 animate-ping'
                : status === 'thinking'
                ? 'bg-purple-400 animate-pulse'
                : status === 'speaking'
                ? 'bg-cyan-400 animate-bounce'
                : 'bg-gray-500'
            }`}
          />
          <span className="capitalize">
            {status === 'listening' && 'Listening to you...'}
            {status === 'thinking' && 'Thinking & Executing Action...'}
            {status === 'speaking' && 'Speaking response...'}
            {status === 'idle' && 'Mic Paused'}
          </span>
        </div>

        {/* Live Speech & Response Feed */}
        <div className="w-full min-h-[100px] flex flex-col justify-center px-4">
          {transcript ? (
            <div className="p-3.5 rounded-2xl bg-white/10 border border-white/10 text-sm text-gray-200 font-medium">
              <span className="text-[10px] uppercase font-bold text-gray-400 block mb-1">You said:</span>
              "{transcript}"
            </div>
          ) : lastAiResponse ? (
            <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 text-sm text-gray-300">
              <span className="text-[10px] uppercase font-bold text-emerald-400 block mb-1">Assistant:</span>
              "{lastAiResponse}"
            </div>
          ) : (
            <p className="text-sm text-gray-400">
              Speak naturally, e.g. <span className="text-gray-200">"Open WhatsApp and send message"</span> or{' '}
              <span className="text-gray-200">"Play songs on YouTube"</span>
            </p>
          )}
        </div>

        {activeTaskDesc && (
          <div className="p-2.5 rounded-xl bg-emerald-900/30 border border-emerald-500/30 text-xs text-emerald-300">
            {activeTaskDesc}
          </div>
        )}
      </div>

      {/* Bottom Controls */}
      <div className="flex items-center justify-center gap-6">
        <button
          onClick={toggleMic}
          className={`p-4 rounded-full transition-all shadow-xl active:scale-95 ${
            isMicEnabled
              ? 'bg-white text-gray-900 hover:bg-gray-200'
              : 'bg-rose-600 text-white hover:bg-rose-700'
          }`}
          title={isMicEnabled ? 'Mute Microphone' : 'Unmute Microphone'}
        >
          {isMicEnabled ? <Mic className="w-6 h-6" /> : <MicOff className="w-6 h-6" />}
        </button>

        <button
          onClick={onClose}
          className="px-5 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-sm font-semibold text-gray-200 hover:text-white border border-white/10 transition-colors"
        >
          End Live Mode
        </button>
      </div>
    </div>
  );
};
