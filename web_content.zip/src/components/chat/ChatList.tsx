import React, { useState } from 'react';
import { Search, Pin, BellOff, Clock, UserPlus, MessageSquare, Check, CheckCheck, Users, Plus } from 'lucide-react';
import { ConversationWithDetails } from '../../types';
import { usePresence } from '../../contexts/PresenceContext';
import { CreateGroupModal } from './CreateGroupModal';

type ChatListProps = {
  conversations: ConversationWithDetails[];
  activeConversationId: string | null;
  onSelectConversation: (id: string) => void;
  onOpenFriendsTab: () => void;
  onConversationCreated?: () => void;
};

export const ChatList: React.FC<ChatListProps> = ({
  conversations,
  activeConversationId,
  onSelectConversation,
  onOpenFriendsTab,
  onConversationCreated,
}) => {
  const [search, setSearch] = useState('');
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const { isUserOnline, typingUsersByConv } = usePresence();

  const filtered = conversations.filter((c) => {
    const query = search.toLowerCase();
    const displayName = c.type === 'group' ? (c.name || 'Group') : c.otherUser.display_name;
    const username = c.otherUser?.username || '';
    return (
      displayName.toLowerCase().includes(query) ||
      username.toLowerCase().includes(query) ||
      (c.lastMessage?.content && c.lastMessage.content.toLowerCase().includes(query))
    );
  });

  const formatTimestamp = (dateStr?: string) => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();

    if (isToday) {
      return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true });
    }
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  return (
    <div id="chat-list-container" className="h-full flex flex-col bg-neutral-900 border-r border-neutral-800 text-white select-none">
      {/* Search & Actions Bar */}
      <div className="p-3 border-b border-neutral-800 flex items-center space-x-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            id="chat-search-input"
            type="text"
            placeholder="Search chats or messages..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
          />
        </div>

        {/* New Group Button */}
        <button
          id="btn-create-group-chat"
          type="button"
          onClick={() => setShowCreateGroup(true)}
          className="p-2 bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-neutral-400 hover:text-emerald-400 rounded-xl transition-colors shrink-0"
          title="Create New Group"
        >
          <Users className="w-4 h-4" />
        </button>
      </div>

      {/* Conversations Scrollable List */}
      <div className="flex-1 overflow-y-auto divide-y divide-neutral-800/40">
        {filtered.length === 0 ? (
          <div className="p-8 text-center flex flex-col items-center justify-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-neutral-800/80 text-neutral-400 flex items-center justify-center">
              <MessageSquare className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-neutral-200">No chats yet</h3>
              <p className="text-xs text-neutral-500 mt-1 max-w-xs">
                Start private 1-to-1 conversations with accepted friends or create a group.
              </p>
            </div>
            <div className="flex items-center space-x-2 mt-2">
              <button
                id="btn-goto-friends-from-empty-chats"
                onClick={onOpenFriendsTab}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-xl flex items-center space-x-1.5 shadow-md shadow-emerald-950/30 transition-all cursor-pointer"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Find Friends</span>
              </button>
              <button
                onClick={() => setShowCreateGroup(true)}
                className="px-3.5 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold rounded-xl flex items-center space-x-1.5 transition-all cursor-pointer"
              >
                <Users className="w-3.5 h-3.5" />
                <span>New Group</span>
              </button>
            </div>
          </div>
        ) : (
          filtered.map((conv) => {
            const isSelected = activeConversationId === conv.id;
            const isGroup = conv.type === 'group';
            const online = !isGroup && isUserOnline(conv.otherUser.id);
            const typingUsers = typingUsersByConv[conv.id];
            const isTyping = typingUsers && (isGroup ? typingUsers.size > 0 : typingUsers.has(conv.otherUser.id));
            const chatName = isGroup ? (conv.name || 'Group Chat') : conv.otherUser.display_name;

            return (
              <button
                key={conv.id}
                id={`chat-item-${conv.id}`}
                type="button"
                onClick={() => onSelectConversation(conv.id)}
                className={`w-full text-left p-3.5 flex items-center space-x-3 transition-colors cursor-pointer ${
                  isSelected
                    ? 'bg-neutral-800/90 border-l-3 border-emerald-500'
                    : 'hover:bg-neutral-800/50'
                }`}
              >
                {/* Avatar with Online or Group indicator */}
                <div className="relative shrink-0">
                  <div className={`w-12 h-12 rounded-full border border-neutral-700/60 overflow-hidden flex items-center justify-center text-base font-bold text-neutral-200 ${
                    isGroup ? 'bg-emerald-950/60 text-emerald-400' : 'bg-neutral-800'
                  }`}>
                    {isGroup ? (
                      <Users className="w-6 h-6" />
                    ) : conv.otherUser.avatar_url ? (
                      <img
                        src={conv.otherUser.avatar_url}
                        alt={conv.otherUser.display_name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      conv.otherUser.display_name.charAt(0).toUpperCase()
                    )}
                  </div>
                  {online && (
                    <div
                      className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-neutral-900"
                      title="Online"
                    />
                  )}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-semibold text-neutral-100 truncate flex items-center space-x-1.5">
                      <span>{chatName}</span>
                      {conv.isPinned && <Pin className="w-3 h-3 text-emerald-400 rotate-45" />}
                    </h4>
                    <span className="text-[11px] text-neutral-500 shrink-0 ml-2">
                      {formatTimestamp(conv.lastMessage?.created_at)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between mt-1">
                    <div className="text-xs text-neutral-400 truncate pr-2">
                      {isTyping ? (
                        <span className="text-emerald-400 font-medium animate-pulse">Typing...</span>
                      ) : conv.lastMessage ? (
                        <span className="truncate flex items-center space-x-1">
                          {conv.lastMessage.is_deleted_everyone ? (
                            <span className="italic text-neutral-500">This message was deleted</span>
                          ) : conv.lastMessage.type === 'voice' ? (
                            <span>🎤 Voice note</span>
                          ) : conv.lastMessage.is_view_once ? (
                            <span>👁️ View once media</span>
                          ) : conv.lastMessage.type === 'image' ? (
                            <span>📷 Photo</span>
                          ) : conv.lastMessage.type === 'video' ? (
                            <span>🎥 Video</span>
                          ) : conv.lastMessage.type === 'file' ? (
                            <span>📎 {conv.lastMessage.file_name || 'Document'}</span>
                          ) : (
                            <span>{conv.lastMessage.content}</span>
                          )}
                        </span>
                      ) : (
                        <span className="italic text-neutral-600">No messages yet</span>
                      )}
                    </div>

                    <div className="flex items-center space-x-1.5 shrink-0">
                      {conv.disappearingDuration !== 'off' && (
                        <Clock className="w-3 h-3 text-neutral-500" title={`Disappearing: ${conv.disappearingDuration}`} />
                      )}
                      {conv.isMuted && <BellOff className="w-3 h-3 text-neutral-500" title="Muted" />}
                      {conv.unreadCount > 0 && (
                        <span className="min-w-4.5 h-4.5 px-1 rounded-full bg-emerald-600 text-white text-[10px] font-bold flex items-center justify-center">
                          {conv.unreadCount}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </button>
            );
          })
        )}
      </div>

      {/* Create Group Modal */}
      <CreateGroupModal
        isOpen={showCreateGroup}
        onClose={() => setShowCreateGroup(false)}
        onGroupCreated={(groupId) => {
          if (onConversationCreated) onConversationCreated();
          onSelectConversation(groupId);
        }}
      />
    </div>
  );
};
