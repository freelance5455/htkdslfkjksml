import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, ActionPayload, UserPermissions, ActiveTask } from '../../types/chat';
import { ActionCard } from './ActionCard';
import {
  Send,
  Sparkles,
  Bot,
  User,
  Copy,
  Check,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  Radio,
  Image as ImageIcon,
  MessageSquare,
  Youtube,
  Lock,
  Menu,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  BrainCircuit,
  Timer,
  BatteryCharging,
  Zap,
  Phone,
  Search,
} from 'lucide-react';

interface ChatInterfaceProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => Promise<string | undefined> | Promise<void>;
  isLoading: boolean;
  onExecuteAction: (action: ActionPayload) => void;
  onDenyAction: (action: ActionPayload) => void;
  onLockScreen: () => void;
  onGenerateImagePrompt: (prompt: string) => void;
  onStartTimer: (seconds: number, label: string) => void;
  onCheckBattery: () => void;
  onToggleTorch: () => void;
  onOpenSidebar: () => void;
  onOpenLiveVoice: () => void;
  permissions: UserPermissions;
  activeTask?: ActiveTask | null;
  autoSpeak: boolean;
  onToggleAutoSpeak: () => void;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({
  messages,
  onSendMessage,
  isLoading,
  onExecuteAction,
  onDenyAction,
  onLockScreen,
  onGenerateImagePrompt,
  onStartTimer,
  onCheckBattery,
  onToggleTorch,
  onOpenSidebar,
  onOpenLiveVoice,
  permissions,
  activeTask,
  autoSpeak,
  onToggleAutoSpeak,
}) => {
  const [inputText, setInputText] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [expandedThinking, setExpandedThinking] = useState<Record<string, boolean>>({});
  const [thinkingTimer, setThinkingTimer] = useState<number>(0);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Thinking duration ticker while loading
  useEffect(() => {
    let interval: any;
    if (isLoading) {
      setThinkingTimer(0);
      interval = setInterval(() => {
        setThinkingTimer((t) => Number((t + 0.1).toFixed(1)));
      }, 100);
    } else {
      setThinkingTimer(0);
    }
    return () => clearInterval(interval);
  }, [isLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isLoading) return;
    const text = inputText.trim();
    setInputText('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
    onSendMessage(text);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSpeak = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    window.speechSynthesis.speak(utterance);
  };

  const toggleThinkingCollapse = (msgId: string) => {
    setExpandedThinking((prev) => ({
      ...prev,
      [msgId]: !prev[msgId],
    }));
  };

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputText(e.target.value);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 160)}px`;
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-white relative">
      {/* Top Navbar */}
      <header className="sticky top-0 z-20 bg-white/95 backdrop-blur-md border-b border-gray-100 px-4 py-2.5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenSidebar}
            className="lg:hidden p-1.5 rounded-xl text-gray-600 hover:bg-gray-100 transition-colors"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2">
            <span className="font-bold text-gray-900 text-sm tracking-tight">AI Assistant</span>
            <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[11px] font-semibold border border-emerald-200 shadow-2xs">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Autonomous Engine Active
            </span>
          </div>
        </div>

        {/* Action Controls & Live Voice Button */}
        <div className="flex items-center gap-2">
          {/* Auto Speak Toggle */}
          <button
            onClick={onToggleAutoSpeak}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-medium border transition-colors flex items-center gap-1.5 ${
              autoSpeak
                ? 'bg-purple-50 text-purple-700 border-purple-200'
                : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
            }`}
            title={autoSpeak ? 'Auto-Voice Speaking Enabled' : 'Enable Auto-Voice Speaking'}
          >
            {autoSpeak ? <Volume2 className="w-3.5 h-3.5 text-purple-600" /> : <VolumeX className="w-3.5 h-3.5 text-gray-400" />}
            <span className="hidden sm:inline">Auto-Speak</span>
          </button>

          {/* Talk Live Button */}
          <button
            id="btn-talk-live"
            onClick={onOpenLiveVoice}
            className="px-3 py-1.5 rounded-xl text-xs font-semibold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 transition-all shadow-xs flex items-center gap-1.5 active:scale-95"
          >
            <Radio className="w-3.5 h-3.5 animate-pulse" />
            <span>Talk Live</span>
          </button>
        </div>
      </header>

      {/* Real Action Quick Tools Ribbon */}
      <div className="bg-gray-50/80 border-b border-gray-100 px-4 py-2 overflow-x-auto scrollbar-none flex items-center gap-2">
        <span className="text-[11px] font-bold text-gray-500 uppercase tracking-wider flex-shrink-0 flex items-center gap-1">
          <Zap className="w-3 h-3 text-amber-500" /> Quick Actions:
        </span>

        <button
          onClick={() => onSendMessage('Open WhatsApp and send a message')}
          className="flex-shrink-0 px-2.5 py-1 rounded-lg bg-white border border-gray-200 hover:border-emerald-300 hover:bg-emerald-50/50 text-xs text-gray-700 flex items-center gap-1.5 transition-colors shadow-2xs"
        >
          <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
          <span>WhatsApp Message</span>
        </button>

        <button
          onClick={() => onSendMessage('Search YouTube for trending songs')}
          className="flex-shrink-0 px-2.5 py-1 rounded-lg bg-white border border-gray-200 hover:border-red-300 hover:bg-red-50/50 text-xs text-gray-700 flex items-center gap-1.5 transition-colors shadow-2xs"
        >
          <Youtube className="w-3.5 h-3.5 text-red-600" />
          <span>YouTube Search</span>
        </button>

        <button
          onClick={onLockScreen}
          className="flex-shrink-0 px-2.5 py-1 rounded-lg bg-white border border-gray-200 hover:border-amber-300 hover:bg-amber-50/50 text-xs text-gray-700 flex items-center gap-1.5 transition-colors shadow-2xs"
        >
          <Lock className="w-3.5 h-3.5 text-amber-600" />
          <span>Lock Device</span>
        </button>

        <button
          onClick={() => onSendMessage('Set a timer for 5 minutes')}
          className="flex-shrink-0 px-2.5 py-1 rounded-lg bg-white border border-gray-200 hover:border-cyan-300 hover:bg-cyan-50/50 text-xs text-gray-700 flex items-center gap-1.5 transition-colors shadow-2xs"
        >
          <Timer className="w-3.5 h-3.5 text-cyan-600" />
          <span>Set Timer</span>
        </button>

        <button
          onClick={onCheckBattery}
          className="flex-shrink-0 px-2.5 py-1 rounded-lg bg-white border border-gray-200 hover:border-teal-300 hover:bg-teal-50/50 text-xs text-gray-700 flex items-center gap-1.5 transition-colors shadow-2xs"
        >
          <BatteryCharging className="w-3.5 h-3.5 text-teal-600" />
          <span>Check Battery</span>
        </button>

        <button
          onClick={onToggleTorch}
          className="flex-shrink-0 px-2.5 py-1 rounded-lg bg-white border border-gray-200 hover:border-yellow-300 hover:bg-yellow-50/50 text-xs text-gray-700 flex items-center gap-1.5 transition-colors shadow-2xs"
        >
          <Zap className="w-3.5 h-3.5 text-yellow-500" />
          <span>Torch</span>
        </button>

        <button
          onClick={() => onSendMessage('Generate an image of a futuristic supercar')}
          className="flex-shrink-0 px-2.5 py-1 rounded-lg bg-white border border-gray-200 hover:border-purple-300 hover:bg-purple-50/50 text-xs text-gray-700 flex items-center gap-1.5 transition-colors shadow-2xs"
        >
          <Sparkles className="w-3.5 h-3.5 text-purple-600" />
          <span>Image Generator</span>
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-6 md:px-8 py-6">
        <div className="max-w-3xl mx-auto space-y-6">
          {/* Active Multi-turn Task Banner */}
          {activeTask && (
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 flex items-center justify-between shadow-2xs">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                <span className="font-semibold">
                  {activeTask.type === 'whatsapp' && activeTask.step === 'awaiting_contact' && 'Active Task: WhatsApp recipient awaiting name or number.'}
                  {activeTask.type === 'whatsapp' && activeTask.step === 'awaiting_message' && `Active Task: WhatsApp message body awaiting confirmation for ${activeTask.contactName}.`}
                </span>
              </div>
              <span className="text-[11px] text-emerald-700 font-medium">Listening for answer</span>
            </div>
          )}

          {/* Empty State */}
          {messages.length === 0 ? (
            <div className="pt-10 pb-6 text-center space-y-8 animate-in fade-in duration-300">
              <div className="w-12 h-12 rounded-2xl bg-gray-900 text-white mx-auto flex items-center justify-center shadow-lg shadow-gray-900/10">
                <Sparkles className="w-6 h-6 text-white" />
              </div>

              <div className="space-y-2">
                <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 tracking-tight">
                  How can I help you today?
                </h2>
                <p className="text-sm text-gray-500 max-w-md mx-auto">
                  I execute real actions in real-time: WhatsApp messages, YouTube video search, device lock, phone dialer, timers, and AI studio imagery.
                </p>
              </div>

              {/* 4 Feature Suggestion Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-left max-w-xl mx-auto">
                <button
                  onClick={() =>
                    onSendMessage('Open WhatsApp and send this message: "I am on my way now"')
                  }
                  className="p-3.5 rounded-2xl border border-gray-200 hover:border-emerald-300 hover:bg-emerald-50/40 transition-all text-left group shadow-2xs"
                >
                  <div className="flex items-center gap-2 font-semibold text-xs text-gray-900 mb-1">
                    <MessageSquare className="w-4 h-4 text-emerald-600" />
                    <span>Open WhatsApp & Send</span>
                  </div>
                  <p className="text-[11px] text-gray-500 line-clamp-2">
                    Autonomous message dispatch and contact dialogue
                  </p>
                </button>

                <button
                  onClick={() => onSendMessage('Search YouTube for trending lo-fi beats')}
                  className="p-3.5 rounded-2xl border border-gray-200 hover:border-red-300 hover:bg-red-50/40 transition-all text-left group shadow-2xs"
                >
                  <div className="flex items-center gap-2 font-semibold text-xs text-gray-900 mb-1">
                    <Youtube className="w-4 h-4 text-red-600" />
                    <span>YouTube Video Search</span>
                  </div>
                  <p className="text-[11px] text-gray-500 line-clamp-2">
                    Search and launch YouTube videos in real-time
                  </p>
                </button>

                <button
                  onClick={onLockScreen}
                  className="p-3.5 rounded-2xl border border-gray-200 hover:border-amber-300 hover:bg-amber-50/40 transition-all text-left group shadow-2xs"
                >
                  <div className="flex items-center gap-2 font-semibold text-xs text-gray-900 mb-1">
                    <Lock className="w-4 h-4 text-amber-600" />
                    <span>Device Screen Lock</span>
                  </div>
                  <p className="text-[11px] text-gray-500 line-clamp-2">
                    Activate screen protection and sleep mode
                  </p>
                </button>

                <button
                  onClick={() =>
                    onSendMessage('Generate an image of a luxury organic perfume bottle on marble')
                  }
                  className="p-3.5 rounded-2xl border border-gray-200 hover:border-purple-300 hover:bg-purple-50/40 transition-all text-left group shadow-2xs"
                >
                  <div className="flex items-center gap-2 font-semibold text-xs text-gray-900 mb-1">
                    <Sparkles className="w-4 h-4 text-purple-600" />
                    <span>AI Studio Image Generator</span>
                  </div>
                  <p className="text-[11px] text-gray-500 line-clamp-2">
                    Synthesize high-resolution commercial photography
                  </p>
                </button>
              </div>
            </div>
          ) : (
            messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 sm:gap-4 ${
                  msg.role === 'user' ? 'justify-end' : 'justify-start'
                }`}
              >
                {msg.role === 'assistant' && (
                  <div className="w-8 h-8 rounded-full bg-gray-900 text-white flex items-center justify-center flex-shrink-0 mt-1 shadow-xs">
                    <Sparkles className="w-4 h-4 text-white" />
                  </div>
                )}

                <div
                  className={`max-w-[85%] sm:max-w-[80%] ${
                    msg.role === 'user'
                      ? 'bg-gray-100 text-gray-900 rounded-2xl px-4 py-2.5 shadow-2xs text-sm'
                      : 'text-gray-900 text-sm leading-relaxed space-y-2'
                  }`}
                >
                  {/* Grok/ZAI Style Thinking Process Header & Accordion */}
                  {msg.role === 'assistant' && msg.thinking && (
                    <div className="mb-2 rounded-xl border border-gray-200 bg-gray-50/70 overflow-hidden text-xs">
                      <button
                        type="button"
                        onClick={() => toggleThinkingCollapse(msg.id)}
                        className="w-full px-3 py-2 flex items-center justify-between text-gray-600 hover:text-gray-900 hover:bg-gray-100/60 transition-colors"
                      >
                        <div className="flex items-center gap-2 font-medium">
                          <BrainCircuit className="w-3.5 h-3.5 text-purple-600" />
                          <span>Thought for {msg.thinking.durationSec}s</span>
                        </div>
                        {expandedThinking[msg.id] ? (
                          <ChevronUp className="w-3.5 h-3.5 text-gray-400" />
                        ) : (
                          <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
                        )}
                      </button>

                      {expandedThinking[msg.id] && (
                        <div className="px-3.5 pb-3 pt-1 border-t border-gray-200/60 space-y-1.5 text-gray-600 font-mono text-[11px] leading-relaxed">
                          {msg.thinking.steps.map((step, idx) => (
                            <div key={idx} className="flex items-start gap-1.5">
                              <span className="text-purple-600 font-bold">•</span>
                              <span>{step}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Message Content */}
                  <div className="whitespace-pre-wrap font-sans text-sm">{msg.content}</div>

                  {/* Render Action Card if present */}
                  {msg.action && (
                    <ActionCard
                      action={msg.action}
                      status={msg.actionStatus}
                      onExecute={onExecuteAction}
                      onDeny={onDenyAction}
                      onLockDevice={onLockScreen}
                      onGenerateImage={onGenerateImagePrompt}
                      onStartTimer={onStartTimer}
                      onToggleTorch={onToggleTorch}
                    />
                  )}

                  {/* Assistant Actions Bar */}
                  {msg.role === 'assistant' && (
                    <div className="flex items-center gap-2 pt-1 text-gray-400">
                      <button
                        onClick={() => handleCopy(msg.id, msg.content)}
                        className="p-1 rounded hover:bg-gray-100 hover:text-gray-700 transition-colors"
                        title="Copy message"
                      >
                        {copiedId === msg.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                      <button
                        onClick={() => handleSpeak(msg.content)}
                        className="p-1 rounded hover:bg-gray-100 hover:text-gray-700 transition-colors"
                        title="Read aloud"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>

                {msg.role === 'user' && (
                  <div className="w-8 h-8 rounded-full bg-gray-200 text-gray-700 flex items-center justify-center flex-shrink-0 mt-1">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            ))
          )}

          {/* Live Thinking Indicator (Grok/ZAI style) */}
          {isLoading && (
            <div className="flex gap-3 items-start animate-in fade-in duration-200">
              <div className="w-8 h-8 rounded-full bg-gray-900 text-white flex items-center justify-center flex-shrink-0 shadow-xs">
                <Sparkles className="w-4 h-4 animate-spin text-purple-400" />
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-purple-50/80 border border-purple-200/80 text-xs text-purple-800 font-mono shadow-2xs">
                  <BrainCircuit className="w-3.5 h-3.5 text-purple-600 animate-pulse" />
                  <span>Thinking & orchestrating autonomous action...</span>
                  <span className="font-bold text-purple-900">({thinkingTimer}s)</span>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Bottom Input Form */}
      <div className="sticky bottom-0 bg-white/95 backdrop-blur-md border-t border-gray-100 p-4">
        <div className="max-w-3xl mx-auto space-y-2">
          <form
            onSubmit={handleSubmit}
            className="flex items-end gap-2 bg-gray-100/90 hover:bg-gray-100 focus-within:bg-white focus-within:border-gray-300 border border-gray-200 rounded-3xl px-4 py-2.5 transition-all shadow-2xs"
          >
            {/* Live Talk Orb trigger inside input */}
            <button
              type="button"
              id="btn-voice-live-trigger"
              onClick={onOpenLiveVoice}
              className="p-2 rounded-full text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 transition-colors flex-shrink-0"
              title="Open Live Voice Mode (Hands-free)"
            >
              <Mic className="w-4 h-4" />
            </button>

            {/* Input Textarea */}
            <textarea
              ref={textareaRef}
              id="chat-input-textarea"
              rows={1}
              value={inputText}
              onChange={handleTextareaChange}
              onKeyDown={handleKeyDown}
              placeholder="Ask anything or command an action (e.g., Open WhatsApp, play song on YouTube, lock screen)..."
              className="flex-1 bg-transparent border-0 focus:outline-none focus:ring-0 text-sm text-gray-900 placeholder-gray-400 resize-none py-1 max-h-36"
            />

            {/* Submit Button */}
            <button
              id="btn-send-chat"
              type="submit"
              disabled={!inputText.trim() || isLoading}
              className="w-8 h-8 rounded-full bg-gray-900 hover:bg-black text-white flex items-center justify-center flex-shrink-0 transition-all disabled:opacity-30 disabled:cursor-not-allowed shadow-xs"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

          {/* Footer Note */}
          <p className="text-center text-[11px] text-gray-400 leading-tight">
            AI Assistant with real-time autonomous execution • Direct WhatsApp, YouTube, Screen Lock & Web integrations.
          </p>
        </div>
      </div>
    </div>
  );
};
