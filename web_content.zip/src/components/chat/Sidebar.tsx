import React from 'react';
import {
  Plus,
  MessageSquare,
  Shield,
  Layers,
  Sparkles,
  Lock,
  Youtube,
  ChevronLeft,
  Smartphone,
  Timer,
  BatteryCharging,
  Radio,
  Zap,
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
  activeView: 'chat' | 'banners';
  onChangeView: (view: 'chat' | 'banners') => void;
  onNewChat: () => void;
  onOpenPermissions: () => void;
  onQuickAction: (actionPrompt: string) => void;
  onLockScreen: () => void;
  onOpenLiveVoice: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onToggle,
  activeView,
  onChangeView,
  onNewChat,
  onOpenPermissions,
  onQuickAction,
  onLockScreen,
  onOpenLiveVoice,
}) => {
  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/20 lg:hidden backdrop-blur-2xs"
          onClick={onToggle}
        />
      )}

      {/* Sidebar Container */}
      <aside
        id="chatgpt-sidebar"
        className={`fixed lg:static top-0 bottom-0 left-0 z-40 w-64 sm:w-72 bg-gray-50 border-r border-gray-200/90 flex flex-col justify-between transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Top Controls */}
        <div className="p-3.5 space-y-3">
          {/* Header & Collapse */}
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-gray-900 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                AI
              </div>
              <span className="font-semibold text-sm text-gray-900 tracking-tight">
                AI Assistant
              </span>
            </div>
            <button
              onClick={onToggle}
              className="lg:hidden p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-200/60"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          </div>

          {/* New Chat Button */}
          <button
            id="btn-new-chat"
            onClick={onNewChat}
            className="w-full py-2.5 px-3 rounded-xl border border-gray-200 bg-white hover:bg-gray-100/80 text-gray-800 text-xs font-semibold flex items-center justify-between shadow-xs transition-all active:scale-98"
          >
            <span className="flex items-center gap-2">
              <Plus className="w-4 h-4 text-gray-700" />
              New Conversation
            </span>
            <span className="text-[10px] text-gray-400 font-mono">Ctrl+K</span>
          </button>

          {/* Talk Live Button inside sidebar */}
          <button
            onClick={onOpenLiveVoice}
            className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-xs transition-all active:scale-98"
          >
            <Radio className="w-3.5 h-3.5 animate-pulse" />
            <span>Launch Live Voice Talk</span>
          </button>

          {/* View Switcher: AI Assistant vs Banner Studio */}
          <div className="p-1 rounded-xl bg-gray-200/70 grid grid-cols-2 gap-1 text-xs font-medium text-gray-600">
            <button
              id="tab-chatgpt-mode"
              onClick={() => onChangeView('chat')}
              className={`py-1.5 px-2 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                activeView === 'chat'
                  ? 'bg-white text-gray-900 font-semibold shadow-xs'
                  : 'hover:text-gray-900'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>AI Chat</span>
            </button>
            <button
              id="tab-banners-mode"
              onClick={() => onChangeView('banners')}
              className={`py-1.5 px-2 rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                activeView === 'banners'
                  ? 'bg-white text-gray-900 font-semibold shadow-xs'
                  : 'hover:text-gray-900'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Banner Studio</span>
            </button>
          </div>
        </div>

        {/* Middle Quick Actions & Tools */}
        <div className="flex-1 overflow-y-auto px-3.5 space-y-4 py-2">
          {/* Real Mobile Action Shortcuts */}
          <div className="space-y-1.5">
            <div className="px-2 text-[11px] font-bold text-gray-500 uppercase tracking-wider flex items-center gap-1.5">
              <Smartphone className="w-3 h-3 text-emerald-600" />
              Real Actions
            </div>

            <button
              onClick={() => onQuickAction('Open WhatsApp and send a message')}
              className="w-full text-left p-2 rounded-xl text-xs text-gray-700 hover:bg-emerald-50 hover:text-emerald-900 hover:border-emerald-200 border border-transparent transition-all flex items-center gap-2.5"
            >
              <MessageSquare className="w-4 h-4 text-emerald-600 flex-shrink-0" />
              <div className="truncate">
                <span className="font-medium">Open WhatsApp & Send</span>
              </div>
            </button>

            <button
              onClick={() => onQuickAction('Search YouTube for trending songs')}
              className="w-full text-left p-2 rounded-xl text-xs text-gray-700 hover:bg-red-50 hover:text-red-900 hover:border-red-200 border border-transparent transition-all flex items-center gap-2.5"
            >
              <Youtube className="w-4 h-4 text-red-600 flex-shrink-0" />
              <div className="truncate">
                <span className="font-medium">Search YouTube Videos</span>
              </div>
            </button>

            <button
              onClick={onLockScreen}
              className="w-full text-left p-2 rounded-xl text-xs text-gray-700 hover:bg-amber-50 hover:text-amber-900 hover:border-amber-200 border border-transparent transition-all flex items-center gap-2.5"
            >
              <Lock className="w-4 h-4 text-amber-600 flex-shrink-0" />
              <div className="truncate">
                <span className="font-medium">Lock Device Screen</span>
              </div>
            </button>

            <button
              onClick={() => onQuickAction('Generate a studio photograph of a futuristic electric hypercar')}
              className="w-full text-left p-2 rounded-xl text-xs text-gray-700 hover:bg-purple-50 hover:text-purple-900 hover:border-purple-200 border border-transparent transition-all flex items-center gap-2.5"
            >
              <Sparkles className="w-4 h-4 text-purple-600 flex-shrink-0" />
              <div className="truncate">
                <span className="font-medium">AI Image Generation</span>
              </div>
            </button>
          </div>

          {/* Quick Prompts */}
          <div className="space-y-1.5 pt-2 border-t border-gray-200/80">
            <div className="px-2 text-[11px] font-bold text-gray-500 uppercase tracking-wider">
              Quick Prompts
            </div>
            <button
              onClick={() => onQuickAction('Search YouTube for top tech reviews')}
              className="w-full text-left p-2 rounded-xl text-xs text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition-colors truncate"
            >
              📺 YouTube Tech Reviews
            </button>
            <button
              onClick={() => onQuickAction('Search Google for breaking science news')}
              className="w-full text-left p-2 rounded-xl text-xs text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition-colors truncate"
            >
              🌐 Google Science News
            </button>
            <button
              onClick={() => onQuickAction('Set a timer for 10 minutes')}
              className="w-full text-left p-2 rounded-xl text-xs text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition-colors truncate"
            >
              ⏱️ Set 10-Min Timer
            </button>
            <button
              onClick={() => onQuickAction('Check my battery status and network')}
              className="w-full text-left p-2 rounded-xl text-xs text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition-colors truncate"
            >
              🔋 Check Device Battery
            </button>
          </div>
        </div>

        {/* Bottom Profile & Privacy/Permissions Center */}
        <div className="p-3 border-t border-gray-200/90 space-y-2 bg-gray-50/80">
          <button
            id="btn-open-permissions"
            onClick={onOpenPermissions}
            className="w-full p-2.5 rounded-xl border border-gray-200 bg-white hover:bg-gray-100 text-gray-800 text-xs font-semibold flex items-center justify-between transition-colors shadow-2xs"
          >
            <span className="flex items-center gap-2 text-emerald-700">
              <Shield className="w-4 h-4 text-emerald-600" />
              Permissions & Security
            </span>
            <span className="px-1.5 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-bold">
              Active
            </span>
          </button>

          <div className="px-2 py-1 flex items-center justify-between text-[11px] text-gray-500">
            <span>ChatGPT Style</span>
            <span>Real Actions v2.5</span>
          </div>
        </div>
      </aside>
    </>
  );
};
