import React, { useState, useEffect } from 'react';
import { X, Users, Check, Loader2, Search } from 'lucide-react';
import { Profile } from '../../types';
import { getFriends } from '../../services/friendService';
import { createGroupConversation } from '../../services/chatService';
import { useAuth } from '../../contexts/AuthContext';

type CreateGroupModalProps = {
  isOpen: boolean;
  onClose: () => void;
  onGroupCreated: (groupId: string) => void;
};

export const CreateGroupModal: React.FC<CreateGroupModalProps> = ({
  isOpen,
  onClose,
  onGroupCreated,
}) => {
  const { user } = useAuth();
  const [groupName, setGroupName] = useState('');
  const [friends, setFriends] = useState<Profile[]>([]);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [loadingFriends, setLoadingFriends] = useState(false);
  const [creating, setCreating] = useState(false);
  const [search, setSearch] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen || !user) return;
    setGroupName('');
    setSelectedIds([]);
    setError(null);
    setLoadingFriends(true);

    getFriends(user.id)
      .then((list) => setFriends(list))
      .catch((err) => console.error('Failed to load friends:', err))
      .finally(() => setLoadingFriends(false));
  }, [isOpen, user]);

  if (!isOpen) return null;

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const filteredFriends = friends.filter((f) => {
    const q = search.toLowerCase();
    return (
      f.display_name.toLowerCase().includes(q) ||
      f.username.toLowerCase().includes(q)
    );
  });

  const handleCreate = async () => {
    if (!groupName.trim()) {
      setError('Please provide a group name');
      return;
    }
    if (selectedIds.length === 0) {
      setError('Please select at least one friend');
      return;
    }

    setCreating(true);
    setError(null);

    try {
      const groupId = await createGroupConversation({
        name: groupName.trim(),
        memberIds: selectedIds,
      });
      onGroupCreated(groupId);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to create group');
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white">Create New Group</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-xl hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4 flex-1 overflow-y-auto">
          {error && (
            <div className="p-2.5 bg-red-500/10 border border-red-500/20 rounded-xl text-xs text-red-300">
              {error}
            </div>
          )}

          {/* Group Name input */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              Group Subject / Name
            </label>
            <input
              type="text"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              placeholder="e.g. Weekend Crew, Project Alpha"
              maxLength={40}
              className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
              autoFocus
            />
          </div>

          {/* Friends Selection */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-neutral-300">
                Add Participants ({selectedIds.length} selected)
              </label>
            </div>

            {/* Search filter */}
            <div className="relative mb-2">
              <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search friends..."
                className="w-full pl-8 pr-3 py-1.5 bg-neutral-950 border border-neutral-800 rounded-lg text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="max-h-52 overflow-y-auto space-y-1 divide-y divide-neutral-800/40">
              {loadingFriends ? (
                <div className="py-8 text-center text-xs text-neutral-500 flex items-center justify-center space-x-2">
                  <Loader2 className="w-4 h-4 animate-spin text-emerald-500" />
                  <span>Loading friends...</span>
                </div>
              ) : filteredFriends.length === 0 ? (
                <div className="py-6 text-center text-xs text-neutral-500">
                  {friends.length === 0
                    ? 'No friends yet. Add friends first to start a group chat.'
                    : 'No matching friends found.'}
                </div>
              ) : (
                filteredFriends.map((friend) => {
                  const isChecked = selectedIds.includes(friend.id);
                  return (
                    <div
                      key={friend.id}
                      onClick={() => toggleSelect(friend.id)}
                      className="pt-2 first:pt-0 flex items-center justify-between p-2 rounded-xl hover:bg-neutral-800/50 cursor-pointer transition-colors"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-9 h-9 rounded-full bg-neutral-800 border border-neutral-700 overflow-hidden flex items-center justify-center text-xs font-bold text-neutral-200">
                          {friend.avatar_url ? (
                            <img
                              src={friend.avatar_url}
                              alt=""
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            friend.display_name.charAt(0).toUpperCase()
                          )}
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-white">
                            {friend.display_name}
                          </p>
                          <p className="text-[10px] text-neutral-400">@{friend.username}</p>
                        </div>
                      </div>

                      <div
                        className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-colors ${
                          isChecked
                            ? 'bg-emerald-600 border-emerald-500 text-white'
                            : 'border-neutral-700 bg-neutral-950'
                        }`}
                      >
                        {isChecked && <Check className="w-3.5 h-3.5" />}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-800 flex items-center justify-end space-x-2 bg-neutral-950/60">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-neutral-400 hover:text-white rounded-xl hover:bg-neutral-800 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleCreate}
            disabled={creating || !groupName.trim() || selectedIds.length === 0}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white text-xs font-bold rounded-xl flex items-center space-x-2 shadow-lg shadow-emerald-950/50 transition-all cursor-pointer"
          >
            {creating ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Creating Group...</span>
              </>
            ) : (
              <span>Create Group</span>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
