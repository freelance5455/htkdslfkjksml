import React, { useEffect, useState } from 'react';
import { X, Search, Send, User, Check, Loader2 } from 'lucide-react';
import { Profile, Message } from '../../types';
import { getFriends } from '../../services/friendService';
import { getOrCreateDirectConversation, sendMessage } from '../../services/chatService';

type ForwardModalProps = {
  isOpen: boolean;
  message: Message | null;
  currentUserId: string;
  onClose: () => void;
  onForwardSuccess: () => void;
};

export const ForwardModal: React.FC<ForwardModalProps> = ({
  isOpen,
  message,
  currentUserId,
  onClose,
  onForwardSuccess,
}) => {
  const [friends, setFriends] = useState<Profile[]>([]);
  const [selectedFriendIds, setSelectedFriendIds] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    setLoading(true);
    getFriends(currentUserId)
      .then((data) => {
        setFriends(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [isOpen, currentUserId]);

  if (!isOpen || !message) return null;

  const filteredFriends = friends.filter((f) =>
    f.display_name.toLowerCase().includes(search.toLowerCase()) ||
    f.username.toLowerCase().includes(search.toLowerCase())
  );

  const toggleSelect = (id: string) => {
    setSelectedFriendIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleForward = async () => {
    if (selectedFriendIds.size === 0) return;
    setSending(true);

    try {
      for (const targetId of selectedFriendIds) {
        const convId = await getOrCreateDirectConversation(targetId);
        await sendMessage({
          conversationId: convId,
          senderId: currentUserId,
          content: message.content,
          type: message.type,
          fileName: message.file_name || undefined,
          fileSize: message.file_size || undefined,
          mimeType: message.mime_type || undefined,
          mediaPath: message.media_path || undefined,
        });
      }
      onForwardSuccess();
      onClose();
    } catch (err) {
      console.error('Forward failed:', err);
      alert('Failed to forward message. Please try again.');
    } finally {
      setSending(false);
    }
  };

  return (
    <div
      id="forward-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 animate-in fade-in"
    >
      <div
        id="forward-modal-card"
        className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh] text-white"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-neutral-800">
          <h3 className="text-base font-semibold">Forward Message</h3>
          <button
            id="btn-close-forward-modal"
            onClick={onClose}
            className="p-1 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message preview snippet */}
        <div className="px-5 py-2.5 bg-neutral-950/60 border-b border-neutral-800 text-xs text-neutral-300 truncate">
          <span className="text-neutral-500 font-medium mr-1.5">Forwarding:</span>
          {message.content || (message.type === 'voice' ? 'Voice Note' : message.file_name || 'Media')}
        </div>

        {/* Search */}
        <div className="p-3 border-b border-neutral-800">
          <div className="relative">
            <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search friends..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        {/* Friends list */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {loading ? (
            <div className="py-8 flex justify-center text-neutral-500">
              <Loader2 className="w-6 h-6 animate-spin text-emerald-500" />
            </div>
          ) : filteredFriends.length === 0 ? (
            <p className="text-center py-8 text-xs text-neutral-500">No friends found</p>
          ) : (
            filteredFriends.map((friend) => {
              const isSelected = selectedFriendIds.has(friend.id);
              return (
                <button
                  key={friend.id}
                  type="button"
                  onClick={() => toggleSelect(friend.id)}
                  className={`w-full flex items-center justify-between p-2.5 rounded-xl transition-colors ${
                    isSelected ? 'bg-emerald-500/10 border border-emerald-500/30' : 'hover:bg-neutral-800/60'
                  }`}
                >
                  <div className="flex items-center space-x-3 text-left">
                    <div className="w-9 h-9 rounded-full bg-neutral-800 overflow-hidden flex items-center justify-center font-bold text-neutral-300 text-sm">
                      {friend.avatar_url ? (
                        <img src={friend.avatar_url} alt={friend.display_name} className="w-full h-full object-cover" />
                      ) : (
                        friend.display_name.charAt(0).toUpperCase()
                      )}
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-neutral-200">{friend.display_name}</p>
                      <p className="text-[11px] text-neutral-500">@{friend.username}</p>
                    </div>
                  </div>

                  <div
                    className={`w-5 h-5 rounded-full border flex items-center justify-center transition-all ${
                      isSelected
                        ? 'bg-emerald-600 border-emerald-600 text-white'
                        : 'border-neutral-700 bg-neutral-950'
                    }`}
                  >
                    {isSelected && <Check className="w-3.5 h-3.5" />}
                  </div>
                </button>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-800 flex items-center justify-between bg-neutral-950/40">
          <span className="text-xs text-neutral-400">
            {selectedFriendIds.size} selected
          </span>
          <button
            id="btn-send-forward"
            type="button"
            disabled={selectedFriendIds.size === 0 || sending}
            onClick={handleForward}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-semibold text-xs rounded-xl shadow-md transition-all flex items-center space-x-2"
          >
            {sending ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Sending...</span>
              </>
            ) : (
              <>
                <span>Send</span>
                <Send className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
