import React from 'react';
import { UserPermissions } from '../../types/chat';
import {
  ShieldCheck,
  X,
  MessageSquare,
  Youtube,
  Lock,
  Phone,
  Bot,
  BellRing,
  CheckCircle,
} from 'lucide-react';

interface PermissionManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  permissions: UserPermissions;
  onUpdatePermissions: (newPerms: UserPermissions) => void;
}

export const PermissionManagerModal: React.FC<PermissionManagerModalProps> = ({
  isOpen,
  onClose,
  permissions,
  onUpdatePermissions,
}) => {
  if (!isOpen) return null;

  const toggle = (key: keyof UserPermissions) => {
    onUpdatePermissions({
      ...permissions,
      [key]: !permissions[key],
    });
  };

  const handleGrantAll = () => {
    onUpdatePermissions({
      whatsapp: true,
      youtube: true,
      deviceControl: true,
      microphone: true,
      geminiAi: true,
      haptics: true,
      alwaysAskBeforeAction: false, // User requested autonomous execution without repeated prompts
    });
  };

  return (
    <div
      id="permission-manager-overlay"
      className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in"
    >
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-gray-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-gray-50/50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-100">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-gray-900">Security & Action Permissions</h3>
              <p className="text-xs text-gray-500">Manage autonomous execution protocols</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-100 text-xs text-emerald-900 leading-relaxed">
            <p className="font-semibold mb-1">Autonomous Execution Engine:</p>
            Actions (WhatsApp message launches, YouTube searches, and phone calls) are dispatched automatically upon your request for high speed and seamless flow.
          </div>

          <div className="space-y-3">
            {/* WhatsApp */}
            <div className="flex items-center justify-between p-3 rounded-xl border border-gray-200 hover:border-gray-300 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
                  <MessageSquare className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-gray-900">WhatsApp Messaging</div>
                  <div className="text-[11px] text-gray-500">Autonomous WhatsApp chat & message bridge</div>
                </div>
              </div>
              <input
                type="checkbox"
                id="perm-whatsapp"
                checked={permissions.whatsapp}
                onChange={() => toggle('whatsapp')}
                className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer"
              />
            </div>

            {/* YouTube */}
            <div className="flex items-center justify-between p-3 rounded-xl border border-gray-200 hover:border-gray-300 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-red-50 text-red-600">
                  <Youtube className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-gray-900">YouTube Search & Playback</div>
                  <div className="text-[11px] text-gray-500">Direct YouTube video search launches</div>
                </div>
              </div>
              <input
                type="checkbox"
                id="perm-youtube"
                checked={permissions.youtube}
                onChange={() => toggle('youtube')}
                className="w-4 h-4 rounded text-red-600 focus:ring-red-500 cursor-pointer"
              />
            </div>

            {/* Device Screen Control */}
            <div className="flex items-center justify-between p-3 rounded-xl border border-gray-200 hover:border-gray-300 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-amber-50 text-amber-600">
                  <Lock className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-gray-900">Screen Lock & Sleep Control</div>
                  <div className="text-[11px] text-gray-500">WakeLock release and lock screen trigger</div>
                </div>
              </div>
              <input
                type="checkbox"
                id="perm-device"
                checked={permissions.deviceControl}
                onChange={() => toggle('deviceControl')}
                className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500 cursor-pointer"
              />
            </div>

            {/* Phone Calls */}
            <div className="flex items-center justify-between p-3 rounded-xl border border-gray-200 hover:border-gray-300 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-gray-900">Phone Call Dialer</div>
                  <div className="text-[11px] text-gray-500">Direct dialer integration (tel:)</div>
                </div>
              </div>
              <input
                type="checkbox"
                id="perm-calls"
                checked={permissions.haptics}
                onChange={() => toggle('haptics')}
                className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer"
              />
            </div>

            {/* Gemini AI */}
            <div className="flex items-center justify-between p-3 rounded-xl border border-gray-200 hover:border-gray-300 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-purple-50 text-purple-600">
                  <Bot className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-gray-900">AI Reasoning & Studio Generation</div>
                  <div className="text-[11px] text-gray-500">High-intelligence thinking & image synthesis</div>
                </div>
              </div>
              <input
                type="checkbox"
                id="perm-gemini"
                checked={permissions.geminiAi}
                onChange={() => toggle('geminiAi')}
                className="w-4 h-4 rounded text-purple-600 focus:ring-purple-500 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 border-t border-gray-100 bg-gray-50 flex items-center justify-between">
          <button
            type="button"
            onClick={handleGrantAll}
            className="text-xs font-semibold text-emerald-700 hover:text-emerald-900 flex items-center gap-1"
          >
            <CheckCircle className="w-3.5 h-3.5" />
            Allow All Autonomous
          </button>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-gray-900 hover:bg-black transition-colors"
          >
            Save & Close
          </button>
        </div>
      </div>
    </div>
  );
};
