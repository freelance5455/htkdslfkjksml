import React, { useState } from 'react';
import {
  Search,
  Image,
  Bell,
  BellOff,
  Clock,
  Trash2,
  XCircle,
  Ban,
  Flag,
  User,
  X,
  Check,
  ChevronRight,
  Palette,
  Timer,
  Pin,
} from 'lucide-react';
import { AutoDeleteChatDuration, DisappearingDuration, Profile } from '../../types';
import { ConfirmationDialog } from '../common/ConfirmationDialog';

type ChatMenuModalProps = {
  isOpen: boolean;
  onClose: () => void;
  otherUser: Profile;
  isMuted: boolean;
  isPinned?: boolean;
  disappearingDuration: DisappearingDuration;
  autoDeleteDuration?: AutoDeleteChatDuration;
  wallpaper?: string | null;
  onToggleSearch: () => void;
  onOpenSharedMedia: () => void;
  onToggleMute: () => void;
  onTogglePin?: () => void;
  onSetDisappearing: (dur: DisappearingDuration) => void;
  onSetAutoDelete?: (dur: AutoDeleteChatDuration) => void;
  onSetWallpaper?: (wallpaper: string) => void;
  onClearChat: () => void;
  onClearChatForAll?: () => void;
  onDeleteChat: () => void;
  onBlockUser: () => void;
  onReportUser: (reason: string) => void;
  onViewProfile: () => void;
};

const DISAPPEARING_OPTIONS: { id: DisappearingDuration; label: string }[] = [
  { id: 'off', label: 'Off' },
  { id: '5m', label: '5 Minutes' },
  { id: '1h', label: '1 Hour' },
  { id: '24h', label: '24 Hours' },
  { id: '7d', label: '7 Days' },
  { id: '30d', label: '30 Days' },
  { id: '90d', label: '90 Days' },
];

const WALLPAPER_OPTIONS = [
  { id: 'default', name: 'Default', bg: 'bg-neutral-900' },
  { id: 'slate', name: 'Deep Slate', bg: 'bg-slate-900' },
  { id: 'emerald', name: 'Emerald Night', bg: 'bg-emerald-950/40' },
  { id: 'midnight', name: 'Midnight Blue', bg: 'bg-blue-950/40' },
  { id: 'purple', name: 'Purple Twilight', bg: 'bg-purple-950/40' },
  { id: 'amoled', name: 'Pure Black', bg: 'bg-black' },
];

export const ChatMenuModal: React.FC<ChatMenuModalProps> = ({
  isOpen,
  onClose,
  otherUser,
  isMuted,
  isPinned = false,
  disappearingDuration,
  autoDeleteDuration = 'off',
  wallpaper = 'default',
  onToggleSearch,
  onOpenSharedMedia,
  onToggleMute,
  onTogglePin,
  onSetDisappearing,
  onSetAutoDelete,
  onSetWallpaper,
  onClearChat,
  onClearChatForAll,
  onDeleteChat,
  onBlockUser,
  onReportUser,
  onViewProfile,
}) => {
  const [showDisappearingOptions, setShowDisappearingOptions] = useState(false);
  const [showAutoDeleteOptions, setShowAutoDeleteOptions] = useState(false);
  const [showWallpaperOptions, setShowWallpaperOptions] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [showClearAllConfirm, setShowClearAllConfirm] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showBlockConfirm, setShowBlockConfirm] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportReason, setReportReason] = useState('');

  if (!isOpen) return null;

  const handleReportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reportReason.trim()) return;
    onReportUser(reportReason.trim());
    setShowReportModal(false);
    setReportReason('');
    onClose();
  };

  return (
    <>
      <div
        id="chat-menu-backdrop"
        className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs flex items-center justify-end md:justify-center p-4 animate-in fade-in"
        onClick={onClose}
      >
        <div
          id="chat-menu-sheet"
          className="w-full max-w-sm max-h-[90vh] overflow-y-auto bg-neutral-900 border border-neutral-800 rounded-3xl p-5 shadow-2xl space-y-4 text-white animate-in slide-in-from-bottom md:zoom-in-95 duration-150"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-neutral-800 overflow-hidden flex items-center justify-center font-bold text-neutral-300">
                {otherUser.avatar_url ? (
                  <img src={otherUser.avatar_url} alt={otherUser.display_name} className="w-full h-full object-cover" />
                ) : (
                  otherUser.display_name.charAt(0).toUpperCase()
                )}
              </div>
              <div>
                <h3 className="text-sm font-semibold text-neutral-100">{otherUser.display_name}</h3>
                <p className="text-xs text-neutral-400">@{otherUser.username}</p>
              </div>
            </div>
            <button
              id="btn-close-chat-menu"
              onClick={onClose}
              className="p-1 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Menu Items */}
          <div className="space-y-1 text-sm">
            <button
              id="btn-menu-view-profile"
              onClick={() => {
                onViewProfile();
                onClose();
              }}
              className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-neutral-800/80 text-neutral-200 transition-colors"
            >
              <div className="flex items-center space-x-3">
                <User className="w-4 h-4 text-neutral-400" />
                <span>Contact Info</span>
              </div>
              <ChevronRight className="w-4 h-4 text-neutral-500" />
            </button>

            <button
              id="btn-menu-search-chat"
              onClick={() => {
                onToggleSearch();
                onClose();
              }}
              className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl hover:bg-neutral-800/80 text-neutral-200 transition-colors"
            >
              <Search className="w-4 h-4 text-neutral-400" />
              <span>Search in Chat</span>
            </button>

            <button
              id="btn-menu-shared-media"
              onClick={() => {
                onOpenSharedMedia();
                onClose();
              }}
              className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl hover:bg-neutral-800/80 text-neutral-200 transition-colors"
            >
              <Image className="w-4 h-4 text-neutral-400" />
              <span>Media, Links and Docs</span>
            </button>

            <button
              id="btn-menu-toggle-mute"
              onClick={() => {
                onToggleMute();
                onClose();
              }}
              className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-neutral-800/80 text-neutral-200 transition-colors"
            >
              <div className="flex items-center space-x-3">
                {isMuted ? <BellOff className="w-4 h-4 text-amber-400" /> : <Bell className="w-4 h-4 text-neutral-400" />}
                <span>{isMuted ? 'Unmute Notifications' : 'Mute Notifications'}</span>
              </div>
              <span className="text-xs text-neutral-500">{isMuted ? 'Muted' : 'Enabled'}</span>
            </button>

            {onTogglePin && (
              <button
                id="btn-menu-toggle-pin"
                onClick={() => {
                  onTogglePin();
                  onClose();
                }}
                className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-neutral-800/80 text-neutral-200 transition-colors"
              >
                <div className="flex items-center space-x-3">
                  <Pin className={`w-4 h-4 ${isPinned ? 'text-emerald-400' : 'text-neutral-400'}`} />
                  <span>{isPinned ? 'Unpin Conversation' : 'Pin Conversation'}</span>
                </div>
                <span className="text-xs text-neutral-500">{isPinned ? 'Pinned' : 'Normal'}</span>
              </button>
            )}

            {/* Disappearing messages toggle */}
            <div className="pt-1">
              <button
                id="btn-menu-disappearing"
                onClick={() => setShowDisappearingOptions(!showDisappearingOptions)}
                className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-neutral-800/80 text-neutral-200 transition-colors"
              >
                <div className="flex items-center space-x-3">
                  <Clock className="w-4 h-4 text-neutral-400" />
                  <span>Disappearing Messages</span>
                </div>
                <span className="text-xs text-emerald-400 font-medium capitalize">
                  {disappearingDuration === 'off' ? 'Off' : disappearingDuration}
                </span>
              </button>

              {showDisappearingOptions && (
                <div className="ml-7 my-1 p-2 bg-neutral-950/80 rounded-xl border border-neutral-800 space-y-1">
                  {DISAPPEARING_OPTIONS.map((opt) => (
                    <button
                      key={opt.id}
                      onClick={() => {
                        onSetDisappearing(opt.id);
                        setShowDisappearingOptions(false);
                      }}
                      className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs hover:bg-neutral-800 text-neutral-300 transition-colors"
                    >
                      <span>{opt.label}</span>
                      {disappearingDuration === opt.id && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Auto-Delete Chat (5 minutes) */}
            <div className="pt-1">
              <button
                id="btn-menu-auto-delete"
                onClick={() => setShowAutoDeleteOptions(!showAutoDeleteOptions)}
                className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-neutral-800/80 text-neutral-200 transition-colors"
              >
                <div className="flex items-center space-x-3">
                  <Timer className="w-4 h-4 text-neutral-400" />
                  <span>Auto-Delete Chat</span>
                </div>
                <span className="text-xs text-amber-400 font-medium">
                  {autoDeleteDuration === '5m' ? '5 Minutes' : 'Off'}
                </span>
              </button>

              {showAutoDeleteOptions && (
                <div className="ml-7 my-1 p-2 bg-neutral-950/80 rounded-xl border border-neutral-800 space-y-1">
                  <button
                    onClick={() => {
                      onSetAutoDelete?.('off');
                      setShowAutoDeleteOptions(false);
                    }}
                    className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs hover:bg-neutral-800 text-neutral-300 transition-colors"
                  >
                    <span>Off</span>
                    {autoDeleteDuration === 'off' && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                  </button>
                  <button
                    onClick={() => {
                      onSetAutoDelete?.('5m');
                      setShowAutoDeleteOptions(false);
                    }}
                    className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-xs hover:bg-neutral-800 text-neutral-300 transition-colors"
                  >
                    <span>5 Minutes</span>
                    {autoDeleteDuration === '5m' && <Check className="w-3.5 h-3.5 text-amber-400" />}
                  </button>
                </div>
              )}
            </div>

            {/* Chat Wallpaper */}
            <div className="pt-1">
              <button
                id="btn-menu-wallpaper"
                onClick={() => setShowWallpaperOptions(!showWallpaperOptions)}
                className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl hover:bg-neutral-800/80 text-neutral-200 transition-colors"
              >
                <div className="flex items-center space-x-3">
                  <Palette className="w-4 h-4 text-neutral-400" />
                  <span>Chat Wallpaper</span>
                </div>
                <span className="text-xs text-neutral-400 capitalize">
                  {wallpaper || 'Default'}
                </span>
              </button>

              {showWallpaperOptions && (
                <div className="ml-7 my-1 p-2 bg-neutral-950/80 rounded-xl border border-neutral-800 grid grid-cols-3 gap-1.5">
                  {WALLPAPER_OPTIONS.map((wp) => (
                    <button
                      key={wp.id}
                      onClick={() => {
                        onSetWallpaper?.(wp.id);
                        setShowWallpaperOptions(false);
                      }}
                      className={`p-2 rounded-lg text-[11px] text-center font-medium border transition-colors ${
                        (wallpaper || 'default') === wp.id
                          ? 'border-emerald-500 text-emerald-400'
                          : 'border-neutral-800 text-neutral-400 hover:text-white'
                      }`}
                    >
                      {wp.name}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <hr className="border-neutral-800 my-2" />

            <button
              id="btn-menu-clear-chat"
              onClick={() => setShowClearConfirm(true)}
              className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl hover:bg-neutral-800/80 text-amber-400 transition-colors"
            >
              <XCircle className="w-4 h-4 text-amber-400" />
              <span>Clear Chat (For Me)</span>
            </button>

            {onClearChatForAll && (
              <button
                id="btn-menu-clear-chat-all"
                onClick={() => setShowClearAllConfirm(true)}
                className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl hover:bg-neutral-800/80 text-red-400 transition-colors"
              >
                <Trash2 className="w-4 h-4 text-red-400" />
                <span>Clear Chat For Everyone</span>
              </button>
            )}

            <button
              id="btn-menu-delete-chat"
              onClick={() => setShowDeleteConfirm(true)}
              className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl hover:bg-neutral-800/80 text-red-400 transition-colors"
            >
              <Trash2 className="w-4 h-4 text-red-400" />
              <span>Delete Chat</span>
            </button>

            <button
              id="btn-menu-block-user"
              onClick={() => setShowBlockConfirm(true)}
              className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl hover:bg-neutral-800/80 text-red-400 transition-colors"
            >
              <Ban className="w-4 h-4 text-red-400" />
              <span>Block @{otherUser.username}</span>
            </button>

            <button
              id="btn-menu-report-user"
              onClick={() => setShowReportModal(true)}
              className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl hover:bg-neutral-800/80 text-neutral-400 hover:text-white transition-colors"
            >
              <Flag className="w-4 h-4 text-neutral-400" />
              <span>Report User</span>
            </button>
          </div>
        </div>
      </div>

      {/* Confirmation Dialogs */}
      <ConfirmationDialog
        isOpen={showClearConfirm}
        title="Clear Chat For Me"
        message="Are you sure you want to clear this chat? This will remove existing messages from your view while preserving the conversation for other participants."
        confirmLabel="Clear Chat"
        onConfirm={() => {
          setShowClearConfirm(false);
          onClearChat();
          onClose();
        }}
        onCancel={() => setShowClearConfirm(false)}
      />

      <ConfirmationDialog
        isOpen={showClearAllConfirm}
        title="Clear Chat For Everyone?"
        message="This will permanently delete all messages in this conversation for both you and your friend. This action cannot be undone."
        confirmLabel="Clear For Everyone"
        onConfirm={() => {
          setShowClearAllConfirm(false);
          onClearChatForAll?.();
          onClose();
        }}
        onCancel={() => setShowClearAllConfirm(false)}
      />

      <ConfirmationDialog
        isOpen={showDeleteConfirm}
        title="Delete Chat"
        message="Delete this conversation from your chat list? The other user's conversation history will remain unaffected."
        confirmLabel="Delete Chat"
        onConfirm={() => {
          setShowDeleteConfirm(false);
          onDeleteChat();
          onClose();
        }}
        onCancel={() => setShowDeleteConfirm(false)}
      />

      <ConfirmationDialog
        isOpen={showBlockConfirm}
        title={`Block @${otherUser.username}?`}
        message="Blocked users cannot send you messages, place voice/video calls, or see your online presence."
        confirmLabel="Block User"
        onConfirm={() => {
          setShowBlockConfirm(false);
          onBlockUser();
          onClose();
        }}
        onCancel={() => setShowBlockConfirm(false)}
      />

      {/* Report Modal */}
      {showReportModal && (
        <div
          id="report-modal-backdrop"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 animate-in fade-in"
        >
          <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-2xl space-y-4 text-white">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-semibold text-neutral-100">Report User</h3>
              <button
                onClick={() => setShowReportModal(false)}
                className="text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleReportSubmit} className="space-y-4">
              <p className="text-xs text-neutral-400">
                Please describe the issue with @{otherUser.username} (e.g. spam, harassment, inappropriate content):
              </p>
              <textarea
                required
                rows={3}
                placeholder="Describe reason for report..."
                value={reportReason}
                onChange={(e) => setReportReason(e.target.value)}
                className="w-full p-3 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
              />
              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setShowReportModal(false)}
                  className="px-4 py-2 text-xs text-neutral-400 bg-neutral-800 rounded-xl hover:bg-neutral-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-red-600 rounded-xl hover:bg-red-500"
                >
                  Submit Report
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};
