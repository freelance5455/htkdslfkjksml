import React, { useState, useEffect } from 'react';
import { X, Image, FileText, Mic, Download, ExternalLink, Loader2 } from 'lucide-react';
import { Message } from '../../types';
import { getSecureMediaUrl } from '../../services/storageService';

type SharedMediaModalProps = {
  isOpen: boolean;
  onClose: () => void;
  messages: Message[];
};

export const SharedMediaModal: React.FC<SharedMediaModalProps> = ({ isOpen, onClose, messages }) => {
  const [tab, setTab] = useState<'media' | 'docs' | 'voice'>('media');
  const [signedUrls, setSignedUrls] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);

  const mediaMessages = messages.filter((m) => (m.type === 'image' || m.type === 'video') && !m.is_view_once && m.media_path);
  const docMessages = messages.filter((m) => m.type === 'file' && m.media_path);
  const voiceMessages = messages.filter((m) => m.type === 'voice' && m.media_path);

  useEffect(() => {
    if (!isOpen) return;

    let mounted = true;
    setLoading(true);

    const allMediaPaths = [...mediaMessages, ...docMessages, ...voiceMessages]
      .map((m) => m.media_path)
      .filter((p): p is string => Boolean(p));

    Promise.all(
      allMediaPaths.map(async (path) => {
        const url = await getSecureMediaUrl(path);
        return { path, url };
      })
    ).then((results) => {
      if (!mounted) return;
      const map: Record<string, string> = {};
      results.forEach((r) => {
        if (r.url) map[r.path] = r.url;
      });
      setSignedUrls(map);
      setLoading(false);
    }).catch(() => {
      if (mounted) setLoading(false);
    });

    return () => {
      mounted = false;
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div
      id="shared-media-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4 animate-in fade-in"
    >
      <div
        id="shared-media-dialog"
        className="w-full max-w-xl bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] text-white"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-950/40">
          <h3 className="text-base font-semibold">Media, Links and Docs</h3>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-neutral-800 bg-neutral-900/60 px-6 pt-2">
          <button
            onClick={() => setTab('media')}
            className={`pb-3 px-4 text-xs font-medium border-b-2 flex items-center space-x-1.5 transition-colors ${
              tab === 'media'
                ? 'border-emerald-500 text-emerald-400 font-semibold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Image className="w-3.5 h-3.5" />
            <span>Media ({mediaMessages.length})</span>
          </button>

          <button
            onClick={() => setTab('docs')}
            className={`pb-3 px-4 text-xs font-medium border-b-2 flex items-center space-x-1.5 transition-colors ${
              tab === 'docs'
                ? 'border-emerald-500 text-emerald-400 font-semibold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Docs ({docMessages.length})</span>
          </button>

          <button
            onClick={() => setTab('voice')}
            className={`pb-3 px-4 text-xs font-medium border-b-2 flex items-center space-x-1.5 transition-colors ${
              tab === 'voice'
                ? 'border-emerald-500 text-emerald-400 font-semibold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Mic className="w-3.5 h-3.5" />
            <span>Voice ({voiceMessages.length})</span>
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4">
          {loading ? (
            <div className="py-16 flex flex-col items-center justify-center space-y-2 text-neutral-500">
              <Loader2 className="w-6 h-6 animate-spin text-emerald-500" />
              <span className="text-xs">Loading media...</span>
            </div>
          ) : tab === 'media' ? (
            mediaMessages.length === 0 ? (
              <div className="py-16 text-center text-xs text-neutral-500">No photos or videos shared yet</div>
            ) : (
              <div className="grid grid-cols-3 gap-2">
                {mediaMessages.map((m) => {
                  const url = m.media_path ? signedUrls[m.media_path] : '';
                  return (
                    <div
                      key={m.id}
                      className="relative aspect-square rounded-xl overflow-hidden bg-neutral-950 group border border-neutral-800"
                    >
                      {url ? (
                        m.type === 'video' ? (
                          <video src={url} className="w-full h-full object-cover" />
                        ) : (
                          <img src={url} alt={m.file_name || 'Media'} className="w-full h-full object-cover" />
                        )
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-neutral-900">
                          <Loader2 className="w-4 h-4 animate-spin text-neutral-600" />
                        </div>
                      )}
                      {url && (
                        <a
                          href={url}
                          target="_blank"
                          rel="noreferrer"
                          className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity"
                        >
                          <ExternalLink className="w-5 h-5 text-white" />
                        </a>
                      )}
                    </div>
                  );
                })}
              </div>
            )
          ) : tab === 'docs' ? (
            docMessages.length === 0 ? (
              <div className="py-16 text-center text-xs text-neutral-500">No documents or files shared yet</div>
            ) : (
              <div className="space-y-2">
                {docMessages.map((m) => {
                  const url = m.media_path ? signedUrls[m.media_path] : '';
                  return (
                    <div
                      key={m.id}
                      className="flex items-center justify-between p-3 rounded-xl bg-neutral-950/60 border border-neutral-800 hover:border-neutral-700 transition-colors"
                    >
                      <div className="flex items-center space-x-3 overflow-hidden">
                        <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/20">
                          <FileText className="w-4 h-4" />
                        </div>
                        <div className="truncate">
                          <p className="text-xs font-semibold text-neutral-200 truncate">{m.file_name || 'Document'}</p>
                          <p className="text-[10px] text-neutral-500">
                            {m.file_size ? `${(m.file_size / 1024).toFixed(1)} KB` : ''} • {new Date(m.created_at).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      {url && (
                        <a
                          href={url}
                          download={m.file_name || 'download'}
                          className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-colors"
                        >
                          <Download className="w-4 h-4" />
                        </a>
                      )}
                    </div>
                  );
                })}
              </div>
            )
          ) : voiceMessages.length === 0 ? (
            <div className="py-16 text-center text-xs text-neutral-500">No voice notes shared yet</div>
          ) : (
            <div className="space-y-2">
              {voiceMessages.map((m) => {
                const url = m.media_path ? signedUrls[m.media_path] : '';
                return (
                  <div
                    key={m.id}
                    className="p-3 rounded-xl bg-neutral-950/60 border border-neutral-800 space-y-2"
                  >
                    <div className="flex items-center justify-between text-xs text-neutral-400">
                      <span className="flex items-center space-x-1.5">
                        <Mic className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Voice Note</span>
                      </span>
                      <span>{new Date(m.created_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}</span>
                    </div>
                    {url && (
                      <audio src={url} controls className="w-full h-8 brightness-90" />
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
