import React, { useState, useEffect } from 'react';
import { ActionPayload } from '../../types/chat';
import {
  MessageSquare,
  Youtube,
  Lock,
  Phone,
  Search,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  Check,
  X,
  Timer,
  BatteryCharging,
  Zap,
  CheckCircle2,
} from 'lucide-react';

interface ActionCardProps {
  action: ActionPayload;
  status?: 'executed' | 'pending' | 'denied';
  onExecute: (action: ActionPayload) => void;
  onDeny: (action: ActionPayload) => void;
  onLockDevice?: () => void;
  onGenerateImage?: (prompt: string) => void;
  onStartTimer?: (seconds: number, label: string) => void;
  onToggleTorch?: () => void;
}

export const ActionCard: React.FC<ActionCardProps> = ({
  action,
  status = 'executed',
  onExecute,
  onDeny,
  onLockDevice,
  onGenerateImage,
  onStartTimer,
  onToggleTorch,
}) => {
  const [currentStatus, setCurrentStatus] = useState<'pending' | 'executed' | 'denied'>(
    status === 'denied' ? 'denied' : 'executed'
  );

  useEffect(() => {
    if (status) {
      setCurrentStatus(status);
    }
  }, [status]);

  const getIcon = () => {
    switch (action.type) {
      case 'whatsapp':
        return <MessageSquare className="w-5 h-5 text-emerald-600" />;
      case 'youtube':
        return <Youtube className="w-5 h-5 text-red-600" />;
      case 'device_lock':
        return <Lock className="w-5 h-5 text-amber-600" />;
      case 'phone_call':
        return <Phone className="w-5 h-5 text-blue-600" />;
      case 'google_search':
        return <Search className="w-5 h-5 text-indigo-600" />;
      case 'start_timer':
        return <Timer className="w-5 h-5 text-cyan-600" />;
      case 'battery_status':
        return <BatteryCharging className="w-5 h-5 text-teal-600" />;
      case 'flashlight':
        return <Zap className="w-5 h-5 text-yellow-500" />;
      case 'generate_image':
        return <Sparkles className="w-5 h-5 text-purple-600" />;
      default:
        return <ExternalLink className="w-5 h-5 text-gray-600" />;
    }
  };

  const getBorderColor = () => {
    switch (action.type) {
      case 'whatsapp':
        return 'border-emerald-200 bg-emerald-50/40';
      case 'youtube':
        return 'border-red-200 bg-red-50/40';
      case 'device_lock':
        return 'border-amber-200 bg-amber-50/40';
      case 'phone_call':
        return 'border-blue-200 bg-blue-50/40';
      case 'google_search':
        return 'border-indigo-200 bg-indigo-50/40';
      case 'start_timer':
        return 'border-cyan-200 bg-cyan-50/40';
      case 'generate_image':
        return 'border-purple-200 bg-purple-50/40';
      default:
        return 'border-gray-200 bg-gray-50/50';
    }
  };

  const handleRun = () => {
    setCurrentStatus('executed');
    onExecute(action);

    if (action.type === 'whatsapp' && action.url) {
      window.open(action.url, '_blank', 'noopener,noreferrer');
    } else if (action.type === 'youtube' && action.url) {
      window.open(action.url, '_blank', 'noopener,noreferrer');
    } else if (action.type === 'device_lock') {
      if (onLockDevice) onLockDevice();
    } else if (action.type === 'phone_call' && action.url) {
      window.location.href = action.url;
    } else if (action.type === 'google_search' && action.url) {
      window.open(action.url, '_blank', 'noopener,noreferrer');
    } else if (action.type === 'start_timer' && action.params.seconds) {
      if (onStartTimer) onStartTimer(action.params.seconds, action.params.label || 'Timer');
    } else if (action.type === 'flashlight') {
      if (onToggleTorch) onToggleTorch();
    } else if (action.type === 'generate_image' && action.params.prompt) {
      if (onGenerateImage) onGenerateImage(action.params.prompt);
    }
  };

  const handleDeny = () => {
    setCurrentStatus('denied');
    onDeny(action);
  };

  return (
    <div
      id={`action-card-${action.type}`}
      className={`mt-3 p-4 rounded-xl border ${getBorderColor()} shadow-2xs transition-all max-w-lg`}
    >
      <div className="flex items-start gap-3">
        <div className="p-2 rounded-lg bg-white shadow-xs border border-gray-100 flex-shrink-0">
          {getIcon()}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <h4 className="text-sm font-semibold text-gray-900">{action.title}</h4>
            <span className="inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-full bg-white text-emerald-700 border border-emerald-200 shadow-2xs">
              <ShieldCheck className="w-3 h-3 text-emerald-600" />
              Autonomous Action
            </span>
          </div>

          <p className="text-xs text-gray-600 mt-1 leading-relaxed">{action.description}</p>

          {/* WhatsApp Message Preview */}
          {action.type === 'whatsapp' && action.params?.message && (
            <div className="mt-2.5 p-2.5 rounded-lg bg-white/90 border border-emerald-100 text-xs text-gray-800">
              <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-700 block mb-0.5">
                Message Payload
              </span>
              <p className="font-mono text-gray-700 italic">"{action.params.message}"</p>
            </div>
          )}

          {/* YouTube Search Preview */}
          {action.type === 'youtube' && action.params?.query && (
            <div className="mt-2.5 p-2 rounded-lg bg-white/90 border border-red-100 text-xs text-gray-800 flex items-center gap-2">
              <Youtube className="w-4 h-4 text-red-600" />
              <span className="font-medium text-gray-900">Query: {action.params.query}</span>
            </div>
          )}

          {/* Status & Autonomous Action Confirmation */}
          {currentStatus === 'executed' && (
            <div className="mt-3 pt-2.5 border-t border-emerald-200/70 flex flex-wrap items-center justify-between gap-2 text-xs">
              <span className="inline-flex items-center gap-1.5 text-emerald-700 font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                Executed in Real-Time
              </span>

              {action.url && (
                <a
                  href={action.url}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 text-emerald-700 hover:text-emerald-900 hover:underline font-medium text-[11px]"
                >
                  Open Direct Link <ExternalLink className="w-3 h-3" />
                </a>
              )}

              {action.type === 'device_lock' && onLockDevice && (
                <button
                  type="button"
                  onClick={onLockDevice}
                  className="px-2 py-1 rounded-md bg-amber-100 hover:bg-amber-200 text-amber-900 font-medium text-[11px] transition-colors"
                >
                  View Lock Screen
                </button>
              )}
            </div>
          )}

          {currentStatus === 'pending' && (
            <div className="mt-3 pt-2.5 border-t border-gray-200 flex items-center justify-between gap-2">
              <span className="text-[11px] text-gray-500">Ready to execute</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleDeny}
                  className="px-2.5 py-1 rounded-lg text-xs font-medium text-gray-600 hover:bg-gray-100 transition-colors"
                >
                  Dismiss
                </button>
                <button
                  type="button"
                  onClick={handleRun}
                  className="px-3 py-1 rounded-lg text-xs font-semibold text-white bg-gray-900 hover:bg-black transition-colors flex items-center gap-1"
                >
                  <Check className="w-3 h-3" /> Run Action
                </button>
              </div>
            </div>
          )}

          {currentStatus === 'denied' && (
            <div className="mt-2.5 pt-2 border-t border-gray-200 text-xs text-gray-400 flex items-center gap-1">
              <X className="w-3.5 h-3.5" /> Action dismissed
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
