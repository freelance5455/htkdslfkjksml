import React, { useState, useEffect, useRef } from 'react';
import { useMohalla } from '../../context/MohallaContext';
import {
  X,
  Send,
  MessageSquare,
  CheckCheck,
  ShieldCheck,
  Clock,
  Phone,
} from 'lucide-react';

interface ChatModalProps {
  bookingId: string;
  onClose: () => void;
}

export const ChatModal: React.FC<ChatModalProps> = ({ bookingId, onClose }) => {
  const { chatMessages, sendChatMessage, currentUser, bookings } = useMohalla();
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const booking = bookings.find((b) => b.id === bookingId);
  const relevantMessages = chatMessages.filter((m) => m.bookingId === bookingId);

  // Auto-scroll to bottom of conversation
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [relevantMessages.length]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    const role = currentUser.role === 'provider' ? 'provider' : 'customer';
    sendChatMessage(bookingId, inputText.trim(), role);
    setInputText('');
  };

  const quickChips = [
    'Assalam-o-Alaikum, I am at the gate.',
    'Please share your exact street number.',
    'I have switched off the main breaker.',
    'Kindly bring 2.5mm copper wire and fuse.',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 sm:p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full h-[600px] max-h-[90vh] shadow-2xl border border-slate-200 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center font-bold text-white text-base">
              {booking ? (currentUser.role === 'provider' ? booking.customerName.charAt(0) : booking.providerName.charAt(0)) : 'M'}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-bold text-sm text-white">
                  {booking ? (currentUser.role === 'provider' ? booking.customerName : booking.providerName) : 'Mohalla Service Chat'}
                </h3>
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
              </div>
              <p className="text-[11px] text-slate-300">
                Booking #{bookingId.slice(-6)} • {booking?.categoryName}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-white/10 text-slate-300 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Safety Banner */}
        <div className="p-2 px-4 bg-emerald-50 border-b border-emerald-100 flex items-center gap-2 text-[11px] text-emerald-800 shrink-0 font-medium">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
          <span>Keep all conversations and pricing agreements inside Mohalla for protection.</span>
        </div>

        {/* Message Thread */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50">
          {relevantMessages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400 text-xs">
              <MessageSquare className="w-10 h-10 text-slate-300 mb-2" />
              <p className="font-bold text-slate-600">Start Direct Chat</p>
              <p className="mt-1">
                Coordinate exact address, gate directions, and tools needed.
              </p>
            </div>
          ) : (
            relevantMessages.map((msg) => {
              const isMe =
                (currentUser.role === 'provider' && msg.senderRole === 'provider') ||
                (currentUser.role !== 'provider' && msg.senderRole === 'customer');

              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-xs shadow-2xs leading-relaxed ${
                      isMe
                        ? 'bg-emerald-700 text-white rounded-br-xs'
                        : 'bg-white text-slate-800 border border-slate-200/80 rounded-bl-xs'
                    }`}
                  >
                    <p>{msg.text}</p>
                    <div
                      className={`text-[9px] mt-1 flex items-center justify-end gap-1 ${
                        isMe ? 'text-emerald-200' : 'text-slate-400'
                      }`}
                    >
                      <span>
                        {new Date(msg.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                      {isMe && <CheckCheck className="w-3 h-3" />}
                    </div>
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-3 py-1.5 bg-white border-t border-slate-100 flex items-center gap-1.5 overflow-x-auto shrink-0">
          {quickChips.map((chip, idx) => (
            <button
              key={idx}
              onClick={() => setInputText(chip)}
              className="text-[11px] px-2.5 py-1 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 whitespace-nowrap cursor-pointer transition-colors"
            >
              {chip}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <form
          onSubmit={handleSend}
          className="p-3 bg-white border-t border-slate-200 flex items-center gap-2 shrink-0"
        >
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Type a message (English / Roman Urdu)..."
            className="flex-1 p-2.5 px-4 rounded-xl border border-slate-300 focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 text-xs text-slate-800 outline-hidden"
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="p-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white disabled:opacity-40 cursor-pointer transition-all"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
