import React, { useEffect, useState } from 'react';
import { X, EyeOff, ShieldAlert, Loader2 } from 'lucide-react';
import { Message } from '../../types';
import { getSecureMediaUrl } from '../../services/storageService';
import { markViewOnceViewed } from '../../services/chatService';

type ViewOnceModalProps = {
  message: Message | null;
  onClose: () => void;
};

export const ViewOnceModal: React.FC<ViewOnceModalProps> = ({ message, onClose }) => {
  const [mediaUrl, setMediaUrl] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!message || !message.media_path) return;

    let isMounted = true;
    setLoading(true);

    getSecureMediaUrl(message.media_path)
      .then((url) => {
        if (isMounted) {
          setMediaUrl(url);
          setLoading(false);
        }
      })
      .catch(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [message]);

  if (!message) return null;

  const handleClose = async () => {
    // Immediately burn / mark viewed in database
    await markViewOnceViewed(message.id).catch(() => {});
    onClose();
  };

  const isVideo = message.mime_type?.startsWith('video/') || message.file_name?.endsWith('.mp4');

  return (
    <div
      id="view-once-modal-backdrop"
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/95 backdrop-blur-xl p-4 animate-in fade-in"
    >
      {/* Top Bar */}
      <div className="w-full max-w-2xl flex items-center justify-between pb-4 text-white z-10">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
            <EyeOff className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-semibold">View Once Media</h3>
            <p className="text-[11px] text-neutral-400">This media will be deleted once closed</p>
          </div>
        </div>

        <button
          id="btn-close-view-once"
          onClick={handleClose}
          className="p-2 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-colors"
          title="Close and destroy"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Media Canvas */}
      <div className="relative w-full max-w-2xl max-h-[75vh] flex items-center justify-center overflow-hidden rounded-2xl bg-neutral-900/50 border border-neutral-800">
        {loading ? (
          <div className="p-12 flex flex-col items-center space-y-3 text-neutral-400">
            <Loader2 className="w-8 h-8 animate-spin text-emerald-500" />
            <span className="text-xs">Decrypting private media...</span>
          </div>
        ) : mediaUrl ? (
          isVideo ? (
            <video
              src={mediaUrl}
              controls
              autoPlay
              playsInline
              className="max-w-full max-h-[70vh] object-contain rounded-xl"
            />
          ) : (
            <img
              src={mediaUrl}
              alt="View once"
              className="max-w-full max-h-[70vh] object-contain select-none pointer-events-none rounded-xl"
            />
          )
        ) : (
          <div className="p-12 text-center text-red-400 text-xs flex items-center space-x-2">
            <ShieldAlert className="w-5 h-5" />
            <span>Could not load private media. It may have expired or been deleted.</span>
          </div>
        )}
      </div>

      {/* Bottom notification */}
      <div className="mt-4 text-center">
        <button
          id="btn-dismiss-view-once"
          onClick={handleClose}
          className="px-6 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold rounded-full border border-neutral-700 transition-colors"
        >
          Done & Mark as Opened
        </button>
      </div>
    </div>
  );
};
