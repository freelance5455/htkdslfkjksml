import React, { useState, useEffect } from 'react';
import { Lock, Unlock, Smartphone, ShieldCheck } from 'lucide-react';

interface ScreenLockModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ScreenLockModal: React.FC<ScreenLockModalProps> = ({ isOpen, onClose }) => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    if (!isOpen) return;

    // Vibrate device if supported
    if ('vibrate' in navigator) {
      try {
        navigator.vibrate([100, 50, 100]);
      } catch {}
    }

    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, [isOpen]);

  if (!isOpen) return null;

  const handleUnlock = () => {
    onClose();
  };

  const formattedTime = time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const formattedDate = time.toLocaleDateString([], {
    weekday: 'long',
    month: 'short',
    day: 'numeric',
  });

  return (
    <div
      id="device-screen-lock-overlay"
      className="fixed inset-0 z-50 bg-black text-white flex flex-col items-center justify-between p-8 select-none backdrop-blur-3xl animate-in fade-in duration-300"
    >
      {/* Top Status */}
      <div className="flex items-center gap-2 text-xs text-neutral-400">
        <Lock className="w-4 h-4 text-emerald-400" />
        <span>Secure Screen Lock & Sleep Mode</span>
      </div>

      {/* Center Clock & Date */}
      <div className="text-center space-y-2 mt-12">
        <div className="text-6xl sm:text-7xl font-light tracking-tight font-mono">{formattedTime}</div>
        <div className="text-sm sm:text-base text-neutral-400 font-medium">{formattedDate}</div>

        <div className="mt-6 max-w-sm mx-auto p-3.5 rounded-xl bg-neutral-900/90 border border-neutral-800 text-left text-xs text-neutral-300 space-y-1.5 shadow-2xl">
          <div className="flex items-center gap-2 font-semibold text-emerald-400">
            <Smartphone className="w-4 h-4" />
            <span>Screen Protection Active</span>
          </div>
          <p className="text-[11px] text-neutral-400 leading-relaxed">
            Screen WakeLock released and display dimmed in accordance with device security sandbox. Tap the button below to resume your session.
          </p>
        </div>
      </div>

      {/* Unlock Area */}
      <div className="w-full max-w-xs space-y-4 mb-8">
        <button
          id="btn-unlock-screen"
          onClick={handleUnlock}
          className="w-full py-4 px-6 rounded-2xl bg-white text-black font-semibold text-sm hover:bg-neutral-200 transition-all flex items-center justify-center gap-2 shadow-2xl active:scale-95"
        >
          <Unlock className="w-4 h-4" />
          <span>Tap to Unlock</span>
        </button>

        <p className="text-center text-[10px] text-neutral-500">
          Click or tap to return to AI Assistant
        </p>
      </div>
    </div>
  );
};
