import React, { useState } from 'react';
import { Smile, Sparkles, Search } from 'lucide-react';

type StickerEmojiPickerProps = {
  isOpen: boolean;
  onSelectEmoji: (emoji: string) => void;
  onSelectSticker: (stickerEmoji: string, label: string) => void;
  onClose: () => void;
};

const EMOJI_CATEGORIES: Record<string, string[]> = {
  'Popular': ['😀', '😂', '😍', '🥰', '😎', '🔥', '👍', '❤️', '🎉', '✨', '🙌', '🙏', '💯', '🤔', '😊', '🥳'],
  'Smileys': ['😃', '😄', '😁', '😆', '😅', '🤣', '😉', '😇', '😋', '😜', '🤪', '🤩', '😏', '😌', '🤤', '😴', '😷', '🤒', '🤕', '🤢', '🤮', '🤧', '🥵', '🥶', '🥴', '😵', '🤯', '🤠', '🥳', '😎'],
  'Gestures': ['👍', '👎', '👌', '✌️', '🤞', '🤟', '🤘', '🤙', '👈', '👉', '👆', '👇', '☝️', '✋', '🤚', '🖐️', '🖖', '👋', '🤝', '👏', '🙌', '👐', '🤲', '🙏'],
  'Hearts': ['❤️', '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔', '❣️', '💕', '💞', '💓', '💗', '💖', '💘', '💝'],
  'Objects': ['⭐', '🌟', '💫', '⚡', '🔥', '💥', '✨', '🎉', '🎊', '🎁', '🏆', '🎯', '🚀', '🔒', '🛡️', '💎'],
};

const STICKER_PACK = [
  { emoji: '🚀', label: 'Blast Off!' },
  { emoji: '🔥', label: 'Lit!' },
  { emoji: '🎉', label: 'Celebrate!' },
  { emoji: '💯', label: '100% Truth' },
  { emoji: '❤️', label: 'Big Love' },
  { emoji: '🙌', label: 'High Praise' },
  { emoji: '✨', label: 'Pure Magic' },
  { emoji: '😎', label: 'Too Cool' },
  { emoji: '⭐', label: 'Super Star' },
  { emoji: '🏆', label: 'Winner!' },
  { emoji: '🤝', label: 'Deal Done' },
  { emoji: '🛡️', label: 'Top Secret' },
];

export const StickerEmojiPicker: React.FC<StickerEmojiPickerProps> = ({
  isOpen,
  onSelectEmoji,
  onSelectSticker,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'emoji' | 'sticker'>('emoji');
  const [selectedCategory, setSelectedCategory] = useState('Popular');
  const [search, setSearch] = useState('');

  if (!isOpen) return null;

  return (
    <div className="absolute bottom-16 right-4 sm:right-12 z-50 w-72 sm:w-80 bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in slide-in-from-bottom-2">
      {/* Tab bar */}
      <div className="p-2 border-b border-neutral-800 flex items-center justify-between bg-neutral-950/60">
        <div className="flex items-center space-x-1">
          <button
            type="button"
            onClick={() => setActiveTab('emoji')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-colors ${
              activeTab === 'emoji'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Smile className="w-3.5 h-3.5" />
            <span>Emojis</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('sticker')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-colors ${
              activeTab === 'sticker'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Stickers</span>
          </button>
        </div>
      </div>

      {activeTab === 'emoji' ? (
        <div className="flex flex-col h-64">
          {/* Categories bar */}
          <div className="flex items-center space-x-1 px-3 py-2 border-b border-neutral-800/60 overflow-x-auto text-xs">
            {Object.keys(EMOJI_CATEGORIES).map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-colors whitespace-nowrap ${
                  selectedCategory === cat
                    ? 'bg-emerald-600/20 text-emerald-400 font-bold'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Emoji Grid */}
          <div className="flex-1 overflow-y-auto p-3 grid grid-cols-6 gap-1.5 select-none">
            {EMOJI_CATEGORIES[selectedCategory]?.map((emo, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => onSelectEmoji(emo)}
                className="h-10 text-xl flex items-center justify-center rounded-xl hover:bg-neutral-800 transition-all hover:scale-125 cursor-pointer"
              >
                {emo}
              </button>
            ))}
          </div>
        </div>
      ) : (
        /* Stickers Grid */
        <div className="h-64 overflow-y-auto p-3 grid grid-cols-3 gap-2.5 select-none">
          {STICKER_PACK.map((stk, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => onSelectSticker(stk.emoji, stk.label)}
              className="p-3 bg-neutral-950 hover:bg-neutral-800/80 border border-neutral-800/80 rounded-2xl flex flex-col items-center justify-center space-y-1 transition-all hover:scale-105 active:scale-95 cursor-pointer group"
            >
              <span className="text-3xl group-hover:animate-bounce">{stk.emoji}</span>
              <span className="text-[10px] text-neutral-400 font-medium group-hover:text-emerald-400">
                {stk.label}
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
