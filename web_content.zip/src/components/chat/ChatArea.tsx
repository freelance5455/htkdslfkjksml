import React, { useState, useEffect, useRef } from 'react';
import {
  Phone,
  Video,
  MoreVertical,
  Search,
  Send,
  Paperclip,
  Smile,
  Mic,
  MicOff,
  Trash2,
  X,
  Check,
  CheckCheck,
  Reply,
  Copy,
  Edit2,
  Share2,
  Star,
  Info,
  Download,
  Eye,
  EyeOff,
  ArrowLeft,
  ChevronDown,
  Loader2,
  StopCircle,
  Users,
} from 'lucide-react';
import { ConversationWithDetails, Message, Profile, MessageReaction } from '../../types';
import { useAuth } from '../../contexts/AuthContext';
import { usePresence } from '../../contexts/PresenceContext';
import { useCall } from '../../contexts/CallContext';
import {
  getMessages,
  sendMessage,
  editMessage,
  deleteMessageForMe,
  deleteMessageForEveryone,
  addReaction,
  removeReaction,
  toggleStarMessage,
  markMessagesRead,
  markMessageDelivered,
  clearChatForMe,
  clearChatForAll,
  deleteChatForMe,
  setDisappearingDuration,
  setAutoDeleteChatDuration,
  setChatWallpaper,
  toggleChatPin,
  toggleChatMute,
  reportUserOrMessage,
} from '../../services/chatService';
import { blockUser } from '../../services/friendService';
import { uploadChatMedia, getSecureMediaUrl } from '../../services/storageService';
import { supabase } from '../../lib/supabase';
import { ChatMenuModal } from './ChatMenuModal';
import { SharedMediaModal } from './SharedMediaModal';
import { ViewOnceModal } from './ViewOnceModal';
import { ForwardModal } from './ForwardModal';
import { StickerEmojiPicker } from './StickerEmojiPicker';
import { GroupInfoModal } from './GroupInfoModal';
import { ConfirmationDialog } from '../common/ConfirmationDialog';

type ChatAreaProps = {
  conversation: ConversationWithDetails;
  onBackMobile: () => void;
  onConversationUpdated: () => void;
  onOpenProfile: (user: Profile) => void;
};

export const ChatArea: React.FC<ChatAreaProps> = ({
  conversation,
  onBackMobile,
  onConversationUpdated,
  onOpenProfile,
}) => {
  const { user } = useAuth();
  const { isUserOnline, typingUsersByConv, setTypingState } = usePresence();
  const { startCall } = useCall();

  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [inputText, setInputText] = useState('');
  const [searchInChat, setSearchInChat] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Modals and menus
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSharedMediaOpen, setIsSharedMediaOpen] = useState(false);
  const [viewOnceTarget, setViewOnceTarget] = useState<Message | null>(null);
  const [forwardTarget, setForwardTarget] = useState<Message | null>(null);
  const [infoMessageTarget, setInfoMessageTarget] = useState<Message | null>(null);

  // Group Info
  const [showGroupInfoModal, setShowGroupInfoModal] = useState(false);

  // Replying & Editing
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [editingMessage, setEditingMessage] = useState<Message | null>(null);

  // Multi-select state
  const [isMultiSelect, setIsMultiSelect] = useState(false);
  const [selectedMessageIds, setSelectedMessageIds] = useState<Set<string>>(new Set());

  // Confirmations
  const [deleteConfirmTarget, setDeleteConfirmTarget] = useState<{
    msgId: string;
    mode: 'me' | 'everyone';
  } | null>(null);

  // Attachments and View-Once
  const [isViewOnceSelected, setIsViewOnceSelected] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [isUploading, setIsUploading] = useState(false);

  // Voice recording
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [voiceSeconds, setVoiceSeconds] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const voiceChunksRef = useRef<Blob[]>([]);
  const voiceTimerRef = useRef<any>(null);

  // Message container ref
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const currentUserId = user?.id || '';
  const otherUser = conversation.otherUser;
  const isOnline = isUserOnline(otherUser.id);
  const isTyping = typingUsersByConv[conversation.id]?.has(otherUser.id);

  // Load messages
  const loadMessages = async () => {
    if (!currentUserId) return;
    try {
      const data = await getMessages(conversation.id, currentUserId, conversation.clearedAt);
      setMessages(data);
      // Mark as read
      await markMessagesRead(conversation.id, currentUserId);
    } catch (err) {
      console.error('Failed to load messages:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setLoading(true);
    loadMessages();

    // Supabase Realtime subscription for new/updated messages
    const channel = supabase
      .channel(`chat-room-${conversation.id}`)
      .on('broadcast', { event: 'new_message' }, ({ payload }) => {
        if (!payload) return;
        // Check if user deleted this message locally
        let deletedMsgIds: string[] = [];
        try {
          const raw = localStorage.getItem(`nexa_deleted_msgs_${currentUserId}`);
          if (raw) deletedMsgIds = JSON.parse(raw);
        } catch {}
        if (deletedMsgIds.includes(payload.id)) return;

        setMessages((prev) => {
          if (prev.some((m) => m.id === payload.id)) return prev;
          return [...prev, payload];
        });
        onConversationUpdated();

        // If from other user, confirm delivery and mark read
        if (payload.sender_id !== currentUserId) {
          markMessageDelivered(payload.id, conversation.id, currentUserId);
          markMessagesRead(conversation.id, currentUserId);
        }
      })
      .on('broadcast', { event: 'message_delivered' }, ({ payload }) => {
        if (!payload) return;
        setMessages((prev) =>
          prev.map((m) => {
            if (m.id === payload.messageId || (!payload.messageId && m.sender_id === currentUserId)) {
              return { ...m, delivered_at: m.delivered_at || payload.deliveredAt || new Date().toISOString() };
            }
            return m;
          })
        );
      })
      .on('broadcast', { event: 'chat_updated' }, () => {
        loadMessages();
        onConversationUpdated();
      })
      .on('broadcast', { event: 'auto_delete_chat_updated' }, () => {
        loadMessages();
        onConversationUpdated();
      })
      .on('broadcast', { event: 'disappearing_duration_updated' }, () => {
        loadMessages();
        onConversationUpdated();
      })
      .on('broadcast', { event: 'chat_cleared_for_all' }, () => {
        loadMessages();
        onConversationUpdated();
      })
      .on('broadcast', { event: 'reaction_updated' }, () => {
        loadMessages();
      })
      .on('broadcast', { event: 'messages_read' }, () => {
        setMessages((prev) =>
          prev.map((m) => (m.sender_id === currentUserId ? { ...m, read_at: new Date().toISOString(), delivered_at: m.delivered_at || new Date().toISOString() } : m))
        );
      })
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'messages',
          filter: `conversation_id=eq.${conversation.id}`,
        },
        () => {
          loadMessages();
          onConversationUpdated();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'message_reactions',
        },
        () => {
          loadMessages();
        }
      )
      .subscribe();

    return () => {
      channel.unsubscribe();
    };
  }, [conversation.id, currentUserId, conversation.clearedAt]);

  // Scroll to bottom on new messages
  useEffect(() => {
    if (!searchInChat) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages.length, searchInChat]);

  // Handle typing indicator
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputText(e.target.value);
    setTypingState(conversation.id, e.target.value.length > 0);
  };

  // Send message
  const handleSendMessage = async () => {
    if (!inputText.trim() || !currentUserId) return;

    if (editingMessage) {
      // Edit mode
      await editMessage(editingMessage.id, currentUserId, inputText.trim(), conversation.id);
      setEditingMessage(null);
      setInputText('');
      setTypingState(conversation.id, false);
      loadMessages();
      return;
    }

    const textToSend = inputText.trim();
    setInputText('');
    setTypingState(conversation.id, false);

    try {
      await sendMessage({
        conversationId: conversation.id,
        senderId: currentUserId,
        content: textToSend,
        type: 'text',
        replyToId: replyingTo?.id,
        disappearingDuration: conversation.disappearingDuration,
      });

      setReplyingTo(null);
      await loadMessages();
      onConversationUpdated();
    } catch (err) {
      console.error('Error sending message:', err);
      alert('Could not send message. Please check your connection.');
    }
  };

  // File Upload Handler
  const handleFileUpload = async (file: File, type: 'image' | 'video' | 'file') => {
    if (!currentUserId) return;
    setIsUploading(true);
    setShowAttachMenu(false);

    try {
      const { mediaPath } = await uploadChatMedia(conversation.id, file, file.name);

      await sendMessage({
        conversationId: conversation.id,
        senderId: currentUserId,
        content: file.name,
        type,
        fileName: file.name,
        fileSize: file.size,
        mimeType: file.type,
        mediaPath,
        isViewOnce: isViewOnceSelected,
        replyToId: replyingTo?.id,
        disappearingDuration: conversation.disappearingDuration,
      });

      setIsViewOnceSelected(false);
      setReplyingTo(null);
      await loadMessages();
      onConversationUpdated();
    } catch (err: any) {
      console.error('File upload failed:', err);
      alert(err.message || 'Failed to upload media.');
    } finally {
      setIsUploading(false);
    }
  };

  // Voice Note Recording
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      voiceChunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) voiceChunksRef.current.push(e.data);
      };

      recorder.start(200);
      setIsRecordingVoice(true);
      setVoiceSeconds(0);

      voiceTimerRef.current = setInterval(() => {
        setVoiceSeconds((prev) => prev + 1);
      }, 1000);
    } catch (err) {
      alert('Microphone permission required to record voice notes.');
    }
  };

  const stopAndSendRecording = async () => {
    if (!mediaRecorderRef.current) return;
    clearInterval(voiceTimerRef.current);

    mediaRecorderRef.current.onstop = async () => {
      const audioBlob = new Blob(voiceChunksRef.current, { type: 'audio/webm' });
      setIsRecordingVoice(false);
      setIsUploading(true);

      try {
        const fileName = `voice_${Date.now()}.webm`;
        const { mediaPath } = await uploadChatMedia(conversation.id, audioBlob, fileName);

        await sendMessage({
          conversationId: conversation.id,
          senderId: currentUserId,
          content: 'Voice Note',
          type: 'voice',
          fileName,
          fileSize: audioBlob.size,
          mimeType: 'audio/webm',
          mediaPath,
          disappearingDuration: conversation.disappearingDuration,
        });

        loadMessages();
        onConversationUpdated();
      } catch (err) {
        console.error('Voice send error:', err);
      } finally {
        setIsUploading(false);
      }

      // Stop mic tracks
      mediaRecorderRef.current?.stream.getTracks().forEach((t) => t.stop());
    };

    mediaRecorderRef.current.stop();
  };

  const cancelRecording = () => {
    clearInterval(voiceTimerRef.current);
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stream.getTracks().forEach((t) => t.stop());
      mediaRecorderRef.current = null;
    }
    voiceChunksRef.current = [];
    setIsRecordingVoice(false);
    setVoiceSeconds(0);
  };

  // Emoji Reaction Toggle
  const handleToggleReaction = async (msgId: string, emoji: string) => {
    const msg = messages.find((m) => m.id === msgId);
    const existing = msg?.reactions?.find((r) => r.user_id === currentUserId && r.emoji === emoji);

    if (existing) {
      await removeReaction(msgId, currentUserId, conversation.id);
    } else {
      await addReaction(msgId, currentUserId, emoji, conversation.id);
    }
    loadMessages();
  };

  // Multi-select actions
  const toggleSelectMessage = (msgId: string) => {
    setSelectedMessageIds((prev) => {
      const next = new Set(prev);
      if (next.has(msgId)) next.delete(msgId);
      else next.add(msgId);
      return next;
    });
  };

  const handleDeleteSelected = async (mode: 'me' | 'everyone') => {
    for (const msgId of selectedMessageIds) {
      if (mode === 'me') {
        await deleteMessageForMe(msgId, currentUserId);
      } else {
        await deleteMessageForEveryone(msgId, currentUserId, conversation.id);
      }
    }
    setSelectedMessageIds(new Set());
    setIsMultiSelect(false);
    loadMessages();
    onConversationUpdated();
  };

  const allSelectedAreMine = Array.from(selectedMessageIds).every((id) => {
    const msg = messages.find((m) => m.id === id);
    return msg?.sender_id === currentUserId;
  });

  const filteredMessages = searchInChat && searchQuery.trim()
    ? messages.filter((m) => m.content.toLowerCase().includes(searchQuery.toLowerCase()))
    : messages;

  return (
    <div id="chat-area-container" className="h-full flex flex-col bg-neutral-950 text-white relative select-none">
      {/* Hidden file inputs */}
      <input
        type="file"
        ref={fileInputRef}
        className="hidden"
        onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'file')}
      />
      <input
        type="file"
        ref={imageInputRef}
        accept="image/*"
        className="hidden"
        onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'image')}
      />
      <input
        type="file"
        ref={videoInputRef}
        accept="video/*"
        className="hidden"
        onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0], 'video')}
      />

      {/* Header */}
      <div className="h-16 px-4 bg-neutral-900/90 border-b border-neutral-800 flex items-center justify-between backdrop-blur-md shrink-0 z-20">
        <div className="flex items-center space-x-3">
          {/* Mobile Back Button */}
          <button
            id="btn-chat-back-mobile"
            onClick={onBackMobile}
            className="md:hidden p-1.5 -ml-1 text-neutral-400 hover:text-white rounded-lg"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          {/* Avatar */}
          <div
            className="relative cursor-pointer"
            onClick={() => (conversation.type === 'group' ? setShowGroupInfoModal(true) : onOpenProfile(otherUser))}
          >
            <div
              className={`w-10 h-10 rounded-full border border-neutral-700/80 overflow-hidden flex items-center justify-center font-bold text-neutral-200 ${
                conversation.type === 'group' ? 'bg-emerald-950/60 text-emerald-400' : 'bg-neutral-800'
              }`}
            >
              {conversation.type === 'group' ? (
                <Users className="w-5 h-5" />
              ) : otherUser.avatar_url ? (
                <img src={otherUser.avatar_url} alt={otherUser.display_name} className="w-full h-full object-cover" />
              ) : (
                otherUser.display_name.charAt(0).toUpperCase()
              )}
            </div>
            {isOnline && conversation.type !== 'group' && (
              <div className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-500 border-2 border-neutral-900" />
            )}
          </div>

          {/* User or Group Details */}
          <div
            className="cursor-pointer"
            onClick={() => (conversation.type === 'group' ? setShowGroupInfoModal(true) : onOpenProfile(otherUser))}
          >
            <h3 className="text-sm font-semibold text-neutral-100 flex items-center space-x-2">
              <span>{conversation.type === 'group' ? conversation.name || 'Group Chat' : otherUser.display_name}</span>
            </h3>
            <p className="text-[11px] text-neutral-400">
              {conversation.type === 'group' ? (
                <span>{conversation.members?.length || 0} participants • Tap for info</span>
              ) : isTyping ? (
                <span className="text-emerald-400 font-medium animate-pulse">Typing...</span>
              ) : isOnline ? (
                <span className="text-emerald-400">Online</span>
              ) : (
                <span>@{otherUser.username}</span>
              )}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center space-x-1">
          {conversation.type !== 'group' && (
            <>
              <button
                id="btn-call-voice"
                onClick={() => startCall(otherUser, 'voice')}
                className="p-2 text-neutral-300 hover:text-emerald-400 rounded-xl hover:bg-neutral-800 transition-colors"
                title="Voice Call"
              >
                <Phone className="w-5 h-5" />
              </button>

              <button
                id="btn-call-video"
                onClick={() => startCall(otherUser, 'video')}
                className="p-2 text-neutral-300 hover:text-emerald-400 rounded-xl hover:bg-neutral-800 transition-colors"
                title="Video Call"
              >
                <Video className="w-5 h-5" />
              </button>
            </>
          )}

          <button
            id="btn-search-toggle"
            onClick={() => setSearchInChat(!searchInChat)}
            className={`p-2 rounded-xl transition-colors ${
              searchInChat ? 'text-emerald-400 bg-neutral-800' : 'text-neutral-300 hover:text-white hover:bg-neutral-800'
            }`}
            title="Search in conversation"
          >
            <Search className="w-5 h-5" />
          </button>

          <button
            id="btn-chat-menu"
            onClick={() => setIsMenuOpen(true)}
            className="p-2 text-neutral-300 hover:text-white rounded-xl hover:bg-neutral-800 transition-colors"
            title="More options"
          >
            <MoreVertical className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* In-Chat Search Bar */}
      {searchInChat && (
        <div className="px-4 py-2 bg-neutral-900 border-b border-neutral-800 flex items-center space-x-2 animate-in slide-in-from-top-2">
          <Search className="w-4 h-4 text-neutral-500" />
          <input
            type="text"
            placeholder="Search messages in this chat..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1 bg-transparent text-xs text-white placeholder-neutral-500 focus:outline-none"
            autoFocus
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="text-neutral-500 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      )}

      {/* Multi-select bar */}
      {isMultiSelect && (
        <div className="px-4 py-2.5 bg-neutral-900/95 border-b border-neutral-800 flex items-center justify-between text-xs text-white z-20">
          <span className="font-semibold text-neutral-300">{selectedMessageIds.size} selected</span>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => handleDeleteSelected('me')}
              disabled={selectedMessageIds.size === 0}
              className="px-3 py-1 bg-neutral-800 hover:bg-neutral-700 disabled:opacity-40 rounded-lg text-neutral-300"
            >
              Delete for me
            </button>
            {allSelectedAreMine && (
              <button
                onClick={() => handleDeleteSelected('everyone')}
                disabled={selectedMessageIds.size === 0}
                className="px-3 py-1 bg-red-600 hover:bg-red-500 disabled:opacity-40 rounded-lg text-white font-medium"
              >
                Delete for everyone
              </button>
            )}
            <button
              onClick={() => {
                setIsMultiSelect(false);
                setSelectedMessageIds(new Set());
              }}
              className="px-2 py-1 text-neutral-400 hover:text-white"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {loading ? (
          <div className="py-20 flex flex-col items-center justify-center space-y-2 text-neutral-500">
            <Loader2 className="w-6 h-6 animate-spin text-emerald-500" />
            <span className="text-xs">Decrypting chat...</span>
          </div>
        ) : filteredMessages.length === 0 ? (
          <div className="py-20 text-center text-xs text-neutral-500 space-y-1">
            <p>No messages here yet.</p>
            <p className="text-[11px] text-neutral-600">Say hello to @{otherUser.username} 👋</p>
          </div>
        ) : (
          filteredMessages.map((msg) => {
            const isMe = msg.sender_id === currentUserId;
            const isSelected = selectedMessageIds.has(msg.id);

            return (
              <div
                key={msg.id}
                id={`msg-bubble-${msg.id}`}
                className={`flex items-end space-x-2 group ${isMe ? 'justify-end' : 'justify-start'}`}
              >
                {isMultiSelect && (
                  <button
                    onClick={() => toggleSelectMessage(msg.id)}
                    className={`w-4 h-4 rounded-full border mb-1 flex items-center justify-center transition-colors ${
                      isSelected ? 'bg-emerald-600 border-emerald-600 text-white' : 'border-neutral-600'
                    }`}
                  >
                    {isSelected && <Check className="w-3 h-3" />}
                  </button>
                )}

                {/* Message Bubble */}
                <div
                  className={`max-w-[78%] sm:max-w-md rounded-2xl p-3 shadow-md relative ${
                    isMe
                      ? 'bg-emerald-700 text-white rounded-br-xs'
                      : 'bg-neutral-800 text-neutral-100 rounded-bl-xs border border-neutral-700/60'
                  }`}
                >
                  {/* Reply preview if replying to another message */}
                  {msg.reply_to_id && (
                    <div className="mb-2 px-2.5 py-1.5 rounded-lg bg-black/20 border-l-3 border-emerald-400 text-xs">
                      <p className="text-[10px] text-emerald-300 font-semibold">Replying</p>
                      <p className="text-neutral-300 truncate">Reply Target</p>
                    </div>
                  )}

                  {/* Message Content rendering based on type */}
                  {msg.is_deleted_everyone ? (
                    <p className="text-xs italic text-neutral-300/80 flex items-center space-x-1.5">
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>This message was deleted</span>
                    </p>
                  ) : msg.is_view_once ? (
                    <div className="space-y-1.5">
                      {msg.viewed_at ? (
                        <div className="flex items-center space-x-2 text-xs text-neutral-300/80 italic py-1">
                          <EyeOff className="w-4 h-4" />
                          <span>View once media (Opened)</span>
                        </div>
                      ) : (
                        <button
                          onClick={() => setViewOnceTarget(msg)}
                          className="flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-black/30 hover:bg-black/40 text-xs text-white font-medium border border-white/10 transition-colors"
                        >
                          <Eye className="w-4 h-4 text-emerald-300" />
                          <span>Open View Once Media</span>
                        </button>
                      )}
                    </div>
                  ) : msg.type === 'image' && msg.media_path ? (
                    <MediaImageBubble mediaPath={msg.media_path} fileName={msg.file_name} />
                  ) : msg.type === 'video' && msg.media_path ? (
                    <MediaVideoBubble mediaPath={msg.media_path} />
                  ) : msg.type === 'file' && msg.media_path ? (
                    <MediaFileBubble
                      mediaPath={msg.media_path}
                      fileName={msg.file_name}
                      fileSize={msg.file_size}
                    />
                  ) : msg.type === 'voice' && msg.media_path ? (
                    <MediaVoiceBubble mediaPath={msg.media_path} />
                  ) : (
                    <p className="text-xs sm:text-sm leading-relaxed whitespace-pre-wrap break-words select-text">
                      {msg.content}
                    </p>
                  )}

                  {/* Footer metadata: Time, edited, ticks */}
                  <div className="flex items-center justify-end space-x-1.5 mt-1 text-[10px] text-neutral-300/80">
                    {msg.is_edited && <span className="italic">edited</span>}
                    <span>
                      {new Date(msg.created_at).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true })}
                    </span>

                    {/* WhatsApp-style ticks for sender */}
                    {isMe && (
                      <span title={msg.read_at ? 'Read' : msg.delivered_at ? 'Delivered' : 'Sent'}>
                        {msg.read_at ? (
                          <CheckCheck className="w-3.5 h-3.5 text-cyan-300" />
                        ) : msg.delivered_at ? (
                          <CheckCheck className="w-3.5 h-3.5 text-neutral-300" />
                        ) : (
                          <Check className="w-3.5 h-3.5 text-neutral-300" />
                        )}
                      </span>
                    )}
                  </div>

                  {/* Emoji Reactions List */}
                  {msg.reactions && msg.reactions.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      {msg.reactions.map((r) => (
                        <button
                          key={r.id}
                          onClick={() => handleToggleReaction(msg.id, r.emoji)}
                          className={`px-1.5 py-0.5 rounded-full text-[11px] flex items-center space-x-1 border ${
                            r.user_id === currentUserId
                              ? 'bg-emerald-500/30 border-emerald-400/60'
                              : 'bg-black/20 border-white/10'
                          }`}
                        >
                          <span>{r.emoji}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Hover Context Actions */}
                {!isMultiSelect && !msg.is_deleted_everyone && (
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center space-x-0.5 bg-neutral-900 border border-neutral-800 rounded-xl p-1 shadow-lg text-neutral-400">
                    <button
                      onClick={() => setReplyingTo(msg)}
                      className="p-1 hover:text-white hover:bg-neutral-800 rounded-lg"
                      title="Reply"
                    >
                      <Reply className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleToggleReaction(msg.id, '❤️')}
                      className="p-1 hover:text-white hover:bg-neutral-800 rounded-lg text-xs"
                      title="React ❤️"
                    >
                      ❤️
                    </button>
                    <button
                      onClick={() => handleToggleReaction(msg.id, '👍')}
                      className="p-1 hover:text-white hover:bg-neutral-800 rounded-lg text-xs"
                      title="React 👍"
                    >
                      👍
                    </button>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(msg.content);
                      }}
                      className="p-1 hover:text-white hover:bg-neutral-800 rounded-lg"
                      title="Copy"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setForwardTarget(msg)}
                      className="p-1 hover:text-white hover:bg-neutral-800 rounded-lg"
                      title="Forward"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={async () => {
                        await toggleStarMessage(msg.id, currentUserId, Boolean(msg.is_saved));
                        loadMessages();
                      }}
                      className={`p-1 rounded-lg ${msg.is_saved ? 'text-amber-400' : 'hover:text-white hover:bg-neutral-800'}`}
                      title={msg.is_saved ? 'Unstar' : 'Star'}
                    >
                      <Star className="w-3.5 h-3.5" />
                    </button>
                    {isMe && msg.type === 'text' && (
                      <button
                        onClick={() => {
                          setEditingMessage(msg);
                          setInputText(msg.content);
                        }}
                        className="p-1 hover:text-white hover:bg-neutral-800 rounded-lg"
                        title="Edit"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      onClick={() => setDeleteConfirmTarget({ msgId: msg.id, mode: 'me' })}
                      className="p-1 hover:text-red-400 hover:bg-neutral-800 rounded-lg"
                      title="Delete for me"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                    {isMe && (
                      <button
                        onClick={() => setDeleteConfirmTarget({ msgId: msg.id, mode: 'everyone' })}
                        className="p-1 hover:text-red-400 hover:bg-neutral-800 rounded-lg"
                        title="Delete for everyone"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-red-400" />
                      </button>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Reply or Edit preview banner */}
      {(replyingTo || editingMessage) && (
        <div className="px-4 py-2 bg-neutral-900 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-300">
          <div className="flex items-center space-x-2 truncate">
            {editingMessage ? (
              <>
                <Edit2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="truncate">Editing: {editingMessage.content}</span>
              </>
            ) : (
              <>
                <Reply className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="truncate">Replying to: {replyingTo?.content || 'Media'}</span>
              </>
            )}
          </div>
          <button
            onClick={() => {
              setReplyingTo(null);
              setEditingMessage(null);
              setInputText('');
            }}
            className="p-1 text-neutral-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Voice Recording Active Bar */}
      {isRecordingVoice ? (
        <div className="p-3 bg-neutral-900 border-t border-neutral-800 flex items-center justify-between text-white">
          <div className="flex items-center space-x-3">
            <div className="w-3 h-3 rounded-full bg-red-500 animate-ping" />
            <span className="text-xs font-mono text-red-400 font-semibold">
              Recording {Math.floor(voiceSeconds / 60).toString().padStart(2, '0')}:{(voiceSeconds % 60).toString().padStart(2, '0')}
            </span>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={cancelRecording}
              className="p-2 text-neutral-400 hover:text-red-400 rounded-xl hover:bg-neutral-800 transition-colors"
              title="Cancel recording"
            >
              <Trash2 className="w-5 h-5" />
            </button>
            <button
              onClick={stopAndSendRecording}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-xl flex items-center space-x-1.5 shadow-md shadow-emerald-950/40"
            >
              <Send className="w-4 h-4" />
              <span>Send Note</span>
            </button>
          </div>
        </div>
      ) : (
        /* Standard Message Composer */
        <div className="p-3 bg-neutral-900/90 border-t border-neutral-800 backdrop-blur-md relative z-20">
          {/* Attachment Popup Menu */}
          {showAttachMenu && (
            <div className="absolute bottom-16 left-4 bg-neutral-900 border border-neutral-800 rounded-2xl p-2 shadow-2xl space-y-1 text-xs text-neutral-200 animate-in zoom-in-95">
              <button
                onClick={() => imageInputRef.current?.click()}
                className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl hover:bg-neutral-800 text-left"
              >
                <span>📷 Photo</span>
              </button>
              <button
                onClick={() => videoInputRef.current?.click()}
                className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl hover:bg-neutral-800 text-left"
              >
                <span>🎥 Video</span>
              </button>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full flex items-center space-x-2.5 px-3 py-2 rounded-xl hover:bg-neutral-800 text-left"
              >
                <span>📎 Document / File</span>
              </button>
            </div>
          )}

          {/* Sticker & Emoji Picker */}
          <StickerEmojiPicker
            isOpen={showEmojiPicker}
            onClose={() => setShowEmojiPicker(false)}
            onSelectEmoji={(emoji) => {
              setInputText((prev) => prev + emoji);
              setShowEmojiPicker(false);
            }}
            onSelectSticker={async (stickerEmoji, label) => {
              setShowEmojiPicker(false);
              try {
                await sendMessage({
                  conversationId: conversation.id,
                  senderId: currentUserId,
                  content: `${stickerEmoji} ${label}`,
                  disappearingDuration: conversation.disappearingDuration,
                });
              } catch (err) {
                console.error('Failed to send sticker:', err);
              }
            }}
          />

          <div className="flex items-center space-x-2">
            {/* Attachment Button */}
            <button
              id="btn-attach-menu"
              type="button"
              onClick={() => setShowAttachMenu(!showAttachMenu)}
              className="p-2 text-neutral-400 hover:text-white rounded-xl hover:bg-neutral-800 transition-colors"
              title="Attach media or document"
            >
              <Paperclip className="w-5 h-5" />
            </button>

            {/* View Once Toggle Button */}
            <button
              id="btn-toggle-view-once"
              type="button"
              onClick={() => setIsViewOnceSelected(!isViewOnceSelected)}
              className={`p-2 rounded-xl text-xs font-bold transition-all border ${
                isViewOnceSelected
                  ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
                  : 'text-neutral-500 border-transparent hover:text-neutral-300 hover:bg-neutral-800'
              }`}
              title="View Once Media"
            >
              ①
            </button>

            {/* Emoji toggle */}
            <button
              id="btn-toggle-emoji"
              type="button"
              onClick={() => setShowEmojiPicker(!showEmojiPicker)}
              className="p-2 text-neutral-400 hover:text-white rounded-xl hover:bg-neutral-800 transition-colors"
              title="Emojis"
            >
              <Smile className="w-5 h-5" />
            </button>

            {/* Input field */}
            <input
              id="chat-message-input"
              type="text"
              placeholder="Type a private message..."
              value={inputText}
              onChange={handleInputChange}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              className="flex-1 px-4 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs sm:text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
            />

            {/* Voice Record or Send Button */}
            {inputText.trim() ? (
              <button
                id="btn-send-message"
                onClick={handleSendMessage}
                className="p-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl shadow-lg shadow-emerald-950/40 transition-transform active:scale-95"
                title="Send message"
              >
                <Send className="w-4 h-4" />
              </button>
            ) : (
              <button
                id="btn-voice-record"
                onClick={startRecording}
                className="p-2.5 text-neutral-400 hover:text-emerald-400 rounded-xl hover:bg-neutral-800 transition-colors"
                title="Record voice note"
              >
                <Mic className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Modals & Dialogs */}
      <ChatMenuModal
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        otherUser={otherUser}
        isMuted={conversation.isMuted}
        isPinned={conversation.isPinned}
        disappearingDuration={conversation.disappearingDuration}
        autoDeleteDuration={conversation.autoDeleteChatDuration || 'off'}
        wallpaper={conversation.wallpaper || 'default'}
        onToggleSearch={() => setSearchInChat(true)}
        onOpenSharedMedia={() => setIsSharedMediaOpen(true)}
        onToggleMute={async () => {
          await toggleChatMute(conversation.id, currentUserId, !conversation.isMuted);
          onConversationUpdated();
        }}
        onTogglePin={async () => {
          await toggleChatPin(conversation.id, currentUserId, !conversation.isPinned);
          onConversationUpdated();
        }}
        onSetDisappearing={async (dur) => {
          await setDisappearingDuration(conversation.id, currentUserId, dur);
          onConversationUpdated();
        }}
        onSetAutoDelete={async (dur) => {
          await setAutoDeleteChatDuration(conversation.id, currentUserId, dur);
          onConversationUpdated();
        }}
        onSetWallpaper={async (wp) => {
          await setChatWallpaper(conversation.id, currentUserId, wp);
          onConversationUpdated();
        }}
        onClearChat={async () => {
          await clearChatForMe(conversation.id, currentUserId);
          loadMessages();
          onConversationUpdated();
        }}
        onClearChatForAll={async () => {
          await clearChatForAll(conversation.id, currentUserId);
          loadMessages();
          onConversationUpdated();
        }}
        onDeleteChat={async () => {
          await deleteChatForMe(conversation.id, currentUserId);
          onBackMobile();
          onConversationUpdated();
        }}
        onBlockUser={async () => {
          await blockUser(currentUserId, otherUser.id);
          onBackMobile();
          onConversationUpdated();
        }}
        onReportUser={async (reason) => {
          await reportUserOrMessage({
            reporterId: currentUserId,
            reportedUserId: otherUser.id,
            reason,
          });
          alert('Report submitted. Thank you.');
        }}
        onViewProfile={() => onOpenProfile(otherUser)}
      />

      <GroupInfoModal
        isOpen={showGroupInfoModal}
        conversation={conversation}
        onClose={() => setShowGroupInfoModal(false)}
        onUpdated={() => {
          onConversationUpdated();
          loadMessages();
        }}
      />

      <SharedMediaModal
        isOpen={isSharedMediaOpen}
        onClose={() => setIsSharedMediaOpen(false)}
        messages={messages}
      />

      <ViewOnceModal
        message={viewOnceTarget}
        onClose={() => {
          setViewOnceTarget(null);
          loadMessages();
        }}
      />

      <ForwardModal
        isOpen={Boolean(forwardTarget)}
        message={forwardTarget}
        currentUserId={currentUserId}
        onClose={() => setForwardTarget(null)}
        onForwardSuccess={() => {
          alert('Message forwarded successfully.');
        }}
      />

      {/* Delete Confirmation */}
      <ConfirmationDialog
        isOpen={Boolean(deleteConfirmTarget)}
        title={deleteConfirmTarget?.mode === 'everyone' ? 'Delete for everyone?' : 'Delete for me?'}
        message={
          deleteConfirmTarget?.mode === 'everyone'
            ? 'This message will be removed for all members of this chat.'
            : 'This message will be removed from your chat history.'
        }
        confirmLabel="Delete"
        onConfirm={async () => {
          if (!deleteConfirmTarget) return;
          if (deleteConfirmTarget.mode === 'everyone') {
            await deleteMessageForEveryone(deleteConfirmTarget.msgId, currentUserId, conversation.id);
          } else {
            await deleteMessageForMe(deleteConfirmTarget.msgId, currentUserId);
          }
          setDeleteConfirmTarget(null);
          loadMessages();
          onConversationUpdated();
        }}
        onCancel={() => setDeleteConfirmTarget(null)}
      />
    </div>
  );
};

// Sub-components for media rendering
const MediaImageBubble: React.FC<{ mediaPath: string; fileName?: string | null }> = ({
  mediaPath,
  fileName,
}) => {
  const [url, setUrl] = useState('');
  useEffect(() => {
    getSecureMediaUrl(mediaPath).then(setUrl);
  }, [mediaPath]);

  if (!url) {
    return (
      <div className="w-48 h-36 bg-black/20 rounded-xl flex items-center justify-center">
        <Loader2 className="w-5 h-5 animate-spin text-neutral-400" />
      </div>
    );
  }

  return (
    <div className="rounded-xl overflow-hidden max-w-xs">
      <img src={url} alt={fileName || 'Photo'} className="w-full max-h-72 object-cover rounded-xl" />
    </div>
  );
};

const MediaVideoBubble: React.FC<{ mediaPath: string }> = ({ mediaPath }) => {
  const [url, setUrl] = useState('');
  useEffect(() => {
    getSecureMediaUrl(mediaPath).then(setUrl);
  }, [mediaPath]);

  if (!url) {
    return (
      <div className="w-48 h-36 bg-black/20 rounded-xl flex items-center justify-center">
        <Loader2 className="w-5 h-5 animate-spin text-neutral-400" />
      </div>
    );
  }

  return (
    <video src={url} controls playsInline className="w-full max-h-72 object-cover rounded-xl" />
  );
};

const MediaFileBubble: React.FC<{ mediaPath: string; fileName?: string | null; fileSize?: number | null }> = ({
  mediaPath,
  fileName,
  fileSize,
}) => {
  const [url, setUrl] = useState('');
  useEffect(() => {
    getSecureMediaUrl(mediaPath).then(setUrl);
  }, [mediaPath]);

  return (
    <div className="flex items-center space-x-3 p-2 bg-black/20 rounded-xl">
      <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-300 flex items-center justify-center shrink-0">
        <Download className="w-4 h-4" />
      </div>
      <div className="truncate flex-1">
        <p className="text-xs font-semibold truncate">{fileName || 'Document'}</p>
        <p className="text-[10px] text-neutral-400">
          {fileSize ? `${(fileSize / 1024).toFixed(1)} KB` : 'File'}
        </p>
      </div>
      {url && (
        <a
          href={url}
          download={fileName || 'file'}
          className="p-1.5 rounded-lg bg-black/30 hover:bg-black/50 text-white transition-colors"
        >
          <Download className="w-3.5 h-3.5" />
        </a>
      )}
    </div>
  );
};

const MediaVoiceBubble: React.FC<{ mediaPath: string }> = ({ mediaPath }) => {
  const [url, setUrl] = useState('');
  useEffect(() => {
    getSecureMediaUrl(mediaPath).then(setUrl);
  }, [mediaPath]);

  if (!url) {
    return (
      <div className="p-2 flex items-center space-x-2 text-xs text-neutral-400">
        <Loader2 className="w-4 h-4 animate-spin" />
        <span>Loading audio...</span>
      </div>
    );
  }

  return (
    <div className="p-1">
      <audio src={url} controls className="w-56 h-8 brightness-95" />
    </div>
  );
};
