import React, { useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import { CHARTS, TANKS, type TankId } from '../data/tankCharts';
import { formatNumber, getTankBounds } from '../utils/tankMath';

interface ChartViewerProps {
  initialTank?: TankId;
}

export const ChartViewer: React.FC<ChartViewerProps> = ({ initialTank = 'P-1' }) => {
  const [selectedTank, setSelectedTank] = useState<TankId>(initialTank);
  const [dipFilter, setDipFilter] = useState('');

  const bounds = getTankBounds(selectedTank);

  const rows = useMemo(() => {
    const chart = CHARTS[selectedTank];
    const q = dipFilter.trim();
    return bounds.keys
      .filter((mm) => (q === '' ? true : String(mm).includes(q)))
      .map((mm) => ({
        mm,
        liters: chart[String(mm)],
      }));
  }, [selectedTank, bounds.keys, dipFilter]);

  const getTankActiveClasses = () =>
    'bg-gradient-to-b from-[#0284c7] to-[#0369a1] text-white border border-[#0369a1] shadow-[0_3px_0_#0c4a6e,0_6px_14px_rgba(3,105,161,0.22)] active:shadow-[0_1px_0_#0c4a6e]';

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        {TANKS.map((tank) => (
          <button
            key={tank}
            type="button"
            onClick={() => setSelectedTank(tank)}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 cursor-pointer select-none transition-all duration-100 ease-out min-h-[40px] hover:-translate-y-[1px] active:translate-y-[2px] ${
              selectedTank === tank
                ? getTankActiveClasses()
                : 'bg-[#f8fafc] text-[#334155] border border-[#cbd5e1] shadow-[0_3px_0_#cbd5e1] hover:border-[#0284c7] hover:text-[#0f172a] hover:bg-white active:shadow-[0_1px_0_#cbd5e1]'
            }`}
          >
            {tank}
          </button>
        ))}
      </div>

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2.5 border-b border-[#e2e8f0]">
        <div className="text-xs text-[#475569]">
          <span className="font-bold text-[#0f172a]">{selectedTank}</span>
          <span className="mx-2 text-[#cbd5e1]">·</span>
          <span>
            Dip {bounds.minMm}–{bounds.maxMm} mm (10 mm step)
          </span>
          <span className="mx-2 text-[#cbd5e1]">·</span>
          <span className="text-[#0369a1] font-semibold">
            Max {formatNumber(bounds.maxLiters)} L
          </span>
        </div>

        <div className="relative w-full sm:w-52">
          <Search className="w-4 h-4 text-[#64748b] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            inputMode="numeric"
            value={dipFilter}
            onChange={(e) => setDipFilter(e.target.value)}
            placeholder="Filter mm (e.g. 1250)"
            aria-label="Filter calibration chart by dip in mm"
            className="w-full min-h-[40px] pl-9 pr-3 py-2 text-sm font-mono-tabular bg-[#f8fafc] text-[#0f172a] border border-[#cbd5e1] rounded-lg focus:outline-none focus:bg-white focus:border-[#0284c7] focus:ring-2 focus:ring-[#0284c7]/15"
          />
        </div>
      </div>

      <div className="max-h-[420px] overflow-y-auto rounded-xl border border-[#cbd5e1] bg-white">
        <table className="w-full border-collapse text-sm">
          <thead className="sticky top-0 bg-[#f1f5f9] border-b border-[#cbd5e1] text-xs text-[#475569]">
            <tr>
              <th className="text-left font-semibold py-2.5 px-4">Sounding Dip (mm)</th>
              <th className="text-right font-semibold py-2.5 px-4">Volume (Liters)</th>
              <th className="text-right font-semibold py-2.5 px-4">Capacity (%)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#e2e8f0]">
            {rows.length === 0 ? (
              <tr>
                <td colSpan={3} className="py-8 text-center text-xs text-[#64748b]">
                  No calibration entries match &ldquo;{dipFilter}&rdquo;.
                </td>
              </tr>
            ) : (
              rows.map((row) => {
                const pct = (row.liters / bounds.maxLiters) * 100;
                return (
                  <tr key={row.mm} className="odd:bg-[#f8fafc] hover:bg-[#e0f2fe]/55 transition-colors">
                    <td className="py-2 px-4 font-mono-tabular font-medium text-[#0f172a]">
                      {row.mm} mm
                    </td>
                    <td className="py-2 px-4 text-right font-mono-tabular font-bold text-[#0369a1]">
                      {formatNumber(row.liters)} L
                    </td>
                    <td className="py-2 px-4 text-right font-mono-tabular text-xs text-[#475569]">
                      {pct.toFixed(1)}%
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
