import React from 'react';
import { X, BookOpen, Sparkles, Send } from 'lucide-react';

interface UtaraDictionaryDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onUseWord: (word: string) => void;
}

const UTARA_WORDS = [
  { word: 'Hang / Cek', meaning: 'Awak (Hang) / Saya (Cek)', example: 'Hang nak pi mana tu cek oi?' },
  { word: 'Depa', meaning: 'Mereka', example: 'Depa dok sembang apa kat luaq tu?' },
  { word: 'Habaq', meaning: 'Beritahu / Cerita', example: 'Habaq mai sat pasai apa hang lambat?' },
  { word: 'Awat / Pasai pa', meaning: 'Kenapa / Mengapa', example: 'Awat hang monyok ja hari ni?' },
  { word: 'Lagu tu / Lagu ni', meaning: 'Macam tu / Macam ni', example: 'Jangan buat lagu tu, tak elok.' },
  { word: 'Ketegaq', meaning: 'Degil / Keras kepala', example: 'Ketegaq sungguh budak ni, suruh tidoq tak mau!' },
  { word: 'Ceriat', meaning: 'Kemas / Bersih / Cantik rapi', example: 'Baju raya hang nampak ceriat sungguh.' },
  { word: 'Berlemun', meaning: 'Basah berpeluh / Berminyak', example: 'Panas lit-lit sampai berlemun dahi.' },
  { word: 'Segak', meaning: 'Kacak / Bergaya / Elok', example: 'Segak bak hang bila pakai baju Melayu.' },
  { word: 'Cemuih', meaning: 'Bosan / Jemu', example: 'Cemuih dah dok dengaq lagu yang sama ja.' },
  { word: 'Padu bak hang', meaning: 'Sangat mantap / Sedap gilerr', example: 'Kuah gulai kari ikan ni padu bak hang!' },
  { word: 'Satgi / Sat', meaning: 'Sebentar lagi / Sekejap', example: 'Tunggu sat, satgi aku sampai.' },
  { word: 'Gabra', meaning: 'Cemas / Panik', example: 'Relaks la, jangan gabra sangat!' },
  { word: 'Perabih', meaning: 'Habiskan licin', example: 'Nasi kandar sepinggan perabih teruih!' },
];

export const UtaraDictionaryDrawer: React.FC<UtaraDictionaryDrawerProps> = ({
  isOpen,
  onClose,
  onUseWord,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-sm animate-fade-in">
      <div 
        className="w-full max-w-md h-full bg-[#100624] border-l border-purple-900/50 flex flex-col shadow-2xl shadow-purple-950"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-purple-900/40 bg-purple-950/20 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-purple-600/30 border border-purple-500/30 flex items-center justify-center text-purple-300">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-white text-sm sm:text-base">Kamus Mini Loghat Utara</h3>
              <p className="text-[11px] text-purple-300">Kosa kata Kedah/Penang yang HANN AI faham</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-purple-900/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List of Words */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          <div className="p-3 rounded-xl bg-purple-900/20 border border-purple-500/20 text-xs text-purple-200 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-400 shrink-0" />
            <span>Klik butang hantar pada mana-mana perkataan untuk tanya HANN AI maksud atau bina ayat!</span>
          </div>

          {UTARA_WORDS.map((item, idx) => (
            <div
              key={idx}
              className="p-3.5 rounded-xl bg-[#170a30]/80 border border-purple-900/40 hover:border-purple-600/40 transition-all flex flex-col gap-1.5"
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-purple-200 text-sm">{item.word}</span>
                <button
                  onClick={() => {
                    onUseWord(`Tolong terangkan maksud perkataan loghat utara "${item.word}" dan bagi 3 contoh ayat sempoi.`);
                    onClose();
                  }}
                  className="flex items-center gap-1 text-[11px] font-semibold text-purple-300 hover:text-white bg-purple-900/40 hover:bg-purple-800/60 px-2 py-1 rounded-lg border border-purple-700/30 transition-all"
                  title="Tanya AI tentang perkataan ini"
                >
                  <Send className="w-3 h-3" />
                  <span>Tanya HANN</span>
                </button>
              </div>
              <p className="text-xs text-slate-300">
                <strong className="text-purple-300 font-medium">Maksud:</strong> {item.meaning}
              </p>
              <p className="text-[11px] text-slate-400 italic font-mono bg-black/30 p-1.5 rounded-md">
                "{item.example}"
              </p>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-purple-900/40 bg-[#090317] flex justify-end">
          <button
            onClick={onClose}
            className="w-full py-2 rounded-xl bg-purple-900/40 hover:bg-purple-800/50 text-xs font-semibold text-purple-200 border border-purple-700/40 transition-colors"
          >
            Tutup Kamus
          </button>
        </div>
      </div>
    </div>
  );
};
