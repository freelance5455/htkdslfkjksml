import React from 'react';
import { useGame } from '../context/GameContext.tsx';
import { Sparkles, Trophy, CheckCircle2 } from 'lucide-react';

export const LevelUpModal: React.FC = () => {
  const { levelUpData, closeLevelUpModal } = useGame();

  if (!levelUpData) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in zoom-in-95">
      <div className="bg-gradient-to-b from-stone-900 to-stone-950 border-4 border-amber-400 rounded-3xl max-w-sm w-full p-6 text-center shadow-2xl space-y-4 relative overflow-hidden">
        {/* Glow & Confetti Header */}
        <div className="absolute -top-12 -left-12 w-32 h-32 bg-amber-500/20 rounded-full blur-2xl"></div>
        <div className="absolute -bottom-12 -right-12 w-32 h-32 bg-emerald-500/20 rounded-full blur-2xl"></div>

        <div className="flex justify-center">
          <div className="relative p-4 bg-amber-500/20 rounded-full border-2 border-amber-400 animate-bounce">
            <Trophy className="w-10 h-10 text-amber-400" />
            <Sparkles className="w-5 h-5 text-amber-300 absolute -top-1 -right-1 animate-spin-slow" />
          </div>
        </div>

        <div>
          <span className="text-xs uppercase tracking-widest text-amber-400 font-black">Chúc Mừng Lên Cấp!</span>
          <h2 className="text-3xl font-black text-amber-300 mt-1">CẤP ĐỘ {levelUpData.newLevel}</h2>
          <p className="text-xs text-stone-300 mt-1">
            Nông trại của bạn đã phát triển lên một tầm cao mới!
          </p>
        </div>

        {/* Unlocked Features List */}
        {levelUpData.unlocks.length > 0 && (
          <div className="bg-stone-950/80 p-3 rounded-2xl border border-stone-800 text-left space-y-1.5 text-xs">
            <div className="font-bold text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-4 h-4" />
              <span>Tính Năng Mới Vừa Mở Khóa:</span>
            </div>
            {levelUpData.unlocks.map((u, idx) => (
              <div key={idx} className="text-stone-300 text-[11px] pl-3 border-l-2 border-emerald-500/60 font-medium">
                {u}
              </div>
            ))}
          </div>
        )}

        <button
          type="button"
          onClick={closeLevelUpModal}
          className="w-full py-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-stone-950 font-black rounded-2xl shadow-lg text-sm transition transform hover:scale-[1.02]"
        >
          ✨ Tiếp Tục Canh Tác
        </button>
      </div>
    </div>
  );
};
