import React from 'react';
import { Code2, FolderOpen } from 'lucide-react';
import { QUICK_ACTIONS } from '../constants/models';

interface EmptyWorkspaceProps {
  onSelectQuickAction: (prompt: string) => void;
  workspaceFileCount: number;
  onOpenWorkspace: () => void;
  desktopView: boolean;
}

export function EmptyWorkspace({
  onSelectQuickAction,
  workspaceFileCount,
  onOpenWorkspace,
  desktopView,
}: EmptyWorkspaceProps) {
  return (
    <div className="flex flex-1 flex-col items-center justify-center px-6 py-12 text-center">
      <div className="max-w-md w-full flex flex-col items-center">
        {/* Subtle centered MyCode badge */}
        <div
          className={`inline-flex items-center gap-2.5 rounded-2xl border border-[#E5E7EB] bg-white px-4 py-2.5 shadow-[0_2px_10px_rgba(17,24,39,0.03)] ${
            desktopView ? 'mb-4' : 'mb-5'
          }`}
        >
          <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#111827] text-white">
            <Code2 className="h-4 w-4" />
          </span>
          <span className="font-display text-base font-bold tracking-tight text-[#111827]">
            MyCode
          </span>
        </div>

        <p className="text-[14px] leading-relaxed text-[#6B7280] max-w-sm">
          Personal AI coding workspace. Build multi-file projects, inspect code inline, and export
          anytime.
        </p>

        {/* Quick-action chips */}
        <div className="mt-7 flex flex-wrap items-center justify-center gap-2">
          {QUICK_ACTIONS.map((action) => (
            <button
              key={action.label}
              type="button"
              onClick={() => onSelectQuickAction(action.prompt)}
              className="min-h-[40px] rounded-xl border border-[#E5E7EB] bg-white px-3.5 py-2 text-[13px] font-medium text-[#111827] hover:bg-[#F9FAFB] hover:border-[#D1D5DB] active:scale-[0.98] transition-all whitespace-nowrap shrink-0"
            >
              {action.label}
            </button>
          ))}
        </div>

        {workspaceFileCount > 0 && (
          <button
            type="button"
            onClick={onOpenWorkspace}
            className="mt-6 inline-flex items-center gap-2 text-[13px] font-medium text-[#4B5563] hover:text-[#111827] transition-colors"
          >
            <FolderOpen className="h-4 w-4" />
            <span>
              View {workspaceFileCount} workspace {workspaceFileCount === 1 ? 'file' : 'files'}
            </span>
          </button>
        )}
      </div>
    </div>
  );
}
