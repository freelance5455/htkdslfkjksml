import React, { useState } from 'react';
import { Bot, Check, Copy, Link2, LogOut, Play, Trash2, UserPlus } from 'lucide-react';
import type { PublicRoomState, RoomSettings } from '../shared/unoTypes';
import { PlayerAvatar } from './PlayerAvatar';

interface LobbyRoomProps {
  room: PublicRoomState;
  onAddBot: () => void;
  onAddHuman?: (name?: string) => void;
  onRenamePlayer?: (targetId: string, newName: string) => void;
  onRemovePlayer: (targetId: string) => void;
  onUpdateSettings: (settings: Partial<RoomSettings>) => void;
  onStartGame: () => void;
  onLeaveRoom: () => void;
}

export const LobbyRoom: React.FC<LobbyRoomProps> = ({
  room,
  onAddBot,
  onAddHuman,
  onRenamePlayer,
  onRemovePlayer,
  onUpdateSettings,
  onStartGame,
  onLeaveRoom,
}) => {
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const isOffline = room.code === 'OFFLINE';
  const me = room.players.find((p) => p.id === room.myId);
  const isHost = Boolean(me?.isHost) || isOffline;
  const emptySeats = Math.max(0, 6 - room.players.length);

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(room.code);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 1800);
    } catch {
      // ignore clipboard errors
    }
  };

  const handleCopyLink = async () => {
    try {
      const url = `${window.location.origin}${window.location.pathname}?room=${room.code}`;
      await navigator.clipboard.writeText(url);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 1800);
    } catch {
      // ignore clipboard errors
    }
  };

  return (
    <div className="relative min-h-dvh w-full overflow-y-auto bg-stone-950 flex flex-col">
      {/* Felt background */}
      <div className="fixed inset-0 pointer-events-none">
        <img
          src="/src/assets/images/table_felt_light_1795173543278.jpg"
          alt="Meja Ari Uno"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover opacity-50"
        />
        <div className="absolute inset-0 bg-stone-950/75" />
      </div>

      {/* Top Bar */}
      <header className="relative z-10 flex items-center justify-between gap-4 px-6 sm:px-10 py-5 border-b border-white/10">
        <div className="flex items-center gap-3">
          <span className="font-display text-xl font-extrabold text-white whitespace-nowrap">
            Ari Uno
          </span>
          <span className="text-stone-500" aria-hidden="true">·</span>
          <span className="text-sm text-stone-300 whitespace-nowrap">
            {isOffline ? 'Mabar Offline (1 Perangkat)' : 'Ruang Mabar Online'}
          </span>
        </div>

        <button
          type="button"
          onClick={onLeaveRoom}
          className="h-10 px-4 rounded-lg bg-stone-900 hover:bg-stone-800 border border-white/15 text-stone-200 text-sm font-medium flex items-center gap-2 transition-colors whitespace-nowrap cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>Keluar</span>
        </button>
      </header>

      {/* Main Lobby Content */}
      <main className="relative z-10 flex-1 w-full max-w-4xl mx-auto px-6 py-8 flex flex-col gap-6">
        {/* Room Code & Invite Strip (Online) OR Offline Pass-and-Play Banner */}
        {isOffline ? (
          <section className="rounded-2xl bg-stone-900/90 border border-white/15 p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <p className="text-xs font-medium text-amber-300">Mode Pass &amp; Play · Tanpa Internet</p>
              <h1 className="font-display text-2xl font-bold text-white">
                Mabar Bergantian di 1 Perangkat
              </h1>
              <p className="text-xs sm:text-sm text-stone-300">
                Tambahkan 2–6 teman (atau campur dengan Bot AI). Layar penutup rahasia otomatis menjaga kartu tiap pemain tetap aman.
              </p>
            </div>
            <span className="text-xs text-stone-400 font-mono-tabular shrink-0">
              {room.players.length}/6 Pemain
            </span>
          </section>
        ) : (
          <section className="rounded-2xl bg-stone-900/90 border border-white/15 p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <p className="text-xs font-medium text-stone-400">Kode Room Mabar</p>
              <div className="flex items-center gap-3">
                <span className="font-mono-tabular text-3xl sm:text-4xl font-bold tracking-[0.2em] text-amber-300">
                  {room.code}
                </span>
                <span className="text-xs text-stone-400 font-mono-tabular">
                  {room.players.length}/6 Pemain
                </span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={handleCopyCode}
                className="h-11 px-4 rounded-xl bg-stone-800 hover:bg-stone-700 border border-white/10 text-stone-100 text-sm font-medium flex items-center gap-2 transition-colors whitespace-nowrap cursor-pointer"
              >
                {copiedCode ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-stone-300" />}
                <span>{copiedCode ? 'Kode Tersalin' : 'Salin Kode'}</span>
              </button>
              <button
                type="button"
                onClick={handleCopyLink}
                className="h-11 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold flex items-center gap-2 transition-colors whitespace-nowrap cursor-pointer"
              >
                {copiedLink ? <Check className="w-4 h-4" /> : <Link2 className="w-4 h-4" />}
                <span>{copiedLink ? 'Link Tersalin' : 'Salin Link Undangan'}</span>
              </button>
            </div>
          </section>
        )}

        {/* 6-Seat Table Grid */}
        <section className="space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="font-display text-lg font-bold text-white">Daftar Pemain di Meja</h2>
            {isHost && room.players.length < 6 && (
              <div className="flex items-center gap-2">
                {isOffline && onAddHuman && (
                  <button
                    type="button"
                    onClick={() => onAddHuman()}
                    className="h-10 px-3.5 rounded-lg bg-amber-400/15 hover:bg-amber-400/25 border border-amber-400/40 text-amber-200 text-sm font-medium flex items-center gap-2 transition-colors whitespace-nowrap cursor-pointer"
                  >
                    <UserPlus className="w-4 h-4" />
                    <span>Tambah Teman</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={onAddBot}
                  className="h-10 px-3.5 rounded-lg bg-stone-800 hover:bg-stone-700 border border-white/15 text-sky-300 text-sm font-medium flex items-center gap-2 transition-colors whitespace-nowrap cursor-pointer"
                >
                  <Bot className="w-4 h-4" />
                  <span>Tambah Bot AI</span>
                </button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {room.players.map((p) => {
              const isMe = p.id === room.myId;
              return (
                <div
                  key={p.id}
                  className={`rounded-xl p-4 border flex items-center justify-between gap-3 ${
                    isMe
                      ? 'bg-stone-800/90 border-amber-400/50'
                      : 'bg-stone-900/85 border-white/12'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <PlayerAvatar avatar={p.avatar} isBot={p.isBot} size="md" />
                    <div className="min-w-0 flex-1">
                      {isOffline && onRenamePlayer && !p.isBot ? (
                        <input
                          type="text"
                          maxLength={18}
                          value={p.name}
                          onChange={(e) => onRenamePlayer(p.id, e.target.value)}
                          aria-label={`Ubah nama ${p.name}`}
                          className="w-full bg-stone-950/70 border border-white/15 rounded-md px-2 py-1 text-sm font-semibold text-white focus:outline-none focus:ring-2 focus:ring-amber-400"
                        />
                      ) : (
                        <p className="font-semibold text-sm text-white truncate">
                          {p.name}
                        </p>
                      )}
                      <p className="text-xs text-stone-400 mt-0.5">
                        {p.isHost ? 'Tuan Rumah' : p.isBot ? 'Bot AI' : p.connected ? 'Siap Main' : 'Terputus'}
                        {!isOffline && isMe ? ' · Kamu' : ''}
                      </p>
                    </div>
                  </div>

                  {isHost && !p.isHost && (
                    <button
                      type="button"
                      onClick={() => onRemovePlayer(p.id)}
                      className="w-9 h-9 rounded-lg flex items-center justify-center text-stone-400 hover:text-rose-400 hover:bg-rose-950/50 transition-colors shrink-0 cursor-pointer"
                      aria-label={`Keluarkan ${p.name}`}
                      title={`Keluarkan ${p.name}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              );
            })}

            {Array.from({ length: emptySeats }).map((_, idx) => (
              <div
                key={`empty-${idx}`}
                className="rounded-xl p-4 border border-dashed border-white/15 bg-stone-900/40 flex items-center justify-between text-stone-500"
              >
                <span className="text-sm">Kursi Kosong</span>
                {isHost && (
                  <div className="flex items-center gap-1">
                    {isOffline && onAddHuman && (
                      <button
                        type="button"
                        onClick={() => onAddHuman()}
                        className="text-xs font-medium text-amber-300 hover:text-amber-200 px-2 py-1.5 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
                      >
                        + Teman
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={onAddBot}
                      className="text-xs font-medium text-sky-400 hover:text-sky-300 px-2 py-1.5 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
                    >
                      + Bot
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>

        {/* Match Settings & Start CTA */}
        <section className="rounded-2xl bg-stone-900/90 border border-white/15 p-5 sm:p-6 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="flex flex-wrap items-center gap-6">
            <div className="space-y-1.5">
              <p className="text-xs font-medium text-stone-400">Mode Skor</p>
              <div className="flex items-center gap-1 p-1 rounded-lg bg-stone-950 border border-white/10">
                <button
                  type="button"
                  disabled={!isHost}
                  onClick={() => onUpdateSettings({ targetScore: 0 })}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    room.settings.targetScore === 0
                      ? 'bg-stone-800 text-white'
                      : 'text-stone-400 hover:text-stone-200'
                  } ${isHost ? 'cursor-pointer' : 'cursor-default'}`}
                >
                  1 Ronde Cepat
                </button>
                <button
                  type="button"
                  disabled={!isHost}
                  onClick={() => onUpdateSettings({ targetScore: 500 })}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    room.settings.targetScore === 500
                      ? 'bg-stone-800 text-white'
                      : 'text-stone-400 hover:text-stone-200'
                  } ${isHost ? 'cursor-pointer' : 'cursor-default'}`}
                >
                  Target 500 Poin
                </button>
              </div>
            </div>

            {!isOffline && (
              <div className="space-y-1.5">
                <p className="text-xs font-medium text-stone-400">Timer Giliran</p>
                <div className="flex items-center gap-1 p-1 rounded-lg bg-stone-950 border border-white/10">
                  <button
                    type="button"
                    disabled={!isHost}
                    onClick={() => onUpdateSettings({ turnSeconds: 25 })}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                      room.settings.turnSeconds > 0
                        ? 'bg-stone-800 text-white'
                        : 'text-stone-400 hover:text-stone-200'
                    } ${isHost ? 'cursor-pointer' : 'cursor-default'}`}
                  >
                    25 Detik
                  </button>
                  <button
                    type="button"
                    disabled={!isHost}
                    onClick={() => onUpdateSettings({ turnSeconds: 0 })}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                      room.settings.turnSeconds === 0
                        ? 'bg-stone-800 text-white'
                        : 'text-stone-400 hover:text-stone-200'
                    } ${isHost ? 'cursor-pointer' : 'cursor-default'}`}
                  >
                    Santai (Tanpa Timer)
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="shrink-0">
            {isHost ? (
              <button
                type="button"
                disabled={room.players.length < 2}
                onClick={onStartGame}
                className="w-full md:w-auto h-12 px-7 rounded-xl bg-amber-400 hover:bg-amber-300 disabled:opacity-45 text-stone-950 font-display font-bold text-base flex items-center justify-center gap-2 transition-colors shadow-lg cursor-pointer whitespace-nowrap"
              >
                <Play className="w-5 h-5 fill-current" />
                <span>Mulai Permainan</span>
              </button>
            ) : (
              <p className="text-sm text-stone-300 font-medium">
                Menunggu Tuan Rumah memulai permainan...
              </p>
            )}
          </div>
        </section>
      </main>
    </div>
  );
};
