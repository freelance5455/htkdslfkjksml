import { useEffect, useState } from "react";
import { Area, AreaChart, ResponsiveContainer, YAxis } from "recharts";
import type { RateSample } from "@/lib/miner/engine";

export function HashChart({ data }: { data: RateSample[] }) {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  if (!ready || data.length < 2) {
    return (
      <div className="flex h-24 items-center border border-muted/25 bg-bg px-3 font-mono text-xs text-muted">
        Trace arms once the rig is hashing
      </div>
    );
  }
  return (
    <div className="h-24 w-full min-w-0 border border-muted/25 bg-bg" role="img" aria-label="Hashrate over recent seconds">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 0, left: 0, bottom: 0 }}>
          <YAxis hide domain={[0, "auto"]} />
          <Area
            type="monotone"
            dataKey="hps"
            stroke="var(--color-brass)"
            fill="var(--color-brass)"
            fillOpacity={0.16}
            strokeWidth={1.5}
            isAnimationActive={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
