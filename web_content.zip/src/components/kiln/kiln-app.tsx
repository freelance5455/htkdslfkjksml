import { useEffect, useRef, useState } from "react";
import { Cpu, Power } from "lucide-react";
import { HashChart } from "@/components/kiln/hash-chart";
import { shortId, BLOCK_REWARD } from "@/lib/miner/chain";
import { EMPTY_SNAPSHOT, MinerEngine, type Snapshot } from "@/lib/miner/engine";

const QUICK = ["status", "balance", "ledger", "job", "diff", "help"] as const;

function formatRate(hps: number): string {
  if (hps >= 1_000_000) return `${(hps / 1_000_000).toFixed(2)} MH/s`;
  if (hps >= 1000) return `${(hps / 1000).toFixed(1)} kH/s`;
  return `${Math.round(hps)} H/s`;
}

function formatUptime(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = s % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return h > 0 ? `${h}:${pad(m)}:${pad(r)}` : `${pad(m)}:${pad(r)}`;
}

function clock(t: number): string {
  if (!t) return "--:--:--";
  const d = new Date(t);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

function formatInt(n: number): string {
  return new Intl.NumberFormat("en-US").format(n);
}

export function KilnApp() {
  const engineRef = useRef<MinerEngine | null>(null);
  const logRef = useRef<HTMLDivElement | null>(null);
  const stickRef = useRef(true);
  const historyRef = useRef<string[]>([]);
  const histIdx = useRef(-1);
  const [snap, setSnap] = useState<Snapshot>(EMPTY_SNAPSHOT);
  const [draft, setDraft] = useState("");
  const [dirty, setDirty] = useState(false);
  const [walletError, setWalletError] = useState("");
  const [line, setLine] = useState("");
  const [armReset, setArmReset] = useState(false);

  useEffect(() => {
    let frame = 0;
    let pending = false;
    const engine = new MinerEngine(() => {
      if (pending) return;
      pending = true;
      frame = requestAnimationFrame(() => {
        pending = false;
        setSnap(engine.snapshot());
      });
    });
    engineRef.current = engine;
    engine.boot();
    setSnap(engine.snapshot());
    return () => {
      cancelAnimationFrame(frame);
      engine.destroy();
      engineRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!dirty) setDraft(snap.wallet);
  }, [snap.wallet, dirty]);

  useEffect(() => {
    const el = logRef.current;
    if (!el || !stickRef.current) return;
    el.scrollTop = el.scrollHeight;
  }, [snap.logs]);

  function commitWallet(): boolean {
    const engine = engineRef.current;
    if (!engine) return false;
    const ok = engine.setWallet(draft);
    if (!ok) {
      setWalletError("Use 8–90 letters, numbers, colon, underscore, or hyphen.");
      return false;
    }
    setWalletError("");
    setDirty(false);
    return true;
  }

  function toggleRig() {
    const engine = engineRef.current;
    if (!engine) return;
    if (snap.running) {
      engine.stop();
      return;
    }
    if (dirty && !commitWallet()) return;
    engine.start();
  }

  function runLine(value: string) {
    const engine = engineRef.current;
    if (!engine) return;
    const trimmed = value.trim();
    if (!trimmed) return;
    historyRef.current.push(trimmed);
    if (historyRef.current.length > 40) historyRef.current.shift();
    histIdx.current = -1;
    engine.exec(trimmed);
  }

  const live = snap.running
    ? `Hashing. Height ${snap.height}. Balance ${snap.balance} LODE.`
    : `Idle. Height ${snap.height}. Balance ${snap.balance} LODE.`;

  return (
    <div className="min-h-dvh bg-bg pb-24">
      <p className="sr-only" aria-live="polite">
        {live}
      </p>
      <header className="border-b border-muted/25">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-4 lg:px-6">
          <div>
            <h1 className="text-lg font-semibold tracking-widest">KILN</h1>
            <p className="font-mono text-xs text-muted">local stratum · sealed sandbox</p>
          </div>
          <div className="flex items-center gap-4 font-mono text-xs">
            <span className="text-muted">pool built-in · no server</span>
            <span className="flex items-center gap-2 text-fg">
              <span
                className={`size-2 rounded-full bg-brass ${snap.running ? "led-live" : "opacity-30"}`}
                aria-hidden
              />
              {snap.running ? "HASHING" : "IDLE"}
            </span>
          </div>
        </div>
      </header>

      <main className="mx-auto grid w-full max-w-6xl gap-4 px-4 py-4 lg:grid-cols-12 lg:px-6">
        <section className="flex min-w-0 flex-col gap-4 lg:col-span-5">
          <div className="border border-muted/25 bg-surface p-4">
            <label htmlFor="wallet" className="font-mono text-xs text-muted">
              Payout address
            </label>
            <div className="mt-2 flex gap-2">
              <input
                id="wallet"
                value={draft}
                autoCapitalize="off"
                autoCorrect="off"
                spellCheck={false}
                autoComplete="off"
                placeholder="lode1… or your own label"
                onChange={(event) => {
                  setDraft(event.target.value);
                  setDirty(true);
                  setWalletError("");
                }}
                className="h-11 min-w-0 flex-1 border border-muted/30 bg-bg px-3 font-mono text-sm text-fg"
              />
              <button
                type="button"
                onClick={commitWallet}
                className="h-11 shrink-0 border border-muted/30 bg-bg px-3 text-sm text-fg"
              >
                Set
              </button>
            </div>
            {walletError ? <p className="mt-2 text-sm text-fg">{walletError}</p> : null}
            <div className="mt-2 flex flex-wrap gap-2">
              <button
                type="button"
                className="h-11 border border-muted/30 bg-bg px-3 text-sm text-fg"
                onClick={() => {
                  const addr = engineRef.current?.mintWallet();
                  if (!addr) return;
                  setDraft(addr);
                  setDirty(false);
                  setWalletError("");
                }}
              >
                Mint address
              </button>
            </div>
            <p className="mt-4 font-mono text-3xl font-medium tabular-nums text-fg">
              {formatInt(snap.balance)}
              <span className="ml-2 text-base font-medium text-brass">LODE</span>
            </p>
            <p className="mt-2 text-sm text-pretty text-muted">
              LODE is credit on this browser’s ledger, not a mainnet coin. The address is only the payee
              written into each block.
            </p>
          </div>

          <div className="border border-muted/25 bg-surface p-4">
            <div className="flex items-center justify-between gap-3">
              <h2 className="flex items-center gap-2 text-sm font-semibold tracking-wide">
                <Cpu className="size-4 text-brass" aria-hidden />
                This machine
              </h2>
              <p className="font-mono text-xs text-muted">
                {snap.cores ? `${snap.cores} threads visible` : "cpu"}
              </p>
            </div>
            <p className="mt-3 font-mono text-3xl font-medium tabular-nums text-brass">{formatRate(snap.hps)}</p>
            <p className="mt-1 font-mono text-xs text-muted">
              {snap.lastShare ? `last share ${snap.lastShare}` : "double SHA-256 of an 80-byte header"}
            </p>
            <div className="mt-4">
              <HashChart data={snap.samples} />
            </div>
            <div className="mt-4 flex items-center gap-2">
              <button
                type="button"
                aria-label="Fewer workers"
                className="size-11 border border-muted/30 bg-bg font-mono text-lg text-fg disabled:opacity-40"
                disabled={snap.threads <= 1}
                onClick={() => engineRef.current?.setThreads(snap.threads - 1)}
              >
                −
              </button>
              <span className="w-8 text-center font-mono text-lg tabular-nums">{snap.threads}</span>
              <button
                type="button"
                aria-label="More workers"
                className="size-11 border border-muted/30 bg-bg font-mono text-lg text-fg disabled:opacity-40"
                disabled={snap.threads >= 4}
                onClick={() => engineRef.current?.setThreads(snap.threads + 1)}
              >
                +
              </button>
              <span className="text-sm text-muted">workers · cap 4</span>
            </div>
            <button
              type="button"
              onClick={toggleRig}
              aria-pressed={snap.running}
              className={
                snap.running
                  ? "mt-4 flex h-12 w-full items-center justify-center gap-2 border border-brass bg-transparent text-sm font-semibold tracking-widest text-brass"
                  : "mt-4 flex h-12 w-full items-center justify-center gap-2 bg-brass text-sm font-semibold tracking-widest text-bg"
              }
            >
              <Power className="size-4" aria-hidden />
              {snap.running ? "STOP RIG" : "START RIG"}
            </button>
            <p className="mt-3 text-sm text-pretty text-muted">
              Workers run only while the rig is on. The built-in pool checks every share itself, then pays{" "}
              {BLOCK_REWARD} LODE to the active address. Fee 0%.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-px bg-muted/25">
            <Stat label="Accepted" value={formatInt(snap.accepted)} />
            <Stat label="Rejected" value={formatInt(snap.rejected)} />
            <Stat label="Height" value={formatInt(snap.height)} />
            <Stat label="Block target" value={`${snap.blockBits} bits`} />
            <Stat label="Share target" value={`${snap.shareBits} bits`} />
            <Stat label="Uptime" value={formatUptime(snap.uptime)} />
          </div>
        </section>

        <section className="flex min-w-0 flex-col gap-4 lg:col-span-7">
          <div className="flex min-h-80 flex-col border border-muted/25 bg-surface">
            <div className="flex items-center justify-between gap-3 border-b border-muted/25 px-3 py-3">
              <h2 className="font-mono text-xs tracking-widest text-muted">KILN SHELL</h2>
              <p className="truncate font-mono text-xs text-muted">stratum+local://kiln</p>
            </div>
            <div
              ref={logRef}
              onScroll={() => {
                const el = logRef.current;
                if (!el) return;
                stickRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 28;
              }}
              className="h-80 overflow-y-auto px-3 py-3 font-mono text-xs leading-relaxed sm:text-sm lg:h-96"
            >
              {snap.logs.map((entry) => (
                <div key={entry.id} className="flex gap-3">
                  <span className="w-16 shrink-0 text-muted tabular-nums">{clock(entry.t)}</span>
                  <span
                    className={`w-10 shrink-0 ${entry.src === "cpu" || entry.tone === "block" ? "text-brass" : "text-muted"}`}
                  >
                    {entry.src}
                  </span>
                  <span
                    className={`min-w-0 flex-1 break-all ${entry.tone === "block" || entry.tone === "ok" ? "text-brass" : "text-fg"}`}
                  >
                    {entry.msg}
                  </span>
                </div>
              ))}
            </div>
            <div className="flex flex-wrap gap-2 border-t border-muted/25 px-3 py-3">
              {QUICK.map((cmd) => (
                <button
                  key={cmd}
                  type="button"
                  className="h-11 border border-muted/30 bg-bg px-3 font-mono text-xs text-fg"
                  onClick={() => runLine(cmd)}
                >
                  {cmd}
                </button>
              ))}
            </div>
            <form
              className="flex h-12 items-center gap-2 border-t border-muted/25 px-3"
              onSubmit={(event) => {
                event.preventDefault();
                runLine(line);
                setLine("");
              }}
            >
              <span className="font-mono text-sm text-brass" aria-hidden>
                {"kiln>"}
              </span>
              <input
                id="shell"
                value={line}
                onChange={(event) => setLine(event.target.value)}
                autoCapitalize="off"
                autoCorrect="off"
                spellCheck={false}
                autoComplete="off"
                aria-label="Shell command"
                className="min-w-0 flex-1 bg-transparent font-mono text-sm text-fg outline-none"
                onKeyDown={(event) => {
                  const hist = historyRef.current;
                  if (event.key === "ArrowUp") {
                    event.preventDefault();
                    if (!hist.length) return;
                    const next = histIdx.current < 0 ? hist.length - 1 : Math.max(0, histIdx.current - 1);
                    histIdx.current = next;
                    setLine(hist[next] ?? "");
                  } else if (event.key === "ArrowDown") {
                    event.preventDefault();
                    if (histIdx.current < 0) return;
                    const next = histIdx.current + 1;
                    if (next >= hist.length) {
                      histIdx.current = -1;
                      setLine("");
                    } else {
                      histIdx.current = next;
                      setLine(hist[next] ?? "");
                    }
                  }
                }}
              />
            </form>
          </div>

          <div className="border border-muted/25 bg-surface">
            <div className="flex items-center justify-between gap-3 border-b border-muted/25 px-4 py-3">
              <h2 className="text-sm font-semibold tracking-wide">Local chain</h2>
              <p className="font-mono text-xs text-muted">tip {snap.tip ? shortId(snap.tip, 8, 4) : "—"}</p>
            </div>
            <ul className="max-h-80 divide-y divide-muted/20 overflow-y-auto">
              {snap.chain.map((block) => (
                <li key={block.height} className="flex items-center gap-3 px-4 py-3">
                  <div className="min-w-0 flex-1">
                    <p className="font-mono text-sm text-fg">
                      <span className="text-brass">#{block.height}</span>
                      <span className="text-muted"> · </span>
                      {block.reward ? `+${block.reward} LODE` : "genesis"}
                      <span className="text-muted"> · </span>
                      {block.height === 0 ? "checkpoint" : `${block.bits} bits`}
                    </p>
                    <p className="truncate font-mono text-xs text-muted">
                      {block.hash.slice(0, 24)}… · {shortId(block.miner)}
                    </p>
                  </div>
                  <button
                    type="button"
                    className="h-11 shrink-0 border border-muted/30 bg-bg px-3 text-sm text-fg"
                    onClick={() => engineRef.current?.verify(block.height)}
                  >
                    Verify
                  </button>
                </li>
              ))}
            </ul>
            <div className="flex flex-wrap gap-2 border-t border-muted/25 px-4 py-3">
              {armReset ? (
                <>
                  <button
                    type="button"
                    className="h-11 border border-brass px-3 text-sm text-brass"
                    onClick={() => {
                      engineRef.current?.resetChain();
                      setArmReset(false);
                    }}
                  >
                    Confirm wipe
                  </button>
                  <button
                    type="button"
                    className="h-11 border border-muted/30 px-3 text-sm text-fg"
                    onClick={() => setArmReset(false)}
                  >
                    Cancel
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  className="h-11 border border-muted/30 px-3 text-sm text-muted"
                  onClick={() => setArmReset(true)}
                >
                  Reset chain
                </button>
              )}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-surface px-3 py-3">
      <div className="font-mono text-xs text-muted">{label}</div>
      <div className="mt-1 font-mono text-base tabular-nums text-fg">{value}</div>
    </div>
  );
}
