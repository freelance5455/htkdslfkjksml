import React from 'react';

interface ZahraHeaderLogoProps {
  className?: string;
}

export const ZahraHeaderLogo: React.FC<ZahraHeaderLogoProps> = ({ className = '' }) => {
  return (
    <div className={`flex items-center justify-center select-none ${className}`}>
      <div className="relative flex items-center justify-center gap-2">
        
        {/* Left Flourish & Heart */}
        <div className="hidden sm:flex items-center gap-1.5 opacity-90">
          <span className="text-rose-500 text-sm">💕</span>
          <svg className="w-12 h-4 text-purple-400" viewBox="0 0 50 16" fill="none">
            <path d="M48 8 C30 8 20 2 0 14" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
          </svg>
        </div>

        {/* Queen Silhouette in Lotus Flower + Calligraphy */}
        <div className="flex items-center gap-2">
          {/* Lotus Queen Emblem */}
          <div className="relative w-12 h-12 flex items-center justify-center">
            {/* Soft pink petal bloom behind */}
            <div className="absolute inset-0 bg-gradient-to-tr from-pink-400/40 via-purple-400/30 to-amber-300/30 rounded-full blur-md" />
            
            <svg viewBox="0 0 100 100" className="w-full h-full filter drop-shadow-[0_2px_6px_rgba(219,39,119,0.4)]" fill="none">
              <defs>
                <linearGradient id="queenGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#EC4899" />
                  <stop offset="50%" stopColor="#A855F7" />
                  <stop offset="100%" stopColor="#7E22CE" />
                </linearGradient>
                <linearGradient id="lotusGrad" x1="0%" y1="100%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#F472B6" />
                  <stop offset="50%" stopColor="#FB7185" />
                  <stop offset="100%" stopColor="#F43F5E" />
                </linearGradient>
                <linearGradient id="crownGradGold" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#FDE047" />
                  <stop offset="100%" stopColor="#EAB308" />
                </linearGradient>
              </defs>

              {/* Lotus Petals */}
              <path d="M50 85 C35 75 22 62 26 45 C34 48 42 58 50 85 Z" fill="url(#lotusGrad)" opacity="0.85" />
              <path d="M50 85 C65 75 78 62 74 45 C66 48 58 58 50 85 Z" fill="url(#lotusGrad)" opacity="0.85" />
              <path d="M50 88 C40 70 34 50 50 35 C66 50 60 70 50 88 Z" fill="#F43F5E" opacity="0.9" />

              {/* Floating Mini Hearts */}
              <path d="M22 28 C20 25 16 26 16 29 C16 34 22 38 22 38 C22 38 28 34 28 29 C28 26 24 25 22 28 Z" fill="#EC4899" />
              <path d="M78 28 C76 25 72 26 72 29 C72 34 78 38 78 38 C78 38 84 34 84 29 C84 26 80 25 78 28 Z" fill="#EC4899" />

              {/* Graceful Queen Profile Silhouette */}
              <path 
                d="M50 30 C56 30 61 35 60 42 C59 47 55 50 54 55 C53 58 55 62 58 65 C54 67 48 66 46 63 C44 59 45 54 47 50 C44 49 42 46 42 42 C42 35 45 30 50 30 Z" 
                fill="url(#queenGrad)" 
              />
              {/* Queen hair waves flowing left */}
              <path 
                d="M48 32 C42 35 38 42 39 50 C37 47 36 42 38 38 C40 34 44 32 48 32 Z" 
                fill="#9333EA" 
              />

              {/* Gold Crown on Queen's head */}
              <path 
                d="M47 24 L50 20 L53 24 L56 21 L55 26 L45 26 L44 21 Z" 
                fill="url(#crownGradGold)" 
              />
            </svg>
          </div>

          {/* Calligraphic Logo Text: زهرة شات */}
          <div className="relative flex items-center">
            {/* Mini golden crown above the letters */}
            <span className="absolute -top-3 right-8 text-amber-400 text-xs animate-bounce">
              👑
            </span>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-wide font-['Cairo'] flex items-center">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-700 via-fuchsia-600 to-pink-600 drop-shadow-sm">
                زهرة
              </span>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-600 to-purple-800 mr-1.5 drop-shadow-sm">
                شات
              </span>
            </h1>
          </div>
        </div>

        {/* Right Flourish & Heart */}
        <div className="hidden sm:flex items-center gap-1.5 opacity-90">
          <svg className="w-12 h-4 text-purple-400" viewBox="0 0 50 16" fill="none">
            <path d="M2 8 C20 8 30 2 50 14" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
          </svg>
          <span className="text-rose-500 text-sm">💕</span>
        </div>

      </div>
    </div>
  );
};
