import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  brier,
  computeOverRest,
  loadHistory,
  saveHistory,
  type HistoryItem,
} from "@/lib/history";
import { useAppStore } from "@/store/app-store";

function fromItems(n: number, control: boolean): HistoryItem[] {
  const all = useAppStore.getState().items;
  const source = control
    ? all.filter((it) => !it.pred.has || it.pred.level === "none").slice(0, n)
    : all.filter((it) => it.pred.has).slice(0, n);
  return source.map((it, idx) => ({
    id: Date.now() + idx,
    time: new Date().toISOString(),
    eventId: it.match.eventId,
    minute: it.match.minute,
    minuteDisplay: it.match.minuteDisplay,
    score: `${it.match.score.fullTime.home}–${it.match.score.fullTime.away}`,
    home: it.match.homeTeam.name,
    away: it.match.awayTeam.name,
    league: it.match.league,
    level: control ? "none" : it.pred.level,
    pOver05: it.pred.pAny != null ? it.pred.pAny / 100 : null,
    pOver15: (() => {
      const o = it.pred.ouLines.find((x) => x.line === 1.5)?.over;
      return o != null ? o / 100 : null;
    })(),
    pOver25: (() => {
      const o = it.pred.ouLines.find((x) => x.line === 2.5)?.over;
      return o != null ? o / 100 : null;
    })(),
    pBtts: it.pred.bttsYes != null ? it.pred.bttsYes / 100 : null,
    nextTeam: it.pred.predicted,
    nextProb: it.pred.probability / 100,
    control,
    result: null,
  }));
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-surface p-3 shadow-[var(--shadow-border)]">
      <div className="text-[10px] font-medium uppercase tracking-wide text-muted">{label}</div>
      <div className="mt-1 font-mono text-lg font-bold tabular-nums">{value}</div>
    </div>
  );
}

export function HistoryView() {
  const [rows, setRows] = useState<HistoryItem[]>([]);
  useEffect(() => {
    setRows(loadHistory());
  }, []);
  const refresh = () => setRows(loadHistory());

  const metrics = useMemo(() => {
    const scored = rows.filter((x) => x.result && x.pOver05 != null && !x.control);
    let hits = 0;
    const bs: number[] = [];
    scored.forEach((x) => {
      const y = computeOverRest(x) ?? 0;
      const p = x.pOver05 ?? 0.5;
      bs.push(brier(p, y));
      if (p >= 0.5 === !!y) hits++;
    });
    return {
      n: rows.length,
      resolved: scored.length,
      acc: scored.length ? `${((hits / scored.length) * 100).toFixed(0)}%` : "—",
      brier: bs.length ? (bs.reduce((s, v) => s + v, 0) / bs.length).toFixed(3) : "—",
    };
  }, [rows]);

  const saveTop = () => {
    const extra = fromItems(3, false);
    if (!extra.length) return;
    saveHistory([...loadHistory(), ...extra]);
    refresh();
  };
  const saveControl = () => {
    const extra = fromItems(3, true);
    if (!extra.length) return;
    saveHistory([...loadHistory(), ...extra]);
    refresh();
  };
  const record = (id: number) => {
    const raw = window.prompt("Resultado final (ex.: 2-1)");
    if (!raw) return;
    const m = raw.match(/(\d+)\s*[-–—:xX]\s*(\d+)/);
    if (!m) return;
    const next = loadHistory().map((x) =>
      x.id === id ? { ...x, result: { home: +m[1], away: +m[2] } } : x,
    );
    saveHistory(next);
    refresh();
  };
  const clear = () => {
    if (!window.confirm("Apagar o histórico?")) return;
    saveHistory([]);
    refresh();
  };

  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold tracking-tight">Histórico</h1>
          <p className="mt-1 text-sm text-muted">Guarda previsões, regista o resultado e mede Brier e acerto.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" onClick={saveTop}>Guardar top 3</Button>
          <Button size="sm" variant="ghost" onClick={saveControl}>Controlo</Button>
          <Button size="sm" variant="outline" onClick={clear}>Limpar</Button>
        </div>
      </div>
      <div className="mb-5 grid grid-cols-2 gap-2 sm:grid-cols-4">
        <Stat label="Guardadas" value={String(metrics.n)} />
        <Stat label="Resolvidas" value={String(metrics.resolved)} />
        <Stat label="Acerto O0.5" value={metrics.acc} />
        <Stat label="Brier" value={metrics.brier} />
      </div>
      {!rows.length ? (
        <div className="rounded-2xl bg-surface px-6 py-16 text-center text-sm text-muted shadow-[var(--shadow-border)]">
          Ainda sem previsões. Guarda o top 3 a partir dos jogos ao vivo.
        </div>
      ) : (
        <div className="overflow-x-auto rounded-2xl bg-surface shadow-[var(--shadow-border)]">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead className="text-[11px] uppercase tracking-wide text-subtle">
              <tr>
                <th className="px-3 py-3 font-medium">Jogo</th>
                <th className="px-3 py-3 font-medium">Min</th>
                <th className="px-3 py-3 font-medium">O0.5</th>
                <th className="px-3 py-3 font-medium">Resultado</th>
                <th className="px-3 py-3 font-medium"></th>
              </tr>
            </thead>
            <tbody>
              {rows
                .slice()
                .reverse()
                .slice(0, 40)
                .map((x) => {
                  const y = x.result && x.pOver05 != null ? computeOverRest(x) : null;
                  const hit = y != null && x.pOver05 != null ? x.pOver05 >= 0.5 === !!y : null;
                  return (
                    <tr key={x.id} className="border-t border-border">
                      <td className="px-3 py-2.5">
                        <div className="font-medium">
                          {x.home} {x.score} {x.away}
                        </div>
                        <div className="text-[11px] text-muted">
                          {x.league}
                          {x.control ? " · controlo" : ""}
                        </div>
                      </td>
                      <td className="px-3 py-2.5 font-mono tabular-nums text-muted">{x.minuteDisplay || "—"}</td>
                      <td className="px-3 py-2.5 font-mono tabular-nums">
                        {x.pOver05 != null ? `${Math.round(x.pOver05 * 100)}%` : "—"}
                      </td>
                      <td className="px-3 py-2.5 font-mono tabular-nums">
                        {x.result ? `${x.result.home}-${x.result.away}` : "Pendente"}
                        {hit === true ? " · ok" : hit === false ? " · miss" : ""}
                      </td>
                      <td className="px-3 py-2.5 text-right">
                        {!x.result ? (
                          <Button size="sm" variant="ghost" onClick={() => record(x.id)}>
                            Registar
                          </Button>
                        ) : null}
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
