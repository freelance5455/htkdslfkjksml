import { useRef, useState } from "react";
import { AlertCircle, Image as ImageIcon, Music2, Pause, Play, RefreshCw, Trash2, Upload } from "lucide-react";
import type { MediaKind } from "@/types";
import { useStudio } from "@/store/StudioContext";
import { formatDuration, formatBytes } from "@/data/defaults";
import { cn } from "@/utils/cn";

export function Waveform({ peaks, className, color = "#d9b65a" }: { peaks?: number[]; className?: string; color?: string }) {
  const values = peaks?.length ? peaks : Array.from({ length: 48 }, (_, i) => 0.18 + Math.abs(Math.sin(i * 1.7)) * 0.5);
  const width = 240;
  const height = 40;
  const barWidth = width / values.length;
  return (
    <svg viewBox={`0 0 ${width} ${height}`} className={cn("h-8 w-full", className)} preserveAspectRatio="none" aria-hidden="true">
      {values.map((peak, index) => {
        const h = Math.max(2, peak * height);
        return <rect key={index} x={index * barWidth + 0.7} y={(height - h) / 2} width={Math.max(1, barWidth - 1.4)} height={h} rx={1} fill={color} opacity={0.42 + peak * 0.5} />;
      })}
    </svg>
  );
}

export function MediaPicker({
  label,
  hint,
  value,
  kind,
  onSelect,
  onRemove,
  suggestedName,
  compact,
}: {
  label: string;
  hint?: string;
  value: string | null;
  kind: MediaKind;
  onSelect: (mediaId: string) => void;
  onRemove: () => void;
  suggestedName?: string;
  compact?: boolean;
}) {
  const { project, mediaUrls, addMediaFile, toast } = useStudio();
  const inputRef = useRef<HTMLInputElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const [busy, setBusy] = useState(false);
  const [playing, setPlaying] = useState(false);
  const meta = value ? project.media[value] : undefined;
  const url = value ? mediaUrls[value] : undefined;
  const available = Boolean(meta && url);

  const pick = async (file: File | undefined) => {
    if (!file) return;
    setBusy(true);
    try {
      const added = await addMediaFile(file, kind);
      onSelect(added.id);
      toast(`رُفع «${added.name}» وربط بالحقل.`, "success");
    } catch {
      /* يعرض addMediaFile الرسالة */
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  return (
    <div className={cn("rounded-xl border border-white/[0.08] bg-[#0c0c10] p-3", compact && "p-2.5")}>
      <div className="mb-2 flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="flex items-center gap-1.5 text-[12px] font-semibold text-[#e8e8ee]">
            {kind === "audio" ? <Music2 size={13} className="text-[#b5a06c]" /> : <ImageIcon size={13} className="text-[#b5a06c]" />}
            {label}
          </p>
          {hint ? <p className="mt-0.5 text-[10px] leading-4 text-[#73737d]">{hint}</p> : null}
        </div>
        {meta ? (
          <button
            type="button"
            onClick={() => {
              audioRef.current?.pause();
              onRemove();
            }}
            className="rounded-lg p-1.5 text-[#85858f] transition hover:bg-red-500/10 hover:text-red-300"
            aria-label={`إزالة ${label}`}
            title="إزالة الارتباط"
          >
            <Trash2 size={14} />
          </button>
        ) : null}
      </div>

      {meta ? (
        <div className="rounded-lg border border-white/[0.07] bg-white/[0.025] p-2.5">
          <div className="flex items-center gap-2">
            <span className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-lg", available ? "bg-[#57dc96]/10 text-[#7de5ac]" : "bg-red-500/10 text-red-300")}>
              {kind === "audio" ? <Music2 size={15} /> : available ? <ImageIcon size={15} /> : <AlertCircle size={15} />}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-[11px] font-medium text-[#e4e4ea]" dir="ltr">
                {meta.name}
              </p>
              <p className="text-[10px] text-[#7d7d87]">
                {available
                  ? kind === "audio"
                    ? `${formatDuration(meta.duration ?? 0)} · ${formatBytes(meta.size)}`
                    : `${meta.width ?? "?"}×${meta.height ?? "?"} · ${formatBytes(meta.size)}`
                  : "الملف غير متاح محليًا — أعد رفعه"}
              </p>
            </div>
            <button type="button" onClick={() => inputRef.current?.click()} className="rounded-lg p-1.5 text-[#8c8c96] transition hover:bg-white/5 hover:text-white" title="استبدال الملف" aria-label="استبدال الملف">
              <RefreshCw size={13} />
            </button>
          </div>
          {kind === "audio" && available ? (
            <div className="mt-2 flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  const audio = audioRef.current;
                  if (!audio) return;
                  if (playing) {
                    audio.pause();
                  } else {
                    audio.currentTime = 0;
                    void audio.play().then(() => setPlaying(true)).catch(() => toast("تعذّر تشغيل معاينة الصوت في هذا المتصفح.", "error"));
                  }
                }}
                className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#d9b65a] text-[#171307]"
                aria-label={playing ? "إيقاف المعاينة" : "تشغيل المعاينة"}
              >
                {playing ? <Pause size={12} /> : <Play size={12} className="-mr-0.5" />}
              </button>
              <Waveform peaks={meta.peaks} color={playing ? "#9ef0c1" : "#d9b65a"} />
              <audio ref={audioRef} src={url} onEnded={() => setPlaying(false)} preload="metadata" />
            </div>
          ) : null}
          {kind === "image" && available ? (
            <div className="mt-2 overflow-hidden rounded-lg border border-white/10">
              <img src={url} alt={meta.name} className="h-20 w-full object-cover" />
            </div>
          ) : null}
        </div>
      ) : (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={busy}
          className="flex w-full items-center justify-center gap-2 rounded-lg border border-dashed border-white/12 bg-white/[0.015] px-3 py-3 text-[11px] text-[#9696a0] transition hover:border-[#d9b65a]/35 hover:text-[#e7cf94] disabled:opacity-50"
        >
          {busy ? <span className="h-3 w-3 animate-spin rounded-full border-2 border-current border-t-transparent" /> : <Upload size={14} />}
          {busy ? "جارٍ فحص الملف…" : kind === "audio" ? "رفع ملف صوت" : "رفع صورة"}
        </button>
      )}

      {suggestedName ? (
        <p className="mt-1.5 truncate text-[9px] text-[#65656f]" dir="ltr" title="اسم الملف المقترح للمطابقة الجماعية">
          {suggestedName}
        </p>
      ) : null}
      <input
        ref={inputRef}
        type="file"
        className="hidden"
        accept={kind === "audio" ? "audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac" : "image/*,.png,.jpg,.jpeg,.webp"}
        onChange={(event) => void pick(event.target.files?.[0])}
      />
    </div>
  );
}
