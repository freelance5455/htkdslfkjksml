import React, { useState } from 'react';
import {
  Film,
  Sparkles,
  CheckCircle2,
  XCircle,
  Clock,
  DollarSign,
  TrendingUp,
  AlertCircle,
  HelpCircle,
  Star,
  Tv,
} from 'lucide-react';
import { ProductionProposal, TimeSlotId } from '../types/game';
import { TIME_SLOTS } from '../data/initialData';
import { soundFx } from '../utils/audio';

interface ProductionProposalModalProps {
  proposal: ProductionProposal;
  cash: number;
  onApprove: (proposal: ProductionProposal, chosenSlot: TimeSlotId | 'none') => void;
  onReject: () => void;
}

export const ProductionProposalModal: React.FC<ProductionProposalModalProps> = ({
  proposal,
  cash,
  onApprove,
  onReject,
}) => {
  const [selectedSlot, setSelectedSlot] = useState<TimeSlotId | 'none'>(proposal.recommendedSlot);

  const canAfford = cash >= proposal.setupCost;

  const handleConfirmApproval = () => {
    if (!canAfford) return;
    soundFx.playVictory();
    onApprove(proposal, selectedSlot);
  };

  const handleRefuse = () => {
    soundFx.playClick();
    onReject();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 select-none">
      <div className="w-full max-w-sm sm:max-w-md bg-slate-900 border-2 border-amber-500/60 rounded-3xl p-4 sm:p-5 shadow-2xl flex flex-col gap-3.5 relative overflow-hidden max-h-[92vh] overflow-y-auto">
        {/* Glow ambient background */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header with Director Avatar & Badge */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-11 h-11 rounded-2xl bg-amber-500/20 border border-amber-400/50 flex items-center justify-center text-2xl shadow-inner shrink-0">
              🎬
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 font-black text-[9px] uppercase tracking-wider">
                  NOVA PROPOSTA
                </span>
                <span className="text-[10px] font-mono text-slate-400">DIRETORIA CRIATIVA</span>
              </div>
              <h2 className="text-base font-extrabold text-white font-display mt-0.5 leading-tight">
                {proposal.directorName}
              </h2>
            </div>
          </div>

          <button
            onClick={handleRefuse}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center text-sm"
            title="Fechar proposta"
          >
            ✕
          </button>
        </div>

        {/* Director's Personal Speech Bubble */}
        <div className="bg-slate-950/90 border border-amber-500/30 rounded-2xl p-3 relative">
          <div className="text-xs text-amber-200/90 italic leading-relaxed">
            &ldquo;Chefe, desenvolvi um projeto especial para alavancar nossa audiência! Veja os detalhes. Podemos iniciar a produção e em qual horário você deseja escalar?&rdquo;
          </div>
        </div>

        {/* Proposed Show Card */}
        <div className="bg-slate-950 rounded-2xl p-3.5 border border-slate-800 flex flex-col gap-2.5 shadow-md">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-slate-800 text-amber-300">
              Gênero: {proposal.genre.toUpperCase()}
            </span>
            <span className="text-[10px] font-mono text-emerald-400 font-bold flex items-center gap-1">
              <Star className="w-3 h-3 fill-emerald-400" />
              Hype: {proposal.hype}%
            </span>
          </div>

          <div>
            <h3 className="text-base font-extrabold text-white leading-tight">
              {proposal.title}
            </h3>
            <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
              {proposal.synopsis}
            </p>
          </div>

          {/* Quick Metrics Grid */}
          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800/80 text-center font-mono">
            <div className="bg-slate-900/80 p-2 rounded-xl border border-slate-800">
              <span className="text-[9px] text-slate-400 block font-sans">QUALIDADE</span>
              <span className="text-xs font-bold text-amber-400">{proposal.estimatedQuality}%</span>
            </div>
            <div className="bg-slate-900/80 p-2 rounded-xl border border-slate-800">
              <span className="text-[9px] text-slate-400 block font-sans">CUSTO / BLOCO</span>
              <span className="text-xs font-bold text-slate-200">R$ {proposal.productionCost.toLocaleString('pt-BR')}</span>
            </div>
            <div className="bg-slate-900/80 p-2 rounded-xl border border-slate-800">
              <span className="text-[9px] text-slate-400 block font-sans">TEMPORADA</span>
              <span className="text-xs font-bold text-slate-300">{proposal.seasonTotal} eps</span>
            </div>
          </div>
        </div>

        {/* Slot Selection (Question: Em qual horário ficará?) */}
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-bold text-slate-200 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>Em qual horário deseja escalar?</span>
            </span>
            <span className="text-[10px] text-amber-400 font-normal">
              Recomendado: {TIME_SLOTS.find((s) => s.id === proposal.recommendedSlot)?.label}
            </span>
          </label>

          <div className="grid grid-cols-2 gap-1.5">
            {TIME_SLOTS.map((slot) => {
              const isSelected = selectedSlot === slot.id;
              const isIdeal = proposal.recommendedSlot === slot.id;

              return (
                <button
                  key={slot.id}
                  type="button"
                  onClick={() => setSelectedSlot(slot.id)}
                  className={`p-2 rounded-xl border text-left transition-all cursor-pointer active:scale-95 flex flex-col gap-0.5 ${
                    isSelected
                      ? 'bg-amber-500/20 border-amber-400 text-white shadow-sm'
                      : 'bg-slate-950/70 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between text-[11px] font-bold">
                    <span>{slot.label}</span>
                    {isIdeal && (
                      <span className="text-[8px] px-1 py-0.2 rounded bg-amber-500 text-slate-950 font-black">
                        IDEAL
                      </span>
                    )}
                  </div>
                  <span className="text-[9px] font-mono text-slate-400">{slot.timeRange}</span>
                </button>
              );
            })}

            {/* Option to store in catalog without immediate scheduling */}
            <button
              type="button"
              onClick={() => setSelectedSlot('none')}
              className={`col-span-2 p-2 rounded-xl border text-center transition-all cursor-pointer active:scale-95 text-xs ${
                selectedSlot === 'none'
                  ? 'bg-amber-500/20 border-amber-400 text-white font-bold'
                  : 'bg-slate-950/70 border-slate-800 text-slate-400 hover:border-slate-700'
              }`}
            >
              📦 Apenas Produzir e Guardar no Acervo (Sem escalar agora)
            </button>
          </div>
        </div>

        {/* Investment & Feasibility Info */}
        <div className="flex items-center justify-between bg-slate-950/90 p-2.5 rounded-xl border border-slate-800 text-xs font-mono">
          <div>
            <span className="text-[10px] text-slate-400 block font-sans">CUSTO DE PRODUÇÃO DO PILOTO</span>
            <span className="font-bold text-amber-400">R$ {proposal.setupCost.toLocaleString('pt-BR')}</span>
          </div>
          <div className="text-right">
            <span className="text-[10px] text-slate-400 block font-sans">SEU SALDO ATUAL</span>
            <span className={`font-bold ${canAfford ? 'text-emerald-400' : 'text-red-400'}`}>
              R$ {cash.toLocaleString('pt-BR')}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2 pt-1">
          <button
            onClick={handleConfirmApproval}
            disabled={!canAfford}
            className={`w-full min-h-[48px] py-3 px-4 rounded-xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg active:scale-95 cursor-pointer ${
              canAfford
                ? 'bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 shadow-amber-950/40'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed opacity-75'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>
              {canAfford ? 'Aprovar Produção & Iniciar' : 'Caixa Insuficiente para Produzir'}
            </span>
          </button>

          <button
            onClick={handleRefuse}
            className="w-full min-h-[42px] py-2 px-3 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95"
          >
            <XCircle className="w-3.5 h-3.5 text-slate-500" />
            <span>Engavetar Projeto (Recusar Proposta)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
