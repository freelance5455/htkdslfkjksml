import React, { useEffect, useState } from 'react';
import { Play, Pause, RotateCcw, SkipForward } from 'lucide-react';

interface AnimatedStrokePlayerProps {
  label: string;
  strokes: string[];
  size?: number;
}

export const AnimatedStrokePlayer: React.FC<AnimatedStrokePlayerProps> = ({
  label,
  strokes,
  size = 180,
}) => {
  const [visibleCount, setVisibleCount] = useState<number>(strokes.length);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [speedMs, setSpeedMs] = useState<number>(750);

  useEffect(() => {
    setVisibleCount(strokes.length);
    setIsPlaying(false);
  }, [label, strokes]);

  useEffect(() => {
    if (!isPlaying) return;
    if (visibleCount >= strokes.length) {
      setIsPlaying(false);
      return;
    }
    const timer = window.setTimeout(() => {
      setVisibleCount((prev) => Math.min(strokes.length, prev + 1));
    }, speedMs);
    return () => window.clearTimeout(timer);
  }, [isPlaying, visibleCount, strokes.length, speedMs]);

  const handlePlay = () => {
    if (visibleCount >= strokes.length) {
      setVisibleCount(0);
    }
    setIsPlaying(true);
  };

  const handleStep = () => {
    setIsPlaying(false);
    setVisibleCount((prev) => (prev >= strokes.length ? 1 : prev + 1));
  };

  const handleReset = () => {
    setIsPlaying(false);
    setVisibleCount(0);
  };

  const getPathStartPoint = (d: string): { x: number; y: number } => {
    const match = d.match(/M\s*([0-9.]+)\s+([0-9.]+)/i);
    if (!match) return { x: 20, y: 20 };
    return { x: Number(match[1]), y: Number(match[2]) };
  };

  return (
    <div className="p-4 rounded-2xl bg-[#060919] border border-slate-800 space-y-3">
      <div className="flex items-center justify-between text-xs">
        <span className="font-semibold text-cyan-300">
          Stroke Order: {visibleCount} / {strokes.length}
        </span>
        <div className="flex items-center gap-1">
          {[
            { label: '0.5x', ms: 1200 },
            { label: '1x', ms: 750 },
            { label: '1.5x', ms: 420 },
          ].map((s) => (
            <button
              key={s.label}
              type="button"
              onClick={() => setSpeedMs(s.ms)}
              className={`px-2 py-0.5 rounded text-[11px] font-mono ${
                speedMs === s.ms ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center justify-center p-2 rounded-xl bg-[#0A102B]/70 border border-slate-800/80">
        <svg viewBox="0 0 100 100" style={{ width: size, height: size }} role="img" aria-label={`Stroke order animation for ${label}`}>
          <line x1="50" y1="0" x2="50" y2="100" stroke="#1e293b" strokeDasharray="3 3" strokeWidth="1" />
          <line x1="0" y1="50" x2="100" y2="50" stroke="#1e293b" strokeDasharray="3 3" strokeWidth="1" />
          <rect x="2" y="2" width="96" height="96" rx="8" fill="none" stroke="#1e293b" strokeWidth="1" />

          {/* Ghost outline of all strokes */}
          {strokes.map((d, idx) => (
            <path
              key={`ghost-${idx}`}
              d={d}
              stroke="#1e293b"
              strokeWidth="4.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              fill="none"
            />
          ))}

          {/* Active drawn strokes */}
          {strokes.slice(0, visibleCount).map((d, idx) => {
            const isNewest = idx === visibleCount - 1 && isPlaying;
            const pt = getPathStartPoint(d);
            return (
              <g key={`active-${idx}`}>
                <path
                  d={d}
                  stroke={isNewest ? '#A855F7' : '#38BDF8'}
                  strokeWidth="5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  fill="none"
                />
                <circle cx={pt.x} cy={pt.y} r="5.5" fill="#0F172A" stroke="#38BDF8" strokeWidth="1.2" />
                <text
                  x={pt.x}
                  y={pt.y + 2.2}
                  textAnchor="middle"
                  fill="#E2E8F0"
                  fontSize="6"
                  fontWeight="bold"
                >
                  {idx + 1}
                </text>
              </g>
            );
          })}
        </svg>
      </div>

      <div className="flex items-center justify-center gap-2">
        <button
          type="button"
          onClick={isPlaying ? () => setIsPlaying(false) : handlePlay}
          className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center gap-1.5"
        >
          {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          {isPlaying ? 'Pause' : 'Animate'}
        </button>
        <button
          type="button"
          onClick={handleStep}
          className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1"
          title="Step next stroke"
        >
          <SkipForward className="w-3.5 h-3.5" />
          Step
        </button>
        <button
          type="button"
          onClick={handleReset}
          className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1"
          title="Reset strokes"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Clear
        </button>
      </div>
    </div>
  );
};
