import React, { useState } from 'react';
import {
  Smartphone,
  Download,
  CheckCircle2,
  X,
  Sparkles,
  ArrowDownToLine,
  Zap,
  ShieldCheck,
  FileCode,
  Share2,
  Copy,
  ExternalLink,
} from 'lucide-react';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import { downloadAndroidApkBundle, downloadDirectApkPackage } from '../../utils/apkExport';

interface AndroidApkModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidApkModal: React.FC<AndroidApkModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isAndroid, install } = usePWAInstall();
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!isOpen) return null;

  const currentUrl = window.location.href;

  const handleOneClickInstall = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (accepted) {
        setDownloadSuccess('تم بدء تثبيت التطبيق بنجاح على هاتفك الأندرويد!');
      }
    } else {
      // Fallback: download APK launcher package
      downloadDirectApkPackage();
      setDownloadSuccess('تم تنزيل حزمة التثبيت المباشرة (Installer Package)!');
    }
  };

  const handleDownloadApkFiles = () => {
    downloadDirectApkPackage();
    downloadAndroidApkBundle();
    setDownloadSuccess('تم استخراج وتحميل ملفات حزمة التثبيت APK بنجاح!');
    setTimeout(() => setDownloadSuccess(null), 5000);
  };

  const copyAppUrl = () => {
    navigator.clipboard.writeText(currentUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
      <div className="w-full max-w-lg bg-white dark:bg-[#1a0f18] rounded-3xl shadow-2xl border border-rose-200/70 dark:border-rose-900/50 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header with Android Badge */}
        <div className="bg-gradient-to-r from-emerald-600 via-rose-600 to-pink-600 p-5 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 left-4 p-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white shadow-inner">
              <Smartphone className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold">تطبيق أندرويد واستخراج ملف APK</h2>
                <span className="text-[10px] font-bold bg-white text-emerald-800 px-2 py-0.5 rounded-full">
                  Android APK
                </span>
              </div>
              <p className="text-xs text-rose-100">
                تثبيت فوري ومباشر على جميع هواتف أندرويد الذكية
              </p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-right">
          {/* Status badge */}
          {isInstalled ? (
            <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <div>
                <p className="text-xs font-bold text-emerald-800 dark:text-emerald-200">
                  التطبيق مثبت بالفعل على جهازك (Standalone Mode)!
                </p>
                <p className="text-[11px] text-emerald-700 dark:text-emerald-300">
                  يعمل التطبيق الآن كبرنامج أندرويد مستقل بدون شريط متصفح وبدعم كامل دون إنترنت.
                </p>
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-2xl bg-gradient-to-br from-rose-50 to-pink-50 dark:from-rose-950/40 dark:to-pink-950/20 border border-rose-200 dark:border-rose-900/60 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-1.5 text-xs font-bold text-rose-700 dark:text-rose-300">
                  <Zap className="w-4 h-4 text-rose-500 fill-rose-500" />
                  <span>تثبيت مباشر بنقرة واحدة (WebAPK)</span>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-rose-200/80 mt-1">
                  يقوم نظام أندرويد بتوليد حزمة APK وتثبيتها مباشرة في شاشة هاتفك
                </p>
              </div>

              <button
                onClick={handleOneClickInstall}
                className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-700 hover:to-pink-700 text-white font-bold text-xs shadow-md shadow-rose-500/25 flex items-center gap-1.5 transition shrink-0"
              >
                <Download className="w-4 h-4" />
                <span>تثبيت الآن</span>
              </button>
            </div>
          )}

          {/* Direct APK extraction & bundle download */}
          <div className="bg-slate-50 dark:bg-slate-900/50 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileCode className="w-5 h-5 text-rose-500" />
                <div>
                  <h3 className="text-xs font-bold text-slate-900 dark:text-rose-100">
                    تجميع واستخراج ملف APK مباشرة
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    حزمة تثبيت جاهزة للهواتف وتجهيز الـ Package
                  </p>
                </div>
              </div>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              يمكنك استخراج حزمة التثبيت المباشرة مع ملف التوجيه والـ Manifest لتشغيله على أي هاتف أو رفعه على PWABuilder / Bubblewrap لإنشاء ملف APK موقع للتثبيت الفوري (Sideload).
            </p>

            <button
              onClick={handleDownloadApkFiles}
              className="w-full py-2.5 px-4 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-750 text-slate-900 dark:text-rose-100 border border-slate-300 dark:border-slate-700 font-semibold text-xs flex items-center justify-center gap-2 transition shadow-xs"
            >
              <ArrowDownToLine className="w-4 h-4 text-rose-600" />
              <span>تحميل حزمة استخراج الـ APK (APK Installer Kit)</span>
            </button>
          </div>

          {/* Android installation steps */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-700 dark:text-rose-200 flex items-center gap-1.5">
              <Smartphone className="w-4 h-4 text-emerald-500" />
              <span>خطوات التثبيت المباشر من هاتف أندرويد:</span>
            </h4>

            <ol className="text-xs text-slate-600 dark:text-slate-300 space-y-2 list-decimal list-inside pr-1 leading-relaxed">
              <li>
                افتح رابط التطبيق عبر متصفح <strong>Google Chrome</strong> على هاتفك الأندرويد.
              </li>
              <li>
                اضغط على أيقونة النقاط الثلاث (<strong>⋮</strong>) في أعلى يمين المتصفح.
              </li>
              <li>
                اختر <strong>«تثبيت التطبيق» (Install App)</strong> أو <strong>«إضافة إلى الشاشة الرئيسية»</strong>.
              </li>
              <li>
                سيقوم هاتف أندرويد بتحزيم وتثبيت ملف الـ APK فوراً مع أيقونة التطبيق الرسمية!
              </li>
            </ol>
          </div>

          {/* App URL copy */}
          <div className="p-3 rounded-xl bg-rose-50/60 dark:bg-rose-950/30 border border-rose-200/60 dark:border-rose-900/40 flex items-center justify-between gap-2">
            <span className="text-xs text-rose-900 dark:text-rose-200 font-mono truncate flex-1 dir-ltr text-left">
              {currentUrl}
            </span>
            <button
              onClick={copyAppUrl}
              className="py-1.5 px-3 rounded-lg bg-white dark:bg-slate-800 border border-rose-300 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs font-semibold flex items-center gap-1 shrink-0 hover:bg-rose-50"
            >
              {copiedLink ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedLink ? 'تم النسخ!' : 'نسخ الرابط للهاتف'}</span>
            </button>
          </div>

          {downloadSuccess && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 text-xs text-emerald-800 dark:text-emerald-200 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{downloadSuccess}</span>
            </div>
          )}

          {/* Online Builder Link */}
          <div className="pt-1 text-center">
            <a
              href={`https://www.pwabuilder.com?url=${encodeURIComponent(currentUrl)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-xs text-rose-600 dark:text-rose-400 hover:underline font-medium"
            >
              <span>توليد ملف APK موقع عبر منصة PWABuilder الرسمية</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
