import React, { useState } from 'react';
import { useKhata } from '../../context/KhataContext';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import {
  Smartphone,
  Download,
  CheckCircle,
  Copy,
  Check,
  Terminal,
  FileCode,
  Info,
  X
} from 'lucide-react';

export const AndroidApkModal: React.FC = () => {
  const { activeModal, setActiveModal, language, t } = useKhata();
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  if (activeModal !== 'android') return null;

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  const handleDownloadBuildGuide = () => {
    const text = `# Smart Home Khata - Android APK Build Instructions
Package ID: com.smarthomekhata.app
App Name: Smart Home Khata (स्मार्ट घरेलू हिसाब-किताब)

1. Build Web Production Bundle:
   npm run build

2. Sync into Android Capacitor Project:
   npx cap sync android

3. Build Release APK via CLI:
   cd android
   ./gradlew assembleRelease

4. Or Open in Android Studio:
   npx cap open android
   -> Build -> Generate Signed Bundle / APK -> Select APK -> release.
`;
    const blob = new Blob([text], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'SMART_HOME_KHATA_ANDROID_APK_GUIDE.md';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
      <div className="w-full max-w-lg rounded-t-3xl sm:rounded-2xl bg-white shadow-2xl border border-slate-200 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-xs z-10">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-emerald-700" />
            <h3 className="text-base font-bold text-slate-900">{t.androidAppTitle}</h3>
          </div>
          <button
            onClick={() => setActiveModal(null)}
            className="p-1 rounded-full text-slate-400 hover:text-slate-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Method 1: Instant PWA Install on Android (Chrome WebAPK) */}
          <div className="p-4 bg-gradient-to-br from-emerald-800 to-teal-800 text-white rounded-2xl shadow-md space-y-3">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-200 block">
                  तरीका 1 (सबसे तेज़ व आसान)
                </span>
                <h4 className="text-base font-extrabold text-white mt-0.5">
                  1-टैप में Android फोन पर इंस्टॉल करें
                </h4>
              </div>
              <span className="bg-emerald-600/60 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                Zero MB Download
              </span>
            </div>

            <p className="text-xs text-emerald-100 leading-relaxed">
              यह ऐप Android WebAPK तकनीक से सुसज्जित है। मोबाइल Chrome में यह बिना किसी बाहरी APK फ़ाइल के सीधे आपके फ़ोन के होम स्क्रीन पर असली Android ऐप की तरह स्थापित हो जाता है और 100% ऑफ़लाइन काम करता है।
            </p>

            {isInstalled ? (
              <div className="flex items-center gap-2 text-xs font-bold bg-white/20 px-3 py-2 rounded-xl text-white">
                <CheckCircle className="w-4 h-4 text-emerald-300" />
                <span>{t.pwaInstalled}</span>
              </div>
            ) : isInstallable ? (
              <button
                onClick={install}
                className="w-full py-2.5 rounded-xl bg-white text-emerald-900 hover:bg-emerald-50 text-xs font-extrabold shadow-sm transition flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4 text-emerald-700" />
                <span>अभी अपने फ़ोन में इंस्टॉल करें (Install Now)</span>
              </button>
            ) : (
              <div className="text-[11px] bg-white/10 p-2.5 rounded-xl text-emerald-100">
                💡 <strong>मोबाइल में लगाने के लिए:</strong> Chrome ब्राउज़र के 3 डॉट्स (⋮) मेनू पर टैप करें और <strong>"Add to Home screen / Install app"</strong> चुनें।
              </div>
            )}
          </div>

          {/* Android App Specifications */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2.5 text-xs">
            <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
              <FileCode className="w-4 h-4 text-emerald-700" />
              <span>Android प्रोजेक्ट कॉन्फ़िगरेशन विवरण (Specs)</span>
            </h4>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="p-2 bg-white rounded-xl border border-slate-200">
                <span className="text-slate-400 block">App Name:</span>
                <span className="font-bold text-slate-800">Smart Home Khata</span>
              </div>
              <div className="p-2 bg-white rounded-xl border border-slate-200">
                <span className="text-slate-400 block">{t.packageId}:</span>
                <span className="font-bold font-mono text-emerald-700">com.smarthomekhata.app</span>
              </div>
              <div className="p-2 bg-white rounded-xl border border-slate-200">
                <span className="text-slate-400 block">Framework:</span>
                <span className="font-bold text-slate-800">Capacitor 6.x + React 19</span>
              </div>
              <div className="p-2 bg-white rounded-xl border border-slate-200">
                <span className="text-slate-400 block">{t.minAndroid}:</span>
                <span className="font-bold text-slate-800">Android 5.1+ (API 22)</span>
              </div>
            </div>
          </div>

          {/* Method 2: Native Signed Release APK Instructions */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  तरीका 2 (Developer / Play Store APK)
                </span>
                <h4 className="text-xs font-bold text-slate-900 mt-0.5">
                  स्वतंत्र .APK फ़ाइल जनरेट करने के चरण
                </h4>
              </div>
              <button
                onClick={handleDownloadBuildGuide}
                className="text-[11px] font-bold text-emerald-700 hover:underline flex items-center gap-1"
              >
                <Download className="w-3 h-3" />
                <span>गाइड डाउनलोड</span>
              </button>
            </div>

            <p className="text-[11px] text-slate-500 leading-relaxed">
              पूरा Android प्रोजेक्ट <code className="bg-slate-200 px-1 py-0.5 rounded text-slate-800 font-mono">/android</code> फोल्डर में पहले से तैयार है। अपने कंप्यूटर पर APK संकलित (compile) करने के लिए ये 3 कमांड चलाएं:
            </p>

            {/* Step 1 */}
            <div className="bg-slate-900 text-slate-200 p-2.5 rounded-xl font-mono text-[11px] flex items-center justify-between">
              <span>npm run build</span>
              <button
                onClick={() => copyToClipboard('npm run build', 'c1')}
                className="text-slate-400 hover:text-white p-1"
              >
                {copiedCmd === 'c1' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>

            {/* Step 2 */}
            <div className="bg-slate-900 text-slate-200 p-2.5 rounded-xl font-mono text-[11px] flex items-center justify-between">
              <span>npx cap sync android</span>
              <button
                onClick={() => copyToClipboard('npx cap sync android', 'c2')}
                className="text-slate-400 hover:text-white p-1"
              >
                {copiedCmd === 'c2' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>

            {/* Step 3 */}
            <div className="bg-slate-900 text-slate-200 p-2.5 rounded-xl font-mono text-[11px] flex items-center justify-between">
              <span>cd android && ./gradlew assembleRelease</span>
              <button
                onClick={() => copyToClipboard('cd android && ./gradlew assembleRelease', 'c3')}
                className="text-slate-400 hover:text-white p-1"
              >
                {copiedCmd === 'c3' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>

            <div className="text-[11px] text-slate-500 bg-emerald-50/70 p-2.5 rounded-xl border border-emerald-100 flex items-start gap-1.5">
              <Info className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                तैयार APK फ़ाइल <code className="font-mono text-emerald-900 font-bold">android/app/build/outputs/apk/release/</code> में मिल जाएगी, जिसे सीधे WhatsApp या पेनड्राइव से किसी भी Android मोबाइल पर डालकर इंस्टॉल किया जा सकता है!
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
