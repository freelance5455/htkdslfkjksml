import React, { useState } from 'react';
import {
  X,
  FileCode,
  Download,
  Copy,
  Check,
  Terminal,
  Smartphone,
  FolderGit2,
  Package
} from 'lucide-react';
import { ANDROID_FILES, generateAndroidProjectZip } from '../../services/androidProjectGenerator';

interface AndroidCodeViewerModalProps {
  onClose: () => void;
}

export const AndroidCodeViewerModal: React.FC<AndroidCodeViewerModalProps> = ({ onClose }) => {
  const [selectedFileIdx, setSelectedFileIdx] = useState(0);
  const [isCopied, setIsCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);

  const selectedFile = ANDROID_FILES[selectedFileIdx];

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const blob = await generateAndroidProjectZip();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'CutPro-Android-Project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (err) {
      console.error(err);
      alert('Error generating zip file.');
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-6">
      <div className="w-full max-w-5xl h-[88vh] bg-[#161B22] border border-[#1F242D] rounded-3xl flex flex-col shadow-2xl overflow-hidden">
        {/* Top Header */}
        <div className="h-16 px-6 border-b border-[#1F242D] flex items-center justify-between bg-[#12161E]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#22C55E]/10 border border-[#22C55E]/30 flex items-center justify-center">
              <Smartphone className="w-5 h-5 text-[#22C55E]" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                CutPro Android Project (Kotlin + Jetpack Compose)
              </h3>
              <span className="text-xs text-[#8B949E]">
                Package: <code className="text-[#00E5FF]">com.cutpro.videoeditor</code> · API 26+ (Media3 Transformer)
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadZip}
              disabled={isZipping}
              className="flex items-center gap-2 px-4 py-2 bg-[#00E5FF] hover:bg-[#33ebff] text-black font-bold text-xs rounded-xl shadow-lg shadow-[#00E5FF]/20 transition-all cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>{isZipping ? 'Bundling Zip...' : 'Download Android Studio (.zip)'}</span>
            </button>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-xl flex items-center justify-center text-[#8B949E] hover:text-white hover:bg-[#1F242D] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Main Body with Sidebar + Code Inspector */}
        <div className="flex-1 flex flex-col md:flex-row min-h-0">
          {/* File Tree Sidebar */}
          <div className="w-full md:w-72 bg-[#0B0E14] border-r border-[#1F242D] flex flex-col p-3 overflow-y-auto">
            <div className="text-[11px] font-semibold text-[#8B949E] uppercase tracking-wider px-2 py-1.5 flex items-center gap-1.5">
              <FolderGit2 className="w-3.5 h-3.5" />
              <span>Project Source Tree</span>
            </div>

            <div className="flex flex-col gap-1 mt-1">
              {ANDROID_FILES.map((file, idx) => {
                const isSelected = selectedFileIdx === idx;
                const fileName = file.path.split('/').pop() || file.path;

                return (
                  <button
                    key={file.path}
                    onClick={() => setSelectedFileIdx(idx)}
                    className={`flex items-center gap-2 px-2.5 py-2 rounded-xl text-left text-xs transition-colors ${
                      isSelected
                        ? 'bg-[#1F242D] text-[#00E5FF] font-semibold border border-[#00E5FF]/20'
                        : 'text-[#8B949E] hover:text-white hover:bg-[#161B22]'
                    }`}
                  >
                    <FileCode className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-[#00E5FF]' : 'text-[#8B949E]'}`} />
                    <span className="truncate">{fileName}</span>
                  </button>
                );
              })}
            </div>

            {/* Quick APK Build guide widget */}
            <div className="mt-auto pt-4 border-t border-[#1F242D]">
              <div className="p-3 rounded-xl bg-[#161B22]/60 border border-[#1F242D] flex flex-col gap-2">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-white">
                  <Terminal className="w-3.5 h-3.5 text-[#00E5FF]" />
                  <span>APK Build Command</span>
                </div>
                <code className="text-[10px] bg-[#0B0E14] p-1.5 rounded font-mono text-[#22C55E] select-all">
                  ./gradlew assembleDebug
                </code>
                <span className="text-[10px] text-[#8B949E]">
                  Generates <code className="text-white">app-debug.apk</code> ready for direct phone installation.
                </span>
              </div>
            </div>
          </div>

          {/* Code Viewer Panel */}
          <div className="flex-1 flex flex-col min-w-0 bg-[#0B0E14]">
            {/* Code Header Bar */}
            <div className="h-11 px-4 border-b border-[#1F242D] flex items-center justify-between bg-[#12161E]/80">
              <span className="text-xs font-mono text-[#8B949E] truncate">
                {selectedFile.path}
              </span>
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-[#8B949E] hover:text-white bg-[#1F242D] hover:bg-[#2A313D] rounded-lg transition-colors"
              >
                {isCopied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-[#22C55E]" />
                    <span className="text-[#22C55E]">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>

            {/* Code Content */}
            <div className="flex-1 p-4 overflow-auto font-mono text-xs text-[#E6EDF3] leading-relaxed select-text">
              <pre className="whitespace-pre">
                {selectedFile.content}
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
