import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Clock, 
  Trophy, 
  Gift, 
  ChevronLeft, 
  ChevronRight, 
  CheckCircle2, 
  XCircle, 
  HelpCircle, 
  AlertTriangle, 
  Play, 
  Check, 
  Sparkles, 
  Volume2, 
  ArrowLeft,
  ShieldCheck,
  Award,
  BookOpen,
  Eye,
  Loader2
} from 'lucide-react';
import { WeeklyQuiz, MCQQuestion, WeeklyQuizSubmission, UserProfile } from '../types';
import { speakQuestionAndAnswer } from '../lib/languageUtils';

interface WeeklyQuizModalProps {
  quiz: WeeklyQuiz;
  language: string;
  userProfile?: UserProfile;
  initialSubmission?: WeeklyQuizSubmission | null;
  onClose: () => void;
  onViewLeaderboard: (quiz: WeeklyQuiz) => void;
}

type QuizStep = 'rules' | 'active' | 'result' | 'review';

export default function WeeklyQuizModal({
  quiz,
  language,
  userProfile,
  initialSubmission,
  onClose,
  onViewLeaderboard
}: WeeklyQuizModalProps) {
  const [step, setStep] = useState<QuizStep>(initialSubmission ? 'result' : 'rules');
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [answers, setAnswers] = useState<Record<number, number>>(initialSubmission?.answers || {});
  
  // Timer state (seconds remaining)
  const totalSeconds = (quiz.timeLimit || 20) * 60;
  const [secondsRemaining, setSecondsRemaining] = useState<number>(totalSeconds);
  const [startTime, setStartTime] = useState<string>('');
  
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submission, setSubmission] = useState<WeeklyQuizSubmission | null>(initialSubmission || null);
  const [userRank, setUserRank] = useState<number>(initialSubmission?.rank || 1);
  const [totalParticipants, setTotalParticipants] = useState<number>(quiz.participantsCount || 1);
  const [reviewQuestions, setReviewQuestions] = useState<MCQQuestion[]>(quiz.questions || []);
  const [showConfirmSubmit, setShowConfirmSubmit] = useState<boolean>(false);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const userId = userProfile?.name 
    ? `user-${userProfile.name.toLowerCase().replace(/\s+/g, '-')}`
    : 'user-guest';

  const displayName = userProfile?.name || (language === 'bn' ? 'শিক্ষার্থী' : 'Student Learner');

  // Load existing attempt if available on mount
  useEffect(() => {
    if (!initialSubmission) {
      fetchUserAttempt();
    }
  }, []);

  const fetchUserAttempt = async () => {
    try {
      const res = await fetch(`/api/weekly-quiz/${quiz.id}/user-attempt?userId=${userId}`);
      if (res.ok) {
        const data = await res.json();
        if (data.hasAttempted && data.submission) {
          setSubmission(data.submission);
          setUserRank(data.rank || 1);
          setTotalParticipants(data.totalParticipants || 1);
          if (data.reviewQuestions) {
            setReviewQuestions(data.reviewQuestions);
          }
          setStep('result');
        }
      }
    } catch (e) {
      console.warn('Failed to check user attempt:', e);
    }
  };

  // Start Quiz Handler
  const handleStartQuiz = async () => {
    try {
      const res = await fetch('/api/weekly-quiz/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ quizId: quiz.id, userId })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.alreadySubmitted) {
          await fetchUserAttempt();
          return;
        }
        const nowIso = data.startTime || new Date().toISOString();
        setStartTime(nowIso);
        setSecondsRemaining((quiz.timeLimit || 20) * 60);
        setStep('active');
        setCurrentIndex(0);
      } else {
        setStep('active');
        setStartTime(new Date().toISOString());
      }
    } catch (e) {
      setStep('active');
      setStartTime(new Date().toISOString());
    }
  };

  // Active Timer Tick & Auto-Submit
  useEffect(() => {
    if (step === 'active') {
      timerRef.current = setInterval(() => {
        setSecondsRemaining((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            handleFinalSubmit(); // Auto-submit when timer expires
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [step]);

  // Submit Quiz Action
  const handleFinalSubmit = async () => {
    if (isSubmitting) return;
    setIsSubmitting(true);
    setShowConfirmSubmit(false);

    try {
      const timeTakenSec = totalSeconds - secondsRemaining;
      const res = await fetch('/api/weekly-quiz/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          quizId: quiz.id,
          userId,
          displayName,
          answers,
          startTime: startTime || new Date(Date.now() - timeTakenSec * 1000).toISOString(),
          clientTimeTakenSeconds: Math.max(10, timeTakenSec)
        })
      });

      if (res.ok) {
        const data = await res.json();
        setSubmission(data.submission);
        setUserRank(data.rank || 1);
        setTotalParticipants(data.totalParticipants || 1);
        if (data.reviewQuestions) {
          setReviewQuestions(data.reviewQuestions);
        }
        setStep('result');
      }
    } catch (err) {
      console.error('Submit error:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSelectOption = (qIdx: number, optionIdx: number) => {
    setAnswers(prev => ({
      ...prev,
      [qIdx]: optionIdx
    }));
  };

  const formatTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const currentQuestion = reviewQuestions[currentIndex] || quiz.questions[currentIndex];
  const answeredCount = Object.keys(answers).length;
  const unansweredCount = quiz.questions.length - answeredCount;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700/90 rounded-3xl w-full max-w-4xl max-h-[94vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 text-slate-100">
        
        {/* ========================================================================= */}
        {/* MODAL HEADER */}
        {/* ========================================================================= */}
        <div className="bg-slate-800/90 border-b border-slate-700/80 px-4 md:px-6 py-3 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-tr from-amber-500 to-amber-600 text-slate-950 rounded-xl font-black shadow-md">
              <Trophy className="w-4 h-4 fill-current" />
            </div>
            <div>
              <h2 className="text-sm md:text-base font-black text-white truncate max-w-xs md:max-w-md">
                {quiz.title}
              </h2>
              <p className="text-[11px] text-slate-400">
                {language === 'bn' ? '🏆 সাপ্তাহিক প্রতিযোগিতা ও মেধা মূল্যায়ন' : 'Weekly Educational Competition'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {step === 'active' && (
              <div className={`px-3 py-1.5 rounded-xl border flex items-center gap-2 font-mono font-black text-xs md:text-sm ${
                secondsRemaining < 180 
                  ? 'bg-rose-950/80 border-rose-500 text-rose-300 animate-pulse' 
                  : 'bg-slate-950 border-indigo-500/50 text-indigo-300'
              }`}>
                <Clock className="w-4 h-4 text-amber-400" />
                <span>{formatTimer(secondsRemaining)}</span>
              </div>
            )}

            <button
              onClick={onClose}
              className="p-2 bg-slate-700/60 hover:bg-slate-700 text-slate-300 rounded-full transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* STEP 1: RULES & QUIZ INFO SCREEN */}
        {/* ========================================================================= */}
        {step === 'rules' && (
          <div className="flex-1 overflow-y-auto p-5 md:p-8 space-y-6">
            
            {/* HERO BANNER */}
            <div className="bg-gradient-to-r from-indigo-950/70 via-slate-900 to-purple-950/70 border border-indigo-500/40 rounded-3xl p-6 md:p-7 relative overflow-hidden">
              <div className="relative z-10 space-y-3">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-3 py-1 bg-amber-500/20 border border-amber-400/40 text-amber-300 font-extrabold text-xs rounded-xl">
                    🎁 {language === 'bn' ? 'সাপ্তাহিক পুরস্কার:' : 'Prize:'} {quiz.prizeName}
                  </span>
                  <span className="px-2.5 py-1 bg-indigo-600/40 border border-indigo-500/40 text-indigo-200 text-xs font-bold rounded-lg">
                    {quiz.targetLevel}
                  </span>
                </div>

                <h3 className="text-xl md:text-2xl font-black text-white">
                  {quiz.title}
                </h3>

                <p className="text-xs md:text-sm text-slate-300 leading-relaxed max-w-2xl">
                  {quiz.description}
                </p>

                {/* PRIZE DISPLAY SNIPPET */}
                <div className="flex items-center gap-4 bg-slate-950/60 border border-slate-800 p-3.5 rounded-2xl max-w-lg mt-2">
                  {quiz.prizeImage ? (
                    <img 
                      src={quiz.prizeImage} 
                      alt={quiz.prizeName} 
                      className="w-14 h-14 rounded-xl object-cover border border-amber-500/30 shrink-0 shadow-md"
                    />
                  ) : (
                    <div className="w-14 h-14 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center shrink-0 text-amber-300">
                      <Gift className="w-6 h-6" />
                    </div>
                  )}
                  <div>
                    <h4 className="text-xs font-black text-white">{quiz.prizeName}</h4>
                    <p className="text-[11px] text-slate-400 line-clamp-2">{quiz.prizeDescription}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* QUIZ METRICS GRID */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-slate-800/60 border border-slate-700/80 rounded-2xl p-4 text-center">
                <span className="text-[11px] text-slate-400 font-bold block">{language === 'bn' ? 'মোট প্রশ্ন' : 'Questions'}</span>
                <span className="text-lg md:text-xl font-black text-indigo-300">{quiz.questionCount || quiz.questions.length}</span>
              </div>
              <div className="bg-slate-800/60 border border-slate-700/80 rounded-2xl p-4 text-center">
                <span className="text-[11px] text-slate-400 font-bold block">{language === 'bn' ? 'সময়সীমা' : 'Time Limit'}</span>
                <span className="text-lg md:text-xl font-black text-teal-300">{quiz.timeLimit} {language === 'bn' ? 'মিনিট' : 'Min'}</span>
              </div>
              <div className="bg-slate-800/60 border border-slate-700/80 rounded-2xl p-4 text-center">
                <span className="text-[11px] text-slate-400 font-bold block">{language === 'bn' ? 'অংশগ্রহণকারী' : 'Participants'}</span>
                <span className="text-lg md:text-xl font-black text-amber-300">{quiz.participantsCount}</span>
              </div>
              <div className="bg-slate-800/60 border border-slate-700/80 rounded-2xl p-4 text-center">
                <span className="text-[11px] text-slate-400 font-bold block">{language === 'bn' ? 'সুযোগ' : 'Attempts'}</span>
                <span className="text-lg md:text-xl font-black text-emerald-300">{language === 'bn' ? '১ বার' : '1 Attempt'}</span>
              </div>
            </div>

            {/* OFFICIAL RULES CHECKLIST */}
            <div className="bg-slate-800/80 border border-slate-700 rounded-3xl p-5 md:p-6 space-y-4 shadow-lg">
              <h4 className="text-sm font-black text-white flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-indigo-400" />
                {language === 'bn' ? '📋 কুইজের নিয়মাবলী (Quiz Rules & Fair Play)' : '📋 Official Quiz Rules & Fair Play'}
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-300">
                {[
                  language === 'bn' ? '• মোট প্রশ্ন: ৫০টি (MCQ ভিত্তিক)' : `• Total Questions: ${quiz.questionCount || 50}`,
                  language === 'bn' ? `• সময়সীমা: ${quiz.timeLimit} মিনিট (টাইমার শেষ হলে অটো-সাবমিট)` : `• Time Limit: ${quiz.timeLimit} Minutes (Auto-submit on expiry)`,
                  language === 'bn' ? '• প্রতি সপ্তাহে ১ জন ব্যবহারকারী ১ বারই অফিশিয়াল সুযোগ পাবেন' : '• Exactly one official attempt per user per weekly quiz',
                  language === 'bn' ? '• স্বয়ংক্রিয় স্কোর গণনা: প্রতিটি সঠিক উত্তরে ১ নম্বর' : '• Automatic score calculation (1 mark per correct answer)',
                  language === 'bn' ? '• সর্বোচ্চ স্কোর অর্জনকারী লিডারবোর্ডের শীর্ষে থাকবেন' : '• Highest score gets the highest rank on the Leaderboard',
                  language === 'bn' ? '• স্কোর সমান হলে দ্রুততম সময়ে সমাপ্তকারী অগ্রাধিকার পাবেন' : '• If scores are equal, faster completion time gets higher rank',
                  language === 'bn' ? '• অ্যাডমিন দ্বারা চূড়ান্ত বিজয়ী যাচাই ও ঘোষণা করা হবে' : '• Final winner is verified and officially announced by Admin',
                  language === 'bn' ? '• সম্পূর্ণ ফ্রি শিক্ষামূলক প্রতিযোগিতা • কোনো ফি বা বেটিং নেই' : '• 100% Free educational challenge • No payment required'
                ].map((rule, idx) => (
                  <div key={idx} className="flex items-start gap-2 bg-slate-900/60 p-3 rounded-xl border border-slate-800/80">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{rule}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* ACTION CTA */}
            <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
              <button
                onClick={handleStartQuiz}
                className="w-full sm:flex-1 py-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-sm rounded-2xl shadow-xl shadow-emerald-600/30 transition-all cursor-pointer flex items-center justify-center gap-2 transform active:scale-95"
              >
                <Play className="w-5 h-5 fill-current" />
                <span>{language === 'bn' ? 'কুইজ শুরু করুন (Start Quiz)' : 'Start Weekly Quiz'}</span>
              </button>

              <button
                onClick={() => onViewLeaderboard(quiz)}
                className="w-full sm:w-auto px-6 py-4 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 font-extrabold text-xs rounded-2xl transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <Trophy className="w-4 h-4 text-amber-400" />
                <span>{language === 'bn' ? 'বর্তমান লিডারবোর্ড দেখুন' : 'View Leaderboard'}</span>
              </button>
            </div>

          </div>
        )}

        {/* ========================================================================= */}
        {/* STEP 2: ACTIVE TIMED QUIZ INTERFACE */}
        {/* ========================================================================= */}
        {step === 'active' && currentQuestion && (
          <div className="flex-1 flex flex-col overflow-hidden">
            
            {/* PROGRESS & QUESTION PALETTE BAR */}
            <div className="bg-slate-900 border-b border-slate-800 p-3 md:p-4 space-y-2.5 shrink-0">
              <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                <span className="text-indigo-300">
                  {language === 'bn' 
                    ? `প্রশ্ন ${currentIndex + 1} / ${quiz.questions.length}` 
                    : `Question ${currentIndex + 1} of ${quiz.questions.length}`}
                </span>
                <span className="text-emerald-400">
                  {language === 'bn' 
                    ? `উত্তর দিয়েছেন: ${answeredCount} | বাকি: ${unansweredCount}` 
                    : `Answered: ${answeredCount} | Remaining: ${unansweredCount}`}
                </span>
              </div>

              {/* JUMP PALETTE GRID (SCROLLABLE) */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                {quiz.questions.map((_, idx) => {
                  const isAnswered = answers[idx] !== undefined;
                  const isCurrent = idx === currentIndex;
                  return (
                    <button
                      key={idx}
                      onClick={() => setCurrentIndex(idx)}
                      className={`w-7 h-7 rounded-lg text-xs font-black shrink-0 transition-all cursor-pointer flex items-center justify-center ${
                        isCurrent
                          ? 'bg-indigo-600 text-white ring-2 ring-indigo-400 shadow-md'
                          : isAnswered
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                      }`}
                    >
                      {idx + 1}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* MAIN QUESTION DISPLAY */}
            <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-5">
              <div className="bg-slate-800/80 border border-slate-700/80 rounded-3xl p-5 md:p-6 space-y-4 shadow-xl">
                
                {/* QUESTION TOP BAR */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 font-black text-xs rounded-xl">
                      {currentQuestion.subject}
                    </span>
                    {currentQuestion.difficulty && (
                      <span className="px-2.5 py-1 bg-slate-700 text-slate-300 font-bold text-[11px] rounded-lg">
                        {currentQuestion.difficulty}
                      </span>
                    )}
                  </div>

                  {/* READ ALOUD SPEAKER */}
                  <button
                    onClick={() => speakQuestionAndAnswer(currentQuestion.question, null, null, language)}
                    className="p-2 bg-slate-700/80 hover:bg-indigo-600 text-indigo-300 hover:text-white rounded-xl transition-all cursor-pointer shadow-md"
                    title={language === 'bn' ? 'প্রশ্নটি শুনুন' : 'Read Question'}
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>

                {/* QUESTION TEXT */}
                <div className="text-base md:text-lg font-black text-white leading-relaxed pt-1">
                  <span className="text-indigo-400 mr-2">Q{currentIndex + 1}.</span>
                  {currentQuestion.question}
                </div>

                {/* OPTIONS LIST */}
                <div className="grid grid-cols-1 gap-2.5 pt-2">
                  {currentQuestion.options.map((option, optIdx) => {
                    const isSelected = answers[currentIndex] === optIdx;

                    return (
                      <button
                        key={optIdx}
                        type="button"
                        onClick={() => handleSelectOption(currentIndex, optIdx)}
                        className={`p-4 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between gap-3 ${
                          isSelected
                            ? 'bg-indigo-600/30 border-indigo-500 text-white font-black shadow-lg shadow-indigo-600/20'
                            : 'bg-slate-900/80 border-slate-700 text-slate-200 hover:border-indigo-500/60 hover:bg-slate-800'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className={`w-6 h-6 rounded-full border flex items-center justify-center text-xs font-black ${
                            isSelected ? 'bg-indigo-500 border-indigo-400 text-white' : 'border-slate-600 text-slate-400'
                          }`}>
                            {String.fromCharCode(65 + optIdx)}
                          </div>
                          <span className="text-xs md:text-sm font-semibold leading-snug">
                            {option.replace(/^[A-D]\.\s*/, '')}
                          </span>
                        </div>

                        {isSelected && (
                          <div className="w-5 h-5 rounded-full bg-indigo-500 text-white flex items-center justify-center shrink-0">
                            <Check className="w-3 h-3 stroke-[3]" />
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>

              </div>
            </div>

            {/* ACTIVE QUIZ FOOTER */}
            <div className="bg-slate-800/90 border-t border-slate-700/80 px-4 md:px-6 py-3.5 flex items-center justify-between gap-3 shrink-0">
              <button
                onClick={() => setCurrentIndex(prev => Math.max(0, prev - 1))}
                disabled={currentIndex === 0}
                className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                  currentIndex === 0 
                    ? 'bg-slate-800 text-slate-600 border border-slate-800 cursor-not-allowed'
                    : 'bg-slate-700 hover:bg-slate-600 text-slate-200'
                }`}
              >
                <ChevronLeft className="w-4 h-4" />
                <span>{language === 'bn' ? 'আগের প্রশ্ন' : 'Previous'}</span>
              </button>

              <button
                onClick={() => setShowConfirmSubmit(true)}
                className="px-5 py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-extrabold rounded-xl text-xs shadow-lg shadow-rose-600/30 transition-all cursor-pointer flex items-center gap-1.5"
              >
                <span>{language === 'bn' ? 'কুইজ সাবমিট করুন' : 'Submit Quiz'}</span>
              </button>

              <button
                onClick={() => {
                  if (currentIndex < quiz.questions.length - 1) {
                    setCurrentIndex(prev => prev + 1);
                  } else {
                    setShowConfirmSubmit(true);
                  }
                }}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold rounded-xl text-xs shadow-lg shadow-indigo-600/30 transition-all cursor-pointer flex items-center gap-1.5"
              >
                <span>{currentIndex === quiz.questions.length - 1 ? (language === 'bn' ? 'সমাপ্ত' : 'Finish') : (language === 'bn' ? 'পরের প্রশ্ন' : 'Next')}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

          </div>
        )}

        {/* ========================================================================= */}
        {/* STEP 3: RESULT SCREEN */}
        {/* ========================================================================= */}
        {step === 'result' && submission && (
          <div className="flex-1 overflow-y-auto p-5 md:p-8 space-y-6 text-center animate-in fade-in zoom-in duration-300">
            
            {/* TROPHY ICON */}
            <div className="w-20 h-20 bg-gradient-to-tr from-amber-500 to-amber-600 text-slate-950 rounded-full flex items-center justify-center mx-auto shadow-2xl shadow-amber-500/20">
              <Award className="w-10 h-10" />
            </div>

            <div className="space-y-1.5">
              <h3 className="text-xl md:text-2xl font-black text-white">
                {language === 'bn' ? '🎉 সাপ্তাহিক কুইজ সম্পন্ন হয়েছে!' : '🎉 Quiz Completed!'}
              </h3>
              <p className="text-xs text-slate-300">
                {language === 'bn' ? 'আপনার ফলাফল সফলভাবে জমা হয়েছে এবং লিডারবোর্ডে যুক্ত করা হয়েছে।' : 'Your submission has been securely recorded and calculated.'}
              </p>
            </div>

            {/* SCORE DISPLAY CARD */}
            <div className="bg-slate-800/90 border border-slate-700/80 rounded-3xl p-6 max-w-lg mx-auto space-y-4 shadow-xl">
              <div className="text-xs font-extrabold text-indigo-300 uppercase tracking-wider">
                {language === 'bn' ? 'আপনার অর্জিত স্কোর' : 'Your Official Score'}
              </div>

              <div className="text-4xl md:text-5xl font-black text-white">
                <span className="text-emerald-400">{submission.score}</span>
                <span className="text-slate-500 text-2xl md:text-3xl"> / {submission.totalQuestions}</span>
              </div>

              {/* STATS METRIC PILLS */}
              <div className="grid grid-cols-3 gap-2 pt-2 text-xs font-bold">
                <div className="bg-emerald-950/50 border border-emerald-500/40 p-2.5 rounded-xl text-emerald-300">
                  <span className="block text-[10px] text-emerald-400/80">{language === 'bn' ? 'সঠিক' : 'Correct'}</span>
                  <span className="text-base font-black">{submission.correctAnswers}</span>
                </div>
                <div className="bg-rose-950/50 border border-rose-500/40 p-2.5 rounded-xl text-rose-300">
                  <span className="block text-[10px] text-rose-400/80">{language === 'bn' ? 'ভুল' : 'Wrong'}</span>
                  <span className="text-base font-black">{submission.wrongAnswers}</span>
                </div>
                <div className="bg-slate-900 border border-slate-700 p-2.5 rounded-xl text-slate-300">
                  <span className="block text-[10px] text-slate-400">{language === 'bn' ? 'সময়' : 'Time'}</span>
                  <span className="text-base font-black">
                    {Math.floor(submission.completionTimeSeconds / 60)}m {submission.completionTimeSeconds % 60}s
                  </span>
                </div>
              </div>

              {/* ESTIMATED RANK HIGHLIGHT */}
              <div className="bg-indigo-950/60 border border-indigo-500/40 rounded-2xl p-3.5 flex items-center justify-between text-xs font-bold">
                <span className="text-indigo-200">
                  {language === 'bn' ? 'বর্তমান সম্ভাব্য র‍্যাঙ্ক:' : 'Current Provisional Rank:'}
                </span>
                <span className="text-amber-300 font-black text-sm">
                  #{userRank} {language === 'bn' ? `(${totalParticipants} জনের মধ্যে)` : `(of ${totalParticipants})`}
                </span>
              </div>
            </div>

            {/* ACTION BUTTONS */}
            <div className="max-w-lg mx-auto grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <button
                onClick={() => onViewLeaderboard(quiz)}
                className="py-3.5 px-4 bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 font-black text-xs rounded-2xl shadow-lg shadow-amber-500/20 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <Trophy className="w-4 h-4 fill-current" />
                <span>{language === 'bn' ? 'লিডারবোর্ড দেখুন' : 'View Leaderboard'}</span>
              </button>

              <button
                onClick={() => setStep('review')}
                className="py-3.5 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs rounded-2xl shadow-lg shadow-indigo-600/20 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <BookOpen className="w-4 h-4" />
                <span>{language === 'bn' ? 'উত্তরমালা ও ব্যাখ্যা দেখুন' : 'Review Answers'}</span>
              </button>
            </div>

          </div>
        )}

        {/* ========================================================================= */}
        {/* STEP 4: ANSWER REVIEW SCREEN */}
        {/* ========================================================================= */}
        {step === 'review' && (
          <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-5">
            
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <button
                onClick={() => setStep('result')}
                className="flex items-center gap-1.5 text-xs font-bold text-indigo-300 hover:text-white transition-all cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>{language === 'bn' ? 'ফলাফলে ফিরে যান' : 'Back to Results'}</span>
              </button>

              <span className="text-xs text-slate-400 font-semibold">
                {language === 'bn' ? `মোট ${reviewQuestions.length} টি প্রশ্নের বিশদ সমাধান` : `${reviewQuestions.length} Questions Review`}
              </span>
            </div>

            <div className="space-y-4">
              {reviewQuestions.map((q, qIdx) => {
                const userChosen = submission?.answers[qIdx];
                const isCorrect = userChosen === q.correctOptionIndex;
                const isUnanswered = userChosen === undefined || userChosen === null;

                return (
                  <div 
                    key={q.id || qIdx}
                    className={`bg-slate-800/80 border rounded-3xl p-5 space-y-3.5 shadow-lg ${
                      isCorrect 
                        ? 'border-emerald-500/50' 
                        : isUnanswered 
                        ? 'border-slate-700' 
                        : 'border-rose-500/50'
                    }`}
                  >
                    {/* QUESTION HEADER */}
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-0.5 bg-slate-900 border border-slate-700 text-slate-300 text-[11px] font-bold rounded-md">
                          {q.subject}
                        </span>
                        <span className="text-xs font-black text-indigo-400">Q{qIdx + 1}</span>
                      </div>

                      {isCorrect ? (
                        <span className="px-2.5 py-1 bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs font-black rounded-lg flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          {language === 'bn' ? 'সঠিক উত্তর (+১)' : 'Correct (+1)'}
                        </span>
                      ) : isUnanswered ? (
                        <span className="px-2.5 py-1 bg-slate-700 text-slate-400 text-xs font-bold rounded-lg">
                          {language === 'bn' ? 'উত্তর দেওয়া হয়নি' : 'Unanswered'}
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 bg-rose-500/20 border border-rose-400/40 text-rose-300 text-xs font-black rounded-lg flex items-center gap-1">
                          <XCircle className="w-3.5 h-3.5" />
                          {language === 'bn' ? 'ভুল উত্তর' : 'Wrong Answer'}
                        </span>
                      )}
                    </div>

                    {/* QUESTION TEXT */}
                    <div className="text-sm md:text-base font-bold text-white leading-relaxed">
                      {q.question}
                    </div>

                    {/* OPTIONS REVIEW */}
                    <div className="grid grid-cols-1 gap-2 pt-1 text-xs">
                      {q.options.map((opt, optIdx) => {
                        const isCorrectOption = optIdx === q.correctOptionIndex;
                        const isChosenOption = userChosen === optIdx;

                        let style = "bg-slate-900/60 border-slate-800 text-slate-400";
                        if (isCorrectOption) {
                          style = "bg-emerald-950/80 border-emerald-500 text-emerald-200 font-bold";
                        } else if (isChosenOption) {
                          style = "bg-rose-950/80 border-rose-500 text-rose-200 font-bold";
                        }

                        return (
                          <div 
                            key={optIdx}
                            className={`p-3 rounded-xl border flex items-center justify-between gap-3 ${style}`}
                          >
                            <span>{opt}</span>
                            {isCorrectOption && (
                              <span className="text-[10px] font-black text-emerald-400 uppercase">
                                ✓ {language === 'bn' ? 'সঠিক উত্তর' : 'Correct Answer'}
                              </span>
                            )}
                            {isChosenOption && !isCorrectOption && (
                              <span className="text-[10px] font-black text-rose-400 uppercase">
                                ✗ {language === 'bn' ? 'আপনার উত্তর' : 'Your Choice'}
                              </span>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {/* EXPLANATION */}
                    {q.explanation && (
                      <div className="bg-slate-900/90 border border-indigo-500/30 rounded-2xl p-4 space-y-2 mt-2">
                        <div className="flex items-center gap-1.5 text-indigo-300 font-extrabold text-xs">
                          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                          <span>{language === 'bn' ? 'বিশ্লেষণ ও ব্যাখ্যা:' : 'Explanation:'}</span>
                        </div>
                        <p className="text-xs text-slate-200 leading-relaxed font-normal">
                          {q.explanation}
                        </p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

          </div>
        )}

        {/* CONFIRMATION SUBMISSION DIALOG */}
        {showConfirmSubmit && (
          <div className="fixed inset-0 z-60 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
              <div className="w-12 h-12 bg-amber-500/20 text-amber-400 rounded-2xl flex items-center justify-center mx-auto">
                <AlertTriangle className="w-6 h-6" />
              </div>

              <div className="text-center space-y-1.5">
                <h4 className="text-lg font-black text-white">
                  {language === 'bn' ? 'কুইজ সাবমিট করবেন?' : 'Submit Weekly Quiz?'}
                </h4>
                <p className="text-xs text-slate-300">
                  {language === 'bn' 
                    ? `আপনি ${answeredCount}টি প্রশ্নের উত্তর দিয়েছেন। ${unansweredCount}টি প্রশ্ন বাকি রয়েছে। সাবমিট করার পর উত্তর আর পরিবর্তন করা যাবে না।`
                    : `You answered ${answeredCount} of ${quiz.questions.length} questions. You cannot change answers after submitting.`}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  onClick={() => setShowConfirmSubmit(false)}
                  className="py-3 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl cursor-pointer"
                >
                  {language === 'bn' ? 'না, চালিয়ে যান' : 'Continue Quiz'}
                </button>
                <button
                  onClick={handleFinalSubmit}
                  disabled={isSubmitting}
                  className="py-3 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl cursor-pointer shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-1.5"
                >
                  {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                  <span>{language === 'bn' ? 'হ্যাঁ, সাবমিট করুন' : 'Confirm Submit'}</span>
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
