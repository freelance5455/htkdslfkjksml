/**
 * JUHNKRIX MUSIKA - JMCEarningToast Component
 * Displays real-time toast notifications whenever JMC is accumulated from mining, listening, or rewarded activities.
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Coins, CheckCircle2, X, Zap } from 'lucide-react';
import { jmcNotificationEngine, JmcEarningEvent } from '../lib/jmcNotificationEngine';

export const JMCEarningToast: React.FC = () => {
  const [currentEvent, setCurrentEvent] = useState<JmcEarningEvent | null>(null);

  useEffect(() => {
    const unsubscribe = jmcNotificationEngine.subscribe((event) => {
      setCurrentEvent(event);
      const timer = setTimeout(() => {
        setCurrentEvent(null);
      }, 7000);
      return () => clearTimeout(timer);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  if (!currentEvent) return null;

  const badgeColor = 
    currentEvent.type === 'MINING' ? 'bg-amber-500/20 text-amber-300 border-amber-400/40' :
    currentEvent.type === 'LISTENING' ? 'bg-purple-500/20 text-purple-300 border-purple-400/40' :
    currentEvent.type === 'STAKING' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40' :
    'bg-blue-500/20 text-blue-300 border-blue-400/40';

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 50, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.9 }}
        className="fixed bottom-6 right-6 z-[9999] max-w-sm w-full bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/90 border-2 border-amber-400/80 rounded-3xl p-4 shadow-2xl shadow-amber-500/40 backdrop-blur-2xl text-slate-100"
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-500 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-amber-500/50 shrink-0 animate-bounce">
              <Coins className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className={`px-2 py-0.5 rounded-full border text-[10px] font-black uppercase tracking-wider ${badgeColor}`}>
                  {currentEvent.type} REWARD
                </span>
                <span className="text-[10px] text-emerald-400 font-bold flex items-center">
                  <CheckCircle2 className="w-3 h-3 mr-0.5" /> Credited
                </span>
              </div>
              <h4 className="text-sm font-extrabold text-amber-200 mt-0.5 flex items-center space-x-1">
                <span>+{currentEvent.amount.toFixed(4)} JMC</span>
                <Sparkles className="w-3.5 h-3.5 text-amber-400 inline" />
              </h4>
            </div>
          </div>

          <button
            onClick={() => setCurrentEvent(null)}
            className="text-slate-400 hover:text-amber-200 p-1 rounded-xl bg-slate-800/60 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="mt-2.5 pt-2.5 border-t border-amber-500/20 text-xs text-slate-300">
          <p className="font-medium truncate">{currentEvent.description}</p>
          <div className="mt-1 flex items-center justify-between text-[10px] text-slate-400 font-mono">
            <span>juhnkrixmusika.pages.dev</span>
            <span>{currentEvent.timestamp}</span>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};
