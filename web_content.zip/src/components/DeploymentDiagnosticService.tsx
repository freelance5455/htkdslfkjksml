import React, { useState, useEffect } from 'react';
import { Globe, Server, Link2, ShieldCheck, RefreshCw } from 'lucide-react';

export const DeploymentDiagnosticService: React.FC = () => {
  const [hostUrl, setHostUrl] = useState<string>('');
  const [environment, setEnvironment] = useState<string>('');
  const [protocol, setProtocol] = useState<string>('');
  const [port, setPort] = useState<string>('');

  useEffect(() => {
    // Collect deployment context metrics
    if (typeof window !== 'undefined') {
      const url = new URL(window.location.href);
      setHostUrl(window.location.hostname);
      setProtocol(url.protocol.replace(':', ''));
      setPort(url.port || (url.protocol === 'https:' ? '443' : '80'));
      
      if (url.hostname.includes('localhost') || url.hostname.includes('127.0.0.1')) {
        setEnvironment('Local Development');
      } else if (url.hostname.includes('ais-dev') || url.hostname.includes('ais-pre') || url.hostname.includes('.run.app')) {
        setEnvironment('Cloud Run Sandbox (AI Studio)');
      } else {
        setEnvironment('Custom Production Domain');
      }
    }
  }, []);

  return (
    <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 border border-slate-700/50 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-5">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
            <Server className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-200 flex items-center space-x-2">
              <span>Environment Diagnostic Service</span>
              <span className="px-1.5 py-0.5 rounded text-[9px] font-black uppercase tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/30">
                Owner Only
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Live deployment connection & routing context for custom domain troubleshooting.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
          <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold block mb-1">Host Identity (IP/Domain)</span>
          <div className="flex items-center space-x-2 text-slate-200">
            <Globe className="w-4 h-4 text-emerald-400" />
            <span className="text-sm font-mono truncate">{hostUrl || 'Resolving...'}</span>
          </div>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
          <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold block mb-1">Environment</span>
          <div className="flex items-center space-x-2 text-slate-200">
            <ShieldCheck className="w-4 h-4 text-purple-400" />
            <span className="text-sm font-medium truncate">{environment || 'Detecting...'}</span>
          </div>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
          <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold block mb-1">Protocol Layer</span>
          <div className="flex items-center space-x-2 text-slate-200">
            <Link2 className="w-4 h-4 text-blue-400" />
            <span className="text-sm font-mono uppercase truncate">{protocol}</span>
          </div>
        </div>

        <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
          <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold block mb-1">Active Port</span>
          <div className="flex items-center space-x-2 text-slate-200">
            <RefreshCw className="w-4 h-4 text-amber-400" />
            <span className="text-sm font-mono truncate">{port}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
