import { Download, Lock, MapPinned, MessageCircle, Phone, Share2 } from "lucide-react";
import { StatusPill } from "@/components/ui/badge";
import { Button, buttonVariants } from "@/components/ui/button";
import {
  computeCommission,
  computeOwnerCommission,
  computeRenterCommission,
  fmtMoney,
  gmapsHref,
  type RoomPublic,
} from "@/lib/rooms-model";
import { cn } from "@/lib/utils";

export function FlyerCard({
  room,
  isOwner,
  signedIn,
  onCall,
  onWhatsApp,
  onShare,
  onDownload,
}: {
  room: RoomPublic;
  isOwner: boolean;
  signedIn: boolean;
  onCall: () => void;
  onWhatsApp: () => void;
  onShare: () => void;
  onDownload: () => void;
}) {
  const commission = computeCommission(room);
  const ownerAmt = computeOwnerCommission(room);
  const renterAmt = computeRenterCommission(room);
  const commLabel =
    `Share this room, earn ${fmtMoney(commission, room.currency)}` +
    (renterAmt > 0
      ? ` (${fmtMoney(ownerAmt, room.currency)} from owner + ${fmtMoney(renterAmt, room.currency)} from renter)`
      : "");

  return (
    <article className="relative rounded-lg border border-line bg-card p-5 pt-5 shadow-[var(--shadow-border)]">
      <span
        aria-hidden="true"
        className="absolute -top-1.5 left-1/2 size-2.5 -translate-x-1/2 rounded-full bg-brass shadow-[0_1px_2px_rgba(0,0,0,.25)]"
      />
      <StatusPill
        tone={room.status === "rented" ? "rented" : "available"}
        className="absolute top-3.5 right-3.5"
      >
        {room.status === "rented" ? "Rented" : "Available"}
      </StatusPill>
      <h3 className="font-serif pr-16 text-[19px] font-semibold leading-snug text-ink">
        {room.title}
      </h3>
      <p className="mt-0.5 text-[13px] text-ink-soft">
        {room.location}
        {room.availableFrom ? ` · from ${room.availableFrom}` : ""}
        {isOwner ? " · your listing" : ""}
      </p>
      <p className="mt-2 font-semibold text-brass-deep tabular-nums">
        {fmtMoney(room.rent, room.currency)}{" "}
        <span className="text-[12.5px] font-normal text-ink-soft">
          / month
          {room.deposit ? ` · deposit ${fmtMoney(room.deposit, room.currency)}` : ""}
        </span>
      </p>
      {room.description ? (
        <p className="mt-2 line-clamp-3 text-[13.5px] text-ink/85">{room.description}</p>
      ) : null}
      <div className="mt-3 inline-block rounded-full bg-paper-alt px-2 py-0.5 text-[11.5px] text-brass-deep">
        {commLabel}
      </div>
      {renterAmt > 0 ? (
        <p className="mt-2 text-[11px] text-ink-soft">
          Heads up: a {fmtMoney(renterAmt, room.currency)} finder's fee applies to the renter if you take this room.
        </p>
      ) : null}
      <div className="mt-4 flex flex-wrap gap-2 border-t border-dashed border-line pt-3">
        <Button className="min-w-0 flex-1" size="sm" onClick={onCall}>
          <Phone className="size-3.5" />
          Call owner
          {!signedIn ? <Lock className="size-3 opacity-70" /> : null}
        </Button>
        {room.id /* always allow WhatsApp slot if we'll fetch contact */ ? (
          <Button className="min-w-0 flex-1" size="sm" variant="secondary" onClick={onWhatsApp}>
            <MessageCircle className="size-3.5" />
            WhatsApp
            {!signedIn ? <Lock className="size-3 opacity-70" /> : null}
          </Button>
        ) : null}
        <Button className="min-w-0 flex-1" size="sm" variant="secondary" onClick={onShare}>
          <Share2 className="size-3.5" />
          Share & earn
        </Button>
        <a
          className={cn(buttonVariants({ variant: "secondary", size: "sm" }), "min-w-0 flex-1")}
          href={gmapsHref(room.location)}
          target="_blank"
          rel="noopener noreferrer"
        >
          <MapPinned className="size-3.5" />
          Google Maps
        </a>
        <Button className="min-w-0 flex-1" size="sm" variant="secondary" onClick={onDownload}>
          <Download className="size-3.5" />
          Flyer
        </Button>
        <p className="basis-full text-[11px] text-ink-soft">
          Numbers stay hidden until you tap to contact — sign in required.
        </p>
      </div>
    </article>
  );
}
