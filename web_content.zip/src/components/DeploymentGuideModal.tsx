import { useState } from 'react';
import { Download, Server, ShieldCheck, Smartphone, X } from 'lucide-react';
import { getAuthToken } from '../api.ts';

interface DeploymentGuideModalProps {
  open: boolean;
  isAdmin?: boolean;
  onClose: () => void;
}

export function DeploymentGuideModal({ open, isAdmin = false, onClose }: DeploymentGuideModalProps) {
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [zipError, setZipError] = useState('');

  if (!open) return null;

  const handleDownloadZip = async () => {
    setDownloadingZip(true);
    setZipError('');
    try {
      const token = getAuthToken();
      const response = await fetch('/api/admin/export-zip', {
        credentials: 'include',
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (!response.ok) {
        const errBody = (await response.json().catch(() => ({}))) as { error?: string };
        throw new Error(errBody.error || `Export failed (${response.status})`);
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'social-boost-source.zip';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (err) {
      setZipError(err instanceof Error ? err.message : 'Unable to export ZIP.');
    } finally {
      setDownloadingZip(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-md p-0 sm:p-4">
      <div className="w-full sm:max-w-3xl rounded-t-3xl sm:rounded-2xl sb-surface p-6 sm:p-8 space-y-6 max-h-[90dvh] overflow-y-auto">
        <div className="flex items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div>
            <h2 className="text-lg font-bold text-gradient-aurora">Production Deployment &amp; Android APK Build</h2>
            <p className="text-xs text-slate-300 mt-0.5">
              Native Capacitor Android project included (`android/`), live Razorpay setup, and production launch steps.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close guide"
            className="min-h-[40px] min-w-[40px] rounded-xl bg-white/[0.06] hover:bg-white/[0.12] flex items-center justify-center text-slate-200 cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {isAdmin && (
          <div className="rounded-xl sb-surface-inner border-cyan-400/35 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="text-xs font-bold text-cyan-200">Download Complete Project ZIP</div>
              <p className="text-[11px] text-slate-300 mt-0.5">
                Includes full frontend, backend, Capacitor `android/` project, and GitHub Actions APK workflow.
              </p>
            </div>
            <button
              type="button"
              disabled={downloadingZip}
              onClick={handleDownloadZip}
              className="min-h-[42px] px-4 rounded-xl btn-gradient-primary disabled:opacity-60 text-xs font-semibold text-white inline-flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer shrink-0"
            >
              <Download className="h-4 w-4" />
              <span>{downloadingZip ? 'Creating ZIP...' : 'Download Source ZIP'}</span>
            </button>
          </div>
        )}

        {zipError && (
          <div className="rounded-xl bg-rose-500/15 border border-rose-400/40 px-4 py-2.5 text-xs text-rose-200">
            {zipError}
          </div>
        )}

        {/* Section 1: Server & Database */}
        <section className="space-y-2.5">
          <div className="flex items-center gap-2 text-sm font-semibold text-cyan-300">
            <Server className="h-4 w-4" />
            <span>1. Full-Stack Production Deployment</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Build the Vite frontend and start the Express + SQLite server with persistent volume storage:
          </p>
          <pre className="rounded-xl sb-surface-inner p-4 text-xs font-mono text-cyan-200 overflow-x-auto leading-relaxed">
{`npm install
npm run build
NODE_ENV=production PORT=3000 \\
SESSION_SECRET="<64-char-random-hex>" \\
DATABASE_PATH="/var/data/social_boost.db" \\
npm start`}
          </pre>
        </section>

        {/* Section 2: Razorpay Live Transition */}
        <section className="space-y-2.5">
          <div className="flex items-center gap-2 text-sm font-semibold text-emerald-300">
            <ShieldCheck className="h-4 w-4" />
            <span>2. Automatic Gateway Verification (Razorpay Live)</span>
          </div>
          <ul className="text-xs text-slate-300 space-y-1.5 list-disc pl-5 leading-relaxed">
            <li>Direct UPI QR &amp; UTR verification works immediately out of the box from Admin &rarr; Payments &amp; Refunds.</li>
            <li>For automatic gateway webhook capture, set <code className="font-mono text-fuchsia-300">PAYMENT_MODE="razorpay"</code> with <code className="font-mono text-fuchsia-300">RAZORPAY_KEY_ID</code>, <code className="font-mono text-fuchsia-300">RAZORPAY_KEY_SECRET</code>, and <code className="font-mono text-fuchsia-300">RAZORPAY_WEBHOOK_SECRET</code>.</li>
            <li>Point Razorpay Webhooks to <code className="font-mono text-cyan-300">https://your-domain.com/api/webhooks/razorpay</code> for <code className="font-mono">payment.captured</code>, <code className="font-mono">payment.pending</code>, and <code className="font-mono">payment.failed</code>.</li>
          </ul>
        </section>

        {/* Section 3: Android APK Build */}
        <section className="space-y-2.5">
          <div className="flex items-center gap-2 text-sm font-semibold text-fuchsia-300">
            <Smartphone className="h-4 w-4" />
            <span>3. Compile the Android APK (Pre-Configured `android/` Project)</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            The native Android Capacitor wrapper (<code className="font-mono text-amber-300">capacitor.config.ts</code> and <code className="font-mono text-amber-300">android/</code>) is already generated. Compile the APK on any machine with Java 17+ &amp; Android SDK, or push to GitHub to trigger <code className="font-mono text-cyan-300">.github/workflows/build-android-apk.yml</code>:
          </p>
          <pre className="rounded-xl sb-surface-inner p-4 text-xs font-mono text-amber-200 overflow-x-auto leading-relaxed">
{`# Sync latest web build into android/ and build APK:
CAPACITOR_SERVER_URL="https://your-live-domain.com" npm run apk:sync
cd android && ./gradlew assembleDebug
# APK output: android/app/build/outputs/apk/debug/app-debug.apk`}
          </pre>
        </section>

        <div className="pt-2 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] px-6 rounded-xl btn-gradient-primary text-xs font-semibold text-white cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
