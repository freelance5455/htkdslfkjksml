import { usePlace, type DayPoint } from "@/components/aether/place-context";
import { useConsole } from "@/lib/console-store";
import { formatTemp } from "@/lib/format";
import { weatherIcon, weatherLabel } from "@/lib/weather";

function dayName(day: DayPoint, index: number): string {
  if (index === 0) return "Hoy";
  if (index === 1) return "Mañana";
  const date = new Date(`${day.date}T12:00:00`);
  const name = date.toLocaleDateString("es", { weekday: "short" });
  return name.charAt(0).toUpperCase() + name.slice(1);
}

export function WeatherCard() {
  const place = usePlace();
  const setPanel = useConsole((state) => state.setPanel);
  const Icon = weatherIcon(place.code);

  return (
    <section className="glass home-weather p-5" aria-label="Clima de ahora">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-5xl font-light tabular-nums">{formatTemp(place.temp)}</p>
          <p className="mt-1 text-muted">{place.status === "error" ? "Sin conexión al clima" : weatherLabel(place.code)}</p>
        </div>
        <Icon className="size-8 text-accent" strokeWidth={1.5} aria-hidden="true" />
      </div>
      <dl className="mt-4 grid grid-cols-3 gap-3 text-sm">
        <div>
          <dt className="text-muted">Sensación</dt>
          <dd className="tabular-nums">{formatTemp(place.feels)}</dd>
        </div>
        <div>
          <dt className="text-muted">Viento</dt>
          <dd className="tabular-nums">{place.wind == null ? "—" : `${Math.round(place.wind)} km/h`}</dd>
        </div>
        <div>
          <dt className="text-muted">Humedad</dt>
          <dd className="tabular-nums">{place.humidity == null ? "—" : `${Math.round(place.humidity)}%`}</dd>
        </div>
      </dl>
      <div className="mt-4 flex gap-2 overflow-x-auto">
        {place.hours.slice(0, 5).map((hour) => (
          <div key={hour.time} className="min-w-14 rounded-xl bg-raised px-2 py-2 text-center">
            <p className="text-xs text-muted tabular-nums">{hour.time}</p>
            <p className="mt-1 text-sm tabular-nums">{formatTemp(hour.temp)}</p>
          </div>
        ))}
      </div>
      <button type="button" className="btn-ghost btn mt-3 px-0" onClick={() => setPanel("weather")}>
        Ver pronóstico
      </button>
    </section>
  );
}

export function WeatherPanel() {
  const place = usePlace();
  const Icon = weatherIcon(place.code);

  return (
    <section className="sheet-panel sheet-weather glass scroll-slim p-5" aria-label="Pronóstico">
      <p className="text-sm text-muted">{place.label}</p>
      <div className="mt-2 flex items-end justify-between gap-3">
        <p className="text-6xl font-light tabular-nums">{formatTemp(place.temp)}</p>
        <Icon className="mb-2 size-10 text-accent" strokeWidth={1.5} aria-hidden="true" />
      </div>
      <p className="text-lg">{weatherLabel(place.code)}</p>
      <p className="mt-1 text-sm text-muted">
        Sensación {formatTemp(place.feels)} · Viento {place.wind == null ? "—" : `${Math.round(place.wind)} km/h`} · Humedad{" "}
        {place.humidity == null ? "—" : `${Math.round(place.humidity)}%`}
      </p>
      {place.sunrise && place.sunset ? (
        <p className="mt-1 text-sm text-muted">
          Amanecer {place.sunrise} · Atardecer {place.sunset}
        </p>
      ) : null}
      {place.status === "error" ? (
        <button type="button" className="btn mt-4" onClick={place.reload}>
          Reintentar
        </button>
      ) : null}
      <h2 className="mt-6 text-sm text-muted">Próximas horas</h2>
      <div className="mt-2 flex gap-2 overflow-x-auto pb-1">
        {place.hours.map((hour) => {
          const HourIcon = weatherIcon(hour.code);
          return (
            <div key={hour.time} className="min-w-16 rounded-xl bg-raised px-2 py-3 text-center">
              <p className="text-xs text-muted tabular-nums">{hour.time}</p>
              <HourIcon className="mx-auto mt-2 size-4 text-accent" strokeWidth={1.5} aria-hidden="true" />
              <p className="mt-2 text-sm tabular-nums">{formatTemp(hour.temp)}</p>
              <p className="text-xs text-muted tabular-nums">{hour.pop}%</p>
            </div>
          );
        })}
      </div>
      <h2 className="mt-6 text-sm text-muted">Siete días</h2>
      <ul className="mt-2 divide-y divide-line">
        {place.days.map((day, index) => {
          const DayIcon = weatherIcon(day.code);
          return (
            <li key={day.date} className="flex items-center gap-3 py-3">
              <span className="w-20 text-sm">{dayName(day, index)}</span>
              <DayIcon className="size-4 text-accent" strokeWidth={1.5} aria-hidden="true" />
              <span className="ml-auto text-sm text-muted tabular-nums">{formatTemp(day.min)}</span>
              <span className="text-sm tabular-nums">{formatTemp(day.max)}</span>
            </li>
          );
        })}
      </ul>
      {place.status === "loading" && place.temp == null ? <p className="mt-4 text-sm text-muted">Leyendo el cielo…</p> : null}
    </section>
  );
}
