import { useState } from "react";
import { Search, X } from "lucide-react";
import { searchPlaces, type PlaceHit } from "@/lib/aether-api";
import { useNav } from "@/components/aether/nav-context";
import { formatDistance, formatTravel } from "@/lib/format";

export function MapSearch() {
  const { destination, route, routing, routeError, setDestination, clearRoute } = useNav();
  const [query, setQuery] = useState("");
  const [hits, setHits] = useState<PlaceHit[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function run(value: string) {
    setBusy(true);
    setError(null);
    const result = await searchPlaces({ data: { q: value } });
    setBusy(false);
    if (!result.ok) {
      setHits([]);
      setError(result.error);
      return;
    }
    setHits(result.hits);
    if (result.hits.length === 0) setError("Sin resultados para esa búsqueda.");
  }

  return (
    <form
      className="map-search glass p-3"
      onSubmit={(event) => {
        event.preventDefault();
        if (query.trim().length >= 2) void run(query.trim());
      }}
    >
      <div className="flex gap-2">
        <input
          className="field"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="A dónde vamos"
          aria-label="Buscar destino"
          enterKeyHint="search"
        />
        <button type="submit" className="btn-accent btn" aria-label="Buscar destino" disabled={busy || query.trim().length < 2}>
          <Search className="size-4" strokeWidth={1.5} />
        </button>
      </div>
      {error ? <p className="mt-2 text-sm text-muted">{error}</p> : null}
      {hits.length > 0 ? (
        <ul className="mt-2 max-h-52 overflow-auto">
          {hits.map((hit) => (
            <li key={hit.id}>
              <button
                type="button"
                className="w-full rounded-xl px-2 py-2 text-left text-sm hover:bg-raised"
                onClick={() => {
                  setDestination(hit);
                  setHits([]);
                  setQuery(hit.label);
                  setError(null);
                }}
              >
                {hit.label}
              </button>
            </li>
          ))}
        </ul>
      ) : null}
      {destination ? (
        <div className="mt-3 flex items-start justify-between gap-3">
          <div>
            <p className="text-sm">{destination.label}</p>
            <p className="text-sm text-accent tabular-nums">
              {routing ? "Trazando ruta…" : route ? `${formatTravel(route.durationS)} · ${formatDistance(route.distanceM)}` : routeError}
            </p>
          </div>
          <button type="button" className="btn" aria-label="Quitar ruta" onClick={clearRoute}>
            <X className="size-4" strokeWidth={1.5} />
          </button>
        </div>
      ) : (
        <p className="mt-2 text-xs text-muted">Busca una dirección y traza la ruta desde donde estás.</p>
      )}
    </form>
  );
}
