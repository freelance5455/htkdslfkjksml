import { useEffect } from "react";
import { ClockCard } from "@/components/aether/ClockCard";
import { Dock } from "@/components/aether/Dock";
import { MapCanvas } from "@/components/aether/MapCanvas";
import { MapSearch } from "@/components/aether/MapSearch";
import { MusicLibrary } from "@/components/aether/MusicLibrary";
import { NavProvider } from "@/components/aether/nav-context";
import { PlaceProvider, usePlace } from "@/components/aether/place-context";
import { Player } from "@/components/aether/Player";
import { WeatherCard, WeatherPanel } from "@/components/aether/WeatherPanel";
import { useConsole } from "@/lib/console-store";
import { formatTravel } from "@/lib/format";
import { useNav } from "@/components/aether/nav-context";

function Header() {
  const place = usePlace();
  const route = useNav().route;
  return (
    <header className="aether-header">
      <p className="wordmark">Aether</p>
      <p className="truncate text-sm text-muted">
        {route ? `En ruta · ${formatTravel(route.durationS)}` : place.label}
      </p>
    </header>
  );
}

function Shell() {
  const panel = useConsole((state) => state.panel);
  const dim = useConsole((state) => state.dim);

  useEffect(() => {
    void useConsole.persist.rehydrate();
  }, []);

  return (
    <main className="aether-root">
      <MapCanvas interactive={panel === "map"} />
      <div className="map-scrim" />
      <Header />
      {panel === "home" ? (
        <div className="home-stack scroll-slim">
          <ClockCard />
          <WeatherCard />
        </div>
      ) : null}
      {panel === "weather" ? <WeatherPanel /> : null}
      {panel === "music" ? <MusicLibrary /> : null}
      {panel === "map" ? <MapSearch /> : null}
      <Player cinema={panel === "music"} />
      {dim > 0 ? <div className="dim-veil" style={{ opacity: dim / 100 }} /> : null}
      <Dock />
    </main>
  );
}

export function Aether() {
  return (
    <PlaceProvider>
      <NavProvider>
        <Shell />
      </NavProvider>
    </PlaceProvider>
  );
}
