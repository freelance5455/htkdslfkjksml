import { useEffect, useState } from "react";
import { searchTracks, type TrackHit } from "@/lib/aether-api";
import { Transport } from "@/components/aether/Player";
import { useConsole } from "@/lib/console-store";
import { formatDuration } from "@/lib/format";
import { parseMediaUrl } from "@/lib/media";

const STATIONS = [
  { label: "Lo-fi", query: "lofi hip hop radio" },
  { label: "Jazz", query: "jazz cafe music" },
  { label: "Pop", query: "pop hits 2026" },
  { label: "Rock", query: "classic rock mix" },
  { label: "Clásica", query: "classical music playlist" },
  { label: "Latina", query: "música latina hits" },
  { label: "Foco", query: "deep focus music" },
  { label: "Electro", query: "electronic music mix" },
];

export function MusicLibrary() {
  const setMedia = useConsole((state) => state.setMedia);
  const pendingQuery = useConsole((state) => state.pendingQuery);
  const setPendingQuery = useConsole((state) => state.setPendingQuery);
  const [query, setQuery] = useState("");
  const [tracks, setTracks] = useState<TrackHit[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function runSearch(value: string, playFirst = false) {
    const parsed = parseMediaUrl(value);
    if (parsed) {
      setMedia(parsed);
      setError(null);
      setTracks([]);
      return;
    }
    setBusy(true);
    setError(null);
    const result = await searchTracks({ data: { q: value } });
    setBusy(false);
    if (!result.ok) {
      setTracks([]);
      setError(result.error);
      return;
    }
    setTracks(result.tracks);
    const first = result.tracks[0];
    if (playFirst && first) {
      setMedia({ kind: "video", id: first.id, title: first.title, author: first.author });
    }
  }

  useEffect(() => {
    if (!pendingQuery) return;
    setQuery(pendingQuery);
    setPendingQuery(null);
    void runSearch(pendingQuery, true);
    // runSearch identity is local; pendingQuery is the trigger.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pendingQuery, setPendingQuery]);

  return (
    <section className="sheet-panel sheet-music glass scroll-slim p-4 md:p-5" aria-label="YouTube Music">
      <p className="text-xs tracking-widest text-muted uppercase">YouTube Music</p>
      <h2 className="mt-1 text-2xl font-light">Qué quieres oír</h2>
      <form
        className="mt-4 flex gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          if (query.trim().length >= 2) void runSearch(query.trim(), true);
        }}
      >
        <input
          className="field"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Tema, artista o enlace"
          aria-label="Buscar en YouTube Music"
          enterKeyHint="search"
        />
        <button type="submit" className="btn-accent btn" disabled={busy || query.trim().length < 2}>
          {busy ? "…" : "Buscar"}
        </button>
      </form>
      <div className="mt-4">
        <Transport />
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {STATIONS.map((station) => (
          <button
            key={station.label}
            type="button"
            className="btn"
            onClick={() => {
              setQuery(station.query);
              void runSearch(station.query, true);
            }}
          >
            {station.label}
          </button>
        ))}
      </div>
      {error ? (
        <p className="mt-4 text-sm text-muted">
          {error}{" "}
          <a className="text-accent underline-offset-2 hover:underline" href="https://music.youtube.com" target="_blank" rel="noreferrer">
            Abrir YouTube Music
          </a>
        </p>
      ) : null}
      <ul className="mt-4 divide-y divide-line">
        {tracks.map((track) => (
          <li key={track.id}>
            <button
              type="button"
              className="flex w-full items-center gap-3 py-3 text-left"
              onClick={() => setMedia({ kind: "video", id: track.id, title: track.title, author: track.author })}
            >
              <img
                src={`https://i.ytimg.com/vi/${track.id}/hqdefault.jpg`}
                alt=""
                className="size-14 rounded-lg object-cover outline outline-1 -outline-offset-1 outline-fg/10"
              />
              <span className="min-w-0 flex-1">
                <span className="block truncate">{track.title}</span>
                <span className="block truncate text-sm text-muted">{track.author}</span>
              </span>
              <span className="text-sm text-muted tabular-nums">{formatDuration(track.duration)}</span>
            </button>
          </li>
        ))}
      </ul>
      {tracks.length === 0 && !busy && !error ? (
        <p className="mt-4 text-sm text-muted">Elige una estación o busca un tema. El audio sigue mientras usas el mapa.</p>
      ) : null}
    </section>
  );
}
