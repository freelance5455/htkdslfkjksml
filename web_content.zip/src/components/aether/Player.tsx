import { useEffect, useRef } from "react";
import { Pause, Play } from "lucide-react";
import { useConsole } from "@/lib/console-store";
import { embedSrc } from "@/lib/media";
import { bindPlayerFrame, playerCmd } from "@/lib/player-bus";

export function Player({ cinema }: { cinema: boolean }) {
  const media = useConsole((state) => state.media);
  const volume = useConsole((state) => state.volume);
  const paused = useConsole((state) => state.paused);
  const setPaused = useConsole((state) => state.setPaused);
  const setVolume = useConsole((state) => state.setVolume);
  const setPanel = useConsole((state) => state.setPanel);
  const origin = typeof window === "undefined" ? "" : window.location.origin;
  const frameRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    playerCmd("setVolume", [volume]);
  }, [volume, media]);

  function syncFrame() {
    bindPlayerFrame(frameRef.current?.contentWindow ?? null);
    playerCmd("setVolume", [useConsole.getState().volume]);
  }

  function toggle() {
    const next = !useConsole.getState().paused;
    setPaused(next);
    playerCmd(next ? "pauseVideo" : "playVideo");
  }

  return (
    <div className={cinema ? "player-cinema glass" : "player-mini glass"}>
      <div className={cinema ? "h-full" : "flex h-full"}>
        <div className={cinema ? "h-full w-full bg-bg" : "h-full shrink-0 bg-bg"}>
          {media ? (
            <iframe
              ref={frameRef}
              title={media.title}
              src={`${embedSrc(media)}&origin=${encodeURIComponent(origin)}`}
              className={cinema ? "h-full w-full" : "h-full w-36 md:w-44"}
              allow="autoplay; encrypted-media; picture-in-picture"
              allowFullScreen
              referrerPolicy="strict-origin-when-cross-origin"
              onLoad={syncFrame}
            />
          ) : (
            <div className={cinema ? "grid h-full place-items-center" : "grid h-full w-24 place-items-center"}>
              <div className="disc" />
            </div>
          )}
        </div>
        {!cinema ? (
          <div className="flex min-w-0 flex-1 flex-col justify-center gap-1 px-3">
            <p className="truncate text-sm">{media?.title ?? "Nada sonando"}</p>
            <p className="truncate text-xs text-muted">{media?.author || "YouTube Music"}</p>
            <div className="mt-1 flex items-center gap-2">
              <button
                type="button"
                className="btn h-9 min-h-9 w-9 px-0"
                aria-label={media ? (paused ? "Reproducir" : "Pausa") : "Abrir música"}
                onClick={() => (media ? toggle() : setPanel("music"))}
              >
                {media && !paused ? (
                  <Pause className="size-4" strokeWidth={1.5} />
                ) : (
                  <Play className="ml-px size-4" strokeWidth={1.5} />
                )}
              </button>
              <input
                className="range"
                type="range"
                min={0}
                max={100}
                value={volume}
                aria-label="Volumen"
                onChange={(event) => setVolume(Number(event.target.value))}
              />
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}

export function Transport() {
  const media = useConsole((state) => state.media);
  const paused = useConsole((state) => state.paused);
  const volume = useConsole((state) => state.volume);
  const setPaused = useConsole((state) => state.setPaused);
  const setVolume = useConsole((state) => state.setVolume);

  function toggle() {
    if (!media) return;
    const next = !paused;
    setPaused(next);
    playerCmd(next ? "pauseVideo" : "playVideo");
  }

  return (
    <div className="flex items-center gap-3">
      <button type="button" className="btn-accent btn" onClick={toggle} disabled={!media} aria-label={paused ? "Reproducir" : "Pausa"}>
        {paused ? <Play className="ml-px size-4" strokeWidth={1.5} /> : <Pause className="size-4" strokeWidth={1.5} />}
        {paused ? "Reproducir" : "Pausa"}
      </button>
      <label className="flex min-w-0 flex-1 items-center gap-2 text-xs text-muted">
        Volumen
        <input
          className="range"
          type="range"
          min={0}
          max={100}
          value={volume}
          aria-label="Volumen"
          onChange={(event) => setVolume(Number(event.target.value))}
        />
      </label>
    </div>
  );
}
