import { useEffect, useRef, useState } from "react";
import type { GeoJSON as GeoLayer, Layer, Map as LeafletMap } from "leaflet";
import type { LineString } from "geojson";
import { LocateFixed, Minus, Plus } from "lucide-react";
import { useNav } from "@/components/aether/nav-context";
import { usePlace } from "@/components/aether/place-context";
import { cn } from "@/lib/cn";

function motionDuration(): number {
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return 0;
  return 0.7;
}

export function MapCanvas({ interactive }: { interactive: boolean }) {
  const { lat, lon } = usePlace();
  const { destination, route } = useNav();
  const hostRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<LeafletMap | null>(null);
  const meRef = useRef<Layer | null>(null);
  const destRef = useRef<Layer | null>(null);
  const routeRef = useRef<GeoLayer | null>(null);
  const followRef = useRef(true);
  const locRef = useRef({ lat, lon });
  locRef.current = { lat, lon };
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    let dead = false;
    let map: LeafletMap | null = null;
    void (async () => {
      const L = await import("leaflet");
      await import("leaflet/dist/leaflet.css");
      if (dead || !hostRef.current) return;
      map = L.map(hostRef.current, {
        zoomControl: false,
        attributionControl: true,
        center: [locRef.current.lat, locRef.current.lon],
        zoom: 12,
        minZoom: 3,
        maxZoom: 16,
      });
      map.attributionControl.setPrefix("");
      const base = "https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}";
      const labels =
        "https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Reference/MapServer/tile/{z}/{y}/{x}";
      L.tileLayer(base, {
        maxZoom: 16,
        attribution: "&copy; Esri",
      }).addTo(map);
      L.tileLayer(labels, { maxZoom: 16, opacity: 0.9 }).addTo(map);
      map.on("dragstart", () => {
        followRef.current = false;
      });
      mapRef.current = map;
      window.setTimeout(() => map?.invalidateSize(), 80);
      if (!dead) setReady(true);
    })();
    return () => {
      dead = true;
      map?.remove();
      mapRef.current = null;
      setReady(false);
    };
  }, []);

  useEffect(() => {
    if (!ready) return;
    const map = mapRef.current;
    if (!map) return;
    let dead = false;
    void (async () => {
      const L = await import("leaflet");
      if (dead || !mapRef.current) return;
      meRef.current?.remove();
      const icon = L.divIcon({
        className: "aether-pin-wrap",
        html: '<div class="aether-pin"></div>',
        iconSize: [18, 18],
        iconAnchor: [9, 9],
      });
      meRef.current = L.marker([lat, lon], { icon, interactive: false, keyboard: false }).addTo(map);
      if (followRef.current && !destination) {
        map.flyTo([lat, lon], Math.max(map.getZoom(), 12), { duration: motionDuration() });
      }
    })();
    return () => {
      dead = true;
    };
  }, [ready, lat, lon, destination]);

  useEffect(() => {
    if (!ready) return;
    const map = mapRef.current;
    if (!map) return;
    let dead = false;
    void (async () => {
      const L = await import("leaflet");
      if (dead || !mapRef.current) return;
      destRef.current?.remove();
      destRef.current = null;
      if (!destination) return;
      followRef.current = false;
      const icon = L.divIcon({
        className: "aether-pin-wrap",
        html: '<div class="aether-dest"></div>',
        iconSize: [12, 12],
        iconAnchor: [6, 6],
      });
      destRef.current = L.marker([destination.lat, destination.lon], {
        icon,
        interactive: false,
        keyboard: false,
      }).addTo(map);
    })();
    return () => {
      dead = true;
    };
  }, [ready, destination]);

  useEffect(() => {
    if (!ready) return;
    const map = mapRef.current;
    if (!map) return;
    let dead = false;
    void (async () => {
      const L = await import("leaflet");
      if (dead || !mapRef.current) return;
      routeRef.current?.remove();
      routeRef.current = null;
      if (!route) return;
      const accent =
        getComputedStyle(document.documentElement).getPropertyValue("--color-accent").trim() || "#e4c4a0";
      const layer = L.geoJSON(route.geometry as LineString, {
        style: { color: accent, weight: 4, opacity: 0.92 },
      }).addTo(map);
      routeRef.current = layer;
      const narrow = window.matchMedia("(max-width: 767px)").matches;
      map.fitBounds(layer.getBounds(), {
        paddingTopLeft: narrow ? [28, 150] : [48, 96],
        paddingBottomRight: narrow ? [28, 180] : [120, 140],
      });
    })();
    return () => {
      dead = true;
    };
  }, [ready, route]);

  function locate() {
    followRef.current = true;
    mapRef.current?.flyTo([locRef.current.lat, locRef.current.lon], 14, { duration: motionDuration() });
  }

  return (
    <div className="absolute inset-0 z-0">
      <div ref={hostRef} className="h-full w-full" />
      <div className={cn("map-zoom", interactive && "is-open")}>
        <button type="button" className="btn" aria-label="Acercar" onClick={() => mapRef.current?.zoomIn()}>
          <Plus className="size-4" strokeWidth={1.5} />
        </button>
        <button type="button" className="btn" aria-label="Alejar" onClick={() => mapRef.current?.zoomOut()}>
          <Minus className="size-4" strokeWidth={1.5} />
        </button>
        <button type="button" className="btn" aria-label="Mi ubicación" onClick={locate}>
          <LocateFixed className="size-4" strokeWidth={1.5} />
        </button>
      </div>
    </div>
  );
}
