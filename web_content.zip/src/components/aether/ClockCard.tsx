import { useEffect, useState } from "react";
import { usePlace } from "@/components/aether/place-context";
import { formatTemp, prettyDate } from "@/lib/format";
import { weatherLabel } from "@/lib/weather";

export function ClockCard() {
  const [now, setNow] = useState<Date | null>(null);
  const place = usePlace();

  useEffect(() => {
    const tick = () => setNow(new Date());
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, []);

  const hours = now ? String(now.getHours()).padStart(2, "0") : "--";
  const minutes = now ? String(now.getMinutes()).padStart(2, "0") : "--";
  const seconds = now ? String(now.getSeconds()).padStart(2, "0") : "--";

  return (
    <section className="glass p-5" aria-label="Hora">
      <p className="text-sm text-muted">{now ? prettyDate(now) : " "}</p>
      <div className="mt-2 flex items-end gap-2">
        <p className="text-7xl leading-none font-light tracking-tight tabular-nums md:text-8xl">
          {hours}:{minutes}
        </p>
        <p className="mb-1 w-10 text-xl text-muted tabular-nums">{seconds}</p>
      </div>
      <p className="mt-4 truncate text-sm text-muted">{place.label}</p>
      <p className="mt-1 text-lg">
        <span className="tabular-nums">{formatTemp(place.temp)}</span>
        <span className="text-muted"> · {weatherLabel(place.code)}</span>
      </p>
    </section>
  );
}
