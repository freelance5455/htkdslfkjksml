import { useState } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { ChevronDown, ChevronUp, SlidersHorizontal, X } from "lucide-react";
import { ICON_OPTIONS, resolveIcon } from "@/components/aether/icons";
import { useConsole, type ActionButton, type ActionKind, type PanelId } from "@/lib/console-store";
import { safeHttpUrl } from "@/lib/format";

const PANELS: { id: PanelId; label: string }[] = [
  { id: "home", label: "Inicio" },
  { id: "map", label: "Mapas" },
  { id: "music", label: "Música" },
  { id: "weather", label: "Clima" },
];

type Draft = {
  id: string | null;
  label: string;
  icon: string;
  kind: ActionKind;
  panel: PanelId;
  url: string;
  query: string;
};

const EMPTY: Draft = {
  id: null,
  label: "",
  icon: "star",
  kind: "panel",
  panel: "music",
  url: "https://",
  query: "",
};

export function CustomizeSheet() {
  const actions = useConsole((state) => state.actions);
  const addAction = useConsole((state) => state.addAction);
  const updateAction = useConsole((state) => state.updateAction);
  const removeAction = useConsole((state) => state.removeAction);
  const moveAction = useConsole((state) => state.moveAction);
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<Draft>(EMPTY);
  const [error, setError] = useState<string | null>(null);

  function load(action: ActionButton) {
    setDraft({
      id: action.id,
      label: action.label,
      icon: action.icon,
      kind: action.kind,
      panel: action.panel ?? "home",
      url: action.url ?? "https://",
      query: action.query ?? "",
    });
    setError(null);
  }

  function save() {
    const label = draft.label.trim().slice(0, 18);
    if (label.length < 1) {
      setError("Ponle un nombre corto.");
      return;
    }
    const action: ActionButton = {
      id: draft.id ?? crypto.randomUUID(),
      label,
      icon: draft.icon,
      kind: draft.kind,
      panel: draft.kind === "panel" ? draft.panel : undefined,
      url: undefined,
      query: undefined,
    };
    if (draft.kind === "url") {
      const url = safeHttpUrl(draft.url);
      if (!url) {
        setError("El enlace tiene que empezar por https://");
        return;
      }
      action.url = url;
    }
    if (draft.kind === "search") {
      const query = draft.query.trim().slice(0, 80);
      if (query.length < 2) {
        setError("Escribe qué música buscar.");
        return;
      }
      action.query = query;
    }
    if (draft.id) updateAction(action);
    else if (actions.length >= 8) {
      setError("La barra admite hasta 8 acciones.");
      return;
    } else addAction(action);
    setDraft(EMPTY);
    setError(null);
  }

  return (
    <Dialog.Root open={open} onOpenChange={setOpen}>
      <Dialog.Trigger asChild>
        <button type="button" className="dock-btn" aria-label="Personalizar acciones">
          <SlidersHorizontal className="size-5" strokeWidth={1.5} />
          <span>Ajustes</span>
        </button>
      </Dialog.Trigger>
      <Dialog.Portal>
        <Dialog.Overlay className="sheet-overlay" />
        <Dialog.Content className="sheet-content scroll-slim" aria-describedby="acciones-ayuda">
          <div className="flex items-start justify-between gap-3">
            <div>
              <Dialog.Title className="text-2xl font-light">Acciones</Dialog.Title>
              <Dialog.Description id="acciones-ayuda" className="mt-1 text-sm text-muted">
                Estos botones viven en la barra inferior. Pueden abrir una pantalla, un enlace o una búsqueda musical.
              </Dialog.Description>
            </div>
            <Dialog.Close className="btn" aria-label="Cerrar">
              <X className="size-4" strokeWidth={1.5} />
            </Dialog.Close>
          </div>

          <ul className="mt-5 divide-y divide-line">
            {actions.map((action, index) => {
              const Icon = resolveIcon(action.icon);
              return (
                <li key={action.id} className="flex items-center gap-2 py-2">
                  <Icon className="size-4 text-accent" strokeWidth={1.5} aria-hidden="true" />
                  <span className="min-w-0 flex-1 truncate">{action.label}</span>
                  <button type="button" className="btn-ghost btn" aria-label={`Subir ${action.label}`} onClick={() => moveAction(action.id, -1)} disabled={index === 0}>
                    <ChevronUp className="size-4" strokeWidth={1.5} />
                  </button>
                  <button
                    type="button"
                    className="btn-ghost btn"
                    aria-label={`Bajar ${action.label}`}
                    onClick={() => moveAction(action.id, 1)}
                    disabled={index === actions.length - 1}
                  >
                    <ChevronDown className="size-4" strokeWidth={1.5} />
                  </button>
                  <button type="button" className="btn" onClick={() => load(action)}>
                    Editar
                  </button>
                  <button type="button" className="btn-ghost btn" onClick={() => removeAction(action.id)} disabled={actions.length <= 1}>
                    Quitar
                  </button>
                </li>
              );
            })}
          </ul>

          <form
            className="mt-5"
            onSubmit={(event) => {
              event.preventDefault();
              save();
            }}
          >
            <h2 className="text-sm text-muted">{draft.id ? "Editar acción" : "Nueva acción"}</h2>
            <label className="mt-3 block text-sm" htmlFor="accion-nombre">
              Nombre
            </label>
            <input
              id="accion-nombre"
              className="field mt-1"
              value={draft.label}
              maxLength={18}
              onChange={(event) => setDraft({ ...draft, label: event.target.value })}
            />
            <p className="mt-4 text-sm">Icono</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {ICON_OPTIONS.map((name) => {
                const Icon = resolveIcon(name);
                return (
                  <button
                    key={name}
                    type="button"
                    className="icon-pick"
                    aria-label={name}
                    aria-pressed={draft.icon === name}
                    onClick={() => setDraft({ ...draft, icon: name })}
                  >
                    <Icon className="size-4" strokeWidth={1.5} />
                  </button>
                );
              })}
            </div>
            <label className="mt-4 block text-sm" htmlFor="accion-tipo">
              Tipo
            </label>
            <select
              id="accion-tipo"
              className="field mt-1"
              value={draft.kind}
              onChange={(event) => setDraft({ ...draft, kind: event.target.value as ActionKind })}
            >
              <option value="panel">Pantalla</option>
              <option value="url">Enlace</option>
              <option value="search">Búsqueda musical</option>
            </select>
            {draft.kind === "panel" ? (
              <select
                className="field mt-2"
                aria-label="Pantalla"
                value={draft.panel}
                onChange={(event) => setDraft({ ...draft, panel: event.target.value as PanelId })}
              >
                {PANELS.map((panel) => (
                  <option key={panel.id} value={panel.id}>
                    {panel.label}
                  </option>
                ))}
              </select>
            ) : null}
            {draft.kind === "url" ? (
              <input
                className="field mt-2"
                aria-label="Enlace"
                inputMode="url"
                value={draft.url}
                onChange={(event) => setDraft({ ...draft, url: event.target.value })}
                placeholder="https://"
              />
            ) : null}
            {draft.kind === "search" ? (
              <input
                className="field mt-2"
                aria-label="Búsqueda musical"
                value={draft.query}
                onChange={(event) => setDraft({ ...draft, query: event.target.value })}
                placeholder="jazz de noche"
              />
            ) : null}
            {error ? <p className="mt-2 text-sm text-muted">{error}</p> : null}
            <div className="mt-4 flex gap-2">
              <button type="submit" className="btn-accent btn">
                Guardar
              </button>
              {draft.id ? (
                <button type="button" className="btn" onClick={() => { setDraft(EMPTY); setError(null); }}>
                  Cancelar
                </button>
              ) : null}
            </div>
          </form>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
