import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { routeDrive, type PlaceHit, type RouteInfo } from "@/lib/aether-api";
import { usePlace } from "@/components/aether/place-context";

type NavState = {
  destination: PlaceHit | null;
  route: RouteInfo | null;
  routing: boolean;
  routeError: string | null;
  setDestination: (place: PlaceHit | null) => void;
  clearRoute: () => void;
};

const NavContext = createContext<NavState | null>(null);

export function NavProvider({ children }: { children: ReactNode }) {
  const { lat, lon } = usePlace();
  const [destination, setDestination] = useState<PlaceHit | null>(null);
  const [route, setRoute] = useState<RouteInfo | null>(null);
  const [routing, setRouting] = useState(false);
  const [routeError, setRouteError] = useState<string | null>(null);

  useEffect(() => {
    if (!destination) {
      setRoute(null);
      setRouteError(null);
      setRouting(false);
      return;
    }
    let cancel = false;
    setRouting(true);
    setRouteError(null);
    void routeDrive({
      data: { fromLat: lat, fromLon: lon, toLat: destination.lat, toLon: destination.lon },
    }).then((result) => {
      if (cancel) return;
      setRouting(false);
      if (result.ok) {
        setRoute(result.route);
        setRouteError(null);
      } else {
        setRoute(null);
        setRouteError(result.error);
      }
    });
    return () => {
      cancel = true;
    };
  }, [destination, lat, lon]);

  const value = useMemo<NavState>(
    () => ({
      destination,
      route,
      routing,
      routeError,
      setDestination,
      clearRoute: () => setDestination(null),
    }),
    [destination, route, routing, routeError],
  );

  return <NavContext.Provider value={value}>{children}</NavContext.Provider>;
}

export function useNav(): NavState {
  const value = useContext(NavContext);
  if (!value) throw new Error("useNav fuera de proveedor");
  return value;
}
