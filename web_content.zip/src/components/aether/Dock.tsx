import { useEffect, useState } from "react";
import { SunMedium } from "lucide-react";
import { CustomizeSheet } from "@/components/aether/CustomizeSheet";
import { resolveIcon } from "@/components/aether/icons";
import { usePlace } from "@/components/aether/place-context";
import { useConsole, type ActionButton } from "@/lib/console-store";
import { formatTemp, safeHttpUrl } from "@/lib/format";

function ActionControl({ action }: { action: ActionButton }) {
  const panel = useConsole((state) => state.panel);
  const setPanel = useConsole((state) => state.setPanel);
  const setPendingQuery = useConsole((state) => state.setPendingQuery);
  const Icon = resolveIcon(action.icon);
  const pressed = action.kind === "panel" && action.panel === panel;

  if (action.kind === "url") {
    const href = safeHttpUrl(action.url ?? "");
    if (!href) return null;
    return (
      <a className="dock-btn" href={href} target="_blank" rel="noreferrer">
        <Icon className="size-5" strokeWidth={1.5} />
        <span>{action.label}</span>
      </a>
    );
  }

  return (
    <button
      type="button"
      className="dock-btn"
      aria-pressed={pressed}
      onClick={() => {
        if (action.kind === "panel" && action.panel) setPanel(action.panel);
        if (action.kind === "search" && action.query) {
          setPanel("music");
          setPendingQuery(action.query);
        }
      }}
    >
      <Icon className="size-5" strokeWidth={1.5} />
      <span>{action.label}</span>
    </button>
  );
}

export function Dock() {
  const actions = useConsole((state) => state.actions);
  const setPanel = useConsole((state) => state.setPanel);
  const dim = useConsole((state) => state.dim);
  const setDim = useConsole((state) => state.setDim);
  const place = usePlace();
  const [brightOpen, setBrightOpen] = useState(false);
  const brightness = 100 - dim;

  useEffect(() => {
    if (!brightOpen) return;
    function close(event: PointerEvent) {
      const target = event.target;
      if (target instanceof Element && target.closest("[data-bright]")) return;
      setBrightOpen(false);
    }
    window.addEventListener("pointerdown", close);
    return () => window.removeEventListener("pointerdown", close);
  }, [brightOpen]);

  return (
    <footer className="aether-dock">
      <button
        type="button"
        className="temp-btn"
        onClick={() => setPanel("weather")}
        aria-label={`Clima, ${formatTemp(place.temp)}`}
      >
        {formatTemp(place.temp)}
      </button>
      <div className="dock-rule" />
      <div className="dock-scroll">
        {actions.map((action) => (
          <ActionControl key={action.id} action={action} />
        ))}
      </div>
      <div className="relative" data-bright="">
        <button
          type="button"
          className="dock-btn"
          aria-expanded={brightOpen}
          aria-label="Brillo"
          onClick={() => setBrightOpen((open) => !open)}
        >
          <SunMedium className="size-5" strokeWidth={1.5} />
          <span>Brillo</span>
        </button>
        {brightOpen ? (
          <div className="bright-pop glass">
            <p className="text-sm">Brillo de la pantalla</p>
            <input
              className="range mt-3"
              type="range"
              min={40}
              max={100}
              value={brightness}
              aria-label="Nivel de brillo"
              onChange={(event) => setDim(100 - Number(event.target.value))}
            />
          </div>
        ) : null}
      </div>
      <CustomizeSheet />
    </footer>
  );
}
