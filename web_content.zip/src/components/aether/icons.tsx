import {
  Bookmark,
  Calendar,
  Car,
  Clock,
  CloudSun,
  Coffee,
  Compass,
  Globe,
  Headphones,
  Heart,
  House,
  Link2,
  Map,
  Mic,
  Moon,
  Music2,
  Navigation,
  Radio,
  Star,
  Sun,
  Thermometer,
  Zap,
  type LucideIcon,
} from "lucide-react";

export const ICONS: Record<string, LucideIcon> = {
  house: House,
  map: Map,
  music: Music2,
  cloud: CloudSun,
  headphones: Headphones,
  compass: Compass,
  radio: Radio,
  coffee: Coffee,
  moon: Moon,
  heart: Heart,
  globe: Globe,
  zap: Zap,
  calendar: Calendar,
  bookmark: Bookmark,
  star: Star,
  navigation: Navigation,
  link: Link2,
  mic: Mic,
  car: Car,
  sun: Sun,
  thermo: Thermometer,
  clock: Clock,
};

export const ICON_OPTIONS = Object.keys(ICONS);

export function resolveIcon(name: string): LucideIcon {
  return ICONS[name] ?? Star;
}
