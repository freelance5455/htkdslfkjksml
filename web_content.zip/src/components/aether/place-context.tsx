import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { reversePlace } from "@/lib/aether-api";

export type HourPoint = { time: string; temp: number; code: number; pop: number };
export type DayPoint = { date: string; min: number; max: number; code: number };

type PlaceState = {
  status: "loading" | "ready" | "error";
  label: string;
  lat: number;
  lon: number;
  temp: number | null;
  feels: number | null;
  code: number | null;
  wind: number | null;
  humidity: number | null;
  isDay: boolean;
  hours: HourPoint[];
  days: DayPoint[];
  sunrise: string;
  sunset: string;
  reload: () => void;
};

const FALLBACK = { lat: -34.6037, lon: -58.3816, label: "Buenos Aires" };

const PlaceContext = createContext<PlaceState | null>(null);

type Forecast = {
  current?: {
    time?: string;
    temperature_2m?: number;
    apparent_temperature?: number;
    weather_code?: number;
    wind_speed_10m?: number;
    relative_humidity_2m?: number;
    is_day?: number;
  };
  hourly?: {
    time?: string[];
    temperature_2m?: number[];
    weather_code?: number[];
    precipitation_probability?: number[];
  };
  daily?: {
    time?: string[];
    weather_code?: number[];
    temperature_2m_max?: number[];
    temperature_2m_min?: number[];
    sunrise?: string[];
    sunset?: string[];
  };
};

function hourLabel(stamp: string): string {
  return stamp.slice(11, 16);
}

async function readForecast(lat: number, lon: number): Promise<Forecast> {
  const url =
    `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
    `&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,relative_humidity_2m,is_day` +
    `&hourly=temperature_2m,weather_code,precipitation_probability` +
    `&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset` +
    `&timezone=auto&forecast_days=7`;
  const response = await fetch(url);
  if (!response.ok) throw new Error("clima");
  return (await response.json()) as Forecast;
}

export function PlaceProvider({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<PlaceState["status"]>("loading");
  const [label, setLabel] = useState("Ubicando…");
  const [lat, setLat] = useState(FALLBACK.lat);
  const [lon, setLon] = useState(FALLBACK.lon);
  const [temp, setTemp] = useState<number | null>(null);
  const [feels, setFeels] = useState<number | null>(null);
  const [code, setCode] = useState<number | null>(null);
  const [wind, setWind] = useState<number | null>(null);
  const [humidity, setHumidity] = useState<number | null>(null);
  const [isDay, setIsDay] = useState(true);
  const [hours, setHours] = useState<HourPoint[]>([]);
  const [days, setDays] = useState<DayPoint[]>([]);
  const [sunrise, setSunrise] = useState("");
  const [sunset, setSunset] = useState("");
  const precise = useRef(false);
  const coords = useRef({ lat: FALLBACK.lat, lon: FALLBACK.lon });

  const applyForecast = useCallback(async (nextLat: number, nextLon: number) => {
    try {
      const data = await readForecast(nextLat, nextLon);
      const current = data.current;
      const hourly = data.hourly;
      const daily = data.daily;
      const times = hourly?.time ?? [];
      const nowStamp = current?.time ?? "";
      let start = times.findIndex((stamp) => stamp >= nowStamp);
      if (start < 0) start = 0;
      const nextHours: HourPoint[] = [];
      for (let index = start; index < Math.min(times.length, start + 12); index += 1) {
        const stamp = times[index];
        if (!stamp) continue;
        nextHours.push({
          time: hourLabel(stamp),
          temp: hourly?.temperature_2m?.[index] ?? 0,
          code: hourly?.weather_code?.[index] ?? 0,
          pop: hourly?.precipitation_probability?.[index] ?? 0,
        });
      }
      const nextDays: DayPoint[] = (daily?.time ?? []).slice(0, 7).map((date, index) => ({
        date,
        min: daily?.temperature_2m_min?.[index] ?? 0,
        max: daily?.temperature_2m_max?.[index] ?? 0,
        code: daily?.weather_code?.[index] ?? 0,
      }));
      setTemp(current?.temperature_2m ?? null);
      setFeels(current?.apparent_temperature ?? null);
      setCode(current?.weather_code ?? null);
      setWind(current?.wind_speed_10m ?? null);
      setHumidity(current?.relative_humidity_2m ?? null);
      setIsDay(current?.is_day !== 0);
      setHours(nextHours);
      setDays(nextDays);
      setSunrise(hourLabel(daily?.sunrise?.[0] ?? ""));
      setSunset(hourLabel(daily?.sunset?.[0] ?? ""));
      setStatus("ready");
    } catch {
      setStatus((current) => (current === "ready" ? "ready" : "error"));
    }
  }, []);

  const adopt = useCallback(
    (nextLat: number, nextLon: number, nextLabel: string | null, isPrecise: boolean) => {
      if (!isPrecise && precise.current) return;
      if (isPrecise) precise.current = true;
      coords.current = { lat: nextLat, lon: nextLon };
      setLat(nextLat);
      setLon(nextLon);
      if (nextLabel) setLabel(nextLabel);
      void applyForecast(nextLat, nextLon);
    },
    [applyForecast],
  );

  useEffect(() => {
    let cancel = false;
    const fallbackTimer = window.setTimeout(() => {
      if (!cancel && !precise.current) adopt(FALLBACK.lat, FALLBACK.lon, FALLBACK.label, false);
    }, 1600);

    void fetch("https://get.geojs.io/v1/ip/geo.json")
      .then((response) => response.json())
      .then((geo: { city?: string; country_code?: string; latitude?: string; longitude?: string }) => {
        if (cancel) return;
        const nextLat = Number(geo.latitude);
        const nextLon = Number(geo.longitude);
        if (!Number.isFinite(nextLat) || !Number.isFinite(nextLon)) return;
        const city = [geo.city, geo.country_code].filter(Boolean).join(", ");
        adopt(nextLat, nextLon, city || "Tu zona", false);
      })
      .catch(() => undefined);

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          if (cancel) return;
          const nextLat = position.coords.latitude;
          const nextLon = position.coords.longitude;
          adopt(nextLat, nextLon, null, true);
          void reversePlace({ data: { lat: nextLat, lon: nextLon } }).then((result) => {
            if (!cancel && result.ok) setLabel(result.label);
          });
        },
        () => undefined,
        { enableHighAccuracy: false, timeout: 8000, maximumAge: 600000 },
      );
    }

    return () => {
      cancel = true;
      window.clearTimeout(fallbackTimer);
    };
  }, [adopt]);

  const reload = useCallback(() => {
    setStatus("loading");
    void applyForecast(coords.current.lat, coords.current.lon);
  }, [applyForecast]);

  const value = useMemo<PlaceState>(
    () => ({
      status,
      label,
      lat,
      lon,
      temp,
      feels,
      code,
      wind,
      humidity,
      isDay,
      hours,
      days,
      sunrise,
      sunset,
      reload,
    }),
    [status, label, lat, lon, temp, feels, code, wind, humidity, isDay, hours, days, sunrise, sunset, reload],
  );

  return <PlaceContext.Provider value={value}>{children}</PlaceContext.Provider>;
}

export function usePlace(): PlaceState {
  const value = useContext(PlaceContext);
  if (!value) throw new Error("usePlace fuera de proveedor");
  return value;
}
