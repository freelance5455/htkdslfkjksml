import React from 'react';
import { type TankId } from '../data/tankCharts';
import { formatNumber, getTankBounds } from '../utils/tankMath';

interface TankStatus {
  liters: number | null;
  error?: string;
}

interface VesselSchematicProps {
  statuses: Record<TankId, TankStatus>;
  onSelectTank: (tank: TankId) => void;
}

const PORT_TANKS: TankId[] = ['P-1', 'P-2', 'P-3', 'P-4'];
const STBD_TANKS: TankId[] = ['S-1', 'S-2', 'S-3', 'S-4'];

export const VesselSchematic: React.FC<VesselSchematicProps> = ({
  statuses,
  onSelectTank,
}) => {
  const renderTankCell = (tank: TankId, side: 'port' | 'stbd') => {
    const status = statuses[tank];
    const bounds = getTankBounds(tank);
    const hasValue = status.liters !== null && !status.error;
    const pct = hasValue
      ? Math.min(100, Math.max(0, ((status.liters ?? 0) / bounds.maxLiters) * 100))
      : 0;

    const isPort = side === 'port';
    const activeBorder = isPort
      ? 'border-[#fda4af] bg-[#fff1f2] hover:border-[#fb7185] shadow-[0_3px_0_#fecdd3]'
      : 'border-[#99f6e4] bg-[#f0fdfa] hover:border-[#2dd4bf] shadow-[0_3px_0_#ccfbf1]';
    const idleBorder = isPort
      ? 'border-[#cbd5e1] bg-[#f8fafc] hover:border-[#fda4af] hover:bg-white shadow-[0_3px_0_#cbd5e1]'
      : 'border-[#cbd5e1] bg-[#f8fafc] hover:border-[#99f6e4] hover:bg-white shadow-[0_3px_0_#cbd5e1]';
    const fillGradient = isPort
      ? 'bg-[#ffe4e6]/80'
      : 'bg-[#ccfbf1]/80';
    const valueTextColor = isPort ? 'text-[#9f1239]' : 'text-[#115e59]';
    const labelColor = isPort ? 'text-[#be123c]' : 'text-[#0f766e]';

    return (
      <button
        key={tank}
        type="button"
        onClick={() => onSelectTank(tank)}
        className={`group relative overflow-hidden rounded-xl border text-left p-2.5 min-h-[64px] cursor-pointer select-none transition-all duration-100 ease-out hover:-translate-y-[1px] active:translate-y-[2px] active:shadow-[0_1px_0_#cbd5e1] focus-visible:outline-2 focus-visible:outline-[#0284c7] ${
          status.error
            ? 'border-[#f43f5e] bg-[#fff1f2] shadow-[0_3px_0_#fecdd3]'
            : hasValue
              ? activeBorder
              : idleBorder
        }`}
      >
        <div
          className={`absolute inset-y-0 left-0 pointer-events-none transition-all duration-200 ${fillGradient}`}
          style={{ width: `${pct}%` }}
        />
        <div className="relative flex items-baseline justify-between gap-2">
          <span
            className={`text-xs font-extrabold tracking-wide ${
              hasValue ? labelColor : 'text-[#0f172a]'
            }`}
          >
            {tank}
          </span>
          <span className="font-mono-tabular text-[11px] font-semibold text-[#475569]">
            {hasValue ? `${pct.toFixed(1)}%` : '—'}
          </span>
        </div>
        <div className="relative mt-1 font-mono-tabular text-xs font-semibold truncate">
          {status.error ? (
            <span className="text-[#dc2626]">Out of range</span>
          ) : hasValue ? (
            <span className={valueTextColor}>{formatNumber(status.liters!)} L</span>
          ) : (
            <span className="text-[#94a3b8]">0 L</span>
          )}
        </div>
      </button>
    );
  };

  const slopStatus = statuses['Slop Tank'];
  const slopBounds = getTankBounds('Slop Tank');
  const slopHasValue = slopStatus.liters !== null && !slopStatus.error;
  const slopPct = slopHasValue
    ? Math.min(100, Math.max(0, ((slopStatus.liters ?? 0) / slopBounds.maxLiters) * 100))
    : 0;

  return (
    <div className="space-y-2.5">
      <div className="flex items-center justify-between text-[11px] font-bold px-1">
        <span className="text-[#be123c]">PORT SIDE (P)</span>
        <span className="font-mono-tabular text-[#64748b]">FWD → AFT</span>
        <span className="text-[#0f766e]">STARBOARD (S)</span>
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        <div className="space-y-2">
          {PORT_TANKS.map((t) => renderTankCell(t, 'port'))}
        </div>
        <div className="space-y-2">
          {STBD_TANKS.map((t) => renderTankCell(t, 'stbd'))}
        </div>
      </div>

      <button
        type="button"
        onClick={() => onSelectTank('Slop Tank')}
        className={`relative w-full overflow-hidden rounded-xl border text-left p-2.5 min-h-[56px] cursor-pointer select-none transition-all duration-100 ease-out hover:-translate-y-[1px] active:translate-y-[2px] active:shadow-[0_1px_0_#cbd5e1] focus-visible:outline-2 focus-visible:outline-[#0284c7] ${
          slopStatus.error
            ? 'border-[#f43f5e] bg-[#fff1f2] shadow-[0_3px_0_#fecdd3]'
            : slopHasValue
              ? 'border-[#fcd34d] bg-[#fffbeb] hover:border-[#f59e0b] shadow-[0_3px_0_#fde68a]'
              : 'border-[#cbd5e1] bg-[#f8fafc] hover:border-[#fcd34d] hover:bg-white shadow-[0_3px_0_#cbd5e1]'
        }`}
      >
        <div
          className="absolute inset-y-0 left-0 bg-[#fef3c7]/85 transition-all duration-200 pointer-events-none"
          style={{ width: `${slopPct}%` }}
        />
        <div className="relative flex items-center justify-between gap-3">
          <div>
            <span
              className={`text-xs font-extrabold tracking-wide ${
                slopHasValue ? 'text-[#b45309]' : 'text-[#0f172a]'
              }`}
            >
              Slop Tank
            </span>
            <span className="ml-2 text-[11px] text-[#64748b]">
              Max {formatNumber(slopBounds.maxLiters)} L
            </span>
          </div>
          <div className="font-mono-tabular text-xs font-semibold">
            {slopStatus.error ? (
              <span className="text-[#dc2626]">Out of range</span>
            ) : slopHasValue ? (
              <span className="text-[#92400e]">
                {formatNumber(slopStatus.liters!)} L ({slopPct.toFixed(1)}%)
              </span>
            ) : (
              <span className="text-[#94a3b8]">—</span>
            )}
          </div>
        </div>
      </button>
    </div>
  );
};
