import React, { useState, useEffect } from 'react';
import { 
  X, 
  ChevronLeft, 
  ChevronRight, 
  Eye, 
  EyeOff, 
  BookOpen, 
  Sparkles, 
  Volume2, 
  Bookmark, 
  Check, 
  ArrowLeft,
  Languages,
  Award,
  Loader2
} from 'lucide-react';
import { DailyQuestionSet, MCQQuestion, UserProfile } from '../types';
import { saveDailySetProgress, saveMistake } from '../lib/dailyQuestionEngine';
import { 
  SUPPORTED_INDIAN_LANGUAGES, 
  getUiLabels, 
  getTranslatedSubjectName, 
  getTranslatedDifficulty, 
  speakQuestionAndAnswer,
  formatNativeNumber
} from '../lib/languageUtils';

interface TodaysQuestionsModalProps {
  language: string;
  dailySet: DailyQuestionSet;
  userProfile?: UserProfile;
  setUserProfile?: React.Dispatch<React.SetStateAction<UserProfile>>;
  initialSubjectFilter?: string;
  onClose: () => void;
  onUpdateProgress: (updatedSet: DailyQuestionSet) => void;
}

export default function TodaysQuestionsModal({
  language: initialLanguage,
  dailySet: initialDailySet,
  userProfile,
  setUserProfile,
  initialSubjectFilter,
  onClose,
  onUpdateProgress
}: TodaysQuestionsModalProps) {
  const [currentLang, setCurrentLang] = useState<string>(initialLanguage || userProfile?.preferredLanguage || 'bn');
  const [dailySet, setDailySet] = useState<DailyQuestionSet>(initialDailySet);
  const [selectedSubject, setSelectedSubject] = useState<string>(initialSubjectFilter || 'ALL');
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [showAnswer, setShowAnswer] = useState<boolean>(false);
  const [userSelectedOption, setUserSelectedOption] = useState<Record<number, number>>({});
  const [savedQuestionIds, setSavedQuestionIds] = useState<string[]>([]);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [isTranslating, setIsTranslating] = useState<boolean>(false);

  const labels = getUiLabels(currentLang);

  // Filter questions based on selected subject
  const filteredQuestions: MCQQuestion[] = selectedSubject === 'ALL'
    ? dailySet.questions
    : dailySet.questions.filter(q => q.subject === selectedSubject);

  const totalQuestions = filteredQuestions.length > 0 ? filteredQuestions.length : dailySet.questions.length;
  const currentQuestion: MCQQuestion | undefined = filteredQuestions[currentIndex] || dailySet.questions[currentIndex];

  useEffect(() => {
    setCurrentIndex(0);
    setShowAnswer(false);
  }, [selectedSubject]);

  // Handle dynamic language switching and question translation
  const handleLanguageSelect = async (newLang: string) => {
    setCurrentLang(newLang);

    // Update user profile language preference
    if (setUserProfile && userProfile) {
      const updatedProf: UserProfile = { ...userProfile, preferredLanguage: newLang as any };
      setUserProfile(updatedProf);
      try {
        localStorage.setItem('edumind_user_profile', JSON.stringify(updatedProf));
      } catch (e) {}
    }

    // Trigger translation of current question set via server API
    setIsTranslating(true);
    try {
      const res = await fetch('/api/gemini/translate-questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          questions: dailySet.questions,
          language: newLang
        })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.questions && Array.isArray(data.questions) && data.questions.length > 0) {
          const translatedMap = new Map(data.questions.map((q: any) => [q.id, q]));
          const updatedQuestions = dailySet.questions.map(q => {
            const tQ: any = translatedMap.get(q.id);
            if (tQ) {
              return {
                ...q,
                question: tQ.question || q.question,
                options: tQ.options || q.options,
                explanation: tQ.explanation || q.explanation,
                shortConcept: tQ.shortConcept || q.shortConcept,
                rememberPoint: tQ.rememberPoint || q.rememberPoint,
                subject: tQ.subject || q.subject
              };
            }
            return q;
          });

          const updatedSet = { ...dailySet, questions: updatedQuestions };
          setDailySet(updatedSet);
          saveDailySetProgress(updatedSet);
          onUpdateProgress(updatedSet);
        }
      }
    } catch (err) {
      console.warn('Questions translation error:', err);
    } finally {
      setIsTranslating(false);
    }
  };

  const handleSelectOption = (optionIndex: number) => {
    setUserSelectedOption(prev => ({ ...prev, [currentIndex]: optionIndex }));
    setShowAnswer(true);

    if (currentQuestion) {
      if (optionIndex !== currentQuestion.correctOptionIndex) {
        saveMistake(currentQuestion, optionIndex);
      }
    }

    const updatedCount = Math.max(dailySet.completedCount, currentIndex + 1);
    const updatedSet: DailyQuestionSet = {
      ...dailySet,
      completedCount: updatedCount,
      userAnswers: { ...dailySet.userAnswers, [currentIndex]: optionIndex }
    };
    setDailySet(updatedSet);
    saveDailySetProgress(updatedSet);
    onUpdateProgress(updatedSet);
  };

  const handleNext = () => {
    if (currentIndex < totalQuestions - 1) {
      const nextIdx = currentIndex + 1;
      setCurrentIndex(nextIdx);
      setShowAnswer(userSelectedOption[nextIdx] !== undefined);

      const updatedCount = Math.max(dailySet.completedCount, nextIdx + 1);
      const updatedSet: DailyQuestionSet = {
        ...dailySet,
        completedCount: updatedCount
      };
      setDailySet(updatedSet);
      saveDailySetProgress(updatedSet);
      onUpdateProgress(updatedSet);
    } else {
      setIsCompleted(true);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      const prevIdx = currentIndex - 1;
      setCurrentIndex(prevIdx);
      setShowAnswer(true);
    }
  };

  const toggleBookmark = (qId: string) => {
    setSavedQuestionIds(prev => 
      prev.includes(qId) ? prev.filter(id => id !== qId) : [...prev, qId]
    );
  };

  // Text to Speech in Selected Language
  const handleReadAloud = () => {
    if (!currentQuestion) return;

    const answerStr = showAnswer && currentQuestion.options[currentQuestion.correctOptionIndex]
      ? `${labels.correctAnswerBadge}: ${currentQuestion.options[currentQuestion.correctOptionIndex]}`
      : null;
    const explanationStr = showAnswer ? currentQuestion.explanation : null;

    speakQuestionAndAnswer(
      currentQuestion.question,
      answerStr,
      explanationStr,
      currentLang
    );
  };

  if (!currentQuestion) {
    return null;
  }

  const selectedOpt = userSelectedOption[currentIndex];
  const isBookmarked = savedQuestionIds.includes(currentQuestion.id);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700/90 rounded-3xl w-full max-w-4xl max-h-[94vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 text-slate-100">
        
        {/* HEADER BAR */}
        <div className="bg-slate-800/90 border-b border-slate-700/80 px-4 md:px-6 py-3 flex flex-wrap items-center justify-between gap-3 shrink-0">
          
          {/* TOP-LEFT BACK BUTTON & HEADER TITLE */}
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-700/80 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl border border-slate-600/80 transition-all cursor-pointer shadow-sm hover:text-white"
              title={labels.backHome}
            >
              <ArrowLeft className="w-4 h-4 text-emerald-400" />
              <span>{labels.backHome}</span>
            </button>

            <div className="hidden sm:block h-6 w-px bg-slate-700" />

            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base md:text-lg font-black text-white">
                  {labels.headerTitle}
                </h2>
                <span className="px-2 py-0.5 bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-[10px] font-extrabold rounded-md hidden md:inline-block">
                  {labels.learningModeBadge}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                {labels.headerSubtitle}
              </p>
            </div>
          </div>

          {/* LANGUAGE SELECTOR & CLOSE BUTTON */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-700/90 rounded-xl px-2.5 py-1.5">
              <Languages className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
              <select
                value={currentLang}
                onChange={(e) => handleLanguageSelect(e.target.value)}
                className="bg-transparent text-slate-100 text-xs font-bold focus:outline-none cursor-pointer"
              >
                {SUPPORTED_INDIAN_LANGUAGES.map((lang) => (
                  <option key={lang.code} value={lang.code} className="bg-slate-900 text-slate-100">
                    {lang.label}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={onClose}
              className="p-2 bg-slate-700/60 hover:bg-slate-700 text-slate-300 rounded-full transition-all cursor-pointer"
              title={labels.backHome}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

        </div>

        {/* TRANSLATING OVERLAY BANNER */}
        {isTranslating && (
          <div className="bg-indigo-600/30 border-b border-indigo-500/40 px-4 py-2 flex items-center justify-center gap-2 text-indigo-200 text-xs font-bold animate-pulse">
            <Loader2 className="w-4 h-4 animate-spin text-indigo-300" />
            <span>{labels.translatingBanner}</span>
          </div>
        )}

        {/* SUBJECT FILTER & PROGRESS BAR */}
        <div className="bg-slate-900 border-b border-slate-800 p-4 space-y-3 shrink-0">
          {/* SUBJECT TABS WITH LOCALIZED NAMES */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            <button
              onClick={() => setSelectedSubject('ALL')}
              className={`px-3 py-1.5 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all cursor-pointer ${
                selectedSubject === 'ALL'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {labels.allSubjectsTab} ({formatNativeNumber(dailySet.questions.length, currentLang)})
            </button>

            {dailySet.selectedSubjects.map(sub => {
              const subCount = dailySet.questions.filter(q => q.subject === sub).length;
              const translatedSubName = getTranslatedSubjectName(sub, currentLang);
              return (
                <button
                  key={sub}
                  onClick={() => setSelectedSubject(sub)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all cursor-pointer ${
                    selectedSubject === sub
                      ? 'bg-indigo-600 text-white shadow-md'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {translatedSubName} ({formatNativeNumber(subCount, currentLang)})
                </button>
              );
            })}
          </div>

          {/* PROGRESS INDICATOR */}
          <div className="flex items-center justify-between text-xs font-bold">
            <span className="text-slate-300">
              {labels.progressFormat(currentIndex + 1, totalQuestions)}
            </span>
            <span className="text-emerald-400">
              {formatNativeNumber(Math.round(((currentIndex + 1) / totalQuestions) * 100), currentLang)}% {labels.completedPercent}
            </span>
          </div>

          <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
            <div 
              className="bg-gradient-to-r from-emerald-500 to-teal-400 h-2 rounded-full transition-all duration-300"
              style={{ width: `${((currentIndex + 1) / totalQuestions) * 100}%` }}
            />
          </div>
        </div>

        {/* MAIN QUESTION DISPLAY */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-5">
          
          {/* COMPLETION VIEW */}
          {isCompleted ? (
            <div className="py-12 text-center space-y-6 max-w-md mx-auto animate-in fade-in zoom-in duration-300">
              <div className="w-20 h-20 bg-emerald-500/20 border-2 border-emerald-400 text-emerald-400 rounded-full flex items-center justify-center mx-auto shadow-xl shadow-emerald-500/10">
                <Award className="w-10 h-10" />
              </div>

              <div className="space-y-2">
                <h3 className="text-xl md:text-2xl font-black text-white">
                  {labels.completedTitle}
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {labels.completedDesc}
                </p>
              </div>

              <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-4 text-left space-y-2 text-xs">
                <div className="flex justify-between text-slate-300 font-bold">
                  <span>{labels.totalQuestionsLabel}</span>
                  <span className="text-emerald-400 font-black">{formatNativeNumber(totalQuestions, currentLang)}</span>
                </div>
                <div className="flex justify-between text-slate-300 font-bold">
                  <span>{labels.selectedSubjectsLabel}</span>
                  <span className="text-indigo-300 font-black">
                    {dailySet.selectedSubjects.map(s => getTranslatedSubjectName(s, currentLang)).join(', ')}
                  </span>
                </div>
              </div>

              <button
                onClick={onClose}
                className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold rounded-2xl text-xs shadow-lg shadow-emerald-600/30 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>{labels.backHome}</span>
              </button>
            </div>
          ) : (
            <>
              {/* QUESTION CARD */}
              <div className="bg-slate-800/80 border border-slate-700/80 rounded-3xl p-5 md:p-6 space-y-4 shadow-xl">
                
                {/* QUESTION METADATA ROW */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 font-black text-xs rounded-xl">
                      {getTranslatedSubjectName(currentQuestion.subject, currentLang)}
                    </span>
                    {currentQuestion.difficulty && (
                      <span className="px-2.5 py-1 bg-slate-700 text-slate-300 font-bold text-[11px] rounded-lg">
                        {getTranslatedDifficulty(currentQuestion.difficulty, currentLang)}
                      </span>
                    )}
                  </div>

                  {/* SPEAKER & BOOKMARK BUTTONS */}
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={handleReadAloud}
                      className="p-2.5 bg-slate-700/80 hover:bg-indigo-600 text-indigo-300 hover:text-white rounded-xl transition-all cursor-pointer shadow-md"
                      title={labels.readAloudTitle}
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => toggleBookmark(currentQuestion.id)}
                      className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
                        isBookmarked
                          ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                          : 'bg-slate-700/80 border-slate-700 text-slate-400 hover:text-white'
                      }`}
                      title={labels.bookmarkTitle}
                    >
                      <Bookmark className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* QUESTION TEXT */}
                <div className="text-base md:text-lg font-black text-white leading-relaxed pt-1">
                  <span className="text-indigo-400 mr-2">
                    Q{formatNativeNumber(currentIndex + 1, currentLang)}.
                  </span>
                  {currentQuestion.question}
                </div>

                {/* OPTIONS LIST */}
                <div className="grid grid-cols-1 gap-2.5 pt-2">
                  {currentQuestion.options.map((option, optIdx) => {
                    const isCorrectIndex = optIdx === currentQuestion.correctOptionIndex;
                    const isUserSelected = selectedOpt === optIdx;

                    let optionStyle = "bg-slate-900/80 border-slate-700 text-slate-200 hover:border-indigo-500/60 hover:bg-slate-800";
                    if (showAnswer) {
                      if (isCorrectIndex) {
                        optionStyle = "bg-emerald-950/80 border-emerald-500 text-emerald-200 font-extrabold shadow-md shadow-emerald-950/50";
                      } else if (isUserSelected) {
                        optionStyle = "bg-rose-950/80 border-rose-500 text-rose-200 font-bold";
                      } else {
                        optionStyle = "bg-slate-900/40 border-slate-800 text-slate-500 opacity-60";
                      }
                    }

                    return (
                      <button
                        key={optIdx}
                        type="button"
                        onClick={() => handleSelectOption(optIdx)}
                        className={`p-4 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between gap-3 ${optionStyle}`}
                      >
                        <span className="text-xs md:text-sm font-semibold leading-snug">
                          {option}
                        </span>

                        {showAnswer && isCorrectIndex && (
                          <span className="px-2.5 py-1 bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-[10px] font-black rounded-lg shrink-0 flex items-center gap-1">
                            <Check className="w-3 h-3 stroke-[3]" />
                            {labels.correctAnswerBadge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* SHOW / HIDE ANSWER BUTTON */}
                <div className="pt-2 flex flex-wrap items-center justify-between gap-2">
                  <button
                    onClick={() => setShowAnswer(!showAnswer)}
                    className="px-4 py-2 bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/40 text-indigo-200 font-bold text-xs rounded-xl flex items-center gap-2 transition-all cursor-pointer"
                  >
                    {showAnswer ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    {showAnswer ? labels.hideAnswerBtn : labels.showAnswerBtn}
                  </button>

                  <span className="text-[11px] text-slate-400 font-medium">
                    {labels.syllabusVerified}
                  </span>
                </div>

                {/* EXPLANATION PANEL */}
                {showAnswer && (
                  <div className="pt-4 border-t border-slate-700/80 space-y-3 animate-in fade-in duration-200">
                    <div className="bg-slate-900/90 border border-indigo-500/30 rounded-2xl p-4 space-y-3">
                      <div className="flex items-center gap-2 text-indigo-300 font-extrabold text-xs">
                        <Sparkles className="w-4 h-4 text-amber-300" />
                        {labels.solutionHeader}
                      </div>

                      <p className="text-xs md:text-sm text-slate-200 leading-relaxed font-normal">
                        {currentQuestion.explanation}
                      </p>

                      {currentQuestion.shortConcept && (
                        <div className="p-3 bg-indigo-950/40 border border-indigo-800/50 rounded-xl text-xs space-y-1">
                          <span className="font-black text-indigo-300 block">
                            💡 {labels.coreConceptHeader}
                          </span>
                          <span className="text-slate-300">{currentQuestion.shortConcept}</span>
                        </div>
                      )}

                      {currentQuestion.rememberPoint && (
                        <div className="p-3 bg-amber-950/40 border border-amber-800/50 rounded-xl text-xs space-y-1">
                          <span className="font-black text-amber-300 block">
                            📌 {labels.examTipHeader}
                          </span>
                          <span className="text-slate-300">{currentQuestion.rememberPoint}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

              </div>
            </>
          )}

        </div>

        {/* BOTTOM NAVIGATION FOOTER */}
        {!isCompleted && (
          <div className="bg-slate-800/90 border-t border-slate-700/80 px-4 md:px-6 py-3.5 flex items-center justify-between gap-3 shrink-0">
            <button
              onClick={handlePrev}
              disabled={currentIndex === 0}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                currentIndex === 0
                  ? 'bg-slate-800 text-slate-600 border border-slate-800 cursor-not-allowed'
                  : 'bg-slate-700 hover:bg-slate-600 text-slate-200'
              }`}
            >
              <ChevronLeft className="w-4 h-4" />
              <span>{labels.prevBtn}</span>
            </button>

            <div className="text-xs text-slate-300 font-bold hidden sm:block">
              {labels.progressFormat(currentIndex + 1, totalQuestions)}
            </div>

            <button
              onClick={handleNext}
              className="px-6 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold rounded-xl text-xs shadow-lg shadow-emerald-600/20 transition-all cursor-pointer flex items-center gap-1.5"
            >
              <span>
                {currentIndex === totalQuestions - 1 ? labels.finishBtn : labels.nextBtn}
              </span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}

      </div>
    </div>
  );
}
