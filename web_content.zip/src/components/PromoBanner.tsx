import React, { useState, useEffect } from 'react';
import { Star, ChevronRight, Sparkles, BookCheck, Award } from 'lucide-react';

interface PromoBannerProps {
  onOpenPremium: () => void;
  isPremiumUser: boolean;
}

export const PromoBanner: React.FC<PromoBannerProps> = ({
  onOpenPremium,
  isPremiumUser,
}) => {
  const [activeSlide, setActiveSlide] = useState(0);

  const slides = [
    {
      brand: "ToppersCBSE.com",
      title: "कक्षा 11 जीव विज्ञान संपूर्ण नोट्स",
      color: "from-amber-500 via-orange-500 to-amber-600",
      bgLight: "bg-orange-50",
      bullets: [
        "उत्तम तथा आसान भाषा",
        "सभी व्युत्पत्ति (Derivations) के साथ",
        "नवीनतम NCERT पाठ्यक्रम पर आधारित",
        "आसान व रंगीन चित्रों के साथ",
        "100% टॉपिक्स एवं महत्वपूर्ण प्रश्न"
      ],
      tag: "BESTSELLER"
    },
    {
      brand: "NEET 2026/27 Special",
      title: "बायोलॉजी NCERT हाई-यील्ड डायग्राम्स",
      color: "from-teal-600 via-emerald-600 to-teal-700",
      bgLight: "bg-emerald-50",
      bullets: [
        "NCERT की प्रत्येक पंक्ति से बने MCQs",
        "360/360 मार्क्स लक्ष्य बायोलॉजी कैप्सूल",
        "पिछले 15 वर्षों के NEET हल प्रश्न",
        "माइक्रोस्कोपिक सचित्र आरेख व्याख्या",
        "शॉर्ट ट्रिक्स & फ्लैशकार्ड्स"
      ],
      tag: "NEET SPECIAL"
    },
    {
      brand: "हस्तलिखित नोट्स",
      title: "टॉपर्स हैंडराइटिंग नोट्स (PDF)",
      color: "from-sky-600 via-blue-600 to-indigo-700",
      bgLight: "bg-sky-50",
      bullets: [
        "सुंदर लिखावट में अध्यायवार नोट्स",
        "परीक्षा में पूरे अंक लाने के लिए टिप्स",
        "अति लघु, लघु व दीर्घ उत्तरीय प्रश्न",
        "माइंड मैप्स द्वारा 5 मिनट में रिवीज़न",
        "ऑफलाइन डाउनलोड की सुविधा"
      ],
      tag: "TOPPERS CHOICE"
    }
  ];

  // Auto-scroll every 5 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [slides.length]);

  return (
    <div className="w-full">
      {/* Top Golden/Amber Banner: Remove Ads + Get Premium Content */}
      <button
        onClick={onOpenPremium}
        className="w-full bg-[#f9a825] hover:bg-[#f57f17] text-white py-2 px-4 flex items-center justify-center gap-2 font-bold text-sm tracking-wide shadow-sm transition-colors cursor-pointer"
      >
        <Star className="w-4 h-4 fill-white text-white shrink-0 animate-pulse" />
        <span>{isPremiumUser ? '⭐ प्रीमियम एक्टिव (विज्ञापन मुक्त)' : 'Remove Ads + Get Premium Content'}</span>
        <ChevronRight className="w-4 h-4 ml-1 opacity-80" />
      </button>

      {/* Carousel Banner Card matching screenshot layout */}
      <div className="px-3 pt-3 pb-2 max-w-md mx-auto">
        <div className="relative overflow-hidden rounded-xl bg-white border border-slate-200 shadow-sm transition-all">
          {/* Active slide display */}
          <div className="p-3.5 bg-gradient-to-r from-orange-50/90 to-amber-50/60 flex items-stretch justify-between gap-3 min-h-[140px]">
            {/* Left Column: Bullet points list */}
            <div className="flex-1 flex flex-col justify-between">
              <div>
                <ul className="space-y-1 text-xs text-slate-800 font-medium">
                  {slides[activeSlide].bullets.map((b, idx) => (
                    <li key={idx} className="flex items-start gap-1.5 leading-snug">
                      <span className="text-orange-500 font-bold shrink-0">•</span>
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Brand watermark link */}
              <div className="mt-2 text-[11px] font-semibold text-slate-500 flex items-center gap-1">
                <BookCheck className="w-3.5 h-3.5 text-orange-500" />
                <span>{slides[activeSlide].brand}</span>
              </div>
            </div>

            {/* Right Column: Styled Preview Sheet / Document snippet */}
            <div className="w-28 sm:w-32 bg-white rounded-lg border border-slate-300 p-2 shadow-inner flex flex-col justify-between shrink-0 relative overflow-hidden">
              <div className="w-full h-1.5 bg-indigo-900 rounded-sm mb-1.5" />
              <div className="space-y-1 text-[8px] text-slate-600 line-clamp-4 leading-tight font-devanagari">
                <p className="font-bold text-indigo-950">सजीवों के लक्षण</p>
                <p className="text-[7px] text-slate-500 leading-tight">1. उपापचय (Metabolism)</p>
                <p className="text-[7px] text-slate-500 leading-tight">2. कोशिकीय संगठन</p>
                <p className="text-[7px] text-slate-500 leading-tight">3. द्विनाम पद्धति लिनियस</p>
              </div>

              {/* Watermark badge on document preview */}
              <div className="mt-2 pt-1 border-t border-slate-200 flex items-center justify-between text-[7px] text-slate-400">
                <span>NCERT 11th</span>
                <span className="text-indigo-600 font-bold">100%</span>
              </div>
            </div>
          </div>

          {/* Carousel Navigation Dots */}
          <div className="bg-slate-900 py-1.5 px-3 flex items-center justify-center gap-2">
            {slides.map((_, i) => (
              <button
                key={i}
                onClick={() => setActiveSlide(i)}
                aria-label={`स्लाइड ${i + 1}`}
                className={`transition-all duration-300 rounded-full ${
                  activeSlide === i
                    ? 'w-6 h-2 bg-white'
                    : 'w-2 h-2 bg-white/40 hover:bg-white/70'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
