import React, { useState } from 'react';
import { 
  X, 
  Star, 
  MessageSquareHeart, 
  Sparkles, 
  CheckCircle2, 
  Coins, 
  ThumbsUp, 
  Send, 
  Vote, 
  Flame,
  ShieldCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useApp } from '../../context/AppContext';
import { AppFeedbackSubmission } from '../../types';

interface AppFeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitFeedback?: (submission: AppFeedbackSubmission) => void;
}

export const AppFeedbackModal: React.FC<AppFeedbackModalProps> = ({
  isOpen,
  onClose,
  onSubmitFeedback
}) => {
  const { currentUser, adjustUserCoins, language, t } = useApp();

  const [rating, setRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [favoriteFeature, setFavoriteFeature] = useState<string>('10,080+ Coins Mega App Install Pool');
  const [selectedRequestedFeatures, setSelectedRequestedFeatures] = useState<string[]>([
    'Instant USDT / Crypto Cashout',
    'More 10,080+ High Payout Install Offers'
  ]);
  const [easeOfUse, setEaseOfUse] = useState<number>(5);
  const [earningSatisfaction, setEarningSatisfaction] = useState<'very_satisfied' | 'satisfied' | 'neutral' | 'dissatisfied'>('very_satisfied');
  const [comments, setComments] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);

  if (!isOpen) return null;

  const featureOptions = [
    '10,080+ Coins Mega App Install Pool',
    'Google Tasks Sync & Auto-Rewards',
    'High Payout VIP Daily Tasks (₹400-₹4,000/day)',
    'Daily Scratch Cards & Spin Wheel Games',
    'Fast Instant UPI Cashouts (PhonePe/GPay)',
    'Referral Commission & 100 Coin Welcome Bonus'
  ];

  const futureFeatureOptions = [
    'Instant USDT / Crypto Cashout',
    'More 10,080+ High Payout Install Offers',
    'Telegram Mini App Earn Bot',
    'Hourly Bonus Streak Multiplier',
    'Daily Top Earners Leaderboard Cash Pool',
    'Voice-Assisted Task Verification'
  ];

  const toggleFeatureVote = (feature: string) => {
    setSelectedRequestedFeatures((prev) => 
      prev.includes(feature) ? prev.filter(f => f !== feature) : [...prev, feature]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    setIsSubmitting(true);

    const submission: AppFeedbackSubmission = {
      id: `fb-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userEmail: currentUser.email,
      overallRating: rating,
      favoriteFeature,
      requestedFeatures: selectedRequestedFeatures,
      easeOfUse,
      earningSatisfaction,
      comments: comments.trim() || 'Great experience with Task Earn Pro high payouts!',
      rewardCoinsEarned: 500,
      submittedAt: new Date().toISOString()
    };

    // Credit reward coins
    adjustUserCoins(currentUser.id, 500, 'App Feedback & Feature Survey Reward');

    if (onSubmitFeedback) {
      onSubmitFeedback(submission);
    }

    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 }
    });

    setIsSubmitting(false);
    setIsCompleted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-7 shadow-2xl relative text-white max-h-[90vh] overflow-y-auto scrollbar-none">
        
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {!isCompleted ? (
          <form onSubmit={handleSubmit} className="space-y-5">
            
            {/* Header */}
            <div className="space-y-1.5 text-center sm:text-left pr-6">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Earn +500 Coins Reward</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                App Feedback & Feature Survey
              </h2>
              <p className="text-xs text-slate-400">
                Help us improve Task Earn Pro. Share your experience and vote for the next features you want to see!
              </p>
            </div>

            {/* Question 1: Overall Star Rating */}
            <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/60 space-y-2">
              <label className="block text-xs font-bold text-slate-200">
                1. How would you rate your experience with Task Earn Pro? *
              </label>
              <div className="flex items-center gap-2 justify-center sm:justify-start">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onMouseEnter={() => setHoverRating(star)}
                    onMouseLeave={() => setHoverRating(0)}
                    onClick={() => setRating(star)}
                    className="p-1 text-2xl transition-transform hover:scale-125 focus:outline-none cursor-pointer"
                  >
                    <Star 
                      className={`w-7 h-7 ${
                        (hoverRating || rating) >= star
                          ? 'text-amber-400 fill-amber-400' 
                          : 'text-slate-600'
                      }`} 
                    />
                  </button>
                ))}
                <span className="text-xs font-bold text-amber-400 ml-2">
                  {rating === 5 ? '⭐⭐⭐⭐⭐ Excellent!' : rating === 4 ? '⭐⭐⭐⭐ Good' : '⭐⭐⭐ Fair'}
                </span>
              </div>
            </div>

            {/* Question 2: Favorite Existing Feature */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-200">
                2. Which earning feature do you love most? *
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {featureOptions.map((feat) => (
                  <button
                    key={feat}
                    type="button"
                    onClick={() => setFavoriteFeature(feat)}
                    className={`p-2.5 rounded-xl border text-left font-medium transition-all cursor-pointer flex items-center gap-2 ${
                      favoriteFeature === feat
                        ? 'bg-purple-600/30 border-purple-500 text-purple-200 shadow-xs'
                        : 'bg-slate-800/40 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <div className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center shrink-0 ${
                      favoriteFeature === feat ? 'border-purple-400 bg-purple-500' : 'border-slate-500'
                    }`}>
                      {favoriteFeature === feat && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                    </div>
                    <span className="leading-tight">{feat}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Question 3: Vote on Requested New Features */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-bold text-slate-200">
                  3. Vote on upcoming features you want next: (Select multiple)
                </label>
                <span className="text-[10px] text-purple-400 font-bold">
                  {selectedRequestedFeatures.length} Selected
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {futureFeatureOptions.map((feat) => {
                  const isSelected = selectedRequestedFeatures.includes(feat);
                  return (
                    <button
                      key={feat}
                      type="button"
                      onClick={() => toggleFeatureVote(feat)}
                      className={`p-2.5 rounded-xl border text-left font-medium transition-all cursor-pointer flex items-center gap-2 ${
                        isSelected
                          ? 'bg-emerald-600/30 border-emerald-500 text-emerald-200'
                          : 'bg-slate-800/40 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <div className={`w-4 h-4 rounded-md border flex items-center justify-center shrink-0 ${
                        isSelected ? 'border-emerald-400 bg-emerald-500 text-slate-950 font-bold text-[10px]' : 'border-slate-500'
                      }`}>
                        {isSelected && '✓'}
                      </div>
                      <span className="leading-tight">{feat}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Question 4: Comments and Feedback */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-200">
                4. What can we do to make Task Earn Pro even better?
              </label>
              <textarea
                rows={3}
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                placeholder="e.g. Love the 10080+ app install earnings and quick UPI payouts! Add more daily games..."
                className="w-full p-3 rounded-2xl border border-slate-700 bg-slate-800/60 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
              />
            </div>

            {/* Submit Action */}
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-3">
              <div className="flex items-center gap-1.5 text-xs text-amber-400 font-bold">
                <Coins className="w-4 h-4" />
                <span>+500 Coins Claim</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-800 text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:opacity-95 text-white font-black text-xs shadow-lg shadow-emerald-500/20 active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Submit & Claim 500 Coins</span>
                </button>
              </div>
            </div>

          </form>
        ) : (
          /* Success Screen */
          <div className="p-6 text-center space-y-4 animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-3xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto shadow-xl">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <div className="space-y-1">
              <h3 className="text-xl font-black text-white">Thank You for Your Feedback!</h3>
              <p className="text-xs text-slate-400">
                Your ratings and feature votes have been submitted to the Task Earn Pro engineering team.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-800/60 inline-flex items-center gap-3 text-emerald-300">
              <div className="w-8 h-8 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black text-sm">
                🪙
              </div>
              <div className="text-left">
                <span className="text-xs font-bold block">+500 Coins Credited!</span>
                <span className="text-[10px] text-slate-400">Added to your main wallet balance</span>
              </div>
            </div>

            <div className="pt-3">
              <button
                type="button"
                onClick={onClose}
                className="w-full py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-colors cursor-pointer"
              >
                Done & Return to Tasks
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
