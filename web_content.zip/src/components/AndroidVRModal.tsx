import React, { useState } from 'react';
import { X, Upload, Compass, Sliders, Smartphone, Link2 } from 'lucide-react';
import { PROJECTION_OPTIONS, Video360Projection } from '../vr/vrState';

interface AndroidVRModalProps {
  open: boolean;
  onClose: () => void;
  dwellMs: number;
  onChangeDwellMs: (ms: number) => void;
  ipdMm: number;
  onChangeIpdMm: (mm: number) => void;
  gyroEnabled: boolean;
  onEnableGyro: () => Promise<void>;
  onLoadLocalVideo: (
    target: '360' | 'cinema',
    file: File,
    projection?: Video360Projection
  ) => void;
  onLoadVideoUrl: (
    target: '360' | 'cinema',
    url: string,
    projection?: Video360Projection
  ) => void;
  onEnterVRBox: () => void;
}

export const AndroidVRModal: React.FC<AndroidVRModalProps> = ({
  open,
  onClose,
  dwellMs,
  onChangeDwellMs,
  ipdMm,
  onChangeIpdMm,
  gyroEnabled,
  onEnableGyro,
  onLoadLocalVideo,
  onLoadVideoUrl,
  onEnterVRBox,
}) => {
  const [urlTarget, setUrlTarget] = useState<'360' | 'cinema'>('cinema');
  const [selectedProjection, setSelectedProjection] =
    useState<Video360Projection>('360-mono');
  const [videoUrl, setVideoUrl] = useState('');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  if (!open) return null;

  const handleFileChange = (
    target: '360' | 'cinema',
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    onLoadLocalVideo(
      target,
      file,
      target === '360' ? selectedProjection : undefined
    );
    setStatusMessage(
      target === '360'
        ? `تم تحميل فيديو VR (${selectedProjection}): ${file.name}`
        : `تم تحميل فيلم السينما: ${file.name}`
    );
  };

  const handleUrlSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = videoUrl.trim();
    if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) {
      setStatusMessage('يرجى إدخال رابط فيديو يبدأ بـ https:// أو http://');
      return;
    }
    onLoadVideoUrl(
      urlTarget,
      trimmed,
      urlTarget === '360' ? selectedProjection : undefined
    );
    setStatusMessage('تم ربط رابط الفيديو بنجاح.');
    setVideoUrl('');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
      role="dialog"
      aria-modal="true"
      aria-label="إعدادات نظارة VR Box وتشغيل الفيديو"
    >
      <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl bg-[#111722] border border-slate-700/80 p-6 text-slate-100 shadow-2xl">
        <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <h2 className="text-lg font-bold text-white">
              إعدادات نظارة VR Box وتشغيل الفيديوهات
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              جهّز ملفات الفيديو والمستشعرات قبل وضع الهاتف داخل نظارة VR Box
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق الإعدادات"
            className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-5 space-y-6">
          {/* Local Video Upload for 360 or Cinema */}
          <section className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                <Upload className="w-4 h-4 text-sky-400" />
                <span>تشغيل فيديو من ذاكرة هاتف أندرويد (MP4 / WebM)</span>
              </h3>
              <select
                value={selectedProjection}
                onChange={(e) =>
                  setSelectedProjection(e.target.value as Video360Projection)
                }
                aria-label="صيغة الفيديو 3D أو 180 أو 360"
                className="rounded-lg bg-slate-900 border border-slate-700 px-2.5 py-1.5 text-xs text-teal-300"
              >
                {PROJECTION_OPTIONS.map((opt) => (
                  <option key={opt.id} value={opt.id}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="cursor-pointer flex flex-col justify-center gap-1 rounded-xl border border-slate-700 bg-slate-900/70 p-4 hover:border-teal-400 transition-colors">
                <span className="text-sm font-semibold text-teal-300">
                  اختيار فيديو 360° / 180° / 3D محلي
                </span>
                <span className="text-xs text-slate-400">
                  يدعم 360° و 180° و 3D SBS و Top-Bottom
                </span>
                <input
                  type="file"
                  accept="video/*"
                  onChange={(e) => handleFileChange('360', e)}
                  className="sr-only"
                />
              </label>

              <label className="cursor-pointer flex flex-col justify-center gap-1 rounded-xl border border-slate-700 bg-slate-900/70 p-4 hover:border-amber-400 transition-colors">
                <span className="text-sm font-semibold text-amber-300">
                  اختيار فيلم للسينما الافتراضية
                </span>
                <span className="text-xs text-slate-400">
                  يعرض على شاشة IMAX داخل قاعة السينما
                </span>
                <input
                  type="file"
                  accept="video/*"
                  onChange={(e) => handleFileChange('cinema', e)}
                  className="sr-only"
                />
              </label>
            </div>
          </section>

          {/* Direct Video URL */}
          <section className="space-y-2.5">
            <h3 className="text-sm font-semibold text-slate-200 flex items-center gap-2">
              <Link2 className="w-4 h-4 text-sky-400" />
              <span>أو تشغيل رابط فيديو مباشر (MP4 / WebM)</span>
            </h3>
            <form onSubmit={handleUrlSubmit} className="flex flex-col sm:flex-row gap-2">
              <select
                value={urlTarget}
                onChange={(e) => setUrlTarget(e.target.value as '360' | 'cinema')}
                aria-label="نوع المشغل للرابط"
                className="rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-xs text-slate-100"
              >
                <option value="cinema">مشغل السينما</option>
                <option value="360">مشغل 360°</option>
              </select>
              <input
                type="url"
                dir="ltr"
                value={videoUrl}
                onChange={(e) => setVideoUrl(e.target.value)}
                placeholder="https://example.com/video.mp4"
                className="flex-1 rounded-lg bg-slate-900 border border-slate-700 px-3 py-2 text-xs text-slate-100 placeholder:text-slate-500"
              />
              <button
                type="submit"
                className="rounded-lg bg-sky-500 px-4 py-2 text-xs font-semibold text-slate-950 hover:bg-sky-400 transition-colors whitespace-nowrap shrink-0"
              >
                تشغيل الرابط
              </button>
            </form>
          </section>

          {/* Gaze Dwell & IPD Calibration */}
          <section className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-800">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-sky-400" />
                  سرعة النقر بالنظر
                </span>
                <span className="font-mono-tabular text-sky-400">
                  {(dwellMs / 1000).toFixed(1)}s
                </span>
              </div>
              <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-lg">
                {[
                  { label: 'سريع (0.9ث)', val: 900 },
                  { label: 'متوازن (1.3ث)', val: 1300 },
                  { label: 'مريح (1.8ث)', val: 1800 },
                ].map((opt) => (
                  <button
                    key={opt.val}
                    type="button"
                    onClick={() => onChangeDwellMs(opt.val)}
                    className={`flex-1 py-1.5 px-2 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                      dwellMs === opt.val
                        ? 'bg-sky-500 text-slate-950'
                        : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-200">
                  تباعد العدسات (IPD)
                </span>
                <span className="font-mono-tabular text-sky-400">{ipdMm} mm</span>
              </div>
              <input
                type="range"
                min={54}
                max={74}
                step={1}
                value={ipdMm}
                onChange={(e) => onChangeIpdMm(Number(e.target.value))}
                aria-label="تباعد العدسات بالمليمتر"
                className="w-full accent-sky-400"
              />
              <p className="text-[11px] text-slate-400">
                اضبطه ليتوافق مع مسافة عدسات نظارة VR Box لديك
              </p>
            </div>
          </section>

          {/* Gyroscope & Android VR Box Launch */}
          <section className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onEnableGyro}
              className="flex items-center justify-center gap-2 rounded-lg border border-slate-700 bg-slate-900 px-4 py-2.5 text-xs font-semibold text-slate-100 hover:border-sky-400 transition-colors"
            >
              <Compass className="w-4 h-4 text-sky-400" />
              <span>
                {gyroEnabled
                  ? 'مستشعر الحركة (الجيروسكوب) مفعّل'
                  : 'تفعيل مستشعر الحركة (الجيروسكوب)'}
              </span>
            </button>

            <button
              type="button"
              onClick={() => {
                onEnterVRBox();
                onClose();
              }}
              className="flex items-center justify-center gap-2 rounded-lg bg-amber-500 px-5 py-2.5 text-xs font-bold text-slate-950 hover:bg-amber-400 transition-colors"
            >
              <Smartphone className="w-4 h-4" />
              <span>دخول وضع نظارة VR Box (شاشة مزدوجة)</span>
            </button>
          </section>

          {statusMessage && (
            <div className="rounded-lg bg-sky-500/10 border border-sky-500/30 px-3 py-2 text-xs text-sky-300">
              {statusMessage}
            </div>
          )}

          <p className="text-[11px] text-slate-400 leading-relaxed">
            طريقة التحكم: لا تحتاج أي ريموت أو يد تحكم. حرّك رأسك لتوجيه النقطة المركزية نحو أي زر أو لوحة أو حرف في لوحة المفاتيح، وسيتم الضغط تلقائياً عند اكتمال الدائرة. انظر للأسفل مباشرة في أي وقت لإظهار زر العودة للقائمة الرئيسية.
          </p>
        </div>
      </div>
    </div>
  );
};
