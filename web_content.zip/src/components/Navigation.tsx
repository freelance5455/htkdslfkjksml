import React from 'react';
import { ZahraLogo } from './ZahraLogo';
import { UserProfile } from '../types';
import { 
  Radio, 
  MessageCircle, 
  FileText, 
  User,
  Download
} from 'lucide-react';

export type ActiveTab = 'rooms' | 'chats' | 'posts' | 'profile';

interface NavigationProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  currentUser: UserProfile;
  onOpenExport?: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({ 
  activeTab, 
  setActiveTab, 
  currentUser,
  onOpenExport
}) => {
  return (
    <>
      {/* Top App Header (Shown on Rooms, Chats, and Posts, hidden on Profile to match user's custom page) */}
      {activeTab !== 'profile' && (
        <header className={`sticky top-0 z-40 w-full backdrop-blur-xl border-b px-4 py-3 transition-colors ${
          activeTab === 'rooms'
            ? 'bg-white/95 border-pink-100/90 text-slate-800 shadow-sm'
            : 'bg-white/95 border-pink-100/90 text-slate-800 shadow-sm'
        }`}>
          <div className="max-w-4xl mx-auto flex items-center justify-between">
            
            {/* Logo & Brand */}
            <div 
              onClick={() => setActiveTab('rooms')} 
              className="flex items-center gap-2.5 cursor-pointer group"
            >
              <ZahraLogo size="sm" pulse={false} />
              <div>
                <span className={`text-base sm:text-lg font-black tracking-tight font-['Cairo'] ${
                  activeTab === 'rooms'
                    ? 'text-transparent bg-clip-text bg-gradient-to-r from-purple-700 via-pink-600 to-rose-600'
                    : 'text-transparent bg-clip-text bg-gradient-to-r from-purple-700 via-pink-600 to-rose-600'
                }`}>
                  زهرة شات
                </span>
                <span className="block text-[10px] text-pink-500 font-medium">
                  Zahra Social
                </span>
              </div>
            </div>

            {/* Actions: Download Code & User Avatar */}
            <div className="flex items-center gap-2 sm:gap-3">
              {onOpenExport && (
                <button
                  onClick={onOpenExport}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-pink-500/10 hover:bg-pink-500/20 text-pink-600 dark:text-pink-400 border border-pink-500/30 text-xs font-bold transition-all cursor-pointer shadow-sm active:scale-95"
                  title="تحميل كود وملف التطبيق (ZIP)"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span className="hidden xs:inline">ملف الكود</span>
                </button>
              )}

              <button
                onClick={() => setActiveTab('profile')}
                className="relative p-0.5 rounded-full ring-2 ring-pink-500/30 hover:ring-pink-500 transition-all cursor-pointer"
                title="الملف الشخصي"
              >
                <img
                  src={currentUser.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${currentUser.uid}`}
                  alt={currentUser.displayName}
                  className="w-9 h-9 rounded-full object-cover bg-slate-50 border border-slate-200 shadow-sm"
                />
                <span className="absolute bottom-0 left-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-white" />
              </button>
            </div>

          </div>
        </header>
      )}

      {/* Floating Bottom Navigation Bar */}
      <nav className={`fixed bottom-0 left-0 right-0 z-40 backdrop-blur-2xl border-t px-2 sm:px-4 py-2 sm:py-2.5 shadow-2xl transition-colors ${
        activeTab === 'profile' || activeTab === 'chats' || activeTab === 'posts'
          ? 'bg-white/95 border-pink-100/90 text-slate-600'
          : 'bg-white/90 border-slate-200/90 text-slate-500'
      }`}>
        <div className="max-w-md mx-auto flex items-center justify-around">
          
          {/* 1. الغرف (Rooms) */}
          <button
            onClick={() => setActiveTab('rooms')}
            className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-2xl transition-all cursor-pointer ${
              activeTab === 'rooms'
                ? 'text-pink-600 scale-105 font-bold'
                : 'hover:text-pink-600'
            }`}
          >
            <div className={`p-1.5 rounded-xl ${
              activeTab === 'rooms' ? 'bg-pink-500/15 text-pink-600 ring-1 ring-pink-500/30' : ''
            }`}>
              <Radio className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold font-['Cairo']">الغرف</span>
          </button>

          {/* 2. المحادثة (Chat / Direct Messages) - Adjacent to Rooms and Profile */}
          <button
            onClick={() => setActiveTab('chats')}
            className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-2xl transition-all cursor-pointer relative ${
              activeTab === 'chats'
                ? 'text-pink-600 scale-105 font-bold'
                : 'hover:text-pink-600'
            }`}
          >
            <div className={`p-1.5 rounded-xl relative ${
              activeTab === 'chats' ? 'bg-pink-500/15 text-pink-600 ring-1 ring-pink-500/30' : ''
            }`}>
              <MessageCircle className="w-5 h-5" />
              {/* Little red unread notification bubble */}
              <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-pink-600 border border-white" />
            </div>
            <span className="text-[11px] font-bold font-['Cairo']">المحادثة</span>
          </button>

          {/* 3. المنشورات (Posts) */}
          <button
            onClick={() => setActiveTab('posts')}
            className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-2xl transition-all cursor-pointer ${
              activeTab === 'posts'
                ? 'text-pink-600 scale-105 font-bold'
                : 'hover:text-pink-600'
            }`}
          >
            <div className={`p-1.5 rounded-xl ${
              activeTab === 'posts' ? 'bg-pink-500/15 text-pink-600 ring-1 ring-pink-500/30' : ''
            }`}>
              <FileText className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold font-['Cairo']">المنشورات</span>
          </button>

          {/* 4. صفحتي (Profile) */}
          <button
            onClick={() => setActiveTab('profile')}
            className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-2xl transition-all cursor-pointer ${
              activeTab === 'profile'
                ? 'text-pink-600 scale-105 font-bold'
                : 'hover:text-pink-600'
            }`}
          >
            <div className={`p-1.5 rounded-xl ${
              activeTab === 'profile' ? 'bg-pink-500/15 text-pink-600 ring-1 ring-pink-500/30' : ''
            }`}>
              <User className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-bold font-['Cairo']">صفحتي</span>
          </button>

        </div>
      </nav>
    </>
  );
};
