import React from 'react';
import { Home, Compass, Plus, Bell, User, MessageCircle, BarChart3, ShieldCheck, Download } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { usePWAInstall } from '../hooks/usePWAInstall';

export type TabType = 'feed' | 'explore' | 'create' | 'notifications' | 'profile' | 'messages' | 'studio' | 'certificate';

interface NavigationProps {
  currentTab: TabType;
  onSelectTab: (tab: TabType) => void;
  unreadCount?: number;
  onSignOut?: () => void;
}

export const BottomNav: React.FC<NavigationProps> = ({ currentTab, onSelectTab, unreadCount = 3 }) => {
  const { userProfile } = useAuth();

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#050505]/95 backdrop-blur-lg border-t border-[#19191F] px-4 py-2">
      <div className="flex items-center justify-around max-w-md mx-auto">
        {/* Início */}
        <button
          onClick={() => onSelectTab('feed')}
          className="flex flex-col items-center justify-center p-2 transition-all"
        >
          <Home
            size={24}
            className={currentTab === 'feed' ? 'text-[#FF008C]' : 'text-[#A1A1AA] hover:text-white'}
          />
          {currentTab === 'feed' && (
            <span className="w-1.5 h-1.5 rounded-full bg-[#FF008C] mt-1" />
          )}
        </button>

        {/* Explorar */}
        <button
          onClick={() => onSelectTab('explore')}
          className="flex flex-col items-center justify-center p-2 transition-all"
        >
          <Compass
            size={24}
            className={currentTab === 'explore' ? 'text-[#FF008C]' : 'text-[#A1A1AA] hover:text-white'}
          />
          {currentTab === 'explore' && (
            <span className="w-1.5 h-1.5 rounded-full bg-[#FF008C] mt-1" />
          )}
        </button>

        {/* Botão Central de Publicação (+): circular, com gradiente rosa e roxo e símbolo branco */}
        <button
          onClick={() => onSelectTab('create')}
          aria-label="Criar publicação"
          className="relative -top-2 flex items-center justify-center w-12 h-12 rounded-full bg-clipshare-gradient glow-clipshare text-white shadow-lg active:scale-95 transition-transform"
        >
          <Plus size={28} strokeWidth={3} />
        </button>

        {/* Notificações */}
        <button
          onClick={() => onSelectTab('notifications')}
          className="relative flex flex-col items-center justify-center p-2 transition-all"
        >
          <Bell
            size={24}
            className={currentTab === 'notifications' ? 'text-[#FF008C]' : 'text-[#A1A1AA] hover:text-white'}
          />
          {unreadCount > 0 && (
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#FF3B30]" />
          )}
          {currentTab === 'notifications' && (
            <span className="w-1.5 h-1.5 rounded-full bg-[#FF008C] mt-1" />
          )}
        </button>

        {/* Perfil */}
        <button
          onClick={() => onSelectTab('profile')}
          className="flex flex-col items-center justify-center p-2 transition-all"
        >
          {userProfile?.photoURL ? (
            <div
              className={`w-7 h-7 rounded-full p-[1.5px] ${
                currentTab === 'profile' ? 'bg-[#FF008C]' : 'border border-transparent'
              }`}
            >
              <img
                src={userProfile.photoURL}
                alt={userProfile.username}
                className="w-full h-full rounded-full object-cover"
              />
            </div>
          ) : (
            <User
              size={24}
              className={currentTab === 'profile' ? 'text-[#FF008C]' : 'text-[#A1A1AA] hover:text-white'}
            />
          )}
          {currentTab === 'profile' && (
            <span className="w-1.5 h-1.5 rounded-full bg-[#FF008C] mt-1" />
          )}
        </button>
      </div>
    </nav>
  );
};

export const DesktopSidebar: React.FC<NavigationProps> = ({ currentTab, onSelectTab, unreadCount = 3, onSignOut }) => {
  const { userProfile, signOut } = useAuth();
  const { isInstallable, install } = usePWAInstall();

  return (
    <aside className="hidden md:flex flex-col justify-between w-64 lg:w-72 h-screen sticky top-0 bg-[#050505] border-r border-[#19191F] p-6 z-30 select-none">
      <div className="space-y-6">
        {/* Brand Header */}
        <div
          onClick={() => onSelectTab('feed')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <img src="/clipshare-bubble.svg" alt="ClipShare" className="w-9 h-9 invert transition-transform group-hover:scale-105" />
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight text-white flex items-center">
              ClipShare
            </h1>
            <p className="text-[11px] text-[#A1A1AA] tracking-wide">Sua vibe. Seu mundo.</p>
          </div>
        </div>

        {/* Primary Navigation Links */}
        <nav className="space-y-1.5 pt-2">
          <button
            onClick={() => onSelectTab('feed')}
            className={`w-full flex items-center gap-4 px-4 py-3 rounded-2xl font-medium text-sm transition-all ${
              currentTab === 'feed'
                ? 'bg-[#19191F] text-white shadow-sm border border-[#272730]'
                : 'text-[#A1A1AA] hover:text-white hover:bg-[#101014]'
            }`}
          >
            <Home size={22} className={currentTab === 'feed' ? 'text-[#FF008C]' : ''} />
            <span>Início (Feed)</span>
          </button>

          <button
            onClick={() => onSelectTab('explore')}
            className={`w-full flex items-center gap-4 px-4 py-3 rounded-2xl font-medium text-sm transition-all ${
              currentTab === 'explore'
                ? 'bg-[#19191F] text-white shadow-sm border border-[#272730]'
                : 'text-[#A1A1AA] hover:text-white hover:bg-[#101014]'
            }`}
          >
            <Compass size={22} className={currentTab === 'explore' ? 'text-[#FF008C]' : ''} />
            <span>Explorar</span>
          </button>

          <button
            onClick={() => onSelectTab('messages')}
            className={`w-full flex items-center gap-4 px-4 py-3 rounded-2xl font-medium text-sm transition-all ${
              currentTab === 'messages'
                ? 'bg-[#19191F] text-white shadow-sm border border-[#272730]'
                : 'text-[#A1A1AA] hover:text-white hover:bg-[#101014]'
            }`}
          >
            <MessageCircle size={22} className={currentTab === 'messages' ? 'text-[#FF008C]' : ''} />
            <span>Mensagens</span>
          </button>

          <button
            onClick={() => onSelectTab('notifications')}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-2xl font-medium text-sm transition-all ${
              currentTab === 'notifications'
                ? 'bg-[#19191F] text-white shadow-sm border border-[#272730]'
                : 'text-[#A1A1AA] hover:text-white hover:bg-[#101014]'
            }`}
          >
            <div className="flex items-center gap-4">
              <Bell size={22} className={currentTab === 'notifications' ? 'text-[#FF008C]' : ''} />
              <span>Notificações</span>
            </div>
            {unreadCount > 0 && (
              <span className="bg-[#FF3B30] text-white text-[11px] font-bold px-2 py-0.5 rounded-full">
                {unreadCount}
              </span>
            )}
          </button>

          <button
            onClick={() => onSelectTab('studio')}
            className={`w-full flex items-center gap-4 px-4 py-3 rounded-2xl font-medium text-sm transition-all ${
              currentTab === 'studio'
                ? 'bg-[#19191F] text-white shadow-sm border border-[#272730]'
                : 'text-[#A1A1AA] hover:text-white hover:bg-[#101014]'
            }`}
          >
            <BarChart3 size={22} className={currentTab === 'studio' ? 'text-[#FF008C]' : ''} />
            <span>ClipShare Studio</span>
          </button>

          <button
            onClick={() => onSelectTab('profile')}
            className={`w-full flex items-center gap-4 px-4 py-3 rounded-2xl font-medium text-sm transition-all ${
              currentTab === 'profile'
                ? 'bg-[#19191F] text-white shadow-sm border border-[#272730]'
                : 'text-[#A1A1AA] hover:text-white hover:bg-[#101014]'
            }`}
          >
            <User size={22} className={currentTab === 'profile' ? 'text-[#FF008C]' : ''} />
            <span>Perfil</span>
          </button>
        </nav>

        {/* Create Post Action Button */}
        <button
          onClick={() => onSelectTab('create')}
          className="w-full flex items-center justify-center gap-2 py-3.5 px-4 rounded-full bg-clipshare-gradient glow-clipshare text-white font-semibold text-sm hover:opacity-95 active:scale-98 transition-all cursor-pointer"
        >
          <Plus size={20} strokeWidth={2.5} />
          <span>Publicar clipe</span>
        </button>

        {/* Influencer Certificate Quick Access */}
        <button
          onClick={() => onSelectTab('certificate')}
          className="w-full flex items-center gap-3 p-3 rounded-2xl bg-gradient-to-r from-amber-500/10 via-rose-500/10 to-purple-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold hover:border-amber-400/50 transition-all text-left"
        >
          <ShieldCheck size={20} className="text-amber-400 shrink-0" />
          <div className="truncate">
            <p className="font-bold">Certificado Criador</p>
            <p className="text-[10px] text-amber-200/80">Verificar autenticidade</p>
          </div>
        </button>

        {/* PWA Install Button if available */}
        {isInstallable && (
          <button
            onClick={install}
            className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-[#19191F] border border-[#272730] text-xs text-[#A1A1AA] hover:text-white transition-colors"
          >
            <Download size={14} />
            <span>Instalar Aplicativo Web</span>
          </button>
        )}
      </div>

      {/* User Quick Switcher & Logout */}
      <div className="pt-4 border-t border-[#19191F]">
        <div className="flex items-center justify-between">
          <div
            onClick={() => onSelectTab('profile')}
            className="flex items-center gap-3 cursor-pointer overflow-hidden"
          >
            <img
              src={userProfile?.photoURL || '/icon.svg'}
              alt={userProfile?.username}
              className="w-10 h-10 rounded-full object-cover border border-[#272730]"
            />
            <div className="truncate">
              <p className="text-sm font-semibold text-white truncate">
                {userProfile?.displayName || 'Criador ClipShare'}
              </p>
              <p className="text-xs text-[#A1A1AA] truncate">
                @{userProfile?.username || 'usuario'}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              if (onSignOut) {
                onSignOut();
              } else {
                signOut();
              }
              onSelectTab('feed');
            }}
            title="Sair da conta"
            className="text-xs text-[#A1A1AA] hover:text-[#FF3B30] p-2 rounded-lg hover:bg-[#101014] transition-colors cursor-pointer"
          >
            Sair
          </button>
        </div>
      </div>
    </aside>
  );
};
