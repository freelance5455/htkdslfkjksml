import React from 'react';
import { BookOpen, ClipboardCheck, BarChart3 } from 'lucide-react';

export type AppView = 'study' | 'tests' | 'graphs';

interface NavigationProps {
  currentView: AppView;
  onViewChange: (view: AppView) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ currentView, onViewChange }) => {
  return (
    <nav
      aria-label="Main Navigation"
      className="fixed bottom-0 left-0 right-0 z-40 bg-[#09090c]/95 backdrop-blur-md border-t border-[#1f1f27] px-2 pt-1.5 pb-2 flex items-center justify-around"
    >
      <div className="w-full max-w-[500px] flex items-center justify-around">
        <button
          type="button"
          onClick={() => onViewChange('study')}
          className={`flex-1 flex flex-col items-center justify-center gap-1 py-1 text-[11px] transition-all cursor-pointer ${
            currentView === 'study'
              ? 'text-white font-bold'
              : 'text-[#777784] font-medium hover:text-zinc-300'
          }`}
        >
          <BookOpen className="w-5 h-5" strokeWidth={currentView === 'study' ? 2.2 : 1.7} />
          <span>Study</span>
          <span
            className={`w-1 h-1 rounded-full transition-opacity ${
              currentView === 'study' ? 'bg-[#ff6b3d] opacity-100' : 'opacity-0'
            }`}
          />
        </button>

        <button
          type="button"
          onClick={() => onViewChange('tests')}
          className={`flex-1 flex flex-col items-center justify-center gap-1 py-1 text-[11px] transition-all cursor-pointer ${
            currentView === 'tests'
              ? 'text-white font-bold'
              : 'text-[#777784] font-medium hover:text-zinc-300'
          }`}
        >
          <ClipboardCheck className="w-5 h-5" strokeWidth={currentView === 'tests' ? 2.2 : 1.7} />
          <span>Tests</span>
          <span
            className={`w-1 h-1 rounded-full transition-opacity ${
              currentView === 'tests' ? 'bg-[#ff6b3d] opacity-100' : 'opacity-0'
            }`}
          />
        </button>

        <button
          type="button"
          onClick={() => onViewChange('graphs')}
          className={`flex-1 flex flex-col items-center justify-center gap-1 py-1 text-[11px] transition-all cursor-pointer ${
            currentView === 'graphs'
              ? 'text-white font-bold'
              : 'text-[#777784] font-medium hover:text-zinc-300'
          }`}
        >
          <BarChart3 className="w-5 h-5" strokeWidth={currentView === 'graphs' ? 2.2 : 1.7} />
          <span>Graphs</span>
          <span
            className={`w-1 h-1 rounded-full transition-opacity ${
              currentView === 'graphs' ? 'bg-[#ff6b3d] opacity-100' : 'opacity-0'
            }`}
          />
        </button>
      </div>
    </nav>
  );
};
