import React from 'react';
import { 
  FileText, 
  Sparkles, 
  Users, 
  Trophy, 
  ShieldAlert, 
  BookOpen, 
  UserCheck 
} from 'lucide-react';
import { Language, UserRole } from '../types';
import { TRANSLATIONS } from '../lib/translations';

interface NavigationProps {
  language: Language;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currentUserRole: UserRole;
  pendingApprovalsCount: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  language,
  activeTab,
  setActiveTab,
  currentUserRole,
  pendingApprovalsCount
}) => {
  const t = TRANSLATIONS[language];

  const navItems = [
    { id: 'papers', label: t.navHome, icon: FileText },
    { id: 'ai-assistant', label: t.navAiAssistant, icon: Sparkles, badge: 'Gemini AI' },
    { id: 'community', label: t.navCommunity, icon: Users },
    { id: 'leaderboard', label: t.navLeaderboard, icon: Trophy },
    { id: 'profile', label: t.navProfile, icon: UserCheck }
  ];

  const isAdmin = currentUserRole === 'ADMIN' || currentUserRole === 'SUPER_ADMIN' || currentUserRole === 'MODERATOR';

  if (isAdmin) {
    navItems.push({
      id: 'admin',
      label: t.navAdmin,
      icon: ShieldAlert,
      badge: pendingApprovalsCount > 0 ? `${pendingApprovalsCount} Pending` : undefined
    });
  }

  return (
    <nav className="bg-slate-900/80 border-b border-slate-800/80 sticky top-16 z-30 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-2 overflow-x-auto py-2 no-scrollbar">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-amber-400'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-slate-950' : 'text-amber-400'}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span
                    className={`px-1.5 py-0.5 text-[9px] font-extrabold uppercase rounded-full ${
                      isActive
                        ? 'bg-slate-950 text-amber-400'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};
