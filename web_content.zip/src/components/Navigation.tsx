import React from 'react';
import { Home, BookMarked, HelpCircle, Layers, Award, User } from 'lucide-react';

export type TabId = 'home' | 'wordbook' | 'detective' | 'flashcards' | 'quiz' | 'profile';

interface NavigationProps {
  currentTab: TabId;
  onSelectTab: (tab: TabId) => void;
  mistakesCount?: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  currentTab,
  onSelectTab,
}) => {
  const tabs = [
    { id: 'home' as TabId, label: 'Home', icon: Home },
    { id: 'wordbook' as TabId, label: 'Words', icon: BookMarked },
    { id: 'detective' as TabId, label: 'Clues', icon: HelpCircle },
    { id: 'flashcards' as TabId, label: 'Cards', icon: Layers },
    { id: 'quiz' as TabId, label: 'Quiz', icon: Award },
    { id: 'profile' as TabId, label: 'Profile', icon: User },
  ];

  return (
    <nav className="bg-white/95 dark:bg-[#111827]/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 fixed bottom-0 left-0 right-0 z-40 safe-bottom transition-colors">
      <div className="max-w-md mx-auto flex items-center justify-around h-16 px-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`flex flex-col items-center justify-center w-12 py-1 relative transition-colors ${
                isActive ? 'text-emerald-600 dark:text-emerald-400 font-black' : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />
              </div>
              <span className={`text-[9px] mt-0.5 tracking-tight ${isActive ? 'font-extrabold' : 'font-semibold'}`}>
                {tab.label}
              </span>
              {isActive && (
                <div className="absolute -top-1 w-5 h-0.5 rounded-full bg-emerald-500" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
