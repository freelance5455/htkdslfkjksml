import React, { useState } from 'react';
import {
  Activity,
  Bot,
  Compass,
  Crosshair,
  Gamepad2,
  Gauge,
  Layers,
  LayoutDashboard,
  Menu,
  MonitorCheck,
  Settings,
  Sliders,
  Sparkles,
  Wifi,
  X,
  Zap,
} from 'lucide-react';
import { ScreenId } from '../types';
import { TranslationPack } from '../i18n';
import { APP_EMBLEM_URL } from '../constants';
import { ResilientImage } from './ResilientImage';

interface NavigationProps {
  activeScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
  t: TranslationPack;
  children: React.ReactNode;
}

interface NavItem {
  id: ScreenId;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  group: 'core' | 'tools' | 'app';
}

export const AppShell: React.FC<NavigationProps> = ({
  activeScreen,
  onNavigate,
  t,
  children,
}) => {
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);

  const navItems: NavItem[] = [
    { id: 'dashboard', label: t.navDashboard, icon: LayoutDashboard, group: 'core' },
    { id: 'games', label: t.navGames, icon: Gamepad2, group: 'core' },
    { id: 'ultra', label: t.navUltra, icon: Zap, group: 'core' },
    { id: 'gfx', label: t.navGfx, icon: Sliders, group: 'core' },
    { id: 'hud', label: t.navHud, icon: Layers, group: 'core' },
    { id: 'monitor', label: t.navMonitor, icon: Activity, group: 'tools' },
    { id: 'device-check', label: t.navDeviceCheck, icon: MonitorCheck, group: 'tools' },
    { id: 'coach', label: t.navCoach, icon: Bot, group: 'tools' },
    { id: 'network', label: t.navNetwork, icon: Wifi, group: 'tools' },
    { id: 'training', label: t.navTraining, icon: Crosshair, group: 'tools' },
    { id: 'settings', label: t.navSettings, icon: Settings, group: 'app' },
    { id: 'onboarding', label: t.navOnboarding, icon: Compass, group: 'app' },
    { id: 'splash', label: t.navSplash, icon: Sparkles, group: 'app' },
  ];

  const handleSelect = (id: ScreenId) => {
    onNavigate(id);
    setMobileDrawerOpen(false);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F4F6F4] dark:bg-[#101010] text-neutral-900 dark:text-neutral-100 transition-colors">
      {/* Top Bar Contract: 3 zones (Brand wordmark — 4-5 nav links — 1 primary CTA) */}
      <header className="sticky top-0 z-30 h-14 px-4 lg:px-6 flex items-center justify-between gap-8 bg-white/85 dark:bg-[#141414]/85 backdrop-blur-md border-b border-neutral-200 dark:border-white/10">
        {/* Zone 1: Brand Title */}
        <button
          type="button"
          onClick={() => handleSelect('dashboard')}
          className="flex items-center gap-2.5 text-left whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#39E52D] rounded-lg"
        >
          <ResilientImage
            src={APP_EMBLEM_URL}
            alt="Game Booster PRO Emblem"
            className="w-7 h-7 rounded-lg object-cover border border-neutral-200 dark:border-white/15"
          />
          <span className="font-display text-base font-bold tracking-tight text-neutral-900 dark:text-white whitespace-nowrap shrink-0">
            {t.appName}
          </span>
        </button>

        {/* Zone 2: 5 concise single-line nav links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-neutral-600 dark:text-neutral-400">
          {(
            [
              { id: 'dashboard', label: t.navDashboard },
              { id: 'games', label: t.navGames },
              { id: 'monitor', label: t.navMonitor },
              { id: 'coach', label: t.navCoach },
              { id: 'network', label: t.navNetwork },
            ] as const
          ).map((link) => {
            const active = activeScreen === link.id;
            return (
              <button
                key={link.id}
                type="button"
                onClick={() => handleSelect(link.id)}
                className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                  active
                    ? 'text-emerald-700 dark:text-[#39E52D] border-emerald-700 dark:border-[#39E52D]'
                    : 'border-transparent hover:text-neutral-900 dark:hover:text-white'
                }`}
              >
                {link.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 primary CTA (plus mobile menu trigger on small viewports) */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => handleSelect('ultra')}
            className="px-4 py-2 min-h-[40px] rounded-xl bg-[#39E52D] hover:bg-[#32cc27] text-black text-xs font-bold tracking-tight transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 shadow-sm"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>{t.launchUltra}</span>
          </button>
          <button
            type="button"
            onClick={() => setMobileDrawerOpen(true)}
            aria-label="Open all screens menu"
            className="lg:hidden min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl border border-neutral-200 dark:border-white/10 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-white/5"
          >
            <Menu className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Workspace: Desktop Sidebar + Viewport */}
      <div className="flex-1 flex max-w-[1600px] w-full mx-auto">
        {/* Desktop Sidebar for all 13 screens */}
        <aside className="hidden lg:flex flex-col w-64 shrink-0 border-r border-neutral-200 dark:border-white/10 bg-white/50 dark:bg-[#131313] px-3 py-5 gap-6">
          <div>
            <div className="px-3 mb-2 text-xs font-medium text-neutral-500 dark:text-neutral-400">
              Gaming Core
            </div>
            <div className="space-y-1">
              {navItems
                .filter((i) => i.group === 'core')
                .map((item) => {
                  const Icon = item.icon;
                  const active = activeScreen === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleSelect(item.id)}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 min-h-[40px] rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
                        active
                          ? 'bg-emerald-600/10 dark:bg-[#39E52D]/15 text-emerald-800 dark:text-[#39E52D] border border-emerald-600/20 dark:border-[#39E52D]/35'
                          : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-white/[0.04] hover:text-neutral-900 dark:hover:text-neutral-100 border border-transparent'
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </button>
                  );
                })}
            </div>
          </div>

          <div>
            <div className="px-3 mb-2 text-xs font-medium text-neutral-500 dark:text-neutral-400">
              Diagnostics & Coach
            </div>
            <div className="space-y-1">
              {navItems
                .filter((i) => i.group === 'tools')
                .map((item) => {
                  const Icon = item.icon;
                  const active = activeScreen === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleSelect(item.id)}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 min-h-[40px] rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
                        active
                          ? 'bg-emerald-600/10 dark:bg-[#39E52D]/15 text-emerald-800 dark:text-[#39E52D] border border-emerald-600/20 dark:border-[#39E52D]/35'
                          : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-white/[0.04] hover:text-neutral-900 dark:hover:text-neutral-100 border border-transparent'
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </button>
                  );
                })}
            </div>
          </div>

          <div>
            <div className="px-3 mb-2 text-xs font-medium text-neutral-500 dark:text-neutral-400">
              Preferences & Tour
            </div>
            <div className="space-y-1">
              {navItems
                .filter((i) => i.group === 'app')
                .map((item) => {
                  const Icon = item.icon;
                  const active = activeScreen === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleSelect(item.id)}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 min-h-[40px] rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
                        active
                          ? 'bg-emerald-600/10 dark:bg-[#39E52D]/15 text-emerald-800 dark:text-[#39E52D] border border-emerald-600/20 dark:border-[#39E52D]/35'
                          : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-100 dark:hover:bg-white/[0.04] hover:text-neutral-900 dark:hover:text-neutral-100 border border-transparent'
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </button>
                  );
                })}
            </div>
          </div>
        </aside>

        {/* Main Content Viewport */}
        <main className="flex-1 min-w-0 px-4 py-5 pb-20 lg:px-8 lg:py-7 lg:pb-10">
          {children}
        </main>
      </div>

      {/* Mobile Bottom Tab Bar (Compact 56px height, well under 15% cap) */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-30 h-14 grid grid-cols-4 bg-white/92 dark:bg-[#141414]/92 backdrop-blur-md border-t border-neutral-200 dark:border-white/10">
        {(
          [
            { id: 'dashboard', label: t.navDashboard, icon: LayoutDashboard },
            { id: 'games', label: t.navGames, icon: Gamepad2 },
            { id: 'monitor', label: t.navMonitor, icon: Gauge },
            { id: 'coach', label: t.navCoach, icon: Bot },
          ] as const
        ).map((tab) => {
          const Icon = tab.icon;
          const active = activeScreen === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => handleSelect(tab.id)}
              className={`flex flex-col items-center justify-center min-h-[44px] transition-colors ${
                active
                  ? 'text-emerald-700 dark:text-[#39E52D]'
                  : 'text-neutral-500 dark:text-neutral-400'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] font-medium mt-0.5 truncate max-w-[76px]">
                {tab.label}
              </span>
            </button>
          );
        })}
      </nav>

      {/* Mobile All-Screens Drawer */}
      {mobileDrawerOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex justify-end">
          <div className="w-72 max-w-[85vw] h-full bg-white dark:bg-[#151515] border-l border-neutral-200 dark:border-white/10 p-4 overflow-y-auto">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-neutral-200 dark:border-white/10">
              <span className="font-display text-base font-bold">{t.appName}</span>
              <button
                type="button"
                onClick={() => setMobileDrawerOpen(false)}
                aria-label="Close navigation menu"
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl hover:bg-neutral-100 dark:hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const active = activeScreen === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelect(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-3 min-h-[44px] rounded-xl text-sm font-medium transition-colors ${
                      active
                        ? 'bg-emerald-600/10 dark:bg-[#39E52D]/15 text-emerald-800 dark:text-[#39E52D]'
                        : 'text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-white/5'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
