import React from 'react';
import { useParentControl } from '../context/ParentControlContext';
import { 
  LayoutDashboard, 
  Grid, 
  Camera, 
  Sliders, 
  MapPin, 
  Bell, 
  PlusCircle, 
  Code2, 
  Mic,
  PackageCheck
} from 'lucide-react';

interface NavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeTab, setActiveTab }) => {
  const { language, unreadAlertsCount, isLiveCameraStreaming, isMicListening } = useParentControl();
  const isAr = language === 'ar';

  const navItems = [
    {
      id: 'dashboard',
      labelAr: 'الرئيسية',
      labelEn: 'Dashboard',
      icon: LayoutDashboard,
    },
    {
      id: 'apps',
      labelAr: 'إدارة التطبيقات',
      labelEn: 'Apps & Limits',
      icon: Grid,
    },
    {
      id: 'camera_mic',
      labelAr: 'الكاميرا والمايك',
      labelEn: 'Camera & Mic',
      icon: Camera,
      indicator: isLiveCameraStreaming || isMicListening ? 'active' : undefined,
    },
    {
      id: 'settings',
      labelAr: 'إعدادات الجهاز',
      labelEn: 'Device Settings',
      icon: Sliders,
    },
    {
      id: 'location',
      labelAr: 'الموقع والمناطق',
      labelEn: 'GPS & Geofence',
      icon: MapPin,
    },
    {
      id: 'alerts',
      labelAr: 'التنبيهات',
      labelEn: 'Alerts',
      icon: Bell,
      badge: unreadAlertsCount > 0 ? unreadAlertsCount : undefined,
    },
    {
      id: 'pair',
      labelAr: 'إقران جهاز',
      labelEn: 'Pair Device',
      icon: PlusCircle,
    },
    {
      id: 'flutter',
      labelAr: 'كود Flutter',
      labelEn: 'Flutter Code',
      icon: Code2,
    },
    {
      id: 'apk',
      labelAr: 'استخراج APK',
      labelEn: 'Export APK',
      icon: PackageCheck,
      badge: isAr ? 'جديد' : 'NEW',
    },
  ];

  return (
    <nav className="hidden sm:block w-full bg-white dark:bg-slate-900 border-b border-slate-200/80 dark:border-slate-800 px-4 sm:px-6 lg:px-8 overflow-x-auto no-scrollbar shadow-xs transition-colors duration-200">
      <div className="max-w-7xl mx-auto flex items-center gap-1 sm:gap-2 py-2 min-w-max">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              id={`nav-tab-${item.id}`}
              onClick={() => setActiveTab(item.id)}
              className={`relative flex items-center gap-2 px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100/80 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span>{isAr ? item.labelAr : item.labelEn}</span>

              {/* Streaming Indicator */}
              {item.indicator === 'active' && (
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
              )}

              {/* Unread Alert Badge */}
              {item.badge !== undefined && (
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                  isActive ? 'bg-white text-indigo-700' : 'bg-rose-600 text-white'
                }`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
