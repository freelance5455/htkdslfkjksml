import React from 'react';
import { useApp } from '../context/AppContext';
import { ScreenId } from '../types';
import { Home, Calendar, Wallet, User, Sparkles, Target, Brain, Smartphone, Maximize2, Moon, Sun } from 'lucide-react';
import { sound } from '../utils/sound';

export const BottomNavigation: React.FC = () => {
  const { activeScreen, setActiveScreen, setQuickActionOpen } = useApp();

  const handleTabClick = (screen: ScreenId) => {
    sound.playClick();
    setActiveScreen(screen);
  };

  return (
    <nav
      aria-label="Bottom Navigation"
      className="fixed bottom-0 left-0 right-0 z-40 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-t border-slate-200/80 dark:border-slate-800 transition-colors"
    >
      <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-between">
        {/* Home */}
        <button
          onClick={() => handleTabClick('home')}
          className={`flex flex-col items-center justify-center flex-1 h-full transition-colors ${
            activeScreen === 'home'
              ? 'text-indigo-600 dark:text-indigo-400 font-semibold'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
          }`}
        >
          <Home className="w-5 h-5 mb-0.5" strokeWidth={activeScreen === 'home' ? 2.3 : 1.8} />
          <span className="text-[11px] tracking-tight">Home</span>
        </button>

        {/* Planner */}
        <button
          onClick={() => handleTabClick('planner')}
          className={`flex flex-col items-center justify-center flex-1 h-full transition-colors ${
            activeScreen === 'planner'
              ? 'text-indigo-600 dark:text-indigo-400 font-semibold'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
          }`}
        >
          <Calendar className="w-5 h-5 mb-0.5" strokeWidth={activeScreen === 'planner' ? 2.3 : 1.8} />
          <span className="text-[11px] tracking-tight">Planner</span>
        </button>

        {/* Center AI Buddy Orb / Button */}
        <div className="flex-1 flex justify-center -mt-5">
          <button
            onClick={() => handleTabClick('buddy')}
            className={`group relative flex items-center justify-center w-14 h-14 rounded-full shadow-lg transition-transform active:scale-95 ${
              activeScreen === 'buddy'
                ? 'bg-gradient-to-tr from-indigo-600 via-violet-600 to-sky-400 ring-4 ring-indigo-200 dark:ring-indigo-950/60 shadow-indigo-500/25'
                : 'bg-gradient-to-tr from-indigo-600 via-violet-500 to-sky-500 hover:shadow-indigo-500/30'
            }`}
            aria-label="AI Buddy Chat"
          >
            <div className="absolute inset-0.5 rounded-full overflow-hidden flex items-center justify-center">
              <img
                src="/src/assets/images/hibuddy_orb_avatar_1794042543018.jpg"
                alt="HiBuddy"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />
            </div>
            <span className="absolute -bottom-5 text-[10px] font-semibold text-indigo-600 dark:text-indigo-400 tracking-tight">
              Buddy
            </span>
          </button>
        </div>

        {/* Money */}
        <button
          onClick={() => handleTabClick('money')}
          className={`flex flex-col items-center justify-center flex-1 h-full transition-colors ${
            activeScreen === 'money'
              ? 'text-indigo-600 dark:text-indigo-400 font-semibold'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
          }`}
        >
          <Wallet className="w-5 h-5 mb-0.5" strokeWidth={activeScreen === 'money' ? 2.3 : 1.8} />
          <span className="text-[11px] tracking-tight">Money</span>
        </button>

        {/* Profile */}
        <button
          onClick={() => handleTabClick('profile')}
          className={`flex flex-col items-center justify-center flex-1 h-full transition-colors ${
            activeScreen === 'profile'
              ? 'text-indigo-600 dark:text-indigo-400 font-semibold'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
          }`}
        >
          <User className="w-5 h-5 mb-0.5" strokeWidth={activeScreen === 'profile' ? 2.3 : 1.8} />
          <span className="text-[11px] tracking-tight">Profile</span>
        </button>
      </div>
    </nav>
  );
};

export const TopHeader: React.FC = () => {
  const {
    activeScreen,
    setActiveScreen,
    profile,
    updateProfile,
    isMobileFrameView,
    setIsMobileFrameView,
  } = useApp();

  const titles: Record<ScreenId, string> = {
    onboarding: 'Welcome',
    home: 'HiBuddy',
    planner: 'Smart Planner',
    buddy: 'AI Assistant',
    money: 'Money Manager',
    goals: 'Goals & Habits',
    memory: 'Personal Memory',
    profile: 'Profile & Settings',
  };

  const toggleTheme = () => {
    sound.playClick();
    const nextTheme = profile.theme === 'dark' ? 'light' : 'dark';
    updateProfile({ theme: nextTheme });
  };

  const toggleViewMode = () => {
    sound.playClick();
    const next = !isMobileFrameView;
    setIsMobileFrameView(next);
    localStorage.setItem('hibuddy_frame_view', JSON.stringify(next));
  };

  return (
    <header className="sticky top-0 z-30 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800/80 transition-colors">
      <div className="max-w-md mx-auto px-4 h-14 flex items-center justify-between">
        {/* Brand / Screen Title */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => {
              sound.playClick();
              setActiveScreen('home');
            }}
            className="flex items-center gap-2 text-left group"
          >
            <div className="w-8 h-8 rounded-full overflow-hidden bg-gradient-to-tr from-indigo-500 to-violet-500 p-0.5 shadow-sm">
              <img
                src="/src/assets/images/hibuddy_orb_avatar_1794042543018.jpg"
                alt="HiBuddy Logo"
                className="w-full h-full object-cover rounded-full"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <h1 className="text-base font-bold text-slate-900 dark:text-slate-100 tracking-tight leading-tight group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                {titles[activeScreen]}
              </h1>
              {activeScreen === 'home' && (
                <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-none">
                  Your life. Your goals. Your buddy.
                </p>
              )}
            </div>
          </button>
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-1.5">
          {/* Quick jump to Habits/Goals */}
          <button
            onClick={() => {
              sound.playClick();
              setActiveScreen('goals');
            }}
            title="Goals & Habits"
            className={`p-2 rounded-lg text-xs font-medium transition-colors ${
              activeScreen === 'goals'
                ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Target className="w-4 h-4" />
          </button>

          {/* Quick jump to Memory */}
          <button
            onClick={() => {
              sound.playClick();
              setActiveScreen('memory');
            }}
            title="Personal Memory"
            className={`p-2 rounded-lg text-xs font-medium transition-colors ${
              activeScreen === 'memory'
                ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400'
                : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Brain className="w-4 h-4" />
          </button>

          {/* Theme switcher */}
          <button
            onClick={toggleTheme}
            title={`Switch to ${profile.theme === 'dark' ? 'Light' : 'Dark'} mode`}
            className="p-2 rounded-lg text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            {profile.theme === 'dark' ? (
              <Sun className="w-4 h-4 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 text-indigo-600" />
            )}
          </button>

          {/* Phone Frame Toggle (Desktop) */}
          <button
            onClick={toggleViewMode}
            title={isMobileFrameView ? 'Expand to Fullscreen' : 'View in Phone Frame'}
            className="hidden md:flex p-2 rounded-lg text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            {isMobileFrameView ? (
              <Maximize2 className="w-4 h-4 text-indigo-500" />
            ) : (
              <Smartphone className="w-4 h-4 text-indigo-500" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
