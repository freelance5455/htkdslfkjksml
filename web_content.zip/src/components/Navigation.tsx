import React from 'react';
import { Home, Flame, BookOpen, TrendingUp, User, Play, Clock, Award, X } from 'lucide-react';
import { useWorkout } from '../context/WorkoutContext';

export type TabType = 'home' | 'workouts' | 'exercises' | 'progress' | 'profile' | 'skills';

interface NavigationProps {
  currentTab: TabType;
  onSelectTab: (tab: TabType) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ currentTab, onSelectTab }) => {
  const {
    activeWorkout,
    setIsWorkoutModalOpen,
    isTimerRunning,
    timerSecondsLeft,
    setIsTimerModalOpen,
    stopRestTimer,
    user
  } = useWorkout();

  const formatSeconds = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = sec % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const completedSetsCount = activeWorkout
    ? activeWorkout.exercises.reduce(
        (acc, ex) => acc + ex.sets.filter((s) => s.completed).length,
        0
      )
    : 0;

  const totalSetsCount = activeWorkout
    ? activeWorkout.exercises.reduce((acc, ex) => acc + ex.sets.length, 0)
    : 0;

  return (
    <>
      {/* Floating Active Mini-Bar (if workout in progress or rest timer running) */}
      {(activeWorkout || isTimerRunning) && (
        <div className="fixed bottom-18 left-0 right-0 z-30 px-3 max-w-lg mx-auto pointer-events-none">
          <div className="flex items-center gap-2 pointer-events-auto">
            {/* Active Workout Banner */}
            {activeWorkout && (
              <button
                onClick={() => setIsWorkoutModalOpen(true)}
                className="flex-1 bg-gradient-to-r from-neutral-900 via-neutral-900 to-cyan-950/60 border border-cyan-500/40 rounded-xl p-2.5 shadow-lg shadow-cyan-950/40 flex items-center justify-between transition-all active:scale-[0.99] group backdrop-blur-md"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-400 shrink-0">
                    <Play className="w-4 h-4 fill-cyan-400" />
                  </div>
                  <div className="text-left truncate">
                    <div className="text-xs font-semibold text-white truncate flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
                      {activeWorkout.name}
                    </div>
                    <div className="text-[11px] text-slate-400 flex items-center gap-1">
                      <span>{formatSeconds(activeWorkout.elapsedSeconds)}</span>
                      <span>·</span>
                      <span className="text-cyan-400 font-mono">
                        {completedSetsCount}/{totalSetsCount} sets
                      </span>
                    </div>
                  </div>
                </div>

                <div className="px-2.5 py-1 text-xs font-semibold bg-cyan-500 text-neutral-950 rounded-lg group-hover:bg-cyan-400 transition-colors whitespace-nowrap shadow-sm shadow-cyan-500/30">
                  Resume
                </div>
              </button>
            )}

            {/* Rest Timer Floating Pill with Instant Stop */}
            {isTimerRunning && (
              <div className="bg-neutral-900 border border-cyan-500/50 rounded-xl px-2.5 py-1.5 flex items-center gap-1.5 shadow-lg shadow-cyan-950/30 text-cyan-400 backdrop-blur-md shrink-0">
                <button
                  onClick={() => setIsTimerModalOpen(true)}
                  className="flex items-center gap-1.5 hover:text-white transition-colors"
                  title="Open Rest Timer"
                >
                  <Clock className="w-3.5 h-3.5 animate-spin text-cyan-400" style={{ animationDuration: '6s' }} />
                  <span className="text-xs font-mono font-bold tracking-wider">
                    {formatSeconds(timerSecondsLeft)}
                  </span>
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    stopRestTimer();
                  }}
                  className="p-1 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors ml-0.5"
                  title="Stop Rest Timer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Main Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#0d0f14]/95 backdrop-blur-lg border-t border-neutral-800/80 pb-safe">
        <div className="max-w-lg mx-auto grid grid-cols-5 h-16 items-center px-1">
          <button
            onClick={() => onSelectTab('home')}
            className={`flex flex-col items-center justify-center h-full transition-colors group relative ${
              currentTab === 'home' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {currentTab === 'home' && (
              <span className="absolute top-0 w-8 h-0.5 bg-cyan-400 rounded-full glow-cyan-sm" />
            )}
            <Home className="w-5 h-5 mb-1 transition-transform group-active:scale-90" />
            <span className="text-[10px] font-semibold tracking-tight">Home</span>
          </button>

          <button
            onClick={() => onSelectTab('workouts')}
            className={`flex flex-col items-center justify-center h-full transition-colors group relative ${
              currentTab === 'workouts' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {currentTab === 'workouts' && (
              <span className="absolute top-0 w-8 h-0.5 bg-cyan-400 rounded-full glow-cyan-sm" />
            )}
            <Flame className="w-5 h-5 mb-1 transition-transform group-active:scale-90" />
            <span className="text-[10px] font-semibold tracking-tight">Workouts</span>
          </button>

          <button
            onClick={() => onSelectTab('exercises')}
            className={`flex flex-col items-center justify-center h-full transition-colors group relative ${
              currentTab === 'exercises' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {currentTab === 'exercises' && (
              <span className="absolute top-0 w-8 h-0.5 bg-cyan-400 rounded-full glow-cyan-sm" />
            )}
            <BookOpen className="w-5 h-5 mb-1 transition-transform group-active:scale-90" />
            <span className="text-[10px] font-semibold tracking-tight">Exercises</span>
          </button>

          <button
            onClick={() => onSelectTab('progress')}
            className={`flex flex-col items-center justify-center h-full transition-colors group relative ${
              currentTab === 'progress' || currentTab === 'skills'
                ? 'text-cyan-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {(currentTab === 'progress' || currentTab === 'skills') && (
              <span className="absolute top-0 w-8 h-0.5 bg-cyan-400 rounded-full glow-cyan-sm" />
            )}
            <TrendingUp className="w-5 h-5 mb-1 transition-transform group-active:scale-90" />
            <span className="text-[10px] font-semibold tracking-tight">Progress</span>
          </button>

          <button
            onClick={() => onSelectTab('profile')}
            className={`flex flex-col items-center justify-center h-full transition-colors group relative ${
              currentTab === 'profile' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {currentTab === 'profile' && (
              <span className="absolute top-0 w-8 h-0.5 bg-cyan-400 rounded-full glow-cyan-sm" />
            )}
            {user.profileImage ? (
              <div
                className={`w-5 h-5 rounded-full overflow-hidden border mb-1 transition-transform group-active:scale-90 ${
                  currentTab === 'profile'
                    ? 'border-cyan-400 ring-1 ring-cyan-400/60'
                    : 'border-neutral-700'
                }`}
              >
                <img src={user.profileImage} alt="" className="w-full h-full object-cover" />
              </div>
            ) : (
              <User className="w-5 h-5 mb-1 transition-transform group-active:scale-90" />
            )}
            <span className="text-[10px] font-semibold tracking-tight">Profile</span>
          </button>
        </div>
      </nav>
    </>
  );
};
