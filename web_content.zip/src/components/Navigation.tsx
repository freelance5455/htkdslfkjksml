import React from 'react';
import { Home, Play, Calendar, BarChart2, User } from 'lucide-react';

export type NavTab = 'home' | 'run' | 'plan' | 'progress' | 'profile';

interface NavigationProps {
  activeTab: NavTab;
  onChangeTab: (tab: NavTab) => void;
  isRunningActive?: boolean;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onChangeTab,
  isRunningActive = false,
}) => {
  const tabs: {
    id: NavTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    isRunCenter?: boolean;
  }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'run', label: 'Run', icon: Play, isRunCenter: true },
    { id: 'plan', label: 'Plan', icon: Calendar },
    { id: 'progress', label: 'Progress', icon: BarChart2 },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#0a0a0a]/95 backdrop-blur-lg border-t border-zinc-800/80 px-2 py-1.5 pb-safe">
      <div className="max-w-md mx-auto flex items-center justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          if (tab.isRunCenter) {
            return (
              <button
                key={tab.id}
                onClick={() => onChangeTab(tab.id)}
                className="relative -top-4 flex flex-col items-center group focus:outline-none"
              >
                <div
                  className={`w-14 h-14 rounded-full flex items-center justify-center border-2 transition-all shadow-lg active:scale-95 ${
                    isActive || isRunningActive
                      ? 'bg-[#00FF66] border-white text-black glow-neon scale-105'
                      : 'bg-zinc-900 border-[#00FF66]/60 text-[#00FF66] hover:border-[#00FF66]'
                  }`}
                >
                  <Play className={`w-6 h-6 ml-0.5 fill-current ${isRunningActive ? 'animate-pulse' : ''}`} />
                </div>
                <span
                  className={`text-[10px] font-bold mt-1 tracking-wider uppercase ${
                    isActive ? 'text-[#00FF66]' : 'text-zinc-400'
                  }`}
                >
                  {isRunningActive ? 'Tracking' : 'Run'}
                </span>
              </button>
            );
          }

          return (
            <button
              key={tab.id}
              onClick={() => onChangeTab(tab.id)}
              className={`flex-1 py-1 flex flex-col items-center gap-1 transition-colors ${
                isActive ? 'text-[#00FF66]' : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
                {isActive && (
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-[#00FF66] rounded-full" />
                )}
              </div>
              <span className={`text-[10px] font-medium tracking-tight ${isActive ? 'font-bold' : ''}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
