import React from 'react';
import { UserProfile } from '../types';
import { Timer, CheckSquare, ShoppingBag, Crown, Palette, Bot } from 'lucide-react';

export type ActiveTab = 'focus' | 'tasks' | 'market' | 'founder' | 'equipment' | 'ai_coach';

interface NavigationProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  user: UserProfile;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onTabChange,
  user,
}) => {
  const isFounder = user.role === 'founder' || user.email.toLowerCase() === 'am282773159@gmail.com';

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/90 backdrop-blur-xl border-t border-slate-800/80 px-2 py-1.5 pb-safe">
      <div className="max-w-md sm:max-w-xl mx-auto flex items-center justify-around gap-1">
        
        {/* 1. Pomodoro Focus */}
        <button
          onClick={() => onTabChange('focus')}
          className={`flex-1 py-1.5 px-1 rounded-2xl flex flex-col items-center gap-1 transition-all duration-200 cursor-pointer ${
            activeTab === 'focus'
              ? 'text-indigo-400 bg-indigo-500/10 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Timer className={`w-5 h-5 ${activeTab === 'focus' ? 'text-indigo-400 stroke-[2.5]' : ''}`} />
          <span className="text-[10px] sm:text-xs">التركيز</span>
        </button>

        {/* 2. Tasks */}
        <button
          onClick={() => onTabChange('tasks')}
          className={`flex-1 py-1.5 px-1 rounded-2xl flex flex-col items-center gap-1 transition-all duration-200 cursor-pointer ${
            activeTab === 'tasks'
              ? 'text-indigo-400 bg-indigo-500/10 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <CheckSquare className={`w-5 h-5 ${activeTab === 'tasks' ? 'text-indigo-400 stroke-[2.5]' : ''}`} />
          <span className="text-[10px] sm:text-xs">المهام</span>
        </button>

        {/* 3. Market */}
        <button
          onClick={() => onTabChange('market')}
          className={`flex-1 py-1.5 px-1 rounded-2xl flex flex-col items-center gap-1 transition-all duration-200 cursor-pointer ${
            activeTab === 'market'
              ? 'text-amber-400 bg-amber-500/10 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <ShoppingBag className={`w-5 h-5 ${activeTab === 'market' ? 'text-amber-400 stroke-[2.5]' : ''}`} />
          <span className="text-[10px] sm:text-xs">المتجر</span>
        </button>

        {/* 4. Founder's Corner - EXACTLY NEXT TO MARKET */}
        {isFounder && (
          <button
            onClick={() => onTabChange('founder')}
            className={`flex-1 py-1.5 px-1 rounded-2xl flex flex-col items-center gap-1 transition-all duration-200 cursor-pointer relative ${
              activeTab === 'founder'
                ? 'text-amber-300 bg-gradient-to-b from-amber-500/25 to-yellow-600/15 border border-amber-500/40 font-black shadow-md shadow-amber-500/20'
                : 'text-amber-400/80 hover:text-amber-300 bg-amber-950/20'
            }`}
          >
            <div className="relative">
              <Crown className="w-5 h-5 text-amber-400 animate-bounce" />
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
            </div>
            <span className="text-[10px] sm:text-xs font-black tracking-tight text-amber-300 truncate max-w-[65px]">
              المؤسس 👑
            </span>
          </button>
        )}

        {/* 5. Equipment Center */}
        <button
          onClick={() => onTabChange('equipment')}
          className={`flex-1 py-1.5 px-1 rounded-2xl flex flex-col items-center gap-1 transition-all duration-200 cursor-pointer ${
            activeTab === 'equipment'
              ? 'text-indigo-400 bg-indigo-500/10 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Palette className={`w-5 h-5 ${activeTab === 'equipment' ? 'text-indigo-400 stroke-[2.5]' : ''}`} />
          <span className="text-[10px] sm:text-xs">المقتنيات</span>
        </button>

        {/* 6. AI Productivity Coach */}
        <button
          onClick={() => onTabChange('ai_coach')}
          className={`flex-1 py-1.5 px-1 rounded-2xl flex flex-col items-center gap-1 transition-all duration-200 cursor-pointer ${
            activeTab === 'ai_coach'
              ? 'text-cyan-400 bg-cyan-500/10 font-bold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Bot className={`w-5 h-5 ${activeTab === 'ai_coach' ? 'text-cyan-400 stroke-[2.5]' : ''}`} />
          <span className="text-[10px] sm:text-xs">المساعد</span>
        </button>

      </div>
    </nav>
  );
};
