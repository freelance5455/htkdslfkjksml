import React from 'react';
import { NavTab } from '../types';
import { Home, MessageSquare, Box, Settings } from 'lucide-react';

interface NavigationProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
}

interface TabItem {
  id: NavTab;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const TABS: TabItem[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'chat', label: 'Chat', icon: MessageSquare },
  { id: 'character', label: 'Character', icon: Box },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export const Navigation: React.FC<NavigationProps> = ({ activeTab, onTabChange }) => {
  return (
    <nav className="shrink-0 bg-[#0c0c18]/95 border-t border-[#ff2d78]/25 backdrop-blur-xl px-2 py-1.5 z-40 select-none pb-[max(0.375rem,env(safe-area-inset-bottom))] shadow-[0_-8px_20px_rgba(0,0,0,0.5)]">
      <div className="max-w-md mx-auto grid grid-cols-4 gap-1">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`relative flex flex-col items-center justify-center py-2 px-1 rounded-xl transition-all duration-200 active:scale-95 ${
                isActive
                  ? 'text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {/* Active Glow Pill Indicator */}
              {isActive && (
                <div className="absolute inset-0 bg-gradient-to-t from-[#ff2d78]/20 via-[#9333ea]/10 to-transparent rounded-xl border border-[#ff2d78]/40 shadow-[0_0_12px_rgba(255,45,120,0.25)] pointer-events-none" />
              )}

              <div className="relative z-10 flex flex-col items-center gap-1">
                <Icon
                  className={`w-5 h-5 transition-transform duration-200 ${
                    isActive ? 'scale-110 text-[#ff2d78]' : 'text-slate-400'
                  }`}
                />
                <span
                  className={`text-[11px] font-cyber tracking-wider font-semibold uppercase ${
                    isActive ? 'text-white' : 'text-slate-400'
                  }`}
                >
                  {tab.label}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
