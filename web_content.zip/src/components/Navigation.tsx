import React from "react";
import { MessageSquare, Mic, Image, Video, Sparkles, Shield } from "lucide-react";
import { TabType } from "../types";

interface NavigationProps {
  currentTab: TabType;
  onTabChange: (tab: TabType) => void;
  voiceListening?: boolean;
}

export const Navigation: React.FC<NavigationProps> = ({
  currentTab,
  onTabChange,
  voiceListening = false,
}) => {
  const tabs: { id: TabType; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: "chat", label: "স্মার্ট চ্যাট", icon: MessageSquare },
    { id: "voice", label: "ভয়েস (Hey Ranabir)", icon: Mic },
    { id: "image", label: "ছবি তৈরি", icon: Image },
    { id: "editor", label: "ফটো/রিল এডিট", icon: Video },
    { id: "content", label: "কন্টেন্ট স্টুডিও", icon: Sparkles },
    { id: "memory", label: "মেমরি ও গোপনীয়তা", icon: Shield },
  ];

  return (
    <nav className="fixed bottom-3 inset-x-0 z-50 px-3 sm:px-4 pointer-events-none">
      <div className="max-w-xl mx-auto pointer-events-auto">
        <div className="glass-panel-elevated rounded-2xl p-1.5 flex items-center justify-around gap-1 border border-indigo-500/25 shadow-2xl shadow-indigo-950/60">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = currentTab === tab.id;
            const isVoiceTab = tab.id === "voice";

            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`relative flex flex-col items-center justify-center py-2 px-2 sm:px-3 rounded-xl transition-all duration-200 group flex-1 ${
                  isActive
                    ? "bg-indigo-600/90 text-white shadow-lg shadow-indigo-600/30 scale-[1.02]"
                    : "text-slate-400 hover:text-slate-200 hover:bg-white/5"
                }`}
              >
                {/* Voice special listening pulse */}
                {isVoiceTab && voiceListening && (
                  <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
                  </span>
                )}

                <Icon className={`w-5 h-5 transition-transform duration-200 ${isActive ? "scale-110" : "group-hover:scale-105"}`} />
                <span className="text-[10px] font-semibold mt-1 tracking-tight truncate max-w-[65px] sm:max-w-none text-center">
                  {tab.id === "chat" ? "চ্যাট" : tab.id === "voice" ? "ভয়েস" : tab.id === "image" ? "ছবি" : tab.id === "editor" ? "এডিট" : tab.id === "content" ? "কন্টেন্ট" : "মেমরি"}
                </span>

                {isActive && (
                  <span className="absolute -bottom-1 w-6 h-0.5 bg-cyan-400 rounded-full"></span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};
