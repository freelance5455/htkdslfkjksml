import React from 'react';
import { Plus, Play, Heart, ListMusic, Music, Sparkles } from 'lucide-react';
import { Song, Playlist } from '../types';
import { ArtworkImage } from './ArtworkImage';

interface HomeScreenProps {
  songs: Song[];
  playlists: Playlist[];
  onPlaySong: (song: Song, contextList: Song[]) => void;
  onAddSongsClick: () => void;
  onSelectPlaylist: (playlist: Playlist) => void;
  onNavigateToLibrary: () => void;
  onNavigateToPlaylists: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  songs,
  playlists,
  onPlaySong,
  onAddSongsClick,
  onSelectPlaylist,
  onNavigateToLibrary,
  onNavigateToPlaylists,
}) => {
  const favorites = songs.filter((s) => s.isFavorite);
  const recentlyPlayed = [...songs]
    .filter((s) => s.playCount > 0)
    .sort((a, b) => b.playCount - a.playCount)
    .slice(0, 8);
  const recentlyAdded = [...songs]
    .sort((a, b) => b.dateAdded - a.dateAdded)
    .slice(0, 6);

  return (
    <div className="space-y-6 pb-28 pt-2">
      {/* Top Welcome & Add Songs CTA */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-100">
            Music Player
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Offline & Private Audio Library
          </p>
        </div>

        <button
          onClick={onAddSongsClick}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-slate-950 font-semibold text-xs transition-all shadow-md shadow-emerald-500/10"
        >
          <Plus size={16} />
          <span>Add Songs</span>
        </button>
      </div>

      {/* Hero Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-950/80 via-[#12181F] to-[#12181F] border border-emerald-500/20 p-5">
        <div className="relative z-10 max-w-sm">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-semibold tracking-wide bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 mb-2">
            <Sparkles size={12} />
            <span>100% OFFLINE PLAYBACK</span>
          </div>
          <h3 className="text-lg font-bold text-slate-100">
            Your Personal Audio Vault
          </h3>
          <p className="text-xs text-slate-400 mt-1 leading-relaxed">
            Import local MP3, FLAC, WAV, and AAC tracks. Zero cloud tracking, rich metadata editing, and gapless queue management.
          </p>
          <div className="flex items-center gap-4 mt-4">
            <button
              onClick={onAddSongsClick}
              className="px-3.5 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-all"
            >
              Import Tracks
            </button>
            <button
              onClick={onNavigateToLibrary}
              className="text-xs font-semibold text-emerald-400 hover:underline"
            >
              Browse Library ({songs.length})
            </button>
          </div>
        </div>
      </div>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-3 gap-3">
        <div
          onClick={onNavigateToLibrary}
          className="p-3.5 rounded-xl bg-[#12181F] border border-slate-800/80 hover:border-emerald-500/40 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-slate-400">
            <Music size={16} className="text-emerald-400" />
            <span className="text-xs text-slate-500">Tracks</span>
          </div>
          <p className="text-xl font-bold text-slate-100 mt-2">{songs.length}</p>
        </div>

        <div
          onClick={onNavigateToLibrary}
          className="p-3.5 rounded-xl bg-[#12181F] border border-slate-800/80 hover:border-emerald-500/40 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-slate-400">
            <Heart size={16} className="text-rose-400 fill-rose-500/20" />
            <span className="text-xs text-slate-500">Favorites</span>
          </div>
          <p className="text-xl font-bold text-slate-100 mt-2">{favorites.length}</p>
        </div>

        <div
          onClick={onNavigateToPlaylists}
          className="p-3.5 rounded-xl bg-[#12181F] border border-slate-800/80 hover:border-emerald-500/40 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-slate-400">
            <ListMusic size={16} className="text-teal-400" />
            <span className="text-xs text-slate-500">Playlists</span>
          </div>
          <p className="text-xl font-bold text-slate-100 mt-2">{playlists.length}</p>
        </div>
      </div>

      {/* Recently Played */}
      {recentlyPlayed.length > 0 && (
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-100">Most Played</h2>
            <button
              onClick={onNavigateToLibrary}
              className="text-xs font-semibold text-emerald-400 hover:underline"
            >
              See all
            </button>
          </div>

          <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-none -mx-4 px-4 sm:mx-0 sm:px-0">
            {recentlyPlayed.map((song) => (
              <div
                key={song.id}
                onClick={() => onPlaySong(song, recentlyPlayed)}
                className="group relative flex-shrink-0 w-36 bg-[#12181F] p-2.5 rounded-xl border border-slate-800 hover:border-emerald-500/30 cursor-pointer transition-all"
              >
                <div className="relative w-full aspect-square rounded-lg overflow-hidden">
                  <ArtworkImage
                    artworkUrl={song.artworkUrl}
                    alt={song.title}
                    className="w-full h-full object-cover"
                    iconSize={32}
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                    <div className="w-10 h-10 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center shadow-lg">
                      <Play size={18} fill="currentColor" className="ml-0.5" />
                    </div>
                  </div>
                </div>
                <h4 className="text-xs font-semibold text-slate-100 truncate mt-2">
                  {song.title}
                </h4>
                <p className="text-[11px] text-slate-400 truncate mt-0.5">
                  {song.artist}
                </p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Favorites Section */}
      {favorites.length > 0 && (
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-100">Favorites</h2>
            <button
              onClick={onNavigateToLibrary}
              className="text-xs font-semibold text-emerald-400 hover:underline"
            >
              View all ({favorites.length})
            </button>
          </div>

          <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-none -mx-4 px-4 sm:mx-0 sm:px-0">
            {favorites.map((song) => (
              <div
                key={song.id}
                onClick={() => onPlaySong(song, favorites)}
                className="group relative flex-shrink-0 w-36 bg-[#12181F] p-2.5 rounded-xl border border-slate-800 hover:border-emerald-500/30 cursor-pointer transition-all"
              >
                <div className="relative w-full aspect-square rounded-lg overflow-hidden">
                  <ArtworkImage
                    artworkUrl={song.artworkUrl}
                    alt={song.title}
                    className="w-full h-full object-cover"
                    iconSize={32}
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                    <div className="w-10 h-10 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center shadow-lg">
                      <Play size={18} fill="currentColor" className="ml-0.5" />
                    </div>
                  </div>
                </div>
                <h4 className="text-xs font-semibold text-slate-100 truncate mt-2">
                  {song.title}
                </h4>
                <p className="text-[11px] text-slate-400 truncate mt-0.5">
                  {song.artist}
                </p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Recently Added List */}
      {recentlyAdded.length > 0 && (
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-100">Recently Added</h2>
            <button
              onClick={onNavigateToLibrary}
              className="text-xs font-semibold text-emerald-400 hover:underline"
            >
              Library
            </button>
          </div>

          <div className="space-y-1.5">
            {recentlyAdded.map((song) => (
              <div
                key={song.id}
                onClick={() => onPlaySong(song, recentlyAdded)}
                className="flex items-center justify-between p-2.5 rounded-xl bg-[#12181F] hover:bg-[#1A232C] border border-slate-800/80 cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <ArtworkImage
                    artworkUrl={song.artworkUrl}
                    alt={song.title}
                    className="w-10 h-10 rounded-lg"
                    iconSize={18}
                  />
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-slate-200 truncate">
                      {song.title}
                    </p>
                    <p className="text-xs text-slate-400 truncate">
                      {song.artist} • {song.album || 'Single'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500 font-mono">
                    {Math.floor(song.duration / 60)}:
                    {(song.duration % 60).toString().padStart(2, '0')}
                  </span>
                  <div className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-emerald-400">
                    <Play size={16} fill="currentColor" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
