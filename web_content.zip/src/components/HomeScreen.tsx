import React, { useState, useMemo } from 'react';
import { JobCategory, JobPosting, JobSector } from '../types/job';
import { JobCard } from './JobCard';
import {
  Search,
  MapPin,
  Sparkles,
  AlertTriangle,
  Building2,
  Briefcase,
  ChevronRight,
  Filter,
  X,
  Compass,
  GraduationCap,
  Flame,
  CheckCircle2,
  ShieldCheck,
  Calendar,
  Clock,
  Star,
  TrendingUp,
  ArrowRight
} from 'lucide-react';

interface HomeScreenProps {
  jobs: JobPosting[];
  savedJobIds: string[];
  onToggleSave: (jobId: string) => void;
  onOpenDetail: (job: JobPosting) => void;
  onReportJob?: (job: JobPosting) => void;
  onNavigateToDrillDown: (state?: string, district?: string, category?: JobCategory) => void;
  onNavigateToNearMe: () => void;
  onOpenAlerts?: () => void;
  likedJobIds?: string[];
  onToggleLike?: (jobId: string) => void;
  onShareJob?: (job: JobPosting) => void;
  isJobsLoading?: boolean;
  hasRealJobs?: boolean;
  isDemoPreviewActive?: boolean;
  onEnableDemoPreview?: () => void;
  onExitDemoPreview?: () => void;
  onNavigateToAdmin?: () => void;
  isAdmin?: boolean;
  theme?: 'dark' | 'light';
}

// All 12 requested categories
const ALL_CATEGORIES: JobCategory[] = [
  'All',
  'Government Jobs',
  'Private Jobs',
  'Latest Jobs',
  'Jobs Near Me',
  'ITI Jobs',
  'Diploma Jobs',
  'Graduate Jobs',
  'Railway Jobs',
  'Banking Jobs',
  'Defence Jobs',
  'Apprenticeship Jobs'
];

const QUALIFICATION_QUICK_FILTERS = [
  'All Quals',
  '10th Pass',
  '12th Pass',
  'ITI',
  'Diploma',
  'Graduate',
  'Engineering'
];

type DiscoverySection = 'all' | 'trending' | 'new' | 'closingSoon' | 'mostSaved';

export const HomeScreen: React.FC<HomeScreenProps> = ({
  jobs,
  savedJobIds,
  onToggleSave,
  onOpenDetail,
  onReportJob,
  onNavigateToDrillDown,
  onNavigateToNearMe,
  onOpenAlerts,
  likedJobIds = [],
  onToggleLike,
  onShareJob,
  isJobsLoading = false,
  hasRealJobs = false,
  isDemoPreviewActive = false,
  onEnableDemoPreview,
  onExitDemoPreview,
  onNavigateToAdmin,
  isAdmin = false,
  theme = 'dark'
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<JobCategory>('All');
  const [selectedSector, setSelectedSector] = useState<'All' | JobSector>('All');
  const [selectedQual, setSelectedQual] = useState('All Quals');
  const [onlyUrgent, setOnlyUrgent] = useState(false);
  const [includeExpired, setIncludeExpired] = useState(false);
  const [activeSection, setActiveSection] = useState<DiscoverySection>('all');

  // Today's date for expiration checking
  const today = useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d;
  }, []);

  // Helper to check if job is expired
  const checkIsExpired = (job: JobPosting): boolean => {
    if (job.status === 'EXPIRED') return true;
    const closingStr = job.closingDate || job.lastDate || job.expiryDate;
    if (!closingStr) return false;
    const deadline = new Date(closingStr);
    return !isNaN(deadline.getTime()) && deadline.getTime() < today.getTime();
  };

  // Helper to get days remaining
  const getDaysRemaining = (job: JobPosting): number => {
    const closingStr = job.closingDate || job.lastDate || job.expiryDate;
    if (!closingStr) return 999;
    const deadline = new Date(closingStr);
    if (isNaN(deadline.getTime())) return 999;
    return Math.ceil((deadline.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  };

  // Base active jobs: only PUBLISHED or VERIFIED, non-expired (unless includeExpired is true)
  const activeJobs = useMemo(() => {
    return jobs.filter((job) => {
      if (job.status && !['PUBLISHED', 'VERIFIED'].includes(job.status)) {
        return false;
      }
      const isExpired = checkIsExpired(job);
      if (!includeExpired && isExpired) return false;
      return true;
    });
  }, [jobs, includeExpired, today]);

  // 1. 🔥 Trending Jobs (engagement: views * 1 + saves * 3 + likes * 2 + applications * 4)
  const trendingJobs = useMemo(() => {
    return [...activeJobs]
      .filter((j) => !checkIsExpired(j))
      .sort((a, b) => {
        const scoreA =
          (a.viewsCount || 0) * 1 +
          (a.savesCount || 0) * 3 +
          (a.likesCount || 0) * 2 +
          (a.applicationsCount || 0) * 4;
        const scoreB =
          (b.viewsCount || 0) * 1 +
          (b.savesCount || 0) * 3 +
          (b.likesCount || 0) * 2 +
          (b.applicationsCount || 0) * 4;
        return scoreB - scoreA;
      });
  }, [activeJobs]);

  // 2. 🆕 New Jobs (recently published/posted)
  const newJobs = useMemo(() => {
    return [...activeJobs]
      .filter((j) => !checkIsExpired(j))
      .sort((a, b) => {
        const dateA = new Date(a.postDate || a.createdAt || '').getTime() || 0;
        const dateB = new Date(b.postDate || b.createdAt || '').getTime() || 0;
        return dateB - dateA;
      });
  }, [activeJobs]);

  // 3. ⏳ Closing Soon (application deadline is approaching, e.g. <= 10 days and >= 0)
  const closingSoonJobs = useMemo(() => {
    return [...activeJobs]
      .filter((j) => {
        if (checkIsExpired(j)) return false;
        const days = getDaysRemaining(j);
        return days >= 0 && days <= 14;
      })
      .sort((a, b) => getDaysRemaining(a) - getDaysRemaining(b));
  }, [activeJobs]);

  // 4. ⭐ Most Saved (highest number of saves)
  const mostSavedJobs = useMemo(() => {
    return [...activeJobs]
      .filter((j) => !checkIsExpired(j))
      .sort((a, b) => (b.savesCount || 0) - (a.savesCount || 0));
  }, [activeJobs]);

  // Standard filter logic for search & pills
  const filteredJobs = useMemo(() => {
    let list = activeJobs;

    // Filter by active discovery section if selected
    if (activeSection === 'trending') list = trendingJobs;
    else if (activeSection === 'new') list = newJobs;
    else if (activeSection === 'closingSoon') list = closingSoonJobs;
    else if (activeSection === 'mostSaved') list = mostSavedJobs;

    return list.filter((job) => {
      // Urgent filter (< 7 days remaining)
      if (onlyUrgent) {
        const diffDays = getDaysRemaining(job);
        const isUrgent = job.isUrgent || (diffDays >= 0 && diffDays <= 7);
        if (!isUrgent) return false;
      }

      // Search query
      const query = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !query ||
        job.title.toLowerCase().includes(query) ||
        job.organization.toLowerCase().includes(query) ||
        job.qualification.toLowerCase().includes(query) ||
        job.state.toLowerCase().includes(query) ||
        job.district.toLowerCase().includes(query) ||
        job.category.some((c) => c.toLowerCase().includes(query));

      // Category matching
      const matchesCategory =
        selectedCategory === 'All'
          ? true
          : selectedCategory === 'Latest Jobs'
          ? job.isLatest
          : job.category.includes(selectedCategory);

      // Sector matching
      const matchesSector =
        selectedSector === 'All' ? true : job.sector === selectedSector;

      // Qualification quick filter
      const matchesQual =
        selectedQual === 'All Quals'
          ? true
          : job.qualification.toLowerCase().includes(selectedQual.toLowerCase());

      return matchesSearch && matchesCategory && matchesSector && matchesQual;
    });
  }, [
    activeJobs,
    activeSection,
    trendingJobs,
    newJobs,
    closingSoonJobs,
    mostSavedJobs,
    searchQuery,
    selectedCategory,
    selectedSector,
    selectedQual,
    onlyUrgent
  ]);

  // Total vacancies calculation
  const totalVacancies = useMemo(() => {
    return filteredJobs.reduce((acc, curr) => acc + (curr.vacancies || 0), 0);
  }, [filteredJobs]);

  const handleCategoryClick = (category: JobCategory) => {
    if (category === 'Jobs Near Me') {
      onNavigateToNearMe();
    } else {
      setSelectedCategory(category);
    }
  };

  const hasDemoEntries = jobs.some((j) => j.demoDataBadge === true);

  // If user is searching or filtering, show the filtered list directly
  const isCustomFiltering =
    searchQuery.trim() !== '' ||
    selectedCategory !== 'All' ||
    selectedSector !== 'All' ||
    selectedQual !== 'All Quals' ||
    onlyUrgent ||
    activeSection !== 'all';

  return (
    <div className={`flex-1 flex flex-col p-3 sm:p-5 space-y-4 transition-colors ${
      theme === 'light' ? 'bg-slate-50 text-slate-900' : 'bg-slate-950 text-slate-100'
    }`}>
      {/* 1. SEARCH JOBS */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          id="input-search-jobs"
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search Jobs (e.g., RRB ALP, SBI PO, DRDO, ITI, Defence)..."
          className={`w-full pl-10 pr-10 py-3 border rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 shadow-inner transition-colors ${
            theme === 'light'
              ? 'bg-white border-slate-200 text-slate-900 placeholder-slate-400'
              : 'bg-slate-900 border-slate-800 text-white placeholder-slate-500'
          }`}
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className={`absolute right-3.5 top-1/2 -translate-y-1/2 transition-colors ${
              theme === 'light' ? 'text-slate-400 hover:text-slate-700' : 'text-slate-400 hover:text-white'
            }`}
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* 3. HOME PAGE JOB DISCOVERY SECTION BAR (Trending, New, Closing Soon, Most Saved) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className={`text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 ${
            theme === 'light' ? 'text-slate-600' : 'text-slate-400'
          }`}>
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Discover Top Vacancies</span>
          </span>
          {activeSection !== 'all' && (
            <button
              onClick={() => setActiveSection('all')}
              className={`text-[11px] font-semibold flex items-center gap-1 transition-colors ${
                theme === 'light' ? 'text-indigo-600 hover:text-indigo-700' : 'text-indigo-400 hover:text-indigo-300'
              }`}
            >
              <span>Back to All Discovery</span>
              <X className="w-3 h-3" />
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {/* 🔥 Trending Jobs Button */}
          <button
            id="tab-discovery-trending"
            onClick={() => setActiveSection(activeSection === 'trending' ? 'all' : 'trending')}
            className={`p-3 rounded-2xl border text-left transition-all flex flex-col justify-between ${
              activeSection === 'trending'
                ? theme === 'light'
                  ? 'bg-rose-50 border-rose-400 ring-2 ring-rose-200 shadow-sm'
                  : 'bg-gradient-to-br from-rose-950/60 to-slate-900 border-rose-500/60 ring-2 ring-rose-500/30'
                : theme === 'light'
                ? 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50 shadow-sm'
                : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-base">🔥</span>
              <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${
                theme === 'light'
                  ? 'bg-rose-100 text-rose-700 border-rose-200'
                  : 'bg-rose-500/20 text-rose-300 border-rose-500/30'
              }`}>
                {trendingJobs.length}
              </span>
            </div>
            <div className="mt-2">
              <div className={`text-xs font-bold ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                Trending Jobs
              </div>
              <p className={`text-[10px] ${theme === 'light' ? 'text-slate-500' : 'text-slate-400'}`}>
                High engagement & views
              </p>
            </div>
          </button>

          {/* 🆕 New Jobs Button */}
          <button
            id="tab-discovery-new"
            onClick={() => setActiveSection(activeSection === 'new' ? 'all' : 'new')}
            className={`p-3 rounded-2xl border text-left transition-all flex flex-col justify-between ${
              activeSection === 'new'
                ? theme === 'light'
                  ? 'bg-indigo-50 border-indigo-400 ring-2 ring-indigo-200 shadow-sm'
                  : 'bg-gradient-to-br from-indigo-950/60 to-slate-900 border-indigo-500/60 ring-2 ring-indigo-500/30'
                : theme === 'light'
                ? 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50 shadow-sm'
                : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-base">🆕</span>
              <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${
                theme === 'light'
                  ? 'bg-indigo-100 text-indigo-700 border-indigo-200'
                  : 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
              }`}>
                {newJobs.length}
              </span>
            </div>
            <div className="mt-2">
              <div className={`text-xs font-bold ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                New Jobs
              </div>
              <p className={`text-[10px] ${theme === 'light' ? 'text-slate-500' : 'text-slate-400'}`}>
                Recently published
              </p>
            </div>
          </button>

          {/* ⏳ Closing Soon Button */}
          <button
            id="tab-discovery-closing-soon"
            onClick={() => setActiveSection(activeSection === 'closingSoon' ? 'all' : 'closingSoon')}
            className={`p-3 rounded-2xl border text-left transition-all flex flex-col justify-between ${
              activeSection === 'closingSoon'
                ? theme === 'light'
                  ? 'bg-amber-50 border-amber-400 ring-2 ring-amber-200 shadow-sm'
                  : 'bg-gradient-to-br from-amber-950/60 to-slate-900 border-amber-500/60 ring-2 ring-amber-500/30'
                : theme === 'light'
                ? 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50 shadow-sm'
                : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-base">⏳</span>
              <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${
                theme === 'light'
                  ? 'bg-amber-100 text-amber-700 border-amber-200'
                  : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
              }`}>
                {closingSoonJobs.length}
              </span>
            </div>
            <div className="mt-2">
              <div className={`text-xs font-bold ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                Closing Soon
              </div>
              <p className={`text-[10px] ${theme === 'light' ? 'text-slate-500' : 'text-slate-400'}`}>
                Deadline approaching
              </p>
            </div>
          </button>

          {/* ⭐ Most Saved Button */}
          <button
            id="tab-discovery-most-saved"
            onClick={() => setActiveSection(activeSection === 'mostSaved' ? 'all' : 'mostSaved')}
            className={`p-3 rounded-2xl border text-left transition-all flex flex-col justify-between ${
              activeSection === 'mostSaved'
                ? theme === 'light'
                  ? 'bg-yellow-50 border-yellow-400 ring-2 ring-yellow-200 shadow-sm'
                  : 'bg-gradient-to-br from-yellow-950/60 to-slate-900 border-yellow-500/60 ring-2 ring-yellow-500/30'
                : theme === 'light'
                ? 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50 shadow-sm'
                : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-base">⭐</span>
              <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${
                theme === 'light'
                  ? 'bg-yellow-100 text-yellow-700 border-yellow-200'
                  : 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30'
              }`}>
                {mostSavedJobs.length}
              </span>
            </div>
            <div className="mt-2">
              <div className={`text-xs font-bold ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                Most Saved
              </div>
              <p className={`text-[10px] ${theme === 'light' ? 'text-slate-500' : 'text-slate-400'}`}>
                Popular with aspirants
              </p>
            </div>
          </button>
        </div>
      </div>

      {/* 4. Fast State → District Drill-down Banner */}
      <div
        id="card-state-district-trigger"
        onClick={() => onNavigateToDrillDown()}
        className={`border p-3.5 rounded-2xl cursor-pointer flex items-center justify-between transition-all group active:scale-[0.99] shadow-sm ${
          theme === 'light'
            ? 'bg-gradient-to-r from-indigo-50 via-white to-white border-indigo-200 hover:border-indigo-300'
            : 'bg-gradient-to-r from-indigo-900/60 via-slate-900 to-slate-900 border-indigo-700/40 hover:border-indigo-500/60'
        }`}
      >
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 ${
              theme === 'light'
                ? 'bg-indigo-100 border-indigo-200 text-indigo-600'
                : 'bg-indigo-600/30 border-indigo-500/30 text-indigo-400'
            }`}
          >
            <MapPin className="w-5 h-5" />
          </div>
          <div>
            <span
              className={`text-xs font-bold transition-colors flex items-center gap-1.5 ${
                theme === 'light'
                  ? 'text-slate-900 group-hover:text-indigo-600'
                  : 'text-white group-hover:text-indigo-300'
              }`}
            >
              <span>Select by State → District → Category</span>
              <span
                className={`px-1.5 py-0.2 text-[9px] font-bold rounded border ${
                  theme === 'light'
                    ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                }`}
              >
                All 36 States & UTs
              </span>
            </span>
            <p className={`text-[11px] mt-0.5 ${theme === 'light' ? 'text-slate-500' : 'text-slate-400'}`}>
              Find specific openings localized to your district
            </p>
          </div>
        </div>
        <ChevronRight
          className={`w-5 h-5 transition-transform group-hover:translate-x-1 shrink-0 ${
            theme === 'light' ? 'text-slate-400 group-hover:text-indigo-600' : 'text-slate-500 group-hover:text-indigo-400'
          }`}
        />
      </div>

      {/* 5. ALL 12 REQUIRED JOB CATEGORIES (Horizontal Scrolling Pills) */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h2
            className={`text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 ${
              theme === 'light' ? 'text-slate-600' : 'text-slate-400'
            }`}
          >
            <Briefcase className={`w-3.5 h-3.5 ${theme === 'light' ? 'text-indigo-600' : 'text-indigo-400'}`} />
            <span>Job Categories</span>
          </h2>
          <span className={`text-[11px] ${theme === 'light' ? 'text-slate-500' : 'text-slate-500'}`}>
            {ALL_CATEGORIES.length - 1} Specializations
          </span>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none -mx-1 px-1">
          {ALL_CATEGORIES.map((cat) => {
            const isSelected = selectedCategory === cat;
            const isNearMe = cat === 'Jobs Near Me';

            return (
              <button
                key={cat}
                id={`chip-category-${cat.replace(/\s+/g, '-').toLowerCase()}`}
                onClick={() => handleCategoryClick(cat)}
                className={`whitespace-nowrap px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all shrink-0 ${
                  isSelected
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20 ring-1 ring-indigo-400'
                    : isNearMe
                    ? theme === 'light'
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100 shadow-sm'
                      : 'bg-emerald-950/40 text-emerald-300 border border-emerald-700/50 hover:bg-emerald-900/40'
                    : theme === 'light'
                    ? 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100 hover:text-slate-900 shadow-sm'
                    : 'bg-slate-900 text-slate-300 border border-slate-800 hover:bg-slate-800 hover:text-white'
                }`}
              >
                {isNearMe && <Compass className={`w-3.5 h-3.5 ${theme === 'light' ? 'text-emerald-700' : 'text-emerald-400'}`} />}
                {cat === 'Government Jobs' && <span>🏛️</span>}
                {cat === 'Private Jobs' && <span>🏢</span>}
                {cat === 'Railway Jobs' && <span>🚆</span>}
                {cat === 'Banking Jobs' && <span>🏦</span>}
                {cat === 'Defence Jobs' && <span>⚔️</span>}
                {cat === 'ITI Jobs' && <span>🔧</span>}
                {cat === 'Diploma Jobs' && <span>📐</span>}
                {cat === 'Graduate Jobs' && <span>🎓</span>}
                {cat === 'Apprenticeship Jobs' && <span>⚙️</span>}
                {cat === 'Latest Jobs' && <Sparkles className="w-3 h-3 text-amber-500" />}
                <span>{cat}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 6. Qualification Quick Filter Bar */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
        <GraduationCap className={`w-3.5 h-3.5 shrink-0 mr-1 ${theme === 'light' ? 'text-slate-500' : 'text-slate-400'}`} />
        {QUALIFICATION_QUICK_FILTERS.map((q) => (
          <button
            key={q}
            onClick={() => setSelectedQual(q)}
            className={`whitespace-nowrap px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all shrink-0 ${
              selectedQual === q
                ? 'bg-emerald-600 text-white font-bold shadow-sm'
                : theme === 'light'
                ? 'bg-white border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-100 shadow-sm'
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            {q}
          </button>
        ))}

        {/* Urgent filter pill */}
        <button
          onClick={() => setOnlyUrgent(!onlyUrgent)}
          className={`whitespace-nowrap px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 shrink-0 border transition-all ${
            onlyUrgent
              ? 'bg-rose-600 border-rose-500 text-white shadow-sm'
              : theme === 'light'
              ? 'bg-white border-slate-200 text-slate-600 hover:text-rose-600 hover:bg-rose-50 shadow-sm'
              : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-rose-300'
          }`}
        >
          <Flame className="w-3 h-3 text-rose-500" />
          <span>Urgent (≤7d)</span>
        </button>
      </div>

      {/* 7. Sector Selector & Results Counter */}
      <div
        className={`flex items-center justify-between gap-2 pt-1 border-t flex-wrap ${
          theme === 'light' ? 'border-slate-200' : 'border-slate-800/80'
        }`}
      >
        <div
          className={`flex items-center gap-1 p-1 rounded-xl border text-xs ${
            theme === 'light' ? 'bg-slate-100 border-slate-200' : 'bg-slate-900 border-slate-800'
          }`}
        >
          {(['All', 'Government', 'Private'] as const).map((sector) => (
            <button
              key={sector}
              id={`btn-sector-${sector.toLowerCase()}`}
              onClick={() => setSelectedSector(sector)}
              className={`px-3 py-1 rounded-lg font-medium transition-all ${
                selectedSector === sector
                  ? 'bg-indigo-600 text-white shadow-sm font-semibold'
                  : theme === 'light'
                  ? 'text-slate-600 hover:text-slate-900'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {sector === 'All' ? 'All Sectors' : `${sector} Only`}
            </button>
          ))}
        </div>

        {/* Results Counter & Expired Toggle */}
        <div
          className={`flex items-center gap-2 text-[11px] ${
            theme === 'light' ? 'text-slate-600' : 'text-slate-400'
          }`}
        >
          <label
            className={`flex items-center gap-1.5 cursor-pointer ${
              theme === 'light' ? 'hover:text-slate-900' : 'hover:text-slate-200'
            }`}
          >
            <input
              type="checkbox"
              checked={includeExpired}
              onChange={(e) => setIncludeExpired(e.target.checked)}
              className={`w-3.5 h-3.5 rounded text-indigo-600 ${
                theme === 'light' ? 'bg-white border-slate-300' : 'bg-slate-900 border-slate-700'
              }`}
            />
            <span>Show Expired</span>
          </label>

          <span className={theme === 'light' ? 'text-slate-300' : 'text-slate-600'}>•</span>
          <div>
            <span className={`font-bold ${theme === 'light' ? 'text-slate-900' : 'text-slate-200'}`}>
              {filteredJobs.length}
            </span> Vacancies
            <span className="hidden sm:inline"> • {totalVacancies.toLocaleString('en-IN')} Posts</span>
          </div>
        </div>
      </div>

      {/* 8. JOB SECTIONS or PRODUCTION EMPTY STATE */}
      {jobs.length === 0 ? (
        isJobsLoading ? (
          <div className={`rounded-3xl p-8 sm:p-10 text-center space-y-4 my-4 border shadow-xl transition-colors ${
            theme === 'light' ? 'bg-white border-slate-200' : 'bg-slate-900 border-slate-800'
          }`}>
            <div className="flex justify-center">
              <div className={`p-2 rounded-2xl shadow-lg border ${
                theme === 'light'
                  ? 'bg-white border-slate-200 shadow-slate-200/60'
                  : 'bg-slate-950 border-slate-700/80 shadow-slate-950/80 ring-1 ring-white/10'
              }`}>
                <img
                  src="/india-job-hub-logo.png"
                  alt="India Job Hub Official Logo"
                  className="w-36 h-36 sm:w-44 sm:h-44 object-contain rounded-xl select-none"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
            <div className="flex items-center justify-center gap-2.5 pt-1">
              <div className="w-5 h-5 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
              <p className={`text-xs font-semibold ${theme === 'light' ? 'text-slate-600' : 'text-slate-400'}`}>
                Synchronizing live recruitment databases...
              </p>
            </div>
          </div>
        ) : (
          <div className={`rounded-3xl p-8 sm:p-10 text-center space-y-5 max-w-xl mx-auto my-4 shadow-xl border transition-colors ${
            theme === 'light' ? 'bg-white border-slate-200' : 'bg-slate-900/90 border-slate-800'
          }`}>
            <div className="flex justify-center">
              <div className={`p-2 sm:p-2.5 rounded-2xl shadow-xl border ${
                theme === 'light'
                  ? 'bg-white border-slate-200 shadow-slate-200/70'
                  : 'bg-slate-950 border-slate-700/80 shadow-slate-950/80 ring-1 ring-white/10'
              }`}>
                <img
                  src="/india-job-hub-logo.png"
                  alt="India Job Hub Official Logo"
                  className="w-40 h-40 sm:w-48 sm:h-48 object-contain rounded-xl select-none"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <h2 className={`text-base sm:text-lg font-bold ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                Welcome to India Job Hub
              </h2>
              <p className={`text-xs leading-relaxed max-w-md mx-auto ${theme === 'light' ? 'text-slate-600' : 'text-slate-400'}`}>
                Official government and private job vacancy gazettes are synchronized continuously across Central & State commissions. Check back shortly or configure job alerts to receive immediate notifications.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-3">
              {isAdmin && onNavigateToAdmin && (
                <button
                  id="btn-navigate-admin-publish"
                  onClick={onNavigateToAdmin}
                  className="w-full sm:w-auto px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-sm transition-all flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Publish Vacancies in Admin Panel</span>
                </button>
              )}
            </div>
          </div>
        )
      ) : !isCustomFiltering ? (
        <div className="space-y-6 pt-1">
          {/* Section 1: 🔥 Trending Jobs */}
          {trendingJobs.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-lg">🔥</span>
                  <div>
                    <h2 className={`text-sm font-bold ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                      Trending Jobs
                    </h2>
                    <p className={`text-[11px] ${theme === 'light' ? 'text-slate-500' : 'text-slate-400'}`}>
                      Most engaged by applications & saves
                    </p>
                  </div>
                </div>
                <button
                  id="btn-view-all-trending"
                  onClick={() => setActiveSection('trending')}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-xl flex items-center gap-1 transition-all ${
                    theme === 'light'
                      ? 'text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200'
                      : 'text-indigo-400 hover:text-indigo-300 bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/20'
                  }`}
                >
                  <span>View All ({trendingJobs.length})</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {trendingJobs.slice(0, 4).map((job) => (
                  <JobCard
                    key={job.id}
                    job={job}
                    isSaved={savedJobIds.includes(job.id)}
                    onToggleSave={onToggleSave}
                    onOpenDetail={onOpenDetail}
                    onReportJob={onReportJob}
                    isLiked={likedJobIds.includes(job.id)}
                    onToggleLike={onToggleLike}
                    onShareJob={onShareJob}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Section 2: 🆕 New Jobs */}
          {newJobs.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-lg">🆕</span>
                  <div>
                    <h2 className={`text-sm font-bold ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                      New Jobs
                    </h2>
                    <p className={`text-[11px] ${theme === 'light' ? 'text-slate-500' : 'text-slate-400'}`}>
                      Fresh notifications just released
                    </p>
                  </div>
                </div>
                <button
                  id="btn-view-all-new"
                  onClick={() => setActiveSection('new')}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-xl flex items-center gap-1 transition-all ${
                    theme === 'light'
                      ? 'text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200'
                      : 'text-indigo-400 hover:text-indigo-300 bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/20'
                  }`}
                >
                  <span>View All ({newJobs.length})</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {newJobs.slice(0, 4).map((job) => (
                  <JobCard
                    key={job.id}
                    job={job}
                    isSaved={savedJobIds.includes(job.id)}
                    onToggleSave={onToggleSave}
                    onOpenDetail={onOpenDetail}
                    onReportJob={onReportJob}
                    isLiked={likedJobIds.includes(job.id)}
                    onToggleLike={onToggleLike}
                    onShareJob={onShareJob}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Section 3: ⏳ Closing Soon */}
          {closingSoonJobs.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-lg">⏳</span>
                  <div>
                    <h2 className={`text-sm font-bold ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                      Closing Soon
                    </h2>
                    <p className={`text-[11px] font-medium ${theme === 'light' ? 'text-amber-700' : 'text-amber-400'}`}>
                      Application deadline in &lt;14 days
                    </p>
                  </div>
                </div>
                <button
                  id="btn-view-all-closing-soon"
                  onClick={() => setActiveSection('closingSoon')}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-xl flex items-center gap-1 transition-all ${
                    theme === 'light'
                      ? 'text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-200'
                      : 'text-amber-400 hover:text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20'
                  }`}
                >
                  <span>View All ({closingSoonJobs.length})</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {closingSoonJobs.slice(0, 4).map((job) => (
                  <JobCard
                    key={job.id}
                    job={job}
                    isSaved={savedJobIds.includes(job.id)}
                    onToggleSave={onToggleSave}
                    onOpenDetail={onOpenDetail}
                    onReportJob={onReportJob}
                    isLiked={likedJobIds.includes(job.id)}
                    onToggleLike={onToggleLike}
                    onShareJob={onShareJob}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Section 4: ⭐ Most Saved */}
          {mostSavedJobs.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-lg">⭐</span>
                  <div>
                    <h2 className={`text-sm font-bold ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                      Most Saved
                    </h2>
                    <p className={`text-[11px] ${theme === 'light' ? 'text-slate-500' : 'text-slate-400'}`}>
                      Bookmarked most by job seekers
                    </p>
                  </div>
                </div>
                <button
                  id="btn-view-all-most-saved"
                  onClick={() => setActiveSection('mostSaved')}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-xl flex items-center gap-1 transition-all ${
                    theme === 'light'
                      ? 'text-yellow-800 bg-yellow-50 hover:bg-yellow-100 border border-yellow-300'
                      : 'text-yellow-400 hover:text-yellow-300 bg-yellow-500/10 hover:bg-yellow-500/20 border border-yellow-500/20'
                  }`}
                >
                  <span>View All ({mostSavedJobs.length})</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {mostSavedJobs.slice(0, 4).map((job) => (
                  <JobCard
                    key={job.id}
                    job={job}
                    isSaved={savedJobIds.includes(job.id)}
                    onToggleSave={onToggleSave}
                    onOpenDetail={onOpenDetail}
                    onReportJob={onReportJob}
                    isLiked={likedJobIds.includes(job.id)}
                    onToggleLike={onToggleLike}
                    onShareJob={onShareJob}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Filtered or Specific Section View */
        <div className="space-y-3 pt-1">
          {activeSection !== 'all' && (
            <div
              className={`p-3 rounded-2xl border flex items-center justify-between ${
                theme === 'light'
                  ? 'bg-indigo-50 border-indigo-200 text-indigo-950'
                  : 'bg-indigo-950/40 border-indigo-800/50 text-indigo-200'
              }`}
            >
              <span className={`text-xs font-bold ${theme === 'light' ? 'text-indigo-900' : 'text-indigo-200'}`}>
                Showing all {filteredJobs.length} {
                  activeSection === 'trending' ? '🔥 Trending Jobs' :
                  activeSection === 'new' ? '🆕 New Jobs' :
                  activeSection === 'closingSoon' ? '⏳ Closing Soon Jobs' : '⭐ Most Saved Jobs'
                }
              </span>
              <button
                onClick={() => setActiveSection('all')}
                className={`text-xs font-semibold hover:underline ${
                  theme === 'light' ? 'text-indigo-600' : 'text-indigo-400'
                }`}
              >
                Reset Section
              </button>
            </div>
          )}

          {filteredJobs.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {filteredJobs.map((job) => (
                <JobCard
                  key={job.id}
                  job={job}
                  isSaved={savedJobIds.includes(job.id)}
                  onToggleSave={onToggleSave}
                  onOpenDetail={onOpenDetail}
                  onReportJob={onReportJob}
                  isLiked={likedJobIds.includes(job.id)}
                  onToggleLike={onToggleLike}
                  onShareJob={onShareJob}
                />
              ))}
            </div>
          ) : (
            <div
              className={`border rounded-2xl p-8 text-center space-y-2 ${
                theme === 'light' ? 'bg-white border-slate-200 shadow-sm' : 'bg-slate-900 border-slate-800'
              }`}
            >
              <Search className={`w-8 h-8 mx-auto ${theme === 'light' ? 'text-slate-400' : 'text-slate-500'}`} />
              <h3 className={`text-sm font-bold ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                No Vacancies Found
              </h3>
              <p className={`text-xs max-w-sm mx-auto ${theme === 'light' ? 'text-slate-500' : 'text-slate-400'}`}>
                No jobs currently match your search and filter criteria. Try resetting filters or clearing qualifications.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('All');
                  setSelectedSector('All');
                  setSelectedQual('All Quals');
                  setOnlyUrgent(false);
                  setIncludeExpired(false);
                  setActiveSection('all');
                }}
                className="mt-2 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-sm"
              >
                Reset All Filters
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
