import React, { useState } from 'react';
import { PoketSafeData } from '../types/budget';
import { 
  ShieldCheck, 
  Plus, 
  ArrowRight, 
  Coffee, 
  Utensils, 
  Bus, 
  ShoppingCart, 
  Receipt, 
  MoreHorizontal, 
  Target
} from 'lucide-react';

import { NavTab } from './BottomNavBar';

interface HomeScreenProps {
  data: PoketSafeData;
  onNavigate: (tab: NavTab) => void;
  onQuickAddExpense: () => void;
  onUpdateCurrentMoney: (amount: number) => void;
}

const CATEGORY_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  coffee: Coffee,
  food: Utensils,
  transport: Bus,
  groceries: ShoppingCart,
  bills: Receipt,
  other: MoreHorizontal,
};

export const HomeScreen: React.FC<HomeScreenProps> = ({
  data,
  onNavigate,
  onQuickAddExpense,
  onUpdateCurrentMoney,
}) => {
  const [isEditingCash, setIsEditingCash] = useState(false);
  const [cashInput, setCashInput] = useState(data.currentMoney > 0 ? data.currentMoney.toString() : '');

  // Core Formula: Safe To Spend = Current Money - Upcoming Unpaid Commitments - Debts Owed
  const unpaidCommitments = (data.commitments || [])
    .filter(c => !c.isPaidThisCycle)
    .reduce((sum, c) => sum + c.amount, 0);

  const debtsOwed = (data.debts || [])
    .filter(d => d.type === 'i_owe' && !d.isSettled)
    .reduce((sum, d) => sum + d.amount, 0);

  const safeToSpend = data.currentMoney - unpaidCommitments - debtsOwed;

  const totalExpensesThisMonth = (data.transactions || [])
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalSavings = (data.savings || []).reduce((sum, s) => sum + s.currentAmount, 0);
  const primaryGoal = data.savings && data.savings.length > 0 ? data.savings[0] : null;
  const goalProgress = primaryGoal 
    ? Math.min(100, Math.round((primaryGoal.currentAmount / primaryGoal.targetAmount) * 100))
    : 0;

  const recentExpenses = (data.transactions || [])
    .filter(t => t.type === 'expense')
    .slice(0, 5);

  const handleSaveCash = () => {
    const val = parseFloat(cashInput) || 0;
    onUpdateCurrentMoney(val);
    setIsEditingCash(false);
  };

  return (
    <div className="space-y-4 pb-6">
      {/* 1. SAFE TO SPEND CARD (Minimal, Clean, No Fluff) */}
      <div className="rounded-3xl bg-slate-900 border border-slate-800 p-6 shadow-xl">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
          <div className="flex items-center gap-1.5 font-semibold text-slate-300 uppercase tracking-wider text-[11px]">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Safe To Spend</span>
          </div>
          <button
            onClick={() => {
              setCashInput(data.currentMoney > 0 ? data.currentMoney.toString() : '');
              setIsEditingCash(!isEditingCash);
            }}
            className="text-xs text-slate-400 hover:text-white transition-colors"
          >
            {isEditingCash ? 'Cancel' : (data.currentMoney === 0 ? '+ Set Cash' : 'Edit Cash')}
          </button>
        </div>

        {/* Quick inline cash editor */}
        {isEditingCash ? (
          <div className="my-3 p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center gap-2">
            <span className="text-xs text-slate-400 font-medium">Cash (RM):</span>
            <input
              type="number"
              step="any"
              autoFocus
              value={cashInput}
              onChange={e => setCashInput(e.target.value)}
              className="flex-1 px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-sm focus:outline-none focus:border-emerald-500"
              placeholder="0.00"
            />
            <button
              onClick={handleSaveCash}
              className="px-3 py-1.5 bg-emerald-500 text-slate-950 text-xs font-bold rounded-lg hover:bg-emerald-400"
            >
              Save
            </button>
          </div>
        ) : null}

        {/* Amount Display */}
        <div className="my-1">
          <div className="flex items-baseline gap-1.5">
            <span className="text-sm font-bold text-emerald-400">RM</span>
            <span
              className={`text-4xl sm:text-5xl font-extrabold tracking-tight font-mono tabular-nums ${
                safeToSpend < 0 ? 'text-rose-400' : 'text-white'
              }`}
            >
              {safeToSpend.toLocaleString('en-MY', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
        </div>

        {/* Compact Cash Breakdown */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between text-xs text-slate-400 gap-2 font-mono">
          <span>Cash: <strong className="text-slate-200">RM {data.currentMoney.toFixed(2)}</strong></span>
          <span aria-hidden="true" className="text-slate-700">·</span>
          <span>Commitments: <strong className="text-slate-200">−RM {unpaidCommitments.toFixed(2)}</strong></span>
          <span aria-hidden="true" className="text-slate-700">·</span>
          <span>Debts: <strong className="text-slate-200">−RM {debtsOwed.toFixed(2)}</strong></span>
        </div>
      </div>

      {/* 2. 4-ITEM SUMMARY GRID */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <div
          onClick={() => onNavigate('transactions')}
          className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 cursor-pointer transition-colors"
        >
          <div className="text-[11px] text-slate-400 font-medium mb-0.5">Expenses</div>
          <div className="text-lg font-bold font-mono text-white tabular-nums">
            RM {totalExpensesThisMonth.toFixed(0)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">This month</div>
        </div>

        <div
          onClick={() => onNavigate('payments')}
          className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 cursor-pointer transition-colors"
        >
          <div className="text-[11px] text-slate-400 font-medium mb-0.5">Commitments</div>
          <div className="text-lg font-bold font-mono text-blue-400 tabular-nums">
            RM {unpaidCommitments.toFixed(0)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Upcoming bills</div>
        </div>

        <div
          onClick={() => onNavigate('payments')}
          className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 cursor-pointer transition-colors"
        >
          <div className="text-[11px] text-slate-400 font-medium mb-0.5">Debt</div>
          <div className="text-lg font-bold font-mono text-amber-400 tabular-nums">
            RM {debtsOwed.toFixed(0)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">I owe</div>
        </div>

        <div
          onClick={() => onNavigate('savings')}
          className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 cursor-pointer transition-colors"
        >
          <div className="text-[11px] text-slate-400 font-medium mb-0.5">Savings</div>
          <div className="text-lg font-bold font-mono text-emerald-400 tabular-nums">
            RM {totalSavings.toFixed(0)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Total saved</div>
        </div>
      </div>

      {/* 3. PRIMARY SAVINGS GOAL */}
      {primaryGoal ? (
        <div
          onClick={() => onNavigate('savings')}
          className="rounded-2xl bg-slate-900/90 border border-slate-800 p-4 hover:border-slate-700 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between gap-3 mb-1.5">
            <div>
              <h3 className="text-xs font-semibold text-white">{primaryGoal.title}</h3>
            </div>
            <div className="text-right">
              <span className="text-xs font-mono font-bold text-white">
                RM {primaryGoal.currentAmount.toFixed(0)}
              </span>
              <span className="text-xs text-slate-400 font-mono"> / RM {primaryGoal.targetAmount.toFixed(0)}</span>
            </div>
          </div>

          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden my-2">
            <div
              className="bg-emerald-400 h-full rounded-full transition-all duration-300"
              style={{ width: `${goalProgress}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[10px] text-slate-400">
            <span>{goalProgress}%</span>
            <span className="text-emerald-400 font-medium flex items-center gap-1">
              <span>View</span>
              <ArrowRight className="w-3 h-3" />
            </span>
          </div>
        </div>
      ) : (
        <div 
          onClick={() => onNavigate('savings')}
          className="rounded-2xl bg-slate-900/90 border border-dashed border-slate-800 p-3.5 text-center cursor-pointer hover:border-slate-700 transition-colors"
        >
          <div className="flex items-center justify-center gap-2 text-xs text-slate-400">
            <Target className="w-3.5 h-3.5 text-slate-500" />
            <span>No savings goals</span>
            <span className="text-emerald-400 font-medium">+ Add Goal</span>
          </div>
        </div>
      )}

      {/* 4. RECENT EXPENSES */}
      <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-4">
        <div className="flex items-center justify-between gap-3 mb-2.5">
          <h3 className="text-xs font-semibold text-white uppercase tracking-wider">Recent Expenses</h3>
          <div className="flex items-center gap-2">
            <button
              onClick={onQuickAddExpense}
              className="px-2 py-0.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-md flex items-center gap-1 transition-colors"
            >
              <Plus className="w-3 h-3 stroke-[2.5]" />
              <span>Add</span>
            </button>
            <button
              onClick={() => onNavigate('transactions')}
              className="text-xs text-slate-400 hover:text-white transition-colors"
            >
              All
            </button>
          </div>
        </div>

        {recentExpenses.length === 0 ? (
          <div className="py-4 text-center text-xs text-slate-500">
            No expenses recorded yet.
          </div>
        ) : (
          <div className="divide-y divide-slate-800/70">
            {recentExpenses.map(expense => {
              const Icon = CATEGORY_ICONS[expense.category] || MoreHorizontal;
              return (
                <div
                  key={expense.id}
                  className="py-2 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-6 h-6 rounded-md bg-slate-800 text-slate-300 flex items-center justify-center shrink-0">
                      <Icon className="w-3 h-3" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-medium text-slate-200 truncate">{expense.title}</p>
                    </div>
                  </div>

                  <span className="font-mono font-bold text-slate-200 tabular-nums shrink-0">
                    −RM {expense.amount.toFixed(2)}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
