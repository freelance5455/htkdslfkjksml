import { Download, Languages, ScanLine } from "lucide-react";
import { DevicePicker } from "@/components/DevicePicker";
import { Button } from "@/components/ui/button";
import { useCaliber } from "@/lib/store";

export function HomeScreen() {
  const { dict, toggleLang, runScan, scanError } = useCaliber();

  return (
    <div className="relative mx-auto flex min-h-dvh w-full max-w-6xl flex-col px-5 pb-10 pt-6">
      <header className="flex items-center justify-between">
        <div className="font-display text-lg font-semibold tracking-[0.22em] text-primary">CALIBER</div>
        <Button variant="ghost" size="sm" onClick={toggleLang} aria-label={dict.language}>
          <Languages className="size-4" />
          {dict.language}
        </Button>
      </header>

      <div className="mt-8 grid flex-1 items-center gap-10 lg:grid-cols-2">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-accent">{dict.homeKicker}</p>
          <h1 className="mt-2 font-display text-5xl font-semibold leading-[0.95] tracking-tight text-fg sm:text-6xl">
            {dict.tagline}
          </h1>
          <p className="mt-4 max-w-prose text-sm leading-relaxed text-muted">{dict.homeLead}</p>

          <div className="relative mx-auto mt-8 h-40 w-40 lg:mx-0">
            <div className="absolute inset-0 rounded-full shadow-[var(--shadow-border)]" />
            <svg viewBox="0 0 160 160" className="absolute inset-0 size-full" aria-hidden>
              <circle cx="80" cy="80" r="62" fill="none" stroke="currentColor" className="text-surface-2" strokeWidth="1" />
              <circle cx="80" cy="80" r="42" fill="none" stroke="currentColor" className="text-surface-2" strokeWidth="1" />
              <g className="radar-sweep text-primary">
                <path d="M80 80 L80 18 A62 62 0 0 1 128 48 Z" fill="currentColor" opacity="0.18" />
                <line x1="80" y1="80" x2="80" y2="18" stroke="currentColor" strokeWidth="2" />
              </g>
              <circle cx="80" cy="80" r="4" fill="currentColor" className="text-accent" />
            </svg>
          </div>

          <Button size="lg" className="mt-6 w-full font-display text-lg tracking-wide sm:w-auto sm:px-10" onClick={() => void runScan()}>
            <ScanLine className="size-5" />
            {dict.scanCta}
          </Button>
          <p className="mt-2 text-xs text-subtle sm:text-start text-center">{dict.scanSub}</p>
          {scanError ? <p className="mt-2 text-sm text-danger">{scanError}</p> : null}
        </div>

        <div>
          <DevicePicker featured />
          <div className="mt-6 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
            <p className="font-display text-sm font-semibold">{dict.buildGuide}</p>
            <p className="mt-1 text-xs leading-relaxed text-muted">{dict.buildBody}</p>
            <a
              href="/caliber-android.zip"
              download
              className="mt-3 inline-flex h-11 items-center gap-2 text-sm text-primary"
            >
              <Download className="size-4" />
              {dict.downloadApk}
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
