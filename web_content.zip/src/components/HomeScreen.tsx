import React from 'react';
import { Play, Grid, Settings, Info, Newspaper, Star, Trophy } from 'lucide-react';
import { PlayerProgress, StageProgress } from '../types/crossword';
import { convertToArabicNumerals } from '../data/sampleStages';
import { soundManager } from '../utils/audio';

interface HomeScreenProps {
  progress: PlayerProgress;
  onStartOrContinue: () => void;
  onOpenStages: () => void;
  onOpenSettings: () => void;
  onOpenAbout: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  progress,
  onStartOrContinue,
  onOpenStages,
  onOpenSettings,
  onOpenAbout,
}) => {
  const hasProgress =
    progress.unlockedStageId > 1 ||
    Object.keys(progress.stageProgresses).length > 0;

  const currentStageText = convertToArabicNumerals(progress.currentStageId || 1);

  // Calculate total stars collected across all completed stages
  const stageList = Object.values(progress.stageProgresses) as StageProgress[];
  const totalStars: number = stageList.reduce((sum: number, sp: StageProgress) => {
    return sum + (sp?.bestStars !== undefined ? sp.bestStars : sp?.completed ? 3 : 0);
  }, 0);

  const completedStagesCount: number = stageList.filter(
    (sp: StageProgress) => sp?.completed
  ).length;

  // Dynamic live date in Arabic (day name, day of month, month name, year with Arabic numerals)
  const today = new Date();
  const formattedLiveDate = today.toLocaleDateString('ar-EG', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  return (
    <div className="flex-1 flex flex-col justify-between items-center p-4 sm:p-6 max-w-md mx-auto w-full paper-texture">
      {/* Front Page Newspaper Header Box */}
      <div className="w-full text-center my-auto flex flex-col items-center">
        {/* Date and Issue Header Line */}
        <div className="w-full flex justify-between items-center text-[10px] sm:text-xs text-[#2c2c2c] border-t-2 border-b border-[#2c2c2c] py-1 px-2 mb-4 font-semibold">
          <span>العدد {convertToArabicNumerals(1)}</span>
          <span>{formattedLiveDate}</span>
          <span>صفحة الألغاز</span>
        </div>

        {/* Newspaper Title */}
        <div className="p-4 bg-[#d8d3c5] border-2 border-[#2c2c2c] newspaper-border-double w-full shadow-xs mb-6">
          <div className="flex items-center justify-center gap-2 mb-1 text-[#2c2c2c]">
            <Newspaper className="w-6 h-6 opacity-80" />
            <span className="text-xs font-bold tracking-widest uppercase">الجريدة التراثية</span>
          </div>
          <h1 className="newspaper-font text-4xl sm:text-5xl font-black text-[#1a1a1a] my-2 leading-tight">
            الكلمات المتقاطعة
          </h1>
          <p className="text-xs sm:text-sm text-[#2c2c2c] font-serif border-t border-[#2c2c2c]/30 pt-2 mt-1">
            رياضة الفكر ومتعة المطالعة في ثقافة الكلمات العربية
          </p>

          {/* Player Achievements Scoreboard */}
          {(hasProgress || totalStars > 0) && (
            <div className="mt-3 pt-2.5 border-t border-[#2c2c2c]/20 flex items-center justify-around text-xs font-bold text-[#1a1a1a] bg-[#ede9e1]/60 py-1.5 px-3 rounded-xs">
              <div className="flex items-center gap-1.5">
                <Star className="w-4 h-4 fill-[#d97706] text-[#b45309]" />
                <span>النجوم:</span>
                <span className="text-[#b45309] font-mono text-sm">
                  {convertToArabicNumerals(totalStars)} / {convertToArabicNumerals(150)}
                </span>
              </div>
              <span className="text-[#2c2c2c]/30">•</span>
              <div className="flex items-center gap-1.5">
                <Trophy className="w-4 h-4 text-[#1a1a1a]" />
                <span>المكتملة:</span>
                <span className="font-mono text-sm">
                  {convertToArabicNumerals(completedStagesCount)} / {convertToArabicNumerals(50)}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-3 max-w-xs">
          {/* Main Action Button */}
          <button
            type="button"
            onClick={() => {
              soundManager.playButtonClick();
              onStartOrContinue();
            }}
            className="w-full py-3.5 px-6 bg-[#1a1a1a] hover:bg-[#2c2c2c] active:bg-[#000] text-[#fdfbf7] font-bold text-lg sm:text-xl rounded-xs border border-[#1a1a1a] shadow-sm flex items-center justify-center gap-3 transition-all touch-manipulation"
          >
            <Play className="w-5 h-5 fill-current" />
            <span>
              {hasProgress
                ? `متابعة المرحلة (${currentStageText})`
                : 'ابدأ اللعب'}
            </span>
          </button>

          {/* Stages Button */}
          <button
            type="button"
            onClick={() => {
              soundManager.playButtonClick();
              onOpenStages();
            }}
            className="w-full py-3 px-6 bg-[#ede9e1] hover:bg-[#e6d5b8] active:bg-[#2c2c2c] active:text-[#fdfbf7] text-[#1a1a1a] font-bold text-base sm:text-lg rounded-xs border border-[#2c2c2c] shadow-xs flex items-center justify-center gap-2.5 transition-all touch-manipulation"
          >
            <Grid className="w-5 h-5" />
            <span>المراحل (٥٠ مرحلة)</span>
          </button>

          {/* Settings Button */}
          <button
            type="button"
            onClick={() => {
              soundManager.playButtonClick();
              onOpenSettings();
            }}
            className="w-full py-3 px-6 bg-[#ede9e1] hover:bg-[#e6d5b8] active:bg-[#2c2c2c] active:text-[#fdfbf7] text-[#1a1a1a] font-bold text-base sm:text-lg rounded-xs border border-[#2c2c2c] shadow-xs flex items-center justify-center gap-2.5 transition-all touch-manipulation"
          >
            <Settings className="w-5 h-5" />
            <span>الإعدادات</span>
          </button>

          {/* About Button */}
          <button
            type="button"
            onClick={() => {
              soundManager.playButtonClick();
              onOpenAbout();
            }}
            className="w-full py-2.5 px-4 bg-transparent hover:bg-[#ede9e1] text-[#2c2c2c] font-semibold text-sm rounded-xs border border-[#2c2c2c]/50 flex items-center justify-center gap-2 transition-all"
          >
            <Info className="w-4 h-4" />
            <span>حول اللعبة</span>
          </button>
        </div>
      </div>

      {/* Newspaper Footer Quote */}
      <footer className="w-full text-center text-[11px] text-[#2c2c2c]/80 border-t border-[#2c2c2c]/30 pt-3 mt-auto">
        <span>مستوحاة من ألعاب الكلمات المتقاطعة للصحف العربية العريقة</span>
      </footer>
    </div>
  );
};
