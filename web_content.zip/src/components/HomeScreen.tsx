import React, { useState, useEffect } from 'react';
import { 
  Zap, 
  ChevronRight, 
  Star, 
  ShieldCheck, 
  Flame, 
  Sparkles,
  ShoppingBag,
  Smartphone,
  Shirt,
  HeartHandshake,
  Home,
  Globe,
  Trophy,
  Gift,
  MessageCircle
} from 'lucide-react';
import { Product } from '../types/ecommerce';
import { HERO_BANNER_IMG } from '../data/mockData';

interface HomeScreenProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onNavigateToCategory: (categoryId: string) => void;
  onOpenWhatsAppOrder?: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  products,
  onSelectProduct,
  onNavigateToCategory,
  onOpenWhatsAppOrder
}) => {
  // Synchronized countdown timer for Flash Sale
  const [timeLeft, setTimeLeft] = useState({ hours: 4, minutes: 27, seconds: 48 });
  const [activeFeedCategory, setActiveFeedCategory] = useState<string>('All');
  const [bannerIndex, setBannerIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: 59, seconds: 59 };
        if (prev.hours > 0) return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return { hours: 6, minutes: 0, seconds: 0 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const flashSaleItems = products.filter(p => p.isFlashSale);

  const quickCategories = [
    { id: 'Fashion', name: 'Fashion', icon: Shirt, bg: 'bg-rose-50 text-rose-600' },
    { id: 'Electronics', name: 'Gadgets', icon: Smartphone, bg: 'bg-blue-50 text-blue-600' },
    { id: 'Beauty', name: 'Beauty', icon: HeartHandshake, bg: 'bg-emerald-50 text-emerald-600' },
    { id: 'Home & Living', name: 'Home', icon: Home, bg: 'bg-purple-50 text-purple-600' },
    { id: 'Groceries', name: 'Sewora Mart', icon: ShoppingBag, bg: 'bg-amber-50 text-amber-600' },
    { id: 'Sports', name: 'Sports', icon: Trophy, bg: 'bg-orange-50 text-[#FF6600]' },
    { id: 'Global', name: 'Global', icon: Globe, bg: 'bg-cyan-50 text-cyan-600' },
    { id: 'Vouchers', name: 'Free Gifts', icon: Gift, bg: 'bg-indigo-50 text-indigo-600' }
  ];

  const filteredFeed = activeFeedCategory === 'All' 
    ? products 
    : products.filter(p => p.category.toLowerCase().includes(activeFeedCategory.toLowerCase()));

  return (
    <div className="pb-20 space-y-3 bg-slate-50 min-h-screen">
      {/* 1. Dynamic Campaign Promo Banner Carousel */}
      <div className="relative overflow-hidden bg-slate-900 mx-2 mt-2 rounded-2xl shadow-sm">
        <div className="relative aspect-[16/9] w-full">
          <img
            src={HERO_BANNER_IMG}
            alt="Sewora Mega Sale"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-black/20 flex flex-col justify-end p-3 text-white">
            <span className="text-[11px] font-semibold text-orange-300 tracking-wider uppercase flex items-center gap-1">
              <Sparkles className="w-3 h-3" /> Live Festival Deals
            </span>
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-white leading-tight">Mega Payday Discounts</h2>
                <p className="text-[11px] text-slate-200">Up to 50% OFF + Free Islandwide Shipping</p>
              </div>
              <button 
                onClick={() => onNavigateToCategory('all')}
                className="bg-[#FF6600] text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-md hover:bg-orange-600 active:scale-95 transition-all"
              >
                Claim Now
              </button>
            </div>
          </div>
        </div>
        
        {/* Banner indicator dots */}
        <div className="absolute bottom-2 right-3 flex gap-1 z-10">
          <span className="w-4 h-1 bg-[#FF6600] rounded-full"></span>
          <span className="w-1.5 h-1 bg-white/60 rounded-full"></span>
          <span className="w-1.5 h-1 bg-white/60 rounded-full"></span>
        </div>
      </div>

      {/* Trust Badges Strip (Daraz-inspired Mall / COD / Genuine) */}
      <div className="mx-2 bg-white rounded-xl p-2.5 shadow-2xs border border-slate-100 flex items-center justify-between text-[11px] text-slate-600">
        <div className="flex items-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-[#FF6600]" />
          <span className="font-semibold text-slate-800">100% Authentic</span>
        </div>
        <span className="text-slate-300">·</span>
        <div className="flex items-center gap-1">
          <span className="font-semibold text-slate-800">Cash on Delivery</span>
        </div>
        <span className="text-slate-300">·</span>
        <div className="flex items-center gap-1">
          <span className="font-semibold text-slate-800">14-Day Free Returns</span>
        </div>
      </div>

      {/* WhatsApp 1-Tap Order & Support Strip */}
      {onOpenWhatsAppOrder && (
        <div 
          onClick={onOpenWhatsAppOrder}
          className="mx-2 bg-gradient-to-r from-emerald-600 to-[#25D366] text-white rounded-2xl p-3 shadow-2xs flex items-center justify-between cursor-pointer hover:opacity-95 active:scale-99 transition-all"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-white/20 backdrop-blur-xs flex items-center justify-center shrink-0">
              <MessageCircle className="w-4 h-4 fill-white text-white" />
            </div>
            <div>
              <div className="font-extrabold text-xs flex items-center gap-1.5">
                <span>SEWORA MART WhatsApp Order</span>
                <span className="bg-yellow-300 text-slate-900 text-[8px] font-black px-1.5 py-0.2 rounded uppercase">
                  Fast
                </span>
              </div>
              <p className="text-[10px] text-emerald-100 mt-0.2">
                Order directly or ask questions on +94 77 123 4567
              </p>
            </div>
          </div>
          <div className="bg-white text-emerald-800 text-[11px] font-bold px-2.5 py-1 rounded-xl shadow-xs shrink-0">
            Open WhatsApp
          </div>
        </div>
      )}

      {/* 2. Category Quick Links (2 Rows of 4 icons) */}
      <div className="mx-2 bg-white rounded-2xl p-3 shadow-2xs border border-slate-100">
        <div className="grid grid-cols-4 gap-y-3 gap-x-2">
          {quickCategories.map((cat) => {
            const Icon = cat.icon;
            return (
              <button
                key={cat.id}
                onClick={() => onNavigateToCategory(cat.id)}
                className="flex flex-col items-center group cursor-pointer"
              >
                <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${cat.bg} group-hover:scale-105 transition-transform shadow-2xs`}>
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-[11px] font-medium text-slate-700 mt-1.5 text-center leading-tight truncate w-full">
                  {cat.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. Flash Sale Section with Countdown Timer */}
      <div className="mx-2 bg-white rounded-2xl p-3 shadow-2xs border border-orange-100 relative overflow-hidden">
        {/* Flash Sale Header */}
        <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 text-[#FF6600]">
              <Zap className="w-4 h-4 fill-[#FF6600]" />
              <span className="font-extrabold text-sm tracking-tight text-slate-900">FLASH SALE</span>
            </div>
            
            {/* Digital Countdown Timer */}
            <div className="flex items-center gap-1 font-mono text-[10px] text-white">
              <span className="bg-slate-900 px-1.5 py-0.5 rounded font-bold">
                {String(timeLeft.hours).padStart(2, '0')}
              </span>
              <span className="text-slate-800 font-bold">:</span>
              <span className="bg-slate-900 px-1.5 py-0.5 rounded font-bold">
                {String(timeLeft.minutes).padStart(2, '0')}
              </span>
              <span className="text-slate-800 font-bold">:</span>
              <span className="bg-[#FF6600] px-1.5 py-0.5 rounded font-bold">
                {String(timeLeft.seconds).padStart(2, '0')}
              </span>
            </div>
          </div>

          <button 
            onClick={() => onNavigateToCategory('all')}
            className="flex items-center text-xs font-semibold text-[#FF6600] hover:text-orange-700 transition-colors"
          >
            <span>SHOP MORE</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Horizontal Flash Sale Carousel */}
        <div className="flex gap-2.5 overflow-x-auto pb-1 scrollbar-none snap-x">
          {flashSaleItems.map((prod) => (
            <div
              key={prod.id}
              onClick={() => onSelectProduct(prod)}
              className="min-w-[130px] max-w-[130px] bg-white rounded-xl border border-slate-100 p-2 shrink-0 snap-start cursor-pointer hover:border-orange-200 hover:shadow-xs transition-all group"
            >
              <div className="relative aspect-square w-full rounded-lg overflow-hidden bg-slate-50 mb-1.5">
                <img
                  src={prod.images[0]}
                  alt={prod.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <span className="absolute top-1 left-1 bg-[#FF6600] text-white text-[9px] font-extrabold px-1 py-0.2 rounded">
                  -{prod.discountPercent}%
                </span>
              </div>

              <div className="font-extrabold text-[#FF6600] text-xs tabular-nums">
                Rs. {prod.price.toLocaleString()}
              </div>
              <div className="text-[10px] text-slate-400 line-through tabular-nums">
                Rs. {prod.originalPrice.toLocaleString()}
              </div>

              {/* Progress bar sold count */}
              <div className="mt-1.5">
                <div className="w-full bg-orange-100 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-[#FF6600] h-full rounded-full transition-all"
                    style={{ width: `${prod.flashSoldPercent || 70}%` }}
                  ></div>
                </div>
                <div className="text-[9px] text-slate-500 font-medium mt-0.5">
                  {prod.flashSoldPercent}% Sold
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. "Just For You" Personalized Recommendation Feed */}
      <div className="mx-2 space-y-2">
        <div className="flex items-center justify-between pt-2">
          <div className="flex items-center gap-1.5">
            <Flame className="w-4 h-4 text-[#FF6600] fill-[#FF6600]" />
            <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">JUST FOR YOU</h3>
          </div>
          <span className="text-[11px] text-slate-500 font-medium">Personalized daily picks</span>
        </div>

        {/* Category Pills Filter */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {['All', 'Fashion', 'Electronics', 'Beauty', 'Home & Living'].map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveFeedCategory(cat)}
              className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                activeFeedCategory === cat
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* 2-Column Product Grid */}
        <div className="grid grid-cols-2 gap-2">
          {filteredFeed.map((product) => (
            <div
              key={product.id}
              onClick={() => onSelectProduct(product)}
              className="bg-white rounded-xl border border-slate-100 overflow-hidden shadow-2xs hover:shadow-md transition-all cursor-pointer flex flex-col group"
            >
              <div className="relative aspect-square w-full bg-slate-50 overflow-hidden">
                <img
                  src={product.images[0]}
                  alt={product.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                {product.freeShipping && (
                  <span className="absolute bottom-1 left-1 bg-emerald-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded shadow-xs">
                    Free Delivery
                  </span>
                )}
                <span className="absolute top-1 right-1 bg-black/60 text-white text-[9px] font-semibold px-1 py-0.5 rounded backdrop-blur-xs">
                  ★ {product.rating}
                </span>
              </div>

              <div className="p-2.5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1 mb-1">
                    <span className="bg-[#FF6600] text-white text-[8px] font-black px-1 rounded uppercase">
                      MALL
                    </span>
                    <span className="text-[10px] text-slate-500 font-medium truncate">
                      {product.category}
                    </span>
                  </div>
                  <h4 className="text-xs font-semibold text-slate-900 line-clamp-2 leading-snug group-hover:text-[#FF6600] transition-colors">
                    {product.title}
                  </h4>
                </div>

                <div className="mt-2 pt-1 border-t border-slate-50">
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-sm font-extrabold text-[#FF6600] tabular-nums">
                      Rs. {product.price.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-slate-400 mt-0.5">
                    <span className="line-through tabular-nums">
                      Rs. {product.originalPrice.toLocaleString()}
                    </span>
                    <span className="text-slate-500 font-medium">
                      {product.soldCount} sold
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
