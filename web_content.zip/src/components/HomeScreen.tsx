import React from 'react';
import { GameStats, GameTheme, PlayerProfile, DailyChallenge, DailyStreakData } from '../types';
import {
  Play,
  Trophy,
  Coins,
  Palette,
  Award,
  Calendar,
  Zap,
  Settings,
  Flame,
  Sparkles,
  Video,
  Smartphone,
  Download,
} from 'lucide-react';

interface HomeScreenProps {
  stats: GameStats;
  currentTheme: GameTheme;
  profile: PlayerProfile;
  dailyChallenge: DailyChallenge;
  streakData: DailyStreakData;
  canClaimStreak: boolean;
  onPlay: () => void;
  onOpenThemes: () => void;
  onOpenDaily: () => void;
  onOpenStreak: () => void;
  onOpenLeaderboard: () => void;
  onOpenAchievements: () => void;
  onOpenProfile: () => void;
  onOpenSettings: () => void;
  onWatchAd?: () => void;
  onOpenDownloadZip?: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  stats,
  currentTheme,
  profile,
  dailyChallenge,
  streakData,
  canClaimStreak,
  onPlay,
  onOpenThemes,
  onOpenDaily,
  onOpenStreak,
  onOpenLeaderboard,
  onOpenAchievements,
  onOpenProfile,
  onOpenSettings,
  onWatchAd,
  onOpenDownloadZip,
}) => {
  return (
    <div className="flex h-full w-full max-w-md flex-col justify-between px-5 py-6 text-center select-none pt-safe pb-safe z-10 overflow-y-auto no-scrollbar">
      {/* Top Header Bar: Profile, Streak, Coins, Settings */}
      <div className="flex w-full items-center justify-between">
        {/* Profile Avatar Trigger */}
        <button
          onClick={onOpenProfile}
          className="flex items-center gap-2 rounded-2xl bg-slate-900/90 px-3 py-1.5 border border-slate-800 hover:border-slate-700 active:scale-95 transition-all"
        >
          <span className="text-xl">{profile.avatar}</span>
          <div className="flex flex-col text-left">
            <span className="text-xs font-bold text-white max-w-[80px] truncate">
              {profile.name}
            </span>
            <span className="text-[10px] text-slate-400">
              {profile.isGoogleUser ? 'Google' : 'Guest'}
            </span>
          </div>
        </button>

        {/* Streak, Coins and Settings Group */}
        <div className="flex items-center gap-1.5">
          {/* Daily Streak Trigger Badge */}
          <button
            onClick={onOpenStreak}
            className={`flex items-center gap-1 rounded-2xl px-2.5 py-1.5 border transition-all active:scale-95 ${
              canClaimStreak
                ? 'bg-gradient-to-r from-orange-500/25 to-amber-500/25 border-orange-500/50 text-orange-400 shadow-[0_0_15px_rgba(249,115,22,0.25)] animate-pulse'
                : 'bg-slate-900/90 border-slate-800 text-slate-300 hover:border-slate-700'
            }`}
            title="Daily Login Streak"
          >
            <Flame className={`h-4 w-4 ${canClaimStreak ? 'text-orange-400 fill-orange-400' : 'text-slate-400'}`} />
            <span className="font-mono text-xs font-black">{streakData.currentStreak}d</span>
            {canClaimStreak && <span className="h-1.5 w-1.5 rounded-full bg-amber-400 animate-ping" />}
          </button>

          {/* Coins Balance */}
          <div className="flex items-center gap-1.5 rounded-2xl bg-slate-900/90 px-3 py-1.5 border border-amber-500/30 shadow-[0_0_15px_rgba(245,158,11,0.15)]">
            <Coins className="h-4 w-4 text-amber-400 fill-amber-400/20" />
            <span className="font-mono text-sm font-black text-amber-300 tabular-nums">
              {stats.coins}
            </span>
          </div>

          {/* Android Project ZIP Download Trigger */}
          {onOpenDownloadZip && (
            <button
              onClick={onOpenDownloadZip}
              className="flex h-9 items-center gap-1.5 rounded-2xl bg-gradient-to-r from-emerald-500/20 to-teal-500/20 px-2.5 border border-emerald-500/50 text-emerald-400 hover:text-white hover:border-emerald-400 active:scale-95 transition-all shadow-[0_0_12px_rgba(16,185,129,0.2)]"
              title="Download Android Studio Project ZIP"
            >
              <Smartphone className="h-4 w-4 text-emerald-400" />
              <span className="text-[10px] font-black uppercase tracking-wider">
                ZIP
              </span>
            </button>
          )}

          {/* Settings Trigger */}
          <button
            onClick={onOpenSettings}
            className="flex h-9 w-9 items-center justify-center rounded-2xl bg-slate-900/90 border border-slate-800 text-slate-300 hover:text-white active:scale-95 transition-all"
            aria-label="Settings"
          >
            <Settings className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Main Hero Branding */}
      <div className="flex flex-col items-center my-auto py-2">
        {/* Glowing Orb Lockup */}
        <div className="relative mb-3 flex items-center justify-center">
          <div className="absolute -left-6 h-12 w-12 rounded-full bg-blue-500/80 blur-xl animate-pulse" />
          <div className="absolute -right-6 h-12 w-12 rounded-full bg-rose-500/80 blur-xl animate-pulse delay-200" />
          <div className="relative flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-tr from-amber-400 via-rose-500 to-blue-500 p-1 shadow-[0_0_35px_rgba(239,68,68,0.45)]">
            <div className="flex h-full w-full items-center justify-center rounded-full bg-slate-950">
              <Zap className="h-9 w-9 text-amber-400 fill-amber-400 animate-bounce" />
            </div>
          </div>
        </div>

        {/* Title & Tagline */}
        <h1 className="text-4xl sm:text-5xl font-black tracking-tight drop-shadow-lg">
          <span className="text-white">COLOR </span>
          <span className="bg-gradient-to-r from-amber-400 via-rose-500 to-blue-500 bg-clip-text text-transparent">
            RUSH
          </span>
        </h1>
        <p className="mt-1 text-xs sm:text-sm font-bold tracking-widest text-slate-400 uppercase">
          Tap Fast. Stay Alive.
        </p>

        {/* Score & Theme Info Cards */}
        <div className="mt-4 grid grid-cols-2 gap-2.5 w-full max-w-xs">
          <div className="flex flex-col items-center rounded-2xl bg-slate-900/80 p-2.5 border border-slate-800">
            <div className="flex items-center gap-1 text-[10px] font-bold text-amber-400 uppercase">
              <Trophy className="h-3 w-3 fill-amber-400" />
              <span>BEST SCORE</span>
            </div>
            <span className="font-mono text-xl font-black text-amber-300 tabular-nums">
              {stats.highScore}
            </span>
          </div>

          <div
            onClick={onOpenThemes}
            className="flex flex-col items-center rounded-2xl bg-slate-900/80 p-2.5 border border-slate-800 cursor-pointer active:scale-95 transition-all hover:border-slate-700"
          >
            <div className="flex items-center gap-1 text-[10px] font-bold text-slate-400 uppercase">
              <Palette className="h-3 w-3 text-indigo-400" />
              <span>THEME</span>
            </div>
            <span className="text-xs font-bold text-indigo-300 mt-1">
              {currentTheme.name}
            </span>
          </div>
        </div>

        {/* Interactive Daily Streak Callout Banner */}
        <div
          onClick={onOpenStreak}
          className={`mt-2.5 flex items-center justify-between w-full max-w-xs rounded-2xl p-2.5 border cursor-pointer active:scale-98 transition-all ${
            canClaimStreak
              ? 'bg-gradient-to-r from-orange-950/70 via-amber-950/50 to-orange-950/70 border-orange-500/50 shadow-[0_0_15px_rgba(249,115,22,0.2)]'
              : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-orange-500/20 text-orange-400">
              <Flame className="h-4 w-4 fill-orange-400" />
            </div>
            <div className="flex flex-col text-left">
              <span className="text-[10px] font-black uppercase text-orange-400 tracking-wider">
                DAILY LOGIN STREAK
              </span>
              <span className="text-xs text-white font-bold">
                {streakData.currentStreak} Day Streak
              </span>
            </div>
          </div>
          <div className="flex items-center gap-1 text-xs font-bold text-amber-300">
            {canClaimStreak ? (
              <span className="bg-amber-500/20 px-2 py-0.5 rounded-full text-[10px] font-black text-amber-300 border border-amber-500/40 animate-pulse">
                CLAIM NOW
              </span>
            ) : (
              <span className="text-[10px] text-slate-400">Claimed ✓</span>
            )}
          </div>
        </div>

        {/* Daily Challenge Teaser Banner */}
        <div
          onClick={onOpenDaily}
          className="mt-2 flex items-center justify-between w-full max-w-xs rounded-2xl bg-gradient-to-r from-indigo-950/70 via-slate-900 to-indigo-950/70 p-2.5 border border-indigo-500/30 cursor-pointer active:scale-98 transition-all"
        >
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-indigo-500/20 text-indigo-400">
              <Calendar className="h-4 w-4" />
            </div>
            <div className="flex flex-col text-left">
              <span className="text-[10px] font-black uppercase text-indigo-300 tracking-wider">
                DAILY CHALLENGE
              </span>
              <span className="text-xs text-slate-300 truncate max-w-[170px]">
                {dailyChallenge.title}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-1 text-xs font-bold text-amber-400">
            <Coins className="h-3.5 w-3.5 fill-amber-400/20" />
            <span>+{dailyChallenge.rewardCoins}</span>
          </div>
        </div>
      </div>

      {/* Main Action Buttons Grid */}
      <div className="w-full flex flex-col items-center gap-2.5 mt-2">
        {/* Giant PLAY Button */}
        <button
          onClick={onPlay}
          className="group relative flex h-14 sm:h-16 w-full cursor-pointer items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 font-black text-lg text-white shadow-[0_8px_30px_rgba(16,185,129,0.4)] transition-all duration-150 active:scale-95 hover:brightness-110"
        >
          <Play className="h-6 w-6 fill-white transition-transform group-hover:scale-110" />
          <span className="tracking-wider">PLAY NOW</span>
        </button>

        {/* Secondary Menu Buttons 2x2 */}
        <div className="grid grid-cols-2 gap-2 w-full">
          <button
            onClick={onOpenDaily}
            className="flex h-11 items-center justify-center gap-2 rounded-xl bg-slate-900/90 border border-slate-800 text-xs font-bold text-slate-200 hover:text-white hover:border-slate-700 active:scale-95 transition-all"
          >
            <Calendar className="h-4 w-4 text-amber-400" />
            <span>DAILY</span>
          </button>

          <button
            onClick={onOpenLeaderboard}
            className="flex h-11 items-center justify-center gap-2 rounded-xl bg-slate-900/90 border border-slate-800 text-xs font-bold text-slate-200 hover:text-white hover:border-slate-700 active:scale-95 transition-all"
          >
            <Trophy className="h-4 w-4 text-yellow-400" />
            <span>LEADERBOARD</span>
          </button>

          <button
            onClick={onOpenThemes}
            className="flex h-11 items-center justify-center gap-2 rounded-xl bg-slate-900/90 border border-slate-800 text-xs font-bold text-slate-200 hover:text-white hover:border-slate-700 active:scale-95 transition-all"
          >
            <Palette className="h-4 w-4 text-cyan-400" />
            <span>THEMES</span>
          </button>

          <button
            onClick={onOpenAchievements}
            className="flex h-11 items-center justify-center gap-2 rounded-xl bg-slate-900/90 border border-slate-800 text-xs font-bold text-slate-200 hover:text-white hover:border-slate-700 active:scale-95 transition-all"
          >
            <Award className="h-4 w-4 text-rose-400" />
            <span>AWARDS</span>
          </button>
        </div>

        {/* Watch Ad Bonus Button */}
        {onWatchAd && (
          <button
            onClick={onWatchAd}
            className="flex h-9 w-full items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-amber-500/15 via-yellow-500/10 to-amber-500/15 border border-amber-500/30 text-[11px] font-bold text-amber-300 hover:bg-amber-500/20 active:scale-95 transition-all"
          >
            <Video className="h-3.5 w-3.5 text-amber-400" />
            <span>Watch Ad (+10 Bonus Coins)</span>
          </button>
        )}

        {/* Android Project Download Banner */}
        {onOpenDownloadZip && (
          <button
            onClick={onOpenDownloadZip}
            className="flex h-9 w-full items-center justify-between px-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-[11px] font-bold text-emerald-300 hover:bg-emerald-900/30 active:scale-95 transition-all"
          >
            <div className="flex items-center gap-1.5">
              <Smartphone className="h-3.5 w-3.5 text-emerald-400" />
              <span>Android Project ZIP (Studio Ready)</span>
            </div>
            <div className="flex items-center gap-1 text-[10px] text-emerald-400 font-mono bg-emerald-500/20 px-1.5 py-0.5 rounded">
              <Download className="h-3 w-3" />
              <span>Get ZIP</span>
            </div>
          </button>
        )}
      </div>
    </div>
  );
};
