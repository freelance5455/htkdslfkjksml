import React from "react";
import { CategoryItem } from "../types";
import {
  Layers,
  Grid,
  LayoutGrid,
  Palette,
  AlignJustify,
  Menu,
  Sparkles,
  SquareDashed,
  Gem,
  Maximize2,
  ArrowRight,
  Calculator,
  Bot,
  CheckCircle2,
  ShieldCheck,
  Zap,
  Phone,
  MessageCircle,
  Download,
  Smartphone,
  WifiOff,
} from "lucide-react";

interface HomeScreenProps {
  categories: CategoryItem[];
  rates: Record<string, number | null>;
  onSelectCategory: (categoryId: string) => void;
  onStartCalculation: () => void;
  onOpenAi: () => void;
  onOpenRates: () => void;
  onInstallApp?: () => void;
  isInstalled?: boolean;
}

// Icon helper
const getCategoryIcon = (iconName: string) => {
  const iconProps = { className: "w-5 h-5 text-indigo-600" };
  switch (iconName) {
    case "Layers":
      return <Layers {...iconProps} />;
    case "Grid":
      return <Grid {...iconProps} />;
    case "LayoutGrid":
      return <LayoutGrid {...iconProps} />;
    case "Palette":
      return <Palette {...iconProps} />;
    case "AlignJustify":
      return <AlignJustify {...iconProps} />;
    case "Menu":
      return <Menu {...iconProps} />;
    case "Sparkles":
      return <Sparkles {...iconProps} />;
    case "SquareDashed":
      return <SquareDashed {...iconProps} />;
    case "Gem":
      return <Gem {...iconProps} />;
    case "Maximize2":
      return <Maximize2 {...iconProps} />;
    default:
      return <Layers {...iconProps} />;
  }
};

export const HomeScreen: React.FC<HomeScreenProps> = ({
  categories,
  rates,
  onSelectCategory,
  onStartCalculation,
  onOpenAi,
  onOpenRates,
  onInstallApp,
  isInstalled,
}) => {
  return (
    <div className="space-y-6">
      {/* Hero Card with Start Calculation & Install Button */}
      <div className="bg-indigo-600 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-indigo-700 relative overflow-hidden">
        {/* Subtle geometric circles */}
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-16 -mb-16 w-48 h-48 bg-indigo-900/30 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 border border-white/20 text-white text-xs font-semibold">
              <Zap className="w-3.5 h-3.5 text-indigo-200" />
              <span>Fast & Accurate Material Costing</span>
            </div>
            {!isInstalled && (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[11px] font-extrabold tracking-wide">
                <Smartphone className="w-3 h-3" />
                PWA READY
              </span>
            )}
          </div>

          <div className="space-y-1.5">
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
              Ceiling & Interior Cost Estimator
            </h2>
            <p className="text-sm text-indigo-100 leading-relaxed max-w-xl">
              Calculate exact square feet area, material BOQ, labour fitting charges, and verified contractor rates with 100% offline precision.
            </p>
          </div>

          {/* Action Button Row */}
          <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <button
              onClick={onStartCalculation}
              id="start-calculation-btn"
              className="flex-1 bg-white hover:bg-indigo-50 text-indigo-700 font-bold py-3.5 px-6 rounded-2xl shadow-lg shadow-indigo-900/20 flex items-center justify-center gap-2.5 text-base transition-all active:scale-[0.98]"
            >
              <Calculator className="w-5 h-5 stroke-[2.5]" />
              <span>Start New Calculation</span>
              <ArrowRight className="w-4 h-4 ml-1" />
            </button>

            {/* Install App Button */}
            {!isInstalled && onInstallApp && (
              <button
                onClick={onInstallApp}
                id="home-install-btn"
                className="bg-amber-400 hover:bg-amber-300 active:bg-amber-500 text-slate-950 font-black py-3.5 px-5 rounded-2xl flex items-center justify-center gap-2 text-sm shadow-md transition-all active:scale-[0.98] uppercase tracking-wide"
              >
                <Download className="w-4 h-4 stroke-[2.5]" />
                <span>📲 INSTALL APP</span>
              </button>
            )}

            <button
              onClick={onOpenAi}
              className="bg-indigo-700/80 hover:bg-indigo-700 text-white font-semibold py-3.5 px-5 rounded-2xl border border-indigo-500/50 flex items-center justify-center gap-2 text-sm transition-all"
            >
              <Bot className="w-4 h-4 text-indigo-200" />
              <span>Smart AI Voice</span>
            </button>
          </div>
        </div>

        {/* Feature badges */}
        <div className="mt-6 pt-5 border-t border-indigo-500/40 grid grid-cols-3 gap-2 text-center text-[11px] sm:text-xs text-indigo-100">
          <div className="flex items-center justify-center gap-1.5 font-medium">
            <CheckCircle2 className="w-3.5 h-3.5 text-indigo-200 shrink-0" />
            <span>Exact Rates</span>
          </div>
          <div className="flex items-center justify-center gap-1.5 font-medium">
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-200 shrink-0" />
            <span>Zero Hidden Fees</span>
          </div>
          <div className="flex items-center justify-center gap-1.5 font-medium">
            <WifiOff className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
            <span>100% Offline Ready</span>
          </div>
        </div>
      </div>

      {/* Prominent Install App Banner Card (if not installed) */}
      {!isInstalled && onInstallApp && (
        <div className="bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 rounded-3xl p-5 sm:p-6 text-slate-950 shadow-md border border-amber-400 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3.5 text-center sm:text-left">
            <div className="w-12 h-12 rounded-2xl bg-slate-950 text-amber-400 flex items-center justify-center shrink-0 shadow-md p-1 overflow-hidden">
              <img
                src="/icon.svg"
                alt="App Icon"
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider bg-slate-950 text-white px-2 py-0.5 rounded">
                  ANDROID & MOBILE APP
                </span>
                <span className="text-xs font-bold text-slate-900">• Free & Safe</span>
              </div>
              <h3 className="text-lg font-black text-slate-950 mt-0.5">
                Install "Ceiling Calculation" App on Phone
              </h3>
              <p className="text-xs text-slate-900 font-medium">
                Home screen icon se seedha 1-tap open hoga • Bina internet ke bhi chalega
              </p>
            </div>
          </div>

          <button
            onClick={onInstallApp}
            id="home-install-banner-btn"
            className="w-full sm:w-auto bg-slate-950 hover:bg-slate-900 active:bg-slate-800 text-white font-black py-3.5 px-6 rounded-2xl flex items-center justify-center gap-2 text-sm shadow-xl active:scale-95 transition-all uppercase tracking-wide shrink-0"
          >
            <Download className="w-4 h-4 stroke-[2.5] text-amber-400" />
            <span>📲 INSTALL APP</span>
          </button>
        </div>
      )}

      {/* Category Section Header */}
      <div className="flex items-center justify-between px-1">
        <div>
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Select Type of Work
          </h3>
          <p className="text-sm font-semibold text-slate-800">Categories & Rates</p>
        </div>
        <button
          onClick={onOpenRates}
          className="text-xs font-bold text-indigo-600 hover:text-indigo-700 underline underline-offset-2"
        >
          View Rate Sheet
        </button>
      </div>

      {/* Category Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {categories.map((cat) => {
          const currentRate = rates[cat.id] ?? cat.defaultRate;
          const isConfigured = currentRate !== null && currentRate !== undefined;

          return (
            <div
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className="group bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 hover:border-indigo-600 hover:shadow-lg transition-all cursor-pointer active:scale-[0.99] flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-indigo-50 group-hover:bg-indigo-100 flex items-center justify-center shrink-0 transition-colors border border-indigo-100">
                      {getCategoryIcon(cat.iconName)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-slate-900 group-hover:text-indigo-600 transition-colors text-sm sm:text-base">
                          {cat.name}
                        </h4>
                        {cat.tag && (
                          <span className="text-[10px] uppercase tracking-wider font-bold bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded-md border border-indigo-200">
                            {cat.tag}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 font-medium">{cat.hindiName}</p>
                    </div>
                  </div>

                  {/* Rate Badge */}
                  <div className="text-right shrink-0">
                    {isConfigured ? (
                      <div className="bg-slate-900 text-white font-extrabold text-xs sm:text-sm px-3 py-1 rounded-xl shadow-sm">
                        ₹{currentRate}
                        <span className="text-[10px] font-normal text-slate-300 ml-0.5">/sq ft</span>
                      </div>
                    ) : (
                      <div className="bg-slate-100 text-slate-500 font-medium text-[11px] px-2 py-1 rounded-lg border border-slate-200">
                        Rate not configured
                      </div>
                    )}
                  </div>
                </div>

                <p className="text-xs text-slate-600 mt-3 line-clamp-2 leading-relaxed">
                  {cat.description}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-indigo-600 group-hover:text-indigo-700">
                <span className="text-[11px] text-slate-400 font-normal">
                  {cat.rateNote || "White material rate"}
                </span>
                <span className="flex items-center gap-1">
                  Calculate
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Formula & Calculation Info Box */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 text-xs text-slate-700 space-y-2 shadow-sm">
        <div className="font-bold flex items-center gap-1.5 text-slate-900 text-sm">
          <Calculator className="w-4 h-4 text-indigo-600" />
          <span>Geometric Balance Calculation Formula</span>
        </div>
        <p className="text-slate-600 leading-relaxed">
          <strong>Area (sq ft)</strong> = Length (ft) × Width (ft) <br />
          <strong>Estimated Material Cost</strong> = Total Area × Rate per sq ft <br />
          <em>Example: 10 ft × 12 ft = 120 sq ft. For PVC Ceiling (₹60/sq ft) = 120 × ₹60 = ₹7,200.</em>
        </p>
      </div>

      {/* For Enquiry & Work Contact Section on Home */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 text-white shadow-lg border border-indigo-900/50 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="space-y-1 text-center sm:text-left">
          <span className="text-[10px] uppercase tracking-widest font-extrabold bg-indigo-500/20 text-indigo-300 px-2.5 py-0.5 rounded-full border border-indigo-500/30 inline-block">
            Contractor Helpline
          </span>
          <h4 className="text-base sm:text-lg font-black text-white">For Enquiry & Work Contact</h4>
          <a
            href="tel:9068926728"
            className="text-2xl sm:text-3xl font-black text-emerald-400 hover:text-emerald-300 font-mono tracking-wider block"
          >
            📞 9068926728
          </a>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <a
            href="tel:9068926728"
            className="flex-1 sm:flex-initial bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black py-3 px-5 rounded-2xl flex items-center justify-center gap-2 text-xs sm:text-sm uppercase tracking-wide active:scale-95 transition-all shadow-md shadow-emerald-500/20"
          >
            <Phone className="w-4 h-4 fill-slate-950 text-slate-950" />
            <span>CALL NOW</span>
          </a>
          <a
            href="https://wa.me/919068926728?text=Hello!%20I%20am%20looking%20for%20ceiling%20and%20interior%20work."
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 sm:flex-initial bg-emerald-600 hover:bg-emerald-500 text-white font-black py-3 px-5 rounded-2xl flex items-center justify-center gap-2 text-xs sm:text-sm uppercase tracking-wide active:scale-95 transition-all shadow-md shadow-emerald-600/20"
          >
            <MessageCircle className="w-4 h-4 fill-white text-white" />
            <span>WHATSAPP</span>
          </a>
        </div>
      </div>
    </div>
  );
};
