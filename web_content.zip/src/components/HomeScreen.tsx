import React, { useState } from 'react';
import { 
  Sun, 
  Moon, 
  Layers, 
  Heart, 
  ChevronLeft, 
  CheckCircle2, 
  Info,
  Compass,
  Sparkles,
  Bell,
  Play,
  Zap,
  Clock,
  User
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { MORNING_ADHKAR, EVENING_ADHKAR } from '../data/adhkarData';
import { calculatePrayerTimes, formatRemainingTime } from '../utils/prayerTimesService';
import { getSavedCoordinates } from '../utils/solarTimeService';
import { DedicationBanner } from './DedicationBanner';
import { AppLogo } from './AppLogo';
import { DailyHadeeth } from './DailyHadeeth';

export const HomeScreen: React.FC = () => {
  const { 
    user,
    userCoordinates,
    setActiveTab, 
    setSelectedCategory, 
    openMorningEveningView, 
    openDhikr, 
    progress, 
    favorites, 
    setShowAboutModal,
    setShowTasbeehModal,
    settings,
    updateSettings,
    showToast,
    solarTimes,
    setShowNotificationCenter,
    refreshLocationForSolarTimes
  } = useApp();

  // Effective Day/Night status: in day the sun is glowing, at night the moon appears
  const isEffectiveNight = settings.themeMode === 'auto' ? solarTimes.isNight : settings.darkMode;

  // Calculate morning & evening completed items
  const morningCompleted = MORNING_ADHKAR.filter(d => (progress[d.id] || 0) >= d.count).length;
  const eveningCompleted = EVENING_ADHKAR.filter(d => (progress[d.id] || 0) >= d.count).length;
  const totalCompleted = morningCompleted + eveningCompleted;

  // Determine smart suggestion based on local time
  const currentHour = new Date().getHours();
  const isMorningTime = currentHour >= 3 && currentHour < 15;

  // Compute live prayer times for quick hero card based on live detected coordinates
  const coords = userCoordinates || getSavedCoordinates();
  const prayerResult = calculatePrayerTimes(
    new Date(),
    coords?.latitude || 21.4225,
    coords?.longitude || 39.8262,
    'Makkah',
    coords?.city || 'موقعك الجغرافي'
  );
  const nextPrayer = prayerResult.nextPrayer;

  const startCategoryDirectly = (cat: 'morning' | 'evening', e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const list = cat === 'morning' ? MORNING_ADHKAR : EVENING_ADHKAR;
    const uncompleted = list.find(d => (progress[d.id] || 0) < d.count);
    openDhikr(uncompleted || list[0]);
  };

  return (
    <div className="space-y-3.5 pb-24 text-right">
      {/* 1. Header: Compact Mobile App Bar */}
      <header className="flex items-center justify-between pt-2">
        <div className="flex items-center gap-2.5">
          <AppLogo size={40} withGlow={true} />
          <div>
            <h1 className="text-xl font-black text-amber-600 dark:text-amber-300 font-cairo tracking-tight">
              حصن المسلم
            </h1>
            <p className="text-[11px] font-bold text-emerald-800 dark:text-emerald-300 font-tajawal">
              أذكار المسلم اليومية
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Quick Theme Switcher Button */}
          <button
            onClick={() => {
              if (settings.themeMode === 'auto') {
                updateSettings({ themeMode: 'dark', darkMode: true });
                showToast('الوضع الليلي: يظهر القمر المنير 🌙');
              } else if (settings.themeMode === 'dark') {
                updateSettings({ themeMode: 'light', darkMode: false });
                showToast('الوضع النهاري: الشمس مضيئة وساطعة ☀️');
              } else {
                updateSettings({ themeMode: 'auto' });
                refreshLocationForSolarTimes();
                showToast('الوضع التلقائي: شمس بالنهار وقمر بالليل حسب موقعك 🌅');
              }
            }}
            className={`p-2 rounded-xl border transition-all cursor-pointer relative ${
              isEffectiveNight
                ? 'bg-[#042017] border-emerald-700/80 text-amber-200'
                : 'bg-[#093526] border-amber-500/40 text-amber-400'
            }`}
            title={isEffectiveNight ? 'الليل: القمر منير 🌙' : 'النهار: الشمس مضيئة ☀️'}
            aria-label="تبديل وضع الشاشة"
          >
            {isEffectiveNight ? (
              <Moon className="w-4.5 h-4.5 text-amber-200 fill-amber-300/25" />
            ) : (
              <Sun className="w-4.5 h-4.5 text-amber-400" />
            )}
            {settings.amoledMode && isEffectiveNight && (
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 absolute -top-0.5 -right-0.5" />
            )}
          </button>

          {/* Daily Reminders Button */}
          <button
            onClick={() => setShowNotificationCenter(true)}
            className="p-2 rounded-xl border border-emerald-700/70 bg-[#042017] text-amber-300 hover:bg-[#062c20] transition-colors cursor-pointer relative"
            title="تذكيرات الأذكار"
            aria-label="تذكيرات الأذكار"
          >
            <Bell className="w-4.5 h-4.5 text-amber-300" />
            {settings.notificationsEnabled && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 absolute top-1.5 right-1.5 ring-1 ring-[#042017]" />
            )}
          </button>

          {/* Standalone Digital Tasbeeh Counter Button (المسبحة الإلكترونية) */}
          <button
            onClick={() => setShowTasbeehModal(true)}
            className="p-2 rounded-xl border border-amber-500/40 bg-[#063323] text-amber-300 hover:bg-[#08402c] transition-colors cursor-pointer"
            title="المسبحة الإلكترونية: عداد تسبيح رقمي مع ميزة الاهتزاز وحفظ العدد"
            aria-label="المسبحة الإلكترونية"
          >
            <Sparkles className="w-4.5 h-4.5 text-amber-300" />
          </button>

          {/* User Account / Google Sync Button */}
          <button
            onClick={() => setActiveTab('settings')}
            className={`p-1.5 rounded-xl border transition-all cursor-pointer flex items-center justify-center ${
              user 
                ? 'border-emerald-500/60 bg-emerald-950/60 text-emerald-300 ring-1 ring-emerald-400/30' 
                : 'border-emerald-700/70 bg-[#042017] text-emerald-400 hover:bg-[#062c20]'
            }`}
            title={user ? `المستخدم: ${user.displayName || user.email}` : 'تسجيل الدخول ومزامنة الأذكار'}
            aria-label="حساب المستخدم ومزامنة السحاب"
          >
            {user?.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.displayName || 'حساب المستخدم'}
                className="w-5 h-5 rounded-lg object-cover"
              />
            ) : (
              <User className="w-4.5 h-4.5" />
            )}
          </button>

          {/* About App Button */}
          <button
            onClick={() => setShowAboutModal(true)}
            className="p-2 rounded-xl border border-emerald-700/70 bg-[#042017] text-amber-400 hover:bg-[#062c20] transition-colors cursor-pointer"
            title="عن التطبيق"
            aria-label="عن التطبيق"
          >
            <Info className="w-4.5 h-4.5" />
          </button>
        </div>
      </header>

      {/* 2. Dedication Banner (Required) */}
      <DedicationBanner />

      {/* 3. Compact Celestial & Sun/Moon Ribbon (شريط الوقت وحالة الشمس والقمر) */}
      <div 
        onClick={() => {
          if (settings.themeMode === 'auto') {
            updateSettings({ themeMode: 'dark', darkMode: true });
            showToast('الوضع الليلي: يظهر القمر 🌙');
          } else if (settings.themeMode === 'dark') {
            updateSettings({ themeMode: 'light', darkMode: false });
            showToast('الوضع النهاري: تضيء الشمس ☀️');
          } else {
            updateSettings({ themeMode: 'auto' });
            showToast('الوضع التلقائي: حسب شروق وغروب الشمس 🌅');
          }
        }}
        className="w-full py-1.5 px-3 rounded-xl border bg-[#032017]/90 border-emerald-800/60 flex items-center justify-between text-xs cursor-pointer select-none transition-colors hover:border-emerald-600/80"
        title="اضغط لتغيير وضع النهار/الليل"
      >
        <div className="flex items-center gap-2">
          {isEffectiveNight ? (
            <div className="flex items-center gap-1.5 text-amber-200 font-bold font-cairo">
              <Moon className="w-3.5 h-3.5 fill-amber-200/30 text-amber-300 shrink-0" />
              <span>{isMorningTime ? 'وقت الصباح ☀️' : 'وقت المساء والليل 🌙'}</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 text-amber-300 font-bold font-cairo">
              <Sun className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>{isMorningTime ? 'وقت الصباح المبارك ☀️' : 'وقت المساء 🌙'}</span>
            </div>
          )}
          <span className="text-[10px] text-[#84b8a0] font-tajawal hidden sm:inline">
            • {isEffectiveNight ? `الغروب ${solarTimes.sunsetFormatted}` : `الشروق ${solarTimes.sunriseFormatted}`}
          </span>
        </div>

        <div className="flex items-center gap-1.5 text-emerald-300 font-bold font-cairo text-[11px]">
          <span>إجمالي اليوم:</span>
          <span className="text-amber-300 font-mono">{totalCompleted}/46</span>
        </div>
      </div>

      {/* 4. MAIN ACTION CHOICES: Morning & Evening Direct Launch Cards (بطاقات التحويل المباشر للصباح والمساء) */}
      <div className="grid grid-cols-2 gap-2.5">
        {/* أذكار الصباح */}
        <div
          onClick={() => openMorningEveningView('morning')}
          className={`p-3.5 rounded-2xl border text-right transition-all cursor-pointer flex flex-col justify-between relative group ${
            isMorningTime
              ? 'bg-gradient-to-br from-[#093526] to-[#042017] border-amber-400/50 shadow-md ring-1 ring-amber-400/30'
              : 'bg-[#ffffff] dark:bg-[#042017] border-emerald-600/15 dark:border-emerald-800/80 hover:border-emerald-600'
          }`}
        >
          {isMorningTime && (
            <span className="absolute -top-2 left-2 text-[9px] font-bold bg-amber-400 text-[#0c2e20] px-2 py-0.5 rounded-full font-cairo shadow-xs">
              الوقت المستحب ☀️
            </span>
          )}

          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-400/30 flex items-center justify-center">
                <Sun className="w-5 h-5 text-amber-400" />
              </div>
              <span className="text-[11px] font-bold text-amber-300 font-mono bg-black/30 px-2 py-0.5 rounded-lg border border-amber-500/20">
                {morningCompleted}/24
              </span>
            </div>

            <h2 className="text-base font-extrabold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo group-hover:text-amber-300 transition-colors">
              أذكار الصباح
            </h2>
            <p className="text-[10px] text-[#4d7d67] dark:text-[#84b8a0] font-tajawal mt-0.5">
              ٢٤ ذكراً ودعاءً مباركاً
            </p>
          </div>

          <div className="mt-3 pt-2.5 border-t border-emerald-800/40 flex items-center justify-between">
            {/* Quick Play direct to dhikr */}
            <button
              onClick={(e) => startCategoryDirectly('morning', e)}
              className="px-2 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-[11px] font-bold font-cairo flex items-center gap-1 transition-colors cursor-pointer"
              title="بدء القراءة فوراً"
            >
              <Play className="w-3 h-3 fill-amber-300" />
              <span>{morningCompleted > 0 ? 'متابعة' : 'قراءة'}</span>
            </button>

            <span className="text-[11px] font-bold text-emerald-400 font-cairo flex items-center gap-0.5 group-hover:translate-x-[-2px] transition-transform">
              <span>عرض</span>
              <ChevronLeft className="w-3.5 h-3.5" />
            </span>
          </div>
        </div>

        {/* أذكار المساء */}
        <div
          onClick={() => openMorningEveningView('evening')}
          className={`p-3.5 rounded-2xl border text-right transition-all cursor-pointer flex flex-col justify-between relative group ${
            !isMorningTime
              ? 'bg-gradient-to-br from-[#093526] to-[#042017] border-emerald-400/50 shadow-md ring-1 ring-emerald-400/30'
              : 'bg-[#ffffff] dark:bg-[#042017] border-emerald-600/15 dark:border-emerald-800/80 hover:border-emerald-600'
          }`}
        >
          {!isMorningTime && (
            <span className="absolute -top-2 left-2 text-[9px] font-bold bg-emerald-400 text-[#0c2e20] px-2 py-0.5 rounded-full font-cairo shadow-xs">
              الوقت المستحب 🌙
            </span>
          )}

          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center justify-center">
                <Moon className="w-5 h-5 text-amber-200 fill-amber-200/30" />
              </div>
              <span className="text-[11px] font-bold text-emerald-300 font-mono bg-black/30 px-2 py-0.5 rounded-lg border border-emerald-500/20">
                {eveningCompleted}/22
              </span>
            </div>

            <h2 className="text-base font-extrabold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo group-hover:text-emerald-300 transition-colors">
              أذكار المساء
            </h2>
            <p className="text-[10px] text-[#4d7d67] dark:text-[#84b8a0] font-tajawal mt-0.5">
              ٢٢ ذكراً للسكينة والحفظ
            </p>
          </div>

          <div className="mt-3 pt-2.5 border-t border-emerald-800/40 flex items-center justify-between">
            {/* Quick Play direct to dhikr */}
            <button
              onClick={(e) => startCategoryDirectly('evening', e)}
              className="px-2 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 text-[11px] font-bold font-cairo flex items-center gap-1 transition-colors cursor-pointer"
              title="بدء القراءة فوراً"
            >
              <Play className="w-3 h-3 fill-emerald-300" />
              <span>{eveningCompleted > 0 ? 'متابعة' : 'قراءة'}</span>
            </button>

            <span className="text-[11px] font-bold text-emerald-400 font-cairo flex items-center gap-0.5 group-hover:translate-x-[-2px] transition-transform">
              <span>عرض</span>
              <ChevronLeft className="w-3.5 h-3.5" />
            </span>
          </div>
        </div>
      </div>

      {/* 4.5 DAILY HADEETH FOR SPIRITUAL INSPIRATION (حديث اليوم النبوي الشريف) */}
      <DailyHadeeth />

      {/* 5. DUAL-VIEW SPECIALIZED HUB (زر التحويل السريع للعرض المتخصص للصباح والمساء) */}
      <button
        onClick={() => openMorningEveningView(isMorningTime ? 'morning' : 'evening')}
        className="w-full p-3 rounded-2xl bg-gradient-to-r from-[#03261b] via-[#053d2b] to-[#03261b] border border-amber-400/40 hover:border-amber-400 flex items-center justify-between text-right transition-all cursor-pointer shadow-xs group"
      >
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-400/30 flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4 text-amber-300" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-extrabold text-[#e8f5ee] font-cairo group-hover:text-amber-200">
                العرض المتخصص للصباح والمساء
              </span>
              <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-400/20 text-amber-300 font-bold font-tajawal">
                تنقل فوري ⚡
              </span>
            </div>
            <p className="text-[10px] text-[#84b8a0] font-tajawal">
              التبديل بنقرة واحدة بين الأذكار مع عداد إلكتروني متكامل
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1 text-[11px] font-bold text-amber-300 font-cairo shrink-0 group-hover:translate-x-[-2px] transition-transform">
          <span>دخول</span>
          <ChevronLeft className="w-3.5 h-3.5" />
        </div>
      </button>

      {/* 5.5 PRAYER TIMES LIVE COUNTDOWN CARD (مواقيت الصلاة والعد التنازلي) */}
      <button
        onClick={() => setActiveTab('prayer_times')}
        className="w-full p-3 rounded-2xl bg-gradient-to-r from-[#03291d] via-[#053d2c] to-[#03291d] border border-amber-400/40 hover:border-amber-300 flex items-center justify-between text-right transition-all cursor-pointer shadow-xs group"
      >
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-400/30 flex items-center justify-center shrink-0">
            <Clock className="w-4 h-4 text-amber-300" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-extrabold text-[#e8f5ee] font-cairo group-hover:text-amber-200">
                مواقيت الصلاة: صلاة {nextPrayer.nameArabic}
              </span>
              <span className="text-[10px] text-amber-300 font-mono font-bold bg-black/40 px-1.5 py-0.2 rounded border border-amber-400/20">
                {nextPrayer.timeFormatted}
              </span>
            </div>
            <p className="text-[10px] text-emerald-300 font-tajawal mt-0.5">
              متبقي: <strong className="text-amber-200 font-mono">{nextPrayer.remainingFormatted}</strong> • {prayerResult.city}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1 text-[11px] font-bold text-amber-300 font-cairo shrink-0 group-hover:translate-x-[-2px] transition-transform">
          <span>عرض المواقيت</span>
          <ChevronLeft className="w-3.5 h-3.5" />
        </div>
      </button>

      {/* 6. QUICK DESTINATION TILES (4 اختيارات رئيسية تحولك مباشرة للهدف) */}
      <div className="grid grid-cols-4 gap-2">
        {/* مواقيت الصلاة */}
        <button
          onClick={() => setActiveTab('prayer_times')}
          className="bg-[#ffffff] dark:bg-[#042017] border border-amber-500/25 dark:border-amber-500/30 rounded-2xl p-2 text-center hover:border-amber-400 transition-all shadow-xs cursor-pointer flex flex-col items-center justify-center gap-1 group"
        >
          <div className="w-8 h-8 rounded-xl bg-amber-500/15 dark:bg-[#0d2e20] text-amber-400 border border-amber-500/30 flex items-center justify-center group-hover:scale-105 transition-transform">
            <Clock className="w-4 h-4" />
          </div>
          <span className="text-[11px] font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
            المواقيت
          </span>
          <span className="text-[8px] text-amber-400/90 font-mono">
            {nextPrayer.nameArabic}
          </span>
        </button>

        {/* جميع الأذكار */}
        <button
          onClick={() => {
            setSelectedCategory('all');
            setActiveTab('list');
          }}
          className="bg-[#ffffff] dark:bg-[#042017] border border-emerald-600/15 dark:border-emerald-800/80 rounded-2xl p-2 text-center hover:border-emerald-500 transition-all shadow-xs cursor-pointer flex flex-col items-center justify-center gap-1 group"
        >
          <div className="w-8 h-8 rounded-xl bg-emerald-700/15 dark:bg-[#083526] text-emerald-700 dark:text-emerald-300 border border-emerald-600/30 flex items-center justify-center group-hover:scale-105 transition-transform">
            <Layers className="w-4 h-4" />
          </div>
          <span className="text-[11px] font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
            الأذكار
          </span>
          <span className="text-[8px] text-[#4d7d67] dark:text-[#84b8a0] font-tajawal">
            ٤٦ ذكراً
          </span>
        </button>

        {/* بوصلة القبلة */}
        <button
          onClick={() => setActiveTab('qibla')}
          className="bg-[#ffffff] dark:bg-[#042017] border border-emerald-600/15 dark:border-emerald-800/80 rounded-2xl p-2 text-center hover:border-emerald-500 transition-all shadow-xs cursor-pointer flex flex-col items-center justify-center gap-1 group"
        >
          <div className="w-8 h-8 rounded-xl bg-emerald-700/15 dark:bg-[#083526] text-emerald-700 dark:text-emerald-300 border border-emerald-600/30 flex items-center justify-center group-hover:scale-105 transition-transform">
            <Compass className="w-4 h-4" />
          </div>
          <span className="text-[11px] font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
            القبلة
          </span>
          <span className="text-[8px] text-[#4d7d67] dark:text-[#84b8a0] font-tajawal">
            الكعبة 🕋
          </span>
        </button>

        {/* المفضلة */}
        <button
          onClick={() => setActiveTab('favorites')}
          className="bg-[#ffffff] dark:bg-[#042017] border border-emerald-600/15 dark:border-emerald-800/80 rounded-2xl p-2 text-center hover:border-emerald-500 transition-all shadow-xs cursor-pointer flex flex-col items-center justify-center gap-1 group"
        >
          <div className="w-8 h-8 rounded-xl bg-red-500/15 dark:bg-red-950/40 text-red-500 border border-red-300/30 flex items-center justify-center group-hover:scale-105 transition-transform">
            <Heart className="w-4 h-4 fill-red-500/20 text-red-500" />
          </div>
          <span className="text-[11px] font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
            المفضلة
          </span>
          <span className="text-[8px] text-red-400 font-mono">
            {favorites.length} أذكار
          </span>
        </button>
      </div>
    </div>
  );
};
