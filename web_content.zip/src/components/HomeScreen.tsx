import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  Search,
  Settings as SettingsIcon,
  Ghost,
} from 'lucide-react';
import { ConsoleStoreIcon, ConsoleLibraryIcon } from './icons/ConsoleIcons';
import {
  HomeOverlay,
  HomeTileId,
  Profile,
  SystemSettings,
  WallpaperOption,
} from '../types/system';
import { soundEngine } from '../audio/soundEngine';
import { screenReader } from '../audio/screenReader';
import { useSwipeNavigation } from '../hooks/useSwipeNavigation';
import { WallpaperBackdrop } from './WallpaperBackdrop';
import { GameStoreOverlay } from './overlays/GameStoreOverlay';
import { GameLibraryOverlay } from './overlays/GameLibraryOverlay';
import { SearchOverlay } from './overlays/SearchOverlay';
import { SettingsOverlay } from './overlays/SettingsOverlay';
import { ProfileOverlay } from './overlays/ProfileOverlay';

interface HomeScreenProps {
  profile: Profile;
  wallpaper: WallpaperOption;
  settings: SystemSettings;
  onUpdateSettings: (next: SystemSettings) => void;
  onRecordProgress: (xpAmount: number, milestone?: string) => void;
  onSwitchProfile: () => void;
  onReplayStartup: () => void;
  onToggleFullscreen: () => void;
  isFullscreen: boolean;
  isRotatedPortrait?: boolean;
  onUnlockAudio: () => void;
}

const TILE_ORDER: HomeTileId[] = [
  'game-store',
  'game-library',
  'search',
  'settings',
  'profile',
];

function formatCurrentTime(): string {
  return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  profile,
  wallpaper,
  settings,
  onUpdateSettings,
  onRecordProgress,
  onSwitchProfile,
  onReplayStartup,
  onToggleFullscreen,
  isFullscreen,
  isRotatedPortrait = false,
  onUnlockAudio,
}) => {
  const [highlightedTile, setHighlightedTile] = useState<HomeTileId | null>('game-store');
  const highlightedTileRef = useRef<HomeTileId | null>('game-store');
  highlightedTileRef.current = highlightedTile;
  const [activeOverlay, setActiveOverlay] = useState<HomeOverlay>('NONE');
  const [avatarError, setAvatarError] = useState(false);
  const [timeText, setTimeText] = useState(formatCurrentTime);
  const lastWheelStepRef = useRef(0);

  const tileMeta = useMemo<
    Record<
      HomeTileId,
      { title: string; description: string; speech: string; overlay: HomeOverlay }
    >
  >(
    () => ({
      'game-store': {
        title: 'Game Store',
        description: 'Browse digital releases and system titles · 0 titles available',
        speech:
          'Game Store. Browse upcoming digital releases and classic console titles. Currently zero titles available. Double-tap to open.',
        overlay: 'GAME_STORE',
      },
      'game-library': {
        title: 'Game Library',
        description: `Launch installed games on ${profile.name} · ${profile.gamesCount} games installed`,
        speech: `Game Library. View and launch games saved to ${profile.name}. Currently ${profile.gamesCount} games installed. Double-tap to open.`,
        overlay: 'GAME_LIBRARY',
      },
      search: {
        title: 'Search',
        description: 'Find titles across your Game Library and Game Store',
        speech:
          'Search. Quickly search for games across your Store and Library. Double-tap to open.',
        overlay: 'SEARCH',
      },
      settings: {
        title: 'Settings',
        description: `Customize ${profile.name}'s wallpaper, music, 8-bit effects, and voice reader`,
        speech: `System Settings. Customize wallpapers, background music, 8-bit sound effects, and voice screen reader for ${profile.name}. Double-tap to open.`,
        overlay: 'SETTINGS',
      },
      profile: {
        title: 'Profile',
        description: `Level ${profile.progression.level} · ${profile.progression.xp}/${profile.progression.xpToNext} XP · Switch or inspect player`,
        speech: `Active Profile, ${profile.name}. Level ${profile.progression.level}. Inspect your saved progression or return to profile selection. Double-tap to open.`,
        overlay: 'PROFILE',
      },
    }),
    [
      profile.name,
      profile.gamesCount,
      profile.progression.level,
      profile.progression.xp,
      profile.progression.xpToNext,
    ]
  );

  useEffect(() => {
    setAvatarError(false);
  }, [profile.avatarUrl]);

  // Single minute-aligned timeout keeps background activity idle on the Home Screen
  useEffect(() => {
    let timeoutId: number;
    const scheduleNextMinute = () => {
      const now = new Date();
      const msUntilNextMinute =
        (60 - now.getSeconds()) * 1000 - now.getMilliseconds() + 50;
      timeoutId = window.setTimeout(() => {
        setTimeText(formatCurrentTime());
        scheduleNextMinute();
      }, Math.max(1000, msUntilNextMinute));
    };
    scheduleNextMinute();
    return () => window.clearTimeout(timeoutId);
  }, []);

  // Fancy dashboard boot chime + piano ambience
  useEffect(() => {
    soundEngine.startMusic('home');
    soundEngine.playHomeUnlock();

    const greetTimer = window.setTimeout(() => {
      screenReader.speak(
        `Welcome back, ${profile.name}. Dashboard ready. Game Store is highlighted. Double-tap to open.`,
        { immediate: true }
      );
    }, 280);

    return () => window.clearTimeout(greetTimer);
    // Run on initial profile login into dashboard
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const activateTile = useCallback(
    (tileId: HomeTileId) => {
      onUnlockAudio();
      soundEngine.playSelect();
      setActiveOverlay(tileMeta[tileId].overlay);
    },
    [onUnlockAudio, tileMeta]
  );

  const stepTile = useCallback(
    (direction: 'left' | 'right') => {
      onUnlockAudio();
      const prev = highlightedTileRef.current;
      const nextId = !prev
        ? direction === 'left'
          ? TILE_ORDER[TILE_ORDER.length - 1]
          : TILE_ORDER[0]
        : TILE_ORDER[
            direction === 'right'
              ? (TILE_ORDER.indexOf(prev) + 1) % TILE_ORDER.length
              : (TILE_ORDER.indexOf(prev) - 1 + TILE_ORDER.length) % TILE_ORDER.length
          ];

      highlightedTileRef.current = nextId;
      setHighlightedTile(nextId);

      if (direction === 'left') soundEngine.playScrollLeft();
      else soundEngine.playScrollRight();
      screenReader.speak(tileMeta[nextId].speech, { immediate: true });
    },
    [onUnlockAudio, tileMeta]
  );

  const { swipeHandlers, shouldSuppressClick } = useSwipeNavigation({
    onSwipeLeft: () => stepTile('left'),
    onSwipeRight: () => stepTile('right'),
    isRotatedPortrait,
    stepPx: 54,
    disabled: activeOverlay !== 'NONE',
  });

  const handleTileTap = (tileId: HomeTileId) => {
    if (shouldSuppressClick()) return;
    onUnlockAudio();
    if (highlightedTile === tileId) {
      activateTile(tileId);
      return;
    }

    if (highlightedTile) {
      const prevIdx = TILE_ORDER.indexOf(highlightedTile);
      const nextIdx = TILE_ORDER.indexOf(tileId);
      if (nextIdx > prevIdx) soundEngine.playScrollRight();
      else if (nextIdx < prevIdx) soundEngine.playScrollLeft();
      else soundEngine.playHighlight();
    } else {
      soundEngine.playHighlight();
    }
    highlightedTileRef.current = tileId;
    setHighlightedTile(tileId);
    screenReader.speak(tileMeta[tileId].speech, { immediate: true });
  };

  const handleWheel = (e: React.WheelEvent) => {
    if (activeOverlay !== 'NONE') return;
    const dominantX = Math.abs(e.deltaX) >= Math.abs(e.deltaY) ? e.deltaX : 0;
    const delta = dominantX !== 0 ? dominantX : e.shiftKey ? e.deltaY : 0;
    if (Math.abs(delta) < 14) return;

    const now = performance.now();
    if (now - lastWheelStepRef.current < 160) return;
    lastWheelStepRef.current = now;

    if (delta > 0) stepTile('right');
    else stepTile('left');
  };

  const closeOverlay = useCallback(() => {
    setActiveOverlay('NONE');
    if (highlightedTile) {
      screenReader.speak(`Returned to dashboard. ${tileMeta[highlightedTile].title} highlighted.`);
    } else {
      screenReader.speak('Returned to dashboard.');
    }
  }, [highlightedTile, tileMeta]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (activeOverlay !== 'NONE') {
        if (e.key === 'Escape') {
          e.preventDefault();
          soundEngine.playBack();
          closeOverlay();
        }
        return;
      }

      if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        e.preventDefault();
        stepTile('right');
      } else if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        e.preventDefault();
        stepTile('left');
      } else if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        if (highlightedTile) {
          activateTile(highlightedTile);
        } else {
          highlightedTileRef.current = 'game-store';
          setHighlightedTile('game-store');
          soundEngine.playHighlight();
          screenReader.speak(tileMeta['game-store'].speech);
        }
      } else if (e.key === 'Escape' && highlightedTile) {
        e.preventDefault();
        highlightedTileRef.current = null;
        setHighlightedTile(null);
        soundEngine.playBack();
        screenReader.speak('Selection cleared.');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeOverlay, highlightedTile, activateTile, stepTile, closeOverlay, tileMeta]);

  const activeMeta = highlightedTile ? tileMeta[highlightedTile] : null;
  const xpPct = Math.min(
    100,
    Math.round((profile.progression.xp / Math.max(1, profile.progression.xpToNext)) * 100)
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      {...swipeHandlers}
      onWheel={handleWheel}
      className="relative w-full h-full flex flex-col justify-between overflow-hidden bg-[#060911] touch-none"
    >
      {/* Stage 1: Fancy Smooth Wallpaper Iris-Reveal + Horizon Light Sweep */}
      <motion.div
        initial={{ opacity: 0, scale: 1.07 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.68, ease: [0.16, 1, 0.3, 1] }}
        className="absolute inset-0"
      >
        <WallpaperBackdrop wallpaperId={wallpaper.id} />
        <div className="absolute inset-0 bg-gradient-to-b from-black/55 via-black/15 to-black/72" />
      </motion.div>

      {/* Transient Cobalt Boot Horizon Line (runs once on mount, fades cleanly) */}
      <motion.div
        initial={{ scaleX: 0, opacity: 0.9 }}
        animate={{ scaleX: 1, opacity: 0 }}
        transition={{ duration: 0.72, ease: [0.16, 1, 0.3, 1] }}
        className="pointer-events-none absolute top-1/2 inset-x-0 h-[2px] z-10 origin-center bg-gradient-to-r from-transparent via-sky-300 to-transparent"
      />

      {/* TOP BAR: All Tiles Slide & Settle Choreographed From Right to Left */}
      <header className="relative z-20 w-full px-8 md:px-10 pt-6 flex items-start justify-between gap-6">
        {/* Top-Left: Only Two Primary Tiles (Game Store & Game Library) */}
        <div className="flex items-start gap-4">
          {/* Tile 1: Game Store */}
          <motion.div
            initial={{ opacity: 0, x: 210, scale: 0.94 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.52, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
          >
            <button
              type="button"
              onClick={() => handleTileTap('game-store')}
              aria-pressed={highlightedTile === 'game-store'}
              className={`group relative w-32 h-32 md:w-36 md:h-36 aspect-square flex flex-col items-start justify-between p-4 text-left transition-all duration-150 cursor-pointer focus:outline-none ${
                highlightedTile === 'game-store'
                  ? 'bg-[#0d182b]/95 border-2 border-sky-400 shadow-[0_0_26px_rgba(56,189,248,0.32)] scale-[1.03]'
                  : 'bg-[#09101d]/88 border border-white/18 hover:border-sky-300/55'
              }`}
            >
              <div
                className={`w-11 h-11 flex items-center justify-center border transition-colors ${
                  highlightedTile === 'game-store'
                    ? 'bg-sky-400 text-slate-950 border-sky-200'
                    : 'bg-sky-500/12 text-sky-300 border-sky-400/25'
                }`}
              >
                <ConsoleStoreIcon className="w-6 h-6" />
              </div>
              <div>
                <div className="font-display text-sm md:text-base font-semibold text-white whitespace-nowrap">
                  Game Store
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5 whitespace-nowrap">
                  {highlightedTile === 'game-store' ? 'Tap again to open' : '0 titles'}
                </div>
              </div>
            </button>
          </motion.div>

          {/* Tile 2: Game Library */}
          <motion.div
            initial={{ opacity: 0, x: 210, scale: 0.94 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.52, delay: 0.14, ease: [0.16, 1, 0.3, 1] }}
          >
            <button
              type="button"
              onClick={() => handleTileTap('game-library')}
              aria-pressed={highlightedTile === 'game-library'}
              className={`group relative w-32 h-32 md:w-36 md:h-36 aspect-square flex flex-col items-start justify-between p-4 text-left transition-all duration-150 cursor-pointer focus:outline-none ${
                highlightedTile === 'game-library'
                  ? 'bg-[#0d182b]/95 border-2 border-sky-400 shadow-[0_0_26px_rgba(56,189,248,0.32)] scale-[1.03]'
                  : 'bg-[#09101d]/88 border border-white/18 hover:border-sky-300/55'
              }`}
            >
              <div
                className={`w-11 h-11 flex items-center justify-center border transition-colors ${
                  highlightedTile === 'game-library'
                    ? 'bg-sky-400 text-slate-950 border-sky-200'
                    : 'bg-sky-500/12 text-sky-300 border-sky-400/25'
                }`}
              >
                <ConsoleLibraryIcon className="w-6 h-6" />
              </div>
              <div>
                <div className="font-display text-sm md:text-base font-semibold text-white whitespace-nowrap">
                  Game Library
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5 whitespace-nowrap">
                  {highlightedTile === 'game-library'
                    ? 'Tap again to open'
                    : `${profile.gamesCount} installed`}
                </div>
              </div>
            </button>
          </motion.div>
        </div>

        {/* Top-Right: Search, Settings, Profile */}
        <div className="flex items-start gap-3">
          {/* Search Tile */}
          <motion.div
            initial={{ opacity: 0, x: 165, scale: 0.92 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.52, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          >
            <button
              type="button"
              onClick={() => handleTileTap('search')}
              aria-label="Search"
              aria-pressed={highlightedTile === 'search'}
              className={`w-14 h-14 md:w-16 md:h-16 aspect-square flex flex-col items-center justify-center gap-1 transition-all duration-150 cursor-pointer focus:outline-none ${
                highlightedTile === 'search'
                  ? 'bg-sky-400 text-slate-950 border-2 border-sky-200 shadow-[0_0_22px_rgba(56,189,248,0.35)] scale-[1.04]'
                  : 'bg-[#09101d]/88 text-sky-300 border border-white/18 hover:border-sky-300/55'
              }`}
            >
              <Search className="w-5 h-5" />
              <span
                className={`text-[10px] font-medium leading-none ${
                  highlightedTile === 'search' ? 'text-slate-950' : 'text-slate-200'
                }`}
              >
                Search
              </span>
            </button>
          </motion.div>

          {/* Settings Tile */}
          <motion.div
            initial={{ opacity: 0, x: 165, scale: 0.92 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.52, delay: 0.26, ease: [0.16, 1, 0.3, 1] }}
          >
            <button
              type="button"
              onClick={() => handleTileTap('settings')}
              aria-label="Settings"
              aria-pressed={highlightedTile === 'settings'}
              className={`w-14 h-14 md:w-16 md:h-16 aspect-square flex flex-col items-center justify-center gap-1 transition-all duration-150 cursor-pointer focus:outline-none ${
                highlightedTile === 'settings'
                  ? 'bg-sky-400 text-slate-950 border-2 border-sky-200 shadow-[0_0_22px_rgba(56,189,248,0.35)] scale-[1.04]'
                  : 'bg-[#09101d]/88 text-sky-300 border border-white/18 hover:border-sky-300/55'
              }`}
            >
              <SettingsIcon className="w-5 h-5" />
              <span
                className={`text-[10px] font-medium leading-none ${
                  highlightedTile === 'settings' ? 'text-slate-950' : 'text-slate-200'
                }`}
              >
                Settings
              </span>
            </button>
          </motion.div>

          {/* Profile Tile */}
          <motion.div
            initial={{ opacity: 0, x: 165, scale: 0.92 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.52, delay: 0.32, ease: [0.16, 1, 0.3, 1] }}
          >
            <button
              type="button"
              onClick={() => handleTileTap('profile')}
              aria-label={`Profile: ${profile.name}`}
              aria-pressed={highlightedTile === 'profile'}
              className={`relative w-14 h-14 md:w-16 md:h-16 aspect-square overflow-hidden transition-all duration-150 cursor-pointer focus:outline-none ${
                highlightedTile === 'profile'
                  ? 'border-2 border-sky-400 shadow-[0_0_22px_rgba(56,189,248,0.38)] scale-[1.04] bg-[#0d182b]'
                  : 'border border-white/25 hover:border-sky-300/60 bg-[#09101d]'
              }`}
            >
              {!avatarError ? (
                <img
                  src={profile.avatarUrl}
                  alt={profile.name}
                  referrerPolicy="no-referrer"
                  draggable={false}
                  onError={() => setAvatarError(true)}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Ghost className="w-6 h-6 text-sky-300" />
                </div>
              )}
            </button>
          </motion.div>
        </div>
      </header>

      {/* Stage 3: Smooth Bottom Caption + Saved Progression Pill + Clock */}
      <motion.footer
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.48, delay: 0.24, ease: [0.16, 1, 0.3, 1] }}
        className="relative z-20 w-full px-8 md:px-10 pb-7 flex items-end justify-between gap-6"
      >
        <div className="max-w-xl">
          <div className="flex items-center gap-3 mb-1.5">
            <span className="text-xs font-medium text-sky-300">
              Retro Game System · {profile.name}
            </span>
            <span className="text-[11px] font-mono-tabular text-slate-300 bg-[#09101d]/85 border border-white/15 px-2 py-0.5">
              Lv.{profile.progression.level} · {xpPct}% XP
            </span>
          </div>

          {activeMeta ? (
            <>
              <h1 className="font-display text-3xl md:text-4xl font-semibold tracking-tight text-white">
                {activeMeta.title}
              </h1>
              <p className="text-sm text-slate-300 mt-1.5">
                {activeMeta.description}
              </p>
              <p className="text-xs text-slate-400 mt-2">
                Swipe left or right to browse · Double-tap or press Enter to open
              </p>
            </>
          ) : (
            <>
              <h1 className="font-display text-3xl md:text-4xl font-semibold tracking-tight text-white">
                Home
              </h1>
              <p className="text-sm text-slate-300 mt-1.5">
                Swipe left or right, or tap any tile once to highlight and double-tap to launch.
              </p>
            </>
          )}
        </div>

        <div className="text-right shrink-0">
          <div className="font-mono-tabular text-2xl font-medium text-white">
            {timeText}
          </div>
          <div className="text-xs text-slate-400 mt-0.5">
            {wallpaper.name}
          </div>
        </div>
      </motion.footer>

      {/* Active Sub-Screen Overlays */}
      <AnimatePresence>
        {activeOverlay === 'GAME_STORE' && (
          <GameStoreOverlay onClose={closeOverlay} />
        )}
        {activeOverlay === 'GAME_LIBRARY' && (
          <GameLibraryOverlay
            profile={profile}
            onClose={closeOverlay}
            onOpenStore={() => setActiveOverlay('GAME_STORE')}
          />
        )}
        {activeOverlay === 'SEARCH' && (
          <SearchOverlay onClose={closeOverlay} />
        )}
        {activeOverlay === 'SETTINGS' && (
          <SettingsOverlay
            profileName={profile.name}
            settings={settings}
            onUpdateSettings={onUpdateSettings}
            onReplayStartup={onReplayStartup}
            onToggleFullscreen={onToggleFullscreen}
            isFullscreen={isFullscreen}
            isRotatedPortrait={isRotatedPortrait}
            onClose={closeOverlay}
          />
        )}
        {activeOverlay === 'PROFILE' && (
          <ProfileOverlay
            profile={profile}
            wallpaper={wallpaper}
            onRecordProgress={onRecordProgress}
            onSwitchProfile={() => {
              setActiveOverlay('NONE');
              onSwitchProfile();
            }}
            onClose={closeOverlay}
          />
        )}
      </AnimatePresence>
    </motion.div>
  );
};
