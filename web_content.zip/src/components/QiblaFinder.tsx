import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Compass, 
  MapPin, 
  RotateCw, 
  CheckCircle2, 
  AlertCircle, 
  Info, 
  Search, 
  X,
  Volume2,
  VolumeX,
  Vibrate,
  Navigation,
  Sparkles
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { 
  calculateQiblaDirection, 
  POPULAR_CITIES, 
  CityPreset, 
  QiblaResult 
} from '../utils/qiblaService';
import { 
  getSavedCoordinates, 
  requestCoordinates, 
  UserCoordinates 
} from '../utils/solarTimeService';
import { triggerVibration, playMilestoneSound } from '../utils/audioFeedback';

export const QiblaFinder: React.FC = () => {
  const { 
    settings, 
    updateSettings, 
    showToast, 
    userCoordinates, 
    refreshLocationForSolarTimes, 
    isDetectingLocation 
  } = useApp();

  // Location state synced with userCoordinates
  const [coords, setCoords] = useState<UserCoordinates | null>(() => {
    return userCoordinates || getSavedCoordinates() || { latitude: 21.4225, longitude: 39.8262, city: 'مكة المكرمة' };
  });
  const [selectedCityName, setSelectedCityName] = useState<string>(() => userCoordinates?.city || 'موقعك الجغرافي');
  const [showCityModal, setShowCityModal] = useState<boolean>(false);
  const [citySearchQuery, setCitySearchQuery] = useState<string>('');

  // Automatically update when userCoordinates is updated from internet / GPS
  useEffect(() => {
    if (userCoordinates) {
      setCoords(userCoordinates);
      setSelectedCityName(userCoordinates.city || 'موقعك الحالي');
    }
  }, [userCoordinates]);

  // Sensor state
  const [compassHeading, setCompassHeading] = useState<number | null>(null);
  const [sensorAvailable, setSensorAvailable] = useState<boolean>(false);
  const [permissionNeeded, setPermissionNeeded] = useState<boolean>(false);
  const [hasAlignedVibrated, setHasAlignedVibrated] = useState<boolean>(false);

  // Manual compass simulator angle when sensor is not available
  const [manualAngle, setManualAngle] = useState<number>(0);

  // Calculate Qibla data
  const qiblaData: QiblaResult = React.useMemo(() => {
    const lat = coords?.latitude ?? 30.0444;
    const lng = coords?.longitude ?? 31.2357;
    return calculateQiblaDirection(lat, lng);
  }, [coords]);

  // Current effective heading (sensor or manual slider)
  const currentHeading = compassHeading !== null ? compassHeading : manualAngle;

  // Bearing of Qibla relative to current phone orientation
  const relativeQiblaAngle = (qiblaData.bearing - currentHeading + 360) % 360;

  // Alignment status: within ±3 degrees
  const angleDiff = Math.abs(relativeQiblaAngle > 180 ? 360 - relativeQiblaAngle : relativeQiblaAngle);
  const isAligned = angleDiff <= 3.5;

  // Smoothing ref for compass animation
  const headingRef = useRef<number>(0);

  // Trigger feedback when aligning directly with Qibla
  useEffect(() => {
    if (isAligned && !hasAlignedVibrated) {
      setHasAlignedVibrated(true);
      triggerVibration(settings.vibration, 'milestone');
      if (settings.sound) {
        playMilestoneSound(true);
      }
    } else if (!isAligned && hasAlignedVibrated) {
      setHasAlignedVibrated(false);
    }
  }, [isAligned, hasAlignedVibrated, settings.vibration, settings.sound]);

  // Device orientation listener
  const handleOrientation = useCallback((e: DeviceOrientationEvent) => {
    let heading: number | null = null;

    // iOS WebKit heading (True / Magnetic North)
    if ('webkitCompassHeading' in e && typeof (e as any).webkitCompassHeading === 'number') {
      heading = (e as any).webkitCompassHeading;
    } 
    // Android / Standard (alpha angle)
    else if (e.alpha !== null && typeof e.alpha === 'number') {
      // If absolute orientation is available
      if (e.absolute || ('webkitCompassHeading' in e)) {
        heading = (360 - e.alpha) % 360;
      } else {
        heading = (360 - e.alpha) % 360;
      }
    }

    if (heading !== null && !isNaN(heading)) {
      setSensorAvailable(true);
      // Circular smoothing to avoid needle flutter
      const prev = headingRef.current;
      let diff = heading - prev;
      if (diff > 180) diff -= 360;
      if (diff < -180) diff += 360;
      const smoothed = (prev + diff * 0.35 + 360) % 360;
      headingRef.current = smoothed;
      setCompassHeading(Math.round(smoothed * 10) / 10);
    }
  }, []);

  // Request iOS permission if needed
  const requestOrientationPermission = async () => {
    if (
      typeof window !== 'undefined' &&
      typeof (DeviceOrientationEvent as any).requestPermission === 'function'
    ) {
      try {
        const response = await (DeviceOrientationEvent as any).requestPermission();
        if (response === 'granted') {
          setPermissionNeeded(false);
          window.addEventListener('deviceorientation', handleOrientation, true);
          showToast('تم تفعيل مستشعر البوصلة بنجاح ✓');
        } else {
          showToast('تم رفض إذن مستشعر البوصلة');
        }
      } catch {
        showToast('تعذر طلب إذن البوصلة');
      }
    }
  };

  // Mount orientation listener
  useEffect(() => {
    if (typeof window === 'undefined') return;

    if (
      typeof (DeviceOrientationEvent as any).requestPermission === 'function'
    ) {
      setPermissionNeeded(true);
    } else if ('ondeviceorientation' in window) {
      window.addEventListener('deviceorientation', handleOrientation, true);
    }

    return () => {
      window.removeEventListener('deviceorientation', handleOrientation, true);
    };
  }, [handleOrientation]);

  // Request GPS / Online Location
  const handleRequestGPS = async () => {
    triggerVibration(settings.vibration, 'light');
    await refreshLocationForSolarTimes(false);
  };

  const handleSelectCity = (city: CityPreset) => {
    const newCoords: UserCoordinates = {
      latitude: city.latitude,
      longitude: city.longitude,
      city: city.name,
    };
    setCoords(newCoords);
    setSelectedCityName(city.name);
    try {
      localStorage.setItem('hisn_coords', JSON.stringify(newCoords));
    } catch {}
    setShowCityModal(false);
    showToast(`تم تعيين القبلة لمدينة ${city.name} (${city.country})`);
  };

  // Filtered cities list for search
  const filteredCities = POPULAR_CITIES.filter(c => 
    c.name.includes(citySearchQuery.trim()) || 
    c.country.includes(citySearchQuery.trim())
  );

  return (
    <div className="space-y-4 pb-24 text-right">
      {/* Header */}
      <div className="pt-2 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-extrabold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
            بوصلة القبلة
          </h2>
          <p className="text-xs text-[#4d7d67] dark:text-[#84b8a0] font-tajawal mt-0.5">
            تحديد اتجاه الكعبة المشرفة بمستشعرات الجهاز الدقيقة
          </p>
        </div>

        {/* Quick Toggles: Vibrate & Sound */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => updateSettings({ vibration: !settings.vibration })}
            className={`p-2 rounded-xl border border-emerald-300/40 dark:border-emerald-800/60 transition-colors cursor-pointer ${
              settings.vibration 
                ? 'bg-emerald-700/15 text-emerald-800 dark:text-emerald-300' 
                : 'bg-[#042017] dark:bg-[#042017] text-slate-400'
            }`}
            title={settings.vibration ? 'الاهتزاز مفعل عند محاذاة القبلة' : 'الاهتزاز معطل'}
          >
            <Vibrate className="w-4 h-4" />
          </button>
          <button
            onClick={() => updateSettings({ sound: !settings.sound })}
            className={`p-2 rounded-xl border border-emerald-300/40 dark:border-emerald-800/60 transition-colors cursor-pointer ${
              settings.sound 
                ? 'bg-emerald-700/15 text-emerald-800 dark:text-emerald-300' 
                : 'bg-[#042017] dark:bg-[#042017] text-slate-400'
            }`}
            title={settings.sound ? 'الصوت مفعل' : 'الصوت معطل'}
          >
            {settings.sound ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Location Card with Switcher */}
      <div className="bg-[#ffffff] dark:bg-[#042017] border border-emerald-600/15 dark:border-emerald-800/80 rounded-2xl p-3.5 flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#eaf5ef] dark:bg-[#083526] text-[#1a4432] dark:text-[#a7d7c0] flex items-center justify-center shrink-0">
            <MapPin className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
                {selectedCityName}
              </span>
              <span className="text-[10px] text-emerald-700 dark:text-emerald-300 font-mono">
                ({coords?.latitude.toFixed(2)}°, {coords?.longitude.toFixed(2)}°)
              </span>
            </div>
            <p className="text-[11px] text-[#4d7d67] dark:text-[#84b8a0] font-tajawal">
              المسافة للكعبة: <strong className="font-mono text-emerald-700 dark:text-emerald-300">{qiblaData.distanceKm.toLocaleString('ar-EG')} كم</strong>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={handleRequestGPS}
            className="px-2.5 py-1.5 rounded-xl bg-emerald-800/10 hover:bg-emerald-800/20 text-emerald-800 dark:text-emerald-300 border border-emerald-300/40 dark:border-emerald-800/60 text-xs font-bold font-cairo transition-colors cursor-pointer"
            title="تحديد الموقع عبر GPS"
          >
            تحديد GPS
          </button>
          <button
            onClick={() => setShowCityModal(true)}
            className="px-2.5 py-1.5 rounded-xl bg-[#eaf5ef] dark:bg-[#062c20] hover:bg-[#d6ecde] dark:hover:bg-[#093526] text-[#1a4432] dark:text-emerald-300 border border-emerald-300/40 dark:border-emerald-800/60 text-xs font-bold font-cairo transition-colors cursor-pointer"
            title="اختيار مدينة أخرى"
          >
            المدينة 🏙️
          </button>
        </div>
      </div>

      {/* iOS Permission Prompt Bar */}
      {permissionNeeded && !sensorAvailable && (
        <div className="bg-amber-500/15 border border-amber-400/40 rounded-2xl p-3 flex items-center justify-between text-xs animate-in fade-in">
          <div className="flex items-center gap-2 text-amber-900 dark:text-amber-200">
            <Compass className="w-4 h-4 text-amber-600 shrink-0" />
            <span className="font-tajawal">يتطلب جهازك إذناً لتشغيل مستشعر البوصلة بدقة</span>
          </div>
          <button
            onClick={requestOrientationPermission}
            className="px-3 py-1 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl text-xs font-cairo cursor-pointer"
          >
            تفعيل البوصلة
          </button>
        </div>
      )}

      {/* Main Qibla Compass Card */}
      <div className={`relative overflow-hidden rounded-3xl p-6 text-center shadow-lg transition-all border ${
        isAligned 
          ? 'bg-gradient-to-b from-[#043325] via-[#054331] to-[#022017] border-emerald-400 shadow-emerald-900/40 ring-4 ring-emerald-500/30' 
          : 'bg-[#ffffff] dark:bg-[#042017] border-emerald-600/15 dark:border-emerald-800/80 shadow-emerald-950/20'
      }`}>
        {/* Alignment Banner Status */}
        <div className="mb-4">
          {isAligned ? (
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-400/60 text-emerald-200 font-bold text-xs font-cairo shadow-sm animate-pulse">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>أنت تواجه القبلة المشرفة الآن مباشرة 🕋</span>
            </div>
          ) : (
            <div className="inline-flex items-center gap-1.5 text-xs text-[#4d7d67] dark:text-[#84b8a0] font-tajawal">
              <span>زاوية القبلة:</span>
              <strong className="font-mono text-emerald-700 dark:text-emerald-300 font-bold text-sm">
                {qiblaData.bearing}°
              </strong>
              <span>({qiblaData.directionArabic})</span>
            </div>
          )}
        </div>

        {/* ============================================================== */}
        {/* INTERACTIVE COMPASS DIAL (قرص البوصلة الدائري) */}
        {/* ============================================================== */}
        <div className="relative w-64 h-64 mx-auto my-3 flex items-center justify-center select-none">
          {/* Outer Compass Rose Dial - Rotates inversely to heading */}
          <div 
            className="absolute inset-0 rounded-full transition-transform duration-100 ease-out flex items-center justify-center shadow-inner"
            style={{ 
              transform: `rotate(${-currentHeading}deg)`,
              background: isAligned
                ? 'radial-gradient(circle, #083829 0%, #032017 100%)'
                : 'radial-gradient(circle, rgba(16, 185, 129, 0.08) 0%, rgba(2, 24, 17, 0.4) 100%)',
              border: isAligned ? '2px solid #34d399' : '2px solid rgba(16, 185, 129, 0.25)'
            }}
          >
            {/* Cardinal Directions (ش - ق - ج - غ) */}
            <span className="absolute top-2 text-xs font-black text-red-500 font-cairo">ش (N)</span>
            <span className="absolute right-3 text-xs font-bold text-[#4d7d67] dark:text-[#84b8a0] font-cairo">ق (E)</span>
            <span className="absolute bottom-2 text-xs font-bold text-[#4d7d67] dark:text-[#84b8a0] font-cairo">ج (S)</span>
            <span className="absolute left-3 text-xs font-bold text-[#4d7d67] dark:text-[#84b8a0] font-cairo">غ (W)</span>

            {/* Degree Tick Marks */}
            <svg className="w-full h-full absolute inset-0 pointer-events-none" viewBox="0 0 200 200">
              {Array.from({ length: 36 }).map((_, i) => {
                const angle = i * 10;
                const isMajor = angle % 90 === 0;
                const isMedium = angle % 30 === 0;
                const length = isMajor ? 10 : isMedium ? 6 : 3;
                return (
                  <line
                    key={angle}
                    x1="100"
                    y1="10"
                    x2="100"
                    y2={10 + length}
                    stroke={isMajor ? '#f59e0b' : 'rgba(52, 211, 153, 0.4)'}
                    strokeWidth={isMajor ? 2 : 1}
                    transform={`rotate(${angle} 100 100)`}
                  />
                );
              })}
            </svg>

            {/* Fixed Qibla Marker on Dial pointing to true Qibla relative to North */}
            <div 
              className="absolute inset-0 flex items-start justify-center pointer-events-none"
              style={{ transform: `rotate(${qiblaData.bearing}deg)` }}
            >
              <div className="flex flex-col items-center -mt-3.5">
                <span className="text-lg filter drop-shadow-md">🕋</span>
                <span className="text-[9px] font-bold text-amber-400 font-cairo">القبلة</span>
              </div>
            </div>
          </div>

          {/* Central Target Reticle & Kaaba Needle */}
          <div 
            className="absolute inset-0 flex items-center justify-center transition-transform duration-100 ease-out pointer-events-none"
            style={{ transform: `rotate(${relativeQiblaAngle}deg)` }}
          >
            {/* Kaaba Arrow Pointer */}
            <div className="flex flex-col items-center -translate-y-12">
              <div className={`w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-b-[24px] transition-colors drop-shadow-md ${
                isAligned ? 'border-b-emerald-400' : 'border-b-amber-500'
              }`} />
              <div className={`w-1 h-14 rounded-full transition-colors ${
                isAligned ? 'bg-emerald-400' : 'bg-gradient-to-b from-amber-500 to-transparent'
              }`} />
            </div>
          </div>

          {/* Center Hub Indicator */}
          <div className={`relative z-10 w-14 h-14 rounded-full flex flex-col items-center justify-center shadow-lg border-2 transition-all ${
            isAligned 
              ? 'bg-emerald-800 text-white border-emerald-300 ring-4 ring-emerald-400/40 scale-105' 
              : 'bg-[#042017] dark:bg-[#021811] text-[#0c2e20] dark:text-[#e8f5ee] border-emerald-500/40'
          }`}>
            <span className="text-base select-none">🕋</span>
            <span className="text-[9px] font-mono font-bold">
              {Math.round(qiblaData.bearing)}°
            </span>
          </div>
        </div>

        {/* Heading degree readout */}
        <div className="mt-3 flex items-center justify-center gap-3 text-xs">
          <div className="px-3 py-1 rounded-xl bg-[#eaf5ef] dark:bg-[#062c20] border border-emerald-300/40 dark:border-emerald-800/60 font-mono font-bold text-[#1a4432] dark:text-emerald-300">
            الاتجاه الحالي: {Math.round(currentHeading)}°
          </div>

          <div className="px-3 py-1 rounded-xl bg-[#eaf5ef] dark:bg-[#062c20] border border-emerald-300/40 dark:border-emerald-800/60 font-mono font-bold text-[#1a4432] dark:text-emerald-300">
            انحراف القبلة: {Math.round(angleDiff)}°
          </div>
        </div>

        {/* Manual Calibration Slider if sensor is unavailable on desktop */}
        {!sensorAvailable && (
          <div className="mt-4 pt-3 border-t border-emerald-200/50 dark:border-emerald-800/60 space-y-2">
            <div className="flex items-center justify-between text-[11px] text-[#4d7d67] dark:text-[#84b8a0]">
              <span className="flex items-center gap-1 font-bold">
                <RotateCw className="w-3 h-3 text-amber-500" />
                <span>محاكي تدوير الجهاز يدوياً:</span>
              </span>
              <span className="font-mono">{manualAngle}°</span>
            </div>
            <input
              type="range"
              min="0"
              max="359"
              value={manualAngle}
              onChange={(e) => setManualAngle(Number(e.target.value))}
              className="w-full accent-emerald-600 cursor-pointer h-1.5 bg-emerald-200 dark:bg-emerald-950 rounded-lg"
            />
            <p className="text-[10px] text-[#4d7d67] dark:text-[#84b8a0] font-tajawal">
              (ملاحظة: على الهواتف الذكية تعمل البوصلة تلقائياً بمستشعر الجهاز)
            </p>
          </div>
        )}
      </div>

      {/* Guidelines & Calibration Card */}
      <div className="bg-[#ffffff] dark:bg-[#042017] border border-emerald-600/15 dark:border-emerald-800/80 rounded-2xl p-4 space-y-2 text-xs shadow-xs">
        <h3 className="font-bold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo flex items-center gap-1.5">
          <Info className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          <span>إرشادات ضبط دقة البوصلة</span>
        </h3>
        <ul className="space-y-1.5 text-[#4d7d67] dark:text-[#84b8a0] font-tajawal leading-relaxed">
          <li className="flex items-start gap-1.5">
            <span className="text-emerald-600 font-bold">•</span>
            <span>ضع الجهاز بشكل <strong>أفقي مستوٍ</strong> موازٍ للأرض للحصول على أفضل دقة.</span>
          </li>
          <li className="flex items-start gap-1.5">
            <span className="text-emerald-600 font-bold">•</span>
            <span>ابتعد عن الأجهزة الكهربائية والمغناطيسية والمعادن لتجنب تشويش المستشعر.</span>
          </li>
          <li className="flex items-start gap-1.5">
            <span className="text-emerald-600 font-bold">•</span>
            <span>في حال عدم استقرار السهم، حرّك الهاتف في الهواء على شكل <strong>رقم (8)</strong> لمعايرته.</span>
          </li>
        </ul>
      </div>

      {/* ============================================================== */}
      {/* CITY SELECTION MODAL (اختيار المدينة يدويًا) */}
      {/* ============================================================== */}
      {showCityModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div 
            className="w-full max-w-md max-h-[85vh] bg-[#042017] dark:bg-[#042017] border border-emerald-600/30 dark:border-emerald-700/60 rounded-3xl p-5 shadow-2xl flex flex-col space-y-3.5 text-right"
            role="dialog"
            aria-modal="true"
          >
            <div className="flex items-center justify-between pb-2 border-b border-emerald-200/50 dark:border-emerald-800/60">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <h3 className="text-sm font-extrabold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
                  اختر مدينتك لتحديد القبلة
                </h3>
              </div>
              <button
                onClick={() => setShowCityModal(false)}
                className="p-1 rounded-full text-[#4d7d67] hover:text-[#0c2e20] dark:hover:text-emerald-300 cursor-pointer"
                aria-label="إغلاق"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Auto-detect GPS / Internet Live Location button */}
            <button
              onClick={() => {
                setShowCityModal(false);
                handleRequestGPS();
              }}
              className="w-full p-2.5 rounded-xl border border-amber-500/50 bg-amber-500/15 hover:bg-amber-500/25 text-amber-200 text-xs font-bold font-cairo flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Navigation className="w-4 h-4 text-amber-300" />
              <span>استخدام موقعي الجغرافي المباشر (تحديث تلقائي) 📍</span>
            </button>

            {/* City search input */}
            <div className="relative">
              <Search className="w-4 h-4 text-emerald-600 absolute right-3 top-3 pointer-events-none" />
              <input
                type="text"
                placeholder="ابحث باسم المدينة أو الدولة..."
                value={citySearchQuery}
                onChange={(e) => setCitySearchQuery(e.target.value)}
                className="w-full pr-9 pl-3 py-2 text-xs bg-[#062c20] dark:bg-[#062c20] border border-emerald-300/40 dark:border-emerald-800/60 rounded-xl text-[#0c2e20] dark:text-[#e8f5ee] placeholder:text-[#4d7d67] focus:outline-none focus:ring-1 focus:ring-emerald-600 font-tajawal"
                dir="rtl"
                autoFocus
              />
            </div>

            {/* Cities list */}
            <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 max-h-60">
              {filteredCities.map((city) => {
                const isSelected = selectedCityName === city.name;
                const cityQibla = calculateQiblaDirection(city.latitude, city.longitude);

                return (
                  <button
                    key={`${city.name}-${city.country}`}
                    onClick={() => handleSelectCity(city)}
                    className={`w-full p-2.5 rounded-xl border text-right transition-colors flex items-center justify-between cursor-pointer ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-700/15 text-emerald-900 dark:text-emerald-200 font-bold'
                        : 'border-emerald-200/40 dark:border-emerald-800/50 hover:bg-[#062c20] dark:hover:bg-[#062c20] text-[#0c2e20] dark:text-[#e8f5ee]'
                    }`}
                  >
                    <div>
                      <p className="text-xs font-bold font-cairo">{city.name}</p>
                      <p className="text-[10px] text-[#4d7d67] dark:text-[#84b8a0]">{city.country}</p>
                    </div>

                    <div className="text-left font-mono text-[11px] text-emerald-700 dark:text-emerald-300">
                      <span>{Math.round(cityQibla.bearing)}°</span>
                      <span className="text-[9px] block text-[#4d7d67] dark:text-[#84b8a0]">
                        {cityQibla.directionArabic}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => setShowCityModal(false)}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-700 to-emerald-800 text-white text-xs font-bold font-cairo hover:from-emerald-600 hover:to-emerald-700 transition-colors cursor-pointer"
            >
              تم
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
