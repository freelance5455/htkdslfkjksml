import React, { useRef, useEffect } from 'react';
import { 
  Monitor, 
  Scan, 
  Sparkles, 
  Mic, 
  Eye, 
  CheckCircle2, 
  Volume2, 
  StopCircle, 
  RefreshCw, 
  Zap, 
  ExternalLink,
  ShieldCheck,
  Maximize2
} from 'lucide-react';
import { SupportedLanguage } from '../types/assistant';

interface LiveScreenObserverHUDProps {
  stream: MediaStream | null;
  isCapturing: boolean;
  onRequestPermission: () => void;
  onStopCapture: () => void;
  onExecuteScreenCommand: (command: string) => void;
  language: SupportedLanguage;
  isProcessing: boolean;
}

export const LiveScreenObserverHUD: React.FC<LiveScreenObserverHUDProps> = ({
  stream,
  isCapturing,
  onRequestPermission,
  onStopCapture,
  onExecuteScreenCommand,
  language,
  isProcessing,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
      videoRef.current.play().catch(() => {});
    }
  }, [stream]);

  return (
    <div className="relative rounded-3xl bg-gradient-to-b from-[#060b17] via-[#091124] to-[#0d071a] border-2 border-cyan-500/50 p-4 sm:p-6 shadow-2xl overflow-hidden">
      {/* Background Holographic Scanline Grid */}
      <div className="absolute inset-0 cyber-grid opacity-40 pointer-events-none" />

      {/* Top HUD Telemetry Bar */}
      <div className="relative z-10 flex flex-wrap items-center justify-between gap-3 border-b border-cyan-900/40 pb-3 text-xs font-mono-tech">
        <div className="flex items-center gap-2">
          <span className="flex h-2.5 w-2.5 relative">
            <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${isCapturing ? 'bg-cyan-400' : 'bg-amber-400'} opacity-75`} />
            <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${isCapturing ? 'bg-cyan-400' : 'bg-amber-400'}`} />
          </span>
          <span className={`font-bold tracking-wider ${isCapturing ? 'text-cyan-300' : 'text-amber-400'}`}>
            {isCapturing
              ? language === 'bn' ? '● ডিসপ্লে ওভারভিউ সক্রিয়: এআই আপনার স্ক্রিন দেখছে' : '● DISPLAY OVERVIEW LINKED: OBSERVING SCREEN'
              : language === 'bn' ? '○ ডিসপ্লে ওভারভিউ সংযোগ প্রয়োজন (অনুমতি দিন)' : '○ DISPLAY LINK PENDING AUTHORIZATION'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          {!isCapturing ? (
            <button
              onClick={onRequestPermission}
              className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-fuchsia-500 hover:from-cyan-400 text-slate-950 font-orbitron font-extrabold text-[11px] tracking-wider transition-all flex items-center gap-1.5 shadow-md shadow-cyan-500/30 animate-pulse"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'স্ক্রিন পারমিশন দিন' : 'GRANT SCREEN ACCESS'}</span>
            </button>
          ) : (
            <button
              onClick={onStopCapture}
              className="px-3 py-1 rounded-xl bg-red-950/70 border border-red-500 text-red-300 font-mono-tech text-[11px] hover:bg-red-900 transition-colors flex items-center gap-1"
            >
              <StopCircle className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'লিঙ্ক বন্ধ করুন' : 'DISCONNECT'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Holographic Screen Eye (Styled like the top Hologram Logo) */}
      <div className="relative z-10 flex flex-col md:flex-row items-center justify-center gap-6 py-4">
        {/* Holographic Circular Orb Container (matches the top logo HUD) */}
        <div className="relative flex items-center justify-center">
          {/* Outer rotating cyber rings */}
          <div className="absolute w-48 h-48 sm:w-56 sm:h-56 rounded-full border border-dashed border-cyan-400/40 animate-spin-slow pointer-events-none" />
          <div className="absolute w-40 h-40 sm:w-48 sm:h-48 rounded-full border border-fuchsia-500/50 animate-spin-reverse pointer-events-none" />

          {/* Holographic Video Display Frame with Circle mask or Rounded Hex */}
          <div className="relative w-36 h-36 sm:w-44 sm:h-44 rounded-full p-1 bg-gradient-to-tr from-cyan-400 via-slate-900 to-fuchsia-500 shadow-xl shadow-cyan-500/30">
            <div className="w-full h-full rounded-full overflow-hidden bg-black relative scanlines border border-cyan-400 flex items-center justify-center">
              {isCapturing ? (
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover filter contrast-105"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center bg-[#070e1c] text-cyan-400/80 p-2 text-center">
                  <Monitor className="w-8 h-8 sm:w-10 sm:h-10 animate-pulse" />
                  <span className="text-[10px] font-mono-tech mt-1 text-slate-400">WAITING FOR LINK</span>
                </div>
              )}

              {/* Cyan scanline & reticle overlay */}
              <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/15 via-transparent to-fuchsia-500/20 mix-blend-screen pointer-events-none" />
              <div className="absolute inset-0 bg-[radial-gradient(circle,transparent_60%,rgba(0,229,255,0.3)_100%)] pointer-events-none" />
            </div>

            {/* Pedestal Tag */}
            <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-slate-950 border border-cyan-400/80 px-2.5 py-0.5 rounded-full text-[9px] font-mono-tech tracking-wider text-cyan-300 shadow-md flex items-center gap-1 whitespace-nowrap">
              <Eye className="w-2.5 h-2.5 text-cyan-400" />
              <span>SCREEN EYE HUD</span>
            </div>
          </div>
        </div>

        {/* Live Command & Voice Actions Panel */}
        <div className="flex-1 space-y-3 text-center md:text-left max-w-lg">
          <div>
            <div className="inline-flex items-center gap-1.5 text-cyan-300 text-xs font-mono-tech font-bold">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>VOICE-POWERED SCREEN CONTROLLER</span>
            </div>
            <h3 className="text-lg sm:text-xl font-orbitron font-extrabold text-white">
              {language === 'bn' ? 'স্ক্রিনের সব দেখে ভয়েসে কাজ করান' : 'Voice-Command Your Screen'}
            </h3>
            <p className="text-slate-400 text-xs mt-1">
              {isCapturing
                ? language === 'bn'
                  ? 'স্ক্রিন লিঙ্ক করা আছে! নিচের বাটনে ক্লিক করুন অথবা ভয়েসে বলুন এআই কী কাজ করবে।'
                  : 'Screen is connected! Click any action below or speak whatever you want the AI to perform.'
                : language === 'bn'
                ? 'স্ক্রিন পারমিশন দিলে এআই আপনার স্ক্রিন দেখে সমস্ত নির্দেশ পালন করতে পারবে।'
                : 'Grant screen permission to allow Rubel Boss AI to observe and execute tasks.'}
            </p>
          </div>

          {/* Quick Voice Directives for Current Screen */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              onClick={() =>
                onExecuteScreenCommand(
                  language === 'bn'
                    ? 'আমার স্ক্রিনে এখন কী কী দেখা যাচ্ছে তা সম্পূর্ণ পড়ে এবং বিশ্লেষণ করে বলো।'
                    : 'Analyze and read everything currently visible on my screen.'
                )
              }
              disabled={isProcessing}
              className="p-2.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-cyan-500/40 hover:border-cyan-400 text-xs text-left text-slate-200 transition-all flex items-center gap-2 group shadow-sm"
            >
              <Scan className="w-3.5 h-3.5 text-cyan-400 shrink-0 group-hover:scale-110 transition-transform" />
              <span className="truncate">{language === 'bn' ? 'স্ক্রিন পড়ে শোনাও' : 'Read Screen Content'}</span>
            </button>

            <button
              onClick={() =>
                onExecuteScreenCommand(
                  language === 'bn'
                    ? 'আমার স্ক্রিনের কোড বা এরর মেসেজ দেখে ভুল সংশোধন করে দাও এবং কোড দাও।'
                    : 'Find any code or error on screen, diagnose, and provide the fixed code.'
                )
              }
              disabled={isProcessing}
              className="p-2.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-fuchsia-500/40 hover:border-fuchsia-400 text-xs text-left text-slate-200 transition-all flex items-center gap-2 group shadow-sm"
            >
              <Zap className="w-3.5 h-3.5 text-fuchsia-400 shrink-0 group-hover:scale-110 transition-transform" />
              <span className="truncate">{language === 'bn' ? 'কোড / এরর ফিক্স করো' : 'Fix Screen Code/Error'}</span>
            </button>

            <button
              onClick={() =>
                onExecuteScreenCommand(
                  language === 'bn'
                    ? 'আমার স্ক্রিনের বর্তমান কন্টেন্ট নিয়ে ফেসবুকে একটি পোস্ট ড্রাফট করো।'
                    : 'Draft an engaging Facebook post based on this screen.'
                )
              }
              disabled={isProcessing}
              className="p-2.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-blue-500/40 hover:border-blue-400 text-xs text-left text-slate-200 transition-all flex items-center gap-2 group shadow-sm"
            >
              <ExternalLink className="w-3.5 h-3.5 text-blue-400 shrink-0 group-hover:scale-110 transition-transform" />
              <span className="truncate">{language === 'bn' ? 'ফেসবুকে পোস্ট তৈরি করো' : 'Post this to Facebook'}</span>
            </button>

            <button
              onClick={() =>
                onExecuteScreenCommand(
                  language === 'bn'
                    ? 'আমার স্ক্রিনের গুরুত্বপূর্ণ টেক্সট এবং নির্দেশাবলী পার্সোনাল নোটে সেভ করো।'
                    : 'Extract key points from this screen and save into personal notes.'
                )
              }
              disabled={isProcessing}
              className="p-2.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-amber-500/40 hover:border-amber-400 text-xs text-left text-slate-200 transition-all flex items-center gap-2 group shadow-sm"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400 shrink-0 group-hover:scale-110 transition-transform" />
              <span className="truncate">{language === 'bn' ? 'স্ক্রিনের ডাটা নোটে রাখো' : 'Save Screen to Notes'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
