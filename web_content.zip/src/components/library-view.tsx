import { useEffect, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import {
  BookOpen,
  FileUp,
  Headphones,
  LoaderCircle,
  Trash2,
} from "lucide-react";
import { BookCover } from "@/components/book-cover";
import { Button } from "@/components/ui/button";
import { useLibrary } from "@/lib/library";
import type { BookSummary } from "@/lib/epub/types";
import { cn, estimateMinutes, formatCount } from "@/lib/utils";

export function LibraryView() {
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [importing, setImporting] = useState(false);
  const { books, hydrated, progress, hydrate, importEpub, removeBook } =
    useLibrary();

  useEffect(() => {
    void hydrate();
  }, [hydrate]);

  const continueId = mostRecentProgress(books, progress);

  async function handleFiles(files: FileList | File[] | null) {
    const file = files?.[0];
    if (!file) return;
    const name = file.name.toLowerCase();
    if (!name.endsWith(".epub") && file.type !== "application/epub+zip") {
      toast.error("Elige un archivo .epub");
      return;
    }
    setImporting(true);
    try {
      const book = await importEpub(file);
      toast.success(`«${book.title}» está en tu biblioteca`);
      void navigate({ to: "/read/$bookId", params: { bookId: book.id } });
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "No se pudo abrir el EPUB";
      toast.error(message);
    } finally {
      setImporting(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  return (
    <main className="mx-auto min-h-dvh w-full max-w-3xl px-5 pb-16 pt-8 sm:px-8">
      <header className="rise-in mb-10">
        <p className="font-sans text-xs font-medium uppercase tracking-[0.18em] text-muted">
          Lector con voz
        </p>
        <h1 className="mt-2 font-display text-5xl font-medium tracking-tight text-fg sm:text-6xl">
          Folio
        </h1>
        <p className="mt-3 max-w-md text-pretty text-base leading-relaxed text-muted">
          Abre un EPUB y escúchalo con las voces de tu dispositivo. El progreso
          se guarda aquí, en este aparato.
        </p>
      </header>

      <section
        className={cn(
          "rise-in-2 relative rounded-2xl bg-bg-elevated p-5 shadow-[var(--shadow-border)] sm:p-6",
          dragging && "ring-2 ring-ring",
        )}
        onDragOver={(event) => {
          event.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(event) => {
          event.preventDefault();
          setDragging(false);
          void handleFiles(event.dataTransfer.files);
        }}
      >
        <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <span className="flex size-11 items-center justify-center rounded-md bg-bg-subtle text-accent">
              <FileUp className="size-5" strokeWidth={1.75} />
            </span>
            <div>
              <h2 className="font-sans text-sm font-medium text-fg">
                Abrir un EPUB
              </h2>
              <p className="mt-1 max-w-sm text-sm leading-relaxed text-muted">
                Arrástralo aquí o elige un archivo. Folio extrae los capítulos y
                los deja listos para leer en voz alta.
              </p>
            </div>
          </div>
          <Button
            onClick={() => inputRef.current?.click()}
            disabled={importing}
            className="shrink-0"
          >
            {importing ? (
              <LoaderCircle className="size-4 animate-spin" />
            ) : (
              <Headphones className="size-4" />
            )}
            {importing ? "Abriendo…" : "Elegir archivo"}
          </Button>
        </div>
        <input
          ref={inputRef}
          type="file"
          accept=".epub,application/epub+zip"
          className="sr-only"
          tabIndex={-1}
          aria-hidden="true"
          onChange={(event) => void handleFiles(event.target.files)}
        />
      </section>

      {continueId && (
        <div className="rise-in-3 mt-5">
          <Button
            variant="secondary"
            className="w-full justify-between sm:w-auto"
            onClick={() =>
              void navigate({
                to: "/read/$bookId",
                params: { bookId: continueId },
              })
            }
          >
            <span className="flex items-center gap-2">
              <BookOpen className="size-4" />
              Continuar lectura
            </span>
            <span className="truncate text-muted">
              {books.find((b) => b.id === continueId)?.title}
            </span>
          </Button>
        </div>
      )}

      <section className="mt-12">
        <div className="mb-4 flex items-baseline justify-between">
          <h2 className="font-display text-xl font-medium tracking-tight">
            Biblioteca
          </h2>
          <p className="text-xs text-muted tabular-nums">
            {hydrated ? formatCount(books.length) : "—"}{" "}
            {books.length === 1 ? "libro" : "libros"}
          </p>
        </div>
        <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {books.map((book) => (
            <li key={book.id}>
              <BookCard
                book={book}
                chapter={progress[book.id]?.chapter}
                onOpen={() =>
                  void navigate({
                    to: "/read/$bookId",
                    params: { bookId: book.id },
                  })
                }
                onRemove={
                  book.isSample ? undefined : () => void removeBook(book.id)
                }
              />
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}

function BookCard({
  book,
  chapter,
  onOpen,
  onRemove,
}: {
  book: BookSummary;
  chapter?: number;
  onOpen: () => void;
  onRemove?: () => void;
}) {
  const minutes = estimateMinutes(book.totalChars);
  return (
    <article className="group relative flex gap-3 rounded-xl bg-bg-elevated p-3 shadow-[var(--shadow-border)] transition-[box-shadow] duration-[var(--motion-quick)] ease-[var(--ease-out)] hover:shadow-[var(--shadow-border-hover)]">
      <button
        type="button"
        onClick={onOpen}
        className="flex min-w-0 flex-1 gap-3 text-left"
      >
        <BookCover
          id={book.id}
          title={book.title}
          className="h-[7.5rem] w-[5.25rem] shrink-0"
        />
        <div className="flex min-w-0 flex-1 flex-col">
          <h3 className="font-display text-base font-medium leading-snug tracking-tight text-fg">
            {book.title}
          </h3>
          <p className="mt-1 truncate text-sm text-muted">
            {book.author ?? "Autor desconocido"}
          </p>
          <p className="mt-auto pt-3 text-xs text-subtle tabular-nums">
            {book.chapterCount}{" "}
            {book.chapterCount === 1 ? "capítulo" : "capítulos"}
            <span className="mx-1.5 text-border">·</span>
            {minutes} min
            {typeof chapter === "number" ? (
              <>
                <span className="mx-1.5 text-border">·</span>
                cap. {chapter + 1}
              </>
            ) : null}
          </p>
          {book.isSample && (
            <span className="mt-2 w-fit rounded-sm bg-bg-subtle px-1.5 py-0.5 text-[10px] font-medium uppercase tracking-wider text-muted">
              Muestra
            </span>
          )}
        </div>
      </button>
      {onRemove && (
        <Button
          variant="ghost"
          size="icon"
          className="size-9 shrink-0 self-start text-muted hover:text-danger"
          aria-label={`Quitar ${book.title}`}
          onClick={() => onRemove()}
        >
          <Trash2 className="size-4" />
        </Button>
      )}
    </article>
  );
}

function mostRecentProgress(
  books: BookSummary[],
  progress: Record<string, { updatedAt: number }>,
): string | null {
  let best: { id: string; at: number } | null = null;
  for (const book of books) {
    const entry = progress[book.id];
    if (!entry) continue;
    if (!best || entry.updatedAt > best.at) {
      best = { id: book.id, at: entry.updatedAt };
    }
  }
  return best?.id ?? null;
}
