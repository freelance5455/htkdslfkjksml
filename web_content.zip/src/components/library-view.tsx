import { useMemo, useState } from "react";
import { Search, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BookCover } from "@/components/book-cover";
import { AddBookPanel } from "@/components/add-book-panel";
import { MoreView } from "@/components/more-view";
import { TabBar } from "@/components/tab-bar";
import { readingMinutes } from "@/lib/utils";
import { selectBooks, useVault } from "@/lib/vault-store";
import type { Book } from "@/lib/library";

export function LibraryView() {
  const tab = useVault((s) => s.tab);
  const adding = useVault((s) => s.adding);

  return (
    <div className="shelf-grain relative flex h-full flex-col text-cream">
      <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain pb-tab">
        {tab === "more" ? <MoreView /> : <ShelfPage mineOnly={tab === "mine"} />}
      </div>
      <TabBar />
      {adding && <AddBookPanel />}
    </div>
  );
}

function ShelfPage({ mineOnly }: { mineOnly: boolean }) {
  const customBooks = useVault((s) => s.customBooks);
  const progress = useVault((s) => s.progress);
  const openBook = useVault((s) => s.openBook);
  const setAdding = useVault((s) => s.setAdding);
  const [query, setQuery] = useState("");
  const all = selectBooks({ customBooks });
  const books = mineOnly ? customBooks : all;

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return books;
    return books.filter(
      (b) =>
        b.title.toLowerCase().includes(q) ||
        b.author.toLowerCase().includes(q) ||
        b.blurb.toLowerCase().includes(q),
    );
  }, [books, query]);

  const continueId = useMemo(() => {
    if (mineOnly) return undefined;
    const entries = Object.entries(progress).filter(([, p]) => p.percent > 2 && p.percent < 98);
    entries.sort((a, b) => b[1].updatedAt - a[1].updatedAt);
    return entries[0]?.[0];
  }, [progress, mineOnly]);
  const continueBook = all.find((b) => b.id === continueId);

  return (
    <div className="px-4 pt-safe">
      <header className="pt-2">
        <p className="text-xs uppercase tracking-[0.18em] text-sage">
          {mineOnly ? "ваши тексты" : "на телефоне"}
        </p>
        <h2 className="mt-1 font-display text-3xl tracking-tight">{mineOnly ? "Мои" : "Полка"}</h2>
      </header>

      {continueBook && <ContinueCard book={continueBook} percent={progress[continueBook.id]?.percent ?? 0} onOpen={openBook} />}

      {mineOnly && (
        <Button variant="sage" size="lg" className="mt-5 w-full" onClick={() => setAdding(true)}>
          Добавить текст
        </Button>
      )}

      {!mineOnly && (
        <label className="relative mt-5 block">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Найти книгу"
            className="h-12 w-full rounded-xl bg-ink-2 pl-10 pr-10 text-sm text-cream shadow-border outline-none placeholder:text-muted focus-visible:shadow-ring"
          />
          {query && (
            <button
              type="button"
              aria-label="Очистить поиск"
              onClick={() => setQuery("")}
              className="absolute right-2 top-1/2 flex size-8 -translate-y-1/2 items-center justify-center text-muted"
            >
              <X className="size-4" />
            </button>
          )}
        </label>
      )}

      {filtered.length === 0 ? (
        <p className="py-16 text-center font-reading text-muted">
          {mineOnly ? "Пока пусто. Добавьте рассказ, главу или письмо." : "Ничего не нашлось."}
        </p>
      ) : (
        <ul className="mt-5 grid grid-cols-2 gap-4">
          {filtered.map((book, i) => {
            const pct = progress[book.id]?.percent ?? 0;
            return (
              <li key={book.id} className="reveal" style={{ animationDelay: `${Math.min(i, 8) * 40}ms` }}>
                <button type="button" onClick={() => openBook(book.id)} className="group flex w-full flex-col text-left">
                  <div className="overflow-hidden rounded-xl shadow-lift transition-transform duration-200 ease-out group-active:scale-[0.98]">
                    <BookCover book={book} />
                  </div>
                  <h3 className="mt-2.5 line-clamp-2 font-display text-sm leading-snug tracking-tight">{book.title}</h3>
                  <p className="mt-0.5 truncate text-xs text-muted">{book.author}</p>
                  <p className="mt-1 text-xs tabular-nums text-faint">
                    {readingMinutes(book.text)} мин
                    {pct > 0 ? ` · ${pct}%` : ""}
                  </p>
                  {pct > 0 && (
                    <div className="mt-2 h-0.5 overflow-hidden rounded-full bg-cream/10">
                      <div className="h-full bg-sage" style={{ width: `${pct}%` }} />
                    </div>
                  )}
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

function ContinueCard({
  book,
  percent,
  onOpen,
}: {
  book: Book;
  percent: number;
  onOpen: (id: string) => void;
}) {
  return (
    <button
      type="button"
      onClick={() => onOpen(book.id)}
      className="mt-5 flex w-full overflow-hidden rounded-2xl bg-ink-2 text-left shadow-border"
    >
      <div className="w-24 shrink-0">
        <BookCover book={book} compact />
      </div>
      <div className="flex min-w-0 flex-1 flex-col justify-center px-4 py-3">
        <p className="text-xs uppercase tracking-[0.18em] text-sage">продолжить</p>
        <p className="mt-1 truncate font-display text-lg tracking-tight">{book.title}</p>
        <p className="truncate text-sm text-muted">{book.author}</p>
        <div className="mt-3 h-1 overflow-hidden rounded-full bg-cream/10">
          <div className="h-full rounded-full bg-sage" style={{ width: `${percent}%` }} />
        </div>
      </div>
    </button>
  );
}
