import React, { useState } from 'react';
import { AppSettings, UserProfile, SecuritySettings } from '../types';
import { Lock, KeyRound, X, CheckCircle, AlertCircle, Eye, EyeOff } from 'lucide-react';
import { getDualAccentInfo } from '../utils/theme';

interface PasswordVerifyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  onVerified?: () => void;
  title?: string;
  titleBangla?: string;
  titleEnglish?: string;
  description?: string;
  descriptionBangla?: string;
  descriptionEnglish?: string;
  appSettings: AppSettings;
  userProfile: UserProfile;
  securitySettings?: SecuritySettings;
  onSaveNewPassword?: (password: string) => void;
}

export const PasswordVerifyModal: React.FC<PasswordVerifyModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  onVerified,
  title,
  titleBangla = 'নিরাপত্তা পাসওয়ার্ড দিন',
  titleEnglish = 'Enter Security Password',
  description,
  descriptionBangla = 'পুরাতন এন্ট্রি পরিবর্তন বা ডিলিট করতে নিরাপত্তা পাসওয়ার্ড প্রয়োজন।',
  descriptionEnglish = 'Password verification required to modify or delete existing entries.',
  appSettings,
  userProfile,
  onSaveNewPassword,
}) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isSettingNew, setIsSettingNew] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const isLight = appSettings.themeMode === 'light';
  const isEn = appSettings.language === 'en';
  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );

  if (!isOpen) return null;

  // The configured password is in userProfile.profilePassword
  const activePassword = userProfile?.profilePassword?.trim() || '';
  const hasConfiguredPassword = Boolean(activePassword);

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (hasConfiguredPassword) {
      if (!password.trim()) {
        setError(isEn ? 'Please enter PIN' : 'অনুগ্রহ করে পিন দিন');
        return;
      }

      if (password.trim() === activePassword) {
        setPassword('');
        setError('');
        if (onSuccess) onSuccess();
        if (onVerified) onVerified();
      } else {
        setError(
          isEn
            ? 'Incorrect PIN. Please try again.'
            : 'ভুল পিন! আবার চেষ্টা করুন।'
        );
      }
    } else {
      // No PIN configured; proceed directly
      setPassword('');
      setError('');
      if (onSuccess) onSuccess();
      if (onVerified) onVerified();
    }
  };

  const handleSetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!newPassword.trim() || newPassword.length < 3) {
      setError(isEn ? 'Password must be at least 3 characters' : 'পাসওয়ার্ড কমপক্ষে ৩ অক্ষরের হতে হবে');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError(isEn ? 'Passwords do not match' : 'উভয় পাসওয়ার্ড মিলছে না');
      return;
    }

    if (onSaveNewPassword) {
      onSaveNewPassword(newPassword.trim());
    }
    setIsSettingNew(false);
    setPassword('');
    if (onSuccess) onSuccess();
    if (onVerified) onVerified();
  };

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center ${
        isLight ? 'bg-slate-900/40 backdrop-blur-xs' : 'bg-black/75 backdrop-blur-xs'
      } p-4 animate-in fade-in duration-200`}
    >
      <div
        className={`w-full max-w-sm ${
          isLight ? 'bg-white border-sky-200 text-sky-950' : 'bg-slate-800 border-slate-700 text-slate-100'
        } border rounded-3xl shadow-2xl overflow-hidden p-6 space-y-4 animate-in fade-in zoom-in-95 duration-200`}
      >
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div
              className="p-3 rounded-2xl"
              style={{
                backgroundColor: `${dualAccent.primary.hex}20`,
                color: dualAccent.primary.hex,
              }}
            >
              <KeyRound className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-base leading-snug">
                {isSettingNew
                  ? isEn
                    ? 'Set New Password'
                    : 'নতুন পাসওয়ার্ড সেট করুন'
                  : title || (isEn ? titleEnglish : titleBangla)}
              </h3>
              <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-slate-400'} mt-0.5`}>
                {isSettingNew
                  ? isEn
                    ? 'Set a master password to protect your data'
                    : 'আপনার হিসাব সুরক্ষিত রাখতে নতুন পাসওয়ার্ড দিন'
                  : description || (isEn ? descriptionEnglish : descriptionBangla)}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className={`p-1.5 rounded-full ${
              isLight ? 'hover:bg-slate-100 text-slate-400' : 'hover:bg-slate-700 text-slate-400'
            } transition`}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Error message */}
        {error && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-500 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {isSettingNew ? (
          <form onSubmit={handleSetPassword} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold mb-1 text-slate-500">
                {isEn ? 'New Password / PIN' : 'নতুন পাসওয়ার্ড / পিন'}
              </label>
              <input
                type={showPassword ? 'text' : 'password'}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder={isEn ? 'Enter new password' : 'নতুন পাসওয়ার্ড লিখুন'}
                className={`w-full px-3 py-2.5 rounded-xl border text-sm ${
                  isLight
                    ? 'bg-slate-50 border-slate-200 text-slate-900 focus:bg-white'
                    : 'bg-slate-900/80 border-slate-700 text-slate-100'
                } outline-hidden focus:ring-2`}
                autoFocus
              />
            </div>
            <div>
              <label className="block text-xs font-semibold mb-1 text-slate-500">
                {isEn ? 'Confirm Password' : 'পাসওয়ার্ড নিশ্চিত করুন'}
              </label>
              <input
                type={showPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder={isEn ? 'Confirm new password' : 'পাসওয়ার্ড পুনরায় লিখুন'}
                className={`w-full px-3 py-2.5 rounded-xl border text-sm ${
                  isLight
                    ? 'bg-slate-50 border-slate-200 text-slate-900 focus:bg-white'
                    : 'bg-slate-900/80 border-slate-700 text-slate-100'
                } outline-hidden focus:ring-2`}
              />
            </div>

            <div className="flex items-center justify-between text-xs pt-1">
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="text-slate-400 hover:text-slate-600 flex items-center gap-1"
              >
                {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span>{showPassword ? (isEn ? 'Hide' : 'লুকান') : (isEn ? 'Show' : 'দেখান')}</span>
              </button>
              <button
                type="button"
                onClick={() => setIsSettingNew(false)}
                className="text-xs text-sky-500 hover:underline"
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 rounded-xl text-white font-bold text-sm shadow-md transition"
              style={{ backgroundColor: dualAccent.primary.hex }}
            >
              {isEn ? 'Save & Proceed' : 'সংরক্ষণ ও অগ্রসর হোন'}
            </button>
          </form>
        ) : hasConfiguredPassword ? (
          <form onSubmit={handleVerify} className="space-y-4">
            <div>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={isEn ? 'Enter your security PIN' : 'আপনার নিরাপত্তা পিন লিখুন'}
                  className={`w-full pl-3 pr-10 py-3 rounded-xl border text-base tracking-widest font-mono ${
                    isLight
                      ? 'bg-slate-50 border-slate-200 text-slate-900 focus:bg-white'
                      : 'bg-slate-900/80 border-slate-700 text-slate-100'
                  } outline-hidden focus:ring-2`}
                  autoFocus
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {onSaveNewPassword && (
                <div className="flex items-center justify-end mt-2 text-[11px] text-slate-400">
                  <button
                    type="button"
                    onClick={() => setIsSettingNew(true)}
                    className="text-sky-500 hover:underline font-semibold cursor-pointer"
                  >
                    {isEn ? 'Change PIN' : 'পিন পরিবর্তন করুন'}
                  </button>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={onClose}
                className={`flex-1 py-2.5 px-4 rounded-xl font-medium text-xs border ${
                  isLight
                    ? 'border-slate-200 text-slate-700 hover:bg-slate-100'
                    : 'border-slate-700 text-slate-300 hover:bg-slate-700/50'
                } transition cursor-pointer`}
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 px-4 rounded-xl text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer"
                style={{ backgroundColor: dualAccent.primary.hex }}
              >
                <Lock className="w-3.5 h-3.5" />
                <span>{isEn ? 'Verify & Continue' : 'যাচাই ও এগিয়ে যান'}</span>
              </button>
            </div>
          </form>
        ) : (
          <div className="space-y-4">
            <div
              className={`p-3.5 rounded-2xl border text-xs leading-relaxed ${
                isLight
                  ? 'bg-slate-50 border-slate-200 text-slate-700'
                  : 'bg-slate-900/60 border-slate-700 text-slate-300'
              }`}
            >
              <p>
                {isEn
                  ? 'No security PIN is currently configured. Click confirm to proceed.'
                  : 'বর্তমানে কোনো নিরাপত্তা পিন সেট করা নেই। নিশ্চিত করতে নিচের বাটনে চাপুন।'}
              </p>
            </div>

            {onSaveNewPassword && (
              <div className="text-center">
                <button
                  type="button"
                  onClick={() => setIsSettingNew(true)}
                  className="text-xs text-sky-500 hover:underline font-semibold cursor-pointer"
                >
                  {isEn ? '+ Set a custom security PIN' : '+ কাস্টম নিরাপত্তা পিন সেট করুন'}
                </button>
              </div>
            )}

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={onClose}
                className={`flex-1 py-2.5 px-4 rounded-xl font-medium text-xs border ${
                  isLight
                    ? 'border-slate-200 text-slate-700 hover:bg-slate-100'
                    : 'border-slate-700 text-slate-300 hover:bg-slate-700/50'
                } transition cursor-pointer`}
              >
                {isEn ? 'Cancel' : 'বাতিল'}
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onSuccess) onSuccess();
                  if (onVerified) onVerified();
                }}
                className="flex-1 py-2.5 px-4 rounded-xl text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer"
                style={{ backgroundColor: dualAccent.primary.hex }}
              >
                <CheckCircle className="w-3.5 h-3.5" />
                <span>{isEn ? 'Confirm & Continue' : 'নিশ্চিত ও অগ্রসর হোন'}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
