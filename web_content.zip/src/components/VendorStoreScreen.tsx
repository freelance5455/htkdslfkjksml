import React, { useState } from 'react';
import { ArrowLeft, Star, Heart, Share2, Ticket, MessageSquare, Check, ShieldCheck } from 'lucide-react';
import { Product, Vendor } from '../types/ecommerce';
import { VENDORS } from '../data/mockData';

interface VendorStoreScreenProps {
  vendorId: string;
  products: Product[];
  onBack: () => void;
  onSelectProduct: (product: Product) => void;
  onOpenChat: (vendor: Vendor) => void;
}

export const VendorStoreScreen: React.FC<VendorStoreScreenProps> = ({
  vendorId,
  products,
  onBack,
  onSelectProduct,
  onOpenChat
}) => {
  const [isFollowing, setIsFollowing] = useState(false);
  const [activeTab, setActiveTab] = useState<'all' | 'popular' | 'vouchers'>('all');
  const [claimedVouchers, setClaimedVouchers] = useState<string[]>([]);

  const vendor: Vendor = VENDORS[vendorId] || VENDORS['v1'];
  const vendorProducts = products.filter(p => p.vendorId === vendorId);

  const handleClaim = (vchId: string) => {
    setClaimedVouchers([...claimedVouchers, vchId]);
  };

  return (
    <div className="pb-24 bg-slate-100 min-h-screen">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-md px-3 py-2.5 flex items-center justify-between border-b border-slate-200">
        <button
          onClick={onBack}
          className="p-1 rounded-full hover:bg-slate-100 text-slate-700 transition-colors"
          aria-label="Back"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <span className="text-xs font-bold text-slate-800">Official Store</span>
        <button 
          onClick={() => alert('Store link copied')}
          className="p-1 text-slate-600 hover:text-slate-900"
        >
          <Share2 className="w-4 h-4" />
        </button>
      </div>

      {/* Store Banner & Brand Info */}
      <div className="bg-slate-900 text-white relative">
        <div className="h-28 overflow-hidden opacity-40">
          <img src={vendor.banner} alt="" className="w-full h-full object-cover" />
        </div>

        <div className="p-3.5 absolute bottom-0 left-0 right-0 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src={vendor.avatar}
              alt={vendor.name}
              className="w-13 h-13 rounded-full border-2 border-white object-cover"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm font-bold text-white leading-tight">{vendor.name}</h2>
                <span className="bg-[#FF6600] text-white text-[8px] font-black px-1.5 py-0.2 rounded">
                  {vendor.badge}
                </span>
              </div>
              <p className="text-[10px] text-slate-300">
                {vendor.followersCount} Followers · {vendor.positiveFeedbackPercent}% Positive
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => onOpenChat(vendor)}
              className="p-2 bg-white/20 hover:bg-white/30 rounded-xl text-white transition-colors"
              title="Chat with Seller"
            >
              <MessageSquare className="w-4 h-4" />
            </button>
            <button
              onClick={() => setIsFollowing(!isFollowing)}
              className={`text-xs font-bold px-3 py-1.5 rounded-xl transition-all ${
                isFollowing
                  ? 'bg-white/20 text-white border border-white/40'
                  : 'bg-[#FF6600] text-white shadow-md hover:bg-orange-600'
              }`}
            >
              {isFollowing ? 'Following' : '+ Follow'}
            </button>
          </div>
        </div>
      </div>

      {/* Store Vouchers Row */}
      {vendor.vouchers && vendor.vouchers.length > 0 && (
        <div className="bg-white p-3 border-b border-slate-200">
          <div className="text-xs font-bold text-slate-900 mb-2 flex items-center gap-1">
            <Ticket className="w-3.5 h-3.5 text-[#FF6600]" />
            <span>Exclusive Store Coupons</span>
          </div>
          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
            {vendor.vouchers.map((vch) => {
              const isClaimed = claimedVouchers.includes(vch.id);
              return (
                <div
                  key={vch.id}
                  className="min-w-[200px] bg-orange-50/60 border border-orange-200 rounded-xl p-2.5 flex items-center justify-between"
                >
                  <div>
                    <div className="font-extrabold text-xs text-[#FF6600]">{vch.discount}</div>
                    <div className="text-[10px] text-slate-500">Min. spend Rs. {vch.minSpend}</div>
                  </div>
                  <button
                    onClick={() => handleClaim(vch.id)}
                    disabled={isClaimed}
                    className={`text-[10px] font-bold px-2 py-1 rounded-lg transition-colors ${
                      isClaimed
                        ? 'bg-slate-200 text-slate-500'
                        : 'bg-[#FF6600] text-white hover:bg-orange-600'
                    }`}
                  >
                    {isClaimed ? 'Claimed' : 'Collect'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="bg-white border-b border-slate-200 px-3 flex gap-6 text-xs font-bold text-slate-600">
        <button
          onClick={() => setActiveTab('all')}
          className={`py-2.5 relative ${activeTab === 'all' ? 'text-[#FF6600]' : 'hover:text-slate-900'}`}
        >
          All Products ({vendorProducts.length})
          {activeTab === 'all' && (
            <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#FF6600]"></span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('popular')}
          className={`py-2.5 relative ${activeTab === 'popular' ? 'text-[#FF6600]' : 'hover:text-slate-900'}`}
        >
          Top Rated
          {activeTab === 'popular' && (
            <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#FF6600]"></span>
          )}
        </button>
      </div>

      {/* Product Grid */}
      <div className="p-2 grid grid-cols-2 gap-2">
        {vendorProducts.map((product) => (
          <div
            key={product.id}
            onClick={() => onSelectProduct(product)}
            className="bg-white rounded-xl border border-slate-100 overflow-hidden shadow-2xs hover:shadow-md transition-all cursor-pointer flex flex-col group"
          >
            <div className="relative aspect-square w-full bg-slate-50 overflow-hidden">
              <img
                src={product.images[0]}
                alt={product.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <span className="absolute top-1 left-1 bg-[#FF6600] text-white text-[9px] font-extrabold px-1 rounded">
                -{product.discountPercent}%
              </span>
            </div>

            <div className="p-2.5 flex-1 flex flex-col justify-between">
              <h4 className="text-xs font-semibold text-slate-900 line-clamp-2 leading-snug group-hover:text-[#FF6600] transition-colors">
                {product.title}
              </h4>

              <div className="mt-2 pt-1 border-t border-slate-50">
                <div className="text-xs font-extrabold text-[#FF6600] tabular-nums">
                  Rs. {product.price.toLocaleString()}
                </div>
                <div className="text-[10px] text-slate-400">
                  ★ {product.rating} · {product.soldCount} sold
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
