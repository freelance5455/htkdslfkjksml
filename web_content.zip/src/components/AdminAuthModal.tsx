import React, { useState } from 'react';
import { Lock, Unlock, ShieldAlert, X } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';
import { storage } from '../services/storage';

interface AdminAuthModalProps {
  language: Language;
  onSuccess: () => void;
  onClose: () => void;
}

export const AdminAuthModal: React.FC<AdminAuthModalProps> = ({
  language,
  onSuccess,
  onClose,
}) => {
  const t = translations[language];
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);

  const handleKeypadPress = (val: string) => {
    if (val === 'DEL') {
      setPin(prev => prev.slice(0, -1));
      setError(false);
      return;
    }
    if (pin.length < 4) {
      const nextPin = pin + val;
      setPin(nextPin);
      setError(false);
      if (nextPin.length === 4) {
        verifyPin(nextPin);
      }
    }
  };

  const verifyPin = (inputPin: string) => {
    const storedPin = storage.getAdminPin();
    if (inputPin === storedPin) {
      onSuccess();
    } else {
      setError(true);
      setTimeout(() => {
        setPin('');
      }, 500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
      <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-700/80 p-6 shadow-2xl text-center space-y-5">
        
        {/* Header */}
        <div className="flex justify-between items-center">
          <span className="text-xs font-bold uppercase tracking-wider text-cyan-400">
            {t.ownerOnly}
          </span>
          <button onClick={onClose} className="text-slate-400 hover:text-white font-bold">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center mx-auto">
          <Lock className="w-7 h-7" />
        </div>

        <div>
          <h3 className="text-lg font-black text-white">
            {t.enterPin}
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Default Owner PIN: <strong className="text-cyan-400 font-mono">1234</strong>
          </p>
        </div>

        {/* PIN Dots Indicator */}
        <div className="flex justify-center gap-4 py-2">
          {[0, 1, 2, 3].map(idx => (
            <div
              key={idx}
              className={`w-4 h-4 rounded-full transition-all ${
                error
                  ? 'bg-rose-500 scale-110 animate-bounce'
                  : pin.length > idx
                  ? 'bg-cyan-400 scale-110 shadow-lg shadow-cyan-400/50'
                  : 'bg-slate-700'
              }`}
            />
          ))}
        </div>

        {error && (
          <p className="text-xs text-rose-400 font-semibold animate-pulse">
            {t.incorrectPin}
          </p>
        )}

        {/* Numeric Keypad */}
        <div className="grid grid-cols-3 gap-2.5 pt-2">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(num => (
            <button
              key={num}
              onClick={() => handleKeypadPress(num)}
              className="py-3.5 rounded-2xl bg-slate-800/80 hover:bg-slate-750 active:bg-cyan-600 text-white font-bold text-lg font-mono transition shadow-sm"
            >
              {num}
            </button>
          ))}
          <button
            onClick={onClose}
            className="py-3.5 rounded-2xl bg-slate-850 hover:bg-slate-800 text-slate-400 font-medium text-xs transition"
          >
            Cancel
          </button>
          <button
            onClick={() => handleKeypadPress('0')}
            className="py-3.5 rounded-2xl bg-slate-800/80 hover:bg-slate-750 active:bg-cyan-600 text-white font-bold text-lg font-mono transition shadow-sm"
          >
            0
          </button>
          <button
            onClick={() => handleKeypadPress('DEL')}
            className="py-3.5 rounded-2xl bg-slate-850 hover:bg-rose-950/40 text-rose-400 font-bold text-xs transition"
          >
            Clear
          </button>
        </div>

      </div>
    </div>
  );
};
