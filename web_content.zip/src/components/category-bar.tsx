import { ChipBar } from "@/components/chip-bar";
import { TOPICS } from "@/lib/youtube/topics";
import type { TopicId } from "@/lib/youtube/types";

export function CategoryBar({
  value,
  onChange,
}: {
  value: TopicId;
  onChange: (id: TopicId) => void;
}) {
  return (
    <ChipBar
      ariaLabel="Categories"
      items={TOPICS.map((t) => ({ id: t.id, label: t.label }))}
      value={value}
      onChange={onChange}
    />
  );
}
