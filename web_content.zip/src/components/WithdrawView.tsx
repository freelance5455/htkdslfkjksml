import React, { useState } from 'react';
import { ShieldCheck, CheckCircle2, Clock, AlertCircle, ArrowUpRight, FileText, ChevronRight, Lock } from 'lucide-react';
import confetti from 'canvas-confetti';
import { PAYMENT_METHODS, COINS_PER_PKR } from '../data/mockData';
import { PaymentMethodId, WithdrawalRecord } from '../types';
import { soundEngine, triggerHaptic } from '../utils/audio';

interface WithdrawViewProps {
  coins: number;
  pkrBalance: number;
  withdrawalHistory: WithdrawalRecord[];
  onProcessWithdrawal: (record: WithdrawalRecord) => void;
  onViewReceipt: (record: WithdrawalRecord) => void;
}

export const WithdrawView: React.FC<WithdrawViewProps> = ({
  coins,
  pkrBalance,
  withdrawalHistory,
  onProcessWithdrawal,
  onViewReceipt,
}) => {
  const [selectedMethodId, setSelectedMethodId] = useState<PaymentMethodId>('easypaisa');
  const [selectedAmountPKR, setSelectedAmountPKR] = useState<number>(25);
  const [accountNumber, setAccountNumber] = useState<string>('');
  const [accountTitle, setAccountTitle] = useState<string>('');
  const [activeSubTab, setActiveSubTab] = useState<'request' | 'history'>('request');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submissionStep, setSubmissionStep] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');

  const selectedMethod = PAYMENT_METHODS.find((m) => m.id === selectedMethodId) || PAYMENT_METHODS[0];
  const coinsNeeded = selectedAmountPKR * COINS_PER_PKR;
  const hasEnoughCoins = coins >= coinsNeeded;

  const presetAmounts = [25, 50, 100, 250, 500, 1000];

  // Helper to format Pakistani phone number: 0300 1234567
  const handlePhoneChange = (val: string) => {
    // Keep only numbers
    const clean = val.replace(/\D/g, '').slice(0, 11);
    setAccountNumber(clean);
  };

  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!accountNumber || accountNumber.length < 11) {
      setErrorMessage('Please enter a valid 11-digit mobile account number (03XX-XXXXXXX).');
      triggerHaptic('heavy');
      return;
    }

    if (!accountTitle.trim() || accountTitle.trim().length < 3) {
      setErrorMessage('Please enter the exact Account Title / Full Name as on your CNIC.');
      triggerHaptic('heavy');
      return;
    }

    if (!hasEnoughCoins) {
      const deficit = coinsNeeded - coins;
      setErrorMessage(`Insufficient coins. You need ${deficit.toLocaleString()} more coins for Rs. ${selectedAmountPKR}. Tap more to earn!`);
      triggerHaptic('heavy');
      return;
    }

    // Begin interactive verification & disbursement simulation
    setIsSubmitting(true);
    triggerHaptic('medium');
    setSubmissionStep('Verifying Account Title via 1Link Switch...');

    setTimeout(() => {
      setSubmissionStep(`Authorizing ${selectedMethod.name} Instant Payout...`);
      soundEngine.playCoin();

      setTimeout(() => {
        setIsSubmitting(false);
        setSubmissionStep('');

        // Generate Transaction Record
        const prefix = selectedMethodId === 'easypaisa' ? 'EP' : selectedMethodId === 'jazzcash' ? 'JC' : 'TRX';
        const randomNum = Math.floor(10000000 + Math.random() * 90000000);
        const trxId = `${prefix}-${randomNum}`;

        const newRecord: WithdrawalRecord = {
          id: String(Date.now()),
          trxId,
          method: selectedMethodId,
          methodName: selectedMethod.name,
          accountNumber,
          accountTitle: accountTitle.trim(),
          amountPKR: selectedAmountPKR,
          coinsDebited: coinsNeeded,
          feePKR: 0,
          status: 'completed',
          timestamp: Date.now(),
          estimatedArrival: 'Instant Transfer Completed',
        };

        // Trigger celebratory sound & confetti
        soundEngine.playCashRegister();
        triggerHaptic('success');
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#00C25E', '#ED1C24', '#FBBF24', '#38BDF8'],
        });

        onProcessWithdrawal(newRecord);
        onViewReceipt(newRecord);
      }, 1200);
    }, 1000);
  };

  return (
    <div className="max-w-md mx-auto px-4 py-3 space-y-4 pb-20">
      {/* Top Banner & Balance */}
      <div className="bg-gradient-to-r from-emerald-950/60 via-slate-900 to-slate-900 border border-emerald-800/40 rounded-2xl p-4 shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider">
              Withdrawable Balance
            </span>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-2xl font-black text-emerald-400 font-mono-num font-display">
                Rs. {pkrBalance.toFixed(2)}
              </span>
              <span className="text-xs text-slate-400 font-mono-num">
                ({coins.toLocaleString()} Coins)
              </span>
            </div>
          </div>
          <div className="text-right">
            <span className="text-[11px] font-semibold text-slate-400 block">Rate</span>
            <span className="text-xs font-bold text-amber-300 font-mono-num">
              100 Coins = 1 PKR
            </span>
          </div>
        </div>

        <div className="mt-3 pt-2.5 border-t border-slate-800/80 space-y-2">
          {/* Milestone progress toward minimum cashout */}
          <div className="space-y-1">
            <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono-num">
              <span>Next Cashout Goal (Rs. 25):</span>
              <span className="font-bold text-amber-300">
                {Math.min(100, Math.round((coins / 2500) * 100))}% ({Math.min(coins, 2500).toLocaleString()} / 2,500 Coins)
              </span>
            </div>
            <div className="w-full h-1.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 to-green-400 rounded-full transition-all duration-300"
                style={{ width: `${Math.min(100, Math.round((coins / 2500) * 100))}%` }}
              />
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-300">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>0% Fee · Direct Mobile Wallets</span>
            </span>
            <span className="text-[11px] text-emerald-400 font-bold">Min. Rs. 25 (2,500 Coins)</span>
          </div>
        </div>
      </div>

      {/* Sub-tab navigation */}
      <div className="flex items-center p-1 bg-slate-900 border border-slate-800 rounded-xl">
        <button
          onClick={() => {
            triggerHaptic('light');
            setActiveSubTab('request');
          }}
          className={`flex-1 py-2 text-xs font-bold rounded-lg transition-colors ${
            activeSubTab === 'request'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Withdraw Cash
        </button>
        <button
          onClick={() => {
            triggerHaptic('light');
            setActiveSubTab('history');
          }}
          className={`flex-1 py-2 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
            activeSubTab === 'history'
              ? 'bg-slate-800 text-white shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <span>History & Receipts</span>
          {withdrawalHistory.length > 0 && (
            <span className="px-1.5 py-0.2 bg-emerald-500/20 text-emerald-300 rounded text-[10px] font-mono-num">
              {withdrawalHistory.length}
            </span>
          )}
        </button>
      </div>

      {activeSubTab === 'request' ? (
        <form onSubmit={handleWithdrawSubmit} className="space-y-4">
          {/* Payment Method Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-2">
              Select Payout Account
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              {PAYMENT_METHODS.map((method) => {
                const isSelected = selectedMethodId === method.id;
                return (
                  <button
                    key={method.id}
                    type="button"
                    onClick={() => {
                      triggerHaptic('light');
                      soundEngine.playTap(1);
                      setSelectedMethodId(method.id);
                    }}
                    className={`relative p-3 rounded-xl border text-left transition-all flex flex-col justify-between ${
                      isSelected
                        ? 'border-amber-400/80 bg-slate-800/90 shadow-md ring-1 ring-amber-400/50'
                        : 'border-slate-800 bg-slate-900/60 hover:bg-slate-900 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      {method.badgeUrl ? (
                        <img
                          src={method.badgeUrl}
                          alt={method.name}
                          referrerPolicy="no-referrer"
                          className="w-7 h-7 rounded-lg object-cover shadow-sm shrink-0"
                        />
                      ) : (
                        <div
                          className="w-7 h-7 rounded-lg flex items-center justify-center text-xs font-black text-white shrink-0"
                          style={{ backgroundColor: method.color }}
                        >
                          {method.name.slice(0, 2)}
                        </div>
                      )}
                      <div className="truncate">
                        <span className="text-xs font-bold text-white block truncate leading-tight">
                          {method.name}
                        </span>
                        <span className="text-[10px] text-slate-400 block truncate">
                          {method.id === 'easypaisa'
                            ? 'Telenor Bank'
                            : method.id === 'jazzcash'
                            ? 'Mobilink Bank'
                            : 'Direct'}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-slate-400 font-medium">Instant</span>
                      {isSelected && (
                        <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Amount Selection */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-2">
              Select Cash Amount (PKR)
            </label>
            <div className="grid grid-cols-3 gap-2">
              {presetAmounts.map((amt) => {
                const isSelected = selectedAmountPKR === amt;
                const cost = amt * COINS_PER_PKR;
                const affordable = coins >= cost;

                return (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => {
                      triggerHaptic('light');
                      setSelectedAmountPKR(amt);
                    }}
                    className={`py-2 px-2.5 rounded-xl border text-center transition-all ${
                      isSelected
                        ? 'border-emerald-500 bg-emerald-950/40 text-emerald-300 font-bold ring-1 ring-emerald-500'
                        : affordable
                        ? 'border-slate-800 bg-slate-900 text-slate-200 hover:border-slate-700'
                        : 'border-slate-800/50 bg-slate-900/40 text-slate-500'
                    }`}
                  >
                    <span className="text-sm font-black font-mono-num block">Rs. {amt}</span>
                    <span className="text-[10px] text-slate-400 font-mono-num block mt-0.5">
                      {cost.toLocaleString()} coins
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Account Details Inputs */}
          <div className="space-y-3 bg-slate-900/60 border border-slate-800 rounded-2xl p-3.5">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {selectedMethod.inputLabel}
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={accountNumber}
                  onChange={(e) => handlePhoneChange(e.target.value)}
                  placeholder={selectedMethod.placeholder}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 font-mono-num"
                  required
                />
              </div>
              <p className="text-[10px] text-slate-500 mt-1">
                Enter your 11-digit active mobile number without dashes or spaces.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Account Title (CNIC Registered Full Name)
              </label>
              <input
                type="text"
                value={accountTitle}
                onChange={(e) => setAccountTitle(e.target.value)}
                placeholder="e.g. Naveed Gabol"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                required
              />
              <p className="text-[10px] text-slate-500 mt-1">
                Must match your registered {selectedMethod.name} account title for instant clearance.
              </p>
            </div>
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div className="p-3 bg-rose-950/50 border border-rose-800/80 rounded-xl flex items-center gap-2 text-xs text-rose-300">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Cost breakdown summary */}
          <div className="bg-slate-900 border border-slate-800/90 rounded-xl p-3 text-xs space-y-1.5">
            <div className="flex items-center justify-between text-slate-400">
              <span>Debited Coins:</span>
              <span className="font-mono-num text-amber-400 font-bold">
                -{coinsNeeded.toLocaleString()} Coins
              </span>
            </div>
            <div className="flex items-center justify-between text-slate-400">
              <span>Transfer Fee (0% Special):</span>
              <span className="font-mono-num text-emerald-400 font-bold">Free (Rs. 0)</span>
            </div>
            <div className="pt-1.5 border-t border-slate-800 flex items-center justify-between font-bold text-white">
              <span>Net Cash to Receive:</span>
              <span className="font-mono-num text-base text-emerald-400 font-display">
                Rs. {selectedAmountPKR}
              </span>
            </div>
          </div>

          {/* Submit Action */}
          <button
            type="submit"
            disabled={isSubmitting}
            className={`w-full h-12 rounded-xl font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-[0.98] ${
              hasEnoughCoins && !isSubmitting
                ? 'bg-gradient-to-r from-emerald-500 to-green-600 text-slate-950 hover:brightness-105 shadow-emerald-500/20'
                : isSubmitting
                ? 'bg-slate-800 text-slate-400 cursor-not-allowed'
                : 'bg-slate-800 text-slate-400 hover:bg-slate-800'
            }`}
          >
            {isSubmitting ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
                <span className="text-white text-xs font-semibold">{submissionStep}</span>
              </div>
            ) : hasEnoughCoins ? (
              <>
                <Lock className="w-4 h-4 text-slate-950" />
                <span>Withdraw Rs. {selectedAmountPKR} to {selectedMethod.name}</span>
              </>
            ) : (
              <span>Need {(coinsNeeded - coins).toLocaleString()} More Coins to Cash Out</span>
            )}
          </button>
        </form>
      ) : (
        /* History & Receipts Tab */
        <div className="space-y-3">
          {withdrawalHistory.length === 0 ? (
            <div className="text-center py-12 px-4 bg-slate-900/40 border border-slate-800/80 rounded-2xl">
              <FileText className="w-10 h-10 text-slate-600 mx-auto mb-2" />
              <h3 className="text-sm font-bold text-slate-300">No Withdrawals Yet</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                Tap the coin to collect coins and request your first real payout to Easypaisa or JazzCash!
              </p>
            </div>
          ) : (
            withdrawalHistory.map((item) => (
              <div
                key={item.id}
                onClick={() => onViewReceipt(item)}
                className="bg-slate-900/70 hover:bg-slate-900 border border-slate-800 rounded-xl p-3 cursor-pointer transition-colors flex items-center justify-between group"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-lg flex items-center justify-center font-black text-xs text-white shrink-0 ${
                      item.method === 'easypaisa' ? 'bg-emerald-600' : 'bg-red-600'
                    }`}
                  >
                    {item.method === 'easypaisa' ? 'EP' : 'JC'}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white">
                        Rs. {item.amountPKR}
                      </span>
                      <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-0.5">
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        <span>Completed</span>
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-400">
                      {item.methodName} · {item.accountNumber.slice(0, 4)}***{item.accountNumber.slice(-3)}
                    </p>
                    <p className="text-[10px] text-slate-500 font-mono-num">
                      {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} · {item.trxId}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1 text-slate-400 group-hover:text-emerald-400 transition-colors">
                  <span className="text-xs font-semibold hidden sm:inline">Receipt</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
