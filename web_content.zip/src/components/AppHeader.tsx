import React from 'react';
import { Menu, Droplet, Bell, Share2 } from 'lucide-react';

interface AppHeaderProps {
  onOpenDrawer: () => void;
  onOpenTheme: () => void;
  onOpenNotification: () => void;
  onOpenShare: () => void;
  selectedClass: '11' | '12';
  onChangeClass: (c: '11' | '12') => void;
  notificationCount: number;
  themeMode: 'teal' | 'sepia' | 'dark';
}

export const AppHeader: React.FC<AppHeaderProps> = ({
  onOpenDrawer,
  onOpenTheme,
  onOpenNotification,
  onOpenShare,
  selectedClass,
  onChangeClass,
  notificationCount,
  themeMode,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-[#00838f] text-white shadow-md transition-colors duration-200">
      <div className="max-w-md mx-auto px-4 h-14 flex items-center justify-between">
        {/* Left: Hamburger menu */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenDrawer}
            aria-label="मेनू खोलें"
            className="w-10 h-10 -ml-1.5 flex items-center justify-center rounded-full hover:bg-white/15 active:bg-white/25 transition-colors"
          >
            <Menu className="w-6 h-6 text-white" />
          </button>

          {/* Title with Class Dropdown */}
          <div className="flex items-center gap-1.5">
            <h1 className="text-lg font-bold tracking-tight truncate max-w-[170px] sm:max-w-xs font-devanagari">
              कक्षा {selectedClass} जीव वि...
            </h1>
            <select
              value={selectedClass}
              onChange={(e) => onChangeClass(e.target.value as '11' | '12')}
              className="text-xs bg-white/20 text-white font-medium rounded px-1 py-0.5 border border-white/30 focus:outline-none cursor-pointer"
              title="कक्षा बदलें"
            >
              <option value="11" className="text-slate-900">11वीं</option>
              <option value="12" className="text-slate-900">12वीं</option>
            </select>
          </div>
        </div>

        {/* Right Action Icons: Droplet (Theme), Bell (Notifications), Share */}
        <div className="flex items-center gap-1">
          {/* Water droplet / eye-comfort reading mode */}
          <button
            onClick={onOpenTheme}
            aria-label="रीडिंग मोड / थीम बदलें"
            title={`वर्तमान थीम: ${themeMode}`}
            className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-white/15 active:bg-white/25 transition-colors relative"
          >
            <Droplet className={`w-5 h-5 ${themeMode === 'sepia' ? 'fill-amber-300 text-amber-200' : themeMode === 'dark' ? 'fill-slate-300 text-slate-200' : 'fill-white/80 text-white'}`} />
          </button>

          {/* Notification bell */}
          <button
            onClick={onOpenNotification}
            aria-label="नोटिफिकेशन देखें"
            title="नवीनतम अपडेट एवं परीक्षा सूचना"
            className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-white/15 active:bg-white/25 transition-colors relative"
          >
            <Bell className="w-5 h-5 text-white" />
            {notificationCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full ring-2 ring-[#00838f]" />
            )}
          </button>

          {/* Share icon */}
          <button
            onClick={onOpenShare}
            aria-label="ऐप शेयर करें"
            title="दोस्तों के साथ शेयर करें"
            className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-white/15 active:bg-white/25 transition-colors"
          >
            <Share2 className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>
    </header>
  );
};
