import React, { useState } from 'react';
import { FileArchive, FileCode2, Plus, Upload, X } from 'lucide-react';
import { ApiError, apiRequest } from '../lib/api';
import type { ProjectSummary } from '../types/studio';

interface UploadCreateModalProps {
  initialMode: 'html' | 'zip' | 'create';
  maxUploadMb: number;
  onClose: () => void;
  onProjectCreated: (
    project: ProjectSummary,
    entryOptions?: { needsSelection: boolean; htmlFiles: string[] }
  ) => void;
  onRequireUpgrade: (message: string) => void;
}

export const UploadCreateModal: React.FC<UploadCreateModalProps> = ({
  initialMode,
  maxUploadMb,
  onClose,
  onProjectCreated,
  onRequireUpgrade,
}) => {
  const [tab, setTab] = useState<'html' | 'zip' | 'create'>(initialMode);
  const [projectName, setProjectName] = useState('');
  const [packageName, setPackageName] = useState('com.htmltoapk.yeniuygulama');
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [htmlContent, setHtmlContent] = useState(
    `<!DOCTYPE html>\n<html lang="tr">\n<head>\n  <meta charset="UTF-8" />\n  <meta name="viewport" content="width=device-width, initial-scale=1.0" />\n  <title>Mobil Web Uygulamam</title>\n  <link rel="stylesheet" href="css/style.css" />\n</head>\n<body>\n  <main class="card">\n    <h1>Merhaba Android</h1>\n    <p>HTML TO APK STUDIO ile derlendi.</p>\n    <button id="btn" type="button">Etkileşimi Test Et</button>\n    <div id="msg"></div>\n  </main>\n  <script src="js/app.js"></script>\n</body>\n</html>`
  );
  const [cssContent, setCssContent] = useState(
    `body { margin: 0; font-family: system-ui, sans-serif; background: #0b1020; color: #f8fafc; min-height: 100vh; display: grid; place-items: center; padding: 20px; }\n.card { background: #151d2e; border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; padding: 24px; max-width: 400px; width: 100%; }\nbutton { margin-top: 12px; background: #6366f1; color: #fff; border: 0; border-radius: 10px; padding: 10px 16px; font-weight: 600; }`
  );
  const [jsContent, setJsContent] = useState(
    `document.getElementById('btn')?.addEventListener('click', () => {\n  document.getElementById('msg').textContent = 'WebView etkileşimi aktif!';\n});`
  );

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = e.target.files ? Array.from(e.target.files) : [];
    setSelectedFiles(list);
    setError(null);
  };

  const handleUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedFiles.length === 0) {
      setError('Lütfen en az bir dosya seçin.');
      return;
    }

    setSubmitting(true);
    setError(null);
    try {
      const form = new FormData();
      if (projectName.trim()) {
        form.append('name', projectName.trim());
      }
      const relPaths: string[] = [];
      for (const f of selectedFiles) {
        form.append('files', f);
        const rel = (f as File & { webkitRelativePath?: string }).webkitRelativePath || f.name;
        relPaths.push(rel);
      }
      form.append('relativePaths', JSON.stringify(relPaths));

      const res = await apiRequest<{
        project: ProjectSummary;
        entryFileNeedsSelection: boolean;
        htmlFiles: string[];
      }>('/api/projects/upload', {
        method: 'POST',
        body: form,
      });

      onProjectCreated(res.project, {
        needsSelection: res.entryFileNeedsSelection,
        htmlFiles: res.htmlFiles,
      });
    } catch (err) {
      if (err instanceof ApiError && err.upgradeRequired) {
        onRequireUpgrade(err.message);
        return;
      }
      setError(err instanceof Error ? err.message : 'Yükleme başarısız oldu.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const res = await apiRequest<{ project: ProjectSummary }>('/api/projects/create', {
        method: 'POST',
        body: JSON.stringify({
          name: projectName.trim() || 'Yeni Mobil Proje',
          packageName: packageName.trim(),
          htmlContent,
          cssContent,
          jsContent,
        }),
      });
      onProjectCreated(res.project);
    } catch (err) {
      if (err instanceof ApiError && err.upgradeRequired) {
        onRequireUpgrade(err.message);
        return;
      }
      setError(err instanceof Error ? err.message : 'Proje oluşturulamadı.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.1] rounded-2xl overflow-hidden max-h-[90vh] flex flex-col">
        <div className="px-6 py-4 border-b border-slate-200 dark:border-white/[0.08] flex items-center justify-between">
          <h2 className="text-base font-semibold text-slate-900 dark:text-[#F8FAFC]">
            Proje Yükle veya Oluştur
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-500 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white transition-colors"
            aria-label="Kapat"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Mode Tabs */}
        <div className="px-6 pt-4 flex flex-wrap items-center gap-2 border-b border-slate-200 dark:border-white/[0.08] pb-4">
          <button
            type="button"
            onClick={() => {
              setTab('zip');
              setSelectedFiles([]);
              setError(null);
            }}
            className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              tab === 'zip'
                ? 'bg-[#6366F1] text-white'
                : 'bg-slate-100 dark:bg-[#0B1020] text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-white/[0.06]'
            }`}
          >
            <FileArchive className="w-3.5 h-3.5" />
            <span>ZIP Projesi Yükle</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setTab('html');
              setSelectedFiles([]);
              setError(null);
            }}
            className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              tab === 'html'
                ? 'bg-[#6366F1] text-white'
                : 'bg-slate-100 dark:bg-[#0B1020] text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-white/[0.06]'
            }`}
          >
            <FileCode2 className="w-3.5 h-3.5" />
            <span>HTML / Web Dosyaları</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setTab('create');
              setError(null);
            }}
            className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              tab === 'create'
                ? 'bg-[#6366F1] text-white'
                : 'bg-slate-100 dark:bg-[#0B1020] text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-white/[0.06]'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Yeni Proje Oluştur</span>
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-5">
          {error && (
            <div className="px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/25 text-xs text-red-600 dark:text-red-300">
              {error}
            </div>
          )}

          {tab !== 'create' ? (
            <form onSubmit={handleUploadSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                  Proje Adı (Opsiyonel)
                </label>
                <input
                  type="text"
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  placeholder="ör. Kurumsal Mobil Katalog"
                  className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-4 py-2.5 text-sm text-slate-900 dark:text-[#F8FAFC] placeholder:text-slate-400 focus:outline-none focus:border-[#6366F1]"
                />
              </div>

              <label className="block border border-dashed border-slate-300 dark:border-white/[0.16] hover:border-[#6366F1] rounded-xl p-8 text-center cursor-pointer bg-slate-50 dark:bg-[#0B1020]/70 transition-colors">
                <Upload className="w-6 h-6 text-[#6366F1] mx-auto mb-3" />
                <p className="text-sm font-medium text-slate-900 dark:text-[#F8FAFC]">
                  {tab === 'zip'
                    ? 'ZIP proje arşivinizi seçin (.zip)'
                    : 'HTML, CSS, JS, JSON, PNG, JPG, SVG veya WebP dosyalarını seçin'}
                </p>
                <p className="mt-1 text-xs text-slate-500 dark:text-[#94A3B8]">
                  Maksimum yükleme sınırı: {maxUploadMb} MB · Klasör yapısı otomatik korunur
                </p>
                <input
                  type="file"
                  multiple={tab === 'html'}
                  accept={
                    tab === 'zip'
                      ? '.zip'
                      : '.html,.htm,.css,.js,.mjs,.json,.png,.jpg,.jpeg,.svg,.webp,.woff,.woff2,.ttf,.ico,.txt,.xml'
                  }
                  onChange={handleFileChange}
                  className="hidden"
                />
              </label>

              {selectedFiles.length > 0 && (
                <div className="bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.08] rounded-xl p-3 max-h-36 overflow-y-auto space-y-1">
                  {selectedFiles.map((f, idx) => (
                    <div
                      key={`${f.name}-${idx}`}
                      className="flex items-center justify-between text-xs text-slate-700 dark:text-[#CBD5E1]"
                    >
                      <span className="truncate font-mono">{f.name}</span>
                      <span className="text-slate-500 dark:text-[#94A3B8] tabular-nums shrink-0 ml-3">
                        {Math.round(f.size / 1024)} KB
                      </span>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-medium rounded-xl text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-white/[0.1]"
                >
                  Vazgeç
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 text-xs font-semibold rounded-xl bg-[#6366F1] hover:bg-[#5558E3] disabled:opacity-60 text-white"
                >
                  {submitting ? 'Yükleniyor...' : 'Projeyi İçe Aktar'}
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                    Proje Adı
                  </label>
                  <input
                    type="text"
                    required
                    value={projectName}
                    onChange={(e) => setProjectName(e.target.value)}
                    placeholder="Mobil Web Uygulamam"
                    className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3.5 py-2 text-sm text-slate-900 dark:text-[#F8FAFC] focus:outline-none focus:border-[#6366F1]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                    Android Paket Adı
                  </label>
                  <input
                    type="text"
                    required
                    value={packageName}
                    onChange={(e) => setPackageName(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl px-3.5 py-2 text-sm font-mono text-slate-900 dark:text-[#F8FAFC] focus:outline-none focus:border-[#6366F1]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1">
                  index.html
                </label>
                <textarea
                  rows={5}
                  value={htmlContent}
                  onChange={(e) => setHtmlContent(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl p-3 text-xs font-mono text-slate-900 dark:text-[#E2E8F0] focus:outline-none focus:border-[#6366F1]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1">
                    css/style.css
                  </label>
                  <textarea
                    rows={4}
                    value={cssContent}
                    onChange={(e) => setCssContent(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl p-3 text-xs font-mono text-slate-900 dark:text-[#E2E8F0] focus:outline-none focus:border-[#6366F1]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1">
                    js/app.js
                  </label>
                  <textarea
                    rows={4}
                    value={jsContent}
                    onChange={(e) => setJsContent(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.1] rounded-xl p-3 text-xs font-mono text-slate-900 dark:text-[#E2E8F0] focus:outline-none focus:border-[#6366F1]"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-medium rounded-xl text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-white/[0.1]"
                >
                  Vazgeç
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 text-xs font-semibold rounded-xl bg-[#6366F1] hover:bg-[#5558E3] disabled:opacity-60 text-white"
                >
                  {submitting ? 'Oluşturuluyor...' : 'Projeyi Oluştur'}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
