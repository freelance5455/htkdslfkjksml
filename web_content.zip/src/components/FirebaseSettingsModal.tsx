import React, { useState } from 'react';
import { 
  X, 
  Database, 
  CheckCircle2, 
  AlertCircle, 
  RefreshCw, 
  Key, 
  Shield, 
  HardDrive, 
  ExternalLink,
  Copy,
  Check
} from 'lucide-react';
import { testConnection, getActiveFirebaseConfig } from '../firebase/config';

interface FirebaseSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FirebaseSettingsModal: React.FC<FirebaseSettingsModalProps> = ({ isOpen, onClose }) => {
  const [config, setConfig] = useState(getActiveFirebaseConfig());
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Custom config form
  const [customJson, setCustomJson] = useState('');
  const [showCustomInput, setShowCustomInput] = useState(false);

  if (!isOpen) return null;

  const handleRunPing = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const res = await testConnection();
      if (res.success) {
        setTestResult({ success: true, message: 'Firestore connection active and responding normally (0 errors).' });
      } else {
        setTestResult({ success: false, message: `Status note: ${res.error || 'Offline cache enabled'}` });
      }
    } catch (err: any) {
      setTestResult({ success: false, message: err.message || 'Connection test failed' });
    } finally {
      setTesting(false);
    }
  };

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleSaveCustom = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const parsed = JSON.parse(customJson);
      if (!parsed.projectId || !parsed.apiKey) {
        alert('Invalid Firebase configuration object. projectId and apiKey are required.');
        return;
      }
      localStorage.setItem('facelook_custom_firebase_config', JSON.stringify(parsed));
      setConfig(parsed);
      setShowCustomInput(false);
      alert('Custom Firebase configuration saved! Reload the page to activate.');
    } catch {
      alert('Failed to parse JSON. Please paste a valid firebaseConfig object.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-xl rounded-3xl shadow-2xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-150 max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-linear-to-r from-orange-500 to-amber-600 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center">
              <Database className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="font-black text-lg sm:text-xl leading-tight">Firebase Configuration</h2>
              <p className="text-xs text-orange-100 font-medium">Status & Required Console Settings</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs sm:text-sm text-slate-700">
          
          {/* Active Config Summary */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-slate-900 text-xs uppercase tracking-wider">
                Current Connected Project
              </span>
              <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 font-bold text-[11px] px-2 py-0.5 rounded-full border border-emerald-200">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                Active
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                <span className="text-slate-400 block text-[10px] font-semibold">PROJECT ID</span>
                <span className="font-mono text-slate-900 font-medium truncate block">
                  {config.projectId}
                </span>
              </div>

              <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                <span className="text-slate-400 block text-[10px] font-semibold">AUTH DOMAIN</span>
                <span className="font-mono text-slate-900 font-medium truncate block">
                  {config.authDomain}
                </span>
              </div>

              <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                <span className="text-slate-400 block text-[10px] font-semibold">FIRESTORE DATABASE</span>
                <span className="font-mono text-slate-900 font-medium truncate block">
                  {config.firestoreDatabaseId || '(default)'}
                </span>
              </div>

              <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                <span className="text-slate-400 block text-[10px] font-semibold">STORAGE BUCKET</span>
                <span className="font-mono text-slate-900 font-medium truncate block">
                  {config.storageBucket}
                </span>
              </div>
            </div>

            {/* Live Ping Button */}
            <div className="pt-2 flex items-center justify-between">
              <button
                onClick={handleRunPing}
                disabled={testing}
                className="flex items-center gap-1.5 bg-white hover:bg-slate-100 text-slate-800 border border-slate-200 px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition-colors shadow-2xs"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${testing ? 'animate-spin' : ''}`} />
                <span>Test Firestore Connection</span>
              </button>

              {testResult && (
                <span className={`text-xs font-semibold ${testResult.success ? 'text-emerald-600' : 'text-amber-600'}`}>
                  {testResult.message}
                </span>
              )}
            </div>
          </div>

          {/* Required Console Settings Checklist */}
          <div className="space-y-3">
            <h3 className="font-bold text-slate-900 text-sm">
              Required Firebase Console Settings Explained:
            </h3>

            {/* 1. Auth */}
            <div className="p-3 bg-white border border-slate-200 rounded-xl flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#1877F2] flex items-center justify-center shrink-0">
                <Key className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-slate-900 text-xs sm:text-sm">1. Authentication Providers</h4>
                <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                  In Firebase Console &rarr; <strong>Authentication</strong> &rarr; <strong>Sign-in method</strong>:
                  Enable <strong>Email/Password</strong> and <strong>Anonymous</strong>. Anonymous allows seamless instant guest test sign-ins on Android.
                </p>
              </div>
            </div>

            {/* 2. Firestore */}
            <div className="p-3 bg-white border border-slate-200 rounded-xl flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-orange-50 text-orange-600 flex items-center justify-center shrink-0">
                <Shield className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-slate-900 text-xs sm:text-sm">2. Firestore Security Rules</h4>
                <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                  Security rules are defined in <code className="font-mono text-orange-600">firestore.rules</code> and deployed. Read is enabled for public posts, and writes are restricted to authenticated owners.
                </p>
              </div>
            </div>

            {/* 3. Storage & CORS */}
            <div className="p-3 bg-white border border-slate-200 rounded-xl flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                <HardDrive className="w-4 h-4" />
              </div>
              <div className="flex-1">
                <h4 className="font-bold text-slate-900 text-xs sm:text-sm">3. Storage & Phone Gallery Uploads</h4>
                <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                  For uploads from Android phones to cloud storage, Firebase Storage rules should allow authenticated uploads:
                </p>
                <div className="my-1.5 p-2 bg-slate-900 text-emerald-400 font-mono text-[11px] rounded-lg flex items-center justify-between">
                  <span>allow read, write: if request.auth != null;</span>
                  <button
                    onClick={() => handleCopy('allow read, write: if request.auth != null;', 'rules')}
                    className="text-slate-400 hover:text-white cursor-pointer"
                  >
                    {copiedKey === 'rules' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <p className="text-[11px] text-slate-500">
                  Note: FaceLook also includes an automatic client-side Base64/IndexedDB fallback engine so gallery uploads work seamlessly even if cloud storage is still configuring!
                </p>
              </div>
            </div>
          </div>

          {/* Connect Another Pre-Existing Firebase Project */}
          <div className="pt-2 border-t border-slate-200">
            <button
              onClick={() => setShowCustomInput(!showCustomInput)}
              className="text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center gap-1 cursor-pointer"
            >
              <span>{showCustomInput ? 'Hide' : 'Connect custom pre-existing Firebase credentials'}</span>
            </button>

            {showCustomInput && (
              <form onSubmit={handleSaveCustom} className="mt-2 space-y-2">
                <p className="text-xs text-slate-500">
                  Paste your <code className="font-mono text-slate-700">firebaseConfig</code> JSON object from Firebase Console &rarr; Project Settings:
                </p>
                <textarea
                  value={customJson}
                  onChange={(e) => setCustomJson(e.target.value)}
                  placeholder='{"apiKey": "AIza...", "authDomain": "...", "projectId": "...", "storageBucket": "..."}'
                  rows={4}
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs font-mono focus:outline-hidden focus:border-orange-500"
                />
                <button
                  type="submit"
                  className="bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs px-4 py-2 rounded-xl cursor-pointer"
                >
                  Save and Use Custom Config
                </button>
              </form>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
