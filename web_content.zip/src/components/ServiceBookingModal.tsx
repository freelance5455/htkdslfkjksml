import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Wrench, 
  MessageCircle, 
  Laptop, 
  Video, 
  Printer, 
  Terminal, 
  HardDrive, 
  Network,
  Calendar,
  Clock,
  MapPin,
  Home,
  Store,
  AlertCircle
} from 'lucide-react';
import { ServiceBookingFormData } from '../types';

export const ServiceBookingModal: React.FC = () => {
  const { 
    isServiceModalOpen, 
    closeServiceModal, 
    selectedServiceForBooking, 
    language, 
    t, 
    shopSettings,
    sendServiceBookingViaWhatsApp 
  } = useApp();

  const [formData, setFormData] = useState<ServiceBookingFormData>({
    customerName: '',
    phoneNumber: '',
    alternatePhone: '',
    address: '',
    serviceType: '',
    deviceType: 'Laptop',
    problemDescription: '',
    preferredDate: new Date().toISOString().split('T')[0],
    preferredTimeSlot: 'Morning (10 AM - 1 PM)',
    serviceMode: 'home_service',
    targetWhatsAppNumber: shopSettings.phone1
  });

  const [formError, setFormError] = useState('');

  useEffect(() => {
    if (selectedServiceForBooking) {
      setFormData(prev => ({
        ...prev,
        serviceType: selectedServiceForBooking.name[language] || selectedServiceForBooking.name.en,
        deviceType: selectedServiceForBooking.category === 'cctv' || selectedServiceForBooking.category === 'dvr_nvr' 
          ? 'CCTV System' 
          : selectedServiceForBooking.category === 'printer' 
          ? 'Printer' 
          : selectedServiceForBooking.category === 'networking' 
          ? 'Networking / Wi-Fi' 
          : 'Laptop'
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        serviceType: language === 'hi' ? 'कंप्यूटर / लैपटॉप रिपेयर' : 'Laptop / PC Repair'
      }));
    }
  }, [selectedServiceForBooking, language]);

  if (!isServiceModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.customerName.trim()) {
      setFormError(language === 'hi' ? 'कृपया अपना पूरा नाम लिखें।' : 'Please enter your full name.');
      return;
    }
    const cleanPhone = formData.phoneNumber.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      setFormError(language === 'hi' ? 'कृपया सही 10 अंकों का मोबाइल नंबर लिखें।' : 'Please enter a valid 10-digit mobile number.');
      return;
    }
    if (!formData.address.trim()) {
      setFormError(language === 'hi' ? 'कृपया अपना पूरा पता या इलाका लिखें।' : 'Please provide your address/location.');
      return;
    }
    if (!formData.problemDescription.trim()) {
      setFormError(language === 'hi' ? 'कृपया समस्या का विवरण दें।' : 'Please describe the problem.');
      return;
    }

    setFormError('');
    sendServiceBookingViaWhatsApp(formData);
    closeServiceModal();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-5 sm:p-7 my-6">
        {/* Close Button */}
        <button
          onClick={closeServiceModal}
          className="absolute top-4 right-4 rounded-full p-2 text-slate-400 hover:text-white hover:bg-slate-800 transition"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30 flex-shrink-0">
            <Wrench className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white">
              {t.serviceModal.title}
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              {t.serviceModal.subtitle}
            </p>
          </div>
        </div>

        {formError && (
          <div className="mb-4 p-3 rounded-lg bg-red-950/60 border border-red-500/40 text-red-200 text-xs font-medium flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{formError}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
          {/* Service Mode Selector: Home Service vs Shop Visit */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 uppercase tracking-wider">
              {t.serviceModal.serviceMode} *
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <label className={`cursor-pointer p-3 rounded-xl border flex items-center gap-3 transition ${
                formData.serviceMode === 'home_service'
                  ? 'bg-blue-600/20 border-blue-500 text-white'
                  : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
              }`}>
                <input
                  type="radio"
                  name="serviceMode"
                  value="home_service"
                  checked={formData.serviceMode === 'home_service'}
                  onChange={() => setFormData({ ...formData, serviceMode: 'home_service' })}
                  className="hidden"
                />
                <Home className="w-5 h-5 text-blue-400 flex-shrink-0" />
                <span className="text-xs font-semibold">
                  {t.serviceModal.homeVisit}
                </span>
              </label>

              <label className={`cursor-pointer p-3 rounded-xl border flex items-center gap-3 transition ${
                formData.serviceMode === 'shop_visit'
                  ? 'bg-blue-600/20 border-blue-500 text-white'
                  : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
              }`}>
                <input
                  type="radio"
                  name="serviceMode"
                  value="shop_visit"
                  checked={formData.serviceMode === 'shop_visit'}
                  onChange={() => setFormData({ ...formData, serviceMode: 'shop_visit' })}
                  className="hidden"
                />
                <Store className="w-5 h-5 text-blue-400 flex-shrink-0" />
                <span className="text-xs font-semibold">
                  {t.serviceModal.shopVisit}
                </span>
              </label>
            </div>
          </div>

          {/* Name & Mobile Number */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {t.serviceModal.name} *
              </label>
              <input
                type="text"
                required
                value={formData.customerName}
                onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                placeholder="e.g. Rahul Sharma"
                className="w-full px-3 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {t.serviceModal.phone} *
              </label>
              <input
                type="tel"
                required
                value={formData.phoneNumber}
                onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                placeholder="e.g. 9876543210"
                className="w-full px-3 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          {/* Address */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              {language === 'hi' ? 'पूरा पता व लैंडमार्क' : 'Full Address & Nearest Landmark'} *
            </label>
            <textarea
              required
              rows={2}
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              placeholder={language === 'hi' ? 'उदा. मकान नंबर 45, गांधी नगर, शिव मंदिर के पास' : 'e.g. House No. 45, Gandhi Nagar, Near Shiv Temple'}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Device Type & Service Type */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {t.serviceModal.deviceType} *
              </label>
              <select
                value={formData.deviceType}
                onChange={(e) => setFormData({ ...formData, deviceType: e.target.value as any })}
                className="w-full px-3 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500"
              >
                <option value="Laptop">Laptop (लैपटॉप)</option>
                <option value="Desktop PC">Desktop PC (कंप्यूटर / डेस्कटॉप)</option>
                <option value="CCTV System">CCTV Cameras / Setup (सीसीटीवी)</option>
                <option value="DVR/NVR">DVR / NVR Recorder (डीवीआर)</option>
                <option value="Printer">Printer / Cartridge (प्रिंटर)</option>
                <option value="Networking / Wi-Fi">Networking / Wi-Fi Router</option>
                <option value="Other">Other Device (अन्य उपकरण)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {language === 'hi' ? 'सर्विस का नाम' : 'Service Type'}
              </label>
              <input
                type="text"
                value={formData.serviceType}
                onChange={(e) => setFormData({ ...formData, serviceType: e.target.value })}
                className="w-full px-3 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          {/* Problem Description */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              {t.serviceModal.problem} *
            </label>
            <textarea
              required
              rows={2}
              value={formData.problemDescription}
              onChange={(e) => setFormData({ ...formData, problemDescription: e.target.value })}
              placeholder={t.serviceModal.problemPlaceholder}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Preferred Date & Time Slot */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {t.serviceModal.preferredDate}
              </label>
              <input
                type="date"
                value={formData.preferredDate}
                onChange={(e) => setFormData({ ...formData, preferredDate: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500 text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {t.serviceModal.preferredSlot}
              </label>
              <select
                value={formData.preferredTimeSlot}
                onChange={(e) => setFormData({ ...formData, preferredTimeSlot: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500 text-xs"
              >
                <option value="Morning (10 AM - 1 PM)">सुबह (10 AM - 1 PM)</option>
                <option value="Afternoon (1 PM - 4 PM)">दोपहर (1 PM - 4 PM)</option>
                <option value="Evening (4 PM - 8 PM)">शाम (4 PM - 8 PM)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {t.serviceModal.selectNumber}
              </label>
              <select
                value={formData.targetWhatsAppNumber}
                onChange={(e) => setFormData({ ...formData, targetWhatsAppNumber: e.target.value })}
                className="w-full px-2 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500 text-xs"
              >
                <option value={shopSettings.phone1}>{shopSettings.phone1} (Main)</option>
                <option value={shopSettings.phone2}>{shopSettings.phone2} (Secondary)</option>
              </select>
            </div>
          </div>

          {/* Disclaimer */}
          <p className="text-[11px] text-slate-400 bg-slate-950 p-2.5 rounded-lg border border-slate-800">
            {t.serviceModal.disclaimer}
          </p>

          {/* Submit */}
          <button
            type="submit"
            className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg shadow-emerald-600/30 transition flex items-center justify-center gap-2"
          >
            <MessageCircle className="w-5 h-5" />
            <span>{t.serviceModal.submitBtn}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
