import React, { useState } from 'react';
import {
  X,
  Coins,
  Crown,
  Zap,
  History,
  ShieldCheck,
  CreditCard,
} from 'lucide-react';
import { CreditTransaction } from '../types/index.ts';

interface CreditsModalProps {
  currentCredits: number;
  transactions: CreditTransaction[];
  onClose: () => void;
  onPurchase: (credits: number, priceStr: string) => void;
}

export const CreditsModal: React.FC<CreditsModalProps> = ({
  currentCredits,
  transactions,
  onClose,
  onPurchase,
}) => {
  const [activeTab, setActiveTab] = useState<'packages' | 'history'>('packages');

  const PACKAGES = [
    {
      id: 'tier_50',
      credits: 50,
      price: '$2.99',
      label: 'Starter Pack',
      popular: false,
      numbersEstimate: 'Up to 5 quick numbers',
    },
    {
      id: 'tier_150',
      credits: 150,
      price: '$6.99',
      label: 'Power User',
      popular: true,
      numbersEstimate: 'Up to 15 quick numbers',
    },
    {
      id: 'tier_500',
      credits: 500,
      price: '$19.99',
      label: 'Developer & Pro',
      popular: false,
      numbersEstimate: '50+ numbers & 7-day rentals',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-6 shadow-2xl relative max-h-[92vh] overflow-y-auto text-slate-800">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 p-1 rounded-full hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* CURRENT BALANCE HERO */}
        <div className="bg-gradient-to-r from-blue-50 via-sky-50 to-blue-50 border border-blue-200 rounded-2xl p-4 mb-5 text-center shadow-xs">
          <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center mx-auto mb-2 shadow-md shadow-blue-600/20">
            <Coins className="w-6 h-6" />
          </div>
          <div className="text-xs text-blue-800 font-bold uppercase tracking-wider">Your Active Balance</div>
          <div className="text-3xl font-extrabold font-mono text-blue-900 my-1">{currentCredits} Credits</div>
          <div className="text-[11px] text-slate-500">10 credits = 1 temporary number (20m window)</div>
        </div>

        {/* TABS */}
        <div className="grid grid-cols-2 p-1 bg-slate-100 rounded-xl border border-slate-200 mb-5">
          <button
            type="button"
            onClick={() => setActiveTab('packages')}
            className={`py-2 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
              activeTab === 'packages' ? 'bg-white text-blue-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Top Up Credits</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('history')}
            className={`py-2 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
              activeTab === 'history' ? 'bg-white text-blue-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Ledger History</span>
          </button>
        </div>

        {activeTab === 'packages' ? (
          <div className="space-y-3">
            {PACKAGES.map((pkg) => (
              <div
                key={pkg.id}
                className={`p-4 rounded-xl border transition-all relative ${
                  pkg.popular
                    ? 'bg-blue-50/50 border-blue-300 shadow-sm shadow-blue-500/10'
                    : 'bg-white border-slate-200'
                }`}
              >
                {pkg.popular && (
                  <span className="absolute -top-2.5 right-4 bg-blue-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                    Most Popular
                  </span>
                )}
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <h4 className="font-bold text-slate-900 text-sm">{pkg.label}</h4>
                    <p className="text-xs text-slate-500">{pkg.numbersEstimate}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-base font-extrabold text-blue-700">{pkg.price}</div>
                    <div className="text-[11px] font-mono text-slate-500">+{pkg.credits} credits</div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onPurchase(pkg.credits, pkg.price)}
                  className="w-full mt-2 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-sm shadow-blue-600/20"
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>Purchase with Card ({pkg.price})</span>
                </button>
              </div>
            ))}

            {/* VIP PASS */}
            <div className="p-4 rounded-xl border border-blue-200 bg-gradient-to-r from-blue-50 to-indigo-50 mt-4">
              <div className="flex items-center gap-2 text-blue-700 font-bold text-sm mb-1">
                <Crown className="w-4 h-4" />
                <span>VIP Monthly Pass ($9.99/mo)</span>
              </div>
              <p className="text-xs text-slate-600 mb-3">
                Unlimited 7-day email addresses, 500 phone credits/month, forward-to-real-email, and zero cooldowns.
              </p>
              <button
                type="button"
                onClick={() => onPurchase(500, '$9.99/mo')}
                className="w-full py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
              >
                <Crown className="w-3.5 h-3.5" />
                <span>Activate VIP Subscription</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-2">
            {transactions.length === 0 ? (
              <p className="text-center text-xs text-slate-400 py-6">No credit transactions yet.</p>
            ) : (
              transactions.map((tx) => (
                <div
                  key={tx.id}
                  className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex items-center justify-between text-xs"
                >
                  <div>
                    <div className="font-semibold text-slate-800">{tx.description}</div>
                    <div className="text-[11px] text-slate-400">
                      {new Date(tx.createdAt).toLocaleDateString([], {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </div>
                  </div>
                  <div
                    className={`font-mono font-bold text-sm ${
                      tx.amount > 0 ? 'text-blue-700' : 'text-rose-600'
                    }`}
                  >
                    {tx.amount > 0 ? `+${tx.amount}` : tx.amount}
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* FOOTER */}
        <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-center gap-1.5 text-[11px] text-slate-500">
          <ShieldCheck className="w-4 h-4 text-blue-600" />
          <span>Automatic refunds if no SMS is received on rented lines</span>
        </div>
      </div>
    </div>
  );
};
