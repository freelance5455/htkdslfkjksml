import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  RotateCcw, 
  Undo2, 
  Volume2, 
  VolumeX, 
  Vibrate, 
  Sliders, 
  Check, 
  ChevronRight, 
  ChevronLeft,
  Flame,
  Award,
  Target,
  RefreshCw,
  X
} from 'lucide-react';
import { MilestoneOption } from '../types';
import { triggerVibration } from '../utils/audioFeedback';

interface DigitalCounterProps {
  currentCount: number;
  targetCount: number;
  freeCounterMode: boolean;
  onTap: () => void;
  onUndo: () => void;
  onReset: () => void;
  onToggleFreeMode: () => void;
  onNextDhikr?: () => void;
  onPrevDhikr?: () => void;
  hasNext?: boolean;
  hasPrev?: boolean;
  isNightReadingActive: boolean;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  onToggleSound: () => void;
  onToggleVibration: () => void;
  onOpenMilestoneModal: () => void;
  vibrationMilestone: MilestoneOption;
  fullScreenMode?: boolean;
  originalTarget?: number;
  onSetTarget?: (target: number) => void;
  cyclesCompleted?: number;
  onNewCycle?: () => void;
}

export const DigitalCounter: React.FC<DigitalCounterProps> = ({
  currentCount,
  targetCount,
  freeCounterMode,
  onTap,
  onUndo,
  onReset,
  onToggleFreeMode,
  onNextDhikr,
  onPrevDhikr,
  hasNext = false,
  hasPrev = false,
  isNightReadingActive,
  soundEnabled,
  vibrationEnabled,
  onToggleSound,
  onToggleVibration,
  onOpenMilestoneModal,
  vibrationMilestone,
  fullScreenMode = false,
  originalTarget = 1,
  onSetTarget,
  cyclesCompleted = 0,
  onNewCycle,
}) => {
  const [tapEffect, setTapEffect] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  const [beadIndex, setBeadIndex] = useState(currentCount % 33);
  const [showCustomModal, setShowCustomModal] = useState(false);
  const [customInputValue, setCustomInputValue] = useState(targetCount.toString());

  const isCompleted = !freeCounterMode && currentCount >= targetCount;
  const remaining = Math.max(0, targetCount - currentCount);
  const progressRatio = targetCount > 0 ? Math.min(currentCount / targetCount, 1) : 0;
  const progressPercent = Math.round(progressRatio * 100);

  // Trigger celebration visual burst and distinctive vibration alert when reaching target
  useEffect(() => {
    if (isCompleted) {
      setShowCelebration(true);
      // Dedicated target reached vibration alert
      triggerVibration(vibrationEnabled, 'complete');
      const timer = setTimeout(() => {
        setShowCelebration(false);
      }, 4500);
      return () => clearTimeout(timer);
    } else {
      setShowCelebration(false);
    }
  }, [isCompleted, currentCount, targetCount, vibrationEnabled]);

  const handlePress = () => {
    if (isCompleted) {
      // Re-trigger target complete vibration if tapping completed button
      triggerVibration(vibrationEnabled, 'complete');
      return;
    }
    setTapEffect(true);
    setBeadIndex((prev) => (prev + 1) % 33);
    setTimeout(() => setTapEffect(false), 130);
    onTap();
  };

  // 5-digit digital display format like real digital tally counters (e.g. 00033)
  const formatDigits = (num: number) => {
    const s = Math.min(99999, Math.max(0, num)).toString();
    return s.padStart(5, '0');
  };

  const digitsStr = formatDigits(currentCount);
  const activeLength = currentCount.toString().length;
  const leadingZeros = digitsStr.slice(0, 5 - activeLength);
  const activeDigits = digitsStr.slice(5 - activeLength);

  // Milestones for high target counts
  const isHighCount = targetCount >= 33 || freeCounterMode;
  const milestones = [33, 66, 99, 100];

  const handleApplyCustomTarget = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseInt(customInputValue, 10);
    if (!isNaN(val) && val > 0 && onSetTarget) {
      onSetTarget(val);
      triggerVibration(vibrationEnabled, 'tap');
    }
    setShowCustomModal(false);
  };

  return (
    <div className={`relative w-full max-w-lg mx-auto flex flex-col items-center select-none transition-all duration-200 ${
      fullScreenMode ? 'py-2 sm:py-4' : 'py-1'
    }`}>
      {/* Celebration Visual Burst / Glowing Halo Overlay upon reaching Target Count */}
      {showCelebration && (
        <div className="absolute -inset-4 sm:-inset-6 z-30 pointer-events-none flex flex-col items-center justify-center animate-in fade-in zoom-in-90 duration-300">
          {/* Radiant expanding halo rings */}
          <div className="absolute inset-0 rounded-3xl bg-radial from-amber-400/25 via-emerald-500/15 to-transparent animate-pulse" />
          <div className="absolute w-44 h-44 rounded-full border-2 border-amber-400/60 animate-ping opacity-75" />
          <div className="absolute w-64 h-64 rounded-full border border-emerald-400/40 animate-ping opacity-50 [animation-delay:200ms]" />
          
          {/* Floating celebratory sparkle badge with Target Reached Announcement */}
          <div className="relative z-40 bg-gradient-to-r from-amber-500 via-emerald-600 to-amber-500 text-white px-5 py-2.5 rounded-2xl shadow-2xl border-2 border-amber-300/80 flex items-center gap-2 transform -translate-y-6 sm:-translate-y-8 animate-bounce">
            <Sparkles className="w-5 h-5 text-amber-200 animate-spin [animation-duration:3s]" />
            <div className="flex flex-col text-center">
              <span className="text-sm sm:text-base font-extrabold font-cairo text-amber-100">
                🎯 تم الوصول للعدد المستهدف ({targetCount} تسبيحة)
              </span>
              <span className="text-[10px] text-amber-200 font-tajawal font-medium">
                اهتزاز تنبيهي واكتمال مبارك بفضل الله
              </span>
            </div>
            <Award className="w-5 h-5 text-amber-200" />
          </div>
        </div>
      )}

      {/* Main Electronic Sebha Body (جسم المسبحة الإلكترونية) */}
      <div className={`w-full rounded-3xl border transition-all duration-300 relative overflow-hidden shadow-2xl p-4 sm:p-5 flex flex-col items-center ${
        isNightReadingActive
          ? 'bg-gradient-to-b from-[#18120b] via-[#120d08] to-[#0a0705] border-amber-800/40 shadow-amber-950/40'
          : 'bg-gradient-to-b from-[#062c20] via-[#042017] to-[#02140e] border-emerald-600/40 shadow-emerald-950/50'
      }`}>
        
        {/* Decorative Top Accent: Islamic Arch Line */}
        <div className="w-full flex items-center justify-between px-1 mb-2">
          <div className="flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full animate-ping ${
              isCompleted 
                ? 'bg-amber-400' 
                : isNightReadingActive ? 'bg-amber-500' : 'bg-emerald-400'
            }`} />
            <span className={`text-[11px] font-bold font-cairo tracking-wide ${
              isNightReadingActive ? 'text-amber-300/90' : 'text-emerald-300'
            }`}>
              عداد التكرار الذكي (Smart Tasbeeh)
            </span>

            {/* Cycle Count Badge */}
            {cyclesCompleted > 0 && (
              <span className="text-[10px] font-mono px-2 py-0.2 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/40">
                الدورة {cyclesCompleted + 1}
              </span>
            )}
          </div>

          {/* Quick Mode & Audio/Haptic Badges */}
          <div className="flex items-center gap-1">
            {/* Free / Target Mode Toggle */}
            <button
              onClick={onToggleFreeMode}
              className={`px-2 py-0.5 rounded-lg text-[10px] font-bold font-tajawal transition-colors cursor-pointer border ${
                freeCounterMode
                  ? 'bg-amber-500/25 text-amber-300 border-amber-400/50 shadow-xs'
                  : isNightReadingActive
                    ? 'bg-amber-950/50 text-amber-200/80 border-amber-800/40 hover:bg-amber-900/40'
                    : 'bg-emerald-950/60 text-emerald-300 border-emerald-700/50 hover:bg-emerald-900/50'
              }`}
              title={freeCounterMode ? 'العودة للعدد المحدد للذكر' : 'تفعيل التسبيح الحر المفتوح'}
            >
              {freeCounterMode ? 'تسبيح حر ∞' : `هدف: ${targetCount}`}
            </button>

            {/* Sound Toggle */}
            <button
              onClick={onToggleSound}
              className={`p-1 rounded-lg transition-colors cursor-pointer border ${
                soundEnabled
                  ? isNightReadingActive
                    ? 'bg-amber-950/60 text-amber-300 border-amber-700/40'
                    : 'bg-emerald-950/60 text-emerald-300 border-emerald-700/40'
                  : 'bg-black/30 text-slate-500 border-transparent opacity-60'
              }`}
              title={soundEnabled ? 'كتم صوت التسبيح' : 'تشغيل صوت التسبيح'}
              aria-label="تبديل الصوت"
            >
              {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            </button>

            {/* Vibration Toggle */}
            <button
              onClick={onToggleVibration}
              className={`p-1 rounded-lg transition-colors cursor-pointer border ${
                vibrationEnabled
                  ? isNightReadingActive
                    ? 'bg-amber-950/60 text-amber-300 border-amber-700/40 ring-1 ring-amber-400/30'
                    : 'bg-emerald-950/60 text-emerald-300 border-emerald-700/40 ring-1 ring-emerald-400/30'
                  : 'bg-black/30 text-slate-500 border-transparent opacity-60'
              }`}
              title={vibrationEnabled ? 'الاهتزاز مفعل عند التسبيح والهدف 📳' : 'الاهتزاز معطل 📴'}
              aria-label="تبديل الاهتزاز"
            >
              <Vibrate className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* ============================================================== */}
        {/* SMART REPETITION TARGET SELECTOR STRIP (شريط الأهداف الذكية) */}
        {/* ============================================================== */}
        {onSetTarget && (
          <div className="w-full flex items-center justify-between gap-1 p-1 mb-2.5 rounded-xl bg-black/30 border border-white/5 overflow-x-auto text-[11px]">
            <span className="text-[10px] text-[#84b8a0] font-tajawal px-1.5 shrink-0 flex items-center gap-1">
              <Target className="w-3 h-3 text-amber-400" />
              <span>الهدف الذكي:</span>
            </span>

            <div className="flex items-center gap-1">
              {/* Original Sunnah Count */}
              <button
                onClick={() => onSetTarget(originalTarget)}
                className={`px-2 py-0.5 rounded-lg font-cairo font-bold transition-all cursor-pointer ${
                  !freeCounterMode && targetCount === originalTarget
                    ? 'bg-amber-500 text-black shadow-xs font-black'
                    : 'bg-black/40 text-[#84b8a0] hover:text-white border border-emerald-800/40'
                }`}
                title={`العدد المأثور للذكر (${originalTarget})`}
              >
                المأثور ({originalTarget})
              </button>

              {/* Preset: 33 */}
              <button
                onClick={() => onSetTarget(33)}
                className={`px-2 py-0.5 rounded-lg font-mono font-bold transition-all cursor-pointer ${
                  !freeCounterMode && targetCount === 33
                    ? 'bg-amber-500 text-black shadow-xs font-black'
                    : 'bg-black/40 text-[#84b8a0] hover:text-white border border-emerald-800/40'
                }`}
                title="هدف ٣٣ تسبيحة"
              >
                ٣٣
              </button>

              {/* Preset: 100 */}
              <button
                onClick={() => onSetTarget(100)}
                className={`px-2 py-0.5 rounded-lg font-mono font-bold transition-all cursor-pointer ${
                  !freeCounterMode && targetCount === 100
                    ? 'bg-amber-500 text-black shadow-xs font-black'
                    : 'bg-black/40 text-[#84b8a0] hover:text-white border border-emerald-800/40'
                }`}
                title="هدف ١٠٠ تسبيحة"
              >
                ١٠٠
              </button>

              {/* Custom Target Modal Trigger */}
              <button
                onClick={() => setShowCustomModal(true)}
                className={`px-2 py-0.5 rounded-lg font-tajawal font-bold transition-all cursor-pointer border ${
                  !freeCounterMode && targetCount !== originalTarget && targetCount !== 33 && targetCount !== 100
                    ? 'bg-amber-500 text-black border-amber-300 font-black'
                    : 'bg-black/40 text-amber-300 hover:text-white border-amber-700/50'
                }`}
                title="تحديد هدف مخصص"
              >
                {!freeCounterMode && targetCount !== originalTarget && targetCount !== 33 && targetCount !== 100
                  ? `هدف: ${targetCount}`
                  : 'مخصص ⚙️'}
              </button>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* CRYSTAL LCD / OLED DIGITAL DISPLAY SCREEN (شاشة العداد الرقمية) */}
        {/* ============================================================== */}
        <div className={`w-full rounded-2xl border p-3 sm:p-4 mb-3.5 transition-all shadow-inner relative overflow-hidden flex flex-col justify-between ${
          isNightReadingActive
            ? 'bg-[#0a0704] border-amber-800/60 shadow-[inset_0_2px_8px_rgba(0,0,0,0.8)]'
            : 'bg-[#02150e] border-emerald-600/50 shadow-[inset_0_2px_10px_rgba(0,0,0,0.8)]'
        }`}>
          {/* LCD Screen Glare / Reflection Sheen */}
          <div className="absolute -top-10 -right-10 w-40 h-20 bg-white/5 rotate-25 pointer-events-none rounded-full blur-xs" />

          {/* Screen Top Status Bar */}
          <div className="flex items-center justify-between text-[11px] font-mono font-bold pb-1.5 border-b border-white/5 mb-1">
            <span className={`flex items-center gap-1 ${
              isNightReadingActive ? 'text-amber-400/90' : 'text-emerald-400/90'
            }`}>
              <Flame className="w-3 h-3 text-amber-400" />
              <span>{freeCounterMode ? 'تسبيح مفتوح ♾️' : `الهدف المستهدف: ${targetCount}`}</span>
            </span>

            {/* Progress Percentage */}
            <span className={`px-1.5 py-0.5 rounded text-[10px] font-mono ${
              isCompleted
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                : isNightReadingActive
                  ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                  : 'bg-emerald-900/40 text-emerald-300 border border-emerald-700/40'
            }`}>
              {freeCounterMode ? `${currentCount} عدّة` : `${progressPercent}%`}
            </span>
          </div>

          {/* Center Large Digital Numbers (مثل الشاشات الكريستالية للمسابح الحقيقية) */}
          <div className="py-2.5 flex items-baseline justify-center gap-1 font-mono tracking-wider select-none">
            {/* Dimmed Leading Zeros */}
            <span className={`text-4xl sm:text-5xl font-black opacity-20 transition-all ${
              isNightReadingActive ? 'text-amber-400' : 'text-emerald-400'
            }`}>
              {leadingZeros}
            </span>

            {/* Active Highlighted Tally Count */}
            <span className={`text-5xl sm:text-6xl font-black drop-shadow-md transition-transform duration-100 ${
              tapEffect ? 'scale-105' : 'scale-100'
            } ${
              isCompleted
                ? 'text-amber-300 drop-shadow-[0_0_12px_rgba(245,158,11,0.6)]'
                : isNightReadingActive
                  ? 'text-amber-200 drop-shadow-[0_0_8px_rgba(251,191,36,0.4)]'
                  : 'text-emerald-200 drop-shadow-[0_0_10px_rgba(110,231,183,0.4)]'
            }`}>
              {activeDigits}
            </span>
          </div>

          {/* Screen Bottom Bar: Remaining / Status */}
          <div className="flex items-center justify-between text-xs pt-1 border-t border-white/5">
            <span className={`font-tajawal text-[11px] font-bold ${
              isCompleted 
                ? 'text-emerald-400 font-extrabold flex items-center gap-1' 
                : isNightReadingActive ? 'text-amber-300/80' : 'text-emerald-300/80'
            }`}>
              {isCompleted ? (
                <>
                  <Check className="w-3.5 h-3.5 stroke-[3] text-amber-300" />
                  <span className="text-amber-300">تم بلوغ الهدف المستهدف ({targetCount}) 📳</span>
                </>
              ) : freeCounterMode ? (
                <span>مسبحة غير محدودة</span>
              ) : (
                <span>المتبقي للهدف: <strong className="font-mono text-sm text-amber-300">{remaining}</strong> تسبيحة</span>
              )}
            </span>

            {/* Mini Milestone Indicator */}
            {isHighCount && (
              <button
                onClick={onOpenMilestoneModal}
                className="text-[10px] font-tajawal text-[#84b8a0] dark:text-emerald-400 hover:underline cursor-pointer flex items-center gap-1"
                title="تخصيص محطات الاهتزاز"
              >
                <Sliders className="w-2.5 h-2.5" />
                <span>
                  {vibrationMilestone === '33' ? 'محطة ٣٣' : 
                   vibrationMilestone === '10' ? 'محطة ١٠' : 
                   vibrationMilestone === 'target' ? 'عند الهدف' : 'بدون'}
                </span>
              </button>
            )}
          </div>

          {/* Progress Bar Line */}
          <div className="w-full h-1.5 bg-black/50 rounded-full mt-2 overflow-hidden border border-white/5">
            <div 
              className={`h-full rounded-full transition-all duration-300 ${
                isCompleted 
                  ? 'bg-gradient-to-r from-emerald-400 via-amber-300 to-emerald-400' 
                  : isNightReadingActive
                    ? 'bg-gradient-to-r from-amber-600 to-amber-400'
                    : 'bg-gradient-to-r from-emerald-600 via-emerald-400 to-emerald-300'
              }`}
              style={{ width: `${freeCounterMode ? (currentCount % 100) : progressPercent}%` }}
            />
          </div>
        </div>

        {/* ============================================================== */}
        {/* INTERACTIVE PRAYER BEADS TRACK (شريط خرزات المسبحة التفاعلي) */}
        {/* ============================================================== */}
        <div className="w-full flex items-center justify-center gap-1.5 py-1 px-2 mb-3 overflow-x-hidden">
          {Array.from({ length: 11 }).map((_, i) => {
            const isCenterBead = i === 5;
            const isPassed = (beadIndex % 11) >= i;
            return (
              <div
                key={i}
                className={`rounded-full transition-all duration-200 transform ${
                  isCenterBead 
                    ? `w-4.5 h-4.5 shadow-md ${
                        tapEffect ? 'scale-125' : 'scale-100'
                      } ${
                        isNightReadingActive 
                          ? 'bg-amber-400 border border-amber-200 shadow-amber-500/50' 
                          : 'bg-emerald-300 border border-white shadow-emerald-400/60'
                      }`
                    : `w-2.5 h-2.5 ${
                        isPassed 
                          ? isNightReadingActive ? 'bg-amber-600' : 'bg-emerald-500' 
                          : isNightReadingActive ? 'bg-amber-950/80 border border-amber-900/60' : 'bg-emerald-950 border border-emerald-800/60'
                      }`
                }`}
              />
            );
          })}
        </div>

        {/* ============================================================== */}
        {/* PRIMARY TACTILE TALLY BUTTON & AUXILIARY CONTROLS (أزرار التسبيح) */}
        {/* ============================================================== */}
        <div className="w-full flex items-center justify-between gap-3 sm:gap-4 px-1">
          {/* Undo Button (-1) */}
          <button
            onClick={() => {
              triggerVibration(vibrationEnabled, 'undo');
              onUndo();
            }}
            disabled={currentCount === 0}
            className={`w-12 h-12 sm:w-14 sm:h-14 rounded-2xl border flex flex-col items-center justify-center transition-all cursor-pointer shadow-md active:scale-90 disabled:opacity-20 ${
              isNightReadingActive
                ? 'bg-[#181109] border-amber-800/50 text-amber-300 hover:bg-[#22180e]'
                : 'bg-[#042017] border-emerald-700/50 text-emerald-300 hover:bg-[#073023]'
            }`}
            title="تراجع عن تسبيحة واحدة (-1)"
            aria-label="تراجع"
          >
            <Undo2 className="w-4.5 h-4.5" />
            <span className="text-[9px] font-bold font-tajawal mt-0.5">تراجع</span>
          </button>

          {/* LARGE PRIMARY TALLY BUTTON (زر التسبيح الضخم المريح) */}
          <div className="flex-1 flex justify-center">
            <button
              onClick={handlePress}
              className={`relative rounded-full transition-all duration-150 select-none cursor-pointer flex flex-col items-center justify-center border-4 shadow-2xl active:scale-95 ${
                fullScreenMode ? 'w-36 h-36 sm:w-40 sm:h-40' : 'w-28 h-28 sm:w-32 sm:h-32'
              } ${tapEffect ? 'scale-90 ring-8 ring-amber-400/30' : 'scale-100'} ${
                isCompleted
                  ? 'bg-gradient-to-br from-amber-600 via-emerald-700 to-emerald-900 border-amber-300 text-white shadow-amber-950/60 ring-4 ring-amber-400/40 animate-pulse'
                  : isNightReadingActive
                    ? 'bg-gradient-to-br from-[#d97706] via-[#b45309] to-[#78350f] border-amber-300/80 text-amber-100 shadow-[0_10px_35px_rgba(217,119,6,0.4)]'
                    : 'bg-gradient-to-br from-[#059669] via-[#047857] to-[#064e3b] border-emerald-300/80 text-white shadow-[0_10px_35px_rgba(5,150,105,0.4)]'
              }`}
              aria-label="تسبيح"
            >
              {/* Concentric Tactile Ring Pattern */}
              <div className="absolute inset-2 rounded-full border border-white/20 pointer-events-none" />
              <div className="absolute inset-4 rounded-full border border-white/10 pointer-events-none" />

              {isCompleted ? (
                <div className="flex flex-col items-center animate-in zoom-in-75 duration-200">
                  <Check className="w-8 h-8 sm:w-10 sm:h-10 text-amber-300 stroke-[3] drop-shadow-md" />
                  <span className="text-xs sm:text-sm font-extrabold font-cairo text-white mt-1">اكتمل الهدف 🎯</span>
                  <span className="text-[10px] text-amber-200 font-tajawal">اهتزاز تنبيهي 📳</span>
                </div>
              ) : (
                <div className="flex flex-col items-center">
                  <span className="text-sm sm:text-base font-black font-cairo tracking-wide drop-shadow-sm">
                    سَبِّحْ
                  </span>
                  <span className="text-2xl sm:text-3xl font-black font-mono tracking-tight mt-0.5">
                    {freeCounterMode ? currentCount : remaining}
                  </span>
                  <span className="text-[10px] font-bold font-tajawal opacity-90">
                    {freeCounterMode ? 'تسبيحة' : targetCount === 1 ? 'مرة واحدة' : 'متبقي'}
                  </span>
                </div>
              )}
            </button>
          </div>

          {/* Reset Button (تصفير العداد) */}
          <button
            onClick={onReset}
            className={`w-12 h-12 sm:w-14 sm:h-14 rounded-2xl border flex flex-col items-center justify-center transition-all cursor-pointer shadow-md active:scale-90 ${
              isNightReadingActive
                ? 'bg-[#181109] border-amber-800/50 text-amber-300 hover:bg-[#22180e]'
                : 'bg-[#042017] border-emerald-700/50 text-emerald-300 hover:bg-[#073023]'
            }`}
            title="إعادة ضبط العداد أو تصفيره"
            aria-label="تصفير"
          >
            <RotateCcw className="w-4.5 h-4.5" />
            <span className="text-[9px] font-bold font-tajawal mt-0.5">تصفير</span>
          </button>
        </div>

        {/* Milestone Indicator Badges (عند 33، 66، 99، 100) */}
        {isHighCount && (
          <div className="flex items-center justify-center gap-1.5 mt-3 pt-2 border-t border-white/5 w-full text-xs">
            <span className={`text-[10px] font-bold font-tajawal ${
              isNightReadingActive ? 'text-amber-400/80' : 'text-emerald-400/80'
            }`}>
              محطات الاهتزاز التلقائي:
            </span>
            <div className="flex items-center gap-1">
              {milestones.map((m) => {
                const isReached = currentCount >= m;
                return (
                  <span
                    key={m}
                    className={`px-1.5 py-0.5 rounded-md text-[10px] font-mono font-bold transition-all ${
                      isReached 
                        ? 'bg-amber-500 text-black shadow-xs font-black' 
                        : isNightReadingActive
                          ? 'bg-amber-950/60 text-amber-400/60 border border-amber-900/40'
                          : 'bg-emerald-950/60 text-emerald-400/60 border border-emerald-800/40'
                    }`}
                  >
                    {m}
                  </span>
                );
              })}
            </div>
          </div>
        )}

        {/* Completion Action Bar (تظهر عند الوصول للعدد المستهدف لإكمال الدورة أو الانتقال) */}
        {isCompleted && (
          <div className="w-full mt-3 pt-3 border-t border-amber-400/30 flex flex-wrap items-center justify-center gap-2 animate-in slide-in-from-bottom-2 duration-200">
            {/* New Cycle Button */}
            {onNewCycle && (
              <button
                onClick={onNewCycle}
                className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold font-cairo text-xs flex items-center justify-center gap-1.5 shadow-md cursor-pointer transition-all active:scale-95"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>دورة جديدة (+{targetCount}) 🔄</span>
              </button>
            )}

            {hasNext && onNextDhikr && (
              <button
                onClick={onNextDhikr}
                className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white text-xs font-bold font-cairo flex items-center justify-center gap-1.5 shadow-md cursor-pointer transition-all active:scale-95"
              >
                <span>الذكر التالي</span>
                <ChevronLeft className="w-4 h-4" />
              </button>
            )}

            <button
              onClick={onReset}
              className={`py-2 px-3 rounded-xl border text-xs font-bold font-cairo flex items-center justify-center gap-1 transition-all cursor-pointer ${
                isNightReadingActive
                  ? 'bg-amber-950/70 border-amber-700/60 text-amber-200 hover:bg-amber-900/60'
                  : 'bg-emerald-950/70 border-emerald-700/60 text-emerald-200 hover:bg-emerald-900/60'
              }`}
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>إعادة العداد</span>
            </button>
          </div>
        )}

        {/* Quick Navigation Between Adhkar (السابق والتالي) */}
        {!isCompleted && (
          <div className="w-full flex items-center justify-between gap-2 mt-2 pt-2 border-t border-white/5">
            <button
              onClick={onPrevDhikr}
              disabled={!hasPrev}
              className={`flex-1 py-1.5 px-2 rounded-xl border text-[11px] font-bold font-tajawal flex items-center justify-center gap-1 transition-colors cursor-pointer disabled:opacity-20 ${
                isNightReadingActive
                  ? 'bg-amber-950/40 border-amber-800/40 text-amber-300 hover:bg-amber-900/40'
                  : 'bg-emerald-950/40 border-emerald-800/40 text-emerald-300 hover:bg-emerald-900/40'
              }`}
              aria-label="الذكر السابق"
            >
              <ChevronRight className="w-3.5 h-3.5" />
              <span>الذكر السابق</span>
            </button>

            <button
              onClick={onNextDhikr}
              disabled={!hasNext}
              className={`flex-1 py-1.5 px-2 rounded-xl border text-[11px] font-bold font-tajawal flex items-center justify-center gap-1 transition-colors cursor-pointer disabled:opacity-20 ${
                isNightReadingActive
                  ? 'bg-amber-950/40 border-amber-800/40 text-amber-300 hover:bg-amber-900/40'
                  : 'bg-emerald-950/40 border-emerald-800/40 text-emerald-300 hover:bg-emerald-900/40'
              }`}
              aria-label="الذكر التالي"
            >
              <span>الذكر التالي</span>
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {/* Custom Target Modal (نافذة إدخال الهدف المخصص) */}
      {showCustomModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="w-full max-w-sm bg-[#042017] border border-emerald-600/50 rounded-3xl p-5 shadow-2xl text-right space-y-4">
            <div className="flex items-center justify-between border-b border-emerald-800 pb-2">
              <div className="flex items-center gap-2 text-amber-300">
                <Target className="w-5 h-5 text-amber-400" />
                <h3 className="text-sm font-extrabold font-cairo text-white">تحديد هدف تكرار ذكي مخصص</h3>
              </div>
              <button
                onClick={() => setShowCustomModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-[#84b8a0] font-tajawal leading-relaxed">
              اختر عدد التسبيحات المستهدف لهذا الذكر. سيهتز الجهاز فور وصولك لهذا العدد:
            </p>

            {/* Quick target presets */}
            <div className="grid grid-cols-4 gap-1.5">
              {[10, 33, 70, 100, 300, 500, 1000].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => setCustomInputValue(num.toString())}
                  className={`py-1.5 rounded-xl border text-xs font-mono font-bold transition-all cursor-pointer ${
                    customInputValue === num.toString()
                      ? 'bg-amber-500 text-black border-amber-300 shadow-xs'
                      : 'bg-black/30 border-emerald-800/60 text-emerald-300 hover:bg-emerald-900/40'
                  }`}
                >
                  {num}
                </button>
              ))}
              <button
                type="button"
                onClick={() => setCustomInputValue(originalTarget.toString())}
                className="py-1.5 rounded-xl border border-emerald-700/60 bg-emerald-900/30 text-amber-300 text-[10px] font-cairo font-bold hover:bg-emerald-900/60"
              >
                المأثور ({originalTarget})
              </button>
            </div>

            <form onSubmit={handleApplyCustomTarget} className="space-y-3 pt-1">
              <div>
                <label className="text-[11px] font-bold text-emerald-300 block mb-1 font-cairo">
                  أو اكتب الرقم يدوياً:
                </label>
                <input
                  type="number"
                  min="1"
                  max="99999"
                  value={customInputValue}
                  onChange={(e) => setCustomInputValue(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-black/50 border border-emerald-600/60 text-amber-300 font-mono text-center text-lg font-bold focus:outline-none focus:ring-2 focus:ring-amber-400"
                  autoFocus
                />
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold font-cairo text-xs transition-all shadow-md cursor-pointer"
                >
                  تأكيد وحفظ الهدف 🎯
                </button>
                <button
                  type="button"
                  onClick={() => setShowCustomModal(false)}
                  className="py-2.5 px-4 rounded-xl bg-black/40 text-slate-300 hover:text-white text-xs font-bold font-cairo cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
