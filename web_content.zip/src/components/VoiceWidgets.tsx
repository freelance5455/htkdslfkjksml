import React, { useEffect } from 'react';
import { Timer, CheckSquare, Trash2, X, Music, VolumeX, Sparkles, Download } from 'lucide-react';
import { NoteItem, TimerItem } from '../types';
import { musicPlayer } from '../services/MusicPlayer';

interface VoiceWidgetsProps {
  timers: TimerItem[];
  notes: NoteItem[];
  isMusicPlaying: boolean;
  musicVibe: string;
  mathResult: { calc: string; result: string } | null;
  onClearTimer: (id: string) => void;
  onDeleteNote: (id: string) => void;
  onStopMusic: () => void;
  onDismissMath: () => void;
}

export const VoiceWidgets: React.FC<VoiceWidgetsProps> = ({
  timers,
  notes,
  isMusicPlaying,
  musicVibe,
  mathResult,
  onClearTimer,
  onDeleteNote,
  onStopMusic,
  onDismissMath,
}) => {
  // Beep when timer reaches 0
  useEffect(() => {
    timers.forEach((t) => {
      if (t.remainingSeconds === 0 && t.active) {
        musicPlayer.playAlertSound();
      }
    });
  }, [timers]);

  return (
    <div className="fixed bottom-20 left-4 right-4 sm:left-auto sm:right-6 sm:bottom-20 z-30 flex flex-col gap-2.5 max-w-sm pointer-events-none">
      {/* Active Music Player Widget */}
      {isMusicPlaying && (
        <div className="pointer-events-auto p-3 rounded-2xl bg-zinc-950/90 border border-purple-500/40 shadow-xl backdrop-blur-xl flex items-center justify-between gap-3 animate-in fade-in slide-in-from-bottom-2">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center border border-purple-500/30 animate-pulse">
              <Music className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-purple-300">
                Playing Synth Vibe
              </span>
              <p className="text-xs font-semibold text-white capitalize">{musicVibe} Chords</p>
            </div>
          </div>
          <button
            onClick={onStopMusic}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-zinc-300 hover:text-white transition-colors cursor-pointer"
            title="Stop Music"
          >
            <VolumeX className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Active Timers */}
      {timers.filter((t) => t.remainingSeconds > 0).map((t) => {
        const mins = Math.floor(t.remainingSeconds / 60);
        const secs = t.remainingSeconds % 60;
        const formatted = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
        const pct = Math.max(0, (t.remainingSeconds / t.totalSeconds) * 100);

        return (
          <div
            key={t.id}
            className="pointer-events-auto p-3 rounded-2xl bg-zinc-950/90 border border-pink-500/40 shadow-xl backdrop-blur-xl flex items-center justify-between gap-3 animate-in fade-in slide-in-from-bottom-2"
          >
            <div className="flex items-center gap-2.5 flex-1">
              <div className="w-8 h-8 rounded-xl bg-pink-500/20 text-pink-400 flex items-center justify-center border border-pink-500/30">
                <Timer className="w-4 h-4 animate-spin" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-semibold text-white truncate">{t.label}</span>
                  <span className="font-mono font-bold text-pink-400">{formatted}</span>
                </div>
                <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-pink-500 to-rose-500 transition-all duration-1000"
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            </div>
            <button
              onClick={() => onClearTimer(t.id)}
              className="p-1 text-zinc-400 hover:text-white transition-colors ml-1 cursor-pointer"
              title="Cancel Timer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}

      {/* Math Result Pop-up */}
      {mathResult && (
        <div className="pointer-events-auto p-3 rounded-2xl bg-zinc-950/90 border border-cyan-500/40 shadow-xl backdrop-blur-xl flex items-center justify-between gap-3 animate-in fade-in slide-in-from-bottom-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-500/30">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] text-zinc-400 block">{mathResult.calc} =</span>
              <span className="text-sm font-bold text-cyan-300 font-mono">{mathResult.result}</span>
            </div>
          </div>
          <button
            onClick={onDismissMath}
            className="p-1 text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Quick Notes Badge / Drawer Indicator */}
      {notes.length > 0 && (
        <div className="pointer-events-auto p-2.5 rounded-2xl bg-zinc-950/80 border border-zinc-700/60 shadow-lg backdrop-blur-md flex flex-col gap-1.5 max-h-36 overflow-y-auto">
          <div className="flex items-center justify-between text-[11px] font-bold text-zinc-400 px-1">
            <span className="flex items-center gap-1 text-pink-400">
              <CheckSquare className="w-3.5 h-3.5" /> Notes Saved ({notes.length})
            </span>
          </div>
          {notes.slice(0, 3).map((n) => (
            <div
              key={n.id}
              className="flex items-center justify-between text-xs bg-white/5 rounded-lg p-1.5 px-2 text-zinc-300"
            >
              <span className="truncate flex-1 mr-2">{n.text}</span>
              <button
                onClick={() => onDeleteNote(n.id)}
                className="text-zinc-500 hover:text-red-400 cursor-pointer"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
