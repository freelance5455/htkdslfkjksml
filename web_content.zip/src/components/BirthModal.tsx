import React, { useState } from 'react';
import { Gender } from '../game/types';
import { Baby, Sparkles, Heart } from 'lucide-react';
import { playClickSound, playLevelUpSound } from '../utils/audio';

interface BirthModalProps {
  partnerName: string;
  defaultGender?: Gender;
  onConfirm: (name: string, gender: Gender) => void;
}

export const BirthModal: React.FC<BirthModalProps> = ({
  partnerName,
  defaultGender = 'boy',
  onConfirm
}) => {
  const [gender, setGender] = useState<Gender>(defaultGender);
  const [name, setName] = useState(gender === 'boy' ? 'كريم' : 'مريم');

  const boyPresets = ['كريم', 'يوسف', 'آدم', 'حمزة', 'عمر', 'زين', 'مالك', 'إياد'];
  const girlPresets = ['مريم', 'نور', 'ياسمين', 'فريدة', 'سلمى', 'حلا', 'ليلى', 'تاليا'];

  const handleGenderChange = (newGender: Gender) => {
    playClickSound();
    setGender(newGender);
    setName(newGender === 'boy' ? 'كريم' : 'مريم');
  };

  const handlePresetClick = (presetName: string) => {
    playClickSound();
    setName(presetName);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    playLevelUpSound();
    onConfirm(name.trim() || (gender === 'boy' ? 'كريم' : 'مريم'), gender);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="w-full max-w-md bg-slate-900 border border-slate-700/80 rounded-3xl p-6 shadow-2xl text-right animate-in fade-in zoom-in-95 duration-200">
        <div className="text-center pb-4 border-b border-slate-800">
          <div className="inline-flex p-3 rounded-full bg-gradient-to-tr from-rose-500/20 to-amber-500/20 text-rose-400 border border-rose-500/30 mb-2">
            <Baby className="w-8 h-8 animate-bounce" />
          </div>
          <h2 className="text-2xl font-black text-amber-300">🎉 حانت لحظة الولادة السعيدة!</h2>
          <p className="text-xs text-slate-300 mt-1">
            وضعت {partnerName} مولودكم بسلام وصحة ممتازة! اختارا نوع الجنين واسمه بحرية:
          </p>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {/* Gender selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              نوع المولود (ولد أم بنت):
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => handleGenderChange('boy')}
                className={`py-3 px-4 rounded-2xl border flex items-center justify-center gap-2 font-bold text-sm transition ${
                  gender === 'boy'
                    ? 'bg-blue-500/20 border-blue-400 text-blue-200 shadow-md shadow-blue-500/10'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <span>👦 ولد</span>
              </button>

              <button
                type="button"
                onClick={() => handleGenderChange('girl')}
                className={`py-3 px-4 rounded-2xl border flex items-center justify-center gap-2 font-bold text-sm transition ${
                  gender === 'girl'
                    ? 'bg-rose-500/20 border-rose-400 text-rose-200 shadow-md shadow-rose-500/10'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <span>👧 بنت</span>
              </button>
            </div>
          </div>

          {/* Name input */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              اكتب اسم {gender === 'boy' ? 'الولد' : 'البنت'} (لك كامل الحرية في كتابة أي اسم):
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={gender === 'boy' ? 'اكتب اسم الولد هنا...' : 'اكتب اسم البنت هنا...'}
              className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-base font-semibold focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 transition"
            />
          </div>

          {/* Quick presets */}
          <div>
            <span className="text-[11px] text-slate-400 block mb-1.5">أو اختر اسماً مقترحاً بضغطة زر:</span>
            <div className="flex flex-wrap gap-1.5">
              {(gender === 'boy' ? boyPresets : girlPresets).map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => handlePresetClick(preset)}
                  className={`px-3 py-1 rounded-xl text-xs font-medium border transition ${
                    name === preset
                      ? 'bg-amber-400 text-slate-950 border-amber-400 font-bold'
                      : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 px-4 mt-2 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-bold text-sm shadow-lg shadow-emerald-500/20 hover:brightness-110 active:scale-[0.98] transition flex items-center justify-center gap-2"
          >
            <span>اعتماد الاسم والاحتفال بالمولود</span>
            <Sparkles className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
