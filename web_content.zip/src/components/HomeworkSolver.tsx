import React, { useState, useRef } from 'react';
import { 
  HelpCircle, 
  Camera, 
  Upload, 
  Sparkles, 
  CheckCircle2, 
  BookOpen, 
  FileText, 
  AlertCircle, 
  RefreshCw,
  Lightbulb,
  ArrowRight
} from 'lucide-react';
import { HomeworkSolution, Language } from '../types';

interface HomeworkSolverProps {
  language: Language;
  targetExam?: string;
}

export default function HomeworkSolver({ language, targetExam = 'Madhyamik' }: HomeworkSolverProps) {
  const [problemText, setProblemText] = useState<string>('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isSolving, setIsSolving] = useState<boolean>(false);
  const [solution, setSolution] = useState<HomeworkSolution | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      setErrorMessage(language === 'bn' ? 'ফাইল সাইজ ১০MB এর কম হতে হবে।' : 'File size must be under 10MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setSelectedImage(event.target?.result as string);
      setErrorMessage(null);
    };
    reader.readAsDataURL(file);
  };

  const handleSolveHomework = async () => {
    if (!problemText.trim() && !selectedImage) {
      setErrorMessage(language === 'bn' ? 'অনুগ্রহ করে একটি প্রশ্ন লিখুন বা ছবি স্ক্যান করুন।' : 'Please type a question or upload an image.');
      return;
    }

    setIsSolving(true);
    setErrorMessage(null);
    setSolution(null);

    try {
      const response = await fetch('/api/gemini/homework', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          problemText,
          image: selectedImage,
          language,
          targetExam
        })
      });

      if (!response.ok) {
        throw new Error('Failed to solve homework');
      }

      const data = await response.json();
      if (data.problemText) {
        setSolution(data);
      } else {
        throw new Error('Invalid solution structure returned.');
      }
    } catch (err: any) {
      console.error('Homework Solver Error:', err);
      setErrorMessage(
        language === 'bn' 
          ? 'হোমওয়ার্ক সমাধান করতে সমস্যা হয়েছে। অনুগ্রহ করে পরিষ্কার ছবি বা সঠিক প্রশ্ন প্রদান করুন।' 
          : 'Failed to solve homework. Please provide a clearer question or image.'
      );
    } finally {
      setIsSolving(false);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 max-w-5xl mx-auto w-full pb-24 md:pb-10">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none" />
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2.5 bg-indigo-600 rounded-2xl shadow-lg shadow-indigo-600/30">
            <HelpCircle className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl md:text-2xl font-black font-display">
              {language === 'bn' ? 'AI হোমওয়ার্ক সলভার (Homework Solver)' : 'AI Homework & Math Solver'}
            </h2>
            <p className="text-xs text-indigo-300 font-medium">
              {language === 'bn' 
                ? 'শুধু উত্তর নয় — প্রতিটি অংক ও বিজ্ঞানের প্রশ্নের নিখুঁত স্টেপ-বাই-স্টেপ ব্যাখ্যা শিখুন' 
                : 'Get step-by-step solutions with core concepts & formulas explained'}
            </p>
          </div>
        </div>
      </div>

      {/* Question Input Card */}
      <div className="bg-white border border-slate-200/80 rounded-3xl p-5 md:p-6 shadow-sm space-y-4">
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-2">
            {language === 'bn' ? 'আপনার প্রশ্ন বা অংকটি লিখুন:' : 'Type your question or homework problem:'}
          </label>
          <textarea
            value={problemText}
            onChange={(e) => setProblemText(e.target.value)}
            rows={3}
            spellCheck={false}
            autoCorrect="off"
            autoCapitalize="off"
            placeholder={
              language === 'bn' 
                ? 'উদাহরণ: x^2 - 5x + 6 = 0 দ্বিঘাত সমীকরণটি সমাধান করো...' 
                : 'e.g., Solve equation x^2 - 5x + 6 = 0 or explain photosynthesis step by step...'
            }
            className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
          />
        </div>

        {/* Upload Image Section */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-slate-100">
          <div className="flex items-center gap-3">
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleImageUpload} 
              accept="image/*,.pdf" 
              className="hidden" 
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all cursor-pointer"
            >
              <Camera className="w-4 h-4 text-indigo-600" />
              {language === 'bn' ? 'খাতার/বইয়ের ছবি বা PDF দিন' : 'Upload Photo / PDF'}
            </button>

            {selectedImage && (
              <span className="text-xs text-emerald-600 font-extrabold flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4" />
                {language === 'bn' ? 'ছবি সংযুক্ত হয়েছে' : 'Image attached'}
              </span>
            )}
          </div>

          <button
            onClick={handleSolveHomework}
            disabled={isSolving}
            className="bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold px-6 py-2.5 rounded-xl text-xs flex items-center gap-2 cursor-pointer shadow-lg shadow-indigo-600/20 transition-all disabled:opacity-50"
          >
            {isSolving ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                {language === 'bn' ? 'AI সমাধান তৈরি করছে...' : 'Solving Step-by-Step...'}
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                {language === 'bn' ? 'স্টেপ-বাই-স্টেপ সমাধান পান' : 'Solve Step-by-Step'}
              </>
            )}
          </button>
        </div>

        {selectedImage && (
          <div className="relative inline-block mt-2">
            <img 
              src={selectedImage} 
              alt="Homework Scan" 
              className="h-28 w-auto rounded-xl border border-slate-200 object-cover shadow-sm" 
            />
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute -top-2 -right-2 bg-rose-600 text-white rounded-full p-1 text-[10px] font-bold shadow-md cursor-pointer"
            >
              ✕
            </button>
          </div>
        )}

        {errorMessage && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}
      </div>

      {/* Loading Skeleton State */}
      {isSolving && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4 animate-pulse">
          <div className="h-5 bg-slate-200 rounded-md w-1/3" />
          <div className="h-12 bg-indigo-50 border border-indigo-100 rounded-2xl p-4" />
          <div className="space-y-3 pt-3">
            <div className="h-4 bg-slate-200 rounded w-full" />
            <div className="h-4 bg-slate-200 rounded w-5/6" />
            <div className="h-4 bg-slate-200 rounded w-4/6" />
          </div>
        </div>
      )}

      {/* Solution Display Card */}
      {solution && !isSolving && (
        <div className="bg-white border border-slate-200/90 rounded-3xl p-6 shadow-md space-y-6">
          
          {/* Question & Final Answer Header */}
          <div className="bg-slate-900 text-slate-100 rounded-2xl p-5 shadow-inner space-y-3">
            <div className="flex items-center gap-2 text-xs font-extrabold text-indigo-400">
              <FileText className="w-4 h-4" />
              {language === 'bn' ? 'চিহ্নিত প্রশ্ন:' : 'Identified Problem:'}
            </div>
            <p className="text-sm font-semibold text-slate-200 leading-relaxed">
              {solution.problemText}
            </p>
            <div className="pt-2 border-t border-slate-800 flex items-center gap-2">
              <span className="text-xs text-emerald-400 font-extrabold">
                {language === 'bn' ? 'চূড়ান্ত উত্তর:' : 'Final Answer:'}
              </span>
              <span className="text-sm font-black text-emerald-300 bg-emerald-950/80 px-3 py-1 rounded-lg border border-emerald-800/80">
                {solution.finalAnswer}
              </span>
            </div>
          </div>

          {/* Step-by-Step Breakdown */}
          <div className="space-y-4">
            <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
              <CheckCircle2 className="w-4.5 h-4.5 text-indigo-600" />
              {language === 'bn' ? 'ধাপে ধাপে সমাধান (Step-by-Step Solution):' : 'Step-by-Step Explanation:'}
            </h3>

            <div className="space-y-3">
              {solution.steps.map((step, idx) => (
                <div key={idx} className="p-4 bg-slate-50 border border-slate-200/80 rounded-2xl space-y-1.5 hover:border-indigo-300 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-indigo-700 bg-indigo-100 px-2.5 py-0.5 rounded-lg">
                      {language === 'bn' ? `ধাপ ${step.stepNumber}` : `Step ${step.stepNumber}`}: {step.title}
                    </span>
                    {step.formulaUsed && (
                      <span className="text-[11px] font-mono font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                        {step.formulaUsed}
                      </span>
                    )}
                  </div>
                  <p className="text-xs font-medium text-slate-700 leading-relaxed pt-1">
                    {step.description}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Key Concepts Involved */}
          {solution.conceptsInvolved && solution.conceptsInvolved.length > 0 && (
            <div className="bg-indigo-50/70 border border-indigo-100 rounded-2xl p-4 space-y-2">
              <div className="flex items-center gap-2 text-xs font-black text-indigo-900">
                <Lightbulb className="w-4 h-4 text-indigo-600" />
                {language === 'bn' ? 'মূল শিক্ষণীয় ধারণা ও সূত্রসমূহ:' : 'Core Concepts Involved:'}
              </div>
              <div className="flex flex-wrap gap-2">
                {solution.conceptsInvolved.map((concept, i) => (
                  <span key={i} className="text-xs font-bold text-indigo-800 bg-white border border-indigo-200 px-3 py-1 rounded-xl shadow-2xs">
                    {concept}
                  </span>
                ))}
              </div>
            </div>
          )}

        </div>
      )}

    </div>
  );
}
