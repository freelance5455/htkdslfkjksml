import React from 'react';
import { CheckCircle, Package, Truck, Home, ArrowRight, ShieldCheck, Copy } from 'lucide-react';
import { CartItem, DeliveryAddress } from '../types/ecommerce';

interface OrderSuccessScreenProps {
  orderData: {
    orderNumber: string;
    items: CartItem[];
    totalAmount: number;
    paymentMethod: string;
    address: DeliveryAddress;
    trackingNumber: string;
    date: string;
  };
  onContinueShopping: () => void;
  onViewAccountOrders: () => void;
}

export const OrderSuccessScreen: React.FC<OrderSuccessScreenProps> = ({
  orderData,
  onContinueShopping,
  onViewAccountOrders
}) => {
  const steps = [
    { title: 'Order Placed', time: 'Just now', icon: CheckCircle, active: true },
    { title: 'Processing & Packing', time: 'Est. in 4 hours', icon: Package, active: true },
    { title: 'Dispatched to Courier', time: 'Est. Tomorrow morning', icon: Truck, active: false },
    { title: 'Delivered', time: 'Est. 1–2 Days', icon: Home, active: false }
  ];

  const copyTracking = () => {
    navigator.clipboard?.writeText(orderData.trackingNumber);
    alert('Tracking ID copied: ' + orderData.trackingNumber);
  };

  return (
    <div className="pb-24 pt-6 px-3 bg-slate-100 min-h-screen">
      <div className="max-w-md mx-auto space-y-3">
        {/* Success Header Card */}
        <div className="bg-white rounded-3xl p-6 text-center border border-slate-200 shadow-sm">
          <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-3 shadow-inner">
            <CheckCircle className="w-8 h-8" />
          </div>
          <h2 className="text-lg font-black text-slate-900">Order Confirmed!</h2>
          <p className="text-xs text-slate-500 mt-1">
            Thank you for shopping on Sewora. Your vendor has received the order and is preparing fulfillment.
          </p>

          <div className="mt-4 p-3 bg-slate-50 rounded-2xl flex items-center justify-between text-xs">
            <div className="text-left">
              <div className="text-[10px] text-slate-400 uppercase font-semibold">Order Number</div>
              <div className="font-mono font-bold text-slate-900">{orderData.orderNumber}</div>
            </div>
            <div className="text-right">
              <div className="text-[10px] text-slate-400 uppercase font-semibold">Payment</div>
              <div className="font-semibold text-slate-800">{orderData.paymentMethod}</div>
            </div>
          </div>
        </div>

        {/* Live Delivery Tracker Timeline */}
        <div className="bg-white rounded-3xl p-4 border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <span className="text-xs font-bold text-slate-900">Package Tracking</span>
            <button
              onClick={copyTracking}
              className="flex items-center gap-1 text-[11px] text-[#FF6600] font-semibold hover:underline"
            >
              <span>{orderData.trackingNumber}</span>
              <Copy className="w-3 h-3" />
            </button>
          </div>

          <div className="relative pl-6 space-y-4 pt-1">
            {/* Vertical connector line */}
            <div className="absolute left-2.5 top-3 bottom-3 w-0.5 bg-slate-200"></div>

            {steps.map((st, i) => {
              const Icon = st.icon;
              return (
                <div key={i} className="relative flex items-start gap-3">
                  <div className={`absolute -left-6 top-0.5 w-5 h-5 rounded-full flex items-center justify-center z-10 ${
                    st.active ? 'bg-[#FF6600] text-white shadow-xs' : 'bg-slate-200 text-slate-400'
                  }`}>
                    <Icon className="w-3 h-3" />
                  </div>
                  <div>
                    <div className={`text-xs font-bold ${st.active ? 'text-slate-900' : 'text-slate-400'}`}>
                      {st.title}
                    </div>
                    <div className="text-[10px] text-slate-400">{st.time}</div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-2.5 bg-orange-50/50 rounded-xl text-[11px] text-slate-600 border border-orange-100 mt-2">
            📍 Delivering to <strong>{orderData.address.name}</strong>, {orderData.address.addressLine}, {orderData.address.city}.
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2 pt-2">
          <button
            onClick={onViewAccountOrders}
            className="w-full bg-slate-900 text-white font-bold text-xs py-3 rounded-2xl hover:bg-slate-800 transition-colors"
          >
            View My Orders
          </button>
          <button
            onClick={onContinueShopping}
            className="w-full bg-white border border-slate-200 text-slate-700 font-bold text-xs py-3 rounded-2xl hover:bg-slate-50 transition-colors"
          >
            Continue Shopping
          </button>
        </div>
      </div>
    </div>
  );
};
