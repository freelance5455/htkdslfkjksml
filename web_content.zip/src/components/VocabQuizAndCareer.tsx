import React, { useState } from 'react';
import { Volume2, ChevronDown, ChevronUp, RotateCcw, CheckCircle2, XCircle } from 'lucide-react';
import { LangMode } from '../data/types';
import { VOCAB_WORDS, INTERVIEW_QAS, QUIZ_BANK } from '../data/vocabQuizAndCareer';
import { BiTextBlock } from './BilingualBlock';

export const VocabularyPanel: React.FC<{ lang: LangMode }> = ({ lang }) => {
  const [catFilter, setCatFilter] = useState<string>('All');
  const [query, setQuery] = useState('');

  const categories = ['All', 'Pipes & Fittings', 'Tools', 'Fixtures', 'Site Commands'];

  const filtered = VOCAB_WORDS.filter((w) => {
    const matchesCat = catFilter === 'All' || w.category === catFilter;
    const q = query.trim().toLowerCase();
    const matchesQuery =
      !q ||
      w.english.toLowerCase().includes(q) ||
      w.arabicPronunciation.toLowerCase().includes(q) ||
      w.arabic.includes(q) ||
      w.hindi.includes(q) ||
      w.hinglish.toLowerCase().includes(q);
    return matchesCat && matchesQuery;
  });

  const speakWord = (text: string, locale: string) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang = locale;
    utter.rate = 0.9;
    window.speechSynthesis.speak(utter);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex flex-wrap gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setCatFilter(cat)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 min-h-[38px] ${
                catFilter === cat ? 'bg-blue-700 text-white' : 'text-slate-700 hover:bg-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={lang === 'hi' ? 'अंग्रेजी, अरबी या हिंदी शब्द खोजें...' : 'Search English, Arabic, or Hindi word...'}
          className="h-11 px-3.5 rounded-xl border border-slate-300 bg-white text-sm w-full md:w-72 focus:outline-none focus:ring-2 focus:ring-blue-600"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {filtered.map((word) => (
          <div key={word.id} className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col justify-between gap-3">
            <div>
              <div className="text-[11px] font-medium text-slate-500">{word.category}</div>
              <div className="flex items-center justify-between gap-2 mt-1">
                <h4 className="font-bold text-slate-900 text-base">{word.english}</h4>
                <button
                  onClick={() => speakWord(word.english, 'en-US')}
                  title="Listen English"
                  className="w-9 h-9 rounded-lg bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-blue-700 flex items-center justify-center shrink-0"
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="bg-blue-50/70 border border-blue-100 rounded-lg p-3 flex items-center justify-between gap-2">
              <div>
                <div className="text-lg font-bold text-blue-950" dir="rtl">
                  {word.arabic}
                </div>
                <div className="text-xs font-semibold text-blue-700">
                  Pronunciation: {word.arabicPronunciation}
                </div>
              </div>
              <button
                onClick={() => speakWord(word.arabic, 'ar-AE')}
                title="Listen Arabic"
                className="w-9 h-9 rounded-lg bg-white border border-blue-200 text-blue-700 hover:bg-blue-700 hover:text-white flex items-center justify-center shrink-0 transition-colors"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>

            <div className="pt-1 border-t border-slate-100 flex items-center justify-between gap-2 text-sm">
              <span className="font-semibold text-slate-900">{word.hindi}</span>
              <span className="text-xs text-slate-500">{word.hinglish}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export const InterviewPanel: React.FC<{ lang: LangMode }> = ({ lang }) => {
  const [openId, setOpenId] = useState<string>(INTERVIEW_QAS[0].id);
  const [category, setCategory] = useState<string>('All');

  const cats = ['All', 'Dubai / Gulf Trade Test', 'Technical & Drawings', 'Field Troubleshooting'];
  const items = INTERVIEW_QAS.filter((q) => category === 'All' || q.category === category);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200 w-fit">
        {cats.map((c) => (
          <button
            key={c}
            onClick={() => setCategory(c)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 min-h-[38px] ${
              category === c ? 'bg-blue-700 text-white' : 'text-slate-700 hover:bg-white'
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {items.map((item, idx) => {
          const isOpen = openId === item.id;
          return (
            <div key={item.id} className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <button
                onClick={() => setOpenId(isOpen ? '' : item.id)}
                className="w-full text-left p-4 flex items-start justify-between gap-3 hover:bg-slate-50 transition-colors min-h-[56px]"
              >
                <div className="space-y-1">
                  <div className="text-xs text-blue-700 font-medium">
                    Q{idx + 1} · {item.category}
                  </div>
                  <div className="font-semibold text-slate-900 text-sm sm:text-base">
                    {lang === 'hi' ? item.question.hi : item.question.en}
                  </div>
                  {lang === 'both' && <div className="text-xs sm:text-sm text-slate-600">{item.question.hi}</div>}
                </div>
                {isOpen ? (
                  <ChevronUp className="w-5 h-5 text-slate-500 shrink-0 mt-1" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-slate-500 shrink-0 mt-1" />
                )}
              </button>
              {isOpen && (
                <div className="px-4 pb-4 pt-2 border-t border-slate-100 bg-blue-50/40">
                  <BiTextBlock text={item.answer} lang={lang} className="text-sm text-slate-800 leading-relaxed" />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export const QuizPanel: React.FC<{ lang: LangMode }> = ({ lang }) => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [finished, setFinished] = useState(false);

  const q = QUIZ_BANK[currentIdx];
  const selected = answers[q.id];
  const hasAnswered = selected !== undefined;

  const score = QUIZ_BANK.reduce((acc, item) => (answers[item.id] === item.correctIndex ? acc + 1 : acc), 0);

  const resetQuiz = () => {
    setAnswers({});
    setCurrentIdx(0);
    setFinished(false);
  };

  if (finished) {
    const pct = Math.round((score / QUIZ_BANK.length) * 100);
    return (
      <div className="bg-white border border-slate-200 rounded-2xl p-6 text-center max-w-xl mx-auto space-y-4">
        <div className="text-xs font-semibold text-blue-700">
          {lang === 'hi' ? 'टेस्ट परिणाम (Result)' : 'Skill Assessment Result'}
        </div>
        <div className="text-4xl font-extrabold font-mono-num text-slate-900">
          {score} / {QUIZ_BANK.length} ({pct}%)
        </div>
        <p className="text-sm text-slate-600">
          {pct >= 75
            ? lang === 'hi'
              ? 'बहुत बढ़िया! आप दुबई और प्रोफेशनल प्लंबिंग इंटरव्यू के लिए तैयार हैं।'
              : 'Excellent work! You have strong mastery of field standards and sizing.'
            : lang === 'hi'
              ? 'अच्छा प्रयास! पाइप साइज, स्लोप और दुबई स्टैंडर्ड्स दोबारा पढ़ें और फिर से टेस्ट दें।'
              : 'Good effort! Review pipe sizes, slope ratios, and Dubai testing rules, then retry.'}
        </p>
        <button
          onClick={resetQuiz}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-700 text-white text-sm font-semibold hover:bg-blue-800 min-h-[44px]"
        >
          <RotateCcw className="w-4 h-4" />
          <span>{lang === 'hi' ? 'फिर से टेस्ट दें' : 'Restart Practice Quiz'}</span>
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 max-w-2xl mx-auto space-y-5">
      <div className="flex items-center justify-between text-xs font-medium text-slate-500 border-b border-slate-100 pb-3">
        <span>
          Question <span className="font-mono-num font-bold text-slate-900">{currentIdx + 1}</span> / {QUIZ_BANK.length} · {q.topic}
        </span>
        <span className="font-mono-num font-semibold text-blue-700">
          Score: {score}
        </span>
      </div>

      <BiTextBlock
        text={q.question}
        lang={lang}
        className="text-base sm:text-lg font-bold text-slate-900"
        hiClassName="text-sm sm:text-base font-medium text-slate-700"
      />

      <div className="space-y-2.5">
        {q.options.map((opt, idx) => {
          const isSelected = selected === idx;
          const isCorrect = idx === q.correctIndex;
          let btnClass = 'border-slate-200 bg-white hover:bg-slate-50 text-slate-800';
          if (hasAnswered) {
            if (isCorrect) btnClass = 'border-emerald-500 bg-emerald-50 text-emerald-950';
            else if (isSelected) btnClass = 'border-red-400 bg-red-50 text-red-950';
            else btnClass = 'border-slate-200 bg-slate-50 text-slate-500';
          }

          return (
            <button
              key={idx}
              disabled={hasAnswered}
              onClick={() => setAnswers((prev) => ({ ...prev, [q.id]: idx }))}
              className={`w-full text-left p-3.5 rounded-xl border transition-colors flex items-center justify-between gap-3 min-h-[48px] ${btnClass}`}
            >
              <div>
                <span className="font-semibold text-sm">{lang === 'hi' ? opt.hi : opt.en}</span>
                {lang === 'both' && opt.hi !== opt.en && (
                  <span className="block text-xs text-slate-600">{opt.hi}</span>
                )}
              </div>
              {hasAnswered && isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />}
              {hasAnswered && isSelected && !isCorrect && <XCircle className="w-5 h-5 text-red-600 shrink-0" />}
            </button>
          );
        })}
      </div>

      {hasAnswered && (
        <div className="p-4 rounded-xl bg-blue-50 border border-blue-200 space-y-2">
          <div className="text-xs font-bold text-blue-900">
            {selected === q.correctIndex
              ? lang === 'hi'
                ? 'सही जवाब!'
                : 'Correct Answer!'
              : lang === 'hi'
                ? 'सही जानकारी समझें:'
                : 'Explanation:'}
          </div>
          <BiTextBlock text={q.explanation} lang={lang} className="text-sm text-blue-950" hiClassName="text-xs text-blue-900" />
        </div>
      )}

      <div className="flex items-center justify-between pt-2">
        <button
          disabled={currentIdx === 0}
          onClick={() => setCurrentIdx((i) => Math.max(0, i - 1))}
          className="px-4 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 disabled:opacity-40 min-h-[40px]"
        >
          {lang === 'hi' ? 'पिछला' : 'Previous'}
        </button>

        {currentIdx < QUIZ_BANK.length - 1 ? (
          <button
            onClick={() => setCurrentIdx((i) => i + 1)}
            className="px-5 py-2 rounded-xl bg-blue-700 text-white text-xs font-semibold hover:bg-blue-800 min-h-[40px]"
          >
            {lang === 'hi' ? 'अगला सवाल' : 'Next Question'}
          </button>
        ) : (
          <button
            onClick={() => setFinished(true)}
            className="px-5 py-2 rounded-xl bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 min-h-[40px]"
          >
            {lang === 'hi' ? 'रिजल्ट देखें' : 'Finish & See Score'}
          </button>
        )}
      </div>
    </div>
  );
};
