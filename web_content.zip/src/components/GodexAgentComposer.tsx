/**
 * GODEX Phase 4 - Agent Composer Component
 * Elevated bottom composer with:
 * - Multiline prompt field (auto-resizing)
 * - Enter = Send, Shift+Enter = Newline
 * - Autonomy Mode Selector (ASSISTED, CONTROLLED, AUTONOMOUS)
 * - Model & Provider Status Indicator
 * - Stop / Cancel button when active operation is running
 * - Preset Prompt Shortcuts with smooth pill styling
 */

import React, { useState, useRef } from 'react';
import { 
  Send, 
  Square, 
  Sparkles, 
  Cpu, 
  Command, 
  Radio
} from 'lucide-react';
import { ExecutionMode, TaskState } from '../types';

export type AutonomyLevel = 'ASSISTED' | 'CONTROLLED' | 'AUTONOMOUS';

interface GodexAgentComposerProps {
  onSendMessage: (prompt: string) => void;
  isRunning: boolean;
  taskState: TaskState;
  executionMode: ExecutionMode;
  onToggleExecutionMode?: () => void;
  onCancelOperation?: () => void;
  selectedModel?: string;
  onOpenModelSettings?: () => void;
  onOpenCommandPalette?: () => void;
}

export const GodexAgentComposer: React.FC<GodexAgentComposerProps> = ({
  onSendMessage,
  isRunning,
  taskState,
  executionMode,
  onToggleExecutionMode,
  onCancelOperation,
  selectedModel = 'gemini-3.7-flash',
  onOpenModelSettings,
  onOpenCommandPalette
}) => {
  const [promptText, setPromptText] = useState('');
  const [autonomy, setAutonomy] = useState<AutonomyLevel>('CONTROLLED');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const isWorking = isRunning || (taskState !== 'IDLE' && taskState !== 'COMPLETED' && taskState !== 'FAILED');

  const handleTextareaInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setPromptText(e.target.value);
    const target = e.target;
    target.style.height = 'auto';
    target.style.height = `${Math.min(target.scrollHeight, 140)}px`;
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSend = () => {
    if (!promptText.trim() || isWorking) return;
    onSendMessage(promptText.trim());
    setPromptText('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const quickShortcuts = [
    { label: 'Video Studio App', text: 'Build an autonomous multi-track AI video editor with visual timeline, prompt-to-scene synthesis, and live canvas preview.' },
    { label: 'Notes App', text: 'Build a responsive notes application with dashboard, categories, tags, search, and pinned notes.' },
    { label: 'Profile Card', text: 'Create a modern profile card component with avatar, name, role badge, and action button.' }
  ];

  return (
    <div 
      id="godex-agent-composer"
      className="p-3 bg-[#07090E] border-t border-[#151B27] shrink-0 select-none font-sans z-20"
    >
      {/* Quick Prompt Presets */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 no-scrollbar">
        <span className="text-[10px] font-mono text-neutral-500 uppercase tracking-wider shrink-0 mr-1 flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-indigo-400" aria-hidden="true" />
          <span>Presets:</span>
        </span>
        {quickShortcuts.map((sc, i) => (
          <button
            key={i}
            onClick={() => setPromptText(sc.text)}
            disabled={isWorking}
            className="px-2.5 py-1 rounded-md bg-[#0C1018] hover:bg-[#131926] border border-[#1A2336] hover:border-indigo-500/50 text-neutral-300 hover:text-white text-[11px] font-sans transition-all whitespace-nowrap shrink-0 active:scale-98 disabled:opacity-50 focus:outline-none focus:ring-1 focus:ring-indigo-500/40"
          >
            {sc.label}
          </button>
        ))}
      </div>

      {/* Main Elevated Composer Box */}
      <div className="rounded-xl bg-[#0B0E17] border border-[#192234] focus-within:border-indigo-500/80 focus-within:ring-1 focus-within:ring-indigo-500/30 transition-all p-2.5 shadow-xl">
        <textarea
          ref={textareaRef}
          value={promptText}
          onChange={handleTextareaInput}
          onKeyDown={handleKeyDown}
          disabled={isWorking}
          rows={1}
          placeholder={
            isWorking
              ? 'Autonomous agent is executing multi-step pipeline...'
              : 'Instruct GODEX Agent (e.g., "Implement authentication module", "Refactor UI components", "Verify build")...'
          }
          className="w-full bg-transparent text-xs text-white placeholder-neutral-500 resize-none font-sans focus:outline-none disabled:opacity-50 min-h-[38px] max-h-[140px] leading-relaxed block select-text"
          aria-label="Agent Instruction Input"
        />

        {/* Composer Controls Bar */}
        <div className="flex items-center justify-between pt-2 border-t border-[#141B2A] mt-1.5">
          <div className="flex items-center gap-2 flex-wrap font-mono text-[10px]">
            {/* Autonomy Selector */}
            <div className="flex items-center bg-[#07090E] p-0.5 rounded-md border border-[#161E2E]">
              <span className="text-neutral-500 px-1 text-[9px]">MODE:</span>
              {(['ASSISTED', 'CONTROLLED', 'AUTONOMOUS'] as AutonomyLevel[]).map((lvl) => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => setAutonomy(lvl)}
                  disabled={isWorking}
                  className={`px-1.5 py-0.5 rounded text-[9px] font-bold transition-all focus:outline-none ${
                    autonomy === lvl
                      ? 'bg-[#151E2E] text-cyan-300 border border-cyan-500/40 shadow-xs'
                      : 'text-neutral-500 hover:text-neutral-300 border border-transparent'
                  }`}
                  aria-pressed={autonomy === lvl}
                >
                  {lvl}
                </button>
              ))}
            </div>

            {/* Model Badge */}
            <button
              type="button"
              onClick={onOpenModelSettings}
              className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-[#080B12] hover:bg-[#121826] border border-[#161E2E] text-neutral-300 hover:text-white transition-colors focus:outline-none focus:ring-1 focus:ring-indigo-500/40"
              title="Change reasoning model"
              aria-label={`Model: ${selectedModel}`}
            >
              <Cpu className="w-3 h-3 text-indigo-400" aria-hidden="true" />
              <span>{selectedModel}</span>
            </button>

            {/* Command Palette Trigger */}
            {onOpenCommandPalette && (
              <button
                type="button"
                onClick={onOpenCommandPalette}
                className="hidden sm:flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-[#080B12] text-neutral-500 hover:text-neutral-300 border border-[#161E2E] focus:outline-none focus:ring-1 focus:ring-indigo-500/40"
                title="Command Palette (⌘K)"
                aria-label="Command Palette shortcut"
              >
                <Command className="w-3 h-3 text-cyan-400" aria-hidden="true" />
                <span>⌘K</span>
              </button>
            )}
          </div>

          {/* Action Buttons: Stop / Send */}
          <div className="flex items-center gap-2 shrink-0">
            {isWorking && onCancelOperation && (
              <button
                type="button"
                onClick={onCancelOperation}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-rose-950/80 hover:bg-rose-900 border border-rose-800 text-rose-300 font-semibold text-xs transition-colors active:scale-95 focus:outline-none focus:ring-1 focus:ring-rose-500/50"
                title="Stop current agent operation"
                aria-label="Stop current operation"
              >
                <Square className="w-3 h-3 fill-current" aria-hidden="true" />
                <span>Stop</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleSend}
              disabled={!promptText.trim() || isWorking}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-gradient-to-r from-indigo-600 via-indigo-500 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 disabled:bg-neutral-800 disabled:from-neutral-800 disabled:to-neutral-800 disabled:text-neutral-500 text-white font-bold text-xs shadow-md shadow-indigo-950/50 transition-all font-sans cursor-pointer disabled:cursor-not-allowed active:scale-95 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
              aria-label="Execute Agent Pipeline"
            >
              <span>Execute</span>
              <Send className="w-3 h-3" aria-hidden="true" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

