import React, { useRef, useState, useEffect, useCallback } from 'react';
import {
  AirportCity,
  Plane,
  CITY_MAP,
  INITIAL_CITIES
} from '../game/flightLogic';
import {
  MAP_WIDTH,
  MAP_HEIGHT,
  WORLD_CONTINENTS,
  USA_BOUNDS,
  CITY_LABEL_OFFSETS,
  projectLatLng,
  getFlightArcPath,
  getArcPosition
} from '../game/worldMapData';
import { sound } from '../game/sound';
import {
  ZoomIn,
  ZoomOut,
  Maximize2,
  Navigation,
  Lock,
  Plane as PlaneIcon,
  CheckCircle2
} from 'lucide-react';

interface FloatingCash {
  id: number;
  x: number;
  y: number;
  amount: number;
}

interface WorldMapProps {
  unlockedCityIds: string[];
  planes: Plane[];
  selectedCityId: string | null;
  selectedPlaneId: string | null;
  onSelectCity: (city: AirportCity) => void;
  onSelectPlane: (planeId: string) => void;
  onUnlockCity: (city: AirportCity) => void;
  cash: number;
  floatingEarnings: FloatingCash[];
}

export const WorldMap: React.FC<WorldMapProps> = ({
  unlockedCityIds,
  planes,
  selectedCityId,
  selectedPlaneId,
  onSelectCity,
  onSelectPlane,
  onUnlockCity,
  cash,
  floatingEarnings
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  // Pan and Zoom transform state
  const [transform, setTransform] = useState({
    x: -USA_BOUNDS.centerX * USA_BOUNDS.defaultZoom + (typeof window !== 'undefined' ? window.innerWidth / 2 : 500),
    y: -USA_BOUNDS.centerY * USA_BOUNDS.defaultZoom + (typeof window !== 'undefined' ? window.innerHeight / 2 : 400),
    zoom: USA_BOUNDS.defaultZoom
  });

  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef({ x: 0, y: 0, startX: 0, startY: 0 });

  // Center on USA on initial mount
  useEffect(() => {
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      setTransform({
        x: -USA_BOUNDS.centerX * USA_BOUNDS.defaultZoom + rect.width / 2,
        y: -USA_BOUNDS.centerY * USA_BOUNDS.defaultZoom + rect.height / 2,
        zoom: USA_BOUNDS.defaultZoom
      });
    }
  }, []);

  // Handle Dragging
  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button')) return;
    setIsDragging(true);
    dragStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      startX: transform.x,
      startY: transform.y
    };
  };

  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - dragStartRef.current.x;
    const dy = e.clientY - dragStartRef.current.y;
    setTransform(prev => ({
      ...prev,
      x: dragStartRef.current.startX + dx,
      y: dragStartRef.current.startY + dy
    }));
  }, [isDragging]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  useEffect(() => {
    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, handleMouseMove, handleMouseUp]);

  // Touch handlers for mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setIsDragging(true);
      dragStartRef.current = {
        x: e.touches[0].clientX,
        y: e.touches[0].clientY,
        startX: transform.x,
        startY: transform.y
      };
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (isDragging && e.touches.length === 1) {
      const dx = e.touches[0].clientX - dragStartRef.current.x;
      const dy = e.touches[0].clientY - dragStartRef.current.y;
      setTransform(prev => ({
        ...prev,
        x: dragStartRef.current.startX + dx,
        y: dragStartRef.current.startY + dy
      }));
    }
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  // Zoom wheel
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const cursorX = e.clientX - rect.left;
    const cursorY = e.clientY - rect.top;

    const zoomFactor = e.deltaY < 0 ? 1.15 : 0.87;
    const newZoom = Math.min(5.5, Math.max(0.65, transform.zoom * zoomFactor));

    // Zoom centered on cursor
    const newX = cursorX - (cursorX - transform.x) * (newZoom / transform.zoom);
    const newY = cursorY - (cursorY - transform.y) * (newZoom / transform.zoom);

    setTransform({
      x: newX,
      y: newY,
      zoom: newZoom
    });
  };

  const zoomIn = () => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const newZoom = Math.min(5.5, transform.zoom * 1.3);
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    setTransform(prev => ({
      x: centerX - (centerX - prev.x) * (newZoom / prev.zoom),
      y: centerY - (centerY - prev.y) * (newZoom / prev.zoom),
      zoom: newZoom
    }));
    sound.playClick();
  };

  const zoomOut = () => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const newZoom = Math.max(0.65, transform.zoom * 0.77);
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    setTransform(prev => ({
      x: centerX - (centerX - prev.x) * (newZoom / prev.zoom),
      y: centerY - (centerY - prev.y) * (newZoom / prev.zoom),
      zoom: newZoom
    }));
    sound.playClick();
  };

  const centerOnUSA = () => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    setTransform({
      x: -USA_BOUNDS.centerX * 2.5 + rect.width / 2,
      y: -USA_BOUNDS.centerY * 2.5 + rect.height / 2,
      zoom: 2.5
    });
    sound.playRadarPing();
  };

  const fitWorld = () => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const zoomW = rect.width / MAP_WIDTH;
    const zoomH = rect.height / MAP_HEIGHT;
    const newZoom = Math.min(zoomW, zoomH) * 0.95;
    setTransform({
      x: (rect.width - MAP_WIDTH * newZoom) / 2,
      y: (rect.height - MAP_HEIGHT * newZoom) / 2,
      zoom: newZoom
    });
    sound.playRadarPing();
  };

  // Group active routes from planes
  const activeRoutes = planes.map(plane => {
    const fromCity = CITY_MAP.get(plane.fromCityId);
    const toCity = CITY_MAP.get(plane.toCityId);
    if (!fromCity || !toCity) return null;

    const p1 = projectLatLng(fromCity.lat, fromCity.lng);
    const p2 = projectLatLng(toCity.lat, toCity.lng);
    const arc = getFlightArcPath(p1, p2);

    // Actual plane position on arc
    const planeEffectiveProgress = plane.isReturning ? 1 - plane.progress : plane.progress;
    const planePos = getArcPosition(p1, p2, planeEffectiveProgress);
    const planeAngle = plane.isReturning ? planePos.angle + 180 : planePos.angle;

    return {
      plane,
      fromCity,
      toCity,
      p1,
      p2,
      arc,
      planePos,
      planeAngle
    };
  }).filter(Boolean);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full overflow-hidden bg-[#07080b] select-none cursor-grab active:cursor-grabbing"
      onMouseDown={handleMouseDown}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onWheel={handleWheel}
      data-testid="world-map-container"
    >
      {/* Radar Coordinate Grid Background / SVG World */}
      <svg
        className="absolute top-0 left-0 w-[2000px] h-[1000px] pointer-events-auto origin-top-left"
        style={{
          transform: `translate(${transform.x}px, ${transform.y}px) scale(${transform.zoom})`,
          transition: isDragging ? 'none' : 'transform 0.08s ease-out'
        }}
        viewBox={`0 0 ${MAP_WIDTH} ${MAP_HEIGHT}`}
      >
        <defs>
          {/* Subtle radar grid pattern */}
          <pattern id="grid" width="100" height="100" patternUnits="userSpaceOnUse">
            <path d="M 100 0 L 0 0 0 100" fill="none" stroke="#181a22" strokeWidth="0.8" strokeDasharray="3 3" />
          </pattern>
          {/* Graticule lines every 30 degrees */}
          <linearGradient id="planeGlow" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#a1a1aa" stopOpacity="0.4" />
          </linearGradient>
        </defs>

        {/* Ocean background with grid */}
        <rect width={MAP_WIDTH} height={MAP_HEIGHT} fill="#08090d" />
        <rect width={MAP_WIDTH} height={MAP_HEIGHT} fill="url(#grid)" />

        {/* Latitude lines */}
        {[166, 333, 500, 666, 833].map(y => (
          <line
            key={`lat-${y}`}
            x1="0"
            y1={y}
            x2={MAP_WIDTH}
            y2={y}
            stroke="#1c1f2b"
            strokeWidth="0.75"
            strokeDasharray="4 6"
          />
        ))}

        {/* Equator prominent line */}
        <line
          x1="0"
          y1="500"
          x2={MAP_WIDTH}
          y2="500"
          stroke="#272b3b"
          strokeWidth="1.2"
          strokeDasharray="6 4"
        />

        {/* Continents (High contrast B&W) */}
        {WORLD_CONTINENTS.map(cont => (
          <path
            key={cont.id}
            d={cont.path}
            fill="#121318"
            stroke="#2d313f"
            strokeWidth="1.2"
            strokeLinejoin="round"
          />
        ))}

        {/* USA Region Tactical Focus Border */}
        <rect
          x={USA_BOUNDS.minX}
          y={USA_BOUNDS.minY}
          width={USA_BOUNDS.maxX - USA_BOUNDS.minX}
          height={USA_BOUNDS.maxY - USA_BOUNDS.minY}
          fill="none"
          stroke="#3f3f46"
          strokeWidth="1"
          strokeDasharray="6 4"
          rx="6"
        />
        <text
          x={USA_BOUNDS.minX + 12}
          y={USA_BOUNDS.minY + 20}
          fill="#71717a"
          fontSize="11"
          fontFamily="monospace"
          letterSpacing="2"
        >
          STARTER REGION // UNITED STATES
        </text>

        {/* Flight Route Arcs */}
        {activeRoutes.map(item => {
          if (!item) return null;
          const { plane, arc } = item;
          const isSelected = selectedPlaneId === plane.id;
          return (
            <g key={`arc-${plane.id}`}>
              {/* Route shadow/background */}
              <path
                d={arc.path}
                fill="none"
                stroke="#000000"
                strokeWidth={isSelected ? '4' : '2.5'}
                opacity="0.6"
              />
              {/* Animated dotted route path */}
              <path
                d={arc.path}
                fill="none"
                stroke={isSelected ? '#ffffff' : '#a1a1aa'}
                strokeWidth={isSelected ? '2' : '1.2'}
                strokeDasharray="5 5"
                className="transition-all"
              />
            </g>
          );
        })}

        {/* Airport Nodes (All Cities) */}
        {INITIAL_CITIES.map(city => {
          const isUnlocked = unlockedCityIds.includes(city.id);
          const isSelected = selectedCityId === city.id;
          const pos = projectLatLng(city.lat, city.lng);
          const canAfford = cash >= city.unlockCost;
          const offset = CITY_LABEL_OFFSETS[city.id] || { badgeX: 8, badgeY: -6, textX: 0, textY: 15 };

          return (
            <g
              key={city.id}
              className="cursor-pointer group"
              onClick={e => {
                e.stopPropagation();
                if (isUnlocked) {
                  onSelectCity(city);
                } else {
                  onUnlockCity(city);
                }
              }}
            >
              {isUnlocked ? (
                // Unlocked Airport Node
                <>
                  {/* Subtle radar beacon ripple */}
                  <circle
                    cx={pos.x}
                    cy={pos.y}
                    r="12"
                    fill="none"
                    stroke="#ffffff"
                    strokeWidth="0.8"
                    opacity="0.25"
                    className="animate-ping"
                  />
                  {/* Outer circle */}
                  <circle
                    cx={pos.x}
                    cy={pos.y}
                    r={isSelected ? '6.5' : '4.5'}
                    fill="#090a0f"
                    stroke={isSelected ? '#ffffff' : '#e4e4e7'}
                    strokeWidth={isSelected ? '2' : '1.5'}
                  />
                  {/* Center core */}
                  <circle
                    cx={pos.x}
                    cy={pos.y}
                    r="2"
                    fill={isSelected ? '#ffffff' : '#a1a1aa'}
                  />
                  {/* Airport IATA badge */}
                  <g transform={`translate(${pos.x + offset.badgeX}, ${pos.y + offset.badgeY})`}>
                    <rect
                      x="0"
                      y="-10"
                      width="32"
                      height="15"
                      rx="3"
                      fill="#090a0f"
                      stroke={isSelected ? '#ffffff' : '#3f3f46'}
                      strokeWidth="1"
                    />
                    <text
                      x="16"
                      y="1.5"
                      textAnchor="middle"
                      fill={isSelected ? '#ffffff' : '#ffffff'}
                      fontSize="9"
                      fontWeight="bold"
                      fontFamily="monospace"
                    >
                      {city.code}
                    </text>
                  </g>
                  {/* City Name */}
                  <text
                    x={pos.x + offset.textX}
                    y={pos.y + offset.textY}
                    textAnchor={offset.textX < 0 ? 'end' : offset.textX > 0 ? 'start' : 'middle'}
                    fill="#d4d4d8"
                    fontSize="8.5"
                    fontWeight="500"
                    fontFamily="sans-serif"
                    className="pointer-events-none drop-shadow"
                  >
                    {city.name}
                  </text>
                </>
              ) : (
                // Locked Airport Node
                <>
                  <circle
                    cx={pos.x}
                    cy={pos.y}
                    r="3.5"
                    fill="#18181b"
                    stroke={canAfford ? '#a1a1aa' : '#3f3f46'}
                    strokeWidth="1"
                    strokeDasharray="2 2"
                  />
                  {/* Cost tag badge */}
                  <g transform={`translate(${pos.x + offset.badgeX}, ${pos.y + offset.badgeY})`}>
                    <rect
                      x="0"
                      y="-9"
                      width="38"
                      height="14"
                      rx="2"
                      fill="#121316"
                      stroke={canAfford ? '#a1a1aa' : '#27272a'}
                      strokeWidth="0.8"
                    />
                    <text
                      x="19"
                      y="1.5"
                      textAnchor="middle"
                      fill={canAfford ? '#f4f4f5' : '#71717a'}
                      fontSize="8"
                      fontFamily="monospace"
                      fontWeight="600"
                    >
                      ${city.unlockCost >= 1000 ? `${(city.unlockCost / 1000).toFixed(0)}k` : city.unlockCost}
                    </text>
                  </g>
                  <text
                    x={pos.x + offset.textX}
                    y={pos.y + offset.textY}
                    textAnchor={offset.textX < 0 ? 'end' : offset.textX > 0 ? 'start' : 'middle'}
                    fill="#52525b"
                    fontSize="7.5"
                    fontFamily="sans-serif"
                    className="pointer-events-none"
                  >
                    {city.name}
                  </text>
                </>
              )}
            </g>
          );
        })}

        {/* Flying Planes on Arcs */}
        {activeRoutes.map(item => {
          if (!item) return null;
          const { plane, planePos, planeAngle } = item;
          const isSelected = selectedPlaneId === plane.id;

          return (
            <g
              key={`plane-marker-${plane.id}`}
              transform={`translate(${planePos.x}, ${planePos.y})`}
              className="cursor-pointer group"
              onClick={e => {
                e.stopPropagation();
                onSelectPlane(plane.id);
                sound.playClick();
              }}
            >
              {/* Contrail trail behind plane */}
              <circle
                r={isSelected ? '14' : '10'}
                fill="none"
                stroke="#ffffff"
                strokeWidth="1"
                opacity="0.2"
                className="animate-pulse"
              />

              {/* Rotated Jet Icon */}
              <g transform={`rotate(${planeAngle})`}>
                {/* Airplane silhouette in crisp white */}
                <path
                  d="M -2 -10 L 2 -10 L 3 -3 L 12 3 L 12 5 L 3 2 L 2 9 L 6 12 L 6 14 L 0 12 L -6 14 L -6 12 L -2 9 L -3 2 L -12 5 L -12 3 L -3 -3 Z"
                  fill={isSelected ? '#ffffff' : '#f4f4f5'}
                  stroke="#090a0f"
                  strokeWidth="1.2"
                />
              </g>

              {/* Plane tag callout */}
              <g transform="translate(14, -12)">
                <rect
                  x="0"
                  y="-8"
                  width="50"
                  height="15"
                  rx="3"
                  fill="#090a0f"
                  stroke={isSelected ? '#ffffff' : '#52525b'}
                  strokeWidth="0.9"
                  opacity="0.92"
                />
                <text
                  x="25"
                  y="3"
                  textAnchor="middle"
                  fill="#ffffff"
                  fontSize="8.5"
                  fontFamily="monospace"
                  fontWeight="bold"
                >
                  {plane.name}
                </text>
              </g>
            </g>
          );
        })}

        {/* Floating Cash Arrival Numbers */}
        {floatingEarnings.map(item => {
          return (
            <g
              key={item.id}
              transform={`translate(${item.x}, ${item.y})`}
              className="pointer-events-none transition-all duration-700 ease-out"
            >
              <rect
                x="-25"
                y="-18"
                width="50"
                height="18"
                rx="3"
                fill="#000000"
                stroke="#ffffff"
                strokeWidth="1"
              />
              <text
                x="0"
                y="-5"
                textAnchor="middle"
                fill="#ffffff"
                fontSize="11"
                fontWeight="bold"
                fontFamily="monospace"
              >
                +${item.amount}
              </text>
            </g>
          );
        })}
      </svg>

      {/* Map Control Utilities (Floating Dock) */}
      <div className="absolute bottom-6 right-6 flex flex-col gap-2 z-10">
        <button
          onClick={zoomIn}
          aria-label="Zoom In"
          className="p-2.5 bg-[#121316] hover:bg-[#1f2026] text-white border border-[#27272a] rounded-lg shadow-md transition-colors"
        >
          <ZoomIn size={18} />
        </button>
        <button
          onClick={zoomOut}
          aria-label="Zoom Out"
          className="p-2.5 bg-[#121316] hover:bg-[#1f2026] text-white border border-[#27272a] rounded-lg shadow-md transition-colors"
        >
          <ZoomOut size={18} />
        </button>
        <button
          onClick={centerOnUSA}
          aria-label="Focus USA Starter Map"
          title="Focus USA"
          className="p-2.5 bg-[#121316] hover:bg-[#1f2026] text-white border border-[#27272a] rounded-lg shadow-md transition-colors flex items-center justify-center font-mono text-xs font-bold"
        >
          USA
        </button>
        <button
          onClick={fitWorld}
          aria-label="Fit World Map"
          title="World View"
          className="p-2.5 bg-[#121316] hover:bg-[#1f2026] text-white border border-[#27272a] rounded-lg shadow-md transition-colors"
        >
          <Maximize2 size={18} />
        </button>
      </div>

      {/* Territory Briefing Badge (Bottom Left) */}
      <div className="absolute bottom-6 left-6 z-10 hidden sm:flex items-center gap-3 px-3 py-2 bg-[#0d0e12]/90 border border-[#27272a] rounded-lg text-xs font-mono text-[#a1a1aa] shadow-lg backdrop-blur-none">
        <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
        <span>RADAR ACTIVE · DRAG MAP TO PAN · SCROLL TO ZOOM</span>
      </div>
    </div>
  );
};
