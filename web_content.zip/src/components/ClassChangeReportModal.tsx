import React, { useState } from 'react';
import { CheckCircle2, Clock, Lock, Send, X, XCircle } from 'lucide-react';
import { ClassChangeReport, LanguageCode } from '../types/edutoon';
import { Logo } from './Logo';

interface ClassChangeReportModalProps {
  currentClass: number;
  studentName: string;
  language: LanguageCode;
  reports: ClassChangeReport[];
  onSubmitReport: (requestedClass: number, reason: string) => Promise<void>;
  onClose: () => void;
}

export const ClassChangeReportModal: React.FC<ClassChangeReportModalProps> = ({
  currentClass,
  studentName,
  language,
  reports,
  onSubmitReport,
  onClose,
}) => {
  const isHi = language === 'hi';
  const availableClasses = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].filter((c) => c !== currentClass);
  const [requestedClass, setRequestedClass] = useState<number>(availableClasses[0] || 1);
  const [reason, setReason] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const hasPending = reports.some((r) => r.status === 'pending');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (reason.trim().length < 5) {
      setErrorMsg(
        isHi
          ? 'कृपया कक्षा बदलने का स्पष्ट कारण (कम से कम 5 अक्षर) लिखें।'
          : 'Please explain your reason for changing class (at least 5 characters).'
      );
      return;
    }

    setSubmitting(true);
    try {
      await onSubmitReport(requestedClass, reason.trim());
      setReason('');
      setSuccessMsg(
        isHi
          ? 'आपकी क्लास चेंज रिपोर्ट एडमिन समीक्षा के लिए भेज दी गई है।'
          : 'Your Class Change Report has been submitted for admin review.'
      );
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to submit report.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
      <div className="w-full max-w-2xl bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden flex flex-col max-h-[92vh]">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-3">
            <Logo size="xs" />
            <div>
              <h2 className="font-display text-base sm:text-lg font-bold text-slate-900">
                {isHi ? 'क्लास चेंज रिपोर्ट (Admin Approval)' : 'Class Change Report'}
              </h2>
              <p className="text-xs text-slate-500">
                {isHi
                  ? `${studentName} · वर्तमान लॉक कक्षा: ${currentClass}`
                  : `${studentName} · Current Locked Class: ${currentClass}`}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center text-slate-600 hover:bg-slate-200/70 cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-5 sm:p-6 overflow-y-auto space-y-6">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex items-start gap-3">
            <Lock className="h-5 w-5 text-sky-600 shrink-0 mt-0.5" />
            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
              {isHi
                ? 'शैक्षणिक सत्र के दौरान कक्षा सीधे नहीं बदली जा सकती। केवल अधिकृत एडमिन ही आपकी रिपोर्ट को स्वीकृत (Approve) कर सकता है।'
                : 'Classes remain locked until the next academic session. Only an authorized administrator can approve a class change after reviewing your reason.'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  {isHi ? 'वर्तमान कक्षा' : 'Current Class'}
                </label>
                <div className="h-11 px-3.5 rounded-xl border border-slate-200 bg-slate-100 text-sm font-semibold text-slate-700 flex items-center font-mono-num">
                  Class {currentClass}
                </div>
              </div>

              <div>
                <label
                  htmlFor="requested-class"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  {isHi ? 'नई कक्षा चुनें' : 'Requested New Class'}
                </label>
                <select
                  id="requested-class"
                  value={requestedClass}
                  onChange={(e) => setRequestedClass(Number(e.target.value))}
                  disabled={hasPending}
                  className="w-full h-11 px-3.5 rounded-xl border border-slate-300 bg-white text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500"
                >
                  {availableClasses.map((c) => (
                    <option key={c} value={c}>
                      {isHi ? `कक्षा ${c}` : `Class ${c}`}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label
                htmlFor="change-reason"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                {isHi ? 'कक्षा बदलने का कारण' : 'Reason for Changing Class'}
              </label>
              <textarea
                id="change-reason"
                rows={3}
                maxLength={500}
                disabled={hasPending}
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder={
                  isHi
                    ? 'उदाहरण: गलती से गलत कक्षा चुन ली गई थी / नई कक्षा में प्रोन्नत हुआ हूँ।'
                    : 'e.g. Selected wrong class by mistake during registration / promoted to next grade.'
                }
                className="w-full p-3.5 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500 disabled:bg-slate-100"
              />
            </div>

            {errorMsg && <p className="text-xs sm:text-sm text-red-700 font-medium">{errorMsg}</p>}
            {successMsg && (
              <p className="text-xs sm:text-sm text-emerald-700 font-medium">{successMsg}</p>
            )}

            <button
              type="submit"
              disabled={submitting || hasPending}
              className="w-full sm:w-auto min-h-[46px] px-6 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 disabled:bg-slate-300 disabled:text-slate-600 text-white text-sm font-semibold inline-flex items-center justify-center gap-2 cursor-pointer"
            >
              <Send className="h-4 w-4" />
              <span>
                {hasPending
                  ? isHi
                    ? 'एक रिपोर्ट पहले से लंबित (Pending) है'
                    : 'A Report is Currently Pending'
                  : submitting
                    ? isHi
                      ? 'भेजा जा रहा है...'
                      : 'Submitting...'
                    : isHi
                      ? 'रिपोर्ट सबमिट करें'
                      : 'Submit Class Change Report'}
              </span>
            </button>
          </form>

          {/* Report Status History */}
          <div className="border-t border-slate-200 pt-5">
            <h3 className="font-display text-sm font-bold text-slate-900 mb-3">
              {isHi ? 'मेरी रिपोर्ट स्थिति' : 'Your Submitted Reports'}
            </h3>
            {reports.length === 0 ? (
              <p className="text-sm text-slate-500">
                {isHi ? 'अभी तक कोई क्लास चेंज रिपोर्ट नहीं भेजी गई है।' : 'No class change reports submitted yet.'}
              </p>
            ) : (
              <div className="space-y-3">
                {reports.map((rep) => (
                  <div
                    key={rep.id}
                    className="p-4 rounded-2xl border border-slate-200 bg-slate-50/70 space-y-1.5"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <p className="text-sm font-semibold text-slate-900 font-mono-num">
                        Class {rep.currentClass} → Class {rep.requestedClass}
                      </p>
                      <span
                        className={`inline-flex items-center gap-1.5 text-xs font-semibold ${
                          rep.status === 'approved'
                            ? 'text-emerald-700'
                            : rep.status === 'rejected'
                              ? 'text-red-700'
                              : 'text-amber-700'
                        }`}
                      >
                        {rep.status === 'approved' && <CheckCircle2 className="h-4 w-4" />}
                        {rep.status === 'rejected' && <XCircle className="h-4 w-4" />}
                        {rep.status === 'pending' && <Clock className="h-4 w-4" />}
                        <span>
                          {rep.status === 'approved'
                            ? 'Approved'
                            : rep.status === 'rejected'
                              ? 'Rejected'
                              : 'Pending'}
                        </span>
                      </span>
                    </div>
                    <p className="text-xs sm:text-sm text-slate-600">{rep.reason}</p>
                    {rep.adminNote && (
                      <p className="text-xs text-slate-700 font-medium pt-1">
                        Admin Note: {rep.adminNote}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
