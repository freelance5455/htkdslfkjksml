import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Code, 
  Copy, 
  Check, 
  Terminal, 
  Download, 
  FileCode, 
  FolderTree, 
  Smartphone, 
  Play, 
  Sparkles,
  ExternalLink
} from 'lucide-react';

interface CodeFile {
  name: string;
  path: string;
  language: string;
  code: string;
}

const RN_CODEBASE: CodeFile[] = [
  {
    name: 'package.json',
    path: 'package.json',
    language: 'json',
    code: `{
  "name": "SecretGossip",
  "version": "1.0.0",
  "scripts": {
    "start": "expo start",
    "android": "expo start --android",
    "ios": "expo start --ios",
    "build:apk": "eas build -p android --profile preview"
  },
  "dependencies": {
    "expo": "~52.0.0",
    "expo-status-bar": "~2.0.0",
    "react": "18.3.1",
    "react-native": "0.76.5",
    "react-native-paper": "^5.12.5",
    "react-native-safe-area-context": "4.12.0",
    "react-native-screens": "~4.4.0",
    "@react-navigation/native": "^7.0.0",
    "@react-navigation/bottom-tabs": "^7.0.0",
    "@react-navigation/native-stack": "^7.0.0",
    "lucide-react-native": "^0.475.0"
  },
  "devDependencies": {
    "@types/react": "~18.3.12",
    "typescript": "^5.3.3"
  },
  "private": true
}`
  },
  {
    name: 'App.tsx',
    path: 'App.tsx',
    language: 'typescript',
    code: `import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { MD3DarkTheme, PaperProvider } from 'react-native-paper';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// Screens
import FeedScreen from './src/screens/FeedScreen';
import CreateConfessionScreen from './src/screens/CreateConfessionScreen';
import ChatRoomsScreen from './src/screens/ChatRoomsScreen';
import GamesScreen from './src/screens/GamesScreen';
import CollegeVerifyScreen from './src/screens/CollegeVerifyScreen';

// Custom Neon Cyber Theme matching Secret Gossip design
const neonDarkTheme = {
  ...MD3DarkTheme,
  colors: {
    ...MD3DarkTheme.colors,
    primary: '#06b6d4', // Cyan neon
    secondary: '#a855f7', // Purple neon
    background: '#07080d',
    surface: '#0e111d',
    card: '#121524',
    text: '#f8fafc',
  },
};

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: '#090b14' },
        headerTintColor: '#06b6d4',
        tabBarStyle: { backgroundColor: '#090b14', borderTopColor: '#1e293b' },
        tabBarActiveTintColor: '#06b6d4',
        tabBarInactiveTintColor: '#64748b',
      }}
    >
      <Tab.Screen name="Feeds" component={FeedScreen} options={{ title: 'Secret Gossip' }} />
      <Tab.Screen name="Rooms" component={ChatRoomsScreen} options={{ title: 'Whisper Rooms' }} />
      <Tab.Screen name="Games" component={GamesScreen} options={{ title: 'Campus Arcade' }} />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <PaperProvider theme={neonDarkTheme}>
        <StatusBar style="light" />
        <NavigationContainer>
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Main" component={MainTabs} />
            <Stack.Screen name="CreateConfession" component={CreateConfessionScreen} />
            <Stack.Screen name="VerifyCollege" component={CollegeVerifyScreen} />
          </Stack.Navigator>
        </NavigationContainer>
      </PaperProvider>
    </SafeAreaProvider>
  );
}`
  },
  {
    name: 'FeedScreen.tsx',
    path: 'src/screens/FeedScreen.tsx',
    language: 'typescript',
    code: `import React, { useState } from 'react';
import { View, FlatList, StyleSheet } from 'react-native';
import { Text, Card, Button, Chip, FAB, IconButton } from 'react-native-paper';

interface ConfessionItem {
  id: string;
  avatar: string;
  name: string;
  hash: string;
  college: string;
  category: string;
  content: string;
  likes: number;
}

const DUMMY_CONFESSIONS: ConfessionItem[] = [
  {
    id: '1',
    avatar: '🦊',
    name: 'Neon Fox',
    hash: '#SS-8F12-4912',
    college: 'DU-NORTH',
    category: 'Secret',
    content: "I secretly leave motivational sticky notes in the central library at 2 AM before exam week. Saw someone cry of relief today!",
    likes: 247,
  },
  {
    id: '2',
    avatar: '🐱',
    name: 'Shadow Lynx',
    hash: '#SS-42A9-8819',
    college: 'IITD-2026',
    category: 'Love',
    content: "Crush on the maroon hoodie student in 3rd row during Prof. Sharma's 8:30 AM Data Structures lecture for 2 semesters. Say hi!",
    likes: 412,
  },
];

export default function FeedScreen({ navigation }: any) {
  const [feed, setFeed] = useState(DUMMY_CONFESSIONS);

  const handleLike = (id: string) => {
    setFeed(prev => prev.map(item => item.id === id ? { ...item, likes: item.likes + 1 } : item));
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={feed}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.list}
        renderItem={({ item }) => (
          <Card style={styles.card}>
            <Card.Title
              title={\`\${item.avatar} \${item.name}\`}
              subtitle={\`\${item.category} · \${item.college} · \${item.hash}\`}
              subtitleStyle={{ color: '#06b6d4', fontSize: 11 }}
            />
            <Card.Content>
              <Text variant="bodyMedium" style={{ color: '#e2e8f0', lineHeight: 22 }}>
                {item.content}
              </Text>
            </Card.Content>
            <Card.Actions>
              <Button icon="fire" onPress={() => handleLike(item.id)} textColor="#f43f5e">
                {item.likes} Likes
              </Button>
              <Button icon="comment-outline" textColor="#94a3b8">
                Reply
              </Button>
            </Card.Actions>
          </Card>
        )}
      />

      <FAB
        icon="plus"
        style={styles.fab}
        color="#07080d"
        onPress={() => navigation.navigate('CreateConfession')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#07080d' },
  list: { padding: 16, paddingBottom: 80 },
  card: {
    backgroundColor: '#0e111d',
    marginBottom: 16,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#1e293b',
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
    backgroundColor: '#06b6d4',
  },
});`
  },
  {
    name: 'CreateConfessionScreen.tsx',
    path: 'src/screens/CreateConfessionScreen.tsx',
    language: 'typescript',
    code: `import React, { useState } from 'react';
import { View, StyleSheet, ScrollView } from 'react-native';
import { TextInput, Button, Text, SegmentedButtons } from 'react-native-paper';

export default function CreateConfessionScreen({ navigation }: any) {
  const [text, setText] = useState('');
  const [category, setCategory] = useState('secret');

  const handlePost = () => {
    if (!text.trim()) return;
    // In real app, dispatch to state or Firestore/Express API
    navigation.goBack();
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 20 }}>
      <Text variant="titleLarge" style={styles.header}>
        Whisper a Confession
      </Text>
      <Text style={styles.subtitle}>
        Real names are never revealed. 100% anonymous disguise.
      </Text>

      <TextInput
        mode="outlined"
        placeholder="What's your deepest secret or campus tea?..."
        multiline
        numberOfLines={6}
        value={text}
        onChangeText={setText}
        style={styles.input}
        textColor="#fff"
      />

      <SegmentedButtons
        value={category}
        onValueChange={setCategory}
        buttons={[
          { value: 'secret', label: 'Secret' },
          { value: 'love', label: 'Love' },
          { value: 'funny', label: 'Funny' },
        ]}
        style={{ marginVertical: 16 }}
      />

      <Button
        mode="contained"
        buttonColor="#06b6d4"
        textColor="#07080d"
        onPress={handlePost}
        style={styles.button}
      >
        Post Anonymously
      </Button>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#07080d' },
  header: { color: '#06b6d4', fontWeight: 'bold' },
  subtitle: { color: '#94a3b8', fontSize: 12, marginBottom: 20 },
  input: { backgroundColor: '#0e111d', marginBottom: 10 },
  button: { borderRadius: 12, paddingVertical: 4 },
});`
  },
  {
    name: 'eas.json',
    path: 'eas.json',
    language: 'json',
    code: `{
  "cli": {
    "version": ">= 12.0.0"
  },
  "build": {
    "preview": {
      "android": {
        "buildType": "apk"
      }
    },
    "production": {
      "android": {
        "buildType": "app-bundle"
      }
    }
  }
}`
  }
];

export const ReactNativeExportModal: React.FC = () => {
  const { isExportModalOpen, setIsExportModalOpen } = useApp();
  const [selectedFile, setSelectedFile] = useState<CodeFile>(RN_CODEBASE[0]);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'androidStudio' | 'files' | 'terminal'>('androidStudio');

  if (!isExportModalOpen) return null;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(selectedFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadAll = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(RN_CODEBASE, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "SecretGossip_ReactNative_StarterKit.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div 
        className="w-full max-w-4xl bg-[#0e111d] border border-cyan-500/40 rounded-3xl shadow-2xl shadow-cyan-950/40 flex flex-col h-[640px] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="p-4 border-b border-slate-800 bg-[#090b14] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-950/80 border border-cyan-500/50 flex items-center justify-center text-cyan-400">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display font-bold text-sm sm:text-base text-slate-100 flex items-center gap-2">
                <span>Secret Gossip Mobile App (React Native + Paper)</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                  APK Ready
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Full folder structure, starter code & EAS Android APK build guide
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsExportModalOpen(false)}
            className="p-1.5 rounded-full bg-slate-800/60 hover:bg-slate-700 text-slate-400 hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* View Switcher: Android Studio Native vs React Native Files vs Expo Terminal */}
        <div className="px-4 py-2 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between text-xs overflow-x-auto">
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <button
              onClick={() => setActiveTab('androidStudio')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeTab === 'androidStudio' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
              <span>Android Studio (Native APK)</span>
            </button>
            <button
              onClick={() => setActiveTab('files')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeTab === 'files' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FolderTree className="w-3.5 h-3.5" />
              <span>React Native Code</span>
            </button>
            <button
              onClick={() => setActiveTab('terminal')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
                activeTab === 'terminal' ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Expo CLI Guide</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-all"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-cyan-400" />}
              <span>{copied ? 'Copied!' : 'Copy File'}</span>
            </button>
            <button
              onClick={handleDownloadAll}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs transition-all shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Export JSON Bundle</span>
            </button>
          </div>
        </div>

        {/* Content Area */}
        {activeTab === 'androidStudio' ? (
          /* Android Studio Native APK Guide */
          <div className="flex-1 p-5 overflow-y-auto space-y-4 text-xs text-slate-300 leading-relaxed bg-[#07080f]">
            
            <div className="p-4 rounded-2xl bg-cyan-950/40 border border-cyan-500/40 space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-display font-bold text-sm text-cyan-300 flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-cyan-400" />
                  <span>Full Native Android APK via Android Studio (Capacitor)</span>
                </h4>
                <span className="font-mono text-[10px] text-cyan-300 bg-cyan-900/60 px-2 py-0.5 rounded-full border border-cyan-400/40">
                  Recommended for Play Store
                </span>
              </div>
              <p className="text-slate-300 text-xs">
                Humne is project mein <code>capacitor.config.json</code> already configure kar diya hai. Aap apne laptop/PC par niche diye gaye 4 steps run karke direct Android Studio se APK generate kar sakte hain!
              </p>
            </div>

            {/* Step 1 */}
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
              <h5 className="font-display font-bold text-xs text-slate-100 flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-cyan-500 text-slate-950 font-bold flex items-center justify-center text-[11px]">1</span>
                <span>Codebase Download Karein & Folder Open Karein</span>
              </h5>
              <p className="text-slate-400">
                Apne computer par VS Code ya Terminal kholein aur is project folder mein jayein.
              </p>
            </div>

            {/* Step 2 */}
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
              <h5 className="font-display font-bold text-xs text-slate-100 flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-cyan-500 text-slate-950 font-bold flex items-center justify-center text-[11px]">2</span>
                <span>Capacitor Android Packages Install Karein</span>
              </h5>
              <p className="text-slate-400">
                Terminal mein yeh command run karein:
              </p>
              <div className="p-3 rounded-xl bg-slate-950 font-mono text-cyan-300 select-all border border-slate-800 flex items-center justify-between">
                <span>npm install @capacitor/core @capacitor/cli @capacitor/android</span>
              </div>
            </div>

            {/* Step 3 */}
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
              <h5 className="font-display font-bold text-xs text-slate-100 flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-cyan-500 text-slate-950 font-bold flex items-center justify-center text-[11px]">3</span>
                <span>Web Build Generate Karein & Android Project Banayein</span>
              </h5>
              <div className="p-3 rounded-xl bg-slate-950 font-mono text-cyan-200 select-all border border-slate-800 space-y-1">
                <div>npm run build</div>
                <div>npx cap add android</div>
              </div>
              <p className="text-slate-400 text-[11px]">
                Yeh command aapke folder mein ek asli <code>android/</code> directory bana degi jisme poora Java/Kotlin Gradle project hoga.
              </p>
            </div>

            {/* Step 4 */}
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-emerald-500/40 space-y-2">
              <h5 className="font-display font-bold text-xs text-emerald-300 flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-500 text-slate-950 font-bold flex items-center justify-center text-[11px]">4</span>
                <span>Android Studio Kholein</span>
              </h5>
              <div className="p-3 rounded-xl bg-slate-950 font-mono text-emerald-300 select-all border border-slate-800">
                <span>npx cap open android</span>
              </div>
              <p className="text-slate-300 text-[11px]">
                Yeh command seedhe <strong>Android Studio</strong> ko open kar degi!
              </p>
            </div>

            {/* Step 5 */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-cyan-950/60 via-indigo-950/40 to-slate-900 border border-cyan-500/50 space-y-2.5">
              <h5 className="font-display font-bold text-sm text-cyan-200 flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-cyan-400 text-slate-950 font-bold flex items-center justify-center text-[11px]">5</span>
                <span>Android Studio Mein APK Export Kaise Karein:</span>
              </h5>
              <ul className="space-y-1.5 text-slate-300 list-disc list-inside">
                <li>Android Studio ke top menu mein jayein: <strong>Build</strong> &gt; <strong>Build Bundle(s) / APK(s)</strong> &gt; <strong>Build APK(s)</strong>.</li>
                <li>Gradle 1-2 minute mein compile karega aur popup aayega: <em>"APK(s) generated successfully"</em>.</li>
                <li><strong>locate</strong> button par click karein. Aapki APK file yahan tayar milegi:
                  <div className="my-1.5 p-2 bg-slate-950 rounded-lg font-mono text-cyan-300 text-[10px] select-all border border-slate-800">
                    android/app/build/outputs/apk/debug/app-debug.apk
                  </div>
                </li>
                <li>Ise apne phone par WhatsApp ya USB se bhejein aur install karke chalayein!</li>
              </ul>
            </div>

            {/* Step 6 */}
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-purple-500/30 space-y-2">
              <h5 className="font-display font-bold text-xs text-purple-300 flex items-center gap-2">
                <span>🔄 Baad Mein Agar Koi Change Kiya Toh?</span>
              </h5>
              <p className="text-slate-300 text-[11px]">
                Jab bhi aap code mein koi naya feature ya design change karein, bas yeh 2 commands run karein:
              </p>
              <div className="p-3 rounded-xl bg-slate-950 font-mono text-purple-300 select-all border border-slate-800">
                npm run build<br />
                npx cap sync
              </div>
              <p className="text-slate-400 text-[11px]">
                Aur Android Studio mein Run (Green Play button) dabate hi aapke mobile mein naya code update ho jayega!
              </p>
            </div>

          </div>
        ) : activeTab === 'files' ? (
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden bg-[#07080f]">
            {/* Left File Tree Sidebar */}
            <div className="w-full md:w-64 border-b md:border-b-0 md:border-r border-slate-800 p-3 overflow-y-auto space-y-1">
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block px-2 mb-1">
                Project Tree
              </span>
              {RN_CODEBASE.map(file => (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-xl text-left text-xs font-mono transition-all ${
                    selectedFile.path === file.path 
                      ? 'bg-cyan-950/60 border border-cyan-500/40 text-cyan-200 font-semibold' 
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                  }`}
                >
                  <FileCode className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span className="truncate">{file.path}</span>
                </button>
              ))}
            </div>

            {/* Right Code Display */}
            <div className="flex-1 p-4 overflow-y-auto font-mono text-xs text-slate-200 bg-[#090b14]/70">
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-[11px] text-slate-400">
                <span>{selectedFile.path}</span>
                <span className="uppercase text-[10px]">{selectedFile.language}</span>
              </div>
              <pre className="whitespace-pre overflow-x-auto leading-relaxed text-slate-300 font-mono text-[11px] select-all">
                {selectedFile.code}
              </pre>
            </div>
          </div>
        ) : (
          /* Terminal Instructions & APK Build Guide */
          <div className="flex-1 p-5 overflow-y-auto space-y-4 text-xs text-slate-300 leading-relaxed bg-[#07080f]">
            
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-cyan-500/30 space-y-2">
              <h4 className="font-display font-bold text-sm text-cyan-300 flex items-center gap-1.5">
                <Play className="w-4 h-4 text-cyan-400" />
                <span>Step 1: Setup React Native Project in VS Code</span>
              </h4>
              <p className="text-slate-400">
                Open terminal in your empty project folder and run:
              </p>
              <div className="p-3 rounded-xl bg-slate-950 font-mono text-cyan-200 select-all border border-slate-800">
                npx create-expo-app SecretGossip --template blank-typescript
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/80 border border-purple-500/30 space-y-2">
              <h4 className="font-display font-bold text-sm text-purple-300 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span>Step 2: Install React Native Paper & Navigation</span>
              </h4>
              <div className="p-3 rounded-xl bg-slate-950 font-mono text-purple-200 select-all border border-slate-800">
                cd SecretGossip<br />
                npm install react-native-paper react-native-safe-area-context react-native-screens @react-navigation/native @react-navigation/bottom-tabs @react-navigation/native-stack lucide-react-native
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/80 border border-emerald-500/30 space-y-2">
              <h4 className="font-display font-bold text-sm text-emerald-300 flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-emerald-400" />
                <span>Step 3: Run Live on Android Device / Emulator</span>
              </h4>
              <div className="p-3 rounded-xl bg-slate-950 font-mono text-emerald-200 select-all border border-slate-800">
                npx expo start
              </div>
              <p className="text-slate-400">
                Scan the QR code with the <strong>Expo Go</strong> app on your Android or iPhone!
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/80 border border-rose-500/30 space-y-2">
              <h4 className="font-display font-bold text-sm text-rose-300 flex items-center gap-1.5">
                <Download className="w-4 h-4 text-rose-400" />
                <span>Step 4: Generate Standalone .APK File for PlayStore</span>
              </h4>
              <p className="text-slate-400">
                To build an installable APK file directly in the cloud:
              </p>
              <div className="p-3 rounded-xl bg-slate-950 font-mono text-rose-200 select-all border border-slate-800">
                npm install -g eas-cli<br />
                eas login<br />
                eas build:configure<br />
                eas build -p android --profile preview
              </div>
              <p className="text-slate-400">
                Expo Application Services (EAS) will generate a downloadable <code>.apk</code> URL directly in your terminal, ready to install on any Android phone!
              </p>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
