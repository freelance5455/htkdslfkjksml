import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Shield, Award, AlertTriangle } from 'lucide-react';
import { soundManager } from '../game/audio/SoundManager';

interface ReviveModalProps {
  score: number;
  distance: number;
  diamonds: number;
  reviveCount: number;
  onRevive: () => void;
  onDecline: () => void;
}

export const ReviveModal: React.FC<ReviveModalProps> = ({
  score,
  distance,
  diamonds,
  reviveCount,
  onRevive,
  onDecline,
}) => {
  const [countdown, setCountdown] = useState<number>(8);
  const canAfford = diamonds >= 1;
  const currentAttempt = reviveCount + 1;

  useEffect(() => {
    // Ensure background music continues seamlessly without interruption or restart
    soundManager.continueMusic();

    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          soundManager.fadeOutMusic(600);
          soundManager.playGameOverSound();
          onDecline();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [onDecline]);

  const handleReviveClick = () => {
    if (!canAfford) return;
    soundManager.playButtonClick();
    soundManager.continueMusic();
    onRevive();
  };

  const handleDeclineClick = () => {
    soundManager.playButtonClick();
    soundManager.fadeOutMusic(600);
    soundManager.playGameOverSound();
    onDecline();
  };

  return (
    <div
      id="revive-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-fade-in select-none"
    >
      <motion.div
        id="revive-modal-card"
        initial={{ scale: 0.88, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.88, opacity: 0 }}
        transition={{ type: 'spring', damping: 24, stiffness: 300 }}
        className="relative w-full max-w-sm rounded-3xl bg-gradient-to-b from-slate-900 via-neutral-900 to-black p-6 text-white border-2 border-cyan-500/50 shadow-[0_0_50px_rgba(6,182,212,0.35)] flex flex-col items-center text-center overflow-hidden"
      >
        {/* Ambient cyan glow backdrop */}
        <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-52 h-52 bg-cyan-500/25 rounded-full blur-3xl pointer-events-none" />

        {/* 1. Header Banner: OUT #1 / #2 / #3 */}
        <div className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-red-600/90 border border-red-400 text-white font-black text-xs uppercase tracking-widest shadow-md mb-2">
          <AlertTriangle className="w-3.5 h-3.5 text-yellow-300" />
          <span>OUT #{currentAttempt}</span>
          <span className="w-1 h-1 rounded-full bg-white/70" />
          <span className="text-yellow-200">REVIVE {currentAttempt}/3</span>
        </div>

        {/* 2. Headline: REVIVE? */}
        <h2 className="text-3xl sm:text-4xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-white to-cyan-300 font-display uppercase drop-shadow">
          REVIVE?
        </h2>

        {/* 3. LARGE GLOWING 💎 DIAMOND ICON */}
        <div className="relative my-3 flex items-center justify-center">
          <div className="absolute -inset-4 rounded-full bg-cyan-400/25 animate-ping opacity-60 pointer-events-none" />
          <div className="relative w-24 h-24 rounded-3xl bg-gradient-to-tr from-cyan-600 via-sky-500 to-blue-400 flex items-center justify-center shadow-[0_0_35px_rgba(6,182,212,0.7)] border-2 border-cyan-200/60 transform rotate-3">
            <span className="text-5xl drop-shadow-[0_4px_10px_rgba(0,0,0,0.5)] transform -rotate-3 animate-pulse">
              💎
            </span>
          </div>
        </div>

        {/* 4. Subheading: USE 1 💎 TO CONTINUE */}
        <div className="text-cyan-200 font-extrabold text-sm tracking-wide uppercase drop-shadow mb-3">
          USE 1 💎 TO CONTINUE ({currentAttempt}/3)
        </div>

        {/* Current Run Score & Distance Card */}
        <div className="w-full mb-3 p-2.5 rounded-2xl bg-slate-900/90 border border-slate-800 flex items-center justify-around">
          <div className="flex flex-col items-center">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <Award className="w-3 h-3 text-amber-400" /> Score
            </span>
            <span className="text-base font-black text-amber-300">{score.toLocaleString()}</span>
          </div>
          <div className="w-px h-6 bg-slate-700/60" />
          <div className="flex flex-col items-center">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Distance</span>
            <span className="text-base font-black text-white">{distance}m</span>
          </div>
        </div>

        {/* 5. Diamond Balance Display & Requirements Check */}
        <div className="flex items-center justify-center gap-2 mb-3 text-xs font-bold">
          <span className="text-slate-400">Current Balance:</span>
          <span className="inline-flex items-center gap-1 px-3 py-0.5 rounded-full bg-cyan-950 border border-cyan-400/60 text-cyan-200 font-black text-sm">
            💎 {diamonds}
          </span>
        </div>

        {/* +3.5s Invincibility Shield Info */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/15 border border-cyan-400/30 text-cyan-300 text-xs font-semibold mb-4">
          <Shield className="w-3.5 h-3.5 text-cyan-400" /> +3.5s Shield Invincibility on Revive
        </div>

        {/* 6. Action Buttons */}
        <div className="w-full flex flex-col gap-2.5">
          {canAfford ? (
            /* IF DIAMONDS >= 1: Active REVIVE button */
            <button
              id="revive-confirm-button"
              onClick={handleReviveClick}
              className="w-full py-3.5 px-6 rounded-2xl font-black text-base uppercase tracking-wider text-slate-950 bg-gradient-to-r from-cyan-400 via-sky-300 to-cyan-400 shadow-[0_0_25px_rgba(6,182,212,0.6)] hover:shadow-[0_0_35px_rgba(6,182,212,0.9)] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer font-display"
            >
              <span>💎 1</span>
              <span className="w-1.5 h-1.5 rounded-full bg-slate-950" />
              <span>REVIVE ({currentAttempt}/3)</span>
            </button>
          ) : (
            /* IF DIAMONDS == 0: Disabled with NOT ENOUGH DIAMONDS message */
            <div className="w-full flex flex-col gap-2">
              <div className="py-2 px-3 rounded-xl bg-red-500/15 border border-red-500/30 text-red-300 text-xs font-bold flex items-center justify-center gap-1.5">
                <span>💎 0 — NOT ENOUGH DIAMONDS</span>
              </div>
              <button
                id="revive-confirm-button-disabled"
                disabled
                className="w-full py-3 px-6 rounded-2xl font-black text-sm uppercase tracking-wider text-slate-500 bg-slate-800/60 cursor-not-allowed border border-slate-700/50"
              >
                REVIVE (UNAVAILABLE)
              </button>
            </div>
          )}

          {/* NO THANKS button with countdown */}
          <button
            id="revive-decline-button"
            onClick={handleDeclineClick}
            className="w-full py-2.5 px-4 rounded-xl text-xs font-bold uppercase tracking-wider text-slate-400 hover:text-white bg-slate-800/40 hover:bg-slate-800/80 transition-colors border border-slate-700/40 cursor-pointer"
          >
            NO THANKS ({countdown}s)
          </button>
        </div>
      </motion.div>
    </div>
  );
};
