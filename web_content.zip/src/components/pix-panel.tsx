import { useEffect, useState } from "react";
import { Check, Copy } from "lucide-react";
import { brl } from "@/lib/format";
import { buildPixPayload, isPlausiblePixKey } from "@/lib/pix";
import { Button } from "@/components/button";

export function PixPanel({
  pixKey,
  receiverName,
  city,
  amountCents,
  txid,
}: {
  pixKey: string;
  receiverName: string;
  city: string;
  amountCents: number;
  txid: string;
}) {
  const ready = isPlausiblePixKey(pixKey);
  const payload = ready
    ? buildPixPayload({
        key: pixKey,
        name: receiverName || "Precisa",
        city: city || "Brasil",
        amountCents,
        txid,
      })
    : "";
  const [url, setUrl] = useState("");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!payload) {
      setUrl("");
      return;
    }
    let live = true;
    void import("qrcode").then((QR) =>
      QR.toDataURL(payload, {
        margin: 1,
        width: 320,
        color: { dark: "#1b5e45", light: "#fffdf8" },
      }).then((next) => {
        if (live) setUrl(next);
      }),
    );
    return () => {
      live = false;
    };
  }, [payload]);

  async function copy() {
    if (!payload) return;
    try {
      await navigator.clipboard.writeText(payload);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  }

  if (!ready) {
    return (
      <div className="rounded-lg border border-line bg-surface-2 p-5">
        <p className="font-semibold">PIX ainda não está nesta vitrine</p>
        <p className="mt-2 text-sm text-muted">
          Quem faz o serviço precisa colocar a chave na caixa e compartilhar o link de novo. Não pague em outra chave
          mandada por mensagem solta.
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-lg border border-line bg-surface p-5">
      <p className="text-sm text-muted">Pague exatamente</p>
      <p className="font-display text-4xl tabular-nums text-accent">{brl(amountCents)}</p>
      <p className="mt-2 text-sm">
        No banco, o recebedor tem que aparecer como{" "}
        <span className="font-semibold">{receiverName || "Precisa"}</span>
        {city ? ` · ${city}` : ""}. Se o nome for outro, não pague.
      </p>
      <div className="mt-4 flex flex-col items-start gap-4 sm:flex-row sm:items-center">
        {url ? (
          <img src={url} alt="QR Code do PIX deste pedido" className="size-52 rounded-md border border-line" />
        ) : (
          <div className="size-52 rounded-md bg-surface-2" />
        )}
        <div className="min-w-0 flex-1">
          <p className="text-xs font-semibold tracking-wide text-muted uppercase">Copia e cola</p>
          <p className="mt-2 break-all rounded-md bg-surface-2 p-3 text-xs leading-relaxed">{payload}</p>
          <Button className="mt-3" variant="surface" onClick={() => void copy()}>
            {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
            {copied ? "Copiado" : "Copiar PIX"}
          </Button>
        </div>
      </div>
    </div>
  );
}
