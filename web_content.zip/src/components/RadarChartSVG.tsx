import React from 'react';
import { CharacterAttribute } from '../types/ascend';
import { calculateAttributeMetrics } from '../utils/progressionEngine';

interface RadarChartSVGProps {
  attributes: CharacterAttribute[];
  size?: number;
  accentColor?: string;
}

export const RadarChartSVG: React.FC<RadarChartSVGProps> = ({
  attributes,
  size = 290,
  accentColor = 'var(--accent-primary)',
}) => {
  const visibleAttrs = attributes.filter((a) => a.visible);
  const count = visibleAttrs.length;
  if (count < 3) {
    return (
      <div className="flex h-48 items-center justify-center text-xs text-[var(--text-secondary)]">
        Enable at least 3 visible attributes to display the radar matrix.
      </div>
    );
  }

  const center = size / 2;
  const radius = size * 0.34;
  const scores = visibleAttrs.map((a) => calculateAttributeMetrics(a).totalScore);
  const maxScore = Math.max(25, ...scores);

  const getCoordinates = (index: number, ratio: number) => {
    const angle = (Math.PI * 2 * index) / count - Math.PI / 2;
    const x = center + radius * ratio * Math.cos(angle);
    const y = center + radius * ratio * Math.sin(angle);
    return { x, y };
  };

  const rings = [0.25, 0.5, 0.75, 1];

  const dataPoints = visibleAttrs.map((attr, idx) => {
    const score = calculateAttributeMetrics(attr).totalScore;
    const ratio = Math.min(1, Math.max(0.12, score / maxScore));
    return getCoordinates(idx, ratio);
  });

  const polygonPoints = dataPoints.map((p) => `${p.x},${p.y}`).join(' ');

  return (
    <div className="relative flex items-center justify-center">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="overflow-visible">
        {/* Concentric rings */}
        {rings.map((r) => {
          const pts = visibleAttrs
            .map((_, idx) => {
              const { x, y } = getCoordinates(idx, r);
              return `${x},${y}`;
            })
            .join(' ');
          return (
            <polygon
              key={r}
              points={pts}
              fill="none"
              stroke="var(--border-subtle)"
              strokeWidth={1}
              strokeDasharray={r < 1 ? '2 2' : undefined}
            />
          );
        })}

        {/* Axis spokes */}
        {visibleAttrs.map((attr, idx) => {
          const end = getCoordinates(idx, 1);
          return (
            <line
              key={attr.id}
              x1={center}
              y1={center}
              x2={end.x}
              y2={end.y}
              stroke="var(--border-subtle)"
              strokeWidth={1}
            />
          );
        })}

        {/* Data polygon */}
        <polygon
          points={polygonPoints}
          fill={accentColor}
          fillOpacity={0.18}
          stroke={accentColor}
          strokeWidth={2}
        />

        {/* Data vertices and labels */}
        {visibleAttrs.map((attr, idx) => {
          const pt = dataPoints[idx];
          const labelPt = getCoordinates(idx, 1.23);
          const score = calculateAttributeMetrics(attr).totalScore;
          return (
            <g key={attr.id}>
              <circle
                cx={pt.x}
                cy={pt.y}
                r={3.5}
                fill={attr.color || accentColor}
                stroke="var(--bg-surface)"
                strokeWidth={1.5}
              />
              <text
                x={labelPt.x}
                y={labelPt.y}
                textAnchor="middle"
                dominantBaseline="middle"
                className="font-mono-metric fill-[var(--text-primary)] text-[10px] font-semibold"
              >
                {attr.code} · {score}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
};
