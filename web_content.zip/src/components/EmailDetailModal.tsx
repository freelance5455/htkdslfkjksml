import React, { useState } from 'react';
import {
  X,
  Trash2,
  AlertTriangle,
  Send,
  Eye,
  EyeOff,
  Paperclip,
  Download,
  ShieldAlert,
  ShieldCheck,
  FileText,
  Clock,
  User,
  ExternalLink,
} from 'lucide-react';
import { EmailMessage } from '../types/index.ts';
import { OtpChip } from './OtpChip.tsx';

interface EmailDetailModalProps {
  message: EmailMessage;
  onClose: () => void;
  onDelete: (id: string) => void;
  onReportSpam: (id: string) => void;
  onForward: (id: string) => void;
}

export const EmailDetailModal: React.FC<EmailDetailModalProps> = ({
  message,
  onClose,
  onDelete,
  onReportSpam,
  onForward,
}) => {
  const [viewMode, setViewMode] = useState<'html' | 'text'>('html');
  const [allowRemoteImages, setAllowRemoteImages] = useState(false);
  const [forwardNotice, setForwardNotice] = useState(false);

  const handleForwardClick = () => {
    onForward(message.id);
    setForwardNotice(true);
    setTimeout(() => setForwardNotice(false), 3000);
  };

  // Safe HTML render with image blocker toggle
  const getRenderedHtml = () => {
    if (!message.htmlBody) return '';
    if (allowRemoteImages) {
      return message.htmlBody.replace(/data-blocked-src="([^"]+)"/g, 'src="$1"');
    }
    return message.htmlBody;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-slate-800">
        {/* Top Header Bar */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between gap-3 bg-blue-50/50">
          <div className="flex items-center gap-2 overflow-hidden">
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="truncate">
              <h2 className="text-base font-bold text-slate-900 truncate">{message.subject}</h2>
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <span className="truncate font-medium">{message.fromName || message.fromAddress}</span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-blue-600" />
                  {new Date(message.receivedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
          </div>

          {/* Action Bar */}
          <div className="flex items-center gap-1 shrink-0">
            <button
              onClick={handleForwardClick}
              className="p-2 rounded-lg text-slate-500 hover:text-blue-600 hover:bg-blue-50 transition-colors"
              title="Forward to real email"
            >
              <Send className="w-4 h-4" />
            </button>
            <button
              onClick={() => onReportSpam(message.id)}
              className="p-2 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 transition-colors"
              title="Report Spam & Block Sender"
            >
              <AlertTriangle className="w-4 h-4" />
            </button>
            <button
              onClick={() => onDelete(message.id)}
              className="p-2 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
              title="Delete Message"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Forward Notice Alert */}
        {forwardNotice && (
          <div className="bg-blue-50 border-b border-blue-200 px-4 py-2 text-xs text-blue-800 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 shrink-0 text-blue-600" />
            <span>Encrypted copy forwarded to your destination inbox!</span>
          </div>
        )}

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* SENDER INFO CARD */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex items-center justify-between text-xs">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-100 border border-blue-200 flex items-center justify-center text-blue-700 font-bold uppercase">
                {message.fromName ? message.fromName.charAt(0) : <User className="w-4 h-4" />}
              </div>
              <div>
                <div className="font-bold text-slate-900">{message.fromName || 'Unknown Sender'}</div>
                <div className="text-slate-500 font-mono text-[11px]">{message.fromAddress}</div>
              </div>
            </div>
            <div className="text-right text-slate-500 font-mono text-[11px]">
              <div>To: <span className="text-blue-600 font-semibold">{message.toAddress}</span></div>
              <div className="text-slate-400">{(message.sizeBytes / 1024).toFixed(1)} KB</div>
            </div>
          </div>

          {/* AUTO-DETECTED OTP CODE HERO CHIP */}
          {message.extractedOtp && (
            <OtpChip code={message.extractedOtp} label="Auto-Detected OTP Verification Code" />
          )}

          {/* VERIFICATION LINK CHIP */}
          {message.verificationUrl && (
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 flex items-center justify-between gap-3 text-xs">
              <div className="truncate">
                <div className="text-[11px] font-bold text-blue-800 uppercase tracking-wider mb-0.5">
                  Verification Link Detected
                </div>
                <div className="text-slate-600 font-mono truncate text-[11px]">{message.verificationUrl}</div>
              </div>
              <a
                href={message.verificationUrl}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shrink-0 transition-colors shadow-sm"
              >
                <span>Open Link</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          )}

          {/* PRIVACY BANNER */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2 text-slate-700">
              <ShieldAlert className="w-4 h-4 text-blue-600 shrink-0" />
              <span>
                {message.hasTrackers
                  ? 'Tracking pixels and web beacons blocked for your privacy.'
                  : 'Zero external tracking pixels allowed.'}
              </span>
            </div>
            <button
              onClick={() => setAllowRemoteImages(!allowRemoteImages)}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white border border-slate-200 hover:border-blue-300 text-slate-700 hover:text-blue-600 text-xs font-medium transition-colors"
            >
              {allowRemoteImages ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              <span>{allowRemoteImages ? 'Block Remote Images' : 'Load Remote Images'}</span>
            </button>
          </div>

          {/* VIEW MODE TOGGLE */}
          <div className="flex items-center justify-end gap-2 text-xs">
            <span className="text-slate-500 font-medium">Format:</span>
            <div className="inline-flex rounded-lg bg-slate-100 p-0.5 border border-slate-200">
              <button
                onClick={() => setViewMode('html')}
                className={`px-3 py-1 rounded-md text-xs transition-colors ${
                  viewMode === 'html'
                    ? 'bg-white text-blue-700 font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                HTML Sandboxed
              </button>
              <button
                onClick={() => setViewMode('text')}
                className={`px-3 py-1 rounded-md text-xs transition-colors ${
                  viewMode === 'text'
                    ? 'bg-white text-blue-700 font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Plain Text
              </button>
            </div>
          </div>

          {/* EMAIL BODY CONTENT */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 min-h-[160px] text-slate-800 text-sm overflow-x-auto shadow-inner">
            {viewMode === 'html' ? (
              <div
                className="prose max-w-none text-slate-800 leading-relaxed font-sans"
                dangerouslySetInnerHTML={{ __html: getRenderedHtml() }}
              />
            ) : (
              <pre className="font-mono text-xs text-slate-700 whitespace-pre-wrap leading-relaxed">
                {message.plainText || message.textPreview}
              </pre>
            )}
          </div>

          {/* ATTACHMENTS */}
          {message.attachments && message.attachments.length > 0 && (
            <div className="border-t border-slate-100 pt-3">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-600 mb-2 uppercase tracking-wider">
                <Paperclip className="w-3.5 h-3.5 text-blue-600" />
                <span>Attachments ({message.attachments.length})</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {message.attachments.map((att) => (
                  <div
                    key={att.id}
                    className="bg-slate-50 border border-slate-200 rounded-xl p-2.5 flex items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-2 overflow-hidden">
                      <FileText className="w-4 h-4 text-blue-600 shrink-0" />
                      <div className="truncate text-xs">
                        <div className="font-semibold text-slate-800 truncate">{att.filename}</div>
                        <div className="text-[10px] text-slate-500 font-mono">
                          {(att.sizeBytes / 1024).toFixed(1)} KB
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        const blob = new Blob([`Simulated attachment download for ${att.filename}`], { type: att.contentType });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = att.filename;
                        a.click();
                        URL.revokeObjectURL(url);
                      }}
                      className="p-1.5 rounded-lg bg-white hover:bg-blue-50 text-slate-600 hover:text-blue-600 border border-slate-200 transition-colors"
                      title="Download file"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
