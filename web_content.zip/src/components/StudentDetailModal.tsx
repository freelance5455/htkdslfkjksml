import { Student, Lesson, PaymentRecord, NoteEntry } from '../types';
import {
  X,
  Phone,
  Mail,
  DollarSign,
  Calendar,
  FileText
} from 'lucide-react';

interface StudentDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: Student | null;
  lessons: Lesson[];
  payments: PaymentRecord[];
  notes: NoteEntry[];
  onOpenPaymentModal: (student: Student) => void;
  onScheduleLesson: (student: Student) => void;
  onAddNote: (student: Student) => void;
}

export const StudentDetailModal = ({
  isOpen,
  onClose,
  student,
  lessons,
  payments,
  notes,
  onOpenPaymentModal,
  onScheduleLesson,
  onAddNote,
}: StudentDetailModalProps) => {
  if (!isOpen || !student) return null;

  const studentLessons = lessons.filter((l) => l.studentId === student.id);
  const studentPayments = payments.filter((p) => p.studentId === student.id);
  const studentNotes = notes.filter((n) => n.studentId === student.id);

  const cyclePayment = student.hourlyRate * student.paymentFrequency;
  const currencySymbol = student.currency === 'USD' ? '$' : '₺';
  const isPaymentDue = student.lessonsInCurrentCycle >= student.paymentFrequency;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="bg-[#121214] text-stone-100 rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-zinc-800 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-zinc-800 shrink-0">
          <div className="flex items-center gap-3">
            <div
              className={`w-12 h-12 rounded-2xl flex items-center justify-center font-bold font-serif text-lg ${
                student.subject === 'english'
                  ? 'bg-sky-950 text-sky-300 border border-sky-800/50'
                  : 'bg-rose-950 text-rose-300 border border-rose-800/50'
              }`}
            >
              {student.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-xl font-serif text-white">
                  {student.name}
                </h3>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    student.subject === 'english'
                      ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  }`}
                >
                  {student.subject === 'english' ? '🇬🇧 İngilizce' : '🇹🇷 Türkçe'}
                </span>
              </div>
              <div className="flex items-center gap-3 text-xs text-stone-400 mt-1">
                {student.phone && (
                  <a
                    href={`tel:${student.phone}`}
                    className="hover:text-rose-400 flex items-center gap-1 transition-colors"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>{student.phone}</span>
                  </a>
                )}
                {student.email && (
                  <a
                    href={`mailto:${student.email}`}
                    className="hover:text-rose-400 flex items-center gap-1 transition-colors"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    <span>{student.email}</span>
                  </a>
                )}
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-white bg-zinc-900 rounded-xl transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="py-4 space-y-4 overflow-y-auto pr-1 flex-1">
          {/* Cycle & Payment Summary Card */}
          <div
            className={`p-4 rounded-2xl border transition-all ${
              isPaymentDue
                ? 'bg-amber-950/40 border-amber-500/60'
                : 'bg-zinc-900 border-zinc-800'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-stone-300 uppercase tracking-wider">
                Mevcut Ödeme Döngüsü
              </span>
              <span className="text-xs font-mono font-bold text-white">
                {student.lessonsInCurrentCycle} / {student.paymentFrequency} Ders
              </span>
            </div>

            {/* Visual Steps */}
            <div className="flex gap-1.5 h-2.5 mb-3">
              {Array.from({ length: student.paymentFrequency }).map((_, idx) => (
                <div
                  key={idx}
                  className={`flex-1 rounded-sm ${
                    idx < student.lessonsInCurrentCycle
                      ? 'bg-emerald-500'
                      : idx === student.paymentFrequency - 1
                      ? 'bg-amber-950 border border-amber-500/50'
                      : 'bg-zinc-800'
                  }`}
                />
              ))}
            </div>

            <div className="flex items-center justify-between text-xs text-stone-300 pt-2 border-t border-zinc-800">
              <div>
                <span>Ders Ücreti: </span>
                <span className="font-bold text-white">
                  {student.hourlyRate.toLocaleString('tr-TR')} {currencySymbol}
                </span>
                <span className="mx-1">•</span>
                <span>Paket Tutarı: </span>
                <span className="font-bold text-white">
                  {cyclePayment.toLocaleString('tr-TR')} {currencySymbol}
                </span>
              </div>

              <button
                onClick={() => {
                  onClose();
                  onOpenPaymentModal(student);
                }}
                className="px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-500 hover:bg-amber-400 text-stone-950 transition-all shadow-md shadow-amber-500/30 cursor-pointer flex items-center gap-1"
              >
                <DollarSign className="w-3.5 h-3.5" />
                <span>Ödeme Alındı</span>
              </button>
            </div>
          </div>

          {/* Action Row */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onScheduleLesson(student);
              }}
              className="flex-1 py-2 px-3 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer border border-zinc-700"
            >
              <Calendar className="w-3.5 h-3.5 text-rose-400" />
              <span>Yeni Ders Planla</span>
            </button>

            <button
              onClick={() => {
                onClose();
                onAddNote(student);
              }}
              className="flex-1 py-2 px-3 bg-zinc-800 hover:bg-zinc-700 text-stone-200 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer border border-zinc-700"
            >
              <FileText className="w-3.5 h-3.5 text-amber-400" />
              <span>Not Ekle</span>
            </button>
          </div>

          {/* Ders Geçmişi & Planlanan Dersler */}
          <div>
            <h4 className="text-xs font-bold text-stone-400 uppercase tracking-wider mb-2">
              Dersler ({studentLessons.length})
            </h4>
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {studentLessons.length === 0 ? (
                <p className="text-xs text-stone-500 italic">Kayıtlı ders bulunmuyor.</p>
              ) : (
                studentLessons.map((l) => (
                  <div
                    key={l.id}
                    className="flex items-center justify-between p-2.5 bg-zinc-900 rounded-xl text-xs border border-zinc-800"
                  >
                    <div>
                      <span className="font-semibold text-white">{l.date} - {l.time}</span>
                      {l.topicNotes && (
                        <p className="text-[11px] text-stone-400 mt-0.5">{l.topicNotes}</p>
                      )}
                    </div>
                    <div className="flex items-center gap-1.5">
                      {l.isPaymentLesson && (
                        <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-950 text-amber-300 border border-amber-500/40 rounded-full">
                          Ödeme Dersi
                        </span>
                      )}
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          l.status === 'completed'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                            : 'bg-zinc-800 text-stone-400'
                        }`}
                      >
                        {l.status === 'completed' ? 'Tamamlandı' : 'Planlandı'}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Ödeme Geçmişi */}
          <div>
            <h4 className="text-xs font-bold text-stone-400 uppercase tracking-wider mb-2">
              Geçmiş Tahsilatlar ({studentPayments.length})
            </h4>
            <div className="space-y-1.5 max-h-36 overflow-y-auto">
              {studentPayments.length === 0 ? (
                <p className="text-xs text-stone-500 italic">Henüz ödeme kaydı yok.</p>
              ) : (
                studentPayments.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center justify-between p-2.5 bg-emerald-950/30 rounded-xl text-xs border border-emerald-800/40"
                  >
                    <div>
                      <span className="font-semibold text-emerald-300">
                        {p.cycleDescription}
                      </span>
                      <span className="text-[10px] text-stone-500 ml-2">
                        {p.date.slice(0, 10)}
                      </span>
                    </div>
                    <span className="font-bold font-mono text-emerald-400">
                      +{p.amount.toLocaleString('tr-TR')} {p.currency === 'USD' ? '$' : '₺'}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
