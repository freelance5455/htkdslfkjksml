import { type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Home, LayoutDashboard, Wallet } from "lucide-react";
import { VaultMark, Wordmark } from "@/components/logo";
import { useVaultReady } from "@/components/vault-provider";
import { cn } from "@/lib/utils";
import { formatAud } from "@/lib/money";
import { useVault } from "@/lib/vault-store";

const NAV = [
  { to: "/", label: "Home", icon: Home },
  { to: "/dashboard", label: "Vault", icon: LayoutDashboard },
  { to: "/wallet", label: "Wallet", icon: Wallet },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const ready = useVaultReady();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const available = useVault((s) => s.available);

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <div className="mx-auto flex min-h-dvh w-full max-w-lg flex-col px-4 pt-safe">
        <header className="flex items-center justify-between gap-3 py-4">
          <Link to="/" className="flex items-center gap-2.5">
            <VaultMark className="size-9" />
            <Wordmark />
          </Link>
          <div className="rounded-full bg-card px-3 py-1.5 shadow-border">
            <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
              Available
            </p>
            <p className="font-medium tabular-nums text-success leading-tight">
              {ready ? formatAud(available) : "—"}
            </p>
          </div>
        </header>

        <main className="flex-1 pb-nav">
          {ready ? (
            children
          ) : (
            <div className="space-y-4 pt-2" aria-busy="true" aria-label="Loading">
              <div className="h-40 rounded-3xl bg-card shadow-border" />
              <div className="h-52 rounded-3xl bg-card shadow-border" />
            </div>
          )}
        </main>
      </div>

      <nav
        className="fixed inset-x-0 bottom-0 z-40 mx-auto w-full max-w-lg px-4 pb-nav-float"
        aria-label="Primary"
      >
        <div className="grid grid-cols-3 rounded-full bg-card p-1.5 shadow-border">
          {NAV.map((item) => {
            const active = pathname === item.to;
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex h-12 items-center justify-center gap-2 rounded-full text-sm font-medium transition-colors duration-150",
                  active
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground",
                )}
                aria-current={active ? "page" : undefined}
              >
                <Icon className="size-4" strokeWidth={1.8} />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
