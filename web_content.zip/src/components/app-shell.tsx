import { useEffect } from "react";
import { Activity, History, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { HistoryView } from "@/components/history-view";
import { LiveView } from "@/components/live-view";
import { CONFIG, hydratePrefs, useAppStore } from "@/store/app-store";
import { cn } from "@/lib/cn";

function LogoMark() {
  return (
    <svg viewBox="0 0 32 32" className="size-8" aria-hidden>
      <polygon points="16,2 28,10 28,22 16,30 4,22 4,10" fill="#16181f" stroke="#c8ccd4" strokeWidth="1.4" />
      <polygon points="16,7 23,11.5 23,20.5 16,25 9,20.5 9,11.5" fill="#c8ccd4" opacity="0.16" />
      <circle cx="16" cy="16" r="3.2" fill="#e24b4b" />
    </svg>
  );
}

export function AppShell() {
  const tab = useAppStore((s) => s.tab);
  const setTab = useAppStore((s) => s.setTab);
  const refresh = useAppStore((s) => s.refresh);
  const loadDemo = useAppStore((s) => s.loadDemo);
  const fetching = useAppStore((s) => s.fetching);
  const status = useAppStore((s) => s.status);
  const lastUpdate = useAppStore((s) => s.lastUpdate);
  const analystMode = useAppStore((s) => s.analystMode);
  const setAnalystMode = useAppStore((s) => s.setAnalystMode);
  const error = useAppStore((s) => s.error);
  const items = useAppStore((s) => s.items);

  useEffect(() => {
    hydratePrefs();
    void refresh();
    const id = window.setInterval(() => void refresh(), CONFIG.UPDATE_INTERVAL);
    const onVis = () => {
      if (!document.hidden) void refresh();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [refresh]);

  const statusLabel =
    status === "loading"
      ? "A carregar"
      : status === "demo"
        ? "Modo exemplo"
        : status === "error"
          ? "Sem ligação"
          : fetching
            ? "A atualizar"
            : `${items.length} ao vivo`;

  return (
    <div className="min-h-dvh bg-bg pb-[calc(4.5rem+env(safe-area-inset-bottom))]">
      <header className="sticky top-0 z-20 border-b border-border bg-bg/92 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <LogoMark />
          <div className="min-w-0 flex-1">
            <div className="text-[15px] font-semibold tracking-tight">Bola de Cristal</div>
            <div className="text-[11px] text-muted">
              {statusLabel}
              {lastUpdate ? ` · ${new Date(lastUpdate).toLocaleTimeString()}` : ""}
            </div>
          </div>
          <Button size="icon" variant="ghost" onClick={() => void refresh()} aria-label="Atualizar">
            <RefreshCw className={cn("size-4", fetching && "animate-spin")} />
          </Button>
        </div>
      </header>

      {error && status !== "ok" ? (
        <div className="mx-auto max-w-6xl px-4 pt-3">
          <div className="rounded-xl bg-live/10 px-3 py-2 text-xs text-live shadow-[0_0_0_1px_rgb(226_75_75/0.22)]">
            {error}. Podes usar o modo exemplo.
          </div>
        </div>
      ) : null}

      <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-3">
        <Button size="sm" variant="ghost" onClick={loadDemo}>
          Carregar exemplo
        </Button>
        <label className="ml-auto flex items-center gap-2 text-xs font-medium text-muted">
          Filtro analista
          <Switch checked={analystMode} onCheckedChange={setAnalystMode} />
        </label>
      </div>

      <main className="px-4 pb-6">
        {tab === "live" ? <LiveView /> : <HistoryView />}
      </main>

      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-bg/95 backdrop-blur-md">
        <div className="mx-auto grid max-w-md grid-cols-2 px-4 pb-[env(safe-area-inset-bottom)] pt-1">
          <button
            type="button"
            onClick={() => setTab("live")}
            className={cn(
              "flex h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-semibold",
              tab === "live" ? "text-accent" : "text-subtle",
            )}
          >
            <Activity className="size-5" />
            Ao vivo
          </button>
          <button
            type="button"
            onClick={() => setTab("history")}
            className={cn(
              "flex h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-semibold",
              tab === "history" ? "text-accent" : "text-subtle",
            )}
          >
            <History className="size-5" />
            Histórico
          </button>
        </div>
      </nav>
    </div>
  );
}
