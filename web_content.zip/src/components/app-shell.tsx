import { Link, useNavigate } from "@tanstack/react-router";
import { Inbox, Plus, Search } from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { formatBytes } from "@/lib/utils";
import { useInboxCount, useVault } from "@/store/vault";

export function AppShell({
  children,
  search,
  onSearch,
  title = "STARDEX",
}: {
  children: React.ReactNode;
  search?: string;
  onSearch?: (q: string) => void;
  title?: string;
}) {
  const navigate = useNavigate();
  const inbox = useInboxCount();
  const quota = useVault((s) => s.quota);
  const importFiles = useVault((s) => s.importFiles);
  const addStar = useVault((s) => s.addStar);
  const fileRef = useRef<HTMLInputElement>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [newName, setNewName] = useState("");
  const [busy, setBusy] = useState(false);

  const usedPct =
    quota && quota.quota > 0 ? Math.min(100, Math.round((quota.usage / quota.quota) * 100)) : 0;

  async function onPick(files: FileList | null, slug?: string) {
    if (!files || files.length === 0) return;
    setBusy(true);
    try {
      const result = await importFiles([...files], slug);
      if (result.filed || result.inbox) {
        toast.success(
          `${result.filed} filed${result.inbox ? ` · ${result.inbox} unmatched` : ""}`,
        );
        if (result.inbox) navigate({ to: "/inbox" });
      }
      if (result.failed) toast.error(`${result.failed} could not be saved — storage may be full`);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <header className="sticky top-0 z-30 border-b border-border bg-background/92 backdrop-blur-sm">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <Link to="/" className="shrink-0 font-display text-2xl font-medium tracking-tight">
            {title}
          </Link>
          {onSearch ? (
            <label className="relative hidden min-w-0 flex-1 sm:block">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" />
              <Input
                value={search}
                onChange={(e) => onSearch(e.target.value)}
                placeholder="Search performers"
                className="h-11 border-transparent bg-secondary pl-10"
                aria-label="Search performers"
              />
            </label>
          ) : (
            <div className="flex-1" />
          )}
          <Link
            to="/inbox"
            className="relative inline-flex size-11 items-center justify-center rounded-md text-foreground hover:bg-secondary"
            aria-label="Unsorted inbox"
          >
            <Inbox className="size-4" />
            {inbox > 0 ? (
              <span className="absolute right-1.5 top-1.5 min-w-4 rounded-full bg-primary px-1 text-center text-xs font-medium tabular-nums text-primary-foreground">
                {inbox}
              </span>
            ) : null}
          </Link>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="icon" aria-label="Add">
                <Plus className="size-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onSelect={() => fileRef.current?.click()} disabled={busy}>
                Import files
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => setAddOpen(true)}>Add performer</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link to="/inbox">Unsorted inbox</Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        {onSearch ? (
          <div className="px-4 pb-3 sm:hidden">
            <label className="relative block">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-subtle" />
              <Input
                value={search}
                onChange={(e) => onSearch(e.target.value)}
                placeholder="Search performers"
                className="h-11 border-transparent bg-secondary pl-10"
                aria-label="Search performers"
              />
            </label>
          </div>
        ) : null}
        {quota ? (
          <div className="mx-auto hidden max-w-6xl px-4 pb-2 sm:block">
            <div className="flex items-center gap-3">
              <Progress value={usedPct} className="flex-1" />
              <p className="shrink-0 text-xs tabular-nums text-muted-foreground">
                {formatBytes(quota.usage)} of {formatBytes(quota.quota)}
              </p>
            </div>
          </div>
        ) : null}
      </header>
      <input
        ref={fileRef}
        type="file"
        className="sr-only"
        accept="video/*,image/*,.gif,.webm,.mp4,.mov,.mkv,.m4v"
        multiple
        onChange={(e) => {
          void onPick(e.target.files);
          e.currentTarget.value = "";
        }}
      />
      {children}

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add performer</DialogTitle>
            <DialogDescription>
              Create a profile that is not in the built-in roster.
            </DialogDescription>
          </DialogHeader>
          <form
            className="space-y-4"
            onSubmit={async (e) => {
              e.preventDefault();
              if (!newName.trim()) return;
              const slug = await addStar(newName.trim());
              setNewName("");
              setAddOpen(false);
              navigate({ to: "/star/$slug", params: { slug } });
            }}
          >
            <Input
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="Stage name"
              autoFocus
            />
            <Button type="submit" className="w-full" disabled={!newName.trim()}>
              Create profile
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
