import { useEffect, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import {
  ClipboardList,
  Dumbbell,
  Home,
  ListChecks,
  PersonStanding,
  Settings,
} from "lucide-react";
import { Toaster } from "sonner";
import { RestTimer } from "@/components/rest-timer";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Início", icon: Home },
  { to: "/treinos", label: "Treinos", icon: Dumbbell },
  { to: "/postura", label: "Postura", icon: PersonStanding },
  { to: "/habitos", label: "Hábitos", icon: ListChecks },
  { to: "/sessoes", label: "Sessões", icon: ClipboardList },
  { to: "/configuracoes", label: "Ajustes", icon: Settings },
] as const;

function isActive(pathname: string, to: string) {
  if (to === "/") {
    return (
      pathname === "/" ||
      pathname.startsWith("/dia") ||
      pathname.startsWith("/calendario") ||
      pathname.startsWith("/estatisticas")
    );
  }
  return pathname === to || pathname.startsWith(`${to}/`);
}

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const setHydrated = useAppStore((s) => s.setHydrated);
  const name = useAppStore((s) => s.settings.name);

  useEffect(() => {
    const result = useAppStore.persist.rehydrate();
    void Promise.resolve(result).finally(() => setHydrated(true));
  }, [setHydrated]);

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-border bg-card/80 px-4 py-6 backdrop-blur-md md:flex">
        <div className="px-2">
          <p className="text-[10px] font-medium tracking-[0.22em] text-primary uppercase">
            21.09 — 30.12
          </p>
          <p className="font-display mt-1 text-xl font-semibold tracking-tight">
            PROJETO 101
          </p>
          {name ? (
            <p className="mt-1 text-sm text-muted-foreground">{name}</p>
          ) : null}
        </div>
        <nav className="mt-8 flex flex-1 flex-col gap-1">
          {NAV.map((item) => {
            const active = isActive(pathname, item.to);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium transition-colors",
                  active
                    ? "bg-primary/15 text-primary"
                    : "text-muted-foreground hover:bg-accent hover:text-foreground",
                )}
              >
                <Icon className="size-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </aside>

      <div className="md:pl-64">
        <main className="mx-auto min-h-dvh w-full max-w-3xl px-4 pt-6 pb-28 md:pb-10">
          {children}
        </main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-card/90 backdrop-blur-md md:hidden">
        <ul
          className="grid grid-cols-6 px-1 pt-1"
          style={{ paddingBottom: "max(0.4rem, env(safe-area-inset-bottom))" }}
        >
          {NAV.map((item) => {
            const active = isActive(pathname, item.to);
            const Icon = item.icon;
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className={cn(
                    "flex min-h-12 flex-col items-center justify-center gap-0.5 rounded-lg text-[10px] font-medium",
                    active ? "text-primary" : "text-muted-foreground",
                  )}
                >
                  <Icon className="size-5" />
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      <RestTimer />
      <Toaster
        theme="dark"
        position="top-center"
        toastOptions={{
          classNames: {
            toast: "bg-popover text-foreground border-border",
          },
        }}
      />
    </div>
  );
}
