import { cn } from "@/lib/utils";
import { Rss, Search, Users } from "lucide-react";
import type { ReactNode } from "react";
import type { FeedTab } from "@/hooks/use-community-feed";

const TABS: { id: FeedTab; label: string; icon: typeof Rss }[] = [
  { id: "community", label: "Community", icon: Rss },
  { id: "following", label: "Following", icon: Users },
  { id: "search", label: "Search channels", icon: Search },
];

export function DesktopNav({
  tab,
  onTab,
}: {
  tab: FeedTab;
  onTab: (tab: FeedTab) => void;
}) {
  return (
    <aside className="hidden w-56 shrink-0 flex-col gap-1 border-r border-border px-3 py-5 lg:flex">
      {TABS.map((item) => {
        const Icon = item.icon;
        const active = tab === item.id;
        return (
          <button
            key={item.id}
            type="button"
            onClick={() => onTab(item.id)}
            className={cn(
              "flex h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium transition-[background-color,color] duration-[var(--motion-quick)]",
              active
                ? "bg-secondary text-foreground"
                : "text-muted-foreground hover:bg-secondary/70 hover:text-foreground",
            )}
          >
            <Icon className="size-4" />
            {item.label}
          </button>
        );
      })}
    </aside>
  );
}

export function BottomNav({
  tab,
  onTab,
}: {
  tab: FeedTab;
  onTab: (tab: FeedTab) => void;
}) {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm lg:hidden">
      <ul className="grid grid-cols-3">
        {TABS.map((item) => {
          const Icon = item.icon;
          const active = tab === item.id;
          return (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => onTab(item.id)}
                className={cn(
                  "flex h-14 w-full flex-col items-center justify-center gap-1 px-1 text-[10px] font-medium leading-tight",
                  active ? "text-foreground" : "text-muted-foreground",
                )}
              >
                <Icon className="size-5" />
                {item.label}
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

export function PageFrame({ children }: { children: ReactNode }) {
  return (
    <div className="mx-auto flex h-dvh min-h-0 w-full max-w-6xl overflow-hidden">
      {children}
    </div>
  );
}
