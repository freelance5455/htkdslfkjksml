import { Link, useRouterState } from "@tanstack/react-router";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { UserButton } from "@/lib/auth/gates";
import { LogoMark } from "@/components/logo";
import { cn } from "@/lib/utils";
import {
  BarChart3,
  BookOpen,
  Building2,
  CalendarCheck,
  Database,
  HeartPulse,
  LayoutDashboard,
  MoreHorizontal,
  Package,
  Receipt,
  Search,
  Settings,
  Users,
  Wallet,
  X,
} from "lucide-react";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { searchAll } from "@/lib/server/books";
import { isoToJalali } from "@/lib/accounting/jalali";

const NAV = [
  { to: "/", label: "داشبورد", icon: LayoutDashboard },
  { to: "/operations", label: "عملیات روزانه", icon: Receipt },
  { to: "/parties", label: "اشخاص", icon: Users },
  { to: "/items", label: "کالاها", icon: Package },
  { to: "/journals", label: "اسناد", icon: BookOpen },
  { to: "/accounts", label: "حساب‌ها", icon: Building2 },
  { to: "/reports", label: "گزارش‌ها", icon: BarChart3 },
  { to: "/crm", label: "CRM", icon: Users },
  { to: "/kpi", label: "KPI", icon: BarChart3 },
  { to: "/liquidity", label: "نقدینگی", icon: Wallet },
  { to: "/checks", label: "چک‌ها", icon: Receipt },
  { to: "/close-day", label: "بستن روز", icon: CalendarCheck },
  { to: "/backup", label: "پشتیبان", icon: Database },
  { to: "/health", label: "سلامت سیستم", icon: HeartPulse },
  { to: "/settings", label: "تنظیمات", icon: Settings },
];

const BOTTOM = [
  { to: "/", label: "داشبورد", icon: LayoutDashboard },
  { to: "/operations", label: "عملیات", icon: Receipt },
  { to: "/reports", label: "گزارش", icon: BarChart3 },
  { to: "/liquidity", label: "نقد", icon: Wallet },
];

export function AppShell({ children }: { children: ReactNode }) {
  const { user, isPending } = useCurrentUserState();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [more, setMore] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [q, setQ] = useState("");
  const [hits, setHits] = useState<Awaited<ReturnType<typeof searchAll>> | null>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    if (!searchOpen || q.trim().length < 1) return;
    const t = setTimeout(() => {
      searchAll({ data: { q } })
        .then(setHits)
        .catch(() => setHits(null));
    }, 180);
    return () => clearTimeout(t);
  }, [q, searchOpen]);

  if (isPending) {
    return (
      <div className="grid min-h-dvh place-items-center bg-navy">
        <div className="text-center">
          <LogoMark className="mx-auto size-16" />
          <p className="mt-4 font-display text-2xl text-gold-soft" style={{ fontFamily: "var(--font-display)" }}>
            MR,KHORASANI
          </p>
          <p className="mt-1 text-xs tracking-[0.2em] text-gold/70 uppercase">Professional Accounting System</p>
        </div>
      </div>
    );
  }
  if (!user) return <RedirectToSignIn />;

  return (
    <div className="min-h-dvh bg-paper">
      <aside className="fixed top-0 right-0 z-30 hidden h-dvh w-60 flex-col border-l border-navy/10 bg-navy text-paper lg:flex">
        <div className="flex items-center gap-2 px-4 py-5">
          <LogoMark className="size-9" />
          <div>
            <div className="font-display text-lg text-gold-soft" style={{ fontFamily: "var(--font-display)" }}>
              MR,KHORASANI
            </div>
            <div className="text-[10px] tracking-widest text-gold/70">ACCOUNTING</div>
          </div>
        </div>
        <nav className="flex-1 space-y-0.5 overflow-y-auto px-2 pb-4">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "flex items-center gap-2 rounded-md px-3 py-2 text-sm",
                pathname === item.to ? "bg-gold/15 text-gold-soft" : "text-paper/75 hover:bg-white/5 hover:text-paper",
              )}
            >
              <item.icon className="size-4 opacity-80" />
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="border-t border-white/10 p-3 text-[11px] text-paper/50">{isoToJalali(new Date().toISOString().slice(0, 10))}</div>
      </aside>

      <header className="sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-line bg-card/90 px-4 py-3 backdrop-blur lg:mr-60">
        <div className="flex items-center gap-2 lg:hidden">
          <LogoMark className="size-8" />
          <span className="font-display text-base text-navy" style={{ fontFamily: "var(--font-display)" }}>
            MR,KHORASANI
          </span>
        </div>
        <button
          type="button"
          onClick={() => setSearchOpen(true)}
          className="hidden min-h-10 flex-1 items-center gap-2 rounded-md border border-line bg-paper px-3 text-sm text-muted md:flex"
        >
          <Search className="size-4" />
          جستجوی سراسری
        </button>
        <div className="flex items-center gap-2">
          <button type="button" className="rounded-md p-2 text-navy md:hidden" onClick={() => setSearchOpen(true)} aria-label="جستجو">
            <Search className="size-5" />
          </button>
          <UserButton />
        </div>
      </header>

      <main className="px-4 py-5 pb-24 lg:mr-60 lg:pb-8">{children}</main>

      <nav className="fixed inset-x-0 bottom-0 z-20 grid grid-cols-5 border-t border-line bg-card pb-[env(safe-area-inset-bottom)] lg:hidden">
        {BOTTOM.map((item) => (
          <Link
            key={item.to}
            to={item.to}
            className={cn(
              "flex min-h-14 flex-col items-center justify-center gap-1 text-[11px]",
              pathname === item.to ? "text-gold" : "text-muted",
            )}
          >
            <item.icon className="size-5" />
            {item.label}
          </Link>
        ))}
        <button type="button" onClick={() => setMore(true)} className="flex min-h-14 flex-col items-center justify-center gap-1 text-[11px] text-muted">
          <MoreHorizontal className="size-5" />
          بیشتر
        </button>
      </nav>

      {more && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <button type="button" className="absolute inset-0 bg-navy/40" onClick={() => setMore(false)} />
          <div className="absolute inset-x-0 bottom-0 max-h-[80vh] overflow-y-auto rounded-t-xl bg-card p-4 pb-8">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-semibold text-navy">بخش‌ها</h2>
              <button type="button" onClick={() => setMore(false)}>
                <X className="size-5" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {NAV.map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setMore(false)}
                  className="flex items-center gap-2 rounded-md border border-line px-3 py-3 text-sm"
                >
                  <item.icon className="size-4 text-gold" />
                  {item.label}
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}

      {searchOpen && (
        <div className="fixed inset-0 z-50">
          <button type="button" className="absolute inset-0 bg-navy/40" onClick={() => setSearchOpen(false)} />
          <div className="relative mx-auto mt-16 w-[min(92vw,560px)] rounded-xl bg-card p-4 shadow-xl">
            <input
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="نام، سند، عملیات، کالا، چک..."
              className="h-12 w-full rounded-md border border-line bg-paper px-3 text-sm outline-none focus:border-gold"
            />
            <SearchHits hits={hits} onPick={() => setSearchOpen(false)} />
          </div>
        </div>
      )}
    </div>
  );
}

function SearchHits({
  hits,
  onPick,
}: {
  hits: Awaited<ReturnType<typeof searchAll>> | null;
  onPick: () => void;
}) {
  const groups = useMemo(() => {
    if (!hits) return [];
    return [
      { title: "اشخاص", to: "/parties", rows: hits.parties as { id: string; name?: string; code?: string }[] },
      { title: "عملیات", to: "/operations", rows: hits.operations as { id: string; number?: string; description?: string }[] },
      { title: "اسناد", to: "/journals", rows: hits.journals as { id: string; number?: string; description?: string }[] },
      { title: "کالا", to: "/items", rows: hits.items as { id: string; name?: string; code?: string }[] },
      { title: "حساب‌ها", to: "/accounts", rows: hits.accounts as { id: string; name?: string; code?: string }[] },
      { title: "چک", to: "/checks", rows: hits.checks as { id: string; number?: string }[] },
    ].filter((g) => g.rows?.length);
  }, [hits]);
  if (!hits) return null;
  if (!groups.length) return <p className="mt-3 text-sm text-muted">موردی یافت نشد.</p>;
  return (
    <div className="mt-3 max-h-80 space-y-3 overflow-y-auto">
      {groups.map((g) => (
        <div key={g.title}>
          <p className="mb-1 text-xs text-muted">{g.title}</p>
          {g.rows.map((r) => (
            <Link key={r.id} to={g.to} onClick={onPick} className="block rounded-md px-2 py-2 text-sm hover:bg-paper-2">
              {(r as { number?: string }).number || (r as { code?: string }).code} —{" "}
              {(r as { name?: string }).name || (r as { description?: string }).description}
            </Link>
          ))}
        </div>
      ))}
    </div>
  );
}
