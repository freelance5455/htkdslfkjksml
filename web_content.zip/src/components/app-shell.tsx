import { Clock3, House, Layers, ScanFace } from "lucide-react";
import { ScanFlow } from "@/components/scan-flow";
import { HistoryScreen, HomeScreen, ScaleScreen } from "@/components/screens";
import { useAppStore, type Tab } from "@/lib/store";
import { cn } from "@/lib/utils";

const TABS: { id: Tab; label: string; icon: typeof House }[] = [
  { id: "home", label: "Home", icon: House },
  { id: "scan", label: "Quét", icon: ScanFace },
  { id: "history", label: "Lịch sử", icon: Clock3 },
  { id: "scale", label: "Thang", icon: Layers },
];

export function AppShell() {
  const screen = useAppStore((s) => s.screen);
  const tab = useAppStore((s) => s.tab);
  const go = useAppStore((s) => s.go);
  const hideNav = screen === "analyzing";

  return (
    <div className="flex min-h-dvh justify-center bg-bg text-fg">
      <div className="relative mx-auto flex min-h-dvh w-full max-w-md flex-col bg-bg">
        <div
          className="pointer-events-none absolute inset-x-0 top-0 h-48"
          style={{
            background:
              "linear-gradient(180deg, rgb(232 220 200 / 6%) 0%, transparent 100%)",
          }}
        />
        <div className="relative flex min-h-0 flex-1 flex-col safe-top">
          {screen === "home" && <HomeScreen />}
          {(screen === "scan" || screen === "analyzing" || screen === "result") && <ScanFlow />}
          {screen === "history" && <HistoryScreen />}
          {screen === "scale" && <ScaleScreen />}
        </div>

        {!hideNav && (
          <nav className="relative z-10 border-t border-border bg-bg/95 px-4 pt-2 nav-pad">
            <ul className="grid grid-cols-4 items-end">
              {TABS.map((item) => {
                const active = tab === item.id;
                const Icon = item.icon;
                const isScan = item.id === "scan";
                return (
                  <li key={item.id} className="flex justify-center">
                    <button
                      type="button"
                      onClick={() => go(item.id === "scan" ? "scan" : item.id)}
                      className={cn(
                        "tap flex flex-col items-center gap-1 text-2xs tracking-wide",
                        active ? "text-accent" : "text-subtle",
                      )}
                    >
                      <span
                        className={cn(
                          "grid place-items-center",
                          isScan
                            ? "size-12 -mt-5 rounded-full bg-accent text-accent-fg shadow-soft"
                            : "size-8",
                        )}
                      >
                        <Icon className={isScan ? "size-5" : "size-5"} strokeWidth={1.7} />
                      </span>
                      <span>{item.label}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </nav>
        )}
      </div>
    </div>
  );
}
