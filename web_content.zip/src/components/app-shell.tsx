import { CalendarDays, FolderClosed, MessageCircle, NotebookPen } from "lucide-react";
import { useAppStore, type AppTab } from "@/lib/store";
import { ChatPane } from "@/components/chat-pane";
import { TodayPane } from "@/components/today-pane";
import { LibraryPane } from "@/components/library-pane";
import { NotesPane } from "@/components/notes-pane";
import { cn } from "@/lib/utils";

const TABS: { id: AppTab; label: string; icon: typeof MessageCircle }[] = [
  { id: "ask", label: "Ask", icon: MessageCircle },
  { id: "today", label: "Today", icon: CalendarDays },
  { id: "library", label: "Library", icon: FolderClosed },
  { id: "notes", label: "Notes", icon: NotebookPen },
];

export function AppShell() {
  const tab = useAppStore((s) => s.tab);
  const setTab = useAppStore((s) => s.setTab);
  const clearChat = useAppStore((s) => s.clearChat);

  return (
    <div className="flex h-[100dvh] w-full justify-center bg-bg text-fg">
    <div className="flex h-full w-full max-w-lg flex-col">
      <header
        className="flex items-center justify-between px-4 pb-2"
        style={{ paddingTop: "max(0.75rem, env(safe-area-inset-top))" }}
      >
        <div>
          <p className="font-display text-2xl tracking-[-0.03em] text-fg">Mira</p>
          <p className="text-xs text-muted">Personal assistant</p>
        </div>
        {tab === "ask" ? (
          <button
            type="button"
            onClick={clearChat}
            className="h-10 rounded-lg px-3 text-sm text-muted transition-colors duration-150 hover:text-fg"
          >
            Clear
          </button>
        ) : (
          <span className="text-xs text-faint">On-device + Grok</span>
        )}
      </header>

      <main className="flex min-h-0 flex-1 flex-col overflow-hidden">
        {tab === "ask" ? <ChatPane /> : null}
        {tab === "today" ? <TodayPane /> : null}
        {tab === "library" ? <LibraryPane /> : null}
        {tab === "notes" ? <NotesPane /> : null}
      </main>

      <nav
        className="grid grid-cols-4 border-t border-border bg-bg px-2 pt-1"
        style={{ paddingBottom: "max(0.4rem, env(safe-area-inset-bottom))" }}
      >
        {TABS.map((item) => {
          const Icon = item.icon;
          const active = tab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id)}
              className={cn(
                "flex min-h-12 flex-col items-center justify-center gap-1 rounded-lg text-[0.7rem] font-medium transition-colors duration-150",
                active ? "text-fg" : "text-muted",
              )}
            >
              <Icon className="size-5" strokeWidth={active ? 2.2 : 1.8} />
              {item.label}
            </button>
          );
        })}
      </nav>
    </div>
    </div>
  );
}
