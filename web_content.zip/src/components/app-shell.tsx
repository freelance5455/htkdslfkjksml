"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCallback, useEffect, useState, type ComponentType, type ReactNode } from "react";
import {
  Bell,
  BookOpen,
  CalendarCheck,
  HeartPulse,
  Home,
  Info,
  LogIn,
  LogOut,
  MessageCircle,
  Phone,
  Plus,
  ShieldCheck,
  Stethoscope,
  UserRound,
} from "lucide-react";
import { useAuth, useI18n, useSite } from "@/components/providers";
import { api } from "@/lib/api-client";
import { EMERGENCY_NUMBERS, LOCALE_META, LOCALES } from "@/lib/constants";
import { cn, initials } from "@/lib/utils";

type IconType = ComponentType<{ className?: string }>;

const NAV_PUBLIC = [
  { href: "/", key: "nav.home", icon: Home },
  { href: "/services", key: "nav.services", icon: Stethoscope },
  { href: "/articles", key: "nav.articles", icon: BookOpen },
  { href: "/about", key: "nav.about", icon: Info },
];

const NAV_AUTH = [
  { href: "/appointments", key: "nav.appointments", icon: CalendarCheck },
  { href: "/notifications", key: "nav.notifications", icon: Bell, badge: true },
  { href: "/profile", key: "nav.profile", icon: UserRound },
];

function isActive(pathname: string, href: string) {
  return href === "/" ? pathname === "/" : pathname === href || pathname.startsWith(`${href}/`);
}

/** Segmented AR / FR / EN switcher. The choice is stored in a cookie read by the server layout. */
export function LanguageSwitcher({ compact = false }: { compact?: boolean }) {
  const { locale, setLocale } = useI18n();
  return (
    <div role="group" aria-label="Language" className="inline-flex rounded-full bg-sky-50 p-1 ring-1 ring-sky-100">
      {LOCALES.map((l) => (
        <button
          key={l}
          type="button"
          onClick={() => setLocale(l)}
          aria-pressed={locale === l}
          title={LOCALE_META[l].native}
          className={cn(
            "rounded-full px-3 py-1.5 text-xs font-semibold transition",
            locale === l ? "bg-white text-teal-700 shadow-sm" : "text-slate-500 hover:text-slate-800",
          )}
        >
          {compact ? LOCALE_META[l].label : LOCALE_META[l].native}
        </button>
      ))}
    </div>
  );
}

function useUnreadCount(enabled: boolean) {
  const [count, setCount] = useState(0);
  const load = useCallback(() => {
    api<{ unreadCount: number }>("/api/notifications")
      .then((r) => setCount(r.unreadCount))
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    if (!enabled) {
      setCount(0);
      return;
    }
    load();
    const id = window.setInterval(load, 60_000);
    window.addEventListener("shifacare:notifications", load);
    return () => {
      window.clearInterval(id);
      window.removeEventListener("shifacare:notifications", load);
    };
  }, [enabled, load]);

  return count;
}

function Logo({ small = false }: { small?: boolean }) {
  const { t } = useI18n();
  return (
    <span className="flex items-center gap-2.5">
      <span
        className={cn(
          "flex shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-teal-500 to-sky-500 text-white shadow-md shadow-teal-500/25",
          small ? "h-9 w-9" : "h-11 w-11",
        )}
      >
        <HeartPulse className={small ? "h-5 w-5" : "h-6 w-6"} />
      </span>
      <span className="flex flex-col leading-tight">
        <span className={cn("font-bold tracking-tight text-slate-900", small ? "text-base" : "text-lg")}>
          Shifa<span className="text-teal-600">Care</span>
        </span>
        <span className="text-[11px] font-semibold text-teal-700">{t("brand.arabic")}</span>
      </span>
    </span>
  );
}

function SideLink({ href, label, icon: Icon, active, badge }: { href: string; label: string; icon: IconType; active: boolean; badge?: number }) {
  return (
    <Link
      href={href}
      aria-current={active ? "page" : undefined}
      className={cn(
        "group flex items-center gap-3 rounded-xl px-3 py-3 text-[15px] font-medium transition",
        active ? "bg-teal-50 text-teal-700 shadow-sm ring-1 ring-teal-100" : "text-slate-700 hover:bg-sky-50 hover:text-slate-900",
      )}
    >
      <Icon className={cn("h-5 w-5 shrink-0", active ? "text-teal-600" : "text-slate-400 group-hover:text-sky-600")} />
      <span className="flex-1 truncate">{label}</span>
      {badge ? <span className="rounded-full bg-rose-500 px-2 py-0.5 text-[11px] font-bold text-white">{badge}</span> : null}
    </Link>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { t, locale } = useI18n();
  const { user, logout } = useAuth();
  const { settings, whatsapp, callLink, defaultMessage } = useSite();
  const pathname = usePathname();
  const unread = useUnreadCount(!!user);
  const emergency = EMERGENCY_NUMBERS[0];
  const phoneLabel = settings.contact.phoneDisplay;

  const mobileItems: Array<{ href: string; label: string; icon: IconType; primary?: boolean }> = [
    { href: "/", label: t("nav.home"), icon: Home },
    { href: "/services", label: t("nav.services"), icon: Stethoscope },
    { href: "/book", label: t("btn.book"), icon: Plus, primary: true },
    { href: "/appointments", label: t("nav.appointments"), icon: CalendarCheck },
    user ? { href: "/profile", label: t("nav.profile"), icon: UserRound } : { href: "/login", label: t("nav.login"), icon: LogIn },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50/60 via-white to-white">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 start-0 z-40 hidden w-72 flex-col border-e border-sky-100 bg-white/95 backdrop-blur-xl lg:flex">
        <div className="flex h-24 items-center px-6">
          <Link href="/" aria-label={t("app.name")}>
            <Logo />
          </Link>
        </div>
        <nav className="flex-1 space-y-1 overflow-y-auto px-3 pb-4" aria-label={t("nav.menu")}>
          {NAV_PUBLIC.map((i) => (
            <SideLink key={i.href} href={i.href} label={t(i.key)} icon={i.icon} active={isActive(pathname, i.href)} />
          ))}
          {user && <div className="my-3 border-t border-slate-100" />}
          {user &&
            NAV_AUTH.map((i) => (
              <SideLink
                key={i.href}
                href={i.href}
                label={t(i.key)}
                icon={i.icon}
                active={isActive(pathname, i.href)}
                badge={i.badge ? unread : undefined}
              />
            ))}
          {user?.role === "admin" && (
            <SideLink href="/admin" label={t("nav.admin")} icon={ShieldCheck} active={isActive(pathname, "/admin")} />
          )}
        </nav>

        <div className="space-y-3 border-t border-slate-100 p-4">
          <Link
            href="/book"
            className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-teal-500 to-sky-500 px-4 py-3.5 text-base font-semibold text-white shadow-md shadow-teal-500/20 transition hover:shadow-lg"
          >
            <Plus className="h-5 w-5" />
            {t("nav.book")}
          </Link>
          <a
            href={callLink}
            className="flex items-center gap-3 rounded-xl bg-emerald-50 px-3 py-2.5 ring-1 ring-emerald-100 transition hover:bg-emerald-100"
          >
            <Phone className="h-5 w-5 text-emerald-700" />
            <span className="flex-1">
              <span className="block text-sm font-bold text-emerald-900">{t("btn.callNow")}</span>
              <span className="block text-xs text-emerald-800" dir="ltr">
                {phoneLabel}
              </span>
            </span>
          </a>
          <div className="flex items-center justify-center">
            <LanguageSwitcher />
          </div>
          {user ? (
            <div className="flex items-center gap-3 rounded-xl bg-slate-50 p-2.5">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-sky-400 to-teal-500 text-xs font-bold text-white">
                {initials(user.fullName)}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold text-slate-900">{user.fullName}</p>
                <p className="truncate text-xs text-slate-500">{t(`role.${user.role}`)}</p>
              </div>
              <button
                type="button"
                onClick={() => void logout()}
                aria-label={t("nav.logout")}
                className="rounded-lg p-2 text-slate-500 transition hover:bg-white hover:text-rose-600"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              <Link href="/login" className="rounded-xl bg-white px-3 py-2.5 text-center text-sm font-semibold text-slate-700 ring-1 ring-slate-200 hover:bg-slate-50">
                {t("nav.login")}
              </Link>
              <Link href="/register" className="rounded-xl bg-teal-600 px-3 py-2.5 text-center text-sm font-semibold text-white hover:bg-teal-700">
                {t("nav.register")}
              </Link>
            </div>
          )}
        </div>
      </aside>

      {/* Mobile / tablet header */}
      <header className="sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-sky-100 bg-white/95 px-4 py-3 backdrop-blur-xl lg:hidden">
        <Link href="/" aria-label={t("app.name")}>
          <Logo small />
        </Link>
        <div className="flex items-center gap-2">
          <a href={callLink} aria-label={t("btn.callNow")} className="rounded-full bg-emerald-50 p-2.5 text-emerald-700 ring-1 ring-emerald-100">
            <Phone className="h-5 w-5" />
          </a>
          {user && (
            <Link href="/notifications" aria-label={t("nav.notifications")} className="relative rounded-full p-2.5 text-slate-600 hover:bg-sky-50">
              <Bell className="h-5 w-5" />
              {unread > 0 && <span className="absolute end-1.5 top-1.5 h-2.5 w-2.5 rounded-full bg-rose-500 ring-2 ring-white" />}
            </Link>
          )}
          <LanguageSwitcher compact />
        </div>
      </header>

      <main className="lg:ms-72">
        <div key={locale} className="animate-page-in mx-auto w-full max-w-6xl px-4 pb-36 pt-6 sm:px-6 lg:px-8 lg:pb-14 lg:pt-10">
          {children}
        </div>
        <footer className="mx-auto max-w-6xl px-4 pb-36 text-xs leading-relaxed text-slate-500 sm:px-6 lg:px-8 lg:pb-10">
          <div className="space-y-3 rounded-2xl bg-white/80 p-5 ring-1 ring-slate-100">
            <p className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-slate-700">
              <a href={callLink} className="inline-flex items-center gap-1.5 font-semibold text-emerald-700 hover:underline">
                <Phone className="h-4 w-4" />
                <span dir="ltr">{phoneLabel}</span>
              </a>
              <a href={whatsapp(defaultMessage)} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 font-semibold text-emerald-700 hover:underline">
                <MessageCircle className="h-4 w-4" />
                {t("btn.whatsapp")}
              </a>
              {settings.contact.city && <span>{settings.contact.city}, {t("app.country")}</span>}
              {settings.contact.email && (
                <a href={`mailto:${settings.contact.email}`} className="hover:underline" dir="ltr">
                  {settings.contact.email}
                </a>
              )}
            </p>
            <p>{t("app.footer")}</p>
          </div>
        </footer>
      </main>

      {/* Mobile bottom navigation */}
      <nav
        aria-label={t("nav.menu")}
        className="fixed inset-x-0 bottom-0 z-40 border-t border-sky-100 bg-white/95 px-2 pb-[max(env(safe-area-inset-bottom),0.5rem)] pt-2 shadow-[0_-8px_24px_rgba(14,116,144,0.08)] backdrop-blur-xl lg:hidden"
      >
        <ul className="grid grid-cols-5 items-end">
          {mobileItems.map((item) => {
            const active = isActive(pathname, item.href);
            const Icon = item.icon;
            if (item.primary) {
              return (
                <li key={item.href} className="flex justify-center">
                  <Link
                    href={item.href}
                    aria-label={item.label}
                    className="-mt-7 flex h-16 w-16 flex-col items-center justify-center rounded-full bg-gradient-to-br from-teal-500 to-sky-500 text-white shadow-xl shadow-teal-500/30 ring-4 ring-white transition active:scale-95"
                  >
                    <Icon className="h-7 w-7" />
                  </Link>
                </li>
              );
            }
            return (
              <li key={item.href} className="flex justify-center">
                <Link
                  href={item.href}
                  className={cn(
                    "flex flex-col items-center gap-1 rounded-xl px-1 py-1.5 text-[12px] font-semibold transition",
                    active ? "text-teal-700" : "text-slate-500",
                  )}
                >
                  <span className={cn("relative rounded-xl p-1.5", active && "bg-teal-50")}>
                    <Icon className="h-6 w-6" />
                    {item.href === "/appointments" && user && unread > 0 && (
                      <span className="absolute -end-0.5 -top-0.5 h-2.5 w-2.5 rounded-full bg-rose-500 ring-2 ring-white" />
                    )}
                  </span>
                  <span className="max-w-full truncate">{item.label}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Floating WhatsApp button (every page) */}
      <a
        href={whatsapp(defaultMessage)}
        target="_blank"
        rel="noopener noreferrer"
        aria-label={t("btn.bookWhatsapp")}
        className="fixed bottom-28 end-4 z-40 flex items-center gap-2 rounded-full bg-emerald-500 px-4 py-3.5 text-sm font-bold text-white shadow-xl shadow-emerald-500/30 ring-4 ring-white transition hover:scale-105 hover:bg-emerald-600 lg:bottom-6 lg:end-6"
      >
        <MessageCircle className="h-6 w-6" />
        <span className="hidden sm:inline">{t("btn.whatsapp")}</span>
      </a>
    </div>
  );
}
