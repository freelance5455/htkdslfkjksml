import { useEffect } from "react";
import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import { Download, FolderOpen, Home, Settings, Compass } from "lucide-react";
import { AddMediaButton } from "@/components/add-media";
import { Wordmark } from "@/components/logo";
import { MiniPlayer } from "@/components/player/mini-player";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useBrowser } from "@/lib/browser-store";
import { useDownloads } from "@/lib/download-store";
import { useLibrary } from "@/lib/library-store";
import { applyDocumentTheme, useSettings } from "@/lib/settings-store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Home", icon: Home },
  { to: "/library", label: "Library", icon: FolderOpen },
  { to: "/browser", label: "Browser", icon: Compass },
  { to: "/downloads", label: "Downloads", icon: Download },
  { to: "/settings", label: "Settings", icon: Settings },
] as const;

export function AppShell() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const hydrate = useLibrary((s) => s.hydrate);
  const hydrateDownloads = useDownloads((s) => s.hydrate);
  const hydrateHistory = useBrowser((s) => s.hydrateHistory);
  const theme = useSettings((s) => s.theme);
  const accent = useSettings((s) => s.accent);
  const scanning = useLibrary((s) => s.scanning);
  const scanDone = useLibrary((s) => s.scanDone);
  const scanTotal = useLibrary((s) => s.scanTotal);

  useEffect(() => {
    void hydrate();
    void hydrateDownloads();
    void hydrateHistory();
  }, [hydrate, hydrateDownloads, hydrateHistory]);

  useEffect(() => {
    applyDocumentTheme(theme, accent);
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => applyDocumentTheme(theme, accent);
    mq.addEventListener?.("change", onChange);
    return () => mq.removeEventListener?.("change", onChange);
  }, [theme, accent]);

  const hideChrome = pathname.startsWith("/player/");

  return (
    <TooltipProvider delayDuration={250}>
      <div className="min-h-dvh bg-bg text-fg">
        {hideChrome ? (
          <Outlet />
        ) : (
          <div className="mx-auto flex min-h-dvh max-w-[1400px]">
            <aside className="sticky top-0 hidden h-dvh w-[220px] shrink-0 flex-col border-r border-border bg-sidebar p-4 md:flex">
              <Link to="/" className="mb-8 px-1">
                <Wordmark />
              </Link>
              <nav className="flex flex-1 flex-col gap-1">
                {NAV.map((item) => {
                  const active =
                    item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.to}
                      to={item.to}
                      className={cn(
                        "flex h-11 items-center gap-3 rounded-lg px-3 text-sm font-medium text-muted transition-colors duration-150",
                        active ? "bg-secondary text-fg" : "hover:bg-secondary/60 hover:text-fg",
                      )}
                    >
                      <Icon className="size-4" />
                      {item.label}
                    </Link>
                  );
                })}
              </nav>
              <AddMediaButton />
            </aside>
            <div className="flex min-w-0 flex-1 flex-col">
              <header className="sticky top-0 z-20 flex h-14 items-center justify-between gap-3 border-b border-border bg-bg/90 px-4 backdrop-blur md:hidden">
                <Link to="/">
                  <Wordmark />
                </Link>
                <AddMediaButton variant="header" />
              </header>
              {scanning ? (
                <div className="border-b border-border bg-surface px-4 py-2 text-xs text-muted">
                  Scanning library… {scanDone}/{scanTotal}
                </div>
              ) : null}
              <main className="flex-1 px-4 pb-28 pt-4 md:px-8 md:pb-24 md:pt-8">
                <Outlet />
              </main>
            </div>
            <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-border bg-bg/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden">
              {NAV.map((item) => {
                const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
                const Icon = item.icon;
                return (
                  <Link
                    key={item.to}
                    to={item.to}
                    className={cn(
                      "flex h-14 flex-col items-center justify-center gap-1 text-[10px] font-medium",
                      active ? "text-primary" : "text-muted",
                    )}
                  >
                    <Icon className="size-5" />
                    {item.label}
                  </Link>
                );
              })}
            </nav>
            <MiniPlayer />
          </div>
        )}
        <Toaster />
      </div>
    </TooltipProvider>
  );
}
