import React, { useState, useEffect } from 'react';
import { Product } from '../types/business';
import { StorageService } from '../db/storage';
import {
  AlertTriangle,
  ArrowLeft,
  PlusCircle,
  Edit2,
  Trash2,
  Package,
  Layers,
  X,
  CheckCircle,
} from 'lucide-react';

interface StockAlertViewProps {
  lang: 'bn' | 'en';
  onBack: () => void;
  onNavigateToProductEdit?: (product: Product) => void;
}

export const StockAlertView: React.FC<StockAlertViewProps> = ({
  lang,
  onBack,
  onNavigateToProductEdit,
}) => {
  const [alerts, setAlerts] = useState(StorageService.getStockAlertProducts());
  const [stockAddProduct, setStockAddProduct] = useState<Product | null>(null);
  const [stockQty, setStockQty] = useState<number | ''>(10);
  const [stockCost, setStockCost] = useState<number | ''>('');
  const [deleteCandidate, setDeleteCandidate] = useState<Product | null>(null);

  const refreshAlerts = () => {
    setAlerts(StorageService.getStockAlertProducts());
  };

  const handleStockAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!stockAddProduct) return;
    const qty = Number(stockQty);
    if (!qty || qty <= 0) return;

    StorageService.addStockToProduct(
      stockAddProduct.id,
      qty,
      Number(stockCost) || stockAddProduct.purchasePrice,
      'Restocked from Stock Alert View'
    );

    setStockAddProduct(null);
    setStockQty(10);
    refreshAlerts();
  };

  const handleDelete = () => {
    if (deleteCandidate) {
      StorageService.deleteProduct(deleteCandidate.id);
      setDeleteCandidate(null);
      refreshAlerts();
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-24 font-sans">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                <AlertTriangle className="w-6 h-6 text-amber-500" />
                <span>{lang === 'bn' ? 'স্টক অ্যালার্ট তালিকা' : 'Stock Alert Center'}</span>
              </h1>
              <p className="text-xs text-slate-500">
                {lang === 'bn'
                  ? `🔴 স্টক শেষ: ${alerts.stockOut.length} টি | 🟠 সীমিত স্টক: ${alerts.limitedStock.length} টি`
                  : `Stock Out: ${alerts.stockOut.length} | Limited: ${alerts.limitedStock.length}`}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-8">
        {/* Section 1: 🔴 Stock Out Products (Stock == 0) */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <span className="w-3 h-3 rounded-full bg-red-600 animate-ping" />
            <h2 className="text-base font-extrabold text-red-700 uppercase tracking-wide">
              {lang === 'bn' ? '🔴 স্টক শেষ (Stock Out) — বিক্রি বন্ধ' : '🔴 Stock Out (Sales Blocked)'}
            </h2>
            <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-800 text-xs font-bold">
              {alerts.stockOut.length}
            </span>
          </div>

          {alerts.stockOut.length === 0 ? (
            <div className="p-6 rounded-2xl bg-white border border-slate-200 text-center text-slate-500 text-xs font-medium">
              🎉 {lang === 'bn' ? 'কোন স্টক আউট পণ্য নেই!' : 'No stock out items at this time!'}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {alerts.stockOut.map((p) => (
                <div
                  key={p.id}
                  className="bg-white rounded-2xl border-2 border-red-200 p-4 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <span className="px-2 py-0.5 rounded-lg bg-indigo-50 text-indigo-700 text-xs font-bold">
                        {p.brand}
                      </span>
                      <span className="px-2 py-0.5 rounded-md bg-red-600 text-white text-[11px] font-extrabold">
                        স্টক: ০ পিস
                      </span>
                    </div>

                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-16 h-16 rounded-xl bg-slate-100 border border-slate-200 overflow-hidden shrink-0 flex items-center justify-center">
                        {p.frontPhoto ? (
                          <img src={p.frontPhoto} alt={p.name} className="w-full h-full object-cover" />
                        ) : (
                          <Package className="w-6 h-6 text-slate-400" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <span className="text-[10px] uppercase font-bold text-slate-400 block">
                          {p.category}
                        </span>
                        <h3 className="font-bold text-slate-900 text-sm leading-tight">
                          {p.modelNumber}
                        </h3>
                        {p.supportedModels && (
                          <p className="text-[11px] text-slate-500 truncate mt-0.5">
                            সাপোর্ট: {p.supportedModels}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-1 p-2 rounded-xl bg-red-50/50 border border-red-100 text-center text-xs mb-3">
                      <div>
                        <span className="text-[10px] text-slate-400 block">ক্রয়</span>
                        <span className="font-bold text-slate-800">৳{p.purchasePrice}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">খুচরা</span>
                        <span className="font-bold text-emerald-700">৳{p.retailPrice}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">পাইকারি</span>
                        <span className="font-bold text-blue-700">৳{p.wholesalePrice}</span>
                      </div>
                    </div>
                  </div>

                  {/* Quick Action */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                    <button
                      onClick={() => {
                        setStockAddProduct(p);
                        setStockCost(p.purchasePrice);
                      }}
                      className="flex-1 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
                    >
                      <PlusCircle className="w-4 h-4" />
                      <span>+ স্টক যোগ করুন</span>
                    </button>
                    <button
                      onClick={() => setDeleteCandidate(p)}
                      className="p-2 rounded-xl bg-slate-100 text-red-600 hover:bg-red-50 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Section 2: 🟠 Limited Stock Products */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <span className="w-3 h-3 rounded-full bg-amber-500" />
            <h2 className="text-base font-extrabold text-amber-800 uppercase tracking-wide">
              {lang === 'bn' ? '🟠 সীমিত স্টক (Limited Stock)' : '🟠 Limited Stock Products'}
            </h2>
            <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-xs font-bold">
              {alerts.limitedStock.length}
            </span>
          </div>

          {alerts.limitedStock.length === 0 ? (
            <div className="p-6 rounded-2xl bg-white border border-slate-200 text-center text-slate-500 text-xs font-medium">
              👍 {lang === 'bn' ? 'সব পণ্যের পর্যাপ্ত স্টক রয়েছে!' : 'All items have healthy stock!'}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {alerts.limitedStock.map((p) => (
                <div
                  key={p.id}
                  className="bg-white rounded-2xl border-2 border-amber-200 p-4 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <span className="px-2 py-0.5 rounded-lg bg-indigo-50 text-indigo-700 text-xs font-bold">
                        {p.brand}
                      </span>
                      <span className="px-2 py-0.5 rounded-md bg-amber-500 text-white text-[11px] font-extrabold">
                        অবশিষ্ট: {p.stockQuantity} পিস
                      </span>
                    </div>

                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-16 h-16 rounded-xl bg-slate-100 border border-slate-200 overflow-hidden shrink-0 flex items-center justify-center">
                        {p.frontPhoto ? (
                          <img src={p.frontPhoto} alt={p.name} className="w-full h-full object-cover" />
                        ) : (
                          <Package className="w-6 h-6 text-slate-400" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <span className="text-[10px] uppercase font-bold text-slate-400 block">
                          {p.category}
                        </span>
                        <h3 className="font-bold text-slate-900 text-sm leading-tight">
                          {p.modelNumber}
                        </h3>
                        <p className="text-[11px] text-slate-500 truncate mt-0.5">
                          সতর্কতা সীমা: {p.alertLimit} পিস
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-1 p-2 rounded-xl bg-amber-50/50 border border-amber-100 text-center text-xs mb-3">
                      <div>
                        <span className="text-[10px] text-slate-400 block">ক্রয়</span>
                        <span className="font-bold text-slate-800">৳{p.purchasePrice}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">খুচরা</span>
                        <span className="font-bold text-emerald-700">৳{p.retailPrice}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">পাইকারি</span>
                        <span className="font-bold text-blue-700">৳{p.wholesalePrice}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                    <button
                      onClick={() => {
                        setStockAddProduct(p);
                        setStockCost(p.purchasePrice);
                      }}
                      className="flex-1 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
                    >
                      <PlusCircle className="w-4 h-4" />
                      <span>+ স্টক বাড়ান</span>
                    </button>
                    <button
                      onClick={() => setDeleteCandidate(p)}
                      className="p-2 rounded-xl bg-slate-100 text-red-600 hover:bg-red-50 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Stock Add Modal */}
      {stockAddProduct && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl p-6 border border-slate-100">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-base text-slate-900">
                স্টক রিস্টক: {stockAddProduct.brand} {stockAddProduct.modelNumber}
              </h3>
              <button
                onClick={() => setStockAddProduct(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleStockAdd} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  নতুন লটের পরিমাণ (পিস) *
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  value={stockQty}
                  onChange={(e) => setStockQty(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ক্রয় মূল্য (৳ / পিস)
                </label>
                <input
                  type="number"
                  min="0"
                  value={stockCost}
                  onChange={(e) => setStockCost(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder={`আগের ক্রয়: ৳${stockAddProduct.purchasePrice}`}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm font-medium focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setStockAddProduct(null)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-500/20 cursor-pointer"
                >
                  স্টক নিশ্চিত করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {deleteCandidate && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl p-6 text-center border border-slate-100">
            <h3 className="font-bold text-slate-900 text-base mb-2">
              পণ্যটি মুছে ফেলতে চান?
            </h3>
            <p className="text-xs text-slate-500 mb-6">
              {deleteCandidate.brand} {deleteCandidate.modelNumber}
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setDeleteCandidate(null)}
                className="flex-1 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs"
              >
                বাতিল
              </button>
              <button
                onClick={handleDelete}
                className="flex-1 py-2.5 rounded-xl bg-red-600 text-white font-bold text-xs"
              >
                মুছে ফেলুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
