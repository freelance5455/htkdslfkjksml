import { memo, type CSSProperties } from "react";
import type { CustType, Hair } from "../game/data";

export function shade(hex: string, amt: number) {
  const h = hex.replace("#", "");
  const n = parseInt(h.length === 3 ? h.split("").map((c) => c + c).join("") : h, 16);
  let r = (n >> 16) + amt;
  let g = ((n >> 8) & 0xff) + amt;
  let b = (n & 0xff) + amt;
  r = Math.max(0, Math.min(255, r));
  g = Math.max(0, Math.min(255, g));
  b = Math.max(0, Math.min(255, b));
  return `rgb(${r},${g},${b})`;
}

export type Mood = "wait" | "low" | "happy" | "angry";

/** Chunky cartoon customer built from plain divs so it stays crisp at any size. */
export function Person({
  type,
  mood = "wait",
  w = 62,
}: {
  type: CustType;
  mood?: Mood;
  w?: number;
}) {
  const h = w * 1.55;
  const skin = type.skin;
  const shirt = type.shirt;
  const pants = shade(shirt, -58);
  const hair = type.hairColor;
  const s = w / 62; // scale factor

  const hairTop = (style: Hair) => {
    const base: CSSProperties = { position: "absolute", background: hair };
    switch (style) {
      case "cap":
        return (
          <>
            <div
              style={{
                ...base,
                left: "6%",
                top: "-6%",
                width: "88%",
                height: "46%",
                borderRadius: "50% 50% 22% 22%",
              }}
            />
            <div
              style={{
                ...base,
                left: "58%",
                top: "30%",
                width: "56%",
                height: "14%",
                borderRadius: "0 40% 40% 0",
                filter: "brightness(.85)",
              }}
            />
          </>
        );
      case "bun":
        return (
          <>
            <div style={{ ...base, left: "4%", top: "-4%", width: "92%", height: "52%", borderRadius: "50% 50% 20% 20%" }} />
            <div
              style={{
                ...base,
                left: "34%",
                top: "-22%",
                width: "34%",
                height: "26%",
                borderRadius: "50%",
                filter: "brightness(1.12)",
              }}
            />
          </>
        );
      case "bald":
        return (
          <>
            <div style={{ ...base, left: "-2%", top: "26%", width: "24%", height: "26%", borderRadius: "50%" }} />
            <div style={{ ...base, right: "-2%", top: "26%", width: "24%", height: "26%", borderRadius: "50%" }} />
          </>
        );
      case "hijab":
        return (
          <>
            <div
              style={{
                position: "absolute",
                left: "-14%",
                top: "-12%",
                width: "128%",
                height: "112%",
                background: hair,
                borderRadius: "48% 48% 42% 42%",
              }}
            />
            <div
              style={{
                position: "absolute",
                left: "-8%",
                top: "62%",
                width: "116%",
                height: "52%",
                background: shade(hair, -18),
                borderRadius: "40% 40% 50% 50%",
              }}
            />
          </>
        );
      case "helmet":
        return (
          <>
            <div
              style={{
                ...base,
                left: "-6%",
                top: "-14%",
                width: "112%",
                height: "62%",
                borderRadius: "50% 50% 18% 18%",
                boxShadow: "inset 0 -3px 0 rgba(0,0,0,.25)",
              }}
            />
            <div style={{ ...base, left: "-6%", top: "38%", width: "112%", height: "9%", filter: "brightness(.7)" }} />
          </>
        );
      case "long":
        return (
          <>
            <div style={{ ...base, left: "-6%", top: "-8%", width: "112%", height: "62%", borderRadius: "50% 50% 24% 24%" }} />
            <div style={{ ...base, left: "-12%", top: "34%", width: "26%", height: "86%", borderRadius: "40%" }} />
            <div style={{ ...base, right: "-12%", top: "34%", width: "26%", height: "86%", borderRadius: "40%" }} />
          </>
        );
      default:
        return (
          <div style={{ ...base, left: "2%", top: "-6%", width: "96%", height: "54%", borderRadius: "50% 50% 26% 26%" }} />
        );
    }
  };

  const eyeStyle: CSSProperties = {
    position: "absolute",
    top: "46%",
    width: 4.6 * s,
    height: mood === "happy" ? 3 * s : 5.4 * s,
    background: "#2a1b3d",
    borderRadius: mood === "happy" ? "50% 50% 0 0" : "50%",
  };

  return (
    <div className="relative" style={{ width: w, height: h }}>
      {/* shadow */}
      <div
        className="absolute left-1/2 -translate-x-1/2 rounded-[50%] bg-black/40 blur-[2px]"
        style={{ bottom: -1, width: w * 0.78, height: 7 * s }}
      />
      {/* legs */}
      <div
        className="absolute"
        style={{
          left: "24%",
          bottom: 4 * s,
          width: "20%",
          height: "26%",
          background: pants,
          borderRadius: "30% 30% 22% 22%",
        }}
      />
      <div
        className="absolute"
        style={{
          right: "24%",
          bottom: 4 * s,
          width: "20%",
          height: "26%",
          background: pants,
          borderRadius: "30% 30% 22% 22%",
        }}
      />
      {/* shoes */}
      <div className="absolute" style={{ left: "19%", bottom: 0, width: "27%", height: 6 * s, background: "#2a1b3d", borderRadius: 6 * s }} />
      <div className="absolute" style={{ right: "19%", bottom: 0, width: "27%", height: 6 * s, background: "#2a1b3d", borderRadius: 6 * s }} />
      {/* torso */}
      <div
        className="absolute left-1/2 -translate-x-1/2"
        style={{
          bottom: "22%",
          width: "74%",
          height: "40%",
          background: shirt,
          borderRadius: "38% 38% 22% 22%",
          boxShadow: `inset -${4 * s}px -${3 * s}px 0 rgba(0,0,0,.16), inset ${3 * s}px ${2 * s}px 0 rgba(255,255,255,.16)`,
        }}
      />
      {/* arms */}
      <div
        className="absolute anim-bob"
        style={{ left: "4%", bottom: "26%", width: "15%", height: "32%", background: shade(shirt, -26), borderRadius: 40, animationDuration: "2.4s" }}
      />
      <div
        className="absolute anim-bob"
        style={{ right: "4%", bottom: "26%", width: "15%", height: "32%", background: shade(shirt, -26), borderRadius: 40, animationDuration: "2.9s" }}
      />
      {/* head */}
      <div
        className="absolute left-1/2 -translate-x-1/2"
        style={{
          top: 0,
          width: "68%",
          height: "42%",
          background: skin,
          borderRadius: "48% 48% 44% 44%",
          boxShadow: `inset -${3 * s}px -${2 * s}px 0 rgba(0,0,0,.12)`,
        }}
      >
        {hairTop(type.hair)}
        {type.hair !== "hijab" && (
          <>
            <div className="absolute" style={{ left: "-6%", top: "44%", width: "14%", height: "18%", background: skin, borderRadius: "50%" }} />
            <div className="absolute" style={{ right: "-6%", top: "44%", width: "14%", height: "18%", background: skin, borderRadius: "50%" }} />
          </>
        )}
        {/* brows */}
        <div
          className="absolute"
          style={{
            left: "20%",
            top: mood === "angry" || mood === "low" ? "38%" : "36%",
            width: "18%",
            height: 2.4 * s,
            background: shade(hair, -10),
            borderRadius: 2,
            transform: mood === "angry" ? "rotate(18deg)" : mood === "low" ? "rotate(10deg)" : "rotate(-4deg)",
          }}
        />
        <div
          className="absolute"
          style={{
            right: "20%",
            top: mood === "angry" || mood === "low" ? "38%" : "36%",
            width: "18%",
            height: 2.4 * s,
            background: shade(hair, -10),
            borderRadius: 2,
            transform: mood === "angry" ? "rotate(-18deg)" : mood === "low" ? "rotate(-10deg)" : "rotate(4deg)",
          }}
        />
        {/* eyes */}
        <div style={{ ...eyeStyle, left: "24%" }} />
        <div style={{ ...eyeStyle, right: "24%" }} />
        {/* mouth */}
        {mood === "happy" ? (
          <div
            className="absolute left-1/2 -translate-x-1/2"
            style={{
              top: "62%",
              width: "34%",
              height: "22%",
              background: "#7a2233",
              borderRadius: "0 0 60% 60%",
              boxShadow: "inset 0 -2px 0 rgba(255,255,255,.35)",
            }}
          />
        ) : mood === "angry" || mood === "low" ? (
          <div
            className="absolute left-1/2 -translate-x-1/2"
            style={{
              top: "70%",
              width: "30%",
              height: 3 * s,
              background: "#7a2233",
              borderRadius: 4,
              transform: "rotate(-3deg)",
              boxShadow: `0 -${3 * s}px 0 -${1 * s}px rgba(122,34,51,.5)`,
            }}
          />
        ) : (
          <div
            className="absolute left-1/2 -translate-x-1/2"
            style={{ top: "66%", width: "26%", height: "12%", borderBottom: `${2.6 * s}px solid #7a2233`, borderRadius: "0 0 60% 60%" }}
          />
        )}
        {(mood === "happy" || mood === "low") && (
          <>
            <div className="absolute" style={{ left: "12%", top: "58%", width: "16%", height: "10%", background: "rgba(255,77,141,.4)", borderRadius: "50%" }} />
            <div className="absolute" style={{ right: "12%", top: "58%", width: "16%", height: "10%", background: "rgba(255,77,141,.4)", borderRadius: "50%" }} />
          </>
        )}
      </div>
      {/* accessory held in hand */}
      <div
        className="absolute anim-bob"
        style={{ right: "-6%", bottom: "30%", fontSize: 17 * s, animationDuration: "3.1s", filter: "drop-shadow(0 2px 2px rgba(0,0,0,.4))" }}
      >
        {type.acc}
      </div>
      {mood === "low" && (
        <div className="absolute anim-float-up" style={{ left: "72%", top: "18%", fontSize: 13 * s }}>
          💧
        </div>
      )}
      {mood === "angry" && (
        <div className="absolute anim-pop" style={{ left: "62%", top: "-4%", fontSize: 20 * s }}>
          💢
        </div>
      )}
    </div>
  );
}

/** String of festive bulbs spanning the street. */
export function StringLights({ bulbs = 14, color = "#ffb627" }: { bulbs?: number; color?: string }) {
  return (
    <div className="pointer-events-none absolute inset-x-0 top-0 h-16">
      <svg className="absolute inset-x-0 top-0 h-8 w-full" viewBox="0 0 100 20" preserveAspectRatio="none">
        <path d="M0 2 Q50 22 100 2" fill="none" stroke="rgba(27,16,41,.75)" strokeWidth="0.7" />
      </svg>
      <div className="absolute inset-x-0 top-0 flex justify-between px-1">
        {Array.from({ length: bulbs }).map((_, i) => {
          const t = i / (bulbs - 1);
          const y = 2 + Math.sin(Math.PI * t) * 22;
          return (
            <div
              key={i}
              className="anim-flicker rounded-full"
              style={{
                marginTop: y,
                width: 8,
                height: 10,
                background: i % 3 === 0 ? "#ff4d8d" : i % 3 === 1 ? color : "#17b8a6",
                boxShadow: `0 0 10px ${i % 3 === 0 ? "#ff4d8d" : i % 3 === 1 ? color : "#17b8a6"}`,
                animationDelay: `${(i % 5) * 0.7}s`,
                borderRadius: "50% 50% 45% 45%",
              }}
            />
          );
        })}
      </div>
    </div>
  );
}

/** Silhouette skyline — varies by location so each day reads differently. */
export function Silhouette({ kind, tint }: { kind: string; tint: string }) {
  const buildings: { x: number; w: number; h: number; win?: boolean }[] = [];
  let seed = kind.charCodeAt(0) * 31 + kind.length * 17;
  const rnd = () => {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    return (seed % 1000) / 1000;
  };
  const count = kind === "park" ? 5 : kind === "tower" || kind === "city" ? 13 : 9;
  let x = -20;
  for (let i = 0; i < count; i++) {
    const w = 40 + rnd() * (kind === "tower" ? 70 : 100);
    const h = kind === "park" ? 30 + rnd() * 40 : kind === "tower" ? 60 + rnd() * 120 : 40 + rnd() * 80;
    buildings.push({ x, w, h, win: h > 55 });
    x += w + 8 + rnd() * 26;
  }
  return (
    <svg className="absolute bottom-[16%] left-0 h-[46%] w-full" viewBox="0 0 1200 260" preserveAspectRatio="none">
      <g fill={tint}>
        {buildings.map((b, i) => (
          <rect key={i} x={b.x} y={260 - b.h} width={b.w} height={b.h} rx="2" />
        ))}
        {kind === "school" && (
          <>
            <rect x="430" y="120" width="180" height="140" />
            <path d="M420 120 L520 62 L620 120 Z" />
            <rect x="516" y="20" width="6" height="46" />
            <path d="M522 24 L566 36 L522 50 Z" fill="#e8384f" />
          </>
        )}
        {kind === "mosque" && (
          <>
            <rect x="500" y="140" width="200" height="120" />
            <path d="M600 60 C 660 96, 668 128, 600 142 C 532 128, 540 96, 600 60 Z" />
            <rect x="596" y="26" width="8" height="40" />
            <circle cx="600" cy="22" r="9" />
            <rect x="452" y="70" width="22" height="190" />
            <path d="M446 70 L463 40 L480 70 Z" />
            <rect x="726" y="70" width="22" height="190" />
            <path d="M720 70 L737 40 L754 70 Z" />
          </>
        )}
        {kind === "park" &&
          [90, 240, 760, 940, 1090].map((tx, i) => (
            <g key={i}>
              <rect x={tx} y="180" width="16" height="80" />
              <circle cx={tx + 8} cy="164" r={44 + (i % 3) * 9} />
            </g>
          ))}
        {kind === "airport" && (
          <>
            <path d="M120 96 L1080 76 L1092 96 L120 116 Z" opacity=".9" />
            <rect x="840" y="60" width="16" height="200" />
            <rect x="812" y="42" width="72" height="26" rx="8" />
          </>
        )}
        {kind === "tower" && (
          <g>
            <rect x="330" y="40" width="12" height="220" />
            <circle cx="336" cy="34" r="8" fill="#e8384f" />
          </g>
        )}
      </g>
      <g fill="#ffb627">
        {buildings
          .filter((b) => b.win)
          .flatMap((b, bi) =>
            Array.from({ length: Math.min(7, Math.floor(b.h / 26)) }).map((_, r) =>
              Array.from({ length: Math.min(3, Math.floor(b.w / 34)) }).map((_, c) =>
                rnd() > 0.45 ? (
                  <rect
                    key={`${bi}-${r}-${c}`}
                    x={b.x + 10 + c * 28}
                    y={260 - b.h + 14 + r * 24}
                    width="9"
                    height="12"
                    opacity={0.25 + rnd() * 0.6}
                  />
                ) : null,
              ),
            ),
          )
          .flat()}
      </g>
    </svg>
  );
}

/** Passing rickshaws / CNG / bus on the road. */

export function Traffic({ night }: { night: boolean }) {
  const vehicles = [
    { icon: "🛺", dur: 15, delay: 0, bottom: 6, size: 34, rev: false },
    { icon: "🚌", dur: 22, delay: 6, bottom: 4, size: 44, rev: true },
    { icon: "🚲", dur: 26, delay: 12, bottom: 8, size: 26, rev: false },
    { icon: "🛺", dur: 18, delay: 9, bottom: 3, size: 30, rev: true },
    { icon: "🚗", dur: 13, delay: 3.5, bottom: 7, size: 30, rev: false },
  ];
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[22%] overflow-hidden">
      {vehicles.map((v, i) => (
        <div
          key={i}
          className="absolute"
          style={{
            bottom: v.bottom,
            left: 0,
            fontSize: v.size,
            animation: `${v.rev ? "trafficRev" : "traffic"} ${v.dur}s linear ${v.delay}s infinite`,
            filter: night ? "brightness(.55) saturate(.7)" : "brightness(.8)",
            opacity: 0.85,
          }}
        >
          {v.icon}
        </div>
      ))}
    </div>
  );
}

/** The player's food cart — visually grows with purchased upgrades. */
export function FoodCart({
  upgrades,
  sign,
  glow,
}: {
  upgrades: Record<string, number>;
  sign: string;
  glow: string;
}) {
  const light = upgrades.light ?? 0;
  const stool = upgrades.stool ?? 0;
  const sound = upgrades.sound ?? 0;
  const banner = upgrades.banner ?? 0;
  const auto = upgrades.auto ?? 0;
  const pot = upgrades.pot ?? 0;
  return (
    <div className="relative select-none" style={{ width: "100%", maxWidth: 250 }}>
      {/* hanging sign */}
      <div className="anim-sway relative mx-auto mb-[-6px] w-[88%]">
        <div
          className="relative rounded-md border-2 px-2 py-1 text-center"
          style={{
            background: banner ? "linear-gradient(100deg,#e8384f,#ff4d8d 45%,#ffb627)" : "linear-gradient(100deg,#7b2d5e,#4a2352)",
            borderColor: "rgba(27,16,41,.65)",
            boxShadow: `0 6px 18px rgba(0,0,0,.45), 0 0 ${banner ? 22 : 10}px ${glow}55`,
          }}
        >
          <div className="font-display text-[11px] leading-tight font-extrabold text-cream sm:text-[13px]" style={{ textShadow: "0 2px 0 rgba(27,16,41,.6)" }}>
            {sign}
          </div>
          {banner > 0 && (
            <div className="text-[9px] font-semibold tracking-wide text-cream/85">
              {banner > 1 ? "★ রাজকীয় ফুডকার্ট ★" : "★ সেরা স্ট্রিট ফুড ★"}
            </div>
          )}
        </div>
        {Array.from({ length: 8 }).map((_, i) => (
          <span
            key={i}
            className="anim-flicker absolute -bottom-1 h-1.5 w-1.5 rounded-full"
            style={{
              left: `${6 + i * 12}%`,
              background: i % 2 ? "#ffe9c2" : "#ffb627",
              boxShadow: "0 0 7px #ffb627",
              animationDelay: `${i * 0.35}s`,
            }}
          />
        ))}
      </div>

      {/* awning */}
      <div className="relative mx-auto h-[26px] w-[104%] -translate-x-[2%]">
        <div
          className="absolute inset-0 rounded-t-[14px]"
          style={{
            background: "repeating-linear-gradient(90deg,#e8384f 0 16px,#fff3dc 16px 32px)",
            boxShadow: "inset 0 -4px 0 rgba(27,16,41,.28)",
          }}
        />
        <div className="absolute -bottom-[7px] left-0 flex w-full justify-between">
          {Array.from({ length: 9 }).map((_, i) => (
            <span
              key={i}
              style={{
                width: "11.5%",
                height: 9,
                background: i % 2 ? "#fff3dc" : "#e8384f",
                borderRadius: "0 0 50% 50%",
              }}
            />
          ))}
        </div>
        {light > 0 && (
          <div className="absolute -bottom-[10px] left-0 flex w-full justify-around">
            {Array.from({ length: 5 + light * 3 }).map((_, i) => (
              <span
                key={i}
                className="anim-flicker h-2 w-2 rounded-full"
                style={{
                  background: ["#ffb627", "#17b8a6", "#ff4d8d"][i % 3],
                  boxShadow: `0 0 9px ${["#ffb627", "#17b8a6", "#ff4d8d"][i % 3]}`,
                  animationDelay: `${i * 0.23}s`,
                }}
              />
            ))}
          </div>
        )}
      </div>

      {/* body */}
      <div
        className="relative mt-[6px] rounded-[10px] border-2 border-ink/60 px-2 pb-3 pt-2"
        style={{
          background: "linear-gradient(180deg,#c98b3a 0%,#a4682a 42%,#8a4b12 100%)",
          boxShadow: "inset 0 3px 0 rgba(255,255,255,.22), 0 12px 24px rgba(0,0,0,.45)",
        }}
      >
        {/* glass case with trays */}
        <div
          className="relative mb-2 flex items-end justify-around rounded-[6px] border border-cream/30 px-1 py-1"
          style={{ background: "linear-gradient(180deg,rgba(255,243,220,.28),rgba(23,184,166,.16))", height: 40 }}
        >
          {["🥟", "🥣", "🍲", "🥨", "🍛", "🫓"]
            .slice(0, 3 + pot)
            .map((f, i) => (
              <span key={i} className="anim-breathe text-[15px] sm:text-[18px]" style={{ animationDelay: `${i * 0.3}s`, filter: "drop-shadow(0 2px 2px rgba(0,0,0,.35))" }}>
                {f}
              </span>
            ))}
          <span className="absolute inset-x-1 top-0 h-3 rounded bg-white/20 blur-[2px]" />
        </div>
        {/* painted front panel */}
        <div
          className="rounded-[5px] px-1 py-[3px] text-center"
          style={{ background: "rgba(27,16,41,.35)", border: "1px dashed rgba(255,243,220,.35)" }}
        >
          <div className="font-display text-[10px] font-bold text-marigold sm:text-[11px]">ভালো খাওয়ান · কম নিন</div>
        </div>
        <div className="mt-1 flex items-center justify-between gap-1">
          {sound > 0 && (
            <span className="anim-breathe text-[13px]" title="সাউন্ড সিস্টেম">
              🔊
            </span>
          )}
          {auto > 0 && (
            <span className="anim-sizzle text-[14px]" title="অটো-মেকার">
              🤖
            </span>
          )}
          <span className="anim-sizzle text-[15px]" title="চুলা">
            🔥
          </span>
          <span className="text-[13px]">🫕</span>
          {pot > 1 && <span className="text-[13px]">🍲</span>}
        </div>
        {/* wheels */}
        <div className="absolute -bottom-4 left-3 h-8 w-8 rounded-full border-4 border-ink/70 bg-tamarind">
          <div className="anim-spin-slow absolute inset-1 rounded-full border-2 border-dashed border-cream/40" />
        </div>
        <div className="absolute -bottom-4 right-3 h-8 w-8 rounded-full border-4 border-ink/70 bg-tamarind">
          <div className="anim-spin-slow absolute inset-1 rounded-full border-2 border-dashed border-cream/40" style={{ animationDuration: "6s" }} />
        </div>
      </div>
      {stool > 0 && (
        <div className="absolute -right-2 bottom-0 text-[20px]">
          🪑
        </div>
      )}
      <div className="pointer-events-none absolute -top-1 left-1/2 h-8 w-16 -translate-x-1/2">
        {[0, 1, 2].map((i) => (
          <span
            key={i}
            className="absolute bottom-0 left-1/2 h-6 w-6 -translate-x-1/2 rounded-full bg-cream/25 blur-[3px]"
            style={{ animation: `steam ${2.4 + i * 0.6}s ease-out ${i * 0.7}s infinite` }}
          />
        ))}
      </div>
    </div>
  );
}

/* Memoised views: these only change once per day, so keep them out of the 10Hz game render. */
export const SilhouetteView = memo(Silhouette);
export const TrafficView = memo(Traffic);
export const LightsView = memo(StringLights);
export const CartView = memo(FoodCart);
export const PersonView = memo(Person);
