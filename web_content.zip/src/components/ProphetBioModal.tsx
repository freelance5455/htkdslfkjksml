import React from 'react';
import { ASSETS } from '../data/spiritualData';
import { X, ShieldCheck, Flame, Radio, Award, HeartHandshake, Globe } from 'lucide-react';

interface ProphetBioModalProps {
  onClose: () => void;
  onOpenPrayer: () => void;
}

export const ProphetBioModal: React.FC<ProphetBioModalProps> = ({ onClose, onOpenPrayer }) => {
  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/50 max-w-2xl w-full rounded-3xl border border-amber-500/30 shadow-2xl p-6 sm:p-8 space-y-6 relative overflow-hidden">
        {/* Background glow */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-amber-300 transition-colors border border-amber-500/20 z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Profile Card Header */}
        <div className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6 relative z-10">
          <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl overflow-hidden border-2 border-amber-400 shadow-2xl flex-shrink-0">
            <img
              src={ASSETS.prophetPortrait}
              alt="Prophet JUHNKRIX SYNVAGORD"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>

          <div className="text-center sm:text-left space-y-1">
            <span className="text-[10px] font-bold tracking-widest text-amber-400 uppercase bg-amber-500/20 px-3 py-1 rounded-full border border-amber-400/30 inline-block">
              GLOBAL PROPHETIC VOICE
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold font-serif text-amber-100">
              Prophet JUHNKRIX SYNVAGORD
            </h2>
            <p className="text-xs text-amber-300/80 font-medium">
              Founder & Anointed Vessel • JUHNKRIX MUSIKA Global
            </p>
          </div>
        </div>

        {/* Bio Details */}
        <div className="space-y-4 text-xs sm:text-sm text-slate-300 leading-relaxed font-sans relative z-10">
          <p>
            Prophet JUHNKRIX SYNVAGORD is a globally recognized spiritual leader, psalm composer, and prophetic teacher called to ignite spiritual revival and bring freedom to nations through anointed gospel praises, soaking frequency soundscapes, and uncompromising biblical truth.
          </p>

          <p>
            With millions of believers tuning into his daily prophetic devotionals and live night services, JUHNKRIX MUSIKA stands as the world&apos;s premier sanctuary for spiritual empowerment, divine healing, and contemplative communion with God.
          </p>
        </div>

        {/* Calling Highlights */}
        <div className="grid grid-cols-2 gap-3 relative z-10">
          <div className="bg-slate-950/80 p-3.5 rounded-2xl border border-amber-500/20 space-y-1">
            <Globe className="w-4 h-4 text-amber-400" />
            <h4 className="text-xs font-bold text-amber-100">Global Outreach</h4>
            <p className="text-[10px] text-slate-400">Broadcasting to over 120+ nations daily.</p>
          </div>

          <div className="bg-slate-950/80 p-3.5 rounded-2xl border border-amber-500/20 space-y-1">
            <Flame className="w-4 h-4 text-amber-400" />
            <h4 className="text-xs font-bold text-amber-100">528Hz Soaking Frequencies</h4>
            <p className="text-[10px] text-slate-400">Harmonically engineered gospel instrumentals.</p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end space-x-3 pt-2 relative z-10">
          <button
            onClick={() => {
              onClose();
              onOpenPrayer();
            }}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-600 text-slate-950 font-bold text-xs flex items-center space-x-2 shadow-lg shadow-amber-500/20 hover:scale-105 transition-all"
          >
            <HeartHandshake className="w-4 h-4 text-slate-950" />
            <span>Send Personal Prayer Petition</span>
          </button>
        </div>
      </div>
    </div>
  );
};
