import { Film, Image as ImageIcon, Trash2, UserRound } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useVault, type MediaMeta } from "@/store/vault";

function Thumb({ item, onOpen }: { item: MediaMeta; onOpen: () => void }) {
  const getBlob = useVault((s) => s.getBlob);
  const [url, setUrl] = useState<string | null>(null);

  useEffect(() => {
    let revoke: string | null = null;
    let alive = true;
    getBlob(item.id).then((got) => {
      if (!alive || !got) return;
      const blob = got.thumb ?? (item.kind !== "video" ? got.blob : null);
      if (!blob) return;
      revoke = URL.createObjectURL(blob);
      setUrl(revoke);
    });
    return () => {
      alive = false;
      if (revoke) URL.revokeObjectURL(revoke);
    };
  }, [getBlob, item.id, item.kind]);

  return (
    <button
      type="button"
      onClick={onOpen}
      className="group relative aspect-square overflow-hidden rounded-md bg-card text-left shadow-[var(--shadow-border)]"
    >
      {url ? (
        <img src={url} alt="" className="h-full w-full object-cover" />
      ) : (
        <div className="flex h-full w-full items-center justify-center text-muted-foreground">
          {item.kind === "video" ? <Film className="size-6" /> : <ImageIcon className="size-6" />}
        </div>
      )}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink/70 to-transparent opacity-80" />
      <span className="absolute bottom-1.5 left-1.5 right-1.5 truncate text-xs text-paper">
        {item.name}
      </span>
      {item.kind === "video" ? (
        <span className="absolute left-1.5 top-1.5 rounded-full bg-ink/70 px-1.5 py-0.5 text-xs uppercase tracking-wide text-ivory">
          Video
        </span>
      ) : item.kind === "gif" ? (
        <span className="absolute left-1.5 top-1.5 rounded-full bg-ink/70 px-1.5 py-0.5 text-xs uppercase tracking-wide text-ivory">
          GIF
        </span>
      ) : null}
    </button>
  );
}

export function MediaGrid({
  items,
  onOpen,
  onDelete,
  onAssign,
  emptyTitle = "Nothing filed yet",
  emptyBody = "Add videos, photos, or GIFs. Names like angela.white.mp4 file themselves.",
}: {
  items: MediaMeta[];
  onOpen: (item: MediaMeta) => void;
  onDelete?: (item: MediaMeta) => void;
  onAssign?: (item: MediaMeta) => void;
  emptyTitle?: string;
  emptyBody?: string;
}) {
  if (items.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-border px-6 py-16 text-center">
        <p className="font-display text-2xl">{emptyTitle}</p>
        <p className="mt-2 text-sm text-muted-foreground">{emptyBody}</p>
      </div>
    );
  }

  return (
    <ul className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4">
      {items.map((item) => (
        <li key={item.id} className="relative">
          <Thumb item={item} onOpen={() => onOpen(item)} />
          <div className="absolute right-1 top-1 flex flex-col gap-1">
            {onAssign ? (
              <Button
                size="icon"
                variant="ghost"
                className={cn("size-9 bg-ink/50 text-paper hover:bg-ink/80")}
                onClick={(e) => {
                  e.stopPropagation();
                  onAssign(item);
                }}
                aria-label={`Assign ${item.name}`}
              >
                <UserRound className="size-3.5" />
              </Button>
            ) : null}
            {onDelete ? (
              <Button
                size="icon"
                variant="ghost"
                className={cn("size-9 bg-ink/50 text-paper hover:bg-ink/80")}
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(item);
                }}
                aria-label={`Delete ${item.name}`}
              >
                <Trash2 className="size-3.5" />
              </Button>
            ) : null}
          </div>
        </li>
      ))}
    </ul>
  );
}
