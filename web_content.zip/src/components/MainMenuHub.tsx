import React from 'react';
import {
  FileText,
  Wrench,
  Layers,
  Images,
  Database,
  Share2,
  Plus,
  ArrowRight,
  Sparkles,
  Smartphone,
  CheckCircle2,
  Calendar,
  Clock,
  ShieldCheck,
  ChevronRight,
  TrendingUp,
  FileSpreadsheet,
  Download
} from 'lucide-react';
import { PaintingReport, MaintenanceReport, ProcedureReport } from '../types/domain';

interface Props {
  paintingReports: PaintingReport[];
  maintenanceReports: MaintenanceReport[];
  procedureReports: ProcedureReport[];
  onSelectView: (view: 'painting' | 'manutenzioni' | 'procedure' | 'galleria') => void;
  onNewPaintingReport: () => void;
  onNewMaintenance: () => void;
  onNewProcedure: () => void;
  onOpenBackup: () => void;
  onQuickShareLastReport: () => void;
}

export const MainMenuHub: React.FC<Props> = ({
  paintingReports,
  maintenanceReports,
  procedureReports,
  onSelectView,
  onNewPaintingReport,
  onNewMaintenance,
  onNewProcedure,
  onOpenBackup,
  onQuickShareLastReport
}) => {
  const totalPaintingPhotos = paintingReports.reduce((acc, r) => acc + (r.images ? r.images.length : 0), 0);
  const totalMaintPhotos = maintenanceReports.reduce((acc, r) => acc + (r.images ? r.images.length : 0), 0);
  const totalProcPhotos = procedureReports.reduce(
    (acc, r) => acc + (r.steps ? r.steps.reduce((sAcc, s) => sAcc + (s.images ? s.images.length : 0), 0) : 0),
    0
  );
  const totalPhotos = totalPaintingPhotos + totalMaintPhotos + totalProcPhotos;

  const todayStr = new Date().toLocaleDateString('it-IT', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });

  return (
    <div className="w-full max-w-xl mx-auto space-y-5 animate-in fade-in duration-200 pb-12">
      {/* Google Pixel 9 Header Card */}
      <div className="relative overflow-hidden bg-gradient-to-br from-neutral-900 via-neutral-900 to-neutral-800 text-white rounded-3xl p-5 sm:p-6 shadow-xl border border-neutral-700">
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-neutral-800/90 text-amber-300 text-[11px] font-mono border border-neutral-700">
              <Smartphone className="w-3.5 h-3.5" />
              <span className="font-semibold">Ottimizzato Google Pixel 9</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight pt-1">
              SFILLER
            </h1>
            <p className="text-xs sm:text-sm text-neutral-300 font-medium">
              Sabbiatura & Verniciatura a Liquido · Hub Operativo
            </p>
          </div>

          <div className="text-right">
            <span className="text-[11px] text-neutral-400 font-mono block capitalize">{todayStr}</span>
            <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400 font-mono mt-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              Attivo
            </span>
          </div>
        </div>

        {/* Quick KPI Overview Tiles for Pixel 9 */}
        <div className="grid grid-cols-3 gap-2 mt-5 pt-4 border-t border-neutral-800 text-center">
          <div className="bg-neutral-800/60 rounded-2xl p-2.5 border border-neutral-700/60">
            <span className="text-lg sm:text-xl font-bold font-mono text-white block">
              {paintingReports.length}
            </span>
            <span className="text-[10px] font-medium text-neutral-400 block truncate">
              Painting Rep.
            </span>
          </div>

          <div className="bg-neutral-800/60 rounded-2xl p-2.5 border border-neutral-700/60">
            <span className="text-lg sm:text-xl font-bold font-mono text-white block">
              {maintenanceReports.length}
            </span>
            <span className="text-[10px] font-medium text-neutral-400 block truncate">
              Manutenzioni
            </span>
          </div>

          <div className="bg-neutral-800/60 rounded-2xl p-2.5 border border-neutral-700/60">
            <span className="text-lg sm:text-xl font-bold font-mono text-white block">
              {procedureReports.length}
            </span>
            <span className="text-[10px] font-medium text-neutral-400 block truncate">
              Schede Libere
            </span>
          </div>
        </div>

        {/* Quick Condividi Banner on Main Menu */}
        <div className="mt-4 pt-3 border-t border-neutral-800/80 flex items-center justify-between gap-2">
          <span className="text-[11px] text-neutral-300 font-medium truncate">
            Condividi velocemente documenti su WhatsApp
          </span>
          <button
            onClick={onQuickShareLastReport}
            className="shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Condividi File</span>
          </button>
        </div>
      </div>

      {/* Main Menu Section Title */}
      <div className="px-1 flex items-center justify-between">
        <h2 className="text-xs font-bold uppercase tracking-wider text-neutral-500 font-mono">
          Seleziona Area di Lavoro
        </h2>
        <span className="text-[11px] text-neutral-400 font-mono">Schermo Intero</span>
      </div>

      {/* 4 Large Operative Cards */}
      <div className="space-y-3.5">
        {/* CARD 1: PAINTING REPORT (MOD. RV-U) */}
        <div className="bg-white rounded-3xl p-4 sm:p-5 border border-neutral-200/90 shadow-sm hover:shadow-md transition-all active:scale-[0.99] flex flex-col justify-between group">
          <div
            onClick={() => onSelectView('painting')}
            className="cursor-pointer space-y-2.5"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-neutral-900 text-white flex items-center justify-center shrink-0 shadow-sm group-hover:bg-neutral-800 transition-colors">
                  <FileText className="w-6 h-6 text-amber-400" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-extrabold text-neutral-900 tracking-tight">
                      Painting Reports
                    </h3>
                    <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 font-mono text-[10px] font-bold border border-amber-200">
                      MOD. RV-U
                    </span>
                  </div>
                  <p className="text-xs text-neutral-500 font-medium">
                    Verniciatura a Liquido & Sabbiatura
                  </p>
                </div>
              </div>

              <div className="w-9 h-9 rounded-2xl bg-neutral-100 group-hover:bg-neutral-900 group-hover:text-white text-neutral-600 flex items-center justify-center shrink-0 transition-colors">
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>

            <p className="text-xs text-neutral-600 leading-relaxed">
              Punto di rugiada automatico, parametri pompa airless, misurazione spessori DFT, foto reportage e conformità norme ISO.
            </p>

            <div className="flex flex-wrap gap-1.5 pt-1 text-[11px] font-medium text-neutral-600">
              <span className="px-2 py-0.5 rounded-lg bg-neutral-100 text-neutral-700">📄 PDF A4</span>
              <span className="px-2 py-0.5 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200">📊 Excel (.xls)</span>
              <span className="px-2 py-0.5 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200">💬 WhatsApp</span>
              <span className="px-2 py-0.5 rounded-lg bg-neutral-100 text-neutral-700 font-mono font-bold">
                {paintingReports.length} archiviati
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 mt-4 pt-3 border-t border-neutral-100">
            <button
              onClick={() => onSelectView('painting')}
              className="flex-1 py-2.5 px-3 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all"
            >
              <span>Apri Sezione Schermo Intero</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onNewPaintingReport}
              title="Crea Subito un Nuovo Painting Report"
              className="p-2.5 bg-neutral-100 hover:bg-neutral-200 active:bg-neutral-300 text-neutral-900 rounded-xl transition-all"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* CARD 2: MANUTENZIONI IMPIANTI */}
        <div className="bg-white rounded-3xl p-4 sm:p-5 border border-neutral-200/90 shadow-sm hover:shadow-md transition-all active:scale-[0.99] flex flex-col justify-between group">
          <div
            onClick={() => onSelectView('manutenzioni')}
            className="cursor-pointer space-y-2.5"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-neutral-900 text-white flex items-center justify-center shrink-0 shadow-sm group-hover:bg-neutral-800 transition-colors">
                  <Wrench className="w-6 h-6 text-sky-400" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-extrabold text-neutral-900 tracking-tight">
                      Manutenzioni Impianti
                    </h3>
                    <span className="px-2 py-0.5 rounded-md bg-sky-100 text-sky-900 font-mono text-[10px] font-bold border border-sky-200">
                      7 Linee
                    </span>
                  </div>
                  <p className="text-xs text-neutral-500 font-medium">
                    Registro Interventi & Manutenzioni
                  </p>
                </div>
              </div>

              <div className="w-9 h-9 rounded-2xl bg-neutral-100 group-hover:bg-neutral-900 group-hover:text-white text-neutral-600 flex items-center justify-center shrink-0 transition-colors">
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>

            <p className="text-xs text-neutral-600 leading-relaxed">
              LINEA 1, 2, 3, 4, 6, POLIN, ALTRO · Campo descrittivo "Attrezzatura revisionata", ricambi impiegati, ore fermo macchina e verbali di collaudo.
            </p>

            <div className="flex flex-wrap gap-1.5 pt-1 text-[11px] font-medium text-neutral-600">
              <span className="px-2 py-0.5 rounded-lg bg-sky-50 text-sky-800 border border-sky-200">🏭 Combobox Impianti</span>
              <span className="px-2 py-0.5 rounded-lg bg-neutral-100 text-neutral-700">⚙️ Attrezzatura Rev.</span>
              <span className="px-2 py-0.5 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200">💬 WhatsApp</span>
              <span className="px-2 py-0.5 rounded-lg bg-neutral-100 text-neutral-700 font-mono font-bold">
                {maintenanceReports.length} interventi
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 mt-4 pt-3 border-t border-neutral-100">
            <button
              onClick={() => onSelectView('manutenzioni')}
              className="flex-1 py-2.5 px-3 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all"
            >
              <span>Apri Sezione Schermo Intero</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onNewMaintenance}
              title="Registra Nuova Manutenzione"
              className="p-2.5 bg-neutral-100 hover:bg-neutral-200 active:bg-neutral-300 text-neutral-900 rounded-xl transition-all"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* CARD 3: PROCEDURE & SCHEDE LIBERE (COMPOSITORE BLOCCHI) */}
        <div className="bg-white rounded-3xl p-4 sm:p-5 border border-neutral-200/90 shadow-sm hover:shadow-md transition-all active:scale-[0.99] flex flex-col justify-between group">
          <div
            onClick={() => onSelectView('procedure')}
            className="cursor-pointer space-y-2.5"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-neutral-900 text-white flex items-center justify-center shrink-0 shadow-sm group-hover:bg-neutral-800 transition-colors">
                  <Layers className="w-6 h-6 text-emerald-400" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-extrabold text-neutral-900 tracking-tight">
                      Procedure & Schede Libere
                    </h3>
                    <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-900 font-mono text-[10px] font-bold border border-emerald-200">
                      Libero
                    </span>
                  </div>
                  <p className="text-xs text-neutral-500 font-medium">
                    Compositore: Titoli, Foto, Didascalie, Firme Touch
                  </p>
                </div>
              </div>

              <div className="w-9 h-9 rounded-2xl bg-neutral-100 group-hover:bg-neutral-900 group-hover:text-white text-neutral-600 flex items-center justify-center shrink-0 transition-colors">
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>

            <p className="text-xs text-neutral-600 leading-relaxed">
              Componi schede e procedure completamente personalizzate con i 4 campi componibili: Titolo, Foto con didascalia, Testo libero e Firma con il dito su touchscreen. Nell'ordine e quantità che vuoi!
            </p>

            <div className="flex flex-wrap gap-1.5 pt-1 text-[11px] font-medium text-neutral-600">
              <span className="px-2 py-0.5 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200">✍️ Firma col Dito</span>
              <span className="px-2 py-0.5 rounded-lg bg-sky-50 text-sky-800 border border-sky-200">📸 Foto & Didascalia</span>
              <span className="px-2 py-0.5 rounded-lg bg-neutral-100 text-neutral-700">📝 Campi Liberi</span>
              <span className="px-2 py-0.5 rounded-lg bg-neutral-100 text-neutral-700 font-mono font-bold">
                {procedureReports.length} schede
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 mt-4 pt-3 border-t border-neutral-100">
            <button
              onClick={() => onSelectView('procedure')}
              className="flex-1 py-2.5 px-3 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all"
            >
              <span>Apri Elenco Schede Libere</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onNewProcedure}
              title="Crea Nuova Scheda Libera"
              className="p-2.5 bg-neutral-100 hover:bg-neutral-200 active:bg-neutral-300 text-neutral-900 rounded-xl transition-all"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* CARD 4: ARCHIVIO FOTOGRAFICO UNIFICATO */}
        <div className="bg-white rounded-3xl p-4 sm:p-5 border border-neutral-200/90 shadow-sm hover:shadow-md transition-all active:scale-[0.99] flex flex-col justify-between group">
          <div
            onClick={() => onSelectView('galleria')}
            className="cursor-pointer space-y-2.5"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-neutral-900 text-white flex items-center justify-center shrink-0 shadow-sm group-hover:bg-neutral-800 transition-colors">
                  <Images className="w-6 h-6 text-purple-400" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-extrabold text-neutral-900 tracking-tight">
                      Archivio Fotografico
                    </h3>
                    <span className="px-2 py-0.5 rounded-md bg-purple-100 text-purple-900 font-mono text-[10px] font-bold border border-purple-200">
                      {totalPhotos} Foto
                    </span>
                  </div>
                  <p className="text-xs text-neutral-500 font-medium">
                    Tutte le immagini di sabbiatura, verniciatura e interventi
                  </p>
                </div>
              </div>

              <div className="w-9 h-9 rounded-2xl bg-neutral-100 group-hover:bg-neutral-900 group-hover:text-white text-neutral-600 flex items-center justify-center shrink-0 transition-colors">
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>

            <p className="text-xs text-neutral-600 leading-relaxed">
              Galleria globale con filtro per tipologia lavorazione, ricerca per commessa o impianto, e visualizzazione ad alta risoluzione a schermo intero.
            </p>

            <div className="flex flex-wrap gap-1.5 pt-1 text-[11px] font-medium text-neutral-600">
              <span className="px-2 py-0.5 rounded-lg bg-neutral-100 text-neutral-700">🔍 Ricerca veloce</span>
              <span className="px-2 py-0.5 rounded-lg bg-neutral-100 text-neutral-700">🔍 Zoom HD</span>
              <span className="px-2 py-0.5 rounded-lg bg-neutral-100 text-neutral-700 font-mono font-bold">
                {totalPhotos} immagini totali
              </span>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-neutral-100">
            <button
              onClick={() => onSelectView('galleria')}
              className="w-full py-2.5 px-3 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all"
            >
              <span>Esplora Foto Schermo Intero</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* CARD 5: DATABASE & BACKUP UTILITY */}
        <div className="bg-neutral-100/80 rounded-2xl p-4 border border-neutral-200 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white border border-neutral-200 flex items-center justify-center text-neutral-700 shadow-xs">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-neutral-900">
                Database, Excel & Backup
              </h4>
              <p className="text-[11px] text-neutral-500">
                Esporta tutti i dati in Excel/CSV, salva o ripristina
              </p>
            </div>
          </div>

          <button
            onClick={onOpenBackup}
            className="px-3 py-2 bg-white hover:bg-neutral-50 active:bg-neutral-200 border border-neutral-300 text-neutral-900 rounded-xl text-xs font-bold transition-all shadow-xs shrink-0"
          >
            Gestisci Dati
          </button>
        </div>
      </div>

      {/* Footer Info specifically for Google Pixel 9 */}
      <div className="text-center pt-2 space-y-1">
        <p className="text-[11px] text-neutral-400 font-mono">
          Google Pixel 9 Display 412x924 · Web Share API &middot; v3.2
        </p>
        <p className="text-[10px] text-neutral-400">
          Tocca qualsiasi card per aprire la sezione a tutto schermo. Puoi tornare al menù in qualsiasi momento.
        </p>
      </div>
    </div>
  );
};
