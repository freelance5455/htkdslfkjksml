import React, { useState } from 'react';
import { SubjectCategory, Topic } from '../types';
import { X, BookPlus, Sparkles, Plus, AlertCircle } from 'lucide-react';
import { getInitialNextReviewDate } from '../utils/spacedRepetition';

interface AddTopicModalProps {
  isOpen: boolean;
  categories: SubjectCategory[];
  onClose: () => void;
  onAddTopic: (topic: Omit<Topic, 'id'>) => void;
  onOpenCategoryManager: () => void;
  onAddCategory?: (category: SubjectCategory) => void;
}

export const AddTopicModal: React.FC<AddTopicModalProps> = ({
  isOpen,
  categories,
  onClose,
  onAddTopic,
  onOpenCategoryManager,
  onAddCategory,
}) => {
  const [title, setTitle] = useState('');
  const [categoryId, setCategoryId] = useState(categories[0]?.id || 'cs');
  const [notes, setNotes] = useState('');
  const [conceptInput, setConceptInput] = useState('');
  const [keyConcepts, setKeyConcepts] = useState<string[]>([]);
  const [autoGenerateInitialCards, setAutoGenerateInitialCards] = useState(true);

  // Inline quick subject creation state
  const [isQuickAddingSubject, setIsQuickAddingSubject] = useState(false);
  const [newSubjectName, setNewSubjectName] = useState('');
  const [newSubjectColor, setNewSubjectColor] = useState('#0284c7');

  const handleCreateSubjectInline = () => {
    if (!newSubjectName.trim()) return;
    const newCat: SubjectCategory = {
      id: `cat-${Date.now()}`,
      name: newSubjectName.trim(),
      description: 'Custom subject discipline',
      color: newSubjectColor,
      iconName: 'Folder',
    };
    if (onAddCategory) {
      onAddCategory(newCat);
    }
    setCategoryId(newCat.id);
    setNewSubjectName('');
    setIsQuickAddingSubject(false);
  };

  if (!isOpen) return null;

  const handleAddConcept = () => {
    if (!conceptInput.trim()) return;
    if (!keyConcepts.includes(conceptInput.trim())) {
      setKeyConcepts([...keyConcepts, conceptInput.trim()]);
    }
    setConceptInput('');
  };

  const handleRemoveConcept = (concept: string) => {
    setKeyConcepts(keyConcepts.filter((c) => c !== concept));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const initialNextDate = getInitialNextReviewDate(new Date());

    // Generate starter flashcards if requested
    const initialFlashcards = [];
    if (autoGenerateInitialCards) {
      if (keyConcepts.length > 0) {
        keyConcepts.forEach((concept, i) => {
          initialFlashcards.push({
            id: `fc-${Date.now()}-${i}`,
            topicId: '',
            front: `Explain the concept: "${concept}" in relation to ${title.trim()}`,
            back: `Key notes: ${notes.slice(0, 150) || 'Core foundational component.'}`,
            hint: `Foundational term for ${title.trim()}`,
            createdAt: new Date().toISOString(),
            reviewCount: 0,
            ratingHistory: [],
          });
        });
      }

      if (notes.trim()) {
        initialFlashcards.push({
          id: `fc-${Date.now()}-core`,
          topicId: '',
          front: `What are the primary mechanisms or principles of ${title.trim()}?`,
          back: notes.trim(),
          hint: 'Summary of your primary study notes.',
          createdAt: new Date().toISOString(),
          reviewCount: 0,
          ratingHistory: [],
        });
      }
    }

    onAddTopic({
      title: title.trim(),
      categoryId,
      notes: notes.trim(),
      keyConcepts,
      createdAt: new Date().toISOString(),
      nextReviewDate: initialNextDate,
      stage: 0, // Starts at Day 0 (Review 1 scheduled for Day 1)
      masteryScore: 0,
      stability: 1.2,
      consecutiveSuccesses: 0,
      history: [],
      flashcards: initialFlashcards,
    });

    // Reset form
    setTitle('');
    setNotes('');
    setKeyConcepts([]);
    setConceptInput('');
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in"
      role="dialog"
      aria-modal="true"
      aria-labelledby="add-topic-title"
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-xl max-h-[90vh] flex flex-col shadow-xl overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <BookPlus className="w-5 h-5" />
            </div>
            <div>
              <h2 id="add-topic-title" className="text-base font-semibold text-slate-900 dark:text-slate-100">
                Register New Study Topic
              </h2>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                Scheduled for Day 1 milestone check-in to combat the forgetting curve
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg transition-colors"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 flex-1">
          {/* Topic Title */}
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Topic Title <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Action Potential & Voltage-Gated Ion Channels"
              className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Subject Category */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-medium text-slate-700 dark:text-slate-300">
                Subject Category <span className="text-rose-500">*</span>
              </label>
              <div className="flex items-center gap-2 text-[11px]">
                <button
                  type="button"
                  onClick={() => setIsQuickAddingSubject((prev) => !prev)}
                  className="text-indigo-600 dark:text-indigo-400 font-medium hover:underline flex items-center gap-1"
                >
                  <Plus className="w-3 h-3" />
                  <span>{isQuickAddingSubject ? 'Hide Form' : 'New Subject'}</span>
                </button>
                <span className="text-slate-300 dark:text-slate-700">·</span>
                <button
                  type="button"
                  onClick={onOpenCategoryManager}
                  className="text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:underline"
                >
                  Manage Subjects
                </button>
              </div>
            </div>

            {/* Quick Add Inline Subject Drawer */}
            {isQuickAddingSubject && (
              <div className="p-3 bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-800 rounded-xl space-y-2.5 animate-in fade-in">
                <div className="text-[11px] font-semibold text-slate-800 dark:text-slate-200">
                  Quick Add Subject
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newSubjectName}
                    onChange={(e) => setNewSubjectName(e.target.value)}
                    placeholder="e.g. Cognitive Psychology"
                    className="flex-1 px-2.5 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-indigo-500"
                  />
                  <button
                    type="button"
                    onClick={handleCreateSubjectInline}
                    className="px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors"
                  >
                    Create
                  </button>
                </div>
                <div className="flex items-center gap-1.5 pt-0.5">
                  <span className="text-[10px] text-slate-500 dark:text-slate-400">Color:</span>
                  {['#0284c7', '#f43f5e', '#10b981', '#6366f1', '#f59e0b', '#8b5cf6'].map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setNewSubjectColor(c)}
                      className={`w-5 h-5 rounded-full transition-transform ${newSubjectColor === c ? 'scale-125 ring-2 ring-indigo-500' : ''}`}
                      style={{ backgroundColor: c }}
                      aria-label={`Color ${c}`}
                    />
                  ))}
                </div>
              </div>
            )}

            <select
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
            >
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.name}
                </option>
              ))}
            </select>
          </div>

          {/* Key Concepts / Terms */}
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Key Concepts & Keywords
            </label>
            <div className="flex gap-2 mb-2">
              <input
                type="text"
                value={conceptInput}
                onChange={(e) => setConceptInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddConcept();
                  }
                }}
                placeholder="Type a concept and press Enter (e.g. Depolarization)"
                className="flex-1 px-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
              />
              <button
                type="button"
                onClick={handleAddConcept}
                className="px-3 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-lg transition-colors"
              >
                Add
              </button>
            </div>

            {keyConcepts.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {keyConcepts.map((c) => (
                  <span
                    key={c}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700"
                  >
                    <span>{c}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveConcept(c)}
                      className="text-slate-400 hover:text-rose-500"
                    >
                      &times;
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Notes / Core Material */}
          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
              Core Notes / Explanation
            </label>
            <textarea
              rows={4}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Paste your concise summary, definitions, formulas, or key mechanisms here..."
              className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Auto create flashcards checkbox */}
          <div className="p-3 bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40 rounded-xl flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="text-xs font-medium text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                Initialize Flashcards from Concepts & Notes
              </div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">
                Automatically drafts question & answer cards for rapid recall review
              </div>
            </div>
            <input
              type="checkbox"
              id="auto-cards"
              checked={autoGenerateInitialCards}
              onChange={(e) => setAutoGenerateInitialCards(e.target.checked)}
              className="w-4 h-4 text-indigo-600 rounded-sm border-slate-300 focus:ring-indigo-500"
            />
          </div>

          {/* Forgetting curve info reminder */}
          <div className="flex items-start gap-2 text-xs text-slate-500 dark:text-slate-400 pt-1">
            <AlertCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
            <span>
              This topic will be placed at <strong>Stage 0 (Day 0)</strong>. Its first milestone recall test is scheduled for tomorrow (Day 1), which arrests the steepest segment of the forgetting curve.
            </span>
          </div>

          {/* Modal Actions */}
          <div className="flex justify-end gap-2 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-medium text-white bg-slate-900 dark:bg-indigo-600 hover:bg-slate-800 dark:hover:bg-indigo-500 rounded-lg transition-colors shadow-xs"
            >
              Add Topic & Schedule Day 1
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
