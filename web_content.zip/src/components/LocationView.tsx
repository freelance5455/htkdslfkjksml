import React, { useState } from 'react';
import {
  ArrowLeftRight,
  Droplets,
  Hand,
  LogOut,
  MessageSquare,
  Utensils,
  Wrench,
} from 'lucide-react';
import {
  ALL_HABITAT_IDS,
  BOX_IDS,
  INTERACTION_MIN_AUTO_END_SEC,
  OUTSIDE_PEN_CAPACITY,
  PLAYER_ACTION_META,
  PUP_ADULT_AGE_SEC,
  formatDurationShort,
  formatLocationLabel,
  formatSimClock,
} from '../data/kennelConstants';
import { canMoveDogTo, isPup } from '../engine/simulation';
import {
  Dog,
  GameState,
  HabitatLocationId,
  LocationId,
  PlayerAction,
} from '../types/kennel';
import { DogPortrait } from './DogPortrait';

interface LocationViewProps {
  state: GameState;
  onEnterLocation: (loc: LocationId) => void;
  onPlaceFood: (loc: HabitatLocationId) => void;
  onPlaceWater: (loc: HabitatLocationId) => void;
  onMoveDog: (dogId: string, dest: HabitatLocationId) => void;
  onInitiateInteraction: (dogId: string) => void;
  onPlayerAction: (action: PlayerAction) => void;
  onRepairPenObject: (objectId: string) => void;
  onSelectDogJournal: (dogId: string) => void;
  onOpenFacility: () => void;
}

const ORDERED_ACTIONS: PlayerAction[] = [
  'offer_palm',
  'crouch',
  'look_away',
  'offer_kibble',
  'pet',
  'playful_wrestle',
  'eye_contact',
  'scold',
  'end_interaction',
];

export const LocationView: React.FC<LocationViewProps> = ({
  state,
  onEnterLocation,
  onPlaceFood,
  onPlaceWater,
  onMoveDog,
  onInitiateInteraction,
  onPlayerAction,
  onRepairPenObject,
  onSelectDogJournal,
  onOpenFacility,
}) => {
  const [movingDogId, setMovingDogId] = useState<string | null>(null);
  const loc = state.playerLocation;

  // Corridor / Outside view
  if (loc === 'corridor') {
    return (
      <div className="space-y-6">
        <section className="rounded-2xl bg-white border border-[#DFDBD0] p-6">
          <p className="text-xs font-medium text-[#5C584F]">Corridor · Neutral Ground</p>
          <h1 className="font-display text-2xl sm:text-3xl font-semibold text-[#1C1B18] mt-1">
            Outside Kennel Breezeway
          </h1>
          <p className="mt-2 text-sm text-[#4A463E] max-w-2xl leading-relaxed">
            You are standing outside the enclosures in the gravel breezeway. All boxes, the Outside Pen, and the Nursery continue running on their own—internal events remain hidden until you step inside or observe a stall from the facility map.
          </p>

          <div className="mt-5 flex flex-wrap gap-3">
            <button
              type="button"
              onClick={() => onEnterLocation('outside_pen')}
              className="min-h-[44px] px-4 py-2 text-sm font-semibold rounded-xl bg-[#1F4E3D] text-white hover:bg-[#173B2E] transition-colors cursor-pointer"
            >
              Enter Outside Pen ({state.dogs.filter((d) => d.location === 'outside_pen').length}/{OUTSIDE_PEN_CAPACITY})
            </button>
            <button
              type="button"
              onClick={() => onEnterLocation('nursery_pen')}
              className="min-h-[44px] px-4 py-2 text-sm font-medium rounded-xl border border-[#D8D3C6] bg-[#F7F5F0] text-[#1C1B18] hover:bg-[#EFECE4] transition-colors cursor-pointer"
            >
              Enter Nursery Pen ({state.dogs.filter((d) => d.location === 'nursery_pen').length})
            </button>
            <button
              type="button"
              onClick={onOpenFacility}
              className="min-h-[44px] px-4 py-2 text-sm font-medium rounded-xl border border-[#D8D3C6] text-[#1C1B18] hover:bg-[#EFECE4] transition-colors cursor-pointer"
            >
              Open 21-Box Facility Map
            </button>
          </div>
        </section>

        <section className="rounded-2xl bg-white border border-[#DFDBD0] p-5">
          <h2 className="font-display text-lg font-semibold text-[#1C1B18] mb-3">
            Quick Enter Occupied Boxes
          </h2>
          <div className="flex flex-wrap gap-2">
            {BOX_IDS.filter((b) => state.dogs.some((d) => d.location === b)).map((boxId) => {
              const occ = state.dogs.find((d) => d.location === boxId)!;
              return (
                <button
                  key={boxId}
                  type="button"
                  onClick={() => onEnterLocation(boxId)}
                  className="min-h-[44px] px-3.5 py-2 text-xs font-medium rounded-lg border border-[#D8D3C6] bg-[#F7F5F0] text-[#1C1B18] hover:bg-[#EFECE4] transition-colors cursor-pointer"
                >
                  {formatLocationLabel(boxId)} · {occ.name}
                </button>
              );
            })}
            {BOX_IDS.every((b) => !state.dogs.some((d) => d.location === b)) && (
              <p className="text-sm text-[#7A7467]">No dogs currently housed in Boxes 01–21.</p>
            )}
          </div>
        </section>
      </div>
    );
  }

  // Inside a Habitat (Box 01..21, Outside Pen, or Nursery Pen)
  const habitatLoc: HabitatLocationId = loc;
  const dogsHere = state.dogs.filter((d) => d.location === habitatLoc);
  const bowl = state.bowls[habitatLoc];
  // Strictly show ONLY logs occurring at player's current location (others remain hidden)
  const localLogs = state.logs
    .filter((l) => l.location === habitatLoc)
    .slice()
    .reverse();

  const activeInter =
    state.activeInteraction && state.activeInteraction.location === habitatLoc
      ? state.activeInteraction
      : null;
  const interDog = activeInter ? state.dogs.find((d) => d.id === activeInter.dogId) ?? null : null;
  const interElapsed = activeInter ? state.totalElapsedSec - activeInter.startedAtTotalSec : 0;

  return (
    <div className="space-y-6">
      {/* Location Header */}
      <section className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#DFDBD0]">
        <div>
          <p className="text-xs font-medium text-[#5C584F] font-mono-tabular">
            Inside Habitat · {dogsHere.length} {dogsHere.length === 1 ? 'Dog' : 'Dogs'} Present
            {habitatLoc === 'outside_pen' ? ` (Max ${OUTSIDE_PEN_CAPACITY})` : habitatLoc === 'nursery_pen' ? ' (Nursery)' : ' (Max 1)'}
          </p>
          <h1 className="font-display text-2xl sm:text-3xl font-semibold text-[#1C1B18] mt-0.5">
            {formatLocationLabel(habitatLoc)}
          </h1>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => onEnterLocation('corridor')}
            className="inline-flex items-center gap-1.5 min-h-[44px] px-3.5 py-2 text-xs font-medium rounded-lg border border-[#D8D3C6] bg-white text-[#1C1B18] hover:bg-[#EFECE4] transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Step Outside</span>
          </button>
          <button
            type="button"
            onClick={onOpenFacility}
            className="min-h-[44px] px-3.5 py-2 text-xs font-medium rounded-lg border border-[#D8D3C6] bg-white text-[#1C1B18] hover:bg-[#EFECE4] transition-colors cursor-pointer"
          >
            Switch Habitat
          </button>
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Bowls, Occupants, Pen Objects */}
        <div className="lg:col-span-5 space-y-5">
          {/* Food & Water Bowls (Only usable when inside!) */}
          <section className="rounded-2xl bg-white border border-[#DFDBD0] p-4 sm:p-5 space-y-4">
            <div className="flex items-baseline justify-between">
              <h2 className="font-display text-lg font-semibold text-[#1C1B18]">
                Habitat Bowls
              </h2>
              <span className="text-xs text-[#5C584F]">Reachable from inside</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-xl bg-[#F7F5F0] border border-[#E5E1D6] p-3">
                <div className="flex items-center justify-between text-xs text-[#5C584F]">
                  <span>Feed Bowl</span>
                  <span className="font-mono-tabular font-semibold text-[#1C1B18]">
                    {Math.round(bowl.food)}%
                  </span>
                </div>
                <div className="mt-2 h-2 rounded-full bg-[#DFDBD0] overflow-hidden">
                  <div
                    className="h-full bg-[#9A5B13] transition-all"
                    style={{ width: `${Math.round(bowl.food)}%` }}
                  />
                </div>
                <button
                  type="button"
                  onClick={() => onPlaceFood(habitatLoc)}
                  className="mt-3 w-full inline-flex items-center justify-center gap-1.5 min-h-[44px] px-3 py-2 text-xs font-semibold rounded-lg bg-[#1F4E3D] text-white hover:bg-[#173B2E] transition-colors cursor-pointer"
                >
                  <Utensils className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Place Food</span>
                </button>
              </div>

              <div className="rounded-xl bg-[#F7F5F0] border border-[#E5E1D6] p-3">
                <div className="flex items-center justify-between text-xs text-[#5C584F]">
                  <span>Water Bowl</span>
                  <span className="font-mono-tabular font-semibold text-[#1C1B18]">
                    {Math.round(bowl.water)}%
                  </span>
                </div>
                <div className="mt-2 h-2 rounded-full bg-[#DFDBD0] overflow-hidden">
                  <div
                    className="h-full bg-[#0E7490] transition-all"
                    style={{ width: `${Math.round(bowl.water)}%` }}
                  />
                </div>
                <button
                  type="button"
                  onClick={() => onPlaceWater(habitatLoc)}
                  className="mt-3 w-full inline-flex items-center justify-center gap-1.5 min-h-[44px] px-3 py-2 text-xs font-semibold rounded-lg bg-[#1F4E3D] text-white hover:bg-[#173B2E] transition-colors cursor-pointer"
                >
                  <Droplets className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Place Water</span>
                </button>
              </div>
            </div>
          </section>

          {/* Dogs Currently Here */}
          <section className="space-y-3">
            <h2 className="font-display text-lg font-semibold text-[#1C1B18]">
              Dogs in {formatLocationLabel(habitatLoc)}
            </h2>

            {dogsHere.length === 0 ? (
              <div className="rounded-2xl bg-white border border-[#DFDBD0] p-5 text-sm text-[#5C584F]">
                No dogs are currently housed in this space. Move a dog here from the Facility Map or acquire one from the Market.
              </div>
            ) : (
              dogsHere.map((dog: Dog) => {
                const pup = isPup(dog);
                const lifeLeft = Math.max(0, dog.lifespanSeconds - dog.ageSeconds);
                const isMovingThis = movingDogId === dog.id;

                return (
                  <div
                    key={dog.id}
                    className="rounded-2xl bg-white border border-[#DFDBD0] p-4 space-y-3"
                  >
                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-start">
                      <div className="sm:col-span-5">
                        <DogPortrait
                          name={dog.name}
                          genetics={dog.genetics}
                          isPup={pup}
                          compact
                        />
                      </div>
                      <div className="sm:col-span-7 space-y-1.5">
                        <div className="flex items-baseline justify-between gap-2">
                          <button
                            type="button"
                            onClick={() => onSelectDogJournal(dog.id)}
                            className="font-display text-lg font-semibold text-[#1C1B18] hover:underline text-left cursor-pointer"
                          >
                            {dog.name}
                          </button>
                          <span className="text-xs text-[#5C584F] font-mono-tabular capitalize">
                            {dog.gender} · {pup ? 'Pup' : 'Adult'}
                          </span>
                        </div>

                        <p className="text-xs text-[#5C584F] capitalize">
                          {dog.genetics.coat} · {dog.genetics.bodyType} ·{' '}
                          {pup
                            ? `Patternless pup (${dog.genetics.pattern} at 1h)`
                            : dog.genetics.pattern}
                        </p>

                        <p className="text-xs text-[#1C1B18] italic">
                          Currently {dog.currentBehavior}.
                        </p>

                        <div className="pt-1 grid grid-cols-2 gap-x-3 gap-y-1 text-[11px] text-[#4A463E] font-mono-tabular">
                          <span>Health: {Math.round(dog.stats.health)}%</span>
                          <span>Mood: {Math.round(dog.stats.mood)}%</span>
                          <span>Hunger: {Math.round(dog.stats.hunger)}%</span>
                          <span>Thirst: {Math.round(dog.stats.thirst)}%</span>
                          <span>Stress: {Math.round(dog.stats.stress)}%</span>
                          <span>
                            {pup
                              ? `Adult in: ${formatDurationShort(PUP_ADULT_AGE_SEC - dog.ageSeconds)}`
                              : `Life left: ${formatDurationShort(lifeLeft)}`}
                          </span>
                        </div>

                        {dog.pregnantRemainingSec !== null && (
                          <p className="text-xs font-medium text-[#1F4E3D] font-mono-tabular">
                            Pregnant · Birth in {formatDurationShort(dog.pregnantRemainingSec)}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-[#EFECE4]">
                      {(!activeInter || activeInter.dogId !== dog.id) && (
                        <button
                          type="button"
                          onClick={() => onInitiateInteraction(dog.id)}
                          className="inline-flex items-center gap-1.5 min-h-[44px] px-3.5 py-2 text-xs font-semibold rounded-lg bg-[#1F4E3D] text-white hover:bg-[#173B2E] transition-colors cursor-pointer"
                        >
                          <Hand className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>Approach Dog</span>
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => setMovingDogId(isMovingThis ? null : dog.id)}
                        className="inline-flex items-center gap-1.5 min-h-[44px] px-3.5 py-2 text-xs font-medium rounded-lg border border-[#D8D3C6] text-[#1C1B18] hover:bg-[#EFECE4] transition-colors cursor-pointer"
                      >
                        <ArrowLeftRight className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Move</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => onSelectDogJournal(dog.id)}
                        className="min-h-[44px] px-3 py-2 text-xs font-medium text-[#1F4E3D] hover:underline cursor-pointer"
                      >
                        Journal Profile
                      </button>
                    </div>

                    {isMovingThis && (
                      <div className="pt-3 border-t border-[#EFECE4] space-y-2">
                        <p className="text-xs font-medium text-[#5C584F]">
                          Choose destination box or pen:
                        </p>
                        <div className="flex flex-wrap gap-1.5 max-h-40 overflow-y-auto">
                          {ALL_HABITAT_IDS.map((dest) => {
                            const check = canMoveDogTo(state.dogs, dog, dest);
                            if (!check.ok) return null;
                            return (
                              <button
                                key={dest}
                                type="button"
                                onClick={() => {
                                  onMoveDog(dog.id, dest);
                                  setMovingDogId(null);
                                }}
                                className="min-h-[36px] px-2.5 py-1 text-xs rounded-lg border border-[#D8D3C6] bg-[#F7F5F0] text-[#1C1B18] hover:bg-[#1F4E3D] hover:text-white transition-colors cursor-pointer"
                              >
                                {formatLocationLabel(dest)}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </section>

          {/* Space Objects inside Outside Pen */}
          {habitatLoc === 'outside_pen' && (
            <section className="rounded-2xl bg-white border border-[#DFDBD0] p-4 sm:p-5 space-y-3">
              <div className="flex items-baseline justify-between">
                <h2 className="font-display text-lg font-semibold text-[#1C1B18]">
                  Pen Space Objects
                </h2>
                <span className="text-xs text-[#5C584F]">Enrichment &amp; wear</span>
              </div>
              <div className="divide-y divide-[#EFECE4]">
                {state.penObjects.map((obj) => (
                  <div key={obj.id} className="py-2.5 flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-baseline gap-2">
                        <span className="text-sm font-medium text-[#1C1B18]">{obj.name}</span>
                        <span className="font-mono-tabular text-xs text-[#5C584F]">
                          {Math.round(obj.condition)}%
                        </span>
                      </div>
                      <p className="text-xs text-[#5C584F] mt-0.5">{obj.lastInteractedText}</p>
                    </div>
                    {obj.condition < 90 && (
                      <button
                        type="button"
                        onClick={() => onRepairPenObject(obj.id)}
                        className="inline-flex items-center gap-1 min-h-[38px] px-2.5 py-1 text-xs font-medium rounded-lg border border-[#D8D3C6] text-[#1C1B18] hover:bg-[#EFECE4] shrink-0 cursor-pointer"
                      >
                        <Wrench className="w-3 h-3" aria-hidden="true" />
                        <span>Repair</span>
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>

        {/* Right Column: Active Dog-to-Player Interaction + Live Text Feed */}
        <div className="lg:col-span-7 space-y-5">
          {/* Active Encounter Panel */}
          {activeInter && interDog && (
            <section className="rounded-2xl bg-white border border-[#1F4E3D]/40 p-4 sm:p-5 space-y-4">
              <div className="flex flex-wrap items-start justify-between gap-3 pb-3 border-b border-[#EFECE4]">
                <div>
                  <p className="text-xs font-semibold text-[#1F4E3D] capitalize">
                    Active Interaction · Reason: {activeInter.reason}
                  </p>
                  <h2 className="font-display text-xl font-semibold text-[#1C1B18] mt-0.5">
                    {interDog.name} has stepped into your space
                  </h2>
                </div>
                <div className="text-right font-mono-tabular text-xs text-[#5C584F]">
                  <div>Elapsed: {formatDurationShort(interElapsed)}</div>
                  <div className="text-[11px]">
                    {interElapsed >= INTERACTION_MIN_AUTO_END_SEC
                      ? 'May depart on own if bored/uneasy'
                      : `Stays engaged until ${INTERACTION_MIN_AUTO_END_SEC}s`}
                  </div>
                </div>
              </div>

              {/* Relationship Breakdown */}
              <div className="grid grid-cols-5 gap-2 text-center bg-[#F7F5F0] rounded-xl p-2.5 border border-[#E5E1D6]">
                {[
                  { label: 'Trust', val: interDog.playerRel.trust },
                  { label: 'Curiosity', val: interDog.playerRel.curiosity },
                  { label: 'Fear', val: interDog.playerRel.fear },
                  { label: 'Anger', val: interDog.playerRel.anger },
                  { label: 'Stress', val: interDog.playerRel.stress },
                ].map((m) => (
                  <div key={m.label}>
                    <div className="text-[11px] text-[#5C584F]">{m.label}</div>
                    <div className="font-mono-tabular text-sm font-semibold text-[#1C1B18]">
                      {Math.round(m.val)}
                    </div>
                  </div>
                ))}
              </div>

              {/* Encounter Transcript */}
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {activeInter.history.map((item) => (
                  <div
                    key={item.id}
                    className={`text-sm leading-relaxed py-1.5 px-3 rounded-xl ${
                      item.actor === 'player'
                        ? 'bg-[#EFECE4] text-[#1C1B18]'
                        : 'bg-[#F7F5F0] text-[#1C1B18]'
                    }`}
                  >
                    <span className="font-mono-tabular text-[11px] text-[#7A7467] mr-2">
                      {item.timeStr}
                    </span>
                    <span className="font-semibold text-xs mr-1.5">
                      {item.actor === 'player' ? 'You:' : `${interDog.name}:`}
                    </span>
                    <span>{item.text}</span>
                  </div>
                ))}
              </div>

              {/* 9 Player Actions */}
              <div className="pt-2 border-t border-[#EFECE4]">
                <p className="text-xs text-[#5C584F] mb-2">
                  Choose a handler response (or pause to watch how {interDog.name} continues):
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {ORDERED_ACTIONS.map((action) => {
                    const meta = PLAYER_ACTION_META[action];
                    const isEnd = action === 'end_interaction';
                    return (
                      <button
                        key={action}
                        type="button"
                        onClick={() => onPlayerAction(action)}
                        title={meta.hint}
                        className={`min-h-[44px] px-3 py-2 text-xs font-semibold rounded-xl text-left transition-colors cursor-pointer ${
                          isEnd
                            ? 'border border-[#D8D3C6] bg-[#F7F5F0] text-[#5C584F] hover:bg-[#EFECE4]'
                            : 'border border-[#D8D3C6] bg-white text-[#1C1B18] hover:border-[#1F4E3D] hover:bg-[#1F4E3D] hover:text-white'
                        }`}
                      >
                        <div className="truncate">{meta.label}</div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </section>
          )}

          {/* Location Text Feed (Chronicle) */}
          <section className="rounded-2xl bg-white border border-[#DFDBD0] p-4 sm:p-5">
            <div className="flex items-baseline justify-between gap-4 pb-3 border-b border-[#EFECE4]">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-[#1F4E3D]" aria-hidden="true" />
                <h2 className="font-display text-lg font-semibold text-[#1C1B18]">
                  Live Field Log · {formatLocationLabel(habitatLoc)}
                </h2>
              </div>
              <span className="text-xs text-[#7A7467]">
                Old entries auto-delete
              </span>
            </div>

            {localLogs.length === 0 ? (
              <p className="py-8 text-sm text-[#5C584F] text-center">
                Quiet for the moment. Observations appear here as dogs eat, patrol, or interact in this habitat.
              </p>
            ) : (
              <ol className="divide-y divide-[#EFECE4] max-h-[540px] overflow-y-auto pr-1">
                {localLogs.map((entry) => (
                  <li key={entry.id} className="py-3 text-sm leading-relaxed text-[#1C1B18]">
                    <div className="flex items-center gap-2 text-[11px] text-[#7A7467] mb-0.5">
                      <span className="font-mono-tabular">{formatSimClock(entry.simTimeSec)}</span>
                      <span aria-hidden="true">·</span>
                      <span className="capitalize font-medium text-[#5C584F]">{entry.category}</span>
                    </div>
                    <p>{entry.text}</p>
                  </li>
                ))}
              </ol>
            )}
          </section>
        </div>
      </div>
    </div>
  );
};
