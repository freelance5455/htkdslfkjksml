import React, { useState, useEffect } from 'react';
import { Sparkles, Flame, BookOpen, RefreshCw } from 'lucide-react';

interface PropheticWordData {
  title: string;
  scripture: string;
  rhema: string;
  prophetNote: string;
}

export const PropheticWordCard: React.FC = () => {
  const [word, setWord] = useState<PropheticWordData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const fetchWord = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/prophetic-word');
      const data = await res.json();
      setWord(data);
    } catch (e) {
      setWord({
        title: "The Season of Divine Acceleration",
        scripture: "Amos 9:13 - 'The days are coming, declares the Lord, when the reaper will be overtaken by the plowman.'",
        rhema: "God is compressing years of struggle into moments of supernatural breakthrough. Step out in bold faith today.",
        prophetNote: "Prophet Juhnkrix Musika"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWord();
  }, []);

  if (loading) {
    return (
      <div className="bg-gradient-to-r from-amber-950/60 via-slate-900 to-slate-950 p-6 rounded-3xl border border-amber-500/30 text-center space-y-2 animate-pulse">
        <Sparkles className="w-6 h-6 text-amber-400 animate-spin mx-auto" />
        <p className="text-xs text-amber-300">Receiving Daily Prophetic Rhema Word...</p>
      </div>
    );
  }

  if (!word) return null;

  return (
    <div className="bg-gradient-to-r from-amber-950/80 via-slate-900 to-purple-950/60 p-6 sm:p-8 rounded-3xl border border-amber-500/40 shadow-2xl space-y-4 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="flex items-center justify-between relative z-10">
        <div className="inline-flex items-center space-x-2 px-3.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-bold font-mono">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>DAILY PROPHETIC RHEMA WORD</span>
        </div>
        <button
          onClick={fetchWord}
          className="p-2 rounded-xl bg-slate-950/80 text-amber-300 hover:text-amber-100 border border-amber-500/30 transition-all flex items-center space-x-1 text-xs font-bold"
          title="Refresh Prophetic Word"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Refresh Word</span>
        </button>
      </div>

      <div className="space-y-3 relative z-10">
        <h3 className="text-xl sm:text-2xl font-extrabold font-serif text-amber-100">
          {word.title}
        </h3>

        <div className="bg-slate-950/80 p-4 rounded-2xl border border-amber-500/20 space-y-1.5">
          <div className="flex items-center space-x-2 text-xs font-bold text-amber-300">
            <BookOpen className="w-4 h-4 text-amber-400" />
            <span>{word.scripture}</span>
          </div>
        </div>

        <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-sans italic bg-amber-950/30 p-4 rounded-2xl border border-amber-500/20">
          &ldquo;{word.rhema}&rdquo;
        </p>

        <div className="flex items-center justify-between text-[11px] text-amber-400/80 font-mono pt-1">
          <span className="flex items-center space-x-1">
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            <span>Declared by {word.prophetNote}</span>
          </span>
          <span>✨ Fresh Manna for Today</span>
        </div>
      </div>
    </div>
  );
};
