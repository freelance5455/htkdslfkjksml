import React, { useState } from 'react';
import { Code2, Copy, Check, Download, FileCode, Smartphone, ExternalLink, Sparkles } from 'lucide-react';
import { soundFX } from '../utils/audio';

interface AndroidCodeExporterProps {
  language: 'en' | 'ur';
}

export const AndroidCodeExporter: React.FC<AndroidCodeExporterProps> = ({ language }) => {
  const [activeTab, setActiveTab] = useState<'mainActivity' | 'manifest' | 'layout' | 'gradle'>('mainActivity');
  const [copied, setCopied] = useState(false);

  const KOTLIN_CODE = `package com.opking47.networkbooster

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * OPKING47 Network Booster
 * Designed for Free Fire Pakistan (PK) & Low Latency Mobile Gaming
 */
class MainActivity : AppCompatActivity() {

    private lateinit var signalText: TextView
    private lateinit var boostBtn: Button
    private lateinit var wifiManager: WifiManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        signalText = findViewById(R.id.signalText)
        boostBtn = findViewById(R.id.boostBtn)
        wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

        // Read and display real Wi-Fi RSSI signal
        val rssi = wifiManager.connectionInfo.rssi
        val level = WifiManager.calculateSignalLevel(rssi, 100)
        signalText.text = "Signal: $level% | Ping: \${rssi}dBm"

        // Boost Logic with Pakistan Free Fire Optimization
        boostBtn.setOnClickListener {
            Toast.makeText(this, "OPKING47 Boosting... DNS Optimized! 🇵🇰", Toast.LENGTH_SHORT).show()
            boostBtn.isEnabled = false
            boostBtn.text = "Optimizing Radio..."

            // Reconnect Wi-Fi for best throughput & flush ARP table
            @Suppress("DEPRECATION")
            try {
                wifiManager.isWifiEnabled = false
            } catch (e: Exception) {
                // Android 10+ settings panel fallback if targetSdk >= 29
            }

            Handler(Looper.getMainLooper()).postDelayed({
                @Suppress("DEPRECATION")
                try {
                    wifiManager.isWifiEnabled = true
                } catch (e: Exception) {}

                val boostedLevel = (level + 15).coerceAtMost(100)
                signalText.text = "Boosted! 🔥 Signal: $boostedLevel% | FF Ping: LOW"
                boostBtn.isEnabled = true
                boostBtn.text = "Boosted! (Open Free Fire)"

                Toast.makeText(this, "Boost Done! Open Free Fire PK Now 🔥", Toast.LENGTH_LONG).show()
            }, 1000)
        }
    }
}`;

  const MANIFEST_CODE = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.opking47.networkbooster">

    <!-- Permissions required for Wi-Fi optimization & signal reading -->
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
    <uses-permission android:name="android.permission.CHANGE_WIFI_STATE" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="OPKING47 Booster"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.AppCompat.NoActionBar">
        
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

  const LAYOUT_CODE = `<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:gravity="center"
    android:padding="24dp"
    android:background="#090D16">

    <!-- Header Logo & Title -->
    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="OPKING47 BOOSTER 🇵🇰"
        android:textColor="#F59E0B"
        android:textSize="24sp"
        android:textStyle="bold"
        android:layout_marginBottom="8dp" />

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Free Fire Pakistan Low Ping Optimizer"
        android:textColor="#94A3B8"
        android:textSize="12sp"
        android:layout_marginBottom="32dp" />

    <!-- Signal Text Display (R.id.signalText) -->
    <TextView
        android:id="@+id/signalText"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:gravity="center"
        android:padding="18dp"
        android:background="#1E293B"
        android:text="Signal: Checking... | Ping: 0dBm"
        android:textColor="#34D399"
        android:textSize="16sp"
        android:textStyle="bold"
        android:layout_marginBottom="40dp" />

    <!-- Boost Button (R.id.boostBtn) -->
    <Button
        android:id="@+id/boostBtn"
        android:layout_width="match_parent"
        android:layout_height="64dp"
        android:text="BOOST NETWORK NOW 🔥"
        android:textColor="#090D16"
        android:textSize="16sp"
        android:textStyle="bold"
        android:backgroundTint="#F59E0B" />

</LinearLayout>`;

  const GRADLE_CODE = `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.opking47.networkbooster"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.opking47.networkbooster"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0-PK"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}`;

  const getCurrentCode = () => {
    switch (activeTab) {
      case 'mainActivity':
        return { code: KOTLIN_CODE, filename: 'MainActivity.kt' };
      case 'manifest':
        return { code: MANIFEST_CODE, filename: 'AndroidManifest.xml' };
      case 'layout':
        return { code: LAYOUT_CODE, filename: 'activity_main.xml' };
      case 'gradle':
        return { code: GRADLE_CODE, filename: 'build.gradle.kts' };
    }
  };

  const current = getCurrentCode();

  const handleCopy = () => {
    navigator.clipboard.writeText(current.code);
    setCopied(true);
    soundFX.playToast();
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([current.code], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = current.filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    soundFX.playToast();
  };

  return (
    <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-amber-400" />
            <h3 className="text-base font-bold text-slate-100">
              {language === 'ur' ? 'اینڈرائڈ اسٹوڈیو سورس کوڈ اور اے پی کے فائل' : 'Android Studio Source Code & APK Project'}
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            {language === 'ur'
              ? 'اپنے موبائل یا اینڈرائڈ اسٹوڈیو میں براہ راست کمپائل کرنے کے لیے مکمل سورس کوڈ'
              : 'Complete ready-to-compile Android project for com.opking47.networkbooster'}
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={handleCopy}
            className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-colors active:scale-95"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400 stroke-[3]" /> : <Copy className="w-3.5 h-3.5 text-amber-400" />}
            <span>{copied ? 'Copied!' : 'Copy Code'}</span>
          </button>

          <button
            onClick={handleDownload}
            className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 shadow-sm shadow-amber-500/20 transition-colors active:scale-95"
          >
            <Download className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>Download {current.filename}</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 border-b border-slate-800/80 mb-3">
        <button
          onClick={() => setActiveTab('mainActivity')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'mainActivity'
              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <FileCode className="w-3.5 h-3.5" />
          <span>MainActivity.kt</span>
        </button>

        <button
          onClick={() => setActiveTab('layout')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'layout'
              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <FileCode className="w-3.5 h-3.5" />
          <span>activity_main.xml</span>
        </button>

        <button
          onClick={() => setActiveTab('manifest')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'manifest'
              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <FileCode className="w-3.5 h-3.5" />
          <span>AndroidManifest.xml</span>
        </button>

        <button
          onClick={() => setActiveTab('gradle')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'gradle'
              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <FileCode className="w-3.5 h-3.5" />
          <span>build.gradle.kts</span>
        </button>
      </div>

      {/* Code Viewer */}
      <div className="relative rounded-xl bg-slate-950 border border-slate-800/80 p-4 font-mono text-xs overflow-x-auto max-h-80 text-slate-300">
        <pre className="whitespace-pre">{current.code}</pre>
      </div>

      {/* How to build info */}
      <div className="mt-3 p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs text-slate-400 space-y-1">
        <div className="font-semibold text-slate-200 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>How to build APK in Android Studio:</span>
        </div>
        <p>1. Open Android Studio → New Project → Empty Views Activity.</p>
        <p>2. Set package name to <code className="text-amber-400">com.opking47.networkbooster</code>.</p>
        <p>3. Paste these files into <code className="text-slate-300">MainActivity.kt</code>, <code className="text-slate-300">activity_main.xml</code>, and <code className="text-slate-300">AndroidManifest.xml</code>.</p>
        <p>4. Click <strong>Build → Build Bundle(s) / APK(s) → Build APK(s)</strong> to generate your installable APK!</p>
      </div>
    </div>
  );
};
