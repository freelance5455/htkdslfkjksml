import React, { useState } from 'react';
import { Code, FileCode, Folder, Copy, Check, Download, Smartphone, Sparkles, Terminal } from 'lucide-react';

interface CodeFile {
  path: string;
  category: string;
  language: string;
  content: string;
}

const KOTLIN_PROJECT_FILES: CodeFile[] = [
  {
    path: 'app/src/main/java/com/wakeup/alarm/data/entity/AlarmEntity.kt',
    category: 'Data Layer (Room Entity)',
    language: 'kotlin',
    content: `package com.wakeup.alarm.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "alarms")
data class AlarmEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val hour: Int,
    val minute: Int,
    val alarmLabel: String,
    val mediaUri: String,
    val mediaName: String,
    val mediaType: String, // "video" or "audio"
    val repeatDays: String, // Comma separated days e.g., "1,2,3,4,5"
    val isEnabled: Boolean = true,
    val volume: Int = 85,
    val gradualVolumeEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val snoozeDuration: Int = 5,
    val createdAt: Long = System.currentTimeMillis()
)`
  },
  {
    path: 'app/src/main/java/com/wakeup/alarm/alarm/AlarmScheduler.kt',
    category: 'Alarm Scheduling Engine',
    language: 'kotlin',
    content: `package com.wakeup.alarm.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.wakeup.alarm.data.entity.AlarmEntity
import java.util.Calendar

class AlarmScheduler(private val context: Context) {

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun schedule(alarm: AlarmEntity) {
        if (!alarm.isEnabled) return

        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("EXTRA_ALARM_ID", alarm.id)
            putExtra("EXTRA_ALARM_LABEL", alarm.alarmLabel)
            putExtra("EXTRA_MEDIA_URI", alarm.mediaUri)
            putExtra("EXTRA_MEDIA_TYPE", alarm.mediaType)
            putExtra("EXTRA_VOLUME", alarm.volume)
            putExtra("EXTRA_GRADUAL", alarm.gradualVolumeEnabled)
            putExtra("EXTRA_VIBRATION", alarm.vibrationEnabled)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            alarm.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val triggerAtMs = calculateNextTriggerMillis(alarm)

        // Use AlarmManager.setAlarmClock() for exact wakeup with clock icon
        val alarmClockInfo = AlarmManager.AlarmClockInfo(triggerAtMs, pendingIntent)
        alarmManager.setAlarmClock(alarmClockInfo, pendingIntent)
    }

    fun cancel(alarmId: Long) {
        val intent = Intent(context, AlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            alarmId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }

    private fun calculateNextTriggerMillis(alarm: AlarmEntity): Long {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, alarm.hour)
            set(Calendar.MINUTE, alarm.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        if (target.before(now)) {
            target.add(Calendar.DAY_OF_YEAR, 1)
        }
        return target.timeInMillis
    }
}`
  },
  {
    path: 'app/src/main/java/com/wakeup/alarm/media/MediaPlaybackService.kt',
    category: 'ExoPlayer Foreground Service',
    language: 'kotlin',
    content: `package com.wakeup.alarm.media

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

class MediaPlaybackService : Service() {

    private var exoPlayer: ExoPlayer? = null

    override fun onCreate() {
        super.onCreate()
        exoPlayer = ExoPlayer.Builder(this).build()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val mediaUri = intent?.getStringExtra("EXTRA_MEDIA_URI")
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("WakeUp Alarm Ringing")
            .setContentText("Playing selected video / audio media")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(null, true)
            .build()

        startForeground(1001, notification)

        mediaUri?.let { uriStr ->
            val mediaItem = MediaItem.fromUri(Uri.parse(uriStr))
            exoPlayer?.apply {
                setMediaItem(mediaItem)
                repeatMode = ExoPlayer.REPEAT_MODE_ONE
                prepare()
                play()
            }
        }

        return START_STICKY
    }

    override fun onDestroy() {
        exoPlayer?.stop()
        exoPlayer?.release()
        exoPlayer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Alarm Media Playback",
                NotificationManager.IMPORTANCE_HIGH
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "wakeup_alarm_playback_channel"
    }
}`
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    category: 'Android Manifest',
    language: 'xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.wakeup.alarm">

    <!-- Permissions -->
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.USE_EXACT_ALARM" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />
    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="WakeUp"
        android:supportsRtl="true"
        android:theme="@style/Theme.WakeUp">

        <activity
            android:name=".ui.MainActivity"
            android:exported="true"
            android:theme="@style/Theme.WakeUp">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <!-- Alarm Receiver & Boot Receiver -->
        <receiver
            android:name=".alarm.AlarmReceiver"
            android:exported="false" />

        <receiver
            android:name=".alarm.BootReceiver"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
            </intent-filter>
        </receiver>

        <!-- Media3 ExoPlayer Foreground Service -->
        <service
            android:name=".media.MediaPlaybackService"
            android:foregroundServiceType="mediaPlayback"
            android:exported="false" />

    </application>
</manifest>`
  }
];

export const AndroidCodeExporter: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<CodeFile>(KOTLIN_PROJECT_FILES[0]);
  const [copied, setCopied] = useState(false);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = () => {
    const dataStr = 'data:text/plain;charset=utf-8,' + encodeURIComponent(
      `WakeUp Video Alarm Clock Native Android Source Code:\n\n` +
      KOTLIN_PROJECT_FILES.map((f) => `=== ${f.path} ===\n${f.content}\n\n`).join('\n')
    );
    const anchor = document.createElement('a');
    anchor.setAttribute('href', dataStr);
    anchor.setAttribute('download', 'WakeUp_Android_Studio_Source.txt');
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200 max-w-5xl mx-auto">
      {/* Top Banner */}
      <div className="p-5 rounded-3xl bg-slate-900 dark:bg-slate-950 text-white shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Smartphone className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold font-sans text-white">
              Native Android Kotlin Source & Architecture
            </h2>
          </div>
          <p className="text-xs text-slate-300">
            Jetpack Compose + Room DB + AlarmManager + Media3 ExoPlayer service code.
          </p>
        </div>

        <button
          onClick={handleDownloadZip}
          className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-2xl bg-white text-slate-900 hover:bg-slate-100 font-extrabold text-xs shadow-md transition-all cursor-pointer shrink-0"
        >
          <Download className="w-4 h-4" />
          <span>Download Android Source</span>
        </button>
      </div>

      {/* Code Browser Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* File Directory List */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-4 space-y-2">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2 px-2 flex items-center gap-1.5">
            <Folder className="w-4 h-4 text-slate-700 dark:text-slate-300" />
            <span>Project File Hierarchy</span>
          </div>

          <div className="space-y-1">
            {KOTLIN_PROJECT_FILES.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left p-3 rounded-2xl transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 font-bold shadow-xs'
                      : 'bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-2 text-xs truncate">
                    <FileCode className="w-4 h-4 shrink-0" />
                    <span className="truncate">{file.path.split('/').pop()}</span>
                  </div>
                  <div className="text-[10px] opacity-75 mt-0.5 truncate pl-6">
                    {file.category}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Code Viewport Pane */}
        <div className="lg:col-span-8 bg-slate-950 text-slate-100 rounded-3xl border border-slate-800 overflow-hidden shadow-2xl flex flex-col min-h-[420px]">
          {/* Editor Header */}
          <div className="p-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-mono font-semibold text-slate-300 truncate max-w-[300px]">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span className="truncate">{selectedFile.path}</span>
            </div>

            <button
              onClick={handleCopyCode}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 transition-colors cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
          </div>

          {/* Editor Code Text Area */}
          <pre className="p-5 font-mono text-xs overflow-x-auto text-emerald-300/90 leading-relaxed flex-1">
            <code>{selectedFile.content}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
