import React, { useState } from 'react';
import { 
  Code2, 
  Copy, 
  Check, 
  Download, 
  CheckCircle2, 
  FileCode, 
  FileArchive,
  Layers, 
  Terminal, 
  ShieldCheck,
  FileCheck2,
  FileText,
  Cloud
} from 'lucide-react';
import { ANDROID_FILES, AndroidSourceFile } from '../data/androidCodePackage';
import { downloadAndroidProjectZip } from '../utils/zipDownloader';
import { exportEntireAppToDrive } from '../services/appExporter';

interface AndroidCodeExporterProps {
  driveToken?: string | null;
  onNavigateToDrive?: () => void;
}

export const AndroidCodeExporter: React.FC<AndroidCodeExporterProps> = ({
  driveToken,
  onNavigateToDrive,
}) => {
  const [selectedFileId, setSelectedFileId] = useState<string>('overlayservice');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isZipping, setIsZipping] = useState(false);
  const [zipProgress, setZipProgress] = useState(0);
  const [isExportingToDrive, setIsExportingToDrive] = useState(false);
  const [driveExportSuccess, setDriveExportSuccess] = useState<string | null>(null);

  const selectedFile = ANDROID_FILES.find(f => f.id === selectedFileId) || ANDROID_FILES[0];

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    setZipProgress(10);
    try {
      await downloadAndroidProjectZip(percent => {
        setZipProgress(percent);
      });
    } catch (err) {
      console.error('Failed to generate zip:', err);
    } finally {
      setTimeout(() => {
        setIsZipping(false);
        setZipProgress(0);
      }, 500);
    }
  };

  const handleExportToDrive = async () => {
    if (!driveToken) {
      if (onNavigateToDrive) {
        onNavigateToDrive();
      } else {
        alert('Faça login no Google Drive primeiro na aba Google Drive.');
      }
      return;
    }

    setIsExportingToDrive(true);
    try {
      const res = await exportEntireAppToDrive(driveToken);
      setDriveExportSuccess(`✓ Projeto exportado para a pasta "${res.folderName}" no Google Drive!`);
      setTimeout(() => setDriveExportSuccess(null), 5000);
    } catch (err: any) {
      alert(`Erro ao exportar para o Google Drive: ${err.message}`);
    } finally {
      setIsExportingToDrive(false);
    }
  };

  const downloadFile = (file: AndroidSourceFile) => {
    const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = file.filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const downloadAllAsText = () => {
    let bundle = `===================================================================\n`;
    bundle += `MEUS ARQUIVOS PAT - PACOTE ANDROID STUDIO CORRIGIDO 100% FUNCIONAL\n`;
    bundle += `MENU FLUTUANTE NATIVO + ATIVAÇÃO EXTERNA ADB SEM ROOT\n`;
    bundle += `===================================================================\n\n`;

    ANDROID_FILES.forEach((f, idx) => {
      bundle += `-------------------------------------------------------------------\n`;
      bundle += `ARQUIVO ${idx + 1}: ${f.filename}\n`;
      bundle += `LOCALIZAÇÃO NO PROJETO: ${f.targetPath}\n`;
      bundle += `RESUMO: ${f.summary}\n`;
      bundle += `CORREÇÕES REALIZADAS:\n`;
      f.fixes.forEach(fix => {
        bundle += `  - ${fix}\n`;
      });
      bundle += `-------------------------------------------------------------------\n`;
      bundle += f.content;
      bundle += `\n\n\n`;
    });

    const blob = new Blob([bundle], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'MEUS_ARQUIVOS_PAT_CORRIGIDO_COMPLETO.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex-1 flex flex-col p-4 md:p-6 overflow-y-auto space-y-6">
      
      {/* Toast */}
      {driveExportSuccess && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-emerald-950 border border-emerald-700 text-emerald-200 text-xs px-4 py-2.5 rounded-lg shadow-2xl font-mono flex items-center space-x-2 animate-fade-in">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{driveExportSuccess}</span>
        </div>
      )}

      {/* Overview Card */}
      <div className="p-4 md:p-5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start space-x-3">
            <div className="p-2.5 rounded-lg bg-emerald-950 border border-emerald-800 text-emerald-400 shrink-0">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white tracking-wide">
                Todos os Erros do Projeto Android Foram Corrigidos
              </h2>
              <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
                Baixe o pacote <strong>.ZIP completo</strong> contendo toda a estrutura de pastas do Android Studio (<code className="text-neutral-300 font-mono">app/src/main/...</code>) pronta para compilar, ou exporte diretamente para o seu Google Drive.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 shrink-0 flex-wrap gap-y-2">
            {/* Export to Google Drive Button */}
            <button
              onClick={handleExportToDrive}
              disabled={isExportingToDrive}
              className="px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition shadow-lg flex items-center space-x-1.5 cursor-pointer disabled:opacity-50"
              title="Exporta o projeto completo para a sua conta do Google Drive"
            >
              <Cloud className="w-4 h-4" />
              <span>{isExportingToDrive ? "Exportando..." : "Exportar para o Google Drive"}</span>
            </button>

            {/* Primary Download Zip Button */}
            <button
              onClick={handleDownloadZip}
              disabled={isZipping}
              className="px-3.5 py-2 rounded-lg bg-white hover:bg-neutral-200 text-black font-bold text-xs transition shadow-lg flex items-center space-x-1.5"
            >
              <FileArchive className="w-4 h-4" />
              <span>{isZipping ? `Gerando .ZIP (${zipProgress}%)...` : 'Baixar .ZIP'}</span>
            </button>

            {/* Alternative Text file */}
            <button
              onClick={downloadAllAsText}
              className="px-3 py-2 rounded-lg bg-neutral-900 border border-neutral-700 text-neutral-300 hover:text-white text-xs font-mono transition flex items-center space-x-1.5"
              title="Baixar todos os blocos em arquivo de texto único"
            >
              <FileText className="w-3.5 h-3.5" />
              <span className="hidden md:inline">.TXT</span>
            </button>
          </div>
        </div>

        {/* Summary of What Was Fixed */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-neutral-900 text-xs">
          <div className="p-3 rounded-lg bg-black/60 border border-neutral-900 space-y-1.5">
            <div className="flex items-center space-x-2 text-rose-400 font-bold">
              <span>✕ O que causava erro no código anterior:</span>
            </div>
            <ul className="text-neutral-400 text-[11px] space-y-1 list-disc list-inside">
              <li>Tentativa de rodar <code className="text-neutral-300">pm grant</code> direto de dentro do Kotlin (gera SecurityException).</li>
              <li>Não existia nenhum serviço de sobreposição para o Menu Flutuante (apenas um WebView comum).</li>
              <li>Falta de permissões de primeiro plano (<code className="text-neutral-300">FOREGROUND_SERVICE</code>).</li>
              <li>Falta de script externo para conceder privilégios de fora sem root.</li>
            </ul>
          </div>

          <div className="p-3 rounded-lg bg-black/60 border border-neutral-900 space-y-1.5">
            <div className="flex items-center space-x-2 text-emerald-400 font-bold">
              <span>✓ Como foi solucionado:</span>
            </div>
            <ul className="text-neutral-300 text-[11px] space-y-1 list-disc list-inside">
              <li>Criado o <strong>OverlayService.kt</strong> com WindowManager flutuante arrastável sobre qualquer jogo.</li>
              <li>Criado o <strong>AdbActivationReceiver.kt</strong> e scripts <code className="text-white">ativar_pat.bat</code> / <code className="text-white">.sh</code>.</li>
              <li>Tratamento de permissão de Overlay com fallback para configurações do sistema.</li>
              <li>Arquivos organizados prontos para copiar direto no Android Studio!</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Code Browser */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        
        {/* File Selector Sidebar */}
        <div className="lg:col-span-4 space-y-2">
          <div className="text-xs font-mono text-neutral-400 mb-2">Arquivos do Pacote:</div>
          <div className="space-y-1.5">
            {ANDROID_FILES.map(file => (
              <button
                key={file.id}
                onClick={() => setSelectedFileId(file.id)}
                className={`w-full p-3 rounded-lg border text-left transition flex items-center justify-between ${
                  selectedFileId === file.id
                    ? 'bg-neutral-900 border-white text-white shadow'
                    : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700'
                }`}
              >
                <div className="flex items-center space-x-2.5 truncate">
                  <FileCode className={`w-4 h-4 shrink-0 ${file.language === 'kotlin' ? 'text-amber-400' : file.language === 'xml' ? 'text-blue-400' : 'text-emerald-400'}`} />
                  <div className="truncate">
                    <div className="text-xs font-bold font-mono truncate">{file.filename}</div>
                    <div className="text-[10px] text-neutral-500 truncate">{file.targetPath}</div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* File Viewer */}
        <div className="lg:col-span-8 rounded-xl bg-neutral-950 border border-neutral-800 flex flex-col overflow-hidden">
          
          {/* Header of Viewer */}
          <div className="p-3 border-b border-neutral-800 flex flex-wrap items-center justify-between bg-black gap-2">
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-mono text-xs font-bold text-white">{selectedFile.filename}</span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-300">
                  {selectedFile.language.toUpperCase()}
                </span>
              </div>
              <div className="text-[10px] text-neutral-500 font-mono mt-0.5">
                Caminho: {selectedFile.targetPath}
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => copyToClipboard(selectedFile.content, selectedFile.id)}
                className="px-3 py-1 rounded bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 text-xs text-white flex items-center space-x-1.5 transition"
              >
                {copiedId === selectedFile.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedId === selectedFile.id ? 'Copiado!' : 'Copiar'}</span>
              </button>

              <button
                onClick={() => downloadFile(selectedFile)}
                className="px-3 py-1 rounded bg-white text-black font-bold text-xs hover:bg-neutral-200 flex items-center space-x-1.5 transition"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Baixar</span>
              </button>
            </div>
          </div>

          {/* Fixes checklist for this specific file */}
          <div className="p-3 bg-neutral-900/40 border-b border-neutral-800/80 text-[11px] space-y-1">
            <span className="text-neutral-400 font-bold block">Correções implementadas neste arquivo:</span>
            <ul className="text-neutral-300 space-y-0.5">
              {selectedFile.fixes.map((fix, idx) => (
                <li key={idx} className="flex items-center space-x-1.5">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                  <span>{fix}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Code Body */}
          <div className="p-3.5 bg-black overflow-x-auto max-h-[500px] font-mono text-xs text-neutral-300 custom-scrollbar">
            <pre className="leading-relaxed">
              {selectedFile.content}
            </pre>
          </div>

        </div>

      </div>

    </div>
  );
};
