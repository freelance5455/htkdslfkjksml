"use client";

/* eslint-disable @next/next/no-img-element */
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import type { Attraction } from "@/db/schema";
import { CATEGORIES, COUNTRIES } from "@/lib/data";
import { useLang } from "@/lib/i18n";

function localISO(offsetDays = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export default function AttractionClient({
  a,
  initialTickets,
  initialDate,
}: {
  a: Attraction;
  initialTickets?: number;
  initialDate?: string;
}) {
  const { lang, t } = useLang();
  const router = useRouter();
  const [tickets, setTickets] = useState(initialTickets && initialTickets > 0 ? Math.min(20, initialTickets) : 2);
  const [date, setDate] = useState(initialDate ?? "");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [minDate, setMinDate] = useState("");

  useEffect(() => {
    setMinDate(localISO(0));
    setDate((d) => d || localISO(1));
  }, []);

  const country = COUNTRIES[a.countryCode];
  const cat = CATEGORIES[a.category];
  const total = tickets * a.price;

  const submit = useCallback(
    async (viaVoice = false) => {
      const say = (text: string) => {
        setError(text);
        if (viaVoice) window.dispatchEvent(new CustomEvent("assistant:speak", { detail: { text } }));
      };
      if (!name.trim()) return say(lang === "ar" ? "أدخل اسمك أولاً ثم قل أكّد الحجز." : "Please enter your name first, then say confirm.");
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
        return say(lang === "ar" ? "أدخل بريدك الإلكتروني الصحيح ثم قل أكّد الحجز." : "Please enter a valid email, then say confirm.");
      }
      if (!date || date < localISO(0)) return say(t("dateRequired"));
      setError("");
      setBusy(true);
      try {
        const res = await fetch("/api/bookings", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ slug: a.slug, name, email, date, tickets }),
        });
        const data = await res.json();
        if (!res.ok || !data.ref) throw new Error(data.error ?? "failed");
        if (viaVoice) {
          const spoken = (data.ref as string).replace(/-/g, " ").split("").join(" ");
          window.dispatchEvent(
            new CustomEvent("assistant:speak", {
              detail: {
                done: true,
                text:
                  lang === "ar"
                    ? `تم تأكيد حجزك! رقم الحجز ${spoken}. أرسلنا تذاكرك إلى بريدك. رحلة سعيدة!`
                    : `Your booking is confirmed! Reference ${spoken}. Enjoy your trip!`,
              },
            }),
          );
        }
        router.push(`/booking/${data.ref}`);
      } catch {
        say(t("error"));
        setBusy(false);
      }
    },
    [a.slug, date, email, lang, name, router, t, tickets],
  );

  // Let the voice assistant control this form.
  const submitRef = useRef(submit);
  useEffect(() => {
    submitRef.current = submit;
  }, [submit]);

  useEffect(() => {
    const onSet = (e: Event) => {
      const d = (e as CustomEvent<{ tickets?: number; date?: string }>).detail;
      if (d?.tickets) setTickets(Math.max(1, Math.min(20, d.tickets)));
      if (d?.date) setDate(d.date);
    };
    const onConfirm = () => submitRef.current(true);
    window.addEventListener("assistant:set", onSet);
    window.addEventListener("assistant:confirm", onConfirm);
    return () => {
      window.removeEventListener("assistant:set", onSet);
      window.removeEventListener("assistant:confirm", onConfirm);
    };
  }, []);

  const input =
    "w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-slate-900 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200";

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 pb-28">
      <Link href="/" className="mb-4 inline-flex items-center gap-1 text-sm font-medium text-indigo-600 hover:underline">
        {lang === "ar" ? "→" : "←"} {t("back")}
      </Link>
      <div className="grid gap-8 lg:grid-cols-[1.4fr_1fr]">
        <div>
          <div className="relative aspect-[16/9] overflow-hidden rounded-3xl bg-slate-200 shadow-lg">
            <img src={a.image} alt={lang === "ar" ? a.nameAr : a.nameEn} className="h-full w-full object-cover" />
            <span className="absolute start-4 top-4 rounded-full bg-white/90 px-3 py-1 text-sm font-semibold shadow">
              {cat?.icon} {cat?.[lang]}
            </span>
          </div>
          <div className="mt-6">
            <div className="text-sm font-medium text-indigo-600">
              {country?.flag} {lang === "ar" ? a.cityAr : a.cityEn} · {country?.[lang]}
            </div>
            <h1 className="mt-1 text-2xl font-extrabold leading-tight text-slate-900 sm:text-3xl">
              {lang === "ar" ? a.nameAr : a.nameEn}
            </h1>
            <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-slate-600">
              <span className="font-semibold text-amber-600">★ {a.rating.toFixed(1)}</span>
              <span>
                ({a.reviews.toLocaleString(lang === "ar" ? "ar-EG" : "en-US")} {t("reviews")})
              </span>
              <span>
                ⏱ {a.durationMin} {t("minutes")}
              </span>
            </div>
            <p className="mt-5 text-base leading-8 text-slate-700">{lang === "ar" ? a.descAr : a.descEn}</p>
            <ul className="mt-5 flex flex-wrap gap-2 text-sm">
              {[`⚡ ${t("instant")}`, `🎟️ ${t("skipLine")}`, `↩️ ${t("freeCancel")}`].map((x) => (
                <li key={x} className="rounded-full bg-emerald-50 px-3 py-1.5 font-medium text-emerald-700">
                  {x}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit(false);
          }}
          className="h-fit space-y-4 rounded-3xl bg-white p-6 shadow-xl ring-1 ring-slate-200 lg:sticky lg:top-24"
        >
          <div className="flex items-end justify-between">
            <h2 className="text-lg font-bold">{t("yourDetails")}</h2>
            <div className="text-end">
              <span className="text-xs text-slate-500">{t("perTicket")}</span>
              <div className="text-2xl font-extrabold">€{a.price}</div>
            </div>
          </div>

          <label className="block text-sm font-medium text-slate-700">
            {t("visitDate")}
            <input type="date" min={minDate} value={date} onChange={(e) => setDate(e.target.value)} className={`${input} mt-1`} />
          </label>

          <div>
            <div className="mb-1 text-sm font-medium text-slate-700">{t("tickets")}</div>
            <div className="flex items-center justify-between rounded-xl border border-slate-200 p-1">
              <button
                type="button"
                onClick={() => setTickets((n) => Math.max(1, n - 1))}
                className="h-11 w-11 rounded-lg bg-slate-100 text-xl font-bold hover:bg-slate-200"
                aria-label="-"
              >
                −
              </button>
              <span className="text-lg font-bold">{tickets}</span>
              <button
                type="button"
                onClick={() => setTickets((n) => Math.min(20, n + 1))}
                className="h-11 w-11 rounded-lg bg-slate-100 text-xl font-bold hover:bg-slate-200"
                aria-label="+"
              >
                +
              </button>
            </div>
          </div>

          <label className="block text-sm font-medium text-slate-700">
            {t("fullName")}
            <input value={name} onChange={(e) => setName(e.target.value)} className={`${input} mt-1`} autoComplete="name" />
          </label>
          <label className="block text-sm font-medium text-slate-700">
            {t("email")}
            <input
              type="email"
              dir="ltr"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={`${input} mt-1 text-start`}
              autoComplete="email"
            />
          </label>

          <div className="flex items-center justify-between border-t border-dashed border-slate-200 pt-4">
            <span className="font-medium text-slate-600">{t("total")}</span>
            <span className="text-2xl font-extrabold text-indigo-700">€{total}</span>
          </div>

          {error && <p className="rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-700">{error}</p>}

          <button
            disabled={busy}
            className="w-full rounded-2xl bg-gradient-to-r from-indigo-600 to-fuchsia-500 py-4 text-lg font-bold text-white shadow-lg transition hover:scale-[1.01] disabled:opacity-60"
          >
            {busy ? t("booking") : t("confirmBooking")}
          </button>
          <p className="text-center text-xs text-slate-500">🎙️ {t("voiceTip")}</p>
        </form>
      </div>
    </div>
  );
}
