import React, { useState, useMemo, useEffect } from 'react';
import { Transaction, Category, PaymentMethod, TransactionType, AppSettings, Account } from '../types';
import { CategoryIcon } from './CategoryIcon';
import { AccountSelectDropdown } from './AccountSelectDropdown';
import {
  X,
  Plus,
  AlertTriangle,
  Calendar,
  Wallet,
  FileText,
  ArrowRightLeft,
  ArrowDownLeft,
  ArrowUpRight,
  Building2,
  Smartphone,
  TrendingDown,
  TrendingUp,
  Handshake,
  Users,
  CheckCircle2,
} from 'lucide-react';
import { formatCurrency, getPaymentMethodLabel } from '../utils/formatters';
import { getDualAccentInfo } from '../utils/theme';

export type AddModalTab = TransactionType;

interface AddTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: Category[];
  accounts?: Account[];
  onSave: (tx: Omit<Transaction, 'id' | 'createdAt'>) => void;
  onAddAccount?: (account: Omit<Account, 'id'>) => Account;
  monthlyBudgetExceeded?: boolean;
  currentExpenseSoFar?: number;
  totalBudgetLimit?: number;
  useBanglaDigits: boolean;
  appSettings?: AppSettings;
}

export const AddTransactionModal: React.FC<AddTransactionModalProps> = ({
  isOpen,
  onClose,
  categories = [],
  accounts = [],
  onSave,
  onAddAccount,
  monthlyBudgetExceeded,
  currentExpenseSoFar = 0,
  totalBudgetLimit = 0,
  useBanglaDigits,
  appSettings,
}) => {
  const safeAccounts = Array.isArray(accounts) ? accounts : [];
  const safeCategories = Array.isArray(categories) ? categories : [];

  // Underlying transaction type ('expense' | 'income' | 'transfer')
  const [type, setType] = useState<TransactionType>('expense');

  const [amount, setAmount] = useState<string>('');
  const [categoryId, setCategoryId] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  
  // Account state
  const [accountId, setAccountId] = useState<string>(safeAccounts[0]?.id || 'acc_cash');
  const [fromAccountId, setFromAccountId] = useState<string>(safeAccounts[0]?.id || 'acc_bank');
  const [toAccountId, setToAccountId] = useState<string>(safeAccounts[1]?.id || safeAccounts[0]?.id || 'acc_bkash');

  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [note, setNote] = useState<string>('');
  const [error, setError] = useState<string>('');

  // Recipient / Giver (গ্রহিতা/দাতা) Ledger state
  const [ledgerMode, setLedgerMode] = useState<'select' | 'new'>('select');
  const [selectedLedgerAccountId, setSelectedLedgerAccountId] = useState<string>('');
  const [customLedgerName, setCustomLedgerName] = useState<string>('');
  const [customLedgerPhone, setCustomLedgerPhone] = useState<string>('');
  const [hasLedgerValidationError, setHasLedgerValidationError] = useState<boolean>(false);

  const isLight = appSettings?.themeMode === 'light';
  const isEn = appSettings?.language === 'en';
  const dualAccent = getDualAccentInfo(
    appSettings?.themeAccent,
    appSettings?.secondaryAccent,
    appSettings?.accentPercentage
  );

  // Group accounts into Wallets/Banks, Receivables, and Payables
  const walletAccounts = useMemo(() => {
    return safeAccounts.filter(
      (a) =>
        a.type !== 'receivable' &&
        a.type !== 'payable' &&
        a.id !== 'acc_receivable' &&
        a.id !== 'acc_payable'
    );
  }, [safeAccounts]);

  const receivableAccounts = useMemo(() => {
    return safeAccounts.filter(
      (a) => a.type === 'receivable' || a.id === 'acc_receivable'
    );
  }, [safeAccounts]);

  const payableAccounts = useMemo(() => {
    return safeAccounts.filter(
      (a) => a.type === 'payable' || a.id === 'acc_payable'
    );
  }, [safeAccounts]);

  // Check if primary account or transfer counterpart is a loan/debt account
  const isIncomeExpenseLoan = useMemo(() => {
    const acc = safeAccounts.find((a) => a.id === accountId);
    return (
      acc?.type === 'receivable' ||
      acc?.type === 'payable' ||
      accountId === 'acc_receivable' ||
      accountId === 'acc_payable'
    );
  }, [accountId, safeAccounts]);

  const fromAcc = safeAccounts.find((a) => a.id === fromAccountId);
  const toAcc = safeAccounts.find((a) => a.id === toAccountId);

  const isTransferFromLoan =
    fromAcc?.type === 'receivable' ||
    fromAcc?.type === 'payable' ||
    fromAccountId === 'acc_receivable' ||
    fromAccountId === 'acc_payable';

  const isTransferToLoan =
    toAcc?.type === 'receivable' ||
    toAcc?.type === 'payable' ||
    toAccountId === 'acc_receivable' ||
    toAccountId === 'acc_payable';

  const isTransferLoan = isTransferFromLoan || isTransferToLoan;

  // MANDATORY REQUIREMENT:
  // Whenever Receivables or Payables is selected in accounts,
  // attaching a Recipient/Giver (গ্রহিতা/দাতা) ledger is strictly mandatory!
  const isLedgerRequired = type === 'transfer' ? isTransferLoan : isIncomeExpenseLoan;

  const isReceivableContext = useMemo(() => {
    if (type === 'transfer') {
      return (
        toAcc?.type === 'receivable' ||
        toAccountId === 'acc_receivable' ||
        fromAcc?.type === 'receivable' ||
        fromAccountId === 'acc_receivable'
      );
    }
    const acc = safeAccounts.find((a) => a.id === accountId);
    return acc?.type === 'receivable' || accountId === 'acc_receivable';
  }, [type, accountId, fromAccountId, toAccountId, fromAcc, toAcc, safeAccounts]);

  const existingLedgers = useMemo(() => {
    return safeAccounts.filter(
      (a) =>
        (a.type === 'receivable' || a.type === 'payable') &&
        a.id !== 'acc_receivable' &&
        a.id !== 'acc_payable'
    );
  }, [safeAccounts]);

  // Context-filtered ledgers: show matching type first
  const contextLedgers = useMemo(() => {
    if (isReceivableContext) {
      const rec = existingLedgers.filter((a) => a.type === 'receivable');
      const pay = existingLedgers.filter((a) => a.type !== 'receivable');
      return [...rec, ...pay];
    } else {
      const pay = existingLedgers.filter((a) => a.type === 'payable');
      const rec = existingLedgers.filter((a) => a.type !== 'payable');
      return [...pay, ...rec];
    }
  }, [existingLedgers, isReceivableContext]);

  useEffect(() => {
    if (existingLedgers.length === 0) {
      setLedgerMode('new');
    }
  }, [existingLedgers.length]);

  // Synchronize tab changes
  const handleTabChange = (newTab: TransactionType) => {
    setType(newTab);
    setCategoryId('');
    setError('');
    setHasLedgerValidationError(false);
  };

  if (!isOpen) return null;

  const filteredCategories = safeCategories.filter((c) => c.type === (type === 'transfer' ? 'expense' : type));

  const parsedAmount = parseFloat(amount) || 0;
  const projectTotalExpense = currentExpenseSoFar + parsedAmount;
  const isOverBudget =
    type === 'expense' && totalBudgetLimit > 0 && projectTotalExpense > totalBudgetLimit;

  // Helper to determine payment method from account
  const resolvePaymentMethod = (accId: string): PaymentMethod => {
    const acc = safeAccounts.find((a) => a.id === accId);
    if (!acc) return paymentMethod;
    if (acc.type === 'cash') return 'cash';
    if (acc.type === 'bank') return 'bank';
    if (acc.type === 'card') return 'card';
    if (acc.type === 'mobile_banking') {
      const lower = `${acc.nameEnglish} ${acc.nameBangla}`.toLowerCase();
      if (lower.includes('bkash')) return 'bkash';
      if (lower.includes('nagad')) return 'nagad';
      if (lower.includes('rocket')) return 'rocket';
    }
    return paymentMethod;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setHasLedgerValidationError(false);

    if (!parsedAmount || parsedAmount <= 0) {
      setError(isEn ? 'Please enter a valid amount' : 'অনুগ্রহ করে সঠিক টাকার পরিমাণ লিখুন');
      return;
    }

    if ((type === 'expense' || type === 'income') && !categoryId) {
      setError(isEn ? 'Please select a category' : 'একটি খাত বা ক্যাটাগরি নির্বাচন করুন');
      return;
    }

    if (type === 'transfer' && fromAccountId === toAccountId) {
      setError(
        isEn
          ? 'Sender and receiver accounts cannot be the same'
          : 'প্রেরক ও প্রাপক অ্যাকাউন্ট একই হতে পারে না'
      );
      return;
    }

    // MANDATORY VALIDATION:
    // When Receivables or Payables is selected in accounts, attaching a Recipient/Giver (গ্রহিতা/দাতা) ledger is MANDATORY!
    let finalPersonName = '';
    let finalLedgerAccountId = '';

    if (isLedgerRequired) {
      if (ledgerMode === 'select' && selectedLedgerAccountId && selectedLedgerAccountId !== '__new__') {
        const found = safeAccounts.find((a) => a.id === selectedLedgerAccountId);
        if (found) {
          finalPersonName = isEn ? found.nameEnglish : found.nameBangla;
          finalLedgerAccountId = found.id;
        }
      } else {
        finalPersonName = customLedgerName.trim();
      }

      // Check if user selected a specific individual person directly from the account dropdown
      if (!finalPersonName) {
        const targetId = type === 'transfer' ? (isTransferToLoan ? toAccountId : fromAccountId) : accountId;
        const directAcc = safeAccounts.find((a) => a.id === targetId);
        if (directAcc && directAcc.id !== 'acc_receivable' && directAcc.id !== 'acc_payable') {
          finalPersonName = isEn ? directAcc.nameEnglish : directAcc.nameBangla;
          finalLedgerAccountId = directAcc.id;
        }
      }

      // If STILL not provided, block submission and highlight error
      if (!finalPersonName) {
        setHasLedgerValidationError(true);
        setError(
          isEn
            ? 'Recipient / Giver (গ্রহিতা/দাতা) ledger is strictly mandatory for Receivables and Payables.'
            : 'Receivables বা Payables এর ক্ষেত্রে গ্রহিতা/দাতা লেজার সংযুক্ত করা বাধ্যতামূলক।'
        );
        return;
      }

      // If a new name was entered, find or create ledger account
      if (!finalLedgerAccountId) {
        const matchByName = safeAccounts.find(
          (a) =>
            (a.type === 'receivable' || a.type === 'payable') &&
            (a.nameBangla.trim().toLowerCase() === finalPersonName.toLowerCase() ||
              a.nameEnglish.trim().toLowerCase() === finalPersonName.toLowerCase())
        );

        if (matchByName) {
          finalLedgerAccountId = matchByName.id;
        } else if (onAddAccount) {
          const determinedType = isReceivableContext ? 'receivable' : 'payable';
          const newAccount = onAddAccount({
            nameBangla: finalPersonName,
            nameEnglish: finalPersonName,
            phoneNumber: customLedgerPhone.trim(),
            type: determinedType,
            openingBalance: 0,
            notes: isEn
              ? `Created from transaction as ${determinedType} ledger`
              : `অ্যাড ট্রানজেকশন থেকে তৈরি ${determinedType === 'receivable' ? 'দেনাদার' : 'পাওনাদার'} গ্রহিতা/দাতা লেজার`,
            color: determinedType === 'receivable' ? '#06B6D4' : '#EF4444',
            icon: determinedType === 'receivable' ? 'ArrowDownLeft' : 'ArrowUpRight',
            createdAt: Date.now(),
          });
          finalLedgerAccountId = newAccount.id;
        }
      }
    }

    // Determine final transaction properties
    let finalTxType: TransactionType = type;
    let finalCategoryId = categoryId;
    let finalAccountId: string | undefined = accountId;
    let finalFromAccountId: string | undefined = fromAccountId;
    let finalToAccountId: string | undefined = toAccountId;
    let finalPaymentMethod: PaymentMethod = paymentMethod;

    if (type === 'transfer') {
      finalTxType = 'transfer';
      finalAccountId = undefined;
      finalFromAccountId = fromAccountId;
      finalToAccountId = toAccountId;
      if (isLedgerRequired && finalLedgerAccountId) {
        if (fromAccountId === 'acc_receivable' || fromAccountId === 'acc_payable') {
          finalFromAccountId = finalLedgerAccountId;
        }
        if (toAccountId === 'acc_receivable' || toAccountId === 'acc_payable') {
          finalToAccountId = finalLedgerAccountId;
        }
      }
      finalPaymentMethod = resolvePaymentMethod(fromAccountId);
      finalCategoryId = 'transfer';
    } else {
      // Income or Expense
      finalTxType = type;
      finalFromAccountId = undefined;
      finalToAccountId = undefined;
      finalAccountId = accountId;
      if (isLedgerRequired && finalLedgerAccountId) {
        if (accountId === 'acc_receivable' || accountId === 'acc_payable') {
          finalAccountId = finalLedgerAccountId;
        }
      }
      finalPaymentMethod = resolvePaymentMethod(accountId);
    }

    // Construct note
    let formattedNote = note.trim();
    if (finalPersonName) {
      const personTag = `[গ্রহিতা/দাতা: ${finalPersonName}]`;
      if (!formattedNote) {
        formattedNote = personTag;
      } else if (!formattedNote.includes(finalPersonName)) {
        formattedNote = `${formattedNote} ${personTag}`;
      }
    }

    onSave({
      type: finalTxType,
      amount: parsedAmount,
      categoryId: finalCategoryId,
      paymentMethod: finalPaymentMethod,
      accountId: finalAccountId,
      fromAccountId: finalFromAccountId,
      toAccountId: finalToAccountId,
      ledgerPerson: finalPersonName || undefined,
      ledgerAccountId: finalLedgerAccountId || undefined,
      date,
      note: formattedNote,
    });

    // Reset form
    setAmount('');
    setNote('');
    setCustomLedgerName('');
    setCustomLedgerPhone('');
    setSelectedLedgerAccountId('');
    setHasLedgerValidationError(false);
    setError('');
    onClose();
  };

  return (
    <div
      id="add_transaction_modal_overlay"
      className={`fixed inset-0 z-50 flex items-end sm:items-center justify-center ${
        isLight ? 'bg-slate-900/40 backdrop-blur-xs' : 'bg-black/70 backdrop-blur-xs'
      } p-0 sm:p-4 animate-in fade-in duration-200`}
    >
      <div
        id="add_transaction_modal_container"
        className={`w-full max-w-lg ${
          isLight
            ? 'bg-white border-sky-200 text-sky-950'
            : 'bg-slate-800 border-slate-700 text-slate-100'
        } border rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]`}
      >
        {/* Header */}
        <div
          id="add_transaction_modal_header"
          className={`flex items-center justify-between px-6 py-4 border-b ${
            isLight
              ? 'border-sky-200 bg-sky-50/90 text-sky-950'
              : 'border-slate-700 bg-slate-800/80 text-slate-100'
          }`}
        >
          <h2 className="text-lg font-bold flex items-center gap-2">
            <Plus className="w-5 h-5" style={{ color: dualAccent.primary.hex }} />
            <span>{isEn ? 'Add Transaction' : 'নতুন হিসাব বা এন্ট্রি যোগ করুন'}</span>
          </h2>
          <button
            id="close_add_transaction_modal_btn"
            onClick={onClose}
            className={`p-2 rounded-full ${
              isLight
                ? 'text-sky-700 hover:text-sky-950 hover:bg-sky-100'
                : 'text-slate-400 hover:text-white hover:bg-slate-700'
            } transition`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4">
          {/* Transaction Category Tabs: Expense, Income, Transfer, Receivables, Payables */}
          <div>
            <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
              {isEn ? 'Transaction Type / Intent *' : 'লেনদেনের ধরণ / উদ্দেশ্য *'}
            </label>
            <div
              id="transaction_type_tabs"
              className={`grid grid-cols-3 gap-1.5 p-1.5 ${
                isLight ? 'bg-sky-100/80 border-sky-200' : 'bg-slate-900 border-slate-700'
              } rounded-2xl border`}
            >
              {/* Expense */}
              <button
                type="button"
                id="type_tab_expense"
                onClick={() => handleTabChange('expense')}
                className={`py-2 px-1 rounded-xl font-medium text-xs sm:text-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  type === 'expense'
                    ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30 font-bold'
                    : isLight
                    ? 'text-sky-800 hover:text-sky-950 hover:bg-sky-200/50'
                    : 'text-gray-400 hover:text-gray-200 hover:bg-slate-800'
                }`}
              >
                <span>💸 {isEn ? 'Expense' : 'খরচ'}</span>
              </button>

              {/* Income */}
              <button
                type="button"
                id="type_tab_income"
                onClick={() => handleTabChange('income')}
                className={`py-2 px-1 rounded-xl font-medium text-xs sm:text-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  type === 'income'
                    ? 'text-white shadow-md font-bold'
                    : isLight
                    ? 'text-sky-800 hover:text-sky-950 hover:bg-sky-200/50'
                    : 'text-gray-400 hover:text-gray-200 hover:bg-slate-800'
                }`}
                style={type === 'income' ? dualAccent.primaryButtonStyle : undefined}
              >
                <span>💰 {isEn ? 'Income' : 'আয়'}</span>
              </button>

              {/* Transfer */}
              <button
                type="button"
                id="type_tab_transfer"
                onClick={() => handleTabChange('transfer')}
                className={`py-2 px-1 rounded-xl font-medium text-xs sm:text-sm transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  type === 'transfer'
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 font-bold'
                    : isLight
                    ? 'text-sky-800 hover:text-sky-950 hover:bg-sky-200/50'
                    : 'text-gray-400 hover:text-gray-200 hover:bg-slate-800'
                }`}
              >
                <span>🔄 {isEn ? 'Transfer' : 'ট্রান্সফার'}</span>
              </button>
            </div>
          </div>

          {/* Amount Input */}
          <div>
            <label
              className={`block text-xs font-semibold uppercase tracking-wider ${
                isLight ? 'text-sky-800' : 'text-gray-400'
              } mb-1.5`}
            >
              {isEn ? 'Amount (৳) *' : 'টাকার পরিমাণ (৳) *'}
            </label>
            <div className="relative">
              <span
                className="absolute left-4 top-1/2 -translate-y-1/2 text-xl font-bold"
                style={{ color: dualAccent.primary.hex }}
              >
                ৳
              </span>
              <input
                id="transaction_amount_input"
                type="number"
                step="any"
                placeholder="0.00"
                value={amount}
                onChange={(e) => {
                  setAmount(e.target.value);
                  setError('');
                }}
                className={`w-full pl-10 pr-4 py-3 ${
                  isLight
                    ? 'bg-sky-50/80 border-sky-200 text-sky-950 placeholder-sky-700/50'
                    : 'bg-slate-900 border-slate-700 text-white placeholder-slate-500'
                } border rounded-xl text-xl font-bold focus:outline-none transition`}
                style={{ borderColor: `${dualAccent.primary.hex}40` }}
                autoFocus
              />
            </div>
          </div>

          {/* Account Selection */}
          {type === 'transfer' ? (
            /* TRANSFER: From Account & To Account with Grouped Options */
            <div className="p-4 rounded-2xl border space-y-3 bg-indigo-50/50 dark:bg-indigo-950/20 border-indigo-200 dark:border-indigo-800/40">
              <p className="text-xs font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5">
                <ArrowRightLeft className="w-4 h-4" />
                <span>{isEn ? 'Account-to-Account Transfer' : 'এক অ্যাকাউন্ট থেকে অন্য অ্যাকাউন্টে ট্রান্সফার'}</span>
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">
                    {isEn ? 'From Account (প্রেরক) *' : 'কোন অ্যাকাউন্ট থেকে যাবে (প্রেরক) *'}
                  </label>
                  <AccountSelectDropdown
                    id="transfer_from_account_select"
                    accounts={safeAccounts}
                    selectedAccountId={fromAccountId}
                    onSelectAccount={(newId) => setFromAccountId(newId)}
                    isLight={isLight}
                    isEn={isEn}
                    placeholder={isEn ? 'Select From Account' : 'প্রেরক অ্যাকাউন্ট বেছে নিন'}
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-500 mb-1">
                    {isEn ? 'To Account (প্রাপক) *' : 'কোন অ্যাকাউন্টে জমা হবে (প্রাপক) *'}
                  </label>
                  <AccountSelectDropdown
                    id="transfer_to_account_select"
                    accounts={safeAccounts}
                    selectedAccountId={toAccountId}
                    onSelectAccount={(newId) => setToAccountId(newId)}
                    isLight={isLight}
                    isEn={isEn}
                    placeholder={isEn ? 'Select To Account' : 'প্রাপক অ্যাকাউন্ট বেছে নিন'}
                  />
                </div>
              </div>
            </div>
          ) : (
            /* INCOME / EXPENSE: Select Primary Account with Grouped Options */
            <div>
              <label
                className={`block text-xs font-semibold uppercase tracking-wider ${
                  isLight ? 'text-sky-800' : 'text-gray-400'
                } mb-1.5 flex items-center gap-1`}
              >
                <Wallet className="w-3.5 h-3.5" />
                <span>
                  {type === 'expense'
                    ? isEn
                      ? 'Expense From Account *'
                      : 'কোন অ্যাকাউন্ট থেকে খরচ হচ্ছে? *'
                    : isEn
                    ? 'Deposit To Account *'
                    : 'টাকা কোন অ্যাকাউন্টে জমা হচ্ছে? *'}
                </span>
              </label>
              <AccountSelectDropdown
                id="primary_account_select"
                accounts={safeAccounts}
                selectedAccountId={accountId}
                onSelectAccount={(newId) => setAccountId(newId)}
                isLight={isLight}
                isEn={isEn}
                placeholder={
                  type === 'expense'
                    ? isEn ? 'Expense From Account *' : 'খরচের অ্যাকাউন্ট নির্বাচন করুন *'
                    : isEn ? 'Deposit To Account *' : 'জমার অ্যাকাউন্ট নির্বাচন করুন *'
                }
              />
            </div>
          )}

          {/* MANDATORY Recipient/Giver (গ্রহিতা/দাতা) Ledger Component */}
          {isLedgerRequired && (
            <div
              id="mandatory_ledger_container"
              className={`p-4 rounded-2xl border transition-all ${
                hasLedgerValidationError
                  ? 'ring-2 ring-rose-500 border-rose-500 bg-rose-50/60 dark:bg-rose-950/40 animate-pulse'
                  : isLight
                  ? 'bg-amber-50/90 border-amber-300 text-amber-950 shadow-xs'
                  : 'bg-amber-950/25 border-amber-800/80 text-amber-100'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5 font-bold text-xs sm:text-sm text-amber-900 dark:text-amber-300">
                  <Handshake className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
                  <span>
                    {isEn ? 'Recipient / Giver (গ্রহিতা/দাতা) Ledger *' : 'গ্রহিতা/দাতা লেজার *'}
                  </span>
                </div>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-600 text-white shadow-xs">
                  {isEn ? 'Mandatory' : 'বাধ্যতামূলক'}
                </span>
              </div>

              {/* Toggle: Select Existing or Add New */}
              {contextLedgers.length > 0 && (
                <div className="flex rounded-xl p-1 bg-amber-100/80 dark:bg-amber-950/60 border border-amber-200/90 dark:border-amber-900/50 mb-3 text-xs font-bold">
                  <button
                    type="button"
                    id="ledger_mode_select_btn"
                    onClick={() => {
                      setLedgerMode('select');
                      setError('');
                      setHasLedgerValidationError(false);
                    }}
                    className={`flex-1 py-1.5 rounded-lg transition text-center cursor-pointer ${
                      ledgerMode === 'select'
                        ? 'bg-white dark:bg-slate-800 text-amber-950 dark:text-amber-100 shadow-xs'
                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                    }`}
                  >
                    {isEn ? 'Choose Existing Ledger' : 'বিদ্যমান লেজার থেকে নির্বাচন'}
                  </button>
                  <button
                    type="button"
                    id="ledger_mode_new_btn"
                    onClick={() => {
                      setLedgerMode('new');
                      setError('');
                      setHasLedgerValidationError(false);
                    }}
                    className={`flex-1 py-1.5 rounded-lg transition text-center cursor-pointer ${
                      ledgerMode === 'new'
                        ? 'bg-white dark:bg-slate-800 text-amber-950 dark:text-amber-100 shadow-xs'
                        : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                    }`}
                  >
                    {isEn ? '+ Add New Person / Entity' : '+ নতুন গ্রহিতা/দাতা'}
                  </button>
                </div>
              )}

              {ledgerMode === 'select' && contextLedgers.length > 0 ? (
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {isReceivableContext
                      ? isEn ? 'Select Recipient / Debtor (গ্রহিতা) *' : 'গ্রহিতা (দেনাদার) লেজার বেছে নিন *'
                      : isEn ? 'Select Giver / Creditor (দাতা) *' : 'দাতা (পাওনাদার) লেজার বেছে নিন *'}
                  </label>
                  <AccountSelectDropdown
                    id="ledger_account_select"
                    accounts={contextLedgers}
                    selectedAccountId={selectedLedgerAccountId}
                    onSelectAccount={(newId) => {
                      setSelectedLedgerAccountId(newId);
                      setError('');
                      setHasLedgerValidationError(false);
                    }}
                    isLight={isLight}
                    isEn={isEn}
                    placeholder={
                      isEn
                        ? '-- Select Recipient / Giver (Mandatory) * --'
                        : '-- গ্রহিতা/দাতা বেছে নিন (বাধ্যতামূলক) * --'
                    }
                    className={
                      hasLedgerValidationError
                        ? 'border-rose-500 ring-1 ring-rose-500'
                        : isLight
                        ? 'border-amber-300'
                        : 'border-amber-800'
                    }
                  />
                </div>
              ) : (
                <div className="space-y-2.5">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                      {isReceivableContext
                        ? isEn ? 'Recipient (Debtor) Name * (Mandatory)' : 'গ্রহিতা (দেনাদার) নাম * (বাধ্যতামূলক)'
                        : isEn ? 'Giver (Creditor) Name * (Mandatory)' : 'দাতা (পাওনাদার) নাম * (বাধ্যতামূলক)'}
                    </label>
                    <input
                      id="custom_ledger_name_input"
                      type="text"
                      placeholder={
                        isReceivableContext
                          ? isEn ? 'e.g. Rahim (Borrower)' : 'যেমন: রহিম (ধার গ্রহিতা / দেনাদার)'
                          : isEn ? 'e.g. Karim (Lender / Creditor)' : 'যেমন: করিম (ধার দাতা / পাওনাদার)'
                      }
                      value={customLedgerName}
                      onChange={(e) => {
                        setCustomLedgerName(e.target.value);
                        setError('');
                        setHasLedgerValidationError(false);
                      }}
                      className={`w-full px-3 py-2.5 rounded-xl border text-xs sm:text-sm font-bold ${
                        hasLedgerValidationError
                          ? 'border-rose-500 ring-1 ring-rose-500'
                          : 'border-amber-300 dark:border-amber-800'
                      } ${
                        isLight
                          ? 'bg-white text-slate-900 placeholder-slate-400'
                          : 'bg-slate-900 text-slate-100 placeholder-slate-500'
                      } outline-hidden focus:ring-2 focus:ring-amber-500`}
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                      {isEn ? 'Phone Number (Optional)' : 'মোবাইল নম্বর (ঐচ্ছিক)'}
                    </label>
                    <input
                      id="custom_ledger_phone_input"
                      type="tel"
                      placeholder="01XXXXXXXXX"
                      value={customLedgerPhone}
                      onChange={(e) => setCustomLedgerPhone(e.target.value)}
                      className={`w-full px-3 py-2 rounded-xl border text-xs font-semibold ${
                        isLight
                          ? 'bg-white border-amber-200 text-slate-900'
                          : 'bg-slate-900 border-slate-700 text-slate-100'
                      } outline-hidden focus:ring-2 focus:ring-amber-500`}
                    />
                  </div>
                </div>
              )}

              {hasLedgerValidationError && (
                <p className="text-xs font-bold text-rose-600 dark:text-rose-400 mt-2 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                  <span>
                    {isEn
                      ? 'Recipient / Giver (গ্রহিতা/দাতা) ledger is required for Receivables/Payables'
                      : 'Receivables বা Payables এর ক্ষেত্রে গ্রহিতা/দাতা লেজার সংযুক্ত করা বাধ্যতামূলক'}
                  </span>
                </p>
              )}
            </div>
          )}

          {/* Budget Alert Warning Banner if expense exceeds monthly limit */}
          {isOverBudget && (
            <div
              className={`p-3 ${
                isLight
                  ? 'bg-rose-50 border-rose-200 text-rose-800'
                  : 'bg-rose-950/80 border-rose-600/60 text-rose-200'
              } border rounded-xl text-xs flex items-start gap-2.5 animate-bounce`}
            >
              <AlertTriangle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">
                  {isEn ? 'Budget Limit Exceeded Warning!' : 'বাজেট অতিক্রম করার সতর্কতা!'}
                </p>
                <p className="mt-0.5 opacity-90">
                  {isEn
                    ? `Adding this expense will exceed your monthly budget limit (${formatCurrency(
                        totalBudgetLimit,
                        useBanglaDigits
                      )}).`
                    : `এই খরচটি যোগ করলে আপনার মাসিক বাজেট সীমারেখা (${formatCurrency(
                        totalBudgetLimit,
                        useBanglaDigits
                      )}) ছাড়িয়ে যাবে।`}
                </p>
              </div>
            </div>
          )}

          {/* Category Selector (Only for Standard Income and Expense) */}
          {(type === 'expense' || type === 'income') && (
            <div>
              <label
                className={`block text-xs font-semibold uppercase tracking-wider ${
                  isLight ? 'text-sky-800' : 'text-gray-400'
                } mb-2`}
              >
                {isEn ? 'Category *' : 'খাত বা ক্যাটাগরি *'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-44 overflow-y-auto p-1 pr-1">
                {filteredCategories.map((cat) => {
                  const isSelected = categoryId === cat.id;
                  return (
                    <button
                      type="button"
                      key={cat.id}
                      onClick={() => {
                        setCategoryId(cat.id);
                        setError('');
                      }}
                      className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-left text-xs transition cursor-pointer ${
                        isSelected
                          ? 'font-bold'
                          : isLight
                          ? 'border-sky-200 bg-sky-50/80 text-sky-950 hover:bg-sky-100 hover:border-sky-300'
                          : 'border-gray-800 bg-gray-950/60 text-gray-300 hover:border-gray-700 hover:bg-gray-800/50'
                      }`}
                      style={
                        isSelected
                          ? {
                              borderColor: dualAccent.primary.hex,
                              backgroundColor: `${dualAccent.primary.hex}22`,
                              color: isLight ? '#0f172a' : '#f8fafc',
                              boxShadow: `0 0 0 1.5px ${dualAccent.primary.hex}`,
                            }
                          : undefined
                      }
                    >
                      <div
                        className="p-1.5 rounded-lg shrink-0 flex items-center justify-center"
                        style={{ backgroundColor: `${cat.color}20`, color: cat.color }}
                      >
                        <CategoryIcon name={cat.icon} className="w-4 h-4" />
                      </div>
                      <span className="font-medium truncate">
                        {isEn ? cat.nameEnglish : cat.nameBangla}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Date & Note */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label
                className={`block text-xs font-semibold uppercase tracking-wider ${
                  isLight ? 'text-sky-800' : 'text-gray-400'
                } mb-1.5 flex items-center gap-1`}
              >
                <Calendar className="w-3.5 h-3.5" /> <span>{isEn ? 'Date' : 'তারিখ'}</span>
              </label>
              <input
                id="transaction_date_input"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className={`w-full px-3 py-2.5 ${
                  isLight
                    ? 'bg-sky-50/80 border-sky-200 text-sky-950 focus:border-emerald-500'
                    : 'bg-slate-900 border-slate-700 text-gray-200 focus:border-emerald-500'
                } border rounded-xl text-sm focus:outline-none`}
              />
            </div>

            <div>
              <label
                className={`block text-xs font-semibold uppercase tracking-wider ${
                  isLight ? 'text-sky-800' : 'text-gray-400'
                } mb-1.5 flex items-center gap-1`}
              >
                <FileText className="w-3.5 h-3.5" />{' '}
                <span>{isEn ? 'Note (Optional)' : 'বিবরণ / নোট (ঐচ্ছিক)'}</span>
              </label>
              <input
                id="transaction_note_input"
                type="text"
                placeholder={
                  type === 'transfer'
                    ? isEn ? 'e.g. Bank to bKash add money' : 'যেমন: ব্যাংক থেকে বিকাশে অ্যাড মানি'
                    : type === 'expense'
                    ? isEn ? 'e.g. Grocery items or Bills' : 'যেমন: বাজার বা ইউটিলিটি বিল'
                    : isEn ? 'e.g. Salary or Client fee' : 'যেমন: বেতন বা ফ্রিল্যান্সিং আয়'
                }
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className={`w-full px-3 py-2.5 ${
                  isLight
                    ? 'bg-sky-50/80 border-sky-200 text-sky-950 placeholder-sky-700/50 focus:border-emerald-500'
                    : 'bg-slate-900 border-slate-700 text-gray-200 placeholder-gray-500 focus:border-emerald-500'
                } border rounded-xl text-sm focus:outline-none`}
              />
            </div>
          </div>

          {error && (
            <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <p className="text-xs font-bold text-rose-600 dark:text-rose-400">{error}</p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="pt-2 flex items-center gap-3">
            <button
              type="button"
              id="cancel_add_transaction_btn"
              onClick={onClose}
              className={`flex-1 py-3 px-4 rounded-xl border ${
                isLight
                  ? 'border-sky-200 text-sky-800 hover:bg-sky-100 hover:text-sky-950'
                  : 'border-gray-800 text-gray-400 hover:text-white'
              } font-medium text-sm transition cursor-pointer`}
            >
              {isEn ? 'Cancel' : 'বাতিল'}
            </button>
            <button
              type="submit"
              id="save_add_transaction_btn"
              className={`flex-1 py-3 px-4 rounded-xl font-bold text-sm text-white shadow-lg transition flex items-center justify-center gap-2 cursor-pointer ${
                type === 'expense'
                  ? 'bg-rose-600 hover:bg-rose-500 shadow-rose-600/30'
                  : type === 'transfer'
                  ? 'bg-indigo-600 hover:bg-indigo-500 shadow-indigo-600/30'
                  : ''
              }`}
              style={type === 'income' ? dualAccent.primaryButtonStyle : undefined}
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>{isEn ? 'Save' : 'সংরক্ষণ করুন'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
