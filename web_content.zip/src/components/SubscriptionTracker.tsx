import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  ArrowUpDown, 
  Check, 
  Receipt, 
  Download, 
  Trash2, 
  Plus, 
  CheckCircle2, 
  Circle, 
  TrendingUp, 
  Users, 
  AlertCircle 
} from 'lucide-react';
import { formatINR, numberToWordsIndian } from '../data/pujaData';
import { PaymentState } from '../types';

interface SubscriptionTrackerProps {
  unitsData: Record<string, [string, number][]>;
  paymentState: PaymentState;
  onTogglePayment: (unit: string, index: number, paid: boolean) => void;
  onOpenReceipt: (member: { name: string; amount: number; unit: string; index: number }) => void;
  onOpenSaveJpg: (unit: string) => void;
  onClearAll: () => void;
  onOpenAddMember: (unit: string) => void;
  isUnlocked: boolean;
}

export const SubscriptionTracker: React.FC<SubscriptionTrackerProps> = ({
  unitsData,
  paymentState,
  onTogglePayment,
  onOpenReceipt,
  onOpenSaveJpg,
  onClearAll,
  onOpenAddMember,
  isUnlocked,
}) => {
  const [currentUnit, setCurrentUnit] = useState<string>('1');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'paid' | 'pending'>('all');
  const [sortBy, setSortBy] = useState<'default' | 'amount-desc' | 'amount-asc' | 'name-asc'>('default');
  const [isArmedClear, setIsArmedClear] = useState<boolean>(false);
  const [clearTimer, setClearTimer] = useState<any>(null);

  const unitKeys = Object.keys(unitsData);

  // Calculate stats for current selection
  const currentStats = useMemo(() => {
    let total = 0;
    let collected = 0;
    let totalMembers = 0;
    let paidMembers = 0;

    const listUnits = currentUnit === 'ALL' ? unitKeys : [currentUnit];

    listUnits.forEach((u) => {
      const items = unitsData[u] || [];
      items.forEach((r, i) => {
        total += r[1];
        totalMembers++;
        const key = `${u}-${i}`;
        if (paymentState[key]?.paid) {
          collected += r[1];
          paidMembers++;
        }
      });
    });

    const pending = total - collected;
    const percentage = total > 0 ? Math.round((collected / total) * 100) : 0;

    return { total, collected, pending, totalMembers, paidMembers, percentage };
  }, [currentUnit, unitsData, paymentState]);

  // Filtered and sorted member records
  const displayMembers = useMemo(() => {
    const list: {
      name: string;
      amount: number;
      unit: string;
      index: number;
      isPaid: boolean;
      paidAt?: string;
      method?: string;
    }[] = [];

    const listUnits = currentUnit === 'ALL' ? unitKeys : [currentUnit];

    listUnits.forEach((u) => {
      const items = unitsData[u] || [];
      items.forEach((r, i) => {
        const key = `${u}-${i}`;
        const isPaid = Boolean(paymentState[key]?.paid);
        const record = {
          name: r[0],
          amount: r[1],
          unit: u,
          index: i,
          isPaid,
          paidAt: paymentState[key]?.paidAt,
          method: paymentState[key]?.method || 'Cash',
        };

        // Filter by status
        if (statusFilter === 'paid' && !isPaid) return;
        if (statusFilter === 'pending' && isPaid) return;

        // Filter by search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchName = record.name.toLowerCase().includes(q);
          const matchUnit = `unit ${record.unit}`.toLowerCase().includes(q) || record.unit.toLowerCase().includes(q);
          const matchAmount = record.amount.toString().includes(q);
          if (!matchName && !matchUnit && !matchAmount) return;
        }

        list.push(record);
      });
    });

    // Sort
    if (sortBy === 'amount-desc') {
      list.sort((a, b) => b.amount - a.amount);
    } else if (sortBy === 'amount-asc') {
      list.sort((a, b) => a.amount - b.amount);
    } else if (sortBy === 'name-asc') {
      list.sort((a, b) => a.name.localeCompare(b.name));
    }

    return list;
  }, [currentUnit, unitsData, paymentState, statusFilter, searchQuery, sortBy]);

  const handleClearClick = () => {
    if (!isArmedClear) {
      setIsArmedClear(true);
      const timer = setTimeout(() => {
        setIsArmedClear(false);
      }, 4000);
      setClearTimer(timer);
    } else {
      clearTimeout(clearTimer);
      setIsArmedClear(false);
      onClearAll();
    }
  };

  return (
    <div className="space-y-5">
      {/* Unit Selector Pills bar */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        {unitKeys.map((u) => (
          <button
            key={u}
            onClick={() => setCurrentUnit(u)}
            className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              currentUnit === u
                ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30 font-bold'
                : 'bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300 hover:border-amber-400'
            }`}
          >
            <span>{u === 'MISC' ? 'MISC Unit' : `Unit ${u}`}</span>
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                currentUnit === u
                  ? 'bg-amber-800/60 text-amber-100'
                  : 'bg-stone-100 dark:bg-stone-800 text-stone-500 dark:text-stone-400'
              }`}
            >
              {unitsData[u]?.length || 0}
            </span>
          </button>
        ))}

        <button
          onClick={() => setCurrentUnit('ALL')}
          className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
            currentUnit === 'ALL'
              ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30 font-bold'
              : 'bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 text-stone-700 dark:text-stone-300 hover:border-amber-400'
          }`}
        >
          <span>All Units (Consolidated)</span>
        </button>
      </div>

      {/* Summary KPI Cards for Active Selection */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Total Budget Card */}
        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wider text-stone-500 dark:text-stone-400">
              Total Subscription
            </p>
            <p className="text-xl sm:text-2xl font-black text-stone-900 dark:text-stone-100 mt-0.5">
              ₹{formatINR(currentStats.total)}
            </p>
            <p className="text-xs text-stone-500 mt-0.5">
              {currentStats.totalMembers} members enrolled
            </p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-600 flex items-center justify-center">
            <Users className="w-5 h-5" />
          </div>
        </div>

        {/* Collected Amount Card */}
        <div className="bg-white dark:bg-stone-900 border border-emerald-500/20 dark:border-emerald-500/30 rounded-2xl p-4 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
              Collected (Paid)
            </p>
            <p className="text-xl sm:text-2xl font-black text-emerald-700 dark:text-emerald-400 mt-0.5">
              ₹{formatINR(currentStats.collected)}
            </p>
            <p className="text-xs text-emerald-600/80 mt-0.5">
              {currentStats.paidMembers} paid • {currentStats.percentage}% achieved
            </p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 flex items-center justify-center">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

        {/* Pending Balance Card */}
        <div className="bg-white dark:bg-stone-900 border border-rose-500/20 dark:border-rose-500/30 rounded-2xl p-4 shadow-sm flex items-center justify-between">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400">
              Pending Balance
            </p>
            <p className="text-xl sm:text-2xl font-black text-rose-700 dark:text-rose-400 mt-0.5">
              ₹{formatINR(currentStats.pending)}
            </p>
            <p className="text-xs text-rose-600/80 mt-0.5">
              {currentStats.totalMembers - currentStats.paidMembers} pending collections
            </p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 flex items-center justify-center">
            <AlertCircle className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Search, Filter, Sort and Action Toolbar */}
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-3 sm:p-4 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
          {/* Search box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search member name or amount..."
              className="w-full text-xs sm:text-sm pl-9 pr-4 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-stone-900 dark:text-stone-100 focus:outline-none focus:ring-2 focus:ring-amber-500 transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-stone-400 hover:text-stone-600"
              >
                ✕
              </button>
            )}
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1.5 self-start md:self-auto overflow-x-auto pb-1 md:pb-0">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                statusFilter === 'all'
                  ? 'bg-stone-800 text-white dark:bg-stone-200 dark:text-stone-900 font-bold'
                  : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400 hover:bg-stone-200'
              }`}
            >
              All ({currentStats.totalMembers})
            </button>
            <button
              onClick={() => setStatusFilter('paid')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1 ${
                statusFilter === 'paid'
                  ? 'bg-emerald-600 text-white font-bold'
                  : 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Paid ({currentStats.paidMembers})</span>
            </button>
            <button
              onClick={() => setStatusFilter('pending')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1 ${
                statusFilter === 'pending'
                  ? 'bg-rose-600 text-white font-bold'
                  : 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 hover:bg-rose-100'
              }`}
            >
              <Circle className="w-3.5 h-3.5" />
              <span>Pending ({currentStats.totalMembers - currentStats.paidMembers})</span>
            </button>
          </div>

          {/* Sort selector */}
          <div className="flex items-center gap-2">
            <ArrowUpDown className="w-3.5 h-3.5 text-stone-400" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="text-xs py-1.5 px-2.5 rounded-lg border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-stone-700 dark:text-stone-300 focus:outline-none focus:ring-2 focus:ring-amber-500"
            >
              <option value="default">Default Order</option>
              <option value="amount-desc">Amount: High to Low</option>
              <option value="amount-asc">Amount: Low to High</option>
              <option value="name-asc">Name: A to Z</option>
            </select>
          </div>
        </div>

        {/* Action Buttons: Save JPG, Add Member, Clear All */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-stone-100 dark:border-stone-800 text-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenSaveJpg(currentUnit)}
              className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-sm transition"
            >
              <Download className="w-4 h-4" />
              <span>Save as JPG</span>
            </button>

            {currentUnit !== 'ALL' && (
              <button
                onClick={() => onOpenAddMember(currentUnit)}
                className="px-3.5 py-2 bg-stone-100 dark:bg-stone-800 text-stone-800 dark:text-stone-200 font-semibold rounded-xl hover:bg-stone-200 dark:hover:bg-stone-700 transition flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4 text-amber-600" />
                <span>Add Member</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleClearClick}
              className={`px-3 py-1.5 rounded-xl font-semibold transition flex items-center gap-1.5 ${
                isArmedClear
                  ? 'bg-red-600 text-white animate-pulse'
                  : 'text-stone-500 hover:text-red-600 dark:text-stone-400 hover:bg-red-50 dark:hover:bg-red-950/30'
              }`}
              title="Clear all recorded payments with confirmation"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{isArmedClear ? 'Tap again to confirm CLEAR ALL' : 'Clear all ticks'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Member Cards List */}
      <div className="space-y-2">
        {displayMembers.length === 0 ? (
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-10 text-center text-stone-500 space-y-2">
            <Users className="w-8 h-8 mx-auto text-stone-400" />
            <p className="text-sm font-semibold">No member records found matching your filters</p>
            <p className="text-xs text-stone-400">Try clearing the search query or status filter.</p>
          </div>
        ) : (
          displayMembers.map((member) => (
            <div
              key={`${member.unit}-${member.index}`}
              className={`flex items-center gap-3 p-3 sm:p-3.5 rounded-xl border transition-all ${
                member.isPaid
                  ? 'bg-emerald-50/70 dark:bg-emerald-950/25 border-emerald-500/40 shadow-sm'
                  : 'bg-white dark:bg-stone-900 border-stone-200 dark:border-stone-800 hover:border-amber-300'
              }`}
            >
              {/* Checkbox */}
              <label className="relative flex items-center justify-center cursor-pointer p-1">
                <input
                  type="checkbox"
                  checked={member.isPaid}
                  onChange={(e) => onTogglePayment(member.unit, member.index, e.target.checked)}
                  className="w-6 h-6 rounded-lg text-emerald-600 border-stone-300 focus:ring-emerald-500 cursor-pointer accent-emerald-600"
                />
              </label>

              {/* Member Details */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-stone-400 dark:text-stone-500 font-mono">
                    #{member.index + 1}
                  </span>
                  <p
                    className={`text-sm sm:text-base font-bold truncate ${
                      member.isPaid
                        ? 'text-stone-900 dark:text-stone-100'
                        : 'text-stone-800 dark:text-stone-200'
                    }`}
                  >
                    {member.name}
                  </p>
                  {currentUnit === 'ALL' && (
                    <span className="text-[10px] px-2 py-0.5 bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300 rounded font-medium">
                      {member.unit === 'MISC' ? 'MISC' : `Unit ${member.unit}`}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2 mt-0.5 text-xs text-stone-500 dark:text-stone-400">
                  <span>
                    {member.isPaid ? (
                      <span className="text-emerald-700 dark:text-emerald-400 font-semibold flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" />
                        <span>Paid • {member.method}</span>
                      </span>
                    ) : (
                      <span className="text-stone-400">Payment pending</span>
                    )}
                  </span>
                </div>
              </div>

              {/* Amount & Actions */}
              <div className="flex items-center gap-2 sm:gap-3 shrink-0">
                <div className="text-right">
                  <p className="text-base sm:text-lg font-black text-stone-900 dark:text-stone-100">
                    ₹{formatINR(member.amount)}
                  </p>
                  <p className="text-[10px] text-stone-400 hidden sm:block">Chanda Subscription</p>
                </div>

                {/* Receipt Generator Button */}
                <button
                  onClick={() => onOpenReceipt(member)}
                  className={`p-2 rounded-xl transition flex items-center gap-1 text-xs font-semibold ${
                    member.isPaid
                      ? 'bg-amber-500/10 text-amber-800 dark:text-amber-300 hover:bg-amber-500/20 border border-amber-500/30'
                      : 'bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400 hover:bg-stone-200 dark:hover:bg-stone-700'
                  }`}
                  title="Generate Official Chanda Receipt"
                >
                  <Receipt className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                  <span className="hidden md:inline">Receipt</span>
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
