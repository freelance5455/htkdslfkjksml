import { useState } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import {
  TrendingUp,
  TrendingDown,
  Sparkles,
  Calendar,
  DollarSign,
  AlertCircle,
  BarChart3,
  Globe2,
} from 'lucide-react';
import { Language } from '../types';
import { playKeyTap } from '../utils/audio';

interface CropPriceTrendChartProps {
  language: Language;
  initialCropId?: string;
}

interface CropTrendData {
  id: string;
  nameSw: string;
  nameEn: string;
  marketType: 'local' | 'world';
  exchangeName: string;
  currentPriceTsh: number;
  unit: string;
  change30DaysPercent: number;
  isUp: boolean;
  adviceSw: string;
  adviceEn: string;
  sellingSignal: 'strong_sell' | 'hold' | 'accumulate';
  history: { day: string; price: number; usdPrice?: number }[];
}

export const CROP_TRENDS_DATA: CropTrendData[] = [
  {
    id: 'crop-maize',
    nameSw: 'Mahindi (Kibaigwa & Kariakoo)',
    nameEn: 'Maize (National Grain Hubs)',
    marketType: 'local',
    exchangeName: 'Kibaigwa Grain Market',
    currentPriceTsh: 780,
    unit: 'kilo',
    change30DaysPercent: 14.7,
    isUp: true,
    adviceSw:
      'Bei inapanda kutokana na mahitaji makubwa ya viwanda vya unga Dar es Salaam na Kenya. Inashauriwa kuuza wiki ijayo kabla ya msimu mpya wa mavuno ya kusini kuanza.',
    adviceEn:
      'Prices climbing due to high miller demand in Dar and cross-border exports to Kenya. Recommended to sell within the next 10 days before Southern highland harvests peak.',
    sellingSignal: 'strong_sell',
    history: [
      { day: 'Siku 1', price: 680 },
      { day: 'Siku 5', price: 690 },
      { day: 'Siku 10', price: 710 },
      { day: 'Siku 15', price: 730 },
      { day: 'Siku 20', price: 750 },
      { day: 'Siku 25', price: 765 },
      { day: 'Leo', price: 780 },
    ],
  },
  {
    id: 'crop-coffee-arabica',
    nameSw: 'Kahawa Arabica (Soko la Dunia)',
    nameEn: 'Arabica Coffee (World ICE Futures)',
    marketType: 'world',
    exchangeName: 'ICE Futures New York',
    currentPriceTsh: 13750,
    unit: 'kilo',
    change30DaysPercent: 18.2,
    isUp: true,
    adviceSw:
      'Bei ya dunia imepanda hadi $2.44/lb kutokana na ukame nchini Brazil. Msimu huu unatoa bei ya juu zaidi ya miaka 3 iliyopita kwa wakulima wa Mbeya na Kilimanjaro!',
    adviceEn:
      'Global benchmark hit $2.44/lb on Brazil drought supply shocks. This is a 3-year peak price window for Tanzanian Arabica specialty growers.',
    sellingSignal: 'strong_sell',
    history: [
      { day: 'Siku 1', price: 11600, usdPrice: 4.52 },
      { day: 'Siku 5', price: 11950, usdPrice: 4.65 },
      { day: 'Siku 10', price: 12400, usdPrice: 4.83 },
      { day: 'Siku 15', price: 12900, usdPrice: 5.02 },
      { day: 'Siku 20', price: 13250, usdPrice: 5.16 },
      { day: 'Siku 25', price: 13500, usdPrice: 5.26 },
      { day: 'Leo', price: 13750, usdPrice: 5.35 },
    ],
  },
  {
    id: 'crop-cocoa',
    nameSw: 'Kakao Bora (Soko la Dunia)',
    nameEn: 'Cocoa (ICE London / Global)',
    marketType: 'world',
    exchangeName: 'ICE Cocoa Futures (London)',
    currentPriceTsh: 20200,
    unit: 'kilo',
    change30DaysPercent: 24.5,
    isUp: true,
    adviceSw:
      'Uhaba mkubwa wa kakao Afrika Magharibi umesababisha bei kufikia rekodi ya kihistoria ($7,850/Tonne). Wakulima wa Kyela na Morogoro wanashauriwa kukausha vizuri kabla ya kuuza.',
    adviceEn:
      'Historic global supply deficits in West Africa have pushed prices to unprecedented highs ($7,850/MT). Ensure optimal fermentation & drying for grade 1 premium pricing.',
    sellingSignal: 'strong_sell',
    history: [
      { day: 'Siku 1', price: 16200, usdPrice: 6.3 },
      { day: 'Siku 5', price: 17100, usdPrice: 6.65 },
      { day: 'Siku 10', price: 17800, usdPrice: 6.93 },
      { day: 'Siku 15', price: 18600, usdPrice: 7.24 },
      { day: 'Siku 20', price: 19400, usdPrice: 7.55 },
      { day: 'Siku 25', price: 19850, usdPrice: 7.73 },
      { day: 'Leo', price: 20200, usdPrice: 7.86 },
    ],
  },
  {
    id: 'crop-cashew',
    nameSw: 'Korosho Ghafi RCN (Soko Kuu)',
    nameEn: 'Raw Cashew Nuts (Mtwara & World Export)',
    marketType: 'world',
    exchangeName: 'Mtwara Auction / India Export',
    currentPriceTsh: 3650,
    unit: 'kilo',
    change30DaysPercent: 8.8,
    isUp: true,
    adviceSw:
      'Mnada wa Mtwara na Lindi unaendelea kwa kasi nzuri. Wanunuzi kutoka India na Vietnam wanakubali bei nzuri kwa korosho zenye Out-turn ya zaidi ya 48 lbs.',
    adviceEn:
      'Mtwara Port auctions show steady appetite from Indian and Vietnamese shellers for high KOR (Kernel Output Ratio 48+ lbs).',
    sellingSignal: 'hold',
    history: [
      { day: 'Siku 1', price: 3350 },
      { day: 'Siku 5', price: 3400 },
      { day: 'Siku 10', price: 3480 },
      { day: 'Siku 15', price: 3520 },
      { day: 'Siku 20', price: 3580 },
      { day: 'Siku 25', price: 3620 },
      { day: 'Leo', price: 3650 },
    ],
  },
  {
    id: 'crop-rice',
    nameSw: 'Mpunga Super Saro (Kilombero)',
    nameEn: 'Paddy Rice Saro (Kilombero Valley)',
    marketType: 'local',
    exchangeName: 'Kariakoo & Ifakara Hub',
    currentPriceTsh: 1250,
    unit: 'kilo',
    change30DaysPercent: 6.4,
    isUp: true,
    adviceSw:
      'Mchele wa Morogoro unaendelea kuongoza kwa ubora. Uhitaji wa mchele safi usio na chenga unalipa zaidi katika masoko ya jijini.',
    adviceEn:
      'Morogoro SARO 5 grain commands standard premium. Grade A unmixed long grains fetch consistent top wholesale rates in Dar es Salaam.',
    sellingSignal: 'hold',
    history: [
      { day: 'Siku 1', price: 1175 },
      { day: 'Siku 5', price: 1190 },
      { day: 'Siku 10', price: 1210 },
      { day: 'Siku 15', price: 1225 },
      { day: 'Siku 20', price: 1235 },
      { day: 'Siku 25', price: 1245 },
      { day: 'Leo', price: 1250 },
    ],
  },
  {
    id: 'crop-cotton',
    nameSw: 'Pamba Safi (Soko la Dunia)',
    nameEn: 'Cotton No. 2 (NY Mercantile)',
    marketType: 'world',
    exchangeName: 'New York Mercantile Exchange',
    currentPriceTsh: 4700,
    unit: 'kilo',
    change30DaysPercent: -2.8,
    isUp: false,
    adviceSw:
      'Bei ya pamba kimataifa imetetereka kidogo kutokana na uzalishaji mkubwa nchini Marekani na China. Inashauriwa kusubiri kabla ya kuachia magunia mengi.',
    adviceEn:
      'World cotton benchmark contracted 2.8% on higher US & Chinese export inventories. Hold volume if storage allows.',
    sellingSignal: 'accumulate',
    history: [
      { day: 'Siku 1', price: 4840 },
      { day: 'Siku 5', price: 4800 },
      { day: 'Siku 10', price: 4780 },
      { day: 'Siku 15', price: 4750 },
      { day: 'Siku 20', price: 4720 },
      { day: 'Siku 25', price: 4710 },
      { day: 'Leo', price: 4700 },
    ],
  },
];

export default function CropPriceTrendChart({
  language,
  initialCropId = 'crop-coffee-arabica',
}: CropPriceTrendChartProps) {
  const isSw = language === 'sw';
  const [selectedCropId, setSelectedCropId] = useState<string>(initialCropId);

  const selectedCrop =
    CROP_TRENDS_DATA.find((c) => c.id === selectedCropId) || CROP_TRENDS_DATA[0];

  const minPrice = Math.min(...selectedCrop.history.map((h) => h.price));
  const maxPrice = Math.max(...selectedCrop.history.map((h) => h.price));

  return (
    <div
      id="crop-price-trend-chart-card"
      className="p-4 rounded-3xl bg-[var(--paper)] border border-[var(--line)] shadow-sm space-y-3.5"
    >
      {/* Header & Crop Selector */}
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[var(--forest)] text-[#F7F4E9] flex items-center justify-center">
              <BarChart3 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-xs text-[var(--ink)]">
                {isSw ? 'Mwenendo wa Bei (Siku 30 Zilizopita)' : '30-Day Price Trend Analytics'}
              </h3>
              <div className="text-[10px] text-[var(--ink-soft)] flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                <span>{selectedCrop.exchangeName}</span>
                {selectedCrop.marketType === 'world' && (
                  <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-amber-500/15 text-amber-700 dark:text-amber-300">
                    {isSw ? 'Soko la Dunia' : 'World Market'}
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="text-right">
            <div className="font-display font-bold text-base text-[var(--forest)]">
              Tsh {selectedCrop.currentPriceTsh.toLocaleString()}
              <span className="text-[10px] font-normal text-[var(--ink-soft)]">/{selectedCrop.unit}</span>
            </div>
            <div
              className={`text-[10px] font-bold flex items-center justify-end gap-0.5 ${
                selectedCrop.isUp ? 'text-[var(--up)]' : 'text-[var(--down)]'
              }`}
            >
              {selectedCrop.isUp ? (
                <TrendingUp className="w-3 h-3" />
              ) : (
                <TrendingDown className="w-3 h-3" />
              )}
              <span>
                {selectedCrop.isUp ? '+' : ''}
                {selectedCrop.change30DaysPercent}% {isSw ? '(Mwezi 1)' : '(1 Month)'}
              </span>
            </div>
          </div>
        </div>

        {/* Crop Pills Selector */}
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-1">
          {CROP_TRENDS_DATA.map((crop) => {
            const isSelected = crop.id === selectedCropId;
            return (
              <button
                key={crop.id}
                onClick={() => {
                  playKeyTap();
                  setSelectedCropId(crop.id);
                }}
                className={`px-3 py-1.5 rounded-xl text-[11px] font-semibold flex-shrink-0 transition-all cursor-pointer border ${
                  isSelected
                    ? 'bg-[var(--forest)] text-[#F7F4E9] border-[var(--forest)] shadow-sm'
                    : 'bg-[var(--bg)] text-[var(--ink-soft)] border-[var(--line)] hover:border-[var(--forest)]/40 hover:text-[var(--ink)]'
                }`}
              >
                {isSw ? crop.nameSw.split(' ')[0] : crop.nameEn.split(' ')[0]}
                {crop.marketType === 'world' ? ' 🌍' : ''}
              </button>
            );
          })}
        </div>
      </div>

      {/* Recharts Chart Canvas */}
      <div className="h-44 w-full pt-1">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={selectedCrop.history}
            margin={{ top: 8, right: 8, left: -20, bottom: 0 }}
          >
            <defs>
              <linearGradient id="cropPriceGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#2D5A43" stopOpacity={0.45} />
                <stop offset="95%" stopColor="#2D5A43" stopOpacity={0.0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(128,128,128,0.15)" />
            <XAxis
              dataKey="day"
              tick={{ fontSize: 9, fill: 'var(--ink-soft)' }}
              tickLine={false}
              axisLine={false}
            />
            <YAxis
              domain={[Math.floor(minPrice * 0.95), Math.ceil(maxPrice * 1.05)]}
              tick={{ fontSize: 9, fill: 'var(--ink-soft)' }}
              tickLine={false}
              axisLine={false}
              tickFormatter={(v) => (v >= 1000 ? `${(v / 1000).toFixed(1)}k` : `${v}`)}
            />
            <Tooltip
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  const data = payload[0].payload;
                  return (
                    <div className="bg-[var(--paper)] border border-[var(--line)] shadow-xl p-2.5 rounded-xl text-xs space-y-0.5">
                      <div className="font-semibold text-[10px] text-[var(--ink-soft)]">{data.day}</div>
                      <div className="font-display font-bold text-sm text-[var(--forest)]">
                        Tsh {Number(data.price).toLocaleString()}/{selectedCrop.unit}
                      </div>
                      {data.usdPrice && (
                        <div className="text-[10px] text-amber-600 dark:text-amber-300 font-medium">
                          ≈ ${data.usdPrice}/kg USD
                        </div>
                      )}
                    </div>
                  );
                }
                return null;
              }}
            />
            <Area
              type="monotone"
              dataKey="price"
              stroke="#2D5A43"
              strokeWidth={2.5}
              fillOpacity={1}
              fill="url(#cropPriceGradient)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Selling Advisory Card for the Farmer */}
      <div className="p-3 rounded-2xl bg-[var(--bg)] border border-[var(--line)] text-xs space-y-1.5">
        <div className="flex items-center justify-between">
          <div className="font-bold text-[var(--ink)] flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>{isSw ? 'Ushauri wa Kufanya Mauzo Bora:' : 'Strategic Selling Recommendation:'}</span>
          </div>

          <span
            className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
              selectedCrop.sellingSignal === 'strong_sell'
                ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30'
                : selectedCrop.sellingSignal === 'hold'
                ? 'bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/30'
                : 'bg-blue-500/15 text-blue-700 dark:text-blue-300 border-blue-500/30'
            }`}
          >
            {selectedCrop.sellingSignal === 'strong_sell'
              ? isSw
                ? 'Wakati Mzuri wa Kuuza 🚀'
                : 'Optimal Selling Peak 🚀'
              : selectedCrop.sellingSignal === 'hold'
              ? isSw
                ? 'Subiri / Hifadhi ⏳'
                : 'Hold Volume ⏳'
              : isSw
                ? 'Kusanya Mazao 📦'
                : 'Accumulate 📦'}
          </span>
        </div>

        <p className="text-[11px] text-[var(--ink-soft)] leading-relaxed">
          {isSw ? selectedCrop.adviceSw : selectedCrop.adviceEn}
        </p>
      </div>
    </div>
  );
}
