import React from 'react';
import { X, Sliders, Volume2, FileAudio, FileText, Cpu, Check } from 'lucide-react';
import {
  AudioSettings,
  NarrationStyleId,
  TextProcessingSettings,
  TTSEngineType,
  VoiceSettings,
} from '../types/tts';

interface AdvancedSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  voiceSettings: VoiceSettings;
  onChangeVoiceSettings: (settings: VoiceSettings) => void;
  audioSettings: AudioSettings;
  onChangeAudioSettings: (settings: AudioSettings) => void;
  textSettings: TextProcessingSettings;
  onChangeTextSettings: (settings: TextProcessingSettings) => void;
  activeEngine: TTSEngineType;
  onChangeEngine: (engine: TTSEngineType) => void;
}

export const AdvancedSettingsModal: React.FC<AdvancedSettingsModalProps> = ({
  isOpen,
  onClose,
  voiceSettings,
  onChangeVoiceSettings,
  audioSettings,
  onChangeAudioSettings,
  textSettings,
  onChangeTextSettings,
  activeEngine,
  onChangeEngine,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-3xl bg-[#101522] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-100">
                సమగ్ర సెట్టింగ్‌లు (Advanced Audio & Engine Settings)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                వాయిస్, బిట్‌రేట్, ఆడియో ఫార్మాట్ మరియు టెక్స్ట్ ప్రీ-ప్రాసెసింగ్ పారామితులు
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-6 flex-1 scrollbar-thin">
          {/* Section 1: TTS Engine */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-400 mb-3 flex items-center gap-2">
              <Cpu className="w-4 h-4" />
              <span>1. వాయిస్ సింథసిస్ ఇంజిన్ (Synthesis Engine)</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => onChangeEngine('edge-neural')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                  activeEngine === 'edge-neural'
                    ? 'bg-emerald-500/15 border-emerald-500 text-emerald-200 ring-1 ring-emerald-500/40'
                    : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:bg-slate-900'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="font-bold text-sm text-emerald-300">Realistic Neural Studio</div>
                  {activeEngine === 'edge-neural' && <Check className="w-4 h-4 text-emerald-400" />}
                </div>
                <div className="text-xs text-slate-400 mt-1">
                  మోహన్ & శృతి వంటి అత్యంత సహజమైన మానవ శైలి తెలుగు గళాలు.
                </div>
              </button>

              <button
                type="button"
                onClick={() => onChangeEngine('gemini-neural')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                  activeEngine === 'gemini-neural'
                    ? 'bg-cyan-500/15 border-cyan-500 text-cyan-200 ring-1 ring-cyan-500/40'
                    : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:bg-slate-900'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="font-bold text-sm">Gemini 3.1 Flash Neural</div>
                  {activeEngine === 'gemini-neural' && <Check className="w-4 h-4 text-cyan-400" />}
                </div>
                <div className="text-xs text-slate-400 mt-1">
                  24kHz స్టూడియో పిసిఎమ్ నాణ్యతతో కూడిన ప్రత్యేక తెలుగు ఏఐ టింబ్రెస్.
                </div>
              </button>

              <button
                type="button"
                onClick={() => onChangeEngine('native-telugu')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                  activeEngine === 'native-telugu'
                    ? 'bg-cyan-500/15 border-cyan-500 text-cyan-200 ring-1 ring-cyan-500/40'
                    : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:bg-slate-900'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="font-bold text-sm">Native Telugu (Google te-IN)</div>
                  {activeEngine === 'native-telugu' && <Check className="w-4 h-4 text-cyan-400" />}
                </div>
                <div className="text-xs text-slate-400 mt-1">
                  ప్రత్యక్ష తెలుగు ఆడియో స్ట్రీమింగ్, వేగవంతమైన జనరేషన్.
                </div>
              </button>
            </div>
          </div>

          {/* Section 2: Audio Format & Bitrate */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400 mb-3 flex items-center gap-2">
              <FileAudio className="w-4 h-4" />
              <span>2. ఆడియో ఎగుమతి & ఎన్‌కోడింగ్ (Audio Export & Bitrate)</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-900/50 p-4 rounded-xl border border-slate-800">
              {/* Format selection */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">
                  డిఫాల్ట్ ఆడియో ఫార్మాట్ (Audio Format):
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onChangeAudioSettings({ ...audioSettings, format: 'mp3' })}
                    className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
                      audioSettings.format === 'mp3'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    MP3 (సిఫార్సు చేయబడింది)
                  </button>
                  <button
                    type="button"
                    onClick={() => onChangeAudioSettings({ ...audioSettings, format: 'wav' })}
                    className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
                      audioSettings.format === 'wav'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    WAV (లాస్‌లెస్)
                  </button>
                </div>
              </div>

              {/* Bitrate selection */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">
                  MP3 బిట్‌రేట్ (Bitrate):
                </label>
                <div className="grid grid-cols-4 gap-1.5">
                  {[128, 192, 256, 320].map((rate) => (
                    <button
                      key={rate}
                      type="button"
                      onClick={() =>
                        onChangeAudioSettings({ ...audioSettings, bitrate: rate as any })
                      }
                      className={`py-1.5 rounded-lg text-xs font-mono font-medium transition-all ${
                        audioSettings.bitrate === rate
                          ? 'bg-emerald-500 text-slate-950 font-bold'
                          : 'bg-slate-800 text-slate-300 border border-slate-700'
                      }`}
                    >
                      {rate}k
                    </button>
                  ))}
                </div>
              </div>

              {/* Volume Normalization toggle */}
              <div className="sm:col-span-2 pt-2 border-t border-slate-800/80 flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-slate-200">
                    ఆటోమేటిక్ వాల్యూమ్ నార్మలైజేషన్ (Normalize Audio Volume)
                  </div>
                  <div className="text-[11px] text-slate-400">
                    ఆడియో శిఖరాలను సరిచేసి స్పష్టమైన, స్థిరమైన సౌండ్ అవుట్‌పుట్‌ను ఇస్తుంది
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={audioSettings.normalizeVolume}
                  onChange={(e) =>
                    onChangeAudioSettings({
                      ...audioSettings,
                      normalizeVolume: e.target.checked,
                    })
                  }
                  className="w-4 h-4 rounded text-emerald-500 focus:ring-emerald-500 bg-slate-800 border-slate-700 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Telugu Text Preprocessing Rules */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-purple-400 mb-3 flex items-center gap-2">
              <FileText className="w-4 h-4" />
              <span>3. తెలుగు టెక్స్ట్ ప్రాసెసింగ్ నియమాలు (Text Rules)</span>
            </h4>
            <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800 space-y-3">
              <label className="flex items-center justify-between cursor-pointer">
                <div>
                  <div className="text-xs font-semibold text-slate-200">
                    సంఖ్యల తెలుగు ఉచ్చారణ (Number Pronunciation)
                  </div>
                  <div className="text-[11px] text-slate-400">
                    సంఖ్యలను స్వయంచాలకంగా తెలుగు అక్షరాలుగా మారుస్తుంది (ఉదా: 2026 ➔ రెండు వేల ఇరవై ఆరు)
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={textSettings.numberPronunciation}
                  onChange={(e) =>
                    onChangeTextSettings({
                      ...textSettings,
                      numberPronunciation: e.target.checked,
                    })
                  }
                  className="w-4 h-4 rounded text-purple-500 focus:ring-purple-500 bg-slate-800 border-slate-700 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between cursor-pointer pt-2 border-t border-slate-800/80">
                <div>
                  <div className="text-xs font-semibold text-slate-200">
                    కరెన్సీ ఉచ్చారణ (Currency Pronunciation)
                  </div>
                  <div className="text-[11px] text-slate-400">
                    ₹500 లేదా $100 లాంటి చిహ్నాలను "ఐదు వందల రూపాయలు"గా మారుస్తుంది
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={textSettings.currencyPronunciation}
                  onChange={(e) =>
                    onChangeTextSettings({
                      ...textSettings,
                      currencyPronunciation: e.target.checked,
                    })
                  }
                  className="w-4 h-4 rounded text-purple-500 focus:ring-purple-500 bg-slate-800 border-slate-700 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between cursor-pointer pt-2 border-t border-slate-800/80">
                <div>
                  <div className="text-xs font-semibold text-slate-200">
                    ఆటోమేటిక్ విరామ చిహ్నాల అమరిక (Auto Punctuation)
                  </div>
                  <div className="text-[11px] text-slate-400">
                    వాక్యాల చివర ఖచ్చితమైన విరామాలు ఉండేలా చూస్తుంది
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={textSettings.autoPunctuation}
                  onChange={(e) =>
                    onChangeTextSettings({
                      ...textSettings,
                      autoPunctuation: e.target.checked,
                    })
                  }
                  className="w-4 h-4 rounded text-purple-500 focus:ring-purple-500 bg-slate-800 border-slate-700 cursor-pointer"
                />
              </label>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 flex justify-end bg-slate-900/80">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-all cursor-pointer"
          >
            సెట్టింగ్‌లను సేవ్ చేయండి (Save Settings)
          </button>
        </div>
      </div>
    </div>
  );
};
