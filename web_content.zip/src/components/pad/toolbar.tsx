import {
  Bold,
  Italic,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignRight,
  List,
  ListOrdered,
  ImagePlus,
  CalendarClock,
  Search,
  ZoomIn,
  ZoomOut,
  Printer,
  Eye,
  Scissors,
  Copy,
  ClipboardPaste,
  Type,
  Highlighter,
  Palette,
  Rows3,
  Indent,
  Outdent,
  FileStack,
  Strikethrough,
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  FONTS,
  FONT_SIZES,
  INK_COLORS,
  HIGHLIGHTS,
  SPACING,
} from "@/lib/default-doc";

export type Tray = "font" | "size" | "color" | "highlight" | "spacing" | "zoom" | null;

export type FormatFlags = {
  bold: boolean;
  italic: boolean;
  underline: boolean;
};

function ToolBtn({
  label,
  active,
  onClick,
  children,
}: {
  label: string;
  active?: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      aria-pressed={active}
      onMouseDown={(event) => event.preventDefault()}
      onClick={onClick}
      className={cn(
        "inline-flex size-11 shrink-0 items-center justify-center rounded-md text-ink/80 transition-[background-color,color,transform] duration-150 ease-out active:scale-[0.96]",
        active ? "bg-accent/12 text-accent" : "hover:bg-ink/6",
      )}
    >
      {children}
    </button>
  );
}

function SlideRow({ children }: { children: React.ReactNode }) {
  return (
    <div className="slide-row flex gap-0.5 overflow-x-auto overscroll-x-contain px-2 pb-1">
      {children}
    </div>
  );
}

export function FormatToolbar({
  flags,
  tray,
  zoom,
  onTray,
  onExec,
  onFont,
  onSize,
  onColor,
  onHighlight,
  onSpacing,
  onPicture,
  onDate,
  onFind,
  onZoomIn,
  onZoomOut,
  onZoomSet,
  onPageSetup,
  onPrint,
  onPrintPreview,
}: {
  flags: FormatFlags;
  tray: Tray;
  zoom: number;
  onTray: (tray: Tray) => void;
  onExec: (cmd: string, value?: string) => void;
  onFont: (name: string) => void;
  onSize: (px: string) => void;
  onColor: (color: string) => void;
  onHighlight: (color: string) => void;
  onSpacing: (value: string) => void;
  onPicture: () => void;
  onDate: () => void;
  onFind: () => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onZoomSet: (zoom: number) => void;
  onPageSetup: () => void;
  onPrint: () => void;
  onPrintPreview: () => void;
}) {
  const toggle = (next: Tray) => onTray(tray === next ? null : next);

  return (
    <div className="border-b border-line bg-surface">
      <SlideRow>
        <ToolBtn label="Bold" active={flags.bold} onClick={() => onExec("bold")}>
          <Bold className="size-4" strokeWidth={2.25} />
        </ToolBtn>
        <ToolBtn label="Italic" active={flags.italic} onClick={() => onExec("italic")}>
          <Italic className="size-4" />
        </ToolBtn>
        <ToolBtn label="Underline" active={flags.underline} onClick={() => onExec("underline")}>
          <Underline className="size-4" />
        </ToolBtn>
        <ToolBtn label="Strikethrough" onClick={() => onExec("strikeThrough")}>
          <Strikethrough className="size-4" />
        </ToolBtn>
        <span className="mx-1 my-3 w-px shrink-0 bg-line" />
        <ToolBtn label="Font" active={tray === "font"} onClick={() => toggle("font")}>
          <Type className="size-4" />
        </ToolBtn>
        <ToolBtn label="Font size" active={tray === "size"} onClick={() => toggle("size")}>
          <span className="font-sans text-xs font-semibold">Tt</span>
        </ToolBtn>
        <ToolBtn label="Text color" active={tray === "color"} onClick={() => toggle("color")}>
          <Palette className="size-4" />
        </ToolBtn>
        <ToolBtn
          label="Highlight"
          active={tray === "highlight"}
          onClick={() => toggle("highlight")}
        >
          <Highlighter className="size-4" />
        </ToolBtn>
        <span className="mx-1 my-3 w-px shrink-0 bg-line" />
        <ToolBtn label="Align left" onClick={() => onExec("justifyLeft")}>
          <AlignLeft className="size-4" />
        </ToolBtn>
        <ToolBtn label="Align center" onClick={() => onExec("justifyCenter")}>
          <AlignCenter className="size-4" />
        </ToolBtn>
        <ToolBtn label="Align right" onClick={() => onExec("justifyRight")}>
          <AlignRight className="size-4" />
        </ToolBtn>
        <ToolBtn label="Bullets" onClick={() => onExec("insertUnorderedList")}>
          <List className="size-4" />
        </ToolBtn>
        <ToolBtn label="Numbered list" onClick={() => onExec("insertOrderedList")}>
          <ListOrdered className="size-4" />
        </ToolBtn>
        <ToolBtn label="Line spacing" active={tray === "spacing"} onClick={() => toggle("spacing")}>
          <Rows3 className="size-4" />
        </ToolBtn>
      </SlideRow>
      <SlideRow>
        <ToolBtn label="Insert picture" onClick={onPicture}>
          <ImagePlus className="size-4" />
        </ToolBtn>
        <ToolBtn label="Insert date and time" onClick={onDate}>
          <CalendarClock className="size-4" />
        </ToolBtn>
        <ToolBtn label="Find" onClick={onFind}>
          <Search className="size-4" />
        </ToolBtn>
        <ToolBtn label="Zoom out" onClick={onZoomOut}>
          <ZoomOut className="size-4" />
        </ToolBtn>
        <ToolBtn label="Zoom in" onClick={onZoomIn}>
          <ZoomIn className="size-4" />
        </ToolBtn>
        <ToolBtn label="Zoom" active={tray === "zoom"} onClick={() => toggle("zoom")}>
          <span className="font-sans text-xs font-semibold tabular-nums">{zoom}%</span>
        </ToolBtn>
        <ToolBtn label="Page setup" onClick={onPageSetup}>
          <FileStack className="size-4" />
        </ToolBtn>
        <ToolBtn label="Print" onClick={onPrint}>
          <Printer className="size-4" />
        </ToolBtn>
        <ToolBtn label="Print preview" onClick={onPrintPreview}>
          <Eye className="size-4" />
        </ToolBtn>
        <span className="mx-1 my-3 w-px shrink-0 bg-line" />
        <ToolBtn label="Cut" onClick={() => onExec("cut")}>
          <Scissors className="size-4" />
        </ToolBtn>
        <ToolBtn label="Copy" onClick={() => onExec("copy")}>
          <Copy className="size-4" />
        </ToolBtn>
        <ToolBtn label="Paste" onClick={() => onExec("paste")}>
          <ClipboardPaste className="size-4" />
        </ToolBtn>
        <ToolBtn label="Increase indent" onClick={() => onExec("indent")}>
          <Indent className="size-4" />
        </ToolBtn>
        <ToolBtn label="Decrease indent" onClick={() => onExec("outdent")}>
          <Outdent className="size-4" />
        </ToolBtn>
      </SlideRow>
      {tray ? (
        <div className="flex gap-2 overflow-x-auto border-t border-line px-3 py-2">
          {tray === "font"
            ? FONTS.map((font) => (
                <Chip key={font} onClick={() => onFont(font)} style={{ fontFamily: font }}>
                  {font}
                </Chip>
              ))
            : null}
          {tray === "size"
            ? FONT_SIZES.map((size) => (
                <Chip key={size} onClick={() => onSize(size)}>
                  {size}
                </Chip>
              ))
            : null}
          {tray === "color"
            ? INK_COLORS.map((c) => (
                <Swatch key={c.name} label={c.name} color={c.value} onClick={() => onColor(c.value)} />
              ))
            : null}
          {tray === "highlight"
            ? HIGHLIGHTS.map((c) => (
                <Swatch
                  key={c.name}
                  label={c.name}
                  color={c.value === "transparent" ? "#fffdf8" : c.value}
                  onClick={() => onHighlight(c.value)}
                />
              ))
            : null}
          {tray === "spacing"
            ? SPACING.map((s) => (
                <Chip key={s.name} onClick={() => onSpacing(s.value)}>
                  {s.name}
                </Chip>
              ))
            : null}
          {tray === "zoom"
            ? [75, 100, 125, 150, 200].map((z) => (
                <Chip key={z} onClick={() => onZoomSet(z)}>
                  {z}%
                </Chip>
              ))
            : null}
        </div>
      ) : null}
    </div>
  );
}

function Chip({
  onClick,
  children,
  style,
}: {
  onClick: () => void;
  children: React.ReactNode;
  style?: React.CSSProperties;
}) {
  return (
    <button
      type="button"
      onMouseDown={(event) => event.preventDefault()}
      onClick={onClick}
      style={style}
      className="h-9 shrink-0 rounded-md bg-paper px-3 font-sans text-sm text-ink ring-1 ring-inset ring-line transition-transform duration-150 active:scale-[0.96]"
    >
      {children}
    </button>
  );
}

function Swatch({
  label,
  color,
  onClick,
}: {
  label: string;
  color: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onMouseDown={(event) => event.preventDefault()}
      onClick={onClick}
      className="flex h-9 shrink-0 items-center gap-2 rounded-md bg-paper px-2 ring-1 ring-inset ring-line transition-transform duration-150 active:scale-[0.96]"
    >
      <span
        className="size-4 rounded-sm ring-1 ring-inset ring-ink/15"
        style={{ background: color }}
      />
      <span className="font-sans text-xs text-ink">{label}</span>
    </button>
  );
}

export function Ruler({ marginPx }: { marginPx: number }) {
  const ticks = Array.from({ length: 17 }, (_, i) => i);
  return (
    <div className="relative h-6 overflow-hidden border-b border-line bg-surface">
      <div
        className="pointer-events-none absolute inset-y-0 bg-accent/10"
        style={{ left: 0, width: marginPx }}
      />
      <div
        className="pointer-events-none absolute inset-y-0 bg-accent/10"
        style={{ right: 0, width: marginPx }}
      />
      <div className="flex h-full items-end">
        {ticks.map((tick) => (
          <div key={tick} className="relative flex-1">
            {tick % 4 === 0 ? (
              <span className="absolute bottom-1 left-0.5 font-mono text-xs tabular-nums text-muted">
                {tick / 2}
              </span>
            ) : null}
            <span
              className={cn(
                "absolute bottom-0 left-0 w-px bg-line",
                tick % 4 === 0 ? "h-2.5" : "h-1.5",
              )}
            />
          </div>
        ))}
      </div>
    </div>
  );
}
