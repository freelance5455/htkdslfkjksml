import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  BookOpen,
  Download,
  FilePlus,
  FolderOpen,
  Link2,
  MoreHorizontal,
  Redo2,
  Save,
  Undo2,
  X,
} from "lucide-react";
import { toast, Toaster } from "sonner";
import { Button } from "@/components/ui/button";
import { FormatToolbar, Ruler, type FormatFlags, type Tray } from "@/components/pad/toolbar";
import {
  DownloadSheet,
  LearnSheet,
  LinkSheet,
  PageSetupSheet,
} from "@/components/pad/sheets";
import { DEFAULT_HTML, DEFAULT_TITLE } from "@/lib/default-doc";
import {
  buildShareUrl,
  decodePad,
  encodePad,
  loadLocal,
  readTokenFromLocation,
  saveLocal,
  type PadDoc,
} from "@/lib/share";
import {
  downloadHtml,
  downloadPdf,
  downloadPng,
  downloadTxt,
} from "@/lib/export-doc";
import { countText, escapeHtml } from "@/lib/utils";
import { cn } from "@/lib/utils";

const MARGIN = { narrow: 16, normal: 28, wide: 44 } as const;

type PageState = {
  size: "a4" | "letter";
  orientation: "portrait" | "landscape";
  margin: "narrow" | "normal" | "wide";
};

export function PadApp() {
  const editorRef = useRef<HTMLDivElement>(null);
  const paperRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const rangeRef = useRef<Range | null>(null);
  const [title, setTitle] = useState(DEFAULT_TITLE);
  const [docKey, setDocKey] = useState(0);
  const [startHtml, setStartHtml] = useState(DEFAULT_HTML);
  const [dirty, setDirty] = useState(false);
  const [saved, setSaved] = useState(true);
  const [zoom, setZoom] = useState(100);
  const [tray, setTray] = useState<Tray>(null);
  const [flags, setFlags] = useState<FormatFlags>({
    bold: false,
    italic: false,
    underline: false,
  });
  const [findOpen, setFindOpen] = useState(false);
  const [findQuery, setFindQuery] = useState("");
  const [findCount, setFindCount] = useState(0);
  const [downloadOpen, setDownloadOpen] = useState(false);
  const [linkOpen, setLinkOpen] = useState(false);
  const [learnOpen, setLearnOpen] = useState(false);
  const [pageOpen, setPageOpen] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [fileOpen, setFileOpen] = useState(false);
  const [shareUrl, setShareUrl] = useState("");
  const [copied, setCopied] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [fromLink, setFromLink] = useState(false);
  const [showTip, setShowTip] = useState(true);
  const [canShare, setCanShare] = useState(false);
  const [htmlTick, setHtmlTick] = useState(0);
  const [page, setPage] = useState<PageState>({
    size: "a4",
    orientation: "portrait",
    margin: "normal",
  });

  const currentHtml = () => editorRef.current?.innerHTML ?? startHtml;
  const stats = useMemo(
    () => countText(editorRef.current?.innerHTML ?? startHtml),
    [htmlTick, startHtml, docKey],
  );

  const restore = useCallback(() => {
    const range = rangeRef.current;
    const editor = editorRef.current;
    if (!range || !editor) return;
    const selection = window.getSelection();
    if (!selection) return;
    selection.removeAllRanges();
    selection.addRange(range);
    editor.focus();
  }, []);

  const exec = useCallback(
    (cmd: string, value?: string) => {
      restore();
      if (cmd === "paste") {
        void (async () => {
          try {
            const text = await navigator.clipboard.readText();
            document.execCommand("insertText", false, text);
            setDirty(true);
            setSaved(false);
            setHtmlTick((n) => n + 1);
          } catch {
            toast("Use a long-press or Ctrl+V to paste");
          }
        })();
        return;
      }
      document.execCommand("styleWithCSS", false, "true");
      document.execCommand(cmd, false, value);
      setDirty(true);
      setSaved(false);
      setHtmlTick((n) => n + 1);
    },
    [restore],
  );

  const applyFontSize = (px: string) => {
    restore();
    document.execCommand("styleWithCSS", false, "true");
    document.execCommand("fontSize", false, "7");
    const editor = editorRef.current;
    editor?.querySelectorAll('font[size="7"], span[style*="font-size: xxx-large"]').forEach((node) => {
      const el = node as HTMLElement;
      el.removeAttribute("size");
      el.style.fontSize = `${px}px`;
    });
    setDirty(true);
    setSaved(false);
  };

  const applySpacing = (value: string) => {
    restore();
    const selection = window.getSelection();
    if (!selection || selection.rangeCount === 0) return;
    let node: Node | null = selection.anchorNode;
    if (node && node.nodeType === Node.TEXT_NODE) node = node.parentElement;
    const block = (node as HTMLElement | null)?.closest("p, li, h1, h2, h3, div");
    if (block instanceof HTMLElement) block.style.lineHeight = value;
    setDirty(true);
    setSaved(false);
  };

  const insertDate = () => {
    restore();
    const formatted = new Intl.DateTimeFormat(undefined, {
      dateStyle: "medium",
      timeStyle: "short",
    }).format(new Date());
    document.execCommand("insertText", false, formatted);
    setDirty(true);
    setSaved(false);
  };

  const insertPicture = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.onchange = () => {
      const file = input.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        restore();
        const src = String(reader.result ?? "");
        document.execCommand("insertHTML", false, `<img src="${src}" alt="" />`);
        setDirty(true);
        setSaved(false);
        setHtmlTick((n) => n + 1);
      };
      reader.readAsDataURL(file);
    };
    input.click();
  };

  const loadDoc = (doc: PadDoc, asLink = false) => {
    setTitle(doc.t || DEFAULT_TITLE);
    setStartHtml(doc.h || "<p></p>");
    setDocKey((k) => k + 1);
    setDirty(false);
    setSaved(true);
    setFromLink(asLink);
    setFindOpen(false);
    setTray(null);
  };

  useEffect(() => {
    setCanShare(typeof navigator !== "undefined" && typeof navigator.share === "function");
    let cancelled = false;
    (async () => {
      const token = readTokenFromLocation();
      if (token) {
        const doc = await decodePad(token);
        if (doc && !cancelled) {
          loadDoc(doc, true);
          setShowTip(false);
          return;
        }
      }
      const local = loadLocal();
      if (local && !cancelled) loadDoc(local);
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    const onSel = () => {
      const selection = window.getSelection();
      if (!selection || selection.rangeCount === 0) return;
      if (!editorRef.current?.contains(selection.anchorNode)) return;
      rangeRef.current = selection.getRangeAt(0).cloneRange();
      try {
        setFlags({
          bold: document.queryCommandState("bold"),
          italic: document.queryCommandState("italic"),
          underline: document.queryCommandState("underline"),
        });
      } catch {
        /* some browsers throw when the selection is not a text range */
      }
    };
    document.addEventListener("selectionchange", onSel);
    return () => document.removeEventListener("selectionchange", onSel);
  }, []);

  useEffect(() => {
    const id = window.setTimeout(() => {
      const doc: PadDoc = { v: 1, t: title, h: currentHtml() };
      saveLocal(doc);
      setSaved(true);
    }, 700);
    return () => window.clearTimeout(id);
  }, [title, htmlTick, docKey]);

  const clearFindMarks = () => {
    const root = editorRef.current;
    if (!root) return;
    root.querySelectorAll("mark.pad-find").forEach((mark) => {
      const text = document.createTextNode(mark.textContent ?? "");
      mark.replaceWith(text);
    });
    root.normalize();
  };

  const runFind = (query: string) => {
    clearFindMarks();
    const root = editorRef.current;
    if (!root || !query.trim()) {
      setFindCount(0);
      return;
    }
    const needle = query.trim();
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const hits: { node: Text; start: number }[] = [];
    while (walker.nextNode()) {
      const node = walker.currentNode as Text;
      const lower = node.data.toLowerCase();
      const q = needle.toLowerCase();
      let idx = lower.indexOf(q);
      while (idx !== -1) {
        hits.push({ node, start: idx });
        idx = lower.indexOf(q, idx + q.length);
      }
    }
    for (let i = hits.length - 1; i >= 0; i--) {
      const hit = hits[i]!;
      if (hit.start + needle.length > hit.node.data.length) continue;
      try {
        const range = document.createRange();
        range.setStart(hit.node, hit.start);
        range.setEnd(hit.node, hit.start + needle.length);
        const mark = document.createElement("mark");
        mark.className = "pad-find";
        range.surroundContents(mark);
      } catch {
        /* skip unstable ranges */
      }
    }
    setFindCount(hits.length);
    root.querySelector("mark.pad-find")?.scrollIntoView({ block: "center", behavior: "smooth" });
  };

  const confirmNew = () => {
    if (dirty && !window.confirm("Start a new document? Unsaved edits stay on this device until you convert to a link or download.")) {
      return;
    }
    loadDoc({ v: 1, t: "Untitled", h: "<p><br></p>" });
    setDirty(false);
    toast("New document");
  };

  const saveFile = (asNew = false) => {
    let name = title;
    if (asNew) {
      const next = window.prompt("Save as", title);
      if (!next) return;
      name = next;
      setTitle(next);
    }
    downloadHtml(currentHtml(), name);
    setSaved(true);
    setDirty(false);
    toast("Saved HTML file");
  };

  const openFile = async (file: File) => {
    const raw = await file.text();
    let html = raw;
    const lower = file.name.toLowerCase();
    if (lower.endsWith(".txt") || file.type === "text/plain") {
      html = `<p>${escapeHtml(raw).replace(/\n\n/g, "</p><p>").replace(/\n/g, "<br/>")}</p>`;
    } else if (lower.endsWith(".rtf")) {
      html = `<p>${escapeHtml(
        raw
          .replace(/\\par[d]?/g, "\n")
          .replace(/\\'[0-9a-fA-F]{2}/g, "")
          .replace(/\\[a-z]+-?\d* ?/g, "")
          .replace(/[{}]/g, ""),
      )
        .replace(/\n+/g, "</p><p>")}</p>`;
    } else {
      const body = raw.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
      if (body?.[1]) html = body[1];
    }
    loadDoc({ v: 1, t: file.name.replace(/\.[^.]+$/, ""), h: html });
    toast("Opened " + file.name);
  };

  const convertToLink = async () => {
    setLinkOpen(true);
    setCopied(false);
    try {
      const token = await encodePad({ v: 1, t: title, h: currentHtml() });
      const url = buildShareUrl(token);
      if (url.length > 28000) {
        toast("This document is too long for a link. Download PDF instead.");
        setShareUrl("");
        return;
      }
      window.history.replaceState(null, "", url);
      setShareUrl(url);
      setDirty(false);
    } catch {
      toast("Could not build a link. Try downloading PDF.");
      setShareUrl("");
    }
  };

  const copyLink = async () => {
    if (!shareUrl) return;
    try {
      await navigator.clipboard.writeText(shareUrl);
    } catch {
      const area = document.createElement("textarea");
      area.value = shareUrl;
      document.body.appendChild(area);
      area.select();
      document.execCommand("copy");
      area.remove();
    }
    setCopied(true);
    toast("Link copied");
  };

  const shareNative = async () => {
    if (!shareUrl || !navigator.share) return;
    try {
      await navigator.share({ title, url: shareUrl, text: title });
    } catch {
      /* user cancelled */
    }
  };

  const handleDownload = async (kind: "pdf" | "png" | "txt" | "html") => {
    const paper = paperRef.current;
    if (!paper) return;
    setBusy(kind);
    const prevZoom = paper.style.zoom;
    paper.style.zoom = "1";
    try {
      if (kind === "png") await downloadPng(paper, title);
      else if (kind === "pdf") await downloadPdf(paper, title);
      else if (kind === "txt") downloadTxt(currentHtml(), title);
      else downloadHtml(currentHtml(), title);
      toast(`Downloaded ${kind.toUpperCase()}`);
    } catch (err) {
      console.error(err);
      toast("Download failed. Try Print and save as PDF.");
    } finally {
      paper.style.zoom = prevZoom;
      setBusy(null);
    }
  };

  const marginPx = MARGIN[page.margin];
  const paperMax =
    page.orientation === "landscape"
      ? page.size === "a4"
        ? "max-w-4xl"
        : "max-w-4xl"
      : page.size === "letter"
        ? "max-w-2xl"
        : "max-w-2xl";

  return (
    <div className="flex h-dvh flex-col overflow-hidden bg-bg text-ink">
      <Toaster
        position="top-center"
        toastOptions={{
          className: "font-sans",
          style: {
            background: "var(--color-chrome)",
            color: "var(--color-chrome-fg)",
            border: "none",
          },
        }}
      />
      <header className="safe-top shrink-0 bg-chrome text-chrome-fg" data-print-hide>
        <div className="flex items-center gap-1 px-1">
          <div className="relative">
            <button
              type="button"
              aria-label="File menu"
              aria-expanded={fileOpen}
              onClick={() => setFileOpen((v) => !v)}
              className="inline-flex size-11 items-center justify-center rounded-md text-chrome-fg transition-transform duration-150 active:scale-[0.96]"
            >
              <MoreHorizontal className="size-5" />
            </button>
            {fileOpen ? (
              <div className="absolute left-1 top-12 z-40 w-44 overflow-hidden rounded-lg bg-surface py-1 text-ink shadow-sheet">
                <MenuItem
                  icon={FilePlus}
                  label="New"
                  onClick={() => {
                    setFileOpen(false);
                    confirmNew();
                  }}
                />
                <MenuItem
                  icon={FolderOpen}
                  label="Open"
                  onClick={() => {
                    setFileOpen(false);
                    fileRef.current?.click();
                  }}
                />
                <MenuItem
                  icon={Save}
                  label="Save"
                  onClick={() => {
                    setFileOpen(false);
                    saveFile(false);
                  }}
                />
                <MenuItem
                  icon={Save}
                  label="Save as"
                  onClick={() => {
                    setFileOpen(false);
                    saveFile(true);
                  }}
                />
              </div>
            ) : null}
          </div>
          <input
            value={title}
            onChange={(e) => {
              setTitle(e.target.value);
              setDirty(true);
              setSaved(false);
            }}
            aria-label="Document title"
            className="min-w-0 flex-1 bg-transparent py-3 text-center font-sans text-base font-medium tracking-tight text-chrome-fg outline-none"
          />
          <button
            type="button"
            aria-label="Undo"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => exec("undo")}
            className="inline-flex size-11 items-center justify-center rounded-md transition-transform duration-150 active:scale-[0.96]"
          >
            <Undo2 className="size-5" />
          </button>
          <button
            type="button"
            aria-label="Redo"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => exec("redo")}
            className="inline-flex size-11 items-center justify-center rounded-md transition-transform duration-150 active:scale-[0.96]"
          >
            <Redo2 className="size-5" />
          </button>
          <button
            type="button"
            aria-label="WordPad window guide"
            onClick={() => setLearnOpen(true)}
            className="inline-flex size-11 items-center justify-center rounded-md transition-transform duration-150 active:scale-[0.96]"
          >
            <BookOpen className="size-5" />
          </button>
        </div>
      </header>

      {showTip ? (
        <div className="flex shrink-0 items-center gap-2 border-b border-line bg-accent/10 px-3 py-2" data-print-hide>
          <Link2 className="size-4 shrink-0 text-accent" />
          <p className="flex-1 text-sm text-ink">
            {fromLink
              ? "Opened from a shared link. Edit, then convert again to send your version."
              : "This note is ready. Convert to Link copies a URL that opens the same page."}
          </p>
          <button
            type="button"
            aria-label="Dismiss tip"
            onClick={() => setShowTip(false)}
            className="inline-flex size-9 items-center justify-center rounded-md text-muted"
          >
            <X className="size-4" />
          </button>
        </div>
      ) : null}

      <div data-print-hide>
      <FormatToolbar
        flags={flags}
        tray={tray}
        zoom={zoom}
        onTray={setTray}
        onExec={exec}
        onFont={(name) => exec("fontName", name)}
        onSize={applyFontSize}
        onColor={(c) => exec("foreColor", c)}
        onHighlight={(c) => exec("hiliteColor", c)}
        onSpacing={applySpacing}
        onPicture={insertPicture}
        onDate={insertDate}
        onFind={() => {
          setFindOpen(true);
          setTimeout(() => document.getElementById("pad-find")?.focus(), 30);
        }}
        onZoomIn={() => setZoom((z) => Math.min(200, z + 25))}
        onZoomOut={() => setZoom((z) => Math.max(75, z - 25))}
        onZoomSet={setZoom}
        onPageSetup={() => setPageOpen(true)}
        onPrint={() => window.print()}
        onPrintPreview={() => setPreviewOpen(true)}
      />
      </div>

      {findOpen ? (
        <div className="flex shrink-0 items-center gap-2 border-b border-line bg-surface px-3 py-2" data-print-hide>
          <input
            id="pad-find"
            defaultValue=""
            onInput={(e) => {
              const value = e.currentTarget.value;
              setFindQuery(value);
              runFind(value);
            }}
            placeholder="Find text"
            className="h-11 min-w-0 flex-1 rounded-md bg-paper px-3 font-sans text-base text-ink outline-none ring-1 ring-inset ring-line"
          />
          <span className="font-sans text-xs tabular-nums text-muted">{findCount}</span>
          <button
            type="button"
            aria-label="Close find"
            onClick={() => {
              setFindOpen(false);
              setFindQuery("");
              clearFindMarks();
            }}
            className="inline-flex size-11 items-center justify-center rounded-md"
          >
            <X className="size-4" />
          </button>
        </div>
      ) : null}

      <main className="min-h-0 flex-1 overflow-y-auto">
        <div className={cn("mx-auto px-3 py-4", paperMax)}>
          <article
            ref={paperRef}
            className={cn(
              "overflow-hidden rounded-xl bg-paper shadow-paper",
              page.orientation === "landscape" ? "min-h-72" : "min-h-96",
            )}
            style={{ zoom: zoom / 100 }}
          >
            <Ruler marginPx={marginPx} />
            <div
              ref={editorRef}
              key={docKey}
              contentEditable
              suppressContentEditableWarning
              role="textbox"
              aria-label="Document"
              spellCheck
              className="pad-editor"
              style={{ padding: marginPx }}
              dangerouslySetInnerHTML={{ __html: startHtml }}
              onInput={() => {
                setDirty(true);
                setSaved(false);
                setHtmlTick((n) => n + 1);
              }}
            />
          </article>
        </div>
      </main>

      <footer className="safe-bottom shrink-0 border-t border-line bg-surface" data-print-hide>
        <div className="flex items-center justify-between px-4 py-1 font-sans text-xs text-muted">
          <span className="tabular-nums">
            {stats.words} words · {stats.chars} characters
          </span>
          <span>{saved ? "Saved on device" : "Editing"}</span>
        </div>
        <div className="grid grid-cols-2 gap-2 px-3 pb-2">
          <Button variant="outline" onClick={() => setDownloadOpen(true)}>
            <Download className="size-4" />
            Download
          </Button>
          <Button onClick={convertToLink}>
            <Link2 className="size-4" />
            Convert to Link
          </Button>
        </div>
      </footer>

      <input
        ref={fileRef}
        type="file"
        accept=".txt,.html,.htm,.rtf,.md,text/plain,text/html"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) void openFile(file);
          e.target.value = "";
        }}
      />

      {fileOpen ? (
        <button
          type="button"
          aria-label="Close menu"
          className="fixed inset-0 z-30 cursor-default"
          onClick={() => setFileOpen(false)}
        />
      ) : null}

      <DownloadSheet
        open={downloadOpen}
        onOpenChange={setDownloadOpen}
        busy={busy}
        onPick={(kind) => void handleDownload(kind)}
      />
      <LinkSheet
        open={linkOpen}
        onOpenChange={setLinkOpen}
        url={shareUrl}
        copied={copied}
        onCopy={() => void copyLink()}
        onShare={() => void shareNative()}
        canShare={canShare}
      />
      <LearnSheet open={learnOpen} onOpenChange={setLearnOpen} />
      <PageSetupSheet
        open={pageOpen}
        onOpenChange={setPageOpen}
        orientation={page.orientation}
        margin={page.margin}
        size={page.size}
        onOrientation={(orientation) => setPage((p) => ({ ...p, orientation }))}
        onMargin={(margin) => setPage((p) => ({ ...p, margin }))}
        onSize={(size) => setPage((p) => ({ ...p, size }))}
      />

      {previewOpen ? (
        <div className="fixed inset-0 z-50 flex flex-col bg-bg/95">
          <div className="flex items-center justify-between px-3 py-2">
            <p className="font-sans text-sm font-medium">Print preview</p>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={() => window.print()}>
                Print
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setPreviewOpen(false)}>
                Close
              </Button>
            </div>
          </div>
          <div className="flex-1 overflow-auto p-4">
            <div className="mx-auto max-w-2xl bg-paper p-8 shadow-paper">
              <h2 className="mb-4 font-sans text-xl font-semibold">{title}</h2>
              <div className="pad-editor" dangerouslySetInnerHTML={{ __html: currentHtml() }} />
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function MenuItem({
  icon: Icon,
  label,
  onClick,
}: {
  icon: typeof FilePlus;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex w-full items-center gap-2 px-3 py-2.5 text-left font-sans text-sm text-ink hover:bg-ink/5"
    >
      <Icon className="size-4 text-muted" />
      {label}
    </button>
  );
}
