import { Drawer } from "vaul";
import {
  Download,
  FileText,
  Image as ImageIcon,
  Link2,
  Share2,
  Copy,
  Check,
  FileCode,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { WINDOW_PARTS } from "@/lib/default-doc";
import { cn } from "@/lib/utils";

export function BottomSheet({
  open,
  onOpenChange,
  title,
  description,
  children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <Drawer.Root open={open} onOpenChange={onOpenChange}>
      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 z-50 bg-ink/40" />
        <Drawer.Content
          className="fixed inset-x-0 bottom-0 z-50 flex max-h-[88dvh] flex-col rounded-t-xl bg-surface outline-none"
          aria-describedby={description ? undefined : undefined}
        >
          <div className="mx-auto mt-3 h-1 w-10 rounded-full bg-line" />
          <Drawer.Title className="px-5 pt-4 font-sans text-lg font-semibold tracking-tight text-ink">
            {title}
          </Drawer.Title>
          {description ? (
            <Drawer.Description className="px-5 pt-1 text-sm text-muted">
              {description}
            </Drawer.Description>
          ) : (
            <Drawer.Description className="sr-only">{title}</Drawer.Description>
          )}
          <div className="sheet-bottom overflow-y-auto px-5 pt-4">
            {children}
          </div>
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
}

export function DownloadSheet({
  open,
  onOpenChange,
  busy,
  onPick,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  busy: string | null;
  onPick: (kind: "pdf" | "png" | "txt" | "html") => void;
}) {
  const options = [
    {
      id: "pdf" as const,
      title: "PDF",
      hint: "Print-ready pages for school or sharing",
      icon: FileText,
    },
    {
      id: "png" as const,
      title: "PNG",
      hint: "A full-page image of the document",
      icon: ImageIcon,
    },
    {
      id: "txt" as const,
      title: "Plain text",
      hint: "TXT without formatting",
      icon: Download,
    },
    {
      id: "html" as const,
      title: "HTML",
      hint: "Keeps headings, lists, and colors",
      icon: FileCode,
    },
  ];

  return (
    <BottomSheet
      open={open}
      onOpenChange={onOpenChange}
      title="Download"
      description="Save this page as PNG, PDF, or text."
    >
      <div className="flex flex-col gap-2">
        {options.map((opt) => (
          <button
            key={opt.id}
            type="button"
            disabled={busy !== null}
            onClick={() => onPick(opt.id)}
            className="flex min-h-14 items-center gap-3 rounded-lg bg-paper px-3 py-3 text-left ring-1 ring-inset ring-line transition-transform duration-150 active:scale-[0.96] disabled:opacity-50"
          >
            <span className="flex size-11 items-center justify-center rounded-md bg-accent/10 text-accent">
              <opt.icon className="size-5" strokeWidth={1.75} />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block font-sans text-sm font-medium text-ink">{opt.title}</span>
              <span className="block text-sm text-muted">{opt.hint}</span>
            </span>
            {busy === opt.id ? (
              <span className="text-xs font-medium text-accent">Saving…</span>
            ) : null}
          </button>
        ))}
      </div>
    </BottomSheet>
  );
}

export function LinkSheet({
  open,
  onOpenChange,
  url,
  copied,
  onCopy,
  onShare,
  canShare,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  url: string;
  copied: boolean;
  onCopy: () => void;
  onShare: () => void;
  canShare: boolean;
}) {
  return (
    <BottomSheet
      open={open}
      onOpenChange={onOpenChange}
      title="Convert to link"
      description="Anyone with this URL opens the same document."
    >
      <div className="rounded-lg bg-paper px-3 py-3 ring-1 ring-inset ring-line">
        <p className="break-all font-mono text-xs leading-relaxed text-ink/80">{url || "Preparing link…"}</p>
      </div>
      <div className="mt-4 flex flex-col gap-2">
        <Button className="w-full" onClick={onCopy} disabled={!url}>
          {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
          {copied ? "Copied" : "Copy link"}
        </Button>
        {canShare ? (
          <Button variant="outline" className="w-full" onClick={onShare} disabled={!url}>
            <Share2 className="size-4" />
            Share
          </Button>
        ) : null}
      </div>
      <p className="mt-3 flex items-start gap-2 text-sm text-muted">
        <Link2 className="mt-0.5 size-4 shrink-0 text-accent" />
        The link stores this page in the URL. No account needed.
      </p>
    </BottomSheet>
  );
}

export function LearnSheet({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  return (
    <BottomSheet
      open={open}
      onOpenChange={onOpenChange}
      title="WordPad window"
      description="Names and jobs of each part — plus how PadLink maps them."
    >
      <div className="overflow-hidden rounded-lg bg-paper ring-1 ring-inset ring-line">
        <div className="bg-chrome px-3 py-2 text-center font-sans text-xs font-medium text-chrome-fg">
          Title bar
        </div>
        <div className="flex gap-1 bg-chrome/90 px-2 py-1.5">
          {["New", "Open", "Save"].map((label) => (
            <span
              key={label}
              className="rounded-sm bg-chrome-fg/10 px-2 py-1 font-sans text-xs text-chrome-fg"
            >
              {label}
            </span>
          ))}
          <span className="ml-auto font-sans text-xs text-chrome-fg/70">Quick Access</span>
        </div>
        <div className="flex gap-3 border-b border-line bg-surface px-3 py-2 font-sans text-xs">
          <span className="font-semibold text-accent">Home</span>
          <span className="text-muted">View</span>
          <span className="ml-auto text-muted">Ribbon</span>
        </div>
        <div className="border-b border-line bg-surface px-3 py-1.5 font-mono text-xs text-muted">
          0 ——— ruler ——— 6 in
        </div>
        <div className="flex h-20 items-center justify-center bg-paper font-sans text-xs text-muted">
          Document area
        </div>
        <div className="flex justify-between bg-surface px-3 py-1.5 font-sans text-xs text-muted">
          <span>Status bar</span>
          <span>Zoom</span>
        </div>
      </div>
      <ul className="mt-4 flex flex-col gap-3">
        {WINDOW_PARTS.map((part) => (
          <li key={part.name} className="flex flex-col gap-0.5">
            <span className="font-sans text-sm font-medium text-ink">{part.name}</span>
            <span className="text-sm text-muted">{part.role}</span>
          </li>
        ))}
      </ul>
    </BottomSheet>
  );
}

export function PageSetupSheet({
  open,
  onOpenChange,
  orientation,
  margin,
  size,
  onOrientation,
  onMargin,
  onSize,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  orientation: "portrait" | "landscape";
  margin: "narrow" | "normal" | "wide";
  size: "a4" | "letter";
  onOrientation: (value: "portrait" | "landscape") => void;
  onMargin: (value: "narrow" | "normal" | "wide") => void;
  onSize: (value: "a4" | "letter") => void;
}) {
  return (
    <BottomSheet
      open={open}
      onOpenChange={onOpenChange}
      title="Page setup"
      description="Paper size, orientation, and margins."
    >
      <Field label="Orientation">
        <Seg
          value={orientation}
          onChange={onOrientation}
          options={[
            { id: "portrait", label: "Portrait" },
            { id: "landscape", label: "Landscape" },
          ]}
        />
      </Field>
      <Field label="Paper">
        <Seg
          value={size}
          onChange={onSize}
          options={[
            { id: "a4", label: "A4" },
            { id: "letter", label: "Letter" },
          ]}
        />
      </Field>
      <Field label="Margins">
        <Seg
          value={margin}
          onChange={onMargin}
          options={[
            { id: "narrow", label: "Narrow" },
            { id: "normal", label: "Normal" },
            { id: "wide", label: "Wide" },
          ]}
        />
      </Field>
    </BottomSheet>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="mb-4">
      <p className="mb-2 font-sans text-xs font-medium uppercase tracking-wider text-muted">{label}</p>
      {children}
    </div>
  );
}

function Seg<T extends string>({
  value,
  onChange,
  options,
}: {
  value: T;
  onChange: (value: T) => void;
  options: { id: T; label: string }[];
}) {
  return (
    <div
      className={cn(
        "grid gap-2 rounded-lg bg-paper p-1 ring-1 ring-inset ring-line",
        options.length > 2 ? "grid-cols-3" : "grid-cols-2",
      )}
    >
      {options.map((opt) => (
        <button
          key={opt.id}
          type="button"
          onClick={() => onChange(opt.id)}
          className={cn(
            "h-11 rounded-md font-sans text-sm font-medium transition-colors duration-150",
            value === opt.id ? "bg-accent text-accent-fg" : "text-ink",
          )}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}
