import React, { useState } from 'react';
import { AlertCircle, Check, ShieldAlert, History } from 'lucide-react';
import type { DailyRecord, Player, Category } from '../types/index.ts';

interface AuditCorrectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  record: DailyRecord | null;
  activePlayer: Player;
  categories: Category[];
  todayDateStr: string;
  onSubmitCorrection: (data: {
    playerId: string;
    categoryId: string;
    localDate: string;
    newBestStreak: number;
    trained: boolean;
    reason: string;
    editorId: string;
  }) => Promise<boolean>;
}

export const AuditCorrectionModal: React.FC<AuditCorrectionModalProps> = ({
  isOpen,
  onClose,
  record,
  activePlayer,
  categories,
  todayDateStr,
  onSubmitCorrection,
}) => {
  const [selectedCatId, setSelectedCatId] = useState<string>(
    record ? record.categoryId : categories[0]?.id || 'cat-200g'
  );
  const [localDate, setLocalDate] = useState<string>(
    record ? record.localDate : todayDateStr
  );
  const [newBestStreak, setNewBestStreak] = useState<number>(
    record ? record.bestStreak : 0
  );
  const [isTrained, setIsTrained] = useState<boolean>(
    record ? record.trained : true
  );
  const [reason, setReason] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) {
      setErrorMsg('Informe o motivo formal da correção para constar no registro de auditoria.');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg('');

    const targetPlayerId = record ? record.playerId : activePlayer.id;

    const ok = await onSubmitCorrection({
      playerId: targetPlayerId,
      categoryId: selectedCatId,
      localDate,
      newBestStreak: Number(newBestStreak),
      trained: isTrained,
      reason: reason.trim(),
      editorId: activePlayer.id,
    });

    setIsSubmitting(false);
    if (ok) {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/80 backdrop-blur-md">
      <div className="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-2xl relative">
        <div className="flex items-center gap-2 mb-2 text-amber-400">
          <History className="w-5 h-5" />
          <h3 className="text-lg font-black text-white">Correção de Registro com Auditoria</h3>
        </div>
        <p className="text-xs text-neutral-400 mb-4 leading-relaxed">
          Toda alteração de resultado oficial fica registrada na trilha pública de auditoria do grupo Garrafões (autor, horário, valor anterior e justificativa).
        </p>

        {errorMsg && (
          <div className="mb-4 p-3 rounded-xl bg-red-950/40 border border-red-800/60 text-xs text-red-300">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-neutral-300 mb-1">
                Data do Registro
              </label>
              <input
                type="date"
                value={localDate}
                onChange={(e) => setLocalDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-neutral-950 border border-neutral-700 rounded-lg text-white font-mono-numbers focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-300 mb-1">
                Categoria
              </label>
              <select
                value={selectedCatId}
                onChange={(e) => setSelectedCatId(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-neutral-950 border border-neutral-700 rounded-lg text-white focus:outline-none focus:border-emerald-500"
              >
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-neutral-300 mb-1">
              Melhor Sequência Corrigida
            </label>
            <input
              type="number"
              min="0"
              max="200"
              value={newBestStreak}
              onChange={(e) => setNewBestStreak(Number(e.target.value))}
              className="w-full px-3 py-2 text-base font-extrabold bg-neutral-950 border border-neutral-700 rounded-lg text-white font-mono-numbers focus:outline-none focus:border-emerald-500"
              required
            />
          </div>

          <div className="flex items-center gap-2 p-3 rounded-xl bg-neutral-950 border border-neutral-800">
            <input
              type="checkbox"
              id="trained-checkbox"
              checked={isTrained}
              onChange={(e) => setIsTrained(e.target.checked)}
              className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
            />
            <label htmlFor="trained-checkbox" className="text-xs text-neutral-300 cursor-pointer">
              Houve treino oficial neste dia (se desmarcado, não conta na média)
            </label>
          </div>

          <div>
            <label className="block text-xs font-bold text-neutral-300 mb-1">
              Motivo da Correção <span className="text-amber-400">*</span>
            </label>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Ex: Correção de digitação de tentativa; recontagem da melhor sequência válida."
              rows={2}
              className="w-full px-3 py-2 text-xs bg-neutral-950 border border-neutral-700 rounded-lg text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
              required
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-4 border-t border-neutral-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-neutral-400 hover:text-white"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 text-xs font-bold bg-amber-500 text-neutral-950 rounded-lg hover:bg-amber-400 transition-colors cursor-pointer"
            >
              Confirmar Correção
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
