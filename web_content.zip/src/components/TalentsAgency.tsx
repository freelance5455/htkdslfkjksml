import React, { useState } from 'react';
import {
  Users,
  Award,
  Sparkles,
  DollarSign,
  AlertTriangle,
  UserCheck,
  UserX,
  GraduationCap,
  Heart,
} from 'lucide-react';
import { Talent } from '../types/game';
import { soundFx } from '../utils/audio';

interface TalentsAgencyProps {
  talents: Talent[];
  cash: number;
  onHireTalent: (talentId: string) => void;
  onFireTalent: (talentId: string) => void;
  onTrainTalent: (talentId: string, cost: number) => void;
}

export const TalentsAgency: React.FC<TalentsAgencyProps> = ({
  talents,
  cash,
  onHireTalent,
  onFireTalent,
  onTrainTalent,
}) => {
  const [filterMode, setFilterMode] = useState<'all' | 'hired' | 'market'>('all');

  const filteredTalents = talents.filter((t) => {
    if (filterMode === 'hired') return t.isHired;
    if (filterMode === 'market') return !t.isHired;
    return true;
  });

  const totalPayroll = talents
    .filter((t) => t.isHired)
    .reduce((sum, t) => sum + t.salary, 0);

  return (
    <div className="w-full h-full flex flex-col gap-3 select-none overflow-y-auto pr-1">
      {/* Header Banner - Compact */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Users className="w-4 h-4 text-amber-400" />
            Casting & Estrelas da Televisão
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Contrate comunicadores queridos do país. Carisma alto atrai multidões, mas monitore o risco de escândalos.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className="text-[10px] font-mono text-slate-400 block uppercase">FOLHA SALARIAL</span>
            <span className="text-xs font-mono font-bold text-red-400">
              - R$ {totalPayroll.toLocaleString('pt-BR')} / sem
            </span>
          </div>

          {/* Filter tabs */}
          <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-lg border border-slate-800">
            <button
              onClick={() => {
                soundFx.playClick();
                setFilterMode('all');
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                filterMode === 'all' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              Todos ({talents.length})
            </button>
            <button
              onClick={() => {
                soundFx.playClick();
                setFilterMode('hired');
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                filterMode === 'hired' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              Contratados ({talents.filter((t) => t.isHired).length})
            </button>
            <button
              onClick={() => {
                soundFx.playClick();
                setFilterMode('market');
              }}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                filterMode === 'market' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              Disponíveis ({talents.filter((t) => !t.isHired).length})
            </button>
          </div>
        </div>
      </div>

      {/* Talent Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {filteredTalents.map((talent) => {
          const trainingCost = 2500;

          return (
            <div
              key={talent.id}
              className={`rounded-2xl border p-5 flex flex-col justify-between transition-all shadow-lg ${
                talent.isHired
                  ? 'bg-slate-900/95 border-amber-500/40 shadow-amber-950/20'
                  : 'bg-slate-900/70 border-slate-800'
              }`}
            >
              <div>
                {/* Avatar & Header */}
                <div className="flex items-center gap-3">
                  <div
                    className={`w-14 h-14 rounded-2xl flex items-center justify-center text-3xl shadow-md border border-white/10 shrink-0 ${talent.avatarBg}`}
                  >
                    {talent.avatarEmoji}
                  </div>
                  <div className="overflow-hidden">
                    <h3 className="text-base font-bold text-white truncate">{talent.name}</h3>
                    <div className="text-xs text-amber-400 font-semibold">{talent.role}</div>
                    <div className="text-[10px] font-mono text-slate-400 mt-0.5">
                      {talent.isHired ? (
                        <span className="text-emerald-400 font-bold">● No Elenco</span>
                      ) : (
                        <span>Disponível no Mercado</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Catchphrase Quote */}
                <div className="mt-3 p-2.5 rounded-lg bg-slate-950/80 border border-slate-800/80 text-xs italic text-slate-300">
                  "{talent.catchphrase}"
                </div>

                {/* Attributes: Carisma & Reputação & Risco */}
                <div className="mt-4 space-y-2.5 text-xs">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-slate-400 flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Carisma Popular:
                      </span>
                      <span className="font-mono font-bold text-white">{talent.charisma}%</span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-amber-500 to-yellow-400"
                        style={{ width: `${talent.charisma}%` }}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-slate-400 flex items-center gap-1">
                        <Award className="w-3.5 h-3.5 text-blue-400" /> Reputação / Prestígio:
                      </span>
                      <span className="font-mono font-bold text-white">{talent.reputation}%</span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className="h-full bg-blue-500"
                        style={{ width: `${talent.reputation}%` }}
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-slate-400 flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5 text-rose-400" /> Risco de Escândalo:
                      </span>
                      <span className="font-mono font-bold text-rose-400">{talent.scandalRisk}%</span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                      <div
                        className="h-full bg-rose-500"
                        style={{ width: `${talent.scandalRisk}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
                  <span className="text-slate-400">Salário Semanal:</span>
                  <span className="font-mono font-bold text-slate-200">
                    R$ {talent.salary.toLocaleString('pt-BR')}
                  </span>
                </div>
              </div>

              {/* Actions */}
              <div className="mt-4 pt-3 border-t border-slate-800 flex flex-col gap-2">
                {talent.isHired ? (
                  <>
                    <button
                      onClick={() => {
                        if (cash >= trainingCost && talent.scandalRisk > 2) {
                          soundFx.playCash();
                          onTrainTalent(talent.id, trainingCost);
                        }
                      }}
                      disabled={talent.scandalRisk <= 2 || cash < trainingCost}
                      className={`w-full min-h-[44px] py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 ${
                        talent.scandalRisk <= 2 || cash < trainingCost
                          ? 'border-slate-800 text-slate-600 bg-slate-950 cursor-not-allowed opacity-60'
                          : 'border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-200'
                      }`}
                      title="Reduz o risco de escândalos e gafes na TV em 8%"
                    >
                      <GraduationCap className="w-4 h-4 text-blue-400" />
                      <span>{cash >= trainingCost ? `Media Training (R$ ${trainingCost.toLocaleString('pt-BR')})` : 'Sem Caixa para Treino'}</span>
                    </button>

                    <button
                      onClick={() => {
                        soundFx.playClick();
                        onFireTalent(talent.id);
                      }}
                      className="w-full min-h-[44px] py-2 px-3 rounded-xl bg-slate-950 hover:bg-red-950/60 border border-slate-800 hover:border-red-800 text-red-400 text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95"
                    >
                      <UserX className="w-4 h-4" />
                      <span>Rescindir Contrato</span>
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => {
                      if (cash >= talent.salary) {
                        soundFx.playCash();
                        onHireTalent(talent.id);
                      }
                    }}
                    disabled={cash < talent.salary}
                    className={`w-full min-h-[46px] py-2 px-3 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-md active:scale-95 ${
                      cash >= talent.salary
                        ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-950/40'
                        : 'bg-slate-800 text-slate-500 cursor-not-allowed opacity-75'
                    }`}
                  >
                    <UserCheck className="w-4 h-4" />
                    <span>{cash >= talent.salary ? 'Contratar Estrela' : 'Caixa Insuficiente'}</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
