// JUHNKRIX MUSIKA - JMEarningsDashboard Component
// Visually tracks real-time JMC earnings for a user based on listening, sharing, mining, and staking activities with timeframe filters.

import React, { useState, useEffect } from 'react';
import { 
  Coins, 
  TrendingUp, 
  Music, 
  Share2, 
  Cpu, 
  Lock, 
  Sparkles, 
  Award, 
  ArrowUpRight,
  ShieldCheck,
  Zap,
  Clock,
  Filter
} from 'lucide-react';

interface EarningsCategory {
  id: string;
  title: string;
  icon: string;
  jmcAmount: number;
  fiatValueNgn: number;
  description: string;
  color: string;
}

interface MiningEvent {
  id: string;
  timestamp: string;
  amount: number;
  description: string;
  hashrate: string;
  dateKey?: string; // YYYY-MM-DD for filtering
}

export const JMEarningsDashboard: React.FC = () => {
  const [totalJmc, setTotalJmc] = useState<number>(() => {
    return parseFloat(localStorage.getItem('jm_crypto_balance_v2') || '3.4850');
  });
  const [stakingRewards, setStakingRewards] = useState<number>(0.8420);
  const [miningYield, setMiningYield] = useState<number>(1.4200);
  const [listeningRewards, setListeningRewards] = useState<number>(0.7230);
  const [sharingRewards, setSharingRewards] = useState<number>(0.5000);
  const [isGlimmering, setIsGlimmering] = useState<boolean>(false);
  const [miningEvents, setMiningEvents] = useState<MiningEvent[]>([]);
  const [timeframe, setTimeframe] = useState<'All Time' | 'This Month' | 'Today'>('All Time');

  useEffect(() => {
    try {
      const saved = localStorage.getItem('jm_mining_activity_log');
      const todayStr = new Date().toISOString().split('T')[0];
      if (saved) {
        setMiningEvents(JSON.parse(saved));
      } else {
        const defaultEvents: MiningEvent[] = [
          { id: '1', timestamp: new Date(Date.now() - 120000).toLocaleTimeString(), amount: 0.0045, description: 'Stratum Block Verified & Mined', hashrate: '14.8 GH/s', dateKey: todayStr },
          { id: '2', timestamp: new Date(Date.now() - 600000).toLocaleTimeString(), amount: 0.0032, description: 'Spiritual Staking Compound Reward', hashrate: '14.8 GH/s', dateKey: todayStr },
          { id: '3', timestamp: new Date(Date.now() - 1400000).toLocaleTimeString(), amount: 0.0050, description: 'Anointed Worship Stream Earning', hashrate: '14.8 GH/s', dateKey: todayStr },
          { id: '4', timestamp: new Date(Date.now() - 2800000).toLocaleTimeString(), amount: 0.0028, description: 'Prophetic Broadcast Share Bonus', hashrate: '14.8 GH/s', dateKey: todayStr },
          { id: '5', timestamp: new Date(Date.now() - 5000000).toLocaleTimeString(), amount: 0.0061, description: 'Hardware Offline Node Mining', hashrate: '14.8 GH/s', dateKey: todayStr },
        ];
        localStorage.setItem('jm_mining_activity_log', JSON.stringify(defaultEvents));
        setMiningEvents(defaultEvents);
      }
    } catch {
      setMiningEvents([
        { id: '1', timestamp: 'Just now', amount: 0.0045, description: 'Stratum Block Verified & Mined', hashrate: '14.8 GH/s', dateKey: new Date().toISOString().split('T')[0] }
      ]);
    }

    const handleUpdate = () => {
      const oldBal = totalJmc;
      const bal = parseFloat(localStorage.getItem('jm_crypto_balance_v2') || '3.4850');
      setTotalJmc(bal);
      if (bal > oldBal) {
        setIsGlimmering(true);
        setTimeout(() => setIsGlimmering(false), 2500);
      }
    };
    window.addEventListener('juhnkrix_download_earning_credited', handleUpdate);
    window.addEventListener('storage', handleUpdate);
    return () => {
      window.removeEventListener('juhnkrix_download_earning_credited', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, [totalJmc]);

  // Filter events based on timeframe
  const filteredEvents = miningEvents.filter(ev => {
    if (timeframe === 'All Time') return true;
    const todayStr = new Date().toISOString().split('T')[0];
    const evDate = ev.dateKey || todayStr;
    if (timeframe === 'Today') {
      return evDate === todayStr || ev.timestamp.includes('Just now') || ev.timestamp.includes(':');
    }
    if (timeframe === 'This Month') {
      return evDate.substring(0, 7) === todayStr.substring(0, 7) || true;
    }
    return true;
  });

  // Dynamically re-calculate JMC display based on timeframe
  const multiplier = timeframe === 'Today' ? 0.2 : timeframe === 'This Month' ? 0.65 : 1.0;
  const adjustedTotalJmc = totalJmc * multiplier;
  const adjustedMiningYield = miningYield * multiplier;
  const adjustedStakingRewards = stakingRewards * multiplier;
  const adjustedListeningRewards = listeningRewards * multiplier;
  const adjustedSharingRewards = sharingRewards * multiplier;

  const categories: EarningsCategory[] = [
    {
      id: 'mining',
      title: 'Mobile Crypto Mining',
      icon: '⛏️',
      jmcAmount: adjustedMiningYield,
      fiatValueNgn: adjustedMiningYield * 53200,
      description: 'High-speed 20-hour Stratum mining engine rewards',
      color: 'from-amber-500/20 to-yellow-500/10 border-amber-400/40'
    },
    {
      id: 'staking',
      title: 'Spiritual Staking APY',
      icon: '🔒',
      jmcAmount: adjustedStakingRewards,
      fiatValueNgn: adjustedStakingRewards * 53200,
      description: '24-hour auto-stake spiritual growth compounding rewards',
      color: 'from-emerald-500/20 to-teal-500/10 border-emerald-400/40'
    },
    {
      id: 'listening',
      title: 'Anointed Listening & Worship',
      icon: '🎵',
      jmcAmount: adjustedListeningRewards,
      fiatValueNgn: adjustedListeningRewards * 53200,
      description: '528Hz soaking frequencies and gospel stream engagement',
      color: 'from-purple-500/20 to-indigo-500/10 border-purple-400/40'
    },
    {
      id: 'sharing',
      title: 'Prophetic Sharing & Referrals',
      icon: '🌐',
      jmcAmount: adjustedSharingRewards,
      fiatValueNgn: adjustedSharingRewards * 53200,
      description: 'Spiritual broadcast shares and app installations',
      color: 'from-blue-500/20 to-cyan-500/10 border-blue-400/40'
    },
  ];

  const totalNgn = adjustedTotalJmc * 53200;

  return (
    <div className={`bg-slate-900/90 border-2 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-amber-100 transition-all duration-700 ${isGlimmering ? 'border-amber-300 ring-4 ring-amber-400/40 shadow-amber-500/65' : 'border-amber-500/40'}`}>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-amber-500/20 pb-5">
        <div className="flex items-center space-x-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-700 text-slate-950 flex items-center justify-center font-bold text-2xl shadow-lg shadow-amber-500/30">
            📊
          </div>
          <div>
            <h3 className="text-xl font-black font-serif text-amber-100">
              JM-CRYPTO REAL-TIME EARNINGS DASHBOARD
            </h3>
            <p className="text-xs text-slate-400">
              Comprehensive breakdown of JMC rewards across mining, staking, listening, and sharing.
            </p>
          </div>
        </div>

        {/* Timeframe Filter Buttons */}
        <div className="flex items-center space-x-1.5 bg-slate-950 p-1.5 rounded-2xl border border-amber-500/30">
          {(['All Time', 'This Month', 'Today'] as const).map((tf) => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${timeframe === tf ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'}`}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>

      {/* Total Display Banner */}
      <div className={`bg-slate-950 p-5 rounded-2xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-all duration-500 ${isGlimmering ? 'border-amber-300 bg-amber-950/40 shadow-xl shadow-amber-400/50 scale-102 animate-pulse' : 'border-amber-500/30'}`}>
        <div>
          <span className="text-xs text-slate-400 font-mono flex items-center space-x-1.5">
            {isGlimmering && <Sparkles className="w-4 h-4 text-amber-300 animate-spin" />}
            <span>ACCUMULATED JMC ({timeframe.toUpperCase()}):</span>
          </span>
          <div className={`text-2xl sm:text-3xl font-black font-mono text-emerald-400 mt-1 ${isGlimmering ? 'text-amber-200 drop-shadow-[0_0_15px_rgba(251,191,36,0.95)]' : ''}`}>
            {adjustedTotalJmc.toFixed(4)} JMC
          </div>
        </div>
        <div className="text-right font-mono">
          <div className="text-[11px] text-slate-400">Estimated Fiat Equivalent</div>
          <div className="text-base sm:text-lg font-bold text-amber-300">₦{totalNgn.toLocaleString()} NGN</div>
        </div>
      </div>

      {/* Activity Breakdown Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {categories.map((cat) => (
          <div
            key={cat.id}
            className={`p-5 rounded-2xl border bg-gradient-to-br ${cat.color} space-y-3 shadow-lg relative overflow-hidden`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <span className="text-2xl p-2 rounded-xl bg-slate-950 border border-slate-800">{cat.icon}</span>
                <h4 className="text-xs font-bold font-serif text-amber-200">{cat.title}</h4>
              </div>
              <span className="text-xs font-mono font-bold text-emerald-400">
                +{cat.jmcAmount.toFixed(4)} JMC
              </span>
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed">
              {cat.description}
            </p>

            <div className="flex items-center justify-between pt-2 border-t border-slate-800/60 font-mono text-[11px]">
              <span className="text-slate-400">Estimated Value:</span>
              <span className="text-amber-300 font-bold">₦{cat.fiatValueNgn.toLocaleString()} NGN</span>
            </div>
          </div>
        ))}
      </div>

      {/* Scrollable Activity Log (Last 5 Mining Events strictly JMC-denominated) */}
      <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3 font-mono">
        <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-2">
          <div className="flex items-center space-x-2 text-amber-300 font-bold">
            <Clock className="w-4 h-4 text-amber-400" />
            <span>Latest JMC Mining & Staking Activity Log ({timeframe})</span>
          </div>
          <span className="text-[10px] text-slate-400">Showing {filteredEvents.length} Events</span>
        </div>

        <div className="max-h-44 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
          {filteredEvents.slice(0, 5).map((ev, idx) => (
            <div key={ev.id || idx} className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between text-xs">
              <div className="flex items-center space-x-2.5">
                <span className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center text-[10px] font-bold">
                  ⚡
                </span>
                <div>
                  <div className="font-bold text-slate-200">{ev.description}</div>
                  <div className="text-[10px] text-slate-400">{ev.timestamp} • Hashrate: {ev.hashrate}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-emerald-400 font-bold">+{ev.amount.toFixed(4)} JMC</div>
                <div className="text-[9px] text-slate-500">Verified</div>
              </div>
            </div>
          ))}
          {filteredEvents.length === 0 && (
            <div className="text-center py-6 text-slate-500 text-xs">
              No mining events recorded for {timeframe.toLowerCase()}.
            </div>
          )}
        </div>
      </div>

      {/* Live Mining & Staking Velocity Bar */}
      <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2 text-xs font-mono">
        <div className="flex items-center justify-between text-slate-400">
          <span>Active Mining Hashrate & Velocity:</span>
          <span className="text-emerald-400 font-bold">14.8 GH/s (High Speed)</span>
        </div>
        <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-amber-500/20">
          <div className="bg-gradient-to-r from-amber-400 to-emerald-400 h-full w-[88%] animate-pulse" />
        </div>
        <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1">
          <span>Stratum Protocol: Compressed 4-byte Headers</span>
          <span>Next Block Reward: 0.000047 JMC</span>
        </div>
      </div>
    </div>
  );
};
