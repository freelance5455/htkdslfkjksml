import { useEffect, useState } from "react";
import { CATALOG, findCatalog } from "@/lib/catalog";
import { CLASS_LABEL, KIND_LABEL, uid } from "@/lib/format";
import { fxToHuf } from "@/lib/portfolio-math";
import { usePortfolio } from "@/lib/portfolio-context";
import type { AssetClass, Currency, Holding } from "@/lib/types";
import { Field, Modal } from "./ui";

const CURRENCIES: Currency[] = ["HUF", "EUR", "USD", "GBP"];
const CLASSES: AssetClass[] = ["etf", "reszveny", "kripto", "keszpenz"];

function num(value: string): number {
  const parsed = Number(value.replace(/\s/g, "").replace(",", "."));
  return Number.isFinite(parsed) ? parsed : NaN;
}

export function HoldingDialog({
  open,
  holding,
  mode,
  onClose,
}: {
  open: boolean;
  holding: Holding | null;
  mode: "asset" | "cash";
  onClose: () => void;
}) {
  const { state, saveHolding, refresh } = usePortfolio();
  const [source, setSource] = useState("VWCE");
  const [symbol, setSymbol] = useState("");
  const [name, setName] = useState("");
  const [assetClass, setAssetClass] = useState<AssetClass>("etf");
  const [currency, setCurrency] = useState<Currency>("EUR");
  const [groupId, setGroupId] = useState(state.groups[0]?.id ?? "");
  const [quantity, setQuantity] = useState("");
  const [avgCost, setAvgCost] = useState("");
  const [costFx, setCostFx] = useState("");
  const [manualPrice, setManualPrice] = useState("");
  const [yahoo, setYahoo] = useState("");
  const [gecko, setGecko] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    const cash = holding?.assetClass === "keszpenz" || (!holding && mode === "cash");
    const known = holding ? findCatalog(holding.symbol) : undefined;
    setSource(cash ? "cash" : known?.symbol ?? (holding ? "custom" : "VWCE"));
    setSymbol(holding?.symbol ?? "");
    setName(holding?.name ?? "");
    setAssetClass(holding?.assetClass ?? (cash ? "keszpenz" : "etf"));
    setCurrency(holding?.currency ?? (cash ? "EUR" : "EUR"));
    setGroupId(holding?.groupId ?? state.groups[0]?.id ?? "");
    setQuantity(holding ? String(holding.quantity) : "");
    setAvgCost(holding ? String(holding.avgCost) : cash ? "1" : "");
    setCostFx(holding ? String(holding.costFxToHuf) : "");
    setManualPrice(holding?.manualPrice ? String(holding.manualPrice) : "");
    setYahoo(holding?.yahoo ?? "");
    setGecko(holding?.gecko ?? "");
    setError("");
  }, [open, holding, mode, state.groups]);

  const catalog = source !== "custom" && source !== "cash" ? findCatalog(source) : undefined;
  const resolvedClass: AssetClass = source === "cash" ? "keszpenz" : (catalog?.assetClass ?? assetClass);
  const resolvedCurrency: Currency = source === "cash" ? currency : (catalog?.currency ?? currency);

  const save = () => {
    const qty = num(quantity);
    const cost = resolvedClass === "keszpenz" ? 1 : num(avgCost);
    const fxInput = num(costFx);
    const fx = Number.isFinite(fxInput) && fxInput > 0 ? fxInput : fxToHuf(resolvedCurrency, state.market.fx);
    const sym = (source === "cash" ? resolvedCurrency : catalog?.symbol ?? symbol).trim().toUpperCase();
    if (!sym) return setError("Kell egy szimbólum.");
    if (!groupId) return setError("Válassz csoportot.");
    if (!Number.isFinite(qty) || qty < 0) return setError("A mennyiség nem szám.");
    if (!Number.isFinite(cost) || cost < 0) return setError("A bekerülési ár nem szám.");
    const manual = num(manualPrice);
    const next: Holding = {
      id: holding?.id ?? uid(),
      symbol: sym,
      name: source === "cash" ? `Készpénz (${resolvedCurrency})` : name || catalog?.name || sym,
      assetClass: resolvedClass,
      currency: resolvedCurrency,
      groupId,
      quantity: qty,
      avgCost: cost,
      costFxToHuf: resolvedCurrency === "HUF" ? 1 : fx,
      manualPrice: Number.isFinite(manual) && manual > 0 ? manual : undefined,
      yahoo: yahoo.trim().toUpperCase() || catalog?.yahoo,
      gecko: gecko.trim().toLowerCase() || catalog?.gecko,
      chain: holding?.chain,
      walletAddress: holding?.walletAddress,
    };
    saveHolding(next);
    onClose();
    void refresh();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={holding ? "Eszköz módosítása" : source === "cash" || mode === "cash" ? "Készpénz" : "Új eszköz"}
      description="Ugyanaz a papír több csoportban is lehet, külön soron."
    >
      <div className="grid gap-3">
        {mode === "asset" || holding?.assetClass !== "keszpenz" ? (
          <Field label="Katalógus">
            <select className="field" value={source} onChange={(event) => setSource(event.target.value)}>
              <optgroup label="ETF">
                {CATALOG.filter((item) => item.assetClass === "etf").map((item) => (
                  <option key={item.symbol} value={item.symbol}>
                    {item.symbol} · {item.name}
                  </option>
                ))}
              </optgroup>
              <optgroup label="Részvény">
                {CATALOG.filter((item) => item.assetClass === "reszveny").map((item) => (
                  <option key={item.symbol} value={item.symbol}>
                    {item.symbol} · {item.name}
                  </option>
                ))}
              </optgroup>
              <optgroup label="Kripto">
                {CATALOG.filter((item) => item.assetClass === "kripto").map((item) => (
                  <option key={item.symbol} value={item.symbol}>
                    {item.symbol} · {item.name}
                  </option>
                ))}
              </optgroup>
              <option value="custom">Saját szimbólum</option>
              <option value="cash">Készpénz</option>
            </select>
          </Field>
        ) : null}
        {source === "custom" ? (
          <>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Szimbólum">
                <input className="field" value={symbol} onChange={(event) => setSymbol(event.target.value)} />
              </Field>
              <Field label="Név">
                <input className="field" value={name} onChange={(event) => setName(event.target.value)} />
              </Field>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Osztály">
                <select className="field" value={assetClass} onChange={(event) => setAssetClass(event.target.value as AssetClass)}>
                  {CLASSES.filter((item) => item !== "keszpenz").map((item) => (
                    <option key={item} value={item}>
                      {CLASS_LABEL[item]}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Jegyzés devizája">
                <select className="field" value={currency} onChange={(event) => setCurrency(event.target.value as Currency)}>
                  {CURRENCIES.map((item) => (
                    <option key={item}>{item}</option>
                  ))}
                </select>
              </Field>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Yahoo szimbólum">
                <input className="field" value={yahoo} placeholder="VWCE.DE" onChange={(event) => setYahoo(event.target.value)} />
              </Field>
              <Field label="CoinGecko azonosító">
                <input className="field" value={gecko} placeholder="bitcoin" onChange={(event) => setGecko(event.target.value)} />
              </Field>
            </div>
            <Field label="Kézi ár, ha nincs jegyzés">
              <input className="field tabular-nums" inputMode="decimal" value={manualPrice} onChange={(event) => setManualPrice(event.target.value)} />
            </Field>
          </>
        ) : null}
        {source === "cash" || mode === "cash" && !holding ? (
          <Field label="Deviza">
            <select className="field" value={currency} onChange={(event) => setCurrency(event.target.value as Currency)}>
              {CURRENCIES.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
          </Field>
        ) : null}
        <Field label="Csoport vagy számla">
          <select className="field" value={groupId} onChange={(event) => setGroupId(event.target.value)}>
            {state.groups.map((group) => (
              <option key={group.id} value={group.id}>
                {group.name} · {KIND_LABEL[group.kind]}
              </option>
            ))}
          </select>
        </Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label={resolvedClass === "keszpenz" ? "Összeg" : "Mennyiség"}>
            <input className="field tabular-nums" inputMode="decimal" value={quantity} onChange={(event) => setQuantity(event.target.value)} />
          </Field>
          {resolvedClass === "keszpenz" ? null : (
            <Field label={`Bekerülés (${resolvedCurrency})`}>
              <input className="field tabular-nums" inputMode="decimal" value={avgCost} onChange={(event) => setAvgCost(event.target.value)} />
            </Field>
          )}
        </div>
        {resolvedCurrency !== "HUF" ? (
          <Field label={`Bekerüléskori árfolyam (1 ${resolvedCurrency} hány Ft)`}>
            <input
              className="field tabular-nums"
              inputMode="decimal"
              placeholder={String(Math.round(fxToHuf(resolvedCurrency, state.market.fx)))}
              value={costFx}
              onChange={(event) => setCostFx(event.target.value)}
            />
          </Field>
        ) : null}
        {error ? <p className="text-sm text-clay">{error}</p> : null}
        <div className="mt-2 flex justify-end gap-2">
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            Mégse
          </button>
          <button type="button" className="btn btn-primary" onClick={save}>
            Mentés
          </button>
        </div>
      </div>
    </Modal>
  );
}
