import React, { useState, useEffect } from 'react';
import { X, Heart, Send, ChevronDown, CornerDownRight } from 'lucide-react';
import { Comment, Post } from '../types';
import { subscribeComments, addCommentToPost } from '../services/db';
import { useAuth } from '../context/AuthContext';

interface CommentsDrawerProps {
  post: Post;
  isOpen: boolean;
  onClose: () => void;
}

export const CommentsDrawer: React.FC<CommentsDrawerProps> = ({ post, isOpen, onClose }) => {
  const { userProfile } = useAuth();
  const [comments, setComments] = useState<Comment[]>([]);
  const [inputText, setInputText] = useState('');
  const [replyingTo, setReplyingTo] = useState<Comment | null>(null);
  const [likedCommentIds, setLikedCommentIds] = useState<Set<string>>(new Set());

  const QUICK_EMOJIS = ['❤️', '🔥', '😂', '😍', '😮', '🙌'];

  useEffect(() => {
    if (!isOpen) return;
    const unsubscribe = subscribeComments(post.id, (loaded) => {
      setComments(loaded);
    });
    return () => unsubscribe();
  }, [post.id, isOpen]);

  const handleSendComment = async (textToSend?: string) => {
    const finalContent = textToSend || inputText;
    if (!finalContent.trim()) return;

    const currentSender = userProfile || {
      id: 'guest',
      username: 'joaovibes',
      displayName: 'João Vibes',
      photoURL: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=300&q=80',
    };

    const isCreator = currentSender.username === post.username || currentSender.id === post.userId;

    try {
      await addCommentToPost({
        postId: post.id,
        userId: currentSender.id,
        username: currentSender.username,
        userDisplayName: currentSender.displayName,
        userPhotoURL: currentSender.photoURL,
        isCreator,
        text: finalContent.trim(),
        parentId: replyingTo?.id || null,
        replyToUsername: replyingTo ? replyingTo.username : null,
      });

      setInputText('');
      setReplyingTo(null);
    } catch (err) {
      console.error('Error adding comment:', err);
    }
  };

  const handleToggleLikeComment = (commentId: string) => {
    setLikedCommentIds((prev) => {
      const next = new Set(prev);
      if (next.has(commentId)) {
        next.delete(commentId);
      } else {
        next.add(commentId);
      }
      return next;
    });
  };

  if (!isOpen) return null;

  // Separate parent comments and replies
  const parentComments = comments.filter((c) => !c.parentId);
  const repliesByParentId = comments.reduce<Record<string, Comment[]>>((acc, c) => {
    if (c.parentId) {
      if (!acc[c.parentId]) acc[c.parentId] = [];
      acc[c.parentId].push(c);
    }
    return acc;
  }, {});

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm animate-fade-in">
      <div
        className="w-full max-w-lg h-[80vh] bg-[#101014] rounded-t-3xl border-t border-[#19191F] flex flex-col shadow-2xl relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Grab bar */}
        <div className="w-12 h-1 bg-[#272730] rounded-full mx-auto mt-2.5 mb-1" />

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3 border-b border-[#19191F]">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-bold text-white">Comentários</h2>
            <span className="text-xs text-[#A1A1AA]">{comments.length || post.commentsCount}</span>
          </div>

          <div className="flex items-center gap-4">
            <button className="flex items-center gap-1 text-xs text-[#A1A1AA] hover:text-white transition-colors">
              <span>Mais relevantes</span>
              <ChevronDown size={14} />
            </button>
            <button
              onClick={onClose}
              className="p-1 text-[#A1A1AA] hover:text-white rounded-full hover:bg-[#19191F] transition-colors"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Comments List */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          {parentComments.length === 0 ? (
            <div className="py-12 text-center text-[#A1A1AA] text-xs">
              Nenhum comentário ainda. Seja o primeiro a interagir!
            </div>
          ) : (
            parentComments.map((comment) => {
              const replies = repliesByParentId[comment.id] || [];
              const isLiked = likedCommentIds.has(comment.id);

              return (
                <div key={comment.id} className="space-y-3">
                  {/* Parent comment */}
                  <div className="flex items-start gap-3">
                    <img
                      src={comment.userPhotoURL}
                      alt={comment.username}
                      className="w-9 h-9 rounded-full object-cover shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white">
                          @{comment.username}
                        </span>
                        {comment.isCreator && (
                          <span className="text-[10px] font-bold text-[#FF008C] bg-[#FF008C]/15 px-1.5 py-0.2 rounded">
                            Criador
                          </span>
                        )}
                        <span className="text-[11px] text-[#A1A1AA]">2h</span>
                      </div>
                      <p className="text-xs text-white/90 mt-1 break-words">{comment.text}</p>
                      <button
                        onClick={() => setReplyingTo(comment)}
                        className="text-[11px] font-semibold text-[#A1A1AA] hover:text-white mt-1 cursor-pointer"
                      >
                        Responder
                      </button>
                    </div>

                    <button
                      onClick={() => handleToggleLikeComment(comment.id)}
                      className="flex flex-col items-center text-[#A1A1AA] hover:text-[#FF3B30] p-1"
                    >
                      <Heart
                        size={16}
                        className={isLiked ? 'fill-[#FF3B30] text-[#FF3B30]' : ''}
                      />
                      <span className="text-[10px] mt-0.5">
                        {comment.likesCount + (isLiked ? 1 : 0)}
                      </span>
                    </button>
                  </div>

                  {/* Indented replies */}
                  {replies.map((reply) => {
                    const isReplyLiked = likedCommentIds.has(reply.id);
                    return (
                      <div key={reply.id} className="ml-10 flex items-start gap-2.5 pt-1">
                        <CornerDownRight size={14} className="text-[#A1A1AA] mt-1 shrink-0" />
                        <img
                          src={reply.userPhotoURL}
                          alt={reply.username}
                          className="w-7 h-7 rounded-full object-cover shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-white">
                              @{reply.username}
                            </span>
                            {reply.isCreator && (
                              <span className="text-[10px] font-bold text-[#FF008C] bg-[#FF008C]/15 px-1.5 py-0.2 rounded">
                                Criador
                              </span>
                            )}
                            <span className="text-[11px] text-[#A1A1AA]">1h</span>
                          </div>
                          <p className="text-xs text-white/90 mt-0.5 break-words">{reply.text}</p>
                          <button
                            onClick={() => setReplyingTo(reply)}
                            className="text-[11px] font-semibold text-[#A1A1AA] hover:text-white mt-1 cursor-pointer"
                          >
                            Responder
                          </button>
                        </div>
                        <button
                          onClick={() => handleToggleLikeComment(reply.id)}
                          className="flex flex-col items-center text-[#A1A1AA] hover:text-[#FF3B30] p-1"
                        >
                          <Heart
                            size={14}
                            className={isReplyLiked ? 'fill-[#FF3B30] text-[#FF3B30]' : ''}
                          />
                          <span className="text-[10px] mt-0.5">
                            {reply.likesCount + (isReplyLiked ? 1 : 0)}
                          </span>
                        </button>
                      </div>
                    );
                  })}
                </div>
              );
            })
          )}
        </div>

        {/* Quick Emojis Bar matching reference image:
            ❤️ 🔥 😂 😍 😮 🙌 */}
        <div className="flex items-center justify-between px-6 py-2 bg-[#050505] border-t border-[#19191F]">
          {QUICK_EMOJIS.map((emoji) => (
            <button
              key={emoji}
              onClick={() => handleSendComment(emoji)}
              className="text-xl hover:scale-125 active:scale-95 transition-transform p-1 cursor-pointer"
            >
              {emoji}
            </button>
          ))}
        </div>

        {/* Replying banner if active */}
        {replyingTo && (
          <div className="flex items-center justify-between px-5 py-1.5 bg-[#19191F] text-xs text-[#A1A1AA]">
            <span>Respondendo a <strong className="text-white">@{replyingTo.username}</strong></span>
            <button onClick={() => setReplyingTo(null)} className="text-white hover:text-red-400">
              <X size={14} />
            </button>
          </div>
        )}

        {/* Bottom Input Area */}
        <div className="p-3 bg-[#050505] border-t border-[#19191F] flex items-center gap-3">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendComment()}
            placeholder="Adicione um comentário..."
            className="flex-1 bg-[#19191F] border border-[#272730] rounded-full px-4 py-2.5 text-xs md:text-sm text-white placeholder-[#A1A1AA] focus:outline-none focus:border-[#FF008C]"
          />
          <button
            onClick={() => handleSendComment()}
            disabled={!inputText.trim()}
            className="w-10 h-10 rounded-full bg-clipshare-gradient glow-clipshare flex items-center justify-center text-white shrink-0 disabled:opacity-40 active:scale-95 transition-all cursor-pointer"
          >
            <Send size={16} className="-ml-0.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
