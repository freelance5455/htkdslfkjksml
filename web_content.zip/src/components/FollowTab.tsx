import React, { useState } from 'react';
import { Send, MessageCircle, HelpCircle, Award, CheckCircle, Sparkles, Share2, ThumbsUp } from 'lucide-react';

export const FollowTab: React.FC = () => {
  const [userDoubt, setUserDoubt] = useState('');
  const [doubtResponse, setDoubtResponse] = useState<string | null>(null);
  const [isAsking, setIsAsking] = useState(false);
  const [dailyAnswered, setDailyAnswered] = useState<number | null>(null);

  const handleAskDoubt = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userDoubt.trim()) return;

    setIsAsking(true);
    // Instant smart biology answer simulation
    setTimeout(() => {
      setIsAsking(false);
      setDoubtResponse(
        `आपके प्रश्न "${userDoubt}" का उत्तर: NCERT कक्षा 11 जीव विज्ञान के अनुसार, इस संकल्पना को मुख्य रूप से कोशिका चक्र एवं पादप/मानव शारीरिकी के संदर्भ में समझा जाता है। परीक्षा में इसका सचित्र वर्णन करने से 100% अंक मिलते हैं। विस्तृत विवरण हेतु ऐप के 'नोट्स' अनुभाग में संबंधित अध्याय देखें!`
      );
    }, 600);
  };

  return (
    <div className="w-full max-w-md mx-auto px-4 pt-3 pb-24 space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-lg font-bold text-slate-800 font-devanagari">
          कम्युनिटी & फॉलो (Study Hub)
        </h2>
        <p className="text-xs text-slate-500">
          जीव विज्ञान अध्ययन समूह, टॉपर्स टिप्स एवं दैनिक प्रश्नोत्तरी
        </p>
      </div>

      {/* Daily Biology MCQ of the Day */}
      <div className="bg-gradient-to-br from-teal-50 to-emerald-50 border border-teal-200 rounded-2xl p-4 shadow-sm space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-bold text-teal-800 uppercase tracking-wider flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-teal-600" />
            आज का महत्वपूर्ण प्रश्न (Question of the Day)
          </span>
          <span className="text-[10px] bg-teal-600 text-white font-bold px-2 py-0.5 rounded-full">
            NEET Special
          </span>
        </div>

        <p className="text-xs font-bold text-slate-900 font-devanagari leading-snug">
          "कोशिका सिद्धांत में 'Omnis cellula-e cellula' किस वैज्ञानिक ने प्रतिपादित किया था?"
        </p>

        <div className="grid grid-cols-2 gap-2 text-xs font-devanagari">
          {['रॉबर्ट हुक', 'श्लीडेन व श्वान', 'रुडोल्फ विरचो', 'रॉबर्ट ब्राउन'].map((opt, i) => (
            <button
              key={i}
              onClick={() => setDailyAnswered(i)}
              className={`p-2 rounded-xl border text-left transition-colors ${
                dailyAnswered === null
                  ? 'bg-white border-teal-100 hover:border-teal-400 text-slate-800'
                  : i === 2
                  ? 'bg-emerald-100 border-emerald-400 text-emerald-900 font-bold'
                  : dailyAnswered === i
                  ? 'bg-rose-100 border-rose-300 text-rose-900 font-bold'
                  : 'bg-white/50 border-slate-200 text-slate-400'
              }`}
            >
              {opt}
            </button>
          ))}
        </div>

        {dailyAnswered !== null && (
          <p className="text-[11px] text-teal-900 bg-white/80 p-2 rounded-lg font-medium">
            {dailyAnswered === 2
              ? '🎉 शाबाश! 1855 में रुडोल्फ विरचो ने बताया कि नई कोशिकाएं पूर्ववर्ती कोशिकाओं से बनती हैं।'
              : '❌ सही उत्तर: रुडोल्फ विरचो (Rudolf Virchow - 1855)।'}
          </p>
        )}
      </div>

      {/* Ask Doubt to Biology Teacher */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-3">
        <div className="flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-indigo-600" />
          <h3 className="text-sm font-bold text-slate-800 font-devanagari">
            बायोलॉजी डाउट पूछें (Instant Doubt Solver)
          </h3>
        </div>

        <form onSubmit={handleAskDoubt} className="space-y-2">
          <textarea
            value={userDoubt}
            onChange={(e) => setUserDoubt(e.target.value)}
            placeholder="अपना प्रश्न यहाँ लिखें... (उदा. C3 और C4 पौधों में क्या अंतर है?)"
            rows={2}
            className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#00838f] text-slate-800"
          />
          <button
            type="submit"
            disabled={isAsking || !userDoubt.trim()}
            className="w-full py-2 bg-[#00838f] hover:bg-[#006064] disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
          >
            {isAsking ? (
              <span>विश्लेषण कर रहे हैं...</span>
            ) : (
              <>
                <Send className="w-3.5 h-3.5" />
                <span>उत्तर प्राप्त करें</span>
              </>
            )}
          </button>
        </form>

        {doubtResponse && (
          <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-xl text-xs text-indigo-950 font-devanagari leading-relaxed">
            {doubtResponse}
          </div>
        )}
      </div>

      {/* Social Communities */}
      <div className="space-y-2.5">
        <h3 className="text-xs font-bold text-slate-700 font-devanagari uppercase tracking-wider">
          स्टडी ग्रुप्स से जुड़ें
        </h3>

        {/* Telegram */}
        <div className="bg-white border border-slate-200 rounded-2xl p-3.5 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sky-500 text-white flex items-center justify-center font-bold text-lg shadow-sm">
              ✈️
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 font-devanagari">
                Telegram Biology Study Channel
              </h4>
              <p className="text-[11px] text-slate-500">
                45,000+ छात्र जुड़े हैं · दैनिक PDF नोट्स
              </p>
            </div>
          </div>
          <button
            onClick={() => alert('टेलीग्राम चैनल से जुड़ने के लिए धन्यवाद!')}
            className="px-3 py-1.5 rounded-lg bg-sky-500 hover:bg-sky-600 text-white text-xs font-bold transition-colors cursor-pointer"
          >
            जुड़ें
          </button>
        </div>

        {/* WhatsApp Group */}
        <div className="bg-white border border-slate-200 rounded-2xl p-3.5 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500 text-white flex items-center justify-center font-bold text-lg shadow-sm">
              <MessageCircle className="w-5 h-5 text-white" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 font-devanagari">
                WhatsApp डाउट ग्रुप (कक्षा 11)
              </h4>
              <p className="text-[11px] text-slate-500">
                शिक्षकों द्वारा त्वरित समाधान
              </p>
            </div>
          </div>
          <button
            onClick={() => alert('व्हाट्सएप ग्रुप लिंक क्लिपबोर्ड पर कॉपी हो गया!')}
            className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold transition-colors cursor-pointer"
          >
            ग्रुप जॉइन
          </button>
        </div>
      </div>
    </div>
  );
};
