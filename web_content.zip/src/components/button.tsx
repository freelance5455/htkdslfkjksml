import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/cn";

type Variant = "primary" | "surface" | "ghost" | "danger";

const styles: Record<Variant, string> = {
  primary: "bg-primary text-primary-fg hover:bg-primary-deep",
  surface: "border border-line bg-surface text-fg hover:border-primary",
  ghost: "bg-transparent text-fg hover:bg-surface-2",
  danger: "border border-line bg-surface text-accent hover:border-accent",
};

export function Button({
  variant = "primary",
  className,
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  return (
    <button
      type={type}
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-md px-4 text-sm font-semibold transition-colors duration-200 disabled:cursor-not-allowed disabled:opacity-50",
        styles[variant],
        className,
      )}
      {...props}
    />
  );
}
