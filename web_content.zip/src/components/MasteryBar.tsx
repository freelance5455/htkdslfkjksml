import React from 'react';
import { getMasteryTier, FORGETTING_INTERVALS } from '../utils/spacedRepetition';

interface MasteryBarProps {
  score: number;
  currentStage: number;
  showMilestones?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export const MasteryBar: React.FC<MasteryBarProps> = ({
  score,
  currentStage,
  showMilestones = true,
  size = 'md',
}) => {
  const tier = getMasteryTier(score);
  const clampedScore = Math.max(0, Math.min(100, Math.round(score)));

  // Milestone labels matching Day 1, 3, 7, 21, 30, 60, 90
  const milestoneDays = [1, 3, 7, 21, 30, 60];

  const barHeight = size === 'sm' ? 'h-2' : size === 'lg' ? 'h-3.5' : 'h-2.5';

  return (
    <div className="w-full space-y-1.5">
      {/* Header labels */}
      <div className="flex items-center justify-between text-xs">
        <div className="flex items-center gap-1.5">
          <span
            className="w-2 h-2 rounded-full inline-block shrink-0"
            style={{ backgroundColor: tier.colorHex }}
            aria-hidden="true"
          />
          <span className="font-medium text-slate-700 dark:text-slate-300">
            {tier.label}
          </span>
        </div>
        <span className="font-mono tabular-nums font-semibold text-slate-900 dark:text-slate-100">
          {clampedScore}%
        </span>
      </div>

      {/* Progress Track */}
      <div
        className={`relative w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden ${barHeight} transition-all`}
        role="progressbar"
        aria-valuenow={clampedScore}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={`Mastery level: ${tier.label}, ${clampedScore}%`}
      >
        <div
          className="h-full rounded-full transition-all duration-500 ease-out"
          style={{
            width: `${clampedScore}%`,
            backgroundColor: tier.colorHex,
            boxShadow: `0 0 10px ${tier.colorHex}40`,
          }}
        />
      </div>

      {/* Milestone tick indicators (Day 1, 3, 7, 21, 30, 60) */}
      {showMilestones && (
        <div className="pt-1 flex items-center justify-between text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400">
          {milestoneDays.map((day, idx) => {
            const isReached = currentStage >= idx + 1;
            const isCurrent = currentStage === idx;
            return (
              <div
                key={day}
                className="flex flex-col items-center"
                title={`Milestone Day ${day}: ${isReached ? 'Completed' : isCurrent ? 'Current target' : 'Upcoming'}`}
              >
                <div
                  className={`w-1.5 h-1.5 rounded-full mb-0.5 transition-colors ${
                    isReached
                      ? 'bg-emerald-500 ring-2 ring-emerald-200 dark:ring-emerald-950'
                      : isCurrent
                      ? 'bg-amber-500 ring-2 ring-amber-200 dark:ring-amber-950'
                      : 'bg-slate-300 dark:bg-slate-700'
                  }`}
                  aria-hidden="true"
                />
                <span
                  className={
                    isReached
                      ? 'font-medium text-slate-700 dark:text-slate-300'
                      : isCurrent
                      ? 'font-bold text-amber-600 dark:text-amber-400'
                      : 'text-slate-500 dark:text-slate-500'
                  }
                >
                  d{day}
                </span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
