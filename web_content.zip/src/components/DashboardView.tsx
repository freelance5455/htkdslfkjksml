import React from 'react';
import {
  Trophy,
  Zap,
  Target,
  Flame,
  Calendar,
  ChevronRight,
  TrendingUp,
  Award,
  BookOpen,
  CheckCircle,
} from 'lucide-react';
import type { Player, Category, Season, WeeklyResult, DailyRecord } from '../types/index.ts';

interface DashboardViewProps {
  activePlayer: Player;
  currentSeason: Season;
  categories: Category[];
  weeklyRanking: Record<string, WeeklyResult[]>;
  dailyRecords: DailyRecord[];
  todayDateStr: string;
  onNavigate: (tab: 'painel' | 'registrar' | 'ranking' | 'historico' | 'perfil' | 'conquistas' | 'manobras' | 'gestao') => void;
  onSelectCategory: (catId: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  activePlayer,
  currentSeason,
  categories,
  weeklyRanking,
  dailyRecords,
  todayDateStr,
  onNavigate,
  onSelectCategory,
}) => {
  const activeCategories = categories.filter((c) => c.status === 'active');

  // Find active player's performance in current season across categories
  const playerCatSummaries = activeCategories.map((cat) => {
    const ranking = weeklyRanking[cat.id] || [];
    const myResult = ranking.find((r) => r.playerId === activePlayer.id);

    // Today's record
    const todayRec = dailyRecords.find(
      (r) => r.id === `${activePlayer.id}_${cat.id}_${todayDateStr}`
    );

    return {
      category: cat,
      result: myResult,
      todayStreak: todayRec ? todayRec.bestStreak : null,
      leader: ranking[0],
    };
  });

  return (
    <div className="space-y-6">
      {/* Hero Card */}
      <div className="bg-gradient-to-br from-neutral-900 via-neutral-900 to-neutral-950 border border-neutral-800 rounded-3xl p-6 sm:p-7 relative overflow-hidden shadow-2xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
                Temporada em Disputa
              </span>
              <span className="text-[10px] text-neutral-400">· São Paulo</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Olá, {activePlayer.name}!
            </h1>
            <p className="text-xs sm:text-sm text-neutral-400 mt-1 max-w-lg">
              {currentSeason.name} em andamento. Lembre-se: apenas sua maior sequência diária conta para a média semanal.
            </p>
          </div>

          {/* Quick Big CTA */}
          <button
            onClick={() => onNavigate('registrar')}
            className="w-full sm:w-auto px-6 py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-neutral-950 font-black text-sm tracking-wider uppercase shadow-xl shadow-emerald-950 flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <Zap className="w-5 h-5 fill-neutral-950" />
            <span>Registrar Sequência</span>
          </button>
        </div>
      </div>

      {/* Category Performance Cards */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-extrabold uppercase tracking-wider text-neutral-400">
            Sua Classificação Provisória na Semana
          </h2>
          <button
            onClick={() => onNavigate('ranking')}
            className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
          >
            <span>Ver Ranking Geral</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {playerCatSummaries.map(({ category, result, todayStreak, leader }) => {
            const hasPlayed = Boolean(result && result.daysTrained > 0);

            return (
              <div
                key={category.id}
                onClick={() => {
                  onSelectCategory(category.id);
                  onNavigate('ranking');
                }}
                className="p-5 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 transition-all cursor-pointer flex flex-col justify-between"
                role="button"
                tabIndex={0}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="font-extrabold text-white text-base">
                      {category.name}
                    </span>
                    <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                      {category.weightGrams}g
                    </span>
                  </div>

                  {hasPlayed ? (
                    <div className="flex items-center justify-between py-2 border-y border-neutral-800/80 my-2">
                      <div>
                        <span className="text-[10px] text-neutral-500 uppercase tracking-wider block">
                          Sua Posição
                        </span>
                        <span className="text-xl font-black text-white font-mono-numbers">
                          {result?.rank}º lugar
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-neutral-500 uppercase tracking-wider block">
                          Sua Média Semanal
                        </span>
                        <span className="text-2xl font-black text-emerald-400 font-mono-numbers">
                          {result?.formattedAverage}
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="py-4 text-center bg-neutral-950/60 rounded-xl my-2 border border-neutral-800/50">
                      <p className="text-xs text-neutral-400">
                        Nenhum treino seu registrado nesta categoria esta semana.
                      </p>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between text-xs text-neutral-400 pt-2">
                  <span>
                    Hoje: <strong className="text-white font-mono-numbers">{todayStreak !== null ? `${todayStreak} acertos` : 'Pendente'}</strong>
                  </span>
                  <span className="flex items-center gap-1 text-emerald-400 font-semibold text-[11px]">
                    <span>Detalhes</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Quick Navigation Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <button
          onClick={() => onNavigate('ranking')}
          className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-left transition-all"
        >
          <Trophy className="w-5 h-5 text-amber-400 mb-2" />
          <h3 className="font-bold text-white text-xs">Ranking Semanal</h3>
          <p className="text-[11px] text-neutral-500 mt-0.5">Tabela ao vivo e líderes</p>
        </button>

        <button
          onClick={() => onNavigate('historico')}
          className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-left transition-all"
        >
          <TrendingUp className="w-5 h-5 text-emerald-400 mb-2" />
          <h3 className="font-bold text-white text-xs">Todos os Tempos</h3>
          <p className="text-[11px] text-neutral-500 mt-0.5">Média histórica oficial</p>
        </button>

        <button
          onClick={() => onNavigate('conquistas')}
          className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-left transition-all"
        >
          <Award className="w-5 h-5 text-purple-400 mb-2" />
          <h3 className="font-bold text-white text-xs">Galeria de Conquistas</h3>
          <p className="text-[11px] text-neutral-500 mt-0.5">Distintivos e títulos</p>
        </button>

        <button
          onClick={() => onNavigate('manobras')}
          className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-left transition-all"
        >
          <BookOpen className="w-5 h-5 text-blue-400 mb-2" />
          <h3 className="font-bold text-white text-xs">Manobras</h3>
          <p className="text-[11px] text-neutral-500 mt-0.5">Catálogo e desafios</p>
        </button>
      </div>
    </div>
  );
};
