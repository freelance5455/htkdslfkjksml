import React, { useMemo } from 'react';
import type { Sale, StoreData, ViewId } from '../types';
import { fmtDateTime, fmtInt, fmtMoney, toDateKey } from '../utils';
import { Icon } from './Icon';

interface DashboardViewProps {
  data: StoreData;
  t: Record<string, string>;
  onNavigate: (view: ViewId) => void;
  onViewReceipt: (sale: Sale) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ data, t, onNavigate, onViewReceipt }) => {
  const todayKey = toDateKey(new Date());
  const todaysSalesList = useMemo(
    () => data.sales.filter((s) => toDateKey(s.date) === todayKey),
    [data.sales, todayKey]
  );

  const metrics = useMemo(() => {
    const todayRevenue = todaysSalesList.reduce((sum, s) => sum + s.grandTotal, 0);
    const todayProfit = todaysSalesList.reduce((sum, s) => sum + s.profit, 0);
    const todayItems = todaysSalesList.reduce((sum, s) => sum + s.items.reduce((a, b) => a + b.qty, 0), 0);

    const totalRevenue = data.sales.reduce((sum, s) => sum + s.grandTotal, 0);
    const totalProfit = data.sales.reduce((sum, s) => sum + s.profit, 0);
    const avgOrderOverall = data.sales.length > 0 ? totalRevenue / data.sales.length : 0;
    const profitMargin = totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : 0;

    const totalDueReceivable = data.customers.reduce((sum, c) => sum + Number(c.dueBalance || 0), 0);
    const dueCustomerCount = data.customers.filter((c) => Number(c.dueBalance || 0) > 0).length;

    return {
      todayRevenue,
      todayProfit,
      todayItems,
      totalRevenue,
      totalProfit,
      avgOrderOverall,
      profitMargin,
      totalDueReceivable,
      dueCustomerCount,
    };
  }, [todaysSalesList, data.sales, data.customers]);

  const last7DaysSales = useMemo(() => {
    const dayTotals: Record<string, { rev: number; count: number }> = {};
    data.sales.forEach((s) => {
      const dk = toDateKey(s.date);
      if (!dayTotals[dk]) dayTotals[dk] = { rev: 0, count: 0 };
      dayTotals[dk].rev += s.grandTotal;
      dayTotals[dk].count += 1;
    });

    const days: { dateKey: string; label: string; revenue: number; count: number; isToday: boolean }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000);
      const dk = toDateKey(d);
      days.push({
        dateKey: dk,
        label: d.toLocaleDateString('en-US', { weekday: 'short' }),
        revenue: dayTotals[dk]?.rev || 0,
        count: dayTotals[dk]?.count || 0,
        isToday: dk === todayKey,
      });
    }
    const maxRev = Math.max(1, ...days.map((d) => d.revenue));
    const weekTotal = days.reduce((s, d) => s + d.revenue, 0);
    return { days, maxRev, weekTotal };
  }, [data.sales, todayKey]);

  const recentSales = useMemo(() => [...data.sales].slice(0, 7), [data.sales]);

  return (
    <div className="space-y-6">
      {/* 1. HERO SALES OVERVIEW */}
      <section className="surface-card p-6 sm:p-7 flex flex-col gap-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-xs font-semibold text-slate-500">
              {data.settings.storeName || t.appName} · {t.todaysSales}
            </p>
            <p className="text-4xl sm:text-5xl font-extrabold text-slate-950 tracking-tight tabular-nums mt-2">
              {fmtMoney(metrics.todayRevenue)}
            </p>
          </div>

          <div className="w-full sm:w-auto">
            <button
              type="button"
              onClick={() => onNavigate('pos')}
              className="btn-primary w-full sm:w-auto min-w-[240px] px-8 py-4 text-base sm:text-lg shadow-[inset_0_1px_0_rgba(255,255,255,0.28),0_6px_20px_-4px_rgba(37,99,235,0.48)]"
            >
              <Icon name="pos" className="w-5 h-5 shrink-0" />
              <span>{t.newSale}</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 pt-5 border-t border-slate-100 tabular-nums">
          <div>
            <p className="text-xs font-medium text-slate-500">{t.todaysProfit}</p>
            <p className="text-lg sm:text-xl font-extrabold text-emerald-600 mt-1">+{fmtMoney(metrics.todayProfit)}</p>
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500">{t.totalOrders}</p>
            <p className="text-lg sm:text-xl font-extrabold text-slate-900 mt-1">{fmtInt(todaysSalesList.length)}</p>
          </div>
          <div>
            <p className="text-xs font-medium text-slate-500">{t.totalItemsSold}</p>
            <p className="text-lg sm:text-xl font-extrabold text-blue-600 mt-1">{fmtInt(metrics.todayItems)}</p>
          </div>
        </div>
      </section>

      {/* 2. KEY SALES METRICS GRID */}
      <section className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <div className="surface-card p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between gap-3">
            <p className="text-xs font-semibold text-slate-500">{t.totalRevenue}</p>
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <Icon name="sales" className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <p className="text-2xl sm:text-3xl font-extrabold text-slate-950 tracking-tight tabular-nums">
              {fmtMoney(metrics.totalRevenue)}
            </p>
            <p className="text-xs text-slate-500 mt-1.5 tabular-nums">
              {t.today}: <span className="font-bold text-blue-600">{fmtMoney(metrics.todayRevenue)}</span>
            </p>
          </div>
        </div>

        <div className="surface-card p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between gap-3">
            <p className="text-xs font-semibold text-slate-500">{t.grossProfit}</p>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
              <Icon name="analytics" className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <p className="text-2xl sm:text-3xl font-extrabold text-emerald-600 tracking-tight tabular-nums">
              {fmtMoney(metrics.totalProfit)}
            </p>
            <p className="text-xs text-slate-500 mt-1.5 tabular-nums">
              Margin <span className="font-bold text-slate-700">{metrics.profitMargin.toFixed(1)}%</span> · {t.today}:{' '}
              <span className="font-bold text-emerald-600">+{fmtMoney(metrics.todayProfit)}</span>
            </p>
          </div>
        </div>

        <div className="surface-card p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between gap-3">
            <p className="text-xs font-semibold text-slate-500">{t.totalSales}</p>
            <div className="w-9 h-9 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
              <Icon name="pos" className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <p className="text-2xl sm:text-3xl font-extrabold text-slate-950 tracking-tight tabular-nums">
              {fmtInt(data.sales.length)}
            </p>
            <p className="text-xs text-slate-500 mt-1.5 tabular-nums">
              Avg order <span className="font-bold text-slate-700">{fmtMoney(metrics.avgOrderOverall)}</span>
            </p>
          </div>
        </div>

        <div className="surface-card p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between gap-3">
            <p className="text-xs font-semibold text-slate-500">{t.pendingDue}</p>
            <div
              className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                metrics.totalDueReceivable > 0 ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-600'
              }`}
            >
              <Icon name="customers" className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <p
              className={`text-2xl sm:text-3xl font-extrabold tracking-tight tabular-nums ${
                metrics.totalDueReceivable > 0 ? 'text-rose-600' : 'text-emerald-600'
              }`}
            >
              {fmtMoney(metrics.totalDueReceivable)}
            </p>
            <p className="text-xs text-slate-500 mt-1.5 tabular-nums">
              {metrics.dueCustomerCount > 0 ? (
                <>
                  <span className="font-bold text-rose-600">{fmtInt(metrics.dueCustomerCount)}</span> {t.customersWithDue}
                </>
              ) : (
                <span className="text-emerald-600 font-semibold">{t.allClear}</span>
              )}
            </p>
          </div>
        </div>
      </section>

      {/* 3. 7-DAY SALES TREND & RECENT SALES FEED */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        <section className="lg:col-span-5 surface-card p-5 sm:p-6 flex flex-col justify-between">
          <div className="flex items-start justify-between gap-3 mb-4 pb-3 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-slate-900">{t.last7Days} Sales</h3>
              <p className="text-xs text-slate-500 mt-0.5">Daily revenue breakdown</p>
            </div>
            <div className="text-right tabular-nums">
              <p className="text-xs font-medium text-slate-500">{t.total}</p>
              <p className="text-base font-extrabold text-blue-600">{fmtMoney(last7DaysSales.weekTotal)}</p>
            </div>
          </div>

          <div className="h-52 flex items-end gap-2.5 pt-6 px-1 border-b border-slate-200">
            {last7DaysSales.days.map((d) => (
              <div key={d.dateKey} className="flex-1 flex flex-col items-center gap-1.5 min-w-0">
                <span className="text-[10px] font-semibold text-slate-500 tabular-nums truncate max-w-full">
                  {d.revenue > 0 ? fmtInt(Math.round(d.revenue)) : '0'}
                </span>
                <div className="w-full flex justify-center items-end h-36">
                  <div
                    title={`${d.label}: ${fmtMoney(d.revenue)} (${d.count} sales)`}
                    style={{ height: `${d.revenue > 0 ? Math.max(8, (d.revenue / last7DaysSales.maxRev) * 100) : 4}%` }}
                    className={`w-full max-w-[36px] rounded-t-lg transition-all ${
                      d.isToday ? 'bg-blue-600' : d.revenue > 0 ? 'bg-slate-300 hover:bg-blue-400' : 'bg-slate-100'
                    }`}
                  />
                </div>
                <span className={`text-[11px] whitespace-nowrap ${d.isToday ? 'font-bold text-blue-600' : 'font-medium text-slate-500'}`}>
                  {d.label}
                </span>
              </div>
            ))}
          </div>
        </section>

        <section className="lg:col-span-7 surface-card p-5 sm:p-6">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
            <div>
              <h3 className="font-bold text-slate-900">{t.recentTransactions}</h3>
              <p className="text-xs text-slate-500 mt-0.5">Latest completed sales invoices</p>
            </div>
            <span className="text-xs font-semibold text-slate-400 tabular-nums">
              {recentSales.length} {recentSales.length === 1 ? 'invoice' : 'invoices'}
            </span>
          </div>

          {recentSales.length === 0 ? (
            <div className="py-12 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                <Icon name="sales" className="w-6 h-6" />
              </div>
              <p className="text-sm text-slate-500">{t.noTransactionsYet}</p>
              <button type="button" onClick={() => onNavigate('pos')} className="btn-primary px-5 py-2.5 text-xs">
                <Icon name="pos" className="w-4 h-4" />
                <span>{t.newSale}</span>
              </button>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {recentSales.map((s) => (
                <div key={s.id} className="py-3 flex items-center justify-between text-sm gap-3">
                  <div className="min-w-0">
                    <p className="font-semibold text-slate-900 truncate">
                      <span className="font-mono text-blue-600">{s.invoiceNo}</span> ·{' '}
                      <span className="font-medium text-slate-800">{s.customerName}</span>
                    </p>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {fmtDateTime(s.date)} · {t[s.paymentMethod] || s.paymentMethod} · {s.items.reduce((a, b) => a + b.qty, 0)} {t.items.toLowerCase()}
                    </p>
                  </div>
                  <div className="flex items-center gap-3 shrink-0 tabular-nums">
                    <div className="text-right">
                      <p className="font-bold text-slate-900">{fmtMoney(s.grandTotal)}</p>
                      <p className="text-xs font-semibold text-emerald-600">+{fmtMoney(s.profit)}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => onViewReceipt(s)}
                      className="btn-secondary px-2.5 py-1.5 text-xs"
                      title={t.viewReceipt}
                    >
                      <Icon name="print" className="w-3.5 h-3.5 text-slate-600" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
