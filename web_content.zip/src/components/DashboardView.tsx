import React from 'react';
import { 
  Users, 
  Receipt, 
  CreditCard, 
  AlertCircle, 
  TrendingUp, 
  Wallet, 
  QrCode, 
  PlusCircle, 
  CheckCircle2, 
  ArrowUpRight, 
  Tv, 
  Wifi, 
  Sparkles,
  Printer,
  Share2,
  MessageSquare,
  Send
} from 'lucide-react';
import { Customer, Bill, Payment, Language, BusinessProfile } from '../types';
import { translations } from '../translations';
import { receiptService } from '../services/receiptService';
import { WhatsAppDispatchPayload } from './WhatsAppDispatchModal';

interface DashboardViewProps {
  customers: Customer[];
  bills: Bill[];
  payments: Payment[];
  activeMonth: string;
  language: Language;
  profile: BusinessProfile;
  onNavigateTab: (tab: string) => void;
  onQuickCollect: (customer?: Customer, bill?: Bill) => void;
  onGenerateBills: () => void;
  onViewReceipt: (payment: Payment) => void;
  onAddCustomer: () => void;
  onOpenWhatsAppModal: (payload: WhatsAppDispatchPayload) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  customers,
  bills,
  payments,
  activeMonth,
  language,
  profile,
  onNavigateTab,
  onQuickCollect,
  onGenerateBills,
  onViewReceipt,
  onAddCustomer,
  onOpenWhatsAppModal,
}) => {
  const t = translations[language];

  // Filtering for active billing month
  const monthBills = bills.filter(b => b.billingMonth === activeMonth);
  const monthPayments = payments.filter(p => p.billingMonth === activeMonth);

  // Statistics
  const totalCustomers = customers.length;
  const activeCustomers = customers.filter(c => c.status === 'ACTIVE').length;
  const inactiveCustomers = totalCustomers - activeCustomers;

  const cableCount = customers.filter(c => c.serviceType === 'CABLE' && c.status === 'ACTIVE').length;
  const broadbandCount = customers.filter(c => c.serviceType === 'BROADBAND' && c.status === 'ACTIVE').length;
  const comboCount = customers.filter(c => c.serviceType === 'COMBO' && c.status === 'ACTIVE').length;

  const totalMonthlyBilling = monthBills.reduce((acc, b) => acc + (b.totalAmount || 0), 0);
  const totalCollected = monthPayments.reduce((acc, p) => acc + (p.amount || 0), 0);
  
  const cashCollected = monthPayments
    .filter(p => p.paymentMethod === 'CASH')
    .reduce((acc, p) => acc + (p.amount || 0), 0);
    
  const upiCollected = monthPayments
    .filter(p => p.paymentMethod === 'UPI')
    .reduce((acc, p) => acc + (p.amount || 0), 0);

  const totalOutstanding = customers.reduce((acc, c) => acc + (c.totalOutstanding || 0), 0);
  const collectionPercentage = totalMonthlyBilling > 0 ? Math.min(100, Math.round((totalCollected / totalMonthlyBilling) * 100)) : 0;

  // Area distribution calculations
  const areaStats: Record<string, { totalDues: number; customerCount: number }> = {};
  customers.forEach(c => {
    const area = c.area || 'Other';
    if (!areaStats[area]) {
      areaStats[area] = { totalDues: 0, customerCount: 0 };
    }
    areaStats[area].customerCount += 1;
    areaStats[area].totalDues += Number(c.totalOutstanding || 0);
  });

  const sortedAreas = Object.entries(areaStats).sort((a, b) => b[1].totalDues - a[1].totalDues);

  // Recent 5 payments
  const recentPayments = payments.slice(0, 5);

  return (
    <div className="space-y-6">
      
      {/* Top Banner with Quick Actions */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-slate-800 to-cyan-950 p-5 sm:p-7 border border-slate-700/80 shadow-2xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-1 rounded-md text-xs font-bold uppercase tracking-wider bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                {profile.village}, Odisha
              </span>
              <span className="text-xs text-slate-400 font-mono">
                Cycle: {activeMonth}
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              {profile.name}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl mt-1">
              {profile.tagline}
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => onQuickCollect()}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-950/40 transition active:scale-95"
            >
              <CreditCard className="w-4 h-4" />
              <span>{t.quickCollect}</span>
            </button>

            <button
              onClick={onGenerateBills}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-600 font-semibold text-xs sm:text-sm shadow-md transition active:scale-95"
            >
              <Receipt className="w-4 h-4" />
              <span>{t.generateBills}</span>
            </button>

            <button
              onClick={onAddCustomer}
              className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 text-slate-200 border border-slate-700 font-semibold text-xs sm:text-sm shadow-sm transition"
            >
              <PlusCircle className="w-4 h-4 text-emerald-400" />
              <span>{t.addCustomer}</span>
            </button>
          </div>
        </div>

        {/* Ambient background glow */}
        <div className="absolute -right-16 -top-16 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Total Customers */}
        <div 
          onClick={() => onNavigateTab('customers')}
          className="cursor-pointer group p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-cyan-500/50 shadow-lg hover:shadow-cyan-950/20 transition-all"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              {t.totalCustomers}
            </span>
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center group-hover:scale-110 transition">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white font-mono-num">
              {totalCustomers}
            </span>
            <span className="text-xs font-semibold text-emerald-400">
              {activeCustomers} {t.active}
            </span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
            <span className="flex items-center gap-1">
              <Tv className="w-3 h-3 text-cyan-400" /> {cableCount}
            </span>
            <span className="flex items-center gap-1">
              <Wifi className="w-3 h-3 text-indigo-400" /> {broadbandCount}
            </span>
            <span className="flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-400" /> {comboCount} Combo
            </span>
          </div>
        </div>

        {/* Total Monthly Billing */}
        <div 
          onClick={() => onNavigateTab('billing')}
          className="cursor-pointer group p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-cyan-500/50 shadow-lg transition-all"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              {t.totalMonthlyBilling}
            </span>
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center group-hover:scale-110 transition">
              <Receipt className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-cyan-300 font-mono-num">
              {receiptService.formatCurrency(totalMonthlyBilling)}
            </span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
            <span>{monthBills.length} Bills in {activeMonth}</span>
            <span className="text-cyan-400 flex items-center gap-0.5">
              View <ArrowUpRight className="w-3 h-3" />
            </span>
          </div>
        </div>

        {/* Total Collection */}
        <div 
          onClick={() => onNavigateTab('payments')}
          className="cursor-pointer group p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 shadow-lg transition-all"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              {t.totalCollection}
            </span>
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center group-hover:scale-110 transition">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-emerald-400 font-mono-num">
              {receiptService.formatCurrency(totalCollected)}
            </span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-300">
            <span className="flex items-center gap-1 text-slate-400">
              <Wallet className="w-3 h-3 text-emerald-400" /> {receiptService.formatCurrency(cashCollected)}
            </span>
            <span className="flex items-center gap-1 text-slate-400">
              <QrCode className="w-3 h-3 text-cyan-400" /> {receiptService.formatCurrency(upiCollected)}
            </span>
          </div>
        </div>

        {/* Total Outstanding Dues */}
        <div 
          onClick={() => onNavigateTab('billing')}
          className="cursor-pointer group p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-rose-500/50 shadow-lg transition-all"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              {t.totalOutstanding}
            </span>
            <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-400 flex items-center justify-center group-hover:scale-110 transition">
              <AlertCircle className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-rose-400 font-mono-num">
              {receiptService.formatCurrency(totalOutstanding)}
            </span>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
            <span>Overall pending recovery</span>
            <span className="text-rose-400 font-semibold">{customers.filter(c => c.totalOutstanding > 0).length} Overdue</span>
          </div>
        </div>

      </div>

      {/* Collection Progress Bar */}
      <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-md">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            {t.collectionRate} ({activeMonth})
          </span>
          <span className="text-xs font-bold text-emerald-400 font-mono-num">
            {collectionPercentage}% Collected ({receiptService.formatCurrency(totalCollected)} / {receiptService.formatCurrency(totalMonthlyBilling)})
          </span>
        </div>
        <div className="w-full h-3 rounded-full bg-slate-800 overflow-hidden p-0.5">
          <div 
            className="h-full rounded-full bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 transition-all duration-700"
            style={{ width: `${collectionPercentage}%` }}
          />
        </div>
        <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              Cash: {receiptService.formatCurrency(cashCollected)}
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
              UPI: {receiptService.formatCurrency(upiCollected)}
            </span>
          </div>
          <span>Remaining: {receiptService.formatCurrency(Math.max(0, totalMonthlyBilling - totalCollected))}</span>
        </div>
      </div>

      {/* Two Column Grid: Area-Wise Breakdown + Recent Collections Ledger */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left: Area Breakdown in Champeswar (1 col) */}
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <span>{t.areaBreakdown}</span>
            </h3>
            <span className="text-xs text-slate-400">{sortedAreas.length} Areas</span>
          </div>

          <div className="space-y-3">
            {sortedAreas.map(([areaName, data]) => (
              <div 
                key={areaName}
                className="p-3 rounded-xl bg-slate-850 border border-slate-800/80 hover:border-slate-700 flex items-center justify-between"
              >
                <div>
                  <div className="font-semibold text-xs sm:text-sm text-slate-200">
                    {areaName}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    {data.customerCount} Subscribers
                  </div>
                </div>
                <div className="text-right">
                  <div className={`font-bold font-mono-num text-xs sm:text-sm ${data.totalDues > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                    {receiptService.formatCurrency(data.totalDues)}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    {data.totalDues > 0 ? 'Dues Pending' : 'Clear'}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Recent Collections & Instant Receipt (2 cols) */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              {t.recentCollections}
            </h3>
            <button
              onClick={() => onNavigateTab('payments')}
              className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
            >
              All Payments <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {recentPayments.length === 0 ? (
            <div className="py-12 text-center text-slate-500 text-sm">
              No payments recorded yet for this cycle.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400">
                    <th className="pb-3 font-semibold">Receipt / Date</th>
                    <th className="pb-3 font-semibold">Customer</th>
                    <th className="pb-3 font-semibold">Method</th>
                    <th className="pb-3 font-semibold text-right">Amount</th>
                    <th className="pb-3 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {recentPayments.map((p) => {
                    const cust = customers.find(c => c.id === p.customerId);
                    return (
                      <tr key={p.id} className="hover:bg-slate-850/50">
                        <td className="py-3 font-medium text-slate-300">
                          <span className="font-mono text-cyan-300 block">{p.receiptNo}</span>
                          <span className="text-[11px] text-slate-400">{receiptService.formatDate(p.paymentDate)}</span>
                        </td>
                        <td className="py-3">
                          <span className="font-bold text-slate-100 block">{p.customerName}</span>
                          <span className="text-[11px] text-slate-400 font-mono">{p.customerCode} • {cust?.area}</span>
                        </td>
                        <td className="py-3">
                          <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold ${
                            p.paymentMethod === 'UPI' 
                              ? 'bg-cyan-950 text-cyan-400 border border-cyan-800' 
                              : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          }`}>
                            {p.paymentMethod}
                          </span>
                        </td>
                        <td className="py-3 text-right font-extrabold text-sm text-emerald-400 font-mono-num">
                          {receiptService.formatCurrency(p.amount)}
                        </td>
                        <td className="py-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => onViewReceipt(p)}
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
                              title={t.printReceipt}
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>
                            {cust && (
                              <button
                                onClick={() => onOpenWhatsAppModal({
                                  mode: 'RECEIPT',
                                  customer: cust,
                                  payment: p,
                                })}
                                className="p-1.5 rounded-lg bg-emerald-950 hover:bg-emerald-900 text-emerald-400 border border-emerald-800 transition"
                                title="Send WhatsApp Receipt"
                              >
                                <Share2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

        </div>

      </div>

      {/* WhatsApp Outstanding Dues Fast Dispatch Hub */}
      {customers.filter(c => c.totalOutstanding > 0).length > 0 && (
        <div className="p-5 rounded-2xl bg-slate-900/90 border border-emerald-900/60 shadow-xl space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-[#25D366]" />
                <span>Direct WhatsApp Dues Reminders Hub</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                  {customers.filter(c => c.totalOutstanding > 0).length} Overdue Subscribers
                </span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Dispatch personalized billing reminders &amp; UPI QR payment links directly to customers on WhatsApp.
              </p>
            </div>

            <button
              onClick={() => onNavigateTab('customers')}
              className="text-xs font-semibold text-cyan-400 hover:underline self-start sm:self-auto"
            >
              View Full Subscriber Ledger →
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 pt-1">
            {customers
              .filter(c => c.totalOutstanding > 0)
              .sort((a, b) => b.totalOutstanding - a.totalOutstanding)
              .slice(0, 6)
              .map(cust => (
                <div
                  key={cust.id}
                  className="p-3 rounded-xl bg-slate-850/80 border border-slate-750 hover:border-emerald-600/50 transition flex items-center justify-between"
                >
                  <div className="min-w-0 pr-2">
                    <span className="font-bold text-xs sm:text-sm text-slate-200 block truncate">
                      {cust.name}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono block">
                      {cust.customerCode} • {cust.mobile}
                    </span>
                    <span className="text-[11px] text-rose-400 font-bold font-mono-num block mt-0.5">
                      Due: {receiptService.formatCurrency(cust.totalOutstanding)}
                    </span>
                  </div>

                  <button
                    onClick={() => onOpenWhatsAppModal({
                      mode: 'DUES',
                      customer: cust,
                    })}
                    className="shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-slate-950 font-black text-xs shadow-md transition active:scale-95"
                    title={`Send WhatsApp notice to ${cust.name}`}
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">WhatsApp</span>
                  </button>
                </div>
              ))}
          </div>
        </div>
      )}

    </div>
  );
};
