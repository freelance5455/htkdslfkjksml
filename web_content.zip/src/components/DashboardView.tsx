import React from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Crown,
  Download,
  FileArchive,
  FileCode2,
  FolderCode,
  Hammer,
  Plus,
  Settings,
  Sparkles,
  Upload,
  XCircle,
} from 'lucide-react';
import { formatBytes, formatDateTr } from '../lib/api';
import type {
  BuildJob,
  MembershipInfo,
  NavSection,
  ProjectSummary,
  SystemCapabilities,
} from '../types/studio';

interface DashboardViewProps {
  projects: ProjectSummary[];
  builds: BuildJob[];
  membership: MembershipInfo;
  capabilities: SystemCapabilities | null;
  selectedProjectId: string | null;
  onSelectProject: (id: string) => void;
  onNavigate: (section: NavSection) => void;
  onOpenUploadModal: (mode: 'html' | 'zip' | 'create') => void;
  onInstantHtmlToApk: (files: FileList) => Promise<void>;
  onSeedSampleApp: () => Promise<void>;
  onStartQuickBuild: (projectId: string) => void;
  onDownloadBuild: (buildId: string) => void;
  onInspectBuild: (buildId: string) => void;
}

function getBuildStatusInfo(status: BuildJob['status']) {
  switch (status) {
    case 'completed_apk':
      return { label: 'İmzalı APK Hazır', color: 'text-[#22C55E]', Icon: CheckCircle2 };
    case 'completed_bundle':
      return { label: 'Gradle Paketi Hazır', color: 'text-[#3B82F6]', Icon: CheckCircle2 };
    case 'running':
    case 'queued':
      return { label: 'Derleniyor', color: 'text-amber-500', Icon: Clock };
    case 'cancelled':
      return { label: 'İptal Edildi', color: 'text-slate-500 dark:text-[#94A3B8]', Icon: XCircle };
    case 'failed':
    default:
      return { label: 'Başarısız', color: 'text-[#EF4444]', Icon: AlertTriangle };
  }
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  projects,
  builds,
  membership,
  capabilities,
  selectedProjectId,
  onSelectProject,
  onNavigate,
  onOpenUploadModal,
  onInstantHtmlToApk,
  onSeedSampleApp,
  onStartQuickBuild,
  onDownloadBuild,
  onInspectBuild,
}) => {
  const [instantUploading, setInstantUploading] = React.useState(false);
  const [seedingSample, setSeedingSample] = React.useState(false);
  const completedBuildsCount = builds.filter(
    (b) => b.status === 'completed_apk' || b.status === 'completed_bundle'
  ).length;
  const lastBuild = builds[0] || null;
  const lastBuildInfo = lastBuild ? getBuildStatusInfo(lastBuild.status) : null;
  const activeProjectId = selectedProjectId || projects[0]?.id || null;

  const handleQuickFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setInstantUploading(true);
    try {
      await onInstantHtmlToApk(files);
    } finally {
      setInstantUploading(false);
      e.target.value = '';
    }
  };

  return (
    <div className="space-y-8">
      {/* Header Row */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold tracking-tight text-slate-900 dark:text-[#F8FAFC]">
            Ana Panel
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-[#94A3B8]">
            HTML, CSS ve JavaScript projelerinizi yükleyin, tek tıkla gerçek Android APK
            dosyasına dönüştürün.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          {!membership.isPremium && (
            <button
              type="button"
              onClick={() => onNavigate('premium')}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-xl bg-[#EAB308]/15 text-[#B45309] dark:text-[#EAB308] border border-[#EAB308]/35 hover:bg-[#EAB308]/25 transition-colors whitespace-nowrap shrink-0"
            >
              <Crown className="w-3.5 h-3.5" />
              <span>Premium’a Geç</span>
            </button>
          )}
          <button
            type="button"
            disabled={seedingSample}
            onClick={async () => {
              setSeedingSample(true);
              try {
                await onSeedSampleApp();
              } finally {
                setSeedingSample(false);
              }
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium rounded-xl bg-white dark:bg-[#151D2E] hover:bg-slate-50 dark:hover:bg-white/[0.06] border border-slate-200 dark:border-white/[0.1] text-slate-800 dark:text-[#F8FAFC] transition-colors whitespace-nowrap shrink-0 disabled:opacity-50"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#3B82F6]" />
            <span>{seedingSample ? 'Ekleniyor...' : 'Örnek Uygulama Ekle'}</span>
          </button>
          <button
            type="button"
            onClick={() => onOpenUploadModal('zip')}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-xl bg-[#6366F1] hover:bg-[#5558E3] text-white transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Proje Yükle</span>
          </button>
        </div>
      </div>

      {/* Direct HTML / ZIP -> APK Drop Bar */}
      <label className="block cursor-pointer bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] hover:border-[#6366F1] dark:hover:border-[#6366F1] rounded-2xl p-6 transition-colors">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="w-11 h-11 rounded-xl bg-[#6366F1]/12 border border-[#6366F1]/25 flex items-center justify-center shrink-0">
              <Upload className="w-5 h-5 text-[#6366F1]" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-slate-900 dark:text-[#F8FAFC]">
                {instantUploading
                  ? 'Proje yükleniyor, ikon ve APK ayarları hazırlanıyor...'
                  : 'Hızlı HTML veya ZIP Yükle ve APK Oluştur'}
              </h2>
              <p className="mt-1 text-xs text-slate-600 dark:text-[#94A3B8] leading-relaxed">
                Doğrudan bir <code className="text-slate-900 dark:text-[#F8FAFC]">.html</code> veya{' '}
                <code className="text-slate-900 dark:text-[#F8FAFC]">.zip</code> dosyası seçin;
                uygulama adını, ikonunu ve WebView ayarlarını doğrulayıp derlemeyi başlatın.
              </p>
            </div>
          </div>
          <span className="inline-flex items-center justify-center px-5 py-2.5 rounded-xl bg-[#6366F1] text-white text-xs font-semibold whitespace-nowrap shrink-0">
            {instantUploading ? 'Yükleniyor...' : 'Dosya Seç (.html / .zip)'}
          </span>
        </div>
        <input
          type="file"
          accept=".html,.htm,.zip"
          disabled={instantUploading}
          onChange={handleQuickFileSelect}
          className="hidden"
        />
      </label>

      {/* 4 KPI Strip (Tabular Numerals) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-[#94A3B8]">Toplam Proje</p>
          <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-[#F8FAFC] tabular-nums">
            {projects.length}{' '}
            <span className="text-xs font-normal text-slate-400 dark:text-[#94A3B8]">
              / {membership.limits.maxProjects}
            </span>
          </p>
        </div>

        <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-[#94A3B8]">
            Oluşturulan APK / Paket
          </p>
          <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-[#F8FAFC] tabular-nums">
            {completedBuildsCount}
          </p>
        </div>

        <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-[#94A3B8]">
            Son Derleme Durumu
          </p>
          <div className="mt-2 flex items-center gap-2">
            {lastBuildInfo ? (
              <>
                <lastBuildInfo.Icon className={`w-5 h-5 shrink-0 ${lastBuildInfo.color}`} />
                <span className={`text-sm font-semibold truncate ${lastBuildInfo.color}`}>
                  {lastBuildInfo.label}
                </span>
              </>
            ) : (
              <span className="text-sm font-medium text-slate-400 dark:text-[#94A3B8]">
                Henüz derleme yok
              </span>
            )}
          </div>
        </div>

        <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-xl p-5">
          <p className="text-xs font-medium text-slate-500 dark:text-[#94A3B8]">
            Aylık Derleme Hakkı
          </p>
          <p className="mt-2 text-2xl font-bold text-slate-900 dark:text-[#F8FAFC] tabular-nums">
            {membership.usage.remainingMonthlyBuilds}{' '}
            <span className="text-xs font-normal text-slate-400 dark:text-[#94A3B8]">
              kalan ({membership.usage.monthlyBuildsUsed}/{membership.limits.monthlyBuilds})
            </span>
          </p>
        </div>
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC] mb-3">
          Hızlı İşlemler
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <button
            type="button"
            onClick={() => onOpenUploadModal('html')}
            className="text-left bg-white dark:bg-[#151D2E] hover:border-[#6366F1] border border-slate-200 dark:border-white/[0.08] rounded-xl p-5 transition-colors"
          >
            <FileCode2 className="w-5 h-5 text-[#6366F1] mb-3" />
            <h3 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
              HTML / Web Dosyaları Yükle
            </h3>
            <p className="mt-1 text-xs text-slate-600 dark:text-[#94A3B8] leading-relaxed">
              HTML, CSS, JS, JSON ve görselleri çoklu seçim ile projenize aktarın.
            </p>
          </button>

          <button
            type="button"
            onClick={() => onOpenUploadModal('zip')}
            className="text-left bg-white dark:bg-[#151D2E] hover:border-[#3B82F6] border border-slate-200 dark:border-white/[0.08] rounded-xl p-5 transition-colors"
          >
            <FileArchive className="w-5 h-5 text-[#3B82F6] mb-3" />
            <h3 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
              ZIP Arşivi Yükle
            </h3>
            <p className="mt-1 text-xs text-slate-600 dark:text-[#94A3B8] leading-relaxed">
              Klasör hiyerarşisini koruyarak ve ZIP Slip korumasıyla arşivi içe aktarın.
            </p>
          </button>

          <button
            type="button"
            onClick={() => onOpenUploadModal('create')}
            className="text-left bg-white dark:bg-[#151D2E] hover:border-[#22C55E] border border-slate-200 dark:border-white/[0.08] rounded-xl p-5 transition-colors"
          >
            <Plus className="w-5 h-5 text-[#22C55E] mb-3" />
            <h3 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
              Yeni Proje Oluştur
            </h3>
            <p className="mt-1 text-xs text-slate-600 dark:text-[#94A3B8] leading-relaxed">
              Temiz HTML5/CSS3/JS başlangıç şablonuyla sıfırdan mobil proje oluşturun.
            </p>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('projects')}
            className="text-left bg-white dark:bg-[#151D2E] hover:border-[#6366F1] border border-slate-200 dark:border-white/[0.08] rounded-xl p-5 transition-colors"
          >
            <FolderCode className="w-5 h-5 text-slate-500 dark:text-[#94A3B8] mb-3" />
            <h3 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
              Projelerim
            </h3>
            <p className="mt-1 text-xs text-slate-600 dark:text-[#94A3B8] leading-relaxed">
              Kayıtlı dosyaları düzenleyin, giriş HTML’i seçin veya canlı önizleyin.
            </p>
          </button>

          <button
            type="button"
            onClick={() => {
              if (activeProjectId) {
                onSelectProject(activeProjectId);
                onStartQuickBuild(activeProjectId);
              } else {
                onOpenUploadModal('create');
              }
            }}
            className="text-left bg-white dark:bg-[#151D2E] hover:border-[#6366F1] border border-slate-200 dark:border-white/[0.08] rounded-xl p-5 transition-colors"
          >
            <Hammer className="w-5 h-5 text-[#6366F1] mb-3" />
            <h3 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
              APK Oluştur
            </h3>
            <p className="mt-1 text-xs text-slate-600 dark:text-[#94A3B8] leading-relaxed">
              Seçili projeyi Kotlin WebView + Android SDK hattında imzalı APK’ya dönüştürün.
            </p>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('settings')}
            className="text-left bg-white dark:bg-[#151D2E] hover:border-[#3B82F6] border border-slate-200 dark:border-white/[0.08] rounded-xl p-5 transition-colors"
          >
            <Settings className="w-5 h-5 text-[#3B82F6] mb-3" />
            <h3 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
              APK Yapılandırma
            </h3>
            <p className="mt-1 text-xs text-slate-600 dark:text-[#94A3B8] leading-relaxed">
              Adaptive Icon, Splash Screen, offline önbellek ve durum çubuğunu ayarlayın.
            </p>
          </button>
        </div>
      </div>

      {/* Real Compiler Capability Strip */}
      {capabilities && (
        <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-xl px-5 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <Settings className="w-4 h-4 text-[#6366F1] shrink-0 mt-0.5" />
            <div className="text-xs text-slate-600 dark:text-[#94A3B8] leading-relaxed">
              <span className="font-semibold text-slate-900 dark:text-[#F8FAFC]">
                Derleme Ortamı:{' '}
              </span>
              {capabilities.summary}
            </div>
          </div>
          <span className="text-xs font-mono text-slate-500 dark:text-[#94A3B8] whitespace-nowrap shrink-0">
            Mod: {capabilities.activeCompilerMode}
          </span>
        </div>
      )}

      {/* Recent Builds Table */}
      <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 dark:border-white/[0.08] flex items-center justify-between gap-4">
          <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
            Son APK Dönüştürmeleri
          </h2>
          <button
            type="button"
            onClick={() => onNavigate('build')}
            className="text-xs font-medium text-[#3B82F6] hover:underline whitespace-nowrap"
          >
            Derleme Hattına Git
          </button>
        </div>

        {builds.length === 0 ? (
          <div className="px-5 py-10 text-center">
            <p className="text-sm text-slate-600 dark:text-[#94A3B8]">
              Henüz bir APK dönüştürme işlemi başlatılmadı.
            </p>
            <button
              type="button"
              onClick={() => {
                if (activeProjectId) {
                  onSelectProject(activeProjectId);
                  onStartQuickBuild(activeProjectId);
                } else {
                  onOpenUploadModal('create');
                }
              }}
              className="mt-4 px-4 py-2 text-xs font-semibold rounded-lg bg-[#6366F1] hover:bg-[#5558E3] text-white transition-colors"
            >
              İlk Derlemeyi Başlat
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-white/[0.06] text-[11px] font-medium text-slate-500 dark:text-[#94A3B8]">
                  <th className="py-3 px-5">Uygulama / Paket</th>
                  <th className="py-3 px-4">Durum</th>
                  <th className="py-3 px-4">Aşama</th>
                  <th className="py-3 px-4 text-right">Boyut</th>
                  <th className="py-3 px-4 text-right">Tarih</th>
                  <th className="py-3 px-5 text-right">İşlem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-white/[0.06] text-xs">
                {builds.slice(0, 8).map((build) => {
                  const info = getBuildStatusInfo(build.status);
                  const canDownload =
                    build.status === 'completed_apk' || build.status === 'completed_bundle';
                  return (
                    <tr
                      key={build.id}
                      className="hover:bg-slate-50 dark:hover:bg-white/[0.02] transition-colors"
                    >
                      <td className="py-3 px-5">
                        <div className="font-medium text-slate-900 dark:text-[#F8FAFC]">
                          {build.app_name || build.project_name}
                        </div>
                        <div className="text-[11px] font-mono text-slate-500 dark:text-[#94A3B8]">
                          {build.package_name}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center gap-1.5 font-medium ${info.color}`}>
                          <info.Icon className="w-3.5 h-3.5 shrink-0" />
                          <span>{info.label}</span>
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-600 dark:text-[#94A3B8] max-w-[220px] truncate">
                        {build.stage}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-600 dark:text-[#94A3B8]">
                        {build.artifact_size_bytes ? formatBytes(build.artifact_size_bytes) : '—'}
                      </td>
                      <td className="py-3 px-4 text-right tabular-nums text-slate-500 dark:text-[#94A3B8] whitespace-nowrap">
                        {formatDateTr(build.created_at)}
                      </td>
                      <td className="py-3 px-5 text-right">
                        <div className="inline-flex items-center gap-3">
                          <button
                            type="button"
                            onClick={() => onInspectBuild(build.id)}
                            className="text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap"
                          >
                            Günlük
                          </button>
                          {canDownload && (
                            <button
                              type="button"
                              onClick={() => onDownloadBuild(build.id)}
                              className="inline-flex items-center gap-1 text-[#3B82F6] hover:underline font-medium whitespace-nowrap"
                            >
                              <Download className="w-3.5 h-3.5" />
                              <span>İndir</span>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
