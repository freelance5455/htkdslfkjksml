import React from "react";
import { 
  Droplets, 
  TrendingUp, 
  Wallet, 
  ShieldCheck, 
  AlertCircle, 
  Users, 
  FileText, 
  FileDown, 
  Plus, 
  CalendarDays, 
  CloudCheck, 
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
  Clock,
  Sprout,
  Activity,
  Receipt
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Record, Customer, ExpenseUsage, Language } from "../types";
import { TRANSLATIONS } from "../translations";
import { format } from "date-fns";

interface DashboardViewProps {
  language: Language;
  records: Record[];
  customers: Customer[];
  expenses: ExpenseUsage[];
  isDbConnected: boolean;
  onNavigate: (view: "billing" | "yearly" | "expenses") => void;
  onOpenPdfModal: () => void;
  onQuickAddRecord: () => void;
}

export default function DashboardView({
  language,
  records,
  customers,
  expenses,
  isDbConnected,
  onNavigate,
  onOpenPdfModal,
  onQuickAddRecord
}: DashboardViewProps) {
  const t = TRANSLATIONS[language];

  // Global calculations
  const grandTotalBilled = records.reduce((sum, r) => {
    const recordSum = (r.entries || []).reduce((acc, entry) => acc + (entry.hours * r.rate), 0);
    return sum + recordSum + (r.previousBalance || 0);
  }, 0);

  const totalReceived = records.reduce((sum, r) => sum + (r.paymentReceived || 0), 0);
  
  const totalOutstanding = records.reduce((sum, r) => {
    const recordSum = (r.entries || []).reduce((acc, entry) => acc + (entry.hours * r.rate), 0);
    const docTotal = recordSum + (r.previousBalance || 0);
    const docPaid = r.paymentReceived || 0;
    return sum + Math.max(0, docTotal - docPaid);
  }, 0);

  const totalHours = records.reduce((sum, r) => {
    return sum + (r.entries || []).reduce((acc, e) => acc + (e.hours || 0), 0);
  }, 0);

  const totalExpenses = expenses.reduce((sum, e) => sum + (e.amount || 0), 0);
  const netSavings = totalReceived - totalExpenses;

  // Collection recovery percentage
  const recoveryPct = grandTotalBilled > 0 ? Math.round((totalReceived / grandTotalBilled) * 100) : 0;

  // High balance parties (top debtors)
  const partyBalances: { [name: string]: { billed: number; paid: number; baaki: number; count: number } } = {};
  records.forEach(r => {
    const name = r.farmer || "Unknown";
    if (!partyBalances[name]) partyBalances[name] = { billed: 0, paid: 0, baaki: 0, count: 0 };
    const b = (r.entries || []).reduce((acc, e) => acc + (e.hours * r.rate), 0) + (r.previousBalance || 0);
    const p = r.paymentReceived || 0;
    partyBalances[name].billed += b;
    partyBalances[name].paid += p;
    partyBalances[name].baaki += Math.max(0, b - p);
    partyBalances[name].count += 1;
  });

  const topDebtors = Object.entries(partyBalances)
    .filter(([_, data]) => data.baaki > 0)
    .sort((a, b) => b[1].baaki - a[1].baaki)
    .slice(0, 5);

  // Crop distribution
  const cropStats: { [crop: string]: { hours: number; billed: number } } = {};
  records.forEach(r => {
    const c = r.crop?.trim() || "सामान्य";
    if (!cropStats[c]) cropStats[c] = { hours: 0, billed: 0 };
    const h = (r.entries || []).reduce((acc, e) => acc + (e.hours || 0), 0);
    const b = (r.entries || []).reduce((acc, e) => acc + (e.hours * r.rate), 0) + (r.previousBalance || 0);
    cropStats[c].hours += h;
    cropStats[c].billed += b;
  });

  return (
    <div className="space-y-6">
      
      {/* Top Welcome & System Status Bar */}
      <div className="bg-card/70 backdrop-blur-md p-5 rounded-3xl border border-border/60 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-foreground">सिस्टमेटिक कृषि जल प्रबंधन डैशबोर्ड</h2>
            <span className="flex items-center gap-1 text-[11px] font-semibold bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 px-2.5 py-0.5 rounded-full border border-emerald-500/20 font-sans">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              {isDbConnected ? "Cloud Firestore Live Synced" : "Local Sync Ready"}
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            सभी सिंचाई सत्र, पार्टी खाताबही, वसूली, मदवार खर्च एवं डिजिटल रोकड़ का केंद्रीय नियंत्रण
          </p>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <Button
            onClick={() => onNavigate("billing")}
            className="bg-primary hover:bg-primary/90 text-primary-foreground text-xs font-bold h-9 px-4 rounded-xl shadow-md gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>नया हिसाब जोड़ें</span>
          </Button>
          <Button
            onClick={() => onNavigate("expenses")}
            variant="outline"
            className="border-border text-xs font-bold h-9 px-3.5 rounded-xl gap-1.5"
          >
            <Wallet className="w-4 h-4 text-emerald-600" />
            <span>खर्च व रोकड़</span>
          </Button>
          <Button
            onClick={onOpenPdfModal}
            variant="outline"
            className="border-border text-xs font-bold h-9 px-3.5 rounded-xl gap-1.5"
          >
            <FileDown className="w-4 h-4 text-primary" />
            <span>PDF रिपोर्ट</span>
          </Button>
        </div>
      </div>

      {/* 6 Main Metric KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3.5">
        
        {/* 1. Grand Billed */}
        <Card className="bg-card border border-border/60 shadow-sm rounded-2xl p-4 flex flex-col justify-between">
          <div className="text-[11px] font-bold text-muted-foreground uppercase flex items-center justify-between">
            <span>कुल कारोबार</span>
            <FileText className="w-3.5 h-3.5 text-primary" />
          </div>
          <div className="my-2">
            <div className="text-xl font-bold font-sans text-foreground">
              ₹{grandTotalBilled.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
            </div>
            <div className="text-[10px] text-muted-foreground font-sans">{records.length} कुल बिल सत्र</div>
          </div>
          <div className="h-1 bg-primary/20 rounded-full overflow-hidden">
            <div className="h-full bg-primary rounded-full w-full"></div>
          </div>
        </Card>

        {/* 2. Total Paid */}
        <Card className="bg-emerald-500/5 border border-emerald-500/20 shadow-sm rounded-2xl p-4 flex flex-col justify-between">
          <div className="text-[11px] font-bold text-emerald-700 dark:text-emerald-400 uppercase flex items-center justify-between">
            <span>कुल वसूली (जमा)</span>
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          </div>
          <div className="my-2">
            <div className="text-xl font-bold font-sans text-emerald-700 dark:text-emerald-400">
              ₹{totalReceived.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
            </div>
            <div className="text-[10px] text-emerald-600/80 font-sans">{recoveryPct}% कुल वसूली दर</div>
          </div>
          <div className="h-1 bg-emerald-500/20 rounded-full overflow-hidden">
            <div className="h-full bg-emerald-600 rounded-full" style={{ width: `${Math.min(100, recoveryPct)}%` }}></div>
          </div>
        </Card>

        {/* 3. Total Outstanding */}
        <Card className="bg-amber-500/5 border border-amber-500/20 shadow-sm rounded-2xl p-4 flex flex-col justify-between">
          <div className="text-[11px] font-bold text-amber-700 dark:text-amber-400 uppercase flex items-center justify-between">
            <span>कुल बकाया (बाकी)</span>
            <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
          </div>
          <div className="my-2">
            <div className="text-xl font-bold font-sans text-amber-700 dark:text-amber-400">
              ₹{totalOutstanding.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
            </div>
            <div className="text-[10px] text-amber-600/80 font-sans">{topDebtors.length} पार्टियों से शेष</div>
          </div>
          <div className="h-1 bg-amber-500/20 rounded-full overflow-hidden">
            <div className="h-full bg-amber-500 rounded-full" style={{ width: `${Math.min(100, 100 - recoveryPct)}%` }}></div>
          </div>
        </Card>

        {/* 4. Total Operational Expenses */}
        <Card className="bg-rose-500/5 border border-rose-500/20 shadow-sm rounded-2xl p-4 flex flex-col justify-between">
          <div className="text-[11px] font-bold text-rose-700 dark:text-rose-400 uppercase flex items-center justify-between">
            <span>ऑपरेशनल खर्च</span>
            <ArrowUpRight className="w-3.5 h-3.5 text-rose-600" />
          </div>
          <div className="my-2">
            <div className="text-xl font-bold font-sans text-rose-700 dark:text-rose-400">
              ₹{totalExpenses.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
            </div>
            <div className="text-[10px] text-rose-600/80 font-sans">{expenses.length} खर्च प्रविष्टियां</div>
          </div>
          <div className="h-1 bg-rose-500/20 rounded-full overflow-hidden">
            <div className="h-full bg-rose-600 rounded-full w-3/4"></div>
          </div>
        </Card>

        {/* 5. Net Cash in Hand */}
        <Card className="bg-blue-500/5 border border-blue-500/20 shadow-sm rounded-2xl p-4 flex flex-col justify-between">
          <div className="text-[11px] font-bold text-blue-700 dark:text-blue-400 uppercase flex items-center justify-between">
            <span>शुद्ध रोकड़ बचत</span>
            <Wallet className="w-3.5 h-3.5 text-blue-600" />
          </div>
          <div className="my-2">
            <div className="text-xl font-bold font-sans text-blue-700 dark:text-blue-400">
              ₹{netSavings.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
            </div>
            <div className="text-[10px] text-blue-600/80 font-sans">वसूली माइनस खर्च</div>
          </div>
          <div className="h-1 bg-blue-500/20 rounded-full overflow-hidden">
            <div className="h-full bg-blue-600 rounded-full w-full"></div>
          </div>
        </Card>

        {/* 6. Total Pumping Hours */}
        <Card className="bg-card border border-border/60 shadow-sm rounded-2xl p-4 flex flex-col justify-between">
          <div className="text-[11px] font-bold text-muted-foreground uppercase flex items-center justify-between">
            <span>सिंचाई कुल समय</span>
            <Clock className="w-3.5 h-3.5 text-primary" />
          </div>
          <div className="my-2">
            <div className="text-xl font-bold font-sans text-primary">
              {totalHours.toFixed(1)} <span className="text-xs font-normal text-muted-foreground">घंटे</span>
            </div>
            <div className="text-[10px] text-muted-foreground font-sans">{Object.keys(cropStats).length} फसल श्रेणियां</div>
          </div>
          <div className="h-1 bg-primary/20 rounded-full overflow-hidden">
            <div className="h-full bg-primary rounded-full w-full"></div>
          </div>
        </Card>
      </div>

      {/* 2-Column Analytics & Operational Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Top Outstanding Follow-ups */}
        <div className="lg:col-span-7 space-y-6">
          <Card className="border border-border/60 shadow-md bg-card/70 backdrop-blur-md rounded-3xl overflow-hidden">
            <CardHeader className="border-b border-border/40 pb-3 flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-base font-bold flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-600" />
                  <span>प्राथमिकता बकाया वसूली सूची (Pending Follow-up)</span>
                </CardTitle>
                <CardDescription>जिन पार्टियों का बकाया सर्वाधिक है</CardDescription>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => onNavigate("billing")}
                className="text-xs text-primary font-semibold h-7"
              >
                सभी देखें →
              </Button>
            </CardHeader>
            <CardContent className="p-0">
              {topDebtors.length === 0 ? (
                <div className="text-center py-8 text-xs text-muted-foreground">
                  🎉 सभी पार्टियों का पूरा हिसाब चुकता है, कोई बकाया नहीं!
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow className="border-border/40 bg-muted/40 text-xs">
                      <TableHead className="font-bold">किसान / पार्टी</TableHead>
                      <TableHead className="font-bold text-center">सत्र</TableHead>
                      <TableHead className="font-bold text-right">कुल बिल</TableHead>
                      <TableHead className="font-bold text-right">जमा</TableHead>
                      <TableHead className="font-bold text-right">शेष बाकी</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {topDebtors.map(([name, data]) => (
                      <TableRow key={name} className="border-border/40 hover:bg-muted/20 text-xs">
                        <TableCell className="font-bold text-foreground">
                          👤 {name}
                        </TableCell>
                        <TableCell className="text-center font-sans">
                          {data.count}
                        </TableCell>
                        <TableCell className="text-right font-sans">
                          ₹{data.billed.toLocaleString('en-IN')}
                        </TableCell>
                        <TableCell className="text-right font-sans text-emerald-600 font-semibold">
                          ₹{data.paid.toLocaleString('en-IN')}
                        </TableCell>
                        <TableCell className="text-right font-sans font-bold text-amber-600 text-sm">
                          ₹{data.baaki.toLocaleString('en-IN')}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          {/* Crop-wise Irrigation Breakdown */}
          <Card className="border border-border/60 shadow-md bg-card/70 backdrop-blur-md rounded-3xl p-5">
            <h3 className="text-base font-bold text-foreground mb-3 flex items-center gap-2">
              <Sprout className="w-4 h-4 text-emerald-600" />
              <span>फसल / श्रेणीवार सिंचाई विश्लेषण</span>
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {Object.entries(cropStats).map(([crop, data]) => (
                <div key={crop} className="p-3.5 rounded-2xl bg-muted/30 border border-border/50">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-xs text-foreground">🌾 {crop}</span>
                    <span className="text-[11px] font-bold font-sans text-primary">{data.hours.toFixed(1)}h</span>
                  </div>
                  <div className="text-xs text-muted-foreground font-sans">
                    बिल: <span className="font-bold text-foreground">₹{data.billed.toLocaleString('en-IN')}</span>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Right Column: Recent Sessions & Quick Navigation Hub */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Quick Navigation Cards */}
          <Card className="border border-border/60 shadow-md bg-card/70 backdrop-blur-md rounded-3xl p-5 space-y-3">
            <h3 className="text-sm font-bold text-foreground uppercase tracking-wider">
              त्वरित नेविगेशन हब (System Modules)
            </h3>
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => onNavigate("billing")}
                className="p-3.5 rounded-2xl border border-border bg-background hover:bg-muted/60 text-left transition-all group"
              >
                <FileText className="w-5 h-5 text-primary mb-2 group-hover:scale-110 transition-transform" />
                <div className="font-bold text-xs text-foreground">दैनिक बिलिंग</div>
                <div className="text-[10px] text-muted-foreground font-sans">किसान सत्र व रसीदें</div>
              </button>

              <button
                type="button"
                onClick={() => onNavigate("expenses")}
                className="p-3.5 rounded-2xl border border-border bg-background hover:bg-muted/60 text-left transition-all group"
              >
                <Wallet className="w-5 h-5 text-emerald-600 mb-2 group-hover:scale-110 transition-transform" />
                <div className="font-bold text-xs text-foreground">खर्च व रोकड़</div>
                <div className="text-[10px] text-muted-foreground font-sans">डीजल, मरम्मत व फंड</div>
              </button>

              <button
                type="button"
                onClick={() => onNavigate("yearly")}
                className="p-3.5 rounded-2xl border border-border bg-background hover:bg-muted/60 text-left transition-all group"
              >
                <CalendarDays className="w-5 h-5 text-indigo-600 mb-2 group-hover:scale-110 transition-transform" />
                <div className="font-bold text-xs text-foreground">वार्षिक इतिहास</div>
                <div className="text-[10px] text-muted-foreground font-sans">साल दर साल तुलना</div>
              </button>

              <button
                type="button"
                onClick={onOpenPdfModal}
                className="p-3.5 rounded-2xl border border-border bg-background hover:bg-muted/60 text-left transition-all group"
              >
                <FileDown className="w-5 h-5 text-rose-600 mb-2 group-hover:scale-110 transition-transform" />
                <div className="font-bold text-xs text-foreground">PDF जनरेटर</div>
                <div className="text-[10px] text-muted-foreground font-sans">सटीक पक्की रिपोर्ट</div>
              </button>
            </div>
          </Card>

          {/* Recent Records Log */}
          <Card className="border border-border/60 shadow-md bg-card/70 backdrop-blur-md rounded-3xl overflow-hidden">
            <CardHeader className="border-b border-border/40 pb-3">
              <CardTitle className="text-base font-bold flex items-center gap-2">
                <Clock className="w-4 h-4 text-primary" />
                <span>हालिया सिंचाई बिलिंग प्रविष्टियां</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-border/40 max-h-[260px] overflow-y-auto">
                {records.slice(0, 5).map(r => {
                  const rSum = (r.entries || []).reduce((acc, e) => acc + (e.hours * r.rate), 0) + (r.previousBalance || 0);
                  const rPaid = r.paymentReceived || 0;
                  const rBaaki = Math.max(0, rSum - rPaid);

                  return (
                    <div key={r.id} className="p-3 text-xs flex items-center justify-between hover:bg-muted/20">
                      <div>
                        <div className="font-bold text-foreground">{r.farmer}</div>
                        <div className="text-[10px] text-muted-foreground font-sans">
                          {format(new Date(r.date), "dd MMM yyyy")} · {r.crop || "-"}
                        </div>
                      </div>
                      <div className="text-right font-sans">
                        <div className="font-bold text-foreground">₹{rSum.toLocaleString('en-IN')}</div>
                        <div className={`text-[10px] font-bold ${rBaaki === 0 ? "text-emerald-600" : "text-amber-600"}`}>
                          {rBaaki === 0 ? "पूर्ण जमा" : `बाकी: ₹${rBaaki}`}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

        </div>
      </div>
    </div>
  );
}
