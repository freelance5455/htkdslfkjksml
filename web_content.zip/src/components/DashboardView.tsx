import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  getMessFinancialSummary, 
  getLandlordFinancialSummary, 
  getSitesFinancialSummary, 
  calculateProRataRentForMonth 
} from '../utils/calculations';
import { formatCurrency, formatNumber } from '../utils/formatters';
import { 
  TrendingUp, 
  Coins, 
  Receipt, 
  AlertCircle, 
  Building2, 
  UtensilsCrossed, 
  Home, 
  Users, 
  ArrowUpRight,
  ShieldAlert,
  Wallet,
  ArrowRight
} from 'lucide-react';

interface DashboardViewProps {
  onOpenQuickEntry: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onOpenQuickEntry }) => {
  const { 
    sites, 
    labours, 
    attendance, 
    advances, 
    engineerPayments, 
    messExpenses, 
    messCollections, 
    roomOwnerConfig, 
    landlordPayments,
    setActiveTab,
    setSelectedSiteId
  } = useApp();

  // Calculations
  const siteSummary = getSitesFinancialSummary(sites, attendance, advances, engineerPayments);
  const messSummary = getMessFinancialSummary(messExpenses, messCollections);
  const proRataRent = calculateProRataRentForMonth(labours, roomOwnerConfig, messCollections);
  const landlordSummary = getLandlordFinancialSummary(
    proRataRent.totalCalculatedRent, 
    landlordPayments, 
    roomOwnerConfig.billingMonth
  );

  // মোট নিট লাভ (সাইট কমিশন + মেস উদ্বৃত্ত + রুম ভাড়ার মার্জিন)
  // মেস উদ্বৃত্ত = মোট খাবার সংগ্রহ - মোট মেস খরচ
  // রুম ভাড়ার মার্জিন = লেবারদের থেকে সংগৃহীত রুম ভাড়া - বাড়িওয়ালাকে প্রদেয় ভাড়া
  const roomRentMargin = messSummary.totalRoomRentCollection - landlordSummary.totalCalculatedRent;
  const netProfit = siteSummary.totalFlatCommission + messSummary.messSurplus + (roomRentMargin > 0 ? roomRentMargin : 0);

  // মোট মেস খরচ ও বাড়িওয়ালাকে প্রদত্ত মোট ভাড়ার সম্মিলিত সামারি
  const totalMessAndRentPaid = messSummary.totalMessExpense + landlordSummary.totalPaidToLandlord;

  // বকেয়া ও পেন্ডিং হিসাব
  const totalPendingDues = proRataRent.totalPendingRentFromLabours + landlordSummary.pendingLandlordRent;

  const activeMessMembers = labours.filter(l => l.roleType === 'mess_and_site' || l.roleType === 'mess_only');
  const activeSiteLabours = labours.filter(l => l.roleType === 'mess_and_site' || l.roleType === 'site_only');

  return (
    <div className="space-y-6">
      
      {/* Welcome & Quick Action Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            বিল্ডিং কন্ট্রাক্টর ও মেস ফাইন্যান্স ড্যাশবোর্ড
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            সাইট কমিশন, লেবার মজুরি, মেস খাবার খরচ এবং বাড়িওয়ালার ভাড়ার রিয়েল-টাইম হিসাব বিবরণী
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={onOpenQuickEntry}
            className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white text-sm font-medium rounded-lg transition-colors shadow-xs flex items-center gap-1.5 whitespace-nowrap"
          >
            <span>+ নতুন ভাউচার / এন্ট্রি</span>
          </button>
        </div>
      </div>

      {/* ৪টি মূল মেট্রিক কার্ডস (Section 1 of Prompt) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* কার্ড ১: মোট নিট লাভ */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs hover:border-amber-300 transition-colors">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>মোট নিট লাভ (Net Profit)</span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl lg:text-3xl font-bold font-mono tabular-nums text-slate-900">
              {formatCurrency(netProfit)}
            </div>
            <div className="mt-2 text-xs text-slate-500 flex items-center gap-1">
              <span>সাইট কমিশন</span>
              <span className="font-semibold text-slate-700 font-mono">{formatCurrency(siteSummary.totalFlatCommission)}</span>
              <span>+ মেস উদ্বৃত্ত</span>
            </div>
          </div>
        </div>

        {/* কার্ড ২: সাইটের মোট কমিশন (নির্দিষ্ট ফ্ল্যাট টাকা) */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs hover:border-amber-300 transition-colors">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>সাইটের মোট কমিশন (ফ্ল্যাট টাকা)</span>
            <div className="p-2 rounded-lg bg-blue-50 text-blue-700">
              <Coins className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl lg:text-3xl font-bold font-mono tabular-nums text-blue-900">
              {formatCurrency(siteSummary.totalFlatCommission)}
            </div>
            <div className="mt-2 text-xs text-slate-500 flex items-center gap-1.5">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-blue-500"></span>
              <span>{formatNumber(siteSummary.totalActiveSites)} টি সক্রিয় সাইট (কোনো % নয়, নির্দিষ্ট টাকা)</span>
            </div>
          </div>
        </div>

        {/* কার্ড ৩: মেস খরচ ও বাড়িওয়ালাকে প্রদত্ত মোট ভাড়া */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs hover:border-amber-300 transition-colors">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>মেস খরচ ও প্রদত্ত মোট ভাড়া</span>
            <div className="p-2 rounded-lg bg-purple-50 text-purple-700">
              <Receipt className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl lg:text-3xl font-bold font-mono tabular-nums text-purple-900">
              {formatCurrency(totalMessAndRentPaid)}
            </div>
            <div className="mt-2 text-xs text-slate-500 flex items-center gap-1">
              <span>মেস: <strong className="text-slate-700 font-mono">{formatCurrency(messSummary.totalMessExpense)}</strong></span>
              <span>· বাড়িওয়ালা: <strong className="text-slate-700 font-mono">{formatCurrency(landlordSummary.totalPaidToLandlord)}</strong></span>
            </div>
          </div>
        </div>

        {/* কার্ড ৪: মোট পেন্ডিং ও বকেয়া টাকার হিসাব */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs hover:border-amber-300 transition-colors">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>মেস ও রুম ভাড়ার পেন্ডিং বকেয়া</span>
            <div className="p-2 rounded-lg bg-rose-50 text-rose-700">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl lg:text-3xl font-bold font-mono tabular-nums text-rose-700">
              {formatCurrency(totalPendingDues)}
            </div>
            <div className="mt-2 text-xs text-slate-500 flex items-center gap-1">
              <span>বাড়িওয়ালার বকেয়া: <strong className="text-rose-600 font-mono">{formatCurrency(landlordSummary.pendingLandlordRent)}</strong></span>
            </div>
          </div>
        </div>

      </div>

      {/* নিট লাভ ও মেস উদ্বৃত্তের সুস্পষ্ট হিসাব ব্যাখ্যা (Calculation Transparency Banner) */}
      <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-xl p-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Wallet className="w-5 h-5 text-amber-700" />
              <h2 className="text-base font-bold text-amber-950">
                আর্থিক হিসাবের পরিষ্কার সমীকরণ (Financial Formula Breakdown)
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-amber-800">
              মোট নিট লাভ = সাইটের নির্দিষ্ট ফ্ল্যাট কমিশন ({formatCurrency(siteSummary.totalFlatCommission)}) + মেস উদ্বৃত্ত ({formatCurrency(messSummary.messSurplus)}) + রুম ভাড়ার উদ্বৃত্ত ({formatCurrency(Math.max(0, roomRentMargin))})
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-3.5 py-2 rounded-lg bg-white/80 border border-amber-200 text-center">
              <span className="block text-[11px] text-amber-700 font-medium">মেস খাবার উদ্বৃত্ত/ঘাটতি</span>
              <span className={`text-sm font-bold font-mono tabular-nums ${messSummary.messSurplus >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                {messSummary.messSurplus >= 0 ? '+' : ''}{formatCurrency(messSummary.messSurplus)}
              </span>
            </div>
            <div className="px-3.5 py-2 rounded-lg bg-white/80 border border-amber-200 text-center">
              <span className="block text-[11px] text-amber-700 font-medium">বাড়িওয়ালার বকেয়া</span>
              <span className="text-sm font-bold font-mono tabular-nums text-rose-700">
                {formatCurrency(landlordSummary.pendingLandlordRent)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* ২-কলামের মূল সেকশন: পেন্ডিং ডিউজ ট্র্যাকার এবং সাইট স্ট্যাটাস */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* কলাম ১: রিয়েল-টাইম পেন্ডিং ও বকেয়া টাকার বিস্তারিত চার্ট */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-amber-600" />
              <h2 className="text-base font-bold text-slate-900">
                পেন্ডিং ও বকেয়া টাকার সম্পূর্ণ হিসাব
              </h2>
            </div>
            <span className="text-xs text-slate-500">রিয়েল-টাইম সামারি</span>
          </div>

          <div className="divide-y divide-slate-100 mt-2">
            
            {/* ১. বাড়িওয়ালার কাছে বকেয়া ভাড়া */}
            <div className="py-3 flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-slate-800">
                  বাড়িওয়ালার বকেয়া ভাড়া (Pending to Landlord)
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  প্রোরোটা মোট পাওনা {formatCurrency(landlordSummary.totalCalculatedRent)} - প্রদত্ত {formatCurrency(landlordSummary.totalPaidToLandlord)}
                </p>
              </div>
              <div className="text-right">
                <span className="text-base font-bold font-mono tabular-nums text-rose-600">
                  {formatCurrency(landlordSummary.pendingLandlordRent)}
                </span>
                <button 
                  onClick={() => setActiveTab('landlord')}
                  className="block text-[11px] text-amber-700 hover:underline mt-0.5"
                >
                  কিস্তি দিন →
                </button>
              </div>
            </div>

            {/* ২. লেবারদের থেকে মেসের রুম ভাড়ার বকেয়া */}
            <div className="py-3 flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-slate-800">
                  লেবারদের থেকে রুম ভাড়ার বকেয়া
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  মেসে থাকা লেবারদের এখনো প্রদেয় রুম ভাড়া বাকি
                </p>
              </div>
              <div className="text-right">
                <span className="text-base font-bold font-mono tabular-nums text-amber-700">
                  {formatCurrency(proRataRent.totalPendingRentFromLabours)}
                </span>
                <button 
                  onClick={() => setActiveTab('mess')}
                  className="block text-[11px] text-amber-700 hover:underline mt-0.5"
                >
                  কালেকশন দেখুন →
                </button>
              </div>
            </div>

            {/* ৩. ইঞ্জিনিয়ারদের থেকে পাওনা টাকা */}
            <div className="py-3 flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-slate-800">
                  ইঞ্জিনিয়ার/মালিকের থেকে পাওনা টাকা
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  সাইটের মোট বিল ও কমিশন বাবদ বাকি বকেয়া
                </p>
              </div>
              <div className="text-right">
                <span className="text-base font-bold font-mono tabular-nums text-blue-700">
                  {formatCurrency(siteSummary.totalPendingFromEngineers)}
                </span>
                <button 
                  onClick={() => setActiveTab('sites')}
                  className="block text-[11px] text-blue-700 hover:underline mt-0.5"
                >
                  পেমেন্ট তুলুন →
                </button>
              </div>
            </div>

            {/* ৪. লেবারদের দৈনিক মজুরি বকেয়া */}
            <div className="py-3 flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-slate-800">
                  লেবারদের মোট প্রদেয় মজুরি বকেয়া
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  মোট অর্জিত মজুরি {formatCurrency(siteSummary.totalAllSitesWages)} - প্রদত্ত অগ্রিম {formatCurrency(siteSummary.totalAllSitesAdvances)}
                </p>
              </div>
              <div className="text-right">
                <span className="text-base font-bold font-mono tabular-nums text-slate-800">
                  {formatCurrency(siteSummary.totalPendingLabourWages)}
                </span>
                <button 
                  onClick={() => setActiveTab('sites')}
                  className="block text-[11px] text-slate-600 hover:underline mt-0.5"
                >
                  অগ্রিম/পার্ট পেমেন্ট দিন →
                </button>
              </div>
            </div>

          </div>
        </div>

        {/* কলাম ২: সাইট-ওয়াইজ কমিশন ও লেবার স্ট্যাটাস কার্ড */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-amber-600" />
                <h2 className="text-base font-bold text-slate-900">
                  সাইট-ওয়াইজ কমিশন ও স্ট্যাটাস
                </h2>
              </div>
              <button
                onClick={() => setActiveTab('sites')}
                className="text-xs font-semibold text-amber-700 hover:underline flex items-center gap-1"
              >
                <span>সব সাইট</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-3 mt-3">
              {sites.map(site => {
                const isSiteActive = site.status === 'active';
                return (
                  <div 
                    key={site.id}
                    onClick={() => {
                      setSelectedSiteId(site.id);
                      setActiveTab('sites');
                    }}
                    className="p-3.5 rounded-lg border border-slate-200 hover:border-amber-300 hover:bg-slate-50/70 transition-colors cursor-pointer"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h4 className="text-sm font-bold text-slate-900">{site.name}</h4>
                        <p className="text-xs text-slate-500 mt-0.5">{site.engineerName} · {site.address}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="text-sm font-bold font-mono tabular-nums text-amber-700">
                          {formatCurrency(site.flatCommission)}
                        </span>
                        <span className="block text-[10px] text-slate-400 font-medium">ফ্ল্যাট কমিশন</span>
                      </div>
                    </div>

                    <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
                      <span className={`inline-flex items-center gap-1 text-[11px] font-medium ${isSiteActive ? 'text-emerald-700' : 'text-slate-500'}`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${isSiteActive ? 'bg-emerald-500' : 'bg-slate-400'}`}></span>
                        {isSiteActive ? 'চলতি কাজ' : 'সম্পন্ন'}
                      </span>
                      <span className="text-slate-500 text-[11px]">
                        ক্লিক করে হাজিরা ও মজুরি দেখুন →
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>সক্রিয় লেবার: <strong>{activeSiteLabours.length} জন সাইটে</strong></span>
            <span>মেস সদস্য: <strong>{activeMessMembers.length} জন মেসে</strong></span>
          </div>
        </div>

      </div>

      {/* মেস পরিচালনা ও বাড়িওয়ালার ভাড়ার রিয়েল-টাইম ওভারভিউ */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* বক্স ১: মেস খরচ ও খাবার বিশ্লেষণ */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">মেস খরচ বিবরণী</span>
            <UtensilsCrossed className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2">
            <div className="text-xl font-bold font-mono tabular-nums text-slate-900">
              {formatCurrency(messSummary.totalMessExpense)}
            </div>
            <p className="text-xs text-slate-500 mt-1">
              বাজার, গ্যাস, বিদ্যুৎ ও বাবুর্চির মোট খরচ
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-600">আদায়কৃত মিল খরচ:</span>
            <span className="font-semibold font-mono text-emerald-700">{formatCurrency(messSummary.totalMealCollection)}</span>
          </div>
        </div>

        {/* বক্স ২: বাড়িওয়ালার প্রতি-জন ভাড়া */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">বাড়িওয়ালার জন-প্রতি ভাড়া</span>
            <Home className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2">
            <div className="text-xl font-bold font-mono tabular-nums text-slate-900">
              {formatCurrency(roomOwnerConfig.perHeadMonthlyRate)} <span className="text-xs font-normal text-slate-500">/ জন / মাস</span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {proRataRent.totalActiveMessLabours} জন সক্রিয় লেবার (Pro-rata ভিত্তিতে দিন গুনে হিসাব)
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-600">চলতি মাসের প্রদেয়:</span>
            <span className="font-semibold font-mono text-slate-900">{formatCurrency(proRataRent.totalCalculatedRent)}</span>
          </div>
        </div>

        {/* বক্স ৩: লেবারদের উপস্থিতি ও মেস স্ট্যাটাস */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">লেবার ও মেস জনসংখ্যা</span>
            <Users className="w-4 h-4 text-amber-600" />
          </div>
          <div className="mt-2">
            <div className="text-xl font-bold font-mono tabular-nums text-slate-900">
              {formatNumber(labours.length)} <span className="text-xs font-normal text-slate-500">জন মোট লেবার</span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              মেসে থাকে: {formatNumber(activeMessMembers.length)} জন · বাইরে কাজ করে: {formatNumber(labours.filter(l => l.roleType === 'mess_only').length)} জন
            </p>
          </div>
          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
            <span className="text-slate-600">সাইটের স্থানীয় লেবার:</span>
            <span className="font-semibold font-mono text-blue-700">{formatNumber(labours.filter(l => l.roleType === 'site_only').length)} জন</span>
          </div>
        </div>

      </div>

    </div>
  );
};
