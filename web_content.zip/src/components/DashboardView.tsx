import React from 'react';
import { Product, SaleTransaction, StoreSettings, ActiveTab } from '../types';
import { 
  ShoppingCart, 
  Barcode, 
  Boxes, 
  Receipt, 
  AlertTriangle, 
  TrendingUp, 
  DollarSign, 
  ArrowRight,
  PackageCheck,
  Plus
} from 'lucide-react';

interface DashboardViewProps {
  inventory: Product[];
  sales: SaleTransaction[];
  settings: StoreSettings;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenReceipt: (sale: SaleTransaction) => void;
  onQuickRestock: (productId: string, amount: number) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  inventory,
  sales,
  settings,
  setActiveTab,
  onOpenReceipt,
  onQuickRestock
}) => {
  // Compute analytics
  const todayStr = new Date().toDateString();
  const completedSales = sales.filter(s => s.status === 'completed');
  const todaySales = completedSales.filter(s => new Date(s.timestamp).toDateString() === todayStr);

  const todayRevenue = todaySales.reduce((acc, s) => acc + s.total, 0);
  const totalRevenue = completedSales.reduce((acc, s) => acc + s.total, 0);

  const lowStockItems = inventory.filter(i => i.stock <= i.minStock);
  const totalStockUnits = inventory.reduce((acc, i) => acc + i.stock, 0);

  // Total inventory valuation
  const inventoryRetailValue = inventory.reduce((acc, i) => acc + (i.price * i.stock), 0);

  // Today estimated gross profit
  const todayProfit = todaySales.reduce((acc, s) => {
    const cost = s.items.reduce((cAcc, item) => cAcc + (item.costPrice * item.quantity), 0);
    return acc + (s.total - cost);
  }, 0);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Store Overview Hero Banner */}
      <div className="glass-card rounded-3xl p-6 sm:p-8 relative overflow-hidden">
        <div className="absolute -right-10 -top-10 w-48 h-48 bg-gradient-to-br from-cyan-500/20 to-blue-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute right-20 -bottom-10 w-40 h-40 bg-purple-500/10 rounded-full blur-2xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-semibold mb-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Store Active & Ready
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              {settings.storeName}
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Live POS Terminal, stock register & barcode tracking system.
            </p>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab('sale')}
              className="px-5 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold rounded-2xl text-xs sm:text-sm shadow-lg shadow-cyan-500/25 flex items-center gap-2 transition cursor-pointer"
            >
              <ShoppingCart className="w-4 h-4" />
              Open POS Terminal
            </button>
          </div>
        </div>

        {/* Quick Metric Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-6">
          <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-slate-400 font-medium">Today's Revenue</span>
              <DollarSign className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-xl sm:text-2xl font-black text-emerald-400">
              {settings.currency}{todayRevenue.toFixed(2)}
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              Est. Profit: <span className="text-emerald-300 font-semibold">{settings.currency}{todayProfit.toFixed(2)}</span>
            </div>
          </div>

          <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-slate-400 font-medium">Sales Today</span>
              <TrendingUp className="w-4 h-4 text-cyan-400" />
            </div>
            <div className="text-xl sm:text-2xl font-black text-cyan-400">
              {todaySales.length}
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              Total sales: {completedSales.length}
            </div>
          </div>

          <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-slate-400 font-medium">Total Products</span>
              <PackageCheck className="w-4 h-4 text-blue-400" />
            </div>
            <div className="text-xl sm:text-2xl font-black text-slate-100">
              {inventory.length}
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              {totalStockUnits} units in stock
            </div>
          </div>

          <div 
            onClick={() => setActiveTab('inventory')}
            className={`p-4 rounded-2xl border cursor-pointer transition ${
              lowStockItems.length > 0
                ? 'bg-amber-950/20 border-amber-500/30 hover:border-amber-500/50'
                : 'bg-slate-900/80 border-slate-800'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-slate-400 font-medium">Low Stock Alert</span>
              <AlertTriangle className={`w-4 h-4 ${lowStockItems.length > 0 ? 'text-amber-400' : 'text-slate-500'}`} />
            </div>
            <div className={`text-xl sm:text-2xl font-black ${lowStockItems.length > 0 ? 'text-amber-400' : 'text-slate-300'}`}>
              {lowStockItems.length}
            </div>
            <div className="text-[11px] text-slate-500 mt-1">
              {lowStockItems.length > 0 ? 'Action required' : 'Inventory healthy'}
            </div>
          </div>
        </div>
      </div>

      {/* Main Action Hub */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <button
          onClick={() => setActiveTab('sale')}
          className="glass-card hover:border-cyan-500/50 p-5 rounded-2xl flex flex-col items-center text-center space-y-3 transition group cursor-pointer"
        >
          <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center text-2xl border border-cyan-500/20 group-hover:scale-110 group-hover:bg-cyan-500/20 transition transform shadow-lg shadow-cyan-500/10">
            <ShoppingCart className="w-7 h-7" />
          </div>
          <div>
            <span className="font-bold text-slate-100 block text-base group-hover:text-cyan-300 transition">
              Sale Terminal
            </span>
            <span className="text-xs text-slate-400 mt-0.5 block">
              Camera scanner, cart & rapid checkout
            </span>
          </div>
        </button>

        <button
          onClick={() => setActiveTab('register')}
          className="glass-card hover:border-blue-500/50 p-5 rounded-2xl flex flex-col items-center text-center space-y-3 transition group cursor-pointer"
        >
          <div className="w-14 h-14 rounded-2xl bg-blue-500/10 text-blue-400 flex items-center justify-center text-2xl border border-blue-500/20 group-hover:scale-110 group-hover:bg-blue-500/20 transition transform shadow-lg shadow-blue-500/10">
            <Barcode className="w-7 h-7" />
          </div>
          <div>
            <span className="font-bold text-slate-100 block text-base group-hover:text-blue-300 transition">
              Register Item
            </span>
            <span className="text-xs text-slate-400 mt-0.5 block">
              Add products & generate barcode labels
            </span>
          </div>
        </button>

        <button
          onClick={() => setActiveTab('inventory')}
          className="glass-card hover:border-purple-500/50 p-5 rounded-2xl flex flex-col items-center text-center space-y-3 transition group cursor-pointer"
        >
          <div className="w-14 h-14 rounded-2xl bg-purple-500/10 text-purple-400 flex items-center justify-center text-2xl border border-purple-500/20 group-hover:scale-110 group-hover:bg-purple-500/20 transition transform shadow-lg shadow-purple-500/10">
            <Boxes className="w-7 h-7" />
          </div>
          <div>
            <span className="font-bold text-slate-100 block text-base group-hover:text-purple-300 transition">
              Inventory Manager
            </span>
            <span className="text-xs text-slate-400 mt-0.5 block">
              Track stock, adjust levels & CSV export
            </span>
          </div>
        </button>
      </div>

      {/* Grid: Low Stock Warnings & Recent Sales */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Low Stock Warning Card */}
        <div className="glass-card rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <h3 className="font-bold text-slate-200 text-sm">Low Stock Items</h3>
            </div>
            <button
              onClick={() => setActiveTab('inventory')}
              className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-medium"
            >
              View All <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          {lowStockItems.length === 0 ? (
            <div className="py-8 text-center text-slate-500 text-xs">
              All inventory items are sufficiently stocked.
            </div>
          ) : (
            <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
              {lowStockItems.map(item => (
                <div
                  key={item.id}
                  className="bg-slate-900/70 border border-slate-800 p-3 rounded-xl flex items-center justify-between"
                >
                  <div className="pr-2">
                    <span className="font-bold text-xs text-slate-200 block truncate max-w-[180px]">
                      {item.name}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">
                      Code: {item.code} • Min: {item.minStock}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-xs font-bold px-2 py-0.5 rounded ${
                      item.stock === 0 
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' 
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    }`}>
                      {item.stock} left
                    </span>
                    <button
                      onClick={() => onQuickRestock(item.id, 10)}
                      title="Quick restock +10 units"
                      className="p-1.5 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/20 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3 h-3" /> 10
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Transactions Card */}
        <div className="glass-card rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
            <div className="flex items-center gap-2">
              <Receipt className="w-4 h-4 text-cyan-400" />
              <h3 className="font-bold text-slate-200 text-sm">Recent Transactions</h3>
            </div>
            <button
              onClick={() => setActiveTab('history')}
              className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-medium"
            >
              All Receipts <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          {sales.length === 0 ? (
            <div className="py-8 text-center text-slate-500 text-xs">
              No sales recorded yet. Head over to Sale Terminal to make your first transaction!
            </div>
          ) : (
            <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
              {sales.slice(-5).reverse().map(sale => (
                <div
                  key={sale.id}
                  onClick={() => onOpenReceipt(sale)}
                  className="bg-slate-900/70 border border-slate-800 hover:border-slate-700 p-3 rounded-xl flex items-center justify-between cursor-pointer transition"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-slate-200">
                        {sale.receiptNumber}
                      </span>
                      {sale.status === 'refunded' && (
                        <span className="text-[10px] bg-rose-500/20 text-rose-300 px-1.5 py-0.2 rounded font-semibold">
                          Refunded
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-slate-400">
                      {sale.items.length} items • {new Date(sale.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-black text-cyan-300 block">
                      {settings.currency}{sale.total.toFixed(2)}
                    </span>
                    <span className="text-[10px] text-slate-500 uppercase font-semibold">
                      {sale.paymentMethod}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
