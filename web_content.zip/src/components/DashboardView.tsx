import React, { useMemo, useState } from 'react';
import { useClimbing } from '../context/ClimbingContext';
import {
  Award,
  Flame,
  User,
  Shield,
  Layers,
  ArrowRight,
  Plus,
  Calendar,
  CheckCircle2,
  StickyNote
} from 'lucide-react';
import { InteractiveCharts } from './InteractiveCharts';
import { DashboardCharts } from './DashboardCharts';
import { ActivityHeatmap } from './ActivityHeatmap';
import { QuickNotes } from './QuickNotes';
import { NICAS_LEVEL_TITLES } from '../types/climbing';

interface DashboardViewProps {
  onNavigateToTab: (tab: 'dashboard' | 'log' | 'checklist' | 'history' | 'centres' | 'profile') => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigateToTab }) => {
  const { climbs, checklist, profile, getClubById, trainingNotes } = useClimbing();
  const [isQuickNotesOpen, setIsQuickNotesOpen] = useState(false);

  // Summary Metrics
  const totalClimbs = climbs.length;

  // Favorite style
  const favoriteStyleInfo = useMemo(() => {
    if (climbs.length === 0) return { style: 'None', count: 0, percent: 0 };
    const counts: Record<string, number> = {};
    climbs.forEach(c => {
      counts[c.style] = (counts[c.style] || 0) + 1;
    });
    let maxStyle = 'Top Rope';
    let maxCount = 0;
    Object.entries(counts).forEach(([style, count]) => {
      if (count > maxCount) {
        maxCount = count;
        maxStyle = style;
      }
    });
    return {
      style: maxStyle,
      count: maxCount,
      percent: Math.round((maxCount / climbs.length) * 100)
    };
  }, [climbs]);

  // Clean sends (Onsite + Flash + Redpoint)
  const cleanSendsCount = useMemo(() => {
    return climbs.filter(c => c.outcome !== 'Attempt').length;
  }, [climbs]);

  const cleanSendRate = totalClimbs > 0 ? Math.round((cleanSendsCount / totalClimbs) * 100) : 0;

  // Level progress
  const currentLevelItems = checklist.filter(c => c.level === profile.currentLevel);
  const completedCurrentLevelItems = currentLevelItems.filter(c => c.status === 'Completed').length;
  const currentLevelPct = currentLevelItems.length > 0
    ? Math.round((completedCurrentLevelItems / currentLevelItems.length) * 100)
    : 0;

  // Unique centres climbed at
  const uniqueClubsCount = useMemo(() => {
    const ids = new Set(climbs.map(c => c.clubId));
    return ids.size;
  }, [climbs]);

  // Recent 5 climbs
  const recentClimbs = useMemo(() => {
    return [...climbs]
      .sort((a, b) => b.date.localeCompare(a.date) || b.createdAt - a.createdAt)
      .slice(0, 5);
  }, [climbs]);

  const homeClub = getClubById(profile.homeClubId);
  const uncompletedNotesCount = trainingNotes.filter(n => !n.isCompleted).length;

  return (
    <div className="space-y-5 w-full max-w-full overflow-hidden relative">
      {/* Candidate Profile Notification Banner if profile is blank */}
      {!profile.candidateName && (
        <div className="p-3.5 sm:p-4 bg-orange-50 dark:bg-orange-950/30 border border-orange-200 dark:border-orange-900/60 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-2.5">
            <User className="w-5 h-5 text-orange-600 shrink-0" />
            <div>
              <p className="text-xs sm:text-sm font-bold text-orange-950 dark:text-orange-200">
                Welcome to your NICAS Logbook!
              </p>
              <p className="text-[11px] text-orange-800 dark:text-orange-300">
                Set up your climber profile (name, age, NICAS registration number, and emergency contact) to personalize your records and PDF reports.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onNavigateToTab('profile')}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-xs shrink-0 self-start sm:self-auto cursor-pointer"
          >
            Complete Profile
          </button>
        </div>
      )}

      {/* Candidate Hero Card */}
      <div className="bg-slate-900 dark:bg-slate-950 text-white rounded-2xl p-5 sm:p-7 shadow-xs relative overflow-hidden border border-slate-800">
        <div className="relative z-10 space-y-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[11px] font-bold text-orange-400 bg-orange-950/80 border border-orange-800/80 px-2.5 py-0.5 rounded">
                NICAS Candidate Logbook
              </span>
              {profile.candidateNumber && (
                <span className="text-[11px] text-slate-300 font-mono">
                  ID: {profile.candidateNumber}
                </span>
              )}
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight text-white">
              {profile.candidateName || 'New NICAS Candidate'}
            </h1>
            <p className="text-xs text-slate-300 max-w-xl leading-relaxed">
              Tracking Level {profile.currentLevel} ({NICAS_LEVEL_TITLES[profile.currentLevel]?.subtitle || 'Foundation'}).
              {homeClub ? ` Home Centre: ${homeClub.name}.` : ''}
            </p>
          </div>

          {/* Quick CTA Actions */}
          <div className="flex items-center gap-2 pt-1 flex-wrap">
            <button
              type="button"
              onClick={() => onNavigateToTab('log')}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 py-2.5 bg-orange-600 hover:bg-orange-700 text-white font-semibold text-xs sm:text-sm rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Log Climb</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigateToTab('checklist')}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs sm:text-sm rounded-xl border border-slate-700 transition-colors cursor-pointer"
            >
              <Shield className="w-4 h-4 text-orange-400" />
              <span>Checklist</span>
            </button>
            <button
              type="button"
              onClick={() => setIsQuickNotesOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs rounded-xl border border-slate-700 transition-colors cursor-pointer"
            >
              <StickyNote className="w-4 h-4 text-orange-400" />
              <span>Quick Notes</span>
              {uncompletedNotesCount > 0 && (
                <span className="bg-orange-600 text-white text-[10px] px-1.5 rounded-full font-mono">
                  {uncompletedNotesCount}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => onNavigateToTab('profile')}
              className="px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs rounded-xl border border-slate-700 transition-colors"
            >
              Profile
            </button>
          </div>
        </div>
      </div>

      {/* KPI Summary Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* 1. Total Climbs */}
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-3.5 sm:p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-medium">
            <span>Total Climbs</span>
            <Flame className="w-4 h-4 text-orange-600" />
          </div>
          <div className="my-1.5">
            <div className="text-2xl sm:text-3xl font-bold font-mono text-slate-900 dark:text-white tabular-nums">
              {totalClimbs}
            </div>
            <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">
              {uniqueClubsCount} centres visited
            </p>
          </div>
          <div className="text-[10px] sm:text-[11px] text-orange-700 dark:text-orange-400 font-semibold pt-1 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <span>Send Rate:</span>
            <span className="font-mono tabular-nums">{cleanSendRate}%</span>
          </div>
        </div>

        {/* 2. Active NICAS Level */}
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-3.5 sm:p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-medium">
            <span>Active Level</span>
            <Award className="w-4 h-4 text-amber-600" />
          </div>
          <div className="my-1.5">
            <div className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
              Level {profile.currentLevel}
            </div>
            <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
              {NICAS_LEVEL_TITLES[profile.currentLevel]?.subtitle || 'Climber'}
            </p>
          </div>
          <div className="text-[10px] sm:text-[11px] text-slate-600 dark:text-slate-400 pt-1 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <span>Signed:</span>
            <span className="font-mono tabular-nums font-semibold text-orange-700 dark:text-orange-400">
              {completedCurrentLevelItems}/{currentLevelItems.length}
            </span>
          </div>
        </div>

        {/* 3. Favorite Style */}
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-3.5 sm:p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-medium">
            <span>Fav Style</span>
            <Layers className="w-4 h-4 text-orange-600" />
          </div>
          <div className="my-1.5">
            <div className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white truncate">
              {favoriteStyleInfo.style}
            </div>
            <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 font-mono tabular-nums">
              {favoriteStyleInfo.count} logged
            </p>
          </div>
          <div className="text-[10px] sm:text-[11px] text-slate-600 dark:text-slate-400 pt-1 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <span>Focus:</span>
            <span className="text-slate-700 dark:text-slate-300 font-medium truncate">{profile.schemeTrack.split(' ')[1] || 'Climb'}</span>
          </div>
        </div>

        {/* 4. Candidate Accreditation */}
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-3.5 sm:p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-medium">
            <span>Assessor</span>
            <Shield className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="my-1.5">
            <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate" title={profile.leadInstructor || 'Not set'}>
              {profile.leadInstructor ? profile.leadInstructor.split('(')[0].trim() : 'Not Set'}
            </div>
            <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">
              {profile.age ? `Age ${profile.age}` : 'Age pending'}
            </p>
          </div>
          <div className="text-[10px] sm:text-[11px] text-slate-600 dark:text-slate-400 pt-1 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <span>Target:</span>
            <span className="font-mono text-slate-700 dark:text-slate-300 font-semibold">Level {profile.targetLevel}</span>
          </div>
        </div>
      </div>

      {/* Recharts Visual Graph Module (Total Climbs per Month & Style Distribution) */}
      <DashboardCharts climbs={climbs} />

      {/* Monthly Activity Heatmap SVG Calendar Grid */}
      <ActivityHeatmap />

      {/* Interactive Dropdown Progress Graphs */}
      <InteractiveCharts climbs={climbs} />

      {/* Two-Column Lower Section: Recent Sessions + NICAS Level Roadmap */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Recent Climbs / Sessions Ledger */}
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 sm:p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-orange-600" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Recent Logged Ascents</h3>
              </div>
              <button
                type="button"
                onClick={() => onNavigateToTab('history')}
                className="text-xs font-semibold text-orange-600 hover:text-orange-800 dark:text-orange-400 flex items-center gap-1"
              >
                <span>All ({climbs.length})</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {climbs.length === 0 ? (
              <div className="py-8 text-center text-slate-500 dark:text-slate-400 space-y-2">
                <p className="text-xs sm:text-sm font-medium text-slate-700 dark:text-slate-300">No climbs recorded yet.</p>
                <p className="text-xs text-slate-400 dark:text-slate-500 max-w-xs mx-auto">
                  Start your logbook by tapping "Log Climb" after your climbing session.
                </p>
                <button
                  type="button"
                  onClick={() => onNavigateToTab('log')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-xs mt-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Log First Ascent</span>
                </button>
              </div>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800 mt-1">
                {recentClimbs.map(climb => {
                  const club = getClubById(climb.clubId);
                  return (
                    <div key={climb.id} className="py-2.5 flex items-center justify-between gap-3 group">
                      <div className="space-y-0.5 min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-slate-900 dark:text-white bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded">
                            {climb.grade}
                          </span>
                          <span className="text-xs font-bold text-slate-900 dark:text-white truncate">
                            {climb.routeName}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400">
                          <span>{climb.style}</span>
                          <span>·</span>
                          <span className="truncate">{club?.name || climb.clubId}</span>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <span
                          className={`text-xs font-semibold block ${
                            climb.outcome === 'Onsite'
                              ? 'text-emerald-700 dark:text-emerald-400'
                              : climb.outcome === 'Flash'
                              ? 'text-orange-700 dark:text-orange-400'
                              : climb.outcome === 'Redpoint'
                              ? 'text-amber-700 dark:text-amber-400'
                              : 'text-slate-500 dark:text-slate-400'
                          }`}
                        >
                          {climb.outcome}
                        </span>
                        <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono tabular-nums">
                          {climb.date}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <span className="text-[11px] text-slate-500 dark:text-slate-400">Candidate session log</span>
            <button
              type="button"
              onClick={() => onNavigateToTab('log')}
              className="text-xs font-semibold text-orange-600 hover:text-orange-800 dark:text-orange-400"
            >
              + Quick Log Climb
            </button>
          </div>
        </div>

        {/* NICAS Level Roadmap Summary */}
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 sm:p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-orange-600" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">NICAS Scheme Syllabus</h3>
              </div>
              <button
                type="button"
                onClick={() => onNavigateToTab('checklist')}
                className="text-xs font-semibold text-orange-600 hover:text-orange-800 dark:text-orange-400 flex items-center gap-1"
              >
                <span>Full Checklist</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-2.5 mt-3">
              {([1, 2, 3, 4, 5] as const).map(lvl => {
                const items = checklist.filter(c => c.level === lvl);
                const completed = items.filter(c => c.status === 'Completed').length;
                const pct = items.length > 0 ? Math.round((completed / items.length) * 100) : 0;
                const isCurrent = profile.currentLevel === lvl;
                const isDone = pct === 100;

                return (
                  <div
                    key={lvl}
                    onClick={() => onNavigateToTab('checklist')}
                    className={`p-2.5 sm:p-3 rounded-xl border transition-all cursor-pointer ${
                      isCurrent
                        ? 'border-orange-300 dark:border-orange-700 bg-orange-50/40 dark:bg-orange-950/20'
                        : isDone
                        ? 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40'
                        : 'border-slate-100 dark:border-slate-800/60 hover:border-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className={`text-xs font-bold truncate ${isCurrent ? 'text-orange-800 dark:text-orange-400' : 'text-slate-800 dark:text-slate-200'}`}>
                          Level {lvl}: {NICAS_LEVEL_TITLES[lvl].subtitle}
                        </span>
                        {isCurrent && (
                          <span className="text-[9px] bg-orange-100 dark:bg-orange-950 text-orange-800 dark:text-orange-400 font-semibold px-1 py-0.2 rounded shrink-0">
                            Active
                          </span>
                        )}
                      </div>
                      {isDone ? (
                        <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 flex items-center gap-1 shrink-0">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Certified
                        </span>
                      ) : (
                        <span className="text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400 shrink-0">
                          {completed}/{items.length}
                        </span>
                      )}
                    </div>
                    {/* Micro bar */}
                    <div className="h-1.5 w-full bg-slate-200/70 dark:bg-slate-700 rounded-full overflow-hidden">
                      <div
                        style={{ width: `${pct}%` }}
                        className={`h-full rounded-full ${
                          isDone ? 'bg-emerald-600' : isCurrent ? 'bg-orange-600' : 'bg-slate-400 dark:bg-slate-500'
                        }`}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
            <span>5 official NICAS Levels</span>
            <span className="font-mono">UK Accredited</span>
          </div>
        </div>
      </div>

      {/* Floating Action Button (FAB) for Quick Notes */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          type="button"
          onClick={() => setIsQuickNotesOpen(true)}
          className="relative group flex items-center gap-2 px-4 py-3 rounded-full bg-orange-600 hover:bg-orange-700 text-white shadow-xl hover:shadow-2xl transition-all cursor-pointer transform hover:scale-105 active:scale-95"
          title="Quick Training Notes"
        >
          <StickyNote className="w-5 h-5" />
          <span className="font-semibold text-xs pr-1">Quick Notes</span>
          {uncompletedNotesCount > 0 && (
            <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-[10px] font-bold rounded-full flex items-center justify-center font-mono border-2 border-white dark:border-slate-900">
              {uncompletedNotesCount}
            </span>
          )}
        </button>
      </div>

      {/* Quick Notes Slide-over Drawer */}
      <QuickNotes
        isOpen={isQuickNotesOpen}
        onClose={() => setIsQuickNotesOpen(false)}
      />
    </div>
  );
};
