import React, { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  AlertTriangle,
  Bell,
  Check,
  FileText,
  IndianRupee,
  ListTodo,
  Plus,
  TrendingUp,
  UserPlus,
  X,
} from 'lucide-react';
import { AppTab, Client, ExpenseItem, Payment, StudioSettings, TaskItem } from '../types';
import {
  formatDateShort,
  formatINR,
  getClientPending,
  getDaysPending,
  getGreeting,
} from '../utils/formatters';

interface DashboardViewProps {
  clients: Client[];
  payments: Payment[];
  tasks: TaskItem[];
  expenses: ExpenseItem[];
  settings: StudioSettings;
  onNavigate: (tab: AppTab) => void;
  onOpenModal: (modal: 'client' | 'payment' | 'invoice' | 'task') => void;
  onToggleTaskDone: (taskId: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  clients,
  payments,
  tasks,
  expenses,
  settings,
  onNavigate,
  onOpenModal,
  onToggleTaskDone,
}) => {
  const [notifOpen, setNotifOpen] = useState(false);
  const [hoveredSegment, setHoveredSegment] = useState<'collected' | 'pending' | 'expenses' | null>(
    null
  );

  const metrics = useMemo(() => {
    const totalBilled = clients.reduce((sum, c) => sum + c.totalAmount, 0);
    const totalCollected = clients.reduce((sum, c) => sum + c.paidAmount, 0);
    const totalPending = clients.reduce((sum, c) => sum + getClientPending(c), 0);
    const pendingClients = clients.filter((c) => getClientPending(c) > 0);
    const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
    const netProfit = totalCollected - totalExpenses;
    const collectionPct = totalBilled > 0 ? Math.round((totalCollected / totalBilled) * 100) : 0;

    return {
      totalBilled,
      totalCollected,
      totalPending,
      pendingClients,
      totalExpenses,
      netProfit,
      collectionPct,
    };
  }, [clients, expenses]);

  const activeTasks = useMemo(() => {
    return tasks.filter((t) => t.stage !== 'done').slice(0, 3);
  }, [tasks]);

  const notifications = useMemo(() => {
    const overdueAlerts = metrics.pendingClients
      .filter((c) => getDaysPending(c.pendingSince) > 3)
      .map((c) => ({
        id: `n-${c.id}`,
        title: `${c.name} overdue ${getDaysPending(c.pendingSince)}d`,
        detail: `${formatINR(getClientPending(c))} pending`,
        target: 'payments' as AppTab,
        urgent: true,
      }));
    const highTasks = tasks
      .filter((t) => t.stage !== 'done' && t.priority === 'high')
      .map((t) => ({
        id: `n-${t.id}`,
        title: t.title,
        detail: `Due ${formatDateShort(t.deadline)}`,
        target: 'tasks' as AppTab,
        urgent: false,
      }));
    return [...overdueAlerts, ...highTasks];
  }, [metrics.pendingClients, tasks]);

  const sparklinePath = useMemo(() => {
    if (payments.length === 0) {
      return 'M 2 38 L 94 38';
    }
    const recent = [...payments].slice(0, 6).reverse();
    const maxVal = Math.max(1, ...recent.map((p) => p.amount));
    const pts = recent.map((p, idx) => {
      const x = recent.length === 1 ? 94 : 2 + (idx / (recent.length - 1)) * 92;
      const y = 38 - (p.amount / maxVal) * 32;
      return { x, y };
    });
    if (pts.length === 1) {
      return `M 2 38 L 94 ${pts[0].y}`;
    }
    return pts
      .map((pt, i) => `${i === 0 ? 'M' : 'L'} ${pt.x.toFixed(1)} ${pt.y.toFixed(1)}`)
      .join(' ');
  }, [payments]);

  const radius = 60;
  const circumference = 2 * Math.PI * radius;
  const chartVolume = metrics.totalCollected + metrics.totalPending + metrics.totalExpenses;
  const hasVolume = chartVolume > 0;
  const collectedLen = hasVolume ? (metrics.totalCollected / chartVolume) * circumference : 0;
  const pendingLen = hasVolume ? (metrics.totalPending / chartVolume) * circumference : 0;
  const expensesLen = hasVolume ? (metrics.totalExpenses / chartVolume) * circumference : 0;

  const clientMap = useMemo(() => {
    const m = new Map<string, Client>();
    clients.forEach((c) => m.set(c.id, c));
    return m;
  }, [clients]);

  const activeCenterLabel = !hasVolume
    ? { title: 'Net Profit', value: formatINR(0) }
    : hoveredSegment === 'collected'
      ? { title: 'Collected', value: formatINR(metrics.totalCollected) }
      : hoveredSegment === 'pending'
        ? { title: 'Pending', value: formatINR(metrics.totalPending) }
        : hoveredSegment === 'expenses'
          ? { title: 'Expenses', value: formatINR(metrics.totalExpenses) }
          : { title: 'Net Profit', value: formatINR(metrics.netProfit) };

  return (
    <div className="space-y-6">
      {/* Top Executive Header (Name & Company only — no portrait image) */}
      <header className="flex items-center justify-between gap-4">
        <div className="min-w-0 space-y-0.5">
          <p className="text-xs font-medium text-slate-500 truncate">
            {settings.companyName} · {settings.adminTitle}
          </p>
          <h1 className="font-display text-2xl sm:text-[28px] font-bold tracking-tight text-[#0F172A] truncate">
            {getGreeting()}, {settings.adminName}
          </h1>
        </div>

        {/* Notification Bell */}
        <div className="relative shrink-0">
          <button
            type="button"
            onClick={() => setNotifOpen((prev) => !prev)}
            aria-label="Notifications"
            className="w-11 h-11 rounded-[8px] border border-slate-200 bg-white hover:bg-slate-50 flex items-center justify-center text-[#0F172A] transition-colors duration-150 ease-out cursor-pointer relative"
          >
            <Bell className="w-5 h-5" strokeWidth={1.75} />
            {notifications.length > 0 && (
              <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-red-600" />
            )}
          </button>

          <AnimatePresence>
            {notifOpen && (
              <motion.div
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 6 }}
                transition={{ duration: 0.16, ease: 'easeOut' }}
                className="absolute right-0 mt-2 w-80 surface-card p-3 z-50 shadow-lg"
              >
                <div className="flex items-center justify-between pb-2.5 border-b border-slate-200">
                  <h2 className="font-display text-sm font-bold text-[#0F172A]">
                    Alerts ({notifications.length})
                  </h2>
                  <button
                    type="button"
                    onClick={() => setNotifOpen(false)}
                    className="w-7 h-7 rounded-[6px] hover:bg-slate-100 flex items-center justify-center text-slate-500 cursor-pointer"
                  >
                    <X className="w-4 h-4" strokeWidth={1.75} />
                  </button>
                </div>
                <div className="divide-y divide-slate-100 max-h-64 overflow-y-auto">
                  {notifications.length === 0 ? (
                    <p className="text-xs text-slate-500 py-5 text-center">
                      No overdue payments or urgent deadlines.
                    </p>
                  ) : (
                    notifications.map((n) => (
                      <button
                        key={n.id}
                        type="button"
                        onClick={() => {
                          setNotifOpen(false);
                          onNavigate(n.target);
                        }}
                        className="w-full text-left py-2.5 px-2 hover:bg-slate-50 rounded-[8px] transition-colors duration-150 flex items-start gap-2.5 cursor-pointer"
                      >
                        <AlertTriangle
                          className={`w-4 h-4 mt-0.5 shrink-0 ${
                            n.urgent ? 'text-red-600' : 'text-amber-600'
                          }`}
                          strokeWidth={1.75}
                        />
                        <div className="min-w-0 space-y-0.5">
                          <p className="text-xs font-semibold text-[#0F172A] truncate">{n.title}</p>
                          <p className="text-[11px] text-slate-500">{n.detail}</p>
                        </div>
                      </button>
                    ))
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </header>

      {/* Section 1: Unified Financial Overview Surface (Solo Owner Metrics, 1px Dividers) */}
      <section className="surface-card overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-slate-200">
          {/* Total Billed Revenue */}
          <div
            onClick={() => onNavigate('reports')}
            className="p-5 sm:p-6 cursor-pointer hover:bg-slate-50/70 transition-colors duration-150 flex items-start justify-between gap-4"
          >
            <div className="space-y-1">
              <p className="text-xs font-medium text-slate-500">Total Contract Revenue</p>
              <p className="font-display text-3xl sm:text-4xl font-bold text-[#0F172A] tabular-nums">
                {formatINR(metrics.totalBilled)}
              </p>
              <div className="inline-flex items-center gap-1.5 pt-1 text-xs sm:text-sm text-slate-500">
                <TrendingUp className="w-4 h-4 text-[#0F172A]" strokeWidth={1.75} />
                <span>
                  {metrics.totalBilled > 0
                    ? `${metrics.collectionPct}% collected · ${clients.length} ${
                        clients.length === 1 ? 'client' : 'clients'
                      }`
                    : 'No client contracts yet'}
                </span>
              </div>
            </div>

            <svg viewBox="0 0 96 42" className="w-24 h-11 shrink-0 mt-2">
              <path
                d={sparklinePath}
                fill="none"
                stroke={payments.length > 0 ? '#0F172A' : '#CBD5E1'}
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>

          {/* Pending Payment Metric */}
          <div
            onClick={() => onNavigate('payments')}
            className="p-5 sm:p-6 cursor-pointer hover:bg-slate-50/70 transition-colors duration-150 flex items-start justify-between gap-4"
          >
            <div className="space-y-1">
              <p className="text-xs font-medium text-slate-500">Pending Payment</p>
              <p
                className={`font-display text-3xl sm:text-4xl font-bold tabular-nums ${
                  metrics.totalPending > 0 ? 'text-red-600' : 'text-[#0F172A]'
                }`}
              >
                {formatINR(metrics.totalPending)}
              </p>
              <p className="text-xs sm:text-sm text-slate-500 pt-1">
                {metrics.pendingClients.length}{' '}
                {metrics.pendingClients.length === 1 ? 'Client Pending' : 'Clients Pending'}
              </p>
            </div>
            {metrics.totalPending > 0 && (
              <span className="px-2.5 py-1 rounded-[6px] bg-red-50 text-red-700 border border-red-200 text-xs font-semibold">
                Action Due
              </span>
            )}
          </div>
        </div>

        {/* Bottom 3-Column Summary Strip inside the same Surface */}
        <div className="border-t border-slate-200 grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-slate-200 bg-slate-50/50">
          <div
            onClick={() => onNavigate('payments')}
            className="px-5 py-3.5 sm:py-4 flex items-center justify-between sm:block sm:space-y-0.5 cursor-pointer hover:bg-slate-100/60 transition-colors duration-150"
          >
            <p className="text-xs sm:text-xs font-medium text-slate-500">Collected Payments</p>
            <p className="font-display text-base sm:text-lg font-bold text-[#0F172A] tabular-nums">
              {formatINR(metrics.totalCollected)}
            </p>
          </div>
          <div
            onClick={() => onNavigate('expenses')}
            className="px-5 py-3.5 sm:py-4 flex items-center justify-between sm:block sm:space-y-0.5 cursor-pointer hover:bg-slate-100/60 transition-colors duration-150"
          >
            <p className="text-xs sm:text-xs font-medium text-slate-500">Business Expenses</p>
            <p className="font-display text-base sm:text-lg font-bold text-[#0F172A] tabular-nums">
              {formatINR(metrics.totalExpenses)}
            </p>
          </div>
          <div
            onClick={() => onNavigate('reports')}
            className="px-5 py-3.5 sm:py-4 flex items-center justify-between sm:block sm:space-y-0.5 cursor-pointer hover:bg-slate-100/60 transition-colors duration-150"
          >
            <p className="text-xs sm:text-xs font-medium text-slate-500">Net Profit</p>
            <p
              className={`font-display text-base sm:text-lg font-bold tabular-nums ${
                metrics.netProfit > 0
                  ? 'text-emerald-700'
                  : metrics.netProfit < 0
                    ? 'text-red-600'
                    : 'text-[#0F172A]'
              }`}
            >
              {formatINR(metrics.netProfit)}
            </p>
          </div>
        </div>
      </section>

      {/* Section 2: Quick Actions */}
      <section className="space-y-3">
        <h2 className="font-display text-sm font-semibold text-[#0F172A]">Quick Actions</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <button
            type="button"
            onClick={() => onOpenModal('client')}
            className="btn-primary h-12 px-4 text-sm font-semibold inline-flex items-center justify-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" strokeWidth={1.75} />
            <span>Add Client</span>
          </button>

          <button
            type="button"
            onClick={() => onOpenModal('payment')}
            className="btn-secondary h-12 px-4 text-sm font-semibold inline-flex items-center justify-center gap-2 cursor-pointer"
          >
            <IndianRupee className="w-4 h-4" strokeWidth={1.75} />
            <span>Add Payment</span>
          </button>

          <button
            type="button"
            onClick={() => onOpenModal('invoice')}
            className="btn-secondary h-12 px-4 text-sm font-semibold inline-flex items-center justify-center gap-2 cursor-pointer"
          >
            <FileText className="w-4 h-4" strokeWidth={1.75} />
            <span>Create Invoice</span>
          </button>

          <button
            type="button"
            onClick={() => onOpenModal('task')}
            className="btn-secondary h-12 px-4 text-sm font-semibold inline-flex items-center justify-center gap-2 cursor-pointer"
          >
            <ListTodo className="w-4 h-4" strokeWidth={1.75} />
            <span>Add Task</span>
          </button>
        </div>
      </section>

      {/* Section 3: Cashflow Breakdown + Today's Tasks (Two Flat Surfaces) */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Donut Chart Surface */}
        <div className="lg:col-span-5 surface-card p-6 flex flex-col justify-between">
          <div className="flex items-start justify-between gap-2">
            <div className="space-y-0.5">
              <h2 className="font-display text-base font-bold text-[#0F172A]">
                Cashflow Breakdown
              </h2>
              <p className="text-xs text-slate-500">
                {hasVolume ? 'Hover slices to inspect' : 'Calculated from payments & expenses'}
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('reports')}
              className="text-xs font-semibold text-[#0F172A] hover:underline cursor-pointer whitespace-nowrap"
            >
              Full Report
            </button>
          </div>

          <div className="my-5 flex items-center justify-center relative">
            <svg viewBox="0 0 168 168" className="w-44 h-44 -rotate-90">
              <circle
                cx="84"
                cy="84"
                r={radius}
                fill="none"
                stroke="#F1F5F9"
                strokeWidth="18"
              />
              {hasVolume && (
                <>
                  <circle
                    cx="84"
                    cy="84"
                    r={radius}
                    fill="none"
                    stroke="#0F172A"
                    strokeWidth={hoveredSegment === 'collected' ? 22 : 18}
                    strokeDasharray={`${collectedLen} ${circumference}`}
                    strokeDashoffset={0}
                    className="transition-all duration-150 ease-out cursor-pointer"
                    onMouseEnter={() => setHoveredSegment('collected')}
                    onMouseLeave={() => setHoveredSegment(null)}
                  />
                  <circle
                    cx="84"
                    cy="84"
                    r={radius}
                    fill="none"
                    stroke="#64748B"
                    strokeWidth={hoveredSegment === 'pending' ? 22 : 18}
                    strokeDasharray={`${pendingLen} ${circumference}`}
                    strokeDashoffset={-collectedLen}
                    className="transition-all duration-150 ease-out cursor-pointer"
                    onMouseEnter={() => setHoveredSegment('pending')}
                    onMouseLeave={() => setHoveredSegment(null)}
                  />
                  <circle
                    cx="84"
                    cy="84"
                    r={radius}
                    fill="none"
                    stroke="#CBD5E1"
                    strokeWidth={hoveredSegment === 'expenses' ? 22 : 18}
                    strokeDasharray={`${expensesLen} ${circumference}`}
                    strokeDashoffset={-(collectedLen + pendingLen)}
                    className="transition-all duration-150 ease-out cursor-pointer"
                    onMouseEnter={() => setHoveredSegment('expenses')}
                    onMouseLeave={() => setHoveredSegment(null)}
                  />
                </>
              )}
            </svg>

            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none space-y-0.5">
              <span className="text-[11px] font-medium text-slate-500">
                {activeCenterLabel.title}
              </span>
              <span className="font-display text-lg font-bold text-[#0F172A] tabular-nums">
                {activeCenterLabel.value}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-slate-200 pt-2 border-t border-slate-200 text-xs">
            <button
              type="button"
              onMouseEnter={() => setHoveredSegment('collected')}
              onMouseLeave={() => setHoveredSegment(null)}
              className="text-left py-2.5 sm:p-2 hover:bg-slate-50 transition-colors cursor-pointer flex items-center justify-between sm:block sm:space-y-0.5"
            >
              <div className="flex items-center gap-1.5 text-slate-500">
                <span className="w-2 h-2 rounded-full bg-[#0F172A]" />
                <span>Collected</span>
              </div>
              <p className="font-semibold text-[#0F172A] tabular-nums">
                {formatINR(metrics.totalCollected)}
              </p>
            </button>
            <button
              type="button"
              onMouseEnter={() => setHoveredSegment('pending')}
              onMouseLeave={() => setHoveredSegment(null)}
              className="text-left py-2.5 sm:p-2 hover:bg-slate-50 transition-colors cursor-pointer flex items-center justify-between sm:block sm:space-y-0.5"
            >
              <div className="flex items-center gap-1.5 text-slate-500">
                <span className="w-2 h-2 rounded-full bg-slate-500" />
                <span>Pending</span>
              </div>
              <p className="font-semibold text-[#0F172A] tabular-nums">
                {formatINR(metrics.totalPending)}
              </p>
            </button>
            <button
              type="button"
              onMouseEnter={() => setHoveredSegment('expenses')}
              onMouseLeave={() => setHoveredSegment(null)}
              className="text-left py-2.5 sm:p-2 hover:bg-slate-50 transition-colors cursor-pointer flex items-center justify-between sm:block sm:space-y-0.5"
            >
              <div className="flex items-center gap-1.5 text-slate-500">
                <span className="w-2 h-2 rounded-full bg-slate-300" />
                <span>Expenses</span>
              </div>
              <p className="font-semibold text-[#0F172A] tabular-nums">
                {formatINR(metrics.totalExpenses)}
              </p>
            </button>
          </div>
        </div>

        {/* Today's Tasks Surface (1px Dividers, Zero nested cards) */}
        <div className="lg:col-span-7 surface-card p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-start justify-between pb-4 border-b border-slate-200">
              <div className="space-y-0.5">
                <h2 className="font-display text-base font-bold text-[#0F172A]">
                  Today&apos;s Tasks
                </h2>
                <p className="text-xs text-slate-500">Active deliverables and deadlines</p>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('tasks')}
                className="text-xs font-semibold text-[#0F172A] hover:underline cursor-pointer whitespace-nowrap"
              >
                Open Kanban
              </button>
            </div>

            {activeTasks.length === 0 ? (
              <div className="py-12 text-center space-y-3">
                <p className="text-sm text-slate-500">No pending tasks yet.</p>
                <button
                  type="button"
                  onClick={() => onOpenModal('task')}
                  className="btn-primary px-4 py-2 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" strokeWidth={1.75} />
                  <span>Add First Task</span>
                </button>
              </div>
            ) : (
              <div className="divide-y divide-slate-200">
                {activeTasks.map((task) => {
                  const client = clientMap.get(task.clientId);
                  const priorityStyle =
                    task.priority === 'high'
                      ? 'text-red-700 bg-red-50 border-red-200'
                      : task.priority === 'medium'
                        ? 'text-amber-700 bg-amber-50 border-amber-200'
                        : 'text-emerald-700 bg-emerald-50 border-emerald-200';
                  const priorityLabel =
                    task.priority === 'high'
                      ? 'High Priority'
                      : task.priority === 'medium'
                        ? 'Medium'
                        : 'Low';

                  return (
                    <div
                      key={task.id}
                      className="py-3.5 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <button
                          type="button"
                          onClick={() => onToggleTaskDone(task.id)}
                          aria-label={`Mark ${task.title} as done`}
                          className="w-6 h-6 rounded-[6px] border border-slate-300 bg-white hover:border-[#0F172A] flex items-center justify-center shrink-0 cursor-pointer transition-colors duration-150"
                        >
                          {task.stage === 'done' && (
                            <Check className="w-4 h-4 text-[#0F172A]" strokeWidth={1.75} />
                          )}
                        </button>
                        <div className="min-w-0 space-y-0.5">
                          <p className="text-sm font-semibold text-[#0F172A] truncate">
                            {task.title}
                          </p>
                          <p className="text-xs text-slate-500 truncate">
                            {client?.name ?? 'Studio'} · Due {formatDateShort(task.deadline)}
                          </p>
                        </div>
                      </div>

                      <span
                        className={`px-2 py-0.5 rounded-[6px] border text-[11px] font-semibold shrink-0 ${priorityStyle}`}
                      >
                        {priorityLabel}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <p className="text-xs text-slate-500">
              {clients.length === 0
                ? 'Start by adding your first client engagement.'
                : metrics.pendingClients.length > 0
                  ? `${metrics.pendingClients.length} pending milestones (${formatINR(
                      metrics.totalPending
                    )})`
                  : 'All client balances settled'}
            </p>
            <button
              type="button"
              onClick={() => (clients.length === 0 ? onOpenModal('client') : onNavigate('clients'))}
              className="btn-secondary px-3.5 py-2 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <UserPlus className="w-4 h-4" strokeWidth={1.75} />
              <span>{clients.length === 0 ? 'Add Client' : 'View Clients'}</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
