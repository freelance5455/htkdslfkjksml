import React from 'react';
import {
  ArrowRight,
  Clock,
  FileBarChart2,
  Landmark,
  Plus,
  Settings,
  Wallet,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  calculateOverallCommitteeTotals,
  calculateOverallLoanTotals,
  computeDashboardCardValue,
  formatDisplayDate,
  formatMoney,
} from '../engine/calculations';
import { DynamicIcon } from './DynamicIcon';

export const DashboardView: React.FC = () => {
  const { snapshot, setActiveRoute, setSettingsSection } = useApp();
  const {
    loanPersons,
    loanTransactions,
    committees,
    committeeTransactions,
    modules,
    submodules,
    fields,
    customRecords,
    dashboardCards,
    auditLogs,
    settings,
  } = snapshot;

  const loanTotals = calculateOverallLoanTotals(loanPersons, loanTransactions);
  const committeeTotals = calculateOverallCommitteeTotals(committees, committeeTransactions);

  const visibleCards = dashboardCards
    .filter((c) => c.visible && c.status === 'published')
    .sort((a, b) => a.position - b.position);

  const publishedModules = modules
    .filter((m) => m.visible && !m.archived && m.status === 'published')
    .sort((a, b) => a.position - b.position);

  // Build real recent transactions across Loan & Committee
  const recentTransactions = [
    ...loanTransactions.map((tx) => {
      const person = loanPersons.find((p) => p.id === tx.personId);
      return {
        id: tx.id,
        date: tx.date,
        updatedAt: tx.updatedAt,
        category: 'Loan',
        title: person?.name || 'Unknown Person',
        subtitle: tx.type === 'received' ? 'Loan Received' : 'Loan Repayment',
        amount: tx.amount,
        direction: tx.type === 'received' ? ('in' as const) : ('out' as const),
        route: 'loans' as const,
      };
    }),
    ...committeeTransactions.map((tx) => {
      const comm = committees.find((c) => c.id === tx.committeeId);
      return {
        id: tx.id,
        date: tx.date,
        updatedAt: tx.updatedAt,
        category: 'Committee',
        title: comm?.name || 'Committee',
        subtitle: `${tx.type === 'installment' ? 'Installment Paid' : 'Payout Received'} · ${tx.personName}`,
        amount: tx.amount,
        direction: tx.type === 'payout' ? ('in' as const) : ('out' as const),
        route: 'committees' as const,
      };
    }),
  ]
    .sort((a, b) => (b.date !== a.date ? b.date.localeCompare(a.date) : b.updatedAt.localeCompare(a.updatedAt)))
    .slice(0, 6);

  return (
    <div className="space-y-6">
      {/* Top Summary Cards (System + Dynamic Dashboard Card Builder cards) */}
      <section aria-labelledby="summary-cards-heading">
        <div className="flex items-center justify-between gap-4 mb-3">
          <h2 id="summary-cards-heading" className="font-display text-sm font-bold text-slate-700">
            Financial Summary
          </h2>
          <button
            type="button"
            onClick={() => {
              setActiveRoute('settings');
              setSettingsSection('cards');
            }}
            className="text-xs font-medium text-emerald-700 hover:text-emerald-800 cursor-pointer whitespace-nowrap"
          >
            Configure Cards
          </button>
        </div>

        <div className="grid grid-cols-2 xl:grid-cols-4 gap-3 sm:gap-4">
          {visibleCards.map((card) => {
            const computed = computeDashboardCardValue({
              card,
              loanPersons,
              loanTransactions,
              committees,
              committeeTransactions,
              customRecords,
              fields,
            });
            const isCount = card.calculation === 'count';
            return (
              <div
                key={card.id}
                className="rounded-xl border border-slate-200 bg-white p-3.5 sm:p-5 shadow-xs hover:shadow-sm transition-shadow"
                style={{ backgroundColor: settings.theme.cardColor }}
              >
                <div className="flex items-start justify-between gap-2 sm:gap-3">
                  <div className="min-w-0">
                    <div className="text-[11px] sm:text-xs font-medium text-slate-500 truncate">{card.title}</div>
                    <div className="mt-1.5 sm:mt-2 font-mono-num text-base sm:text-2xl font-bold text-slate-900 truncate">
                      {computed.error
                        ? 'Error'
                        : isCount
                          ? computed.value
                          : formatMoney(computed.value, settings)}
                    </div>
                  </div>
                  <div
                    className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg flex items-center justify-center text-white shrink-0"
                    style={{ backgroundColor: card.color }}
                  >
                    <DynamicIcon name={card.icon} className="w-4 h-4 sm:w-5 sm:h-5" />
                  </div>
                </div>
                <div className="mt-2.5 sm:mt-3 pt-2 sm:pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] sm:text-xs text-slate-500">
                  <span className="truncate">{computed.formattedHint}</span>
                  <span className="capitalize hidden sm:inline">{card.sourceType}</span>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Quick Overview Strip */}
      <section
        aria-labelledby="quick-overview-heading"
        className="rounded-xl border border-slate-200 bg-white p-4 sm:p-5"
        style={{ backgroundColor: settings.theme.cardColor }}
      >
        <div className="flex flex-wrap items-center justify-between gap-3 mb-3 sm:mb-4">
          <div>
            <h2 id="quick-overview-heading" className="font-display text-sm sm:text-base font-bold text-slate-900">
              Quick Overview
            </h2>
            <p className="text-xs text-slate-500 hidden sm:block">
              Live balances computed from saved IndexedDB transactions (Loans &amp; Committees isolated)
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveRoute('loans')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-white cursor-pointer"
              style={{ backgroundColor: settings.theme.primaryColor }}
            >
              <Plus className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Loan Entry</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveRoute('committees')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-white cursor-pointer"
              style={{ backgroundColor: settings.theme.secondaryColor }}
            >
              <Plus className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Committee Entry</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 pt-2 border-t border-slate-100">
          <div>
            <div className="text-xs text-slate-500">Loan Accounts</div>
            <div className="mt-1 font-mono-num text-lg font-bold text-slate-900">
              {loanTotals.activePeople}
            </div>
            <div className="text-xs text-slate-400">
              Opening {formatMoney(loanTotals.totalOpeningBalance, settings)}
            </div>
          </div>
          <div>
            <div className="text-xs text-slate-500">Active Committees</div>
            <div className="mt-1 font-mono-num text-lg font-bold text-slate-900">
              {committeeTotals.activeCommittees}
            </div>
            <div className="text-xs text-slate-400">
              Paid {formatMoney(committeeTotals.totalInstallmentsPaid, settings)}
            </div>
          </div>
          <div>
            <div className="text-xs text-slate-500">Committee Payouts</div>
            <div className="mt-1 font-mono-num text-lg font-bold text-emerald-700">
              {formatMoney(committeeTotals.totalPayouts, settings)}
            </div>
            <div className="text-xs text-slate-400">
              Payable {formatMoney(committeeTotals.totalPayable, settings)}
            </div>
          </div>
          <div>
            <div className="text-xs text-slate-500">Custom Records</div>
            <div className="mt-1 font-mono-num text-lg font-bold text-slate-900">
              {customRecords.filter((r) => !r.archived).length}
            </div>
            <div className="text-xs text-slate-400">
              {publishedModules.length} custom module(s)
            </div>
          </div>
        </div>
      </section>

      {/* Module Cards (Core + Dynamic Custom Modules) */}
      <section aria-labelledby="modules-heading">
        <div className="flex items-center justify-between gap-4 mb-3">
          <h2 id="modules-heading" className="font-display text-sm font-bold text-slate-700">
            Modules
          </h2>
          <button
            type="button"
            onClick={() => {
              setActiveRoute('settings');
              setSettingsSection('modules');
            }}
            className="text-xs font-medium text-emerald-700 hover:text-emerald-800 cursor-pointer"
          >
            Manage Modules
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4">
          {/* Loan Management Module Card */}
          <button
            type="button"
            onClick={() => setActiveRoute('loans')}
            className="group text-left rounded-xl border border-slate-200 bg-white p-5 hover:border-slate-300 hover:shadow-sm transition-all cursor-pointer"
          >
            <div className="flex items-center justify-between gap-3">
              <div
                className="w-11 h-11 rounded-xl flex items-center justify-center text-white"
                style={{ backgroundColor: settings.theme.loanModuleColor }}
              >
                <Wallet className="w-5 h-5" aria-hidden="true" />
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-slate-700 transition-colors" aria-hidden="true" />
            </div>
            <h3 className="mt-4 font-display text-base font-bold text-slate-900">
              Loan Management
            </h3>
            <p className="mt-1 text-xs text-slate-500">
              {loanTotals.activePeople} people · Payable {formatMoney(loanTotals.remainingPayable, settings)}
            </p>
          </button>

          {/* Committee Management Module Card */}
          <button
            type="button"
            onClick={() => setActiveRoute('committees')}
            className="group text-left rounded-xl border border-slate-200 bg-white p-5 hover:border-slate-300 hover:shadow-sm transition-all cursor-pointer"
          >
            <div className="flex items-center justify-between gap-3">
              <div
                className="w-11 h-11 rounded-xl flex items-center justify-center text-white"
                style={{ backgroundColor: settings.theme.committeeModuleColor }}
              >
                <Landmark className="w-5 h-5" aria-hidden="true" />
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-slate-700 transition-colors" aria-hidden="true" />
            </div>
            <h3 className="mt-4 font-display text-base font-bold text-slate-900">
              Committee Management
            </h3>
            <p className="mt-1 text-xs text-slate-500">
              {committeeTotals.activeCommittees} committees · Receivable {formatMoney(committeeTotals.totalReceivable, settings)}
            </p>
          </button>

          {/* Dynamic Custom Module Cards */}
          {publishedModules.map((mod) => {
            const subCount = submodules.filter(
              (s) => s.moduleId === mod.id && s.visible && !s.archived && s.status === 'published'
            ).length;
            const recCount = customRecords.filter((r) => r.moduleId === mod.id && !r.archived).length;
            return (
              <button
                key={mod.id}
                type="button"
                onClick={() => setActiveRoute(`module:${mod.id}`)}
                className="group text-left rounded-xl border border-slate-200 bg-white p-5 hover:border-slate-300 hover:shadow-sm transition-all cursor-pointer"
              >
                <div className="flex items-center justify-between gap-3">
                  <div
                    className="w-11 h-11 rounded-xl flex items-center justify-center text-white"
                    style={{ backgroundColor: mod.color }}
                  >
                    <DynamicIcon name={mod.icon} className="w-5 h-5" />
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-slate-700 transition-colors" aria-hidden="true" />
                </div>
                <h3 className="mt-4 font-display text-base font-bold text-slate-900 truncate">
                  {mod.name}
                </h3>
                <p className="mt-1 text-xs text-slate-500 truncate">
                  {subCount} submodule(s) · {recCount} record(s)
                </p>
              </button>
            );
          })}

          {/* Quick shortcut card to Reports & Builder if fewer custom modules */}
          <button
            type="button"
            onClick={() => setActiveRoute('reports')}
            className="group text-left rounded-xl border border-slate-200 bg-white p-5 hover:border-slate-300 hover:shadow-sm transition-all cursor-pointer"
          >
            <div className="flex items-center justify-between gap-3">
              <div className="w-11 h-11 rounded-xl flex items-center justify-center text-white bg-slate-800">
                <FileBarChart2 className="w-5 h-5" aria-hidden="true" />
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-slate-700 transition-colors" aria-hidden="true" />
            </div>
            <h3 className="mt-4 font-display text-base font-bold text-slate-900">
              Reports &amp; Exports
            </h3>
            <p className="mt-1 text-xs text-slate-500">
              {snapshot.reports.length} custom report(s) · CSV &amp; Print
            </p>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveRoute('settings');
              setSettingsSection('modules');
            }}
            className="group text-left rounded-xl border border-dashed border-slate-300 bg-slate-50/70 p-5 hover:border-emerald-500 hover:bg-emerald-50/30 transition-all cursor-pointer"
          >
            <div className="flex items-center justify-between gap-3">
              <div className="w-11 h-11 rounded-xl flex items-center justify-center bg-emerald-100 text-emerald-700">
                <Settings className="w-5 h-5" aria-hidden="true" />
              </div>
              <Plus className="w-4 h-4 text-emerald-700" aria-hidden="true" />
            </div>
            <h3 className="mt-4 font-display text-base font-bold text-slate-900">
              Create New Module
            </h3>
            <p className="mt-1 text-xs text-slate-500">
              Build custom tables, formulas &amp; cards in Settings
            </p>
          </button>
        </div>
      </section>

      {/* Recent Transactions & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section
          aria-labelledby="recent-tx-heading"
          className="rounded-xl border border-slate-200 bg-white overflow-hidden"
        >
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
            <h2 id="recent-tx-heading" className="font-display text-sm font-bold text-slate-900">
              Recent Financial Transactions
            </h2>
            <span className="text-xs text-slate-400">{recentTransactions.length} shown</span>
          </div>
          {recentTransactions.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500">
              No loan or committee transactions recorded yet. Add your first entry from Loan or Committee Management.
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {recentTransactions.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveRoute(item.route)}
                  className="w-full px-5 py-3.5 flex items-center justify-between gap-3 hover:bg-slate-50 text-left cursor-pointer"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-slate-900 truncate">{item.title}</div>
                    <div className="text-xs text-slate-500 truncate">
                      {item.category} · {item.subtitle} · {formatDisplayDate(item.date, settings.dateFormat)}
                    </div>
                  </div>
                  <div
                    className={`font-mono-num text-sm font-bold shrink-0 ${
                      item.direction === 'in' ? 'text-emerald-700' : 'text-slate-900'
                    }`}
                  >
                    {formatMoney(item.amount, settings)}
                  </div>
                </button>
              ))}
            </div>
          )}
        </section>

        <section
          aria-labelledby="recent-activity-heading"
          className="rounded-xl border border-slate-200 bg-white overflow-hidden"
        >
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
            <h2 id="recent-activity-heading" className="font-display text-sm font-bold text-slate-900">
              Recent Activity
            </h2>
            <button
              type="button"
              onClick={() => setActiveRoute('audit-log')}
              className="text-xs font-medium text-emerald-700 hover:text-emerald-800 cursor-pointer"
            >
              View Audit Log
            </button>
          </div>
          {auditLogs.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500">
              Activity logs will appear automatically as you create, edit, or delete records.
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {auditLogs.slice(0, 6).map((log) => (
                <div key={log.id} className="px-5 py-3.5 flex items-start gap-3">
                  <Clock className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" aria-hidden="true" />
                  <div className="min-w-0 flex-1">
                    <div className="text-sm text-slate-800 truncate">{log.summary}</div>
                    <div className="text-xs text-slate-400">
                      {log.action.replace(/_/g, ' ')} · {new Date(log.timestamp).toLocaleString()}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
