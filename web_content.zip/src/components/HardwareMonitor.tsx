import React from 'react';
import { 
  Cpu, 
  Activity, 
  Flame, 
  Battery, 
  Gauge, 
  ShieldCheck, 
  AlertTriangle, 
  Zap, 
  Lock, 
  Unlock, 
  Sliders, 
  Terminal, 
  HardDrive
} from 'lucide-react';
import { SystemMetrics, AdbStatus } from '../types';

interface HardwareMonitorProps {
  metrics: SystemMetrics;
  setMetrics: React.Dispatch<React.SetStateAction<SystemMetrics>>;
  adbStatus: AdbStatus;
  onNavigateToAdb: () => void;
  onQuickActivateAdb: () => void;
}

export const HardwareMonitor: React.FC<HardwareMonitorProps> = ({
  metrics,
  setMetrics,
  adbStatus,
  onNavigateToAdb,
  onQuickActivateAdb,
}) => {
  const isAdbActive = adbStatus.connected;
  const isAdvancedMode = metrics.monitoringMode === 'advanced_adb';

  return (
    <div className="flex-1 flex flex-col p-4 md:p-6 overflow-y-auto space-y-6">
      
      {/* Header com Chaveador de Modo: Simples vs Avançado via ADB */}
      <div className="p-4 md:p-5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start space-x-3">
            <div className={`p-2.5 rounded-lg shrink-0 ${isAdvancedMode ? 'bg-cyan-950 border border-cyan-800 text-cyan-400' : 'bg-neutral-900 border border-neutral-800 text-neutral-300'}`}>
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-sm font-bold text-white tracking-wide">
                  Monitor de Hardware: CPU & GPU
                </h2>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                  isAdvancedMode 
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-700' 
                    : 'bg-neutral-900 text-neutral-400 border border-neutral-800'
                }`}>
                  {isAdvancedMode ? 'MODO AVANÇADO (ADB)' : 'MODO SIMPLES'}
                </span>
              </div>
              <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
                Escolha entre o monitoramento básico do sistema e a telemetria profunda com leitura de frequências de GPU e núcleos de CPU liberada exclusivamente via ADB.
              </p>
            </div>
          </div>

          {/* Segmented Switcher for Simple vs Advanced */}
          <div className="flex items-center p-1 rounded-lg bg-neutral-900 border border-neutral-800 shrink-0">
            <button
              onClick={() => setMetrics(prev => ({ ...prev, monitoringMode: 'simple' }))}
              className={`px-3 py-1.5 text-xs font-mono font-medium rounded-md transition ${
                !isAdvancedMode
                  ? 'bg-white text-black font-bold shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Monitor Simples
            </button>
            <button
              onClick={() => setMetrics(prev => ({ ...prev, monitoringMode: 'advanced_adb' }))}
              className={`px-3 py-1.5 text-xs font-mono font-medium rounded-md transition flex items-center space-x-1.5 ${
                isAdvancedMode
                  ? 'bg-cyan-500 text-black font-bold shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              {isAdbActive ? <Unlock className="w-3 h-3" /> : <Lock className="w-3 h-3 text-amber-400" />}
              <span>Avançado (ADB)</span>
            </button>
          </div>
        </div>

        {/* Status explanation strip */}
        <div className="p-3 rounded-lg bg-black/50 border border-neutral-800/80 text-[11px] font-mono flex items-center justify-between">
          <div className="flex items-center space-x-2 text-neutral-400">
            <Activity className="w-3.5 h-3.5 text-emerald-400" />
            <span>
              {isAdvancedMode 
                ? (isAdbActive 
                    ? "Telemetria de GPU (Adreno/Mali) e Clocks por Núcleo de CPU Ativos via Shell UID 2000."
                    : "Modo Avançado selecionado, mas requer Ativação ADB para dados de GPU.")
                : "Modo Simples: Dados padrão do Android (Bateria, RAM geral e Temperatura aproximada)."}
            </span>
          </div>
          {!isAdbActive && isAdvancedMode && (
            <button
              onClick={onQuickActivateAdb}
              className="px-2.5 py-1 rounded bg-amber-500 text-black font-bold text-[10px] hover:bg-amber-400 transition whitespace-nowrap ml-2"
            >
              Ativar ADB Agora
            </button>
          )}
        </div>
      </div>

      {/* MODO SIMPLES DE MONITORAMENTO */}
      {!isAdvancedMode ? (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Card 1: SoC Temperature */}
            <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between text-neutral-400 text-xs">
                <span className="flex items-center gap-1.5">
                  <Flame className="w-4 h-4 text-amber-400" /> Temperatura Geral
                </span>
                <span className="font-mono text-emerald-400 text-[11px]">Normal</span>
              </div>
              <div className="text-2xl font-bold font-mono text-white tabular-nums">
                {metrics.cpuTemp.toFixed(1)} °C
              </div>
              <div className="w-full bg-neutral-900 h-2 rounded-full overflow-hidden border border-neutral-800">
                <div 
                  className="bg-amber-400 h-full transition-all duration-300"
                  style={{ width: `${Math.min(100, (metrics.cpuTemp / 70) * 100)}%` }}
                />
              </div>
              <span className="text-[10px] text-neutral-500 font-mono block">Zona térmica do chassi/SoC</span>
            </div>

            {/* Card 2: Battery Temp & Level */}
            <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between text-neutral-400 text-xs">
                <span className="flex items-center gap-1.5">
                  <Battery className="w-4 h-4 text-emerald-400" /> Bateria & Carga
                </span>
                <span className="font-mono text-white font-bold text-xs">{metrics.batteryLevel}%</span>
              </div>
              <div className="text-2xl font-bold font-mono text-white tabular-nums">
                {metrics.batteryTemp.toFixed(1)} °C
              </div>
              <div className="w-full bg-neutral-900 h-2 rounded-full overflow-hidden border border-neutral-800">
                <div 
                  className="bg-emerald-400 h-full transition-all duration-300"
                  style={{ width: `${Math.min(100, (metrics.batteryTemp / 50) * 100)}%` }}
                />
              </div>
              <span className="text-[10px] text-neutral-500 font-mono block">Monitor de ciclo e saúde térmica</span>
            </div>

            {/* Card 3: RAM Usage */}
            <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2">
              <div className="flex items-center justify-between text-neutral-400 text-xs">
                <span className="flex items-center gap-1.5">
                  <HardDrive className="w-4 h-4 text-cyan-400" /> Memória RAM do Sistema
                </span>
                <span className="font-mono text-neutral-300 text-[11px]">{((metrics.ramUsedGb / metrics.ramTotalGb) * 100).toFixed(0)}%</span>
              </div>
              <div className="text-2xl font-bold font-mono text-white tabular-nums">
                {metrics.ramUsedGb} / {metrics.ramTotalGb} GB
              </div>
              <div className="w-full bg-neutral-900 h-2 rounded-full overflow-hidden border border-neutral-800">
                <div 
                  className="bg-cyan-400 h-full transition-all duration-300"
                  style={{ width: `${(metrics.ramUsedGb / metrics.ramTotalGb) * 100}%` }}
                />
              </div>
              <span className="text-[10px] text-neutral-500 font-mono block">Memória alocada em apps e cache</span>
            </div>

          </div>

          {/* Simple FPS Card */}
          <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Gauge className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold font-mono text-white">Taxa de Quadros de Renderização (FPS)</span>
              </div>
              <span className="text-lg font-bold font-mono text-emerald-400 tabular-nums">{metrics.fps} FPS</span>
            </div>
            {/* Sparkline */}
            <div className="h-10 w-full flex items-end gap-1 bg-black/60 p-1.5 rounded border border-neutral-800">
              {metrics.fpsHistory.map((val, i) => (
                <div 
                  key={i} 
                  className="flex-1 bg-emerald-400 rounded-t-sm transition-all duration-150"
                  style={{ height: `${Math.min(100, (val / 120) * 100)}%` }}
                />
              ))}
            </div>
          </div>
        </div>
      ) : (
        /* MODO AVANÇADO VIA ADB (CPU E GPU PROFUNDAS) */
        <div className="space-y-6">
          
          {/* ADB Guard Warning if not activated */}
          {!isAdbActive ? (
            <div className="p-6 rounded-xl bg-neutral-950 border border-amber-800/60 flex flex-col items-center justify-center text-center space-y-3">
              <div className="p-3 rounded-full bg-amber-950 border border-amber-700 text-amber-400">
                <Lock className="w-6 h-6" />
              </div>
              <div className="max-w-md space-y-1">
                <h3 className="text-sm font-bold text-white">Telemetria de GPU e Clocks Bloqueados pelo Android</h3>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  O Android proíbe aplicativos normais de ler os nós de sistema de GPU (<code className="text-neutral-300 font-mono">/sys/class/kgsl</code>) e os clocks por núcleo (<code className="text-neutral-300 font-mono">/sys/devices/system/cpu/cpufreq</code>). Ative o ADB sem root para liberar esses dados na hora!
                </p>
              </div>
              <div className="flex items-center space-x-3 pt-2">
                <button
                  onClick={onQuickActivateAdb}
                  className="px-4 py-2 rounded bg-white text-black font-bold text-xs hover:bg-neutral-200 transition shadow flex items-center space-x-1.5"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Simular Ativação ADB Agora</span>
                </button>
                <button
                  onClick={onNavigateToAdb}
                  className="px-4 py-2 rounded bg-neutral-900 border border-neutral-700 text-xs text-white hover:bg-neutral-800 transition"
                >
                  Ver Scripts de Ativação
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* SEÇÃO 1: MONITOR DE GPU (ADRENO / MALI) */}
              <div className="p-5 rounded-xl bg-neutral-950 border border-cyan-800/40 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-neutral-800 pb-3 gap-2">
                  <div className="flex items-center space-x-2">
                    <Zap className="w-4 h-4 text-cyan-400" />
                    <div>
                      <h3 className="text-xs font-mono font-bold text-white uppercase tracking-wider">
                        Telemetria de GPU (Placa Gráfica)
                      </h3>
                      <span className="text-[10px] text-neutral-400 font-mono">
                        {metrics.gpuModel} · Renderizador: {metrics.gpuRenderer}
                      </span>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-700">
                    Lido via ADB: /sys/class/kgsl/kgsl-3d0
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* GPU Usage */}
                  <div className="p-3.5 rounded-lg bg-black border border-neutral-800 space-y-1.5">
                    <div className="flex justify-between text-xs text-neutral-400">
                      <span>Carga da GPU:</span>
                      <span className="font-mono text-cyan-400 font-bold tabular-nums">{metrics.gpuUsage}%</span>
                    </div>
                    <div className="text-xl font-bold font-mono text-white tabular-nums">
                      {metrics.gpuUsage}%
                    </div>
                    <div className="w-full bg-neutral-900 h-2 rounded-full overflow-hidden border border-neutral-800">
                      <div 
                        className="bg-cyan-400 h-full transition-all duration-300"
                        style={{ width: `${metrics.gpuUsage}%` }}
                      />
                    </div>
                  </div>

                  {/* GPU Frequency */}
                  <div className="p-3.5 rounded-lg bg-black border border-neutral-800 space-y-1.5">
                    <div className="flex justify-between text-xs text-neutral-400">
                      <span>Frequência da GPU:</span>
                      <span className="font-mono text-neutral-300 font-bold tabular-nums">{metrics.gpuFreqMhz} MHz</span>
                    </div>
                    <div className="text-xl font-bold font-mono text-white tabular-nums">
                      {metrics.gpuFreqMhz} <span className="text-xs text-neutral-400 font-normal">/ {metrics.gpuMaxFreqMhz} MHz</span>
                    </div>
                    <div className="w-full bg-neutral-900 h-2 rounded-full overflow-hidden border border-neutral-800">
                      <div 
                        className="bg-emerald-400 h-full transition-all duration-300"
                        style={{ width: `${(metrics.gpuFreqMhz / metrics.gpuMaxFreqMhz) * 100}%` }}
                      />
                    </div>
                  </div>

                  {/* GPU Temperature */}
                  <div className="p-3.5 rounded-lg bg-black border border-neutral-800 space-y-1.5">
                    <div className="flex justify-between text-xs text-neutral-400">
                      <span>Temperatura da GPU:</span>
                      <span className="font-mono text-amber-400 font-bold tabular-nums">{metrics.gpuTemp.toFixed(1)} °C</span>
                    </div>
                    <div className="text-xl font-bold font-mono text-white tabular-nums">
                      {metrics.gpuTemp.toFixed(1)} °C
                    </div>
                    <div className="w-full bg-neutral-900 h-2 rounded-full overflow-hidden border border-neutral-800">
                      <div 
                        className="bg-amber-400 h-full transition-all duration-300"
                        style={{ width: `${Math.min(100, (metrics.gpuTemp / 70) * 100)}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* SEÇÃO 2: MONITOR DE CPU POR NÚCLEOS (OCTA-CORE CLUSTERS) */}
              <div className="p-5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-neutral-800 pb-3 gap-2">
                  <div className="flex items-center space-x-2">
                    <Cpu className="w-4 h-4 text-emerald-400" />
                    <div>
                      <h3 className="text-xs font-mono font-bold text-white uppercase tracking-wider">
                        Telemetria de CPU por Núcleo (Clocks em Tempo Real)
                      </h3>
                      <span className="text-[10px] text-neutral-400 font-mono">
                        Governador: {metrics.governor} · Throttling: {metrics.throttling ? 'ATIVO' : 'DESATIVADO'}
                      </span>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-700">
                    Lido via ADB: /sys/devices/system/cpu/cpufreq
                  </span>
                </div>

                {/* 8 Cores Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                  {metrics.cpuCores.map(core => {
                    const isPrime = core.cluster === 'prime';
                    const isPerf = core.cluster === 'performance';
                    const clusterColor = isPrime ? 'text-rose-400' : isPerf ? 'text-cyan-400' : 'text-emerald-400';
                    const barColor = isPrime ? 'bg-rose-500' : isPerf ? 'bg-cyan-400' : 'bg-emerald-400';

                    return (
                      <div key={core.id} className="p-3 rounded-lg bg-black border border-neutral-800 space-y-1.5">
                        <div className="flex justify-between items-center text-[11px] font-mono">
                          <span className="font-bold text-white">Núcleo {core.id}</span>
                          <span className={`text-[9px] uppercase px-1 rounded ${isPrime ? 'bg-rose-950 text-rose-300' : isPerf ? 'bg-cyan-950 text-cyan-300' : 'bg-emerald-950 text-emerald-300'}`}>
                            {core.cluster}
                          </span>
                        </div>
                        <div className="text-base font-bold font-mono text-white tabular-nums">
                          {core.freqMhz} <span className="text-[10px] text-neutral-400 font-normal">MHz</span>
                        </div>
                        <div className="w-full bg-neutral-900 h-1.5 rounded-full overflow-hidden">
                          <div 
                            className={`h-full transition-all duration-300 ${barColor}`}
                            style={{ width: `${(core.freqMhz / core.maxFreqMhz) * 100}%` }}
                          />
                        </div>
                        <div className="flex justify-between text-[10px] text-neutral-500 font-mono">
                          <span>Uso: {core.usagePercent}%</span>
                          <span>Max: {core.maxFreqMhz}MHz</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </>
          )}

        </div>
      )}

    </div>
  );
};
