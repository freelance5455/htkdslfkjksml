import React, { useState } from 'react';
import { PoketSafeData, Transaction, Commitment, Debt, ExpenseCategory } from '../types/budget';
import { Plus, Trash2, ArrowUpRight, ArrowDownLeft, Shield, Clock, Coffee, Utensils, Bus, ShoppingCart, Receipt, MoreHorizontal, CreditCard } from 'lucide-react';

interface TransactionsPageProps {
  data: PoketSafeData;
  onAddExpense: (title: string, amount: number, category: ExpenseCategory) => void;
  onAddIncome: (title: string, amount: number) => void;
  onAddCommitment: (name: string, amount: number, dueDate: string) => void;
  onAddDebt: (person: string, amount: number, type: 'i_owe' | 'they_owe', reason: string) => void;
  onDeleteTransaction: (id: string) => void;
  onOpenLoanModal?: () => void;
}

export const TransactionsPage: React.FC<TransactionsPageProps> = ({
  data,
  onAddExpense,
  onAddIncome,
  onAddCommitment,
  onAddDebt,
  onDeleteTransaction,
  onOpenLoanModal,
}) => {
  // Mode selector for simple entry forms: 'expense' | 'income' | 'commitment' | 'debt'
  const [activeForm, setActiveForm] = useState<'none' | 'expense' | 'income' | 'commitment' | 'debt'>('none');

  // Expense form
  const [expTitle, setExpTitle] = useState('');
  const [expAmount, setExpAmount] = useState('');
  const [expCategory, setExpCategory] = useState<ExpenseCategory>('food');

  // Income form
  const [incTitle, setIncTitle] = useState('');
  const [incAmount, setIncAmount] = useState('');

  // Commitment form
  const [commName, setCommName] = useState('');
  const [commAmount, setCommAmount] = useState('');
  const [commDueDate, setCommDueDate] = useState('15th Nov');

  // Debt form
  const [debtPerson, setDebtPerson] = useState('');
  const [debtAmount, setDebtAmount] = useState('');
  const [debtType, setDebtType] = useState<'i_owe' | 'they_owe'>('i_owe');
  const [debtReason, setDebtReason] = useState('');

  const handleCreateExpense = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(expAmount);
    if (!expTitle.trim() || isNaN(amt) || amt <= 0) return;
    onAddExpense(expTitle.trim(), amt, expCategory);
    setExpTitle('');
    setExpAmount('');
    setActiveForm('none');
  };

  const handleCreateIncome = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(incAmount);
    if (!incTitle.trim() || isNaN(amt) || amt <= 0) return;
    onAddIncome(incTitle.trim(), amt);
    setIncTitle('');
    setIncAmount('');
    setActiveForm('none');
  };

  const handleCreateCommitment = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(commAmount);
    if (!commName.trim() || isNaN(amt) || amt <= 0) return;
    onAddCommitment(commName.trim(), amt, commDueDate.trim() || 'Next cycle');
    setCommName('');
    setCommAmount('');
    setActiveForm('none');
  };

  const handleCreateDebt = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(debtAmount);
    if (!debtPerson.trim() || isNaN(amt) || amt <= 0) return;
    onAddDebt(debtPerson.trim(), amt, debtType, debtReason.trim() || 'Split bill');
    setDebtPerson('');
    setDebtAmount('');
    setDebtReason('');
    setActiveForm('none');
  };

  return (
    <div className="space-y-5 pb-6">
      {/* 4 FAST ACTION BUTTONS */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <button
          onClick={() => setActiveForm(activeForm === 'expense' ? 'none' : 'expense')}
          className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
            activeForm === 'expense'
              ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Plus className="w-3.5 h-3.5 text-rose-400" />
          <span>Add Expense</span>
        </button>

        <button
          onClick={() => setActiveForm(activeForm === 'income' ? 'none' : 'income')}
          className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
            activeForm === 'income'
              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Plus className="w-3.5 h-3.5 text-emerald-400" />
          <span>Add Income</span>
        </button>

        <button
          onClick={() => setActiveForm(activeForm === 'commitment' ? 'none' : 'commitment')}
          className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
            activeForm === 'commitment'
              ? 'bg-blue-500/20 text-blue-300 border-blue-500/40'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Plus className="w-3.5 h-3.5 text-blue-400" />
          <span>Add Commitment</span>
        </button>

        <button
          onClick={() => setActiveForm(activeForm === 'debt' ? 'none' : 'debt')}
          className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
            activeForm === 'debt'
              ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Plus className="w-3.5 h-3.5 text-amber-400" />
          <span>Add Debt</span>
        </button>
      </div>

      {/* LOAN TEMPLATES QUICK LAUNCH BANNER */}
      {onOpenLoanModal && (
        <div 
          onClick={onOpenLoanModal}
          className="p-3.5 rounded-2xl bg-gradient-to-r from-blue-950/70 to-purple-950/70 border border-blue-500/30 hover:border-blue-400/60 cursor-pointer transition-all flex items-center justify-between shadow-md group"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
              <CreditCard className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 font-bold text-white text-xs">
                <span>Create Loan / Installment Plan</span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-blue-500/20 text-blue-300">
                  Templates: 1–36 Mo
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Auto-calculate monthly commitments for SPayLater, laptops, or devices.
              </p>
            </div>
          </div>
          <span className="text-xs text-blue-400 font-bold group-hover:translate-x-0.5 transition-transform">
            →
          </span>
        </div>
      )}

      {/* FORM: ADD EXPENSE */}
      {activeForm === 'expense' && (
        <form onSubmit={handleCreateExpense} className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 text-xs">
          <div className="flex items-center justify-between font-semibold text-white">
            <span>Log Daily Expense</span>
            <button type="button" onClick={() => setActiveForm('none')} className="text-slate-400 hover:text-white">Cancel</button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div>
              <label className="block text-slate-400 mb-1">What did you spend on?</label>
              <input
                type="text"
                placeholder="e.g. Coffee, Lunch, Grab"
                value={expTitle}
                onChange={e => setExpTitle(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                autoFocus
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Amount (RM)</label>
              <input
                type="number"
                step="0.01"
                placeholder="0.00"
                value={expAmount}
                onChange={e => setExpAmount(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono"
              />
            </div>
          </div>
          <div className="flex flex-wrap gap-1 pt-1">
            {(['food', 'coffee', 'transport', 'groceries', 'bills', 'other'] as ExpenseCategory[]).map(cat => (
              <button
                key={cat}
                type="button"
                onClick={() => setExpCategory(cat)}
                className={`px-2.5 py-1 rounded-md capitalize transition-colors ${
                  expCategory === cat
                    ? 'bg-emerald-500 text-slate-950 font-bold'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
          <button
            type="submit"
            className="w-full py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg transition-colors mt-2"
          >
            Record Expense
          </button>
        </form>
      )}

      {/* FORM: ADD INCOME */}
      {activeForm === 'income' && (
        <form onSubmit={handleCreateIncome} className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 text-xs">
          <div className="flex items-center justify-between font-semibold text-white">
            <span>Add Income</span>
            <button type="button" onClick={() => setActiveForm('none')} className="text-slate-400 hover:text-white">Cancel</button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div>
              <label className="block text-slate-400 mb-1">Source / Title</label>
              <input
                type="text"
                placeholder="e.g. Salary, Freelance, Allowance"
                value={incTitle}
                onChange={e => setIncTitle(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                autoFocus
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Amount (RM)</label>
              <input
                type="number"
                step="0.01"
                placeholder="0.00"
                value={incAmount}
                onChange={e => setIncAmount(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono"
              />
            </div>
          </div>
          <button
            type="submit"
            className="w-full py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-lg transition-colors mt-2"
          >
            Add To Current Money
          </button>
        </form>
      )}

      {/* FORM: ADD COMMITMENT */}
      {activeForm === 'commitment' && (
        <form onSubmit={handleCreateCommitment} className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 text-xs">
          <div className="flex items-center justify-between font-semibold text-white">
            <span>Add Recurring Commitment</span>
            <button type="button" onClick={() => setActiveForm('none')} className="text-slate-400 hover:text-white">Cancel</button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <div className="sm:col-span-2">
              <label className="block text-slate-400 mb-1">Commitment Name</label>
              <input
                type="text"
                placeholder="e.g. SPayLater, Phone bill, Internet bill, Rent"
                value={commName}
                onChange={e => setCommName(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
                autoFocus
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Amount (RM)</label>
              <input
                type="number"
                step="0.01"
                placeholder="0.00"
                value={commAmount}
                onChange={e => setCommAmount(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono"
              />
            </div>
          </div>
          <div>
            <label className="block text-slate-400 mb-1">Due Date</label>
            <input
              type="text"
              placeholder="e.g. 15th of every month, Every Friday, Last day of month"
              value={commDueDate}
              onChange={e => setCommDueDate(e.target.value)}
              className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
            />
          </div>
          <button
            type="submit"
            className="w-full py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg transition-colors mt-2"
          >
            Save Commitment & Ring-Fence Funds
          </button>
        </form>
      )}

      {/* FORM: ADD DEBT */}
      {activeForm === 'debt' && (
        <form onSubmit={handleCreateDebt} className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 text-xs">
          <div className="flex items-center justify-between font-semibold text-white">
            <span>Add Debt / IOU</span>
            <button type="button" onClick={() => setActiveForm('none')} className="text-slate-400 hover:text-white">Cancel</button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div>
              <label className="block text-slate-400 mb-1">Direction</label>
              <select
                value={debtType}
                onChange={e => setDebtType(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
              >
                <option value="i_owe">I Owe Them (Deducted from Safe To Spend)</option>
                <option value="they_owe">They Owe Me (Collectible)</option>
              </select>
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Person's Name</label>
              <input
                type="text"
                placeholder="e.g. Amir, Sarah"
                value={debtPerson}
                onChange={e => setDebtPerson(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div>
              <label className="block text-slate-400 mb-1">Amount (RM)</label>
              <input
                type="number"
                step="0.01"
                placeholder="0.00"
                value={debtAmount}
                onChange={e => setDebtAmount(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1">Reason / Note</label>
              <input
                type="text"
                placeholder="e.g. Hotpot dinner split"
                value={debtReason}
                onChange={e => setDebtReason(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
              />
            </div>
          </div>
          <button
            type="submit"
            className="w-full py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg transition-colors mt-2"
          >
            Record Debt
          </button>
        </form>
      )}

      {/* ALL TRANSACTIONS LOG */}
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-5 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-semibold text-white">Transaction History</h3>
            <p className="text-xs text-slate-400">{data.transactions.length} items logged</p>
          </div>
        </div>

        {data.transactions.length === 0 ? (
          <div className="py-12 text-center">
            <div className="w-12 h-12 rounded-full bg-slate-800 text-slate-400 flex items-center justify-center mx-auto mb-3">
              <Receipt className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-semibold text-white">No Transactions Yet</h4>
            <p className="text-xs text-slate-400 max-w-xs mx-auto mt-1 mb-4">
              Your expense history and income records will appear here in chronological order.
            </p>
            <button
              onClick={() => setActiveForm('expense')}
              className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs inline-flex items-center gap-1.5 transition-colors shadow-md"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>Add Your First Expense</span>
            </button>
          </div>
        ) : (
          <div className="divide-y divide-slate-800">
            {data.transactions.map(item => (
              <div
                key={item.id}
                className="py-3 flex items-center justify-between gap-3 group hover:bg-slate-800/40 px-2 rounded-lg transition-colors text-xs"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                      item.type === 'income'
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {item.type === 'income' ? <ArrowDownLeft className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                  </div>
                  <div className="min-w-0">
                    <p className="font-medium text-white truncate">{item.title}</p>
                    <span className="text-[11px] text-slate-500 capitalize">
                      {item.type === 'income' ? 'Income' : item.category} · {new Date(item.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <span
                    className={`font-mono font-bold tabular-nums text-sm ${
                      item.type === 'income' ? 'text-emerald-400' : 'text-slate-200'
                    }`}
                  >
                    {item.type === 'income' ? '+' : '-'}RM {item.amount.toFixed(0)}
                  </span>
                  <button
                    onClick={() => onDeleteTransaction(item.id)}
                    className="opacity-0 group-hover:opacity-100 p-1 text-slate-500 hover:text-rose-400 transition-opacity"
                    title="Delete"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
