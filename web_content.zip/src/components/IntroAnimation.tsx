import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Volume2,
  VolumeX,
  RotateCcw,
  ArrowRight,
  Sparkles,
  Image as ImageIcon,
  MapPin,
  Tractor,
  Maximize2,
  Minimize2,
  CheckCircle2,
  ShieldCheck,
  TrendingUp,
  CloudSun,
} from 'lucide-react';
import { Language } from '../types';
import { playDawnChime, playKeyTap } from '../utils/audio';
import kilimoFarmImg from '../assets/images/kilimo_real_farm_1789987201114.jpg';

interface IntroAnimationProps {
  language: Language;
  onComplete: () => void;
  onSkipToLogin: () => void;
}

export default function IntroAnimation({
  language,
  onComplete,
  onSkipToLogin,
}: IntroAnimationProps) {
  const [soundEnabled, setSoundEnabled] = useState(false);
  const [animationKey, setAnimationKey] = useState(0);
  const [isPhotoExpanded, setIsPhotoExpanded] = useState(false);
  const [activeTab, setActiveTab] = useState<'all' | 'photo'>('all');

  useEffect(() => {
    if (soundEnabled) {
      playDawnChime();
    }
  }, [soundEnabled, animationKey]);

  const handleRestart = (e: React.MouseEvent) => {
    e.stopPropagation();
    playKeyTap();
    setAnimationKey((prev) => prev + 1);
  };

  const toggleSound = (e: React.MouseEvent) => {
    e.stopPropagation();
    const next = !soundEnabled;
    setSoundEnabled(next);
    if (next) {
      playDawnChime();
    }
  };

  const toggleExpandPhoto = (e: React.MouseEvent) => {
    e.stopPropagation();
    playKeyTap();
    setIsPhotoExpanded(!isPhotoExpanded);
  };

  const isSw = language === 'sw';

  return (
    <div
      id="intro-animation-container"
      onClick={onComplete}
      className="relative w-full h-full overflow-hidden select-none cursor-pointer flex flex-col items-center justify-between"
      style={{
        background: '#0B1B13',
      }}
    >
      {/* 1. CINEMATIC REAL FARMLAND PHOTO BACKGROUND WITH KEN-BURNS MOTION */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden" key={`bg-${animationKey}`}>
        <motion.img
          src={kilimoFarmImg}
          alt="Shamba Halisi la Mazao ya Kilimo"
          referrerPolicy="no-referrer"
          initial={{ scale: 1.08, y: 0, opacity: 0.75 }}
          animate={{
            scale: [1.08, 1.15, 1.08],
            y: [0, -10, 0],
            opacity: [0.75, 0.85, 0.75],
          }}
          transition={{ duration: 18, repeat: Infinity, ease: 'easeInOut' }}
          className="w-full h-full object-cover object-center filter saturate-110"
        />

        {/* Deep Forest Gradient Overlays for High Legibility & Vignette */}
        <div
          className="absolute inset-0"
          style={{
            background:
              'linear-gradient(180deg, rgba(11,27,19,0.82) 0%, rgba(15,32,24,0.55) 30%, rgba(15,32,24,0.72) 65%, rgba(11,27,19,0.96) 100%)',
          }}
        />

        {/* Radial Sunrise Glow overlay */}
        <motion.div
          initial={{ opacity: 0.3 }}
          animate={{ opacity: [0.3, 0.55, 0.3] }}
          transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute -top-24 left-1/2 -translate-x-1/2 w-[500px] h-[350px] rounded-full pointer-events-none"
          style={{
            background:
              'radial-gradient(circle, rgba(245,210,120,0.45) 0%, rgba(200,155,60,0.2) 50%, transparent 80%)',
            filter: 'blur(35px)',
          }}
        />
      </div>

      {/* 2. TOP FLOATING UTILITY CONTROLS */}
      <div className="absolute top-3 left-3 right-3 z-30 flex items-center justify-between pointer-events-auto">
        <div className="flex items-center gap-1.5">
          {/* Sound Toggle */}
          <button
            id="intro-sound-toggle"
            onClick={toggleSound}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full text-xs font-medium text-amber-100 bg-black/40 backdrop-blur-md border border-white/15 hover:bg-black/60 transition-colors shadow-sm"
            title={isSw ? 'Sauti ya asubuhi' : 'Morning ambient sound'}
          >
            {soundEnabled ? (
              <Volume2 className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
            ) : (
              <VolumeX className="w-3.5 h-3.5 opacity-60" />
            )}
            <span className="text-[10px] font-semibold hidden xs:inline">
              {soundEnabled ? (isSw ? 'Sauti Ipo' : 'Sound On') : (isSw ? 'Bila Sauti' : 'Muted')}
            </span>
          </button>

          {/* Real Photo Focus Toggle Pill */}
          <button
            id="intro-photo-focus-btn"
            onClick={toggleExpandPhoto}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-full text-[10px] font-semibold text-emerald-100 bg-emerald-950/60 backdrop-blur-md border border-emerald-400/30 hover:bg-emerald-900/70 transition-colors shadow-sm"
            title={isSw ? 'Tazama picha halisi ya shamba' : 'Inspect real farmland photo'}
          >
            <ImageIcon className="w-3.5 h-3.5 text-emerald-300" />
            <span>{isPhotoExpanded ? (isSw ? 'Muundo Asili' : 'Standard') : (isSw ? 'Picha Kubwa' : 'Photo View')}</span>
          </button>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            id="intro-replay-btn"
            onClick={handleRestart}
            className="p-1.5 rounded-full text-amber-100 bg-black/40 backdrop-blur-md border border-white/15 hover:bg-black/60 transition-colors shadow-sm"
            title={isSw ? 'Rudia mwanzo' : 'Replay animation'}
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          <button
            id="intro-skip-btn"
            onClick={(e) => {
              e.stopPropagation();
              playKeyTap();
              onSkipToLogin();
            }}
            className="px-3 py-1.5 rounded-full text-xs font-bold text-emerald-100 bg-[var(--forest)]/90 backdrop-blur-md border border-emerald-400/40 hover:bg-[var(--forest-dark)] transition-all shadow-sm"
          >
            {isSw ? 'Kuingia' : 'Skip to Login'}
          </button>
        </div>
      </div>

      {/* 3. CENTRAL HERO STAGE WITH REAL FARMLAND SHOWCASE */}
      <div
        className="relative z-10 w-full flex-1 flex flex-col items-center justify-center px-4 pt-12 pb-2"
        key={`stage-${animationKey}`}
      >
        {/* EXPANDED FULL-RES PHOTO MODAL VIEW */}
        <AnimatePresence>
          {isPhotoExpanded && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md rounded-2xl overflow-hidden border-2 border-amber-300/60 shadow-2xl bg-black/80 backdrop-blur-lg p-2.5 my-auto"
            >
              <div className="relative rounded-xl overflow-hidden border border-white/20 aspect-video">
                <img
                  src={kilimoFarmImg}
                  alt="Kilimo Halisi cha Kisasa Tanzania"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30" />

                <div className="absolute top-2 left-2 flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-[10px] text-amber-200 font-bold">
                  <Sparkles className="w-3 h-3 text-amber-300" />
                  <span>100% Picha Halisi ya Kilimo (Kilimo.jpeg)</span>
                </div>

                <button
                  onClick={toggleExpandPhoto}
                  className="absolute top-2 right-2 p-1 rounded-full bg-black/60 text-white hover:bg-black/80 cursor-pointer"
                >
                  <Minimize2 className="w-3.5 h-3.5" />
                </button>

                <div className="absolute bottom-2 left-2 right-2 text-white text-xs">
                  <div className="font-bold flex items-center gap-1 text-emerald-300">
                    <Tractor className="w-3.5 h-3.5" />
                    <span>{isSw ? 'Mashamba ya Nafaka & Kilimo cha Kisasa' : 'Grain Fields & Mechanized Agriculture'}</span>
                  </div>
                  <p className="text-[10px] text-neutral-200 mt-0.5">
                    {isSw
                      ? 'Ukanda wa uzalishaji wa nafaka, Bonde la Kilombero na Nyanda za Juu Kusini.'
                      : 'High-yield grain agricultural belt, fertile soils and modern cultivation.'}
                  </p>
                </div>
              </div>

              <div className="mt-2 text-center">
                <button
                  onClick={toggleExpandPhoto}
                  className="text-[11px] text-amber-200 hover:text-white font-medium cursor-pointer"
                >
                  {isSw ? '← Rejea kwenye Utangulizi' : '← Return to Intro View'}
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* DEFAULT COMPANION VIEW: REAL FARMLAND HERO CARD + BRAND TYPOGRAPHY */}
        {!isPhotoExpanded && (
          <div className="w-full max-w-sm flex flex-col items-center text-center">
            {/* REAL FARMLAND HERO SHOWCASE CARD */}
            <motion.div
              initial={{ y: 20, opacity: 0, scale: 0.95 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, ease: 'easeOut' }}
              className="relative w-full rounded-2xl sm:rounded-3xl overflow-hidden border-2 border-amber-300/40 shadow-2xl shadow-black/60 bg-[#142A20]/90 group cursor-pointer"
              onClick={toggleExpandPhoto}
            >
              {/* Real Farmland Image Frame */}
              <div className="relative w-full h-[155px] sm:h-[175px] overflow-hidden">
                <img
                  src={kilimoFarmImg}
                  alt="Kilimo Halisi cha Nafaka"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover filter saturate-115 transform group-hover:scale-105 transition-transform duration-700"
                />

                {/* Subtle vignette & light sheen */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0F2018] via-transparent to-black/20" />

                {/* Top Location & Authentic Badge */}
                <div className="absolute top-2 left-2 flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-black/65 backdrop-blur-md border border-white/20 text-[10px] font-bold text-amber-200 shadow-md">
                  <MapPin className="w-3 h-3 text-amber-300" />
                  <span>{isSw ? 'Bonde la Kilombero, TZ' : 'Kilombero Valley, TZ'}</span>
                </div>

                <div className="absolute top-2 right-2 flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-900/80 backdrop-blur-md border border-emerald-400/40 text-[9px] font-bold text-emerald-200">
                  <Tractor className="w-3 h-3 text-emerald-300" />
                  <span>{isSw ? 'Mashine & Tija' : 'Agri-Tech'}</span>
                </div>

                {/* Bottom Overlay Label */}
                <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between text-white text-[11px]">
                  <div className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-black/60 backdrop-blur-sm border border-white/15">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span className="font-semibold text-white">
                      {isSw ? 'Kilimo Halisi cha Mazao' : 'Authentic Grain Farmland'}
                    </span>
                  </div>

                  <div className="px-1.5 py-0.5 rounded bg-amber-400/90 text-[#142A20] font-bold text-[9px] flex items-center gap-0.5 shadow-xs">
                    <Maximize2 className="w-2.5 h-2.5" />
                    <span>{isSw ? 'Kuza' : 'Expand'}</span>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* BRANDING & VALUE PROPOSITION */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
              className="mt-3.5 space-y-1.5"
            >
              {/* Companion Subtitle Pill */}
              <div className="inline-flex items-center justify-center gap-1.5 px-3 py-0.5 rounded-full bg-amber-400/20 border border-amber-300/40 text-amber-200">
                <Sparkles className="w-3 h-3 text-amber-300 animate-spin" />
                <span className="text-[10px] font-bold tracking-wider uppercase">
                  {isSw ? 'Mwenzi wa Mkulima wa Kisasa' : 'Smart Farmer Companion'}
                </span>
                <Sparkles className="w-3 h-3 text-amber-300 animate-spin" />
              </div>

              <h1 className="font-display text-4xl sm:text-5xl font-bold tracking-tight text-[#F7F4E9] drop-shadow-md">
                Ardhi
              </h1>

              <div className="w-14 h-0.5 mx-auto rounded-full bg-gradient-to-r from-amber-400 via-amber-200 to-amber-400 opacity-80" />

              <p className="text-xs sm:text-sm font-medium text-emerald-100/90 max-w-[290px] mx-auto leading-relaxed">
                {isSw
                  ? 'Kila unachohitaji shambani — kalenda ya kupanda, bei za masoko ya Tanzania & dunia, na wanunuzi wa uhakika.'
                  : 'Everything for your farm — planting calendar, live domestic & global prices, and direct verified buyers.'}
              </p>
            </motion.div>

            {/* QUICK FEATURE TILES OVER REAL SCENE */}
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.5 }}
              className="grid grid-cols-3 gap-1.5 w-full mt-3 px-1"
            >
              <div className="p-2 rounded-xl bg-black/40 backdrop-blur-md border border-white/10 text-center flex flex-col items-center gap-1">
                <CloudSun className="w-4 h-4 text-amber-300" />
                <span className="text-[10px] font-bold text-white leading-tight">
                  {isSw ? 'Hewa ya Eneo' : 'Local Weather'}
                </span>
              </div>

              <div className="p-2 rounded-xl bg-black/40 backdrop-blur-md border border-white/10 text-center flex flex-col items-center gap-1">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <span className="text-[10px] font-bold text-white leading-tight">
                  {isSw ? 'Bei & Malengo' : 'Price Targets'}
                </span>
              </div>

              <div className="p-2 rounded-xl bg-black/40 backdrop-blur-md border border-white/10 text-center flex flex-col items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-amber-300" />
                <span className="text-[10px] font-bold text-white leading-tight">
                  {isSw ? 'Wanunuzi & Pochi' : 'Buyers & Wallet'}
                </span>
              </div>
            </motion.div>
          </div>
        )}
      </div>

      {/* 4. BOTTOM ACTION FOOTER */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7, duration: 0.6 }}
        className="relative z-20 w-full px-5 pb-5 pt-1 flex flex-col items-center gap-2 pointer-events-auto"
      >
        <button
          id="intro-continue-btn"
          onClick={(e) => {
            e.stopPropagation();
            playKeyTap();
            onComplete();
          }}
          className="w-full max-w-[280px] py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#E7C273] via-[#F6DE9F] to-[#E7C273] text-[#142A20] font-bold text-sm shadow-xl shadow-black/40 flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
        >
          <span>{isSw ? 'Gusa Kuendelea' : 'Tap to Continue'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-1.5 text-[10px] text-amber-200/80 font-medium">
          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
          <span>{isSw ? 'Inafanya kazi mtandaoni na nje ya mtandao (Offline)' : 'Works online & offline in East Africa'}</span>
        </div>
      </motion.div>
    </div>
  );
}

