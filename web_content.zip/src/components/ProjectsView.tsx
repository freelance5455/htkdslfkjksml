import React, { useState } from 'react';
import { FolderGit2, Trash2, Copy, Edit3, Play, Plus, Clock, Video } from 'lucide-react';
import { VideoProject } from '../types/project';
import { formatTime } from '../utils/videoMath';

interface ProjectsViewProps {
  projects: VideoProject[];
  onSelectProject: (p: VideoProject) => void;
  onNewProject: () => void;
  onDeleteProject: (id: string) => void;
  onDuplicateProject: (id: string) => void;
  onRenameProject: (id: string, newName: string) => void;
  lang: 'ar' | 'en';
}

export const ProjectsView: React.FC<ProjectsViewProps> = ({
  projects,
  onSelectProject,
  onNewProject,
  onDeleteProject,
  onDuplicateProject,
  onRenameProject,
  lang
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState<string>('');

  const handleStartRename = (p: VideoProject) => {
    setEditingId(p.id);
    setEditingName(p.name);
  };

  const handleSaveRename = (id: string) => {
    if (editingName.trim()) {
      onRenameProject(id, editingName.trim());
    }
    setEditingId(null);
  };

  return (
    <div className="max-w-5xl mx-auto p-4 sm:p-6 space-y-6 pb-28">
      {/* Header */}
      <div className="flex items-center justify-between bg-[#111224] p-5 rounded-2xl border border-purple-900/40">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-purple-600/30 text-purple-300 border border-purple-500/40">
            <FolderGit2 className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-white">
              {lang === 'ar' ? 'إدارة المشاريع المحفوظة' : 'My Video Projects'}
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              {lang === 'ar'
                ? 'جميع مشاريعك وإعدادات القوالب محفوظة بأمان على جهازك'
                : 'All your video drafts and template presets are saved locally'}
            </p>
          </div>
        </div>

        <button
          onClick={onNewProject}
          className="py-2 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-1.5 shadow transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{lang === 'ar' ? 'مشروع جديد' : 'New Project'}</span>
        </button>
      </div>

      {/* Projects List */}
      {projects.length === 0 ? (
        <div className="p-10 rounded-2xl bg-[#111224] border border-purple-900/30 text-center space-y-3">
          <Video className="w-12 h-12 text-slate-600 mx-auto" />
          <h3 className="text-base font-bold text-white">
            {lang === 'ar' ? 'لا توجد مشاريع محفوظة حالياً' : 'No saved projects yet'}
          </h3>
          <p className="text-xs text-slate-400">
            {lang === 'ar' ? 'ابدأ مشروعاً جديداً أو جرب الفيديو الافتراضي' : 'Start a new project or try demo video'}
          </p>
          <button
            onClick={onNewProject}
            className="py-2 px-4 rounded-xl bg-purple-600 text-white font-semibold text-xs inline-flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>{lang === 'ar' ? 'إنشاء أول مشروع' : 'Create First Project'}</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {projects.map((p) => {
            const isEditing = editingId === p.id;

            return (
              <div
                key={p.id}
                className="bg-[#111224] border border-purple-900/40 hover:border-purple-600/60 rounded-2xl p-4 flex flex-col justify-between space-y-3 shadow-lg transition"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-purple-950 text-purple-300 border border-purple-800/40">
                      {p.aspectRatio}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {formatTime(p.duration || 60)}
                    </span>
                  </div>

                  {isEditing ? (
                    <div className="flex items-center gap-1">
                      <input
                        type="text"
                        value={editingName}
                        onChange={(e) => setEditingName(e.target.value)}
                        className="flex-1 px-2 py-1 bg-black text-white text-xs rounded border border-purple-500 focus:outline-none"
                      />
                      <button
                        onClick={() => handleSaveRename(p.id)}
                        className="px-2 py-1 bg-emerald-600 text-white text-xs rounded"
                      >
                        ✓
                      </button>
                    </div>
                  ) : (
                    <h3 className="font-bold text-sm text-white truncate">{p.name}</h3>
                  )}

                  <p className="text-[10px] text-slate-500 mt-1">
                    {lang === 'ar' ? 'آخر تعديل:' : 'Updated:'}{' '}
                    {new Date(p.updatedAt || Date.now()).toLocaleDateString('ar-EG')}
                  </p>
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between gap-1 pt-2 border-t border-purple-900/30">
                  <button
                    onClick={() => onSelectProject(p)}
                    className="flex-1 py-1.5 px-3 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5" />
                    <span>{lang === 'ar' ? 'فتح المحرر' : 'Open'}</span>
                  </button>

                  <button
                    onClick={() => handleStartRename(p)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
                    title={lang === 'ar' ? 'إعادة تسمية' : 'Rename'}
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => onDuplicateProject(p.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
                    title={lang === 'ar' ? 'تكرار المشروع' : 'Duplicate'}
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => {
                      if (confirm(lang === 'ar' ? 'هل أنت متأكد من حذف هذا المشروع؟' : 'Delete this project?')) {
                        onDeleteProject(p.id);
                      }
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-red-400 hover:bg-slate-800 transition cursor-pointer"
                    title={lang === 'ar' ? 'حذف' : 'Delete'}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
