import React, { useEffect, useState } from 'react';
import {
  FileCode,
  FolderCode,
  Hammer,
  MonitorSmartphone,
  Plus,
  Save,
  Settings,
  Trash2,
} from 'lucide-react';
import { apiRequest, formatBytes, formatDateTr, resolveProjectIconSrc } from '../lib/api';
import type { NavSection, ProjectDetail, ProjectSummary } from '../types/studio';

interface ProjectsViewProps {
  projects: ProjectSummary[];
  selectedProject: ProjectDetail | null;
  onSelectProject: (id: string) => void;
  onRefreshProjects: () => Promise<void>;
  onRefreshSelected: (id: string) => Promise<void>;
  onOpenUploadModal: (mode: 'html' | 'zip' | 'create') => void;
  onNavigate: (section: NavSection) => void;
  onStartBuild: (projectId: string) => void;
}

export const ProjectsView: React.FC<ProjectsViewProps> = ({
  projects,
  selectedProject,
  onSelectProject,
  onRefreshProjects,
  onRefreshSelected,
  onOpenUploadModal,
  onNavigate,
  onStartBuild,
}) => {
  const [activeFilePath, setActiveFilePath] = useState<string>('');
  const [fileContent, setFileContent] = useState<string>('');
  const [savedContent, setSavedContent] = useState<string>('');
  const [fileLoading, setFileLoading] = useState(false);
  const [savingFile, setSavingFile] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [newFilePath, setNewFilePath] = useState('');
  const [showNewFileInput, setShowNewFileInput] = useState(false);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const isDirty = activeFilePath.length > 0 && fileContent !== savedContent;

  useEffect(() => {
    if (selectedProject && selectedProject.files.length > 0) {
      const preferred =
        selectedProject.files.find((f) => f.path === selectedProject.entry_file) ||
        selectedProject.files.find((f) => !f.isBinary) ||
        selectedProject.files[0];
      if (preferred && !preferred.isBinary) {
        void loadFileContent(selectedProject.id, preferred.path);
      } else {
        setActiveFilePath('');
        setFileContent('');
        setSavedContent('');
      }
    } else {
      setActiveFilePath('');
      setFileContent('');
      setSavedContent('');
    }
  }, [selectedProject?.id]);

  const loadFileContent = async (projectId: string, relPath: string) => {
    setFileLoading(true);
    setStatusMsg(null);
    setActiveFilePath(relPath);
    try {
      const res = await apiRequest<{ path: string; content: string }>(
        `/api/projects/${projectId}/file?path=${encodeURIComponent(relPath)}`
      );
      setFileContent(res.content);
      setSavedContent(res.content);
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Dosya okunamadı.');
    } finally {
      setFileLoading(false);
    }
  };

  const handleSaveFile = async () => {
    if (!selectedProject || !activeFilePath) return;
    setSavingFile(true);
    setStatusMsg(null);
    try {
      await apiRequest(`/api/projects/${selectedProject.id}/file`, {
        method: 'PUT',
        body: JSON.stringify({ path: activeFilePath, content: fileContent }),
      });
      setSavedContent(fileContent);
      await onRefreshSelected(selectedProject.id);
      setStatusMsg(`"${activeFilePath}" kaydedildi.`);
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Dosya kaydedilemedi.');
    } finally {
      setSavingFile(false);
    }
  };

  const handleCreateNewFile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject || !newFilePath.trim()) return;
    try {
      await apiRequest(`/api/projects/${selectedProject.id}/file`, {
        method: 'PUT',
        body: JSON.stringify({ path: newFilePath.trim(), content: '' }),
      });
      const created = newFilePath.trim();
      setNewFilePath('');
      setShowNewFileInput(false);
      await onRefreshSelected(selectedProject.id);
      await loadFileContent(selectedProject.id, created);
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Dosya oluşturulamadı.');
    }
  };

  const handleEntryFileChange = async (entryFile: string) => {
    if (!selectedProject) return;
    try {
      await apiRequest(`/api/projects/${selectedProject.id}/entry`, {
        method: 'PUT',
        body: JSON.stringify({ entryFile }),
      });
      await onRefreshSelected(selectedProject.id);
      await onRefreshProjects();
      setStatusMsg(`Giriş HTML dosyası "${entryFile}" olarak güncellendi.`);
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Giriş dosyası güncellenemedi.');
    }
  };

  const handleDeleteProject = async (id: string) => {
    try {
      await apiRequest(`/api/projects/${id}`, { method: 'DELETE' });
      setConfirmDeleteId(null);
      await onRefreshProjects();
    } catch (err) {
      setStatusMsg(err instanceof Error ? err.message : 'Proje silinemedi.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-[#F8FAFC]">
            Projelerim
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-[#94A3B8]">
            Proje dosyalarını düzenleyin, giriş HTML dosyasını seçin veya yeni APK oluşturun.
          </p>
        </div>
        <button
          type="button"
          onClick={() => onOpenUploadModal('zip')}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl bg-[#6366F1] hover:bg-[#5558E3] text-white transition-colors whitespace-nowrap shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Proje Ekle</span>
        </button>
      </div>

      {projects.length === 0 ? (
        <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl p-10 text-center">
          <FolderCode className="w-8 h-8 text-slate-400 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-slate-900 dark:text-[#F8FAFC]">
            Henüz kayıtlı projeniz yok
          </h3>
          <p className="mt-1 text-sm text-slate-600 dark:text-[#94A3B8]">
            Başlamak için bir HTML/ZIP projesi yükleyin veya sıfırdan yeni bir proje oluşturun.
          </p>
          <button
            type="button"
            onClick={() => onOpenUploadModal('create')}
            className="mt-5 px-5 py-2.5 text-xs font-semibold rounded-xl bg-[#6366F1] hover:bg-[#5558E3] text-white"
          >
            Yeni Proje Oluştur
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Project List */}
          <div className="lg:col-span-4 space-y-3">
            {projects.map((p) => {
              const isSelected = selectedProject?.id === p.id;
              return (
                <div
                  key={p.id}
                  className={`rounded-xl border p-4 transition-colors ${
                    isSelected
                      ? 'bg-white dark:bg-[#151D2E] border-[#6366F1]'
                      : 'bg-white dark:bg-[#151D2E] border-slate-200 dark:border-white/[0.08] hover:border-slate-300 dark:hover:border-white/[0.16]'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => onSelectProject(p.id)}
                    className="w-full text-left"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={resolveProjectIconSrc(
                          p.id,
                          p.config.iconPreset,
                          p.config.customIconPath,
                          p.updated_at
                        )}
                        alt={p.config.appName || p.name}
                        referrerPolicy="no-referrer"
                        className="w-10 h-10 rounded-xl object-cover border border-slate-200 dark:border-white/[0.12] shrink-0 bg-slate-100 dark:bg-[#0B1020]"
                      />
                      <div className="min-w-0 flex-1">
                        <h3 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC] truncate">
                          {p.name}
                        </h3>
                        <p className="mt-0.5 text-xs font-mono text-slate-500 dark:text-[#94A3B8] truncate">
                          {p.config.packageName}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2.5 flex items-center gap-2 text-[11px] text-slate-500 dark:text-[#94A3B8] tabular-nums">
                      <span>{p.total_files} dosya</span>
                      <span aria-hidden="true">·</span>
                      <span>{formatBytes(p.total_size_bytes)}</span>
                      <span aria-hidden="true">·</span>
                      <span>{formatDateTr(p.updated_at)}</span>
                    </div>
                  </button>

                  <div className="mt-3 pt-3 border-t border-slate-100 dark:border-white/[0.06] flex items-center justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={() => {
                          onSelectProject(p.id);
                          onNavigate('preview');
                        }}
                        className="inline-flex items-center gap-1 text-xs text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white transition-colors"
                      >
                        <MonitorSmartphone className="w-3.5 h-3.5" />
                        <span>Önizle</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          onSelectProject(p.id);
                          onNavigate('settings');
                        }}
                        className="inline-flex items-center gap-1 text-xs text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white transition-colors"
                      >
                        <Settings className="w-3.5 h-3.5" />
                        <span>Ayarlar</span>
                      </button>
                    </div>

                    {confirmDeleteId === p.id ? (
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => void handleDeleteProject(p.id)}
                          className="text-xs font-semibold text-[#EF4444]"
                        >
                          Onayla
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmDeleteId(null)}
                          className="text-xs text-slate-500 dark:text-[#94A3B8]"
                        >
                          Vazgeç
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteId(p.id)}
                        className="text-xs text-slate-400 hover:text-[#EF4444] transition-colors"
                        aria-label="Projeyi Sil"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* File Explorer & Code Editor */}
          {selectedProject && (
            <div className="lg:col-span-8 bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-xl overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-200 dark:border-white/[0.08] flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-sm font-semibold text-slate-900 dark:text-[#F8FAFC]">
                    {selectedProject.name}
                  </h2>
                  <p className="text-xs text-slate-600 dark:text-[#94A3B8] mt-0.5">
                    Giriş dosyası:{' '}
                    <select
                      value={selectedProject.entry_file}
                      onChange={(e) => void handleEntryFileChange(e.target.value)}
                      className="bg-slate-50 dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.12] rounded-md px-2 py-0.5 text-xs font-mono text-slate-900 dark:text-[#F8FAFC] ml-1"
                    >
                      {selectedProject.htmlFiles.map((hf) => (
                        <option key={hf} value={hf}>
                          {hf}
                        </option>
                      ))}
                    </select>
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onNavigate('preview')}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-white/[0.1] bg-slate-50 dark:bg-[#111827] text-slate-800 dark:text-[#F8FAFC] hover:bg-slate-100 dark:hover:bg-white/[0.06] whitespace-nowrap"
                  >
                    <MonitorSmartphone className="w-3.5 h-3.5" />
                    <span>Canlı Önizle</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onStartBuild(selectedProject.id)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-[#6366F1] hover:bg-[#5558E3] text-white transition-colors whitespace-nowrap"
                  >
                    <Hammer className="w-3.5 h-3.5" />
                    <span>APK Oluştur</span>
                  </button>
                </div>
              </div>

              {statusMsg && (
                <div className="px-5 py-2.5 bg-[#3B82F6]/10 border-b border-[#3B82F6]/20 text-xs text-blue-700 dark:text-blue-300">
                  {statusMsg}
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-12 min-h-[440px]">
                {/* File Tree */}
                <div className="md:col-span-4 border-b md:border-b-0 md:border-r border-slate-200 dark:border-white/[0.08] p-3 space-y-1 bg-slate-50 dark:bg-[#111827]">
                  <div className="flex items-center justify-between px-2 py-1.5 mb-1">
                    <span className="text-[11px] font-medium text-slate-500 dark:text-[#94A3B8]">
                      Proje Dosyaları
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowNewFileInput((v) => !v)}
                      className="text-xs text-[#3B82F6] hover:underline"
                    >
                      + Dosya
                    </button>
                  </div>

                  {showNewFileInput && (
                    <form onSubmit={handleCreateNewFile} className="px-1 pb-2 flex gap-1">
                      <input
                        type="text"
                        value={newFilePath}
                        onChange={(e) => setNewFilePath(e.target.value)}
                        placeholder="js/extra.js"
                        className="flex-1 min-w-0 bg-white dark:bg-[#0B1020] border border-slate-200 dark:border-white/[0.12] rounded px-2 py-1 text-xs font-mono text-slate-900 dark:text-[#F8FAFC]"
                      />
                      <button
                        type="submit"
                        className="px-2 py-1 text-xs bg-[#6366F1] text-white rounded"
                      >
                        Ekle
                      </button>
                    </form>
                  )}

                  {selectedProject.files.map((f) => (
                    <button
                      key={f.path}
                      type="button"
                      disabled={f.isBinary}
                      onClick={() => void loadFileContent(selectedProject.id, f.path)}
                      className={`w-full flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-lg text-xs text-left transition-colors ${
                        activeFilePath === f.path
                          ? 'bg-[#6366F1] text-white'
                          : f.isBinary
                          ? 'text-slate-400 dark:text-slate-600 cursor-default'
                          : 'text-slate-700 dark:text-[#CBD5E1] hover:bg-slate-200/70 dark:hover:bg-white/[0.04]'
                      }`}
                    >
                      <span className="inline-flex items-center gap-2 truncate font-mono">
                        <FileCode className="w-3.5 h-3.5 shrink-0 opacity-75" />
                        <span className="truncate">{f.path}</span>
                      </span>
                      <span className="text-[10px] opacity-75 tabular-nums shrink-0">
                        {formatBytes(f.size)}
                      </span>
                    </button>
                  ))}
                </div>

                {/* Code Editor */}
                <div className="md:col-span-8 flex flex-col">
                  <div className="px-4 py-2.5 border-b border-slate-200 dark:border-white/[0.08] flex items-center justify-between bg-slate-50 dark:bg-[#111827]">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-xs font-mono text-slate-700 dark:text-[#CBD5E1] truncate">
                        {activeFilePath || 'Düzenlemek için sol listeden bir metin dosyası seçin'}
                      </span>
                      {isDirty && (
                        <span className="text-[11px] font-medium text-amber-500 shrink-0">
                          (Kaydedilmedi)
                        </span>
                      )}
                    </div>
                    {activeFilePath && (
                      <button
                        type="button"
                        disabled={savingFile}
                        onClick={() => void handleSaveFile()}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-[#6366F1] hover:bg-[#5558E3] disabled:opacity-50 text-white transition-colors whitespace-nowrap"
                      >
                        <Save className="w-3.5 h-3.5" />
                        <span>{savingFile ? 'Kaydediliyor...' : 'Kaydet'}</span>
                      </button>
                    )}
                  </div>

                  {fileLoading ? (
                    <div className="flex-1 p-6 text-xs text-slate-500 dark:text-[#94A3B8]">
                      Dosya yükleniyor...
                    </div>
                  ) : activeFilePath ? (
                    <textarea
                      value={fileContent}
                      onChange={(e) => setFileContent(e.target.value)}
                      spellCheck={false}
                      className="flex-1 w-full min-h-[380px] bg-white dark:bg-[#0B1020] p-4 text-xs font-mono text-slate-900 dark:text-[#E2E8F0] leading-relaxed focus:outline-none resize-none"
                    />
                  ) : (
                    <div className="flex-1 p-8 text-xs text-slate-500 dark:text-[#94A3B8] flex items-center justify-center">
                      Düzenlenecek bir HTML, CSS, JS veya JSON dosyası seçin.
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
