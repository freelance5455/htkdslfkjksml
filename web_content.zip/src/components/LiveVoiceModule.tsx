import React, { useEffect, useRef, useState } from 'react';
import {
  Mic,
  MicOff,
  PhoneOff,
  Volume2,
  Square,
  Send,
  AlertCircle,
  ShieldCheck,
  Sparkles,
  RefreshCw,
  Wifi,
  WifiOff,
  CheckCircle2,
} from 'lucide-react';
import type { SupportedLanguage, VoiceProfileId } from '../types';
import {
  VOICE_PROFILES,
  extractReadableError,
  float32ToBase64Pcm16,
  base64Pcm16ToFloat32,
} from '../utils/rajuEngine';
import { LotusOrb } from './LotusOrb';

interface LiveVoiceModuleProps {
  language: SupportedLanguage;
  onLanguageChange: (lang: SupportedLanguage) => void;
  selectedVoice: VoiceProfileId;
  onVoiceChange: (voice: VoiceProfileId) => void;
  onEarnXp: (amount: number) => void;
}

interface TranscriptEntry {
  id: string;
  speaker: 'You' | 'RAJU AI';
  text: string;
  voice?: string;
  timestamp: string;
}

type ConnectionStatus = 'disconnected' | 'verifying' | 'connecting' | 'connected' | 'reconnecting' | 'error';

const LIVE_HISTORY_KEY = 'raju_ai_live_voice_history_v1';

export const LiveVoiceModule: React.FC<LiveVoiceModuleProps> = ({
  language,
  onLanguageChange,
  selectedVoice,
  onVoiceChange,
  onEarnXp,
}) => {
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('disconnected');
  const [micStatus, setMicStatus] = useState<'idle' | 'active' | 'muted' | 'denied' | 'unavailable'>('idle');
  const [micLevel, setMicLevel] = useState(0);
  const [orbState, setOrbState] = useState<'idle' | 'listening' | 'speaking' | 'thinking'>('idle');
  const [transcripts, setTranscripts] = useState<TranscriptEntry[]>(() => {
    try {
      const raw = localStorage.getItem(LIVE_HISTORY_KEY);
      return raw ? (JSON.parse(raw) as TranscriptEntry[]) : [];
    } catch {
      return [];
    }
  });
  const [liveSubtitle, setLiveSubtitle] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [textFallbackInput, setTextFallbackInput] = useState('');
  const [previewLoadingId, setPreviewLoadingId] = useState<VoiceProfileId | null>(null);
  const [voiceCloneConsent, setVoiceCloneConsent] = useState(false);
  const [autoReconnect, setAutoReconnect] = useState(true);
  const [reconnectAttempt, setReconnectAttempt] = useState(0);
  const [verifiedModelInfo, setVerifiedModelInfo] = useState<string>('gemini-3.8-live');

  const wsRef = useRef<WebSocket | null>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const activeSourcesRef = useRef<AudioBufferSourceNode[]>([]);
  const isMutedRef = useRef<boolean>(false);
  const manualCloseRef = useRef<boolean>(false);
  const reconnectTimerRef = useRef<number | null>(null);
  const orbStateRef = useRef<'idle' | 'listening' | 'speaking' | 'thinking'>('idle');
  const autoReconnectRef = useRef<boolean>(true);
  const reconnectAttemptRef = useRef<number>(0);

  useEffect(() => {
    isMutedRef.current = micStatus === 'muted';
  }, [micStatus]);

  useEffect(() => {
    orbStateRef.current = orbState;
  }, [orbState]);

  useEffect(() => {
    autoReconnectRef.current = autoReconnect;
  }, [autoReconnect]);

  useEffect(() => {
    try {
      localStorage.setItem(LIVE_HISTORY_KEY, JSON.stringify(transcripts.slice(-60)));
    } catch {
      // ignore storage quota errors
    }
  }, [transcripts]);

  const stopAllPlayback = () => {
    for (const src of activeSourcesRef.current) {
      try {
        src.stop();
      } catch {
        // ignore already stopped source
      }
    }
    activeSourcesRef.current = [];
    if (outputAudioCtxRef.current) {
      nextStartTimeRef.current = outputAudioCtxRef.current.currentTime;
    }
    setOrbState((prev) => (prev === 'speaking' ? 'listening' : prev));
  };

  const cleanupMediaAndSocket = (isManual = true) => {
    if (isManual) {
      manualCloseRef.current = true;
      if (reconnectTimerRef.current !== null) {
        window.clearTimeout(reconnectTimerRef.current);
        reconnectTimerRef.current = null;
      }
      setReconnectAttempt(0);
      reconnectAttemptRef.current = 0;
    }
    stopAllPlayback();
    if (wsRef.current) {
      try {
        wsRef.current.onclose = null;
        wsRef.current.onerror = null;
        wsRef.current.close();
      } catch {
        // ignore
      }
      wsRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
    }
    if (inputAudioCtxRef.current) {
      inputAudioCtxRef.current.close().catch(() => {});
      inputAudioCtxRef.current = null;
    }
    if (outputAudioCtxRef.current) {
      outputAudioCtxRef.current.close().catch(() => {});
      outputAudioCtxRef.current = null;
    }
    setMicLevel(0);
    if (isManual) {
      setConnectionStatus('disconnected');
      setMicStatus('idle');
      setOrbState('idle');
    }
  };

  useEffect(() => {
    return () => {
      cleanupMediaAndSocket(true);
    };
  }, []);

  const schedulePcmChunk = async (base64Pcm: string) => {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return;
    if (!outputAudioCtxRef.current) {
      outputAudioCtxRef.current = new AudioCtx({ sampleRate: 24000 });
    }
    const ctx = outputAudioCtxRef.current;
    if (ctx.state === 'suspended') {
      await ctx.resume().catch(() => {});
    }
    const float32 = base64Pcm16ToFloat32(base64Pcm);
    if (float32.length === 0) return;

    const audioBuffer = ctx.createBuffer(1, float32.length, 24000);
    audioBuffer.getChannelData(0).set(float32);

    const source = ctx.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(ctx.destination);

    const now = ctx.currentTime;
    const startAt = Math.max(now + 0.01, nextStartTimeRef.current);
    source.start(startAt);
    nextStartTimeRef.current = startAt + audioBuffer.duration;
    activeSourcesRef.current.push(source);
    setOrbState('speaking');

    source.onended = () => {
      activeSourcesRef.current = activeSourcesRef.current.filter((s) => s !== source);
      if (activeSourcesRef.current.length === 0 && wsRef.current?.readyState === WebSocket.OPEN) {
        setOrbState('listening');
      }
    };
  };

  const checkCompatibility = (): string | null => {
    if (typeof window === 'undefined') return 'Browser window not available.';
    if (!('WebSocket' in window)) {
      return 'Your browser does not support WebSockets required for Gemini Live audio streaming.';
    }
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) {
      return 'Web Audio API (AudioContext) is not supported in this browser. Please use Chrome, Edge, Safari, or Firefox.';
    }
    return null;
  };

  const startLiveSession = async (isRetry = false) => {
    setErrorMsg(null);
    const compatError = checkCompatibility();
    if (compatError) {
      setErrorMsg(compatError);
      setConnectionStatus('error');
      return;
    }

    if (selectedVoice === 'My Voice') {
      setErrorMsg(
        'My Voice is an optional future feature requiring an authorized voice-cloning service and verified voice-owner consent. Please choose one of the 5 active voices.'
      );
      return;
    }

    manualCloseRef.current = false;
    if (!isRetry) {
      setReconnectAttempt(0);
      reconnectAttemptRef.current = 0;
    }

    // Create & resume 24kHz output AudioContext directly inside user gesture to satisfy browser autoplay rules
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    try {
      if (!outputAudioCtxRef.current) {
        outputAudioCtxRef.current = new AudioCtx({ sampleRate: 24000 });
      }
      if (outputAudioCtxRef.current.state === 'suspended') {
        await outputAudioCtxRef.current.resume();
      }
      nextStartTimeRef.current = outputAudioCtxRef.current.currentTime;
    } catch (audioErr) {
      setErrorMsg(`Audio playback setup failed: ${extractReadableError(audioErr)}`);
      setConnectionStatus('error');
      return;
    }

    // Step 1: Verify Gemini Live model & API authentication on backend
    setConnectionStatus('verifying');
    try {
      const verifyRes = await fetch('/api/live/verify');
      const verifyData = await verifyRes.json().catch(() => ({}));
      if (!verifyRes.ok || !verifyData.ok) {
        throw new Error(
          extractReadableError(verifyData.error || verifyData, 'Gemini 3.8 Live verification failed.')
        );
      }
      if (verifyData.model) {
        setVerifiedModelInfo(String(verifyData.model).replace(/^models\//, ''));
      }
    } catch (verifyErr) {
      setErrorMsg(extractReadableError(verifyErr, 'Could not verify Gemini Live API key or model availability.'));
      setConnectionStatus('error');
      return;
    }

    // Step 2: Open /live WebSocket bridge
    setConnectionStatus(isRetry ? 'reconnecting' : 'connecting');
    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/live?voiceProfile=${encodeURIComponent(
        selectedVoice
      )}&language=${encodeURIComponent(language)}`;

      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = async () => {
        setConnectionStatus('connected');
        setReconnectAttempt(0);
        reconnectAttemptRef.current = 0;
        setOrbState('listening');
        onEarnXp(15);

        // Step 3: Request microphone permission & stream 16kHz PCM audio
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          setMicStatus('unavailable');
          setLiveSubtitle('Live WebSocket connected! Microphone API unavailable in this context — use the text prompt below.');
          return;
        }

        try {
          const stream = await navigator.mediaDevices.getUserMedia({
            audio: {
              sampleRate: 16000,
              channelCount: 1,
              echoCancellation: true,
              noiseSuppression: true,
              autoGainControl: true,
            },
          });
          mediaStreamRef.current = stream;
          setMicStatus('active');

          const inputCtx = new AudioCtx({ sampleRate: 16000 });
          inputAudioCtxRef.current = inputCtx;
          if (inputCtx.state === 'suspended') {
            await inputCtx.resume().catch(() => {});
          }
          const source = inputCtx.createMediaStreamSource(stream);
          const processor = inputCtx.createScriptProcessor(4096, 1, 1);
          source.connect(processor);
          processor.connect(inputCtx.destination);

          let loudFrames = 0;
          processor.onaudioprocess = (e) => {
            const channelData = e.inputBuffer.getChannelData(0);
            // Compute RMS mic level for visual meter & conversational barge-in
            let sumSquares = 0;
            for (let i = 0; i < channelData.length; i++) {
              sumSquares += channelData[i] * channelData[i];
            }
            const rms = Math.sqrt(sumSquares / channelData.length);
            const normalizedLevel = isMutedRef.current ? 0 : Math.min(100, Math.round(rms * 420));
            setMicLevel(normalizedLevel);

            if (isMutedRef.current || ws.readyState !== WebSocket.OPEN) return;

            // Natural conversational interruption: stop AI playback if user speaks steadily while AI is speaking
            if (orbStateRef.current === 'speaking' && rms > 0.065) {
              loudFrames += 1;
              if (loudFrames >= 2) {
                stopAllPlayback();
                setLiveSubtitle('Listening to your interruption...');
                loudFrames = 0;
              }
            } else {
              loudFrames = 0;
            }

            const b64 = float32ToBase64Pcm16(channelData);
            ws.send(JSON.stringify({ audio: b64 }));
          };
        } catch (micErr) {
          const errName = micErr instanceof Error ? micErr.name : '';
          if (errName === 'NotAllowedError' || errName === 'PermissionDeniedError') {
            setMicStatus('denied');
            setErrorMsg(
              'Microphone permission was denied. Please allow microphone access in your browser site settings, or type below to talk via text-to-voice.'
            );
          } else if (errName === 'NotFoundError' || errName === 'DevicesNotFoundError') {
            setMicStatus('unavailable');
            setLiveSubtitle('No physical microphone detected — Live audio output is active. Type a message below to hear AI respond!');
          } else {
            setMicStatus('unavailable');
            setLiveSubtitle(`Microphone notice: ${extractReadableError(micErr)} — Text-to-Live-Audio fallback is ready below.`);
          }
        }
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.type === 'connected') {
            setLiveSubtitle(`Connected to ${msg.model || 'gemini-3.8-live'} (${selectedVoice}). Speak naturally!`);
          } else if (msg.type === 'audio' && msg.audio) {
            schedulePcmChunk(msg.audio);
          } else if (msg.type === 'inputTranscript' && msg.text) {
            setLiveSubtitle(`You: ${msg.text}`);
            setTranscripts((prev) => [
              ...prev.slice(-50),
              {
                id: `${Date.now()}-in-${Math.random().toString(36).slice(2, 6)}`,
                speaker: 'You',
                text: String(msg.text),
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              },
            ]);
          } else if (msg.type === 'outputTranscript' && msg.text) {
            setLiveSubtitle(`${selectedVoice}: ${msg.text}`);
            setTranscripts((prev) => [
              ...prev.slice(-50),
              {
                id: `${Date.now()}-out-${Math.random().toString(36).slice(2, 6)}`,
                speaker: 'RAJU AI',
                voice: selectedVoice,
                text: String(msg.text),
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              },
            ]);
          } else if (msg.type === 'text' && msg.text) {
            setLiveSubtitle(`${selectedVoice}: ${msg.text}`);
          } else if (msg.type === 'interrupted') {
            stopAllPlayback();
            setLiveSubtitle('AI interrupted — listening to you...');
          } else if (msg.type === 'turnComplete') {
            if (activeSourcesRef.current.length === 0) {
              setOrbState('listening');
            }
          } else if (msg.type === 'error') {
            const readable = extractReadableError(msg.error, 'Gemini Live API reported a session error.');
            setErrorMsg(readable);
            manualCloseRef.current = true;
            cleanupMediaAndSocket(true);
            setConnectionStatus('error');
          } else if (msg.type === 'closed') {
            cleanupMediaAndSocket(false);
            if (!manualCloseRef.current && autoReconnectRef.current && reconnectAttemptRef.current < 3) {
              const nextAttempt = reconnectAttemptRef.current + 1;
              reconnectAttemptRef.current = nextAttempt;
              setReconnectAttempt(nextAttempt);
              setConnectionStatus('reconnecting');
              setLiveSubtitle(`Live session closed. Auto-reconnecting (attempt ${nextAttempt}/3)...`);
              reconnectTimerRef.current = window.setTimeout(() => {
                startLiveSession(true);
              }, 1200 * nextAttempt);
            } else {
              setConnectionStatus('disconnected');
              setOrbState('idle');
            }
          }
        } catch (err) {
          console.error('Live WS parse error:', extractReadableError(err));
        }
      };

      ws.onerror = (ev) => {
        const readable = extractReadableError(
          ev,
          'WebSocket connection to Gemini 3.8 Live encountered a network error.'
        );
        setErrorMsg(readable);
      };

      ws.onclose = () => {
        if (mediaStreamRef.current) {
          mediaStreamRef.current.getTracks().forEach((t) => t.stop());
          mediaStreamRef.current = null;
        }
        if (inputAudioCtxRef.current) {
          inputAudioCtxRef.current.close().catch(() => {});
          inputAudioCtxRef.current = null;
        }
        setMicLevel(0);

        if (!manualCloseRef.current && autoReconnectRef.current && reconnectAttemptRef.current < 3) {
          const nextAttempt = reconnectAttemptRef.current + 1;
          reconnectAttemptRef.current = nextAttempt;
          setReconnectAttempt(nextAttempt);
          setConnectionStatus('reconnecting');
          setLiveSubtitle(`Connection interrupted. Reconnecting (${nextAttempt}/3)...`);
          reconnectTimerRef.current = window.setTimeout(() => {
            startLiveSession(true);
          }, 1200 * nextAttempt);
        } else if (!manualCloseRef.current) {
          setConnectionStatus('disconnected');
          setOrbState('idle');
        }
      };
    } catch (err) {
      setErrorMsg(extractReadableError(err, 'Failed to initialize Live Voice session.'));
      setConnectionStatus('error');
    }
  };

  const handleToggleMute = () => {
    if (micStatus === 'active') {
      setMicStatus('muted');
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getAudioTracks().forEach((t) => {
          t.enabled = false;
        });
      }
    } else if (micStatus === 'muted') {
      setMicStatus('active');
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getAudioTracks().forEach((t) => {
          t.enabled = true;
        });
      }
    }
  };

  const handleSendTextToLive = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = textFallbackInput.trim();
    if (!trimmed || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
    stopAllPlayback();
    wsRef.current.send(JSON.stringify({ text: trimmed }));
    setTranscripts((prev) => [
      ...prev.slice(-50),
      {
        id: `${Date.now()}-user`,
        speaker: 'You',
        text: trimmed,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
    setLiveSubtitle(`You: ${trimmed}`);
    setOrbState('thinking');
    setTextFallbackInput('');
  };

  const handlePreviewVoice = async (profileId: VoiceProfileId) => {
    setErrorMsg(null);
    const profile = VOICE_PROFILES.find((p) => p.id === profileId);
    if (!profile) return;

    if (profile.isFutureFeature) {
      setErrorMsg(
        'My Voice requires an authorized voice-cloning service and verified voice-owner consent. It is not simulated.'
      );
      return;
    }

    setPreviewLoadingId(profileId);
    try {
      const sampleText = profile.sampleGreeting[language] || profile.sampleGreeting.English;
      const res = await fetch('/api/gemini/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: sampleText,
          voiceProfile: profileId,
          speed: 'normal',
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(extractReadableError(data.error || data, 'Voice preview failed.'));
      }
      if (data.audioBase64) {
        const audio = new Audio(`data:audio/wav;base64,${data.audioBase64}`);
        setOrbState('speaking');
        audio.onended = () => setOrbState(connectionStatus === 'connected' ? 'listening' : 'idle');
        await audio.play();
      }
    } catch (err) {
      setErrorMsg(extractReadableError(err, 'Unable to play voice preview.'));
    } finally {
      setPreviewLoadingId(null);
    }
  };

  const languages: SupportedLanguage[] = ['English', 'Hindi', 'Hinglish', 'Japanese'];
  const isConnected = connectionStatus === 'connected';
  const isBusyConnecting =
    connectionStatus === 'verifying' ||
    connectionStatus === 'connecting' ||
    connectionStatus === 'reconnecting';

  const statusMeta = {
    disconnected: { label: 'Disconnected', color: 'text-slate-400', dot: 'bg-slate-500' },
    verifying: { label: 'Verifying API & Model...', color: 'text-amber-300', dot: 'bg-amber-400 animate-pulse' },
    connecting: { label: 'Connecting WebSocket...', color: 'text-cyan-300', dot: 'bg-cyan-400 animate-pulse' },
    reconnecting: { label: `Reconnecting (${reconnectAttempt}/3)...`, color: 'text-amber-300', dot: 'bg-amber-400 animate-ping' },
    connected: { label: 'Live Audio Connected', color: 'text-emerald-300', dot: 'bg-emerald-400 animate-pulse' },
    error: { label: 'Connection Error', color: 'text-rose-300', dot: 'bg-rose-500' },
  }[connectionStatus];

  return (
    <div className="space-y-6">
      {/* Header & Connection Status Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <h2 className="text-2xl font-bold text-white tracking-tight">
              Real-Time Voice Conversation
            </h2>
            <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-xl bg-[#0B102B] border border-slate-800 text-xs font-semibold ${statusMeta.color}`}>
              <span className={`w-2 h-2 rounded-full ${statusMeta.dot}`} />
              {statusMeta.label}
            </span>
          </div>
          <p className="text-sm text-slate-400 mt-1">
            Genuine two-way spoken AI with instant interruption powered by <span className="font-mono text-cyan-300">{verifiedModelInfo}</span>
          </p>
        </div>

        {/* Language Segmented Selector */}
        <div className="flex items-center gap-1 p-1 rounded-xl bg-[#0B102B] border border-slate-800 overflow-x-auto">
          {languages.map((lang) => (
            <button
              key={lang}
              type="button"
              onClick={() => onLanguageChange(lang)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                language === lang
                  ? 'bg-gradient-to-r from-cyan-500 to-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {lang}
            </button>
          ))}
        </div>
      </div>

      {errorMsg && (
        <div
          role="alert"
          className="flex items-start gap-3 p-4 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-200 text-sm"
        >
          <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-semibold text-rose-100">Live Voice Notice</p>
            <p className="mt-0.5 text-rose-200/90 break-words">{errorMsg}</p>
          </div>
          <button
            type="button"
            onClick={() => setErrorMsg(null)}
            className="text-xs text-rose-300 hover:text-white underline whitespace-nowrap"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Main Live Voice Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Left/Center Orb Stage (7 cols) */}
        <div className="lg:col-span-7 flex flex-col items-center justify-between p-6 sm:p-8 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 relative overflow-hidden">
          <div className="w-full flex flex-wrap items-center justify-between gap-2 z-10 text-xs">
            <span className="text-cyan-300 font-medium">
              Voice: <strong>{selectedVoice}</strong> · {language}
            </span>
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-1.5 text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoReconnect}
                  onChange={(e) => setAutoReconnect(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-900 text-cyan-500"
                />
                <span>Auto-Reconnect</span>
              </label>
              <span className="flex items-center gap-1 text-slate-400">
                {isConnected ? <Wifi className="w-3.5 h-3.5 text-emerald-400" /> : <WifiOff className="w-3.5 h-3.5 text-slate-500" />}
                {micStatus === 'active'
                  ? 'Mic Active'
                  : micStatus === 'muted'
                    ? 'Mic Muted'
                    : micStatus === 'denied'
                      ? 'Mic Blocked'
                      : micStatus === 'unavailable'
                        ? 'Text/Audio Fallback'
                        : 'Mic Standby'}
              </span>
            </div>
          </div>

          <div className="text-center space-y-1 z-10 mt-4">
            <h3 className="text-xl font-bold text-white">
              {isConnected
                ? orbState === 'speaking'
                  ? 'RAJU AI is Speaking... (Speak or tap Orb to interrupt)'
                  : orbState === 'thinking'
                    ? 'Processing your message...'
                    : micStatus === 'muted'
                      ? 'Microphone Muted'
                      : 'Listening Continuously...'
                : isBusyConnecting
                  ? statusMeta.label
                  : 'Ready for Live Two-Way Voice'}
            </h3>
          </div>

          <div className="my-6 z-10 flex flex-col items-center gap-3">
            <LotusOrb
              size="xl"
              state={orbState}
              onClick={isConnected ? stopAllPlayback : () => startLiveSession(false)}
              label={isConnected ? 'Interrupt AI Speech' : 'Start Live Voice Chat'}
            />

            {/* Real-time Microphone Input Waveform Meter */}
            {isConnected && (
              <div className="w-48 space-y-1">
                <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                  <span>Mic Input</span>
                  <span>{micLevel}%</span>
                </div>
                <div className="h-2 rounded-full bg-[#060919] border border-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-400 via-cyan-400 to-purple-500 transition-all duration-75"
                    style={{ width: `${micLevel}%` }}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Live Subtitles Box */}
          <div className="w-full max-w-lg min-h-[60px] px-4 py-3 rounded-xl bg-[#060919]/90 border border-slate-800/80 text-center flex items-center justify-center mb-5 z-10">
            <p className="text-sm text-slate-200">
              {liveSubtitle ||
                (isConnected
                  ? 'Speak naturally into your microphone or send a prompt below...'
                  : 'Click "Start Voice Chat" to verify Gemini 3.8 Live and open two-way streaming audio.')}
            </p>
          </div>

          {/* Primary Voice Controls */}
          <div className="flex flex-wrap items-center justify-center gap-3 z-10">
            {!isConnected ? (
              <button
                type="button"
                onClick={() => startLiveSession(false)}
                disabled={isBusyConnecting}
                className="flex items-center gap-2.5 px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white font-semibold text-sm shadow-[0_0_25px_rgba(0,210,255,0.35)] transition whitespace-nowrap shrink-0 disabled:opacity-50"
              >
                {isBusyConnecting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Mic className="w-4 h-4" />}
                {isBusyConnecting ? statusMeta.label : 'Start Voice Chat'}
              </button>
            ) : (
              <>
                <button
                  type="button"
                  onClick={handleToggleMute}
                  disabled={micStatus === 'denied' || micStatus === 'unavailable'}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold border transition whitespace-nowrap shrink-0 disabled:opacity-50 ${
                    micStatus === 'muted'
                      ? 'bg-amber-500/20 border-amber-400/50 text-amber-200'
                      : 'bg-slate-800/90 border-slate-700 text-slate-100 hover:bg-slate-700'
                  }`}
                >
                  {micStatus === 'muted' ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                  {micStatus === 'muted' ? 'Unmute Mic' : 'Mute Mic'}
                </button>

                <button
                  type="button"
                  onClick={stopAllPlayback}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-950/80 border border-indigo-500/40 text-indigo-200 hover:bg-indigo-900/70 text-xs font-semibold transition whitespace-nowrap shrink-0"
                >
                  <Square className="w-3.5 h-3.5" />
                  Interrupt AI
                </button>

                <button
                  type="button"
                  onClick={() => cleanupMediaAndSocket(true)}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold transition whitespace-nowrap shrink-0"
                >
                  <PhoneOff className="w-4 h-4" />
                  End Session
                </button>
              </>
            )}
          </div>

          {/* Interactive Prompt Input inside Live Session */}
          {isConnected && (
            <form onSubmit={handleSendTextToLive} className="w-full max-w-lg mt-5 flex gap-2 z-10">
              <input
                type="text"
                value={textFallbackInput}
                onChange={(e) => setTextFallbackInput(e.target.value)}
                placeholder={`Speak or type in ${language} to hear ${selectedVoice} respond...`}
                aria-label="Send message to Live session"
                className="flex-1 min-w-0 px-3.5 py-2 rounded-xl bg-[#060919] border border-slate-800 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                Send
              </button>
            </form>
          )}
        </div>

        {/* Right Column: Voice Personalities & Conversation History (5 cols) */}
        <div className="lg:col-span-5 flex flex-col gap-5">
          {/* Voice Personalities Card */}
          <div className="p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">Anime & Tutor Voice Personalities</h3>
              <span className="text-xs text-slate-400">Preview & Select</span>
            </div>

            <div className="space-y-2">
              {VOICE_PROFILES.map((profile) => {
                const isSelected = selectedVoice === profile.id;
                const isPreviewing = previewLoadingId === profile.id;
                return (
                  <div
                    key={profile.id}
                    className={`p-3 rounded-xl border transition flex items-center justify-between gap-3 ${
                      isSelected
                        ? 'bg-indigo-950/60 border-cyan-400/60 shadow-[0_0_15px_rgba(34,211,238,0.18)]'
                        : 'bg-[#060919]/70 border-slate-800/80 hover:border-slate-700'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => onVoiceChange(profile.id)}
                      className="flex-1 text-left focus:outline-none"
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold text-white">{profile.name}</span>
                        {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />}
                        {profile.isFutureFeature && (
                          <span className="text-[11px] text-amber-300">· Consent-Gated</span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">{profile.subtitle}</p>
                    </button>

                    <button
                      type="button"
                      onClick={() => handlePreviewVoice(profile.id)}
                      disabled={isPreviewing}
                      aria-label={`Preview ${profile.name} voice`}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-medium flex items-center gap-1.5 whitespace-nowrap shrink-0 disabled:opacity-50"
                    >
                      {isPreviewing ? (
                        <Sparkles className="w-3.5 h-3.5 animate-spin" />
                      ) : profile.isFutureFeature ? (
                        <ShieldCheck className="w-3.5 h-3.5 text-amber-300" />
                      ) : (
                        <Volume2 className="w-3.5 h-3.5" />
                      )}
                      {isPreviewing ? 'Playing...' : profile.isFutureFeature ? 'Policy' : 'Preview'}
                    </button>
                  </div>
                );
              })}
            </div>

            {selectedVoice === 'My Voice' && (
              <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/40 text-xs text-amber-200 space-y-2">
                <p className="font-semibold text-amber-100">Authorized Voice Cloning Policy</p>
                <p className="text-amber-200/90 leading-relaxed">
                  RAJU AI only uses verified prebuilt Gemini Live & TTS voices and never simulates unauthorized voice cloning.
                </p>
                <label className="flex items-center gap-2 pt-1 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={voiceCloneConsent}
                    onChange={(e) => setVoiceCloneConsent(e.target.checked)}
                    className="rounded border-amber-400 bg-slate-900 text-cyan-500"
                  />
                  <span>I acknowledge the explicit voice-owner consent requirement.</span>
                </label>
              </div>
            )}
          </div>

          {/* Persistent Voice Conversation History */}
          <div className="flex-1 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 flex flex-col min-h-[220px]">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-white">
                Voice Conversation History ({transcripts.length})
              </h3>
              {transcripts.length > 0 && (
                <button
                  type="button"
                  onClick={() => setTranscripts([])}
                  className="text-xs text-slate-400 hover:text-rose-300"
                >
                  Clear History
                </button>
              )}
            </div>

            <div className="flex-1 overflow-y-auto space-y-2.5 max-h-56 pr-1">
              {transcripts.length === 0 ? (
                <div className="h-full flex items-center justify-center text-center py-8 text-xs text-slate-500">
                  Real-time spoken transcripts and AI voice replies will be saved here across your sessions.
                </div>
              ) : (
                transcripts.map((item) => (
                  <div
                    key={item.id}
                    className={`p-2.5 rounded-xl text-xs ${
                      item.speaker === 'You'
                        ? 'bg-cyan-950/40 border border-cyan-500/30 text-cyan-100'
                        : 'bg-indigo-950/50 border border-indigo-500/30 text-slate-100'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                      <span className="font-semibold text-cyan-300">
                        {item.speaker} {item.voice ? `(${item.voice})` : ''}
                      </span>
                      <span className="font-mono tabular-nums">{item.timestamp}</span>
                    </div>
                    <p>{item.text}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
