"use client";

import { useCallback, useEffect, useState } from "react";
import { Compass, LocateFixed, Loader2 } from "lucide-react";
import { toArabicDigits } from "@/lib/site";

/* ------------------------------------------------------------------ */
/* Constants & types                                                   */
/* ------------------------------------------------------------------ */

const KAABA = { lat: 21.4225, lng: 39.8262 };
const DAMASCUS = { lat: 33.5138, lng: 36.2765 };
/** Muslim World League calculation method (aladhan.com method id 3). */
const METHOD = 3;

type PrayerKey = "Fajr" | "Sunrise" | "Dhuhr" | "Asr" | "Maghrib" | "Isha";

const PRAYERS: { key: PrayerKey; name: string; countable: boolean }[] = [
  { key: "Fajr", name: "الفجر", countable: true },
  { key: "Sunrise", name: "الشروق", countable: false },
  { key: "Dhuhr", name: "الظهر", countable: true },
  { key: "Asr", name: "العصر", countable: true },
  { key: "Maghrib", name: "المغرب", countable: true },
  { key: "Isha", name: "العشاء", countable: true },
];

type Coords = { lat: number; lng: number; fromDevice: boolean };

type ApiResponse = {
  code: number;
  data: {
    timings: Record<PrayerKey, string>;
    date: {
      gregorian: { date: string };
      hijri: { day: string; month: { ar: string }; year: string };
    };
    meta: { timezone: string };
  };
};

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

/** Initial bearing from (lat, lng) to the Kaaba, in degrees clockwise from north. */
function qiblaBearing(lat: number, lng: number): number {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const toDeg = (r: number) => (r * 180) / Math.PI;
  const φ1 = toRad(lat);
  const φ2 = toRad(KAABA.lat);
  const Δλ = toRad(KAABA.lng - lng);
  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  return (toDeg(Math.atan2(y, x)) + 360) % 360;
}

/** Great-circle distance in kilometres. */
function distanceToKaabaKm(lat: number, lng: number): number {
  const R = 6371;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(KAABA.lat - lat);
  const dLng = toRad(KAABA.lng - lng);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat)) * Math.cos(toRad(KAABA.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

/** "HH:MM (+03)" -> seconds since midnight. */
function timeToSeconds(value: string): number {
  const [h, m] = value.slice(0, 5).split(":").map(Number);
  return h * 3600 + m * 60;
}

/** Current time-of-day (seconds) in the given IANA timezone. */
function nowSecondsIn(timeZone: string): number {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).formatToParts(new Date());
  const get = (type: string) => Number(parts.find((p) => p.type === type)?.value ?? 0);
  return get("hour") * 3600 + get("minute") * 60 + get("second");
}

function formatCountdown(totalSeconds: number): string {
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return toArabicDigits(`${pad(h)}:${pad(m)}:${pad(s)}`);
}

function formatClock(hhmm: string): string {
  return toArabicDigits(hhmm.slice(0, 5));
}

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function PrayerTimes() {
  const [coords, setCoords] = useState<Coords | null>(null);
  const [locating, setLocating] = useState(false);
  const [data, setData] = useState<ApiResponse["data"] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  const locate = useCallback(() => {
    if (!("geolocation" in navigator)) {
      setCoords({ ...DAMASCUS, fromDevice: false });
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude, fromDevice: true });
        setLocating(false);
      },
      () => {
        setCoords({ ...DAMASCUS, fromDevice: false });
        setLocating(false);
      },
      { enableHighAccuracy: false, timeout: 8000, maximumAge: 10 * 60 * 1000 },
    );
  }, []);

  // Detect location once on mount.
  useEffect(() => {
    locate();
  }, [locate]);

  // Fetch today's timings for the chosen coordinates.
  useEffect(() => {
    if (!coords) return;
    const controller = new AbortController();
    const now = new Date();
    const dd = String(now.getDate()).padStart(2, "0");
    const mm = String(now.getMonth() + 1).padStart(2, "0");
    const yyyy = now.getFullYear();
    const url = `https://api.aladhan.com/v1/timings/${dd}-${mm}-${yyyy}?latitude=${coords.lat}&longitude=${coords.lng}&method=${METHOD}`;

    setError(null);
    fetch(url, { signal: controller.signal })
      .then((r) => {
        if (!r.ok) throw new Error("bad response");
        return r.json() as Promise<ApiResponse>;
      })
      .then((json) => {
        if (json.code !== 200) throw new Error("bad code");
        setData(json.data);
      })
      .catch((err: unknown) => {
        if ((err as { name?: string }).name === "AbortError") return;
        setError("تعذّر تحميل المواقيت الآن. تحقق من اتصالك بالإنترنت ثم حدّث الصفحة.");
      });

    return () => controller.abort();
  }, [coords]);

  // Live clock for the countdown.
  useEffect(() => {
    const id = window.setInterval(() => setTick((t) => t + 1), 1000);
    return () => window.clearInterval(id);
  }, []);

  const timezone = data?.meta.timezone ?? "Asia/Damascus";
  const nowSec = data ? nowSecondsIn(timezone) : 0;
  void tick; // re-render every second

  // Next obligatory prayer (skips sunrise); wraps to tomorrow's Fajr.
  let next: { name: string; key: PrayerKey; remaining: number } | null = null;
  if (data) {
    const upcoming = PRAYERS.filter((p) => p.countable)
      .map((p) => ({ ...p, at: timeToSeconds(data.timings[p.key]) }))
      .sort((a, b) => a.at - b.at);
    const found = upcoming.find((p) => p.at > nowSec);
    const target = found ?? { ...upcoming[0], at: upcoming[0].at + 86400 };
    next = {
      name: target.name,
      key: target.key,
      remaining: target.at - nowSec,
    };
  }

  const bearing = coords ? qiblaBearing(coords.lat, coords.lng) : null;
  const distance = coords ? distanceToKaabaKm(coords.lat, coords.lng) : null;

  const hijri = data
    ? `${toArabicDigits(data.date.hijri.day)} ${data.date.hijri.month.ar} ${toArabicDigits(data.date.hijri.year)} هـ`
    : "";
  const gregorian = data
    ? new Intl.DateTimeFormat("ar-SY", { weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: timezone }).format(new Date())
    : "";

  return (
    <div className="grid items-start gap-8 lg:grid-cols-[1.5fr_1fr]">
      {/* Prayer times */}
      <div className="rounded-[2rem] border border-white/10 bg-white/[0.03] p-6 backdrop-blur sm:p-8">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-sm text-gold-light">
              {coords ? (coords.fromDevice ? "حسب موقعك الحالي" : "حسب مدينة دمشق (الموقع الافتراضي)") : "جارٍ تحديد موقعك…"}
            </p>
            {data && (
              <p className="mt-2 font-serif text-2xl font-bold text-ivory">{hijri}</p>
            )}
            {data && <p className="mt-1 text-sm text-ivory/55">{gregorian}</p>}
          </div>
          <button
            type="button"
            onClick={locate}
            disabled={locating}
            className="inline-flex items-center gap-2 rounded-full border border-gold/40 px-4 py-2 text-sm text-gold-light transition-colors hover:bg-gold hover:text-navy disabled:opacity-50"
          >
            {locating ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : <LocateFixed className="size-4" aria-hidden="true" />}
            تحديد موقعي
          </button>
        </div>

        {error && (
          <p role="alert" className="mt-6 rounded-2xl border border-destructive/40 bg-destructive/10 p-4 text-sm text-ivory/90">
            {error}
          </p>
        )}

        {!data && !error && (
          <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3" aria-hidden="true">
            {PRAYERS.map((p) => (
              <div key={p.key} className="h-24 animate-pulse rounded-2xl bg-white/5" />
            ))}
          </div>
        )}

        {data && next && (
          <>
            <div className="mt-8 rounded-2xl border border-gold/50 bg-gold/10 p-5 text-center" aria-live="polite">
              <p className="text-sm text-gold-light">الصلاة القادمة</p>
              <p className="mt-1 font-serif text-4xl font-bold text-ivory">{next.name}</p>
              <p className="mt-2 font-serif text-2xl text-gold-light tabular-nums">
                بعد {formatCountdown(next.remaining)}
              </p>
            </div>

            <ul className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
              {PRAYERS.map((p) => {
                const isNext = p.key === next?.key;
                return (
                  <li
                    key={p.key}
                    className={`rounded-2xl border p-4 text-center transition-colors ${
                      isNext ? "border-gold bg-gold text-navy" : "border-white/10 bg-white/[0.03] text-ivory"
                    }`}
                  >
                    <p className={`text-sm ${isNext ? "text-navy/70" : "text-gold-light"}`}>{p.name}</p>
                    <p className="mt-2 font-serif text-3xl font-bold tabular-nums">{formatClock(data.timings[p.key])}</p>
                  </li>
                );
              })}
            </ul>
          </>
        )}
      </div>

      {/* Qibla */}
      <div className="rounded-[2rem] border border-white/10 bg-white/[0.03] p-6 text-center backdrop-blur sm:p-8">
        <p className="inline-flex items-center gap-2 text-sm text-gold-light">
          <Compass className="size-4" aria-hidden="true" />
          اتجاه القبلة
        </p>

        <div className="relative mx-auto mt-6 aspect-square w-full max-w-[18rem]">
          <div className="absolute inset-0 rounded-full border border-gold/30 bg-[radial-gradient(circle,rgba(49,75,117,0.55),transparent_70%)]" aria-hidden="true" />
          <div className="absolute inset-[6%] rounded-full border border-dashed border-gold/25" aria-hidden="true" />
          <span className="absolute start-1/2 top-2 -translate-x-1/2 text-xs text-ivory/60" aria-hidden="true">
            ش
          </span>
          <span className="absolute bottom-2 start-1/2 -translate-x-1/2 text-xs text-ivory/40" aria-hidden="true">
            ج
          </span>
          <div
            className="absolute inset-0 transition-transform duration-700"
            style={{ transform: `rotate(${bearing ?? 0}deg)` }}
            aria-hidden="true"
          >
            <svg viewBox="0 0 100 100" className="size-full">
              <path d="M50 8 L58 50 L50 92 L42 50 Z" fill="#B69A69" />
              <path d="M50 8 L58 50 L42 50 Z" fill="#D8C39A" />
              <rect x="44" y="44" width="12" height="12" fill="#17243A" stroke="#D8C39A" strokeWidth="1" />
            </svg>
          </div>
        </div>

        {bearing !== null && distance !== null ? (
          <div className="mt-6 space-y-2">
            <p className="font-serif text-4xl font-bold text-ivory tabular-nums">{toArabicDigits(bearing.toFixed(1))}°</p>
            <p className="text-sm text-ivory/60">
              عن الشمال باتجاه عقارب الساعة
            </p>
            <p className="pt-3 text-sm text-ivory/70">
              المسافة إلى الكعبة المشرفة:{" "}
              <span className="font-semibold text-gold-light tabular-nums">
                {toArabicDigits(Math.round(distance).toLocaleString("en-US"))} كم
              </span>
            </p>
          </div>
        ) : (
          <p className="mt-6 text-sm text-ivory/55">جارٍ حساب الاتجاه…</p>
        )}
      </div>
    </div>
  );
}
