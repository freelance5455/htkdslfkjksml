import React, { useEffect, useState } from 'react';
import { Smartphone, RotateCw } from 'lucide-react';

export const LandscapeNotice: React.FC = () => {
  const [isLandscapeMobile, setIsLandscapeMobile] = useState(false);

  useEffect(() => {
    const checkOrientation = () => {
      // If mobile device in landscape orientation
      const landscapeMobile = window.innerWidth > window.innerHeight && window.innerHeight < 600;
      setIsLandscapeMobile(landscapeMobile);
    };

    checkOrientation();
    window.addEventListener('resize', checkOrientation);
    window.addEventListener('orientationchange', checkOrientation);
    return () => {
      window.removeEventListener('resize', checkOrientation);
      window.removeEventListener('orientationchange', checkOrientation);
    };
  }, []);

  if (!isLandscapeMobile) return null;

  return (
    <div className="fixed top-2 left-1/2 -translate-x-1/2 z-50 bg-amber-500/95 text-slate-950 font-black text-xs px-3.5 py-1.5 rounded-full shadow-xl flex items-center space-x-2 animate-pulse border border-white">
      <Smartphone className="w-3.5 h-3.5" />
      <span>For best experience, rotate your phone to Portrait 9:16</span>
      <RotateCw className="w-3.5 h-3.5" />
    </div>
  );
};
