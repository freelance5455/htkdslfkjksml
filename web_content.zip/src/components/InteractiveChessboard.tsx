import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Color, PieceSymbol, Square, Move } from 'chess.js';
import { X } from 'lucide-react';
import { ChessPieceSvg } from './ChessPieces';

export interface BoardCell {
  square: Square;
  type: PieceSymbol;
  color: Color;
}

export type PieceFlipMode = 'turn' | 'tabletop' | 'none';

export interface AnimatedMoveInfo {
  id: number;
  from: Square;
  to: Square;
  captured?: PieceSymbol;
  flags: string;
  wasDragged: boolean;
}

export interface PendingPromotion {
  from: Square;
  to: Square;
  color: Color;
}

interface InteractiveChessboardProps {
  board: (BoardCell | null)[][];
  turn: Color;
  boardOrientation: 'white' | 'black';
  pieceFlipMode: PieceFlipMode;
  selectedSquare: Square | null;
  validMovesForSelected: Move[];
  lastMove?: AnimatedMoveInfo | null;
  checkedKingSquare: Square | null;
  pendingPromotion: PendingPromotion | null;
  disabled?: boolean;
  onSquareClick: (square: Square) => void;
  onPieceDrop: (from: Square, to: Square, wasDragged: boolean) => void;
  onSelectPromotion: (piece: 'q' | 'r' | 'b' | 'n') => void;
  onCancelPromotion: () => void;
}

interface DragState {
  from: Square;
  piece: { type: PieceSymbol; color: Color };
  startX: number;
  startY: number;
  currentX: number;
  currentY: number;
  hasMovedThreshold: boolean;
  hoveredSquare: Square | null;
}

const FILES = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
const RANKS = ['8', '7', '6', '5', '4', '3', '2', '1'];

const PROMOTION_OPTIONS: { symbol: 'q' | 'n' | 'r' | 'b'; label: string }[] = [
  { symbol: 'q', label: 'Queen' },
  { symbol: 'n', label: 'Knight' },
  { symbol: 'r', label: 'Rook' },
  { symbol: 'b', label: 'Bishop' },
];

function getVisualCoords(
  square: Square,
  boardOrientation: 'white' | 'black'
): { row: number; col: number } {
  const fileIndex = FILES.indexOf(square[0]);
  const rankIndex = RANKS.indexOf(square[1]);
  return {
    row: boardOrientation === 'white' ? rankIndex : 7 - rankIndex,
    col: boardOrientation === 'white' ? fileIndex : 7 - fileIndex,
  };
}

export const InteractiveChessboard: React.FC<InteractiveChessboardProps> = ({
  board,
  turn,
  boardOrientation,
  pieceFlipMode,
  selectedSquare,
  validMovesForSelected,
  lastMove,
  checkedKingSquare,
  pendingPromotion,
  disabled = false,
  onSquareClick,
  onPieceDrop,
  onSelectPromotion,
  onCancelPromotion,
}) => {
  const boardRef = useRef<HTMLDivElement | null>(null);
  const pieceRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const lastAnimatedIdRef = useRef<number>(0);
  const [dragState, setDragState] = useState<DragState | null>(null);
  const [captureBurstSquare, setCaptureBurstSquare] = useState<Square | null>(null);

  // Determine whether a given piece color should be rotated 180 degrees
  const shouldRotatePiece = useCallback(
    (pieceColor: Color): boolean => {
      const topSideColor: Color = boardOrientation === 'white' ? 'b' : 'w';
      if (pieceFlipMode === 'turn') {
        // Rotate all pieces 180deg when it is the top player's turn
        return turn === topSideColor;
      }
      if (pieceFlipMode === 'tabletop') {
        // Top player's pieces always face top (180deg); bottom player's pieces face bottom (0deg)
        return pieceColor === topSideColor;
      }
      return false;
    },
    [boardOrientation, pieceFlipMode, turn]
  );

  // Dynamic Chess.com-style FLIP / Web Animations API flight when a move occurs
  useEffect(() => {
    if (!lastMove || lastMove.id === lastAnimatedIdRef.current) return;
    lastAnimatedIdRef.current = lastMove.id;

    const animateSquareFlight = (fromSq: Square, toSq: Square, wasDragged: boolean) => {
      const el = pieceRefs.current[toSq];
      if (!el) return;

      if (wasDragged) {
        // Snappy landing settle after drag-and-drop
        el.animate(
          [
            { transform: 'scale(1.16)' },
            { transform: 'scale(0.96)' },
            { transform: 'scale(1)' },
          ],
          {
            duration: 165,
            easing: 'cubic-bezier(0.22, 1, 0.36, 1)',
          }
        );
        return;
      }

      const fromCoords = getVisualCoords(fromSq, boardOrientation);
      const toCoords = getVisualCoords(toSq, boardOrientation);
      const deltaCol = (fromCoords.col - toCoords.col) * 100;
      const deltaRow = (fromCoords.row - toCoords.row) * 100;

      el.animate(
        [
          {
            transform: `translate(${deltaCol}%, ${deltaRow}%) scale(1.02)`,
            zIndex: '30',
          },
          {
            transform: `translate(${deltaCol * 0.32}%, ${deltaRow * 0.32}%) scale(1.22)`,
            zIndex: '30',
            offset: 0.55,
          },
          {
            transform: 'translate(0%, 0%) scale(1)',
            zIndex: '10',
          },
        ],
        {
          duration: 220,
          easing: 'cubic-bezier(0.2, 0.88, 0.25, 1.02)',
        }
      );
    };

    animateSquareFlight(lastMove.from, lastMove.to, lastMove.wasDragged);

    // If the move was castling, also animate the Rook gliding across!
    if (lastMove.flags.includes('k') || lastMove.flags.includes('q')) {
      const rank = lastMove.to[1];
      const isKingside = lastMove.flags.includes('k');
      const rookFrom = `${isKingside ? 'h' : 'a'}${rank}` as Square;
      const rookTo = `${isKingside ? 'f' : 'd'}${rank}` as Square;
      animateSquareFlight(rookFrom, rookTo, false);
    }

    // Trigger capture ring pulse if a piece was captured
    if (lastMove.captured || lastMove.flags.includes('e')) {
      setCaptureBurstSquare(lastMove.to);
      const timer = window.setTimeout(() => setCaptureBurstSquare(null), 280);
      return () => window.clearTimeout(timer);
    }
  }, [lastMove, boardOrientation]);

  // Convert client (x, y) coordinates to a chess Square ('a1'..'h8')
  const getSquareFromPoint = useCallback(
    (clientX: number, clientY: number): Square | null => {
      const el = boardRef.current;
      if (!el) return null;
      const rect = el.getBoundingClientRect();
      if (
        clientX < rect.left ||
        clientX > rect.right ||
        clientY < rect.top ||
        clientY > rect.bottom
      ) {
        return null;
      }

      const relX = (clientX - rect.left) / rect.width;
      const relY = (clientY - rect.top) / rect.height;

      const colIndex = Math.min(7, Math.max(0, Math.floor(relX * 8)));
      const rowIndex = Math.min(7, Math.max(0, Math.floor(relY * 8)));

      const file =
        boardOrientation === 'white' ? FILES[colIndex] : FILES[7 - colIndex];
      const rank =
        boardOrientation === 'white' ? RANKS[rowIndex] : RANKS[7 - rowIndex];

      return `${file}${rank}` as Square;
    },
    [boardOrientation]
  );

  const handlePointerDown = (
    e: React.PointerEvent<HTMLDivElement>,
    square: Square,
    cell: BoardCell | null
  ) => {
    if (disabled) return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;

    // If promotion popup is open and user clicks on the board outside it, close promotion popup
    if (pendingPromotion) {
      onCancelPromotion();
      return;
    }

    if (cell && cell.color === turn) {
      e.currentTarget.setPointerCapture(e.pointerId);
      setDragState({
        from: square,
        piece: { type: cell.type, color: cell.color },
        startX: e.clientX,
        startY: e.clientY,
        currentX: e.clientX,
        currentY: e.clientY,
        hasMovedThreshold: false,
        hoveredSquare: square,
      });

      if (selectedSquare !== square) {
        onSquareClick(square);
      }
    } else {
      onSquareClick(square);
    }
  };

  useEffect(() => {
    if (!dragState) return;

    const handleGlobalPointerMove = (e: PointerEvent) => {
      const dx = e.clientX - dragState.startX;
      const dy = e.clientY - dragState.startY;
      const dist = Math.hypot(dx, dy);
      const hovered = getSquareFromPoint(e.clientX, e.clientY);

      setDragState((prev) =>
        prev
          ? {
              ...prev,
              currentX: e.clientX,
              currentY: e.clientY,
              hasMovedThreshold: prev.hasMovedThreshold || dist > 6,
              hoveredSquare: hovered,
            }
          : null
      );
    };

    const handleGlobalPointerUp = (e: PointerEvent) => {
      const targetSquare = getSquareFromPoint(e.clientX, e.clientY);

      if (
        dragState.hasMovedThreshold &&
        targetSquare &&
        targetSquare !== dragState.from
      ) {
        onPieceDrop(dragState.from, targetSquare, true);
      }
      setDragState(null);
    };

    window.addEventListener('pointermove', handleGlobalPointerMove);
    window.addEventListener('pointerup', handleGlobalPointerUp);
    window.addEventListener('pointercancel', handleGlobalPointerUp);

    return () => {
      window.removeEventListener('pointermove', handleGlobalPointerMove);
      window.removeEventListener('pointerup', handleGlobalPointerUp);
      window.removeEventListener('pointercancel', handleGlobalPointerUp);
    };
  }, [dragState, getSquareFromPoint, onPieceDrop]);

  const displayRowIndices =
    boardOrientation === 'white'
      ? [0, 1, 2, 3, 4, 5, 6, 7]
      : [7, 6, 5, 4, 3, 2, 1, 0];
  const displayColIndices =
    boardOrientation === 'white'
      ? [0, 1, 2, 3, 4, 5, 6, 7]
      : [7, 6, 5, 4, 3, 2, 1, 0];

  // Calculate inline promotion popover position if active
  const promotionCoords = pendingPromotion
    ? getVisualCoords(pendingPromotion.to, boardOrientation)
    : null;
  const isPromotionAtTopEdge = promotionCoords ? promotionCoords.row === 0 : true;

  return (
    <div
      ref={boardRef}
      className="relative w-full h-full grid grid-cols-8 grid-rows-8 touch-none select-none"
    >
      {displayRowIndices.map((rIdx, visualRow) =>
        displayColIndices.map((cIdx, visualCol) => {
          const square = `${FILES[cIdx]}${RANKS[rIdx]}` as Square;
          const cell = board[rIdx][cIdx];
          const isLight = (rIdx + cIdx) % 2 === 0;

          const isSelected = selectedSquare === square;
          const isLastMove =
            lastMove?.from === square || lastMove?.to === square;
          const isKingInCheck = checkedKingSquare === square;
          const validMoveToHere = validMovesForSelected.find(
            (m) => m.to === square
          );
          const isCaptureTarget =
            Boolean(validMoveToHere?.captured) ||
            Boolean(validMoveToHere?.flags.includes('e'));
          const isBeingDragged =
            dragState?.from === square && dragState.hasMovedThreshold;
          const isDragHoverTarget =
            dragState?.hasMovedThreshold &&
            dragState?.hoveredSquare === square &&
            Boolean(validMoveToHere);

          // Hide origin pawn while inline promotion picker is open
          const isHiddenForPendingPromotion =
            pendingPromotion?.from === square;

          const showRankLabel = visualCol === 0;
          const showFileLabel = visualRow === 7;

          let squareBg = isLight ? '#EBECD0' : '#739552';
          if (isSelected) {
            squareBg = isLight ? '#F5F682' : '#B9CA43';
          } else if (isLastMove) {
            squareBg = isLight ? '#F5F682' : '#BBCB45';
          }

          const rotatePiece = cell ? shouldRotatePiece(cell.color) : false;

          return (
            <div
              key={square}
              data-square={square}
              onPointerDown={(e) => handlePointerDown(e, square, cell)}
              style={{ backgroundColor: squareBg }}
              className={`relative flex items-center justify-center w-full h-full transition-colors duration-75 ${
                (cell && cell.color === turn && !disabled) || validMoveToHere
                  ? 'cursor-pointer'
                  : 'cursor-default'
              }`}
            >
              {/* Checked King Red Glow */}
              {isKingInCheck && (
                <div
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    background:
                      'radial-gradient(circle, rgba(239, 68, 68, 0.92) 0%, rgba(220, 38, 38, 0.55) 62%, transparent 90%)',
                  }}
                />
              )}

              {/* Capture Burst Effect */}
              {captureBurstSquare === square && (
                <div className="absolute inset-1 rounded-full border-4 border-amber-300/75 animate-ping pointer-events-none z-20" />
              )}

              {/* Drag Hover Target Highlight Frame */}
              {isDragHoverTarget && (
                <div className="absolute inset-0 border-[3px] border-white/85 pointer-events-none z-10" />
              )}

              {/* Rank Coordinate Label */}
              {showRankLabel && (
                <span
                  className={`absolute top-1 left-1.5 text-[10px] sm:text-xs font-bold leading-none pointer-events-none font-mono ${
                    isLight ? 'text-[#739552]' : 'text-[#EBECD0]'
                  }`}
                >
                  {RANKS[rIdx]}
                </span>
              )}

              {/* File Coordinate Label */}
              {showFileLabel && (
                <span
                  className={`absolute bottom-1 right-1.5 text-[10px] sm:text-xs font-bold leading-none pointer-events-none font-mono ${
                    isLight ? 'text-[#739552]' : 'text-[#EBECD0]'
                  }`}
                >
                  {FILES[cIdx]}
                </span>
              )}

              {/* Valid Target Square Indicators */}
              {validMoveToHere && !isCaptureTarget && !pendingPromotion && (
                <div className="w-[30%] h-[30%] rounded-full bg-black/20 pointer-events-none z-10 transition-transform duration-150" />
              )}

              {validMoveToHere && isCaptureTarget && !pendingPromotion && (
                <div className="absolute inset-[7%] rounded-full border-[5px] sm:border-[6px] border-black/22 pointer-events-none z-10" />
              )}

              {/* Render Chess Piece SVG with Smooth Flip Rotation & Flight Ref */}
              {cell && !isHiddenForPendingPromotion && (
                <div
                  ref={(el) => {
                    pieceRefs.current[square] = el;
                  }}
                  className={`w-[85%] h-[85%] flex items-center justify-center will-change-transform ${
                    isBeingDragged ? 'opacity-20 scale-90' : 'opacity-100'
                  }`}
                >
                  <div
                    className={`w-full h-full transition-transform duration-300 ease-out ${
                      rotatePiece ? 'rotate-180' : 'rotate-0'
                    }`}
                  >
                    <ChessPieceSvg color={cell.color} type={cell.type} />
                  </div>
                </div>
              )}
            </div>
          );
        })
      )}

      {/* Chess.com-style Compact Column Pawn Promotion Popover */}
      {pendingPromotion && promotionCoords && (
        <div
          style={{
            left: `${promotionCoords.col * 12.5}%`,
            width: '12.5%',
            ...(isPromotionAtTopEdge ? { top: 0 } : { bottom: 0 }),
          }}
          onPointerDown={(e) => e.stopPropagation()}
          className={`absolute z-30 flex ${
            isPromotionAtTopEdge ? 'flex-col' : 'flex-col-reverse'
          } bg-white/98 rounded-md shadow-[0_10px_30px_rgba(0,0,0,0.65)] ring-1 ring-black/20 overflow-hidden animate-in fade-in zoom-in-95 duration-150`}
        >
          {PROMOTION_OPTIONS.map((item) => {
            const rotatePromoPiece = shouldRotatePiece(pendingPromotion.color);
            return (
              <button
                key={item.symbol}
                type="button"
                onClick={() => onSelectPromotion(item.symbol)}
                title={`Promote to ${item.label}`}
                className="w-full aspect-square p-1.5 flex items-center justify-center hover:bg-[#81B64C]/30 active:bg-[#81B64C]/50 transition-colors cursor-pointer"
              >
                <div
                  className={`w-full h-full transition-transform duration-200 hover:scale-110 ${
                    rotatePromoPiece ? 'rotate-180' : 'rotate-0'
                  }`}
                >
                  <ChessPieceSvg
                    color={pendingPromotion.color}
                    type={item.symbol}
                  />
                </div>
              </button>
            );
          })}
          <button
            type="button"
            onClick={onCancelPromotion}
            title="Cancel promotion"
            className="w-full py-1 bg-[#E2E4C8] hover:bg-[#D4D6B8] text-[#262522] flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-3.5 h-3.5 stroke-[2.5]" />
          </button>
        </div>
      )}

      {/* Floating Dragged Piece Ghost */}
      {dragState && dragState.hasMovedThreshold && boardRef.current && (
        <div
          style={{
            position: 'fixed',
            left: dragState.currentX,
            top: dragState.currentY,
            width: boardRef.current.clientWidth / 8,
            height: boardRef.current.clientHeight / 8,
            transform: `translate(-50%, -50%) scale(1.18) ${
              shouldRotatePiece(dragState.piece.color) ? 'rotate(180deg)' : ''
            }`,
          }}
          className="pointer-events-none z-50 flex items-center justify-center"
        >
          <ChessPieceSvg
            color={dragState.piece.color}
            type={dragState.piece.type}
          />
        </div>
      )}
    </div>
  );
};
