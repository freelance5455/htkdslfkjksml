import React, { useState } from 'react';
import { FileSpreadsheet, CheckCircle2, Search, Filter } from 'lucide-react';
import { Ledger } from '../types/tally';
import { formatCurrency } from '../utils/tallyEngine';

interface TrialBalanceViewProps {
  ledgers: Ledger[];
  onSelectLedger?: (ledgerId: string) => void;
}

export const TrialBalanceView: React.FC<TrialBalanceViewProps> = ({ ledgers, onSelectLedger }) => {
  const [searchQuery, setSearchQuery] = useState<string>('');

  const activeLedgers = ledgers
    .filter((l) => l.currentBalance > 0)
    .filter((l) => l.name.toLowerCase().includes(searchQuery.toLowerCase()) || l.group.toLowerCase().includes(searchQuery.toLowerCase()));

  const totalDebit = activeLedgers
    .filter((l) => l.currentBalanceType === 'Dr')
    .reduce((sum, l) => sum + l.currentBalance, 0);

  const totalCredit = activeLedgers
    .filter((l) => l.currentBalanceType === 'Cr')
    .reduce((sum, l) => sum + l.currentBalance, 0);

  return (
    <div className="flex-1 flex flex-col pb-8 text-slate-800 dark:text-slate-100">
      {/* Header bar */}
      <div className="bg-emerald-900 text-white px-4 py-3 shadow-xs">
        <div className="text-[10px] uppercase font-bold text-emerald-300 tracking-wider">
          Audit & Verification
        </div>
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold">Trial Balance (Dr & Cr Matching)</h2>
          <span className="text-[11px] text-emerald-200 font-mono">Real-Time</span>
        </div>
      </div>

      {/* Verification Banner */}
      <div className="p-3 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 space-y-2">
        <div className="flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-1.5 font-bold text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 className="w-4 h-4" />
            <span>Double-Entry Balance Audited</span>
          </div>
          <span className="text-slate-500">
            {activeLedgers.length} Active Accounts
          </span>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search account ledger..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs focus:ring-2 focus:ring-emerald-500"
          />
        </div>
      </div>

      {/* Table */}
      <div className="p-3">
        <div className="bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-xs">
          <div className="grid grid-cols-12 px-3 py-2 bg-slate-100 dark:bg-slate-800 text-[11px] font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300">
            <div className="col-span-6">Particulars (Ledger)</div>
            <div className="col-span-3 text-right">Debit (₹)</div>
            <div className="col-span-3 text-right">Credit (₹)</div>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-700/60 text-xs font-mono">
            {activeLedgers.map((led) => {
              const isDr = led.currentBalanceType === 'Dr';
              return (
                <div
                  key={led.id}
                  onClick={() => onSelectLedger?.(led.id)}
                  className="grid grid-cols-12 px-3 py-2.5 items-center hover:bg-slate-50 dark:hover:bg-slate-700/40 cursor-pointer transition-colors"
                >
                  <div className="col-span-6 pr-1">
                    <div className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                      {led.name}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate font-sans">
                      {led.group}
                    </div>
                  </div>

                  <div className="col-span-3 text-right font-medium tabular-nums text-slate-900 dark:text-slate-200">
                    {isDr ? formatCurrency(led.currentBalance) : '—'}
                  </div>

                  <div className="col-span-3 text-right font-medium tabular-nums text-slate-900 dark:text-slate-200">
                    {!isDr ? formatCurrency(led.currentBalance) : '—'}
                  </div>
                </div>
              );
            })}

            {/* Total Row */}
            <div className="grid grid-cols-12 px-3 py-3 bg-emerald-50 dark:bg-emerald-950/50 font-bold text-xs text-slate-900 dark:text-white border-t-2 border-emerald-500">
              <div className="col-span-6">TOTAL BALANCES</div>
              <div className="col-span-3 text-right tabular-nums text-emerald-700 dark:text-emerald-300">
                {formatCurrency(totalDebit)}
              </div>
              <div className="col-span-3 text-right tabular-nums text-emerald-700 dark:text-emerald-300">
                {formatCurrency(totalCredit)}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
