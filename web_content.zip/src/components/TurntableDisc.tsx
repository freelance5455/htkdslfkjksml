/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState, useEffect } from 'react';
import { Disc3, Radio } from 'lucide-react';
import { audioEngine } from '../services/audioEngine';

interface TurntableDiscProps {
  isPlaying: boolean;
  coverUrl?: string;
  playbackRate: number;
  onRateChange: (rate: number) => void;
  trackTitle?: string;
}

export const TurntableDisc: React.FC<TurntableDiscProps> = ({
  isPlaying,
  coverUrl,
  playbackRate,
  onRateChange,
  trackTitle = 'DJ SUNNY',
}) => {
  const [rotation, setRotation] = useState(0);
  const [isScratching, setIsScratching] = useState(false);
  const [pitchOffset, setPitchOffset] = useState(0); // -16 to +16 %
  const [isBeatPulse, setIsBeatPulse] = useState(false);

  const turntableRef = useRef<HTMLDivElement | null>(null);
  const lastTouchAngleRef = useRef<number | null>(null);
  const animRef = useRef<number | null>(null);

  // Sync pitch with audio engine
  useEffect(() => {
    const rate = 1.0 + pitchOffset / 100;
    onRateChange(rate);
  }, [pitchOffset, onRateChange]);

  // Audio beat pulse listener
  useEffect(() => {
    const handleBeat = () => {
      setIsBeatPulse(true);
      setTimeout(() => setIsBeatPulse(false), 90);
    };
    audioEngine.addBeatListener(handleBeat);
    return () => audioEngine.removeBeatListener(handleBeat);
  }, []);

  // Continuous rotation loop when playing & not scratching
  useEffect(() => {
    let lastTime = performance.now();
    const spinLoop = (now: number) => {
      const delta = (now - lastTime) / 1000;
      lastTime = now;

      if (isPlaying && !isScratching) {
        // Standard 33.3 RPM speed = 0.55 rev/sec = 200 deg/sec
        const speed = 200 * playbackRate;
        setRotation((prev) => (prev + speed * delta) % 360);
      }
      animRef.current = requestAnimationFrame(spinLoop);
    };

    animRef.current = requestAnimationFrame(spinLoop);
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [isPlaying, isScratching, playbackRate]);

  // Calculate angle relative to vinyl center
  const getPointerAngle = (clientX: number, clientY: number) => {
    if (!turntableRef.current) return 0;
    const rect = turntableRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const dx = clientX - centerX;
    const dy = clientY - centerY;
    return Math.atan2(dy, dx) * (180 / Math.PI);
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    setIsScratching(true);
    audioEngine.ensureContext();
    lastTouchAngleRef.current = getPointerAngle(e.clientX, e.clientY);
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    audioEngine.triggerScratch(1, 1.2);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isScratching || lastTouchAngleRef.current === null) return;
    const currentAngle = getPointerAngle(e.clientX, e.clientY);
    let deltaAngle = currentAngle - lastTouchAngleRef.current;

    // Normalizing wrap-around jumps
    if (deltaAngle > 180) deltaAngle -= 360;
    if (deltaAngle < -180) deltaAngle += 360;

    if (Math.abs(deltaAngle) > 1.2) {
      setRotation((prev) => (prev + deltaAngle) % 360);
      const direction = deltaAngle > 0 ? 1 : -1;
      const speed = Math.min(3, Math.abs(deltaAngle) / 8);
      audioEngine.triggerScratch(direction, speed);
      lastTouchAngleRef.current = currentAngle;
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsScratching(false);
    lastTouchAngleRef.current = null;
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      // safe fallback
    }
  };

  return (
    <div className="relative w-full max-w-[360px] mx-auto select-none">
      {/* Turntable Plinth / Chassis */}
      <div className="relative p-4 rounded-3xl bg-gradient-to-b from-[#131422] to-[#0a0a14] border border-cyan-500/30 shadow-[0_10px_35px_rgba(0,0,0,0.8)]">
        
        {/* Top Deck Badging */}
        <div className="flex items-center justify-between mb-2 px-1">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-cyan-400" />
            <span className="text-[11px] font-bold tracking-widest text-cyan-300 font-dj uppercase">
              DECK A • PRO-SERIES
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-semibold text-zinc-400">PITCH</span>
            <span className={`text-[11px] font-mono font-bold ${pitchOffset === 0 ? 'text-cyan-400' : 'text-purple-400'}`}>
              {pitchOffset > 0 ? `+${pitchOffset}%` : `${pitchOffset}%`}
            </span>
          </div>
        </div>

        {/* Main Turntable Platter Area */}
        <div className="relative flex items-center justify-center py-2">
          
          {/* Audio-reactive LED halo around vinyl platter */}
          <div
            className={`absolute w-[290px] h-[290px] rounded-full transition-all duration-100 ${
              isBeatPulse
                ? 'scale-105 shadow-[0_0_40px_rgba(0,240,255,0.7),0_0_70px_rgba(176,38,255,0.4)]'
                : 'shadow-[0_0_20px_rgba(0,240,255,0.25)]'
            }`}
          />

          {/* Strobe dots outer ring on aluminum platter */}
          <div className="relative w-[280px] h-[280px] rounded-full bg-gradient-to-tr from-zinc-800 via-zinc-900 to-zinc-700 p-2 shadow-inner border border-zinc-600/40 flex items-center justify-center">
            
            {/* Real Vinyl Record */}
            <div
              ref={turntableRef}
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              onPointerCancel={handlePointerUp}
              style={{
                transform: `rotate(${rotation}deg)`,
                cursor: isScratching ? 'grabbing' : 'grab',
              }}
              className="relative w-[256px] h-[256px] rounded-full vinyl-grooves border-2 border-zinc-700/60 shadow-2xl flex items-center justify-center touch-none overflow-hidden transition-transform ease-linear"
            >
              {/* Dynamic Vinyl Light Reflection Sheen */}
              <div className="absolute inset-0 rounded-full vinyl-sheen pointer-events-none" />

              {/* Center Vinyl Label (DJ SUNNY Crest or Album Art) */}
              <div className="relative w-24 h-24 rounded-full border-2 border-cyan-400/80 shadow-[0_0_15px_rgba(0,240,255,0.6)] overflow-hidden flex flex-col items-center justify-center bg-black/90">
                {coverUrl ? (
                  <img
                    src={coverUrl}
                    alt={trackTitle}
                    className="w-full h-full object-cover opacity-85"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-cyan-900/60 via-purple-900/60 to-black p-1">
                    <Disc3 className="w-8 h-8 text-cyan-300 animate-spin" />
                    <span className="text-[8px] font-extrabold tracking-widest text-cyan-200 uppercase mt-0.5 font-dj text-center">
                      DJ SUNNY
                    </span>
                  </div>
                )}

                {/* Center spindle hole */}
                <div className="absolute w-4 h-4 rounded-full bg-zinc-300 border-2 border-zinc-800 shadow-inner z-10" />
              </div>
            </div>

            {/* Tonearm Assembly */}
            <div
              className={`absolute top-2 right-2 pointer-events-none transition-transform duration-700 ease-out origin-[20px_20px] ${
                isPlaying ? 'rotate-[26deg]' : 'rotate-[-5deg]'
              }`}
              style={{ width: '90px', height: '170px' }}
            >
              {/* Pivot Gimbal Base */}
              <div className="w-8 h-8 rounded-full bg-gradient-to-b from-zinc-600 to-zinc-900 border border-zinc-500 shadow-md flex items-center justify-center">
                <div className="w-3 h-3 rounded-full bg-cyan-400 shadow-[0_0_8px_#00f0ff]" />
              </div>

              {/* Tonearm metallic shaft */}
              <div className="w-1.5 h-32 bg-gradient-to-r from-zinc-300 via-zinc-400 to-zinc-500 shadow-lg ml-3.5 origin-top transform rotate-[-8deg] relative">
                {/* Cartridge & Stylus headshell */}
                <div className="absolute bottom-0 -left-1.5 w-4 h-6 bg-purple-600 rounded-sm border border-purple-300 shadow-[0_0_6px_#b026ff]">
                  <div className="w-1 h-2 bg-red-500 mx-auto mt-3" />
                </div>
              </div>
            </div>

          </div>
        </div>

        {/* Pitch Slider & Turntable Deck Controls */}
        <div className="mt-3 pt-3 border-t border-cyan-500/20 flex items-center justify-between px-2 gap-4">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                audioEngine.triggerScratch(1, 1.4);
                setTimeout(() => audioEngine.triggerScratch(-1, 1.2), 120);
              }}
              className="px-3 py-1.5 rounded-lg bg-zinc-800/80 hover:bg-zinc-700 border border-cyan-400/40 text-cyan-300 text-[11px] font-bold font-dj uppercase active:scale-95 transition-all shadow-[0_0_8px_rgba(0,240,255,0.3)]"
            >
              SCRATCH FX
            </button>
            <button
              onClick={() => setPitchOffset(0)}
              className="px-2.5 py-1.5 rounded-lg bg-zinc-800/80 hover:bg-zinc-700 border border-purple-400/40 text-purple-300 text-[11px] font-bold font-mono active:scale-95 transition-all"
              title="Reset Pitch to 0%"
            >
              0% RESET
            </button>
          </div>

          {/* Precision Pitch Bend Slider */}
          <div className="flex-1 max-w-[150px] flex items-center gap-1.5">
            <span className="text-[10px] text-zinc-400 font-mono">-16%</span>
            <input
              type="range"
              min="-16"
              max="16"
              step="0.5"
              value={pitchOffset}
              onChange={(e) => setPitchOffset(parseFloat(e.target.value))}
              className="w-full dj-slider cursor-pointer"
            />
            <span className="text-[10px] text-zinc-400 font-mono">+16%</span>
          </div>
        </div>

      </div>
    </div>
  );
};
