/**
 * GODEX Phase 0 - Multi-Tab Code Editor & Workspace
 * Professional IDE editor area supporting multiple open tabs, line numbers,
 * breadcrumb path, line metrics, and instant file synchronization.
 */

import React, { useState } from 'react';
import { 
  FileCode, 
  X, 
  Copy, 
  Check, 
  Sparkles, 
  Save, 
  Code2, 
  Layers, 
  Maximize2, 
  Minimize2,
  FileText,
  Play
} from 'lucide-react';

interface GodexEditorWorkspaceProps {
  files: Record<string, string>;
  activeFile: string;
  openTabs: string[];
  onSelectTab: (path: string) => void;
  onCloseTab: (path: string) => void;
  onUpdateFileContent: (path: string, content: string) => void;
  onOpenDiff: () => void;
  onRunPreview: () => void;
}

export const GodexEditorWorkspace: React.FC<GodexEditorWorkspaceProps> = ({
  files,
  activeFile,
  openTabs,
  onSelectTab,
  onCloseTab,
  onUpdateFileContent,
  onOpenDiff,
  onRunPreview
}) => {
  const currentContent = files[activeFile] || '';
  const [copied, setCopied] = useState(false);
  const lines = currentContent.split('\n');

  const handleCopy = () => {
    navigator.clipboard.writeText(currentContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const getLanguageLabel = (path: string) => {
    if (path.endsWith('.tsx') || path.endsWith('.ts')) return 'TypeScript React';
    if (path.endsWith('.jsx') || path.endsWith('.js')) return 'JavaScript';
    if (path.endsWith('.json')) return 'JSON';
    if (path.endsWith('.css')) return 'CSS / Tailwind';
    if (path.endsWith('.html')) return 'HTML';
    if (path.endsWith('.md')) return 'Markdown';
    return 'Plain Text';
  };

  return (
    <div className="flex-1 h-full flex flex-col bg-[#08090D] overflow-hidden select-none font-sans">
      {/* Multi-Tab Bar */}
      <div className="h-9 border-b border-[#1C2230] bg-[#0A0D14] flex items-center justify-between shrink-0 overflow-x-auto no-scrollbar">
        {/* Open Tabs */}
        <div className="flex items-center h-full">
          {openTabs.map((tabPath) => {
            const isActive = tabPath === activeFile;
            const fileName = tabPath.split('/').pop() || tabPath;
            return (
              <div
                key={tabPath}
                onClick={() => onSelectTab(tabPath)}
                className={`h-full flex items-center gap-2 px-3 border-r border-[#1C2230] cursor-pointer text-xs font-mono transition-colors group ${
                  isActive
                    ? 'bg-[#08090D] text-cyan-300 border-t-2 border-t-cyan-400 font-semibold'
                    : 'bg-[#0E121B] text-neutral-400 hover:bg-[#131824] hover:text-neutral-200 border-t-2 border-t-transparent'
                }`}
              >
                <FileCode className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-neutral-500'}`} />
                <span className="truncate max-w-[140px]">{fileName}</span>
                {openTabs.length > 1 && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onCloseTab(tabPath);
                    }}
                    className="p-0.5 rounded hover:bg-[#1C2538] text-neutral-500 hover:text-neutral-200 opacity-0 group-hover:opacity-100 transition-opacity"
                    title="Close Tab"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            );
          })}
        </div>

        {/* Action Buttons in Editor Bar */}
        <div className="flex items-center gap-1.5 px-2 sm:px-3 shrink-0">
          <button
            onClick={onRunPreview}
            className="flex items-center gap-1 px-2 py-1 sm:py-0.5 rounded bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-[10px] font-mono font-semibold transition-all shadow-xs"
            title="Launch Sandbox Live Preview"
          >
            <Play className="w-3 h-3 fill-current" />
            <span>PREVIEW</span>
          </button>

          <button
            onClick={onOpenDiff}
            className="flex items-center gap-1 px-2 py-1 sm:py-0.5 rounded bg-[#121824] hover:bg-[#1A2335] border border-[#202C42] text-cyan-300 text-[10px] font-mono font-medium transition-colors"
            title="Inspect AI Modifications Diff"
          >
            <Sparkles className="w-3 h-3 text-cyan-400" />
            <span>DIFF</span>
          </button>

          <button
            onClick={handleCopy}
            className="flex items-center gap-1 px-2 py-1 sm:py-0.5 rounded bg-[#121824] hover:bg-[#1A2335] border border-[#202C42] text-neutral-300 text-[10px] font-mono font-medium transition-colors"
            title="Copy source code"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            <span>{copied ? 'COPIED' : 'COPY'}</span>
          </button>
        </div>
      </div>

      {/* Breadcrumb Path Bar */}
      <div className="h-6 bg-[#0B0E15] border-b border-[#181F2C] px-3 flex items-center justify-between text-[10px] sm:text-[11px] font-mono text-neutral-400 select-none shrink-0">
        <div className="flex items-center truncate">
          <span className="text-neutral-500">workspace</span>
          <span className="mx-1 text-neutral-600">/</span>
          <span className="text-cyan-300 font-medium truncate">{activeFile}</span>
        </div>
        <span className="text-[9px] text-neutral-500 hidden sm:inline font-mono">{lines.length} lines</span>
      </div>

      {/* Editor Content Area */}
      <div className="flex-1 flex overflow-hidden relative font-mono text-xs leading-relaxed bg-[#08090D] select-text">
        {/* Line Numbers Gutter */}
        <div className="w-9 sm:w-12 py-3 bg-[#06070A] border-r border-[#141822] select-none text-right pr-2 text-neutral-600 font-mono text-[10px] sm:text-[11px] overflow-hidden shrink-0">
          {lines.map((_, i) => (
            <div key={i} className="h-5 leading-5">{i + 1}</div>
          ))}
        </div>

        {/* Textarea Code Input */}
        <div className="flex-1 relative overflow-auto p-2 sm:p-3 bg-tech-dots/10 overscroll-contain">
          <textarea
            spellCheck={false}
            value={currentContent}
            onChange={(e) => onUpdateFileContent(activeFile, e.target.value)}
            className="w-full h-full min-h-[500px] bg-transparent text-neutral-200 placeholder-neutral-600 resize-none font-mono text-xs sm:text-xs leading-5 focus:outline-none whitespace-pre overflow-visible"
          />
        </div>
      </div>

      {/* Editor Footer Status Bar */}
      <div className="h-5 bg-[#0A0D14] border-t border-[#181F2C] px-3 flex items-center justify-between text-[10px] font-mono text-neutral-400 select-none shrink-0">
        <div className="flex items-center gap-3">
          <span>{lines.length} lines</span>
          <span>{currentContent.length} chars</span>
          <span className="text-cyan-400">{getLanguageLabel(activeFile)}</span>
        </div>
        <div className="flex items-center gap-3">
          <span>UTF-8</span>
          <span>Spaces: 2</span>
          <span className="text-emerald-400">Authoritative File</span>
        </div>
      </div>
    </div>
  );
};
