import React from "react";
import { motion } from "framer-motion";
import { MapPin, Clock, Users, ChevronRight, Star } from "lucide-react";
import type { JobPosting, Worker, AppNotification } from "../types";
import { Avatar, Badge, Card, cx } from "./ui";

/* ---------------- Job Card ---------------- */

export function JobCard({ job, onClick }: { job: JobPosting; onClick?: () => void }) {
  const budgetLabel = job.fixedBudget
    ? `₹${job.fixedBudget.toLocaleString("en-IN")}`
    : `₹${job.budgetMin.toLocaleString("en-IN")}–₹${job.budgetMax.toLocaleString("en-IN")}`;
  return (
    <Card interactive onClick={onClick} className="p-4">
      <div className="flex items-start gap-3">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-saffron/10 text-2xl">
          {job.emoji}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between gap-2">
            <h3 className="font-display font-bold text-[15px] truncate">{job.title}</h3>
            <ChevronRight size={16} className="shrink-0 text-ink/30 dark:text-white/30" />
          </div>
          <p className="mt-0.5 flex items-center gap-1 text-xs text-ink/55 dark:text-white/55">
            <MapPin size={12} /> {job.location.area} · {job.distanceKm} km
          </p>
          <p className="mt-2 text-sm text-ink/75 dark:text-white/75 line-clamp-1">{job.description}</p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Badge tone="saffron">{budgetLabel}</Badge>
            <Badge tone="neutral">
              <Clock size={11} className="mr-0.5" /> {job.schedule}
            </Badge>
            {job.workersRequired > 1 && (
              <Badge tone="info">
                <Users size={11} className="mr-0.5" /> {job.workersRequired} workers
              </Badge>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}

/* ---------------- Worker Card ---------------- */

export function WorkerCard({
  worker,
  onClick,
  action,
}: {
  worker: Worker;
  onClick?: () => void;
  action?: React.ReactNode;
}) {
  return (
    <Card interactive onClick={onClick} className="p-4">
      <div className="flex items-center gap-3">
        <Avatar initials={worker.initials} color={worker.color} verified={worker.verified} size="lg" />
        <div className="min-w-0 flex-1">
          <h3 className="font-display font-bold text-[15px] truncate">{worker.name}</h3>
          <p className="text-xs text-ink/55 dark:text-white/55">{worker.skillLabel}</p>
          <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
            <span className="flex items-center gap-1 font-semibold">
              <Star size={12} className="fill-saffron text-saffron" /> {worker.rating}
            </span>
            <span className="flex items-center gap-1 font-semibold text-lime-dark dark:text-lime">
              ◆ {worker.shramScore} SHRAM Score
            </span>
            <span className="text-ink/50 dark:text-white/50">{worker.distanceKm} km</span>
          </div>
          <p className="mt-1 text-[11px] text-ink/45 dark:text-white/45">{worker.jobsCompleted} jobs completed</p>
        </div>
      </div>
      {action && <div className="mt-3">{action}</div>}
    </Card>
  );
}

/* ---------------- Notification Card ---------------- */

const notifIcon: Record<string, string> = {
  job: "💼",
  payment: "₹",
  score: "◆",
  system: "🔔",
  match: "🤝",
  review: "★",
};

export function NotificationCard({
  notification,
  onClick,
}: {
  notification: AppNotification;
  onClick?: () => void;
}) {
  return (
    <button onClick={onClick} className="w-full text-left">
      <div
        className={cx(
          "flex gap-3 rounded-2xl p-4 transition-colors",
          notification.read ? "bg-transparent" : "bg-saffron/6"
        )}
      >
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-ink/5 dark:bg-white/10 text-base">
          {notifIcon[notification.type] || "🔔"}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <p className="font-display text-sm font-bold">{notification.title}</p>
            {!notification.read && <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-saffron" />}
          </div>
          <p className="mt-0.5 text-xs text-ink/60 dark:text-white/60">{notification.body}</p>
          <p className="mt-1 text-[11px] text-ink/35 dark:text-white/35">{notification.time}</p>
        </div>
      </div>
    </button>
  );
}

/* ---------------- Jodhpur Demo Map ---------------- */

export interface MapMarkerData {
  id: string;
  x: number;
  y: number;
  emoji: string;
  label?: string;
  accent?: "saffron" | "cyan" | "lime";
  pulse?: boolean;
  selected?: boolean;
}

export function JodhpurMap({
  markers,
  onMarkerClick,
  height = 280,
  showLabel = true,
  center,
}: {
  markers: MapMarkerData[];
  onMarkerClick?: (id: string) => void;
  height?: number;
  showLabel?: boolean;
  center?: { x: number; y: number };
}) {
  const accentColor: Record<string, string> = {
    saffron: "bg-saffron",
    cyan: "bg-cyan",
    lime: "bg-lime",
  };
  return (
    <div
      className="relative w-full overflow-hidden rounded-[24px] border border-ink/8 dark:border-white/10"
      style={{ height }}
    >
      {/* base */}
      <div className="absolute inset-0 bg-[#e9e4d8] dark:bg-[#121722]">
        <svg className="absolute inset-0 h-full w-full opacity-40 dark:opacity-25" preserveAspectRatio="none" viewBox="0 0 100 100">
          {[12, 28, 44, 60, 76, 92].map((v) => (
            <line key={`h${v}`} x1="0" y1={v} x2="100" y2={v} stroke="currentColor" strokeWidth="0.3" className="text-ink dark:text-white" />
          ))}
          {[10, 26, 42, 58, 74, 90].map((v) => (
            <line key={`v${v}`} x1={v} y1="0" x2={v} y2="100" stroke="currentColor" strokeWidth="0.3" className="text-ink dark:text-white" />
          ))}
          <path d="M0 65 Q 30 40 55 55 T 100 35" stroke="currentColor" strokeWidth="0.9" className="text-saffron/50" fill="none" />
          <path d="M20 0 Q 35 45 30 100" stroke="currentColor" strokeWidth="0.9" className="text-cyan/40" fill="none" />
        </svg>
      </div>

      {showLabel && (
        <div className="absolute left-3 top-3 z-10 rounded-full bg-ink/80 dark:bg-white/90 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-white dark:text-ink backdrop-blur">
          Demo Map — Jodhpur
        </div>
      )}

      {center && (
        <div
          className="absolute z-10 flex h-4 w-4 items-center justify-center"
          style={{ left: `${center.x}%`, top: `${center.y}%`, transform: "translate(-50%,-50%)" }}
        >
          <span className="absolute h-8 w-8 rounded-full bg-cyan/30 animate-pulse-soft" />
          <span className="h-3 w-3 rounded-full bg-cyan ring-4 ring-white/70 dark:ring-ink/70" />
        </div>
      )}

      {markers.map((m) => (
        <motion.button
          key={m.id}
          onClick={() => onMarkerClick?.(m.id)}
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: m.selected ? 1.25 : 1, opacity: 1 }}
          whileTap={{ scale: 0.9 }}
          transition={{ type: "spring", stiffness: 300, damping: 18 }}
          className="absolute z-10 -translate-x-1/2 -translate-y-1/2"
          style={{ left: `${m.x}%`, top: `${m.y}%` }}
        >
          <span className="relative flex items-center justify-center">
            {m.pulse && (
              <span className={cx("absolute h-9 w-9 rounded-full animate-pulse-soft", accentColor[m.accent || "saffron"], "opacity-30")} />
            )}
            <span
              className={cx(
                "flex h-8 w-8 items-center justify-center rounded-full text-sm shadow-lg ring-2 ring-white dark:ring-ink-soft",
                m.selected ? "bg-ink text-white dark:bg-offwhite dark:text-ink scale-110" : "bg-white dark:bg-ink-soft"
              )}
            >
              {m.emoji}
            </span>
          </span>
          {m.label && (
            <span className="mt-1 block rounded-md bg-white/90 dark:bg-ink/90 px-1.5 py-0.5 text-[9px] font-bold whitespace-nowrap shadow">
              {m.label}
            </span>
          )}
        </motion.button>
      ))}
    </div>
  );
}

/* ---------------- Bottom Nav ---------------- */

export function BottomNav({
  items,
  active,
  onSelect,
}: {
  items: { key: string; label: string; icon: React.ReactNode }[];
  active: string;
  onSelect: (key: string) => void;
}) {
  return (
    <div className="sticky bottom-0 z-30 border-t border-ink/8 dark:border-white/8 bg-white/90 dark:bg-ink-soft/90 backdrop-blur-lg px-2 pb-[max(10px,env(safe-area-inset-bottom))] pt-2">
      <div className="flex items-center justify-around">
        {items.map((item) => (
          <button
            key={item.key}
            onClick={() => onSelect(item.key)}
            className="flex flex-1 flex-col items-center gap-1 py-1.5 transition-transform active:scale-90"
          >
            <span
              className={cx(
                "transition-colors",
                active === item.key ? "text-saffron" : "text-ink/40 dark:text-white/40"
              )}
            >
              {item.icon}
            </span>
            <span
              className={cx(
                "text-[10px] font-semibold",
                active === item.key ? "text-saffron" : "text-ink/40 dark:text-white/40"
              )}
            >
              {item.label}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ---------------- Animated Rupee Counter ---------------- */

export function RupeeCounter({ value, className = "" }: { value: number; className?: string }) {
  const [display, setDisplay] = React.useState(0);
  React.useEffect(() => {
    let frame: number;
    const duration = 1100;
    const start = performance.now();
    function tick(now: number) {
      const progress = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplay(Math.round(eased * value));
      if (progress < 1) frame = requestAnimationFrame(tick);
    }
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [value]);
  return <span className={className}>₹{display.toLocaleString("en-IN")}</span>;
}
