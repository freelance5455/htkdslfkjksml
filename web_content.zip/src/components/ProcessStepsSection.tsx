import React from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import { 
  FileText, 
  Stethoscope, 
  PlaneTakeoff, 
  HeartHandshake, 
  Sparkles,
  Crown
} from 'lucide-react';

export const ProcessStepsSection: React.FC = () => {
  const { language, openRequestModalForService } = useApp();
  const t = translations[language];
  const isAr = language === 'ar';

  const steps = [
    {
      num: '01',
      title: t.step1Title,
      desc: t.step1Desc,
      icon: <FileText className="w-6 h-6 text-[#D4AF37]" />,
    },
    {
      num: '02',
      title: t.step2Title,
      desc: t.step2Desc,
      icon: <Stethoscope className="w-6 h-6 text-[#D4AF37]" />,
    },
    {
      num: '03',
      title: t.step3Title,
      desc: t.step3Desc,
      icon: <PlaneTakeoff className="w-6 h-6 text-[#D4AF37]" />,
    },
    {
      num: '04',
      title: t.step4Title,
      desc: t.step4Desc,
      icon: <HeartHandshake className="w-6 h-6 text-[#D4AF37]" />,
    },
    {
      num: '05',
      title: t.step5Title,
      desc: t.step5Desc,
      icon: <Sparkles className="w-6 h-6 text-[#D4AF37]" />,
    }
  ];

  return (
    <section className="py-20 bg-black text-white border-b border-[#D4AF37]/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <span className="text-xs font-bold text-amber-300 bg-[#D4AF37]/15 border border-[#D4AF37]/40 px-3.5 py-1.5 rounded-full inline-flex items-center gap-1.5 shadow-sm">
            <Crown className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>{isAr ? 'مسار رعاية سلس ومنظم' : 'Care Journey Roadmap'}</span>
          </span>
          <h2 className="text-3xl sm:text-4xl font-black bg-gradient-to-r from-white via-zinc-100 to-amber-200 bg-clip-text text-transparent">
            {t.howItWorksTitle}
          </h2>
          <p className="text-zinc-400 text-sm sm:text-base">
            {t.howItWorksSubtitle}
          </p>
        </div>

        {/* 5 Steps Linear Flow */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6 relative">
          {steps.map((step, idx) => (
            <div 
              key={idx} 
              className="relative bg-zinc-950/90 rounded-2xl p-6 border border-zinc-800 flex flex-col justify-between hover:border-[#D4AF37] transition-all hover:shadow-[0_0_20px_rgba(212,175,55,0.15)] group"
            >
              {/* Step number badge */}
              <div className="flex items-center justify-between mb-4">
                <span className="text-2xl font-black text-zinc-700 group-hover:text-amber-400 transition-colors font-mono">
                  {step.num}
                </span>
                <div className="w-12 h-12 rounded-xl bg-black border border-[#D4AF37]/30 flex items-center justify-center shadow-md group-hover:scale-110 transition-transform">
                  {step.icon}
                </div>
              </div>

              <div>
                <h3 className="font-bold text-white text-base mb-2 group-hover:text-amber-300 transition-colors">
                  {step.title}
                </h3>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  {step.desc}
                </p>
              </div>

              <div className="mt-6 pt-3 border-t border-zinc-900 flex items-center justify-between text-[11px] text-zinc-500 font-medium">
                <span>{isAr ? `مرحلة ${idx + 1} من 5` : `Stage ${idx + 1} of 5`}</span>
                <span className="w-2 h-2 rounded-full bg-[#D4AF37]"></span>
              </div>
            </div>
          ))}
        </div>

        {/* Direct Action Bottom Callout in Gold & Black */}
        <div className="mt-14 bg-gradient-to-r from-zinc-950 via-black to-zinc-950 border border-[#D4AF37]/40 rounded-3xl p-8 text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl">
          <div className="space-y-2 text-center md:text-start">
            <h3 className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-amber-200 to-[#D4AF37] bg-clip-text text-transparent">
              {isAr ? 'جاهز لبدء رحلة التنسيق الطبي أو الاستشفائي؟' : 'Ready to start your medical coordination journey?'}
            </h3>
            <p className="text-zinc-400 text-xs sm:text-sm max-w-xl">
              {isAr 
                ? 'فريق التنسيق الطبي المتخصص متاح لدراسة التقارير وتقديم عرض متكامل خلال 24 ساعة دون أي التزام مالي.'
                : 'Our specialized medical coordination desk is available to review inquiries and deliver a tailored plan within 24 hours.'}
            </p>
          </div>
          <button
            onClick={() => openRequestModalForService('medical_sector')}
            className="bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-extrabold px-6 py-3.5 rounded-xl transition-all shadow-lg shadow-amber-500/20 shrink-0 text-sm"
          >
            {isAr ? 'ابدأ خطوتك الأولى الآن' : 'Begin Step 1 Now'}
          </button>
        </div>

      </div>
    </section>
  );
};
