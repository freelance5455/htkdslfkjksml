import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  Bell,
  CheckCheck,
  CheckCircle2,
  Info,
} from 'lucide-react';
import { apiRequest, formatDateTr } from '../lib/api';
import type { NavSection, NotificationItem } from '../types/studio';

interface NotificationsViewProps {
  onNavigate: (section: NavSection) => void;
  onUnreadCountChange: (count: number) => void;
}

export const NotificationsView: React.FC<NotificationsViewProps> = ({
  onNavigate,
  onUnreadCountChange,
}) => {
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadNotifications = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiRequest<{
        notifications: NotificationItem[];
        unreadCount: number;
      }>('/api/notifications');
      setItems(res.notifications);
      onUnreadCountChange(res.unreadCount);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Bildirimler yüklenemedi.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadNotifications();
  }, []);

  const handleMarkRead = async (item: NotificationItem) => {
    if (!item.is_read) {
      try {
        const res = await apiRequest<{ ok: boolean; unreadCount: number }>(
          `/api/notifications/${item.id}/read`,
          { method: 'POST' }
        );
        setItems((prev) =>
          prev.map((n) => (n.id === item.id ? { ...n, is_read: 1 } : n))
        );
        onUnreadCountChange(res.unreadCount);
      } catch {
        // ignore
      }
    }
    if (item.link_section) {
      onNavigate(item.link_section as NavSection);
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await apiRequest('/api/notifications/read-all', { method: 'POST' });
      setItems((prev) => prev.map((n) => ({ ...n, is_read: 1 })));
      onUnreadCountChange(0);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'İşlem başarısız.');
    }
  };

  const unreadTotal = items.filter((i) => !i.is_read).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-[#F8FAFC]">
            Bildirimler
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-[#94A3B8]">
            APK derleme sonuçları, ödeme onayları ve hesap güvenlik bildirimleri.
          </p>
        </div>

        {unreadTotal > 0 && (
          <button
            type="button"
            onClick={() => void handleMarkAllRead()}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-xl border border-slate-200 dark:border-white/[0.1] bg-white dark:bg-[#151D2E] hover:bg-slate-50 dark:hover:bg-white/[0.05] text-slate-800 dark:text-[#F8FAFC] transition-colors whitespace-nowrap shrink-0"
          >
            <CheckCheck className="w-4 h-4 text-[#22C55E]" />
            <span>Tümünü Okundu İşaretle ({unreadTotal})</span>
          </button>
        )}
      </div>

      {error && (
        <div className="px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/25 text-xs text-red-600 dark:text-red-300">
          {error}
        </div>
      )}

      <div className="bg-white dark:bg-[#151D2E] border border-slate-200 dark:border-white/[0.08] rounded-2xl overflow-hidden">
        {loading ? (
          <div className="p-8 text-xs text-slate-500 dark:text-[#94A3B8]">
            Bildirimler yükleniyor...
          </div>
        ) : items.length === 0 ? (
          <div className="p-12 text-center">
            <Bell className="w-7 h-7 text-slate-400 mx-auto mb-3" />
            <p className="text-sm font-medium text-slate-900 dark:text-[#F8FAFC]">
              Henüz bildiriminiz bulunmuyor
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-[#94A3B8]">
              Derlemeler tamamlandığında veya üyeliğiniz güncellendiğinde burada görünecektir.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-white/[0.06]">
            {items.map((item) => {
              const Icon =
                item.type === 'success'
                  ? CheckCircle2
                  : item.type === 'error' || item.type === 'warning'
                  ? AlertTriangle
                  : Info;
              const iconColor =
                item.type === 'success'
                  ? 'text-[#22C55E]'
                  : item.type === 'error'
                  ? 'text-[#EF4444]'
                  : item.type === 'warning'
                  ? 'text-[#EAB308]'
                  : 'text-[#3B82F6]';

              return (
                <div
                  key={item.id}
                  onClick={() => void handleMarkRead(item)}
                  className={`px-6 py-4 flex items-start justify-between gap-4 cursor-pointer transition-colors ${
                    item.is_read
                      ? 'hover:bg-slate-50 dark:hover:bg-white/[0.02]'
                      : 'bg-[#6366F1]/[0.06] hover:bg-[#6366F1]/[0.1]'
                  }`}
                >
                  <div className="flex items-start gap-3.5 min-w-0">
                    <Icon className={`w-4 h-4 shrink-0 mt-0.5 ${iconColor}`} />
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC]">
                          {item.title}
                        </h3>
                        {!item.is_read && (
                          <span className="text-[10px] font-semibold text-[#6366F1]">
                            Yeni
                          </span>
                        )}
                      </div>
                      <p className="mt-1 text-xs text-slate-600 dark:text-[#94A3B8] leading-relaxed">
                        {item.message}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-[11px] text-slate-500 dark:text-[#94A3B8] tabular-nums whitespace-nowrap">
                      {formatDateTr(item.created_at)}
                    </span>
                    {item.link_section && (
                      <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
