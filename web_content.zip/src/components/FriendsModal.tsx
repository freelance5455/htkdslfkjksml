import React, { useState } from 'react';
import { Check, Copy, DoorOpen, Trash2, UserPlus, Users, X } from 'lucide-react';
import type { BikeModelType, FriendInfo } from '../game/types';

interface FriendsModalProps {
  open: boolean;
  playerId: string;
  playerName: string;
  friends: FriendInfo[];
  wsConnected: boolean;
  onClose: () => void;
  onSaveName: (name: string) => Promise<void>;
  onAddFriend: (friendId: string) => Promise<void>;
  onRemoveFriend: (friendId: string) => Promise<void>;
  onJoinFriendRoom: (roomId: string) => void;
}

const BIKE_LABELS: Record<BikeModelType, string> = {
  cg_titan_160: 'CG 160 Titan',
  cg_fan_160: 'CG 160 Fan',
  bros_160: 'NXR 160 Bros',
};

export const FriendsModal: React.FC<FriendsModalProps> = ({
  open,
  playerId,
  playerName,
  friends,
  wsConnected,
  onClose,
  onSaveName,
  onAddFriend,
  onRemoveFriend,
  onJoinFriendRoom,
}) => {
  const [friendIdInput, setFriendIdInput] = useState('');
  const [nameInput, setNameInput] = useState(playerName);
  const [busy, setBusy] = useState(false);
  const [savingName, setSavingName] = useState(false);
  const [copied, setCopied] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  if (!open) return null;

  const handleCopyId = async () => {
    try {
      await navigator.clipboard.writeText(playerId);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setFeedback({ type: 'err', text: `Copie manualmente seu ID: ${playerId}` });
    }
  };

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = friendIdInput.trim().toUpperCase();
    if (!cleaned) {
      setFeedback({ type: 'err', text: 'Digite o ID do amigo.' });
      return;
    }
    setBusy(true);
    setFeedback(null);
    try {
      await onAddFriend(cleaned);
      setFriendIdInput('');
      setFeedback({ type: 'ok', text: 'Amigo adicionado com sucesso!' });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Erro ao adicionar amigo.',
      });
    } finally {
      setBusy(false);
    }
  };

  const handleNameSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = nameInput.trim();
    if (!trimmed) return;
    setSavingName(true);
    setFeedback(null);
    try {
      await onSaveName(trimmed);
      setFeedback({ type: 'ok', text: 'Apelido salvo!' });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'Erro ao salvar apelido.',
      });
    } finally {
      setSavingName(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-3">
      <div className="w-full max-w-2xl max-h-[90vh] flex flex-col bg-neutral-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <Users className="w-5 h-5 text-amber-400" />
            <h2 className="font-display text-lg font-bold text-white">Adicionar Amigos</h2>
            <span aria-hidden="true" className="text-neutral-600">·</span>
            <span className="flex items-center gap-1.5 text-xs text-neutral-300">
              <span
                className={`w-2 h-2 rounded-full ${wsConnected ? 'bg-emerald-400' : 'bg-rose-400'}`}
              />
              {wsConnected ? 'Servidor conectado' : 'Reconectando'}
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors cursor-pointer"
            aria-label="Fechar Amigos"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-5 grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Left Column: My ID + Add Friend by ID */}
          <div className="space-y-4">
            <div className="bg-neutral-950/70 border border-white/10 rounded-xl p-3.5 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-neutral-300">Seu ID no Moto Win</span>
                <button
                  type="button"
                  onClick={handleCopyId}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-amber-300 cursor-pointer whitespace-nowrap"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copiado' : 'Copiar ID'}</span>
                </button>
              </div>
              <div className="font-mono-tabular text-xl font-bold tracking-wider text-white">
                {playerId || 'Gerando...'}
              </div>
              <p className="text-[11px] text-neutral-400 leading-snug">
                Envie este ID para seu amigo adicionar você pelo celular dele.
              </p>

              <form onSubmit={handleNameSubmit} className="flex gap-2 pt-1 border-t border-white/10">
                <input
                  type="text"
                  maxLength={20}
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  placeholder="Seu apelido"
                  className="flex-1 min-w-0 px-3 py-1.5 rounded-lg bg-neutral-900 border border-white/15 text-xs text-white focus:outline-none focus:border-amber-400"
                />
                <button
                  type="submit"
                  disabled={savingName}
                  className="px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-white whitespace-nowrap cursor-pointer"
                >
                  {savingName ? '...' : 'Salvar'}
                </button>
              </form>
            </div>

            <form
              onSubmit={handleAddSubmit}
              className="bg-neutral-950/70 border border-white/10 rounded-xl p-3.5 space-y-2.5"
            >
              <label className="block text-sm font-bold text-white">
                Adicionar Amigo pelo ID
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={friendIdInput}
                  onChange={(e) => setFriendIdInput(e.target.value.toUpperCase())}
                  placeholder="Ex: MW-48291"
                  className="flex-1 min-w-0 px-3 py-2 rounded-xl bg-neutral-900 border border-white/15 font-mono-tabular text-sm text-white placeholder:text-neutral-500 focus:outline-none focus:border-amber-400"
                />
                <button
                  type="submit"
                  disabled={busy || !playerId}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-neutral-950 font-bold text-xs whitespace-nowrap cursor-pointer"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>{busy ? 'Buscando...' : 'Adicionar'}</span>
                </button>
              </div>
              {feedback && (
                <div
                  className={`text-xs font-medium px-3 py-2 rounded-lg border ${
                    feedback.type === 'ok'
                      ? 'bg-emerald-950/70 border-emerald-500/40 text-emerald-300'
                      : 'bg-rose-950/70 border-rose-500/40 text-rose-300'
                  }`}
                >
                  {feedback.text}
                </div>
              )}
            </form>
          </div>

          {/* Right Column: Real Friends List */}
          <div className="bg-neutral-950/70 border border-white/10 rounded-xl p-3.5 flex flex-col min-h-[200px]">
            <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-white/10">
              <h3 className="text-sm font-bold text-white">Seus Amigos</h3>
              <span className="text-xs font-mono-tabular text-neutral-400">
                {friends.length} {friends.length === 1 ? 'amigo' : 'amigos'}
              </span>
            </div>

            {friends.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center py-6 px-3 text-neutral-400 space-y-1.5">
                <Users className="w-7 h-7 text-neutral-600" />
                <p className="text-xs font-medium text-neutral-300">Nenhum amigo adicionado ainda</p>
                <p className="text-[11px] text-neutral-500">
                  Peça o ID do seu amigo e digite em "Adicionar Amigo pelo ID".
                </p>
              </div>
            ) : (
              <div className="space-y-2 overflow-y-auto pr-0.5">
                {friends.map((f) => (
                  <div
                    key={f.id}
                    className="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-neutral-900 border border-white/10"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`w-2 h-2 rounded-full shrink-0 ${
                            f.online ? 'bg-emerald-400' : 'bg-neutral-600'
                          }`}
                        />
                        <span className="text-xs font-bold text-white truncate">{f.name}</span>
                      </div>
                      <div className="text-[11px] text-neutral-400 font-mono-tabular mt-0.5 truncate">
                        {f.id} · {BIKE_LABELS[f.bikeModel] ?? 'CG 160'} ·{' '}
                        {f.roomId ? `Sala ${f.roomId}` : f.online ? 'Online' : 'Offline'}
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {f.roomId && (
                        <button
                          type="button"
                          onClick={() => onJoinFriendRoom(f.roomId!)}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-neutral-950 text-[11px] font-bold whitespace-nowrap cursor-pointer"
                        >
                          <DoorOpen className="w-3.5 h-3.5" />
                          <span>Entrar</span>
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => onRemoveFriend(f.id)}
                        title="Remover amigo"
                        className="p-1.5 rounded-lg bg-neutral-800 hover:bg-rose-900/60 text-neutral-400 hover:text-rose-300 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
