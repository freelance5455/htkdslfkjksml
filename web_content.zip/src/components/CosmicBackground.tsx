import React, { useEffect, useRef } from 'react';

interface Star {
  x: number;
  y: number;
  size: number;
  speed: number;
  opacity: number;
  baseOpacity: number;
  color: string;
}

export const CosmicBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    const starCount = Math.min(60, Math.floor((width * height) / 18000));
    const colors = ['#38bdf8', '#818cf8', '#c084fc', '#67e8f9', '#ffffff'];
    const stars: Star[] = Array.from({ length: starCount }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      size: Math.random() * 1.8 + 0.6,
      speed: Math.random() * 0.2 + 0.05,
      opacity: Math.random() * 0.7 + 0.2,
      baseOpacity: Math.random() * 0.5 + 0.2,
      color: colors[Math.floor(Math.random() * colors.length)],
    }));

    let tick = 0;

    const render = () => {
      tick++;
      ctx.clearRect(0, 0, width, height);

      // Render subtle stardust
      for (const s of stars) {
        s.y -= s.speed;
        if (s.y < 0) {
          s.y = height;
          s.x = Math.random() * width;
        }

        const pulse = Math.sin(tick * 0.03 + s.x) * 0.2;
        const currentOpacity = Math.max(0.1, Math.min(1, s.baseOpacity + pulse));

        ctx.beginPath();
        ctx.arc(s.x, s.y, s.size, 0, Math.PI * 2);
        ctx.fillStyle = s.color;
        ctx.globalAlpha = currentOpacity;
        ctx.shadowColor = s.color;
        ctx.shadowBlur = s.size * 3;
        ctx.fill();
      }

      ctx.globalAlpha = 1.0;
      ctx.shadowBlur = 0;
      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden select-none bg-[#050B14]">
      {/* Background Image Scrim */}
      <img
        src="/src/assets/images/astra_cosmic_backdrop_1792478978614.jpg"
        alt="Cosmic Space Backdrop"
        referrerPolicy="no-referrer"
        className="absolute inset-0 w-full h-full object-cover opacity-45 mix-blend-screen"
      />
      {/* Radial Electric Blue Vignette */}
      <div 
        className="absolute inset-0 bg-[radial-gradient(circle_at_50%_35%,rgba(14,35,80,0.45)_0%,rgba(5,11,20,0.92)_75%,#050B14_100%)]" 
      />
      {/* Dynamic Stardust Canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
    </div>
  );
};
