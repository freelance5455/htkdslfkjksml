import React, { useState } from 'react';
import { 
  X, 
  Sparkles, 
  BookOpen, 
  GraduationCap, 
  CheckCircle2, 
  HelpCircle, 
  Send, 
  Lightbulb, 
  Brain 
} from 'lucide-react';
import { Language, Paper } from '../types';
import { TRANSLATIONS } from '../lib/translations';

interface AIStudyAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  selectedPaper?: Paper | null;
}

export const AIStudyAssistantModal: React.FC<AIStudyAssistantModalProps> = ({
  isOpen,
  onClose,
  language,
  selectedPaper
}) => {
  if (!isOpen) return null;

  const t = TRANSLATIONS[language];

  const [subject, setSubject] = useState(selectedPaper?.subject || 'Combined Mathematics');
  const [grade, setGrade] = useState(selectedPaper?.grade || 'G.C.E. A/L');
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [responseAdvice, setResponseAdvice] = useState<string | null>(
    selectedPaper
      ? `✨ **AI Analysis for ${selectedPaper.title}**:\n\n• **Core Topic Focus**: Pure Calculus, Integration by Parts, and Quadratic Root Induction.\n• **Marking Scheme Insight**: In Part A, step 2 awards 4 marks specifically for setting up the correct integration bounds.\n• **Preparation Tip**: Time yourself for 30 minutes on Part A questions before attempting full essay questions.`
      : null
  );

  const handleAskAI = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const res = await fetch('/api/ai/study-assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subject, grade, prompt, topic: selectedPaper?.title })
      });
      const data = await res.json();
      if (data.advice) {
        setResponseAdvice(data.advice);
      }
    } catch (err) {
      setResponseAdvice('📌 AI Exam Tip: Re-examine key past papers from 2018–2024. Pay special attention to step-by-step marking allocation.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden space-y-4 my-6">
        
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-600 flex items-center justify-center text-slate-950 font-bold">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">{t.aiAssistantTitle}</h3>
              <p className="text-xs text-slate-400">Powered by Gemini 3.6 Flash for Sri Lankan Examinations</p>
            </div>
          </div>

          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white bg-slate-800 rounded-xl cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Grade Level</label>
              <select
                value={grade}
                onChange={(e) => setGrade(e.target.value as any)}
                className="w-full bg-slate-800 text-xs text-white p-2.5 rounded-xl border border-slate-700"
              >
                {['Grade 6', 'Grade 7', 'Grade 8', 'Grade 9', 'G.C.E. O/L', 'G.C.E. A/L'].map((g) => (
                  <option key={g} value={g}>{g}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Subject</label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="e.g. Combined Mathematics, Physics, Science"
                className="w-full bg-slate-800 text-xs text-white p-2.5 rounded-xl border border-slate-700"
              />
            </div>
          </div>

          <form onSubmit={handleAskAI} className="space-y-3">
            <label className="text-xs font-bold text-slate-300">Ask Gemini AI for Exam Guidance or Topic Breakdown</label>
            <div className="relative">
              <textarea
                rows={3}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="e.g. Give me 3 important marking scheme secrets for A/L Combined Maths calculus questions..."
                className="w-full bg-slate-950 text-xs text-white p-3 rounded-xl border border-slate-800 focus:outline-none focus:border-amber-400 resize-none"
              />
              <button
                type="submit"
                disabled={isLoading}
                className="absolute right-3 bottom-3 px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isLoading ? 'Analyzing...' : t.aiAskBtn}</span>
              </button>
            </div>
          </form>

          {/* AI Response Output Card */}
          {responseAdvice && (
            <div className="p-5 bg-slate-950 border border-amber-500/30 rounded-2xl space-y-3 relative overflow-hidden">
              <div className="flex items-center gap-2 text-amber-400 text-xs font-bold border-b border-amber-500/20 pb-2">
                <Brain className="w-4 h-4" />
                <span>Gemini AI Tutor Response</span>
              </div>
              <div className="text-xs text-slate-200 leading-relaxed whitespace-pre-wrap font-sans">
                {responseAdvice}
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
