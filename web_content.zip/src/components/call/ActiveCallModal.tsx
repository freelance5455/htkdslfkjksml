import React, { useEffect, useRef } from 'react';
import {
  Phone,
  PhoneOff,
  Mic,
  MicOff,
  Video,
  VideoOff,
  Volume2,
  VolumeX,
  RotateCw,
} from 'lucide-react';
import { useCall } from '../../contexts/CallContext';

export const ActiveCallModal: React.FC = () => {
  const {
    activeCall,
    acceptCall,
    rejectCall,
    endCall,
    toggleMute,
    toggleVideo,
    toggleSpeaker,
  } = useCall();

  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const remoteAudioRef = useRef<HTMLAudioElement>(null);

  // Attach local stream to video element
  useEffect(() => {
    if (localVideoRef.current && activeCall?.localStream) {
      localVideoRef.current.srcObject = activeCall.localStream;
    }
  }, [activeCall?.localStream]);

  // Attach remote stream to video or audio element
  useEffect(() => {
    if (activeCall?.remoteStream) {
      if (remoteVideoRef.current && activeCall.callType === 'video') {
        remoteVideoRef.current.srcObject = activeCall.remoteStream;
      }
      if (remoteAudioRef.current) {
        remoteAudioRef.current.srcObject = activeCall.remoteStream;
      }
    }
  }, [activeCall?.remoteStream, activeCall?.callType]);

  // Adjust audio element based on speaker state
  useEffect(() => {
    if (remoteAudioRef.current && activeCall) {
      remoteAudioRef.current.volume = activeCall.isSpeakerOn ? 1.0 : 0.25;
    }
  }, [activeCall?.isSpeakerOn]);

  if (!activeCall) return null;

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleFlipCamera = async () => {
    if (!activeCall?.localStream) return;
    const videoTrack = activeCall.localStream.getVideoTracks()[0];
    if (!videoTrack) return;
    try {
      const currentFacing = videoTrack.getSettings?.()?.facingMode;
      const targetFacing = currentFacing === 'user' ? 'environment' : 'user';
      const newMedia = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: targetFacing } },
      });
      const newVideoTrack = newMedia.getVideoTracks()[0];
      if (newVideoTrack) {
        activeCall.localStream.removeTrack(videoTrack);
        videoTrack.stop();
        activeCall.localStream.addTrack(newVideoTrack);
      }
    } catch (e) {
      console.log('Camera switch not available:', e);
    }
  };

  const isIncoming = activeCall.status === 'incoming';

  return (
    <div
      id="active-call-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center bg-neutral-950/95 backdrop-blur-xl animate-in fade-in"
    >
      {/* Hidden audio element for remote voice */}
      <audio ref={remoteAudioRef} autoPlay playsInline />

      {/* Video Call Canvas (if video and connected or connecting) */}
      {activeCall.callType === 'video' && (
        <div className="absolute inset-0 overflow-hidden flex items-center justify-center">
          {activeCall.remoteStream && !activeCall.isVideoOff ? (
            <video
              ref={remoteVideoRef}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="flex flex-col items-center justify-center space-y-4">
              <div className="w-28 h-28 rounded-full bg-neutral-800 border-2 border-neutral-700 flex items-center justify-center text-4xl font-bold text-neutral-300 shadow-2xl">
                {activeCall.peerUser.avatar_url ? (
                  <img
                    src={activeCall.peerUser.avatar_url}
                    alt={activeCall.peerUser.display_name}
                    className="w-full h-full rounded-full object-cover"
                  />
                ) : (
                  activeCall.peerUser.display_name.charAt(0).toUpperCase()
                )}
              </div>
              <p className="text-sm text-neutral-400">Remote camera paused</p>
            </div>
          )}

          {/* Local Camera PIP */}
          {activeCall.localStream && (
            <div className="absolute top-6 right-6 w-36 sm:w-48 aspect-3/4 rounded-2xl overflow-hidden border-2 border-neutral-700 shadow-2xl bg-neutral-900 z-10">
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover mirror -scale-x-100"
              />
              {activeCall.isVideoOff && (
                <div className="absolute inset-0 bg-neutral-900/90 flex items-center justify-center text-xs text-neutral-400">
                  Camera off
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Voice Call UI or Pre-connection State */}
      {(activeCall.callType === 'voice' || isIncoming || activeCall.status === 'ringing') && (
        <div className="relative z-10 flex flex-col items-center text-center space-y-6 max-w-sm px-6">
          {/* Avatar with pulse ring */}
          <div className="relative">
            {activeCall.status === 'ringing' || isIncoming ? (
              <div className="absolute -inset-4 rounded-full bg-emerald-500/20 animate-ping" />
            ) : null}
            <div className="relative w-32 h-32 rounded-full border-4 border-neutral-800 shadow-2xl overflow-hidden bg-neutral-800 flex items-center justify-center text-5xl font-bold text-neutral-300">
              {activeCall.peerUser.avatar_url ? (
                <img
                  src={activeCall.peerUser.avatar_url}
                  alt={activeCall.peerUser.display_name}
                  className="w-full h-full object-cover"
                />
              ) : (
                activeCall.peerUser.display_name.charAt(0).toUpperCase()
              )}
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold text-white">{activeCall.peerUser.display_name}</h2>
            <p className="text-sm text-emerald-400 font-mono mt-0.5">@{activeCall.peerUser.username}</p>
            <div className="mt-3 inline-flex items-center space-x-2 px-3.5 py-1 rounded-full bg-neutral-900/80 border border-neutral-800 text-xs font-medium text-neutral-300">
              {activeCall.status === 'incoming' && (
                <span className="text-amber-400">Incoming {activeCall.callType} call...</span>
              )}
              {activeCall.status === 'ringing' && (
                <span className="text-neutral-300">Ringing...</span>
              )}
              {activeCall.status === 'connecting' && (
                <span className="text-blue-400">Connecting WebRTC...</span>
              )}
              {activeCall.status === 'connected' && (
                <span className="text-emerald-400 font-mono">
                  {formatDuration(activeCall.durationSeconds)}
                </span>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Call Controls Bar at Bottom */}
      <div className="absolute bottom-10 inset-x-0 z-20 flex items-center justify-center space-x-3 sm:space-x-5 px-6">
        {isIncoming ? (
          <>
            {/* Reject Button */}
            <button
              id="btn-call-reject"
              onClick={rejectCall}
              className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-lg shadow-red-950/50 transition-transform active:scale-95"
              title="Decline call"
            >
              <PhoneOff className="w-7 h-7" />
            </button>

            {/* Accept Button */}
            <button
              id="btn-call-accept"
              onClick={acceptCall}
              className="w-16 h-16 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center shadow-lg shadow-emerald-950/50 transition-transform active:scale-95 animate-bounce"
              title="Accept call"
            >
              <Phone className="w-7 h-7" />
            </button>
          </>
        ) : (
          <>
            {/* Speaker Toggle Button - Always available for Voice & Video */}
            <button
              id="btn-call-toggle-speaker"
              onClick={toggleSpeaker}
              className={`w-12 h-12 sm:w-13 sm:h-13 rounded-full flex items-center justify-center shadow-lg transition-all ${
                activeCall.isSpeakerOn
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/50 hover:bg-emerald-500/30'
                  : 'bg-neutral-800/90 hover:bg-neutral-700 text-neutral-400'
              }`}
              title={activeCall.isSpeakerOn ? 'Speaker On (Ear piece: Off)' : 'Speaker Off (Ear piece: On)'}
            >
              {activeCall.isSpeakerOn ? <Volume2 className="w-5 h-5 sm:w-6 sm:h-6" /> : <VolumeX className="w-5 h-5 sm:w-6 sm:h-6" />}
            </button>

            {/* Mute toggle */}
            <button
              id="btn-call-toggle-mute"
              onClick={toggleMute}
              className={`w-12 h-12 sm:w-13 sm:h-13 rounded-full flex items-center justify-center shadow-lg transition-all ${
                activeCall.isMuted
                  ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                  : 'bg-neutral-800/90 hover:bg-neutral-700 text-white'
              }`}
              title={activeCall.isMuted ? 'Unmute microphone' : 'Mute microphone'}
            >
              {activeCall.isMuted ? <MicOff className="w-5 h-5 sm:w-6 sm:h-6" /> : <Mic className="w-5 h-5 sm:w-6 sm:h-6" />}
            </button>

            {/* Video toggle (for video calls) */}
            {activeCall.callType === 'video' && (
              <>
                <button
                  id="btn-call-toggle-video"
                  onClick={toggleVideo}
                  className={`w-12 h-12 sm:w-13 sm:h-13 rounded-full flex items-center justify-center shadow-lg transition-all ${
                    activeCall.isVideoOff
                      ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                      : 'bg-neutral-800/90 hover:bg-neutral-700 text-white'
                  }`}
                  title={activeCall.isVideoOff ? 'Turn camera on' : 'Turn camera off'}
                >
                  {activeCall.isVideoOff ? <VideoOff className="w-5 h-5 sm:w-6 sm:h-6" /> : <Video className="w-5 h-5 sm:w-6 sm:h-6" />}
                </button>

                {/* Flip Camera button */}
                <button
                  id="btn-call-flip-camera"
                  onClick={handleFlipCamera}
                  className="w-12 h-12 sm:w-13 sm:h-13 rounded-full bg-neutral-800/90 hover:bg-neutral-700 text-white flex items-center justify-center shadow-lg transition-all"
                  title="Switch Camera"
                >
                  <RotateCw className="w-5 h-5 sm:w-6 sm:h-6" />
                </button>
              </>
            )}

            {/* End Call Button */}
            <button
              id="btn-call-end"
              onClick={endCall}
              className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-xl shadow-red-950/60 transition-transform active:scale-95"
              title="End call"
            >
              <PhoneOff className="w-6 h-6 sm:w-7 sm:h-7" />
            </button>
          </>
        )}
      </div>
    </div>
  );
};
