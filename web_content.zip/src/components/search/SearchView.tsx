import React, { useState, useMemo } from 'react';
import { Book } from '../../types';
import { CoverImage } from '../common/CoverImage';
import { EmptyState } from '../common/EmptyState';
import {
  Search,
  X,
  BookOpen,
  Filter,
  Sparkles,
  Heart,
  Globe,
  Tag,
} from 'lucide-react';

interface SearchViewProps {
  books: Book[];
  onOpenBookDetail: (book: Book) => void;
  onOpenReader: (book: Book) => void;
  onOpenAddBook: () => void;
}

export const SearchView: React.FC<SearchViewProps> = ({
  books,
  onOpenBookDetail,
  onOpenReader,
  onOpenAddBook,
}) => {
  const [query, setQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'title' | 'author' | 'genre' | 'tag' | 'saga'>('all');
  const [activeTab, setActiveTab] = useState<'local' | 'online'>('local');

  // Search Results
  const results = useMemo(() => {
    if (!query.trim()) return [];

    const q = query.toLowerCase().trim();

    return books.filter((b) => {
      switch (selectedFilter) {
        case 'title':
          return b.title.toLowerCase().includes(q);
        case 'author':
          return b.author.toLowerCase().includes(q);
        case 'genre':
          return b.genres?.some((g) => g.toLowerCase().includes(q));
        case 'tag':
          return b.tags?.some((t) => t.toLowerCase().includes(q));
        case 'saga':
          return b.saga?.toLowerCase().includes(q);
        default:
          return (
            b.title.toLowerCase().includes(q) ||
            b.author.toLowerCase().includes(q) ||
            b.saga?.toLowerCase().includes(q) ||
            b.genres?.some((g) => g.toLowerCase().includes(q)) ||
            b.tags?.some((t) => t.toLowerCase().includes(q)) ||
            b.description?.toLowerCase().includes(q)
          );
      }
    });
  }, [books, query, selectedFilter]);

  return (
    <div className="space-y-6 pb-16 animate-fadeIn">
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Syne']">
          Buscar libros
        </h1>
        <p className="text-xs text-zinc-400 mt-0.5">
          Encuentra libros en tu biblioteca personal por título, autor, saga o etiquetas
        </p>
      </div>

      {/* Local vs Online Search Switch (conforming to Section 57: Preparar interfaz sin falsas integraciones) */}
      <div className="flex items-center gap-1 p-1 bg-white/[0.04] border border-white/10 rounded-xl max-w-xs">
        <button
          onClick={() => setActiveTab('local')}
          className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold transition-all ${
            activeTab === 'local'
              ? 'bg-white/15 text-white shadow-sm'
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          Mi Biblioteca ({books.length})
        </button>
        <button
          onClick={() => setActiveTab('online')}
          className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold transition-all ${
            activeTab === 'online'
              ? 'bg-white/15 text-white shadow-sm'
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          Catálogo Online
        </button>
      </div>

      {activeTab === 'online' ? (
        <div className="glass-panel rounded-2xl p-6 text-center border border-white/10 max-w-lg mx-auto space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-white/10 border border-white/20 text-white mx-auto flex items-center justify-center">
            <Globe className="w-6 h-6" />
          </div>
          <h3 className="text-base font-semibold text-white">Búsqueda Online (Próximamente)</h3>
          <p className="text-xs text-zinc-400 leading-relaxed">
            La arquitectura está preparada para conectar catálogos internacionales (ISBN, Google Books, Open Library) en futuras actualizaciones. En esta V1, puedes agregar cualquier libro manualmente con todos sus detalles.
          </p>
          <button
            onClick={onOpenAddBook}
            className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white border border-white/20 rounded-xl text-xs font-semibold transition-all"
          >
            Agregar libro manual
          </button>
        </div>
      ) : (
        <>
          {/* Search Input Bar */}
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
              <Search className="w-5 h-5" />
            </div>
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar por título, autor, saga, género o palabra clave..."
              className="w-full pl-11 pr-10 py-3.5 bg-zinc-900/90 border border-white/15 rounded-2xl text-white placeholder-zinc-500 text-sm focus:outline-none focus:border-white/40 focus:ring-1 focus:ring-white/20 transition-all shadow-inner"
              autoFocus
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-zinc-400 hover:text-white"
                aria-label="Borrar búsqueda"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Quick Filter Attributes */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            <span className="text-zinc-500 mr-1 text-[11px] shrink-0">Buscar en:</span>
            {[
              { id: 'all', label: 'Todo' },
              { id: 'title', label: 'Título' },
              { id: 'author', label: 'Autor' },
              { id: 'genre', label: 'Género' },
              { id: 'saga', label: 'Saga' },
              { id: 'tag', label: 'Etiquetas' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setSelectedFilter(f.id as any)}
                className={`px-3 py-1 rounded-lg border whitespace-nowrap transition-all ${
                  selectedFilter === f.id
                    ? 'bg-white/15 border-white/30 text-white font-medium shadow-sm'
                    : 'bg-white/[0.03] border-white/10 text-zinc-400 hover:text-white'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Results List */}
          {query.trim() === '' ? (
            <div className="glass-panel-subtle rounded-2xl p-8 text-center border border-white/5 space-y-3">
              <Search className="w-8 h-8 text-zinc-600 mx-auto" />
              <p className="text-xs text-zinc-400">
                Escribe para buscar entre tus {books.length} libros guardados.
              </p>
            </div>
          ) : results.length === 0 ? (
            <EmptyState
              icon={Search}
              title="No se encontraron coincidencias"
              description={`No se encontró ningún libro con "${query}" en ${selectedFilter === 'all' ? 'la biblioteca' : selectedFilter}.`}
              actionLabel="Agregar nuevo libro"
              onAction={onOpenAddBook}
            />
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-zinc-400 px-1">
                <span>
                  {results.length} {results.length === 1 ? 'coincidencia' : 'coincidencias'}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {results.map((book) => (
                  <div
                    key={book.id}
                    onClick={() => onOpenBookDetail(book)}
                    className="glass-panel-interactive rounded-2xl p-3 flex items-start gap-3.5 border border-white/10 cursor-pointer group"
                  >
                    <div className="w-14 shrink-0">
                      <CoverImage
                        url={book.coverUrl}
                        title={book.title}
                        author={book.author}
                        className="rounded-lg shadow-md"
                      />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-semibold text-white/95 truncate group-hover:text-white transition-colors">
                          {book.title}
                        </h4>
                        {book.favorite && (
                          <Heart className="w-3.5 h-3.5 text-white fill-white shrink-0 ml-1" />
                        )}
                      </div>
                      <p className="text-xs text-zinc-400 truncate mt-0.5">{book.author}</p>

                      {book.saga && (
                        <p className="text-[11px] text-zinc-400 truncate mt-1">
                          {book.saga} #{book.sagaIndex || 1}
                        </p>
                      )}

                      <div className="flex items-center gap-2 mt-2 text-[11px] text-zinc-400">
                        <span className="font-semibold">{book.status}</span>
                        {book.status === 'LEYENDO' && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="text-zinc-300 font-mono">{book.progress}%</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
