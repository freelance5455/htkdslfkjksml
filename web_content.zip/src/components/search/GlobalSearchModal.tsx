import React, { useState, useEffect } from 'react';
import { api } from '../../services/api';
import {
  Search, X, Users, FileText, Hash,
  Bookmark, ShoppingBag, ArrowRight
} from 'lucide-react';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectUser: (userId: string) => void;
  onSelectTab: (tab: string) => void;
  onSelectHashtag: (tag: string) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  onSelectUser,
  onSelectTab,
  onSelectHashtag
}) => {
  const [query, setQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'people' | 'posts' | 'marketplace' | 'groups'>('all');
  const [results, setResults] = useState<{
    users: any[];
    posts: any[];
    marketplace: any[];
    groups: any[];
  }>({ users: [], posts: [], marketplace: [], groups: [] });
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    if (!query.trim()) {
      setResults({ users: [], posts: [], marketplace: [], groups: [] });
      return;
    }

    const timer = setTimeout(async () => {
      try {
        setIsSearching(true);
        const [usersRes, postsRes, mktRes, grpRes] = await Promise.all([
          api.searchUsers({ q: query }),
          api.getPosts(),
          api.getMarketplace({ q: query }),
          api.getGroups()
        ]);

        const filteredPosts = (postsRes.posts || []).filter(
          p => p.content.toLowerCase().includes(query.toLowerCase()) ||
               p.hashtags.some(h => h.toLowerCase().includes(query.toLowerCase()))
        );

        const filteredGroups = (grpRes.groups || []).filter(
          g => g.name.toLowerCase().includes(query.toLowerCase()) ||
               g.description.toLowerCase().includes(query.toLowerCase())
        );

        setResults({
          users: usersRes.users || [],
          posts: filteredPosts,
          marketplace: mktRes.items || [],
          groups: filteredGroups
        });
      } catch (err) {
        console.error(err);
      } finally {
        setIsSearching(false);
      }
    }, 250);

    return () => clearTimeout(timer);
  }, [query]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 pt-16 bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-6 text-slate-100 max-h-[85vh] flex flex-col animate-in zoom-in-95">

        {/* Input Bar */}
        <div className="relative mb-4">
          <Search className="w-5 h-5 text-amber-500 absolute left-4 top-3.5" />
          <input
            type="text"
            placeholder="Pesquisar pessoas, publicações, hashtags, grupos e mercado..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-2xl pl-12 pr-10 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors"
            autoFocus
          />
          <button
            onClick={onClose}
            className="absolute right-3.5 top-3 p-1 text-slate-400 hover:text-white rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-1.5 pb-3 border-b border-slate-800 text-xs overflow-x-auto scrollbar-none">
          {(['all', 'people', 'posts', 'marketplace', 'groups'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              className={`px-3 py-1.5 rounded-xl font-medium transition-colors ${activeFilter === f ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-950 text-slate-400 hover:text-white'}`}
            >
              {f === 'all' ? 'Tudo' : f === 'people' ? 'Pessoas' : f === 'posts' ? 'Publicações' : f === 'marketplace' ? 'Marketplace' : 'Grupos'}
            </button>
          ))}
        </div>

        {/* Results Area */}
        <div className="flex-1 overflow-y-auto space-y-4 my-3 pr-1">
          {!query.trim() ? (
            <div className="p-8 text-center text-slate-500 text-xs">
              Digite palavras-chave para pesquisar na rede social Angola Connect.
            </div>
          ) : (
            <>
              {/* Users */}
              {(activeFilter === 'all' || activeFilter === 'people') && results.users.length > 0 && (
                <div>
                  <h4 className="text-[11px] font-bold text-amber-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5" />
                    <span>Pessoas ({results.users.length})</span>
                  </h4>
                  <div className="space-y-1.5">
                    {results.users.slice(0, 4).map((u) => (
                      <button
                        key={u.id}
                        onClick={() => { onSelectUser(u.id); onClose(); }}
                        className="w-full p-2.5 bg-slate-950/60 hover:bg-slate-800/80 rounded-xl flex items-center justify-between text-left transition-colors"
                      >
                        <div className="flex items-center gap-2.5">
                          <img src={u.avatar} className="w-8 h-8 rounded-full object-cover" />
                          <div>
                            <p className="text-xs font-bold text-white">{u.name}</p>
                            <p className="text-[10px] text-slate-400">@{u.username} · 🇦🇴 {u.province}</p>
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-slate-500" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Marketplace */}
              {(activeFilter === 'all' || activeFilter === 'marketplace') && results.marketplace.length > 0 && (
                <div>
                  <h4 className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>Mercado Angola ({results.marketplace.length})</span>
                  </h4>
                  <div className="space-y-1.5">
                    {results.marketplace.slice(0, 3).map((item) => (
                      <button
                        key={item.id}
                        onClick={() => { onSelectTab('marketplace'); onClose(); }}
                        className="w-full p-2.5 bg-slate-950/60 hover:bg-slate-800/80 rounded-xl flex items-center justify-between text-left transition-colors"
                      >
                        <div className="flex items-center gap-2.5">
                          <img src={item.images[0]} className="w-8 h-8 rounded-lg object-cover" />
                          <div>
                            <p className="text-xs font-bold text-white line-clamp-1">{item.title}</p>
                            <p className="text-[10px] text-amber-400 font-bold font-mono">
                              {item.price.toLocaleString()} {item.currency} · 🇦🇴 {item.province}
                            </p>
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-slate-500" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Groups */}
              {(activeFilter === 'all' || activeFilter === 'groups') && results.groups.length > 0 && (
                <div>
                  <h4 className="text-[11px] font-bold text-blue-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Bookmark className="w-3.5 h-3.5" />
                    <span>Grupos & Comunidades ({results.groups.length})</span>
                  </h4>
                  <div className="space-y-1.5">
                    {results.groups.slice(0, 3).map((g) => (
                      <button
                        key={g.id}
                        onClick={() => { onSelectTab('groups'); onClose(); }}
                        className="w-full p-2.5 bg-slate-950/60 hover:bg-slate-800/80 rounded-xl flex items-center justify-between text-left transition-colors"
                      >
                        <div className="flex items-center gap-2.5">
                          <img src={g.avatar} className="w-8 h-8 rounded-lg object-cover" />
                          <div>
                            <p className="text-xs font-bold text-white line-clamp-1">{g.name}</p>
                            <p className="text-[10px] text-slate-400">{g.category}</p>
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-slate-500" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Posts */}
              {(activeFilter === 'all' || activeFilter === 'posts') && results.posts.length > 0 && (
                <div>
                  <h4 className="text-[11px] font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5" />
                    <span>Publicações ({results.posts.length})</span>
                  </h4>
                  <div className="space-y-1.5">
                    {results.posts.slice(0, 3).map((p) => (
                      <button
                        key={p.id}
                        onClick={() => { onSelectTab('feed'); onClose(); }}
                        className="w-full p-2.5 bg-slate-950/60 hover:bg-slate-800/80 rounded-xl text-left transition-colors"
                      >
                        <p className="text-xs text-slate-200 line-clamp-2">{p.content}</p>
                        <span className="text-[10px] text-amber-400 mt-1 block">🇦🇴 {p.province}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {results.users.length === 0 && results.posts.length === 0 && results.marketplace.length === 0 && results.groups.length === 0 && (
                <div className="p-8 text-center text-slate-500 text-xs">
                  Nenhum resultado encontrado para "{query}".
                </div>
              )}
            </>
          )}
        </div>

      </div>
    </div>
  );
};
