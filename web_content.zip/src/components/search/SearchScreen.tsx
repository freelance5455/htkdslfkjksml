import React, { useState, useMemo } from 'react';
import { useMusic } from '../../context/MusicContext';
import { MusicListItem } from '../cards/MusicListItem';
import { ArtistCard } from '../cards/ArtistCard';
import { AlbumCard } from '../cards/AlbumCard';
import { PlaylistCard } from '../cards/PlaylistCard';
import {
  Search,
  Mic,
  MicOff,
  X,
  Clock,
  TrendingUp,
  Sparkles,
  Music,
  Disc3,
  User,
  ListMusic
} from 'lucide-react';

type SearchCategory = 'All' | 'Songs' | 'Artists' | 'Albums' | 'Playlists';

export const SearchScreen: React.FC = () => {
  const {
    songs,
    artists,
    albums,
    playlists,
    searchHistory,
    addSearchHistory,
    clearSearchHistory,
    setSelectedPlaylistId,
    setSelectedArtistId
  } = useMusic();

  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<SearchCategory>('All');
  const [isListening, setIsListening] = useState(false);

  // Trending searches list
  const trendingSearches = [
    'Arijit Singh',
    'Midnight Horizon',
    'Bengali Acoustic Bliss',
    'Dua Lipa',
    'Workout 140 BPM',
    'Raindrops on Park Street'
  ];

  // Dynamic filter matching
  const filteredResults = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return null;

    const matchedSongs = songs.filter(
      (s) =>
        s.title.toLowerCase().includes(q) ||
        s.artist.toLowerCase().includes(q) ||
        s.album.toLowerCase().includes(q) ||
        s.genre.toLowerCase().includes(q)
    );

    const matchedArtists = artists.filter(
      (a) =>
        a.name.toLowerCase().includes(q) ||
        a.genres.some((g) => g.toLowerCase().includes(q))
    );

    const matchedAlbums = albums.filter(
      (al) =>
        al.title.toLowerCase().includes(q) ||
        al.artist.toLowerCase().includes(q)
    );

    const matchedPlaylists = playlists.filter(
      (p) =>
        p.title.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q)
    );

    return {
      songs: matchedSongs,
      artists: matchedArtists,
      albums: matchedAlbums,
      playlists: matchedPlaylists,
      totalCount:
        matchedSongs.length +
        matchedArtists.length +
        matchedAlbums.length +
        matchedPlaylists.length
    };
  }, [query, songs, artists, albums, playlists]);

  const handleSearchSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (query.trim()) {
      addSearchHistory(query.trim());
    }
  };

  const handleSelectSearchTerm = (term: string) => {
    setQuery(term);
    addSearchHistory(term);
  };

  // Voice search simulation / Web Speech API
  const handleVoiceSearch = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      try {
        const recognition = new SpeechRecognition();
        recognition.lang = 'en-US';
        setIsListening(true);

        recognition.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          setQuery(transcript);
          addSearchHistory(transcript);
          setIsListening(false);
        };

        recognition.onerror = () => {
          setIsListening(false);
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognition.start();
        return;
      } catch {
        // Fallback to simulation
      }
    }

    // Friendly simulation if speech API is unavailable in sandbox
    setIsListening(true);
    setTimeout(() => {
      const phrases = ['Arijit Singh', 'Midnight Horizon', 'Bengali Acoustic'];
      const picked = phrases[Math.floor(Math.random() * phrases.length)];
      setQuery(picked);
      addSearchHistory(picked);
      setIsListening(false);
    }, 1800);
  };

  return (
    <div className="space-y-5 pb-24 pt-2 max-w-3xl mx-auto px-1">
      {/* Search Input Bar */}
      <div className="relative">
        <form onSubmit={handleSearchSubmit} className="relative flex items-center">
          <div className="absolute left-4 text-slate-400 pointer-events-none">
            <Search className="w-5 h-5" />
          </div>

          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search songs, artists, albums, playlists..."
            className="w-full pl-11 pr-24 py-3.5 rounded-2xl bg-white/[0.06] hover:bg-white/[0.08] focus:bg-white/[0.1] border border-white/10 focus:border-purple-500/60 text-sm text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500/20 transition-all shadow-inner"
          />

          {/* Right Action Icons in Input */}
          <div className="absolute right-2 flex items-center gap-1">
            {query && (
              <button
                type="button"
                onClick={() => setQuery('')}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white"
                aria-label="Clear search query"
              >
                <X className="w-4 h-4" />
              </button>
            )}

            <button
              type="button"
              onClick={handleVoiceSearch}
              title="Voice search"
              className={`p-2 rounded-xl transition-all ${
                isListening
                  ? 'bg-red-500/20 text-red-400 animate-pulse'
                  : 'text-slate-400 hover:text-purple-300 hover:bg-white/10'
              }`}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>
          </div>
        </form>

        {/* Listening indicator modal pill */}
        {isListening && (
          <div className="mt-2 p-3 rounded-2xl bg-purple-950/60 border border-purple-500/30 flex items-center justify-between animate-in fade-in">
            <div className="flex items-center gap-2.5">
              <span className="w-3 h-3 rounded-full bg-red-500 animate-ping" />
              <span className="text-xs font-semibold text-purple-200">Listening to your voice... Speak now</span>
            </div>
            <button
              onClick={() => setIsListening(false)}
              className="text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
          </div>
        )}
      </div>

      {/* Category Pills (Tabs) */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
        {(['All', 'Songs', 'Artists', 'Albums', 'Playlists'] as SearchCategory[]).map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-4 py-1.5 rounded-full text-xs font-semibold transition-all shrink-0 ${
              activeCategory === cat
                ? 'bg-purple-600 text-white shadow-md shadow-purple-600/25'
                : 'bg-white/[0.04] text-slate-400 hover:text-white hover:bg-white/[0.08] border border-white/[0.05]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Search Results vs Explore Views */}
      {filteredResults ? (
        filteredResults.totalCount === 0 ? (
          /* Empty Search State */
          <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
            <div className="w-20 h-20 rounded-3xl bg-white/[0.03] border border-white/10 flex items-center justify-center mb-4 text-purple-400 shadow-xl">
              <Sparkles className="w-10 h-10 opacity-60" />
            </div>
            <h3 className="font-display font-bold text-lg text-white">No results found for &ldquo;{query}&rdquo;</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-sm">
              Please check your spelling, try different keywords, or explore one of our curated genres.
            </p>
            <button
              onClick={() => setQuery('')}
              className="mt-5 px-5 py-2 rounded-full bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs transition-colors shadow-md"
            >
              Clear & Explore Music
            </button>
          </div>
        ) : (
          /* Dynamic Search Results */
          <div className="space-y-6 animate-in fade-in">
            {/* Matched Songs */}
            {(activeCategory === 'All' || activeCategory === 'Songs') &&
              filteredResults.songs.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between px-1">
                    <h3 className="font-display font-bold text-sm sm:text-base text-white flex items-center gap-1.5">
                      <Music className="w-4 h-4 text-purple-400" />
                      <span>Songs ({filteredResults.songs.length})</span>
                    </h3>
                  </div>
                  <div className="space-y-1.5 bg-white/[0.02] p-2 rounded-2xl border border-white/[0.04]">
                    {filteredResults.songs.map((song) => (
                      <MusicListItem
                        key={song.id}
                        song={song}
                        contextQueue={filteredResults.songs}
                      />
                    ))}
                  </div>
                </div>
              )}

            {/* Matched Artists */}
            {(activeCategory === 'All' || activeCategory === 'Artists') &&
              filteredResults.artists.length > 0 && (
                <div className="space-y-2">
                  <h3 className="font-display font-bold text-sm sm:text-base text-white flex items-center gap-1.5 px-1">
                    <User className="w-4 h-4 text-pink-400" />
                    <span>Artists ({filteredResults.artists.length})</span>
                  </h3>
                  <div className="flex items-center gap-3 overflow-x-auto pb-2 no-scrollbar">
                    {filteredResults.artists.map((artist) => (
                      <ArtistCard
                        key={artist.id}
                        artist={artist}
                        onClick={() => setSelectedArtistId(artist.id)}
                      />
                    ))}
                  </div>
                </div>
              )}

            {/* Matched Albums */}
            {(activeCategory === 'All' || activeCategory === 'Albums') &&
              filteredResults.albums.length > 0 && (
                <div className="space-y-2">
                  <h3 className="font-display font-bold text-sm sm:text-base text-white flex items-center gap-1.5 px-1">
                    <Disc3 className="w-4 h-4 text-blue-400" />
                    <span>Albums ({filteredResults.albums.length})</span>
                  </h3>
                  <div className="flex items-center gap-3 overflow-x-auto pb-2 no-scrollbar">
                    {filteredResults.albums.map((album) => (
                      <AlbumCard key={album.id} album={album} />
                    ))}
                  </div>
                </div>
              )}

            {/* Matched Playlists */}
            {(activeCategory === 'All' || activeCategory === 'Playlists') &&
              filteredResults.playlists.length > 0 && (
                <div className="space-y-2">
                  <h3 className="font-display font-bold text-sm sm:text-base text-white flex items-center gap-1.5 px-1">
                    <ListMusic className="w-4 h-4 text-emerald-400" />
                    <span>Playlists ({filteredResults.playlists.length})</span>
                  </h3>
                  <div className="flex items-center gap-3 overflow-x-auto pb-2 no-scrollbar">
                    {filteredResults.playlists.map((playlist) => (
                      <PlaylistCard
                        key={playlist.id}
                        playlist={playlist}
                        onClick={() => setSelectedPlaylistId(playlist.id)}
                      />
                    ))}
                  </div>
                </div>
              )}
          </div>
        )
      ) : (
        /* Default Search Screen with Recent & Trending */
        <div className="space-y-6 animate-in fade-in">
          {/* Recent Searches */}
          {searchHistory.length > 0 && (
            <div className="space-y-2.5">
              <div className="flex items-center justify-between px-1">
                <span className="font-display font-bold text-sm text-slate-200 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-purple-400" />
                  <span>Recent Searches</span>
                </span>
                <button
                  onClick={clearSearchHistory}
                  className="text-xs text-slate-400 hover:text-purple-300"
                >
                  Clear all
                </button>
              </div>

              <div className="flex flex-wrap gap-2">
                {searchHistory.map((item, i) => (
                  <button
                    key={i}
                    onClick={() => handleSelectSearchTerm(item)}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.06] text-xs text-slate-300 transition-colors"
                  >
                    <Clock className="w-3 h-3 text-slate-500" />
                    <span>{item}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Trending Searches */}
          <div className="space-y-2.5">
            <div className="flex items-center gap-1.5 px-1">
              <TrendingUp className="w-4 h-4 text-pink-400" />
              <span className="font-display font-bold text-sm text-slate-200">
                Trending Searches
              </span>
            </div>

            <div className="flex flex-wrap gap-2">
              {trendingSearches.map((term, i) => (
                <button
                  key={i}
                  onClick={() => handleSelectSearchTerm(term)}
                  className="px-3.5 py-1.5 rounded-full bg-gradient-to-r from-purple-900/30 to-pink-900/30 hover:from-purple-900/50 hover:to-pink-900/50 border border-purple-500/20 text-xs font-medium text-purple-200 transition-all hover:scale-105 active:scale-95"
                >
                  {term}
                </button>
              ))}
            </div>
          </div>

          {/* Popular Artists */}
          <div className="space-y-2.5">
            <h3 className="font-display font-bold text-sm text-slate-200 px-1">
              Popular Artists
            </h3>
            <div className="flex items-center gap-3 overflow-x-auto pb-2 no-scrollbar">
              {artists.slice(0, 5).map((artist) => (
                <ArtistCard key={artist.id} artist={artist} />
              ))}
            </div>
          </div>

          {/* Popular Songs */}
          <div className="space-y-2.5">
            <h3 className="font-display font-bold text-sm text-slate-200 px-1">
              Popular Songs
            </h3>
            <div className="space-y-1.5 bg-white/[0.02] p-2 rounded-2xl border border-white/[0.04]">
              {songs.slice(0, 4).map((song, idx) => (
                <MusicListItem
                  key={song.id}
                  song={song}
                  rank={idx + 1}
                  showRank={true}
                  contextQueue={songs}
                />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
