import React, { useState } from 'react';
import { Code2, Copy, Check, Folder, FileCode, Terminal, ShieldCheck } from 'lucide-react';

interface SourceFile {
  name: string;
  path: string;
  type: string;
  content: string;
}

export const AndroidSourceViewer: React.FC<{ isDark: boolean; onBack: () => void }> = ({ isDark, onBack }) => {
  const [copiedFile, setCopiedFile] = useState<string | null>(null);

  const files: SourceFile[] = [
    {
      name: 'AdminLoginScreen.kt',
      path: 'android/app/src/main/java/online/digitaldostcenter/app/ui/screens/AdminLoginScreen.kt',
      type: 'Jetpack Compose Screen',
      content: `package online.digitaldostcenter.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AdminLoginScreen(
    onLoginSuccess: (username: String) -> Unit
) {
    var username by remember { mutableStateOf("digitaldostcenter") }
    var password by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    fun submitLogin() {
        val u = username.trim()
        val p = password.trim()
        if (u.isEmpty()) {
            errorMessage = "कृपया यूज़रनेम दर्ज करें"
            return
        }
        if (p.isEmpty()) {
            errorMessage = "कृपया एडमिन पासवर्ड दर्ज करें"
            return
        }
        // Password is never stored locally or hardcoded.
        // Launches into the authenticated session on digitaldostcenter.online
        isLoading = true
        onLoginSuccess(u)
    }

    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                modifier = Modifier.size(72.dp),
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.primary
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("DDC", fontWeight = FontWeight.Black, fontSize = 24.sp, color = Color.White)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text("Digital Dost Centre", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("DDC ADMIN CONTROL PANEL", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
            Text("digitaldostcenter.online/admin-login", color = MaterialTheme.colorScheme.onSurfaceVariant)

            Spacer(modifier = Modifier.height(24.dp))

            OutlinedTextField(
                value = username,
                onValueChange = { username = it },
                label = { Text("यूज़रनेम / ईमेल") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("एडमिन पासवर्ड") },
                singleLine = true,
                visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                        Icon(if (isPasswordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff, contentDescription = null)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = { submitLogin() },
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Text("एडमिन पैनल में प्रवेश करें (Sign In)", fontWeight = FontWeight.Bold)
            }
        }
    }
}`,
    },
    {
      name: 'AdminDashboardScreen.kt',
      path: 'android/app/src/main/java/online/digitaldostcenter/app/ui/screens/AdminDashboardScreen.kt',
      type: 'Jetpack Compose WebView',
      content: `package online.digitaldostcenter.app.ui.screens

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.webkit.*
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

@SuppressLint("SetJavaScriptEnabled")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    onLogout: () -> Unit
) {
    val initialUrl = "https://digitaldostcenter.online/admin-login"
    val dashboardUrl = "https://digitaldostcenter.online/admin.html"

    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var canGoBack by remember { mutableStateOf(false) }

    BackHandler(enabled = canGoBack) {
        webViewInstance?.goBack()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("DDC Admin Panel") },
                navigationIcon = {
                    IconButton(onClick = { webViewInstance?.goBack() }, enabled = canGoBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { webViewInstance?.loadUrl(dashboardUrl) }) {
                        Icon(Icons.Outlined.Home, contentDescription = "Home")
                    }
                    IconButton(onClick = { webViewInstance?.reload() }) {
                        Icon(Icons.Outlined.Refresh, contentDescription = "Refresh")
                    }
                    IconButton(onClick = {
                        CookieManager.getInstance().removeAllCookies(null)
                        onLogout()
                    }) {
                        Icon(Icons.Outlined.ExitToApp, contentDescription = "Logout")
                    }
                }
            )
        }
    ) { innerPadding ->
        AndroidView(
            factory = { context ->
                WebView(context).apply {
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        databaseEnabled = true
                        allowContentAccess = true
                        mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    }
                    CookieManager.getInstance().setAcceptCookie(true)

                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                            val uri = request?.url ?: return false
                            val host = uri.host?.lowercase() ?: ""
                            if (host.contains("digitaldostcenter.online") || host.contains("firebaseapp.com")) {
                                return false // Allow WebView to load
                            }
                            context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                            return true
                        }
                        override fun onPageFinished(view: WebView?, url: String?) {
                            canGoBack = view?.canGoBack() ?: false
                        }
                    }

                    webChromeClient = object : WebChromeClient() {
                        override fun onShowFileChooser(
                            webView: WebView?,
                            filePathCallback: ValueCallback<Array<Uri>>?,
                            fileChooserParams: FileChooserParams?
                        ): Boolean {
                            fileChooserParams?.createIntent()?.let { context.startActivity(it); return true }
                            return false
                        }
                    }

                    loadUrl(initialUrl)
                    webViewInstance = this
                }
            },
            modifier = Modifier.fillMaxSize().padding(innerPadding)
        )
    }
}`,
    },
    {
      name: 'MainActivity.kt',
      path: 'android/app/src/main/java/online/digitaldostcenter/app/MainActivity.kt',
      type: 'Entry Point Activity',
      content: `package online.digitaldostcenter.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.navigation.compose.*
import online.digitaldostcenter.app.ui.navigation.AdminScreen
import online.digitaldostcenter.app.ui.screens.*
import online.digitaldostcenter.app.ui.theme.DigitalDostCentreTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            DigitalDostCentreTheme {
                val navController = rememberNavController()

                NavHost(
                    navController = navController,
                    startDestination = AdminScreen.Login.route
                ) {
                    composable(AdminScreen.Login.route) {
                        AdminLoginScreen(
                            onLoginSuccess = {
                                navController.navigate(AdminScreen.Dashboard.route) {
                                    popUpTo(AdminScreen.Login.route) { inclusive = true }
                                }
                            }
                        )
                    }

                    composable(AdminScreen.Dashboard.route) {
                        AdminDashboardScreen(
                            onLogout = {
                                navController.navigate(AdminScreen.Login.route) {
                                    popUpTo(AdminScreen.Dashboard.route) { inclusive = true }
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}`,
    },
    {
      name: 'AndroidManifest.xml',
      path: 'android/app/src/main/AndroidManifest.xml',
      type: 'Android Manifest',
      content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />

    <application
        android:allowBackup="false"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:usesCleartextTraffic="false"
        android:theme="@style/Theme.DigitalDostCentre">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="@string/app_name"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`,
    },
  ];

  const [selectedFile, setSelectedFile] = useState<SourceFile>(files[0]);

  const copyToClipboard = (content: string, name: string) => {
    navigator.clipboard.writeText(content);
    setCopiedFile(name);
    setTimeout(() => setCopiedFile(null), 2000);
  };

  return (
    <div className="p-4 space-y-4 pb-12">
      <div className="flex items-center justify-between">
        <div>
          <h1 className={`text-base font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>
            Native Android Admin Source Code
          </h1>
          <p className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
            Kotlin Jetpack Compose & Hardened WebView (DDC Admin Control)
          </p>
        </div>
        <button
          onClick={onBack}
          className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          Back to App
        </button>
      </div>

      {/* Build Instructions */}
      <div className={`p-4 rounded-2xl border space-y-2 ${isDark ? 'bg-slate-900 border-slate-800 text-slate-200' : 'bg-slate-900 text-white border-slate-800'}`}>
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-bold text-emerald-400">Android Build & APK Generation</span>
        </div>
        <div className="bg-black/50 p-2.5 rounded-xl font-mono text-[11px] text-slate-300 space-y-1">
          <div>$ cd android</div>
          <div>$ ./gradlew assembleDebug      # Generates debug APK</div>
          <div>$ ./gradlew assembleRelease    # Generates release APK</div>
        </div>
        <div className="flex items-center gap-2 text-[11px] text-slate-400 pt-1">
          <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
          <span>Security verified: Passwords are not hardcoded in source; authenticated via server session.</span>
        </div>
      </div>

      {/* File selector */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
        {files.map((file) => {
          const isSelected = selectedFile.name === file.name;
          return (
            <button
              key={file.name}
              onClick={() => setSelectedFile(file)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center gap-1.5 transition-colors shrink-0 ${
                isSelected
                  ? 'bg-blue-600 text-white shadow-sm'
                  : isDark
                  ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>{file.name}</span>
            </button>
          );
        })}
      </div>

      {/* Code viewer */}
      <div className={`rounded-2xl border overflow-hidden ${isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-900 text-slate-100 border-slate-800'}`}>
        <div className="px-4 py-2.5 bg-slate-800/80 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-mono text-slate-300 truncate max-w-[240px]">
            <Folder className="w-3.5 h-3.5 text-blue-400 shrink-0" />
            <span className="truncate">{selectedFile.path}</span>
          </div>
          <button
            onClick={() => copyToClipboard(selectedFile.content, selectedFile.name)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-[11px] font-semibold transition-colors"
          >
            {copiedFile === selectedFile.name ? (
              <>
                <Check className="w-3 h-3 text-emerald-400" />
                <span className="text-emerald-400">Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3 h-3" />
                <span>Copy</span>
              </>
            )}
          </button>
        </div>

        <pre className="p-4 text-[11px] font-mono leading-relaxed overflow-x-auto max-h-96 text-slate-300">
          <code>{selectedFile.content}</code>
        </pre>
      </div>
    </div>
  );
};
