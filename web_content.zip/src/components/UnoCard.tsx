import React from 'react';
import type { CardColor, CardFace, Side, UnoCardData } from '../shared/unoTypes';

interface UnoCardProps {
  card: UnoCardData;
  activeSide: Side;
  size?: 'sm' | 'md' | 'lg';
  playable?: boolean;
  dimmed?: boolean;
  selected?: boolean;
  onClick?: () => void;
  className?: string;
}

const LIGHT_BG: Record<CardColor, string> = {
  red: 'bg-[#DC2626] text-white',
  blue: 'bg-[#2563EB] text-white',
  green: 'bg-[#16A34A] text-white',
  yellow: 'bg-[#EAB308] text-stone-950',
  pink: 'bg-[#DB2777] text-white',
  teal: 'bg-[#0D9488] text-white',
  orange: 'bg-[#EA580C] text-white',
  purple: 'bg-[#7C3AED] text-white',
  wild: 'bg-[#1C1917] text-white',
};

const DARK_BG: Record<CardColor, string> = {
  red: 'bg-[#DC2626] text-white',
  blue: 'bg-[#2563EB] text-white',
  green: 'bg-[#16A34A] text-white',
  yellow: 'bg-[#EAB308] text-stone-950',
  pink: 'bg-[#BE185D] text-pink-50',
  teal: 'bg-[#0F766E] text-teal-50',
  orange: 'bg-[#C2410C] text-orange-50',
  purple: 'bg-[#6D28D9] text-purple-50',
  wild: 'bg-[#09090B] text-white',
};

function getCornerLabel(face: CardFace): string {
  switch (face.value) {
    case 'draw1':
      return '+1';
    case 'draw5':
      return '+5';
    case 'skip':
      return '⊘';
    case 'skip_all':
      return '⊘⊘';
    case 'reverse':
      return '⇄';
    case 'flip':
      return 'FLIP';
    case 'wild':
      return 'W';
    case 'wild_draw2':
      return '+2';
    case 'wild_draw_color':
      return '+W';
    default:
      return face.value;
  }
}

function renderCenterGlyph(face: CardFace, side: Side, size: 'sm' | 'md' | 'lg') {
  const iconDim = size === 'sm' ? 22 : size === 'lg' ? 38 : 30;
  const numClass =
    size === 'sm'
      ? 'text-xl font-extrabold'
      : size === 'lg'
        ? 'text-4xl font-extrabold'
        : 'text-3xl font-extrabold';

  if (/^[1-9]$/.test(face.value)) {
    const underline = face.value === '6' || face.value === '9';
    return (
      <span className={`font-display tracking-tight leading-none ${numClass} ${underline ? 'underline decoration-2 underline-offset-4' : ''}`}>
        {face.value}
      </span>
    );
  }

  switch (face.value) {
    case 'draw1':
      return (
        <div className="flex flex-col items-center leading-none">
          <span className={`font-display font-extrabold ${size === 'sm' ? 'text-lg' : 'text-2xl'}`}>+1</span>
        </div>
      );
    case 'draw5':
      return (
        <div className="flex flex-col items-center leading-none">
          <span className={`font-display font-extrabold ${size === 'sm' ? 'text-lg' : 'text-2xl'}`}>+5</span>
        </div>
      );
    case 'skip':
      return (
        <svg width={iconDim} height={iconDim} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6">
          <circle cx="12" cy="12" r="8.5" />
          <line x1="6" y1="18" x2="18" y2="6" />
        </svg>
      );
    case 'skip_all':
      return (
        <div className="flex flex-col items-center gap-0.5">
          <svg width={iconDim} height={iconDim} viewBox="0 0 28 24" fill="none" stroke="currentColor" strokeWidth="2.4">
            <circle cx="10" cy="12" r="6.5" />
            <line x1="5.5" y1="16.5" x2="14.5" y2="7.5" />
            <circle cx="18" cy="12" r="6.5" />
            <line x1="13.5" y1="16.5" x2="22.5" y2="7.5" />
          </svg>
        </div>
      );
    case 'reverse':
      return (
        <svg width={iconDim} height={iconDim} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
          <path d="M17 3l4 4-4 4" />
          <path d="M3 7h18" />
          <path d="M7 21l-4-4 4-4" />
          <path d="M21 17H3" />
        </svg>
      );
    case 'flip':
      return (
        <div className="flex flex-col items-center gap-0.5">
          <svg width={iconDim - 2} height={iconDim - 2} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 12a9 9 0 0 1 15.3-6.4L21 8" />
            <path d="M21 3v5h-5" />
            <path d="M21 12a9 9 0 0 1-15.3 6.4L3 16" />
            <path d="M3 21v-5h5" />
          </svg>
          {size !== 'sm' && (
            <span className="text-[9px] font-bold tracking-wider uppercase">FLIP</span>
          )}
        </div>
      );
    case 'wild':
    case 'wild_draw2':
    case 'wild_draw_color': {
      const colors =
        side === 'light'
          ? ['#DC2626', '#2563EB', '#16A34A', '#EAB308']
          : ['#DB2777', '#0D9488', '#EA580C', '#7C3AED'];
      return (
        <div className="flex flex-col items-center gap-0.5">
          <svg width={iconDim} height={iconDim} viewBox="0 0 32 32">
            <path d="M16 2 A14 14 0 0 1 30 16 L16 16 Z" fill={colors[0]} />
            <path d="M30 16 A14 14 0 0 1 16 30 L16 16 Z" fill={colors[1]} />
            <path d="M16 30 A14 14 0 0 1 2 16 L16 16 Z" fill={colors[2]} />
            <path d="M2 16 A14 14 0 0 1 16 2 L16 16 Z" fill={colors[3]} />
            <circle cx="16" cy="16" r="13.5" fill="none" stroke="white" strokeWidth="1.5" strokeOpacity="0.85" />
          </svg>
          {face.value === 'wild_draw2' && (
            <span className="text-xs font-extrabold tracking-tight leading-none">+2</span>
          )}
          {face.value === 'wild_draw_color' && (
            <span className="text-[10px] font-extrabold tracking-tight leading-none">+WARNA</span>
          )}
        </div>
      );
    }
    default:
      return null;
  }
}

const CardFaceView: React.FC<{
  face: CardFace;
  side: Side;
  size: 'sm' | 'md' | 'lg';
}> = ({ face, side, size }) => {
  const isLight = side === 'light';
  const palette = isLight ? LIGHT_BG[face.color] : DARK_BG[face.color];
  const corner = getCornerLabel(face);
  const cornerText = size === 'sm' ? 'text-[10px]' : size === 'lg' ? 'text-sm' : 'text-xs';

  return (
    <div
      className={`w-full h-full rounded-xl select-none relative overflow-hidden flex flex-col justify-between p-1.5 ${palette} ${
        isLight
          ? 'ring-2 ring-white shadow-[0_6px_16px_rgba(0,0,0,0.38)]'
          : 'ring-2 ring-stone-900 shadow-[0_6px_18px_rgba(0,0,0,0.65)]'
      }`}
    >
      {/* Inner frame distinguisher between Light Side and Dark Side */}
      <div
        className={`absolute inset-1 rounded-lg pointer-events-none ${
          isLight
            ? 'border border-white/35'
            : 'border border-white/20 bg-stone-950/35'
        }`}
      />

      {/* Top-left corner index */}
      <div className={`relative z-10 font-display font-bold leading-none pl-0.5 pt-0.5 ${cornerText}`}>
        {corner}
      </div>

      {/* Center emblem oval */}
      <div className="relative z-10 flex items-center justify-center flex-1">
        <div
          className={`flex items-center justify-center rounded-full ${
            size === 'sm' ? 'w-9 h-11' : size === 'lg' ? 'w-16 h-20' : 'w-12 h-15'
          } ${
            isLight
              ? 'bg-white/18 backdrop-blur-[1px]'
              : 'bg-stone-950/55 ring-1 ring-white/20'
          }`}
        >
          {renderCenterGlyph(face, side, size)}
        </div>
      </div>

      {/* Bottom-right corner index */}
      <div
        className={`relative z-10 font-display font-bold leading-none pr-0.5 pb-0.5 self-end rotate-180 ${cornerText}`}
      >
        {corner}
      </div>
    </div>
  );
};

export const UnoCard: React.FC<UnoCardProps> = ({
  card,
  activeSide,
  size = 'md',
  playable = false,
  dimmed = false,
  selected = false,
  onClick,
  className = '',
}) => {
  const dimensions =
    size === 'sm'
      ? 'w-14 h-20'
      : size === 'lg'
        ? 'w-24 h-36 sm:w-28 sm:h-40'
        : 'w-[4.6rem] h-[6.8rem] sm:w-20 sm:h-28';

  const isDark = activeSide === 'dark';

  const interactiveClasses = onClick
    ? playable
      ? 'cursor-pointer hover:-translate-y-3 focus-visible:-translate-y-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-300'
      : 'cursor-not-allowed'
    : '';

  const stateClasses = selected
    ? '-translate-y-4 ring-2 ring-amber-400 rounded-xl'
    : dimmed
      ? 'opacity-50 brightness-75'
      : playable
        ? 'ring-2 ring-white/80 rounded-xl'
        : '';

  return (
    <button
      type="button"
      onClick={onClick}
      disabled={!onClick || (dimmed && !playable)}
      aria-label={`Kartu ${activeSide === 'light' ? card.light.color : card.dark.color} ${
        activeSide === 'light' ? card.light.value : card.dark.value
      }`}
      className={`perspective-1000 relative shrink-0 transition-transform duration-150 ease-out ${dimensions} ${interactiveClasses} ${stateClasses} ${className}`}
    >
      <div
        className={`preserve-3d relative w-full h-full transition-transform duration-300 ease-out ${
          isDark ? 'rotate-y-180' : ''
        }`}
      >
        {/* Front: Light Side */}
        <div className="backface-hidden absolute inset-0">
          <CardFaceView face={card.light} side="light" size={size} />
        </div>

        {/* Back: Dark Side */}
        <div className="backface-hidden rotate-y-180 absolute inset-0">
          <CardFaceView face={card.dark} side="dark" size={size} />
        </div>
      </div>
    </button>
  );
};

export const UnoCardBack: React.FC<{
  side: Side;
  size?: 'xs' | 'sm' | 'md' | 'lg';
  className?: string;
}> = ({ side, size = 'md', className = '' }) => {
  const dimensions =
    size === 'xs'
      ? 'w-6 h-9 rounded-md'
      : size === 'sm'
        ? 'w-10 h-14 rounded-lg'
        : size === 'lg'
          ? 'w-24 h-36 sm:w-28 sm:h-40 rounded-xl'
          : 'w-20 h-28 rounded-xl';

  // In UNO Flip, the card back reflects the opposite side!
  const showingOppositeDark = side === 'light';

  return (
    <div
      className={`${dimensions} relative overflow-hidden select-none flex items-center justify-center border ${
        showingOppositeDark
          ? 'bg-stone-950 border-purple-400/40 text-purple-200 shadow-md'
          : 'bg-emerald-950 border-amber-200/50 text-amber-100 shadow-md'
      } ${className}`}
    >
      <div
        className={`w-[72%] h-[68%] rounded-full flex items-center justify-center border ${
          showingOppositeDark
            ? 'bg-gradient-to-br from-pink-700/40 to-purple-800/40 border-pink-400/35'
            : 'bg-gradient-to-br from-red-600/40 to-amber-500/35 border-white/30'
        }`}
      >
        {size !== 'xs' && (
          <span className="font-display font-extrabold tracking-tight text-[10px] sm:text-xs -rotate-12">
            FLIP
          </span>
        )}
      </div>
    </div>
  );
};
