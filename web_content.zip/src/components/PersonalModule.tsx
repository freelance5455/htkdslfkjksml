import React, { useEffect, useMemo, useState } from 'react';
import { Edit2, Plus, Search, Trash2, UserPlus } from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  calculateCommitteeSummaries,
  calculateLoanSummaries,
  formatCurrency,
  formatDate,
  formatNumber,
  round2,
} from '../utils/calculations';
import { getTodayIso } from '../utils/storage';
import type {
  CommitteeDirection,
  CommitteeFrequency,
  CommitteeTxType,
  LoanTransactionType,
} from '../types';
import { ConfirmModal } from './ConfirmModal';

const PAYMENT_METHODS = ['Cash', 'Bank Transfer', 'JazzCash', 'EasyPaisa', 'Cheque', 'Other'];

export const PersonalModule: React.FC = () => {
  const {
    state,
    activeSubTab,
    focusedRecordId,
    clearFocusedRecord,
    tr,
    themeTokens,
    notify,
    upsertLoanPerson,
    deleteLoanPerson,
    upsertLoanTx,
    deleteLoanTx,
    upsertCommittee,
    deleteCommittee,
    upsertCommitteeTx,
    deleteCommitteeTx,
  } = useApp();

  const [tab, setTab] = useState<'loan' | 'committee'>(
    activeSubTab === 'committee' ? 'committee' : 'loan'
  );

  useEffect(() => {
    if (activeSubTab === 'loan' || activeSubTab === 'committee') {
      setTab(activeSubTab);
    }
  }, [activeSubTab]);

  const cur = state.settings.currencyLabel || 'PKR';
  const dateFmt = state.settings.dateFormat;

  const [confirmState, setConfirmState] = useState<{
    open: boolean;
    type: 'loan_person' | 'loan_tx' | 'committee' | 'committee_tx';
    id: string;
    label: string;
  }>({ open: false, type: 'loan_tx', id: '', label: '' });

  // ==========================================
  // LOAN MANAGER STATE
  // ==========================================
  const loanSummary = useMemo(
    () => calculateLoanSummaries(state.loanPersons, state.loanTransactions),
    [state.loanPersons, state.loanTransactions]
  );

  const [lpEditId, setLpEditId] = useState<string | null>(null);
  const [lpName, setLpName] = useState('');
  const [lpOpening, setLpOpening] = useState('0');
  const [lpNotes, setLpNotes] = useState('');
  const [showPersonForm, setShowPersonForm] = useState(false);

  const [ltEditId, setLtEditId] = useState<string | null>(null);
  const [ltPersonId, setLtPersonId] = useState('');
  const [ltNewPersonName, setLtNewPersonName] = useState('');
  const [ltType, setLtType] = useState<LoanTransactionType>('received');
  const [ltAmount, setLtAmount] = useState('');
  const [ltLoanDate, setLtLoanDate] = useState(getTodayIso());
  const [ltTxDate, setLtTxDate] = useState(getTodayIso());
  const [ltDesc, setLtDesc] = useState('');
  const [ltMethod, setLtMethod] = useState('Cash');
  const [ltRemarks, setLtRemarks] = useState('');
  const [ltError, setLtError] = useState('');

  // Loan filters
  const [lSearch, setLSearch] = useState('');
  const [lPersonFilter, setLPersonFilter] = useState('');
  const [lTypeFilter, setLTypeFilter] = useState('');

  const resetLoanTxForm = () => {
    setLtEditId(null);
    setLtPersonId(state.loanPersons[0]?.id || '');
    setLtNewPersonName('');
    setLtType('received');
    setLtAmount('');
    setLtLoanDate(getTodayIso());
    setLtTxDate(getTodayIso());
    setLtDesc('');
    setLtMethod('Cash');
    setLtRemarks('');
    setLtError('');
  };

  useEffect(() => {
    if (!ltPersonId && state.loanPersons.length > 0) {
      setLtPersonId(state.loanPersons[0].id);
    }
  }, [state.loanPersons, ltPersonId]);

  const handleSavePerson = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lpName.trim()) {
      notify('Lender / Person name is required.', 'error');
      return;
    }
    const id = upsertLoanPerson(
      {
        name: lpName.trim(),
        openingBalance: round2(parseFloat(lpOpening) || 0),
        notes: lpNotes.trim(),
      },
      lpEditId || undefined
    );
    setLtPersonId(id);
    setLpEditId(null);
    setLpName('');
    setLpOpening('0');
    setLpNotes('');
    setShowPersonForm(false);
    notify('Lender saved.');
  };

  const handleSaveLoanTx = (e: React.FormEvent) => {
    e.preventDefault();
    setLtError('');
    const amt = parseFloat(ltAmount);
    if (!Number.isFinite(amt) || amt <= 0) {
      setLtError('Please enter a valid positive amount.');
      return;
    }

    let targetPersonId = ltPersonId;
    let targetPersonName = state.loanPersons.find((p) => p.id === ltPersonId)?.name || '';

    if (!targetPersonId || targetPersonId === '__new__') {
      if (!ltNewPersonName.trim()) {
        setLtError('Please select a lender or enter a new lender name.');
        return;
      }
      targetPersonName = ltNewPersonName.trim();
      targetPersonId = upsertLoanPerson({
        name: targetPersonName,
        openingBalance: 0,
        notes: '',
      });
    }

    upsertLoanTx(
      {
        personId: targetPersonId,
        personName: targetPersonName,
        loanDate: ltLoanDate || ltTxDate || getTodayIso(),
        transactionDate: ltTxDate || getTodayIso(),
        type: ltType,
        amount: round2(amt),
        description: ltDesc.trim(),
        paymentMethod: ltMethod,
        remarks: ltRemarks.trim(),
      },
      ltEditId || undefined
    );
    notify(ltEditId ? 'Loan transaction updated.' : 'Loan transaction saved.');
    resetLoanTxForm();
  };

  const filteredLoanTxs = useMemo(() => {
    const q = lSearch.trim().toLowerCase();
    return state.loanTransactions
      .filter((tx) => {
        if (lPersonFilter && tx.personId !== lPersonFilter) return false;
        if (lTypeFilter && tx.type !== lTypeFilter) return false;
        if (q) {
          const hay = `${tx.personName} ${tx.description} ${tx.remarks} ${tx.paymentMethod}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .sort((a, b) => b.transactionDate.localeCompare(a.transactionDate));
  }, [state.loanTransactions, lPersonFilter, lTypeFilter, lSearch]);

  // ==========================================
  // COMMITTEE MANAGER STATE
  // ==========================================
  const committeeSummary = useMemo(
    () => calculateCommitteeSummaries(state.committees, state.committeeTransactions),
    [state.committees, state.committeeTransactions]
  );

  const [showCommitteeForm, setShowCommitteeForm] = useState(false);
  const [cEditId, setCEditId] = useState<string | null>(null);
  const [cTitle, setCTitle] = useState('');
  const [cGroup, setCGroup] = useState('');
  const [cTotal, setCTotal] = useState('');
  const [cInstAmt, setCInstAmt] = useState('');
  const [cStartDate, setCStartDate] = useState(getTodayIso());
  const [cCount, setCCount] = useState('10');
  const [cFreq, setCFreq] = useState<CommitteeFrequency>('Monthly');
  const [cDueDay, setCDueDay] = useState('5th of month');
  const [cOpening, setCOpening] = useState('0');
  const [cDirection, setCDirection] = useState<CommitteeDirection>('payable');
  const [cRemarks, setCRemarks] = useState('');

  const [ctEditId, setCtEditId] = useState<string | null>(null);
  const [ctCommitteeId, setCtCommitteeId] = useState('');
  const [ctDate, setCtDate] = useState(getTodayIso());
  const [ctType, setCtType] = useState<CommitteeTxType>('Installment');
  const [ctAmount, setCtAmount] = useState('');
  const [ctMethod, setCtMethod] = useState('Cash');
  const [ctRemarks, setCtRemarks] = useState('');
  const [ctError, setCtError] = useState('');

  const [cFilterId, setCFilterId] = useState('');
  const [cSearch, setCSearch] = useState('');

  useEffect(() => {
    if (!ctCommitteeId && state.committees.length > 0) {
      setCtCommitteeId(state.committees[0].id);
    }
  }, [state.committees, ctCommitteeId]);

  useEffect(() => {
    if (focusedRecordId) {
      if (state.loanTransactions.some((t) => t.id === focusedRecordId)) {
        setTab('loan');
        const tx = state.loanTransactions.find((x) => x.id === focusedRecordId);
        if (tx) {
          setLtEditId(tx.id);
          setLtPersonId(tx.personId);
          setLtType(tx.type);
          setLtAmount(String(tx.amount));
          setLtLoanDate(tx.loanDate);
          setLtTxDate(tx.transactionDate);
          setLtDesc(tx.description);
          setLtMethod(tx.paymentMethod);
          setLtRemarks(tx.remarks);
        }
        clearFocusedRecord();
      } else if (state.committeeTransactions.some((t) => t.id === focusedRecordId)) {
        setTab('committee');
        const tx = state.committeeTransactions.find((x) => x.id === focusedRecordId);
        if (tx) {
          setCtEditId(tx.id);
          setCtCommitteeId(tx.committeeId);
          setCtDate(tx.date);
          setCtType(tx.type);
          setCtAmount(String(tx.amount));
          setCtMethod(tx.paymentMethod);
          setCtRemarks(tx.remarks);
        }
        clearFocusedRecord();
      }
    }
  }, [focusedRecordId, state.loanTransactions, state.committeeTransactions, clearFocusedRecord]);

  const handleSaveCommittee = (e: React.FormEvent) => {
    e.preventDefault();
    const totalNum = parseFloat(cTotal);
    const instNum = parseFloat(cInstAmt);
    const countNum = parseInt(cCount, 10) || 1;
    if (!cTitle.trim()) {
      notify('Committee title is required.', 'error');
      return;
    }
    if (!Number.isFinite(totalNum) || totalNum <= 0) {
      notify('Enter a valid total committee amount.', 'error');
      return;
    }
    const id = upsertCommittee(
      {
        title: cTitle.trim(),
        personOrGroup: cGroup.trim(),
        totalAmount: round2(totalNum),
        installmentAmount: round2(Number.isFinite(instNum) && instNum > 0 ? instNum : totalNum / countNum),
        startDate: cStartDate || getTodayIso(),
        totalInstallments: countNum,
        frequency: cFreq,
        dueDay: cDueDay.trim(),
        openingBalance: round2(parseFloat(cOpening) || 0),
        direction: cDirection,
        remarks: cRemarks.trim(),
      },
      cEditId || undefined
    );
    setCtCommitteeId(id);
    setCEditId(null);
    setCTitle('');
    setCGroup('');
    setCTotal('');
    setCInstAmt('');
    setCOpening('0');
    setCRemarks('');
    setShowCommitteeForm(false);
    notify('Committee saved.');
  };

  const handleSaveCommitteeTx = (e: React.FormEvent) => {
    e.preventDefault();
    setCtError('');
    const target = state.committees.find((c) => c.id === ctCommitteeId);
    if (!target) {
      setCtError('Create and select a committee first.');
      return;
    }
    const amt = parseFloat(ctAmount);
    if (!Number.isFinite(amt) || amt <= 0) {
      setCtError('Please enter a valid positive amount.');
      return;
    }
    upsertCommitteeTx(
      {
        committeeId: target.id,
        committeeTitle: target.title,
        date: ctDate || getTodayIso(),
        type: ctType,
        amount: round2(amt),
        paymentMethod: ctMethod,
        remarks: ctRemarks.trim(),
      },
      ctEditId || undefined
    );
    setCtEditId(null);
    setCtAmount('');
    setCtRemarks('');
    notify(ctEditId ? 'Committee entry updated.' : 'Committee entry saved.');
  };

  const filteredCommitteeTxs = useMemo(() => {
    const q = cSearch.trim().toLowerCase();
    return state.committeeTransactions
      .filter((tx) => {
        if (cFilterId && tx.committeeId !== cFilterId) return false;
        if (q) {
          const hay = `${tx.committeeTitle} ${tx.type} ${tx.remarks} ${tx.paymentMethod}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [state.committeeTransactions, cFilterId, cSearch]);

  const triggerDelete = (
    type: 'loan_person' | 'loan_tx' | 'committee' | 'committee_tx',
    id: string,
    label: string
  ) => {
    if (!state.settings.confirmBeforeDelete) {
      if (type === 'loan_person') deleteLoanPerson(id);
      else if (type === 'loan_tx') deleteLoanTx(id);
      else if (type === 'committee') deleteCommittee(id);
      else deleteCommitteeTx(id);
      notify('Moved to Recycle Bin.');
      return;
    }
    setConfirmState({ open: true, type, id, label });
  };

  return (
    <div className="space-y-6">
      {/* Submodule Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex rounded-lg bg-slate-200/70 p-1" role="tablist">
          <button
            type="button"
            role="tab"
            aria-selected={tab === 'loan'}
            onClick={() => setTab('loan')}
            className={`rounded-md px-4 py-2 text-sm font-medium transition-colors whitespace-nowrap ${
              tab === 'loan'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tr('loan_manager')}
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={tab === 'committee'}
            onClick={() => setTab('committee')}
            className={`rounded-md px-4 py-2 text-sm font-medium transition-colors whitespace-nowrap ${
              tab === 'committee'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tr('committee_manager')}
          </button>
        </div>

        {tab === 'loan' ? (
          <button
            type="button"
            onClick={() => setShowPersonForm((v) => !v)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
          >
            <UserPlus className="h-4 w-4" />
            <span>{tr('add_loan_person')}</span>
          </button>
        ) : (
          <button
            type="button"
            onClick={() => setShowCommitteeForm((v) => !v)}
            className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-xs font-medium text-white whitespace-nowrap ${themeTokens.accentBg} ${themeTokens.accentHover}`}
          >
            <Plus className="h-4 w-4" />
            <span>{tr('add_committee')}</span>
          </button>
        )}
      </div>

      {/* ==========================================
          TAB A: LOAN MANAGER
         ========================================== */}
      {tab === 'loan' && (
        <div className="space-y-6">
          {/* Loan Summary Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">{tr('loan_payable')}</div>
              <div className="mt-1 text-2xl font-bold text-slate-900 tabular-nums">
                {formatCurrency(loanSummary.totalLoanPayable, cur)}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">Opening + Received − Repaid</div>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">{tr('total_received')}</div>
              <div className="mt-1 text-xl font-bold text-amber-700 tabular-nums">
                {formatCurrency(loanSummary.totalReceived, cur)}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">
                Opening: {formatCurrency(loanSummary.totalOpening, cur)}
              </div>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">{tr('total_repaid')}</div>
              <div className="mt-1 text-xl font-bold text-emerald-700 tabular-nums">
                {formatCurrency(loanSummary.totalRepaid, cur)}
              </div>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">Active Lenders</div>
              <div className="mt-1 text-xl font-bold text-slate-900 tabular-nums">
                {loanSummary.perPerson.length}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">Committee is tracked separately</div>
            </div>
          </div>

          {/* Add / Edit Person Form */}
          {showPersonForm && (
            <form onSubmit={handleSavePerson} className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
              <h3 className="text-sm font-semibold text-slate-900">
                {lpEditId ? 'Edit Person / Lender' : tr('add_loan_person')}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label htmlFor="lp-name" className="block text-xs font-medium text-slate-700 mb-1">
                    Person / Lender Name *
                  </label>
                  <input
                    id="lp-name"
                    type="text"
                    value={lpName}
                    onChange={(e) => setLpName(e.target.value)}
                    required
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
                <div>
                  <label htmlFor="lp-opening" className="block text-xs font-medium text-slate-700 mb-1">
                    Opening Balance ({cur})
                  </label>
                  <input
                    id="lp-opening"
                    type="number"
                    step="any"
                    value={lpOpening}
                    onChange={(e) => setLpOpening(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
                  />
                </div>
                <div>
                  <label htmlFor="lp-notes" className="block text-xs font-medium text-slate-700 mb-1">
                    Notes
                  </label>
                  <input
                    id="lp-notes"
                    type="text"
                    value={lpNotes}
                    onChange={(e) => setLpNotes(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowPersonForm(false)}
                  className="rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs font-medium text-slate-700"
                >
                  {tr('cancel')}
                </button>
                <button
                  type="submit"
                  className={`rounded-lg px-4 py-1.5 text-xs font-medium text-white ${themeTokens.accentBg} ${themeTokens.accentHover}`}
                >
                  {tr('save')}
                </button>
              </div>
            </form>
          )}

          {/* Loan Transaction Form */}
          <form onSubmit={handleSaveLoanTx} className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-slate-900">
                {ltEditId ? 'Edit Loan Transaction' : tr('add_loan_tx')}
              </h3>
              {ltEditId && (
                <button type="button" onClick={resetLoanTxForm} className="text-xs text-slate-500">
                  {tr('cancel')}
                </button>
              )}
            </div>

            {ltError && (
              <div role="alert" className="rounded-lg bg-red-50 border border-red-200 px-3.5 py-2.5 text-xs font-medium text-red-700">
                {ltError}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label htmlFor="lt-person" className="block text-xs font-medium text-slate-700 mb-1">
                  Person / Lender *
                </label>
                <select
                  id="lt-person"
                  value={ltPersonId || '__new__'}
                  onChange={(e) => setLtPersonId(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  {state.loanPersons.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                  <option value="__new__">+ New Lender...</option>
                </select>
              </div>

              {(!ltPersonId || ltPersonId === '__new__') && (
                <div>
                  <label htmlFor="lt-new-person" className="block text-xs font-medium text-slate-700 mb-1">
                    New Lender Name *
                  </label>
                  <input
                    id="lt-new-person"
                    type="text"
                    value={ltNewPersonName}
                    onChange={(e) => setLtNewPersonName(e.target.value)}
                    placeholder="Enter person name"
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
              )}

              <div>
                <label htmlFor="lt-type" className="block text-xs font-medium text-slate-700 mb-1">
                  Transaction Type *
                </label>
                <select
                  id="lt-type"
                  value={ltType}
                  onChange={(e) => setLtType(e.target.value as LoanTransactionType)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  <option value="received">Loan Received (Borrowed)</option>
                  <option value="repaid">Loan Repaid (Returned)</option>
                </select>
              </div>

              <div>
                <label htmlFor="lt-amount" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('amount')} ({cur}) *
                </label>
                <input
                  id="lt-amount"
                  type="number"
                  step="any"
                  value={ltAmount}
                  onChange={(e) => setLtAmount(e.target.value)}
                  required
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
                />
              </div>

              <div>
                <label htmlFor="lt-tx-date" className="block text-xs font-medium text-slate-700 mb-1">
                  Transaction Date *
                </label>
                <input
                  id="lt-tx-date"
                  type="date"
                  value={ltTxDate}
                  onChange={(e) => setLtTxDate(e.target.value)}
                  required
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>

              <div>
                <label htmlFor="lt-method" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('payment_method')}
                </label>
                <select
                  id="lt-method"
                  value={ltMethod}
                  onChange={(e) => setLtMethod(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  {PAYMENT_METHODS.map((m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  ))}
                </select>
              </div>

              <div className="sm:col-span-2 flex gap-3 items-end">
                <div className="flex-1">
                  <label htmlFor="lt-desc" className="block text-xs font-medium text-slate-700 mb-1">
                    Description / Purpose
                  </label>
                  <input
                    id="lt-desc"
                    type="text"
                    value={ltDesc}
                    onChange={(e) => setLtDesc(e.target.value)}
                    placeholder="Purpose or repayment note..."
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
                <button
                  type="submit"
                  className={`inline-flex items-center gap-2 rounded-lg px-5 py-2 text-sm font-medium text-white whitespace-nowrap shrink-0 ${themeTokens.accentBg} ${themeTokens.accentHover}`}
                >
                  <Plus className="h-4 w-4" />
                  <span>{ltEditId ? tr('update') : tr('save')}</span>
                </button>
              </div>
            </div>
          </form>

          {/* Per-Person Balances */}
          {loanSummary.perPerson.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-200 text-xs font-semibold text-slate-800">
                Person-Wise Loan Balances
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                    <tr>
                      <th className="px-4 py-2.5 text-start">Person / Lender</th>
                      <th className="px-4 py-2.5 text-end">Opening</th>
                      <th className="px-4 py-2.5 text-end">Received</th>
                      <th className="px-4 py-2.5 text-end">Repaid</th>
                      <th className="px-4 py-2.5 text-end">Closing Payable</th>
                      <th className="px-4 py-2.5 text-end">{tr('actions')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {loanSummary.perPerson.map((p) => (
                      <tr key={p.personId} className="hover:bg-slate-50">
                        <td className="px-4 py-2.5 font-medium text-slate-900">{p.personName}</td>
                        <td className="px-4 py-2.5 text-end tabular-nums text-slate-600">
                          {formatCurrency(p.openingBalance, cur)}
                        </td>
                        <td className="px-4 py-2.5 text-end tabular-nums text-amber-700">
                          {formatCurrency(p.totalReceived, cur)}
                        </td>
                        <td className="px-4 py-2.5 text-end tabular-nums text-emerald-700">
                          {formatCurrency(p.totalRepaid, cur)}
                        </td>
                        <td className="px-4 py-2.5 text-end tabular-nums font-bold text-slate-900">
                          {formatCurrency(p.closingPayable, cur)}
                        </td>
                        <td className="px-4 py-2.5 text-end whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => setLPersonFilter(lPersonFilter === p.personId ? '' : p.personId)}
                            className="text-xs font-medium text-emerald-700 hover:underline me-2"
                          >
                            {lPersonFilter === p.personId ? 'Show All' : 'Filter'}
                          </button>
                          <button
                            type="button"
                            onClick={() => triggerDelete('loan_person', p.personId, p.personName)}
                            aria-label={`Delete lender ${p.personName}`}
                            className="p-1 text-slate-400 hover:text-red-600"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Loan Ledger Table */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-4 gap-2.5">
              <div className="relative sm:col-span-2">
                <Search className="h-4 w-4 text-slate-400 absolute start-3 top-2.5" />
                <input
                  type="text"
                  value={lSearch}
                  onChange={(e) => setLSearch(e.target.value)}
                  placeholder="Search loan ledger..."
                  aria-label="Search loan ledger"
                  className="w-full rounded-lg border border-slate-300 ps-9 pe-3 py-2 text-xs"
                />
              </div>
              <select
                value={lPersonFilter}
                onChange={(e) => setLPersonFilter(e.target.value)}
                aria-label="Filter loan by person"
                className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs bg-white"
              >
                <option value="">All Lenders</option>
                {state.loanPersons.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
              <select
                value={lTypeFilter}
                onChange={(e) => setLTypeFilter(e.target.value)}
                aria-label="Filter loan by type"
                className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs bg-white"
              >
                <option value="">All Types</option>
                <option value="received">Received</option>
                <option value="repaid">Repaid</option>
              </select>
            </div>

            {filteredLoanTxs.length === 0 ? (
              <div className="px-5 py-10 text-center text-sm text-slate-500">{tr('no_records')}</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                    <tr>
                      <th className="px-4 py-3 text-start">{tr('date')}</th>
                      <th className="px-4 py-3 text-start">Person</th>
                      <th className="px-4 py-3 text-start">Type</th>
                      <th className="px-4 py-3 text-start">{tr('description')}</th>
                      <th className="px-4 py-3 text-end">{tr('amount')}</th>
                      <th className="px-4 py-3 text-end">{tr('actions')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredLoanTxs.map((tx) => (
                      <tr key={tx.id} className="hover:bg-slate-50">
                        <td className="px-4 py-3 whitespace-nowrap tabular-nums">
                          {formatDate(tx.transactionDate, dateFmt)}
                        </td>
                        <td className="px-4 py-3 font-medium text-slate-900">{tx.personName}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-xs font-semibold">
                          <span className={tx.type === 'received' ? 'text-amber-700' : 'text-emerald-700'}>
                            {tx.type === 'received' ? 'Loan Received' : 'Loan Repaid'}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-slate-600">
                          {tx.description || tx.paymentMethod}
                        </td>
                        <td className="px-4 py-3 text-end tabular-nums font-semibold text-slate-900 whitespace-nowrap">
                          {formatCurrency(tx.amount, cur)}
                        </td>
                        <td className="px-4 py-3 text-end whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => {
                              setLtEditId(tx.id);
                              setLtPersonId(tx.personId);
                              setLtType(tx.type);
                              setLtAmount(String(tx.amount));
                              setLtLoanDate(tx.loanDate);
                              setLtTxDate(tx.transactionDate);
                              setLtDesc(tx.description);
                              setLtMethod(tx.paymentMethod);
                              setLtRemarks(tx.remarks);
                              window.scrollTo({ top: 0, behavior: 'smooth' });
                            }}
                            aria-label={`Edit loan transaction for ${tx.personName}`}
                            className="p-1.5 text-slate-500 hover:text-emerald-700 rounded"
                          >
                            <Edit2 className="h-4 w-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              triggerDelete('loan_tx', tx.id, `${tx.personName} (${tx.amount})`)
                            }
                            aria-label={`Delete loan transaction for ${tx.personName}`}
                            className="p-1.5 text-slate-500 hover:text-red-600 rounded"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ==========================================
          TAB B: COMMITTEE MANAGER (SEPARATE LEDGER)
         ========================================== */}
      {tab === 'committee' && (
        <div className="space-y-6">
          {/* Committee Summary */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">Remaining To Pay</div>
              <div className="mt-1 text-2xl font-bold text-slate-900 tabular-nums">
                {formatCurrency(committeeSummary.totalRemainingToPay, cur)}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">Separate from Loan Payable</div>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">Due to Receive</div>
              <div className="mt-1 text-xl font-bold text-emerald-700 tabular-nums">
                {formatCurrency(committeeSummary.totalDueToReceive, cur)}
              </div>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">Total Installments Paid</div>
              <div className="mt-1 text-xl font-bold text-slate-900 tabular-nums">
                {formatCurrency(committeeSummary.totalInstallmentsPaid, cur)}
              </div>
            </div>
            <div className="bg-white border border-slate-200 rounded-xl p-4">
              <div className="text-xs text-slate-500">Total Payouts</div>
              <div className="mt-1 text-xl font-bold text-slate-900 tabular-nums">
                {formatCurrency(committeeSummary.totalPayouts, cur)}
              </div>
            </div>
          </div>

          {/* Add / Edit Committee Form */}
          {showCommitteeForm && (
            <form onSubmit={handleSaveCommittee} className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
              <h3 className="text-sm font-semibold text-slate-900">
                {cEditId ? 'Edit Committee' : tr('add_committee')}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label htmlFor="c-title" className="block text-xs font-medium text-slate-700 mb-1">
                    Committee Title *
                  </label>
                  <input
                    id="c-title"
                    type="text"
                    value={cTitle}
                    onChange={(e) => setCTitle(e.target.value)}
                    placeholder="e.g. Office 10-Month Committee"
                    required
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
                <div>
                  <label htmlFor="c-group" className="block text-xs font-medium text-slate-700 mb-1">
                    Person / Group
                  </label>
                  <input
                    id="c-group"
                    type="text"
                    value={cGroup}
                    onChange={(e) => setCGroup(e.target.value)}
                    placeholder="Organizer or group"
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
                <div>
                  <label htmlFor="c-total" className="block text-xs font-medium text-slate-700 mb-1">
                    Total Committee Amount ({cur}) *
                  </label>
                  <input
                    id="c-total"
                    type="number"
                    step="any"
                    value={cTotal}
                    onChange={(e) => setCTotal(e.target.value)}
                    required
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
                  />
                </div>
                <div>
                  <label htmlFor="c-inst" className="block text-xs font-medium text-slate-700 mb-1">
                    Installment Amount ({cur})
                  </label>
                  <input
                    id="c-inst"
                    type="number"
                    step="any"
                    value={cInstAmt}
                    onChange={(e) => setCInstAmt(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
                  />
                </div>
                <div>
                  <label htmlFor="c-count" className="block text-xs font-medium text-slate-700 mb-1">
                    Number of Installments
                  </label>
                  <input
                    id="c-count"
                    type="number"
                    min="1"
                    value={cCount}
                    onChange={(e) => setCCount(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
                  />
                </div>
                <div>
                  <label htmlFor="c-start" className="block text-xs font-medium text-slate-700 mb-1">
                    Start Date
                  </label>
                  <input
                    id="c-start"
                    type="date"
                    value={cStartDate}
                    onChange={(e) => setCStartDate(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                </div>
                <div>
                  <label htmlFor="c-freq" className="block text-xs font-medium text-slate-700 mb-1">
                    Frequency
                  </label>
                  <select
                    id="c-freq"
                    value={cFreq}
                    onChange={(e) => setCFreq(e.target.value as CommitteeFrequency)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                  >
                    <option value="Monthly">Monthly</option>
                    <option value="Weekly">Weekly</option>
                    <option value="Bi-Weekly">Bi-Weekly</option>
                    <option value="Custom">Custom</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="c-dir" className="block text-xs font-medium text-slate-700 mb-1">
                    Balance Type
                  </label>
                  <select
                    id="c-dir"
                    value={cDirection}
                    onChange={(e) => setCDirection(e.target.value as CommitteeDirection)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                  >
                    <option value="payable">To Pay (Installments)</option>
                    <option value="receivable">Due to Receive (Payout)</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCommitteeForm(false)}
                  className="rounded-lg border border-slate-300 px-3.5 py-1.5 text-xs font-medium text-slate-700"
                >
                  {tr('cancel')}
                </button>
                <button
                  type="submit"
                  className={`rounded-lg px-4 py-1.5 text-xs font-medium text-white ${themeTokens.accentBg} ${themeTokens.accentHover}`}
                >
                  {tr('save')}
                </button>
              </div>
            </form>
          )}

          {/* Committee Transaction Form */}
          <form onSubmit={handleSaveCommitteeTx} className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <h3 className="text-sm font-semibold text-slate-900">
              {ctEditId ? 'Edit Committee Entry' : tr('add_committee_tx')}
            </h3>

            {ctError && (
              <div role="alert" className="rounded-lg bg-red-50 border border-red-200 px-3.5 py-2.5 text-xs font-medium text-red-700">
                {ctError}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              <div>
                <label htmlFor="ct-com" className="block text-xs font-medium text-slate-700 mb-1">
                  Committee *
                </label>
                <select
                  id="ct-com"
                  value={ctCommitteeId}
                  onChange={(e) => setCtCommitteeId(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  {state.committees.length === 0 && <option value="">No committees yet</option>}
                  {state.committees.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.title}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="ct-type" className="block text-xs font-medium text-slate-700 mb-1">
                  Entry Type *
                </label>
                <select
                  id="ct-type"
                  value={ctType}
                  onChange={(e) => setCtType(e.target.value as CommitteeTxType)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"
                >
                  <option value="Installment">Installment</option>
                  <option value="Payout">Payout</option>
                </select>
              </div>

              <div>
                <label htmlFor="ct-amount" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('amount')} ({cur}) *
                </label>
                <input
                  id="ct-amount"
                  type="number"
                  step="any"
                  value={ctAmount}
                  onChange={(e) => setCtAmount(e.target.value)}
                  required
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm tabular-nums"
                />
              </div>

              <div>
                <label htmlFor="ct-date" className="block text-xs font-medium text-slate-700 mb-1">
                  {tr('date')} *
                </label>
                <input
                  id="ct-date"
                  type="date"
                  value={ctDate}
                  onChange={(e) => setCtDate(e.target.value)}
                  required
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
                />
              </div>

              <div className="flex items-end">
                <button
                  type="submit"
                  className={`w-full inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2 text-sm font-medium text-white whitespace-nowrap ${themeTokens.accentBg} ${themeTokens.accentHover}`}
                >
                  <Plus className="h-4 w-4" />
                  <span>{ctEditId ? tr('update') : tr('save')}</span>
                </button>
              </div>
            </div>
          </form>

          {/* Per-Committee Overview Table */}
          {committeeSummary.perCommittee.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-200 text-xs font-semibold text-slate-800">
                Active Committees Overview
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                    <tr>
                      <th className="px-4 py-2.5 text-start">Committee</th>
                      <th className="px-4 py-2.5 text-end">Total</th>
                      <th className="px-4 py-2.5 text-end">Installments</th>
                      <th className="px-4 py-2.5 text-end">Paid</th>
                      <th className="px-4 py-2.5 text-end">Payouts</th>
                      <th className="px-4 py-2.5 text-end">Remaining</th>
                      <th className="px-4 py-2.5 text-start">Position</th>
                      <th className="px-4 py-2.5 text-end">{tr('actions')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {committeeSummary.perCommittee.map((c) => (
                      <tr key={c.committeeId} className="hover:bg-slate-50">
                        <td className="px-4 py-2.5">
                          <div className="font-medium text-slate-900">{c.title}</div>
                          {c.personOrGroup && <div className="text-xs text-slate-500">{c.personOrGroup}</div>}
                        </td>
                        <td className="px-4 py-2.5 text-end tabular-nums">
                          {formatCurrency(c.totalAmount, cur)}
                        </td>
                        <td className="px-4 py-2.5 text-end tabular-nums text-slate-600">
                          {formatNumber(c.installmentsPaidCount)} / {formatNumber(c.totalInstallments)}
                        </td>
                        <td className="px-4 py-2.5 text-end tabular-nums">
                          {formatCurrency(c.totalInstallmentsPaid, cur)}
                        </td>
                        <td className="px-4 py-2.5 text-end tabular-nums">
                          {formatCurrency(c.totalPayouts, cur)}
                        </td>
                        <td className="px-4 py-2.5 text-end tabular-nums font-semibold">
                          {formatCurrency(c.remainingBalance, cur)}
                        </td>
                        <td className="px-4 py-2.5 text-xs font-semibold whitespace-nowrap">
                          <span
                            className={
                              c.statusLabel === 'Due to Receive'
                                ? 'text-emerald-700'
                                : c.statusLabel === 'To Pay'
                                  ? 'text-amber-700'
                                  : 'text-slate-500'
                            }
                          >
                            {c.statusLabel}
                          </span>
                        </td>
                        <td className="px-4 py-2.5 text-end whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => triggerDelete('committee', c.committeeId, c.title)}
                            aria-label={`Delete committee ${c.title}`}
                            className="p-1 text-slate-400 hover:text-red-600"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Committee Transactions Table */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div className="relative sm:col-span-2">
                <Search className="h-4 w-4 text-slate-400 absolute start-3 top-2.5" />
                <input
                  type="text"
                  value={cSearch}
                  onChange={(e) => setCSearch(e.target.value)}
                  placeholder="Search committee ledger..."
                  aria-label="Search committee ledger"
                  className="w-full rounded-lg border border-slate-300 ps-9 pe-3 py-2 text-xs"
                />
              </div>
              <select
                value={cFilterId}
                onChange={(e) => setCFilterId(e.target.value)}
                aria-label="Filter by committee"
                className="rounded-lg border border-slate-300 px-2.5 py-2 text-xs bg-white"
              >
                <option value="">All Committees</option>
                {state.committees.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.title}
                  </option>
                ))}
              </select>
            </div>

            {filteredCommitteeTxs.length === 0 ? (
              <div className="px-5 py-10 text-center text-sm text-slate-500">{tr('no_records')}</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                    <tr>
                      <th className="px-4 py-3 text-start">{tr('date')}</th>
                      <th className="px-4 py-3 text-start">Committee</th>
                      <th className="px-4 py-3 text-start">Type</th>
                      <th className="px-4 py-3 text-end">{tr('amount')}</th>
                      <th className="px-4 py-3 text-end">{tr('actions')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredCommitteeTxs.map((tx) => (
                      <tr key={tx.id} className="hover:bg-slate-50">
                        <td className="px-4 py-3 whitespace-nowrap tabular-nums">
                          {formatDate(tx.date, dateFmt)}
                        </td>
                        <td className="px-4 py-3 font-medium text-slate-900">{tx.committeeTitle}</td>
                        <td className="px-4 py-3 text-xs font-semibold text-slate-700">{tx.type}</td>
                        <td className="px-4 py-3 text-end tabular-nums font-semibold">
                          {formatCurrency(tx.amount, cur)}
                        </td>
                        <td className="px-4 py-3 text-end whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() =>
                              triggerDelete('committee_tx', tx.id, `${tx.committeeTitle} (${tx.amount})`)
                            }
                            aria-label={`Delete committee entry ${tx.committeeTitle}`}
                            className="p-1.5 text-slate-500 hover:text-red-600 rounded"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      <ConfirmModal
        open={confirmState.open}
        title={tr('confirm_delete_title')}
        message={`${tr('confirm_delete_msg')} (${confirmState.label})`}
        confirmLabel={tr('delete')}
        cancelLabel={tr('cancel')}
        onCancel={() => setConfirmState((s) => ({ ...s, open: false }))}
        onConfirm={() => {
          if (confirmState.type === 'loan_person') deleteLoanPerson(confirmState.id);
          else if (confirmState.type === 'loan_tx') deleteLoanTx(confirmState.id);
          else if (confirmState.type === 'committee') deleteCommittee(confirmState.id);
          else deleteCommitteeTx(confirmState.id);
          notify('Moved to Recycle Bin.');
          setConfirmState((s) => ({ ...s, open: false }));
        }}
      />
    </div>
  );
};
