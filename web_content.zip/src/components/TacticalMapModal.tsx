import React from 'react';
import { X } from 'lucide-react';
import { HudSnapshot, SectorId } from '../game/types';
import { SECTORS } from '../game/world';

interface TacticalMapModalProps {
  open: boolean;
  hud: HudSnapshot;
  onClose: () => void;
}

const ABILITY_LABELS: Record<string, string> = {
  phase_dash: 'Phase Dash [Shift]',
  grapple_tether: 'Grapple Tether [C]',
  aero_thruster: 'Aero-Thruster [2x Jump]',
  overdrive_arc: 'Overdrive Arc [Blade Wave]',
};

export const TacticalMapModal: React.FC<TacticalMapModalProps> = ({
  open,
  hud,
  onClose,
}) => {
  if (!open) return null;

  const discovered = new Set<SectorId>(hud.discoveredSectors);
  const sectorList = Object.values(SECTORS);
  const defeated = new Set<string>(hud.defeatedBosses || []);

  // Normalize player world coordinates (-1100..5500, -550..3150) onto SVG 820x500 canvas
  const mapPlayerX = Math.max(20, Math.min(800, 40 + ((hud.playerX + 1100) / 6600) * 740));
  const mapPlayerY = Math.max(15, Math.min(485, 20 + ((hud.playerY + 550) / 3700) * 470));

  return (
    <div
      className="absolute inset-0 z-40 flex items-center justify-center overflow-y-auto bg-black/85 p-3 md:p-6"
      role="dialog"
      aria-modal="true"
      aria-label="Sector Cartography Map"
    >
      <div className="my-auto w-full max-w-4xl border border-slate-700/80 bg-[#090d18] p-4 shadow-2xl md:p-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div>
            <h2 className="font-display text-2xl font-bold tracking-wide text-slate-100">
              Sector Cartography
            </h2>
            <p className="mt-1 text-xs text-slate-400">
              <span>{hud.discoveredSectors.length} of 9 Sectors Mapped</span>
              <span className="mx-2" aria-hidden="true">·</span>
              <span>Bosses: {defeated.size}/4</span>
              <span className="mx-2" aria-hidden="true">·</span>
              <span>Shards: {hud.shards}</span>
              <span className="mx-2" aria-hidden="true">·</span>
              <span>Current: {hud.currentSectorName}</span>
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex h-10 w-10 items-center justify-center border border-slate-700 text-slate-300 transition-colors hover:border-cyan-400 hover:text-white focus-visible:outline-2 focus-visible:outline-cyan-400"
            aria-label="Close map"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="mt-5 border border-slate-800 bg-[#05070e] p-3">
          <svg
            viewBox="0 0 820 500"
            className="h-auto w-full"
            aria-label="Interconnected Metroidvania Map"
          >
            {/* Subtle architectural grid */}
            <defs>
              <pattern id="mapGrid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path
                  d="M 40 0 L 0 0 0 40"
                  fill="none"
                  stroke="rgba(148,163,184,0.06)"
                  strokeWidth="1"
                />
              </pattern>
            </defs>
            <rect width="820" height="500" fill="url(#mapGrid)" />

            {/* Inter-sector connection conduits */}
            <g stroke="#334155" strokeWidth="4" strokeLinecap="round">
              {/* Sunken Conduit <-> Maglev Spire */}
              <line x1="160" y1="285" x2="165" y2="285" />
              {/* Sunken Conduit <-> Relay Skybridge */}
              <line x1="340" y1="275" x2="345" y2="275" />
              {/* Sunken Conduit <-> Cryo-Foundry */}
              <line x1="290" y1="325" x2="290" y2="332" />
              {/* Cryo-Foundry <-> Relay Skybridge */}
              <line x1="380" y1="332" x2="380" y2="325" />
              {/* Relay Skybridge <-> Data Vault */}
              <line x1="470" y1="220" x2="470" y2="225" />
              {/* Maglev Spire <-> Black Spire */}
              <line x1="160" y1="160" x2="165" y2="160" />
              {/* Data Vault <-> Black Spire */}
              <line x1="390" y1="160" x2="395" y2="160" />
              {/* Relay Skybridge <-> Void Foundry */}
              <line x1="540" y1="275" x2="545" y2="275" />
              {/* Cryo-Foundry <-> Cryo-Abyss */}
              <line x1="305" y1="410" x2="305" y2="416" />
              {/* Data Vault <-> Zenith Apex */}
              <line x1="455" y1="112" x2="455" y2="120" />
            </g>

            {sectorList.map((sec) => {
              const isDiscovered = discovered.has(sec.id);
              const isCurrent = hud.currentSector === sec.id;
              return (
                <g key={sec.id}>
                  <rect
                    x={sec.mapRect.x}
                    y={sec.mapRect.y}
                    width={sec.mapRect.w}
                    height={sec.mapRect.h}
                    rx={4}
                    fill={isDiscovered ? 'rgba(15, 23, 42, 0.92)' : 'rgba(9, 13, 24, 0.5)'}
                    stroke={isCurrent ? sec.color : isDiscovered ? sec.color : '#1e293b'}
                    strokeOpacity={isCurrent ? 1 : isDiscovered ? 0.6 : 0.7}
                    strokeWidth={isCurrent ? 2.5 : 1.5}
                    strokeDasharray={isDiscovered ? undefined : '6 4'}
                  />
                  <text
                    x={sec.mapRect.x + 10}
                    y={sec.mapRect.y + 20}
                    fill={isDiscovered ? '#f1f5f9' : '#475569'}
                    fontSize="12"
                    fontWeight="700"
                    fontFamily="Chakra Petch, sans-serif"
                  >
                    {isDiscovered ? sec.name : 'Uncharted Sector'}
                  </text>
                  <text
                    x={sec.mapRect.x + 10}
                    y={sec.mapRect.y + 35}
                    fill={isDiscovered ? '#94a3b8' : '#334155'}
                    fontSize="9.5"
                    fontFamily="Plus Jakarta Sans, sans-serif"
                  >
                    {isDiscovered ? sec.subtitle : 'Explore adjoining conduits'}
                  </text>
                </g>
              );
            })}

            {/* Boss markers */}
            {[
              { id: 'boss_archon', label: 'Archon-IX', x: 318, y: 192 },
              { id: 'boss_vortex', label: 'Vortex-VII', x: 695, y: 295 },
              { id: 'boss_glacier', label: 'Glacier-Omega', x: 315, y: 468 },
              { id: 'boss_nexus', label: 'Nexus-Prime', x: 540, y: 86 },
            ].map((bm) => {
              const isDead = defeated.has(bm.id);
              return (
                <g key={bm.id} transform={`translate(${bm.x}, ${bm.y})`}>
                  <polygon
                    points="0,-7 7,0 0,7 -7,0"
                    fill={isDead ? '#10b981' : '#f43f5e'}
                  />
                  <text
                    x="11"
                    y="3.5"
                    fill={isDead ? '#6ee7b7' : '#fda4af'}
                    fontSize="9.5"
                    fontWeight="600"
                  >
                    {isDead ? `${bm.label} ✓` : bm.label}
                  </text>
                </g>
              );
            })}

            {/* Live Player Beacon */}
            <g transform={`translate(${mapPlayerX}, ${mapPlayerY})`}>
              <circle r="8" fill="rgba(34, 211, 238, 0.25)" />
              <circle r="4.5" fill="#22d3ee" stroke="#ffffff" strokeWidth="1.5" />
            </g>
          </svg>
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-300">
          <div className="flex flex-wrap items-center gap-4">
            <span className="font-semibold text-slate-400">Installed Modules:</span>
            {hud.abilities.length === 0 ? (
              <span className="text-slate-500">None yet — explore Maglev Spire & Cryo-Foundry</span>
            ) : (
              hud.abilities.map((ab) => (
                <span key={ab} className="text-cyan-300">
                  {ABILITY_LABELS[ab] || ab}
                </span>
              ))
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="border border-cyan-500/60 bg-cyan-500/15 px-4 py-2 font-medium text-cyan-200 transition-colors hover:bg-cyan-500/25 whitespace-nowrap shrink-0"
          >
            Return to Game [M]
          </button>
        </div>
      </div>
    </div>
  );
};
