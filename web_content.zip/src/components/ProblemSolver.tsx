import { useRef, useState } from "react";
import { solveProblem, trySmartLookup, type SolverResult } from "../solver";
import { useAppState, type Screen } from "../state/AppState";
import { useFormulaHistory } from "../state/FormulaHistoryState";
import FormulaCard from "./FormulaCard";
import GeometryDiagram from "./GeometryDiagram";

const EXAMPLES = [
  { label: "Quadratic", text: "x^2 - 5x + 6 = 0" },
  { label: "Simultaneous equations", text: "2x + y = 10, x - y = 2" },
  { label: "Factorise", text: "factorise x^2 + 7x + 12" },
  { label: "Triangle exterior angle", text: "In triangle ABC, BC is produced to D. If angle ABC = 70 and angle BAC = 50, find angle ACD." },
  { label: "Circle theorem (tangent)", text: "PA and PB are tangents from an external point P to a circle with centre O. If angle APB = 70 degrees, find angle AOB." },
  { label: "Geometry proof", text: "Prove that the angles opposite to equal sides of an isosceles triangle are equal." },
  { label: "Circle area", text: "find area of circle with radius 7" },
  { label: "Pythagoras", text: "right triangle with a=3 and b=4, find hypotenuse" },
  { label: "Ohm's law", text: "voltage 12 and resistance 4, find current" },
  { label: "Mole concept", text: "mass 18g and molar mass 18, find number of moles" },
];

export default function ProblemSolver() {
  const { navigate, board } = useAppState();
  const { recordUsage } = useFormulaHistory();
  const [text, setText] = useState("");
  const [result, setResult] = useState<SolverResult | null>(null);
  const [lookupState, setLookupState] = useState<"idle" | "checking" | "done">("idle");
  const [lookupResult, setLookupResult] = useState<SolverResult | null>(null);
  const lastLoggedRef = useRef<string | null>(null);

  function handleSolve(input?: string) {
    const target = (input ?? text).trim();
    if (!target) return;
    const r = solveProblem(target);
    setResult(r);
    setLookupResult(null);
    setLookupState("idle");

    if (r.matched && r.formulaUsed) {
      const logKey = `${target}::${r.formulaUsed.name}`;
      if (lastLoggedRef.current !== logKey) {
        recordUsage(
          { ...r.formulaUsed, board: r.formulaUsed.board ?? board },
          target,
          r.concept ?? `Used to solve: "${target}"`
        );
        lastLoggedRef.current = logKey;
      }
    }

    if (!r.matched) {
      setLookupState("checking");
      trySmartLookup(target)
        .then((lookup) => {
          setLookupResult(lookup);
          setLookupState("done");
          if (lookup?.formulaUsed) {
            recordUsage({ ...lookup.formulaUsed, board: lookup.formulaUsed.board ?? board }, target, lookup.concept ?? "Found via formula lookup");
          }
        })
        .catch(() => setLookupState("done"));
    }
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <div className="mb-2 flex items-center gap-2">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-md">
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
            <rect x="4" y="2" width="16" height="20" rx="2" />
            <path d="M8 7h8M8 11h8M8 15h4" />
          </svg>
        </span>
        <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100">Problem Solver</h1>
      </div>
      <p className="text-sm text-slate-500 dark:text-slate-400">
        Type a Class 8–10 maths, physics or chemistry question — algebra, geometry proofs, circle theorems, word problems and more — and get a
        complete step-by-step solution with the exact theorem or formula used.
      </p>

      <div className="mt-5 space-y-3">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder='e.g. "In triangle ABC, BC is produced to D. If angle ABC = 70 and angle BAC = 50, find angle ACD."'
          rows={4}
          className="w-full rounded-xl border border-slate-200 bg-white p-4 text-sm shadow-sm outline-none ring-indigo-200 transition focus:ring-4 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:ring-indigo-500/20"
        />
        <button
          onClick={() => handleSolve()}
          disabled={!text.trim()}
          className="rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 px-5 py-2.5 text-sm font-semibold text-white shadow-md transition hover:opacity-90 disabled:opacity-40"
        >
          Solve it →
        </button>
        <div className="flex flex-wrap gap-2 pt-1">
          {EXAMPLES.map((ex) => (
            <button
              key={ex.label}
              onClick={() => {
                setText(ex.text);
                handleSolve(ex.text);
              }}
              className="rounded-full border border-slate-200 bg-white px-3 py-1 text-xs font-medium text-slate-500 transition hover:border-indigo-300 hover:text-indigo-600 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400"
            >
              {ex.label}
            </button>
          ))}
        </div>
      </div>

      {result && <ResultPanel result={result} navigate={navigate} />}

      {!result?.matched && lookupState !== "idle" && (
        <div className="mt-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900">
          <h3 className="text-sm font-bold uppercase tracking-wide text-slate-400">Formula Lookup</h3>
          {lookupState === "checking" && <p className="mt-2 text-sm text-slate-500">Checking FormulaVerse's knowledge base…</p>}
          {lookupState === "done" && lookupResult && <ResultPanel result={lookupResult} navigate={navigate} embedded />}
          {lookupState === "done" && !lookupResult && (
            <p className="mt-2 text-sm text-slate-500">
              No internet lookup service is configured in this deployment, and this topic isn't in FormulaVerse's built-in knowledge base yet.
              Try rephrasing, or browse Search for a related formula.
            </p>
          )}
        </div>
      )}
    </div>
  );
}

function ResultPanel({ result, navigate, embedded }: { result: SolverResult; navigate: (s: Screen) => void; embedded?: boolean }) {
  return (
    <div className={embedded ? "mt-2" : "mt-8 animate-fade-in rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-800 dark:bg-slate-900"}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span
          className={`inline-block rounded-md px-2.5 py-1 text-xs font-semibold uppercase tracking-wide text-white ${
            result.matched ? "bg-gradient-to-r from-indigo-500 to-purple-500" : "bg-slate-400"
          }`}
        >
          {result.category}
        </span>
        {result.formulaUsed?.classLevel && (
          <span className="rounded-md bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-500 dark:bg-slate-800 dark:text-slate-400">
            Class {result.formulaUsed.classLevel} · {result.formulaUsed.subject}
          </span>
        )}
      </div>

      {result.given && result.given.length > 0 && (
        <Block title="Given">
          <ul className="list-disc space-y-1 pl-5 text-sm text-slate-600 dark:text-slate-300">
            {result.given.map((g, i) => (
              <li key={i}>{g}</li>
            ))}
          </ul>
        </Block>
      )}

      {result.toFind && (
        <Block title="To Find / Prove">
          <p className="text-sm text-slate-600 dark:text-slate-300">{result.toFind}</p>
        </Block>
      )}

      {result.concept && (
        <Block title="Concept / Theorem Used">
          <p className="text-sm text-slate-600 dark:text-slate-300">{result.concept}</p>
        </Block>
      )}

      {result.diagram && (
        <Block title="Diagram">
          <GeometryDiagram spec={result.diagram} />
        </Block>
      )}

      {result.formulaText && (
        <Block title="Formula">
          <div className="rounded-xl bg-gradient-to-br from-indigo-600 to-purple-600 p-3 text-center font-mono text-sm text-white shadow-inner">{result.formulaText}</div>
        </Block>
      )}

      {result.steps.length > 0 && (
        <Block title="Step-by-Step Working">
          <ol className="list-decimal space-y-1.5 pl-5 font-mono text-sm text-slate-600 dark:text-slate-300">
            {result.steps.map((s, i) => (
              <li key={i}>{s}</li>
            ))}
          </ol>
        </Block>
      )}

      {result.needsClarification && (
        <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-200">
          <span className="font-semibold">⚠ Clarification needed: </span>
          {result.needsClarification}
        </div>
      )}

      <div
        className={`mt-4 rounded-xl p-4 text-center text-lg font-bold ${
          result.matched ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300" : "bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300"
        }`}
      >
        {result.answer}
      </div>

      {result.verification && (
        <Block title="Verification">
          <p className="text-sm text-slate-600 dark:text-slate-300">{result.verification}</p>
        </Block>
      )}

      {result.relatedFormulaId && (
        <button
          onClick={() => navigate({ name: "formula", id: result.relatedFormulaId! })}
          className="mt-4 w-full rounded-xl border border-indigo-200 bg-indigo-50 px-4 py-2.5 text-sm font-semibold text-indigo-600 transition hover:bg-indigo-100 dark:border-indigo-500/30 dark:bg-indigo-500/10 dark:text-indigo-300"
        >
          Open the interactive formula for this topic →
        </button>
      )}

      {result.formulaUsed && !result.relatedFormulaId && (
        <p className="mt-4 text-center text-xs text-slate-400 dark:text-slate-500">
          Saved to Formula History: <span className="font-medium text-slate-500 dark:text-slate-400">{result.formulaUsed.name}</span>
        </p>
      )}

      {result.suggestions && result.suggestions.length > 0 && (
        <div className="mt-5">
          <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">Related formulas you might need</h3>
          <div className="grid gap-3 sm:grid-cols-2">
            {result.suggestions.map((f) => (
              <FormulaCard key={f.id} formula={f} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function Block({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-4">
      <h3 className="mb-1.5 text-xs font-bold uppercase tracking-wide text-slate-400 dark:text-slate-500">{title}</h3>
      {children}
    </div>
  );
}
