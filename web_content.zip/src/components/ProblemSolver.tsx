import React, { useState } from 'react';
import {
  Sparkles,
  ArrowRight,
  TrendingUp,
  DollarSign,
  Calendar,
  Layers,
  ShieldAlert,
  Clock,
  Bookmark,
  Check,
  Copy,
  FileText,
  AlertCircle,
  Lightbulb,
  Users,
  Target,
  CheckCircle2,
  AlertTriangle,
  Smartphone,
  Wrench,
  HelpCircle,
  Info,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Language, SolvedOpportunity } from '../types';
import { translations } from '../translations/translations';
import { synthesizeOpportunity } from '../services/aiFallbackService';

interface Props {
  language: Language;
  onSaveOpportunity: (opp: SolvedOpportunity) => void;
  savedIds: string[];
  onOpenBusinessPlanModal?: (title: string, description: string) => void;
}

type ResultTab = 'analysis' | 'solutions' | 'budget' | 'timeline' | 'validation';

export const ProblemSolver: React.FC<Props> = ({
  language,
  onSaveOpportunity,
  savedIds,
  onOpenBusinessPlanModal,
}) => {
  const [problemText, setProblemText] = useState('');
  const [category, setCategory] = useState('All');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<SolvedOpportunity | null>(null);
  const [activeResultTab, setActiveResultTab] = useState<ResultTab>('analysis');
  const [copied, setCopied] = useState(false);
  const [resultSource, setResultSource] = useState<string>('gemini');

  const t = translations[language].solver;

  const handleSolve = async () => {
    if (!problemText.trim()) return;

    setIsLoading(true);
    setError(null);

    let resolvedData: any = null;
    let sourceUsed = 'gemini';

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 35000);

      const response = await fetch('/api/gemini/solve-problem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        signal: controller.signal,
        body: JSON.stringify({
          problem: problemText.trim(),
          language,
          category,
        }),
      });

      clearTimeout(timeoutId);

      if (response.ok) {
        const resData = await response.json().catch(() => null);
        if (resData?.data?.opportunityTitle) {
          resolvedData = resData.data;
          sourceUsed = resData.source || 'gemini';
        }
      } else {
        console.warn('Backend responded with HTTP status:', response.status);
      }
    } catch (err: any) {
      console.warn('Network or proxy unavailable, switching seamlessly to Innovation Engine:', err?.message);
    }

    // If server or network was busy/unavailable, run client-side Project Zero engine
    if (!resolvedData || !resolvedData.opportunityTitle) {
      resolvedData = synthesizeOpportunity(problemText.trim(), category, language);
      sourceUsed = 'engine';
    }

    setResultSource(sourceUsed);

    const opportunity: SolvedOpportunity = {
      id: `opp_${Date.now()}`,
      originalProblem: problemText.trim(),
      category,
      language,
      createdAt: new Date().toISOString(),
      // 12 core points with safe fallbacks
      opportunityTitle: resolvedData.opportunityTitle || 'Turnaround Venture Blueprint',
      tagline: resolvedData.tagline || 'Transforming local obstacles into enterprise value',
      problemAnalysis: resolvedData.problemAnalysis || {
        exactProblemBreakdown: problemText.trim(),
        rootCauses: ['Structural logistics gap', 'Limited local processing capacity'],
        currentCostOfInaction: 'Persistent economic loss and diminished productivity',
      },
      affectedAndCustomers: resolvedData.affectedAndCustomers || {
        affectedDemographics: 'Local community members and informal market operators',
        payingCustomers: ['Commercial buyers', 'Local households'],
        whyTheyWillPay: 'Direct cost reduction and verified convenience',
      },
      candidateSolutions: resolvedData.candidateSolutions || [],
      recommendedSolution: resolvedData.recommendedSolution || {
        solutionTitle: resolvedData.opportunityTitle || 'Direct Service Venture',
        selectionRationale: 'Lowest initial cash requirement and immediate daily cashflow',
        howItWorksInPractice: 'Mobilizing local resources with digital payment tracking',
      },
      startupBudget: resolvedData.startupBudget || {
        totalEstimatedETB: '25,000 ETB',
        lineItems: [
          { item: 'Initial inventory & supplies', costETB: '15,000 ETB', essential: true },
          { item: 'Local marketing & signage', costETB: '4,000 ETB', essential: true },
          { item: 'Operating reserve & contingency', costETB: '6,000 ETB', essential: false },
        ],
        lowCapitalTip: 'Begin with prepayments or deposits before purchasing inventory.',
      },
      incomeModel: resolvedData.incomeModel || {
        revenueStreams: ['Direct unit sales', 'Service handling fee'],
        pricingStrategyETB: 'Transparent fixed pricing aligned with market affordability',
        paymentMethods: ['Telebirr', 'CBE Birr', 'Cash'],
      },
      financialEstimates: resolvedData.financialEstimates || {
        estimatedMonthlyRevenueETB: '45,000 ETB',
        estimatedMonthlyExpensesETB: '20,000 ETB',
        estimatedMonthlyNetETB: '25,000 ETB',
        expenseBreakdown: ['Supplies (65%)', 'Logistics (20%)', 'Comms & Reserve (15%)'],
        disclaimer: 'Estimates only. Actual results depend on sales execution and seasonal factors.',
      },
      sevenDayActionPlan: resolvedData.sevenDayActionPlan || [],
      skillsAndResources: resolvedData.skillsAndResources || {
        requiredSkills: ['Customer relationship management', 'Basic bookkeeping'],
        physicalEquipment: ['Reliable smartphone', 'Storage or transport container'],
        digitalTools: ['Telebirr merchant / personal app', 'Telegram channel'],
      },
      risksAndMitigations: resolvedData.risksAndMitigations || [],
      marketDemandTests: resolvedData.marketDemandTests || [],
      validationStatus: resolvedData.validationStatus || {
        isHypothesis: true,
        evidenceStatement: 'Unverified hypothesis. Must secure at least 5 verbal pre-orders before capital spend.',
      },
      // Backward-compatibility properties
      marketOpportunity: resolvedData.problemAnalysis?.exactProblemBreakdown || resolvedData.marketOpportunity,
      proposedSolution: resolvedData.recommendedSolution?.solutionTitle || resolvedData.proposedSolution,
      monetizationModel: resolvedData.incomeModel?.revenueStreams || resolvedData.monetizationModel,
      estimatedStartupBudget: resolvedData.startupBudget?.totalEstimatedETB || resolvedData.estimatedStartupBudget,
      requiredSkills: resolvedData.skillsAndResources?.requiredSkills || resolvedData.requiredSkills,
      keyRisksAndMitigations: resolvedData.risksAndMitigations || resolvedData.keyRisksAndMitigations,
      immediateNext24Hours:
        resolvedData.sevenDayActionPlan?.[0]?.specificActions?.[0] || resolvedData.immediateNext24Hours,
    };

    setResult(opportunity);
    setActiveResultTab('analysis');
    setIsLoading(false);

    // Confetti celebration
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#059669', '#10b981', '#34d399', '#6ee7b7'],
      });
    } catch {}
  };

  const handleCopy = () => {
    if (!result) return;
    const text = `=====================================================
PROJECT ZERO • VENTURE BLUEPRINT
"${result.opportunityTitle}"
${result.tagline}
=====================================================

1. EXACT PROBLEM ANALYSIS & ROOT CAUSES:
Problem: ${result.problemAnalysis.exactProblemBreakdown}
Root Causes:
${result.problemAnalysis.rootCauses.map((rc) => `  • ${rc}`).join('\n')}
Cost of Inaction: ${result.problemAnalysis.currentCostOfInaction}

2. AFFECTED PEOPLE & PAYING CUSTOMERS:
Affected Demographics: ${result.affectedAndCustomers.affectedDemographics}
Paying Customers:
${result.affectedAndCustomers.payingCustomers.map((pc) => `  • ${pc}`).join('\n')}
Why They Will Pay: ${result.affectedAndCustomers.whyTheyWillPay}

3. 3 BUSINESS SOLUTIONS CONSIDERED:
${result.candidateSolutions.map((cs, i) => `${i + 1}. ${cs.title} (Complexity: ${cs.operationalComplexity})
   Summary: ${cs.modelSummary}
   Pros: ${cs.pros.join(', ')}
   Cons: ${cs.cons.join(', ')}`).join('\n\n')}

4. SELECTED PRACTICAL SOLUTION:
Selected: ${result.recommendedSolution.solutionTitle}
Why Selected: ${result.recommendedSolution.selectionRationale}
Operational Model: ${result.recommendedSolution.howItWorksInPractice}

5. STARTUP BUDGET (ETHOPIAN BIRR):
Total Estimated Budget: ${result.startupBudget.totalEstimatedETB}
Itemized Costs:
${result.startupBudget.lineItems.map((li) => `  • ${li.item}: ${li.costETB} [${li.essential ? 'Essential' : 'Optional'}]`).join('\n')}
Low-Capital Starter Tip: ${result.startupBudget.lowCapitalTip}

6. INCOME MODEL & PRICING:
Revenue Streams:
${result.incomeModel.revenueStreams.map((rs) => `  • ${rs}`).join('\n')}
Pricing Strategy: ${result.incomeModel.pricingStrategyETB}
Payment Channels: ${result.incomeModel.paymentMethods.join(', ')}

7. FINANCIAL ESTIMATES (ESTIMATES ONLY):
Est. Monthly Revenue: ${result.financialEstimates.estimatedMonthlyRevenueETB}
Est. Monthly Expenses: ${result.financialEstimates.estimatedMonthlyExpensesETB}
Est. Monthly Net Profit: ${result.financialEstimates.estimatedMonthlyNetETB}
Expense Breakdown: ${result.financialEstimates.expenseBreakdown.join(', ')}
Disclaimer: ${result.financialEstimates.disclaimer}

8. 7-DAY ACTION PLAN:
${result.sevenDayActionPlan.map((d) => `Day ${d.dayNumber}: ${d.dayTitle}
   Milestone: ${d.milestoneGoal}
   Actions: ${d.specificActions.join(' | ')}`).join('\n\n')}

9. SKILLS & RESOURCES:
Skills: ${result.skillsAndResources.requiredSkills.join(', ')}
Equipment: ${result.skillsAndResources.physicalEquipment.join(', ')}
Digital Tools: ${result.skillsAndResources.digitalTools.join(', ')}

10. RISKS & MITIGATIONS:
${result.risksAndMitigations.map((rm) => `  ⚠️ ${rm.risk}\n  ✅ ${rm.mitigation}`).join('\n\n')}

11. TESTING MARKET DEMAND BEFORE INVESTING:
${result.marketDemandTests.map((t, idx) => `Test ${idx + 1}: ${t.testMethod}
   How to Test: ${t.howToConduct}
   Success Signal: ${t.successSignal}`).join('\n\n')}

12. MARKET DEMAND EVIDENCE NOTICE:
${result.validationStatus.evidenceStatement}
`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const isSaved = result ? savedIds.includes(result.id) : false;

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-3xl mx-auto">
      {/* Intro Header */}
      <div className="bg-gradient-to-br from-emerald-800 to-teal-900 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-emerald-500/10 rounded-full blur-2xl"></div>
        <div className="flex items-center space-x-2 text-emerald-300 text-xs font-bold uppercase tracking-wider mb-2">
          <Sparkles className="w-4 h-4" />
          <span>PROJECT ZERO • 12-POINT VENTURE ENGINE</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight leading-snug">
          {t.title}
        </h2>
        <p className="text-emerald-100 text-xs sm:text-sm mt-2 leading-relaxed">
          {t.subtitle}
        </p>
      </div>

      {/* Problem Input Card */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 shadow-sm border border-slate-200 space-y-4">
        <div>
          <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center justify-between">
            <span>{language === 'am' ? 'ያስተዋሉት ችግር ምንድነው?' : 'What Problem Have You Observed?'}</span>
            <span className="text-[11px] font-normal text-slate-400">
              {problemText.length}/1000
            </span>
          </label>
          <textarea
            value={problemText}
            onChange={(e) => setProblemText(e.target.value)}
            placeholder={t.inputPlaceholder}
            rows={4}
            className="w-full p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-slate-800 text-sm focus:outline-hidden focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all placeholder:text-slate-400 leading-relaxed resize-none"
          />
        </div>

        {/* Sector / Category Pills */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-2">
            {t.categoryLabel}
          </label>
          <div className="flex flex-wrap gap-2">
            {[
              { id: 'All', label: t.categories.all },
              { id: 'Agriculture', label: t.categories.agri },
              { id: 'Eco-Green', label: t.categories.green },
              { id: 'Tech', label: t.categories.tech },
              { id: 'Trades', label: t.categories.trades },
              { id: 'Services', label: t.categories.services },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setCategory(cat.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                  category === cat.id
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Presets / Sample Problems */}
        <div className="pt-2 border-t border-slate-100">
          <div className="flex items-center space-x-1.5 text-xs text-slate-500 font-semibold mb-2">
            <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
            <span>{t.tryExamples}</span>
          </div>
          <div className="space-y-1.5">
            {t.examples.map((example, idx) => (
              <button
                key={idx}
                onClick={() => setProblemText(example)}
                className="w-full text-left p-2.5 rounded-xl bg-emerald-50/60 hover:bg-emerald-100/70 border border-emerald-100 text-emerald-900 text-xs transition-colors flex items-start justify-between group"
              >
                <span className="line-clamp-2 leading-relaxed">{example}</span>
                <ArrowRight className="w-3.5 h-3.5 text-emerald-600 shrink-0 ml-2 mt-0.5 opacity-60 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
              </button>
            ))}
          </div>
        </div>

        {/* Error message */}
        {error && (
          <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start space-x-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {/* Submit Action Button */}
        <button
          onClick={handleSolve}
          disabled={isLoading || !problemText.trim()}
          className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center space-x-2 cursor-pointer"
        >
          {isLoading ? (
            <>
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
              <span>{t.analyzingBtn}</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>{t.solveBtn}</span>
            </>
          )}
        </button>
      </div>

      {/* Result Display Section */}
      {result && (
        <div className="bg-white rounded-3xl p-5 sm:p-6 shadow-md border-2 border-emerald-500/30 space-y-5 animate-in fade-in slide-in-from-bottom-4 duration-300">
          {/* Header Badge */}
          <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-100">
            <div className="flex items-center space-x-2">
              <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-emerald-100 text-emerald-800 uppercase tracking-wider flex items-center space-x-1">
                <Sparkles className="w-3 h-3 mr-1" />
                {t.resultHeader}
              </span>
              <span className="text-xs text-slate-400 font-mono">
                {new Date(result.createdAt).toLocaleDateString()}
              </span>
              <span
                className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold flex items-center space-x-1 ${
                  resultSource !== 'engine'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700'
                }`}
              >
                <Sparkles className="w-2.5 h-2.5 mr-1 text-emerald-200" />
                <span>{resultSource !== 'engine' ? `Live AI (${resultSource})` : 'Innovation Engine'}</span>
              </span>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={handleCopy}
                className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center space-x-1 transition-colors"
                title="Copy entire 12-point blueprint to clipboard"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span className="hidden sm:inline">{copied ? 'Copied' : t.copyBtn}</span>
              </button>

              <button
                onClick={() => onSaveOpportunity(result)}
                className={`p-2 rounded-xl text-xs font-semibold flex items-center space-x-1 transition-all ${
                  isSaved
                    ? 'bg-emerald-600 text-white'
                    : 'bg-emerald-100 hover:bg-emerald-200 text-emerald-800'
                }`}
              >
                <Bookmark className="w-3.5 h-3.5" />
                <span>{isSaved ? 'Saved' : t.saveOpportunity}</span>
              </button>
            </div>
          </div>

          {/* Opportunity Title & Tagline */}
          <div className="bg-gradient-to-r from-emerald-50 to-teal-50 p-5 rounded-2xl border border-emerald-100">
            <div className="flex items-center space-x-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-md bg-emerald-700 text-white font-mono text-[10px] uppercase font-bold tracking-wider">
                {result.category}
              </span>
              <span className="text-emerald-700 text-xs font-medium">
                {result.startupBudget?.totalEstimatedETB || result.estimatedStartupBudget}
              </span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-emerald-950">
              {result.opportunityTitle}
            </h3>
            <p className="text-emerald-800 text-sm font-medium mt-1 italic">
              “{result.tagline}”
            </p>
          </div>

          {/* 5-Tab Navigation covering all 12 points */}
          <div className="flex border-b border-slate-200 overflow-x-auto text-xs font-bold gap-1 pb-1">
            {[
              { id: 'analysis', label: t.tabs.analysis },
              { id: 'solutions', label: t.tabs.solutions },
              { id: 'budget', label: t.tabs.budget },
              { id: 'timeline', label: t.tabs.timeline },
              { id: 'validation', label: t.tabs.validation },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveResultTab(tab.id as ResultTab)}
                className={`pb-2 px-3 border-b-2 whitespace-nowrap transition-all rounded-t-lg ${
                  activeResultTab === tab.id
                    ? 'border-emerald-600 text-emerald-800 bg-emerald-50/50'
                    : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-50'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* TAB 1: Problem & Customers (Requirements 1 & 2) */}
          {activeResultTab === 'analysis' && (
            <div className="space-y-4 text-xs sm:text-sm text-slate-700 animate-in fade-in duration-200">
              {/* 1. Exact Problem Analysis & Root Causes */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="font-bold text-slate-900 flex items-center space-x-2 text-xs uppercase tracking-wider">
                  <Target className="w-4 h-4 text-emerald-600" />
                  <span>{t.sections.exactAnalysis}</span>
                </div>
                <p className="leading-relaxed text-slate-800 bg-white p-3 rounded-xl border border-slate-200">
                  {result.problemAnalysis?.exactProblemBreakdown || result.originalProblem}
                </p>

                {/* Root Causes */}
                <div className="pt-2">
                  <div className="text-xs font-bold text-slate-800 mb-1.5 flex items-center space-x-1.5">
                    <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{t.sections.rootCauses}:</span>
                  </div>
                  <div className="space-y-1.5">
                    {(result.problemAnalysis?.rootCauses || []).map((rc, idx) => (
                      <div key={idx} className="flex items-start space-x-2 bg-emerald-50/60 p-2.5 rounded-xl border border-emerald-100">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 mt-1.5 shrink-0" />
                        <span className="text-emerald-950 font-medium leading-relaxed">{rc}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Cost of Inaction */}
                <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-950 text-xs flex items-start space-x-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">{t.sections.costOfInaction}: </span>
                    <span>{result.problemAnalysis?.currentCostOfInaction}</span>
                  </div>
                </div>
              </div>

              {/* 2. Affected Demographics & Paying Customers */}
              <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
                <div className="font-bold text-slate-900 flex items-center space-x-2 text-xs uppercase tracking-wider">
                  <Users className="w-4 h-4 text-teal-600" />
                  <span>{t.sections.affectedPeople}</span>
                </div>
                <p className="text-slate-600 text-xs leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-200">
                  {result.affectedAndCustomers?.affectedDemographics}
                </p>

                <div className="pt-2">
                  <div className="text-xs font-bold text-slate-800 mb-1.5 flex items-center space-x-1.5">
                    <DollarSign className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{t.sections.payingCustomers}:</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {(result.affectedAndCustomers?.payingCustomers || []).map((pc, idx) => (
                      <div key={idx} className="p-2.5 rounded-xl bg-teal-50 border border-teal-100 text-teal-950 flex items-center space-x-2 font-medium text-xs">
                        <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
                        <span>{pc}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Why They Will Pay */}
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 space-y-1">
                  <div className="text-xs font-bold text-emerald-950 flex items-center space-x-1.5">
                    <Lightbulb className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{t.sections.whyTheyPay}</span>
                  </div>
                  <p className="text-xs text-emerald-900 leading-relaxed font-medium">
                    {result.affectedAndCustomers?.whyTheyWillPay}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: 3 Solutions & Selected Recommendation (Requirements 3 & 4) */}
          {activeResultTab === 'solutions' && (
            <div className="space-y-5 text-xs sm:text-sm text-slate-700 animate-in fade-in duration-200">
              {/* 3. Candidate Solutions Considered */}
              <div className="space-y-3">
                <div className="font-bold text-slate-900 flex items-center space-x-2 text-xs uppercase tracking-wider">
                  <Layers className="w-4 h-4 text-emerald-600" />
                  <span>{t.sections.candidateSolutions}</span>
                </div>

                <div className="grid grid-cols-1 gap-3">
                  {(result.candidateSolutions || []).map((sol, idx) => {
                    const isSelected = sol.title.toLowerCase().includes(result.recommendedSolution?.solutionTitle?.toLowerCase() || '') ||
                      result.recommendedSolution?.solutionTitle?.toLowerCase().includes(sol.title.toLowerCase());

                    return (
                      <div
                        key={sol.id || idx}
                        className={`p-4 rounded-2xl border transition-all ${
                          isSelected
                            ? 'bg-emerald-50/70 border-emerald-400 ring-2 ring-emerald-200 shadow-xs'
                            : 'bg-white border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <div className="flex items-center space-x-2">
                            <span className="w-6 h-6 rounded-full bg-slate-800 text-white font-bold text-xs flex items-center justify-center shrink-0">
                              {idx + 1}
                            </span>
                            <h4 className="font-extrabold text-slate-900 text-sm">
                              {sol.title}
                            </h4>
                          </div>

                          <div className="flex items-center space-x-1.5">
                            <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                              sol.operationalComplexity === 'Low'
                                ? 'bg-emerald-100 text-emerald-800'
                                : sol.operationalComplexity === 'Medium'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}>
                              {sol.operationalComplexity} Complexity
                            </span>
                            {isSelected && (
                              <span className="px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-bold uppercase tracking-wider">
                                Recommended
                              </span>
                            )}
                          </div>
                        </div>

                        <p className="text-slate-600 text-xs mb-3 leading-relaxed">
                          {sol.modelSummary}
                        </p>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                          <div className="bg-emerald-50/50 p-2.5 rounded-xl border border-emerald-100">
                            <span className="font-bold text-emerald-900 block mb-1">Pros:</span>
                            <ul className="space-y-1 text-emerald-800">
                              {(sol.pros || []).map((pro, pIdx) => (
                                <li key={pIdx} className="flex items-start space-x-1.5">
                                  <Check className="w-3 h-3 text-emerald-600 shrink-0 mt-0.5" />
                                  <span>{pro}</span>
                                </li>
                              ))}
                            </ul>
                          </div>

                          <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                            <span className="font-bold text-slate-800 block mb-1">Cons / Challenges:</span>
                            <ul className="space-y-1 text-slate-600">
                              {(sol.cons || []).map((con, cIdx) => (
                                <li key={cIdx} className="flex items-start space-x-1.5">
                                  <AlertTriangle className="w-3 h-3 text-amber-500 shrink-0 mt-0.5" />
                                  <span>{con}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 4. Selected Practical Solution */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-emerald-900 to-teal-950 text-white shadow-md space-y-3">
                <div className="flex items-center space-x-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-400 text-emerald-950 font-black text-[10px] uppercase tracking-wider">
                    Selected Most Practical Solution
                  </span>
                </div>
                <h4 className="text-lg font-black text-white">
                  {result.recommendedSolution?.solutionTitle || result.proposedSolution}
                </h4>

                <div className="space-y-2 text-xs">
                  <div className="bg-white/10 p-3 rounded-xl backdrop-blur-xs">
                    <span className="font-bold text-emerald-300 block mb-1">
                      {t.sections.whyChosen}:
                    </span>
                    <p className="text-emerald-50 leading-relaxed font-medium">
                      {result.recommendedSolution?.selectionRationale}
                    </p>
                  </div>

                  <div className="bg-white/10 p-3 rounded-xl backdrop-blur-xs">
                    <span className="font-bold text-emerald-300 block mb-1">
                      {t.sections.howItWorks}:
                    </span>
                    <p className="text-emerald-50 leading-relaxed">
                      {result.recommendedSolution?.howItWorksInPractice}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Budget & Financials in ETB (Requirements 5, 6, 7) */}
          {activeResultTab === 'budget' && (
            <div className="space-y-5 text-xs sm:text-sm text-slate-700 animate-in fade-in duration-200">
              {/* 5. Realistic Startup Budget in ETB */}
              <div className="p-5 rounded-2xl bg-emerald-50 border-2 border-emerald-200 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="font-bold text-emerald-950 text-xs uppercase tracking-wider flex items-center space-x-1.5">
                    <DollarSign className="w-4 h-4 text-emerald-600" />
                    <span>{t.sections.startupBudgetETB}</span>
                  </div>
                  <div className="px-3 py-1 rounded-xl bg-emerald-700 text-white font-black text-sm tracking-wide self-start sm:self-auto">
                    {result.startupBudget?.totalEstimatedETB || result.estimatedStartupBudget}
                  </div>
                </div>

                {/* Itemized Line Items Table */}
                <div className="space-y-2 pt-2">
                  <div className="text-xs font-bold text-emerald-900">
                    {t.sections.essentialItems}:
                  </div>
                  <div className="bg-white rounded-xl border border-emerald-200 overflow-hidden divide-y divide-slate-100">
                    {(result.startupBudget?.lineItems || []).map((li, idx) => (
                      <div key={idx} className="p-2.5 flex items-center justify-between text-xs">
                        <div className="flex items-center space-x-2">
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                            li.essential ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                          }`}>
                            {li.essential ? 'Essential' : 'Optional'}
                          </span>
                          <span className="font-medium text-slate-800">{li.item}</span>
                        </div>
                        <span className="font-extrabold text-slate-900 font-mono">{li.costETB}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Low-Capital Starter Tip */}
                {result.startupBudget?.lowCapitalTip && (
                  <div className="p-3 rounded-xl bg-white/80 border border-emerald-300 text-emerald-950 text-xs flex items-start space-x-2">
                    <Lightbulb className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold">{t.sections.lowCapitalTip}: </span>
                      <span>{result.startupBudget.lowCapitalTip}</span>
                    </div>
                  </div>
                )}
              </div>

              {/* 6. Income Model & Pricing Strategy */}
              <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-4">
                <div className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center space-x-1.5">
                  <TrendingUp className="w-4 h-4 text-emerald-600" />
                  <span>{t.sections.incomeStreams}</span>
                </div>

                <div className="space-y-2">
                  {(result.incomeModel?.revenueStreams || result.monetizationModel || []).map((stream, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-start space-x-2.5 text-xs text-slate-800"
                    >
                      <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <span className="font-medium leading-relaxed">{stream}</span>
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div className="p-3 rounded-xl bg-emerald-50/50 border border-emerald-100 space-y-1">
                    <span className="font-bold text-emerald-950 text-xs block">
                      {t.sections.pricingStrategy}:
                    </span>
                    <p className="text-xs text-emerald-900 leading-relaxed font-medium">
                      {result.incomeModel?.pricingStrategyETB}
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-teal-50/50 border border-teal-100 space-y-1">
                    <span className="font-bold text-teal-950 text-xs block">
                      Local Payment Methods:
                    </span>
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {(result.incomeModel?.paymentMethods || ['Telebirr', 'CBE Birr', 'Cash']).map((pm, idx) => (
                        <span key={idx} className="px-2.5 py-1 rounded-lg bg-teal-100 text-teal-900 text-[11px] font-bold">
                          {pm}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* 7. Clearly Labeled Monthly Financial Estimates */}
              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center space-x-1.5">
                    <DollarSign className="w-4 h-4 text-emerald-600" />
                    <span>{t.sections.financialEstimatesTitle}</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 text-[10px] font-bold uppercase">
                    Estimates
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="p-3 rounded-xl bg-white border border-slate-200">
                    <span className="text-[10px] text-slate-500 font-bold uppercase block mb-1">
                      {t.sections.estRevenue}
                    </span>
                    <span className="text-xs sm:text-sm font-black text-emerald-700">
                      {result.financialEstimates?.estimatedMonthlyRevenueETB}
                    </span>
                  </div>
                  <div className="p-3 rounded-xl bg-white border border-slate-200">
                    <span className="text-[10px] text-slate-500 font-bold uppercase block mb-1">
                      {t.sections.estExpenses}
                    </span>
                    <span className="text-xs sm:text-sm font-black text-rose-600">
                      {result.financialEstimates?.estimatedMonthlyExpensesETB}
                    </span>
                  </div>
                  <div className="p-3 rounded-xl bg-white border-2 border-emerald-400">
                    <span className="text-[10px] text-slate-500 font-bold uppercase block mb-1">
                      {t.sections.estNetProfit}
                    </span>
                    <span className="text-xs sm:text-sm font-black text-emerald-800">
                      {result.financialEstimates?.estimatedMonthlyNetETB}
                    </span>
                  </div>
                </div>

                {/* Expense Breakdown */}
                <div>
                  <span className="font-bold text-slate-800 text-xs block mb-1.5">
                    {t.sections.expenseBreakdown}:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {(result.financialEstimates?.expenseBreakdown || []).map((eb, idx) => (
                      <span key={idx} className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-slate-700 text-xs font-medium">
                        {eb}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Financial Disclaimer */}
                <div className="p-3 rounded-xl bg-amber-50/80 border border-amber-200 text-amber-900 text-xs flex items-start space-x-2">
                  <Info className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">{t.sections.financialDisclaimer}: </span>
                    <span>{result.financialEstimates?.disclaimer}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: 7-Day Action Plan (Requirement 8) */}
          {activeResultTab === 'timeline' && (
            <div className="space-y-4 text-xs sm:text-sm text-slate-700 animate-in fade-in duration-200">
              <div className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center space-x-1.5">
                <Calendar className="w-4 h-4 text-emerald-600" />
                <span>{t.sections.sevenDayTitle}</span>
              </div>

              {/* Immediate Next 24 Hours Callout */}
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200">
                <div className="font-bold text-amber-950 mb-1 flex items-center space-x-1.5 text-xs uppercase tracking-wider">
                  <Clock className="w-4 h-4 text-amber-600" />
                  <span>{t.next24Hours}</span>
                </div>
                <p className="leading-relaxed text-amber-900 font-semibold">
                  {result.sevenDayActionPlan?.[0]?.specificActions?.[0] || result.immediateNext24Hours}
                </p>
              </div>

              {/* 7-Day Timeline */}
              <div className="space-y-3 relative before:absolute before:inset-0 before:left-3.5 before:w-0.5 before:bg-emerald-200">
                {(result.sevenDayActionPlan || []).map((day, idx) => (
                  <div key={day.dayNumber || idx} className="relative pl-8">
                    <div className="absolute left-1.5 top-1.5 w-4 h-4 rounded-full bg-emerald-600 ring-4 ring-emerald-100 flex items-center justify-center text-[9px] text-white font-bold">
                    </div>
                    <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs text-xs space-y-2 hover:border-emerald-300 transition-all">
                      <div className="flex flex-wrap items-center justify-between gap-1 font-bold text-slate-900">
                        <span className="text-emerald-800 font-extrabold text-sm">
                          Day {day.dayNumber}: {day.dayTitle}
                        </span>
                        <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px]">
                          Milestone: {day.milestoneGoal}
                        </span>
                      </div>

                      <ul className="space-y-1.5 pt-1 text-slate-600">
                        {(day.specificActions || []).map((act, aIdx) => (
                          <li key={aIdx} className="flex items-start space-x-2">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                            <span className="leading-relaxed text-slate-800 font-medium">{act}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: Risks & Market Demand Validation (Requirements 9, 10, 11, 12) */}
          {activeResultTab === 'validation' && (
            <div className="space-y-5 text-xs sm:text-sm text-slate-700 animate-in fade-in duration-200">
              {/* 12. Market Demand Evidence Notice (Enforcing Requirement 12) */}
              <div className="p-4 rounded-2xl bg-amber-50 border-2 border-amber-300 space-y-2">
                <div className="flex items-center space-x-2 text-amber-950 font-bold text-xs uppercase tracking-wider">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>{t.sections.evidenceWarningTitle}</span>
                </div>
                <p className="text-xs text-amber-900 font-medium leading-relaxed">
                  {result.validationStatus?.evidenceStatement ||
                    'Notice: Market demand is currently an unproven hypothesis. Do NOT invest startup capital or sign leases until customer intent is verified through tangible pre-orders or verbal commitments.'}
                </p>
              </div>

              {/* 11. Ways to Test Market Demand Before Investing Money */}
              <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
                <div className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center space-x-1.5">
                  <Target className="w-4 h-4 text-emerald-600" />
                  <span>{t.sections.demandTestingTitle}</span>
                </div>

                <div className="space-y-3">
                  {(result.marketDemandTests || []).map((test, idx) => (
                    <div key={idx} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-2">
                      <div className="font-bold text-slate-900 flex items-center space-x-1.5">
                        <span className="w-5 h-5 rounded-full bg-slate-800 text-white font-bold text-[10px] flex items-center justify-center shrink-0">
                          {idx + 1}
                        </span>
                        <span className="text-sm">{test.testMethod}</span>
                      </div>

                      <div className="space-y-1 pl-6">
                        <div className="text-slate-700">
                          <strong className="text-slate-900">{t.sections.howToTest}: </strong>
                          <span>{test.howToConduct}</span>
                        </div>
                        <div className="text-emerald-800 font-medium">
                          <strong>{t.sections.successSignal}: </strong>
                          <span>{test.successSignal}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 10. Operational Risks & Smart Mitigations */}
              <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
                <div className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center space-x-1.5">
                  <ShieldAlert className="w-4 h-4 text-rose-500" />
                  <span>{t.sections.risksTitle}</span>
                </div>

                <div className="space-y-2">
                  {(result.risksAndMitigations || result.keyRisksAndMitigations || []).map((item, idx) => (
                    <div key={idx} className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
                      <div className="font-bold text-rose-700 flex items-start space-x-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0 mt-0.5" />
                        <span>{item.risk}</span>
                      </div>
                      <div className="text-emerald-800 font-medium pl-5 flex items-start space-x-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{item.mitigation}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 9. Skills & Resources Required */}
              <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-3">
                <div className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center space-x-1.5">
                  <Layers className="w-4 h-4 text-emerald-600" />
                  <span>{t.sections.skillsTitle}</span>
                </div>

                <div className="space-y-3">
                  <div>
                    <span className="text-xs font-bold text-slate-700 block mb-1.5">
                      {t.sections.practicalSkills}:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {(result.skillsAndResources?.requiredSkills || result.requiredSkills || []).map((sk, idx) => (
                        <span key={idx} className="px-2.5 py-1 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-900 font-medium text-xs">
                          {sk}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="text-xs font-bold text-slate-700 block mb-1.5 flex items-center space-x-1">
                      <Wrench className="w-3 h-3 text-slate-500" />
                      <span>{t.sections.equipmentNeeded}:</span>
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {(result.skillsAndResources?.physicalEquipment || []).map((eq, idx) => (
                        <span key={idx} className="px-2.5 py-1 rounded-lg bg-slate-100 border border-slate-200 text-slate-800 font-medium text-xs">
                          {eq}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="text-xs font-bold text-slate-700 block mb-1.5 flex items-center space-x-1">
                      <Smartphone className="w-3 h-3 text-slate-500" />
                      <span>{t.sections.digitalTools}:</span>
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {(result.skillsAndResources?.digitalTools || []).map((dt, idx) => (
                        <span key={idx} className="px-2.5 py-1 rounded-lg bg-teal-50 border border-teal-200 text-teal-900 font-medium text-xs">
                          {dt}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Footer Call to Action: Generate 1-Page Business Plan */}
          <div className="pt-4 border-t border-slate-100">
            <button
              onClick={() => onOpenBusinessPlanModal?.(result.opportunityTitle, result.recommendedSolution?.solutionTitle || result.proposedSolution || '')}
              className="w-full py-3.5 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm transition-colors flex items-center justify-center space-x-2 shadow-sm cursor-pointer"
            >
              <FileText className="w-4 h-4 text-emerald-400" />
              <span>{t.generateBusinessPlan}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
