import { useMemo, useState } from "react";
import { lineDiff } from "../lib/diff";
import { cn } from "../utils/cn";

export default function DiffView({
  before,
  after,
}: {
  before: string;
  after: string;
}) {
  const rows = useMemo(() => lineDiff(before, after), [before, after]);
  const [expanded, setExpanded] = useState(false);
  return (
    <div className="overflow-hidden rounded-lg border border-line bg-bg">
      <div className="flex items-center justify-between border-b border-line px-3 py-2 font-mono text-[10px]">
        <span className="text-muted">PROPOSED DIFF</span>
        <span className="flex gap-3">
          <span className="text-ok">
            +{rows.filter((r) => r.kind === "add").length}
          </span>
          <span className="text-danger">
            -{rows.filter((r) => r.kind === "remove").length}
          </span>
        </span>
      </div>
      <div className="max-h-[320px] overflow-auto py-1 font-mono text-[11px] leading-[20px]">
        {(expanded ? rows : rows.slice(0, 16)).map((row, i) => (
          <div
            key={i}
            className={cn(
              "flex min-w-fit",
              row.kind === "add"
                ? "bg-oksoft text-ok"
                : row.kind === "remove"
                  ? "bg-dangersoft text-danger"
                  : "text-muted",
            )}
          >
            <span className="w-9 shrink-0 select-none pr-2 text-right opacity-40">
              {row.oldLine ?? ""}
            </span>
            <span className="w-9 shrink-0 select-none pr-2 text-right opacity-40">
              {row.newLine ?? ""}
            </span>
            <span className="w-5 shrink-0 select-none">
              {row.kind === "add" ? "+" : row.kind === "remove" ? "-" : " "}
            </span>
            <span className="whitespace-pre pr-4">{row.text || " "}</span>
          </div>
        ))}
      </div>
      {rows.length > 16 && (
        <button
          onClick={() => setExpanded(!expanded)}
          className="w-full border-t border-line py-2 text-[11px] text-muted hover:bg-surface2"
        >
          {expanded ? "Show less" : `Show all ${rows.length} lines`}
        </button>
      )}
    </div>
  );
}
