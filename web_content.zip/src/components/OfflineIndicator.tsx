import React from 'react';
import { useOnlineStatus } from '../hooks/usePWAInstall';
import { WifiOff } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  const { t } = useApp();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2.5 rounded-lg bg-amber-600 px-4 py-2.5 text-xs sm:text-sm font-medium text-white shadow-xl border border-amber-400">
      <WifiOff className="w-4 h-4 animate-pulse flex-shrink-0" />
      <span>{t.pwaBanner.offlineAlert}</span>
    </div>
  );
};
