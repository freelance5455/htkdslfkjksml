import React from 'react';
import { WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export const OfflineIndicator: React.FC<{ isLight: boolean }> = ({ isLight }) => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      className={`fixed bottom-20 left-4 right-4 sm:left-auto sm:right-6 z-50 flex items-center gap-2 rounded-2xl px-4 py-2.5 text-xs font-semibold shadow-xl border animate-bounce ${
        isLight
          ? 'bg-amber-500 text-white border-amber-600'
          : 'bg-amber-600/90 text-white border-amber-500/80 backdrop-blur-sm'
      }`}
    >
      <WifiOff className="w-4 h-4 shrink-0" />
      <span>অফলাইন — সংরক্ষিত ডেটা থেকে অ্যাপ চলছে</span>
    </div>
  );
};
