import React from 'react';
import { WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import type { Language } from '../types/study';

interface OfflineIndicatorProps {
  lang?: Language;
}

export const OfflineIndicator: React.FC<OfflineIndicatorProps> = ({ lang = 'bn' }) => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      role="status"
      className="fixed bottom-20 left-4 z-50 flex items-center gap-2 rounded-xl border border-amber-300/30 bg-amber-500/90 px-3.5 py-2 text-xs font-semibold text-slate-950 shadow-lg backdrop-blur-md md:bottom-5"
    >
      <WifiOff className="h-3.5 w-3.5" aria-hidden="true" />
      <span>{lang === 'bn' ? 'অফলাইন মোড' : 'Offline Mode'}</span>
    </div>
  );
};
