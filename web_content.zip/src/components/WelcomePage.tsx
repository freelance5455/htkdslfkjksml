import React from "react";
import {
  ArrowRight,
  BookOpen,
  Camera,
  CheckCircle2,
  Globe,
  Info,
  ShieldCheck,
  UserCheck,
} from "lucide-react";
import type { ServerHealth, UserProfile } from "../types/chat";
import { BrandLogo } from "./BrandLogo";

interface WelcomePageProps {
  health: ServerHealth | null;
  user: UserProfile;
  onStartChat: () => void;
  onOpenAbout: () => void;
  onOpenSettings: () => void;
}

export const WelcomePage: React.FC<WelcomePageProps> = ({
  health,
  user,
  onStartChat,
  onOpenAbout,
  onOpenSettings,
}) => {
  const features = [
    {
      icon: <Camera className="w-5 h-5 text-blue-600 dark:text-blue-400" />,
      title: "Text & Photo Understanding",
      description:
        "Type a question or upload a photo of handwritten notes, printed textbook pages, diagrams, or math problems.",
    },
    {
      icon: <Globe className="w-5 h-5 text-blue-600 dark:text-blue-400" />,
      title: "English, বাংলা & हिन्दी",
      description:
        "Automatically detects the language of your question and replies clearly in English, Bengali, or Hindi.",
    },
    {
      icon: <BookOpen className="w-5 h-5 text-blue-600 dark:text-blue-400" />,
      title: "Step-by-Step Explanations",
      description:
        "Solves academic and math problems clearly step by step in simple language instead of skipping straight to a result.",
    },
    {
      icon: <ShieldCheck className="w-5 h-5 text-blue-600 dark:text-blue-400" />,
      title: "Text & Photo Only · Private",
      description:
        "Zero microphone or voice tracking. Conversations stay saved in your browser unless you clear them.",
    },
  ];

  return (
    <div className="flex-1 overflow-y-auto mih-scroll">
      <div className="max-w-5xl mx-auto px-4 sm:px-8 py-8 sm:py-14 space-y-10">
        {/* Hero Block */}
        <section className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-10 shadow-xs">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-8">
            <div className="space-y-5 max-w-2xl">
              <BrandLogo size="lg" showSubtitle />

              <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white leading-tight [text-wrap:balance]">
                Clear answers from text and photos, built for everyday learning.
              </h1>

              <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed">
                Ask questions by typing or capturing a photo. MIH.AI explains
                concepts step by step in English, Bengali (বাংলা), and Hindi
                (हिन्दी) with a clean, distraction-free workspace.
              </p>

              <div className="flex flex-wrap items-center gap-3 pt-1">
                <button
                  type="button"
                  onClick={onStartChat}
                  className="min-h-[48px] px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-[0.99] text-white text-sm sm:text-base font-semibold inline-flex items-center gap-2 transition-all shadow-xs whitespace-nowrap"
                >
                  <span>Start Chatting</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={onOpenAbout}
                  className="min-h-[48px] px-5 py-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 text-sm font-medium transition-colors whitespace-nowrap"
                >
                  Privacy & About
                </button>
              </div>
            </div>

            {/* Honest Environment & Account Status Panel */}
            <div className="w-full lg:w-80 shrink-0 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
              <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                Workspace Status
              </div>

              <div className="space-y-3 text-sm">
                <div className="flex items-start gap-2.5">
                  {health?.aiConfigured ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mt-0.5 shrink-0" />
                  ) : (
                    <Info className="w-4 h-4 text-amber-600 dark:text-amber-400 mt-0.5 shrink-0" />
                  )}
                  <div>
                    <div className="font-medium text-slate-900 dark:text-slate-100">
                      {health === null
                        ? "Checking AI service…"
                        : health.aiConfigured
                        ? "Gemini Multimodal AI Ready"
                        : "Gemini API Not Configured"}
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">
                      {health?.aiConfigured
                        ? "Server-side text and photo analysis is active."
                        : "Add GEMINI_API_KEY in Settings > Secrets to activate live responses."}
                    </p>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-start gap-2.5">
                  <UserCheck className="w-4 h-4 text-blue-600 dark:text-blue-400 mt-0.5 shrink-0" />
                  <div>
                    <div className="font-medium text-slate-900 dark:text-slate-100">
                      {user.mode === "google"
                        ? `Signed in as ${user.name}`
                        : "Local Demo Mode Active"}
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">
                      {health?.googleAuthConfigured
                        ? "Google Sign-In is available in Settings, or continue right away without logging in."
                        : "No login required. Chat history is stored locally on this device."}
                    </p>
                    <button
                      type="button"
                      onClick={onOpenSettings}
                      className="mt-2 text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline"
                    >
                      Open Settings
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Capabilities Grid */}
        <section aria-label="Core capabilities">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {features.map((feat) => (
              <div
                key={feat.title}
                className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 sm:p-6 space-y-2.5"
              >
                <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/50 flex items-center justify-center">
                  {feat.icon}
                </div>
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100">
                  {feat.title}
                </h2>
                <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                  {feat.description}
                </p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
