/**
 * SPR - Sahil Powerful Run
 * 12 Stylized 3D Players & 15 Custom 3D Skateboards Showcase & Shop
 * 
 * Responsive Portrait & Landscape Engine:
 * - Portrait Mode (Vertical): Uses full available phone screen.
 *   Shows Top Navigation (Home button, Coin Balance, Settings, Leaderboard, Mail/Reward, Profile).
 *   Sub-header with Runners & Boards switcher tabs.
 *   Prominent, large 3D character/board preview (no clipping of head, body, feet, skateboard, or pedestal).
 *   Player/Board status bar with instant Select/Equip/Unlock action buttons.
 *   Scrollable cards roster.
 *   Docked bottom navigation bar (Home, Balance, Runners, Boards, More).
 * - Landscape Mode (Horizontal): Streamlined horizontal layout.
 *   Portrait-only top UI (Home button, top icons) hidden as requested.
 *   Side-by-side 3D stage and cards roster.
 * - Dynamic rotation adaptation without reload.
 * - 100% Offline with zero external dependencies.
 */

import React, { useState } from 'react';
import {
  X,
  Check,
  Lock,
  Sparkles,
  Disc,
  Zap,
  Magnet,
  Shield,
  Home,
  Settings,
  BarChart2,
  Mail,
  MoreVertical,
  User,
  Coins,
} from 'lucide-react';
import { CHARACTERS, CharacterDef } from '../game/constants';
import { SKATEBOARDS, SkateboardDef } from '../game/constants/skateboards';
import { saveManager } from '../game/storage/SaveManager';
import { soundManager } from '../game/audio/SoundManager';
import { CharacterPreviewCanvas } from '../game/scenes/CharacterPreviewCanvas';
import { SkateboardPreviewCanvas } from '../game/scenes/SkateboardPreviewCanvas';
import { useOrientation } from '../hooks/useOrientation';

interface Props {
  onClose: () => void;
  coins: number;
  onCoinsChange: (newBalance: number) => void;
  onCharacterSelected: (charId: number) => void;
  onSkateboardEquipped?: (boardId: number) => void;
  initialTab?: 'characters' | 'skateboards';
  isPortrait?: boolean;
  onHome?: () => void;
  onOpenSettings?: () => void;
  onOpenLeaderboard?: () => void;
  onOpenDailyReward?: () => void;
  onOpenAbout?: () => void;
}

export const ShopModal: React.FC<Props> = ({
  onClose,
  coins,
  onCoinsChange,
  onCharacterSelected,
  onSkateboardEquipped,
  initialTab = 'characters',
  isPortrait: propIsPortrait,
  onHome,
  onOpenSettings,
  onOpenLeaderboard,
  onOpenDailyReward,
  onOpenAbout,
}) => {
  const [activeTab, setActiveTab] = useState<'characters' | 'skateboards'>(initialTab);
  const detectedIsPortrait = useOrientation();
  const isPortrait = propIsPortrait !== undefined ? propIsPortrait : detectedIsPortrait;

  // Character State
  const currentSelectedCharId = saveManager.getSelectedCharacterId();
  const [inspectingCharId, setInspectingCharId] = useState<number>(currentSelectedCharId);
  const [previewBoardOnChar, setPreviewBoardOnChar] = useState<boolean>(true);

  // Skateboard State
  const currentEquippedBoardId = saveManager.getEquippedSkateboardId();
  const [inspectingBoardId, setInspectingBoardId] = useState<number>(currentEquippedBoardId || 1);

  // Common UI State
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Active Inspecting Items
  const inspectingChar = CHARACTERS.find((c) => c.id === inspectingCharId) || CHARACTERS[0];
  const isCharOwned = saveManager.isCharacterUnlocked(inspectingChar.id);
  const isCharSelected = inspectingChar.id === currentSelectedCharId;

  const inspectingBoard = SKATEBOARDS.find((b) => b.id === inspectingBoardId) || SKATEBOARDS[0];
  const isBoardOwned = saveManager.isSkateboardUnlocked(inspectingBoard.id);
  const isBoardEquipped = inspectingBoard.id === currentEquippedBoardId;

  // Character handlers
  const handleSelectCharacter = (charId: number) => {
    soundManager.playButtonClick();
    saveManager.setSelectedCharacterId(charId);
    onCharacterSelected(charId);
  };

  const handleBuyCharacter = (char: CharacterDef) => {
    soundManager.playButtonClick();
    if (coins < char.price) {
      setErrorMsg(`Not enough coins! You need ₹${(char.price - coins).toLocaleString()} more.`);
      setTimeout(() => setErrorMsg(null), 3000);
      return;
    }

    if (saveManager.spendCoins(char.price)) {
      saveManager.unlockCharacter(char.id);
      saveManager.setSelectedCharacterId(char.id);
      onCoinsChange(saveManager.getCoins());
      onCharacterSelected(char.id);
      soundManager.playPowerupSound();
    }
  };

  // Skateboard handlers
  const handleEquipSkateboard = (boardId: number) => {
    soundManager.playButtonClick();
    saveManager.setEquippedSkateboardId(boardId);
    onSkateboardEquipped?.(boardId);
  };

  const handleBuySkateboard = (board: SkateboardDef) => {
    soundManager.playButtonClick();
    const stock = saveManager.getSkateboardStock(board.id);
    if (stock <= 0) {
      setErrorMsg('This skateboard is OUT OF STOCK! All 100 pieces sold out.');
      setTimeout(() => setErrorMsg(null), 3000);
      return;
    }

    if (coins < board.price) {
      setErrorMsg(`Not enough coins! You need ₹${(board.price - coins).toLocaleString()} more.`);
      setTimeout(() => setErrorMsg(null), 3000);
      return;
    }

    const result = saveManager.buySkateboard(board.id, board.price);
    if (result.success) {
      onCoinsChange(saveManager.getCoins());
      onSkateboardEquipped?.(board.id);
      soundManager.playPowerupSound();
    } else if (result.reason) {
      setErrorMsg(result.reason);
      setTimeout(() => setErrorMsg(null), 3000);
    }
  };

  const unlockedCharCount = saveManager.getSaveData().unlockedCharacters.length;
  const unlockedBoardCount = saveManager.getUnlockedSkateboards().length;

  const handleHomeClick = () => {
    soundManager.playButtonClick();
    if (onHome) {
      onHome();
    } else {
      onClose();
    }
  };

  /* =========================================================================
     PORTRAIT MODE LAYOUT (Matches reference design specifications)
     ========================================================================= */
  if (isPortrait) {
    return (
      <div className="fixed inset-0 z-40 flex flex-col bg-gradient-to-b from-[#060914] via-[#090f20] to-black text-white select-none overflow-hidden safe-area-insets">
        {/* 1. PORTRAIT-ONLY TOP BAR (Home, Coin Balance, Settings, Leaderboard, Mail, Profile) */}
        <div className="flex items-center justify-between px-3 pt-2 pb-1.5 bg-slate-950/90 border-b border-slate-800/80 shrink-0">
          <div className="flex items-center gap-2">
            {/* Home button */}
            <button
              id="shop-portrait-home-btn"
              onClick={handleHomeClick}
              className="w-10 h-10 rounded-xl bg-slate-900 border-2 border-amber-400/80 hover:border-amber-300 text-amber-300 flex items-center justify-center shadow-[0_0_12px_rgba(245,158,11,0.3)] active:scale-95 transition cursor-pointer"
              title="Return to Home"
            >
              <Home className="w-5 h-5 stroke-[2.5]" />
            </button>

            {/* Coin Balance Pill */}
            <div
              id="shop-portrait-coin-balance"
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900/90 border-2 border-amber-400/80 rounded-full shadow-md"
            >
              <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center shadow-inner text-slate-950 text-xs font-black">
                🪙
              </div>
              <span className="text-amber-400 font-bold text-sm tracking-wide font-display">
                ₹{coins.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Top action icons */}
          <div className="flex items-center gap-2">
            <button
              id="shop-portrait-btn-settings"
              onClick={() => {
                soundManager.playButtonClick();
                if (onOpenSettings) onOpenSettings();
                else onClose();
              }}
              className="w-8 h-8 rounded-full bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 flex items-center justify-center shadow active:scale-95 transition cursor-pointer"
              title="Settings"
            >
              <Settings className="w-4 h-4" />
            </button>

            <button
              id="shop-portrait-btn-leaderboard"
              onClick={() => {
                soundManager.playButtonClick();
                if (onOpenLeaderboard) onOpenLeaderboard();
                else onClose();
              }}
              className="w-8 h-8 rounded-full bg-slate-900 hover:bg-slate-800 border border-yellow-500/70 text-yellow-300 flex items-center justify-center shadow active:scale-95 transition cursor-pointer"
              title="Leaderboard"
            >
              <BarChart2 className="w-4 h-4" />
            </button>

            <button
              id="shop-portrait-btn-mail"
              onClick={() => {
                soundManager.playButtonClick();
                if (onOpenDailyReward) onOpenDailyReward();
                else onClose();
              }}
              className="relative w-8 h-8 rounded-full bg-slate-900 hover:bg-slate-800 border border-red-500/70 text-red-300 flex items-center justify-center shadow active:scale-95 transition cursor-pointer"
              title="Daily Rewards & Mail"
            >
              <Mail className="w-4 h-4" />
              <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 bg-red-500 border border-white text-white rounded-full text-[8px] font-black flex items-center justify-center">
                1
              </span>
            </button>

            <button
              id="shop-portrait-btn-profile"
              onClick={() => {
                soundManager.playButtonClick();
                if (onOpenAbout) onOpenAbout();
                else onClose();
              }}
              className="relative w-8 h-8 rounded-full p-0.5 bg-gradient-to-tr from-amber-500 to-yellow-300 shadow active:scale-95 transition cursor-pointer overflow-hidden"
              title="Profile & Info"
            >
              <img src="/thumbnail.jpg" alt="SPR" className="w-full h-full rounded-full object-cover" />
            </button>
          </div>
        </div>

        {/* 2. SUB-HEADER BANNER WITH TABS SWITCHER */}
        <div className="flex items-center justify-between px-3 py-2 bg-gradient-to-r from-slate-900/90 via-slate-950/90 to-slate-900/90 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-500 to-yellow-400 flex items-center justify-center text-slate-950 text-base font-black shadow-md">
              👑
            </div>
            <div>
              <h2 className="text-xs sm:text-sm font-black tracking-wider text-white uppercase font-display leading-tight">
                {activeTab === 'characters' ? 'SPR 3D RUNNERS ROSTER' : 'SPR 3D SKATEBOARD GARAGE'}
              </h2>
              <p className="text-[10px] text-slate-400">
                {activeTab === 'characters'
                  ? `12 Stylized 3D Characters • Unlocked: ${unlockedCharCount}/12`
                  : `15 Custom 3D Boards • Unlocked: ${unlockedBoardCount}/15`}
              </p>
            </div>
          </div>

          {/* Switcher Tabs */}
          <div className="flex items-center bg-slate-950 p-0.5 rounded-xl border border-slate-800 shadow-inner">
            <button
              id="shop-tab-runners-portrait"
              onClick={() => {
                soundManager.playButtonClick();
                setActiveTab('characters');
                setErrorMsg(null);
              }}
              className={`px-2.5 py-1 text-xs font-black rounded-lg transition uppercase font-display flex items-center gap-1 cursor-pointer ${
                activeTab === 'characters'
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>🏃</span>
              <span>RUNNERS</span>
            </button>
            <button
              id="shop-tab-boards-portrait"
              onClick={() => {
                soundManager.playButtonClick();
                setActiveTab('skateboards');
                setErrorMsg(null);
              }}
              className={`px-2.5 py-1 text-xs font-black rounded-lg transition uppercase font-display flex items-center gap-1 cursor-pointer ${
                activeTab === 'skateboards'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>🛹</span>
              <span>BOARDS (15)</span>
            </button>
          </div>
        </div>

        {/* 3. SCROLLABLE MAIN CONTENT (Full screen vertical height, properly fitted) */}
        <div className="flex-1 overflow-y-auto flex flex-col pb-2">
          {activeTab === 'characters' ? (
            /* ========================================================
               PORTRAIT RUNNERS VIEW
               ======================================================== */
            <div className="flex flex-col w-full">
              {/* Large 3D Character Stage */}
              <div className="relative w-full h-64 sm:h-72 bg-gradient-to-b from-[#0c1224] via-[#080d1a] to-black border-b border-slate-800 shrink-0">
                <CharacterPreviewCanvas
                  characterId={inspectingChar.id}
                  showSkateboard={previewBoardOnChar}
                />

                {/* Top-left Badges */}
                <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 pointer-events-none">
                  <span className="text-[10px] font-bold text-amber-300 bg-black/80 px-2 py-0.5 rounded border border-amber-500/50 font-mono shadow">
                    Player #{inspectingChar.id}
                  </span>
                  <span className="text-[10px] font-bold text-cyan-300 bg-black/80 px-2 py-0.5 rounded border border-cyan-500/50 shadow">
                    3D Model
                  </span>
                </div>

                {/* Bottom-right Board Toggle */}
                <button
                  id="shop-portrait-toggle-board"
                  onClick={() => {
                    soundManager.playButtonClick();
                    setPreviewBoardOnChar(!previewBoardOnChar);
                  }}
                  className={`absolute bottom-2.5 right-2.5 px-2.5 py-1 text-[11px] rounded-lg font-bold border transition flex items-center gap-1.5 shadow-lg cursor-pointer ${
                    previewBoardOnChar
                      ? 'bg-amber-500/25 border-amber-400 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.4)]'
                      : 'bg-slate-900/85 border-slate-700 text-slate-400 hover:text-white'
                  }`}
                  title="Toggle Skateboard on Player"
                >
                  <Disc className="w-3.5 h-3.5" />
                  <span>{previewBoardOnChar ? 'Board: ON' : 'Board: OFF'}</span>
                </button>
              </div>

              {/* Player Status Bar & Action Button */}
              <div className="px-3 py-2 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
                <div>
                  <h3 className="text-sm sm:text-base font-black text-white font-display uppercase tracking-wide">
                    {inspectingChar.name}
                  </h3>
                  <div className="text-[11px] font-semibold text-amber-400 flex items-center gap-1">
                    <span>{inspectingChar.title}</span>
                    <span className="text-slate-500">•</span>
                    <span className="text-slate-400 text-[10px] italic">{inspectingChar.lore}</span>
                  </div>
                </div>

                <div className="shrink-0">
                  {isCharOwned ? (
                    isCharSelected ? (
                      <span className="px-3 py-1.5 bg-emerald-950 border border-emerald-500/60 text-emerald-400 text-xs font-black uppercase rounded-lg shadow flex items-center gap-1 font-display">
                        <Check className="w-3.5 h-3.5" /> ACTIVE
                      </span>
                    ) : (
                      <button
                        id="shop-portrait-btn-select-runner"
                        onClick={() => handleSelectCharacter(inspectingChar.id)}
                        className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-slate-950 font-black text-xs uppercase tracking-wider rounded-lg transition shadow-lg flex items-center gap-1 cursor-pointer font-display"
                      >
                        SELECT RUNNER
                      </button>
                    )
                  ) : (
                    <button
                      id="shop-portrait-btn-buy-runner"
                      onClick={() => handleBuyCharacter(inspectingChar)}
                      className="px-3 py-1.5 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-500 hover:from-amber-400 hover:to-orange-400 active:scale-95 text-slate-950 font-black text-xs uppercase tracking-wider rounded-lg transition shadow-[0_0_15px_rgba(245,158,11,0.5)] flex items-center gap-1 cursor-pointer font-display"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>UNLOCK ₹{inspectingChar.price.toLocaleString()}</span>
                    </button>
                  )}
                </div>
              </div>

              {errorMsg && (
                <div className="mx-3 mt-2 text-xs text-red-400 font-bold bg-red-950/90 border border-red-500/60 p-2 rounded-lg animate-shake">
                  {errorMsg}
                </div>
              )}

              {/* Roster Section Header */}
              <div className="px-3 pt-2.5 pb-1 flex items-center justify-between text-[11px] font-bold text-slate-400">
                <span>SELECT A 3D RUNNER ({unlockedCharCount}/12 UNLOCKED)</span>
                <span className="text-[10px] text-amber-400">Tap card to inspect 3D Model</span>
              </div>

              {/* 12 Characters Cards Grid */}
              <div className="px-3 py-1.5 grid grid-cols-2 sm:grid-cols-3 gap-2">
                {CHARACTERS.map((char) => {
                  const owned = saveManager.isCharacterUnlocked(char.id);
                  const active = char.id === currentSelectedCharId;
                  const inspecting = char.id === inspectingCharId;

                  return (
                    <div
                      key={char.id}
                      id={`portrait-char-card-${char.id}`}
                      onClick={() => {
                        soundManager.playButtonClick();
                        setInspectingCharId(char.id);
                      }}
                      className={`relative p-2.5 rounded-xl border transition cursor-pointer flex flex-col justify-between ${
                        inspecting
                          ? 'bg-slate-800/95 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.35)] ring-1 ring-amber-400'
                          : owned
                          ? 'bg-slate-900/70 border-slate-700/70 hover:border-slate-500 hover:bg-slate-800/80'
                          : 'bg-black/60 border-slate-800/80 opacity-85 hover:opacity-100'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[10px] font-black text-slate-400 font-mono">
                          #{char.id}
                        </span>
                        {active ? (
                          <span className="px-1.5 py-0.5 bg-emerald-500 text-slate-950 text-[9px] font-black rounded uppercase">
                            ACTIVE
                          </span>
                        ) : owned ? (
                          <span className="text-emerald-400 text-[10px] font-bold">UNLOCKED</span>
                        ) : (
                          <span className="flex items-center gap-0.5 text-[10px] font-black text-amber-400 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-500/40 font-display">
                            <Lock className="w-2.5 h-2.5" />
                            ₹{char.price.toLocaleString()}
                          </span>
                        )}
                      </div>

                      <div className="my-0.5">
                        <div className="text-xs font-bold text-white truncate font-display">
                          {char.name}
                        </div>
                        <div className="text-[10px] text-slate-400 truncate">{char.title}</div>
                      </div>

                      <div className="flex items-center gap-1.5 mt-1 pt-1 border-t border-slate-800/80">
                        <div
                          className="w-3 h-3 rounded-full border border-white/30 shadow-inner"
                          style={{ backgroundColor: `#${char.colorScheme.vest.toString(16).padStart(6, '0')}` }}
                          title="Vest"
                        />
                        <div
                          className="w-3 h-3 rounded-full border border-white/30 shadow-inner"
                          style={{ backgroundColor: `#${char.colorScheme.soleGlow.toString(16).padStart(6, '0')}` }}
                          title="LED Glow"
                        />
                        <span className="text-[9px] text-slate-400 ml-auto truncate max-w-[85px]">
                          {char.features.vestType.replace('-', ' ')}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            /* ========================================================
               PORTRAIT SKATEBOARDS VIEW
               ======================================================== */
            <div className="flex flex-col w-full">
              {/* Large 3D Skateboard Stage */}
              <div className="relative w-full h-56 sm:h-64 bg-gradient-to-b from-[#0c1224] via-[#080d1a] to-black border-b border-slate-800 shrink-0">
                <SkateboardPreviewCanvas board={inspectingBoard} />

                {/* Top-left Badges */}
                <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 pointer-events-none">
                  <span className="text-[10px] font-bold text-cyan-300 bg-black/80 px-2 py-0.5 rounded border border-cyan-500/50 font-mono shadow">
                    Board #{inspectingBoard.id}
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase shadow ${
                      inspectingBoard.visuals.rarity === 'Mythic'
                        ? 'bg-rose-950/90 text-rose-300 border border-rose-500/60'
                        : inspectingBoard.visuals.rarity === 'Legendary'
                        ? 'bg-amber-950/90 text-amber-300 border border-amber-500/60'
                        : inspectingBoard.visuals.rarity === 'Epic'
                        ? 'bg-purple-950/90 text-purple-300 border border-purple-500/60'
                        : inspectingBoard.visuals.rarity === 'Rare'
                        ? 'bg-blue-950/90 text-blue-300 border border-blue-500/60'
                        : 'bg-slate-800 text-slate-300 border border-slate-700'
                    }`}
                  >
                    {inspectingBoard.visuals.rarity}
                  </span>
                </div>

                {/* Bottom-right Stock Badge */}
                <div className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded bg-black/80 border border-slate-700 text-[10px] font-mono text-slate-300">
                  Stock: {saveManager.getSkateboardStock(inspectingBoard.id)}/100
                </div>
              </div>

              {/* Board Status Bar & Action Button */}
              <div className="px-3 py-2 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
                <div>
                  <h3 className="text-sm sm:text-base font-black text-white font-display uppercase tracking-wide flex items-center gap-1">
                    <span>🛹</span>
                    <span>{inspectingBoard.name}</span>
                  </h3>
                  <div className="text-[11px] font-semibold text-cyan-400">
                    {inspectingBoard.theme} • <span className="text-slate-300 italic">{inspectingBoard.perkDescription}</span>
                  </div>
                </div>

                <div className="shrink-0">
                  {isBoardOwned ? (
                    isBoardEquipped ? (
                      <span className="px-3 py-1.5 bg-cyan-950 border border-cyan-500/60 text-cyan-300 text-xs font-black uppercase rounded-lg shadow flex items-center gap-1 font-display">
                        <Check className="w-3.5 h-3.5" /> EQUIPPED
                      </span>
                    ) : (
                      <button
                        id="shop-portrait-btn-equip-board"
                        onClick={() => handleEquipSkateboard(inspectingBoard.id)}
                        className="px-3 py-1.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 active:scale-95 text-slate-950 font-black text-xs uppercase tracking-wider rounded-lg transition shadow-lg flex items-center gap-1 cursor-pointer font-display"
                      >
                        EQUIP 🛹
                      </button>
                    )
                  ) : saveManager.getSkateboardStock(inspectingBoard.id) <= 0 ? (
                    <span className="px-3 py-1.5 bg-red-950/60 border border-red-500/40 text-red-400 text-xs font-bold rounded-lg">
                      SOLD OUT
                    </span>
                  ) : (
                    <button
                      id="shop-portrait-btn-buy-board"
                      onClick={() => handleBuySkateboard(inspectingBoard)}
                      className="px-3 py-1.5 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-500 hover:from-amber-400 hover:to-orange-400 active:scale-95 text-slate-950 font-black text-xs uppercase tracking-wider rounded-lg transition shadow-[0_0_15px_rgba(245,158,11,0.5)] flex items-center gap-1 cursor-pointer font-display"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>UNLOCK ₹{inspectingBoard.price}</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Bonus Stats Grid */}
              <div className="mx-3 mt-2 grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-[10px] bg-slate-950/80 p-2 rounded-lg border border-slate-800">
                <div className="flex items-center gap-1 text-slate-300">
                  <Zap className="w-3 h-3 text-amber-400 shrink-0" />
                  <span>Speed:</span>
                  <strong className="text-amber-300 ml-auto">+{inspectingBoard.bonusStats.speedBonus} km/h</strong>
                </div>
                <div className="flex items-center gap-1 text-slate-300">
                  <Sparkles className="w-3 h-3 text-cyan-400 shrink-0" />
                  <span>Ride:</span>
                  <strong className="text-cyan-300 ml-auto">+{inspectingBoard.bonusStats.durationBonus}s</strong>
                </div>
                <div className="flex items-center gap-1 text-slate-300">
                  <Shield className="w-3 h-3 text-blue-400 shrink-0" />
                  <span>Jump:</span>
                  <strong className="text-blue-300 ml-auto">x{inspectingBoard.bonusStats.jumpMultiplier.toFixed(2)}</strong>
                </div>
                <div className="flex items-center gap-1 text-slate-300">
                  <Magnet className="w-3 h-3 text-red-400 shrink-0" />
                  <span>Magnet:</span>
                  <strong className="text-red-300 ml-auto">{inspectingBoard.bonusStats.coinAttraction ? 'Auto-Pull' : 'Standard'}</strong>
                </div>
              </div>

              {errorMsg && (
                <div className="mx-3 mt-2 text-xs text-red-400 font-bold bg-red-950/90 border border-red-500/60 p-2 rounded-lg animate-shake">
                  {errorMsg}
                </div>
              )}

              {/* Boards Section Header */}
              <div className="px-3 pt-2.5 pb-1 flex items-center justify-between text-[11px] font-bold text-slate-400">
                <span>15 OFFICIAL 3D SKATEBOARDS ({unlockedBoardCount}/15 UNLOCKED)</span>
                <span className="text-[10px] text-cyan-400">Tap card to inspect 3D Model</span>
              </div>

              {/* 15 Skateboards Grid */}
              <div className="px-3 py-1.5 grid grid-cols-2 sm:grid-cols-3 gap-2">
                {SKATEBOARDS.map((board) => {
                  const owned = saveManager.isSkateboardUnlocked(board.id);
                  const equipped = board.id === currentEquippedBoardId;
                  const inspecting = board.id === inspectingBoardId;
                  const stock = saveManager.getSkateboardStock(board.id);

                  return (
                    <div
                      key={board.id}
                      id={`portrait-board-card-${board.id}`}
                      onClick={() => {
                        soundManager.playButtonClick();
                        setInspectingBoardId(board.id);
                      }}
                      className={`relative p-2.5 rounded-xl border transition cursor-pointer flex flex-col justify-between ${
                        inspecting
                          ? 'bg-slate-800/95 border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.35)] ring-1 ring-cyan-300'
                          : owned
                          ? 'bg-slate-900/70 border-slate-700/70 hover:border-slate-500 hover:bg-slate-800/80'
                          : 'bg-black/60 border-slate-800/80 opacity-85 hover:opacity-100'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[10px] font-black text-slate-400 font-mono">
                          #{board.id}
                        </span>
                        {equipped ? (
                          <span className="px-1.5 py-0.5 bg-cyan-400 text-slate-950 text-[9px] font-black rounded uppercase">
                            EQUIPPED
                          </span>
                        ) : owned ? (
                          <span className="text-emerald-400 text-[10px] font-bold">UNLOCKED</span>
                        ) : stock <= 0 ? (
                          <span className="text-red-400 text-[9px] font-bold">SOLD OUT</span>
                        ) : (
                          <span className="flex items-center gap-0.5 text-[10px] font-black text-amber-400 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-500/40 font-display">
                            <Lock className="w-2.5 h-2.5" />
                            ₹{board.price}
                          </span>
                        )}
                      </div>

                      <div className="my-0.5">
                        <div className="text-xs font-bold text-white truncate font-display">
                          {board.name}
                        </div>
                        <div className="text-[10px] text-cyan-300 truncate">{board.theme}</div>
                      </div>

                      <div className="flex items-center gap-1.5 mt-1 pt-1 border-t border-slate-800/80">
                        <div
                          className="w-3 h-3 rounded-full border border-white/30 shadow-inner"
                          style={{ backgroundColor: `#${board.visuals.deckBottom.toString(16).padStart(6, '0')}` }}
                          title="Deck"
                        />
                        <div
                          className="w-3 h-3 rounded-full border border-white/30 shadow-inner"
                          style={{ backgroundColor: `#${board.visuals.deckEdge.toString(16).padStart(6, '0')}` }}
                          title="Rails"
                        />
                        <div
                          className="w-3 h-3 rounded-full border border-white/30 shadow-inner"
                          style={{ backgroundColor: `#${(board.visuals.wheelsGlow || 0x38bdf8).toString(16).padStart(6, '0')}` }}
                          title="Wheels"
                        />
                        <span className="text-[9px] text-slate-400 ml-auto truncate max-w-[80px]">
                          {board.visuals.rarity}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* 4. DOCKED BOTTOM NAVIGATION BAR (PORTRAIT) */}
        <div className="h-14 sm:h-16 bg-slate-950 border-t border-slate-800/90 px-3 flex items-center justify-around shrink-0 shadow-[0_-5px_20px_rgba(0,0,0,0.6)]">
          <button
            id="shop-nav-home"
            onClick={handleHomeClick}
            className="flex flex-col items-center justify-center gap-0.5 py-1 px-3 text-slate-400 hover:text-amber-300 transition active:scale-95 cursor-pointer"
          >
            <Home className="w-5 h-5" />
            <span className="text-[10px] font-bold font-display">Home</span>
          </button>

          <button
            id="shop-nav-balance"
            onClick={() => {
              soundManager.playButtonClick();
              if (onOpenDailyReward) onOpenDailyReward();
            }}
            className="flex flex-col items-center justify-center gap-0.5 py-1 px-3 text-slate-400 hover:text-amber-300 transition active:scale-95 cursor-pointer"
          >
            <Coins className="w-5 h-5 text-amber-400" />
            <span className="text-[10px] font-bold font-display text-amber-400">Balance</span>
          </button>

          <button
            id="shop-nav-runners"
            onClick={() => {
              soundManager.playButtonClick();
              setActiveTab('characters');
            }}
            className={`flex flex-col items-center justify-center gap-0.5 py-1 px-3 transition active:scale-95 cursor-pointer ${
              activeTab === 'characters'
                ? 'text-amber-400 scale-105 drop-shadow-[0_0_8px_rgba(245,158,11,0.6)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <User className="w-5 h-5" />
            <span className="text-[10px] font-black font-display">Runners</span>
          </button>

          <button
            id="shop-nav-boards"
            onClick={() => {
              soundManager.playButtonClick();
              setActiveTab('skateboards');
            }}
            className={`flex flex-col items-center justify-center gap-0.5 py-1 px-3 transition active:scale-95 cursor-pointer ${
              activeTab === 'skateboards'
                ? 'text-cyan-400 scale-105 drop-shadow-[0_0_8px_rgba(6,182,212,0.6)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Disc className="w-5 h-5" />
            <span className="text-[10px] font-black font-display">Boards</span>
          </button>

          <button
            id="shop-nav-more"
            onClick={() => {
              soundManager.playButtonClick();
              if (onOpenSettings) onOpenSettings();
              else onClose();
            }}
            className="flex flex-col items-center justify-center gap-0.5 py-1 px-3 text-slate-400 hover:text-white transition active:scale-95 cursor-pointer"
          >
            <MoreVertical className="w-5 h-5" />
            <span className="text-[10px] font-bold font-display">More</span>
          </button>
        </div>
      </div>
    );
  }

  /* =========================================================================
     LANDSCAPE MODE LAYOUT (Matches reference design specifications)
     "Landscape = Hide Top UI (No Home button, No Balance, No Top Icons)"
     ========================================================================= */
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-2 sm:p-3 bg-black/85 backdrop-blur-md select-none">
      <div className="relative w-full max-w-6xl h-[96vh] max-h-[720px] bg-gradient-to-b from-slate-900 via-slate-950 to-black border border-amber-500/40 rounded-2xl shadow-[0_0_50px_rgba(245,158,11,0.25)] flex flex-col overflow-hidden">
        {/* Landscape Top Header: No Home button, No top icons (Settings, Leaderboard, Mail, Avatar hidden) */}
        <div className="flex items-center justify-between px-4 py-2 border-b border-slate-800 bg-slate-900/80 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-amber-600 to-yellow-400 flex items-center justify-center text-slate-950 font-black shadow-md text-sm">
              👑
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black tracking-wider text-white uppercase font-display leading-tight">
                {activeTab === 'characters' ? 'SPR 3D RUNNERS ROSTER' : 'SPR 3D SKATEBOARD GARAGE'}
              </h2>
              <p className="text-[10px] text-slate-400">
                {activeTab === 'characters'
                  ? `12 Stylized 3D Characters • Unlocked: ${unlockedCharCount}/12`
                  : `15 Custom 3D Boards • Unlocked: ${unlockedBoardCount}/15`}
              </p>
            </div>
          </div>

          {/* Switcher Tabs */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 shadow-inner">
            <button
              id="shop-tab-characters-landscape"
              onClick={() => {
                soundManager.playButtonClick();
                setActiveTab('characters');
                setErrorMsg(null);
              }}
              className={`px-3 py-1 text-xs font-black rounded-lg transition uppercase font-display flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'characters'
                  ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>🏃</span>
              <span>RUNNERS</span>
            </button>
            <button
              id="shop-tab-skateboards-landscape"
              onClick={() => {
                soundManager.playButtonClick();
                setActiveTab('skateboards');
                setErrorMsg(null);
              }}
              className={`px-3 py-1 text-xs font-black rounded-lg transition uppercase font-display flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'skateboards'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>🛹</span>
              <span>BOARDS (15)</span>
            </button>
          </div>

          {/* Right: Coin Balance & Clean Close button */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-950 border border-amber-500/50 rounded-full shadow">
              <span className="text-xs">🪙</span>
              <span className="text-amber-400 font-bold text-xs sm:text-sm font-display">
                ₹{coins.toLocaleString()}
              </span>
            </div>

            <button
              id="shop-landscape-btn-close"
              onClick={() => {
                soundManager.playButtonClick();
                onClose();
              }}
              className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition cursor-pointer"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Body: Side-by-side 3D stage and cards roster */}
        {activeTab === 'characters' ? (
          /* Landscape Characters View */
          <div className="flex-1 grid grid-cols-12 gap-0 overflow-hidden">
            {/* Left 3D Stage */}
            <div className="col-span-5 relative bg-gradient-to-b from-slate-950 via-slate-900 to-black p-3 flex flex-col justify-between border-r border-slate-800 overflow-y-auto">
              <div className="w-full h-48 sm:h-56 relative shrink-0">
                <CharacterPreviewCanvas
                  characterId={inspectingChar.id}
                  showSkateboard={previewBoardOnChar}
                />

                <div className="absolute top-2 left-2 flex items-center gap-1.5 pointer-events-none">
                  <span className="text-[10px] text-amber-300 bg-black/70 px-2 py-0.5 rounded border border-amber-500/40 font-mono">
                    Player #{inspectingChar.id}
                  </span>
                  <span className="text-[10px] text-cyan-300 bg-black/70 px-2 py-0.5 rounded border border-cyan-500/40">
                    3D Model
                  </span>
                </div>

                <button
                  onClick={() => setPreviewBoardOnChar(!previewBoardOnChar)}
                  className={`absolute bottom-2 right-2 px-2.5 py-1 text-[11px] rounded font-bold border transition flex items-center gap-1.5 cursor-pointer ${
                    previewBoardOnChar
                      ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-[0_0_10px_rgba(245,158,11,0.3)]'
                      : 'bg-slate-900/80 border-slate-700 text-slate-400 hover:text-white'
                  }`}
                  title="Toggle Skateboard Stance"
                >
                  <Disc className="w-3.5 h-3.5" />
                  <span>{previewBoardOnChar ? 'Board: ON' : 'Board: OFF'}</span>
                </button>
              </div>

              {/* Character Info Card */}
              <div className="flex flex-col gap-1.5 mt-2 bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-base font-black text-white font-display uppercase tracking-wide">
                      {inspectingChar.name}
                    </h3>
                    <div className="text-xs font-semibold text-amber-400">{inspectingChar.title}</div>
                  </div>
                  {isCharOwned ? (
                    <span className="px-2 py-0.5 bg-emerald-950 border border-emerald-500/60 text-emerald-400 text-[10px] font-bold uppercase rounded">
                      UNLOCKED
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 px-2 py-0.5 bg-slate-950 border border-amber-500/60 text-amber-400 text-[11px] font-black uppercase rounded font-display">
                      <Lock className="w-3 h-3" /> ₹{inspectingChar.price.toLocaleString()}
                    </span>
                  )}
                </div>

                <p className="text-[11px] text-slate-300 line-clamp-2 italic">{inspectingChar.lore}</p>

                {errorMsg && (
                  <div className="text-xs text-red-400 font-bold bg-red-950/80 border border-red-500/60 p-1.5 rounded animate-shake">
                    {errorMsg}
                  </div>
                )}

                {isCharOwned ? (
                  isCharSelected ? (
                    <button
                      disabled
                      className="w-full py-2 bg-emerald-600/30 border border-emerald-500/50 text-emerald-300 font-bold text-xs rounded-lg flex items-center justify-center gap-2 cursor-default"
                    >
                      <Check className="w-3.5 h-3.5" /> ACTIVE RUNNER
                    </button>
                  ) : (
                    <button
                      onClick={() => handleSelectCharacter(inspectingChar.id)}
                      className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 active:scale-98 text-slate-950 font-black text-xs uppercase tracking-wider rounded-lg transition shadow-lg flex items-center justify-center gap-2 cursor-pointer font-display"
                    >
                      SELECT RUNNER
                    </button>
                  )
                ) : (
                  <button
                    onClick={() => handleBuyCharacter(inspectingChar)}
                    className="w-full py-2 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-500 hover:from-amber-400 hover:to-orange-400 active:scale-98 text-slate-950 font-black text-xs uppercase tracking-wider rounded-lg transition shadow-[0_0_20px_rgba(245,158,11,0.5)] flex items-center justify-center gap-2 cursor-pointer font-display"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>UNLOCK FOR ₹{inspectingChar.price.toLocaleString()}</span>
                  </button>
                )}
              </div>
            </div>

            {/* Right Roster Grid */}
            <div className="col-span-7 flex flex-col p-3 overflow-hidden bg-slate-950/70">
              <div className="text-xs font-bold text-slate-400 mb-2 flex items-center justify-between">
                <span>SELECT A 3D RUNNER ({unlockedCharCount}/12 UNLOCKED)</span>
                <span className="text-[10px] text-amber-400">Tap to inspect 3D Model</span>
              </div>

              <div className="flex-1 overflow-y-auto pr-1 grid grid-cols-2 lg:grid-cols-3 gap-2 pb-2">
                {CHARACTERS.map((char) => {
                  const owned = saveManager.isCharacterUnlocked(char.id);
                  const active = char.id === currentSelectedCharId;
                  const inspecting = char.id === inspectingCharId;

                  return (
                    <div
                      key={char.id}
                      onClick={() => {
                        soundManager.playButtonClick();
                        setInspectingCharId(char.id);
                      }}
                      className={`relative p-2 rounded-xl border transition cursor-pointer flex flex-col justify-between ${
                        inspecting
                          ? 'bg-slate-800/90 border-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.3)] ring-1 ring-amber-400'
                          : owned
                          ? 'bg-slate-900/60 border-slate-700/60 hover:border-slate-500 hover:bg-slate-850'
                          : 'bg-black/60 border-slate-800/80 opacity-80 hover:opacity-100 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[10px] font-black text-slate-400">
                          #{char.id}
                        </span>
                        {active ? (
                          <span className="px-1.5 py-0.5 bg-emerald-500 text-slate-950 text-[9px] font-black rounded uppercase">
                            ACTIVE
                          </span>
                        ) : owned ? (
                          <span className="text-emerald-400 text-[10px] font-bold">UNLOCKED</span>
                        ) : (
                          <span className="flex items-center gap-0.5 text-[10px] font-black text-amber-400 bg-amber-950/60 px-1 py-0.5 rounded border border-amber-500/40 font-display">
                            <Lock className="w-2.5 h-2.5" />
                            ₹{char.price.toLocaleString()}
                          </span>
                        )}
                      </div>

                      <div className="my-0.5">
                        <div className="text-xs font-bold text-white truncate font-display">
                          {char.name}
                        </div>
                        <div className="text-[10px] text-slate-400 truncate">{char.title}</div>
                      </div>

                      <div className="flex items-center gap-1.5 mt-1 pt-1 border-t border-slate-800/80">
                        <div
                          className="w-3 h-3 rounded-full border border-white/20 shadow-inner"
                          style={{ backgroundColor: `#${char.colorScheme.vest.toString(16).padStart(6, '0')}` }}
                          title="Vest Color"
                        />
                        <div
                          className="w-3 h-3 rounded-full border border-white/20 shadow-inner"
                          style={{ backgroundColor: `#${char.colorScheme.soleGlow.toString(16).padStart(6, '0')}` }}
                          title="LED Sole Glow"
                        />
                        <span className="text-[9px] text-slate-400 ml-auto truncate max-w-[85px]">
                          {char.features.vestType.replace('-', ' ')}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        ) : (
          /* Landscape Skateboards View */
          <div className="flex-1 grid grid-cols-12 gap-0 overflow-hidden">
            {/* Left 3D Stage */}
            <div className="col-span-5 relative bg-gradient-to-b from-slate-950 via-slate-900 to-black p-3 flex flex-col justify-between border-r border-slate-800 overflow-y-auto">
              <div className="w-full h-44 sm:h-52 relative shrink-0">
                <SkateboardPreviewCanvas board={inspectingBoard} />

                <div className="absolute top-2 left-2 flex items-center gap-1.5 pointer-events-none">
                  <span className="text-[10px] text-cyan-300 bg-black/80 px-2 py-0.5 rounded border border-cyan-500/40 font-mono">
                    Board #{inspectingBoard.id}
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                      inspectingBoard.visuals.rarity === 'Mythic'
                        ? 'bg-rose-950/90 text-rose-300 border border-rose-500/50'
                        : inspectingBoard.visuals.rarity === 'Legendary'
                        ? 'bg-amber-950/90 text-amber-300 border border-amber-500/50'
                        : inspectingBoard.visuals.rarity === 'Epic'
                        ? 'bg-purple-950/90 text-purple-300 border border-purple-500/50'
                        : inspectingBoard.visuals.rarity === 'Rare'
                        ? 'bg-blue-950/90 text-blue-300 border border-blue-500/50'
                        : 'bg-slate-800 text-slate-300 border border-slate-700'
                    }`}
                  >
                    {inspectingBoard.visuals.rarity}
                  </span>
                </div>
              </div>

              {/* Skateboard Info Card */}
              <div className="flex flex-col gap-1.5 mt-2 bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-base font-black text-white font-display uppercase tracking-wide flex items-center gap-1.5">
                      <span>🛹</span>
                      <span>{inspectingBoard.name}</span>
                    </h3>
                    <div className="text-xs font-semibold text-cyan-400">{inspectingBoard.theme}</div>
                  </div>
                  {isBoardOwned ? (
                    <div className="flex flex-col items-end">
                      <span className="px-2 py-0.5 bg-emerald-950 border border-emerald-500/60 text-emerald-400 text-[10px] font-bold uppercase rounded">
                        UNLOCKED
                      </span>
                      <span className="text-[10px] text-slate-400 mt-0.5 font-mono">
                        Stock: {saveManager.getSkateboardStock(inspectingBoard.id)}/100
                      </span>
                    </div>
                  ) : (
                    <div className="flex flex-col items-end">
                      <span className="flex items-center gap-1 px-2 py-0.5 bg-slate-950 border border-amber-500/60 text-amber-400 text-[11px] font-black uppercase rounded font-display">
                        <Lock className="w-3 h-3" /> ₹{inspectingBoard.price}
                      </span>
                      <span className="text-[10px] mt-0.5 font-mono text-slate-400">
                        Stock: {saveManager.getSkateboardStock(inspectingBoard.id)}/100
                      </span>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-1 text-[10px] bg-slate-950/70 p-1.5 rounded-lg border border-slate-800">
                  <div className="flex items-center gap-1 text-slate-300">
                    <Zap className="w-3 h-3 text-amber-400" />
                    <span>+{inspectingBoard.bonusStats.speedBonus} km/h</span>
                  </div>
                  <div className="flex items-center gap-1 text-slate-300">
                    <Sparkles className="w-3 h-3 text-cyan-400" />
                    <span>+{inspectingBoard.bonusStats.durationBonus}s ride</span>
                  </div>
                </div>

                {errorMsg && (
                  <div className="text-xs text-red-400 font-bold bg-red-950/80 border border-red-500/60 p-1.5 rounded animate-shake">
                    {errorMsg}
                  </div>
                )}

                {isBoardOwned ? (
                  isBoardEquipped ? (
                    <button
                      disabled
                      className="w-full py-2 bg-cyan-600/30 border border-cyan-500/50 text-cyan-300 font-bold text-xs rounded-lg flex items-center justify-center gap-2 cursor-default"
                    >
                      <Check className="w-3.5 h-3.5" /> EQUIPPED BOARD
                    </button>
                  ) : (
                    <button
                      onClick={() => handleEquipSkateboard(inspectingBoard.id)}
                      className="w-full py-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 active:scale-98 text-slate-950 font-black text-xs uppercase tracking-wider rounded-lg transition shadow-lg flex items-center justify-center gap-2 cursor-pointer font-display"
                    >
                      <span>EQUIP SKATEBOARD 🛹</span>
                    </button>
                  )
                ) : saveManager.getSkateboardStock(inspectingBoard.id) <= 0 ? (
                  <button
                    disabled
                    className="w-full py-2 bg-red-950/50 border border-red-500/40 text-red-400 font-bold text-xs rounded-lg flex items-center justify-center gap-2 cursor-not-allowed"
                  >
                    <span>OUT OF STOCK (0/100)</span>
                  </button>
                ) : (
                  <button
                    onClick={() => handleBuySkateboard(inspectingBoard)}
                    className="w-full py-2 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-500 hover:from-amber-400 hover:to-orange-400 active:scale-98 text-slate-950 font-black text-xs uppercase tracking-wider rounded-lg transition shadow-[0_0_20px_rgba(245,158,11,0.5)] flex items-center justify-center gap-2 cursor-pointer font-display"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>UNLOCK FOR ₹{inspectingBoard.price}</span>
                  </button>
                )}
              </div>
            </div>

            {/* Right Skateboards Grid */}
            <div className="col-span-7 flex flex-col p-3 overflow-hidden bg-slate-950/70">
              <div className="text-xs font-bold text-slate-400 mb-2 flex items-center justify-between">
                <span>15 OFFICIAL 3D SKATEBOARDS ({unlockedBoardCount}/15 UNLOCKED)</span>
                <span className="text-[10px] text-cyan-400">Tap to inspect 3D Model</span>
              </div>

              <div className="flex-1 overflow-y-auto pr-1 grid grid-cols-2 lg:grid-cols-3 gap-2 pb-2">
                {SKATEBOARDS.map((board) => {
                  const owned = saveManager.isSkateboardUnlocked(board.id);
                  const equipped = board.id === currentEquippedBoardId;
                  const inspecting = board.id === inspectingBoardId;
                  const stock = saveManager.getSkateboardStock(board.id);

                  return (
                    <div
                      key={board.id}
                      onClick={() => {
                        soundManager.playButtonClick();
                        setInspectingBoardId(board.id);
                      }}
                      className={`relative p-2 rounded-xl border transition cursor-pointer flex flex-col justify-between ${
                        inspecting
                          ? 'bg-slate-800/90 border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.3)] ring-1 ring-cyan-300'
                          : owned
                          ? 'bg-slate-900/60 border-slate-700/60 hover:border-slate-500 hover:bg-slate-850'
                          : 'bg-black/60 border-slate-800/80 opacity-80 hover:opacity-100 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[10px] font-black text-slate-400">
                          #{board.id}
                        </span>
                        {equipped ? (
                          <span className="px-1.5 py-0.5 bg-cyan-400 text-slate-950 text-[9px] font-black rounded uppercase">
                            EQUIPPED
                          </span>
                        ) : owned ? (
                          <span className="text-emerald-400 text-[10px] font-bold">UNLOCKED</span>
                        ) : stock <= 0 ? (
                          <span className="text-red-400 text-[9px] font-bold">SOLD OUT</span>
                        ) : (
                          <span className="flex items-center gap-0.5 text-[10px] font-black text-amber-400 bg-amber-950/60 px-1 py-0.5 rounded border border-amber-500/40 font-display">
                            <Lock className="w-2.5 h-2.5" />
                            ₹{board.price}
                          </span>
                        )}
                      </div>

                      <div className="my-0.5">
                        <div className="text-xs font-bold text-white truncate font-display">
                          {board.name}
                        </div>
                        <div className="text-[10px] text-cyan-300 truncate">{board.theme}</div>
                      </div>

                      <div className="flex items-center gap-1.5 mt-1 pt-1 border-t border-slate-800/80">
                        <div
                          className="w-3 h-3 rounded-full border border-white/20 shadow-inner"
                          style={{ backgroundColor: `#${board.visuals.deckBottom.toString(16).padStart(6, '0')}` }}
                          title="Deck Bottom"
                        />
                        <div
                          className="w-3 h-3 rounded-full border border-white/20 shadow-inner"
                          style={{ backgroundColor: `#${board.visuals.deckEdge.toString(16).padStart(6, '0')}` }}
                          title="Rails"
                        />
                        <div
                          className="w-3 h-3 rounded-full border border-white/20 shadow-inner"
                          style={{ backgroundColor: `#${(board.visuals.wheelsGlow || 0x38bdf8).toString(16).padStart(6, '0')}` }}
                          title="Wheels"
                        />
                        <span className="text-[9px] text-slate-400 ml-auto truncate max-w-[80px]">
                          {board.visuals.rarity}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
