import React, { useState } from 'react';
import { X, Zap, Magnet, Rocket, Footprints, ShieldAlert, Check, Lock, Gift, Sparkles } from 'lucide-react';
import { HoverboardItem, BackpackItem } from '../types/game';
import { STORE_UPGRADES } from '../game/storeData';
import { HOVERBOARDS, BACKPACKS } from '../game/itemsData';

interface ShopModalProps {
  coins: number;
  gems: number;
  upgrades: Record<string, number>;
  selectedBoardId: string;
  selectedBackpackId: string;
  unlockedBoards: string[];
  unlockedBackpacks: string[];
  onUpgradePowerup: (upgradeId: string, cost: number) => boolean;
  onSelectBoard: (board: HoverboardItem) => void;
  onUnlockBoard: (board: HoverboardItem) => boolean;
  onSelectBackpack: (backpack: BackpackItem) => void;
  onUnlockBackpack: (backpack: BackpackItem) => boolean;
  onSpinMysteryBox: () => { coins: number; gems: number };
  onClose: () => void;
}

export const ShopModal: React.FC<ShopModalProps> = ({
  coins,
  gems,
  upgrades,
  selectedBoardId,
  selectedBackpackId,
  unlockedBoards,
  unlockedBackpacks,
  onUpgradePowerup,
  onSelectBoard,
  onUnlockBoard,
  onSelectBackpack,
  onUnlockBackpack,
  onSpinMysteryBox,
  onClose
}) => {
  const [tab, setTab] = useState<'upgrades' | 'boards' | 'backpacks' | 'lucky'>('upgrades');
  const [mysteryReward, setMysteryReward] = useState<{ coins: number; gems: number } | null>(null);
  const [isSpinning, setIsSpinning] = useState(false);

  const handleOpenMysteryBox = () => {
    if (coins < 200 || isSpinning) return;
    setIsSpinning(true);
    setTimeout(() => {
      const reward = onSpinMysteryBox();
      setMysteryReward(reward);
      setIsSpinning(false);
    }, 1200);
  };

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center p-3 md:p-6 bg-slate-950/85">
      <div className="bg-slate-900 border-2 border-slate-700 rounded-3xl w-full max-w-3xl h-[88vh] max-h-[750px] shadow-2xl flex flex-col overflow-hidden">
        {/* Top Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-xl">
              🛍️
            </div>
            <div>
              <h2 className="text-lg md:text-xl font-black text-white">متجر الترقيات والمعدات</h2>
              <div className="text-xs text-slate-400">طور قدراتك واشترِ أسرع الزلاجات وأقوى حقائب الظهر</div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-slate-800 px-3 py-1 rounded-full text-xs font-bold border border-amber-500/30 text-amber-300">
              <span>🪙</span>
              <span className="tabular-nums">{coins.toLocaleString('ar-EG')}</span>
            </div>
            <div className="flex items-center gap-1 bg-slate-800 px-3 py-1 rounded-full text-xs font-bold border border-cyan-500/30 text-cyan-300">
              <span>💎</span>
              <span className="tabular-nums">{gems.toLocaleString('ar-EG')}</span>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-all ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Buttons */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 p-2 gap-2 text-xs md:text-sm font-bold">
          <button
            onClick={() => setTab('upgrades')}
            className={`flex-1 py-2 rounded-xl transition-all ${
              tab === 'upgrades' ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-400 hover:bg-slate-800'
            }`}
          >
            ⚡ ترقيات المهارات
          </button>
          <button
            onClick={() => setTab('boards')}
            className={`flex-1 py-2 rounded-xl transition-all ${
              tab === 'boards' ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-400 hover:bg-slate-800'
            }`}
          >
            🏎️ المركبات والزلاجات
          </button>
          <button
            onClick={() => setTab('backpacks')}
            className={`flex-1 py-2 rounded-xl transition-all ${
              tab === 'backpacks' ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-400 hover:bg-slate-800'
            }`}
          >
            🎒 الحقائب والنفاثات
          </button>
          <button
            onClick={() => setTab('lucky')}
            className={`flex-1 py-2 rounded-xl transition-all ${
              tab === 'lucky' ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-400 hover:bg-slate-800'
            }`}
          >
            🎁 صندوق الحظ
          </button>
        </div>

        {/* Tab Contents */}
        <div className="flex-1 overflow-y-auto p-4">
          {/* 1. Powerup Upgrades */}
          {tab === 'upgrades' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {STORE_UPGRADES.map((upg) => {
                const currentLvl = upgrades[upg.id] || 1;
                const isMax = currentLvl >= upg.maxLevel;
                const cost = upg.baseCost * currentLvl;

                const renderIcon = () => {
                  if (upg.iconName === 'Magnet') return <Magnet className="w-6 h-6 text-red-400" />;
                  if (upg.iconName === 'Zap') return <Zap className="w-6 h-6 text-blue-400" />;
                  if (upg.iconName === 'Footprints') return <Footprints className="w-6 h-6 text-emerald-400" />;
                  if (upg.iconName === 'Rocket') return <Rocket className="w-6 h-6 text-amber-400" />;
                  return <ShieldAlert className="w-6 h-6 text-purple-400" />;
                };

                return (
                  <div key={upg.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2.5">
                          <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center">
                            {renderIcon()}
                          </div>
                          <div>
                            <h3 className="font-extrabold text-white text-sm">{upg.name}</h3>
                            <div className="text-[11px] text-amber-400 font-bold">
                              المستوى {currentLvl} / {upg.maxLevel}
                            </div>
                          </div>
                        </div>
                      </div>

                      <p className="text-xs text-slate-400 mb-3">{upg.description}</p>

                      {/* Level Progress Pip Bars */}
                      <div className="flex items-center gap-1.5 mb-3">
                        {Array.from({ length: upg.maxLevel }, (_, i) => (
                          <div
                            key={i}
                            className={`flex-1 h-2 rounded-full ${
                              i < currentLvl ? 'bg-amber-400' : 'bg-slate-800'
                            }`}
                          />
                        ))}
                      </div>
                    </div>

                    <button
                      disabled={isMax || coins < cost}
                      onClick={() => onUpgradePowerup(upg.id, cost)}
                      className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
                        isMax
                          ? 'bg-slate-800 text-slate-500 cursor-default'
                          : coins >= cost
                          ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 active:scale-95 cursor-pointer shadow-md'
                          : 'bg-slate-800 text-slate-400 opacity-60 cursor-not-allowed'
                      }`}
                    >
                      {isMax ? (
                        <span>أقصى مستوى مكتمل! ⭐</span>
                      ) : (
                        <span>ترقية مقابل {cost.toLocaleString('ar-EG')} 🪙</span>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {/* 2. Hoverboards */}
          {tab === 'boards' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {HOVERBOARDS.map((board) => {
                const isUnlocked = unlockedBoards.includes(board.id) || board.cost === 0;
                const isSelected = selectedBoardId === board.id;

                return (
                  <div
                    key={board.id}
                    className={`bg-slate-900 border rounded-2xl p-4 flex flex-col justify-between transition-all ${
                      isSelected ? 'border-amber-400 shadow-md' : 'border-slate-800'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                          <div
                            className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl shadow-inner border"
                            style={{ backgroundColor: board.primaryColor, borderColor: board.trailColor }}
                          >
                            {board.vehicleType === 'bike' ? '🏍️' : board.vehicleType === 'kart' ? '🏎️' : board.vehicleType === 'scooter' ? '🛴' : board.vehicleType === 'rocket' ? '🚀' : board.vehicleType === 'carpet' ? '🧞' : '🛹'}
                          </div>
                          <div>
                            <h3 className="font-extrabold text-white text-sm">{board.name}</h3>
                            <div className="text-[11px] text-cyan-400 font-bold">
                              سرعة +{Math.round((board.speedMultiplier - 1) * 100)}% · درع حماية
                            </div>
                          </div>
                        </div>
                      </div>
                      <p className="text-xs text-slate-400 mb-3">{board.description}</p>
                    </div>

                    {isUnlocked ? (
                      <button
                        disabled={isSelected}
                        onClick={() => onSelectBoard(board)}
                        className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
                          isSelected
                            ? 'bg-emerald-600/60 text-white cursor-default'
                            : 'bg-amber-500 hover:bg-amber-400 text-slate-950 active:scale-95 cursor-pointer'
                        }`}
                      >
                        {isSelected ? <Check className="w-4 h-4" /> : null}
                        <span>{isSelected ? 'مجهزة حالياً' : 'تجهيز الزلاجة'}</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => onUnlockBoard(board)}
                        className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all shadow-md cursor-pointer"
                      >
                        <Lock className="w-4 h-4" />
                        <span>شراء مقابل {board.cost.toLocaleString('ar-EG')} 🪙</span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* 3. Backpacks & Jetpacks */}
          {tab === 'backpacks' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {BACKPACKS.map((bp) => {
                const isUnlocked = unlockedBackpacks.includes(bp.id) || bp.cost === 0;
                const isSelected = selectedBackpackId === bp.id;

                return (
                  <div
                    key={bp.id}
                    className={`bg-slate-900 border rounded-2xl p-4 flex flex-col justify-between transition-all ${
                      isSelected ? 'border-amber-400 shadow-md' : 'border-slate-800'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <div
                          className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl shadow-inner border"
                          style={{ backgroundColor: bp.primaryColor }}
                        >
                          {bp.isJetpack ? '🚀' : '🎒'}
                        </div>
                        <div>
                          <h3 className="font-extrabold text-white text-sm">{bp.name}</h3>
                          <div className="text-[11px] text-amber-400 font-bold">{bp.bonus}</div>
                        </div>
                      </div>
                    </div>

                    {isUnlocked ? (
                      <button
                        disabled={isSelected}
                        onClick={() => onSelectBackpack(bp)}
                        className={`w-full py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
                          isSelected
                            ? 'bg-emerald-600/60 text-white cursor-default'
                            : 'bg-amber-500 hover:bg-amber-400 text-slate-950 active:scale-95 cursor-pointer'
                        }`}
                      >
                        {isSelected ? <Check className="w-4 h-4" /> : null}
                        <span>{isSelected ? 'مجهزة حالياً' : 'تجهيز الحقيبة'}</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => onUnlockBackpack(bp)}
                        className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all shadow-md cursor-pointer"
                      >
                        <Lock className="w-4 h-4" />
                        <span>شراء مقابل {bp.cost.toLocaleString('ar-EG')} 🪙</span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* 4. Lucky Mystery Box */}
          {tab === 'lucky' && (
            <div className="flex flex-col items-center justify-center text-center p-6 bg-slate-900/60 border border-slate-800 rounded-3xl max-w-md mx-auto">
              <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-amber-400 to-orange-600 flex items-center justify-center text-5xl shadow-2xl mb-4 animate-bounce">
                🎁
              </div>

              <h3 className="text-xl font-black text-white mb-1">صندوق الحظ والجوائز اليومية</h3>
              <p className="text-xs text-slate-400 max-w-xs mb-4">
                افتح صندوق الحظ واربح كميات ضخمة من العملات الذهبية والجواهر النادرة!
              </p>

              {mysteryReward && (
                <div className="bg-amber-500/15 border border-amber-400 rounded-2xl p-3 mb-4 w-full">
                  <div className="text-xs text-amber-300 font-bold">🎉 مبروك! حصلت على:</div>
                  <div className="text-lg font-black text-white mt-1">
                    +{mysteryReward.coins} 🪙 و +{mysteryReward.gems} 💎
                  </div>
                </div>
              )}

              <button
                disabled={coins < 200 || isSpinning}
                onClick={handleOpenMysteryBox}
                className="py-3 px-6 rounded-2xl bg-gradient-to-r from-amber-500 to-red-500 hover:from-amber-400 hover:to-red-400 text-slate-950 font-black text-sm active:scale-95 transition-all shadow-xl flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Sparkles className="w-4 h-4" />
                <span>{isSpinning ? 'جاري الفتح...' : 'افتح الصندوق مقابل 200 🪙'}</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
