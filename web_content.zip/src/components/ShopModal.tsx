import React, { useState } from 'react';
import { COLOR_THEMES, NODE_SKINS } from '../utils/colorThemes';
import { SaveData } from '../types/game';
import { X, Coins, Check, Lock, Sparkles, Palette, CircleDot, Zap } from 'lucide-react';
import { soundEngine } from '../utils/audio';

interface ShopModalProps {
  saveData: SaveData;
  onBuyTheme: (themeId: string, price: number) => void;
  onEquipTheme: (themeId: string) => void;
  onBuySkin: (skinId: string, price: number) => void;
  onEquipSkin: (skinId: string) => void;
  onBuyBooster: (type: 'hint' | 'extraMoves' | 'colorClear' | 'undo', count: number, price: number) => void;
  onClose: () => void;
}

export const ShopModal: React.FC<ShopModalProps> = ({
  saveData,
  onBuyTheme,
  onEquipTheme,
  onBuySkin,
  onEquipSkin,
  onBuyBooster,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<'themes' | 'skins' | 'boosters'>('themes');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md select-none animate-in fade-in duration-150">
      <div className="relative w-full max-w-2xl max-h-[90vh] bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                CHROMA SHOP
              </h2>
              <p className="text-xs text-slate-400">
                Unlock radiant neon palettes, skins, and power-ups
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Player Coins Display */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 font-mono font-bold text-amber-400 text-sm">
              <Coins className="w-4 h-4 text-amber-400" />
              <span className="tabular-nums">{saveData.stats.totalCoins}</span>
            </div>

            <button
              onClick={() => {
                soundEngine.playNodeSelect(0);
                onClose();
              }}
              className="w-9 h-9 flex items-center justify-center rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 py-3 border-b border-slate-800/60">
          <button
            onClick={() => {
              soundEngine.playNodeSelect(0);
              setActiveTab('themes');
            }}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'themes'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Color Themes</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(1);
              setActiveTab('skins');
            }}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'skins'
                ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <CircleDot className="w-3.5 h-3.5" />
            <span>Node Skins</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playNodeSelect(2);
              setActiveTab('boosters');
            }}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'boosters'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Boosters</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto py-4 pr-1">
          {/* THEMES TAB */}
          {activeTab === 'themes' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {Object.values(COLOR_THEMES).map((theme) => {
                const isUnlocked = saveData.unlockedThemes.includes(theme.id);
                const isEquipped = saveData.activeThemeId === theme.id;
                const canAfford = saveData.stats.totalCoins >= theme.price;

                return (
                  <div
                    key={theme.id}
                    className={`p-4 rounded-2xl border transition-all flex flex-col justify-between ${
                      isEquipped
                        ? 'bg-slate-950/90 border-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.2)]'
                        : 'bg-slate-950/50 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="font-bold text-white text-sm">{theme.name}</span>
                        {isEquipped ? (
                          <span className="flex items-center gap-1 text-[10px] font-black text-cyan-400 uppercase tracking-wider">
                            <Check className="w-3 h-3" /> EQUIPPED
                          </span>
                        ) : isUnlocked ? (
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                            UNLOCKED
                          </span>
                        ) : (
                          <div className="flex items-center gap-1 font-mono text-xs font-bold text-amber-400">
                            <Coins className="w-3.5 h-3.5 text-amber-400" />
                            <span>{theme.price}</span>
                          </div>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 mb-3">{theme.description}</p>

                      {/* Palette Color Preview Strip */}
                      <div className="flex items-center gap-1.5 mb-4 p-2 bg-slate-900 rounded-xl border border-slate-800/80">
                        {Object.values(theme.colors).map((c, i) => (
                          <div
                            key={i}
                            className="flex-1 h-3 rounded-full"
                            style={{
                              backgroundColor: c.hex,
                              boxShadow: `0 0 6px ${c.hex}`
                            }}
                          />
                        ))}
                      </div>
                    </div>

                    {/* Action Button */}
                    {isEquipped ? (
                      <button
                        disabled
                        className="w-full py-2 rounded-xl bg-cyan-500/20 text-cyan-300 font-bold text-xs border border-cyan-500/30 cursor-default"
                      >
                        ACTIVE
                      </button>
                    ) : isUnlocked ? (
                      <button
                        onClick={() => {
                          soundEngine.playNodeSelect(2);
                          onEquipTheme(theme.id);
                        }}
                        className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-colors"
                      >
                        EQUIP THEME
                      </button>
                    ) : (
                      <button
                        onClick={() => {
                          if (canAfford) {
                            soundEngine.playBooster();
                            onBuyTheme(theme.id, theme.price);
                          }
                        }}
                        disabled={!canAfford}
                        className={`w-full py-2 rounded-xl flex items-center justify-center gap-1.5 font-bold text-xs transition-all ${
                          canAfford
                            ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-[0_0_12px_rgba(245,158,11,0.3)]'
                            : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                        }`}
                      >
                        <Lock className="w-3.5 h-3.5" />
                        <span>UNLOCK FOR {theme.price} COINS</span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* SKINS TAB */}
          {activeTab === 'skins' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {Object.values(NODE_SKINS).map((skin) => {
                const isUnlocked = saveData.unlockedSkins.includes(skin.id);
                const isEquipped = saveData.activeSkinId === skin.id;
                const canAfford = saveData.stats.totalCoins >= skin.price;

                return (
                  <div
                    key={skin.id}
                    className={`p-4 rounded-2xl border transition-all flex flex-col justify-between ${
                      isEquipped
                        ? 'bg-slate-950/90 border-purple-500/50 shadow-[0_0_15px_rgba(168,85,247,0.2)]'
                        : 'bg-slate-950/50 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="font-bold text-white text-sm">{skin.name}</span>
                        {isEquipped ? (
                          <span className="flex items-center gap-1 text-[10px] font-black text-purple-400 uppercase tracking-wider">
                            <Check className="w-3 h-3" /> EQUIPPED
                          </span>
                        ) : isUnlocked ? (
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                            UNLOCKED
                          </span>
                        ) : (
                          <div className="flex items-center gap-1 font-mono text-xs font-bold text-amber-400">
                            <Coins className="w-3.5 h-3.5 text-amber-400" />
                            <span>{skin.price}</span>
                          </div>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 mb-4">{skin.description}</p>
                    </div>

                    {/* Action Button */}
                    {isEquipped ? (
                      <button
                        disabled
                        className="w-full py-2 rounded-xl bg-purple-500/20 text-purple-300 font-bold text-xs border border-purple-500/30 cursor-default"
                      >
                        ACTIVE
                      </button>
                    ) : isUnlocked ? (
                      <button
                        onClick={() => {
                          soundEngine.playNodeSelect(2);
                          onEquipSkin(skin.id);
                        }}
                        className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-colors"
                      >
                        EQUIP SKIN
                      </button>
                    ) : (
                      <button
                        onClick={() => {
                          if (canAfford) {
                            soundEngine.playBooster();
                            onBuySkin(skin.id, skin.price);
                          }
                        }}
                        disabled={!canAfford}
                        className={`w-full py-2 rounded-xl flex items-center justify-center gap-1.5 font-bold text-xs transition-all ${
                          canAfford
                            ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-[0_0_12px_rgba(245,158,11,0.3)]'
                            : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                        }`}
                      >
                        <Lock className="w-3.5 h-3.5" />
                        <span>UNLOCK FOR {skin.price} COINS</span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* BOOSTERS REFILL TAB */}
          {activeTab === 'boosters' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {[
                {
                  type: 'hint' as const,
                  title: '3x Hint Pack',
                  desc: 'Highlights the shortest connecting path for an unsolved color.',
                  count: 3,
                  price: 100,
                  current: saveData.boosters.hint
                },
                {
                  type: 'extraMoves' as const,
                  title: '2x Extra Moves Pack (+5 Moves each)',
                  desc: 'Gives +5 additional moves when solving tight puzzles.',
                  count: 2,
                  price: 120,
                  current: saveData.boosters.extraMoves
                },
                {
                  type: 'colorClear' as const,
                  title: '1x Color Clear Solvers',
                  desc: 'Instantly connects and solves 1 color pair automatically.',
                  count: 1,
                  price: 150,
                  current: saveData.boosters.colorClear
                },
                {
                  type: 'undo' as const,
                  title: '5x Undo Charges',
                  desc: 'Reverses the last completed path without move penalties.',
                  count: 5,
                  price: 80,
                  current: saveData.boosters.undo
                }
              ].map((b, i) => {
                const canAfford = saveData.stats.totalCoins >= b.price;
                return (
                  <div
                    key={i}
                    className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-white text-sm">{b.title}</span>
                        <span className="text-[11px] font-mono font-bold text-slate-400">
                          Owned: {b.current}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mb-4">{b.desc}</p>
                    </div>

                    <button
                      onClick={() => {
                        if (canAfford) {
                          soundEngine.playBooster();
                          onBuyBooster(b.type, b.count, b.price);
                        }
                      }}
                      disabled={!canAfford}
                      className={`w-full py-2.5 rounded-xl flex items-center justify-center gap-1.5 font-bold text-xs transition-all ${
                        canAfford
                          ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-[0_0_12px_rgba(245,158,11,0.3)]'
                          : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      <Coins className="w-3.5 h-3.5" />
                      <span>BUY FOR {b.price} COINS</span>
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
