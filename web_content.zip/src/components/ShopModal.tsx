import React, { useState } from 'react';
import {
  Building2,
  Car,
  Home,
  Landmark,
  Palette,
  Shirt,
  ShoppingBag,
  Smartphone,
  Sparkles,
  Utensils,
  Wrench,
  X,
} from 'lucide-react';
import {
  CharacterCustomization,
  ClothingStyle,
  PhoneModelId,
  PlaceDef,
  SaveData,
  VehicleTuning,
  VehicleType,
} from '../types/game';
import { PHONE_MODELS, VEHICLE_SPECS } from '../data/karachiWorldData';
import { BankApp } from './BankApp';

interface ShopModalProps {
  place: PlaceDef;
  save: SaveData;
  onClose: () => void;
  onBuyOrSummonVehicle: (type: VehicleType) => void;
  onUpgradeVehicle: (
    type: VehicleType,
    patch: Partial<VehicleTuning>,
    cost: number,
    label: string
  ) => void;
  onBuyPhone: (modelId: PhoneModelId) => void;
  onSetPhoneColor: (color: string) => void;
  onBuyProperty: (placeId: string) => void;
  onEatMeal: (cost: number, label: string) => void;
  onRestAtHome: (placeName: string) => void;
  onUpdateCustomization: (custom: CharacterCustomization) => void;
  onBankDeposit: (amount: number) => void;
  onBankWithdraw: (amount: number) => void;
  onBankTakeLoan: (amount: number) => void;
  onBankRepayLoan: () => void;
}

const DEALERSHIP_VEHICLES: VehicleType[] = [
  'mehran',
  'alto',
  'corolla',
  'civic',
  'land_cruiser',
  'bus',
  'truck',
  'boat',
];

const BIKE_SHOP_VEHICLES: VehicleType[] = ['motorcycle', 'rickshaw'];

const CAR_PAINT_SWATCHES = [
  '#dc2626',
  '#0284c7',
  '#f8fafc',
  '#111827',
  '#16a34a',
  '#eab308',
  '#7c3aed',
];

const PHONE_FRAME_SWATCHES = [
  '#0f172a',
  '#1e3a8a',
  '#7c3aed',
  '#be123c',
  '#047857',
  '#b45309',
  '#cbd5e1',
];

export const ShopModal: React.FC<ShopModalProps> = ({
  place,
  save,
  onClose,
  onBuyOrSummonVehicle,
  onUpgradeVehicle,
  onBuyPhone,
  onSetPhoneColor,
  onBuyProperty,
  onEatMeal,
  onRestAtHome,
  onUpdateCustomization,
  onBankDeposit,
  onBankWithdraw,
  onBankTakeLoan,
  onBankRepayLoan,
}) => {
  const activeCustom = save.customizations[save.activeCharacter];
  const [selectedTuneCar, setSelectedTuneCar] = useState<VehicleType>(
    save.ownedVehicles[0] || 'mehran'
  );

  const Icon =
    place.type === 'dealership' || place.type === 'bike_shop'
      ? Car
      : place.type === 'bank'
        ? Landmark
        : place.type === 'phone_shop'
          ? Smartphone
          : place.type === 'home'
            ? Home
            : place.type === 'restaurant'
              ? Utensils
              : place.type === 'clothing'
                ? Shirt
                : place.type === 'property'
                  ? Building2
                  : ShoppingBag;

  const vehicleCatalog =
    place.type === 'dealership'
      ? DEALERSHIP_VEHICLES
      : place.type === 'bike_shop'
        ? BIKE_SHOP_VEHICLES
        : [];

  const tuningTarget = save.ownedVehicles.includes(selectedTuneCar)
    ? selectedTuneCar
    : save.ownedVehicles[0] || 'mehran';
  const currentTuning: VehicleTuning = save.vehicleTuning[tuningTarget] || {
    color: VEHICLE_SPECS[tuningTarget].defaultColor,
    engineLevel: 1,
    handlingLevel: 1,
  };
  const engineCost = currentTuning.engineLevel * 15000;
  const handlingCost = currentTuning.handlingLevel * 12000;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-black/65">
      <div className="w-full max-w-md bg-slate-950 border-2 border-slate-700 rounded-2xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 bg-slate-900 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <Icon className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="text-base font-black text-white">{place.name}</h2>
              <p className="text-xs text-slate-400 capitalize">{place.district.replace(/_/g, ' ')}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4 max-h-[72vh] overflow-y-auto">
          <p className="text-xs text-slate-300 leading-relaxed">{place.description}</p>
          <div className="text-xs font-black text-emerald-400 tabular-nums">
            Wallet: Rs. {save.cash.toLocaleString()}
          </div>

          {/* K-BANK & ATM HQ */}
          {place.type === 'bank' && (
            <BankApp
              save={save}
              onDeposit={onBankDeposit}
              onWithdraw={onBankWithdraw}
              onTakeLoan={onBankTakeLoan}
              onRepayLoan={onBankRepayLoan}
            />
          )}

          {/* HOME (Starter House) */}
          {place.type === 'home' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2.5">
                <div className="text-xs font-black uppercase tracking-wider text-amber-400">
                  Home Amenities
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onRestAtHome(place.name);
                    onClose();
                  }}
                  className="w-full py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-black text-xs cursor-pointer"
                >
                  Rest & Sleep (100% Health + Save Game)
                </button>
              </div>

              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                <div className="text-xs font-black uppercase tracking-wider text-emerald-400">
                  Home Garage — Summon Owned Vehicle
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {save.ownedVehicles.map((vt) => (
                    <button
                      key={vt}
                      type="button"
                      onClick={() => {
                        onBuyOrSummonVehicle(vt);
                        onClose();
                      }}
                      className="p-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-left cursor-pointer"
                    >
                      <div className="text-xs font-bold text-white truncate">
                        {VEHICLE_SPECS[vt].name}
                      </div>
                      <div className="text-[10px] text-sky-400 font-bold">Drive Out</div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                <div className="text-xs font-black uppercase tracking-wider text-pink-400">
                  Home Wardrobe
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {(
                    [
                      { id: 'shalwar_kameez', label: 'Shalwar Kameez' },
                      { id: 'kurta_waistcoat', label: 'Kurta Waistcoat' },
                      { id: 'ajrak_street', label: 'Ajrak Street' },
                      { id: 'modern_casual', label: 'Modern Casual' },
                    ] as { id: ClothingStyle; label: string }[]
                  ).map((o) => (
                    <button
                      key={o.id}
                      type="button"
                      onClick={() => onUpdateCustomization({ ...activeCustom, style: o.id })}
                      className={`p-2 rounded-lg border text-xs font-bold cursor-pointer ${
                        activeCustom.style === o.id
                          ? 'bg-amber-400 text-slate-950 border-amber-300'
                          : 'bg-slate-800 text-white border-slate-700'
                      }`}
                    >
                      {o.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* PHONE SHOP */}
          {place.type === 'phone_shop' && (
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="text-xs font-black uppercase tracking-wider text-purple-400">
                  Smartphones (Boost YouTube Income)
                </div>
                {(['lite', 'pro_5g', 'creator_max'] as PhoneModelId[]).map((mid) => {
                  const model = PHONE_MODELS[mid];
                  const isActive = save.phoneModel === mid;
                  const canAfford = save.cash >= model.price;
                  return (
                    <div
                      key={mid}
                      className={`p-3 rounded-xl border ${
                        isActive
                          ? 'bg-purple-950/40 border-purple-400'
                          : 'bg-slate-900 border-slate-800'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="text-sm font-bold text-white flex items-center gap-1.5">
                            {model.name}
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-black">
                              {model.ytMultiplier}x YT
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-0.5">{model.tagline}</p>
                        </div>
                        <button
                          type="button"
                          disabled={isActive || (!isActive && !canAfford)}
                          onClick={() => onBuyPhone(mid)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-black shrink-0 cursor-pointer ${
                            isActive
                              ? 'bg-purple-500 text-white'
                              : canAfford
                                ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                          }`}
                        >
                          {isActive
                            ? 'Equipped'
                            : model.price === 0
                              ? 'Equip'
                              : `Buy Rs.${model.price.toLocaleString()}`}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                <div className="flex items-center gap-1.5 text-xs font-black text-slate-200">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Phone Case & Bezel Color (Free)
                </div>
                <div className="flex gap-2">
                  {PHONE_FRAME_SWATCHES.map((col) => (
                    <button
                      key={col}
                      type="button"
                      onClick={() => onSetPhoneColor(col)}
                      style={{ backgroundColor: col }}
                      className={`w-7 h-7 rounded-full border-2 cursor-pointer ${
                        save.phoneThemeColor === col ? 'border-amber-400 scale-110' : 'border-slate-600'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* VEHICLE CATALOG (Car Shop & Bike Shop) */}
          {vehicleCatalog.length > 0 && (
            <div className="space-y-2">
              {vehicleCatalog.map((vt) => {
                const spec = VEHICLE_SPECS[vt];
                const owned = save.ownedVehicles.includes(vt);
                const canAfford = save.cash >= spec.price;
                return (
                  <div
                    key={vt}
                    className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between"
                  >
                    <div>
                      <div className="text-sm font-bold text-white">{spec.name}</div>
                      <div className="text-[11px] text-slate-400">
                        Top Speed {Math.round(spec.topSpeed * 3.6)} km/h
                      </div>
                    </div>
                    <button
                      type="button"
                      disabled={!owned && !canAfford}
                      onClick={() => {
                        onBuyOrSummonVehicle(vt);
                        onClose();
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-black cursor-pointer ${
                        owned
                          ? 'bg-sky-500 hover:bg-sky-400 text-white'
                          : canAfford
                            ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                            : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      {owned ? 'Drive Out' : `Buy Rs.${spec.price.toLocaleString()}`}
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {/* CAR SHOP AUTO CUSTOMS (Paint & Tuning Upgrades) */}
          {place.type === 'dealership' && save.ownedVehicles.length > 0 && (
            <div className="p-4 rounded-xl bg-slate-900 border border-sky-500/40 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-sky-400">
                  <Wrench className="w-3.5 h-3.5" /> Auto Customs & Tuning
                </div>
              </div>

              <select
                value={tuningTarget}
                onChange={(e) => setSelectedTuneCar(e.target.value as VehicleType)}
                className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-xs font-bold text-white"
              >
                {save.ownedVehicles.map((vt) => (
                  <option key={vt} value={vt}>
                    {VEHICLE_SPECS[vt].name}
                  </option>
                ))}
              </select>

              <div>
                <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-300 mb-1.5">
                  <Palette className="w-3.5 h-3.5 text-amber-400" /> Custom Paint Job (Rs. 3,500)
                </div>
                <div className="flex gap-2">
                  {CAR_PAINT_SWATCHES.map((col) => (
                    <button
                      key={col}
                      type="button"
                      disabled={save.cash < 3500}
                      onClick={() =>
                        onUpgradeVehicle(
                          tuningTarget,
                          { color: col },
                          3500,
                          `${VEHICLE_SPECS[tuningTarget].name} repainted`
                        )
                      }
                      style={{ backgroundColor: col }}
                      className={`w-7 h-7 rounded-full border-2 cursor-pointer ${
                        currentTuning.color === col ? 'border-amber-400 scale-110' : 'border-slate-600'
                      }`}
                    />
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  disabled={currentTuning.engineLevel >= 3 || save.cash < engineCost}
                  onClick={() =>
                    onUpgradeVehicle(
                      tuningTarget,
                      { engineLevel: currentTuning.engineLevel + 1 },
                      engineCost,
                      `${VEHICLE_SPECS[tuningTarget].name} Engine Lv.${currentTuning.engineLevel + 1}`
                    )
                  }
                  className="p-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-50 border border-slate-700 text-left cursor-pointer"
                >
                  <div className="text-[11px] font-black text-white">
                    Engine Lv.{currentTuning.engineLevel}/3
                  </div>
                  <div className="text-[10px] text-emerald-400 font-bold">
                    {currentTuning.engineLevel >= 3
                      ? 'MAXED'
                      : `Upgrade Rs.${engineCost.toLocaleString()}`}
                  </div>
                </button>

                <button
                  type="button"
                  disabled={currentTuning.handlingLevel >= 3 || save.cash < handlingCost}
                  onClick={() =>
                    onUpgradeVehicle(
                      tuningTarget,
                      { handlingLevel: currentTuning.handlingLevel + 1 },
                      handlingCost,
                      `${VEHICLE_SPECS[tuningTarget].name} Grip Lv.${currentTuning.handlingLevel + 1}`
                    )
                  }
                  className="p-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-50 border border-slate-700 text-left cursor-pointer"
                >
                  <div className="text-[11px] font-black text-white">
                    Grip Lv.{currentTuning.handlingLevel}/3
                  </div>
                  <div className="text-[10px] text-sky-400 font-bold">
                    {currentTuning.handlingLevel >= 3
                      ? 'MAXED'
                      : `Upgrade Rs.${handlingCost.toLocaleString()}`}
                  </div>
                </button>
              </div>

              <button
                type="button"
                onClick={() => {
                  onBuyOrSummonVehicle(tuningTarget);
                  onClose();
                }}
                className="w-full py-2 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs cursor-pointer"
              >
                Spawn Tuned {VEHICLE_SPECS[tuningTarget].name} Outside
              </button>
            </div>
          )}

          {place.type === 'restaurant' && (
            <div className="space-y-2">
              {[
                { name: 'Special Chicken Biryani + Raita', cost: 450 },
                { name: 'Burns Road Beef Nihari & Naan', cost: 850 },
                { name: 'Doodh Patti Chai + Bun Kabab', cost: 250 },
              ].map((item) => (
                <button
                  key={item.name}
                  type="button"
                  disabled={save.cash < item.cost}
                  onClick={() => {
                    onEatMeal(item.cost, item.name);
                    onClose();
                  }}
                  className="w-full p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 flex items-center justify-between text-left cursor-pointer"
                >
                  <div>
                    <div className="text-sm font-bold text-white">{item.name}</div>
                    <div className="text-[11px] text-emerald-400">Restores 100% Health & Stamina</div>
                  </div>
                  <span className="text-xs font-black text-amber-400 tabular-nums">
                    Rs. {item.cost}
                  </span>
                </button>
              ))}
            </div>
          )}

          {(place.type === 'clothing' || place.type === 'mall') && (
            <div className="space-y-2">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Select Pakistani Outfit
              </div>
              {(
                [
                  { id: 'shalwar_kameez', label: 'Classic Shalwar Kameez', price: 0 },
                  { id: 'kurta_waistcoat', label: 'Festive Kurta & Waistcoat', price: 0 },
                  { id: 'ajrak_street', label: 'Sindhi Ajrak Street Look', price: 0 },
                  { id: 'modern_casual', label: 'Dolmen Mall Designer Jacket', price: 0 },
                ] as { id: ClothingStyle; label: string; price: number }[]
              ).map((outfit) => (
                <button
                  key={outfit.id}
                  type="button"
                  onClick={() => {
                    onUpdateCustomization({ ...activeCustom, style: outfit.id });
                    onClose();
                  }}
                  className={`w-full p-3 rounded-xl border text-left text-sm font-bold cursor-pointer ${
                    activeCustom.style === outfit.id
                      ? 'bg-amber-400 text-slate-950 border-amber-300'
                      : 'bg-slate-900 text-white border-slate-800 hover:bg-slate-800'
                  }`}
                >
                  {outfit.label}
                </button>
              ))}
            </div>
          )}

          {place.type === 'property' && (
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300">Property Price</span>
                <span className="text-sm font-black text-amber-400 tabular-nums">
                  Rs. {(place.price ?? 100000).toLocaleString()}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300">Passive Income</span>
                <span className="text-sm font-black text-emerald-400 tabular-nums">
                  +Rs. {(place.incomePerMin ?? 2000).toLocaleString()} / min
                </span>
              </div>
              {save.ownedProperties.includes(place.id) ? (
                <div className="space-y-2">
                  <div className="py-2 text-center rounded-lg bg-emerald-950 border border-emerald-500/40 text-emerald-400 text-xs font-black">
                    YOU OWN THIS KARACHI ASSET
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      onRestAtHome(place.name);
                      onClose();
                    }}
                    className="w-full py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-black text-xs cursor-pointer"
                  >
                    Rest at Home (100% Health & Save Game)
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  disabled={save.cash < (place.price ?? 100000)}
                  onClick={() => {
                    onBuyProperty(place.id);
                    onClose();
                  }}
                  className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:bg-slate-800 disabled:text-slate-500 text-slate-950 font-black text-xs cursor-pointer"
                >
                  Purchase Property
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
