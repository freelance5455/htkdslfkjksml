import React, { useState } from "react";
import { Item, Player } from "../types";
import { MUSTAKIM_SHOP_INVENTORY } from "../game/constants";
import { sound } from "../audio";
import {
  X,
  Store,
  Coins,
  ShoppingBag,
  Sparkles,
  Layers,
  Check,
} from "lucide-react";

interface ShopModalProps {
  isOpen: boolean;
  onClose: () => void;
  player: Player;
  inventory: Item[];
  onBuyItem: (item: Item, cost: number) => void;
  onSellItem: (item: Item, count: number, earnings: number) => void;
}

export const ShopModal: React.FC<ShopModalProps> = ({
  isOpen,
  onClose,
  player,
  inventory,
  onBuyItem,
  onSellItem,
}) => {
  const [activeTab, setActiveTab] = useState<"buy" | "sell">("buy");
  const [purchaseNotice, setPurchaseNotice] = useState<string | null>(null);

  if (!isOpen) return null;

  // Handle Buy
  const handleBuy = (shopItem: Item) => {
    if (player.coins < shopItem.value) {
      sound.playDogWhimper();
      setPurchaseNotice(`❌ পর্যাপ্ত টাকা নেই! ${shopItem.value} Tk প্রয়োজন।`);
      setTimeout(() => setPurchaseNotice(null), 2500);
      return;
    }
    sound.playCoin();
    onBuyItem(shopItem, shopItem.value);
    setPurchaseNotice(`✅ কেনা হয়েছে: ${shopItem.bengaliName} (-${shopItem.value} Tk)`);
    setTimeout(() => setPurchaseNotice(null), 2500);
  };

  // Handle Sell
  const handleSell = (item: Item) => {
    if (item.count <= 0) return;
    sound.playCoin();
    const earnings = item.value * item.count;
    onSellItem(item, item.count, earnings);
    setPurchaseNotice(`💰 বিক্রি হয়েছে: ${item.count}টি ${item.bengaliName} (+${earnings} Tk)`);
    setTimeout(() => setPurchaseNotice(null), 2500);
  };

  // Items Tojo can sell (crops, resources, crafted goods)
  const sellableItems = inventory.filter(
    (item) => item.type === "crop" || item.type === "resource" || (item.count > 0 && item.value > 0 && item.id !== "hand_empty")
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-2 sm:p-4 select-none">
      <div className="relative w-full max-w-2xl bg-stone-900 border-2 border-teal-500 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Floating/Prominent Close Button - Always visible regardless of scrolling or screen size */}
        <div className="bg-gradient-to-r from-stone-950 via-teal-950/70 to-stone-950 p-3 sm:p-4 border-b border-teal-600/50 flex items-center justify-between gap-2">
          {/* Shopkeeper Profile */}
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-teal-900/70 border-2 border-teal-400 flex items-center justify-center text-2xl sm:text-3xl shadow-lg relative shrink-0">
              <span>👨‍💻</span>
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full border-2 border-stone-900 animate-pulse" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base sm:text-lg font-bold text-teal-200 font-['Hind_Siliguri'] truncate">
                  দেপলোপার মুস্তাকিম স্টোর
                </h2>
                <span className="text-[10px] bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/60 font-bold shrink-0">
                  স্থায়ী দোকানদার
                </span>
              </div>
              <p className="text-[11px] text-stone-300 truncate">
                নদীর ঘাট • তোজোর জন্য সব বীজ, হাতিয়ার, খাবার ও উপাদান
              </p>
            </div>
          </div>

          {/* Right Header Controls: Coins & Highly Visible Close Button */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Coins badge */}
            <div className="bg-stone-950/90 px-2.5 py-1.5 rounded-xl border border-amber-500/50 flex items-center gap-1.5 text-amber-300 text-xs sm:text-sm font-bold font-mono shadow">
              <Coins className="w-4 h-4 text-amber-400" />
              <span>{player.coins} Tk</span>
            </div>

            {/* HIGH VISIBILITY CLOSE BUTTON (X) */}
            <button
              onClick={onClose}
              className="px-2.5 sm:px-3 py-1.5 bg-red-600 hover:bg-red-500 active:bg-red-700 text-white font-bold rounded-xl shadow-lg border border-red-400 flex items-center gap-1 cursor-pointer transition transform active:scale-95 shrink-0"
              title="দোকান বন্ধ করুন [X / Esc]"
              aria-label="Close Shop"
            >
              <X className="w-4 h-4 sm:w-5 sm:h-5 text-white stroke-[2.5]" />
              <span className="text-xs font-['Hind_Siliguri'] font-bold hidden sm:inline">
                বন্ধ
              </span>
            </button>
          </div>
        </div>

        {/* Temporary Purchase/Sell Banner */}
        {purchaseNotice && (
          <div className="bg-teal-950 border-b border-teal-500/60 text-teal-200 px-3 py-1.5 text-xs font-bold text-center animate-fade-in font-['Hind_Siliguri']">
            {purchaseNotice}
          </div>
        )}

        {/* Navigation Tabs (Pure Shopping: Buy Goods & Sell Loot) */}
        <div className="flex items-center bg-stone-950 border-b border-stone-800 text-xs font-bold">
          <button
            onClick={() => setActiveTab("buy")}
            className={`flex-1 py-3 flex items-center justify-center gap-2 cursor-pointer transition border-b-2 ${
              activeTab === "buy"
                ? "border-teal-400 text-teal-300 bg-stone-900/80"
                : "border-transparent text-stone-400 hover:text-stone-200"
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span>সব আইটেম কিনুন ({MUSTAKIM_SHOP_INVENTORY.length} টি)</span>
          </button>
          <button
            onClick={() => setActiveTab("sell")}
            className={`flex-1 py-3 flex items-center justify-center gap-2 cursor-pointer transition border-b-2 ${
              activeTab === "sell"
                ? "border-amber-400 text-amber-300 bg-stone-900/80"
                : "border-transparent text-stone-400 hover:text-stone-200"
            }`}
          >
            <Coins className="w-4 h-4" />
            <span>ফসল ও উপাদান বিক্রি করুন ({sellableItems.length})</span>
          </button>
        </div>

        {/* Tab 1: BUY GOODS (All Game Items Sold by Developer Mustakim) */}
        {activeTab === "buy" && (
          <div className="p-3 sm:p-4 overflow-y-auto space-y-2.5 flex-1">
            <div className="bg-teal-950/40 p-2.5 rounded-xl border border-teal-800/40 flex items-center justify-between text-xs text-teal-200 font-['Hind_Siliguri']">
              <span>👨‍💻 তোজো ভাই! যা লাগবে সব আমার কাছ থেকে নিন—সব আইটেম মজুত আছে।</span>
              <span className="text-amber-400 font-mono font-bold">{player.coins} Tk ব্যালেন্স</span>
            </div>

            {MUSTAKIM_SHOP_INVENTORY.map((item) => {
              const canAfford = player.coins >= item.value;

              return (
                <div
                  key={item.id}
                  className="p-3 bg-stone-800/90 rounded-xl border border-stone-700/80 flex items-center justify-between gap-3 hover:border-teal-500/60 transition shadow-sm"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-12 h-12 rounded-xl bg-stone-900 border border-stone-700 flex items-center justify-center text-2xl shrink-0 shadow-inner">
                      {item.icon}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-stone-100 font-['Hind_Siliguri'] text-sm">
                          {item.bengaliName}
                        </span>
                        <span className="text-stone-400 text-[11px]">({item.name})</span>
                        {item.tier && (
                          <span className="text-[10px] bg-amber-950 text-amber-300 px-1.5 py-0.2 rounded font-mono border border-amber-600/40">
                            Tier {item.tier}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-stone-300 mt-0.5 line-clamp-1 font-['Hind_Siliguri']">
                        {item.description}
                      </p>
                    </div>
                  </div>

                  <div className="shrink-0 flex items-center gap-2.5 sm:gap-3">
                    <span className="font-mono font-bold text-amber-300 text-xs sm:text-sm">
                      {item.value} Tk
                    </span>
                    <button
                      onClick={() => handleBuy(item)}
                      disabled={!canAfford}
                      className={`px-3 sm:px-3.5 py-1.5 rounded-xl font-bold text-xs cursor-pointer transition shadow flex items-center gap-1 ${
                        canAfford
                          ? "bg-teal-600 hover:bg-teal-500 text-white shadow-teal-900/40 transform active:scale-95"
                          : "bg-stone-800 text-stone-500 border border-stone-700 cursor-not-allowed"
                      }`}
                    >
                      <span>কিনুন</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Tab 2: SELL LOOT & CROPS */}
        {activeTab === "sell" && (
          <div className="p-3 sm:p-4 overflow-y-auto space-y-2.5 flex-1">
            {sellableItems.length === 0 ? (
              <div className="text-center py-12 text-stone-400 text-xs flex flex-col items-center gap-2">
                <Store className="w-10 h-10 text-stone-600" />
                <span className="font-bold text-sm text-stone-300 font-['Hind_Siliguri']">
                  বিক্রির জন্য কোনো মালপত্র বা ফসল নেই!
                </span>
                <span className="text-stone-400 font-['Hind_Siliguri']">
                  কুঠার দিয়ে গাছ কেটে কাঠ আনুন অথবা জমিতে কচু ও ধান চাষ করে এখানে বিক্রি করুন।
                </span>
              </div>
            ) : (
              sellableItems.map((item) => {
                const totalValue = item.value * item.count;
                return (
                  <div
                    key={item.id}
                    className="p-3 bg-stone-800/90 rounded-xl border border-stone-700/80 flex items-center justify-between gap-3 shadow-sm"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-xl bg-stone-900 border border-stone-700 flex items-center justify-center text-xl shrink-0 shadow-inner">
                        {item.icon}
                      </div>
                      <div>
                        <span className="font-bold text-stone-100 font-['Hind_Siliguri'] text-sm">
                          {item.bengaliName}
                        </span>
                        <p className="text-xs text-stone-400 font-['Hind_Siliguri']">
                          মজুদ: <span className="font-mono text-emerald-400 font-bold">{item.count} টি</span> • দর: {item.value} Tk/টি
                        </p>
                      </div>
                    </div>

                    <div className="shrink-0 flex items-center gap-2.5 sm:gap-3">
                      <span className="font-mono font-bold text-emerald-400 text-xs sm:text-sm">
                        +{totalValue} Tk
                      </span>
                      <button
                        onClick={() => handleSell(item)}
                        className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold cursor-pointer transition shadow transform active:scale-95"
                      >
                        সব বিক্রি করুন
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}

        {/* Footer with Clear Close Button and Location Info */}
        <div className="p-3 bg-stone-950 border-t border-stone-800 text-xs text-stone-400 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-[11px]">
            <span className="text-teal-400 font-bold">🏪 স্থায়ী দোকান</span>
            <span>• যেকোনো সময় ঘাটে এসে কেনাকাটা করুন</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-stone-800 hover:bg-red-700 text-stone-200 hover:text-white rounded-xl font-bold text-xs cursor-pointer transition flex items-center gap-1.5 border border-stone-700 hover:border-red-500 shadow"
          >
            <X className="w-4 h-4 text-red-400" />
            <span>দোকান বন্ধ করুন [Esc]</span>
          </button>
        </div>
      </div>
    </div>
  );
};
