"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { apiPost } from "@/lib/client/api";

export type ShellUser = { id: number; email: string; name: string; role: string; planKey: string } | null;

const NAV = [
  { href: "/home", label: "Home", icon: "🏠" },
  { href: "/create", label: "Create", icon: "✨" },
  { href: "/ideas", label: "Ideas", icon: "💡" },
  { href: "/calendar", label: "Calendar", icon: "🗓️" },
  { href: "/analyze", label: "Analyze", icon: "🔍" },
  { href: "/profile", label: "Profile", icon: "👤" },
];

export default function AppShell({
  user,
  usage,
  announcement,
  children,
}: {
  user: ShellUser;
  usage: { remaining: number; limit: number; planName: string } | null;
  announcement?: string;
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [loggingOut, setLoggingOut] = useState(false);

  const isActive = (href: string) => pathname === href || pathname.startsWith(`${href}/`);
  const planLabel = usage?.planName ?? "Free";
  const isPaid = planLabel.toLowerCase() !== "free";

  return (
    <div className="mx-auto flex w-full max-w-6xl gap-6 px-3 pb-28 pt-3 md:px-6 md:pb-8">
      {/* Desktop sidebar */}
      <aside className="sticky top-4 hidden h-[calc(100dvh-2rem)] w-56 shrink-0 flex-col justify-between rounded-2xl border border-white/10 bg-white/[0.03] p-4 md:flex">
        <div>
          <Link href="/home" className="mb-6 flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400 text-lg">🛠️</span>
            <span className="text-sm font-bold leading-tight">
              Creator
              <br />
              Toolkit
            </span>
          </Link>
          <nav className="flex flex-col gap-1">
            {NAV.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium transition ${
                  isActive(item.href)
                    ? "bg-gradient-to-r from-violet-500/25 to-transparent text-white"
                    : "text-[color:var(--muted)] hover:bg-white/5 hover:text-white"
                }`}
              >
                <span>{item.icon}</span>
                {item.label}
              </Link>
            ))}
            {user?.role === "admin" ? (
              <Link
                href="/admin"
                className={`mt-2 flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium ${
                  isActive("/admin") ? "bg-white/10 text-white" : "text-amber-200/80 hover:bg-white/5"
                }`}
              >
                <span>⚙️</span> Admin
              </Link>
            ) : null}
          </nav>
        </div>
        <div className="space-y-3">
          {usage ? (
            <div className="rounded-xl border border-white/10 bg-black/20 p-3">
              <p className="text-[0.7rem] uppercase tracking-wider text-[color:var(--muted)]">{planLabel} plan</p>
              <p className="mt-1 text-sm font-semibold">
                {usage.remaining} / {usage.limit} left
              </p>
              <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-violet-400 to-cyan-300"
                  style={{ width: `${usage.limit ? Math.min(100, Math.round((usage.remaining / usage.limit) * 100)) : 0}%` }}
                />
              </div>
              {!isPaid ? (
                <Link href="/pricing" className="btn btn-primary btn-sm mt-3 w-full">
                  Upgrade
                </Link>
              ) : null}
            </div>
          ) : null}
          <button
            type="button"
            className="btn btn-ghost btn-sm w-full"
            disabled={loggingOut}
            onClick={async () => {
              setLoggingOut(true);
              await apiPost("/api/auth/logout", {}).catch(() => undefined);
              router.push("/login");
              router.refresh();
            }}
          >
            {loggingOut ? "Signing out…" : "Sign out"}
          </button>
        </div>
      </aside>

      <div className="min-w-0 flex-1">
        {/* Mobile header */}
        <header className="mb-4 flex items-center justify-between gap-3 md:hidden">
          <Link href="/home" className="flex items-center gap-2">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400 text-lg">🛠️</span>
            <span className="text-sm font-bold">Creator Toolkit</span>
          </Link>
          <div className="flex items-center gap-2">
            {usage ? (
              <Link href="/profile" className="chip">
                {usage.remaining}/{usage.limit} left
              </Link>
            ) : null}
            {!isPaid ? (
              <Link href="/pricing" className="btn btn-primary btn-sm">
                Upgrade
              </Link>
            ) : null}
          </div>
        </header>

        {announcement ? (
          <div className="mb-4 hidden rounded-xl border border-violet-400/20 bg-violet-500/10 px-4 py-2 text-xs text-violet-100 md:block">
            {announcement}
          </div>
        ) : null}

        {children}
      </div>

      {/* Mobile bottom nav */}
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-white/10 bg-[#080a17]/95 px-1 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden">
        <ul className="flex items-stretch justify-between">
          {NAV.map((item) => (
            <li key={item.href} className="flex-1">
              <Link
                href={item.href}
                className={`flex flex-col items-center gap-0.5 py-2 text-[0.62rem] font-medium transition ${
                  isActive(item.href) ? "text-violet-200" : "text-[color:var(--muted)]"
                }`}
              >
                <span className="text-base leading-none">{item.icon}</span>
                {item.label}
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
}
