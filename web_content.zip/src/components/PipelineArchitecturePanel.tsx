import React from 'react';
import {
  Cpu,
  Layers,
  ShieldCheck,
  DownloadCloud,
  CheckCircle,
  AlertTriangle,
  Sliders,
  DollarSign,
  Info,
} from 'lucide-react';
import { ModularPluginConfig } from '../types';

interface PipelineArchitecturePanelProps {
  pluginConfig: ModularPluginConfig;
  setPluginConfig: React.Dispatch<React.SetStateAction<ModularPluginConfig>>;
}

export const PipelineArchitecturePanel: React.FC<PipelineArchitecturePanelProps> = ({
  pluginConfig,
  setPluginConfig,
}) => {
  return (
    <div className="flex flex-col gap-6">
      {/* Overview Card */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-orange-400">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">
              मॉड्यूलर अनुवाद और डबिंग पाइपलाइन आर्किटेक्चर (Modular Pipeline Architecture)
            </h3>
            <p className="text-xs text-slate-400">
              भाषण पहचान (Speech Recognition) → हिंदी अनुवाद (Translation) → टाइमस्टैम्प सिंक (Timing) → ऑडियो डबिंग (Audio Dubbing)
            </p>
          </div>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          यह आर्किटेक्चर प्रत्येक घटक को स्वतंत्र प्लगइन के रूप में अलग करता है। यह ऐप बिना किसी पेड एपीआई के पूरी तरह से ऑफ़लाइन काम कर सकता है, साथ ही भविष्य के उन्नत क्लाउड AI सेवाओं (जैसे Firebase AI Logic या Google Gemini) के लिए तैयार है।
        </p>
      </div>

      {/* 4 Pipeline Stages (Interactive Plugin Selectors) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Stage 1: Speech Recognition */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-md bg-blue-500/20 text-blue-400 font-bold text-xs flex items-center justify-center">
                1
              </span>
              <h4 className="text-sm font-bold text-white">भाषण पहचान (Speech-to-Text)</h4>
            </div>
            <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
              प्लगइन समर्थित
            </span>
          </div>

          <p className="text-xs text-slate-400">
            वीडियो ऑडियो ट्रैक से भाषण को पहचानना और समय के अनुसार टेक्स्ट निकालना।
          </p>

          <div className="flex flex-col gap-2 mt-1">
            <label className="flex items-center gap-2 text-xs p-2 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
              <input
                type="radio"
                name="speech_provider"
                checked={pluginConfig.speechProvider === 'manual_entry'}
                onChange={() =>
                  setPluginConfig((prev) => ({ ...prev, speechProvider: 'manual_entry' }))
                }
                className="accent-orange-500"
              />
              <div>
                <span className="font-semibold text-white">मैनुअल और ऑफ़लाइन ट्रांसक्रिप्ट (0$ लागत)</span>
                <p className="text-[11px] text-slate-500">उपयोगकर्ता द्वारा दर्ज टेक्स्ट या SRT फ़ाइल</p>
              </div>
            </label>

            <label className="flex items-center gap-2 text-xs p-2 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
              <input
                type="radio"
                name="speech_provider"
                checked={pluginConfig.speechProvider === 'browser_speech'}
                onChange={() =>
                  setPluginConfig((prev) => ({ ...prev, speechProvider: 'browser_speech' }))
                }
                className="accent-orange-500"
              />
              <div>
                <span className="font-semibold text-white">Android SpeechRecognizer / Web Speech</span>
                <p className="text-[11px] text-slate-500">डिवाइस का मूल ऑन-डिवाइस ऑडियो पहचान इंजन</p>
              </div>
            </label>

            <label className="flex items-center gap-2 text-xs p-2 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
              <input
                type="radio"
                name="speech_provider"
                checked={pluginConfig.speechProvider === 'gemini_transcribe'}
                onChange={() =>
                  setPluginConfig((prev) => ({ ...prev, speechProvider: 'gemini_transcribe' }))
                }
                className="accent-orange-500"
              />
              <div>
                <span className="font-semibold text-white">Google Gemini Transcribe (Cloud AI)</span>
                <p className="text-[11px] text-slate-500">उच्च-सटीक क्लाउड ऑडियो विश्लेषण</p>
              </div>
            </label>
          </div>
        </div>

        {/* Stage 2: Hindi Translation */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-md bg-orange-500/20 text-orange-400 font-bold text-xs flex items-center justify-center">
                2
              </span>
              <h4 className="text-sm font-bold text-white">हिंदी अनुवाद (Hindi Translation)</h4>
            </div>
            <span className="text-[10px] text-orange-400 bg-orange-500/10 px-2 py-0.5 rounded border border-orange-500/30">
              देवनागरी आउटपुट
            </span>
          </div>

          <p className="text-xs text-slate-400">
            पहचाने गए संवाद को स्वाभाविक, मुहावरेदार हिंदी देवनागरी लिपि में अनुवाद करना।
          </p>

          <div className="flex flex-col gap-2 mt-1">
            <label className="flex items-center gap-2 text-xs p-2 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
              <input
                type="radio"
                name="trans_engine"
                checked={pluginConfig.translationEngine === 'manual'}
                onChange={() =>
                  setPluginConfig((prev) => ({ ...prev, translationEngine: 'manual' }))
                }
                className="accent-orange-500"
              />
              <div>
                <span className="font-semibold text-white">ऑफ़लाइन डिक्शनरी और प्रत्यक्ष इनपुट (Zero-Cost)</span>
                <p className="text-[11px] text-slate-500">सीधे हिंदी में टाइप करें या पूर्व-निर्मित अनुवाद चुनें</p>
              </div>
            </label>

            <label className="flex items-center gap-2 text-xs p-2 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
              <input
                type="radio"
                name="trans_engine"
                checked={pluginConfig.translationEngine === 'gemini_flash'}
                onChange={() =>
                  setPluginConfig((prev) => ({ ...prev, translationEngine: 'gemini_flash' }))
                }
                className="accent-orange-500"
              />
              <div>
                <span className="font-semibold text-white">Gemini 2.5 Flash / Firebase AI Logic</span>
                <p className="text-[11px] text-slate-500">स्वाभाविक भारतीय संदर्भ के साथ व्याकरण-सम्मत अनुवाद</p>
              </div>
            </label>
          </div>
        </div>

        {/* Stage 3: Subtitle Timing */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-md bg-purple-500/20 text-purple-400 font-bold text-xs flex items-center justify-center">
                3
              </span>
              <h4 className="text-sm font-bold text-white">टाइमस्टैम्प संरेखन (Subtitle Timing)</h4>
            </div>
            <span className="text-[10px] text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/30">
              SRT / WebVTT
            </span>
          </div>

          <p className="text-xs text-slate-400">
            प्रत्येक वाक्य के लिए मिलीसेकंड सटीक प्रारंभ और समाप्ति समय आवंटित करना।
          </p>

          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300">
            <p className="font-semibold text-white mb-1">सटीकता मानदंड (Standard):</p>
            <ul className="list-disc list-inside space-y-1 text-slate-400 text-[11px]">
              <li>प्रति वाक्य आदर्श अवधि: 2.5 सेकंड से 5.0 सेकंड</li>
              <li>अतिव्यापन (Overlap) मुक्त क्रमिक टाइमलाइन</li>
              <li>ExoPlayer Player.Listener के साथ 100ms पोलिंग सिंक</li>
            </ul>
          </div>
        </div>

        {/* Stage 4: Audio Dubbing */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-md bg-emerald-500/20 text-emerald-400 font-bold text-xs flex items-center justify-center">
                4
              </span>
              <h4 className="text-sm font-bold text-white">हिंदी डब ऑडियो (Audio Dubbing & TTS)</h4>
            </div>
            <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
              डकिंग सपोर्ट
            </span>
          </div>

          <p className="text-xs text-slate-400">
            अनुवादित हिंदी वाक्यों को स्पष्ट स्वर में बोलकर सुनाना और मूल ऑडियो को धीमा करना।
          </p>

          <div className="flex flex-col gap-2 mt-1">
            <label className="flex items-center gap-2 text-xs p-2 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
              <input
                type="radio"
                name="tts_engine"
                checked={pluginConfig.ttsEngine === 'android_web_speech'}
                onChange={() =>
                  setPluginConfig((prev) => ({ ...prev, ttsEngine: 'android_web_speech' }))
                }
                className="accent-orange-500"
              />
              <div>
                <span className="font-semibold text-white">Android native TextToSpeech (hi_IN)</span>
                <p className="text-[11px] text-slate-500">100% ऑफ़लाइन, शून्य विलंबता, मुफ़्त ऑन-डिवाइस इंजन</p>
              </div>
            </label>

            <label className="flex items-center gap-2 text-xs p-2 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
              <input
                type="radio"
                name="tts_engine"
                checked={pluginConfig.ttsEngine === 'gemini_tts'}
                onChange={() =>
                  setPluginConfig((prev) => ({ ...prev, ttsEngine: 'gemini_tts' }))
                }
                className="accent-orange-500"
              />
              <div>
                <span className="font-semibold text-white">Gemini Flash Lite TTS (Cloud Studio Voice)</span>
                <p className="text-[11px] text-slate-500">स्टूडियो गुणवत्ता वाली 24kHz प्राकृतिक आवाज़</p>
              </div>
            </label>
          </div>
        </div>
      </div>

      {/* Technical Honesty & Transparency Panel (Demanded by User Prompt) */}
      <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col gap-4">
        <h4 className="text-sm font-bold text-white flex items-center gap-2">
          <Info className="w-4 h-4 text-orange-400" />
          <span>तकनीकी स्पष्टीकरण: अनुमतियाँ, मॉडल डाउनलोड, लागत और कोटा (Technical Specifications)</span>
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          {/* Permissions */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex flex-col gap-2">
            <span className="font-semibold text-orange-400 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" />
              <span>एंड्रॉइड अनुमतियाँ (Permissions)</span>
            </span>
            <ul className="text-slate-400 space-y-1.5 text-[11px]">
              <li>
                <strong className="text-slate-200">READ_MEDIA_VIDEO:</strong> Android 13+ (API 33+) में फ़ोन से स्थानीय वीडियो फ़ाइलें चुनने के लिए अनिवार्य।
              </li>
              <li>
                <strong className="text-slate-200">READ_EXTERNAL_STORAGE:</strong> Android 12 और नीचे के उपकरणों के लिए।
              </li>
              <li>
                <strong className="text-slate-200">&lt;queries&gt; TTS_SERVICE:</strong> Android 11+ में Google TTS इंजन ढूँढ़ने के लिए अनिवार्य।
              </li>
            </ul>
          </div>

          {/* Model Downloads */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex flex-col gap-2">
            <span className="font-semibold text-blue-400 flex items-center gap-1.5">
              <DownloadCloud className="w-4 h-4" />
              <span>ऑफ़लाइन मॉडल डाउनलोड (Downloads)</span>
            </span>
            <ul className="text-slate-400 space-y-1.5 text-[11px]">
              <li>
                <strong className="text-slate-200">Google TTS Hindi Voice Data:</strong> फ़ोन सेटिंग्स → भाषा और इनपुट → टेक्स्ट-टू-स्पीच → हिंदी वॉइस पैक (~18 MB)।
              </li>
              <li>
                <strong className="text-slate-200">शून्य नेटवर्क विलंबता:</strong> एक बार डाउनलोड होने पर बिना इंटरनेट के रीयल-टाइम हिंदी बोलेगा।
              </li>
            </ul>
          </div>

          {/* Quotas & Costs */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex flex-col gap-2">
            <span className="font-semibold text-emerald-400 flex items-center gap-1.5">
              <DollarSign className="w-4 h-4" />
              <span>लागत और कोटा (Costs & Quotas)</span>
            </span>
            <ul className="text-slate-400 space-y-1.5 text-[11px]">
              <li>
                <strong className="text-emerald-300">ऑफ़लाइन प्लेबैक व डबिंग:</strong> ₹0 / 100% मुफ़्त (किसी भुगतान या क्रेडिट कार्ड की आवश्यकता नहीं)।
              </li>
              <li>
                <strong className="text-slate-200">Gemini Cloud AI:</strong> Google AI Studio फ़्री टियर में प्रति मिनट 15 अनुरोध निःशुल्क हैं।
              </li>
            </ul>
          </div>
        </div>

        {/* Real-time Dubbing Reality Note */}
        <div className="p-3.5 rounded-xl bg-amber-950/20 border border-amber-900/40 text-xs text-amber-200 flex items-start gap-2.5">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold">रीयल-टाइम डबिंग प्रक्रिया की वास्तविकता (Engineering Reality):</span>
            <p className="text-slate-300 mt-1 leading-relaxed">
              किसी भी वीडियो को वास्तव में "रीयल-टाइम" में डब करने के लिए एक बहु-चरणीय पाइपलाइन की आवश्यकता होती है: पहले पूरे ऑडियो या वॉयस सेगमेंट को समझना (ASR), फिर संदर्भ को हिंदी में बदलना, फिर टाइमस्टैम्प तय करना, और अंत में TTS द्वारा ऑडियो उत्पन्न करना। तात्कालिक लाइव डबिंग में 1-2 सेकंड की प्रासंगिक विलंबता सामान्य है। हमारा ऐप इस पाइपलाइन को सही ढंग से लागू करता है और मूल वीडियो वॉल्यूम को आवश्यकतानुसार डक (धीमा) करता है।
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
