import { useEffect, useRef, useState } from "react";
import { drawPitch } from "@/game/draw";
import {
  BALL_SECONDS,
  CONTACT_AT,
  SHOTS,
  SQUAD,
  applyBall,
  freshInnings,
  mulberry32,
  overBallLabel,
  resolveBall,
  rollDelivery,
  simulateAiInnings,
  type BallResult,
  type Delivery,
  type Innings,
  type Shot,
} from "@/game/logic";

type Screen = "menu" | "ai" | "play" | "result";

const HOLD = 0.85;

let audioCtx: AudioContext | null = null;

function beep(freq: number, dur: number, type: OscillatorType = "square", gain = 0.05) {
  const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return;
  audioCtx = audioCtx ?? new Ctx();
  if (audioCtx.state === "suspended") void audioCtx.resume();
  const o = audioCtx.createOscillator();
  const g = audioCtx.createGain();
  o.type = type;
  o.frequency.value = freq;
  g.gain.value = gain;
  g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + dur);
  o.connect(g);
  g.connect(audioCtx.destination);
  o.start();
  o.stop(audioCtx.currentTime + dur);
}

function loadBest(): number {
  try {
    return Number(localStorage.getItem("ansar-best") || "0") || 0;
  } catch {
    return 0;
  }
}

interface Live {
  screen: Screen;
  innings: Innings;
  delivery: Delivery | null;
  result: BallResult | null;
  shot: Shot | null;
  timing: number | null;
  elapsed: number;
  rng: () => number;
  target: number;
  overs: number;
  shake: number;
  resolved: boolean;
  finishing: boolean;
}

export function CricketApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [overs, setOvers] = useState(5);
  const [screen, setScreen] = useState<Screen>("menu");
  const [target, setTarget] = useState(0);
  const [aiWkts, setAiWkts] = useState(0);
  const [innings, setInnings] = useState<Innings>(() => freshInnings());
  const [comment, setComment] = useState("حلقه برابره کړه، بیا شاټ ووهه.");
  const [best, setBest] = useState(0);
  const [won, setWon] = useState<"win" | "lose" | "tie" | null>(null);
  const [aiFlash, setAiFlash] = useState("0/0");

  const live = useRef<Live>({
    screen: "menu",
    innings: freshInnings(),
    delivery: null,
    result: null,
    shot: null,
    timing: null,
    elapsed: 0,
    rng: mulberry32(1),
    target: 0,
    overs: 5,
    shake: 0,
    resolved: false,
    finishing: false,
  });

  const api = useRef({
    beginBall: () => {},
    finishChase: (_inn: Innings, _tgt: number) => {},
  });

  useEffect(() => {
    setBest(loadBest());
  }, []);

  function beginBall() {
    const L = live.current;
    const overIndex = Math.floor(L.innings.balls / 6);
    const d = rollDelivery(L.rng, overIndex);
    L.delivery = d;
    L.result = null;
    L.shot = null;
    L.timing = null;
    L.elapsed = 0;
    L.resolved = false;
    setComment(`${d.bowler} را روان دی…`);
  }

  function finishChase(inn: Innings, tgt: number) {
    const L = live.current;
    if (L.screen !== "play") return;
    L.screen = "result";
    L.delivery = null;
    let outcome: "win" | "lose" | "tie" = "lose";
    if (inn.runs >= tgt) outcome = "win";
    else if (inn.runs === tgt - 1) outcome = "tie";
    setWon(outcome);
    setScreen("result");
    setInnings(inn);
    if (outcome === "win") {
      setBest((prev) => {
        const next = Math.max(prev, inn.runs);
        try {
          localStorage.setItem("ansar-best", String(next));
        } catch {
          /* ignore quota */
        }
        return next;
      });
      setComment(`انصار وګټله. ${inn.runs} منډې په ${overBallLabel(inn.balls)} کې.`);
    } else if (outcome === "tie") {
      setComment("لوبه مساوي شوه.");
    } else {
      setComment(`سیال وګټله. ${tgt - 1 - inn.runs} منډې پاتې وې.`);
    }
  }

  api.current.beginBall = beginBall;
  api.current.finishChase = finishChase;

  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    let raf = 0;
    let last = performance.now();

    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const L = live.current;
      if (L.screen === "play" && L.delivery && !L.resolved) {
        L.elapsed += dt;
        const prog = L.elapsed / BALL_SECONDS;
        if (prog >= 1) {
          L.resolved = true;
          const res = resolveBall(L.delivery, L.shot, L.timing, L.rng);
          L.result = res;
          const nextInn = applyBall(L.innings, res);
          L.innings = nextInn;
          setInnings(nextInn);
          setComment(res.text);
          L.shake = res.wicket || res.runs >= 4 ? 1 : 0;
          if (res.wicket) beep(140, 0.25, "sawtooth", 0.06);
          else if (res.runs === 6) beep(520, 0.18, "triangle", 0.07);
          else if (res.runs === 4) beep(420, 0.12, "triangle", 0.06);
          else if (res.runs > 0) beep(300, 0.08, "square", 0.04);
          else beep(180, 0.05, "square", 0.03);

          const done = nextInn.wickets >= 10 || nextInn.balls >= L.overs * 6 || nextInn.runs >= L.target;
          if (done && !L.finishing) {
            L.finishing = true;
            window.setTimeout(() => api.current.finishChase(nextInn, L.target), (HOLD + 0.05) * 1000);
          }
        }
      } else if (L.screen === "play" && L.delivery && L.resolved) {
        L.elapsed += dt;
        if (L.elapsed > BALL_SECONDS + HOLD && !L.finishing) {
          const done =
            L.innings.wickets >= 10 || L.innings.balls >= L.overs * 6 || L.innings.runs >= L.target;
          if (!done) api.current.beginBall();
        }
      }
      if (L.shake > 0) L.shake = Math.max(0, L.shake - dt * 2.2);

      const rect = c.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const bw = Math.max(2, Math.floor(rect.width * dpr));
      const bh = Math.max(2, Math.floor(rect.height * dpr));
      if (c.width !== bw || c.height !== bh) {
        c.width = bw;
        c.height = bh;
      }
      const ctx = c.getContext("2d");
      if (ctx && rect.width > 0 && rect.height > 0) {
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        const sx = L.shake > 0 ? (Math.random() - 0.5) * 8 * L.shake : 0;
        ctx.save();
        ctx.translate(sx, 0);
        drawPitch(ctx, rect.width, rect.height, {
          delivery: L.delivery,
          innings: L.innings,
          target: L.target,
          progress: L.delivery ? L.elapsed / BALL_SECONDS : 0,
          shot: L.shot,
          result: L.result,
          shake: L.shake,
          batterName: SQUAD[L.innings.striker] ?? "",
          bowlerName: L.delivery?.bowler ?? "",
        });
        ctx.restore();
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, []);

  function startMatch(chosenOvers: number) {
    beep(330, 0.08, "square", 0.04);
    const seed = (Date.now() ^ Math.floor(Math.random() * 1e9)) >>> 0;
    const ai = simulateAiInnings(chosenOvers, seed);
    const tgt = Math.max(1, ai.runs + 1);
    const inn = freshInnings();
    live.current = {
      screen: "ai",
      innings: inn,
      delivery: null,
      result: null,
      shot: null,
      timing: null,
      elapsed: 0,
      rng: mulberry32(seed ^ 0x9e3779b9),
      target: tgt,
      overs: chosenOvers,
      shake: 0,
      resolved: false,
      finishing: false,
    };
    setOvers(chosenOvers);
    setTarget(tgt);
    setAiWkts(ai.wickets);
    setInnings(inn);
    setWon(null);
    setScreen("ai");
    setComment("سیالان بیټ کوي…");
    setAiFlash("0/0");

    let i = 0;
    let runs = 0;
    let wk = 0;
    const tick = () => {
      if (live.current.screen !== "ai") return;
      if (i >= ai.balls.length) {
        setAiFlash(`${runs}/${wk}`);
        goPlay();
        return;
      }
      const b = ai.balls[i];
      if (b.wicket) wk += 1;
      else runs += b.runs;
      i += 1;
      setAiFlash(`${runs}/${wk}`);
      window.setTimeout(tick, 60);
    };
    window.setTimeout(tick, 240);
  }

  function goPlay() {
    if (live.current.screen === "play" || live.current.screen === "result") return;
    live.current.screen = "play";
    setScreen("play");
    setComment("ستا وار دی. حلقه سمه کړه او شاټ ووهه.");
    beginBall();
  }

  function playShot(shot: Shot) {
    const L = live.current;
    if (L.screen !== "play" || !L.delivery || L.shot || L.resolved) return;
    const prog = L.elapsed / BALL_SECONDS;
    if (prog < 0.22) {
      setComment("ډیر وختي! بال ته انتظار وکړه.");
      return;
    }
    L.shot = shot;
    L.timing = L.elapsed - CONTACT_AT * BALL_SECONDS;
    beep(640, 0.05, "square", 0.04);
  }

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const map: Record<string, Shot> = {
        Digit1: "straight",
        Digit2: "cover",
        Digit3: "pull",
        Digit4: "sweep",
        Digit5: "loft",
        Digit6: "block",
      };
      const shot = map[e.code];
      if (shot) playShot(shot);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  const ballsLeft = overs * 6 - innings.balls;
  const need = Math.max(0, target - innings.runs);
  const rrr = ballsLeft > 0 ? ((need / ballsLeft) * 6).toFixed(2) : "0";
  const striker = SQUAD[innings.striker] ?? "—";
  const non = SQUAD[innings.nonStriker] ?? "—";

  return (
    <main className="flex h-[100dvh] flex-col bg-bg text-fg">
      <header className="flex items-center justify-between gap-3 border-b border-line px-4 py-3">
        <div>
          <p className="font-score text-xl tracking-wide text-gold">انصار کرکټ</p>
          <p className="text-xs text-muted">د شپې لوبغالی · بیټنګ</p>
        </div>
        <p className="font-score text-sm text-muted">غوره {best}</p>
      </header>

      {screen === "play" && (
        <div className="grid grid-cols-3 gap-2 px-3 py-2 text-center">
          <div className="rounded-xl bg-surface px-2 py-2">
            <p className="text-xs text-muted">انصار</p>
            <p className="font-score text-2xl leading-none">
              {innings.runs}/{innings.wickets}
            </p>
            <p className="font-score text-xs text-muted">{overBallLabel(innings.balls)}</p>
          </div>
          <div className="rounded-xl bg-surface px-2 py-2">
            <p className="text-xs text-muted">هدف</p>
            <p className="font-score text-2xl leading-none text-gold">{target}</p>
            <p className="text-xs text-muted">
              سیال {Math.max(0, target - 1)}/{aiWkts}
            </p>
          </div>
          <div className="rounded-xl bg-surface px-2 py-2">
            <p className="text-xs text-muted">اړتیا</p>
            <p className="font-score text-2xl leading-none">{need}</p>
            <p className="font-score text-xs text-muted">RRR {rrr}</p>
          </div>
        </div>
      )}

      {screen === "play" && <p className="truncate px-4 pb-1 text-center text-sm text-muted">{comment}</p>}

      <div className={screen === "play" ? "relative min-h-48 flex-1 px-3" : "relative px-3 pt-3"}>
        <canvas
          ref={canvasRef}
          className={
            screen === "play"
              ? "absolute inset-x-3 inset-y-0 h-auto w-auto rounded-2xl border border-line"
              : "h-52 w-full rounded-2xl border border-line bg-surface"
          }
        />
        {screen === "ai" && (
          <div className="pointer-events-none absolute inset-x-3 top-3 flex h-52 flex-col items-center justify-center">
            <p className="text-sm text-muted">سیالان بیټ کوي</p>
            <p className="font-score text-6xl text-gold">{aiFlash}</p>
          </div>
        )}
      </div>

      {screen === "menu" && (
        <section className="flex flex-1 flex-col items-center justify-center gap-5 px-5 pb-6">
          <div className="max-w-md text-center">
            <h1 className="text-3xl font-extrabold">انصار الیون تعقیب کوي</h1>
            <p className="mt-2 text-sm leading-relaxed text-muted">
              سیالان لومړی بیټ کوي. ته هدف څاري. کله چې طلایي حلقه د بیټر سره برابره شي، شاټ وټاکه — سم وخت څلور او شپږ راوړي.
            </p>
          </div>
          <div className="flex gap-2">
            {[5, 10].map((n) => (
              <button
                key={n}
                type="button"
                onClick={() => setOvers(n)}
                className={`min-h-11 rounded-xl px-4 py-2 text-sm font-bold ${
                  overs === n ? "bg-gold text-gold-ink" : "bg-surface-2 text-fg"
                }`}
              >
                {n} اوورونه
              </button>
            ))}
          </div>
          <button
            type="button"
            onClick={() => startMatch(overs)}
            className="min-h-12 rounded-xl bg-gold px-8 py-3 text-base font-extrabold text-gold-ink"
          >
            لوبه پیل کړه
          </button>
          <p className="text-center text-xs text-muted">کمپیوټر: ۱ سټریټ · ۲ کور · ۳ پل · ۴ سویپ · ۵ شپږ · ۶ دفاع</p>
        </section>
      )}

      {screen === "ai" && (
        <div className="flex justify-center py-4">
          <button
            type="button"
            onClick={() => {
              if (live.current.screen === "ai") goPlay();
            }}
            className="min-h-11 rounded-xl bg-surface-2 px-5 py-2 text-sm font-bold"
          >
            هدف ته ورشه
          </button>
        </div>
      )}

      {screen === "play" && (
        <>
          <div className="flex items-center justify-between gap-2 px-4 py-1 text-xs text-muted">
            <span className="truncate">
              {striker} {innings.scores[innings.striker]}({innings.ballsFaced[innings.striker]})
            </span>
            <span className="font-score shrink-0 tracking-widest">{innings.recent.slice(-6).join(" ") || "•"}</span>
            <span className="truncate">
              {non} {innings.scores[innings.nonStriker]}
            </span>
          </div>
          <div className="grid grid-cols-3 gap-2 px-3 pb-3">
            {SHOTS.map((s, i) => (
              <button
                key={s.id}
                type="button"
                onPointerDown={(e) => {
                  e.preventDefault();
                  playShot(s.id);
                }}
                className="min-h-12 rounded-xl bg-surface-2 px-2 py-2 text-sm font-bold active:bg-gold active:text-gold-ink"
              >
                {s.ps}
                <span className="mt-0.5 block text-xs font-medium text-muted">
                  {i + 1} {s.en}
                </span>
              </button>
            ))}
          </div>
        </>
      )}

      {screen === "result" && (
        <section className="flex flex-1 flex-col items-center gap-3 overflow-auto px-5 pb-6 text-center">
          <p className="font-score text-sm text-gold">{won === "win" ? "بریا" : won === "tie" ? "مساوي" : "ماته"}</p>
          <h2 className="text-3xl font-extrabold">
            {won === "win" ? "انصار وګټله" : won === "tie" ? "لوبه مساوي شوه" : "سیال وګټله"}
          </h2>
          <p className="font-score text-5xl">
            {innings.runs}/{innings.wickets}
          </p>
          <p className="text-sm text-muted">
            هدف {target} · {overBallLabel(innings.balls)}
          </p>
          <p className="max-w-sm text-sm text-muted">{comment}</p>
          <ul className="w-full max-w-sm space-y-1 text-sm">
            {SQUAD.slice(0, Math.min(11, Math.max(innings.nextBatter, 2))).map((name, idx) => (
              <li key={name} className="flex justify-between rounded-lg bg-surface px-3 py-1">
                <span>{name}</span>
                <span className="font-score">
                  {innings.scores[idx]}
                  {innings.ballsFaced[idx] ? ` (${innings.ballsFaced[idx]})` : ""}
                </span>
              </li>
            ))}
          </ul>
          <button
            type="button"
            onClick={() => {
              live.current.screen = "menu";
              live.current.delivery = null;
              live.current.result = null;
              setScreen("menu");
            }}
            className="min-h-12 rounded-xl bg-gold px-8 py-3 font-extrabold text-gold-ink"
          >
            بیا لوبه
          </button>
        </section>
      )}
    </main>
  );
}
