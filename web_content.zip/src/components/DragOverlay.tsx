import React from 'react';
import { BlockVisualEffect, DragState } from '../types/game';
import { ShapeMatrix } from './BlockPiece';

interface DragOverlayProps {
  dragState: DragState | null;
  boardCellSize: number;
  visualStyle?: BlockVisualEffect;
}

export const DragOverlay: React.FC<DragOverlayProps> = ({
  dragState,
  boardCellSize,
  visualStyle = 'crystalline',
}) => {
  if (!dragState) return null;

  const { piece, currentX, currentY } = dragState;

  // Center of the piece in px
  const widthPx = piece.width * boardCellSize;
  const heightPx = piece.height * boardCellSize;

  return (
    <div
      className="fixed pointer-events-none z-50 select-none will-change-transform"
      style={{
        left: `${currentX}px`,
        top: `${currentY}px`,
        transform: `translate(-${widthPx / 2}px, -${heightPx / 2}px)`,
      }}
    >
      <div className="filter drop-shadow-[0_12px_24px_rgba(0,0,0,0.8)] scale-105">
        <ShapeMatrix
          matrix={piece.matrix}
          color={piece.color}
          cellSize={boardCellSize}
          visualStyle={visualStyle}
        />
      </div>
    </div>
  );
};
