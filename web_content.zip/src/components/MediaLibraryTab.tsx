import React, { useState, useEffect, useRef } from 'react';
import { Video, Music, Upload, Play, Trash2, Eye, Sparkles, FolderOpen, Check } from 'lucide-react';
import { PRESET_MEDIA_ITEMS, getAllUserMediaFiles, saveUserMediaFile, deleteUserMediaFile } from '../utils/mediaStore';
import { StoredMediaFile, PresetMediaItem } from '../types/alarm';

export const MediaLibraryTab: React.FC = () => {
  const [userFiles, setUserFiles] = useState<StoredMediaFile[]>([]);
  const [filterType, setFilterType] = useState<'all' | 'video' | 'audio'>('all');
  const [isUploading, setIsUploading] = useState(false);
  const [previewingMedia, setPreviewingMedia] = useState<{ url: string; isVideo: boolean; name: string } | null>(null);

  const videoInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);

  const loadFiles = async () => {
    const files = await getAllUserMediaFiles();
    setUserFiles(files);
  };

  useEffect(() => {
    loadFiles();
  }, []);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: 'video' | 'audio') => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    try {
      await saveUserMediaFile(files[0], type);
      await loadFiles();
    } catch (err) {
      console.error('Failed uploading file:', err);
    } finally {
      setIsUploading(false);
    }
  };

  const handleDeleteUserFile = async (id: string) => {
    await deleteUserMediaFile(id);
    await loadFiles();
  };

  const handlePreviewPreset = (item: PresetMediaItem) => {
    setPreviewingMedia({
      url: item.url,
      isVideo: item.type === 'video',
      name: item.name,
    });
  };

  const handlePreviewUserFile = (file: StoredMediaFile) => {
    const blobUrl = URL.createObjectURL(file.blob);
    setPreviewingMedia({
      url: blobUrl,
      isVideo: file.type === 'video',
      name: file.name,
    });
  };

  const filteredPresets = PRESET_MEDIA_ITEMS.filter((item) => {
    if (filterType === 'all') return true;
    return item.type === filterType;
  });

  const filteredUserFiles = userFiles.filter((file) => {
    if (filterType === 'all') return true;
    return file.type === filterType;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Tab Title & Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white font-sans">
            Media Storage & Library
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">
            Select videos or music from phone storage or WakeUp presets.
          </p>
        </div>

        {/* Filter Segmented Buttons */}
        <div className="flex items-center gap-1 p-1 bg-slate-200/80 dark:bg-slate-800 rounded-2xl shrink-0">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors cursor-pointer ${
              filterType === 'all'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            All ({PRESET_MEDIA_ITEMS.length + userFiles.length})
          </button>
          <button
            onClick={() => setFilterType('video')}
            className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors cursor-pointer ${
              filterType === 'video'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Videos
          </button>
          <button
            onClick={() => setFilterType('audio')}
            className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors cursor-pointer ${
              filterType === 'audio'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Music
          </button>
        </div>
      </div>

      {/* Local Phone Storage Upload Card */}
      <div className="p-5 rounded-3xl bg-slate-900 dark:bg-slate-950 text-white shadow-lg space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FolderOpen className="w-5 h-5 text-blue-400" />
            <h3 className="text-sm font-bold uppercase tracking-wider text-white">
              Storage Access Framework
            </h3>
          </div>
          <span className="text-[11px] font-semibold text-slate-400 bg-slate-800 px-2.5 py-0.5 rounded-full">
            IndexedDB Persistent
          </span>
        </div>

        <p className="text-xs text-slate-300">
          Upload MP4 videos or MP3/WAV/AAC songs directly from your device. Files persist locally in app storage.
        </p>

        <input
          ref={videoInputRef}
          type="file"
          accept="video/*"
          className="hidden"
          onChange={(e) => handleFileUpload(e, 'video')}
        />
        <input
          ref={audioInputRef}
          type="file"
          accept="audio/*"
          className="hidden"
          onChange={(e) => handleFileUpload(e, 'audio')}
        />

        <div className="grid grid-cols-2 gap-3 pt-1">
          <button
            onClick={() => videoInputRef.current?.click()}
            disabled={isUploading}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition-colors cursor-pointer"
          >
            <Video className="w-4 h-4 text-purple-400" />
            <span>Upload Local Video</span>
          </button>

          <button
            onClick={() => audioInputRef.current?.click()}
            disabled={isUploading}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition-colors cursor-pointer"
          >
            <Music className="w-4 h-4 text-emerald-400" />
            <span>Upload Local Music</span>
          </button>
        </div>
      </div>

      {/* User Custom Uploads Section */}
      {filteredUserFiles.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Your Local Device Media ({filteredUserFiles.length})
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {filteredUserFiles.map((file) => (
              <div
                key={file.id}
                className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0">
                    {file.type === 'video' ? (
                      <Video className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                    ) : (
                      <Music className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {file.name}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      {(file.size / (1024 * 1024)).toFixed(2)} MB · {file.type.toUpperCase()}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => handlePreviewUserFile(file)}
                    className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
                    title="Preview Media"
                  >
                    <Play className="w-4 h-4 text-blue-600 fill-blue-600/20" />
                  </button>
                  <button
                    onClick={() => handleDeleteUserFile(file.id)}
                    className="p-2 text-slate-400 hover:text-red-600 rounded-xl"
                    title="Delete File"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Preset Library Grid */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">
          Built-in WakeUp High-Definition Media ({filteredPresets.length})
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredPresets.map((item) => (
            <div
              key={item.id}
              className="group rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs hover:border-slate-300 dark:hover:border-slate-700 transition-all flex flex-col justify-between"
            >
              {/* Thumbnail Header */}
              <div className="relative h-36 bg-slate-950 overflow-hidden">
                <img
                  src={item.thumbnail}
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-90"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />

                <div className="absolute top-2.5 left-2.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-black/60 backdrop-blur-md text-white border border-white/20 flex items-center gap-1">
                  {item.type === 'video' ? <Video className="w-3 h-3 text-purple-400" /> : <Music className="w-3 h-3 text-emerald-400" />}
                  <span>{item.type}</span>
                </div>

                <div className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded-lg text-[10px] font-mono font-semibold bg-black/70 text-white">
                  {item.durationStr}
                </div>
              </div>

              {/* Card Body */}
              <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                    {item.name}
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                    {item.artistOrDesc}
                  </p>
                </div>

                <button
                  onClick={() => handlePreviewPreset(item)}
                  className="w-full py-2 px-3 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-900 hover:text-white dark:hover:bg-white dark:hover:text-slate-900 text-slate-800 dark:text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Preview Media</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Media Preview Modal Overlay */}
      {previewingMedia && (
        <div className="fixed inset-0 z-60 bg-black/90 flex items-center justify-center p-4">
          <div className="relative w-full max-w-lg bg-slate-900 rounded-3xl overflow-hidden border border-slate-800">
            <div className="flex items-center justify-between p-4 bg-slate-950">
              <span className="text-xs font-bold text-white truncate max-w-[280px]">
                {previewingMedia.name}
              </span>
              <button
                onClick={() => setPreviewingMedia(null)}
                className="p-1 text-slate-400 hover:text-white rounded-full"
              >
                ✕
              </button>
            </div>

            <div className="p-4 flex items-center justify-center bg-black min-h-[260px]">
              {previewingMedia.isVideo ? (
                <video
                  src={previewingMedia.url}
                  controls
                  autoPlay
                  className="max-h-[350px] w-full object-contain rounded-xl"
                />
              ) : (
                <div className="w-full flex flex-col items-center justify-center gap-4 py-8">
                  <Music className="w-16 h-16 text-emerald-400 animate-pulse" />
                  <audio src={previewingMedia.url} controls autoPlay className="w-full max-w-md" />
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
