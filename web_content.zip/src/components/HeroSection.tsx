import React from 'react';
import { ArrowRight, ShoppingBag } from 'lucide-react';
import { HERO_CAMPAIGN_IMAGE } from '../lib/catalogDefaults';

interface HeroSectionProps {
  onShopNow: () => void;
  onExploreNewArrivals: () => void;
}

export function HeroSection({ onShopNow, onExploreNewArrivals }: HeroSectionProps) {
  return (
    <section className="relative w-full overflow-hidden bg-neutral-100">
      <div className="relative min-h-[520px] lg:min-h-[640px] w-full flex items-end">
        <img
          src={HERO_CAMPAIGN_IMAGE}
          alt="Fashion Hub contemporary tailored fashion campaign"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover object-center"
        />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/30 to-black/10"
        />

        <div className="relative z-10 w-full px-6 sm:px-10 lg:px-14 pb-12 sm:pb-16 pt-28">
          <div className="max-w-2xl text-white">
            <p className="text-xs tracking-[0.2em] uppercase text-neutral-200 mb-3">
              Autumn / Winter Editorial Collection
            </p>
            <h1 className="font-display text-4xl sm:text-6xl font-semibold tracking-tight leading-[1.04] mb-4">
              FASHION THAT DEFINES YOU
            </h1>
            <p className="text-base sm:text-lg text-neutral-100/90 max-w-lg mb-8 font-normal">
              Discover Your Perfect Style
            </p>
            <div className="flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={onShopNow}
                className="inline-flex items-center gap-2.5 px-7 py-3.5 rounded-full bg-white text-[#0A0A0A] text-sm font-semibold hover:bg-neutral-100 transition-colors cursor-pointer whitespace-nowrap"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Shop Now</span>
              </button>
              <button
                type="button"
                onClick={onExploreNewArrivals}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/60 text-white text-sm font-medium hover:bg-white/10 transition-colors cursor-pointer whitespace-nowrap"
              >
                <span>New Arrivals</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
