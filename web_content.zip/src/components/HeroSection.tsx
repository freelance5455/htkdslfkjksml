"use client";

import dynamic from "next/dynamic";
import HeroContent from "./HeroContent";

const Hero3D = dynamic(() => import("@/components/Hero3D"), {
  ssr: false,
  loading: () => (
    <div className="flex h-full w-full items-center justify-center">
      <div className="h-[70%] w-[42%] max-w-[260px] animate-pulse rounded-[2.5rem] bg-[radial-gradient(ellipse_at_center,rgba(139,92,246,0.35),transparent_70%)]" />
    </div>
  ),
});

export default function HeroSection() {
  return (
    <section id="home" className="relative overflow-hidden pt-24 lg:min-h-[100svh]">
      <div className="bg-futuristic absolute inset-0" />
      <div className="bg-grid absolute inset-0" />
      <div className="pointer-events-none absolute right-[10%] top-1/4 h-[420px] w-[420px] rounded-full bg-purple-600/25 blur-[130px]" />
      <div className="pointer-events-none absolute left-[5%] bottom-10 h-[320px] w-[320px] rounded-full bg-blue-600/20 blur-[120px]" />

      <div className="relative z-10 mx-auto grid max-w-7xl items-center gap-4 px-4 lg:min-h-[calc(100svh-6rem)] lg:grid-cols-[1.05fr_1fr]">
        <HeroContent />
        <div className="relative h-[72svh] min-h-[520px] w-full lg:h-[86svh]">
          <Hero3D />
          <p className="pointer-events-none absolute bottom-2 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full border border-white/10 bg-black/50 px-4 py-1.5 text-[11px] tracking-wider text-slate-400 backdrop-blur">
            👆 Tap the 3D keys · Drag to rotate
          </p>
        </div>
      </div>
    </section>
  );
}
