import React from 'react';
import { useData } from '../context/DataContext.tsx';
import {
  ArrowRight,
  Users,
  Star,
  ShieldCheck,
  Plus,
  Calendar,
  Package
} from 'lucide-react';

interface HeroSectionProps {
  onNavigateStartProject: () => void;
  onNavigateFounders: () => void;
  onNavigateVouches: () => void;
  onNavigateAddVouch: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onNavigateStartProject,
  onNavigateFounders,
  onNavigateVouches,
  onNavigateAddVouch
}) => {
  const { data, latestApprovedVouch, vouchStats } = useData();

  if (data?.settings?.sectionVisibility?.hero === false) {
    return null;
  }

  const showVouchesSection = data?.settings?.sectionVisibility?.reputation !== false;

  const formatDate = (iso?: string | null) => {
    if (!iso) return '';
    try {
      return new Date(iso).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch {
      return '';
    }
  };

  return (
    <section id="hero-section" className="pt-8 sm:pt-14 pb-10 max-w-[1120px] mx-auto px-4 sm:px-6">
      {/* Introduction Hero Area */}
      <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-xs font-mono font-semibold tracking-wider text-cyan-300 bg-cyan-950/60 border border-cyan-500/30 mb-5">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
          <span>{data?.settings?.heroBadge || 'CUBIX STUDIO • DIGITAL DEVELOPMENT & CREATIVE SOLUTIONS'}</span>
        </div>

        <h1 className="text-4xl sm:text-6xl font-black text-white tracking-tight leading-[1.12] mb-5 font-['Plus_Jakarta_Sans']">
          {data?.settings?.heroHeadline || 'Turning Ideas Into Digital Experiences.'}
        </h1>

        <p className="text-slate-200 text-base sm:text-lg leading-relaxed max-w-2xl mx-auto mb-8 font-normal">
          {data?.settings?.heroSubtitle ||
            data?.settings?.heroDescription ||
            'Cubix Studio builds modern websites, custom digital solutions, and creative experiences that help brands and communities grow.'}
        </p>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-3.5">
          <button
            onClick={onNavigateStartProject}
            className="flex items-center gap-2 px-7 py-3 rounded-full bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-extrabold text-sm sm:text-base transition-all duration-150 cursor-pointer shadow-sm hover:shadow-cyan-400/20"
          >
            <span>{data?.settings?.heroPrimaryBtnText || 'Start a Project'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={onNavigateFounders}
            className="flex items-center gap-2 px-6 py-3 rounded-full bg-[#081528] hover:bg-[#0c223f] text-cyan-200 hover:text-white border border-cyan-500/30 hover:border-cyan-400/60 font-bold text-sm sm:text-base transition-all duration-150 cursor-pointer"
          >
            <Users className="w-4 h-4 text-cyan-400" />
            <span>{data?.settings?.heroSecondaryBtnText || 'Meet the Founders'}</span>
          </button>
        </div>
      </div>

      {/* B. CUBIX VOUCHES Section (Replaces AI Assistant) */}
      {showVouchesSection && (
        <div
          id="cubix-vouches"
          className="relative rounded-2xl border border-slate-800/90 bg-[#050d1a]/95 backdrop-blur-xl shadow-[0_24px_64px_rgba(0,0,0,0.65)] overflow-hidden"
        >
          <div className="h-[1px] w-full bg-gradient-to-r from-transparent via-cyan-400/50 to-transparent" />

          <div className="p-6 sm:p-9 lg:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Content: Heading, Description, Reputation Statistics, and Homepage Actions */}
            <div className="lg:col-span-6 space-y-5">
              <div className="space-y-2.5">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-mono uppercase tracking-wider">
                  <span>CUBIX VOUCHES</span>
                </span>

                <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-['Plus_Jakarta_Sans']">
                  Trust is built, not claimed.
                </h2>

                <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-xl">
                  Real feedback from people who have experienced Cubix Studio.
                </p>
              </div>

              {/* Reputation Statistics: 1. Total Vouches & 2. Client Rating (N/5) */}
              <div className="grid grid-cols-2 gap-3.5 max-w-md">
                <div className="p-4 rounded-xl bg-[#030914]/90 border border-slate-800/90">
                  <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400">
                    Total Vouches
                  </div>
                  <div className="text-2xl sm:text-3xl font-extrabold text-white font-mono mt-1">
                    {vouchStats.totalVouches}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">Approved reviews</div>
                </div>

                <div className="p-4 rounded-xl bg-[#030914]/90 border border-slate-800/90">
                  <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400">
                    Client Rating
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-2xl sm:text-3xl font-extrabold text-white font-mono">
                      {vouchStats.formattedRating}
                    </span>
                    <Star className="w-5 h-5 text-amber-400 fill-amber-400 shrink-0" />
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">Average score</div>
                </div>
              </div>

              {/* Homepage Actions: Add a Vouch & View All Vouches */}
              <div className="pt-1 flex flex-wrap items-center gap-3.5">
                <button
                  type="button"
                  onClick={onNavigateAddVouch}
                  className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-extrabold text-xs sm:text-sm transition-all duration-150 cursor-pointer shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add a Vouch</span>
                </button>

                <button
                  type="button"
                  onClick={onNavigateVouches}
                  className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-900/90 hover:bg-slate-800/90 text-slate-200 hover:text-white border border-slate-700/80 text-xs sm:text-sm font-semibold transition-all cursor-pointer"
                >
                  <span>View All Vouches</span>
                  <ArrowRight className="w-4 h-4 text-cyan-400" />
                </button>
              </div>
            </div>

            {/* Right Card: Latest Approved Vouch (Strictly Newest by Publication/Approval Timestamp) */}
            <div className="lg:col-span-6">
              <div className="rounded-xl border border-slate-800/90 bg-[#030914]/90 p-5 sm:p-6">
                <div className="flex items-center justify-between pb-3.5 mb-4 border-b border-slate-800/80">
                  <span className="text-[11px] font-mono uppercase tracking-wider text-cyan-300 font-semibold">
                    Latest Vouch
                  </span>
                  {latestApprovedVouch && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-mono text-slate-400">
                      <Calendar className="w-3 h-3 text-slate-500" />
                      <span>
                        {formatDate(latestApprovedVouch.approvedAt || latestApprovedVouch.createdAt)}
                      </span>
                    </span>
                  )}
                </div>

                {latestApprovedVouch ? (
                  <div className="space-y-3.5">
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2.5">
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-base font-bold text-white">
                            {latestApprovedVouch.name}
                          </span>
                          <span className="text-xs font-mono text-cyan-300 bg-slate-950 border border-slate-800 px-2 py-0.5 rounded">
                            Discord: {latestApprovedVouch.discordUsername}
                          </span>
                          {latestApprovedVouch.isVerified && (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-[11px] font-medium">
                              <ShieldCheck className="w-3 h-3 text-emerald-400" />
                              <span>Verified Client</span>
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-1.5">
                          <Package className="w-3.5 h-3.5 text-cyan-400" />
                          <span>{latestApprovedVouch.productOrService}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`w-4 h-4 ${
                              star <= latestApprovedVouch.rating
                                ? 'text-amber-400 fill-amber-400'
                                : 'text-slate-700'
                            }`}
                          />
                        ))}
                        <span className="text-xs font-mono font-bold text-amber-300 ml-1">
                          {latestApprovedVouch.rating}/5
                        </span>
                      </div>
                    </div>

                    <p className="text-slate-200 text-sm leading-relaxed line-clamp-4 whitespace-pre-line">
                      {latestApprovedVouch.feedback}
                    </p>
                  </div>
                ) : (
                  <div className="py-6 text-center space-y-2.5">
                    <p className="text-sm font-semibold text-slate-200">
                      No approved vouches published yet.
                    </p>
                    <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
                      Have you worked with Cubix Studio? Share your feedback to be featured here once approved.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
