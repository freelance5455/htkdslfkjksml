import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import { 
  Send, 
  Search, 
  ArrowLeft, 
  ArrowRight, 
  ShieldCheck, 
  HeartHandshake, 
  Award, 
  Sparkles, 
  Clock, 
  Plane,
  Crown
} from 'lucide-react';

export const HeroSection: React.FC = () => {
  const { 
    language, 
    setCurrentView, 
    openRequestModalForService, 
    lookupTracking, 
    showToast 
  } = useApp();

  const [heroTrackCode, setHeroTrackCode] = useState('');
  const t = translations[language];
  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ArrowLeft : ArrowRight;

  const handleTrackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!heroTrackCode.trim()) return;
    const ok = lookupTracking(heroTrackCode.trim());
    if (ok) {
      setCurrentView('tracking');
    } else {
      showToast(
        isAr 
          ? `لم نجد طلباً برقم (${heroTrackCode}). جرب الكود التجريبي ALM-REQ-7924`
          : `Request (${heroTrackCode}) not found. Try demo code ALM-REQ-7924`
      );
    }
  };

  return (
    <section className="relative overflow-hidden bg-black text-white py-16 sm:py-24 border-b border-[#D4AF37]/20">
      {/* Subtle geometric pattern overlay */}
      <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#D4AF37_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none"></div>

      {/* Ambient glowing radial spots in pure gold */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[650px] h-[400px] bg-amber-500/15 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-10 right-10 w-[350px] h-[300px] bg-[#D4AF37]/10 rounded-full blur-2xl pointer-events-none"></div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Main Content Column */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-start">
            
            {/* Slogan Pill in Gold & Black */}
            <div className="inline-flex items-center gap-2 bg-black/80 border border-[#D4AF37]/50 px-4 py-1.5 rounded-full text-xs sm:text-sm text-amber-300 shadow-[0_0_15px_rgba(212,175,55,0.2)] backdrop-blur-md">
              <Crown className="w-4 h-4 text-[#D4AF37] animate-pulse" />
              <span className="font-bold tracking-wide">
                {t.slogan}
              </span>
            </div>

            {/* Main Headline with Gold Gradient */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-5xl font-black tracking-tight leading-tight sm:leading-snug bg-gradient-to-r from-white via-zinc-100 to-amber-200 bg-clip-text text-transparent">
              {t.heroTitle}
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-zinc-300 leading-relaxed max-w-2xl mx-auto lg:mx-0 font-normal">
              {t.heroSubtitle}
            </p>

            {/* CTAs Group */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 sm:gap-4 pt-2">
              <button
                onClick={() => openRequestModalForService('medical_sector')}
                className="bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black font-extrabold px-6 py-3.5 rounded-2xl shadow-xl shadow-amber-500/25 hover:scale-[1.02] active:scale-[0.98] transition-all duration-200 flex items-center gap-2.5 text-sm sm:text-base border border-amber-300"
              >
                <Send className="w-5 h-5 text-black" />
                <span>{t.heroCtaRequest}</span>
                <ArrowIcon className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  const target = document.getElementById('services-grid');
                  if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                  } else {
                    setCurrentView('medical');
                  }
                }}
                className="bg-zinc-900/90 hover:bg-zinc-800 text-amber-200 font-semibold px-5 py-3.5 rounded-2xl border border-[#D4AF37]/40 hover:border-amber-400 transition-all text-sm sm:text-base flex items-center gap-2"
              >
                <span>{t.heroCtaExplore}</span>
              </button>

              <button
                onClick={() => {
                  setCurrentView('admin');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="bg-black/90 hover:bg-zinc-900 text-amber-400 font-semibold px-4 py-3.5 rounded-2xl border border-[#D4AF37]/50 hover:border-amber-300 transition-all text-xs sm:text-sm flex items-center gap-2 shadow-xs"
              >
                <span>{isAr ? 'لوحة الإدارة التجريبية' : 'Admin Panel'}</span>
              </button>
            </div>

            {/* Quick Tracking Bar in Black & Gold */}
            <div className="pt-4 max-w-xl mx-auto lg:mx-0">
              <div className="bg-zinc-950/90 p-2.5 rounded-2xl border border-[#D4AF37]/30 backdrop-blur-md shadow-2xl">
                <form onSubmit={handleTrackSubmit} className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <Search className="absolute right-3 rtl:right-3 rtl:left-auto ltr:left-3 ltr:right-auto top-1/2 -translate-y-1/2 w-4 h-4 text-amber-400" />
                    <input
                      type="text"
                      value={heroTrackCode}
                      onChange={(e) => setHeroTrackCode(e.target.value)}
                      placeholder={t.heroTrackInputPlaceholder}
                      className="w-full bg-black text-white placeholder-zinc-500 text-xs sm:text-sm py-2.5 px-9 rounded-xl border border-zinc-800 focus:outline-hidden focus:border-[#D4AF37] font-mono"
                    />
                  </div>
                  <button
                    type="submit"
                    className="bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black text-xs sm:text-sm font-extrabold px-4.5 py-2.5 rounded-xl transition-all whitespace-nowrap"
                  >
                    {t.heroTrackBtn}
                  </button>
                </form>
                <div className="flex items-center justify-between px-2 pt-2 text-[11px] text-zinc-400">
                  <span>{isAr ? 'جرّب التتبع الفوري بالرمز:' : 'Try instant demo track code:'}</span>
                  <button
                    type="button"
                    onClick={() => {
                      setHeroTrackCode('ALM-REQ-7924');
                      lookupTracking('ALM-REQ-7924');
                      setCurrentView('tracking');
                    }}
                    className="text-amber-400 font-mono hover:underline font-bold"
                  >
                    ALM-REQ-7924
                  </button>
                </div>
              </div>
            </div>

            {/* Key Trust Signals */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-zinc-800">
              <div className="flex items-center gap-2 text-zinc-300 text-xs">
                <ShieldCheck className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>{isAr ? 'مستشفيات معتمدة' : 'Accredited Hubs'}</span>
              </div>
              <div className="flex items-center gap-2 text-zinc-300 text-xs">
                <Plane className="w-4 h-4 text-amber-400 shrink-0" />
                <span>{isAr ? 'استقبال وتأشيرة سياحة' : 'VIP Airport Care'}</span>
              </div>
              <div className="flex items-center gap-2 text-zinc-300 text-xs">
                <Clock className="w-4 h-4 text-yellow-400 shrink-0" />
                <span>{isAr ? 'منسق طبي 24/7' : '24/7 Concierge'}</span>
              </div>
              <div className="flex items-center gap-2 text-zinc-300 text-xs">
                <HeartHandshake className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>{isAr ? 'سرية وخصوصية تامة' : 'Strict Privacy'}</span>
              </div>
            </div>

          </div>

          {/* Right Visual Showcase Card */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Premium Black & Gold Card Container */}
              <div className="relative bg-gradient-to-br from-zinc-950/95 via-black to-zinc-950/95 rounded-3xl p-6 sm:p-7 border border-[#D4AF37]/40 shadow-2xl backdrop-blur-xl space-y-6">
                
                {/* Header of Preview Box with Official Transparent Logo */}
                <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
                  <div className="flex items-center gap-3">
                    <img 
                      src="/assets/aistudio/logo_transparent.png" 
                      alt="Al Mowasat Logo" 
                      className="w-16 h-14 object-contain drop-shadow-[0_4px_12px_rgba(212,175,55,0.4)]"
                    />
                    <div>
                      <div className="text-xs text-amber-400 font-semibold uppercase tracking-wider">
                        {isAr ? 'الاعتماد والتميز الطبي' : 'Accreditation & Standards'}
                      </div>
                      <div className="text-sm font-bold text-white">
                        {isAr ? 'معايير مصرية ودولية موثقة' : 'GAHAR & JCI Standards'}
                      </div>
                    </div>
                  </div>
                  <span className="text-[10px] bg-[#D4AF37]/20 text-amber-300 border border-[#D4AF37]/40 px-2.5 py-1 rounded-full font-mono font-bold">
                    VERIFIED
                  </span>
                </div>

                {/* Simulated Concierge Status */}
                <div className="bg-black/90 rounded-2xl p-4 border border-zinc-800 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-zinc-400">{isAr ? 'حالة التنسيق الطبي النشط:' : 'Active Medical Coordination:'}</span>
                    <span className="text-amber-400 font-bold flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
                      {isAr ? 'متاح على مدار الساعة' : 'Live Concierge'}
                    </span>
                  </div>

                  {/* Sample Active Patient Route Card */}
                  <div className="p-3 bg-zinc-900/90 rounded-xl border border-zinc-800 flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-[#D4AF37]/20 border border-[#D4AF37]/40 flex items-center justify-center text-amber-300 font-bold text-xs">
                      خ.ع
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-bold text-white truncate">
                        {isAr ? 'خالد الكواري (الدوحة - قطر)' : 'Khalid Al-Kuwari (Qatar)'}
                      </div>
                      <div className="text-[11px] text-amber-300 truncate">
                        {isAr ? 'مجمع النيل الطبي • قسطرة قلبية' : 'Nile Medical • Cardiac Stent'}
                      </div>
                    </div>
                    <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-1 rounded-md font-mono border border-amber-500/30">
                      {isAr ? 'مؤكد' : 'Confirmed'}
                    </span>
                  </div>

                  {/* Progress Milestone Bar */}
                  <div className="space-y-1.5 pt-1">
                    <div className="flex justify-between text-[11px] text-zinc-400">
                      <span>{isAr ? 'اكتمال جاهزية الرحلة:' : 'Journey Readiness:'}</span>
                      <span className="text-amber-400 font-semibold">85%</span>
                    </div>
                    <div className="w-full h-2 bg-zinc-800 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-amber-500 via-yellow-400 to-[#D4AF37] w-[85%] rounded-full shadow-[0_0_10px_rgba(212,175,55,0.5)]"></div>
                    </div>
                    <div className="flex justify-between text-[10px] text-zinc-500">
                      <span>{isAr ? 'المطار والتأشيرة' : 'Visa & Airport'}</span>
                      <span>{isAr ? 'حجز المستشفى' : 'Hospital Bed'}</span>
                      <span>{isAr ? 'الاستقبال' : 'Arrival'}</span>
                    </div>
                  </div>
                </div>

                {/* 3 Quick Pillar Highlights */}
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="bg-black/80 p-2.5 rounded-xl border border-zinc-800">
                    <div className="text-base sm:text-lg font-black text-amber-400 font-mono">40+</div>
                    <div className="text-[10px] text-zinc-400 leading-tight">
                      {isAr ? 'تخصص دقيق' : 'Sub-Specialties'}
                    </div>
                  </div>
                  <div className="bg-black/80 p-2.5 rounded-xl border border-zinc-800">
                    <div className="text-base sm:text-lg font-black text-amber-300 font-mono">100%</div>
                    <div className="text-[10px] text-zinc-400 leading-tight">
                      {isAr ? 'مرافقة لغوية' : 'Language Escort'}
                    </div>
                  </div>
                  <div className="bg-black/80 p-2.5 rounded-xl border border-zinc-800">
                    <div className="text-base sm:text-lg font-black text-amber-200 font-mono">0$</div>
                    <div className="text-[10px] text-zinc-400 leading-tight">
                      {isAr ? 'تقييم مبدئي' : 'Assessment'}
                    </div>
                  </div>
                </div>

                {/* Interactive Action inside Card */}
                <button
                  onClick={() => openRequestModalForService('foreign_reception')}
                  className="w-full py-3 bg-gradient-to-r from-amber-400 via-yellow-500 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-black rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20"
                >
                  <Plane className="w-3.5 h-3.5 text-black" />
                  <span>{isAr ? 'تنسيق باقة استقبال علاجية متكاملة' : 'Arrange Full Reception & Care Package'}</span>
                </button>

              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
