import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Delete, Lock, RotateCcw } from 'lucide-react';

interface SplashLockScreenProps {
  expectedPin: string;
  adminName: string;
  companyName: string;
  onUnlock: () => void;
}

export const SplashLockScreen: React.FC<SplashLockScreenProps> = ({
  expectedPin,
  adminName,
  companyName,
  onUnlock,
}) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);

  const handleDigit = (digit: string) => {
    if (pin.length >= 4) return;
    const next = pin + digit;
    setPin(next);
    setError(false);

    if (next.length === 4) {
      if (next === expectedPin) {
        setTimeout(() => onUnlock(), 150);
      } else {
        setError(true);
        setTimeout(() => {
          setPin('');
          setError(false);
        }, 450);
      }
    }
  };

  const handleBackspace = () => {
    setError(false);
    setPin((prev) => prev.slice(0, -1));
  };

  const handleClear = () => {
    setError(false);
    setPin('');
  };

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (/^[0-9]$/.test(e.key)) {
        handleDigit(e.key);
      } else if (e.key === 'Backspace') {
        handleBackspace();
      } else if (e.key === 'Escape') {
        handleClear();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  });

  const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];

  return (
    <div className="min-h-[100dvh] w-full flex items-center justify-center px-4 py-6 bg-[#F4F5F8]">
      <motion.div
        initial={{ opacity: 0, y: 6 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2, ease: 'easeOut' }}
        className="w-full max-w-[400px] surface-card p-7 sm:p-8 text-center"
      >
        <div className="mx-auto w-16 h-16 rounded-[12px] bg-[#0F172A] flex items-center justify-center mb-4">
          <span className="font-display text-xl font-bold tracking-tight text-white">
            {companyName.slice(0, 2).toUpperCase()}
          </span>
        </div>

        <h1 className="font-display text-2xl sm:text-[26px] font-bold tracking-tight text-[#0F172A]">
          {companyName}
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Manage Clients, Payments &amp; Work Like a Pro
        </p>

        <div className="mt-6 pt-6 border-t border-slate-200">
          <div className="inline-flex items-center gap-2 text-sm font-semibold text-[#0F172A]">
            <Lock className="w-4 h-4 text-[#0F172A]" strokeWidth={1.75} />
            <span>Welcome Back, {adminName}</span>
          </div>

          <motion.div
            animate={error ? { x: [-6, 6, -4, 4, 0] } : { x: 0 }}
            transition={{ duration: 0.22, ease: 'easeOut' }}
            className="flex items-center justify-center gap-4 my-6"
          >
            {[0, 1, 2, 3].map((idx) => {
              const filled = idx < pin.length;
              return (
                <div
                  key={idx}
                  className={`w-3.5 h-3.5 rounded-full transition-colors duration-150 ease-out ${
                    error ? 'bg-red-600' : filled ? 'bg-[#0F172A]' : 'bg-slate-200'
                  }`}
                />
              );
            })}
          </motion.div>

          <p className={`text-xs sm:text-sm mb-5 ${error ? 'text-red-600 font-medium' : 'text-slate-500'}`}>
            {error ? 'Incorrect PIN. Please try again.' : 'Enter 4-digit Admin PIN'}
          </p>

          <div className="grid grid-cols-3 gap-3 max-w-[288px] mx-auto">
            {keys.map((digit) => (
              <button
                key={digit}
                type="button"
                onClick={() => handleDigit(digit)}
                className="h-14 sm:h-[60px] rounded-[10px] border border-slate-200 bg-white hover:bg-slate-50 active:scale-[0.97] text-xl font-display font-semibold text-[#0F172A] transition-all duration-150 ease-out flex items-center justify-center cursor-pointer select-none"
              >
                {digit}
              </button>
            ))}

            {pin.length > 0 ? (
              <button
                type="button"
                onClick={handleClear}
                aria-label="Clear PIN"
                className="h-14 sm:h-[60px] rounded-[10px] border border-slate-200 bg-white hover:bg-slate-50 active:scale-[0.97] text-slate-500 hover:text-[#0F172A] transition-all duration-150 ease-out flex items-center justify-center cursor-pointer select-none"
              >
                <RotateCcw className="w-5 h-5" strokeWidth={1.75} />
              </button>
            ) : (
              <div aria-hidden="true" className="h-14 sm:h-[60px]" />
            )}

            <button
              type="button"
              onClick={() => handleDigit('0')}
              className="h-14 sm:h-[60px] rounded-[10px] border border-slate-200 bg-white hover:bg-slate-50 active:scale-[0.97] text-xl font-display font-semibold text-[#0F172A] transition-all duration-150 ease-out flex items-center justify-center cursor-pointer select-none"
            >
              0
            </button>

            <button
              type="button"
              onClick={handleBackspace}
              aria-label="Delete digit"
              className="h-14 sm:h-[60px] rounded-[10px] border border-slate-200 bg-white hover:bg-slate-50 active:scale-[0.97] text-slate-600 hover:text-[#0F172A] transition-all duration-150 ease-out flex items-center justify-center cursor-pointer select-none"
            >
              <Delete className="w-5 h-5" strokeWidth={1.75} />
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
