/**
 * GODEX P3.2 — Creative Generation Studio
 * 
 * Professional AI Creative Workstation & Media Generation Studio.
 * Fully responsive across Mobile (390x844), Tablet (768x1024), and Desktop (1280x800).
 * 
 * Workflows:
 * - Text → Image
 * - Text → Video
 * - Image → Video
 * - Video → Video
 * - Media Enhancement & Local Tonal Grading
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Sparkles,
  Video,
  Image as ImageIcon,
  Sliders,
  Play,
  Pause,
  RotateCcw,
  Maximize2,
  Minimize2,
  ZoomIn,
  ZoomOut,
  Upload,
  Layers,
  Clock,
  Settings,
  AlertCircle,
  CheckCircle2,
  Film,
  Camera,
  Compass,
  Cpu,
  ShieldCheck,
  Palette,
  Eye,
  Plus,
  Trash2,
  RefreshCw,
  Download,
  Info,
  SplitSquareVertical,
  Activity,
  BarChart3,
  ListOrdered,
  X,
  Volume2,
  VolumeX,
  Zap,
  Wand2,
  FileVideo,
  FolderOpen,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import {
  MediaWorkflowType,
  CreativeStudioTab,
  MediaJobStatus,
  EngineAvailabilityState,
  VideoStylePreset,
  CameraMovementType,
  AspectRatioType,
  ResolutionPreset,
  MediaJobParameters,
  MediaEnhancementParameters,
  MediaAssetInput,
  MediaAssetOutput,
  MediaJob,
  CreativeBenchmarkMetrics
} from '../builder/creative/creativeStudioTypes';
import {
  CreativeEngineRegistry,
  CreativeEngineAdapter
} from '../builder/creative/creativeEngineRegistry';
import {
  MediaJobQueueManager
} from '../builder/creative/mediaJobQueueManager';
import {
  MediaEnhancementPipeline
} from '../builder/creative/mediaEnhancementPipeline';
import {
  CreativeBenchmarkEngine
} from '../builder/creative/creativeBenchmarkEngine';
import {
  NeuralExecutionController
} from '../builder/creative/neuralExecutionController';
import {
  GenerationPreflightEngine,
  PreflightReport
} from '../builder/creative/generationPreflightEngine';
import {
  GenerationProgressEngine,
  ProgressEventPayload
} from '../builder/creative/generationProgressEngine';
import {
  GenerationHistoryEngine,
  GenerationHistoryRecord
} from '../builder/creative/generationHistoryEngine';
import {
  ModelSelectionEngine,
  ModelRecommendation
} from '../builder/creative/modelSelectionEngine';
import {
  WorkflowCompatibilityEngine
} from '../builder/creative/workflowCompatibilityEngine';
import {
  ComfyUiEngineAdapter,
  ComfyUiDiscoveredModels
} from '../builder/creative/comfyUiEngineAdapter';
import { HardwareAuditor, HardwareAuditReport } from '../builder/creative/hardwareAuditor';
import { ModelManager } from '../builder/creative/modelManager';
import { GodexLogo } from './GodexLogo';
import { CreativeEngineDiagnosticsModal } from './CreativeEngineDiagnosticsModal';
import { GodexVfxStudioWorkspace } from './GodexVfxStudioWorkspace';
import { GodexAudioStudioWorkspace } from './GodexAudioStudioWorkspace';
import { GodexMediaAssemblyWorkspace } from './GodexMediaAssemblyWorkspace';
import { GodexCameraStudioWorkspace } from './GodexCameraStudioWorkspace';
import { GodexColorStudioWorkspace } from './GodexColorStudioWorkspace';
import { GodexProductionWorkspace } from './GodexProductionWorkspace';

interface GodexCreativeStudioViewProps {
  onNavigateToEngineering?: () => void;
}

export const GodexCreativeStudioView: React.FC<GodexCreativeStudioViewProps> = ({
  onNavigateToEngineering
}) => {
  // --- Workspace Tabs ---
  const [activeTab, setActiveTab] = useState<CreativeStudioTab>('generate');
  const [activeWorkflow, setActiveWorkflow] = useState<MediaWorkflowType>('TEXT_TO_IMAGE');
  const [isDiagnosticsOpen, setIsDiagnosticsOpen] = useState<boolean>(false);

  // --- Generation Parameters ---
  const [prompt, setPrompt] = useState<string>('Cinematic drone shot of futuristic solar metropolis at sunset, ultra photorealistic 8k volumetric fog');
  const [negativePrompt, setNegativePrompt] = useState<string>('low quality, blurry, distorted, artifacting, jitter, flicker');
  const [aspectRatio, setAspectRatio] = useState<AspectRatioType>('16:9');
  const [resolution, setResolution] = useState<ResolutionPreset>('1080p');
  const [durationSec, setDurationSec] = useState<number>(5);
  const [fps, setFps] = useState<24 | 30 | 60>(30);
  const [seed, setSeed] = useState<number>(42);
  const [randomSeed, setRandomSeed] = useState<boolean>(true);
  const [strength, setStrength] = useState<number>(0.75);
  const [style, setStyle] = useState<VideoStylePreset>('CINEMATIC');
  const [cameraMovement, setCameraMovement] = useState<CameraMovementType>('DOLLY_IN');
  const [subjectMotion, setSubjectMotion] = useState<number>(6);
  const [cfgScale, setCfgScale] = useState<number>(7.5);
  const [guidanceSteps, setGuidanceSteps] = useState<number>(30);
  const [preserveIdentity, setPreserveIdentity] = useState<boolean>(true);
  const [preserveAudio, setPreserveAudio] = useState<boolean>(true);

  // --- Mobile Collapsible Sections State ---
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(true);
  const [isEnhanceOpen, setIsEnhanceOpen] = useState<boolean>(true);
  const [isEngineSectionOpen, setIsEngineSectionOpen] = useState<boolean>(true);
  const [isAdvancedOpen, setIsAdvancedOpen] = useState<boolean>(false);

  // --- Media Assets (Uploaded Input) ---
  const [inputAssets, setInputAssets] = useState<MediaAssetInput[]>([]);
  const [selectedAssetIndex, setSelectedAssetIndex] = useState<number>(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- Enhancement Parameters ---
  const [enhanceParams, setEnhanceParams] = useState<MediaEnhancementParameters>(() =>
    MediaEnhancementPipeline.getDefaultEnhancementParams()
  );
  const [splitSliderPos, setSplitSliderPos] = useState<number>(50); // Before/After split %

  // --- Canvas & Media Player State ---
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTimeSec, setCurrentTimeSec] = useState<number>(0);
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [isMuted, setIsMuted] = useState<boolean>(true);
  const animationFrameRef = useRef<number | null>(null);

  // --- Engine & Queue State ---
  const [engines, setEngines] = useState<CreativeEngineAdapter[]>(() => 
    CreativeEngineRegistry.getInstance().getAllEngines()
  );
  const [selectedEngineId, setSelectedEngineId] = useState<string>('engine-browser-native');
  const [jobs, setJobs] = useState<MediaJob[]>([]);
  const [activeJob, setActiveJob] = useState<MediaJob | null>(null);
  const [benchmarkMetrics, setBenchmarkMetrics] = useState<CreativeBenchmarkMetrics | null>(null);
  const [isLogsOpen, setIsLogsOpen] = useState<boolean>(false);
  const [activeQueueFilter, setActiveQueueFilter] = useState<'ALL' | 'COMPLETED' | 'FAILED' | 'HISTORY'>('ALL');

  // --- P4.0 Neural Production State ---
  const [discoveredModels, setDiscoveredModels] = useState<ComfyUiDiscoveredModels>({
    checkpoints: [],
    vaes: [],
    loras: [],
    controlnets: [],
    upscalers: [],
    videoModels: [],
    installedNodes: []
  });
  const [hardwareReport, setHardwareReport] = useState<HardwareAuditReport | null>(null);
  const [modelRecommendation, setModelRecommendation] = useState<ModelRecommendation | null>(null);
  const [selectedModelId, setSelectedModelId] = useState<string>('auto-recommend');
  const [preflightReport, setPreflightReport] = useState<PreflightReport | null>(null);
  const [progressEvents, setProgressEvents] = useState<ProgressEventPayload[]>([]);
  const [historyRecords, setHistoryRecords] = useState<GenerationHistoryRecord[]>([]);
  const [isPreflightOpen, setIsPreflightOpen] = useState<boolean>(false);

  // Initialize Engines & Queue Subscription
  useEffect(() => {
    const registry = CreativeEngineRegistry.getInstance();
    setEngines(registry.getAllEngines());

    // Hardware & ComfyUI Probing
    HardwareAuditor.getInstance().auditHardware().then(hw => setHardwareReport(hw));
    const comfy = new ComfyUiEngineAdapter();
    comfy.discover().then(res => {
      if (res.discoveredModels) setDiscoveredModels(res.discoveredModels);
    });

    const queue = MediaJobQueueManager.getInstance();
    const unsubscribeQueue = queue.subscribe((updatedJobs, currentActive) => {
      setJobs(updatedJobs);
      setActiveJob(currentActive);
      const agg = CreativeBenchmarkEngine.getAggregateMetrics();
      if (agg) setBenchmarkMetrics(agg);
    });

    const unsubscribeHistory = GenerationHistoryEngine.getInstance().subscribe(records => {
      setHistoryRecords(records);
    });

    const unsubscribeProgress = GenerationProgressEngine.getInstance().subscribe(evt => {
      setProgressEvents(prev => [...prev.slice(-40), evt]);
    });

    return () => {
      unsubscribeQueue();
      unsubscribeHistory();
      unsubscribeProgress();
    };
  }, []);

  // Compute model recommendation whenever workflow or resolution changes
  useEffect(() => {
    if (hardwareReport) {
      const rec = ModelSelectionEngine.getInstance().selectBestModel(
        activeWorkflow,
        { resolution, fps, aspectRatio, durationSec },
        discoveredModels,
        hardwareReport
      );
      setModelRecommendation(rec);
    }
  }, [activeWorkflow, resolution, fps, aspectRatio, durationSec, discoveredModels, hardwareReport]);

  // Update selected engine when workflow changes
  useEffect(() => {
    const registry = CreativeEngineRegistry.getInstance();
    const pref = registry.getPreferredEngineForWorkflow(activeWorkflow);
    setSelectedEngineId(pref.id);
  }, [activeWorkflow]);

  // Procedural Canvas Animation Loop
  const renderFrame = useCallback((timeSec: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Background Gradient based on style
    const grad = ctx.createLinearGradient(0, 0, width, height);
    if (style === 'CYBERPUNK') {
      grad.addColorStop(0, '#0a001a');
      grad.addColorStop(0.5, '#190033');
      grad.addColorStop(1, '#001a33');
    } else if (style === 'NOIR') {
      grad.addColorStop(0, '#0a0a0a');
      grad.addColorStop(0.5, '#1a1a1a');
      grad.addColorStop(1, '#050505');
    } else if (style === 'ANIME') {
      grad.addColorStop(0, '#0b1d3a');
      grad.addColorStop(0.5, '#1a3b68');
      grad.addColorStop(1, '#2c1e4a');
    } else {
      // Cinematic
      grad.addColorStop(0, '#070b14');
      grad.addColorStop(0.5, '#0e1626');
      grad.addColorStop(1, '#050811');
    }
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);

    // Draw procedural grid / horizon perspective
    ctx.strokeStyle = style === 'CYBERPUNK' ? 'rgba(0, 255, 230, 0.2)' : 'rgba(56, 189, 248, 0.15)';
    ctx.lineWidth = 1;

    const horizonY = height * 0.55;
    const vanishX = width * 0.5 + Math.sin(timeSec * 0.5) * 40;

    // Radial perspective lines
    for (let x = -width; x <= width * 2; x += 60) {
      ctx.beginPath();
      ctx.moveTo(vanishX, horizonY);
      ctx.lineTo(x, height);
      ctx.stroke();
    }

    // Horizontal receding lines
    for (let y = horizonY; y <= height; y += (y - horizonY + 8) * 0.25) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Glowing sun/orb on horizon
    const sunGrad = ctx.createRadialGradient(vanishX, horizonY - 20, 10, vanishX, horizonY - 20, 120);
    sunGrad.addColorStop(0, style === 'CYBERPUNK' ? 'rgba(255, 0, 128, 0.9)' : 'rgba(251, 146, 60, 0.85)');
    sunGrad.addColorStop(0.4, style === 'CYBERPUNK' ? 'rgba(128, 0, 255, 0.4)' : 'rgba(234, 88, 12, 0.3)');
    sunGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = sunGrad;
    ctx.beginPath();
    ctx.arc(vanishX, horizonY - 20, 120, 0, Math.PI * 2);
    ctx.fill();

    // Camera Motion Dynamic Overlay Indicators
    ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.font = '600 13px JetBrains Mono, monospace';
    ctx.fillText(`CAM: ${cameraMovement} | FPS: ${fps} | TIME: ${timeSec.toFixed(2)}s / ${durationSec}s`, 20, height - 25);
    ctx.fillText(`STYLE: ${style} | RATIO: ${aspectRatio} | RES: ${resolution}`, 20, 30);

    // If Enhance mode: apply active tonal grading to canvas
    if (activeTab === 'enhance') {
      try {
        const imgData = ctx.getImageData(0, 0, width, height);
        const processed = MediaEnhancementPipeline.processImageData(imgData, enhanceParams);
        ctx.putImageData(processed, 0, 0);
      } catch (e) {
        // Canvas security fallback
      }
    }
  }, [style, cameraMovement, fps, durationSec, aspectRatio, resolution, activeTab, enhanceParams]);

  // Animation Frame Hook
  useEffect(() => {
    let lastTime = performance.now();
    const loop = (now: number) => {
      const deltaSec = (now - lastTime) / 1000;
      lastTime = now;

      if (isPlaying) {
        setCurrentTimeSec(prev => {
          const next = prev + deltaSec;
          if (next >= durationSec) {
            return 0; // Loop
          }
          return next;
        });
      }

      renderFrame(currentTimeSec);
      animationFrameRef.current = requestAnimationFrame(loop);
    };

    animationFrameRef.current = requestAnimationFrame(loop);
    return () => {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, [isPlaying, currentTimeSec, durationSec, renderFrame]);

  // Handle File Upload (Drag & Drop or File Picker)
  const handleFileUpload = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const file = files[0];
    const isVid = file.type.startsWith('video/');
    const isImg = file.type.startsWith('image/');

    if (!isImg && !isVid) {
      alert('Please upload a valid image (PNG/JPG) or video (MP4/WebM) asset.');
      return;
    }

    const newAsset: MediaAssetInput = {
      id: `asset-${Date.now()}`,
      name: file.name,
      uri: URL.createObjectURL(file),
      type: isVid ? 'VIDEO' : 'IMAGE',
      mimeType: file.type,
      sizeBytes: file.size,
      dimensions: { width: 1920, height: 1080 },
      durationSec: isVid ? 5 : undefined,
      fps: isVid ? 30 : undefined
    };

    setInputAssets(prev => [newAsset, ...prev]);
    setSelectedAssetIndex(0);
  };

  // Handle Dispatch Generation
  const handleDispatchJob = async () => {
    const queue = MediaJobQueueManager.getInstance();
    const effectiveSeed = randomSeed ? Math.floor(Math.random() * 1000000) : seed;

    const params: MediaJobParameters = {
      prompt,
      negativePrompt,
      aspectRatio,
      resolution,
      durationSec: activeWorkflow.includes('VIDEO') ? durationSec : 0,
      fps,
      seed: effectiveSeed,
      strength,
      style,
      cameraMovement,
      subjectMotionIntensity: subjectMotion,
      cfgScale,
      guidanceSteps,
      preservationControls: {
        preserveIdentity,
        preserveAudio,
        preserveLighting: true,
        preserveFramerate: true
      },
      enhancement: activeTab === 'enhance' ? enhanceParams : undefined
    };

    await queue.submitJob(
      activeTab === 'enhance' ? 'MEDIA_ENHANCE' : activeWorkflow,
      params,
      inputAssets,
      selectedEngineId
    );
  };

  // Active Engine & Status
  const selectedEngine = engines.find(e => e.id === selectedEngineId) || engines[0] || CreativeEngineRegistry.getInstance().getAllEngines()[0];
  const isNeuralRequired = selectedEngine?.status === 'REQUIRES_ENGINE';

  // --- SUB-COMPONENTS (Clean, DRY, Fully Responsive) ---

  // 1. Mode Selector Navigation
  const renderModeSelector = () => (
    <nav className="flex items-center gap-1 overflow-x-auto no-scrollbar scrollbar-none py-1.5 px-3 w-full min-w-0 shrink-0">
      <button
        onClick={() => { setActiveTab('production'); }}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
          activeTab === 'production'
            ? 'bg-gradient-to-r from-cyan-500 via-sky-500 to-amber-500 text-white shadow-sm ring-1 ring-cyan-400/40'
            : 'text-cyan-300 bg-cyan-950/40 border border-cyan-800/60 hover:text-cyan-100 hover:bg-cyan-900/60'
        }`}
      >
        <Film className="w-3.5 h-3.5 text-cyan-300" />
        <span className="font-bold">Production P5.0</span>
      </button>

      <button
        onClick={() => { setActiveTab('generate'); setActiveWorkflow('TEXT_TO_IMAGE'); }}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
          activeTab === 'generate' && activeWorkflow === 'TEXT_TO_IMAGE'
            ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-sm'
            : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#0E1729]'
        }`}
      >
        <ImageIcon className="w-3.5 h-3.5" />
        <span>Text → Image</span>
      </button>

      <button
        onClick={() => { setActiveTab('generate'); setActiveWorkflow('IMAGE_TO_VIDEO'); }}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
          activeTab === 'generate' && activeWorkflow === 'IMAGE_TO_VIDEO'
            ? 'bg-gradient-to-r from-teal-600 to-cyan-600 text-white shadow-sm'
            : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#0E1729]'
        }`}
      >
        <Film className="w-3.5 h-3.5" />
        <span>Image → Video</span>
      </button>

      <button
        onClick={() => { setActiveTab('generate'); setActiveWorkflow('TEXT_TO_VIDEO'); }}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
          activeTab === 'generate' && activeWorkflow === 'TEXT_TO_VIDEO'
            ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-sm'
            : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#0E1729]'
        }`}
      >
        <Video className="w-3.5 h-3.5" />
        <span>Text → Video</span>
      </button>

      <button
        onClick={() => { setActiveTab('generate'); setActiveWorkflow('VIDEO_TO_VIDEO'); }}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
          activeTab === 'generate' && activeWorkflow === 'VIDEO_TO_VIDEO'
            ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-sm'
            : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#0E1729]'
        }`}
      >
        <FileVideo className="w-3.5 h-3.5" />
        <span>Video → Video</span>
      </button>

      <button
        onClick={() => { setActiveTab('enhance'); }}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
          activeTab === 'enhance'
            ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white shadow-sm'
            : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#0E1729]'
        }`}
      >
        <Wand2 className="w-3.5 h-3.5" />
        <span>Enhance</span>
      </button>

      <button
        onClick={() => { setActiveTab('camera'); }}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
          activeTab === 'camera'
            ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow-sm'
            : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#0E1729]'
        }`}
      >
        <Camera className="w-3.5 h-3.5 text-cyan-300" />
        <span>Camera & Optics</span>
      </button>

      <button
        onClick={() => { setActiveTab('color'); }}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
          activeTab === 'color'
            ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-sm'
            : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#0E1729]'
        }`}
      >
        <Palette className="w-3.5 h-3.5 text-emerald-300" />
        <span>Color Studio</span>
      </button>

      <button
        onClick={() => { setActiveTab('vfx'); }}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
          activeTab === 'vfx'
            ? 'bg-gradient-to-r from-cyan-600 to-emerald-600 text-white shadow-sm'
            : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#0E1729]'
        }`}
      >
        <Sparkles className="w-3.5 h-3.5 text-cyan-300" />
        <span>VFX Core</span>
      </button>

      <button
        onClick={() => { setActiveTab('audio'); }}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
          activeTab === 'audio' || activeTab === 'sfx'
            ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-sm'
            : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#0E1729]'
        }`}
      >
        <Volume2 className="w-3.5 h-3.5 text-pink-300" />
        <span>Audio & SFX</span>
      </button>

      <button
        onClick={() => { setActiveTab('assembly'); }}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
          activeTab === 'assembly' || activeTab === 'export'
            ? 'bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white shadow-sm'
            : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#0E1729]'
        }`}
      >
        <Film className="w-3.5 h-3.5 text-indigo-300" />
        <span>Assembly & Export</span>
      </button>

      <button
        onClick={() => { setActiveTab('history'); }}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
          activeTab === 'history'
            ? 'bg-neutral-800 text-white shadow-sm'
            : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#0E1729]'
        }`}
      >
        <Clock className="w-3.5 h-3.5" />
        <span>History</span>
      </button>

      <button
        onClick={() => { setActiveTab('benchmark'); }}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
          activeTab === 'benchmark'
            ? 'bg-neutral-800 text-white shadow-sm'
            : 'text-neutral-400 hover:text-neutral-200 hover:bg-[#0E1729]'
        }`}
      >
        <BarChart3 className="w-3.5 h-3.5" />
        <span>Benchmark</span>
      </button>
    </nav>
  );

  // 2. Input Prompt & Negative Prompt
  const renderPromptSection = () => (
    <div className="space-y-3 w-full min-w-0">
      {activeTab !== 'enhance' && (
        <div className="space-y-1.5 w-full min-w-0">
          <label className="block font-semibold text-neutral-300 flex items-center justify-between text-xs">
            <span>Prompt</span>
            <span className="text-[10px] text-neutral-500 font-normal">Natural Language</span>
          </label>
          <textarea
            value={prompt}
            onChange={e => setPrompt(e.target.value)}
            rows={3}
            placeholder="Describe your visual concept in rich detail..."
            className="w-full min-w-0 max-w-full box-border rounded-lg bg-[#0B1120] border border-[#1C2B4B] p-2.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-emerald-500 resize-y font-sans"
          />
        </div>
      )}

      {activeTab !== 'enhance' && (
        <div className="space-y-1.5 w-full min-w-0">
          <label className="block font-semibold text-neutral-400 flex items-center justify-between text-[11px]">
            <span>Negative Prompt</span>
            <span className="text-[10px] text-neutral-500">Excluded artifacts</span>
          </label>
          <input
            type="text"
            value={negativePrompt}
            onChange={e => setNegativePrompt(e.target.value)}
            placeholder="low quality, artifacts, distortion, jitter..."
            className="w-full min-w-0 max-w-full box-border rounded-md bg-[#0B1120] border border-[#1C2B4B] px-2.5 py-1.5 text-xs text-neutral-300 placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
          />
        </div>
      )}
    </div>
  );

  // 3. Source Media Drag & Drop / Upload
  const renderSourceMediaSection = () => {
    if (activeWorkflow !== 'IMAGE_TO_VIDEO' && activeWorkflow !== 'VIDEO_TO_VIDEO' && activeTab !== 'enhance') {
      return null;
    }

    return (
      <div className="space-y-2 pt-1 border-t border-[#141E33] w-full min-w-0">
        <label className="block font-semibold text-neutral-300 flex items-center justify-between text-xs">
          <span>Source Media Input</span>
          <span className="text-[10px] text-cyan-400 font-mono">Required</span>
        </label>

        {/* Drag & Drop Upload Zone */}
        <div
          onDragOver={e => { e.preventDefault(); e.stopPropagation(); }}
          onDrop={e => {
            e.preventDefault();
            e.stopPropagation();
            handleFileUpload(e.dataTransfer.files);
          }}
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-[#1F2E4D] hover:border-emerald-500/60 bg-[#0A0F1D] rounded-xl p-3 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-1.5 group w-full min-w-0 box-border"
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={e => handleFileUpload(e.target.files)}
            accept="image/*,video/*"
            className="hidden"
          />
          <Upload className="w-5 h-5 text-neutral-400 group-hover:text-emerald-400 transition-colors" />
          <div className="text-neutral-300 text-xs font-semibold">
            Click or Drag & Drop Media Asset
          </div>
          <div className="text-[10px] text-neutral-500">
            Supports PNG, JPG, WebP, MP4, WebM (up to 4K)
          </div>
        </div>

        {/* Uploaded Asset Badges */}
        {inputAssets.length > 0 && (
          <div className="space-y-1.5 w-full min-w-0">
            <div className="text-[10px] text-neutral-400 uppercase font-mono font-bold">Uploaded Assets ({inputAssets.length})</div>
            <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar w-full min-w-0">
              {inputAssets.map((asset, idx) => (
                <div
                  key={asset.id}
                  onClick={() => setSelectedAssetIndex(idx)}
                  className={`flex items-center gap-1.5 p-1.5 rounded-lg border text-[11px] cursor-pointer shrink-0 transition-all ${
                    selectedAssetIndex === idx
                      ? 'bg-[#101F38] border-emerald-500 text-white'
                      : 'bg-[#080D1A] border-[#1C2B4B] text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  {asset.type === 'VIDEO' ? <Film className="w-3 h-3 text-cyan-400 shrink-0" /> : <ImageIcon className="w-3 h-3 text-emerald-400 shrink-0" />}
                  <span className="truncate max-w-[90px] sm:max-w-[120px] font-mono">{asset.name}</span>
                  <button
                    onClick={e => {
                      e.stopPropagation();
                      setInputAssets(prev => prev.filter((_, i) => i !== idx));
                    }}
                    className="hover:text-rose-400 shrink-0 p-0.5"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  };

  // 4. Generation Settings & Parameters
  const renderGenerationSettings = () => (
    <div className="space-y-3 w-full min-w-0">
      {/* Aspect Ratio & Resolution Presets */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 border-t border-[#141E33] w-full min-w-0">
        <div className="w-full min-w-0">
          <label className="block text-[11px] font-semibold text-neutral-400 mb-1">Aspect Ratio</label>
          <select
            value={aspectRatio}
            onChange={e => setAspectRatio(e.target.value as AspectRatioType)}
            className="w-full min-w-0 rounded-md bg-[#0B1120] border border-[#1C2B4B] px-2.5 py-1.5 text-xs text-neutral-200 focus:outline-none focus:border-emerald-500 font-mono"
          >
            <option value="16:9">16:9 Landscape (Cinematic)</option>
            <option value="9:16">9:16 Vertical (Reels/Shorts)</option>
            <option value="1:1">1:1 Square (Feed)</option>
            <option value="4:3">4:3 Classic TV</option>
            <option value="21:9">21:9 Ultrawide Scope</option>
          </select>
        </div>

        <div className="w-full min-w-0">
          <label className="block text-[11px] font-semibold text-neutral-400 mb-1">Resolution Preset</label>
          <select
            value={resolution}
            onChange={e => setResolution(e.target.value as ResolutionPreset)}
            className="w-full min-w-0 rounded-md bg-[#0B1120] border border-[#1C2B4B] px-2.5 py-1.5 text-xs text-neutral-200 focus:outline-none focus:border-emerald-500 font-mono"
          >
            <option value="720p">720p HD (Fast)</option>
            <option value="1080p">1080p FHD (Standard)</option>
            <option value="4K">4K UHD (Master Grade)</option>
          </select>
        </div>
      </div>

      {/* Video Duration & Framerate (if video workflow) */}
      {(activeWorkflow.includes('VIDEO') || activeTab === 'editor') && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 border-t border-[#141E33] w-full min-w-0">
          <div className="w-full min-w-0">
            <label className="block text-[11px] font-semibold text-neutral-400 mb-1">Duration ({durationSec}s)</label>
            <input
              type="range"
              min={1}
              max={30}
              step={1}
              value={durationSec}
              onChange={e => setDurationSec(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
          </div>

          <div className="w-full min-w-0">
            <label className="block text-[11px] font-semibold text-neutral-400 mb-1">Framerate</label>
            <div className="grid grid-cols-3 gap-1 w-full min-w-0">
              {([24, 30, 60] as const).map(rate => (
                <button
                  key={rate}
                  onClick={() => setFps(rate)}
                  className={`py-1 rounded text-[10px] font-mono font-bold transition-all ${
                    fps === rate
                      ? 'bg-emerald-600 text-white'
                      : 'bg-[#0B1120] border border-[#1C2B4B] text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  {rate} FPS
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Style Preset Selector */}
      <div className="space-y-1 w-full min-w-0">
        <label className="block text-[11px] font-semibold text-neutral-400 flex items-center justify-between">
          <span>Visual Style / Direction</span>
          <Palette className="w-3 h-3 text-neutral-500 shrink-0" />
        </label>
        <select
          value={style}
          onChange={e => setStyle(e.target.value as VideoStylePreset)}
          className="w-full min-w-0 rounded-md bg-[#0B1120] border border-[#1C2B4B] px-2.5 py-1.5 text-xs text-neutral-200 focus:outline-none focus:border-emerald-500 font-mono"
        >
          <option value="CINEMATIC">Cinematic Master Grade</option>
          <option value="PHOTOREAL">Hyper Photorealistic</option>
          <option value="CYBERPUNK">Cyberpunk Neon Dusk</option>
          <option value="OCTANE_3D">3D Octane Render Studio</option>
          <option value="ANIME">Anime Studio Aesthetic</option>
          <option value="NOIR">Monochrome 35mm Noir</option>
          <option value="STUDIO_PORTRAIT">Studio Lighting Portrait</option>
          <option value="ANALOG_FILM">Kodak 35mm Grain Film</option>
          <option value="ARCHITECTURAL">Architectural BIM Render</option>
        </select>
      </div>

      {/* Camera Motion Preset */}
      {activeWorkflow.includes('VIDEO') && (
        <div className="space-y-1 w-full min-w-0">
          <label className="block text-[11px] font-semibold text-neutral-400 flex items-center justify-between">
            <span>Camera Motion Trajectory</span>
            <Camera className="w-3 h-3 text-cyan-400 shrink-0" />
          </label>
          <select
            value={cameraMovement}
            onChange={e => setCameraMovement(e.target.value as CameraMovementType)}
            className="w-full min-w-0 rounded-md bg-[#0B1120] border border-[#1C2B4B] px-2.5 py-1.5 text-xs text-neutral-200 focus:outline-none focus:border-emerald-500 font-mono"
          >
            <option value="DOLLY_IN">Dolly In (Push Forward)</option>
            <option value="DOLLY_OUT">Dolly Out (Pull Back)</option>
            <option value="PAN_RIGHT">Pan Right (Smooth Lateral)</option>
            <option value="PAN_LEFT">Pan Left (Smooth Lateral)</option>
            <option value="TILT_UP">Tilt Up (Vertical Pan)</option>
            <option value="TILT_DOWN">Tilt Down (Vertical Pan)</option>
            <option value="TRUCK_RIGHT">Truck Right (Lateral Track)</option>
            <option value="TRUCK_LEFT">Truck Left (Lateral Track)</option>
            <option value="ORBIT_360">Orbital 360° Arc</option>
            <option value="CRANE_UP">Crane Up (Vertical Boom)</option>
            <option value="CRANE_DOWN">Crane Down (Vertical Boom)</option>
            <option value="ZOOM_PULL">Cinematic Zoom Pull</option>
            <option value="TRACKING_SHOT">Tracking Shot (Subject Follow)</option>
            <option value="DEPTH_AWARE_MOVEMENT">Depth-Aware Parallax Flow</option>
            <option value="HANDHELD_DYNAMIC">Handheld Dynamic Stroll</option>
            <option value="STATIC">Static Locked Tripod</option>
          </select>
        </div>
      )}

      {/* Enhancement Sliders (If on Enhance tab) */}
      {activeTab === 'enhance' && (
        <div className="space-y-3 pt-2 border-t border-[#141E33] font-mono text-[11px] w-full min-w-0">
          <div className="flex items-center justify-between text-amber-300 font-bold">
            <span>Real Deterministic Filters</span>
            <button
              onClick={() => setEnhanceParams(MediaEnhancementPipeline.getDefaultEnhancementParams())}
              className="text-[10px] text-neutral-400 hover:text-white underline"
            >
              Reset
            </button>
          </div>

          <div>
            <div className="flex justify-between text-neutral-400">
              <span>3x3 Unsharp Sharpening</span>
              <span>{enhanceParams.sharpening}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={enhanceParams.sharpening}
              onChange={e => setEnhanceParams({ ...enhanceParams, sharpening: Number(e.target.value) })}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-neutral-400">
              <span>Exposure Adjustment</span>
              <span>{enhanceParams.exposure > 0 ? `+${enhanceParams.exposure}` : enhanceParams.exposure}</span>
            </div>
            <input
              type="range"
              min={-50}
              max={50}
              value={enhanceParams.exposure}
              onChange={e => setEnhanceParams({ ...enhanceParams, exposure: Number(e.target.value) })}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-neutral-400">
              <span>Contrast Curve</span>
              <span>{enhanceParams.contrast > 0 ? `+${enhanceParams.contrast}` : enhanceParams.contrast}</span>
            </div>
            <input
              type="range"
              min={-50}
              max={50}
              value={enhanceParams.contrast}
              onChange={e => setEnhanceParams({ ...enhanceParams, contrast: Number(e.target.value) })}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-neutral-400">
              <span>Saturation Modulation</span>
              <span>{enhanceParams.saturation > 0 ? `+${enhanceParams.saturation}` : enhanceParams.saturation}</span>
            </div>
            <input
              type="range"
              min={-50}
              max={50}
              value={enhanceParams.saturation}
              onChange={e => setEnhanceParams({ ...enhanceParams, saturation: Number(e.target.value) })}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-neutral-400">
              <span>Color Temperature</span>
              <span>{enhanceParams.temperature > 0 ? `+${enhanceParams.temperature}` : enhanceParams.temperature}</span>
            </div>
            <input
              type="range"
              min={-50}
              max={50}
              value={enhanceParams.temperature}
              onChange={e => setEnhanceParams({ ...enhanceParams, temperature: Number(e.target.value) })}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-neutral-400">
              <span>Gamma Correction</span>
              <span>{enhanceParams.gamma.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min={0.5}
              max={2.0}
              step={0.05}
              value={enhanceParams.gamma}
              onChange={e => setEnhanceParams({ ...enhanceParams, gamma: Number(e.target.value) })}
              className="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-neutral-400 mb-1">Spatial Interpolation Scale</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1 w-full min-w-0">
              {[1.0, 1.5, 2.0, 4.0].map(s => (
                <button
                  key={s}
                  onClick={() => setEnhanceParams({ ...enhanceParams, resolutionScale: s })}
                  className={`py-1 rounded text-[10px] font-bold transition-all ${
                    enhanceParams.resolutionScale === s
                      ? 'bg-amber-600 text-white'
                      : 'bg-[#0B1120] border border-[#1C2B4B] text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  {s}x Bicubic
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Preservation & Advanced Controls */}
      <div className="pt-2 border-t border-[#141E33] space-y-2 w-full min-w-0">
        <div className="flex items-center justify-between text-[11px]">
          <span className="text-neutral-400">Preserve Subject Identity</span>
          <input
            type="checkbox"
            checked={preserveIdentity}
            onChange={e => setPreserveIdentity(e.target.checked)}
            className="accent-emerald-500 rounded"
          />
        </div>
        <div className="flex items-center justify-between text-[11px]">
          <span className="text-neutral-400">Preserve Soundtrack Audio</span>
          <input
            type="checkbox"
            checked={preserveAudio}
            onChange={e => setPreserveAudio(e.target.checked)}
            className="accent-emerald-500 rounded"
          />
        </div>
      </div>

      {/* Seed Input */}
      <div className="pt-2 border-t border-[#141E33] flex items-center justify-between text-[11px] w-full min-w-0">
        <span className="text-neutral-400">Seed:</span>
        <div className="flex items-center gap-2">
          <input
            type="number"
            disabled={randomSeed}
            value={seed}
            onChange={e => setSeed(Number(e.target.value))}
            className="w-20 rounded bg-[#0B1120] border border-[#1C2B4B] px-1.5 py-0.5 text-xs text-neutral-200 disabled:opacity-40 font-mono"
          />
          <label className="flex items-center gap-1 text-[10px] text-neutral-500 cursor-pointer">
            <input
              type="checkbox"
              checked={randomSeed}
              onChange={e => setRandomSeed(e.target.checked)}
              className="accent-emerald-500"
            />
            <span>Random</span>
          </label>
        </div>
      </div>
    </div>
  );

  // 5. Center Canvas Preview & Stage
  const renderMediaPreviewStage = () => (
    <div className="flex flex-col bg-[#03060E] overflow-hidden min-w-0 w-full rounded-xl border border-[#141E33]">
      {/* Viewport Action Bar */}
      <div className="h-10 border-b border-[#141E33] bg-[#070B16] px-3 sm:px-4 flex items-center justify-between text-xs shrink-0 font-mono w-full min-w-0">
        <div className="flex items-center gap-2 sm:gap-3 overflow-hidden">
          <span className="text-neutral-400 flex items-center gap-1.5 shrink-0">
            <Eye className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span className="hidden sm:inline">CANVAS VIEWPORT</span>
            <span className="sm:hidden">STAGE</span>
          </span>
          <span className="text-neutral-600">|</span>
          <span className="text-neutral-400 shrink-0">{aspectRatio}</span>
          <span className="text-neutral-600">|</span>
          <span className="text-neutral-400 shrink-0">{resolution}</span>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <button
            onClick={() => setZoomLevel(prev => Math.max(50, prev - 10))}
            className="p-1 rounded hover:bg-[#121B30] text-neutral-400 hover:text-white"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <span className="text-[11px] text-neutral-400 w-8 text-center">{zoomLevel}%</span>
          <button
            onClick={() => setZoomLevel(prev => Math.min(200, prev + 10))}
            className="p-1 rounded hover:bg-[#121B30] text-neutral-400 hover:text-white"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setZoomLevel(100)}
            className="px-2 py-0.5 rounded bg-[#101A2E] hover:bg-[#17243F] text-[10px] text-neutral-300"
          >
            Fit
          </button>
        </div>
      </div>

      {/* Interactive Canvas Stage */}
      <div className="flex items-center justify-center p-3 sm:p-6 overflow-hidden relative bg-[radial-gradient(#131e36_1px,transparent_1px)] [background-size:24px_24px] min-h-[220px] sm:min-h-[300px]">
        {/* Aspect Ratio Container */}
        <div
          style={{
            transform: `scale(${zoomLevel / 100})`,
            transition: 'transform 0.1s ease-out'
          }}
          className="relative shadow-2xl rounded-lg overflow-hidden border border-[#1C2C4E] bg-black max-w-full max-h-full flex items-center justify-center"
        >
          <canvas
            ref={canvasRef}
            width={aspectRatio === '9:16' ? 608 : aspectRatio === '1:1' ? 1080 : 1920}
            height={1080}
            className="w-full h-auto max-h-[45vh] sm:max-h-[60vh] object-contain block"
          />

          {/* Before/After Split Line if in Enhance mode */}
          {activeTab === 'enhance' && (
            <div
              className="absolute inset-y-0 w-0.5 bg-amber-400 pointer-events-none shadow-[0_0_8px_#f59e0b]"
              style={{ left: `${splitSliderPos}%` }}
            >
              <div className="absolute top-4 -left-3 bg-amber-500 text-black font-bold text-[9px] px-1 py-0.5 rounded shadow">
                SPLIT
              </div>
            </div>
          )}

          {/* Truthful Engine Boundary Alert Overlay if Neural Engine is required */}
          {isNeuralRequired && (
            <div className="absolute bottom-2 sm:bottom-4 left-2 sm:left-4 right-2 sm:right-4 p-2.5 sm:p-3 rounded-xl bg-gradient-to-r from-[#0C172C]/95 to-[#0F1D38]/95 border border-cyan-500/40 backdrop-blur-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs font-mono shadow-xl">
              <div className="flex items-center gap-2">
                <Info className="w-4 h-4 text-cyan-400 shrink-0" />
                <div>
                  <div className="font-bold text-white text-[11px] sm:text-xs">Neural generation engine required</div>
                  <div className="text-[10px] text-neutral-400 leading-tight">
                    Remote cluster required for latent diffusion. Browser procedural simulator active locally.
                  </div>
                </div>
              </div>
              <button
                onClick={() => setSelectedEngineId('engine-browser-native')}
                className="w-full sm:w-auto px-3 py-1 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-[11px] shrink-0 text-center"
              >
                Use Browser Native
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Center Playback & Scrub Bar */}
      <div className="border-t border-[#141E33] bg-[#070B16] px-3 sm:px-4 py-2 flex flex-col sm:flex-row items-center justify-between gap-2 shrink-0 font-mono text-xs w-full min-w-0">
        {/* Playback controls */}
        <div className="flex items-center justify-between sm:justify-start w-full sm:w-auto gap-2 shrink-0">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="p-1.5 sm:p-2 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white transition-all shadow-md shrink-0"
              title={isPlaying ? 'Pause' : 'Play Preview'}
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> : <Play className="w-3.5 h-3.5 sm:w-4 sm:h-4 fill-current" />}
            </button>

            <button
              onClick={() => setCurrentTimeSec(0)}
              className="p-1 sm:p-1.5 rounded hover:bg-[#121B30] text-neutral-400 hover:text-white shrink-0"
              title="Rewind to Start"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => setIsMuted(!isMuted)}
              className="p-1 sm:p-1.5 rounded hover:bg-[#121B30] text-neutral-400 hover:text-white shrink-0"
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
            </button>
          </div>

          <span className="text-[10px] sm:text-[11px] text-neutral-300 font-mono">
            {currentTimeSec.toFixed(2)}s / {durationSec}.00s
          </span>
        </div>

        {/* Scrub Timeline Bar */}
        <div className="w-full flex-1 flex items-center gap-2 min-w-0 max-w-full sm:max-w-xl">
          <span className="text-[10px] text-neutral-500 shrink-0">00:00</span>
          <input
            type="range"
            min={0}
            max={durationSec}
            step={0.05}
            value={currentTimeSec}
            onChange={e => {
              setCurrentTimeSec(Number(e.target.value));
              renderFrame(Number(e.target.value));
            }}
            className="flex-1 accent-emerald-500 cursor-pointer h-1.5 bg-[#141E33] rounded-lg min-w-0"
          />
          <span className="text-[10px] text-neutral-500 shrink-0">
            00:{durationSec.toString().padStart(2, '0')}
          </span>
        </div>

        {/* Status & Stats */}
        <div className="hidden sm:flex items-center gap-2 shrink-0">
          <span className="text-[10px] text-neutral-400 font-mono">
            Frame {Math.round(currentTimeSec * fps)} / {durationSec * fps}
          </span>
        </div>
      </div>
    </div>
  );

  // 6. Engine Configuration, Model Selection & Preflight Diagnostics
  const renderEngineSection = () => (
    <div className="space-y-3 w-full min-w-0 font-sans">
      {/* Real Engine Connection Status */}
      <div className="p-2.5 rounded-xl bg-[#090E1C] border border-[#182644] flex items-center justify-between text-xs font-mono">
        <div className="flex items-center gap-2">
          <span className={`w-2.5 h-2.5 rounded-full ${
            selectedEngine?.status === 'AVAILABLE_LOCALLY' || selectedEngine?.status === 'AVAILABLE_BROWSER_NATIVE'
              ? 'bg-emerald-400 animate-pulse'
              : 'bg-amber-400'
          }`} />
          <span className="font-bold text-neutral-200">{selectedEngine?.name || 'Browser-Native Canvas & DSP Engine'}</span>
        </div>
        <span className="text-[10px] px-2 py-0.5 rounded bg-[#101A2E] text-cyan-300 font-bold border border-[#1C2C4E]">
          {selectedEngine?.status || 'AVAILABLE_BROWSER_NATIVE'}
        </span>
      </div>

      {/* Model Selection & Recommendation */}
      <div className="space-y-1.5 w-full min-w-0">
        <div className="flex items-center justify-between">
          <label className="font-semibold text-neutral-300 text-xs flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-cyan-400" />
            <span>Neural Model Architecture</span>
          </label>
          {modelRecommendation && (
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-800 font-mono font-bold">
              {modelRecommendation.confidence} Recommended
            </span>
          )}
        </div>

        <select
          value={selectedModelId}
          onChange={e => setSelectedModelId(e.target.value)}
          className="w-full min-w-0 rounded-md bg-[#0B1120] border border-[#1C2B4B] px-2.5 py-2 text-xs text-neutral-200 focus:outline-none focus:border-cyan-500 font-mono"
        >
          <option value="auto-recommend">
            ✨ Auto-Select Optimal Model ({modelRecommendation ? modelRecommendation.modelName : 'Dynamic'})
          </option>
          <optgroup label="Local Checkpoints / Video Diffusers">
            {discoveredModels.videoModels.map(m => (
              <option key={m} value={m}>{m}</option>
            ))}
            {discoveredModels.checkpoints.map(m => (
              <option key={m} value={m}>{m}</option>
            ))}
            <option value="animatediff-motion-v3">AnimateDiff Motion Module v3</option>
            <option value="svd-xt-1.1">Stable Video Diffusion XT 1.1</option>
            <option value="cogvideox-5b-i2v">CogVideoX 5B I2V</option>
            <option value="sdxl-base-1.0">SDXL Base 1.0 (FP16)</option>
          </optgroup>
        </select>

        {modelRecommendation && (
          <div className="p-2 rounded-lg bg-[#07131D] border border-cyan-500/20 text-[10px] font-mono text-neutral-400 space-y-1">
            <div className="text-cyan-300 font-bold flex items-center justify-between">
              <span>{modelRecommendation.modelName}</span>
              <span>Req: {modelRecommendation.vramRequiredGb}GB VRAM</span>
            </div>
            <div className="text-neutral-400 leading-tight">{modelRecommendation.rationale}</div>
          </div>
        )}
      </div>

      {/* Preflight Check Button & Summary */}
      <div className="p-2.5 rounded-xl bg-[#090E1C] border border-[#182644] space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-bold text-neutral-300 font-mono flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Preflight Readiness</span>
          </span>
          <button
            onClick={async () => {
              const effectiveSeed = randomSeed ? Math.floor(Math.random() * 1000000) : seed;
              const rep = await GenerationPreflightEngine.getInstance().executePreflight(
                activeWorkflow,
                { prompt, negativePrompt, aspectRatio, resolution, durationSec, fps, seed: effectiveSeed },
                inputAssets,
                selectedEngineId
              );
              setPreflightReport(rep);
              setIsPreflightOpen(true);
            }}
            className="text-[10px] px-2 py-0.5 rounded bg-[#101F38] hover:bg-[#182F54] text-cyan-300 border border-cyan-700/50 font-mono font-bold"
          >
            Run Preflight
          </button>
        </div>

        {preflightReport && (
          <div className="text-[10px] font-mono space-y-1 pt-1 border-t border-[#141E33]">
            <div className="flex justify-between items-center">
              <span className="text-neutral-400">Status:</span>
              <span className={`font-bold ${preflightReport.passed ? 'text-emerald-400' : 'text-rose-400'}`}>
                {preflightReport.passed ? 'ALL CHECKS PASSED' : 'PREFLIGHT BLOCKED'}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-neutral-400">Resolution:</span>
              <span className="text-neutral-200">{preflightReport.normalizedParams.resolution}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-neutral-400">Estimated VRAM:</span>
              <span className="text-cyan-300">{(preflightReport.resourceEstimate.estimatedVramGb || 0).toFixed(1)} GB</span>
            </div>
            {preflightReport.warnings.length > 0 && (
              <div className="text-amber-400 text-[9px] pt-1">
                ⚠️ {preflightReport.warnings.join(', ')}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Engine Selector */}
      <div className="space-y-2 w-full min-w-0">
        <label className="block font-semibold text-neutral-300 text-xs">Execution Engines</label>
        <div className="space-y-2 w-full min-w-0">
          {engines.map(eng => (
            <div
              key={eng.id}
              onClick={() => setSelectedEngineId(eng.id)}
              className={`p-2.5 rounded-xl border cursor-pointer transition-all w-full min-w-0 box-border ${
                selectedEngineId === eng.id
                  ? 'bg-[#0E1A33] border-cyan-500/60 shadow-md'
                  : 'bg-[#090E1C] border-[#182644] hover:border-[#233760]'
              }`}
            >
              <div className="flex items-center justify-between gap-1 flex-wrap">
                <span className="font-bold text-neutral-200 font-mono text-[11px] truncate">{eng.name}</span>
                <span
                  className={`text-[9px] px-1.5 py-0.5 rounded font-bold font-mono shrink-0 ${
                    eng.status === 'AVAILABLE_BROWSER_NATIVE'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      : eng.status === 'REQUIRES_ENGINE'
                      ? 'bg-amber-950 text-amber-300 border border-amber-800'
                      : 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                  }`}
                >
                  {eng.status}
                </span>
              </div>
              <div className="text-[10px] text-neutral-400 mt-1 break-words">
                {eng.isFreeLocal ? 'Zero cloud cost, 100% offline & local' : 'High-compute remote cluster'}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Benchmark Scorecard if available */}
      {benchmarkMetrics && (
        <div className="p-3 rounded-xl bg-[#07131D] border border-cyan-500/30 font-mono text-[11px] space-y-2 w-full min-w-0 box-border">
          <div className="flex items-center justify-between text-cyan-300 font-bold">
            <span className="flex items-center gap-1.5">
              <BarChart3 className="w-3.5 h-3.5 shrink-0" />
              <span>Empirical Quality Score</span>
            </span>
            <span className="text-[10px] text-neutral-400 shrink-0">{benchmarkMetrics.sampleCount} Samples</span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-[10px] w-full min-w-0">
            <div className="bg-[#040B11] p-2 rounded border border-[#0D2436] min-w-0">
              <div className="text-neutral-400 truncate">Prompt Adherence</div>
              <div className="text-emerald-400 font-bold text-xs">{benchmarkMetrics.promptAdherence}%</div>
            </div>
            <div className="bg-[#040B11] p-2 rounded border border-[#0D2436] min-w-0">
              <div className="text-neutral-400 truncate">Temporal Consistency</div>
              <div className="text-emerald-400 font-bold text-xs">{benchmarkMetrics.temporalConsistency}%</div>
            </div>
            <div className="bg-[#040B11] p-2 rounded border border-[#0D2436] min-w-0">
              <div className="text-neutral-400 truncate">Motion Quality</div>
              <div className="text-cyan-400 font-bold text-xs">{benchmarkMetrics.motionQuality}%</div>
            </div>
            <div className="bg-[#040B11] p-2 rounded border border-[#0D2436] min-w-0">
              <div className="text-neutral-400 truncate">Artifact Rate</div>
              <div className="text-emerald-400 font-bold text-xs">{benchmarkMetrics.artifactRate}%</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  // 7. Dispatch & Generate Action
  const renderDispatchControls = () => (
    <div className="pt-2 w-full min-w-0">
      <button
        onClick={handleDispatchJob}
        className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-bold text-xs sm:text-sm font-mono shadow-lg transition-all flex items-center justify-center gap-2 group cursor-pointer"
      >
        <Zap className="w-4 h-4 fill-current group-hover:scale-110 transition-transform shrink-0" />
        <span className="truncate">{activeTab === 'enhance' ? 'APPLY ENHANCEMENT' : `DISPATCH ${activeWorkflow}`}</span>
      </button>
      <div className="text-center text-[10px] text-neutral-500 mt-2 font-mono">
        Safe Mutex Lock Arbitrated by ConflictManager
      </div>
    </div>
  );

  // 8. Generation Queue, History & Execution Logs
  const renderGenerationQueue = () => (
    <div className="border border-[#141E33] bg-[#070B16] rounded-xl flex flex-col shrink-0 font-mono text-xs overflow-hidden w-full min-w-0">
      {/* Queue Header & Filters */}
      <div className="px-3 sm:px-4 py-2 border-b border-[#141E33] bg-[#080E1C] flex items-center justify-between flex-wrap gap-2 shrink-0">
        <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
          <span className="font-bold text-neutral-300 flex items-center gap-1.5 text-[11px] shrink-0">
            <ListOrdered className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>ACTIVE QUEUE ({jobs.length})</span>
          </span>

          <div className="flex items-center gap-1">
            {(['ALL', 'COMPLETED', 'FAILED', 'HISTORY'] as const).map(f => (
              <button
                key={f}
                onClick={() => setActiveQueueFilter(f as any)}
                className={`px-2 py-0.5 rounded text-[10px] font-bold transition-colors ${
                  activeQueueFilter === f
                    ? 'bg-[#182644] text-white'
                    : 'text-neutral-500 hover:text-neutral-300'
                }`}
              >
                {f} {f === 'HISTORY' ? `(${historyRecords.length})` : ''}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setIsLogsOpen(!isLogsOpen)}
            className="px-2 py-1 rounded bg-[#101A2E] hover:bg-[#182744] text-[10px] text-cyan-300 transition-colors"
          >
            {isLogsOpen ? 'Hide Logs' : 'Execution Logs'}
          </button>
          <button
            onClick={() => {
              MediaJobQueueManager.getInstance().clearHistory();
              GenerationHistoryEngine.getInstance().clearHistory();
            }}
            className="p-1 rounded hover:bg-[#182744] text-neutral-500 hover:text-rose-400 transition-colors"
            title="Clear Queue & History"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Queue Items, History or Logs Stream */}
      <div className="p-3 space-y-2 max-h-72 overflow-y-auto w-full min-w-0">
        {isLogsOpen ? (
          <div className="space-y-1 font-mono text-[10px] text-neutral-400 bg-black/40 p-2.5 rounded-lg border border-[#141E33] overflow-x-auto break-all">
            {activeJob?.executionEvidence.logs.map((log, i) => (
              <div key={i} className="leading-relaxed">{log}</div>
            )) || progressEvents.map((evt, i) => (
              <div key={i} className="leading-relaxed">[{evt.stage}] {evt.message} {evt.percent !== null ? `(${evt.percent}%)` : ''}</div>
            )) || <div className="text-neutral-600">No active execution logs. Submit a job to view real-time pipeline output.</div>}
          </div>
        ) : activeQueueFilter === 'HISTORY' ? (
          historyRecords.length === 0 ? (
            <div className="text-center py-4 text-neutral-500 text-xs font-mono">
              No completed generations recorded in history yet.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 w-full min-w-0">
              {historyRecords.map(rec => (
                <div
                  key={rec.id}
                  className="p-2.5 rounded-lg bg-[#0A0F1F] border border-[#182644] flex flex-col justify-between gap-1.5 w-full min-w-0 box-border text-[10px]"
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="font-bold text-neutral-200 truncate">{rec.workflow}</span>
                    <span className={`px-1.5 py-0.5 rounded font-bold ${
                      rec.overallQualityScore >= 75 ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-amber-950 text-amber-300'
                    }`}>
                      Q-Score: {rec.overallQualityScore.toFixed(1)}
                    </span>
                  </div>
                  <div className="text-neutral-400 truncate">{rec.prompt}</div>
                  <div className="grid grid-cols-3 gap-1 pt-1 text-[9px] text-neutral-400 border-t border-[#141E33]">
                    <div>Temp: <span className="text-cyan-300">{(rec.quality?.temporalScore ?? 85).toFixed(0)}</span></div>
                    <div>Visual: <span className="text-emerald-300">{(rec.quality?.visualScore ?? 90).toFixed(0)}</span></div>
                    <div>Refine: <span className="text-amber-300">{rec.refinementCycles}</span></div>
                  </div>
                  <div className="text-[9px] text-neutral-500 flex justify-between pt-1">
                    <span>{rec.resolution} · {rec.fps || 24}fps</span>
                    <span>{(rec.durationSec || 4).toFixed(1)}s</span>
                  </div>
                </div>
              ))}
            </div>
          )
        ) : jobs.length === 0 ? (
          <div className="text-center py-4 text-neutral-500 text-xs font-mono">
            No media jobs in queue. Configure parameters above and click Dispatch.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 w-full min-w-0">
            {jobs
              .filter(j => activeQueueFilter === 'ALL' || (activeQueueFilter === 'COMPLETED' ? j.status === 'COMPLETED' : j.status === 'FAILED'))
              .map(job => (
                <div
                  key={job.jobId}
                  className="p-2.5 rounded-lg bg-[#0A0F1F] border border-[#182644] flex flex-col justify-between gap-2 w-full min-w-0 box-border"
                >
                  <div className="overflow-hidden space-y-1 w-full min-w-0">
                    <div className="flex items-center justify-between gap-1 w-full">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span
                          className={`w-2 h-2 rounded-full shrink-0 ${
                            job.status === 'COMPLETED'
                              ? 'bg-emerald-400'
                              : job.status === 'RUNNING'
                              ? 'bg-cyan-400 animate-pulse'
                              : job.status === 'FAILED'
                              ? 'bg-rose-400'
                              : 'bg-amber-400'
                          }`}
                        />
                        <span className="font-bold text-neutral-200 text-[11px] truncate">{job.type}</span>
                        <span className="text-[9px] text-neutral-500 font-mono shrink-0">({job.parameters.aspectRatio})</span>
                      </div>

                      <div className="shrink-0 flex items-center gap-1">
                        {job.status === 'RUNNING' && (
                          <button
                            onClick={() => MediaJobQueueManager.getInstance().cancelJob(job.jobId)}
                            className="px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 hover:bg-rose-900 text-[9px]"
                          >
                            Cancel
                          </button>
                        )}
                        {(job.status === 'FAILED' || job.status === 'REQUIRES_ENGINE') && (
                          <button
                            onClick={() => MediaJobQueueManager.getInstance().retryJob(job.jobId)}
                            className="px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 hover:bg-cyan-900 text-[9px] border border-cyan-800"
                          >
                            Retry
                          </button>
                        )}
                        {job.status === 'COMPLETED' && (
                          <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-800 font-bold">
                            VERIFIED
                          </span>
                        )}
                        {job.status === 'REQUIRES_ENGINE' && (
                          <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-800 font-bold">
                            ENGINE REQ
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="text-[10px] text-neutral-400 truncate w-full">
                      {job.parameters.prompt || 'Enhancement filter pipeline'}
                    </div>

                    {job.progress !== null && job.status === 'RUNNING' && (
                      <div className="w-full bg-[#121B30] h-1 rounded-full overflow-hidden mt-1">
                        <div className="bg-emerald-500 h-full transition-all" style={{ width: `${job.progress}%` }} />
                      </div>
                    )}
                  </div>
                </div>
              ))}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div 
      id="godex-creative-studio" 
      className="h-full w-full max-w-full flex flex-col bg-[#050811] text-neutral-200 select-none overflow-y-auto lg:overflow-hidden font-sans box-border"
    >
      {/* 1. TOP CREATIVE HEADER */}
      <header className="border-b border-[#141E33] bg-[#080D1A] px-3 sm:px-4 py-2 sm:py-0 sm:h-14 flex flex-col sm:flex-row sm:items-center justify-between shrink-0 z-20 gap-2 w-full min-w-0">
        <div className="flex items-center justify-between sm:justify-start gap-3 w-full sm:w-auto min-w-0">
          <div className="flex items-center gap-2 cursor-pointer shrink-0">
            <GodexLogo size={24} />
            <div className="flex items-center gap-1.5 sm:gap-2">
              <span className="font-bold tracking-wider text-xs sm:text-sm text-white font-mono">GODEX</span>
              <span className="text-[9px] sm:text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                CREATIVE STUDIO
              </span>
              <span className="text-[9px] sm:text-[10px] text-neutral-400 font-mono">P3.2</span>
            </div>
          </div>

          {/* Desktop Only Navigation Rail inside header */}
          <div className="hidden lg:flex items-center gap-1 ml-2">
            <div className="h-4 w-px bg-[#1F2C4C] mx-1" />
            {renderModeSelector()}
          </div>

          {/* Mobile Status & Action */}
          <div className="flex items-center gap-2 sm:hidden">
            <div className="flex items-center gap-1 text-[10px] font-mono bg-[#0D1527] px-2 py-0.5 rounded border border-[#18233C]">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-emerald-300 font-bold">READY</span>
            </div>
          </div>
        </div>

        {/* Secondary Engineering Area Quick Link & Diagnostics */}
        <div className="hidden sm:flex items-center gap-2 sm:gap-3 shrink-0">
          <button
            onClick={() => setIsDiagnosticsOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#0D1527] hover:bg-[#15203A] border border-[#18233C] text-xs font-mono text-emerald-300 transition-colors"
            title="Inspect Hardware, ComfyUI, Neural Runtimes, and Memory Audit"
          >
            <Activity className="w-3.5 h-3.5 text-emerald-400" />
            <span className="font-bold">Diagnostics</span>
          </button>

          <div className="flex items-center gap-1.5 text-xs font-mono bg-[#0D1527] px-2.5 py-1 rounded-md border border-[#18233C]">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-emerald-300 font-bold">READY</span>
            <span className="text-neutral-500">|</span>
            <span className="text-neutral-400">{jobs.filter(j => j.status === 'COMPLETED').length} Assets</span>
          </div>

          {onNavigateToEngineering && (
            <button
              onClick={onNavigateToEngineering}
              className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-[#0E1729] hover:bg-[#18243D] border border-[#233354] text-cyan-300 hover:text-cyan-200 text-xs font-semibold transition-all shadow-sm shrink-0"
              title="Access full Engineering, Code Editor, Preview, and App Builder"
            >
              <Cpu className="w-3.5 h-3.5 text-cyan-400" />
              <span>Engineering & Apps →</span>
            </button>
          )}
        </div>
      </header>

      {/* Mobile/Tablet Horizontal Mode Selector Bar */}
      <div className="lg:hidden border-b border-[#141E33] bg-[#070D1A] w-full min-w-0 shrink-0">
        {renderModeSelector()}
      </div>

      {/* ========================================================================= */}
      {/* DESKTOP & MOBILE WORKSPACES */}
      {/* ========================================================================= */}
      {activeTab === 'production' ? (
        <div className="flex-1 flex flex-col overflow-hidden min-h-0 w-full min-w-0">
          <GodexProductionWorkspace />
        </div>
      ) : activeTab === 'camera' ? (
        <div className="flex-1 flex flex-col overflow-hidden min-h-0 w-full min-w-0">
          <GodexCameraStudioWorkspace initialPrompt={prompt} />
        </div>
      ) : activeTab === 'color' ? (
        <div className="flex-1 flex flex-col overflow-hidden min-h-0 w-full min-w-0">
          <GodexColorStudioWorkspace onOpenDiagnostics={() => setIsDiagnosticsOpen(true)} />
        </div>
      ) : activeTab === 'vfx' ? (
        <div className="flex-1 flex flex-col overflow-hidden min-h-0 w-full min-w-0">
          <GodexVfxStudioWorkspace onOpenDiagnostics={() => setIsDiagnosticsOpen(true)} />
        </div>
      ) : activeTab === 'audio' || activeTab === 'sfx' ? (
        <div className="flex-1 flex flex-col overflow-hidden min-h-0 w-full min-w-0">
          <GodexAudioStudioWorkspace onOpenDiagnostics={() => setIsDiagnosticsOpen(true)} />
        </div>
      ) : activeTab === 'assembly' || activeTab === 'export' ? (
        <div className="flex-1 flex flex-col overflow-hidden min-h-0 w-full min-w-0">
          <GodexMediaAssemblyWorkspace />
        </div>
      ) : (
        <>
          {/* ========================================================================= */}
          {/* DESKTOP LAYOUT (>= 1024px) — RETAINS MULTI-PANEL WORKSTATION PRECISION */}
          {/* ========================================================================= */}
          <div className="hidden lg:flex flex-1 overflow-hidden min-h-0 w-full min-w-0">
            {/* LEFT / INPUT PIPELINE */}
            <div className="w-80 xl:w-96 border-r border-[#141E33] bg-[#070B16] flex flex-col shrink-0 overflow-y-auto p-4 space-y-4 text-xs font-sans">
              <div className="flex items-center justify-between pb-2 border-b border-[#141E33]">
                <span className="font-bold text-neutral-300 uppercase tracking-wider font-mono text-[11px] flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Generation Pipeline</span>
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-800 text-emerald-400 font-mono font-bold">
                  {activeTab === 'enhance' ? 'ENHANCER' : activeWorkflow.replace(/_/g, ' ')}
                </span>
              </div>

              {renderPromptSection()}
              {renderSourceMediaSection()}
              {renderGenerationSettings()}
            </div>

            {/* CENTER / LARGE MEDIA PREVIEW & STAGE */}
            <div className="flex-1 flex flex-col bg-[#03060E] overflow-hidden min-w-0">
              {renderMediaPreviewStage()}
            </div>

            {/* RIGHT / ENGINE CONFIGURATION & DISPATCH */}
            <div className="w-80 xl:w-96 border-l border-[#141E33] bg-[#070B16] flex flex-col shrink-0 overflow-y-auto p-4 space-y-4 text-xs font-sans">
              <div className="flex items-center justify-between pb-2 border-b border-[#141E33]">
                <span className="font-bold text-neutral-300 uppercase tracking-wider font-mono text-[11px] flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Engine & Dispatch</span>
                </span>
                <span className="text-[10px] text-neutral-400 font-mono">v3.2</span>
              </div>

              {renderEngineSection()}
              {renderDispatchControls()}
            </div>
          </div>

          {/* DESKTOP BOTTOM QUEUE (>= 1024px) */}
          <div className="hidden lg:block h-44 border-t border-[#141E33] bg-[#070B16] shrink-0">
            {renderGenerationQueue()}
          </div>

          {/* ========================================================================= */}
          {/* MOBILE & TABLET LAYOUT (< 1024px) — SINGLE COLUMN VERTICAL WORKSPACE */}
          {/* ========================================================================= */}
          <div className="flex lg:hidden flex-col w-full min-w-0 max-w-full p-3 sm:p-4 space-y-4 box-border">
            {/* 3. Input / Prompt section */}
            <section className="bg-[#070B16] border border-[#141E33] rounded-xl p-3.5 space-y-3 w-full min-w-0">
              <div className="flex items-center justify-between pb-2 border-b border-[#141E33]">
                <span className="font-bold text-neutral-300 uppercase tracking-wider font-mono text-[11px] flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Prompt & Concept</span>
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-800 text-emerald-400 font-mono font-bold">
                  {activeTab === 'enhance' ? 'ENHANCER' : activeWorkflow.replace(/_/g, ' ')}
                </span>
              </div>
              {renderPromptSection()}
            </section>

            {/* 4. Source media section when required */}
            {(activeWorkflow === 'IMAGE_TO_VIDEO' || activeWorkflow === 'VIDEO_TO_VIDEO' || activeTab === 'enhance') && (
              <section className="bg-[#070B16] border border-[#141E33] rounded-xl p-3.5 space-y-3 w-full min-w-0">
                {renderSourceMediaSection()}
              </section>
            )}

            {/* 5. Generation settings (Collapsible Card) */}
            <section className="bg-[#070B16] border border-[#141E33] rounded-xl p-3.5 space-y-3 w-full min-w-0">
              <button
                onClick={() => setIsSettingsOpen(!isSettingsOpen)}
                className="flex items-center justify-between w-full text-left"
              >
                <span className="font-bold text-neutral-300 uppercase tracking-wider font-mono text-[11px] flex items-center gap-1.5">
                  <Palette className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                  <span>Generation Settings & Controls</span>
                </span>
                {isSettingsOpen ? <ChevronUp className="w-4 h-4 text-neutral-400" /> : <ChevronDown className="w-4 h-4 text-neutral-400" />}
              </button>

              {isSettingsOpen && (
                <div className="pt-2 border-t border-[#141E33]">
                  {renderGenerationSettings()}
                </div>
              )}
            </section>

            {/* 6. Media preview / stage */}
            <section className="w-full min-w-0">
              {renderMediaPreviewStage()}
            </section>

            {/* 7. Engine status & scorecards */}
            <section className="bg-[#070B16] border border-[#141E33] rounded-xl p-3.5 space-y-3 w-full min-w-0">
              <button
                onClick={() => setIsEngineSectionOpen(!isEngineSectionOpen)}
                className="flex items-center justify-between w-full text-left"
              >
                <span className="font-bold text-neutral-300 uppercase tracking-wider font-mono text-[11px] flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span>Engine Status & Empirical Profile</span>
                </span>
                {isEngineSectionOpen ? <ChevronUp className="w-4 h-4 text-neutral-400" /> : <ChevronDown className="w-4 h-4 text-neutral-400" />}
              </button>

              {isEngineSectionOpen && (
                <div className="pt-2 border-t border-[#141E33]">
                  {renderEngineSection()}
                </div>
              )}
            </section>

            {/* 8. Generate / Cancel controls */}
            <section className="w-full min-w-0">
              {renderDispatchControls()}
            </section>

            {/* 9. Generation queue */}
            <section className="w-full min-w-0">
              {renderGenerationQueue()}
            </section>

            {/* 10. Engineering quick button on mobile */}
            {onNavigateToEngineering && (
              <section className="pt-2 pb-6 w-full min-w-0">
                <button
                  onClick={onNavigateToEngineering}
                  className="w-full py-3 rounded-xl bg-[#0E1729] hover:bg-[#18243D] border border-[#233354] text-cyan-300 text-xs font-semibold font-mono flex items-center justify-center gap-2 transition-all shadow-sm"
                >
                  <Cpu className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>Switch to AI Engineering & Code Studio →</span>
                </button>
              </section>
            )}
          </div>
        </>
      )}

      {/* Diagnostics Modal */}
      <CreativeEngineDiagnosticsModal
        isOpen={isDiagnosticsOpen}
        onClose={() => setIsDiagnosticsOpen(false)}
      />
    </div>
  );
};
