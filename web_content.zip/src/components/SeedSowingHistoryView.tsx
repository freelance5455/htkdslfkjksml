import React, { useState } from 'react';
import { motion } from 'motion/react';
import { History, ArrowUpRight, CheckCircle2, ShieldCheck, Building2, Download, Calendar, ExternalLink, RefreshCw, Zap } from 'lucide-react';
import { offlineCache, SowingRecord } from '../lib/offlineCache';

interface SeedSowingHistoryViewProps {
  onTriggerFlutterwavePayout?: () => void;
}

export const SeedSowingHistoryView: React.FC<SeedSowingHistoryViewProps> = ({ onTriggerFlutterwavePayout }) => {
  const profile = offlineCache.getProfile();
  const history: SowingRecord[] = profile.sowingHistory || [
    { id: 'sow-1', date: '2026-10-10', amountUSD: 50, platform: 'Flutterwave / OPay NUBAN', category: 'Prophetic Seed' },
    { id: 'sow-2', date: '2026-10-11', amountUSD: 120, platform: 'Flutterwave / Wema Bank', category: 'Gospel Music Ministry' },
    { id: 'sow-3', date: '2026-10-12', amountUSD: 250, platform: 'Flutterwave / MiniPay Vault', category: 'Altar Offering' },
  ];

  const [filter, setFilter] = useState<string>('ALL');

  const filteredHistory = history.filter(item => {
    if (filter === 'ALL') return true;
    return item.category.toLowerCase().includes(filter.toLowerCase());
  });

  const totalNgnSown = history.reduce((sum, item) => sum + item.amountUSD * 1500, 0); // approx NGN conversion

  return (
    <div className="bg-neutral-900/90 border border-amber-500/30 rounded-2xl p-6 text-white shadow-2xl backdrop-blur-xl">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6 pb-4 border-b border-neutral-800">
        <div>
          <div className="flex items-center gap-2 text-amber-400 font-bold text-lg">
            <History className="w-5 h-5 text-amber-400 animate-spin-slow" />
            <span>Flutterwave Payout & Seed Sowing Timeline</span>
          </div>
          <p className="text-xs text-neutral-400 mt-1">
            Real-time auditable ledger of cash-out transactions routed through Flutterwave NIBSS clearing to OPay, Wema, and MiniPay accounts.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-xs text-emerald-400 font-semibold flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4" /> Flutterwave NIBSS Live
          </div>
          {onTriggerFlutterwavePayout && (
            <button
              onClick={onTriggerFlutterwavePayout}
              className="px-4 py-2 bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-black font-bold text-xs rounded-xl shadow-lg transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5 fill-black" /> Cash Out to Flutterwave
            </button>
          )}
        </div>
      </div>

      {/* Summary Stat Bar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-neutral-950/80 border border-neutral-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <div className="text-xs text-neutral-400">Total Payout Volume</div>
            <div className="text-xl font-black text-amber-400 mt-1">${history.reduce((a, b) => a + b.amountUSD, 0).toLocaleString()} USD</div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <ArrowUpRight className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-neutral-950/80 border border-neutral-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <div className="text-xs text-neutral-400">Estimated Naira Sown</div>
            <div className="text-xl font-black text-emerald-400 mt-1">₦{totalNgnSown.toLocaleString()}</div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <Building2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-neutral-950/80 border border-neutral-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <div className="text-xs text-neutral-400">Clearing Status</div>
            <div className="text-sm font-bold text-cyan-400 mt-1 flex items-center gap-1">
              <CheckCircle2 className="w-4 h-4 text-cyan-400" /> Instant NIBSS Settlement
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 mb-4 overflow-x-auto pb-2">
        {['ALL', 'Prophetic Seed', 'Gospel Music', 'Altar Offering', 'Tithe'].map((cat) => (
          <button
            key={cat}
            onClick={() => setFilter(cat === 'Gospel Music' ? 'Gospel Music Ministry' : cat)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              filter === cat || (cat === 'Gospel Music' && filter === 'Gospel Music Ministry')
                ? 'bg-amber-500 text-black font-bold shadow-md'
                : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Timeline Stream */}
      <div className="space-y-3 relative before:absolute before:left-4 before:top-2 before:bottom-2 before:w-0.5 before:bg-neutral-800">
        {filteredHistory.length === 0 ? (
          <div className="text-center py-12 text-neutral-500 text-sm">
            No sowing or cash-out records found for this category.
          </div>
        ) : (
          filteredHistory.map((item, idx) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="relative pl-10 group"
            >
              {/* Timeline Dot */}
              <div className="absolute left-2.5 top-3.5 -translate-x-1/2 w-3 h-3 rounded-full bg-amber-500 border-2 border-neutral-900 group-hover:scale-125 transition-transform" />

              <div className="bg-neutral-950/90 border border-neutral-800 hover:border-amber-500/50 rounded-xl p-4 transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-amber-500/10 text-amber-400 border border-amber-500/30">
                      {item.category}
                    </span>
                    <span className="text-xs text-neutral-400 flex items-center gap-1">
                      <Calendar className="w-3 h-3" /> {item.date}
                    </span>
                  </div>
                  <div className="text-sm font-bold text-white flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-emerald-400" />
                    <span>{item.platform}</span>
                  </div>
                </div>

                <div className="flex items-center gap-4 w-full md:w-auto justify-between md:justify-end">
                  <div className="text-right">
                    <div className="text-base font-black text-amber-400">+${item.amountUSD} USD</div>
                    <div className="text-[11px] text-emerald-400 font-semibold">₦{(item.amountUSD * 1500).toLocaleString()} NGN</div>
                  </div>
                  <div className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-[11px] font-bold text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Settled
                  </div>
                </div>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
};
