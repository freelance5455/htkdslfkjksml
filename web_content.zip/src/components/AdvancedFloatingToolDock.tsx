import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  StylusToolType,
  StylusSettings,
  CanvasThemeStyle,
  SmartEraserFilterMode,
} from "../types";
import { StylusSettingsManager } from "../utils/digitalInkEngine";
import { useDisplayScale } from "../utils/displayScaleManager";
import { PenPreviewBadge } from "./PenPreviewBadge";
import {
  SkeuomorphicFountainPen,
  SkeuomorphicPencil,
  SkeuomorphicHighlighter,
  SkeuomorphicEraser,
  SkeuomorphicLasso,
  SkeuomorphicLaserMarker,
  SkeuomorphicRecallTape,
} from "./SkeuomorphicPenIcons";
import {
  RotateCcw,
  RotateCw,
  Sparkles,
  Check,
  Move,
  Sliders,
  X,
  ChevronDown,
  ChevronRight,
  ChevronLeft,
  Shapes,
  Link,
  PanelTop,
  PanelBottom,
  Plus,
  Palette,
} from "lucide-react";

export type DockPositionMode = "floating" | "top_dock" | "bottom_dock" | "left_dock" | "compact_fab";
export type EraserMode = "pixel" | "stroke";

interface AdvancedFloatingToolDockProps {
  activeTool: StylusToolType;
  onChangeTool: (tool: StylusToolType) => void;
  activeColor: string;
  onChangeColor: (color: string) => void;
  strokeSize: number;
  onChangeStrokeSize: (size: number) => void;
  opacity?: number;
  onChangeOpacity?: (opacity: number) => void;
  onUndo?: () => void;
  onRedo?: () => void;
  onClearAll?: () => void;
  onRecognizeText?: () => void;
  isVisible: boolean;
  onClose?: () => void;
  canvasStyle?: CanvasThemeStyle;
  isShapeRecognitionActive?: boolean;
  onToggleShapeRecognition?: () => void;
  eraserMode?: EraserMode;
  onChangeEraserMode?: (mode: EraserMode) => void;
  activeEraserFilter?: SmartEraserFilterMode;
  onChangeEraserFilter?: (filter: SmartEraserFilterMode) => void;
  onToggleAllRecallTapes?: () => void;
  onAddBidirectionalLink?: () => void;
}

export const AdvancedFloatingToolDock: React.FC<AdvancedFloatingToolDockProps> = ({
  activeTool,
  onChangeTool,
  activeColor,
  onChangeColor,
  strokeSize,
  onChangeStrokeSize,
  opacity = 1.0,
  onChangeOpacity,
  onUndo,
  onRedo,
  onClearAll,
  onRecognizeText,
  isVisible,
  onClose,
  canvasStyle = "hybrid_white",
  isShapeRecognitionActive = false,
  onToggleShapeRecognition,
  eraserMode = "pixel",
  onChangeEraserMode,
  activeEraserFilter = "all",
  onChangeEraserFilter,
  onToggleAllRecallTapes,
  onAddBidirectionalLink,
}) => {
  // Global Settings Subscription
  const [settings, setSettings] = useState<StylusSettings>(StylusSettingsManager.getSettings());
  const { scaleConfig, dp, toolSize } = useDisplayScale();
  const dynIconSize = toolSize(28).iconSize;
  
  // Dock Mode: floating | top_dock | bottom_dock | left_dock | compact_fab
  const [dockPosition, setDockPosition] = useState<DockPositionMode>("floating");

  // Offline-first (X, Y) Coordinates persistence
  const [dockCoords, setDockCoords] = useState<{ x: number; y: number }>(() => {
    try {
      const saved = localStorage.getItem("noteflow_dock_coords_v2");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed.x === "number" && typeof parsed.y === "number") {
          return parsed;
        }
      }
    } catch {
      // fallback
    }
    return { x: 0, y: 0 };
  });

  // Collapsed / Expanded state (Right section expand arrow)
  const [isCollapsed, setIsCollapsed] = useState<boolean>(false);

  // Quick Palette Popover (opens above active tool on tap / double tap)
  const [showQuickPalette, setShowQuickPalette] = useState<boolean>(false);

  // 5 Favorite Colors
  const [favoriteColors, setFavoriteColors] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("noteflow_quick_palette_colors");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length >= 5) return parsed.slice(0, 5);
      }
    } catch {}
    return ["#0F172A", "#0284C7", "#059669", "#F59E0B", "#E11D48"];
  });

  // Submenus
  const [showEraserFilterMenu, setShowEraserFilterMenu] = useState<boolean>(false);
  const [showLassoActions, setShowLassoActions] = useState<boolean>(false);
  const [showPositionMenu, setShowPositionMenu] = useState<boolean>(false);
  const [localEraserMode, setLocalEraserMode] = useState<EraserMode>(eraserMode);
  const [localEraserFilter, setLocalEraserFilter] = useState<SmartEraserFilterMode>(activeEraserFilter);

  useEffect(() => {
    const unsub = StylusSettingsManager.subscribe((newSettings) => {
      setSettings(newSettings);
      if (newSettings.activeEraserFilter) {
        setLocalEraserFilter(newSettings.activeEraserFilter);
      }
    });
    return unsub;
  }, []);

  // Save favorite colors whenever updated
  useEffect(() => {
    try {
      localStorage.setItem("noteflow_quick_palette_colors", JSON.stringify(favoriteColors));
    } catch {}
  }, [favoriteColors]);

  // Handle Drag End to store coordinates offline
  const handleDragEnd = (_e: any, info: any) => {
    if (dockPosition !== "floating") return;
    const newCoords = {
      x: (dockCoords.x || 0) + info.offset.x,
      y: (dockCoords.y || 0) + info.offset.y,
    };
    setDockCoords(newCoords);
    try {
      localStorage.setItem("noteflow_dock_coords_v2", JSON.stringify(newCoords));
    } catch {}

    // Edge snapping logic if within 80px from boundary
    const winW = typeof window !== "undefined" ? window.innerWidth : 1000;
    const winH = typeof window !== "undefined" ? window.innerHeight : 800;
    const clientX = info.point.x;
    const clientY = info.point.y;

    if (clientY < 80) {
      setDockPosition("top_dock");
    } else if (winH - clientY < 80) {
      setDockPosition("bottom_dock");
    } else if (clientX < 80) {
      setDockPosition("left_dock");
    }
  };

  const closeAllPopups = () => {
    setShowQuickPalette(false);
    setShowEraserFilterMenu(false);
    setShowLassoActions(false);
    setShowPositionMenu(false);
  };

  const handleToolClick = (toolId: StylusToolType) => {
    if (activeTool === toolId) {
      // Second tap on the active pen opens or toggles Quick Palette!
      setShowQuickPalette((prev) => !prev);
    } else {
      onChangeTool(toolId);
      // When switching to a tool, if it was eraser/lasso close quick palette
      if (toolId === "eraser" || toolId === "lasso_cut") {
        setShowQuickPalette(false);
      }
    }
    setShowEraserFilterMenu(false);
    setShowLassoActions(false);
  };

  const handleSelectColor = (hex: string) => {
    onChangeColor(hex);
    if (!favoriteColors.includes(hex)) {
      setFavoriteColors((prev) => [hex, ...prev.slice(0, 4)]);
    }
  };

  const handleSelectEraserFilter = (filter: SmartEraserFilterMode) => {
    setLocalEraserFilter(filter);
    StylusSettingsManager.updateSettings({ activeEraserFilter: filter });
    if (onChangeEraserFilter) {
      onChangeEraserFilter(filter);
    }
    setShowEraserFilterMenu(false);
  };

  const toggleEraserMode = () => {
    const nextMode = localEraserMode === "pixel" ? "stroke" : "pixel";
    setLocalEraserMode(nextMode);
    if (onChangeEraserMode) {
      onChangeEraserMode(nextMode);
    }
  };

  if (!isVisible) return null;

  // Position wrapper logic
  let positionClasses = "fixed z-50 pointer-events-auto select-none transition-all duration-300";
  if (dockPosition === "top_dock") {
    positionClasses += " top-4 left-1/2 -translate-x-1/2";
  } else if (dockPosition === "bottom_dock") {
    positionClasses += " bottom-6 left-1/2 -translate-x-1/2";
  } else if (dockPosition === "left_dock") {
    positionClasses += " top-1/2 left-4 -translate-y-1/2";
  } else if (dockPosition === "compact_fab") {
    positionClasses += " bottom-6 right-6";
  } else {
    // Floating free (with offline saved X, Y transform)
    positionClasses += " top-14 left-1/2 -translate-x-1/2";
  }

  // Glassmorphic Shell Style:
  // Gündüz modunda %80 opaklıkta beyaz (bg-white/80)
  // Gece modunda %80 opaklıkta koyu safir/siyah buzlu cam (dark:bg-[#070F2B]/80 dark:border-slate-700/60)
  const glassmorphicShellClass =
    "bg-white/80 dark:bg-[#070F2B]/80 text-slate-800 dark:text-white backdrop-blur-xl border border-white/60 dark:border-slate-700/60 shadow-2xl rounded-[24px] ring-1 ring-slate-900/5 dark:ring-white/10";

  return (
    <motion.div
      drag={dockPosition === "floating"}
      dragMomentum={false}
      onDragEnd={handleDragEnd}
      initial={{ opacity: 0, scale: 0.95, y: -10 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95, y: -10 }}
      className={positionClasses}
      style={
        dockPosition === "floating" && (dockCoords.x !== 0 || dockCoords.y !== 0)
          ? { transform: `translate(calc(-50% + ${dockCoords.x}px), ${dockCoords.y}px)` }
          : undefined
      }
    >
      {/* ========================================================================= */}
      {/* HIZLI PALET (QUICK PALETTE POPOVER)                                       */}
      {/* Aktif kaleme dokunulduğunda hemen çubuğun üzerinde açılır                */}
      {/* ========================================================================= */}
      <AnimatePresence>
        {showQuickPalette && (
          <motion.div
            initial={{ opacity: 0, y: 8, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, scale: 0.94 }}
            transition={{ duration: 0.18 }}
            className={`absolute bottom-full mb-3 left-1/2 -translate-x-1/2 p-3 sm:p-3.5 rounded-[22px] min-w-[280px] sm:min-w-[320px] shadow-2xl z-50 flex flex-col gap-3 ${glassmorphicShellClass}`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-black uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-teal-500" />
                <span>Hızlı Palet & Kalınlık</span>
              </span>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono font-extrabold px-2 py-0.5 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-300 border border-teal-200 dark:border-teal-800">
                  {strokeSize} px
                </span>
                <button
                  type="button"
                  onClick={() => setShowQuickPalette(false)}
                  className="p-1 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Horizontal Stroke Width Slider */}
            <div className="space-y-1">
              <input
                type="range"
                min="1"
                max="30"
                value={strokeSize}
                onChange={(e) => onChangeStrokeSize(Number(e.target.value))}
                className="w-full accent-teal-500 h-2 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between items-center text-[9px] text-slate-400 font-mono">
                <span>1px İnce</span>
                <span>15px Orta</span>
                <span>30px Kalın</span>
              </div>
            </div>

            {/* 5 Favorite Color Dots */}
            <div className="pt-2 border-t border-slate-200/60 dark:border-slate-800/80 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                {favoriteColors.map((hex, idx) => (
                  <button
                    key={`${hex}-${idx}`}
                    type="button"
                    onClick={() => handleSelectColor(hex)}
                    className={`relative w-7 h-7 rounded-full border-2 transition-transform hover:scale-110 cursor-pointer ${
                      activeColor.toLowerCase() === hex.toLowerCase()
                        ? "scale-115 border-teal-500 ring-2 ring-teal-400/50 shadow-md"
                        : "border-white dark:border-slate-800"
                    }`}
                    style={{ backgroundColor: hex }}
                    title={hex}
                  >
                    {activeColor.toLowerCase() === hex.toLowerCase() && (
                      <span className="absolute inset-0 flex items-center justify-center text-white drop-shadow-md">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </span>
                    )}
                  </button>
                ))}
              </div>

              {/* Custom Color Input */}
              <label className="relative w-7 h-7 rounded-full border border-dashed border-teal-500 flex items-center justify-center cursor-pointer hover:bg-teal-50 dark:hover:bg-teal-950/40 text-teal-600 dark:text-teal-400 transition-colors" title="Özel Renk Seç">
                <Plus className="w-3.5 h-3.5" />
                <input
                  type="color"
                  value={activeColor}
                  onChange={(e) => handleSelectColor(e.target.value)}
                  className="sr-only"
                />
              </label>
            </div>

            {/* Live Stroke Preview Line */}
            <div className="p-2 rounded-xl bg-slate-100/80 dark:bg-slate-900/60 border border-slate-200/50 dark:border-slate-800 flex items-center justify-center">
              <PenPreviewBadge
                tool={activeTool}
                color={activeColor}
                size={strokeSize}
                width={120}
                height={22}
                className="bg-transparent"
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ========================================================================= */}
      {/* ANA ÇUBUK GÖVDESİ (BORDER-RADIUS: 24PX & GLASSMORPHISM)                   */}
      {/* ========================================================================= */}
      <div className={`p-2 sm:p-2.5 flex flex-col items-center ${glassmorphicShellClass}`}>
        
        {/* TOP CENTER: KÜÇÜK GRİ SÜRÜKLEME TUTAMACI (DRAG HANDLE) */}
        <div
          onClick={() => {
            setShowPositionMenu((prev) => !prev);
            closeAllPopups();
          }}
          className="w-10 h-1.5 rounded-full bg-slate-400/50 hover:bg-slate-400 mb-1.5 mx-auto cursor-grab active:cursor-grabbing transition-colors"
          title="Sürükle veya Konum Menüsünü Aç"
        />

        {/* Position Menu Dropdown */}
        {showPositionMenu && (
          <div className="absolute top-10 left-1/2 -translate-x-1/2 bg-slate-900 border border-slate-700 p-2 rounded-2xl shadow-2xl z-50 flex flex-col gap-1 min-w-[180px] text-xs text-white animate-in zoom-in-95">
            <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 px-2 py-1">
              Çubuk Konumu:
            </span>
            {[
              { id: "top_dock", name: "Üst Ortaya Sabitle", icon: PanelTop },
              { id: "bottom_dock", name: "Alt Ortaya Sabitle", icon: PanelBottom },
              { id: "floating", name: "Serbest Sürükle (X, Y Kayıt)", icon: Move },
            ].map((p) => {
              const IconC = p.icon;
              const isCur = dockPosition === p.id;
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => {
                    setDockPosition(p.id as DockPositionMode);
                    setShowPositionMenu(false);
                  }}
                  className={`w-full text-left px-2.5 py-1.5 rounded-xl flex items-center justify-between gap-2 transition-colors cursor-pointer ${
                    isCur ? "bg-teal-600 text-white font-bold" : "hover:bg-slate-800 text-slate-300"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <IconC className="w-3.5 h-3.5 text-amber-400" />
                    <span>{p.name}</span>
                  </div>
                  {isCur && <Check className="w-3.5 h-3.5 text-white" />}
                </button>
              );
            })}
          </div>
        )}

        {/* ========================================================================= */}
        {/* TOOLBAR CONTROLS ROW (OR COLLAPSED COMPACT PILL)                          */}
        {/* ========================================================================= */}
        {isCollapsed ? (
          <div className="flex items-center gap-2 px-1">
            <button
              type="button"
              onClick={() => setShowQuickPalette((prev) => !prev)}
              className="p-1 rounded-xl flex items-center gap-1 cursor-pointer"
              title="Aktif Araç - Hızlı palet için dokunun"
            >
              {activeTool === "fountain" && <SkeuomorphicFountainPen color={activeColor} size={dynIconSize} isActive={true} />}
              {activeTool === "pencil" && <SkeuomorphicPencil color={activeColor} size={dynIconSize} isActive={true} />}
              {activeTool === "highlighter" && <SkeuomorphicHighlighter color={activeColor} size={dynIconSize} isActive={true} />}
              {activeTool === "recall_tape" && <SkeuomorphicRecallTape color={settings.recallTapeColor || "#F59E0B"} size={dynIconSize} isActive={true} />}
              {activeTool === "eraser" && <SkeuomorphicEraser size={dynIconSize} isActive={true} />}
              {activeTool === "lasso_cut" && <SkeuomorphicLasso color={activeColor} size={dynIconSize} isActive={true} />}
              {activeTool === "laser_marker" && <SkeuomorphicLaserMarker color={activeColor} size={dynIconSize} isActive={true} />}
            </button>
            <button
              type="button"
              onClick={() => setIsCollapsed(false)}
              className="p-1.5 rounded-xl hover:bg-slate-200/80 dark:hover:bg-slate-800 text-teal-600 dark:text-teal-400 cursor-pointer"
              title="Çubuğu Genişlet"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        ) : (
        <div className="flex items-center gap-1 sm:gap-2 flex-wrap justify-center">
          
          {/* ======================================================================= */}
          {/* 1. SOL BÖLGE: HIZLI EYLEMLER (GERİ AL & İLERİ AL)                        */}
          {/* ======================================================================= */}
          <div className="flex items-center gap-1">
            {onUndo && (
              <button
                type="button"
                onClick={onUndo}
                className="p-1.5 sm:p-2 rounded-2xl hover:bg-slate-200/80 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white transition-colors cursor-pointer"
                title="Geri Al (Undo)"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}

            {onRedo && (
              <button
                type="button"
                onClick={onRedo}
                className="p-1.5 sm:p-2 rounded-2xl hover:bg-slate-200/80 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-950 dark:hover:text-white transition-colors cursor-pointer"
                title="İleri Al (Redo)"
              >
                <RotateCw className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="h-7 w-[1.5px] bg-slate-300/80 dark:bg-slate-700/80 mx-1 shrink-0" />

          {/* ======================================================================= */}
          {/* 2. MERKEZ BÖLGE (ARAÇLAR: DOLMA, KURŞUN, FOSFORLU, HAFIZA BANDI)         */}
          {/* AKTİF ARAÇ ANİMASYONU: 15px translateY kalkma ve yumuşak gölge         */}
          {/* ======================================================================= */}
          <div className="flex items-center gap-1 sm:gap-1.5">
            {/* DOLMA KALEM (FOUNTAIN PEN) */}
            {(() => {
              const isSelected = activeTool === "fountain";
              return (
                <button
                  type="button"
                  onClick={() => handleToolClick("fountain")}
                  className={`group relative p-1.5 sm:p-2 rounded-2xl transition-all duration-200 cursor-pointer flex flex-col items-center ${
                    isSelected
                      ? "-translate-y-[15px] shadow-[0_14px_24px_-4px_rgba(0,0,0,0.35)] bg-white dark:bg-slate-800 ring-2 ring-teal-400 z-20"
                      : "hover:bg-slate-200/60 dark:hover:bg-slate-800/60 hover:-translate-y-1"
                  }`}
                  title="Dolma Kalem (Açı & Basınç Duyarlı) - İkinci tıkta hızlı palet"
                >
                  <SkeuomorphicFountainPen
                    color={activeColor}
                    size={dynIconSize}
                    isActive={isSelected}
                  />
                  {isSelected && (
                    <span className="w-1.5 h-1.5 rounded-full bg-teal-500 mt-0.5" />
                  )}
                </button>
              );
            })()}

            {/* KURŞUN KALEM (PENCIL) */}
            {(() => {
              const isSelected = activeTool === "pencil";
              return (
                <button
                  type="button"
                  onClick={() => handleToolClick("pencil")}
                  className={`group relative p-1.5 sm:p-2 rounded-2xl transition-all duration-200 cursor-pointer flex flex-col items-center ${
                    isSelected
                      ? "-translate-y-[15px] shadow-[0_14px_24px_-4px_rgba(0,0,0,0.35)] bg-white dark:bg-slate-800 ring-2 ring-amber-400 z-20"
                      : "hover:bg-slate-200/60 dark:hover:bg-slate-800/60 hover:-translate-y-1"
                  }`}
                  title="Kurşun Kalem (Mat Grafit Doku) - İkinci tıkta hızlı palet"
                >
                  <SkeuomorphicPencil
                    color={activeColor}
                    size={dynIconSize}
                    isActive={isSelected}
                  />
                  {isSelected && (
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-0.5" />
                  )}
                </button>
              );
            })()}

            {/* FOSFORLU KALEM (HIGHLIGHTER) */}
            {(() => {
              const isSelected = activeTool === "highlighter";
              return (
                <button
                  type="button"
                  onClick={() => handleToolClick("highlighter")}
                  className={`group relative p-1.5 sm:p-2 rounded-2xl transition-all duration-200 cursor-pointer flex flex-col items-center ${
                    isSelected
                      ? "-translate-y-[15px] shadow-[0_14px_24px_-4px_rgba(0,0,0,0.35)] bg-white dark:bg-slate-800 ring-2 ring-yellow-400 z-20"
                      : "hover:bg-slate-200/60 dark:hover:bg-slate-800/60 hover:-translate-y-1"
                  }`}
                  title="Fosforlu Kalem (Yarı Şeffaf Neon Marker) - İkinci tıkta hızlı palet"
                >
                  <SkeuomorphicHighlighter
                    color={activeColor}
                    size={dynIconSize}
                    isActive={isSelected}
                  />
                  {isSelected && (
                    <span className="w-1.5 h-1.5 rounded-full bg-yellow-400 mt-0.5" />
                  )}
                </button>
              );
            })()}

            {/* HAFIZA BANDI (ACTIVE RECALL TAPE) */}
            {(() => {
              const isSelected = activeTool === "recall_tape";
              return (
                <button
                  type="button"
                  onClick={() => handleToolClick("recall_tape")}
                  className={`group relative p-1.5 sm:p-2 rounded-2xl transition-all duration-200 cursor-pointer flex flex-col items-center ${
                    isSelected
                      ? "-translate-y-[15px] shadow-[0_14px_24px_-4px_rgba(0,0,0,0.35)] bg-white dark:bg-slate-800 ring-2 ring-amber-500 z-20"
                      : "hover:bg-slate-200/60 dark:hover:bg-slate-800/60 hover:-translate-y-1"
                  }`}
                  title="Hafıza Bandı (Active Recall Tape: Kapat ve Dokununca Cevabı Göster)"
                >
                  <SkeuomorphicRecallTape
                    color={settings.recallTapeColor || "#F59E0B"}
                    size={dynIconSize}
                    isActive={isSelected}
                  />
                  {isSelected && (
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-0.5" />
                  )}
                </button>
              );
            })()}

            {/* AYIRICI ÇİZGİ (DIVIDER) */}
            <div className="h-7 w-[1.5px] bg-slate-300/80 dark:bg-slate-700/80 mx-1 shrink-0" />

            {/* AKILLI SİLGİ (SMART ERASER WITH LAYER FILTER) */}
            {(() => {
              const isSelected = activeTool === "eraser";
              return (
                <div className="relative flex items-center">
                  <button
                    type="button"
                    onClick={() => {
                      if (activeTool === "eraser") {
                        setShowEraserFilterMenu((prev) => !prev);
                      } else {
                        onChangeTool("eraser");
                        closeAllPopups();
                      }
                    }}
                    className={`group relative p-1.5 sm:p-2 rounded-2xl transition-all duration-200 cursor-pointer flex flex-col items-center ${
                      isSelected
                        ? "-translate-y-[15px] shadow-[0_14px_24px_-4px_rgba(0,0,0,0.35)] bg-white dark:bg-slate-800 ring-2 ring-rose-400 z-20"
                        : "hover:bg-slate-200/60 dark:hover:bg-slate-800/60 hover:-translate-y-1"
                    }`}
                    title="Akıllı Silgi (Katman Filtresi için tekrar dokunun)"
                  >
                    <SkeuomorphicEraser size={dynIconSize} isActive={isSelected} />
                    {isSelected && (
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-0.5" />
                    )}
                  </button>

                  {/* Dropdown chevron indicator for layer filter */}
                  <button
                    type="button"
                    onClick={() => {
                      setShowEraserFilterMenu((prev) => !prev);
                      setShowLassoActions(false);
                      setShowQuickPalette(false);
                    }}
                    className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-white transition-colors cursor-pointer"
                    title="Silgi Katman Filtresi Menüsü"
                  >
                    <ChevronDown className="w-3 h-3" />
                  </button>

                  {/* Smart Eraser Layer Filter Menu Dropdown */}
                  {showEraserFilterMenu && (
                    <div className="absolute top-12 left-0 bg-slate-900 border border-slate-700 p-2.5 rounded-2xl shadow-2xl z-50 flex flex-col gap-1 min-w-[210px] text-xs text-white animate-in zoom-in-95">
                      <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 px-1">
                        Akıllı Katman Silici:
                      </span>
                      {[
                        { id: "all", label: "Tümünü Sil", desc: "Çizim, vurgu ve bantları siler" },
                        { id: "ink_only", label: "Sadece Çizimi Sil", desc: "Vurgu ve bantları korur" },
                        { id: "highlighter_only", label: "Sadece Vurgulayıcıyı Sil", desc: "El yazısını korur" },
                        { id: "tape_only", label: "Sadece Hafıza Bandını Sil", desc: "Altındaki bilgiyi korur" },
                      ].map((f) => {
                        const isSel = localEraserFilter === f.id;
                        return (
                          <button
                            key={f.id}
                            type="button"
                            onClick={() => handleSelectEraserFilter(f.id as SmartEraserFilterMode)}
                            className={`text-left p-2 rounded-xl flex items-center justify-between transition-colors cursor-pointer ${
                              isSel ? "bg-rose-700 text-white font-bold" : "hover:bg-slate-800 text-slate-300"
                            }`}
                          >
                            <div>
                              <p className="font-bold text-xs">{f.label}</p>
                              <p className="text-[10px] text-slate-400">{f.desc}</p>
                            </div>
                            {isSel && <Check className="w-3.5 h-3.5 text-amber-300 shrink-0" />}
                          </button>
                        );
                      })}

                      {/* Pixel vs Stroke Toggle */}
                      <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                        <span className="text-[10px] text-slate-400">Silme Modu:</span>
                        <button
                          type="button"
                          onClick={toggleEraserMode}
                          className="px-2 py-0.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-[10px] font-mono text-amber-300 border border-slate-700"
                        >
                          {localEraserMode === "pixel" ? "Piksel Hassas" : "Tüm Darbe"}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })()}

            {/* LASSO ARACI (LASSO & CUT WITH OCR / LINK) */}
            {(() => {
              const isSelected = activeTool === "lasso_cut";
              return (
                <div className="relative flex items-center">
                  <button
                    type="button"
                    onClick={() => {
                      if (activeTool === "lasso_cut") {
                        setShowLassoActions((prev) => !prev);
                      } else {
                        onChangeTool("lasso_cut");
                        setShowLassoActions(true);
                      }
                      setShowEraserFilterMenu(false);
                      setShowQuickPalette(false);
                    }}
                    className={`group relative p-1.5 sm:p-2 rounded-2xl transition-all duration-200 cursor-pointer flex flex-col items-center ${
                      isSelected
                        ? "-translate-y-[15px] shadow-[0_14px_24px_-4px_rgba(0,0,0,0.35)] bg-white dark:bg-slate-800 ring-2 ring-teal-500 z-20"
                        : "hover:bg-slate-200/60 dark:hover:bg-slate-800/60 hover:-translate-y-1"
                    }`}
                    title="Kement Aracı (Lasso: Seçim, OCR ve Link Ekle)"
                  >
                    <SkeuomorphicLasso
                      color={activeColor}
                      size={dynIconSize}
                      isActive={isSelected}
                    />
                    {isSelected && (
                      <span className="w-1.5 h-1.5 rounded-full bg-teal-500 mt-0.5" />
                    )}
                  </button>

                  {/* Lasso Actions Popup */}
                  {isSelected && showLassoActions && (
                    <div className="absolute top-12 left-0 bg-slate-900 border border-slate-700 p-2 rounded-2xl shadow-2xl z-50 flex items-center gap-1.5 text-xs text-white animate-in zoom-in-95">
                      {onRecognizeText && (
                        <button
                          type="button"
                          onClick={() => {
                            onRecognizeText();
                            setShowLassoActions(false);
                          }}
                          className="px-2.5 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold flex items-center gap-1 cursor-pointer whitespace-nowrap"
                        >
                          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                          <span>Metne Çevir (OCR)</span>
                        </button>
                      )}
                      {onAddBidirectionalLink && (
                        <button
                          type="button"
                          onClick={() => {
                            onAddBidirectionalLink();
                            setShowLassoActions(false);
                          }}
                          className="px-2.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold flex items-center gap-1 cursor-pointer whitespace-nowrap"
                        >
                          <Link className="w-3.5 h-3.5 text-sky-300" />
                          <span>[[Link]] Ekle</span>
                        </button>
                      )}
                    </div>
                  )}
                </div>
              );
            })()}

            {/* LAZER İŞARETLEYİCİ (LASER MARKER) */}
            {(() => {
              const isSelected = activeTool === "laser_marker";
              return (
                <button
                  type="button"
                  onClick={() => handleToolClick("laser_marker")}
                  className={`group relative p-1.5 sm:p-2 rounded-2xl transition-all duration-200 cursor-pointer flex flex-col items-center ${
                    isSelected
                      ? "-translate-y-[15px] shadow-[0_14px_24px_-4px_rgba(0,0,0,0.35)] bg-white dark:bg-slate-800 ring-2 ring-rose-500 z-20"
                      : "hover:bg-slate-200/60 dark:hover:bg-slate-800/60 hover:-translate-y-1"
                  }`}
                  title="Lazer İşaretleyici (Sunum Vurgu İzi)"
                >
                  <SkeuomorphicLaserMarker
                    color={activeColor}
                    size={dynIconSize}
                    isActive={isSelected}
                  />
                  {isSelected && (
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mt-0.5" />
                  )}
                </button>
              );
            })()}
          </div>

          <div className="h-7 w-[1.5px] bg-slate-300/80 dark:bg-slate-700/80 mx-1 shrink-0" />

          {/* ======================================================================= */}
          {/* 3. SAĞ BÖLGE (GENİŞLETME OKU & HIZLI PALET AÇICI)                       */}
          {/* ======================================================================= */}
          <div className="flex items-center gap-1">
            {/* Quick Palette Opener Button */}
            <button
              type="button"
              onClick={() => setShowQuickPalette((prev) => !prev)}
              className={`p-1.5 sm:p-2 rounded-2xl transition-all cursor-pointer flex items-center gap-1 ${
                showQuickPalette
                  ? "bg-teal-600 text-white shadow-md ring-2 ring-teal-400"
                  : "hover:bg-slate-200/80 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
              }`}
              title="Hızlı Palet (Kalınlık & 5 Favori Renk)"
            >
              <Palette className="w-4 h-4 text-teal-500" />
            </button>

            {/* Smart Shape Recognition Button */}
            {onToggleShapeRecognition && (
              <button
                type="button"
                onClick={onToggleShapeRecognition}
                className={`p-1.5 sm:p-2 rounded-2xl transition-all cursor-pointer ${
                  isShapeRecognitionActive
                    ? "bg-amber-500 text-slate-950 font-black shadow-md ring-2 ring-amber-300"
                    : "hover:bg-slate-200/80 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400"
                }`}
                title="Akıllı Geometrik Şekil Tanıma"
              >
                <Shapes className="w-4 h-4" />
              </button>
            )}

            {/* Sağ Üst Köşede Çubuğu Açıp Kapatacak Minik Genişletme Oku (Expand Arrow) */}
            <button
              type="button"
              onClick={() => setIsCollapsed((prev) => !prev)}
              className="p-1 sm:p-1.5 rounded-xl hover:bg-slate-200/80 dark:hover:bg-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-white transition-colors cursor-pointer"
              title={isCollapsed ? "Çubuğu Genişlet" : "Çubuğu Daralt"}
            >
              {isCollapsed ? (
                <ChevronRight className="w-3.5 h-3.5" />
              ) : (
                <ChevronLeft className="w-3.5 h-3.5" />
              )}
            </button>

            {/* Close Button */}
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="p-1 sm:p-1.5 rounded-xl hover:bg-rose-100 dark:hover:bg-rose-950/60 text-slate-400 hover:text-rose-500 transition-colors cursor-pointer"
                title="Çizim Çubuğunu Gizle"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
        )}
      </div>
    </motion.div>
  );
};
