import React, { useState } from 'react';
import {
  Plus,
  Play,
  ArrowLeft,
  Upload,
  Download,
  Trash2,
  ArrowUp,
  ArrowDown,
  Edit2,
  Folder,
  Music,
  ListMusic,
} from 'lucide-react';
import { Song, Playlist } from '../types';
import { ArtworkImage } from './ArtworkImage';

interface PlaylistsScreenProps {
  playlists: Playlist[];
  songs: Song[];
  onCreatePlaylist: (name: string, description: string) => void;
  onUpdatePlaylist: (playlist: Playlist) => void;
  onDeletePlaylist: (id: string) => void;
  onPlaySong: (song: Song, contextList: Song[]) => void;
  onExportPlaylist: (playlist: Playlist) => void;
  onImportPlaylist: (file: File) => void;
}

export const PlaylistsScreen: React.FC<PlaylistsScreenProps> = ({
  playlists,
  songs,
  onCreatePlaylist,
  onUpdatePlaylist,
  onDeletePlaylist,
  onPlaySong,
  onExportPlaylist,
  onImportPlaylist,
}) => {
  const [selectedPlaylistId, setSelectedPlaylistId] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');

  const selectedPlaylist = playlists.find((p) => p.id === selectedPlaylistId);
  const playlistSongs = selectedPlaylist
    ? selectedPlaylist.songIds
        .map((id) => songs.find((s) => s.id === id))
        .filter((s): s is Song => s !== undefined)
    : [];

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    onCreatePlaylist(newTitle.trim(), newDesc.trim());
    setNewTitle('');
    setNewDesc('');
    setShowCreateModal(false);
  };

  const moveTrack = (index: number, direction: 'up' | 'down') => {
    if (!selectedPlaylist) return;
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= selectedPlaylist.songIds.length) return;

    const newSongIds = [...selectedPlaylist.songIds];
    const temp = newSongIds[index];
    newSongIds[index] = newSongIds[targetIdx];
    newSongIds[targetIdx] = temp;

    onUpdatePlaylist({
      ...selectedPlaylist,
      songIds: newSongIds,
    });
  };

  const removeTrack = (songId: string) => {
    if (!selectedPlaylist) return;
    onUpdatePlaylist({
      ...selectedPlaylist,
      songIds: selectedPlaylist.songIds.filter((id) => id !== songId),
    });
  };

  const handleCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!selectedPlaylist || !e.target.files?.[0]) return;
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      onUpdatePlaylist({
        ...selectedPlaylist,
        coverUrl: reader.result as string,
      });
    };
    reader.readAsDataURL(file);
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onImportPlaylist(file);
    }
  };

  return (
    <div className="space-y-4 pb-28 pt-2">
      {/* If viewing a single playlist */}
      {selectedPlaylist ? (
        <div className="space-y-5">
          {/* Header */}
          <div className="flex items-center justify-between">
            <button
              onClick={() => setSelectedPlaylistId(null)}
              className="flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-slate-100 transition-colors"
            >
              <ArrowLeft size={16} />
              <span>All Playlists</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onExportPlaylist(selectedPlaylist)}
                className="p-2 text-slate-400 hover:text-emerald-400 hover:bg-slate-800 rounded-lg transition-colors"
                title="Export Playlist JSON"
              >
                <Download size={18} />
              </button>
              <button
                onClick={() => {
                  if (confirm(`Delete playlist "${selectedPlaylist.name}"?`)) {
                    onDeletePlaylist(selectedPlaylist.id);
                    setSelectedPlaylistId(null);
                  }
                }}
                className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors"
                title="Delete Playlist"
              >
                <Trash2 size={18} />
              </button>
            </div>
          </div>

          {/* Playlist Hero Info */}
          <div className="flex items-start gap-4 p-4 rounded-2xl bg-[#12181F] border border-slate-800">
            <div className="relative group w-24 h-24 rounded-xl overflow-hidden shadow-lg border border-slate-700/60 flex-shrink-0">
              <ArtworkImage
                artworkUrl={selectedPlaylist.coverUrl || playlistSongs[0]?.artworkUrl}
                alt={selectedPlaylist.name}
                className="w-full h-full object-cover"
                iconSize={32}
              />
              <label
                htmlFor="cover-upload"
                className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition-opacity"
                title="Change cover artwork"
              >
                <Edit2 size={18} className="text-white" />
              </label>
              <input
                id="cover-upload"
                type="file"
                accept="image/*"
                onChange={handleCoverUpload}
                className="hidden"
              />
            </div>

            <div className="flex-1 min-w-0">
              <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-400">
                PLAYLIST
              </span>
              <h2 className="text-xl font-bold text-slate-100 truncate mt-0.5">
                {selectedPlaylist.name}
              </h2>
              {selectedPlaylist.description && (
                <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                  {selectedPlaylist.description}
                </p>
              )}
              <div className="flex items-center gap-3 mt-3">
                <span className="text-xs text-slate-400">
                  {playlistSongs.length} tracks
                </span>
                {playlistSongs.length > 0 && (
                  <button
                    onClick={() => onPlaySong(playlistSongs[0], playlistSongs)}
                    className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-all shadow-md"
                  >
                    <Play size={14} fill="currentColor" />
                    <span>Play All</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Songs list with reorder buttons */}
          {playlistSongs.length === 0 ? (
            <div className="text-center py-12 px-4 rounded-xl bg-[#12181F]/50 border border-slate-800">
              <Folder size={32} className="mx-auto text-slate-600 mb-2" />
              <p className="text-sm font-semibold text-slate-300">
                This playlist is empty
              </p>
              <p className="text-xs text-slate-500 mt-1">
                Go to your Library and tap "Add to Playlist" on any song.
              </p>
            </div>
          ) : (
            <div className="space-y-1.5">
              {playlistSongs.map((song, index) => (
                <div
                  key={`${song.id}-${index}`}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-[#12181F] hover:bg-[#1A232C] border border-slate-800/80 transition-colors"
                >
                  <div
                    onClick={() => onPlaySong(song, playlistSongs)}
                    className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer"
                  >
                    <span className="text-xs font-mono text-slate-500 w-5">
                      {index + 1}
                    </span>
                    <ArtworkImage
                      artworkUrl={song.artworkUrl}
                      alt={song.title}
                      className="w-10 h-10 rounded-lg"
                      iconSize={18}
                    />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-slate-100 truncate">
                        {song.title}
                      </p>
                      <p className="text-xs text-slate-400 truncate">
                        {song.artist}
                      </p>
                    </div>
                  </div>

                  {/* Reordering and remove actions */}
                  <div className="flex items-center gap-1">
                    <button
                      disabled={index === 0}
                      onClick={() => moveTrack(index, 'up')}
                      className="p-1.5 text-slate-500 hover:text-slate-200 disabled:opacity-20"
                      title="Move up"
                    >
                      <ArrowUp size={16} />
                    </button>
                    <button
                      disabled={index === playlistSongs.length - 1}
                      onClick={() => moveTrack(index, 'down')}
                      className="p-1.5 text-slate-500 hover:text-slate-200 disabled:opacity-20"
                      title="Move down"
                    >
                      <ArrowDown size={16} />
                    </button>
                    <button
                      onClick={() => removeTrack(song.id)}
                      className="p-1.5 text-slate-500 hover:text-rose-400"
                      title="Remove from playlist"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        /* All Playlists Grid */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-slate-100">
                Playlists
              </h1>
              <p className="text-xs text-slate-400 mt-0.5">
                {playlists.length} playlists created
              </p>
            </div>

            <div className="flex items-center gap-2">
              <label
                htmlFor="import-playlist"
                className="p-2 text-slate-300 hover:text-emerald-400 border border-slate-700 hover:bg-slate-800 rounded-lg cursor-pointer transition-colors"
                title="Import Playlist JSON"
              >
                <Upload size={16} />
              </label>
              <input
                id="import-playlist"
                type="file"
                accept=".json,application/json"
                onChange={handleImportFile}
                className="hidden"
              />

              <button
                onClick={() => setShowCreateModal(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-xs transition-all shadow-sm"
              >
                <Plus size={16} />
                <span>New Playlist</span>
              </button>
            </div>
          </div>

          {playlists.length === 0 ? (
            <div className="text-center py-16 px-4 bg-[#12181F]/40 rounded-2xl border border-slate-800/60">
              <ListMusic size={36} className="mx-auto text-emerald-400 mb-2" />
              <p className="text-sm font-semibold text-slate-300">
                No playlists yet
              </p>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                Create custom playlists to group songs for workouts, focus, or late night listening.
              </p>
              <button
                onClick={() => setShowCreateModal(true)}
                className="mt-4 px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-xs inline-flex items-center gap-1.5 transition-all"
              >
                <Plus size={16} />
                <span>Create First Playlist</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {playlists.map((playlist) => {
                const firstSong = songs.find((s) => s.id === playlist.songIds[0]);
                const cover = playlist.coverUrl || firstSong?.artworkUrl;

                return (
                  <div
                    key={playlist.id}
                    onClick={() => setSelectedPlaylistId(playlist.id)}
                    className="group bg-[#12181F] p-3 rounded-2xl border border-slate-800 hover:border-emerald-500/40 cursor-pointer transition-all"
                  >
                    <div className="relative aspect-square w-full rounded-xl overflow-hidden">
                      <ArtworkImage
                        artworkUrl={cover}
                        alt={playlist.name}
                        className="w-full h-full object-cover"
                        iconSize={40}
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                        <div className="w-10 h-10 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center shadow-lg">
                          <Play size={18} fill="currentColor" className="ml-0.5" />
                        </div>
                      </div>
                    </div>

                    <h3 className="text-sm font-bold text-slate-100 truncate mt-2.5">
                      {playlist.name}
                    </h3>
                    <p className="text-xs text-slate-400 truncate mt-0.5">
                      {playlist.songIds.length} tracks
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Create Playlist Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#12181F] border border-slate-700 rounded-2xl p-5 shadow-2xl">
            <h3 className="text-base font-bold text-slate-100">Create Playlist</h3>
            <form onSubmit={handleCreateSubmit} className="space-y-4 mt-4">
              <div>
                <label className="text-xs font-medium text-slate-400">
                  Playlist Name
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g., Roadtrip Chill"
                  className="w-full mt-1 px-3 py-2 bg-[#1A232C] text-sm text-slate-100 rounded-lg border border-slate-700 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-slate-400">
                  Description (optional)
                </label>
                <textarea
                  rows={2}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="What's this playlist for?"
                  className="w-full mt-1 px-3 py-2 bg-[#1A232C] text-sm text-slate-100 rounded-lg border border-slate-700 focus:outline-none focus:border-emerald-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition-colors"
                >
                  Create
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
