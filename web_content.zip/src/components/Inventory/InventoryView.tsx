import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Plus, 
  Package, 
  AlertTriangle, 
  Edit3, 
  Trash2, 
  ShoppingBag, 
  TrendingUp, 
  ArrowDownCircle, 
  X,
  Layers,
  Check
} from 'lucide-react';
import { Product, ProductCategory, UnitType, UserRole } from '../../types';
import { formatTaka, toBnNum } from '../../utils/formatters';
import { AddProductModal } from '../Products/AddProductModal';

interface InventoryViewProps {
  products: Product[];
  onAddProduct: (product: Omit<Product, 'id'>) => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  onRestockProduct: (data: {
    productId: string;
    productName: string;
    quantity: number;
    unitCost: number;
    supplierName?: string;
    invoiceNo?: string;
  }) => void;
  activeRole: UserRole;
}

const CATEGORIES: ('সব' | ProductCategory)[] = [
  'সব',
  'চাল ও ডাল',
  'তেল ও ঘি',
  'পেঁয়াজ, আলু ও রসুন',
  'মসলা ও লবণ',
  'স্ন্যাক্স ও নুডলস',
  'চা, চিনি ও বেকারি',
  'দুগ্ধ ও ডিম',
  'সাবান ও প্রসাধন',
  'অন্যান্য',
];

const UNITS: UnitType[] = ['কেজি', 'গ্রাম', 'লিটার', 'মিলি', 'প্যাকেট', 'পিস', 'ডজন', 'হালি', 'বস্তা'];

export const InventoryView: React.FC<InventoryViewProps> = ({
  products,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  onRestockProduct,
  activeRole,
}) => {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'সব' | ProductCategory>('সব');
  const [lowStockOnly, setLowStockOnly] = useState(false);

  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [restockProductTarget, setRestockProductTarget] = useState<Product | null>(null);

  // Restock Form State
  const [restockQty, setRestockQty] = useState('');
  const [restockCost, setRestockCost] = useState('');
  const [supplierName, setSupplierName] = useState('');
  const [supplierInvoice, setSupplierInvoice] = useState('');

  // Low Stock Items
  const lowStockItems = useMemo(() => {
    return products.filter((p) => p.stock <= p.lowStockAlert);
  }, [products]);

  // Filtered Products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      if (lowStockOnly && p.stock > p.lowStockAlert) return false;
      if (selectedCategory !== 'সব' && p.category !== selectedCategory) return false;
      const q = search.toLowerCase().trim();
      if (!q) return true;
      return (
        p.nameBn.toLowerCase().includes(q) ||
        p.nameEn.toLowerCase().includes(q) ||
        (p.barcode && p.barcode.includes(q))
      );
    });
  }, [products, lowStockOnly, selectedCategory, search]);

  // Open Edit Modal
  const handleOpenEdit = (p: Product) => {
    setEditingProduct(p);
    setShowAddModal(true);
  };

  // Open Add Modal
  const handleOpenAdd = () => {
    setEditingProduct(null);
    setShowAddModal(true);
  };

  // Open Restock Modal
  const handleOpenRestock = (p: Product) => {
    setRestockProductTarget(p);
    setRestockQty('10');
    setRestockCost(String(p.purchasePrice));
    setSupplierName('');
    setSupplierInvoice('');
  };

  // Submit Restock
  const handleSubmitRestock = (e: React.FormEvent) => {
    e.preventDefault();
    if (!restockProductTarget) return;
    const qty = parseFloat(restockQty);
    const cost = parseFloat(restockCost);

    if (isNaN(qty) || qty <= 0 || isNaN(cost) || cost <= 0) {
      alert('সঠিক পরিমাণ ও দর প্রদান করুন');
      return;
    }

    onRestockProduct({
      productId: restockProductTarget.id,
      productName: restockProductTarget.nameBn,
      quantity: qty,
      unitCost: cost,
      supplierName: supplierName.trim() || undefined,
      invoiceNo: supplierInvoice.trim() || undefined,
    });

    setRestockProductTarget(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-5">
      
      {/* Title & Actions */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            দোকানের পণ্যের তালিকা ও স্টক ইনভেন্টরি
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            সকল পণ্যের কেনা-বেচার দর ও বর্তমান মজুদের রিয়েল-টাইম তথ্য
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-4 py-2.5 bg-emerald-800 text-white rounded-xl hover:bg-emerald-700 text-sm font-semibold shadow-sm transition"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>নতুন পণ্য যোগ করুন</span>
        </button>
      </div>

      {/* Automatic Low Stock Alert Banner */}
      {lowStockItems.length > 0 && (
        <div className="bg-amber-50 border border-amber-300 rounded-2xl p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-start gap-3">
            <div className="p-2 bg-amber-200/80 rounded-xl text-amber-900 shrink-0 mt-0.5">
              <AlertTriangle className="w-5 h-5 text-amber-800" />
            </div>
            <div>
              <h4 className="font-bold text-amber-900 text-sm">
                স্টক সতর্কবার্তা: {toBnNum(lowStockItems.length)} টি পণ্যের স্টক শেষ হওয়ার পথে!
              </h4>
              <p className="text-xs text-amber-800/90 mt-0.5">
                {lowStockItems.slice(0, 4).map((p) => `${p.nameBn} (${toBnNum(p.stock)} ${p.unit})`).join(', ')}
                {lowStockItems.length > 4 ? ` এবং আরও ${toBnNum(lowStockItems.length - 4)}টি` : ''}। গ্রাহক শূন্য হওয়ার আগেই এখনই নতুন মাল তোলার অর্ডার দিন।
              </p>
            </div>
          </div>

          <button
            onClick={() => setLowStockOnly(!lowStockOnly)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg shrink-0 transition ${
              lowStockOnly
                ? 'bg-amber-700 text-white'
                : 'bg-amber-200 text-amber-900 hover:bg-amber-300'
            }`}
          >
            {lowStockOnly ? 'সব পণ্য দেখুন' : 'লো স্টক পণ্যগুলো ফিল্টার করুন'}
          </button>
        </div>
      )}

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="পণ্য বা বারকোড খুঁজুন..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-emerald-600 focus:bg-white"
          />
        </div>

        {/* Category Filter */}
        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value as any)}
          className="px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-700"
        >
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
      </div>

      {/* Product Inventory Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
              <tr>
                <th className="py-3 px-4">পণ্যের নাম</th>
                <th className="py-3 px-4">ক্যাটাগরি</th>
                {activeRole === 'OWNER' && (
                  <th className="py-3 px-4 text-right">ক্রয় মূল্য</th>
                )}
                <th className="py-3 px-4 text-right">বিক্রয় মূল্য</th>
                {activeRole === 'OWNER' && (
                  <th className="py-3 px-4 text-right">একক লাভ</th>
                )}
                <th className="py-3 px-4 text-center">বর্তমান মজুদ (স্টক)</th>
                <th className="py-3 px-4 text-center">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredProducts.map((p) => {
                const isLow = p.stock <= p.lowStockAlert;
                const margin = +(p.sellPrice - p.purchasePrice).toFixed(2);

                return (
                  <tr key={p.id} className="hover:bg-slate-50/70 transition">
                    
                    {/* Name & Photo thumbnail */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-slate-100 border border-slate-200 overflow-hidden flex items-center justify-center shrink-0">
                          {p.imageUrl ? (
                            <img
                              src={p.imageUrl}
                              alt={p.nameBn}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <ShoppingBag className="w-4 h-4 text-emerald-600" />
                          )}
                        </div>
                        <div>
                          <div className="font-semibold text-slate-900">{p.nameBn}</div>
                          <div className="text-[11px] text-slate-500">{p.nameEn || p.unit}</div>
                        </div>
                      </div>
                    </td>

                    {/* Category */}
                    <td className="py-3 px-4 text-slate-600 text-xs">
                      {p.category}
                    </td>

                    {/* Purchase Price (Owner only) */}
                    {activeRole === 'OWNER' && (
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-600">
                        ৳{toBnNum(p.purchasePrice)}
                      </td>
                    )}

                    {/* Sell Price */}
                    <td className="py-3 px-4 text-right font-mono font-bold tabular-nums text-emerald-800">
                      ৳{toBnNum(p.sellPrice)} <span className="text-[11px] font-normal text-slate-400">/{p.unit}</span>
                    </td>

                    {/* Margin (Owner only) */}
                    {activeRole === 'OWNER' && (
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-700">
                        +৳{toBnNum(margin)}
                      </td>
                    )}

                    {/* Stock Status */}
                    <td className="py-3 px-4 text-center">
                      <div className="inline-flex items-center gap-1.5">
                        <span className={`font-mono font-bold tabular-nums ${isLow ? 'text-amber-700' : 'text-slate-800'}`}>
                          {toBnNum(p.stock)} {p.unit}
                        </span>
                        {isLow && (
                          <span className="px-1.5 py-0.2 rounded bg-amber-100 text-amber-800 text-[10px] font-bold">
                            কম
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        
                        {/* Quick Restock */}
                        <button
                          onClick={() => handleOpenRestock(p)}
                          className="px-2 py-1 bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-md text-xs font-semibold hover:bg-emerald-100 transition"
                          title="মাল ক্রয় / স্টক বৃদ্ধি"
                        >
                          + মাল ক্রয়
                        </button>

                        {/* Edit */}
                        <button
                          onClick={() => handleOpenEdit(p)}
                          className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg"
                          title="এডিট করুন"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>

                        {/* Delete */}
                        <button
                          onClick={() => {
                            if (confirm(`আপনি কি নিশ্চিত যে "${p.nameBn}" পণ্যটি মুছে ফেলতে চান?`)) {
                              onDeleteProduct(p.id);
                            }
                          }}
                          className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg"
                          title="মুছে ফেলুন"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>

                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Product Modal */}
      <AddProductModal
        isOpen={showAddModal}
        onClose={() => {
          setShowAddModal(false);
          setEditingProduct(null);
        }}
        onAddProduct={onAddProduct}
        editingProduct={editingProduct}
        onUpdateProduct={onUpdateProduct}
      />

      {/* Restock / মাল ক্রয় Modal */}
      {restockProductTarget && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 pb-2">
              <div>
                <h3 className="font-bold text-slate-900 text-sm">নতুন মাল ক্রয় ও স্টক বৃদ্ধি</h3>
                <p className="text-xs text-slate-500">{restockProductTarget.nameBn}</p>
              </div>
              <button
                onClick={() => setRestockProductTarget(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-xs flex justify-between">
              <span>বর্তমান মজুদ:</span>
              <span className="font-bold text-slate-800 font-mono">
                {toBnNum(restockProductTarget.stock)} {restockProductTarget.unit}
              </span>
            </div>

            <form onSubmit={handleSubmitRestock} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  নতুন ক্রয়কৃত পরিমাণ ({restockProductTarget.unit}):
                </label>
                <input
                  type="number"
                  step="any"
                  value={restockQty}
                  onChange={(e) => setRestockQty(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-base font-bold"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  ক্রয় দর প্রতি {restockProductTarget.unit} (৳):
                </label>
                <input
                  type="number"
                  step="any"
                  value={restockCost}
                  onChange={(e) => setRestockCost(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  সরবরাহকারী / আড়তের নাম:
                </label>
                <input
                  type="text"
                  placeholder="যেমন: শ্যামবাজার আড়ত / সিটি ডিস্ট্রিবিউটর"
                  value={supplierName}
                  onChange={(e) => setSupplierName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="bg-emerald-50 p-2.5 rounded-lg border border-emerald-200 flex justify-between text-xs">
                <span>মোট ক্রয় খরচ:</span>
                <span className="font-bold text-emerald-900 font-mono">
                  ৳ {toBnNum((parseFloat(restockQty) || 0) * (parseFloat(restockCost) || 0))}
                </span>
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setRestockProductTarget(null)}
                  className="flex-1 py-2 bg-slate-100 text-slate-700 rounded-lg font-medium"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-emerald-800 text-white rounded-lg font-bold hover:bg-emerald-700"
                >
                  স্টকে যোগ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
