import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  Award,
  CheckCircle,
  Clock,
  Code,
  Cpu,
  Globe,
  Layers,
  Play,
  Radio,
  Search,
  Server,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Smartphone,
  Sliders,
  Terminal,
  TrendingUp,
  Wrench,
  Zap,
} from 'lucide-react';
import { api } from '../services/api.ts';
import { CapabilityDescriptor, PermissionLevel, SkillDefinition, ToolDefinition } from '../types.ts';

interface ToolSkillEngineProps {
  tools: ToolDefinition[];
  skills: SkillDefinition[];
  onExecuteToolDirect: (toolName: string, params: Record<string, unknown>) => Promise<any>;
}

const PERMISSION_BADGES: Record<PermissionLevel, { label: string; class: string }> = {
  READ: { label: 'READ (Auto)', class: 'bg-emerald-50 text-emerald-800 border-emerald-200' },
  SAFE_WRITE: { label: 'SAFE WRITE (Audited)', class: 'bg-sky-50 text-sky-800 border-sky-200' },
  SENSITIVE: { label: 'SENSITIVE (Sandbox)', class: 'bg-amber-50 text-amber-900 border-amber-300' },
  EXTERNAL_ACTION: { label: 'EXTERNAL ACTION (Gated)', class: 'bg-rose-50 text-rose-800 border-rose-200' },
};

const MODE_BADGES: Record<string, { label: string; class: string }> = {
  REAL: { label: 'REAL', class: 'bg-emerald-100 text-emerald-900 border-emerald-300 font-bold' },
  SIMULATED: { label: 'SIMULATED', class: 'bg-indigo-100 text-indigo-900 border-indigo-300 font-bold' },
  UNAVAILABLE: { label: 'UNAVAILABLE', class: 'bg-rose-100 text-rose-900 border-rose-300 font-bold' },
  BLOCKED_REQUIRES_PERMISSION: {
    label: 'REQUIRES PERMISSION',
    class: 'bg-amber-100 text-amber-900 border-amber-300 font-bold',
  },
  FAILED: { label: 'FAILED', class: 'bg-red-100 text-red-900 border-red-300 font-bold' },
};

const SAFETY_BADGES: Record<string, { label: string; class: string }> = {
  SAFE: { label: 'SAFE', class: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  CAUTION: { label: 'CAUTION', class: 'bg-sky-50 text-sky-700 border-sky-200' },
  SENSITIVE: { label: 'SENSITIVE', class: 'bg-amber-50 text-amber-800 border-amber-300' },
  HAZARDOUS: { label: 'HAZARDOUS', class: 'bg-rose-50 text-rose-800 border-rose-300' },
};

export const ToolSkillEngine: React.FC<ToolSkillEngineProps> = ({
  tools,
  skills,
  onExecuteToolDirect,
}) => {
  const [activeTab, setActiveTab] = useState<'tools' | 'skills' | 'capabilities' | 'devices'>('tools');
  const [capabilities, setCapabilities] = useState<CapabilityDescriptor[]>([]);
  const [testToolModal, setTestToolModal] = useState<ToolDefinition | null>(null);
  const [testParamsJson, setTestParamsJson] = useState('{}');
  const [testResult, setTestResult] = useState<any>(null);
  const [isTesting, setIsTesting] = useState(false);

  useEffect(() => {
    api.getCapabilities()
      .then((res) => {
        if (res.capabilities) {
          setCapabilities(res.capabilities);
        }
      })
      .catch(() => {
        // Fallback capability descriptors if network latency occurs
      });
  }, []);

  const handleOpenTest = (tool: ToolDefinition) => {
    setTestToolModal(tool);
    setTestResult(null);

    // Formulate default params
    const defaultParams: Record<string, any> = {};
    if (tool.name === 'finance_analyzer') {
      defaultParams.mode = 'sip_calculator';
      defaultParams.monthlyAmount = 500;
      defaultParams.annualRate = 12;
      defaultParams.years = 5;
    } else if (tool.name === 'web_search') {
      defaultParams.query = 'Autonomous agent systems benchmarks';
      defaultParams.maxResults = 2;
    } else if (tool.name === 'code_analyzer') {
      defaultParams.code = 'function sortItems(arr) { return arr.slice().sort(); }';
    } else if (tool.name === 'security_audit_analyzer') {
      defaultParams.targetType = 'code';
      defaultParams.content = 'const apiKey = "12345";';
    } else if (tool.name === 'device_control_action') {
      defaultParams.action = 'open_settings';
      defaultParams.details = 'Launch device control intent';
    } else if (tool.name === 'system_diagnostics') {
      defaultParams.deepScan = true;
    } else {
      for (const [key, val] of Object.entries(tool.parameters || {})) {
        const info = val as { type?: string; required?: boolean };
        defaultParams[key] = info?.type === 'number' ? 10 : info?.type === 'boolean' ? true : 'example_input';
      }
    }
    setTestParamsJson(JSON.stringify(defaultParams, null, 2));
  };

  const handleRunDirectTest = async () => {
    if (!testToolModal) return;
    setIsTesting(true);
    setTestResult(null);
    try {
      const parsed = JSON.parse(testParamsJson);
      const res = await onExecuteToolDirect(testToolModal.name, parsed);
      setTestResult(res);
    } catch (err: any) {
      setTestResult({ success: false, error: err?.message || 'Invalid JSON input or execution failed' });
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div id="tool-skill-engine-panel" className="space-y-6">
      {/* Subsystem Switcher Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white border border-slate-200 p-5 rounded-2xl shadow-xs">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2 font-sans">
            <Wrench className="w-5 h-5 text-amber-600" />
            Tool & Capability Execution Foundation
          </h2>
          <p className="text-xs text-slate-600 font-mono mt-0.5">
            Strict capability contracts, explicit execution modes (REAL, SIMULATED, UNAVAILABLE), and permission gating.
          </p>
        </div>

        <div className="flex items-center gap-1 bg-slate-100 p-1.5 rounded-xl border border-slate-200 flex-wrap">
          <button
            onClick={() => setActiveTab('tools')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-semibold transition-all ${
              activeTab === 'tools'
                ? 'bg-white text-sky-900 border border-slate-200 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            TOOLS ({tools.length})
          </button>
          <button
            onClick={() => setActiveTab('capabilities')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-semibold transition-all ${
              activeTab === 'capabilities'
                ? 'bg-white text-emerald-900 border border-slate-200 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            CAPABILITIES ({capabilities.length || 13})
          </button>
          <button
            onClick={() => setActiveTab('skills')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-semibold transition-all ${
              activeTab === 'skills'
                ? 'bg-white text-purple-900 border border-slate-200 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            SKILLS ({skills.length})
          </button>
          <button
            onClick={() => setActiveTab('devices')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-semibold transition-all ${
              activeTab === 'devices'
                ? 'bg-white text-indigo-900 border border-slate-200 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            DEVICE STATUS
          </button>
        </div>
      </div>

      {/* TOOLS TAB */}
      {activeTab === 'tools' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {tools.map((tool) => {
            const badge = PERMISSION_BADGES[tool.permissionLevel] || PERMISSION_BADGES.READ;
            const modeBadge = MODE_BADGES[tool.executionMode || 'REAL'] || MODE_BADGES.REAL;
            const safetyBadge = SAFETY_BADGES[tool.safetyLevel || 'SAFE'] || SAFETY_BADGES.SAFE;

            return (
              <div
                key={tool.name}
                className="bg-white border border-slate-200 rounded-2xl p-5 flex flex-col justify-between hover:border-sky-300 hover:shadow-xs transition-all"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5 font-sans">
                        <Terminal className="w-4 h-4 text-sky-600" />
                        {tool.name}
                      </h3>
                      <div className="flex items-center gap-2 mt-1 flex-wrap">
                        <span className={`px-2 py-0.5 rounded text-[9px] font-mono border ${modeBadge.class}`}>
                          MODE: {modeBadge.label}
                        </span>
                        <span className={`px-2 py-0.5 rounded text-[9px] font-mono border ${safetyBadge.class}`}>
                          SAFETY: {safetyBadge.label}
                        </span>
                        <span className="text-[10px] font-mono text-slate-500 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {tool.timeoutMs}ms
                        </span>
                      </div>
                    </div>

                    <span className={`px-2.5 py-1 rounded-md text-[10px] font-mono border ${badge.class} font-bold`}>
                      {badge.label}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 font-sans leading-relaxed mb-3">{tool.description}</p>

                  {/* Parameters preview */}
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 mb-4 text-xs font-mono">
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1.5 font-bold">
                      Input Schema Parameters
                    </span>
                    <div className="space-y-1.5 max-h-28 overflow-y-auto pr-1 scrollbar-thin">
                      {Object.entries(tool.parameters || {}).map(([paramName, paramVal]) => {
                        const paramInfo = paramVal as { type?: string; required?: boolean };
                        return (
                          <div key={paramName} className="flex items-baseline justify-between text-[11px]">
                            <span className="text-sky-800 font-semibold">
                              {paramName} {paramInfo?.required ? '*' : ''}
                            </span>
                            <span className="text-slate-500 text-[10px]">({paramInfo?.type || 'any'})</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => handleOpenTest(tool)}
                  className="w-full py-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-sky-800 text-xs font-mono font-semibold flex items-center justify-center gap-2 transition-all shadow-xs"
                >
                  <Play className="w-3.5 h-3.5 text-sky-600" />
                  TEST TOOL RUNNER
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* CAPABILITIES TAB */}
      {activeTab === 'capabilities' && (
        <div className="space-y-4">
          <div className="bg-emerald-50/60 border border-emerald-200 rounded-2xl p-4 text-xs font-mono text-emerald-950 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <ShieldCheck className="w-5 h-5 text-emerald-600 flex-shrink-0" />
              <span>
                Truthful capability discovery registry: <strong>REAL</strong> capabilities execute live container I/O;
                <strong>SIMULATED</strong> execute sandboxed computations; <strong>UNAVAILABLE</strong> explicitly fail safe without inventing mock outputs.
              </span>
            </div>
            <span className="px-2.5 py-1 rounded-md bg-white border border-emerald-300 font-bold text-[11px]">
              {capabilities.length} REGISTERED
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {capabilities.map((cap) => {
              const modeClass =
                cap.availability === 'REAL'
                  ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                  : cap.availability === 'SIMULATED'
                  ? 'bg-indigo-100 text-indigo-900 border-indigo-300'
                  : 'bg-rose-100 text-rose-900 border-rose-300';

              return (
                <div
                  key={cap.id}
                  className="bg-white border border-slate-200 rounded-2xl p-4 flex flex-col justify-between hover:shadow-xs transition-all"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <h3 className="text-xs font-bold text-slate-900 font-sans">{cap.name}</h3>
                      <span className={`px-2 py-0.5 rounded text-[9px] font-mono border font-bold ${modeClass}`}>
                        {cap.availability}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600 font-sans leading-relaxed mb-3">{cap.description}</p>
                  </div>

                  <div className="space-y-1 text-[10px] font-mono border-t border-slate-100 pt-2.5 text-slate-500">
                    <div className="flex justify-between">
                      <span>CATEGORY:</span>
                      <strong className="text-slate-700">{cap.category}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>PERMISSION:</span>
                      <strong className="text-slate-700">{cap.requiredPermission}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>SAFETY:</span>
                      <strong className="text-slate-700">{cap.safetyLevel}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>PROVIDER:</span>
                      <strong className="text-slate-700">{cap.provider}</strong>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SKILLS TAB */}
      {activeTab === 'skills' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {skills.map((skill) => (
            <div
              key={skill.id}
              className="bg-white border border-slate-200 rounded-2xl p-5 flex flex-col justify-between hover:border-purple-300 hover:shadow-xs transition-all"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5 font-sans">
                      <Award className="w-4 h-4 text-purple-600" />
                      {skill.name}
                    </h3>
                    <span className="text-[10px] font-mono text-slate-500">VERSION {skill.version}</span>
                  </div>

                  <span className="px-2.5 py-1 rounded-md text-[10px] font-mono bg-purple-50 text-purple-800 border border-purple-200 font-bold">
                    {skill.status}
                  </span>
                </div>

                <p className="text-xs text-slate-600 font-sans leading-relaxed mb-3">{skill.description}</p>

                {/* Composed tools */}
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 mb-3 text-xs font-mono">
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider block mb-1.5 font-bold">
                    Orchestrated Tool Dependencies
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {skill.requiredTools.map((toolName) => (
                      <span
                        key={toolName}
                        className="px-2 py-0.5 rounded bg-white border border-slate-200 text-sky-800 text-[10px] font-semibold"
                      >
                        {toolName}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Permissions required */}
                <div className="flex items-center gap-1.5 text-[11px] font-mono text-slate-600">
                  <Shield className="w-3 h-3 text-slate-400" />
                  <span>Required Clearances:</span>
                  <span className="font-semibold text-slate-800">{skill.requiredPermissions.join(', ')}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* DEVICE STATUS PANEL */}
      {activeTab === 'devices' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
            <div className="flex items-center gap-3 mb-4 pb-3 border-b border-slate-200">
              <div className="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-200 flex items-center justify-center text-indigo-600">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900 font-sans">Device & App Control Subsystem</h3>
                <p className="text-xs text-slate-600 font-mono">
                  Real-time status of physical Android companion devices and host environment abstractions.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-rose-50/70 border border-rose-200 rounded-xl p-4">
                <span className="text-[10px] font-mono text-rose-700 uppercase font-bold block mb-1">
                  Android Companion Link
                </span>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                  <span className="text-sm font-bold font-mono text-rose-900">NOT CONNECTED</span>
                </div>
                <p className="text-[11px] text-rose-700 mt-2 font-sans">
                  Truthful status: No active ADB daemon or native mobile bridge bound to web runtime container.
                </p>
              </div>

              <div className="bg-emerald-50/70 border border-emerald-200 rounded-xl p-4">
                <span className="text-[10px] font-mono text-emerald-700 uppercase font-bold block mb-1">
                  Host Environment
                </span>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <span className="text-sm font-bold font-mono text-emerald-900">CLOUD / WEB CONTAINER</span>
                </div>
                <p className="text-[11px] text-emerald-700 mt-2 font-sans">
                  Linux sandboxed execution environment with Node.js runtime and SQLite database storage.
                </p>
              </div>

              <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-4">
                <span className="text-[10px] font-mono text-amber-700 uppercase font-bold block mb-1">
                  Native Device Actions
                </span>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  <span className="text-sm font-bold font-mono text-amber-900">UNAVAILABLE (SAFE)</span>
                </div>
                <p className="text-[11px] text-amber-700 mt-2 font-sans">
                  Requests to open apps, lock screen, or toggle device hardware return explicit UNAVAILABLE.
                </p>
              </div>
            </div>

            <h4 className="text-xs font-bold font-mono uppercase text-slate-800 mb-3">
              Environment Capability Breakdown
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-emerald-700 font-bold block mb-1.5 flex items-center gap-1.5">
                  <CheckCircle className="w-3.5 h-3.5" /> Supported in Current Environment
                </span>
                <ul className="space-y-1 text-[11px] text-slate-600">
                  <li>• Multi-Source Web Intelligence & Extract</li>
                  <li>• Sandboxed JavaScript/TypeScript Code Execution</li>
                  <li>• Static Security & Vulnerability Analysis</li>
                  <li>• Quantitative SIP & Paper Portfolio Modeling</li>
                  <li>• Persistent SQLite Memory & Fact Store</li>
                  <li>• Zero-Trust Permission Gated Dispatches</li>
                </ul>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-rose-700 font-bold block mb-1.5 flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5" /> Unavailable Without Native Companion
                </span>
                <ul className="space-y-1 text-[11px] text-slate-600">
                  <li>• Native Android App Launching / Screen Interaction</li>
                  <li>• Device Hardware Toggle (Wi-Fi, Bluetooth, Flashlight)</li>
                  <li>• SMS / Telephony Hardware Access</li>
                  <li>• Real-Money Brokerage Order Execution</li>
                  <li>• Offensive Penetration Testing / Exploit Dispatch</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Interactive Tool Test Modal */}
      {testToolModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-xl w-full p-5 shadow-xl space-y-4 font-mono text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <Wrench className="w-4 h-4 text-sky-600" />
                <h3 className="text-sm font-bold text-slate-900 font-sans">Test Tool: {testToolModal.name}</h3>
              </div>
              <button
                onClick={() => setTestToolModal(null)}
                className="text-slate-400 hover:text-slate-700 px-2 py-1 rounded-lg hover:bg-slate-100 transition-colors"
              >
                ✕
              </button>
            </div>

            <div>
              <label className="block text-[11px] text-slate-600 mb-1.5 font-bold">Execution Input JSON Parameters:</label>
              <textarea
                rows={6}
                value={testParamsJson}
                onChange={(e) => setTestParamsJson(e.target.value)}
                className="w-full p-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs font-mono focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500/30"
              />
            </div>

            <div className="flex items-center justify-between">
              <span className="text-slate-600 text-[11px]">
                Permission Level: <strong className="text-slate-900">{testToolModal.permissionLevel}</strong>
              </span>
              <button
                onClick={handleRunDirectTest}
                disabled={isTesting}
                className="px-5 py-2.5 rounded-xl bg-sky-700 hover:bg-sky-800 text-white font-bold flex items-center gap-2 transition-all disabled:opacity-50 shadow-xs"
              >
                <Play className="w-3.5 h-3.5" />
                {isTesting ? 'RUNNING...' : 'INVOKE TOOL'}
              </button>
            </div>

            {testResult && (
              <div className="mt-3 pt-3 border-t border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-slate-600 uppercase font-bold">Execution Telemetry:</span>
                  <div className="flex items-center gap-2">
                    {testResult.executionState && (
                      <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-800 font-bold text-[10px]">
                        STATE: {testResult.executionState}
                      </span>
                    )}
                    {testResult.durationMs !== undefined && (
                      <span className="text-slate-500 text-[10px]">{testResult.durationMs}ms</span>
                    )}
                  </div>
                </div>
                <pre className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-800 max-h-48 overflow-auto scrollbar-thin">
                  {JSON.stringify(testResult, null, 2)}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
