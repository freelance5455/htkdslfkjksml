import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import {
  MessageCircle,
  Users,
  Search,
  Globe,
  Lock,
  ShieldCheck,
  Send,
  UserPlus,
  Sparkles,
  PhoneCall,
  Video,
  Mic,
  Smile,
  Plus,
  Handshake,
  Clock,
  X,
  Check,
  Radio,
  Share2,
  KeyRound,
  Layers,
  Activity,
  CheckCheck,
  History,
  ShieldAlert,
  FileText,
  ExternalLink,
  ShieldQuestion,
  CheckCircle2,
  Paperclip,
  Pin,
  PinOff,
  Download,
  Image as ImageIcon
} from 'lucide-react';
import {
  jmChatService,
  JMChatUser,
  JMChatGroup,
  JMChatMessage
} from '../lib/jmChatService';
import { mockDecentralizedSocket } from '../lib/decentralizedSocketEngine';
import { decentralizedSyncService } from '../lib/decentralizedSyncService';
import { prophetSecurityEngine } from '../lib/prophetSecurityEngine';
import { SovereignSecurityMachineModal } from './SovereignSecurityMachineModal';
import {
  COUNTRIES_195,
  ALL_195_COUNTRY_NAMES,
  getCountryFlag
} from '../lib/countries';

// ==========================================
// Connection History Storage & Type Definition
// ==========================================
export interface ConnectionHistoryItem {
  id: string;
  userId: string;
  userName: string;
  userCountry: string;
  userAvatar: string;
  status: 'ACCEPTED' | 'REJECTED' | 'PENDING';
  timestamp: string;
}

const CONNECTION_HISTORY_KEY = 'jm_chat_connection_history_vault_v2';

// Preset Group Avatars for Customization
const PRESET_GROUP_AVATARS = [
  { name: 'Sanctuary Worship', url: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=150&auto=format&fit=crop&q=80' },
  { name: 'Global Trade', url: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=150&auto=format&fit=crop&q=80' },
  { name: 'Apostolic Altar', url: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=150&auto=format&fit=crop&q=80' },
  { name: 'Prayer Network', url: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=150&auto=format&fit=crop&q=80' }
];

// ==========================================
// Fuzzy Matching Helper Function
// ==========================================
function fuzzyMatches(target: string, query: string): boolean {
  if (!query || !query.trim()) return true;
  if (!target) return false;

  const t = target.toLowerCase();
  const q = query.toLowerCase().trim();

  if (t.includes(q)) return true;

  const tokens = q.split(/\s+/).filter(Boolean);
  if (tokens.length > 1 && tokens.every(tok => t.includes(tok))) {
    return true;
  }

  let qIdx = 0;
  for (let i = 0; i < t.length && qIdx < q.length; i++) {
    if (t[i] === q[qIdx]) {
      qIdx++;
    }
  }
  return qIdx === q.length;
}

// ==========================================
// E2EE Message Wrapper Component with Message Status Indicator (sent, delivered, read) & Pinning
// ==========================================
interface E2EEMessageCardProps {
  message: JMChatMessage;
  isMe: boolean;
  nodeSignature?: string;
  onTogglePin?: (message: JMChatMessage) => void;
}

export const E2EEMessageCard: React.FC<E2EEMessageCardProps> = ({
  message,
  isMe,
  nodeSignature = 'E2EE-PEER-HASH-9982B',
  onTogglePin
}) => {
  const isSystem = message.senderId === 'system';

  if (isSystem) {
    return (
      <div className="flex flex-col items-center justify-center my-3 animate-fadeIn">
        <div className="max-w-xl p-3 rounded-2xl bg-slate-900/90 border border-amber-500/30 text-center shadow-lg">
          <div className="flex items-center justify-center gap-1.5 text-amber-400 text-xs font-bold mb-1">
            <Lock className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-mono uppercase tracking-wider">End-to-End Encrypted Group Protocol</span>
          </div>
          <p className="text-[11px] text-amber-200/90 font-mono leading-relaxed">
            {message.text}
          </p>
          <div className="text-[9px] text-slate-500 font-mono mt-1">
            Decentralized Socket Swarm • Zero Server Storage
          </div>
        </div>
      </div>
    );
  }

  // Precise Decentralized Read Status
  const status = message.status || 'delivered';
  const isRead = status === 'read';
  const isDelivered = status === 'delivered' || isRead;

  return (
    <div className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} my-2.5 group animate-fadeIn`}>
      {!isMe && (
        <div className="flex items-center gap-2 mb-1 ml-1 text-xs">
          {message.senderAvatar && (
            <img
              src={message.senderAvatar}
              alt={message.senderName}
              className="w-5 h-5 rounded-full object-cover border border-amber-500/40"
            />
          )}
          <span className="font-bold text-amber-300 font-serif">{message.senderName}</span>
          <span className="text-[10px] text-emerald-400 font-mono font-semibold flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Online Member
          </span>
        </div>
      )}

      <div
        className={`max-w-[85%] sm:max-w-[75%] rounded-3xl p-4 shadow-xl border transition-all ${
          message.isPinned ? 'ring-2 ring-amber-400/60 ' : ''
        }${
          isMe
            ? 'bg-gradient-to-br from-amber-500 via-amber-600 to-yellow-600 text-slate-950 border-amber-300/40 rounded-tr-none shadow-amber-500/10'
            : 'bg-slate-900/95 text-slate-100 border-slate-700/80 rounded-tl-none shadow-black/40'
        }`}
      >
        {/* Pinned Message Tag */}
        {message.isPinned && (
          <div
            className={`flex items-center justify-between pb-1.5 mb-2 border-b text-[10px] font-mono font-bold ${
              isMe ? 'border-slate-950/20 text-slate-950' : 'border-amber-400/30 text-amber-300'
            }`}
          >
            <span className="flex items-center gap-1">
              <Pin className="w-3.5 h-3.5 fill-current" />
              <span>PINNED • {message.pinnedBy || 'Participant'} ({message.pinnedAt || message.timestamp})</span>
            </span>
            {onTogglePin && (
              <button
                onClick={() => onTogglePin(message)}
                className={`text-[9px] hover:underline flex items-center gap-0.5 cursor-pointer ${
                  isMe ? 'text-slate-900' : 'text-rose-300'
                }`}
                title="Unpin this message"
              >
                <PinOff className="w-3 h-3" />
                <span>Unpin</span>
              </button>
            )}
          </div>
        )}

        <div
          className={`flex items-center justify-between gap-3 pb-2 mb-2 border-b text-[10px] font-mono font-bold ${
            isMe ? 'border-slate-950/20 text-slate-900' : 'border-slate-800 text-emerald-400'
          }`}
        >
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>256-BIT AES-GCM E2EE</span>
          </div>
          <div className="flex items-center gap-1 opacity-80 text-[9px]">
            <KeyRound className="w-3 h-3" />
            <span className="truncate max-w-[120px]">{nodeSignature}</span>
          </div>
        </div>

        {/* Secure File / Attachment Preview */}
        {message.attachmentUrl && (
          <div className="my-2 p-2.5 rounded-2xl bg-slate-950/80 border border-amber-500/30 space-y-2">
            {message.attachmentType === 'image' || message.attachmentUrl.startsWith('data:image') ? (
              <div className="space-y-1.5">
                <img
                  src={message.attachmentUrl}
                  alt={message.attachmentName || 'E2EE Shared Image'}
                  className="rounded-xl max-h-64 w-full object-cover border border-slate-800 shadow-md"
                />
                <div className="flex items-center justify-between text-[10px] font-mono text-slate-300 pt-1">
                  <span className="truncate max-w-[160px] font-bold">{message.attachmentName || 'Shared image'}</span>
                  <span>{message.attachmentSize || 'Encrypted File'}</span>
                  <a
                    href={message.attachmentUrl}
                    download={message.attachmentName || 'juhnkrix_e2ee_image.png'}
                    className="text-amber-300 hover:text-amber-100 flex items-center gap-1 font-bold underline cursor-pointer"
                  >
                    <Download className="w-3 h-3" />
                    <span>Download</span>
                  </a>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between gap-3 p-2 rounded-xl bg-slate-900 border border-slate-800">
                <div className="flex items-center space-x-2.5 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 border border-amber-400/30">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-amber-100 truncate">{message.attachmentName || 'Shared Document'}</p>
                    <span className="text-[10px] text-slate-400 font-mono">{message.attachmentSize || 'Document'} • E2EE Verified</span>
                  </div>
                </div>
                <a
                  href={message.attachmentUrl}
                  download={message.attachmentName || 'juhnkrix_e2ee_doc.pdf'}
                  className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-xs font-mono font-bold flex items-center gap-1 shrink-0 cursor-pointer"
                >
                  <Download className="w-3 h-3" />
                  <span>Download</span>
                </a>
              </div>
            )}
          </div>
        )}

        <p className={`text-xs sm:text-sm leading-relaxed whitespace-pre-wrap font-sans ${isMe ? 'font-medium' : 'text-slate-100'}`}>
          {message.text}
        </p>

        {/* Message Footer with Dynamic Status Indicators (sent, delivered, read) & Pin Action */}
        <div
          className={`flex items-center justify-between gap-2 mt-2 pt-1.5 border-t text-[10px] font-mono ${
            isMe ? 'border-slate-950/15 text-slate-900/80' : 'border-slate-800/80 text-slate-400'
          }`}
        >
          <span className="text-[9px] flex items-center gap-1">
            <Lock className="w-2.5 h-2.5" />
            <span>Decentralized E2EE Swarm</span>
          </span>

          <div className="flex items-center gap-1.5">
            <span>{message.timestamp}</span>

            {/* Read / Delivered / Sent Status Indicators */}
            {isMe && (
              <span
                className="font-bold flex items-center ml-0.5"
                title={
                  isRead
                    ? 'Status: READ by all group members'
                    : isDelivered
                    ? 'Status: DELIVERED to decentralized network'
                    : 'Status: SENT to local mesh'
                }
              >
                {isRead ? (
                  <span className="text-emerald-950 font-black tracking-tighter">✓✓</span>
                ) : isDelivered ? (
                  <span className="text-slate-800 font-black tracking-tighter opacity-80">✓✓</span>
                ) : (
                  <span className="text-slate-800 font-bold opacity-70">✓</span>
                )}
              </span>
            )}

            {/* Quick Pin / Unpin button */}
            {onTogglePin && (
              <button
                onClick={() => onTogglePin(message)}
                className={`ml-1 p-0.5 rounded transition-all cursor-pointer ${
                  message.isPinned
                    ? 'text-amber-400 hover:text-amber-200'
                    : isMe
                    ? 'text-slate-900/60 hover:text-slate-950'
                    : 'text-slate-400 hover:text-amber-300'
                }`}
                title={message.isPinned ? 'Unpin message' : 'Pin message for all group members'}
              >
                <Pin className={`w-3 h-3 ${message.isPinned ? 'fill-current' : ''}`} />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// ==========================================
// Memoized Believer User Card using React.memo
// ==========================================
interface BelieverCardProps {
  user: JMChatUser;
  connectionHistory: ConnectionHistoryItem[];
  onChatNow: (user: JMChatUser) => void;
  onAccept: (user: JMChatUser) => void;
  onReject: (user: JMChatUser) => void;
  onConnect: (user: JMChatUser) => void;
}

export const BelieverCard: React.FC<BelieverCardProps> = React.memo(({
  user,
  connectionHistory,
  onChatNow,
  onAccept,
  onReject,
  onConnect
}) => {
  const historyItem = connectionHistory.find(h => h.userId === user.id);
  const effectiveStatus = historyItem
    ? historyItem.status === 'ACCEPTED'
      ? 'CONNECTED'
      : historyItem.status === 'PENDING'
      ? 'PENDING_OUTGOING'
      : user.connectionStatus
    : user.connectionStatus;

  return (
    <div
      className={`p-4 sm:p-5 rounded-2xl bg-slate-950 border transition-all flex flex-col justify-between space-y-3 shadow-lg ${
        user.isOnline ? 'border-emerald-500/40 hover:border-emerald-400/70' : 'border-slate-800 hover:border-amber-500/40'
      }`}
    >
      <div className="flex items-start space-x-3.5">
        <div className="relative shrink-0">
          <img
            src={user.avatar}
            alt={user.name}
            className="w-14 h-14 rounded-2xl object-cover border-2 border-amber-500/30"
          />
          <span
            className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-slate-950 ${
              user.isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'
            }`}
          />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h4 className="text-xs sm:text-sm font-bold text-amber-100 truncate">{user.name}</h4>
            {user.isOnline ? (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 shrink-0">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>● Online</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-rose-500/20 text-rose-300 border border-rose-400/30 shrink-0">
                <span className="w-2 h-2 rounded-full bg-rose-400" />
                <span>● Offline</span>
              </span>
            )}
          </div>

          <div className="text-[11px] font-mono text-amber-300 mt-1 flex items-center space-x-1">
            <Globe className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>
              {getCountryFlag(user.country)} {user.city}, {user.country}
            </span>
          </div>

          <p className="text-[11px] text-slate-300 font-medium mt-1 truncate">{user.role}</p>
          <p className="text-[10px] text-slate-400 line-clamp-2 mt-0.5 leading-relaxed">{user.bio}</p>
        </div>
      </div>

      <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
        <span className="text-[10px] font-mono text-slate-400">
          Sector: <strong className="text-slate-200">{user.businessSector}</strong>
        </span>

        {effectiveStatus === 'CONNECTED' ? (
          <button
            onClick={() => onChatNow(user)}
            className="px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-400/50 text-xs font-bold flex items-center space-x-1.5 hover:bg-emerald-500/30 transition-all cursor-pointer shadow-sm shadow-emerald-500/20"
            title="Connected Partner • Click to chat"
          >
            <Check className="w-3.5 h-3.5 text-emerald-400" />
            <span>Connected</span>
          </button>
        ) : effectiveStatus === 'PENDING_OUTGOING' ? (
          <span
            className="px-4 py-2 rounded-xl bg-amber-500/15 border border-amber-500/40 text-amber-300 text-xs font-mono font-bold flex items-center space-x-1.5 shadow-sm"
            title="Friendship Request Sent • Awaiting Confirmation"
          >
            <Clock className="w-3.5 h-3.5 text-amber-400 animate-spin" />
            <span>Pending</span>
          </span>
        ) : effectiveStatus === 'PENDING_INCOMING' ? (
          <div className="flex items-center space-x-1.5">
            <button
              onClick={() => onAccept(user)}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 text-xs font-black flex items-center space-x-1 shadow-md shadow-emerald-500/20 cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Accept</span>
            </button>
            <button
              onClick={() => onReject(user)}
              className="px-2.5 py-2 rounded-xl bg-slate-900 text-rose-300 border border-rose-500/30 text-xs font-bold hover:bg-slate-800 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          <button
            onClick={() => onConnect(user)}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs flex items-center space-x-1.5 shadow-md shadow-amber-500/20 transition-all hover:scale-105 cursor-pointer uppercase"
            title="Send Friend & Business Partner Connection Request"
          >
            <Handshake className="w-4 h-4 text-slate-950" />
            <span>Connect</span>
          </button>
        )}
      </div>
    </div>
  );
}, (prevProps, nextProps) => {
  return (
    prevProps.user.id === nextProps.user.id &&
    prevProps.user.isOnline === nextProps.user.isOnline &&
    prevProps.user.connectionStatus === nextProps.user.connectionStatus &&
    prevProps.user.name === nextProps.user.name &&
    prevProps.connectionHistory.length === nextProps.connectionHistory.length
  );
});

BelieverCard.displayName = 'BelieverCard';

// ==========================================
// Memoized Direct Contact Item using React.memo
// ==========================================
interface DirectContactItemProps {
  user: JMChatUser;
  isSelected: boolean;
  onSelect: (userId: string) => void;
}

export const DirectContactItem: React.FC<DirectContactItemProps> = React.memo(({
  user,
  isSelected,
  onSelect
}) => {
  return (
    <button
      onClick={() => onSelect(user.id)}
      className={`w-full p-3.5 rounded-2xl border text-left transition-all flex items-start space-x-3 cursor-pointer ${
        isSelected
          ? 'bg-gradient-to-r from-amber-500/20 to-amber-600/10 border-amber-400 shadow-md ring-1 ring-amber-400/40'
          : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
      }`}
    >
      <div className="relative shrink-0">
        <img
          src={user.avatar}
          alt={user.name}
          className="w-12 h-12 rounded-2xl object-cover border border-amber-500/30"
        />
        <span
          className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full border-2 border-slate-950 ${
            user.isOnline ? 'bg-emerald-500' : 'bg-rose-500'
          }`}
        />
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <h4 className="text-xs font-bold text-amber-100 truncate">{user.name}</h4>
          {user.isOnline ? (
            <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded-full text-[9px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>● Online</span>
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded-full text-[9px] font-mono font-bold bg-rose-500/20 text-rose-300 border border-rose-400/30 shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
              <span>● Offline</span>
            </span>
          )}
        </div>

        <p className="text-[11px] text-slate-400 truncate mt-0.5">{user.role}</p>

        <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 mt-1">
          <span>
            {getCountryFlag(user.country)} {user.city}, {user.country}
          </span>
          <span className="text-emerald-400">🔒 E2EE Direct</span>
        </div>
      </div>
    </button>
  );
}, (prevProps, nextProps) => {
  return (
    prevProps.user.id === nextProps.user.id &&
    prevProps.user.isOnline === nextProps.user.isOnline &&
    prevProps.isSelected === nextProps.isSelected &&
    prevProps.user.connectionStatus === nextProps.user.connectionStatus
  );
});

DirectContactItem.displayName = 'DirectContactItem';

// ==========================================
// Main JMChatView Component (#jm-chat)
// ==========================================
export const JMChatView: React.FC = () => {
  const [users, setUsers] = useState<JMChatUser[]>(() => jmChatService.getUsers());
  const [groups, setGroups] = useState<JMChatGroup[]>(() => jmChatService.getGroups());
  const [activeTab, setActiveTab] = useState<'discover' | 'groups' | 'chats' | 'history'>('discover');
  const [selectedConversationId, setSelectedConversationId] = useState<string>('group-001');

  // Search & Filtering States
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCountry, setSelectedCountry] = useState<string>('All Countries');
  const [selectedAlphabet, setSelectedAlphabet] = useState<string>('ALL');

  // Active Messages & Input
  const [messageInput, setMessageInput] = useState<string>('');
  const [messages, setMessages] = useState<JMChatMessage[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Security Badge & Security Audit Modal State
  const [securityBadgeMode, setSecurityBadgeMode] = useState<'End-to-End Encrypted' | 'Encrypted Group Session'>('End-to-End Encrypted');
  const [showSecurityAuditModal, setShowSecurityAuditModal] = useState<boolean>(false);

  // Connection History State persisted to local storage
  const [connectionHistory, setConnectionHistory] = useState<ConnectionHistoryItem[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const saved = localStorage.getItem(CONNECTION_HISTORY_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn('Failed to load connection history:', e);
    }
    return [
      {
        id: 'hist-001',
        userId: 'user-ng-01',
        userName: 'Brother Emmanuel Adebayo',
        userCountry: 'Nigeria',
        userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        status: 'ACCEPTED',
        timestamp: 'Today, 08:24 AM'
      },
      {
        id: 'hist-002',
        userId: 'user-uk-02',
        userName: 'Sister Grace Henderson',
        userCountry: 'United Kingdom',
        userAvatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
        status: 'ACCEPTED',
        timestamp: 'Yesterday, 04:15 PM'
      },
      {
        id: 'hist-003',
        userId: 'user-us-03',
        userName: 'Pastor Michael Jenkins',
        userCountry: 'United States',
        userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        status: 'PENDING',
        timestamp: 'Just now'
      }
    ];
  });

  const recordConnectionHistory = useCallback((userId: string, userName: string, userCountry: string, userAvatar: string, status: 'ACCEPTED' | 'REJECTED' | 'PENDING') => {
    setConnectionHistory(prev => {
      const filtered = prev.filter(item => item.userId !== userId);
      const updated = [
        {
          id: `hist-${Date.now()}`,
          userId,
          userName,
          userCountry,
          userAvatar,
          status,
          timestamp: new Date().toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })
        },
        ...filtered
      ];
      try {
        if (typeof window !== 'undefined') {
          localStorage.setItem(CONNECTION_HISTORY_KEY, JSON.stringify(updated));
        }
      } catch (e) {
        console.warn('Failed to persist connection history:', e);
      }
      return updated;
    });
  }, []);

  // Connection Request Alert Modal / State
  const [pendingRequestUser, setPendingRequestUser] = useState<JMChatUser | null>(null);
  const [connectionModalUser, setConnectionModalUser] = useState<JMChatUser | null>(null);
  const [feedbackToast, setFeedbackToast] = useState<{ type: 'success' | 'info' | 'error'; text: string } | null>(null);

  // New Group Modal State with Customizable Group Avatar
  const [showNewGroupModal, setShowNewGroupModal] = useState<boolean>(false);
  const [newGroupName, setNewGroupName] = useState<string>('');
  const [newGroupDescription, setNewGroupDescription] = useState<string>('');
  const [selectedGroupAvatar, setSelectedGroupAvatar] = useState<string>(PRESET_GROUP_AVATARS[0].url);
  const [customGroupAvatarUrl, setCustomGroupAvatarUrl] = useState<string>('');

  // Edit Group Avatar Modal State
  const [showEditGroupAvatarModal, setShowEditGroupAvatarModal] = useState<boolean>(false);
  const [editGroupAvatarUrl, setEditGroupAvatarUrl] = useState<string>(PRESET_GROUP_AVATARS[0].url);
  const [selectedEditPresetAvatar, setSelectedEditPresetAvatar] = useState<string>(PRESET_GROUP_AVATARS[0].url);

  // Sovereign Security Machine Modal State
  const [showSecurityMachineModal, setShowSecurityMachineModal] = useState<boolean>(false);

  // Secure File Sharing Input Refs
  const groupFileInputRef = useRef<HTMLInputElement>(null);
  const directFileInputRef = useRef<HTMLInputElement>(null);

  // Socket Swarm Status State
  const [socketSwarmInfo, setSocketSwarmInfo] = useState<{
    nodeId: string;
    activePeers: number;
    health: string;
  }>({
    nodeId: mockDecentralizedSocket.getSocketNodeId(),
    activePeers: 14208,
    health: '99.98%'
  });

  const alphabetList = useMemo(() => {
    return ['ALL', ...'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('')];
  }, []);

  const countries = useMemo(() => {
    return ['All Countries', ...ALL_195_COUNTRY_NAMES];
  }, []);

  const showToast = useCallback((type: 'success' | 'info' | 'error', text: string) => {
    setFeedbackToast({ type, text });
    setTimeout(() => {
      setFeedbackToast(prev => (prev?.text === text ? null : prev));
    }, 5000);
  }, []);

  // Synchronize with jmChatService
  const refreshChatData = useCallback(() => {
    setUsers([...jmChatService.getUsers()]);
    setGroups([...jmChatService.getGroups()]);
  }, []);

  // Compute pinned messages for current conversation
  const pinnedMessages = useMemo(() => {
    return messages.filter(m => m.isPinned);
  }, [messages]);

  // Toggle Pin message in decentralized storage
  const handleTogglePinMessage = useCallback((msg: JMChatMessage) => {
    if (msg.isPinned) {
      jmChatService.unpinMessage(selectedConversationId, msg.id);
      if (selectedConversationId.startsWith('group-')) {
        mockDecentralizedSocket.emit('unpin_group_message', {
          roomId: selectedConversationId,
          messageId: msg.id
        });
      }
      showToast('info', 'Message unpinned.');
    } else {
      jmChatService.pinMessage(selectedConversationId, msg.id, 'You (Believer)');
      if (selectedConversationId.startsWith('group-')) {
        mockDecentralizedSocket.emit('pin_group_message', {
          roomId: selectedConversationId,
          messageId: msg.id,
          pinnedMessage: msg,
          pinnedBy: 'You (Believer)'
        });
      }
      showToast('success', '📌 Message pinned and persisted for all group participants!');
    }
    setMessages([...jmChatService.getMessages(selectedConversationId)]);
  }, [selectedConversationId, showToast]);

  // Secure File Sharing Handler (Images / Documents)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 25 * 1024 * 1024) {
      showToast('error', 'File size exceeds sovereign P2P chunk limit (25 MB max).');
      return;
    }

    const isImg = file.type.startsWith('image/');
    const sizeFormatted = file.size > 1024 * 1024
      ? `${(file.size / (1024 * 1024)).toFixed(1)} MB`
      : `${Math.round(file.size / 1024)} KB`;

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      const newMsg = jmChatService.sendFileMessage(selectedConversationId, {
        name: file.name,
        sizeFormatted,
        dataUrl,
        type: isImg ? 'image' : 'document',
        caption: messageInput.trim() || undefined
      });

      if (selectedConversationId.startsWith('group-')) {
        mockDecentralizedSocket.emit('send_group_message', newMsg);
      }

      setMessages([...jmChatService.getMessages(selectedConversationId)]);
      setMessageInput('');
      showToast('success', `✓ Encrypted ${isImg ? 'image' : 'document'} ("${file.name}") shared securely with group!`);

      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 80);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Subscribe to service & socket
  useEffect(() => {
    const unsubService = jmChatService.subscribe(refreshChatData);

    const incoming = jmChatService.getUsers().find(u => u.connectionStatus === 'PENDING_INCOMING');
    if (incoming) {
      setPendingRequestUser(incoming);
    }

    const unsubSocketMsg = mockDecentralizedSocket.on('group_message_received', (data: any) => {
      if (data?.roomId) {
        const currentList = jmChatService.getMessages(data.roomId);
        if (!currentList.some(m => m.id === data.message.id)) {
          currentList.push(data.message);
        }
        setMessages([...currentList]);
        setTimeout(() => {
          messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
        }, 60);
      }
    });

    const unsubReadReceipt = mockDecentralizedSocket.on('message_read_receipt', (data: any) => {
      if (data?.roomId) {
        setMessages(prev =>
          prev.map(m => (m.senderId === 'me' ? { ...m, status: 'read' as const } : m))
        );
      }
    });

    const unsubPinnedMsg = mockDecentralizedSocket.on('group_message_pinned', (data: any) => {
      if (data?.roomId) {
        setMessages(prev =>
          prev.map(m => (m.id === data.messageId ? { ...m, isPinned: true, pinnedBy: data.pinnedBy } : m))
        );
      }
    });

    const unsubUnpinnedMsg = mockDecentralizedSocket.on('group_message_unpinned', (data: any) => {
      if (data?.roomId) {
        setMessages(prev =>
          prev.map(m => (m.id === data.messageId ? { ...m, isPinned: false } : m))
        );
      }
    });

    const unsubHeartbeat = mockDecentralizedSocket.on('socket_heartbeat', (data: any) => {
      setSocketSwarmInfo({
        nodeId: data.nodeId || mockDecentralizedSocket.getSocketNodeId(),
        activePeers: data.activePeers || 14208,
        health: data.swarmHealth || '99.99%'
      });
    });

    const handleReqAlert = (e: any) => {
      refreshChatData();
      const u = jmChatService.getUsers().find(user => user.id === e.detail?.targetUserId);
      if (u) {
        setPendingRequestUser(u);
        recordConnectionHistory(u.id, u.name, u.country, u.avatar, 'PENDING');
        showToast('info', `Notification: ${e.detail?.message || 'Connection request received!'}`);
      }
    };

    const handleAcceptAlert = (e: any) => {
      refreshChatData();
      const u = jmChatService.getUsers().find(user => user.id === e.detail?.targetUserId);
      if (u) {
        recordConnectionHistory(u.id, u.name, u.country, u.avatar, 'ACCEPTED');
      }
      showToast('success', e.detail?.message || 'Connection accepted!');
    };

    const handleRejectAlert = (e: any) => {
      refreshChatData();
      const u = jmChatService.getUsers().find(user => user.id === e.detail?.targetUserId);
      if (u) {
        recordConnectionHistory(u.id, u.name, u.country, u.avatar, 'REJECTED');
      }
      showToast('error', e.detail?.message || 'Connection request rejected.');
    };

    const handleGroupAvatarUpdated = (e: any) => {
      refreshChatData();
      showToast('success', e.detail?.message || 'Group avatar successfully updated!');
    };

    const handleMessagePinnedAlert = (e: any) => {
      setMessages([...jmChatService.getMessages(selectedConversationId)]);
      if (e.detail?.message) {
        showToast('info', e.detail.message);
      }
    };

    const handleMessageUnpinnedAlert = () => {
      setMessages([...jmChatService.getMessages(selectedConversationId)]);
    };

    window.addEventListener('juhnkrix_chat_connection_requested', handleReqAlert);
    window.addEventListener('juhnkrix_chat_connection_accepted', handleAcceptAlert);
    window.addEventListener('juhnkrix_chat_connection_rejected', handleRejectAlert);
    window.addEventListener('juhnkrix_group_avatar_updated', handleGroupAvatarUpdated);
    window.addEventListener('juhnkrix_message_pinned', handleMessagePinnedAlert);
    window.addEventListener('juhnkrix_message_unpinned', handleMessageUnpinnedAlert);

    return () => {
      unsubService();
      unsubSocketMsg();
      unsubReadReceipt();
      unsubPinnedMsg();
      unsubUnpinnedMsg();
      unsubHeartbeat();
      window.removeEventListener('juhnkrix_chat_connection_requested', handleReqAlert);
      window.removeEventListener('juhnkrix_chat_connection_accepted', handleAcceptAlert);
      window.removeEventListener('juhnkrix_chat_connection_rejected', handleRejectAlert);
      window.removeEventListener('juhnkrix_group_avatar_updated', handleGroupAvatarUpdated);
      window.removeEventListener('juhnkrix_message_pinned', handleMessagePinnedAlert);
      window.removeEventListener('juhnkrix_message_unpinned', handleMessageUnpinnedAlert);
    };
  }, [refreshChatData, recordConnectionHistory, showToast, selectedConversationId]);

  useEffect(() => {
    if (selectedConversationId) {
      setMessages(jmChatService.getMessages(selectedConversationId));

      // Mark conversation read and propagate read state across participants
      jmChatService.markConversationRead(selectedConversationId, 'me');
      mockDecentralizedSocket.emit('mark_messages_read', {
        roomId: selectedConversationId,
        readerId: 'me'
      });

      if (selectedConversationId.startsWith('group-')) {
        mockDecentralizedSocket.emit('join_group', { groupId: selectedConversationId });
      }

      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 80);
    }
  }, [selectedConversationId, activeTab]);

  const connectedUsers = useMemo(() => {
    return users.filter(u => u.connectionStatus === 'CONNECTED');
  }, [users]);

  // Real-time sorting mechanism automatically moving online users (green) to the top of contact list
  const sortedConnectedUsers = useMemo(() => {
    return [...connectedUsers].sort((a, b) => {
      if (a.isOnline && !b.isOnline) return -1;
      if (!a.isOnline && b.isOnline) return 1;
      return a.name.localeCompare(b.name);
    });
  }, [connectedUsers]);

  // Real-time fuzzy search using memoized filtering approach
  const sortedFilteredUsers = useMemo(() => {
    if (selectedCountry && selectedCountry !== 'All Countries') {
      jmChatService.ensureCountryUsers(selectedCountry);
    }

    const matched = users.filter((user) => {
      if (selectedCountry && selectedCountry !== 'All Countries') {
        if (user.country.toLowerCase() !== selectedCountry.toLowerCase()) {
          return false;
        }
      }

      if (selectedAlphabet && selectedAlphabet !== 'ALL') {
        const firstLetter = user.name.trim().charAt(0).toUpperCase();
        if (firstLetter !== selectedAlphabet.toUpperCase()) {
          return false;
        }
      }

      if (searchQuery.trim()) {
        const matchesName = fuzzyMatches(user.name, searchQuery);
        const matchesCountry = fuzzyMatches(user.country, searchQuery);
        const matchesCity = fuzzyMatches(user.city, searchQuery);
        const matchesSector = fuzzyMatches(user.businessSector, searchQuery);
        const matchesRole = fuzzyMatches(user.role, searchQuery);

        if (!matchesName && !matchesCountry && !matchesCity && !matchesSector && !matchesRole) {
          return false;
        }
      }

      return true;
    });

    return matched.sort((a, b) => {
      if (a.isOnline && !b.isOnline) return -1;
      if (!a.isOnline && b.isOnline) return 1;
      if (a.connectionStatus === 'CONNECTED' && b.connectionStatus !== 'CONNECTED') return -1;
      if (a.connectionStatus !== 'CONNECTED' && b.connectionStatus === 'CONNECTED') return 1;
      return a.name.localeCompare(b.name);
    });
  }, [searchQuery, selectedCountry, selectedAlphabet, users]);

  const activeChatMeta = useMemo(() => {
    if (selectedConversationId.startsWith('group-')) {
      const g = groups.find(grp => grp.id === selectedConversationId);
      return {
        isGroup: true,
        title: g?.name || 'Kingdom Group Chat',
        subtitle: `${g?.memberCount.toLocaleString() || '1,000+'} members • Decentralized E2EE Swarm`,
        avatar: g?.avatar,
        isOnline: true,
        onlineText: 'Active Swarm'
      };
    } else {
      const u = users.find(usr => usr.id === selectedConversationId);
      return {
        isGroup: false,
        title: u?.name || 'Believer Friend',
        subtitle: `${u?.role || 'Friend & Business Partner'} • ${u?.city}, ${u?.country}`,
        avatar: u?.avatar,
        isOnline: u?.isOnline ?? false,
        onlineText: u?.isOnline ? 'Online' : 'Offline'
      };
    }
  }, [selectedConversationId, groups, users]);

  const handleSendMessage = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!messageInput.trim()) return;

    const trimmed = messageInput.trim();
    setMessageInput('');

    if (activeTab === 'groups' || selectedConversationId.startsWith('group-')) {
      mockDecentralizedSocket.emit('send_group_message', {
        id: `sock-msg-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        conversationId: selectedConversationId,
        senderId: 'me',
        senderName: 'You (JUHNKRIX Believer)',
        senderAvatar: '/favicon.svg',
        text: trimmed,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        messageType: 'text'
      });
    } else {
      jmChatService.sendMessage(selectedConversationId, trimmed);
      setMessages([...jmChatService.getMessages(selectedConversationId)]);
    }

    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 60);
  };

  const handleInitiateConnect = useCallback((user: JMChatUser) => {
    setConnectionModalUser(user);
  }, []);

  const handleConfirmSendRequest = useCallback((user: JMChatUser) => {
    const res = jmChatService.sendConnectionRequest(user.id);
    recordConnectionHistory(user.id, user.name, user.country, user.avatar, 'PENDING');
    setConnectionModalUser(null);
    refreshChatData();
    showToast('info', res.message);
  }, [recordConnectionHistory, refreshChatData, showToast]);

  const handleAcceptRequest = useCallback((user: JMChatUser) => {
    const res = jmChatService.acceptConnection(user.id);
    recordConnectionHistory(user.id, user.name, user.country, user.avatar, 'ACCEPTED');
    setPendingRequestUser(null);
    setConnectionModalUser(null);
    refreshChatData();
    showToast('success', res.message);
    setSelectedConversationId(user.id);
    setActiveTab('chats');
  }, [recordConnectionHistory, refreshChatData, showToast]);

  const handleRejectRequest = useCallback((user: JMChatUser) => {
    const res = jmChatService.rejectConnection(user.id);
    recordConnectionHistory(user.id, user.name, user.country, user.avatar, 'REJECTED');
    setPendingRequestUser(null);
    setConnectionModalUser(null);
    refreshChatData();
    showToast('error', res.message);
  }, [recordConnectionHistory, refreshChatData, showToast]);

  const handleChatNow = useCallback((user: JMChatUser) => {
    setSelectedConversationId(user.id);
    setActiveTab('chats');
  }, []);

  const handleSelectContact = useCallback((userId: string) => {
    setSelectedConversationId(userId);
  }, []);

  const handleCreateGroup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName.trim()) return;

    const finalAvatar = customGroupAvatarUrl.trim() || selectedGroupAvatar;
    const grp = jmChatService.createGroup(
      newGroupName.trim(),
      newGroupDescription.trim() || 'Decentralized end-to-end encrypted believer group',
      finalAvatar
    );
    setNewGroupName('');
    setNewGroupDescription('');
    setCustomGroupAvatarUrl('');
    setShowNewGroupModal(false);
    setSelectedConversationId(grp.id);
    setActiveTab('groups');
    showToast('success', `✓ Custom E2EE group "${grp.name}" successfully created with custom avatar!`);
  };

  const handleUpdateGroupAvatarSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedConversationId.startsWith('group-')) return;
    const finalAvatar = editGroupAvatarUrl.trim() || selectedEditPresetAvatar;
    const res = jmChatService.updateGroupAvatar(selectedConversationId, finalAvatar);
    setShowEditGroupAvatarModal(false);
    setEditGroupAvatarUrl('');
    refreshChatData();
    showToast('success', res.message);
  };

  return (
    <div id="jm-chat" className="space-y-6 text-slate-100 animate-fadeIn">
      {/* Toast Notification */}
      {feedbackToast && (
        <div
          className={`fixed top-20 right-6 z-50 max-w-md p-4 rounded-2xl text-xs font-bold shadow-2xl border-2 flex items-start space-x-3 animate-bounce ${
            feedbackToast.type === 'success'
              ? 'bg-emerald-950 text-emerald-200 border-emerald-400'
              : feedbackToast.type === 'error'
              ? 'bg-rose-950 text-rose-200 border-rose-400'
              : 'bg-amber-950 text-amber-200 border-amber-400'
          }`}
        >
          <Sparkles className="w-5 h-5 shrink-0 text-amber-400" />
          <div className="flex-1 leading-snug">{feedbackToast.text}</div>
          <button onClick={() => setFeedbackToast(null)} className="text-white font-bold ml-2 cursor-pointer">
            ✕
          </button>
        </div>
      )}

      {/* Main Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-amber-950/90 via-slate-900 to-slate-950 border-2 border-amber-500/40 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center space-x-2 px-3.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black tracking-wider uppercase">
              <MessageCircle className="w-4 h-4 text-amber-400" />
              <span>JM CHAT • END-TO-END ENCRYPTED DECENTRALIZED NETWORK</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black font-serif text-amber-100 tracking-tight flex items-center gap-3">
              <span>JM CHAT</span>
              <span className="text-xs sm:text-sm font-sans font-extrabold px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 flex items-center space-x-1.5">
                <Lock className="w-3.5 h-3.5 text-emerald-400" />
                <span>100% E2EE SECURE</span>
              </span>
            </h1>

            <p className="text-slate-300 text-xs sm:text-sm max-w-3xl leading-relaxed">
              Connect with fellow gospel believers worldwide across <strong className="text-amber-300">all 195 countries</strong>. 
              Featuring customizable group avatars, decentralized read receipts (single/double checkmarks), and an interactive **Security Audit** component.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2 text-xs font-mono">
              <div className="px-3.5 py-1.5 rounded-xl bg-slate-950/90 border border-emerald-500/40 text-emerald-300 flex items-center space-x-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shadow-sm shadow-emerald-400" />
                <span>Status: <strong>● Online Auto-Sorted to Top (React.memo Optimized)</strong></span>
              </div>
              <div className="px-3.5 py-1.5 rounded-xl bg-slate-950/90 border border-amber-500/30 text-amber-300 flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
                <span>Security Audit: <strong>Verified P2P Mesh</strong></span>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto shrink-0">
            <button
              onClick={() => setActiveTab('discover')}
              className="px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-black text-xs uppercase flex items-center justify-center space-x-2 shadow-xl shadow-amber-500/20 transition-all hover:scale-105 cursor-pointer"
            >
              <UserPlus className="w-4 h-4 text-slate-950" />
              <span>DISCOVER & CONNECT</span>
            </button>

            <button
              onClick={() => setActiveTab('history')}
              className="px-5 py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/40 font-bold text-xs uppercase flex items-center justify-center space-x-2 transition-all hover:scale-105 cursor-pointer"
            >
              <History className="w-4 h-4 text-amber-400" />
              <span>CONNECTION HISTORY ({connectionHistory.length})</span>
            </button>
          </div>
        </div>
      </div>

      {/* Incoming Connection Request Alert Banner */}
      {pendingRequestUser && (
        <div className="p-5 rounded-3xl bg-gradient-to-r from-amber-950 via-slate-900 to-slate-950 border-2 border-amber-400 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 animate-pulse">
          <div className="flex items-center space-x-4">
            <div className="relative shrink-0">
              <img
                src={pendingRequestUser.avatar}
                alt={pendingRequestUser.name}
                className="w-14 h-14 rounded-2xl object-cover border-2 border-amber-400"
              />
              <span
                className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-slate-950 ${
                  pendingRequestUser.isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'
                }`}
              />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h4 className="text-sm font-black text-amber-200 font-serif">
                  FRIEND & BUSINESS PARTNER REQUEST
                </h4>
                {pendingRequestUser.isOnline ? (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span>● Online</span>
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-rose-500/20 text-rose-300 border border-rose-400/30">
                    <span className="w-2 h-2 rounded-full bg-rose-400" />
                    <span>● Offline</span>
                  </span>
                )}
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300">
                  {getCountryFlag(pendingRequestUser.country)} {pendingRequestUser.city}, {pendingRequestUser.country}
                </span>
              </div>
              <p className="text-xs text-amber-100 mt-1.5 leading-relaxed font-sans max-w-3xl">
                "{pendingRequestUser.name} wants to be your friend and business partner, click on the ACCEPT button to connect with the user or click on the REJECT button to decline or revoke the friend and business partner request"
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2.5 w-full md:w-auto shrink-0 justify-end">
            <button
              onClick={() => handleAcceptRequest(pendingRequestUser)}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs uppercase flex items-center space-x-1.5 shadow-lg shadow-emerald-500/30 transition-all hover:scale-105 cursor-pointer"
            >
              <Check className="w-4 h-4 text-slate-950" />
              <span>ACCEPT</span>
            </button>

            <button
              onClick={() => handleRejectRequest(pendingRequestUser)}
              className="px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-rose-300 hover:text-rose-200 border border-rose-500/40 font-bold text-xs uppercase flex items-center space-x-1.5 transition-all hover:scale-105 cursor-pointer"
            >
              <X className="w-4 h-4" />
              <span>REJECT</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Tab Navigation Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900 border border-amber-500/30 p-2.5 rounded-2xl shadow-xl">
        <div className="flex items-center space-x-2 flex-wrap gap-y-2">
          <button
            onClick={() => setActiveTab('discover')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 cursor-pointer ${
              activeTab === 'discover'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md font-extrabold'
                : 'text-slate-400 hover:text-amber-200'
            }`}
          >
            <Globe className="w-4 h-4" />
            <span>Discover & Connect ({users.length})</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('groups');
              if (!selectedConversationId.startsWith('group-') && groups.length > 0) {
                setSelectedConversationId(groups[0].id);
              }
            }}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 cursor-pointer ${
              activeTab === 'groups'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md font-extrabold'
                : 'text-slate-400 hover:text-amber-200'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Group Chat ({groups.length})</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('chats');
              if (selectedConversationId.startsWith('group-') && connectedUsers.length > 0) {
                setSelectedConversationId(connectedUsers[0].id);
              }
            }}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 cursor-pointer ${
              activeTab === 'chats'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md font-extrabold'
                : 'text-slate-400 hover:text-amber-200'
            }`}
          >
            <MessageCircle className="w-4 h-4" />
            <span>Direct Chats ({connectedUsers.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('history')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 cursor-pointer ${
              activeTab === 'history'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md font-extrabold'
                : 'text-slate-400 hover:text-amber-200'
            }`}
          >
            <History className="w-4 h-4" />
            <span>Connection History ({connectionHistory.length})</span>
          </button>
        </div>

        <div className="flex items-center space-x-2 text-xs font-mono text-emerald-400 px-3">
          <Lock className="w-3.5 h-3.5" />
          <span>Zero External Server Logs • E2EE Mesh</span>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* TAB CONTENT: GROUP CHAT (WITH SECURITY AUDIT & CUSTOM AVATARS)            */}
      {/* ========================================================================= */}
      {activeTab === 'groups' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-slate-900 border border-amber-500/30 rounded-3xl p-4 sm:p-6 shadow-2xl min-h-[640px]">
          <div className="lg:col-span-4 border-b lg:border-b-0 lg:border-r border-slate-800 pr-0 lg:pr-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-black font-serif text-amber-200 uppercase tracking-wider flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-amber-400" />
                  <span>GROUP CHAT ROOMS</span>
                </h3>
                <p className="text-[10px] text-slate-400 font-mono">Custom Avatars & E2EE Swarms</p>
              </div>

              <button
                onClick={() => setShowNewGroupModal(true)}
                className="px-2.5 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 text-xs font-bold flex items-center space-x-1 border border-amber-500/40 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New Group</span>
              </button>
            </div>

            <div className="p-3 rounded-2xl bg-slate-950/80 border border-emerald-500/30 text-[11px] font-mono text-emerald-300 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>Decentralized Socket Swarm</span>
              </div>
              <span className="text-[10px] text-slate-400">{socketSwarmInfo.activePeers.toLocaleString()} Nodes</span>
            </div>

            <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
              {groups.map((grp) => {
                const isSelected = selectedConversationId === grp.id;
                return (
                  <button
                    key={grp.id}
                    onClick={() => setSelectedConversationId(grp.id)}
                    className={`w-full p-3.5 rounded-2xl border text-left transition-all flex items-start space-x-3 cursor-pointer ${
                      isSelected
                        ? 'bg-gradient-to-r from-amber-500/20 to-amber-600/10 border-amber-400 shadow-md ring-1 ring-amber-400/40'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <img
                      src={grp.avatar}
                      alt={grp.name}
                      className="w-12 h-12 rounded-2xl object-cover border border-amber-500/30 shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-bold text-amber-100 truncate">{grp.name}</h4>
                        <span className="text-[10px] font-mono text-slate-500">{grp.lastMessageTime}</span>
                      </div>
                      <p className="text-[11px] text-slate-400 truncate mt-0.5">{grp.lastMessage}</p>
                      <div className="flex items-center space-x-2 mt-1.5">
                        <span className="text-[9px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                          <Lock className="w-2.5 h-2.5" />
                          <span>E2EE Group</span>
                        </span>
                        <span className="text-[9px] text-slate-400 font-mono">
                          {grp.memberCount.toLocaleString()} members
                        </span>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="lg:col-span-8 flex flex-col justify-between space-y-4">
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center space-x-3.5">
                {activeChatMeta.avatar && (
                  <img
                    src={activeChatMeta.avatar}
                    alt={activeChatMeta.title}
                    className="w-11 h-11 rounded-2xl object-cover border-2 border-amber-500/40"
                  />
                )}
                <div>
                  <div className="flex items-center space-x-2.5 flex-wrap">
                    <h3 className="text-base font-black text-amber-100 font-serif">{activeChatMeta.title}</h3>
                    <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      <span>Live Swarm</span>
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">{activeChatMeta.subtitle}</p>
                </div>
              </div>

              {/* Security Audit, Anti-Piracy Shield & Edit Avatar Buttons in Chat Header */}
              <div className="flex items-center space-x-2 flex-wrap gap-y-2">
                {activeChatMeta.isGroup && (
                  <button
                    onClick={() => {
                      const currentGrp = groups.find(g => g.id === selectedConversationId);
                      if (currentGrp) {
                        setEditGroupAvatarUrl(currentGrp.avatar);
                      }
                      setShowEditGroupAvatarModal(true);
                    }}
                    className="px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center space-x-1.5 cursor-pointer transition-all"
                    title="Set or Update Custom Group Avatar"
                  >
                    <Plus className="w-3.5 h-3.5 text-amber-400" />
                    <span>Edit Avatar</span>
                  </button>
                )}

                <button
                  onClick={() => setShowSecurityMachineModal(true)}
                  className="px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-mono font-bold flex items-center space-x-1.5 shadow-md cursor-pointer transition-all hover:scale-105"
                  title="Inspect Signed Certificate & Anti-Piracy Machine for juhnkrix.musika@gmail.com"
                >
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  <span>Anti-Piracy Shield</span>
                </button>

                <button
                  onClick={() => setShowSecurityAuditModal(true)}
                  className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-950 to-slate-900 border border-emerald-500/50 text-emerald-300 hover:text-emerald-200 text-xs font-mono font-bold flex items-center space-x-2 shadow-md cursor-pointer transition-all hover:scale-105"
                  title="Trigger Security Audit Breakdown of Encryption Protocols"
                >
                  <ShieldAlert className="w-4 h-4 text-emerald-400 animate-pulse" />
                  <span>Security Audit</span>
                </button>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-gradient-to-r from-emerald-950/70 via-slate-950 to-slate-950 border border-emerald-500/40 text-[11px] text-emerald-200 font-mono flex items-center space-x-2.5 shadow-lg">
              <Lock className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="leading-relaxed">
                No one else outside the group can access the group messages or see or know what is going on in the group, because it is an end-to-end user chatting decentralized network.
              </span>
            </div>

            {/* Pinned Messages Header Banner */}
            {pinnedMessages.length > 0 && (
              <div className="p-3 rounded-2xl bg-amber-950/60 border border-amber-400/40 text-[11px] text-amber-200 flex items-center justify-between shadow-lg animate-fadeIn">
                <div className="flex items-center space-x-2.5 min-w-0">
                  <Pin className="w-4 h-4 text-amber-400 fill-amber-400 shrink-0" />
                  <span className="font-bold text-amber-300 uppercase tracking-wider font-mono text-[10px] shrink-0">
                    PINNED ({pinnedMessages.length}):
                  </span>
                  <span className="truncate text-slate-200">
                    {pinnedMessages[pinnedMessages.length - 1].attachmentName
                      ? `[File: ${pinnedMessages[pinnedMessages.length - 1].attachmentName}] `
                      : ''}
                    {pinnedMessages[pinnedMessages.length - 1].text}
                  </span>
                </div>
                <button
                  onClick={() => handleTogglePinMessage(pinnedMessages[pinnedMessages.length - 1])}
                  className="px-2.5 py-1 rounded-xl bg-slate-900 border border-rose-500/30 text-rose-300 hover:text-rose-100 text-[10px] font-bold shrink-0 cursor-pointer transition-all ml-2"
                  title="Unpin this message"
                >
                  Unpin
                </button>
              </div>
            )}

            <div className="flex-1 max-h-[420px] min-h-[340px] overflow-y-auto space-y-1 p-4 bg-slate-950/80 rounded-2xl border border-slate-800">
              {messages.map((msg) => {
                const isMe = msg.senderId === 'me';
                return (
                  <E2EEMessageCard
                    key={msg.id}
                    message={msg}
                    isMe={isMe}
                    nodeSignature={`NODE-${socketSwarmInfo.nodeId.substring(5)}-AUDITED`}
                    onTogglePin={handleTogglePinMessage}
                  />
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            <form onSubmit={handleSendMessage} className="flex items-center space-x-2 pt-2">
              {/* Secure File Sharing Attachment Button */}
              <input
                type="file"
                ref={groupFileInputRef}
                onChange={handleFileUpload}
                accept="image/*,.pdf,.doc,.docx,.txt,.zip,.jm"
                className="hidden"
              />
              <button
                type="button"
                onClick={() => groupFileInputRef.current?.click()}
                className="p-3.5 rounded-2xl bg-slate-950 border border-slate-700 hover:border-amber-400 text-slate-300 hover:text-amber-300 cursor-pointer transition-all shadow-md shrink-0"
                title="Share encrypted image or document from your device with the group"
              >
                <Paperclip className="w-4 h-4 text-amber-400" />
              </button>

              <div className="relative flex-1">
                <input
                  type="text"
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  placeholder={`Write an end-to-end encrypted group message to ${activeChatMeta.title}...`}
                  className="w-full pl-4 pr-10 py-3.5 rounded-2xl bg-slate-950 border border-slate-700 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 font-sans"
                />
                <button
                  type="button"
                  onClick={() => setMessageInput(prev => `${prev} 🙏`)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-amber-300 cursor-pointer"
                >
                  <Smile className="w-5 h-5" />
                </button>
              </div>

              <button
                type="submit"
                disabled={!messageInput.trim()}
                className="px-5 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold shadow-lg shadow-amber-500/20 disabled:opacity-40 cursor-pointer transition-all hover:scale-105 flex items-center space-x-1.5"
              >
                <Send className="w-4 h-4 text-slate-950" />
                <span className="text-xs uppercase font-black">SEND</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB CONTENT: DIRECT CHATS (WITH READ RECEIPT CHECKMARKS)                  */}
      {/* ========================================================================= */}
      {activeTab === 'chats' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-slate-900 border border-amber-500/30 rounded-3xl p-4 sm:p-6 shadow-2xl min-h-[640px]">
          <div className="lg:col-span-4 border-b lg:border-b-0 lg:border-r border-slate-800 pr-0 lg:pr-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-black font-serif text-amber-200 uppercase tracking-wider flex items-center gap-1.5">
                  <MessageCircle className="w-4 h-4 text-amber-400" />
                  <span>CONTACT LIST</span>
                </h3>
                <p className="text-[10px] text-emerald-400 font-mono">
                  ● Online Contacts at Top ({sortedConnectedUsers.filter(u => u.isOnline).length} Active) - Memoized
                </p>
              </div>

              <button
                onClick={() => setActiveTab('discover')}
                className="px-2.5 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 text-xs font-bold flex items-center space-x-1 border border-amber-500/40 cursor-pointer"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Find More</span>
              </button>
            </div>

            <div className="space-y-2 max-h-[520px] overflow-y-auto pr-1">
              {sortedConnectedUsers.length === 0 ? (
                <div className="p-8 rounded-2xl bg-slate-950 text-center space-y-3 border border-slate-800">
                  <Handshake className="w-10 h-10 text-amber-400/60 mx-auto" />
                  <p className="text-xs text-slate-300 font-medium">No connected friends or partners yet.</p>
                  <p className="text-[11px] text-slate-500">
                    Discover believers across 195 countries and click 'Connect' to start private chatting!
                  </p>
                  <button
                    onClick={() => setActiveTab('discover')}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-xs uppercase cursor-pointer"
                  >
                    DISCOVER & CONNECT
                  </button>
                </div>
              ) : (
                sortedConnectedUsers.map((user) => (
                  <DirectContactItem
                    key={user.id}
                    user={user}
                    isSelected={selectedConversationId === user.id}
                    onSelect={handleSelectContact}
                  />
                ))
              )}
            </div>
          </div>

          <div className="lg:col-span-8 flex flex-col justify-between space-y-4">
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div className="flex items-center space-x-3.5">
                {activeChatMeta.avatar && (
                  <img
                    src={activeChatMeta.avatar}
                    alt={activeChatMeta.title}
                    className="w-11 h-11 rounded-2xl object-cover border-2 border-amber-500/40"
                  />
                )}
                <div>
                  <div className="flex items-center space-x-2.5">
                    <h3 className="text-base font-black text-amber-100 font-serif">{activeChatMeta.title}</h3>
                    {activeChatMeta.isOnline ? (
                      <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                        <span>● Online</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-rose-500/20 text-rose-300 border border-rose-400/30">
                        <span className="w-2 h-2 rounded-full bg-rose-400" />
                        <span>● Offline</span>
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">{activeChatMeta.subtitle}</p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setShowSecurityMachineModal(true)}
                  className="px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-mono font-bold flex items-center space-x-1.5 shadow-md cursor-pointer transition-all hover:scale-105"
                  title="Inspect Signed Certificate & Anti-Piracy Machine for juhnkrix.musika@gmail.com"
                >
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  <span>Anti-Piracy Shield</span>
                </button>

                <button
                  onClick={() => setShowSecurityAuditModal(true)}
                  className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-950 to-slate-900 border border-emerald-500/50 text-emerald-300 hover:text-emerald-200 text-xs font-mono font-bold flex items-center space-x-2 shadow-md cursor-pointer transition-all hover:scale-105"
                  title="Trigger Security Audit Breakdown of Encryption Protocols"
                >
                  <ShieldAlert className="w-4 h-4 text-emerald-400 animate-pulse" />
                  <span>Security Audit</span>
                </button>
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-gradient-to-r from-emerald-950/70 via-slate-950 to-slate-950 border border-emerald-500/40 text-[11px] text-emerald-200 font-mono flex items-center space-x-2.5 shadow-lg">
              <Lock className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                Chats and business transactions between you and this partner are end-to-end encrypted so no one else can see what you say or do on the JUHNKRIX MUSIKA network.
              </span>
            </div>

            {/* Pinned Messages Header Banner */}
            {pinnedMessages.length > 0 && (
              <div className="p-3 rounded-2xl bg-amber-950/60 border border-amber-400/40 text-[11px] text-amber-200 flex items-center justify-between shadow-lg animate-fadeIn">
                <div className="flex items-center space-x-2.5 min-w-0">
                  <Pin className="w-4 h-4 text-amber-400 fill-amber-400 shrink-0" />
                  <span className="font-bold text-amber-300 uppercase tracking-wider font-mono text-[10px] shrink-0">
                    PINNED ({pinnedMessages.length}):
                  </span>
                  <span className="truncate text-slate-200">
                    {pinnedMessages[pinnedMessages.length - 1].attachmentName
                      ? `[File: ${pinnedMessages[pinnedMessages.length - 1].attachmentName}] `
                      : ''}
                    {pinnedMessages[pinnedMessages.length - 1].text}
                  </span>
                </div>
                <button
                  onClick={() => handleTogglePinMessage(pinnedMessages[pinnedMessages.length - 1])}
                  className="px-2.5 py-1 rounded-xl bg-slate-900 border border-rose-500/30 text-rose-300 hover:text-rose-100 text-[10px] font-bold shrink-0 cursor-pointer transition-all ml-2"
                  title="Unpin this message"
                >
                  Unpin
                </button>
              </div>
            )}

            <div className="flex-1 max-h-[420px] min-h-[340px] overflow-y-auto space-y-1 p-4 bg-slate-950/80 rounded-2xl border border-slate-800">
              {messages.map((msg) => {
                const isMe = msg.senderId === 'me';
                return (
                  <E2EEMessageCard
                    key={msg.id}
                    message={msg}
                    isMe={isMe}
                    nodeSignature={`NODE-${socketSwarmInfo.nodeId.substring(5)}-DIRECT-AUDITED`}
                    onTogglePin={handleTogglePinMessage}
                  />
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            <form onSubmit={handleSendMessage} className="flex items-center space-x-2 pt-2">
              <input
                type="file"
                ref={directFileInputRef}
                onChange={handleFileUpload}
                accept="image/*,.pdf,.doc,.docx,.txt,.zip,.jm"
                className="hidden"
              />
              <button
                type="button"
                onClick={() => directFileInputRef.current?.click()}
                className="p-3.5 rounded-2xl bg-slate-950 border border-slate-700 hover:border-amber-400 text-slate-300 hover:text-amber-300 cursor-pointer transition-all shadow-md shrink-0"
                title="Share encrypted image or document from your device"
              >
                <Paperclip className="w-4 h-4 text-amber-400" />
              </button>

              <div className="relative flex-1">
                <input
                  type="text"
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  placeholder={`Write an end-to-end encrypted private message to ${activeChatMeta.title}...`}
                  className="w-full pl-4 pr-10 py-3.5 rounded-2xl bg-slate-950 border border-slate-700 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 font-sans"
                />
                <button
                  type="button"
                  onClick={() => setMessageInput(prev => `${prev} 🙏`)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-amber-300 cursor-pointer"
                >
                  <Smile className="w-5 h-5" />
                </button>
              </div>

              <button
                type="submit"
                disabled={!messageInput.trim()}
                className="px-5 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold shadow-lg shadow-amber-500/20 disabled:opacity-40 cursor-pointer transition-all hover:scale-105 flex items-center space-x-1.5"
              >
                <Send className="w-4 h-4 text-slate-950" />
                <span className="text-xs uppercase font-black">SEND</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB CONTENT: DISCOVER & CONNECT                                           */}
      {/* ========================================================================= */}
      {activeTab === 'discover' && (
        <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Real-time fuzzy search by user name, country (e.g. Nigeria, Canada, UK), city, or sector..."
                className="w-full pl-10 pr-10 py-3.5 rounded-2xl bg-slate-950 border border-slate-700 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 font-sans"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs p-1 cursor-pointer bg-slate-800 rounded-full w-5 h-5 flex items-center justify-center"
                  title="Clear search"
                >
                  ✕
                </button>
              )}
            </div>

            <div className="flex items-center space-x-2 shrink-0">
              <Globe className="w-5 h-5 text-amber-400 shrink-0" />
              <select
                value={selectedCountry}
                onChange={(e) => setSelectedCountry(e.target.value)}
                className="bg-slate-950 border border-slate-700 text-xs sm:text-sm text-amber-200 font-bold rounded-2xl px-4 py-3.5 focus:outline-none focus:border-amber-400 cursor-pointer font-sans max-w-[290px]"
              >
                {countries.map((c) => (
                  <option key={c} value={c}>
                    {c === 'All Countries' ? '🌍 All Countries (Global 195)' : `${getCountryFlag(c)} ${c}`}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="space-y-1.5 pt-1">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">
              Quick Filter By Alphabetical Starting Letter:
            </span>
            <div className="flex flex-wrap items-center gap-1.5">
              {alphabetList.map((char) => (
                <button
                  key={char}
                  onClick={() => setSelectedAlphabet(char)}
                  className={`min-w-7 h-7 px-1.5 rounded-lg text-[11px] font-bold font-mono transition-all cursor-pointer ${
                    selectedAlphabet === char
                      ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md font-black scale-105'
                      : 'bg-slate-950 text-slate-400 hover:text-amber-300 border border-slate-800'
                  }`}
                >
                  {char}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-2">
            <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
              <h3 className="text-sm font-black font-serif text-amber-100 flex items-center space-x-2">
                <span>
                  FOUND {sortedFilteredUsers.length} BELIEVER(S) IN {selectedCountry.toUpperCase()}
                </span>
                {selectedAlphabet !== 'ALL' && (
                  <span className="text-xs text-amber-400 font-mono">(Starting with "{selectedAlphabet}")</span>
                )}
              </h3>
              <div className="flex items-center space-x-2 text-xs font-mono text-slate-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="text-emerald-400 font-bold">Online Auto-Sorted to Top (React.memo Optimized)</span>
              </div>
            </div>

            {sortedFilteredUsers.length === 0 ? (
              <div className="p-12 rounded-3xl bg-slate-950 border border-slate-800 text-center space-y-3">
                <Users className="w-12 h-12 text-amber-400/40 mx-auto" />
                <h4 className="text-sm font-bold text-amber-200">No users found in this region.</h4>
                <p className="text-xs text-slate-400">
                  {selectedCountry !== 'All Countries'
                    ? `No believers found in ${selectedCountry} matching "${searchQuery}". Try selecting 'All Countries' or resetting your search.`
                    : 'Try modifying your search query or resetting filters.'}
                </p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCountry('All Countries');
                    setSelectedAlphabet('ALL');
                  }}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-bold text-xs uppercase cursor-pointer"
                >
                  Reset Filters & View All
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {sortedFilteredUsers.map((u) => (
                  <BelieverCard
                    key={u.id}
                    user={u}
                    connectionHistory={connectionHistory}
                    onChatNow={handleChatNow}
                    onAccept={handleAcceptRequest}
                    onReject={handleRejectRequest}
                    onConnect={handleInitiateConnect}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB CONTENT: CONNECTION HISTORY                                           */}
      {/* ========================================================================= */}
      {activeTab === 'history' && (
        <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
            <div>
              <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black tracking-wider uppercase mb-2">
                <History className="w-3.5 h-3.5 text-amber-400" />
                <span>Decentralized Storage Audit Vault</span>
              </div>
              <h2 className="text-2xl font-black font-serif text-amber-100">CONNECTION HISTORY TRACKER</h2>
              <p className="text-xs text-slate-400 mt-1">
                Tracks all recent friend & business partner connection handshakes, acceptance statuses, and cryptographic timestamps.
              </p>
            </div>

            <button
              onClick={() => {
                if (window.confirm('Clear all connection history records?')) {
                  setConnectionHistory([]);
                  localStorage.removeItem(CONNECTION_HISTORY_KEY);
                  showToast('info', 'Connection history cleared.');
                }
              }}
              className="px-4 py-2 rounded-xl bg-slate-950 border border-rose-500/40 text-rose-300 hover:text-rose-200 text-xs font-bold uppercase cursor-pointer transition-all"
            >
              Clear History
            </button>
          </div>

          <div className="space-y-3">
            {connectionHistory.length === 0 ? (
              <div className="p-12 rounded-3xl bg-slate-950 border border-slate-800 text-center space-y-3">
                <History className="w-10 h-10 text-amber-400/40 mx-auto" />
                <h4 className="text-sm font-bold text-amber-200">No connection history recorded yet.</h4>
                <p className="text-xs text-slate-400">Send or receive connection requests in Discover & Connect to populate history.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {connectionHistory.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-lg hover:border-amber-500/40 transition-all"
                  >
                    <div className="flex items-center space-x-3.5">
                      <img
                        src={item.userAvatar}
                        alt={item.userName}
                        className="w-12 h-12 rounded-xl object-cover border border-amber-500/30 shrink-0"
                      />
                      <div>
                        <div className="flex items-center space-x-2">
                          <h4 className="text-xs sm:text-sm font-bold text-amber-100">{item.userName}</h4>
                          <span className="text-[10px] font-mono text-slate-400">
                            {getCountryFlag(item.userCountry)} {item.userCountry}
                          </span>
                        </div>
                        <p className="text-[10px] font-mono text-slate-500 mt-0.5">Timestamp: {item.timestamp}</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 w-full sm:w-auto justify-end">
                      <span className={`px-3 py-1 rounded-xl text-xs font-mono font-bold uppercase border ${
                        item.status === 'ACCEPTED'
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                          : item.status === 'REJECTED'
                          ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                          : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      }`}>
                        {item.status === 'ACCEPTED' ? '✓ Accepted Partner' : item.status === 'REJECTED' ? '✕ Rejected' : '⏱ Pending Handshake'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SECURITY AUDIT BREAKDOWN MODAL                                            */}
      {/* ========================================================================= */}
      {showSecurityAuditModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-slate-900 border-2 border-emerald-500/50 rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative text-left">
            <button
              onClick={() => setShowSecurityAuditModal(false)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-amber-300 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-3.5">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-400/30 flex items-center justify-center shrink-0">
                <ShieldAlert className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <h3 className="text-lg font-black font-serif text-emerald-100">
                  DECENTRALIZED ENCRYPTION SECURITY AUDIT
                </h3>
                <span className="text-xs font-mono text-emerald-400">
                  🔒 Verified Sovereign P2P Mesh Architecture
                </span>
              </div>
            </div>

            <div className="space-y-3.5 text-xs text-slate-300 font-sans leading-relaxed">
              <p>
                This live security audit confirms that all messages, voice notes, and media transmitted across the JUHNKRIX MUSIKA decentralized network adhere to zero-knowledge sovereign encryption standards.
              </p>

              <div className="space-y-2 font-mono text-[11px]">
                <div className="p-3 rounded-xl bg-slate-950 border border-emerald-500/30 flex items-start space-x-3">
                  <KeyRound className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-amber-200">Curve25519 & X3DH Key Exchange:</strong>
                    <p className="text-slate-400 text-[10px] mt-0.5">Asymmetric cryptographic handshake establishes ephemeral session keys directly between peers.</p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-emerald-500/30 flex items-start space-x-3">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-emerald-200">AES-256-GCM Symmetric Cipher:</strong>
                    <p className="text-slate-400 text-[10px] mt-0.5">All message payloads are authenticated and encrypted with 256-bit Galois/Counter Mode.</p>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-emerald-500/30 flex items-start space-x-3">
                  <Lock className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-cyan-200">Zero Server Storage & Forward Secrecy:</strong>
                    <p className="text-slate-400 text-[10px] mt-0.5">No transcripts are ever logged on external servers. Compromising one session key exposes no past chats.</p>
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/35 text-emerald-200 text-[11px] font-mono">
                ✓ Node ID: <strong>{socketSwarmInfo.nodeId}</strong> | Active Swarm Nodes: <strong>{socketSwarmInfo.activePeers.toLocaleString()}</strong> ({socketSwarmInfo.health} uptime)
              </div>
            </div>

            <div className="flex items-center justify-end pt-2">
              <button
                onClick={() => setShowSecurityAuditModal(false)}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-black text-xs uppercase cursor-pointer shadow-lg"
              >
                Close Audit Report
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* CONNECTION MODAL                                                          */}
      {/* ========================================================================= */}
      {connectionModalUser && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-slate-900 border-2 border-amber-500/50 rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl relative text-left">
            <button
              onClick={() => setConnectionModalUser(null)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-amber-300 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-start space-x-4">
              <div className="relative shrink-0">
                <img
                  src={connectionModalUser.avatar}
                  alt={connectionModalUser.name}
                  className="w-16 h-16 rounded-2xl object-cover border-2 border-amber-400"
                />
                <span
                  className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-slate-950 ${
                    connectionModalUser.isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'
                  }`}
                />
              </div>

              <div>
                <h3 className="text-lg font-black font-serif text-amber-100">
                  CONNECT WITH {connectionModalUser.name.toUpperCase()}
                </h3>
                <div className="flex items-center gap-2 mt-1">
                  {connectionModalUser.isOnline ? (
                    <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold text-emerald-400">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      <span>● Online Believer</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold text-rose-400">
                      <span className="w-2 h-2 rounded-full bg-rose-400" />
                      <span>● Offline Believer</span>
                    </span>
                  )}
                  <span className="text-[10px] font-mono text-slate-400">
                    • {getCountryFlag(connectionModalUser.country)} {connectionModalUser.city}, {connectionModalUser.country}
                  </span>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-amber-950/60 border border-amber-400/40 text-amber-100 text-xs sm:text-sm leading-relaxed font-sans">
              "{connectionModalUser.name} wants to be your friend and business partner, click on the ACCEPT button to connect with the user or click on the REJECT button to decline or revoke the friend and business partner request"
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                <Lock className="w-3.5 h-3.5" />
                <span>E2EE Private Handshake</span>
              </span>

              <div className="flex items-center space-x-3">
                <button
                  type="button"
                  onClick={() => handleRejectRequest(connectionModalUser)}
                  className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-rose-300 hover:text-rose-200 border border-rose-500/30 font-bold text-xs uppercase cursor-pointer"
                >
                  REJECT
                </button>
                <button
                  type="button"
                  onClick={() => handleConfirmSendRequest(connectionModalUser)}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs uppercase shadow-lg shadow-emerald-500/20 cursor-pointer"
                >
                  ACCEPT / SEND REQUEST
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* CREATE NEW GROUP MODAL WITH CUSTOMIZABLE AVATARS                          */}
      {/* ========================================================================= */}
      {showNewGroupModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border-2 border-amber-500/50 rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl relative text-left">
            <button
              onClick={() => setShowNewGroupModal(false)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-amber-300 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-3.5">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-400/30 flex items-center justify-center text-xl shrink-0">
                <Users className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-black font-serif text-amber-100">
                  CREATE E2EE GROUP WITH CUSTOM AVATAR
                </h3>
                <span className="text-xs font-mono text-emerald-400">
                  🔒 Strictly Private • Decentralized Network
                </span>
              </div>
            </div>

            <form onSubmit={handleCreateGroup} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Group Title:</label>
                <input
                  type="text"
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  placeholder="e.g. Lagos Apostolic Altar & Trade"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Group Purpose / Description:</label>
                <textarea
                  value={newGroupDescription}
                  onChange={(e) => setNewGroupDescription(e.target.value)}
                  placeholder="Describe fellowship objectives, trade topics, or prayer schedules..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 h-20"
                />
              </div>

              {/* Customizable Group Avatar Selection */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300 block">Choose Group Avatar Preset or Custom URL:</label>
                <div className="grid grid-cols-4 gap-2">
                  {PRESET_GROUP_AVATARS.map((preset) => (
                    <button
                      key={preset.name}
                      type="button"
                      onClick={() => {
                        setSelectedGroupAvatar(preset.url);
                        setCustomGroupAvatarUrl('');
                      }}
                      className={`relative rounded-2xl overflow-hidden border-2 transition-all cursor-pointer aspect-square ${
                        selectedGroupAvatar === preset.url && !customGroupAvatarUrl
                          ? 'border-amber-400 ring-2 ring-amber-400/50 scale-105'
                          : 'border-slate-800 opacity-70 hover:opacity-100'
                      }`}
                      title={preset.name}
                    >
                      <img src={preset.url} alt={preset.name} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>

                <div className="pt-1">
                  <input
                    type="url"
                    value={customGroupAvatarUrl}
                    onChange={(e) => setCustomGroupAvatarUrl(e.target.value)}
                    placeholder="Or paste custom avatar image URL (https://...)"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewGroupModal(false)}
                  className="px-5 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-xs uppercase shadow-md shadow-amber-500/20 cursor-pointer"
                >
                  Create Group Thread
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showEditGroupAvatarModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border-2 border-amber-500/50 rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl relative text-left">
            <button
              onClick={() => setShowEditGroupAvatarModal(false)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-amber-300 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-3.5">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-400/30 flex items-center justify-center text-xl shrink-0">
                <Users className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-black font-serif text-amber-100">
                  UPDATE GROUP AVATAR
                </h3>
                <span className="text-xs font-mono text-emerald-400">
                  🔒 Synchronized via Decentralized Network
                </span>
              </div>
            </div>

            <form onSubmit={handleUpdateGroupAvatarSubmit} className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300 block">Select Preset Avatar or Paste Custom URL:</label>
                <div className="grid grid-cols-4 gap-2">
                  {PRESET_GROUP_AVATARS.map((preset) => (
                    <button
                      key={preset.name}
                      type="button"
                      onClick={() => {
                        setSelectedEditPresetAvatar(preset.url);
                        setEditGroupAvatarUrl('');
                      }}
                      className={`relative rounded-2xl overflow-hidden border-2 transition-all cursor-pointer aspect-square ${
                        selectedEditPresetAvatar === preset.url && !editGroupAvatarUrl
                          ? 'border-amber-400 ring-2 ring-amber-400/50 scale-105'
                          : 'border-slate-800 opacity-70 hover:opacity-100'
                      }`}
                      title={preset.name}
                    >
                      <img src={preset.url} alt={preset.name} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>

                <div className="pt-1">
                  <input
                    type="url"
                    value={editGroupAvatarUrl}
                    onChange={(e) => setEditGroupAvatarUrl(e.target.value)}
                    placeholder="Or paste custom image URL (https://...)"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowEditGroupAvatarModal(false)}
                  className="px-5 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 font-black text-xs uppercase shadow-md shadow-amber-500/20 cursor-pointer"
                >
                  Save & Synchronize
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Sovereign Security Machine & Anti-Piracy Threat Telemetry Modal */}
      <SovereignSecurityMachineModal
        isOpen={showSecurityMachineModal}
        onClose={() => setShowSecurityMachineModal(false)}
      />
    </div>
  );
};
