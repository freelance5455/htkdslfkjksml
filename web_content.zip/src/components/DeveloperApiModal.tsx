import React, { useState } from 'react';
import { 
  Code2, 
  Key, 
  Copy, 
  Check, 
  Play, 
  Terminal, 
  BookOpen, 
  RefreshCw, 
  Trash2, 
  Send, 
  Sparkles,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { DeveloperApiKey, ApiTestResponse, Language, PersonaId } from '../types/tts';
import { generateApiSnippets } from '../utils/apiDocs';
import { SUPPORTED_LANGUAGES } from '../constants/languages';
import { VOICE_PERSONAS } from '../constants/personas';

interface DeveloperApiModalProps {
  isOpen: boolean;
  onClose: () => void;
  apiKeys: DeveloperApiKey[];
  onGenerateKey: (name?: string) => DeveloperApiKey;
  onRevokeKey: (id: string) => void;
  defaultLanguage: Language;
  defaultPersona: PersonaId;
}

export const DeveloperApiModal: React.FC<DeveloperApiModalProps> = ({
  isOpen,
  onClose,
  apiKeys,
  onGenerateKey,
  onRevokeKey,
  defaultLanguage,
  defaultPersona,
}) => {
  const [activeTab, setActiveTab] = useState<'keys' | 'playground' | 'docs'>('keys');
  const [selectedLanguageCode, setSelectedLanguageCode] = useState(defaultLanguage.code);
  const [selectedPersonaId, setSelectedPersonaId] = useState(defaultPersona);
  const [testText, setTestText] = useState('Welcome to SK text to speech Developer API.');
  const [speed, setSpeed] = useState(1.0);
  const [copiedKeyId, setCopiedKeyId] = useState<string | null>(null);
  const [copiedSnippet, setCopiedSnippet] = useState<string | null>(null);
  const [snippetLang, setSnippetLang] = useState<'curl' | 'javascript' | 'python' | 'php'>('curl');

  // Test Runner State
  const [isRunningTest, setIsRunningTest] = useState(false);
  const [testResult, setTestResult] = useState<ApiTestResponse | null>(null);

  if (!isOpen) return null;

  const activeKey = apiKeys[0]?.key || 'sk_live_demo_client_key_9941';

  const snippets = generateApiSnippets(
    activeKey,
    testText,
    selectedLanguageCode,
    selectedPersonaId,
    speed
  );

  const handleCopy = (text: string, id: string, type: 'key' | 'snippet') => {
    navigator.clipboard.writeText(text);
    if (type === 'key') {
      setCopiedKeyId(id);
      setTimeout(() => setCopiedKeyId(null), 2000);
    } else {
      setCopiedSnippet(id);
      setTimeout(() => setCopiedSnippet(null), 2000);
    }
  };

  const handleRunApiTest = async () => {
    setIsRunningTest(true);
    setTestResult(null);
    const startTime = Date.now();

    try {
      const response = await fetch('/api/v1/tts/synthesize', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': activeKey,
        },
        body: JSON.stringify({
          text: testText,
          language: selectedLanguageCode,
          persona: selectedPersonaId,
          speed,
        }),
      });

      const data = await response.json();
      const durationMs = Date.now() - startTime;

      const headerObj: Record<string, string> = {};
      response.headers.forEach((val, key) => {
        headerObj[key] = val;
      });

      setTestResult({
        status: response.status,
        ok: response.ok,
        durationMs,
        charCount: testText.length,
        audioFormat: data?.data?.mimeType || 'audio/wav',
        audioBase64: data?.data?.audioBase64,
        headers: headerObj,
        message: data?.error || (response.ok ? 'Success: Audio synthesized' : 'Failed'),
      });
    } catch (err: any) {
      setTestResult({
        status: 500,
        ok: false,
        durationMs: Date.now() - startTime,
        charCount: testText.length,
        audioFormat: 'audio/wav',
        headers: {},
        message: err?.message || 'Connection failed. Check network or server.',
      });
    } finally {
      setIsRunningTest(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/65 backdrop-blur-md animate-in fade-in overflow-y-auto">
      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl max-w-4xl w-full shadow-2xl overflow-hidden flex flex-col my-auto max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between bg-zinc-50 dark:bg-zinc-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-violet-600/10 text-violet-600 dark:text-violet-400">
              <Code2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-extrabold text-zinc-900 dark:text-white">
                  SK text to speech Developer API
                </h2>
                <span className="text-[10px] uppercase font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                  v1.0 Live
                </span>
              </div>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                Integrate multilingual TTS into mobile apps, websites, and backend bots
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 px-3 py-1 rounded-xl text-sm"
          >
            ✕
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="px-6 pt-3 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-4 bg-zinc-50/50 dark:bg-zinc-950/30">
          <button
            onClick={() => setActiveTab('keys')}
            className={`pb-3 text-xs font-bold transition-all border-b-2 flex items-center gap-1.5 ${
              activeTab === 'keys'
                ? 'border-violet-600 text-violet-600 dark:text-violet-400'
                : 'border-transparent text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
            }`}
          >
            <Key className="w-4 h-4" />
            API Keys &amp; Credentials
          </button>

          <button
            onClick={() => setActiveTab('playground')}
            className={`pb-3 text-xs font-bold transition-all border-b-2 flex items-center gap-1.5 ${
              activeTab === 'playground'
                ? 'border-violet-600 text-violet-600 dark:text-violet-400'
                : 'border-transparent text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
            }`}
          >
            <Terminal className="w-4 h-4" />
            Interactive Playground &amp; Code
          </button>

          <button
            onClick={() => setActiveTab('docs')}
            className={`pb-3 text-xs font-bold transition-all border-b-2 flex items-center gap-1.5 ${
              activeTab === 'docs'
                ? 'border-violet-600 text-violet-600 dark:text-violet-400'
                : 'border-transparent text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            API Reference
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          
          {/* TAB 1: API KEYS */}
          {activeTab === 'keys' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 bg-violet-500/5 dark:bg-violet-950/20 border border-violet-500/20 rounded-2xl">
                <div>
                  <h4 className="text-sm font-bold text-zinc-900 dark:text-white flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-violet-500" />
                    Developer Authentication
                  </h4>
                  <p className="text-xs text-zinc-600 dark:text-zinc-400 mt-0.5">
                    Pass your key via the <code className="font-mono bg-violet-500/10 px-1 py-0.5 rounded text-violet-600 dark:text-violet-300">x-api-key</code> header or Bearer authorization.
                  </p>
                </div>
                <button
                  onClick={() => onGenerateKey()}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-violet-600 hover:bg-violet-500 text-white shadow-md shadow-violet-600/30 flex items-center gap-1.5 shrink-0 self-start sm:self-auto"
                >
                  <Key className="w-3.5 h-3.5" />
                  Generate New API Key
                </button>
              </div>

              {/* Keys list */}
              <div className="space-y-3">
                <h5 className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                  Active API Keys ({apiKeys.length})
                </h5>

                {apiKeys.length === 0 ? (
                  <div className="text-center py-8 text-zinc-400 text-xs">
                    No keys found. Click &quot;Generate New API Key&quot; to create your first credential.
                  </div>
                ) : (
                  apiKeys.map((k) => (
                    <div
                      key={k.id}
                      className="p-4 rounded-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-50/50 dark:bg-zinc-950/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-zinc-900 dark:text-white">
                            {k.name}
                          </span>
                          <span className="text-[10px] font-semibold text-emerald-600 bg-emerald-500/10 px-1.5 py-0.5 rounded">
                            Active
                          </span>
                        </div>
                        <div className="font-mono text-xs text-zinc-600 dark:text-zinc-400 flex items-center gap-2">
                          <span>{k.key}</span>
                        </div>
                        <div className="text-[10px] text-zinc-400">
                          Created: {new Date(k.createdAt).toLocaleDateString()} · Rate limit: {k.rateLimit} req/min
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleCopy(k.key, k.id, 'key')}
                          className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-white dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-700 flex items-center gap-1.5"
                        >
                          {copiedKeyId === k.id ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-500" />
                              Copied
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              Copy Key
                            </>
                          )}
                        </button>

                        <button
                          onClick={() => onRevokeKey(k.id)}
                          className="p-1.5 rounded-lg text-zinc-400 hover:text-red-500 hover:bg-red-500/10"
                          title="Revoke Key"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* TAB 2: PLAYGROUND & CODE GENERATION */}
          {activeTab === 'playground' && (
            <div className="space-y-6">
              {/* Interactive test panel */}
              <div className="p-4 bg-zinc-50 dark:bg-zinc-950 rounded-2xl border border-zinc-200 dark:border-zinc-800 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400 flex items-center gap-1.5">
                    <Terminal className="w-4 h-4 text-violet-500" />
                    Live API Sandbox Tester
                  </h4>
                  <span className="font-mono text-[11px] text-violet-600 dark:text-violet-400 font-semibold">
                    POST /api/v1/tts/synthesize
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-zinc-500">Language</label>
                    <select
                      value={selectedLanguageCode}
                      onChange={(e) => setSelectedLanguageCode(e.target.value)}
                      className="w-full mt-1 px-3 py-1.5 text-xs rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-white"
                    >
                      {SUPPORTED_LANGUAGES.map((l) => (
                        <option key={l.code} value={l.code}>
                          {l.flag} {l.name} ({l.nativeName})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-zinc-500">Persona</label>
                    <select
                      value={selectedPersonaId}
                      onChange={(e) => setSelectedPersonaId(e.target.value as PersonaId)}
                      className="w-full mt-1 px-3 py-1.5 text-xs rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-white"
                    >
                      {VOICE_PERSONAS.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-zinc-500">Speed</label>
                    <select
                      value={speed}
                      onChange={(e) => setSpeed(parseFloat(e.target.value))}
                      className="w-full mt-1 px-3 py-1.5 text-xs rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-white"
                    >
                      <option value={0.75}>0.75x</option>
                      <option value={1.0}>1.0x (Normal)</option>
                      <option value={1.25}>1.25x</option>
                      <option value={1.5}>1.5x</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-zinc-500">Payload Text</label>
                  <textarea
                    value={testText}
                    onChange={(e) => setTestText(e.target.value)}
                    rows={2}
                    className="w-full mt-1 p-2.5 text-xs rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-white font-sans"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <button
                    onClick={handleRunApiTest}
                    disabled={isRunningTest}
                    className="px-4 py-2 rounded-xl text-xs font-bold bg-violet-600 hover:bg-violet-500 text-white shadow-md shadow-violet-600/30 flex items-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {isRunningTest ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        Executing Endpoint...
                      </>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5" />
                        Send API Request
                      </>
                    )}
                  </button>

                  {testResult && (
                    <div className="flex items-center gap-2 text-xs">
                      {testResult.ok ? (
                        <span className="flex items-center gap-1 text-emerald-500 font-bold">
                          <CheckCircle2 className="w-4 h-4" /> 200 OK ({testResult.durationMs}ms)
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-red-500 font-bold">
                          <AlertCircle className="w-4 h-4" /> {testResult.status} Error
                        </span>
                      )}
                    </div>
                  )}
                </div>

                {/* Test Result Output */}
                {testResult && (
                  <div className="p-3 rounded-xl bg-zinc-900 text-zinc-200 text-xs font-mono space-y-2 border border-zinc-800">
                    <div className="flex items-center justify-between text-[11px] text-zinc-400 border-b border-zinc-800 pb-1">
                      <span>Response Status: {testResult.status}</span>
                      <span>Latency: {testResult.durationMs}ms</span>
                    </div>

                    {testResult.audioBase64 && (
                      <div className="pt-1">
                        <span className="text-[11px] text-zinc-400 block mb-1">Preview Audio Output:</span>
                        <audio
                          controls
                          src={`data:${testResult.audioFormat};base64,${testResult.audioBase64}`}
                          className="w-full h-8"
                        />
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Code Snippets Section */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
                    Integration Code Snippets
                  </h4>

                  {/* Language Selector */}
                  <div className="flex items-center gap-1 bg-zinc-100 dark:bg-zinc-800 p-1 rounded-lg text-xs font-medium">
                    {(['curl', 'javascript', 'python', 'php'] as const).map((lang) => (
                      <button
                        key={lang}
                        onClick={() => setSnippetLang(lang)}
                        className={`px-2.5 py-1 rounded-md capitalize transition-all ${
                          snippetLang === lang
                            ? 'bg-white dark:bg-zinc-700 text-zinc-900 dark:text-white font-bold shadow-xs'
                            : 'text-zinc-500 hover:text-zinc-900 dark:hover:text-white'
                        }`}
                      >
                        {lang === 'javascript' ? 'JS / Node' : lang}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="relative rounded-2xl bg-zinc-950 p-4 font-mono text-xs text-zinc-300 border border-zinc-800 overflow-x-auto shadow-inner">
                  <button
                    onClick={() => handleCopy(snippets[snippetLang], snippetLang, 'snippet')}
                    className="absolute top-3 right-3 px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-[11px] font-sans font-semibold text-zinc-300 flex items-center gap-1.5 transition-all"
                  >
                    {copiedSnippet === snippetLang ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" /> Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" /> Copy Snippet
                      </>
                    )}
                  </button>

                  <pre className="pr-16 leading-relaxed whitespace-pre">
                    {snippets[snippetLang]}
                  </pre>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: API REFERENCE */}
          {activeTab === 'docs' && (
            <div className="space-y-6 text-xs text-zinc-700 dark:text-zinc-300 leading-relaxed">
              
              <div>
                <h4 className="text-sm font-bold text-zinc-900 dark:text-white mb-1">
                  1. Synthesis Endpoint
                </h4>
                <div className="flex items-center gap-2 font-mono bg-zinc-100 dark:bg-zinc-950 px-3 py-2 rounded-xl border border-zinc-200 dark:border-zinc-800">
                  <span className="font-bold text-emerald-600 dark:text-emerald-400">POST</span>
                  <span className="text-zinc-800 dark:text-zinc-200">/api/v1/tts/synthesize</span>
                </div>
              </div>

              <div>
                <h5 className="font-bold text-zinc-900 dark:text-white mb-2">Request Headers</h5>
                <div className="border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden font-mono text-[11px]">
                  <div className="bg-zinc-50 dark:bg-zinc-950 p-2.5 font-bold border-b border-zinc-200 dark:border-zinc-800 grid grid-cols-3">
                    <span>Header</span>
                    <span>Type</span>
                    <span>Description</span>
                  </div>
                  <div className="p-2.5 grid grid-cols-3 border-b border-zinc-200 dark:border-zinc-800">
                    <code>Content-Type</code>
                    <span>string</span>
                    <span>Must be <code>application/json</code></span>
                  </div>
                  <div className="p-2.5 grid grid-cols-3">
                    <code>x-api-key</code>
                    <span>string</span>
                    <span>Your generated API Key</span>
                  </div>
                </div>
              </div>

              <div>
                <h5 className="font-bold text-zinc-900 dark:text-white mb-2">JSON Body Parameters</h5>
                <div className="border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden font-mono text-[11px]">
                  <div className="bg-zinc-50 dark:bg-zinc-950 p-2.5 font-bold border-b border-zinc-200 dark:border-zinc-800 grid grid-cols-4">
                    <span>Field</span>
                    <span>Type</span>
                    <span>Required</span>
                    <span>Default / Values</span>
                  </div>
                  <div className="p-2.5 grid grid-cols-4 border-b border-zinc-200 dark:border-zinc-800">
                    <code>text</code>
                    <span>string</span>
                    <span className="text-emerald-500 font-bold">Yes</span>
                    <span>Up to 5,000 characters</span>
                  </div>
                  <div className="p-2.5 grid grid-cols-4 border-b border-zinc-200 dark:border-zinc-800">
                    <code>language</code>
                    <span>string</span>
                    <span>No</span>
                    <span><code>ta-IN</code>, <code>te-IN</code>, <code>en-US</code>...</span>
                  </div>
                  <div className="p-2.5 grid grid-cols-4 border-b border-zinc-200 dark:border-zinc-800">
                    <code>persona</code>
                    <span>string</span>
                    <span>No</span>
                    <span><code>male</code>, <code>female</code>, <code>child</code>, <code>alien</code>...</span>
                  </div>
                  <div className="p-2.5 grid grid-cols-4">
                    <code>speed</code>
                    <span>number</span>
                    <span>No</span>
                    <span>0.25 to 3.0 (default: 1.0)</span>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-bold text-zinc-900 dark:text-white mb-1">
                  2. Languages Listing Endpoint
                </h4>
                <div className="flex items-center gap-2 font-mono bg-zinc-100 dark:bg-zinc-950 px-3 py-2 rounded-xl border border-zinc-200 dark:border-zinc-800">
                  <span className="font-bold text-sky-600 dark:text-sky-400">GET</span>
                  <span className="text-zinc-800 dark:text-zinc-200">/api/v1/languages</span>
                </div>
                <p className="mt-1 text-zinc-500">
                  Returns all available languages, dialect codes, native names, and persona definitions.
                </p>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
};
