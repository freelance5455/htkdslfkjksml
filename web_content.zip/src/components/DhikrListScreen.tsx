import React, { useState, useEffect } from 'react';
import { 
  Sun, 
  Moon, 
  Layers, 
  Heart, 
  Check, 
  ChevronLeft,
  Sparkles,
  Volume2,
  VolumeX
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { MORNING_ADHKAR, EVENING_ADHKAR, ALL_ADHKAR } from '../data/adhkarData';
import { DhikrItem } from '../types';
import { recitationEngine } from '../utils/recitationService';
import { triggerVibration } from '../utils/audioFeedback';

export const DhikrListScreen: React.FC = () => {
  const { 
    selectedCategory, 
    setSelectedCategory, 
    openMorningEveningView,
    openDhikr, 
    isFavorite, 
    toggleFavorite, 
    getProgressFor,
    settings,
    showToast
  } = useApp();

  const [activeAudioDhikrId, setActiveAudioDhikrId] = useState<string | null>(null);

  useEffect(() => {
    const handleAudioState = () => {
      if (!recitationEngine.isPlaying()) {
        setActiveAudioDhikrId(null);
      }
    };
    recitationEngine.setOnStateChange(handleAudioState);
    return () => {
      // unbind
    };
  }, []);

  const handleToggleAudio = (dhikr: DhikrItem, e: React.MouseEvent) => {
    e.stopPropagation();
    triggerVibration(settings.vibration !== false, 'light');

    if (activeAudioDhikrId === dhikr.id && recitationEngine.isPlaying()) {
      recitationEngine.pause();
      setActiveAudioDhikrId(null);
      showToast('تم إيقاف تلاوة الذكر');
    } else {
      setActiveAudioDhikrId(dhikr.id);
      recitationEngine.setReciter(settings.selectedReciter || 'alafasy');
      recitationEngine.playDhikr(dhikr);
      showToast(`استماع للذكر المبارك: ${dhikr.title} 🎙️`);
    }
  };

  const getDisplayedList = (): DhikrItem[] => {
    switch (selectedCategory) {
      case 'morning': return MORNING_ADHKAR;
      case 'evening': return EVENING_ADHKAR;
      default: return ALL_ADHKAR;
    }
  };

  const list = getDisplayedList();

  return (
    <div className="space-y-4 pb-24">
      {/* Header */}
      <div className="pt-2">
        <h2 className="text-2xl font-extrabold text-[#0c2e20] dark:text-[#e8f5ee] font-cairo">
          فهرس الأذكار
        </h2>
        <p className="text-xs text-[#4d7d67] dark:text-[#84b8a0] font-tajawal mt-0.5">
          {list.length} ذكراً ودعاءً مباركاً من القرآن والسنة
        </p>
      </div>

      {/* Specialized Morning & Evening Fast View Launcher Banner */}
      <div 
        onClick={() => openMorningEveningView(selectedCategory === 'evening' ? 'evening' : 'morning')}
        className="w-full p-3 rounded-2xl bg-gradient-to-r from-[#03261b] via-[#053828] to-[#03261b] border border-amber-400/40 text-amber-300 flex items-center justify-between cursor-pointer hover:border-amber-300 transition-all shadow-md group"
      >
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-400/30 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="font-extrabold text-xs font-cairo text-amber-200">
              العرض المتخصص لأذكار الصباح والمساء ⚡
            </div>
            <div className="text-[10px] text-emerald-300 font-tajawal">
              تنقل فوري بين الوردين مع عداد مباشر داخل البطاقات
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1 text-xs font-bold font-cairo bg-amber-400/20 px-2.5 py-1 rounded-xl text-amber-300 border border-amber-400/30 group-hover:bg-amber-400/30 transition-colors">
          <span>دخول</span>
          <ChevronLeft className="w-3.5 h-3.5" />
        </div>
      </div>

      {/* Segmented Filter Control */}
      <div className="flex items-center p-1 bg-[#eaf5ef] dark:bg-[#062c20] rounded-2xl border border-emerald-300/40 dark:border-emerald-800">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            selectedCategory === 'all'
              ? 'bg-[#042017] dark:bg-[#093526] text-[#0c2e20] dark:text-emerald-300 shadow-xs border border-emerald-400/40'
              : 'text-[#4d7d67] dark:text-[#7ba993] hover:text-[#0c2e20] dark:hover:text-emerald-200'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>الكل ({ALL_ADHKAR.length})</span>
        </button>

        <button
          onClick={() => setSelectedCategory('morning')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            selectedCategory === 'morning'
              ? 'bg-[#042017] dark:bg-[#093526] text-amber-800 dark:text-amber-300 shadow-xs border border-emerald-400/40'
              : 'text-[#4d7d67] dark:text-[#7ba993] hover:text-[#0c2e20] dark:hover:text-emerald-200'
          }`}
        >
          <Sun className="w-3.5 h-3.5" />
          <span>الصباح ({MORNING_ADHKAR.length})</span>
        </button>

        <button
          onClick={() => setSelectedCategory('evening')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
            selectedCategory === 'evening'
              ? 'bg-[#042017] dark:bg-[#093526] text-emerald-800 dark:text-emerald-300 shadow-xs border border-emerald-400/40'
              : 'text-[#4d7d67] dark:text-[#7ba993] hover:text-[#0c2e20] dark:hover:text-emerald-200'
          }`}
        >
          <Moon className="w-3.5 h-3.5" />
          <span>المساء ({EVENING_ADHKAR.length})</span>
        </button>
      </div>

      {/* Dhikr Cards List */}
      <div className="space-y-2.5">
        {list.map((dhikr) => {
          const currentCount = getProgressFor(dhikr.id);
          const isDone = currentCount >= dhikr.count;
          const favorited = isFavorite(dhikr.id);

          const repetitionText = 
            dhikr.count === 1 ? 'مرة واحدة' :
            dhikr.count === 3 ? '٣ مرات' :
            dhikr.count === 4 ? '٤ مرات' :
            dhikr.count === 7 ? '٧ مرات' :
            dhikr.count === 10 ? '١٠ مرات' :
            dhikr.count === 100 ? '١٠٠ مرة' : `${dhikr.count} مرات`;

          return (
            <div
              key={dhikr.id}
              onClick={() => openDhikr(dhikr)}
              className="bg-[#ffffff] dark:bg-[#042017] border border-emerald-600/15 dark:border-emerald-800/60 rounded-2xl p-4 shadow-xs hover:border-emerald-500 dark:hover:border-emerald-600 hover:shadow-md transition-all cursor-pointer flex items-start justify-between gap-3 group"
            >
              {/* Order number / Category Icon */}
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-800 to-emerald-950 text-amber-300 border border-emerald-600/40 flex items-center justify-center font-bold text-xs shrink-0 font-cairo shadow-xs">
                {dhikr.orderNumber}
              </div>

              {/* Title and Excerpt */}
              <div className="flex-1 min-w-0 text-right">
                <div className="flex items-center justify-between gap-2 mb-1">
                  <h3 className="text-sm font-extrabold text-[#0c2e20] dark:text-[#e8f5ee] truncate font-cairo group-hover:text-emerald-800 dark:group-hover:text-amber-300 transition-colors">
                    {dhikr.title}
                  </h3>
                  
                  {/* Repetition Tag in Soft Light Green */}
                  <span className="shrink-0 px-2.5 py-0.5 rounded-full bg-emerald-700/15 dark:bg-emerald-400/15 border border-emerald-600/40 text-[#123828] dark:text-emerald-300 text-[10px] font-bold font-cairo shadow-2xs">
                    {repetitionText}
                  </span>
                </div>

                <p className="text-xs text-[#2b5945] dark:text-[#84b8a0] font-tajawal line-clamp-2 leading-relaxed">
                  {dhikr.text}
                </p>

                {/* Status and count info */}
                <div className="flex items-center gap-3 mt-2 text-[11px] text-[#4d7d67] dark:text-[#7ba993]">
                  <span className="text-emerald-800 dark:text-emerald-300 font-medium">
                    · {dhikr.categoryArabic}
                  </span>
                  {currentCount > 0 && (
                    <span className={isDone ? 'text-emerald-600 dark:text-emerald-400 font-bold' : 'text-amber-600 dark:text-amber-400 font-medium'}>
                      · المنجز: {currentCount} / {dhikr.count}
                    </span>
                  )}
                  {isDone && (
                    <span className="text-emerald-600 dark:text-emerald-400 flex items-center gap-0.5 font-bold">
                      <Check className="w-3 h-3" /> مكتمل
                    </span>
                  )}
                </div>
              </div>

              {/* Audio, Favorite & Navigation indicators */}
              <div className="flex flex-col items-center gap-1.5 shrink-0">
                {/* Audio Listen Button */}
                <button
                  type="button"
                  onClick={(e) => handleToggleAudio(dhikr, e)}
                  className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                    activeAudioDhikrId === dhikr.id
                      ? 'bg-amber-500 text-[#0c2e20] shadow-xs animate-pulse ring-1 ring-amber-300'
                      : 'text-[#62927c] hover:text-amber-500 dark:hover:text-amber-300'
                  }`}
                  title={activeAudioDhikrId === dhikr.id ? 'إيقاف الاستماع' : 'استمع لتلاوة الذكر'}
                  aria-label="الاستماع للذكر"
                >
                  {activeAudioDhikrId === dhikr.id ? (
                    <VolumeX className="w-4 h-4" />
                  ) : (
                    <Volume2 className="w-4 h-4" />
                  )}
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleFavorite(dhikr.id);
                  }}
                  className="p-1.5 rounded-lg text-[#62927c] hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors cursor-pointer"
                  title="المفضلة"
                  aria-label="المفضلة"
                >
                  <Heart className={`w-4 h-4 ${favorited ? 'fill-emerald-600 text-emerald-600' : ''}`} />
                </button>

                <ChevronLeft className="w-4 h-4 text-[#7ca994] dark:text-[#5e967e] group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors" />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
