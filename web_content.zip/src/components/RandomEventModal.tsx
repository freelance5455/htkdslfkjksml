import React from 'react';
import { RandomEventDef } from '../game/events';
import { GameState } from '../game/types';
import { Sparkles, AlertCircle, Briefcase, Heart, Skull, Building2 } from 'lucide-react';
import { playClickSound, playMoneySound } from '../utils/audio';

interface RandomEventModalProps {
  event: RandomEventDef;
  gameState: GameState;
  onSelectOption: (optionIndex: number) => void;
}

export const RandomEventModal: React.FC<RandomEventModalProps> = ({
  event,
  gameState,
  onSelectOption
}) => {
  const getIcon = () => {
    switch (event.category) {
      case 'family': return <Heart className="w-5 h-5 text-rose-400" />;
      case 'work': return <Briefcase className="w-5 h-5 text-emerald-400" />;
      case 'crime': return <Skull className="w-5 h-5 text-red-400" />;
      case 'crisis': return <AlertCircle className="w-5 h-5 text-amber-400" />;
      default: return <Building2 className="w-5 h-5 text-cyan-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-3xl p-6 shadow-2xl text-right animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
          <div className="p-2.5 rounded-2xl bg-slate-800 border border-slate-700">
            {getIcon()}
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100">{event.title}</h2>
            <span className="text-[10px] text-slate-400">حدث يومي عشوائي وموقف يحتاج قرارك</span>
          </div>
        </div>

        <p className="mt-4 text-xs text-slate-200 leading-relaxed bg-slate-950 p-4 rounded-2xl border border-slate-800">
          {event.text(gameState)}
        </p>

        <div className="mt-5 space-y-2.5">
          <span className="block text-xs font-semibold text-slate-300">ما هو قرارك وتصرفك؟</span>
          {event.options.map((opt, idx) => (
            <button
              key={idx}
              onClick={() => {
                playClickSound();
                onSelectOption(idx);
              }}
              className="w-full p-3.5 rounded-2xl bg-slate-950/80 hover:bg-slate-800/90 border border-slate-800 hover:border-amber-400/50 text-right transition group"
            >
              <div className="text-xs font-bold text-amber-300 group-hover:text-amber-200 flex items-center justify-between">
                <span>{opt.label}</span>
                <Sparkles className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition text-amber-400" />
              </div>
              {opt.description && (
                <div className="text-[11px] text-slate-400 mt-1">{opt.description}</div>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
