import React, { useState } from 'react';
import { LayoutTemplate, Sparkles, Check, ArrowRight, Eye, Play } from 'lucide-react';
import { VIDEO_TEMPLATES } from '../data/templates';
import { VideoProject, VideoTemplate } from '../types/project';

interface TemplatesViewProps {
  onApplyTemplate: (template: VideoTemplate) => void;
  lang: 'ar' | 'en';
}

export const TemplatesView: React.FC<TemplatesViewProps> = ({
  onApplyTemplate,
  lang
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [previewTemplate, setPreviewTemplate] = useState<VideoTemplate | null>(null);

  const categories = [
    { id: 'all', labelAr: 'جميع القوالب (16)', labelEn: 'All (16)' },
    { id: 'social', labelAr: 'منصات التواصل (Reels & Shorts)', labelEn: 'Social Media' },
    { id: 'creative', labelAr: 'إبداعي وسينمائي', labelEn: 'Creative & Cinema' },
    { id: 'news_sports', labelAr: 'أخبار ورياضة وجيمنج', labelEn: 'News & Sports' },
    { id: 'business', labelAr: 'أعمال وتسويق', labelEn: 'Business & Ads' },
  ];

  const filteredTemplates = selectedCategory === 'all'
    ? VIDEO_TEMPLATES
    : VIDEO_TEMPLATES.filter((t) => t.category === selectedCategory);

  return (
    <div className="max-w-6xl mx-auto p-4 sm:p-6 space-y-6 pb-28">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#111224] p-5 rounded-2xl border border-purple-900/40">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-purple-600/30 text-purple-300 border border-purple-500/40">
            <LayoutTemplate className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-white">
              {lang === 'ar' ? 'مكتبة القوالب الجاهزة' : 'Ready-made Templates'}
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              {lang === 'ar'
                ? '16 قالباً احترافياً بنقرة واحدة لتحويل وتنسيق مقاطعك لمنصات التواصل والأعمال'
                : '16 professional presets ready to transform your video in one click'}
            </p>
          </div>
        </div>

        <span className="text-xs px-3 py-1.5 rounded-full bg-purple-950 text-purple-300 border border-purple-800/40 font-semibold self-start sm:self-auto">
          {VIDEO_TEMPLATES.length} {lang === 'ar' ? 'قالب جاهز' : 'Templates'}
        </span>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {categories.map((c) => (
          <button
            key={c.id}
            onClick={() => setSelectedCategory(c.id)}
            className={`py-2 px-3.5 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
              selectedCategory === c.id
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md shadow-purple-900/30'
                : 'bg-[#111224] text-slate-400 hover:text-white border border-purple-900/30'
            }`}
          >
            {lang === 'ar' ? c.labelAr : c.labelEn}
          </button>
        ))}
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {filteredTemplates.map((tpl) => (
          <div
            key={tpl.id}
            className="group bg-[#111224] border border-purple-900/40 hover:border-purple-600/60 rounded-2xl overflow-hidden shadow-lg transition-all hover:-translate-y-1 flex flex-col justify-between"
          >
            {/* Visual Header Mockup */}
            <div className={`h-40 bg-gradient-to-br ${tpl.bgGradient} p-4 flex flex-col justify-between relative overflow-hidden border-b border-purple-900/30`}>
              <div className="flex items-center justify-between z-10">
                <span
                  style={{ backgroundColor: tpl.accentColor }}
                  className="text-[10px] uppercase font-black px-2 py-0.5 rounded-md text-white shadow"
                >
                  {tpl.badgeText}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-md bg-black/50 text-slate-200 backdrop-blur font-mono">
                  {tpl.aspectRatio}
                </span>
              </div>

              {/* Sample typography in mockup */}
              <div className="z-10 text-center my-auto">
                <div className="font-extrabold text-sm text-white drop-shadow-md">
                  {tpl.defaultTitle}
                </div>
              </div>

              {/* Blurred circle decoration */}
              <div
                style={{ backgroundColor: tpl.accentColor }}
                className="absolute -bottom-6 -right-6 w-24 h-24 rounded-full opacity-30 blur-xl"
              />
            </div>

            {/* Content */}
            <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
              <div>
                <h3 className="font-bold text-sm text-white group-hover:text-purple-300 transition">
                  {lang === 'ar' ? tpl.nameAr : tpl.nameEn}
                </h3>
                <p className="text-xs text-slate-400 line-clamp-2 mt-1 leading-relaxed">
                  {lang === 'ar' ? tpl.descriptionAr : tpl.descriptionEn}
                </p>

                {/* Features List */}
                <div className="space-y-1 mt-3">
                  {tpl.features.slice(0, 2).map((feat, i) => (
                    <div key={i} className="flex items-center gap-1.5 text-[11px] text-purple-300">
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-2 border-t border-purple-900/30">
                <button
                  onClick={() => setPreviewTemplate(tpl)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition cursor-pointer"
                  title={lang === 'ar' ? 'معاينة القالب' : 'Preview'}
                >
                  <Eye className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onApplyTemplate(tpl)}
                  className="flex-1 py-2 px-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow transition cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{lang === 'ar' ? 'استخدام القالب' : 'Use Template'}</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Preview Dialog Modal */}
      {previewTemplate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-lg bg-[#111224] border border-purple-800/40 rounded-2xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-purple-900/30 pb-3">
              <div className="flex items-center gap-2">
                <span
                  style={{ backgroundColor: previewTemplate.accentColor }}
                  className="px-2 py-0.5 rounded text-[10px] font-bold text-white"
                >
                  {previewTemplate.badgeText}
                </span>
                <h3 className="font-bold text-base text-white">
                  {lang === 'ar' ? previewTemplate.nameAr : previewTemplate.nameEn}
                </h3>
              </div>
              <button
                onClick={() => setPreviewTemplate(null)}
                className="text-slate-400 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className={`p-6 rounded-xl bg-gradient-to-br ${previewTemplate.bgGradient} text-center space-y-3`}>
              <div className="text-xl font-black text-white">{previewTemplate.defaultTitle}</div>
              <div className="text-xs text-purple-200">
                {lang === 'ar' ? previewTemplate.descriptionAr : previewTemplate.descriptionEn}
              </div>
            </div>

            <div className="space-y-2 text-xs text-slate-300">
              <span className="font-bold text-white block">{lang === 'ar' ? 'الميزات والخصائص:' : 'Features:'}</span>
              <ul className="space-y-1 list-disc list-inside text-slate-400">
                {previewTemplate.features.map((f, i) => (
                  <li key={i}>{f}</li>
                ))}
              </ul>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-purple-900/30">
              <button
                onClick={() => setPreviewTemplate(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold cursor-pointer"
              >
                {lang === 'ar' ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                onClick={() => {
                  onApplyTemplate(previewTemplate);
                  setPreviewTemplate(null);
                }}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>{lang === 'ar' ? 'تطبيق على الفيديو' : 'Apply to Video'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
