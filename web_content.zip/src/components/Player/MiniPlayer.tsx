import React from 'react';
import { useMusic } from '../../context/MusicContext';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Heart,
  Maximize2,
  Volume1,
  Volume2,
  VolumeX,
  Plus,
  Minus,
  Repeat1,
  Repeat,
  Radio,
  Sparkles,
  Power
} from 'lucide-react';

export const MiniPlayer: React.FC = () => {
  const {
    currentSong,
    isPlaying,
    currentTime,
    duration,
    togglePlayPause,
    stopMusic,
    prevTrack,
    nextTrack,
    likedSongIds,
    toggleLike,
    volume,
    volumeUp,
    volumeDown,
    setVolume,
    playbackMode,
    cyclePlaybackMode,
    isSameTypeMode,
    toggleSameTypeMode,
    vibeMode,
    setVibeMode,
    setIsFullScreenPlayerOpen,
  } = useMusic();

  if (!currentSong) return null;

  const isLiked = likedSongIds.has(currentSong.id);
  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;
  const volumePercent = Math.round(volume * 100);

  return (
    <div
      onClick={() => setIsFullScreenPlayerOpen(true)}
      className="fixed bottom-14 md:bottom-0 left-0 right-0 z-30 bg-[#1c1c1c]/95 backdrop-blur-md border-t border-white/10 select-none cursor-pointer transition-all hover:bg-[#252525]/95 shadow-2xl"
    >
      {/* Top Thin Progress Line */}
      <div className="w-full h-1 bg-white/10 relative overflow-hidden">
        <div
          className="h-full bg-red-600 transition-all duration-200"
          style={{ width: `${Math.min(100, Math.max(0, progressPercent))}%` }}
        />
      </div>

      <div className="flex items-center justify-between px-3 sm:px-6 py-2 h-14">
        {/* Left: Thumbnail & Title */}
        <div className="flex items-center gap-3 min-w-0 flex-1">
          <div className="relative w-10 h-10 rounded-md overflow-hidden bg-neutral-800 shrink-0 shadow">
            <img
              src={currentSong.coverUrl}
              alt={currentSong.title}
              className={`w-full h-full object-cover ${isPlaying ? 'scale-105' : 'scale-100'} transition-transform duration-700`}
            />
            {isPlaying && (
              <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
              </div>
            )}
          </div>

          <div className="min-w-0 pr-2">
            <div className="flex items-center gap-2">
              <p className="text-sm font-semibold text-white truncate leading-tight">
                {currentSong.title}
              </p>
              {isPlaying && (
                <div className="flex items-end gap-0.5 h-3 shrink-0" title="Audio is playing">
                  <span className="w-0.5 h-3 bg-red-500 rounded-full animate-bounce" style={{ animationDuration: '0.6s' }} />
                  <span className="w-0.5 h-2 bg-red-500 rounded-full animate-bounce" style={{ animationDuration: '0.4s' }} />
                  <span className="w-0.5 h-3.5 bg-red-500 rounded-full animate-bounce" style={{ animationDuration: '0.8s' }} />
                </div>
              )}
            </div>
            <div className="flex items-center gap-2 text-xs text-neutral-400 truncate mt-0.5">
              <span>{currentSong.artist}</span>
              <span>•</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-white/10 text-neutral-300">
                {currentSong.genre}
              </span>
            </div>
          </div>
        </div>

        {/* Center/Right: Sound Up/Down, Prev, Play/Pause, Next, Loop One, Like */}
        <div
          className="flex items-center gap-1 sm:gap-2 shrink-0"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Sound Down & Sound Up Buttons */}
          <div className="hidden sm:flex items-center bg-black/40 rounded-full border border-white/10 px-1 py-0.5">
            <button
              onClick={volumeDown}
              className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-white/10 transition cursor-pointer"
              title="Sound Down (-10%)"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>

            <span className="text-[10px] font-semibold text-neutral-300 px-1.5 w-9 text-center">
              {volumePercent}%
            </span>

            <button
              onClick={volumeUp}
              className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-white/10 transition cursor-pointer"
              title="Sound Up (+10%)"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Same Type / Repeat One Button */}
          <button
            onClick={cyclePlaybackMode}
            className={`p-1.5 rounded-full transition cursor-pointer ${
              playbackMode === 'repeat-one'
                ? 'bg-red-600/30 text-red-400 border border-red-500/40'
                : 'text-neutral-400 hover:text-white'
            }`}
            title={
              playbackMode === 'repeat-one'
                ? 'Looping this single song (Repeat 1 ON)'
                : `Playback Mode: ${playbackMode}`
            }
          >
            {playbackMode === 'repeat-one' ? (
              <Repeat1 className="w-4 h-4 text-red-500" />
            ) : (
              <Repeat className="w-4 h-4" />
            )}
          </button>

          {/* YouTube Music Vibe / Same Wave Tuner Button */}
          <button
            onClick={() => {
              if (!isSameTypeMode) {
                toggleSameTypeMode();
              } else {
                // Cycle vibe mode
                const modes: ('same-wave' | 'discover-different' | 'chill' | 'upbeat' | 'same-artist')[] = [
                  'same-wave',
                  'discover-different',
                  'chill',
                  'upbeat',
                  'same-artist'
                ];
                const curIdx = modes.indexOf(vibeMode as any);
                const nextMode = modes[(curIdx + 1) % modes.length];
                setVibeMode(nextMode);
              }
            }}
            className={`hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wide transition cursor-pointer active:scale-95 ${
              isSameTypeMode
                ? 'bg-red-950/60 text-red-300 border border-red-500/50 shadow-sm'
                : 'bg-white/5 text-neutral-400 hover:text-white'
            }`}
            title={`YouTube Music Vibe: ${vibeMode}. Click to switch wave tuner! (Same wave, different songs)`}
          >
            <Radio className={`w-3 h-3 ${isSameTypeMode ? 'text-red-500 animate-pulse' : ''}`} />
            <span>
              {vibeMode === 'same-wave'
                ? '🌊 Same Wave (Different)'
                : vibeMode === 'discover-different'
                ? '✨ Fresh Artists'
                : vibeMode === 'chill'
                ? '🌙 Chill Wave'
                : vibeMode === 'upbeat'
                ? '⚡ Fast Wave'
                : '🎤 Same Artist'}
            </span>
          </button>

          {/* Like */}
          <button
            onClick={() => toggleLike(currentSong.id)}
            className="p-2 text-neutral-400 hover:text-white transition cursor-pointer"
            title={isLiked ? 'Unlike' : 'Like'}
          >
            <Heart
              className={`w-5 h-5 ${isLiked ? 'fill-red-600 text-red-600' : ''}`}
            />
          </button>

          {/* Previous Song Button */}
          <button
            onClick={prevTrack}
            className="p-2 text-neutral-400 hover:text-white transition cursor-pointer active:scale-95"
            title="Previous Song"
          >
            <SkipBack className="w-5 h-5 fill-current" />
          </button>

          {/* Play/Pause */}
          <button
            onClick={togglePlayPause}
            className="w-10 h-10 rounded-full bg-white text-black flex items-center justify-center hover:scale-105 active:scale-95 transition cursor-pointer shadow-md shadow-black/40"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? (
              <Pause className="w-5 h-5 fill-black" />
            ) : (
              <Play className="w-5 h-5 fill-black ml-0.5" />
            )}
          </button>

          {/* Next Song Button */}
          <button
            onClick={nextTrack}
            className="p-2 text-neutral-400 hover:text-white transition cursor-pointer active:scale-95"
            title="Next Song"
          >
            <SkipForward className="w-5 h-5 fill-current" />
          </button>

          {/* OFF Music Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              stopMusic();
            }}
            className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-red-950/70 hover:bg-red-600 text-red-300 hover:text-white border border-red-500/50 text-xs font-bold transition cursor-pointer shadow-sm active:scale-95 ml-1"
            title="Turn Off Music (Stop Playing)"
          >
            <Power className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Off Music</span>
          </button>

          {/* Expand Full Player */}
          <button
            onClick={() => setIsFullScreenPlayerOpen(true)}
            className="hidden sm:block p-2 text-neutral-400 hover:text-white transition cursor-pointer"
            title="Expand Full Screen"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
