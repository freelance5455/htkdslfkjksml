import React, { useState } from 'react';
import { useMusic } from '../../context/MusicContext';
import { formatTime } from '../../utils/formatTime';
import { VisualizerView } from './VisualizerView';
import { LyricsView } from './LyricsView';
import { EqualizerView } from './EqualizerView';
import {
  ChevronDown,
  MoreVertical,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Shuffle,
  Repeat,
  Repeat1,
  Heart,
  Download,
  Share2,
  Volume2,
  VolumeX,
  Clock,
  ListMusic,
  Mic2,
  Sliders,
  Sparkles,
  CheckCircle2,
  Tv,
  Music,
  Volume1,
  ExternalLink,
  Plus,
  Minus,
  Radio,
  Power
} from 'lucide-react';

export const FullScreenPlayer: React.FC = () => {
  const {
    currentSong,
    isPlaying,
    currentTime,
    duration,
    togglePlayPause,
    stopMusic,
    seek,
    nextTrack,
    prevTrack,
    playbackMode,
    cyclePlaybackMode,
    setPlaybackModeDirect,
    isSameTypeMode,
    toggleSameTypeMode,
    vibeMode,
    setVibeMode,
    isShuffle,
    toggleShuffle,
    volume,
    setVolume,
    volumeUp,
    volumeDown,
    likedSongIds,
    toggleLike,
    downloadedSongIds,
    toggleDownload,
    queue,
    queueIndex,
    playSong,
    isFullScreenPlayerOpen,
    setIsFullScreenPlayerOpen,
    playerTab,
    setPlayerTab,
    playerMode,
    setPlayerMode,
    sleepTimerMinutes,
    sleepTimerRemaining,
    setSleepTimer,
  } = useMusic();

  const [showOptions, setShowOptions] = useState(false);
  const [showVisualizerOverlay, setShowVisualizerOverlay] = useState(false);
  const [showSleepTimerModal, setShowSleepTimerModal] = useState(false);

  if (!isFullScreenPlayerOpen || !currentSong) return null;

  const isLiked = likedSongIds.has(currentSong.id);
  const isDownloaded = downloadedSongIds.has(currentSong.id);

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: currentSong.title,
          text: `Listening to ${currentSong.title} by ${currentSong.artist} on YouTube Music!`,
          url: currentSong.youtubeId
            ? `https://www.youtube.com/watch?v=${currentSong.youtubeId}`
            : window.location.href,
        });
      } catch {
        // Share cancelled
      }
    } else {
      const url = currentSong.youtubeId
        ? `https://www.youtube.com/watch?v=${currentSong.youtubeId}`
        : window.location.href;
      navigator.clipboard.writeText(url);
      alert('Track link copied to clipboard!');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#030303] text-white flex flex-col overflow-hidden select-none animate-in fade-in duration-200">
      {/* Dynamic blurred ambient background from album artwork */}
      <div
        className="absolute inset-0 opacity-25 filter blur-3xl pointer-events-none scale-125"
        style={{
          backgroundImage: `url(${currentSong.coverUrl})`,
          backgroundPosition: 'center',
          backgroundSize: 'cover',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-[#030303]/90 to-[#030303] pointer-events-none" />

      {/* Top Header: Dismiss, Song/Video Toggle, Options */}
      <div className="relative z-10 flex items-center justify-between px-4 py-3 border-b border-white/5">
        <button
          onClick={() => setIsFullScreenPlayerOpen(false)}
          className="p-2 rounded-full hover:bg-white/10 text-neutral-300 hover:text-white transition cursor-pointer"
          title="Minimize player"
        >
          <ChevronDown className="w-6 h-6" />
        </button>

        {/* YouTube Music Signature: Song | Video Switcher */}
        <div className="flex items-center p-1 rounded-full bg-[#181818] border border-white/10 shadow-inner">
          <button
            onClick={() => setPlayerMode('song')}
            className={`flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-bold transition cursor-pointer ${
              playerMode === 'song'
                ? 'bg-white text-black shadow-md'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Music className="w-3.5 h-3.5" />
            <span>Song</span>
          </button>
          <button
            onClick={() => setPlayerMode('video')}
            className={`flex items-center gap-1.5 px-3.5 py-1 rounded-full text-xs font-bold transition cursor-pointer ${
              playerMode === 'video'
                ? 'bg-red-600 text-white shadow-md shadow-red-600/30'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Tv className="w-3.5 h-3.5" />
            <span>Video</span>
          </button>
        </div>

        {/* Right header actions: Off Music & Options Menu */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              stopMusic();
              setIsFullScreenPlayerOpen(false);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-red-950/70 hover:bg-red-600 text-red-300 hover:text-white border border-red-500/50 text-xs font-bold transition cursor-pointer shadow-sm active:scale-95"
            title="Turn Off Music"
          >
            <Power className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Off Music</span>
          </button>

          {/* Options Menu Button */}
          <div className="relative">
            <button
              onClick={() => setShowOptions(!showOptions)}
              className="p-2 rounded-full hover:bg-white/10 text-neutral-300 hover:text-white transition cursor-pointer"
              title="Track options"
            >
              <MoreVertical className="w-5 h-5" />
            </button>

          {showOptions && (
            <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-[#1e1e1e] border border-white/10 shadow-2xl py-2 z-50 text-sm">
              <button
                onClick={() => {
                  setShowSleepTimerModal(true);
                  setShowOptions(false);
                }}
                className="w-full flex items-center justify-between px-4 py-2 hover:bg-white/10 text-left transition"
              >
                <div className="flex items-center gap-2.5">
                  <Clock className="w-4 h-4 text-amber-400" />
                  <span>Sleep Timer</span>
                </div>
                {sleepTimerRemaining && (
                  <span className="text-xs text-amber-400 font-semibold">
                    {formatTime(sleepTimerRemaining)}
                  </span>
                )}
              </button>

              <button
                onClick={() => {
                  setShowVisualizerOverlay(!showVisualizerOverlay);
                  setShowOptions(false);
                }}
                className="w-full flex items-center gap-2.5 px-4 py-2 hover:bg-white/10 text-left transition"
              >
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span>{showVisualizerOverlay ? 'Show Artwork' : 'Live Spectrum Audio'}</span>
              </button>

              <button
                onClick={() => {
                  toggleDownload(currentSong.id);
                  setShowOptions(false);
                }}
                className="w-full flex items-center gap-2.5 px-4 py-2 hover:bg-white/10 text-left transition"
              >
                <Download className="w-4 h-4 text-emerald-400" />
                <span>{isDownloaded ? 'Remove Download' : 'Download for Offline'}</span>
              </button>

              {currentSong.youtubeId && (
                <a
                  href={`https://www.youtube.com/watch?v=${currentSong.youtubeId}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center gap-2.5 px-4 py-2 hover:bg-white/10 text-left transition text-red-400"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Open in YouTube App</span>
                </a>
              )}

              <button
                onClick={() => {
                  handleShare();
                  setShowOptions(false);
                }}
                className="w-full flex items-center gap-2.5 px-4 py-2 hover:bg-white/10 text-left transition"
              >
                <Share2 className="w-4 h-4 text-blue-400" />
                <span>Share Song</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>

      {/* Sleep Timer Dialog */}
      {showSleepTimerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="w-full max-w-xs rounded-2xl bg-[#1e1e1e] border border-white/10 p-5 shadow-2xl text-white">
            <h3 className="font-bold text-base mb-1">Set Sleep Timer</h3>
            <p className="text-xs text-neutral-400 mb-4">
              Music stops automatically when timer expires.
            </p>
            <div className="space-y-1">
              {[15, 30, 45, 60].map((mins) => (
                <button
                  key={mins}
                  onClick={() => {
                    setSleepTimer(mins);
                    setShowSleepTimerModal(false);
                  }}
                  className={`w-full py-2.5 px-3 rounded-xl text-sm font-medium text-left transition cursor-pointer ${
                    sleepTimerMinutes === mins
                      ? 'bg-red-600 text-white'
                      : 'hover:bg-white/10 text-neutral-300'
                  }`}
                >
                  {mins} minutes
                </button>
              ))}
              {sleepTimerMinutes !== null && (
                <button
                  onClick={() => {
                    setSleepTimer(null);
                    setShowSleepTimerModal(false);
                  }}
                  className="w-full py-2.5 px-3 rounded-xl text-sm font-medium text-left text-red-400 hover:bg-white/10 transition cursor-pointer"
                >
                  Turn off timer
                </button>
              )}
            </div>
            <button
              onClick={() => setShowSleepTimerModal(false)}
              className="mt-4 w-full py-2 rounded-xl bg-white/10 text-sm font-semibold hover:bg-white/20 transition"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="relative z-10 flex-1 overflow-y-auto flex flex-col items-center justify-between px-4 sm:px-8 py-2 max-w-xl mx-auto w-full">
        {/* Dynamic Display: Lyrics | Equalizer | Video | Album Cover */}
        {playerTab === 'lyrics' ? (
          <LyricsView />
        ) : playerTab === 'equalizer' ? (
          <EqualizerView />
        ) : playerMode === 'video' && currentSong.youtubeId ? (
          /* Official YouTube Video Player Container */
          <div className="w-full flex flex-col items-center justify-center my-auto py-2">
            <div className="w-full aspect-video rounded-2xl overflow-hidden shadow-2xl shadow-black/80 border border-white/10 bg-black">
              <iframe
                src={`https://www.youtube.com/embed/${currentSong.youtubeId}?autoplay=1&enablejsapi=1&playsinline=1&rel=0`}
                title={currentSong.title}
                className="w-full h-full"
                allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
                allowFullScreen
              />
            </div>
            <p className="text-[11px] text-neutral-400 mt-2 flex items-center gap-1.5">
              <Tv className="w-3.5 h-3.5 text-red-500" />
              <span>Playing Official Video • YouTube Music</span>
            </p>
          </div>
        ) : showVisualizerOverlay ? (
          /* Spectrum Audio Waveform Overlay */
          <div className="w-full flex flex-col items-center justify-center my-auto py-6">
            <div className="relative w-64 h-64 sm:w-72 sm:h-72 rounded-2xl overflow-hidden shadow-2xl border border-white/10 flex flex-col items-center justify-center bg-black/60 backdrop-blur-md p-4">
              <VisualizerView isPlaying={isPlaying} />
              <p className="text-xs font-semibold text-neutral-400 mt-4 tracking-wider uppercase">
                Real-Time Frequency Waveform
              </p>
            </div>
          </div>
        ) : (
          /* High-Res Album Cover with Ambient Shadow */
          <div className="relative w-full flex items-center justify-center my-auto py-2">
            <div className="relative w-64 h-64 sm:w-80 sm:h-80 rounded-2xl overflow-hidden shadow-2xl shadow-black/80 border border-white/10 group">
              <img
                src={currentSong.coverUrl}
                alt={currentSong.title}
                className="w-full h-full object-cover"
              />
              <button
                onClick={() => setShowVisualizerOverlay(!showVisualizerOverlay)}
                className="absolute bottom-3 right-3 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-[11px] font-semibold text-white/90 hover:text-white flex items-center gap-1.5 transition"
              >
                <Sparkles className="w-3.5 h-3.5 text-red-500" />
                <span>Visualizer</span>
              </button>
            </div>
          </div>
        )}

        {/* Track Info & Like / Download Row */}
        <div className="w-full flex items-center justify-between mt-2 pt-2">
          <div className="min-w-0 pr-3">
            <h2 className="text-xl sm:text-2xl font-bold text-white truncate leading-tight">
              {currentSong.title}
            </h2>
            <p className="text-sm font-medium text-neutral-400 truncate mt-1">
              {currentSong.artist} • <span className="text-xs text-neutral-500">{currentSong.album}</span>
            </p>
          </div>

          <div className="flex items-center gap-1">
            {/* Download */}
            <button
              onClick={() => toggleDownload(currentSong.id)}
              className="p-2.5 rounded-full hover:bg-white/10 text-neutral-400 hover:text-white transition cursor-pointer"
              title={isDownloaded ? 'Downloaded Offline' : 'Download for Offline'}
            >
              {isDownloaded ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              ) : (
                <Download className="w-5 h-5" />
              )}
            </button>

            {/* Like */}
            <button
              onClick={() => toggleLike(currentSong.id)}
              className="p-2.5 rounded-full hover:bg-white/10 transition cursor-pointer"
              title={isLiked ? 'Liked' : 'Like'}
            >
              <Heart
                className={`w-6 h-6 ${isLiked ? 'fill-red-600 text-red-600' : 'text-neutral-400 hover:text-white'}`}
              />
            </button>
          </div>
        </div>

        {/* Progress Scrubber */}
        <div className="w-full mt-4">
          <input
            type="range"
            min="0"
            max={duration || 100}
            step="0.5"
            value={currentTime}
            onChange={(e) => seek(parseFloat(e.target.value))}
            className="w-full h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer accent-red-600 hover:h-2 transition-all"
          />
          <div className="flex items-center justify-between text-xs font-semibold text-neutral-400 mt-1.5">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* Playback Controls (Shuffle, Prev, Play/Pause, Next, Repeat) */}
        <div className="w-full flex items-center justify-between mt-3 px-2 sm:px-6">
          {/* Shuffle */}
          <button
            onClick={toggleShuffle}
            className={`p-3 rounded-full transition cursor-pointer ${
              isShuffle ? 'text-red-500' : 'text-neutral-400 hover:text-white'
            }`}
            title={isShuffle ? 'Shuffle On' : 'Shuffle Off'}
          >
            <Shuffle className="w-5 h-5" />
          </button>

          {/* Previous */}
          <button
            onClick={prevTrack}
            className="p-3 text-neutral-300 hover:text-white transition cursor-pointer active:scale-95"
            title="Previous track"
          >
            <SkipBack className="w-7 h-7 fill-current" />
          </button>

          {/* Play/Pause */}
          <button
            onClick={togglePlayPause}
            className="w-16 h-16 rounded-full bg-white text-black flex items-center justify-center hover:scale-105 active:scale-95 transition cursor-pointer shadow-xl shadow-white/10"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? (
              <Pause className="w-8 h-8 fill-black" />
            ) : (
              <Play className="w-8 h-8 fill-black ml-1" />
            )}
          </button>

          {/* Next */}
          <button
            onClick={nextTrack}
            className="p-3 text-neutral-300 hover:text-white transition cursor-pointer active:scale-95"
            title="Next track"
          >
            <SkipForward className="w-7 h-7 fill-current" />
          </button>

          {/* Repeat */}
          <button
            onClick={cyclePlaybackMode}
            className={`p-3 rounded-full transition cursor-pointer ${
              playbackMode !== 'repeat-off' ? 'text-red-500' : 'text-neutral-400 hover:text-white'
            }`}
            title={`Repeat mode: ${playbackMode}`}
          >
            {playbackMode === 'repeat-one' ? (
              <Repeat1 className="w-5 h-5" />
            ) : (
              <Repeat className="w-5 h-5" />
            )}
          </button>
        </div>

        {/* Volume Controls Row with Sound Down & Sound Up Buttons */}
        <div className="w-full flex items-center justify-center gap-2.5 mt-3 px-4 max-w-sm">
          {/* Mute button */}
          <button
            onClick={() => setVolume(volume === 0 ? 0.9 : 0)}
            className="p-1.5 rounded-full hover:bg-white/10 text-neutral-400 hover:text-white transition cursor-pointer"
            title={volume === 0 ? 'Unmute' : 'Mute'}
          >
            {volume === 0 ? <VolumeX className="w-4 h-4 text-red-500" /> : <Volume2 className="w-4 h-4" />}
          </button>

          {/* Sound Down Button */}
          <button
            onClick={volumeDown}
            className="p-1.5 rounded-full bg-white/5 hover:bg-white/15 text-neutral-300 hover:text-white transition cursor-pointer"
            title="Sound Down (-10%)"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>

          <input
            type="range"
            min="0"
            max="1"
            step="0.05"
            value={volume}
            onChange={(e) => setVolume(parseFloat(e.target.value))}
            className="w-full h-1 bg-white/20 rounded-full appearance-none cursor-pointer accent-red-600"
          />

          {/* Sound Up Button */}
          <button
            onClick={volumeUp}
            className="p-1.5 rounded-full bg-white/5 hover:bg-white/15 text-neutral-300 hover:text-white transition cursor-pointer"
            title="Sound Up (+10%)"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>

          <span className="text-[11px] text-neutral-400 w-8 text-right font-medium">
            {Math.round(volume * 100)}%
          </span>
        </div>

        {/* Quick Vibe / Song Type Strip */}
        <div className="flex items-center gap-2 mt-2 px-2">
          {/* Loop This Exact Song Button */}
          <button
            onClick={() => {
              if (playbackMode === 'repeat-one') {
                setPlaybackModeDirect('repeat-all');
              } else {
                setPlaybackModeDirect('repeat-one');
              }
            }}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold transition cursor-pointer ${
              playbackMode === 'repeat-one'
                ? 'bg-red-600 text-white shadow-md shadow-red-600/30'
                : 'bg-white/5 text-neutral-400 hover:text-white'
            }`}
            title="Loop this single song repeatedly"
          >
            <Repeat1 className="w-3.5 h-3.5" />
            <span>{playbackMode === 'repeat-one' ? 'Looping This Song' : 'Loop Song'}</span>
          </button>

          {/* Continuous Same-Wave / Vibe Radio Mode */}
          <button
            onClick={() => {
              if (!isSameTypeMode) {
                toggleSameTypeMode();
              } else {
                const modes: ('same-wave' | 'discover-different' | 'chill' | 'upbeat' | 'same-artist')[] = [
                  'same-wave',
                  'discover-different',
                  'chill',
                  'upbeat',
                  'same-artist'
                ];
                const curIdx = modes.indexOf(vibeMode as any);
                setVibeMode(modes[(curIdx + 1) % modes.length]);
              }
            }}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold transition cursor-pointer active:scale-95 ${
              isSameTypeMode
                ? 'bg-red-950/60 text-red-300 border border-red-500/50 shadow'
                : 'bg-white/5 text-neutral-400 hover:text-white'
            }`}
            title={`YouTube Music Vibe: ${vibeMode}. Click to switch wave tuner!`}
          >
            <Radio className={`w-3.5 h-3.5 ${isSameTypeMode ? 'text-red-500 animate-pulse' : ''}`} />
            <span>
              {vibeMode === 'same-wave'
                ? `Same Wave: ${currentSong.genre} (Diverse)`
                : vibeMode === 'discover-different'
                ? 'Discover: Different Artists'
                : vibeMode === 'chill'
                ? 'Wave: Chill / Acoustic'
                : vibeMode === 'upbeat'
                ? 'Wave: High Energy'
                : `Artist: ${currentSong.artist.split(',')[0]}`}
            </span>
          </button>

          {/* Turn Off Music Button */}
          <button
            onClick={() => {
              stopMusic();
              setIsFullScreenPlayerOpen(false);
            }}
            className="flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold bg-red-950/70 hover:bg-red-600 text-red-300 hover:text-white border border-red-500/50 transition cursor-pointer active:scale-95 shadow"
            title="Turn Off Music"
          >
            <Power className="w-3.5 h-3.5" />
            <span>Off Music</span>
          </button>
        </div>

        {/* Bottom Tab Bar (UP NEXT, LYRICS, EQUALIZER) */}
        <div className="w-full flex items-center justify-around border-t border-white/10 mt-4 pt-2 pb-safe">
          <button
            onClick={() => setPlayerTab('upNext')}
            className={`flex items-center gap-1.5 py-1.5 px-3 rounded-full text-xs font-bold uppercase tracking-wider transition cursor-pointer ${
              playerTab === 'upNext'
                ? 'bg-white/15 text-white'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <ListMusic className="w-3.5 h-3.5" />
            <span>Up Next ({queue.length})</span>
          </button>

          <button
            onClick={() => setPlayerTab('lyrics')}
            className={`flex items-center gap-1.5 py-1.5 px-3 rounded-full text-xs font-bold uppercase tracking-wider transition cursor-pointer ${
              playerTab === 'lyrics'
                ? 'bg-red-600/30 text-red-400 border border-red-500/40'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Mic2 className="w-3.5 h-3.5" />
            <span>Lyrics</span>
          </button>

          <button
            onClick={() => setPlayerTab('equalizer')}
            className={`flex items-center gap-1.5 py-1.5 px-3 rounded-full text-xs font-bold uppercase tracking-wider transition cursor-pointer ${
              playerTab === 'equalizer'
                ? 'bg-white/15 text-white'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Equalizer</span>
          </button>
        </div>
      </div>

      {/* Up Next Drawer / View with YouTube Music Vibe Tuner */}
      {playerTab === 'upNext' && (
        <div className="relative z-10 w-full max-w-xl mx-auto px-4 pb-6 overflow-y-auto max-h-56 border-t border-white/5 bg-black/60 backdrop-blur-md rounded-t-3xl">
          {/* Header */}
          <div className="flex items-center justify-between py-2.5 border-b border-white/5">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-400">
                Queue • {queue.length} Tracks
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-red-950/60 text-red-400 border border-red-500/30 font-bold">
                Same Wave, Different Songs
              </span>
            </div>
            <span className="text-xs text-red-500 font-semibold flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
              Autoplay Active
            </span>
          </div>

          {/* YouTube Music Vibe Tuner Pills */}
          <div className="flex items-center gap-1.5 py-2.5 overflow-x-auto scrollbar-none">
            {[
              { id: 'same-wave', label: '🌊 Same Wave (Auto)', desc: 'Same vibe, different artists & songs' },
              { id: 'discover-different', label: '✨ Different & Fresh', desc: 'Different artists in this wave' },
              { id: 'familiar', label: '❤️ Familiar Hits', desc: 'Popular hits of this vibe' },
              { id: 'upbeat', label: '⚡ Energize', desc: 'High energy & faster BPM' },
              { id: 'chill', label: '🌙 Chill Acoustic', desc: 'Soft & relaxing acoustic' },
              { id: 'same-artist', label: '🎤 Same Artist Only', desc: 'Strictly songs by this artist' },
            ].map((tuner) => (
              <button
                key={tuner.id}
                onClick={() => setVibeMode(tuner.id as any)}
                className={`px-3 py-1 rounded-full text-xs font-semibold shrink-0 transition cursor-pointer active:scale-95 ${
                  vibeMode === tuner.id
                    ? 'bg-white text-black shadow-md font-bold'
                    : 'bg-white/10 hover:bg-white/20 text-neutral-300'
                }`}
                title={tuner.desc}
              >
                {tuner.label}
              </button>
            ))}
          </div>

          <div className="space-y-1.5">
            {queue.map((song, idx) => {
              const isCurrent = idx === queueIndex;
              return (
                <div
                  key={`${song.id}-${idx}`}
                  onClick={() => playSong(song)}
                  className={`flex items-center justify-between p-2 rounded-xl transition cursor-pointer ${
                    isCurrent
                      ? 'bg-white/10 text-white font-semibold border-l-2 border-red-600'
                      : 'hover:bg-white/5 text-neutral-300'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={song.coverUrl}
                      alt={song.title}
                      className="w-9 h-9 rounded-md object-cover"
                    />
                    <div className="min-w-0">
                      <p className="text-sm truncate leading-tight">{song.title}</p>
                      <p className="text-xs text-neutral-400 truncate">{song.artist}</p>
                    </div>
                  </div>
                  <span className="text-xs text-neutral-500 shrink-0 ml-2">
                    {formatTime(song.duration)}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
