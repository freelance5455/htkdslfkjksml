import React, { useEffect, useRef } from 'react';
import { useMusic } from '../../context/MusicContext';
import { Mic2, Music } from 'lucide-react';

export const LyricsView: React.FC = () => {
  const { currentSong, currentTime, seek } = useMusic();
  const activeLineRef = useRef<HTMLDivElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const lyrics = currentSong?.lyrics || [];

  // Determine current active lyric line index
  let activeIndex = -1;
  for (let i = 0; i < lyrics.length; i++) {
    if (currentTime >= lyrics[i].time) {
      activeIndex = i;
    } else {
      break;
    }
  }

  // Smooth scroll to active line
  useEffect(() => {
    if (activeLineRef.current && containerRef.current) {
      activeLineRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
      });
    }
  }, [activeIndex]);

  if (!currentSong || lyrics.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-72 text-neutral-400 text-center p-6">
        <Mic2 className="w-10 h-10 mb-3 text-neutral-600" />
        <p className="font-semibold text-white">No lyrics available</p>
        <p className="text-xs text-neutral-500 mt-1">
          Lyrics for &ldquo;{currentSong?.title}&rdquo; aren&apos;t synchronized yet.
        </p>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="h-[360px] sm:h-[420px] overflow-y-auto px-4 py-8 space-y-6 text-center select-none"
    >
      <div className="flex items-center justify-center gap-2 text-xs font-semibold text-red-500 tracking-wider uppercase mb-4">
        <Mic2 className="w-3.5 h-3.5" />
        <span>Synchronized Karaoke Lyrics</span>
      </div>

      {lyrics.map((line, idx) => {
        const isActive = idx === activeIndex;
        const isPast = idx < activeIndex;

        return (
          <div
            key={idx}
            ref={isActive ? activeLineRef : null}
            onClick={() => seek(line.time)}
            className={`transition-all duration-300 cursor-pointer rounded-xl py-2 px-3 ${
              isActive
                ? 'text-white text-xl sm:text-2xl font-extrabold scale-105 bg-white/5 shadow-lg shadow-black/40'
                : isPast
                ? 'text-neutral-400 text-base sm:text-lg font-medium opacity-60 hover:opacity-90'
                : 'text-neutral-500 text-base sm:text-lg font-normal opacity-40 hover:opacity-80'
            }`}
          >
            <p className="leading-snug">{line.text}</p>
          </div>
        );
      })}

      <div className="pt-10 pb-6 text-xs text-neutral-500 flex items-center justify-center gap-1.5">
        <Music className="w-3.5 h-3.5" />
        <span>Lyrics provided for &quot;{currentSong.title}&quot; • Tap any line to seek</span>
      </div>
    </div>
  );
};
