import React, { useEffect, useRef } from 'react';
import { audioEngine } from '../../services/audioEngine';

interface VisualizerViewProps {
  isPlaying: boolean;
  accentColor?: string;
}

export const VisualizerView: React.FC<VisualizerViewProps> = ({ isPlaying, accentColor = '#ff0000' }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const render = () => {
      const data = audioEngine.getVisualizerData();
      const width = canvas.width;
      const height = canvas.height;

      ctx.clearRect(0, 0, width, height);

      // Draw mirrored bar spectrum
      const barCount = 32;
      const barWidth = (width / barCount) - 2;

      for (let i = 0; i < barCount; i++) {
        const val = data[i % data.length] || 0;
        const normalized = isPlaying ? val / 255 : 0.05;
        const barHeight = Math.max(4, normalized * height * 0.85);

        const x = i * (barWidth + 2);
        const y = height - barHeight;

        const grad = ctx.createLinearGradient(0, height, 0, y);
        grad.addColorStop(0, '#ff0000');
        grad.addColorStop(0.6, '#ff4444');
        grad.addColorStop(1, '#ff9999');

        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.roundRect(x, y, barWidth, barHeight, [3, 3, 0, 0]);
        ctx.fill();
      }

      animFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isPlaying, accentColor]);

  return (
    <div className="w-full flex items-center justify-center p-2">
      <canvas
        ref={canvasRef}
        width={320}
        height={90}
        className="w-full max-w-md h-20 rounded-xl"
      />
    </div>
  );
};
