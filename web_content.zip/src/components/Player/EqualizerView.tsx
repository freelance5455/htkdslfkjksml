import React from 'react';
import { useMusic } from '../../context/MusicContext';
import { EQUALIZER_PRESETS } from '../../data/musicCatalog';
import { Sliders, Volume2, Gauge, Zap } from 'lucide-react';

export const EqualizerView: React.FC = () => {
  const {
    activePreset,
    setEqualizerPreset,
    customBands,
    setBandGain,
    bassBoost,
    setBassBoost,
    playbackRate,
    setPlaybackRate,
  } = useMusic();

  const bandLabels = ['60 Hz', '230 Hz', '910 Hz', '3.6 kHz', '14 kHz'];
  const bandDescriptions = ['Sub-Bass', 'Bass', 'Midrange', 'Presence', 'Treble'];

  return (
    <div className="h-[360px] sm:h-[420px] overflow-y-auto px-4 py-4 text-white space-y-6">
      <div className="flex items-center justify-between border-b border-white/10 pb-3">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-red-500" />
          <h3 className="font-bold text-sm">Studio Audio Equalizer</h3>
        </div>
        <span className="text-xs text-neutral-400">Web Audio 5-Band DSP</span>
      </div>

      {/* Presets Chips */}
      <div>
        <label className="text-xs font-semibold text-neutral-400 uppercase tracking-wider block mb-2">
          Sound Profiles & Presets
        </label>
        <div className="flex flex-wrap gap-2">
          {EQUALIZER_PRESETS.map((preset) => {
            const isSelected = activePreset.id === preset.id;
            return (
              <button
                key={preset.id}
                onClick={() => setEqualizerPreset(preset)}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition cursor-pointer ${
                  isSelected
                    ? 'bg-red-600 text-white font-semibold shadow-md shadow-red-600/30'
                    : 'bg-white/10 hover:bg-white/20 text-neutral-300'
                }`}
              >
                {preset.name}
              </button>
            );
          })}
        </div>
      </div>

      {/* 5-Band EQ Sliders */}
      <div>
        <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
          <span>Frequency Spectrum</span>
          <span>Gain: -12 dB to +12 dB</span>
        </div>
        <div className="grid grid-cols-5 gap-2 bg-[#121212] p-4 rounded-2xl border border-white/5">
          {bandLabels.map((label, idx) => {
            const currentGain = customBands[idx] ?? 0;
            return (
              <div key={label} className="flex flex-col items-center">
                <span className="text-[11px] font-bold text-white mb-2">
                  {currentGain > 0 ? `+${currentGain.toFixed(0)}` : currentGain.toFixed(0)}dB
                </span>
                <div className="h-28 flex items-center justify-center">
                  <input
                    type="range"
                    min="-12"
                    max="12"
                    step="1"
                    value={currentGain}
                    onChange={(e) => setBandGain(idx, parseFloat(e.target.value))}
                    className="h-24 w-2 appearance-none bg-neutral-800 rounded-full outline-none accent-red-500 cursor-pointer"
                    style={{ writingMode: 'vertical-lr', direction: 'rtl' }}
                  />
                </div>
                <span className="text-[11px] font-medium text-white mt-2">{label}</span>
                <span className="text-[9px] text-neutral-500">{bandDescriptions[idx]}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bass Boost Dial & Speed Multiplier */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Bass Boost */}
        <div className="bg-[#121212] p-4 rounded-2xl border border-white/5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-neutral-300">
              <Zap className="w-3.5 h-3.5 text-red-500" />
              <span>Subwoofer Bass Boost</span>
            </div>
            <span className="text-xs font-bold text-red-400">{bassBoost}/10</span>
          </div>
          <input
            type="range"
            min="0"
            max="10"
            step="1"
            value={bassBoost}
            onChange={(e) => setBassBoost(parseInt(e.target.value, 10))}
            className="w-full accent-red-500 cursor-pointer"
          />
        </div>

        {/* Playback Speed / Pitch */}
        <div className="bg-[#121212] p-4 rounded-2xl border border-white/5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-neutral-300">
              <Gauge className="w-3.5 h-3.5 text-blue-400" />
              <span>Speed & Pitch Tempo</span>
            </div>
            <span className="text-xs font-bold text-blue-400">{playbackRate}x</span>
          </div>
          <div className="flex items-center gap-1.5">
            {[0.75, 1.0, 1.25, 1.5].map((speed) => (
              <button
                key={speed}
                onClick={() => setPlaybackRate(speed)}
                className={`flex-1 py-1 rounded-lg text-xs font-semibold transition cursor-pointer ${
                  playbackRate === speed
                    ? 'bg-blue-600 text-white'
                    : 'bg-white/5 hover:bg-white/10 text-neutral-400'
                }`}
              >
                {speed}x
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
