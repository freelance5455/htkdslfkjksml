import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FileCode2, FileText, FileJson, FileType, Plus } from "lucide-react";
import type { StudioApi } from "@/hooks/useStudio";
import { LANG_LABEL, type LangId } from "@/lib/language";
import { cn } from "@/lib/utils";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  studio: StudioApi;
}

function iconFor(lang: LangId) {
  switch (lang) {
    case "html":
    case "xml":
      return FileCode2;
    case "json":
      return FileJson;
    case "css":
      return FileType;
    default:
      return FileText;
  }
}

export function FileDialog({ open, onOpenChange, studio }: Props) {
  const { files, activeFileId, setActiveFile, createFile } = studio;
  const [newName, setNewName] = useState("");

  const handleCreate = async () => {
    if (!newName.trim()) return;
    await createFile(newName.trim());
    setNewName("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-md">
        <DialogHeader>
          <DialogTitle>الملفات</DialogTitle>
        </DialogHeader>

        <div className="flex items-center gap-2">
          <Input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleCreate()}
            placeholder="اسم ملف جديد (مثال: app.js)"
            className="flex-1"
          />
          <Button onClick={handleCreate} className="gap-1 bg-sky-600 hover:bg-sky-700">
            <Plus className="h-4 w-4" />
            إنشاء
          </Button>
        </div>

        <div className="flex flex-col gap-1.5">
          {files.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">
              لا توجد ملفات بعد
            </p>
          ) : (
            files.map((f) => {
              const Icon = iconFor(f.language as LangId);
              const active = f.id === activeFileId;
              return (
                <button
                  key={f.id}
                  onClick={() => {
                    setActiveFile(f.id);
                    onOpenChange(false);
                  }}
                  className={cn(
                    "flex items-center gap-3 rounded-lg border p-2.5 text-start transition-colors",
                    active
                      ? "border-sky-500 bg-sky-50 dark:bg-sky-950/50"
                      : "border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-900"
                  )}
                >
                  <div
                    className={cn(
                      "rounded-md p-1.5",
                      active
                        ? "bg-sky-600 text-white"
                        : "bg-slate-100 text-sky-600 dark:bg-slate-800 dark:text-sky-400"
                    )}
                  >
                    <Icon className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="truncate text-sm font-medium">{f.name}</span>
                      {f.dirty && (
                        <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-amber-500" />
                      )}
                    </div>
                    <p className="text-[11px] text-muted-foreground">
                      {LANG_LABEL[f.language as LangId]}
                    </p>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}