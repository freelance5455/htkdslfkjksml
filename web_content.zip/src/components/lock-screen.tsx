import { useState } from "react";
import { Button } from "@/components/ui/button";
import { SealLock, ShelfMark } from "@/components/mark";
import { PinDots, PinPad } from "@/components/pin-pad";
import { useVault } from "@/lib/vault-store";

export function LockScreen({ mode }: { mode: "setup" | "unlock" }) {
  const setup = useVault((s) => s.setup);
  const unlock = useVault((s) => s.unlock);
  const resetVault = useVault((s) => s.resetVault);

  const [pin, setPin] = useState("");
  const [draft, setDraft] = useState("");
  const [step, setStep] = useState<"enter" | "confirm">(mode === "setup" ? "enter" : "enter");
  const [error, setError] = useState("");
  const [shake, setShake] = useState(false);
  const [busy, setBusy] = useState(false);
  const [wiping, setWiping] = useState(false);

  function fail(message: string) {
    setError(message);
    setShake(true);
    window.setTimeout(() => setShake(false), 400);
    setPin("");
  }

  async function onComplete(value: string) {
    if (busy) return;
    setError("");
    if (mode === "setup") {
      if (step === "enter") {
        setDraft(value);
        setPin("");
        setStep("confirm");
        return;
      }
      if (value !== draft) {
        setStep("enter");
        setDraft("");
        fail("Коды не совпали. Ещё раз.");
        return;
      }
      setBusy(true);
      await setup(value);
      setBusy(false);
      return;
    }
    setBusy(true);
    const ok = await unlock(value);
    setBusy(false);
    if (!ok) fail("Неверный код.");
  }

  const caption =
    mode === "setup"
      ? step === "confirm"
        ? "Повторите код"
        : "Придумайте код из 4 цифр"
      : "Введите код, чтобы открыть полку";

  return (
    <main className="shelf-grain flex h-full flex-col px-6 pt-safe text-cream">
      <div className="flex flex-1 flex-col items-center justify-end pb-4">
        <span className="text-sage">
          {mode === "setup" ? <ShelfMark className="size-11" /> : <SealLock className="size-10" />}
        </span>
        <p className="mt-4 text-xs font-medium uppercase tracking-[0.22em] text-sage">закрытая библиотека</p>
        <h1 className="mt-2 font-display text-4xl font-medium tracking-tight">Тайная полка</h1>
        <p className="mt-4 text-center font-reading text-sm text-muted">{caption}</p>
        <div className="mt-6">
          <PinDots value={pin} shake={shake} />
        </div>
        <p className="mt-4 h-5 text-center text-sm text-danger" role="alert">
          {error}
        </p>
      </div>

      <div className="pb-safe pb-6">
        <PinPad value={pin} onChange={setPin} onComplete={onComplete} disabled={busy} />
        {mode === "unlock" && (
          <div className="mt-4 text-center">
            {!wiping ? (
              <button
                type="button"
                onClick={() => setWiping(true)}
                className="text-sm text-faint underline-offset-4 hover:text-muted hover:underline"
              >
                Забыли код?
              </button>
            ) : (
              <div className="space-y-3 rounded-2xl bg-ink-2 p-4 text-left shadow-border">
                <p className="font-reading text-sm leading-relaxed text-cream-2">
                  Код нельзя восстановить. Можно стереть сейф — свои тексты и закладки пропадут.
                </p>
                <div className="flex flex-wrap gap-2">
                  <Button variant="danger" size="sm" onClick={resetVault}>
                    Стереть сейф
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => setWiping(false)}>
                    Оставить
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </main>
  );
}
