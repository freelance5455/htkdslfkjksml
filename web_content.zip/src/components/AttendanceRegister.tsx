import { useState } from 'react';
import {
  ArrowLeft,
  Check,
  CheckCircle2,
  Download,
  FileDown,
  FileText,
  Search,
  Trash2,
  Upload,
  UserPlus,
  X,
} from 'lucide-react';
import type { AttendanceMark, Department, ShiftType, Worker } from '../types/attendance';
import {
  computeDepartmentSummary,
  filterWorkers,
  formatDisplayDate,
  formatShiftLabel,
  generateAttendanceCsv,
  getRecordForDate,
  slugifyFilename,
} from '../utils/attendanceLogic';
import { downloadAttendancePdf } from '../utils/pdfExport';
import { ShiftToggle } from './ShiftToggle';

interface AttendanceRegisterProps {
  department: Department;
  selectedDate: string;
  selectedShift: ShiftType;
  onChangeDate: (date: string) => void;
  onChangeShift: (shift: ShiftType) => void;
  onBack: () => void;
  onToggleMark: (workerId: string, mark: AttendanceMark) => void;
  onSubmitAttendance: () => void;
  onOpenAddWorker: () => void;
  onOpenBulkImport: () => void;
  onDeleteWorker: (workerId: string) => void;
}

export function AttendanceRegister({
  department,
  selectedDate,
  selectedShift,
  onChangeDate,
  onChangeShift,
  onBack,
  onToggleMark,
  onSubmitAttendance,
  onOpenAddWorker,
  onOpenBulkImport,
  onDeleteWorker,
}: AttendanceRegisterProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [workerPendingDelete, setWorkerPendingDelete] = useState<Worker | null>(null);

  const record = getRecordForDate(department, selectedDate, selectedShift);
  const summary = computeDepartmentSummary(department, selectedDate, selectedShift);
  const filteredWorkers: Worker[] = filterWorkers(department.workers, searchQuery);

  const handleDownloadCsv = () => {
    const csvContent = generateAttendanceCsv(department, selectedDate, selectedShift);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${slugifyFilename(department.name)}-${selectedShift}-shift-attendance-${selectedDate}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDownloadPdf = () => {
    downloadAttendancePdf(department, selectedDate, selectedShift);
  };

  return (
    <>
      <div className="no-print min-h-screen bg-[#F8FAFC] text-slate-900 flex flex-col">
        {/* Top Navigation & Header */}
        <header className="bg-white border-b border-slate-200">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 py-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <button
                type="button"
                onClick={onBack}
                aria-label="Back to Home Dashboard"
                className="min-w-[44px] min-h-[44px] px-3 inline-flex items-center justify-center gap-1.5 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors shrink-0"
              >
                <ArrowLeft className="w-4 h-4" />
                <span className="hidden sm:inline">Back</span>
              </button>
              <div className="min-w-0">
                <h1 className="text-lg sm:text-xl font-bold text-slate-900 truncate">
                  {department.name}
                </h1>
                <p className="text-sm text-slate-600 truncate">
                  Supervisor: <span className="font-medium text-slate-900">{department.supervisor}</span>
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2.5 shrink-0">
              <ShiftToggle selectedShift={selectedShift} onChangeShift={onChangeShift} />

              <div className="flex items-center gap-2">
                <label htmlFor="attendance-date-picker" className="text-xs sm:text-sm font-medium text-slate-600 whitespace-nowrap">
                  Date
                </label>
                <input
                  id="attendance-date-picker"
                  type="date"
                  value={selectedDate}
                  onChange={(e) => {
                    if (e.target.value) {
                      onChangeDate(e.target.value);
                    }
                  }}
                  className="min-h-[44px] px-3 py-2 text-sm font-medium text-slate-900 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
                />
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-5 sm:py-6 space-y-5 pb-28">
          {/* Live 3-Column Summary Card */}
          <section
            aria-label="Live Attendance Summary"
            className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden"
          >
            <div className="grid grid-cols-3 divide-x divide-slate-100 text-center">
              <div className="px-3 py-4 sm:py-5">
                <p className="text-xs sm:text-sm font-medium text-slate-500">Total</p>
                <p
                  data-testid="summary-total"
                  className="mt-1 text-2xl sm:text-3xl font-bold text-slate-900 tabular-nums"
                >
                  {summary.total}
                </p>
              </div>
              <div className="px-3 py-4 sm:py-5 bg-emerald-50/30">
                <p className="text-xs sm:text-sm font-semibold text-emerald-700">Present (P)</p>
                <p
                  data-testid="summary-present"
                  className="mt-1 text-2xl sm:text-3xl font-bold text-emerald-600 tabular-nums"
                >
                  {summary.present}
                </p>
              </div>
              <div className="px-3 py-4 sm:py-5 bg-rose-50/30">
                <p className="text-xs sm:text-sm font-semibold text-rose-700">Absent (Ab)</p>
                <p
                  data-testid="summary-absent"
                  className="mt-1 text-2xl sm:text-3xl font-bold text-rose-600 tabular-nums"
                >
                  {summary.absent}
                </p>
              </div>
            </div>
          </section>

          {/* Search & Actions Bar */}
          <section aria-label="Search and Worker Actions" className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search
                className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by Name, Worker ID, or Role..."
                aria-label="Search workers by Name, Worker ID, or Role"
                className="w-full min-h-[44px] pl-10 pr-4 py-2.5 text-sm text-slate-900 bg-white border border-slate-200 rounded-xl shadow-xs placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
              />
            </div>

            <div className="flex items-center gap-2.5 shrink-0">
              <button
                type="button"
                onClick={onOpenAddWorker}
                className="flex-1 sm:flex-initial min-h-[44px] px-4 py-2 inline-flex items-center justify-center gap-2 text-sm font-semibold text-white bg-[#2563EB] hover:bg-[#1D4ED8] rounded-xl shadow-xs transition-colors whitespace-nowrap"
              >
                <UserPlus className="w-4 h-4" />
                <span>Add Worker</span>
              </button>
              <button
                type="button"
                onClick={onOpenBulkImport}
                className="flex-1 sm:flex-initial min-h-[44px] px-4 py-2 inline-flex items-center justify-center gap-2 text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl shadow-xs transition-colors whitespace-nowrap"
              >
                <Upload className="w-4 h-4 text-slate-500" />
                <span>Bulk Import Workers</span>
              </button>
            </div>
          </section>

          {/* Session Submitted Banner */}
          {summary.submitted && (
            <div
              role="status"
              className="flex items-center gap-2.5 px-4 py-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-sm font-semibold"
            >
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" aria-hidden="true" />
              <span>Attendance for this session has been submitted</span>
            </div>
          )}

          {/* Worker List Cards */}
          <section aria-label="Worker Attendance Roster">
            {department.workers.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-8 text-center space-y-3">
                <p className="text-base font-semibold text-slate-900">No workers in this department yet</p>
                <p className="text-sm text-slate-500 max-w-md mx-auto">
                  Add workers individually or paste a list in bulk to start marking daily attendance.
                </p>
                <div className="pt-2 flex flex-wrap justify-center gap-2.5">
                  <button
                    type="button"
                    onClick={onOpenAddWorker}
                    className="min-h-[44px] px-4 py-2 inline-flex items-center gap-2 text-sm font-semibold text-white bg-[#2563EB] hover:bg-[#1D4ED8] rounded-xl"
                  >
                    <UserPlus className="w-4 h-4" />
                    <span>Add First Worker</span>
                  </button>
                  <button
                    type="button"
                    onClick={onOpenBulkImport}
                    className="min-h-[44px] px-4 py-2 inline-flex items-center gap-2 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl"
                  >
                    <Upload className="w-4 h-4" />
                    <span>Bulk Import Workers</span>
                  </button>
                </div>
              </div>
            ) : filteredWorkers.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-8 text-center space-y-3">
                <p className="text-base font-semibold text-slate-900">No matching workers found</p>
                <p className="text-sm text-slate-500">
                  No workers match &ldquo;{searchQuery}&rdquo; by Name, Worker ID, or Role.
                </p>
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="min-h-[44px] px-4 py-2 text-sm font-semibold text-[#2563EB] bg-blue-50 hover:bg-blue-100 rounded-xl"
                >
                  Clear Search
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {filteredWorkers.map((worker) => {
                  const mark = record.marks[worker.id];
                  const isPresent = mark === 'present';
                  const isAbsent = mark === 'absent';

                  const cardBorderClass = isPresent
                    ? 'border-emerald-500 bg-emerald-50/35 ring-1 ring-emerald-500/25'
                    : isAbsent
                      ? 'border-rose-500 bg-rose-50/35 ring-1 ring-rose-500/25'
                      : 'border-slate-200/90 bg-white';

                  return (
                    <div
                      key={worker.id}
                      data-testid={`worker-card-${worker.id}`}
                      data-status={mark ?? 'unmarked'}
                      className={`rounded-2xl border shadow-sm px-4 py-3.5 sm:px-5 sm:py-4 flex items-center justify-between gap-3 transition-colors duration-150 ${cardBorderClass}`}
                    >
                      <div className="min-w-0 space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-mono text-xs font-semibold text-slate-500">
                            {worker.id}
                          </span>
                          <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-xs font-medium">
                            {worker.role}
                          </span>
                        </div>
                        <p className="text-base font-semibold text-slate-900 truncate">
                          {worker.name}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => onToggleMark(worker.id, 'present')}
                          aria-label={`Mark ${worker.name} (${worker.id}) Present`}
                          aria-pressed={isPresent}
                          className={`w-11 h-11 sm:w-12 sm:h-12 rounded-full flex items-center justify-center border transition-all duration-150 ${
                            isPresent
                              ? 'bg-emerald-600 border-emerald-600 text-white shadow-sm scale-[1.03]'
                              : 'bg-white border-emerald-200 text-emerald-600 hover:bg-emerald-50 hover:border-emerald-400'
                          }`}
                        >
                          <Check className="w-5 h-5 stroke-[2.5]" />
                        </button>

                        <button
                          type="button"
                          onClick={() => onToggleMark(worker.id, 'absent')}
                          aria-label={`Mark ${worker.name} (${worker.id}) Absent`}
                          aria-pressed={isAbsent}
                          className={`w-11 h-11 sm:w-12 sm:h-12 rounded-full flex items-center justify-center border transition-all duration-150 ${
                            isAbsent
                              ? 'bg-rose-600 border-rose-600 text-white shadow-sm scale-[1.03]'
                              : 'bg-white border-rose-200 text-rose-600 hover:bg-rose-50 hover:border-rose-400'
                          }`}
                        >
                          <X className="w-5 h-5 stroke-[2.5]" />
                        </button>

                        <span className="w-px h-7 bg-slate-200 mx-0.5" aria-hidden="true" />

                        <button
                          type="button"
                          onClick={() => setWorkerPendingDelete(worker)}
                          aria-label={`Delete ${worker.name} (${worker.id})`}
                          title={`Delete ${worker.name}`}
                          className="w-11 h-11 rounded-xl flex items-center justify-center text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                        >
                          <Trash2 className="w-4.5 h-4.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>
        </main>

        {/* Sticky Submission & Export Footer */}
        <footer className="sticky bottom-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-2.5">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleDownloadPdf}
                aria-label="Download PDF Report"
                className="min-h-[44px] px-3 sm:px-3.5 py-2 inline-flex items-center gap-1.5 text-xs sm:text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors whitespace-nowrap"
              >
                <FileDown className="w-4 h-4 text-slate-600" aria-hidden="true" />
                <span className="sm:hidden">PDF</span>
                <span className="hidden sm:inline">Download PDF</span>
              </button>
              <button
                type="button"
                onClick={handleDownloadCsv}
                aria-label="Download CSV Report"
                className="min-h-[44px] px-3 sm:px-3.5 py-2 inline-flex items-center gap-1.5 text-xs sm:text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors whitespace-nowrap"
              >
                <Download className="w-4 h-4 text-slate-600" aria-hidden="true" />
                <span className="sm:hidden">CSV</span>
                <span className="hidden sm:inline">Download CSV</span>
              </button>
            </div>

            <button
              type="button"
              onClick={onSubmitAttendance}
              disabled={department.workers.length === 0}
              className={`flex-1 sm:flex-initial min-h-[44px] px-6 py-2.5 inline-flex items-center justify-center gap-2 text-sm font-semibold text-white disabled:bg-slate-300 disabled:cursor-not-allowed rounded-xl shadow-sm transition-colors whitespace-nowrap ${
                summary.submitted
                  ? 'bg-emerald-600 hover:bg-emerald-700'
                  : 'bg-[#2563EB] hover:bg-[#1D4ED8]'
              }`}
            >
              {summary.submitted ? (
                <CheckCircle2 className="w-4 h-4" aria-hidden="true" />
              ) : (
                <FileText className="w-4 h-4" aria-hidden="true" />
              )}
              <span>{summary.submitted ? 'Submitted' : 'Submit Attendance'}</span>
            </button>
          </div>
        </footer>

        {workerPendingDelete && (
          <div
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-900/50 backdrop-blur-xs p-0 sm:p-4"
            role="dialog"
            aria-modal="true"
            aria-labelledby="delete-worker-modal-title"
          >
            <div className="w-full sm:max-w-sm bg-white rounded-t-3xl sm:rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
              <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
                <h2 id="delete-worker-modal-title" className="text-lg font-semibold text-slate-900">
                  Delete Worker
                </h2>
                <button
                  type="button"
                  onClick={() => setWorkerPendingDelete(null)}
                  aria-label="Close delete worker modal"
                  className="min-w-[44px] min-h-[44px] -mr-2 flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="p-5 space-y-4">
                <p className="text-sm text-slate-600 leading-relaxed">
                  Remove <strong className="text-slate-900">{workerPendingDelete.name}</strong>{' '}
                  (<span className="font-mono text-xs text-slate-700">{workerPendingDelete.id}</span>) from{' '}
                  <strong className="text-slate-900">{department.name}</strong>? This removes the worker from the department roster.
                </p>
                <div className="flex items-center justify-end gap-2.5">
                  <button
                    type="button"
                    onClick={() => setWorkerPendingDelete(null)}
                    className="min-h-[44px] px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onDeleteWorker(workerPendingDelete.id);
                      setWorkerPendingDelete(null);
                    }}
                    className="min-h-[44px] px-5 py-2 text-sm font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-xs transition-colors"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Formal Printable PDF View */}
      <div className="print-only p-8 text-slate-900 bg-white">
        <div className="border-b-2 border-slate-900 pb-4 mb-6 flex items-end justify-between">
          <div>
            <h1 className="text-2xl font-bold">Daily Attendance Register</h1>
            <p className="text-sm text-slate-600 mt-1">
              Department: <strong className="text-slate-900">{department.name}</strong> · Supervisor:{' '}
              <strong className="text-slate-900">{department.supervisor}</strong>
            </p>
          </div>
          <div className="text-right text-sm">
            <p className="font-semibold">Date: {formatDisplayDate(selectedDate)} ({selectedDate})</p>
            <p className="text-slate-600">
              {formatShiftLabel(selectedShift)} · Status: {summary.submitted ? 'Submitted' : 'Draft'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-4 mb-6 border border-slate-300 rounded-lg p-3 text-center">
          <div>
            <p className="text-xs text-slate-500">Total Workers</p>
            <p className="text-lg font-bold tabular-nums">{summary.total}</p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Present (P)</p>
            <p className="text-lg font-bold text-emerald-700 tabular-nums">{summary.present}</p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Absent (Ab)</p>
            <p className="text-lg font-bold text-rose-700 tabular-nums">{summary.absent}</p>
          </div>
          <div>
            <p className="text-xs text-slate-500">Unmarked</p>
            <p className="text-lg font-bold text-slate-700 tabular-nums">{summary.unmarked}</p>
          </div>
        </div>

        <table className="w-full border-collapse text-sm">
          <thead>
            <tr className="border-b-2 border-slate-800 text-left">
              <th className="py-2 pr-4 font-semibold">Worker ID</th>
              <th className="py-2 pr-4 font-semibold">Full Name</th>
              <th className="py-2 pr-4 font-semibold">Role / Designation</th>
              <th className="py-2 font-semibold text-right">Status</th>
            </tr>
          </thead>
          <tbody>
            {department.workers.map((worker) => {
              const mark = record.marks[worker.id];
              const statusText =
                mark === 'present' ? 'Present' : mark === 'absent' ? 'Absent' : 'Unmarked';
              return (
                <tr key={worker.id} className="border-b border-slate-200">
                  <td className="py-2 pr-4 font-mono">{worker.id}</td>
                  <td className="py-2 pr-4 font-medium">{worker.name}</td>
                  <td className="py-2 pr-4">{worker.role}</td>
                  <td className="py-2 text-right font-semibold">{statusText}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}
