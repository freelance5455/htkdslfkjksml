import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  Calendar,
  MapPin,
  Clock,
  Plus,
  Search,
  DollarSign,
  Smartphone,
  CreditCard,
  CheckCircle2,
  Ticket,
  ArrowRight,
  TrendingUp,
  Sparkles,
} from 'lucide-react';
import { EventItem, EventCategory } from '../types';
import { EventManagementDrawer } from './EventManagementDrawer';

export const DashboardPage: React.FC = () => {
  const {
    user,
    events,
    openCreateEventModal,
    setCurrentPage,
    updateUserProfile,
    showToast,
    formatKsh,
  } = useApp();

  const [selectedEventForDrawer, setSelectedEventForDrawer] = useState<EventItem | null>(null);

  // Payout Settings State
  const [payoutMpesa, setPayoutMpesa] = useState(user?.mpesaNumber || user?.phone || '0712 345 678');
  const [payoutPaypal, setPayoutPaypal] = useState(user?.paypalEmail || 'host@eventra.com');
  const [autoDisburse, setAutoDisburse] = useState(false);
  const [isSavingPayoutSettings, setIsSavingPayoutSettings] = useState(false);

  // Search & Filter within My Events
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<EventCategory>('all');

  // Filter events created by or associated with this host
  const hostEvents = useMemo(() => {
    return events.filter(
      (e) =>
        e.isUserCreated ||
        e.hostUid === user?.id ||
        e.hostName?.toLowerCase() === (user?.name || '').toLowerCase() ||
        e.hostMpesa === (user?.mpesaNumber || user?.phone) ||
        // Baseline showcase listings for testing and immediate interaction
        e.id === 'evt_festival_aurora' ||
        e.id === 'evt_orchestra_mahler'
    );
  }, [events, user]);

  const filteredHostEvents = useMemo(() => {
    return hostEvents.filter((evt) => {
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        evt.title.toLowerCase().includes(q) ||
        evt.venue.toLowerCase().includes(q) ||
        evt.city.toLowerCase().includes(q);
      const matchCat = categoryFilter === 'all' || evt.category === categoryFilter;
      return matchSearch && matchCat;
    });
  }, [hostEvents, searchQuery, categoryFilter]);

  const handleSavePayoutSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingPayoutSettings(true);
    try {
      await updateUserProfile({
        mpesaNumber: payoutMpesa.trim(),
        paypalEmail: payoutPaypal.trim(),
      });
      showToast('Host payout destination rails saved successfully');
    } catch {
      showToast('Failed to save payout settings');
    } finally {
      setIsSavingPayoutSettings(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#090a0d] text-[#f4f4f6] pt-24 pb-28">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 space-y-8">
        {/* Top Header Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#1f2229]">
          <div>
            <span className="text-xs font-semibold text-[#9496a1] uppercase tracking-wider block">
              Creator & Host Studio
            </span>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white mt-0.5">
              Host Dashboard
            </h1>
            <p className="text-xs text-[#9496a1] mt-1 max-w-xl">
              Click any event card in your portfolio to open its dedicated analytics, live buyer stream, and modification suite.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={openCreateEventModal}
              className="px-5 py-2.5 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-md active:scale-95"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>Create New Event</span>
            </button>
          </div>
        </div>

        {/* ======================================================== */}
        {/* CONSOLIDATED HOST PAYMENT METHODS & PAYOUT SETTINGS     */}
        {/* ======================================================== */}
        <div className="p-6 sm:p-7 rounded-[32px] bg-[#111317] border border-[#1f2229] shadow-xl space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1f2229]">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                <DollarSign className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-base font-bold text-white">
                  Consolidated Payment Methods & Payout Settings
                </h2>
                <p className="text-xs text-[#9496a1]">
                  Configure verified rails for ticket proceeds settlement and automated payouts.
                </p>
              </div>
            </div>

            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-semibold border border-emerald-500/20">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Direct Rails Active</span>
            </div>
          </div>

          <form onSubmit={handleSavePayoutSettings} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Rail 1: Safaricom M-Pesa B2C */}
            <div className="p-4 rounded-2xl bg-[#16181f] border border-[#232733] space-y-2">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold text-white">
                  M-Pesa B2C Payout Rail
                </span>
              </div>
              <label className="text-[10px] font-bold uppercase tracking-wider text-[#9496a1] block">
                Kenyan Phone Number
              </label>
              <input
                type="text"
                value={payoutMpesa}
                onChange={(e) => setPayoutMpesa(e.target.value)}
                placeholder="0712 345 678"
                className="w-full h-12 px-4 text-xs font-mono font-medium rounded-xl border border-[#262934] bg-[#1a1d26] text-white focus:border-emerald-500 focus:outline-none"
                required
              />
              <span className="text-[10px] text-[#646875] block">Direct Daraja B2C mobile disbursement</span>
            </div>

            {/* Rail 2: PayPal Express */}
            <div className="p-4 rounded-2xl bg-[#16181f] border border-[#232733] space-y-2">
              <div className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-blue-400" />
                <span className="text-xs font-bold text-white">
                  PayPal Payout Rail
                </span>
              </div>
              <label className="text-[10px] font-bold uppercase tracking-wider text-[#9496a1] block">
                Account Email
              </label>
              <input
                type="email"
                value={payoutPaypal}
                onChange={(e) => setPayoutPaypal(e.target.value)}
                placeholder="host@eventra.com"
                className="w-full h-12 px-4 text-xs font-medium rounded-xl border border-[#262934] bg-[#1a1d26] text-white focus:border-emerald-500 focus:outline-none"
                required
              />
              <span className="text-[10px] text-[#646875] block">For global ticket buyers & currency settlement</span>
            </div>

            {/* Rail 3: Settlement Schedule & Save */}
            <div className="p-4 rounded-2xl bg-[#16181f] border border-[#232733] space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">
                    Auto Daily Disbursement
                  </span>
                  <button
                    type="button"
                    onClick={() => setAutoDisburse(!autoDisburse)}
                    className={`w-10 h-6 flex items-center rounded-full p-1 cursor-pointer transition-colors ${
                      autoDisburse ? 'bg-emerald-500' : 'bg-[#262934]'
                    }`}
                  >
                    <div
                      className={`bg-white w-4 h-4 rounded-full shadow-xs transform transition-transform ${
                        autoDisburse ? 'translate-x-4' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
                <span className="text-[10px] text-[#646875] block mt-1">
                  {autoDisburse ? 'Daily automatic transfer at midnight EAT' : 'Manual cashout from event drawers'}
                </span>
              </div>

              <button
                type="submit"
                disabled={isSavingPayoutSettings}
                className="w-full py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-white text-xs font-bold transition-all cursor-pointer shadow-xs active:scale-98"
              >
                {isSavingPayoutSettings ? 'Saving...' : 'Save Payout Rails'}
              </button>
            </div>
          </form>
        </div>

        {/* ======================================================== */}
        {/* MY EVENTS GRID: CLEAN & ENTIRELY CLICKABLE CARDS         */}
        {/* ======================================================== */}
        <div className="p-6 sm:p-7 rounded-[32px] bg-[#111317] border border-[#1f2229] shadow-xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <Ticket className="w-5 h-5 text-emerald-400" />
                <h2 className="text-lg font-bold text-white">
                  My Hosted Events ({filteredHostEvents.length})
                </h2>
              </div>
              <p className="text-xs text-[#9496a1] mt-0.5">
                Click any event card to view its dedicated gross sales, remaining inventory, and live buyer feed.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={openCreateEventModal}
                className="px-3.5 py-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Publish Another Event</span>
              </button>
            </div>
          </div>

          {/* Search & Category Filter */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-[#646875]" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search hosted events by title, venue, or city..."
                className="w-full h-11 pl-10 pr-4 text-xs font-medium rounded-xl border border-[#232733] bg-[#16181f] text-white placeholder:text-[#5d606f] focus:border-emerald-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
              {(
                [
                  { id: 'all', label: 'All' },
                  { id: 'concerts', label: 'Festival' },
                  { id: 'classical', label: 'Symphony' },
                  { id: 'electronic', label: 'Electronic' },
                  { id: 'sports', label: 'Sports' },
                ] as const
              ).map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setCategoryFilter(cat.id)}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                    categoryFilter === cat.id
                      ? 'bg-emerald-500 text-white font-bold shadow-xs'
                      : 'bg-[#16181f] text-[#9496a1] hover:text-white border border-[#232733]'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Clean Clickable Event Cards Grid */}
          {filteredHostEvents.length === 0 ? (
            <div className="py-16 text-center space-y-3">
              <Ticket className="w-10 h-10 mx-auto text-[#646875] opacity-40" />
              <h3 className="text-sm font-bold text-white">No Hosted Events Found</h3>
              <p className="text-xs text-[#9496a1] max-w-sm mx-auto">
                {searchQuery
                  ? 'No events match your current search query or filter.'
                  : 'You have not published any events yet. Create your first event to start accepting ticket purchases worldwide.'}
              </p>
              <button
                onClick={openCreateEventModal}
                className="mt-2 px-4 py-2 rounded-full bg-emerald-500 text-white text-xs font-bold hover:bg-emerald-600 transition-all cursor-pointer"
              >
                Create an Event
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredHostEvents.map((evt) => {
                return (
                  <div
                    key={evt.id}
                    onClick={() => setSelectedEventForDrawer(evt)}
                    className="p-5 rounded-[28px] bg-[#16181f] border border-[#232733] hover:border-emerald-500/50 hover:bg-[#1a1d27] transition-all duration-200 cursor-pointer shadow-sm group flex flex-col justify-between space-y-4"
                  >
                    <div className="flex items-start gap-4">
                      <div className="relative w-24 h-24 rounded-2xl overflow-hidden shrink-0 border border-[#262934]">
                        <img
                          src={evt.image}
                          alt={evt.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                        <span className="absolute bottom-1.5 left-1.5 text-[9px] font-bold uppercase tracking-wider text-emerald-400 bg-black/70 px-1.5 py-0.5 rounded">
                          {evt.categoryLabel || evt.category}
                        </span>
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 mb-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                            Live & On Sale
                          </span>
                        </div>

                        <h3 className="text-base font-bold text-white group-hover:text-emerald-400 transition-colors truncate">
                          {evt.title}
                        </h3>

                        <div className="space-y-1 mt-1 text-xs text-[#9496a1]">
                          <div className="flex items-center gap-1.5 truncate">
                            <Calendar className="w-3.5 h-3.5 text-[#646875] shrink-0" />
                            <span>{evt.date} · {evt.time}</span>
                          </div>

                          <div className="flex items-center gap-1.5 truncate">
                            <MapPin className="w-3.5 h-3.5 text-[#646875] shrink-0" />
                            <span>{evt.venue}, {evt.city}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Card Footer: Starting Price & Click Prompt */}
                    <div className="pt-3 border-t border-[#232733] flex items-center justify-between text-xs">
                      <div>
                        <span className="text-[10px] uppercase font-bold text-[#646875] block">
                          Pass Starting From
                        </span>
                        <span className="font-bold text-white">
                          {formatKsh(evt.personalPrice || evt.price || 2500)}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 text-emerald-400 group-hover:translate-x-1 transition-transform font-bold text-xs">
                        <span>Manage Event & Feed</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Scoped Unified Event Details & Management Drawer */}
      {selectedEventForDrawer && (
        <EventManagementDrawer
          event={selectedEventForDrawer}
          onClose={() => setSelectedEventForDrawer(null)}
        />
      )}
    </div>
  );
};
