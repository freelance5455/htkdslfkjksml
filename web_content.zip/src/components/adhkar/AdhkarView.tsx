import React, { useState, useEffect, useMemo } from 'react';
import { MORNING_ADHKAR, EVENING_ADHKAR } from '../../data/adhkar';
import { DhikrItem } from '../../types';
import {
  Sun,
  Moon,
  Sparkles,
  RotateCcw,
  CheckCircle2,
  BookOpen,
  Volume2,
  ChevronDown,
  ChevronUp,
  Award,
} from 'lucide-react';
import { playNotificationChime } from '../../utils/notifications';

const ADHKAR_STORAGE_KEY = 'my_smart_day_adhkar_counts_v1';

export const AdhkarView: React.FC = () => {
  // Auto-detect morning vs evening based on current hour
  const currentHour = new Date().getHours();
  const [activeCategory, setActiveCategory] = useState<'morning' | 'evening'>(
    currentHour >= 4 && currentHour < 16 ? 'morning' : 'evening'
  );

  const [counts, setCounts] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem(ADHKAR_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        const today = new Date().toISOString().split('T')[0];
        if (parsed.date === today) {
          return parsed.counts || {};
        }
      }
    } catch {
      // Ignore
    }
    return {};
  });

  const [expandedInfo, setExpandedInfo] = useState<Record<string, boolean>>({});

  // Save counts to localStorage
  useEffect(() => {
    try {
      const today = new Date().toISOString().split('T')[0];
      localStorage.setItem(
        ADHKAR_STORAGE_KEY,
        JSON.stringify({ date: today, counts })
      );
    } catch {
      // Ignore
    }
  }, [counts]);

  const activeList: DhikrItem[] = useMemo(() => {
    return activeCategory === 'morning' ? MORNING_ADHKAR : EVENING_ADHKAR;
  }, [activeCategory]);

  const handleIncrement = (id: string, targetCount: number) => {
    const current = counts[id] || 0;
    if (current < targetCount) {
      const next = current + 1;
      setCounts((prev) => ({ ...prev, [id]: next }));
      playNotificationChime(next >= targetCount ? 'success' : 'click');
    }
  };

  const handleResetDhikr = (id: string) => {
    setCounts((prev) => ({ ...prev, [id]: 0 }));
    playNotificationChime('click');
  };

  const handleResetAllCategory = () => {
    if (confirm(`هل تريد إعادة تصفير عدادات ${activeCategory === 'morning' ? 'أذكار الصباح' : 'أذكار المساء'}؟`)) {
      setCounts((prev) => {
        const updated = { ...prev };
        activeList.forEach((item) => {
          delete updated[item.id];
        });
        return updated;
      });
      playNotificationChime('alert');
    }
  };

  const toggleExpand = (id: string) => {
    setExpandedInfo((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Calculate progress
  const completedCount = useMemo(() => {
    return activeList.filter((item) => (counts[item.id] || 0) >= item.targetCount).length;
  }, [activeList, counts]);

  const progressPercent = Math.round((completedCount / activeList.length) * 100);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-rose-700 via-pink-700 to-rose-600 p-6 text-white shadow-sm border border-rose-400/30">
        <div
          className="absolute inset-0 opacity-15 bg-cover bg-center pointer-events-none mix-blend-overlay"
          style={{ backgroundImage: `url('/public/assets/aistudio/images_5d51feea.jpg')` }}
        />

        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-rose-200 text-xs font-semibold mb-1">
              <Sparkles className="w-4 h-4 text-pink-300" />
              <span>الورد اليومي وحصن المسلم</span>
            </div>
            <h2 className="text-2xl font-bold tracking-tight">أذكار الصباح والمساء</h2>
            <p className="text-xs text-rose-100/90 mt-1 max-w-xl">
              عداد تسبيح تفاعلي بالتشكيل الكامل، ومتابعة فضل كل ذكر لتبدأ وتختم يومك ببركة وسكينة
            </p>
          </div>

          {/* Reset Category Button */}
          <button
            onClick={handleResetAllCategory}
            className="px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-semibold backdrop-blur-md border border-white/20 transition-all flex items-center gap-1.5 self-start sm:self-auto"
            title="تصفير عدادات هذا القسم"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>تصفير العدادات</span>
          </button>
        </div>
      </div>

      {/* Switcher & Progress Header */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
        {/* Morning / Evening Toggle */}
        <div className="md:col-span-2 flex items-center p-1.5 rounded-2xl bg-white dark:bg-[#180d15] border border-rose-100 dark:border-rose-950/60 shadow-xs">
          <button
            onClick={() => setActiveCategory('morning')}
            className={`flex-1 py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
              activeCategory === 'morning'
                ? 'bg-gradient-to-r from-rose-600 to-pink-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-rose-200 hover:text-rose-700'
            }`}
          >
            <Sun className="w-4 h-4" />
            <span>أذكار الصباح ({MORNING_ADHKAR.length} ذكر)</span>
          </button>

          <button
            onClick={() => setActiveCategory('evening')}
            className={`flex-1 py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
              activeCategory === 'evening'
                ? 'bg-gradient-to-r from-rose-600 to-pink-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-rose-200 hover:text-rose-700'
            }`}
          >
            <Moon className="w-4 h-4" />
            <span>أذكار المساء ({EVENING_ADHKAR.length} ذكر)</span>
          </button>
        </div>

        {/* Progress Card */}
        <div className="bg-white dark:bg-[#180d15] p-3.5 rounded-2xl border border-rose-100 dark:border-rose-950/60 shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <div className="text-[11px] font-semibold text-slate-500 dark:text-rose-200/70">
              إنجاز {activeCategory === 'morning' ? 'أذكار الصباح' : 'أذكار المساء'}
            </div>
            <div className="text-sm font-bold font-mono text-slate-900 dark:text-rose-100">
              {completedCount} من {activeList.length} أذكار مكتملة ({progressPercent}%)
            </div>
          </div>

          <div className="w-10 h-10 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 flex items-center justify-center font-bold text-xs font-mono">
            {progressPercent}%
          </div>
        </div>
      </div>

      {/* Adhkar Cards List */}
      <div className="space-y-4">
        {activeList.map((item, index) => {
          const currentCount = counts[item.id] || 0;
          const isDone = currentCount >= item.targetCount;
          const isExpanded = !!expandedInfo[item.id];

          return (
            <div
              key={item.id}
              className={`p-5 rounded-2xl border transition-all duration-200 ${
                isDone
                  ? 'bg-rose-50/40 dark:bg-rose-950/20 border-rose-200/70 dark:border-rose-900/50 opacity-80'
                  : 'bg-white dark:bg-[#180d15] border-rose-100 dark:border-rose-950/60 shadow-xs'
              }`}
            >
              {/* Top row: Dhikr index and Target badge */}
              <div className="flex items-center justify-between mb-3 text-xs">
                <span className="font-bold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/60 px-2.5 py-0.5 rounded-lg border border-rose-200/50 dark:border-rose-900/40">
                  الذكر #{index + 1}
                </span>

                <div className="flex items-center gap-2">
                  <span className="font-medium text-slate-500 dark:text-rose-200/70 text-[11px]">
                    التكرار المطلوب: {item.targetCount} {item.targetCount === 1 ? 'مرة' : 'مرات'}
                  </span>
                  {item.source && (
                    <span className="text-[10px] text-rose-700 dark:text-rose-300 bg-pink-50 dark:bg-pink-950/40 px-2 py-0.5 rounded">
                      {item.source}
                    </span>
                  )}
                </div>
              </div>

              {/* Dhikr Arabic Text */}
              <div className="font-serif text-base sm:text-lg leading-loose text-slate-900 dark:text-rose-50 py-1 mb-4 select-text">
                {item.text}
              </div>

              {/* Interactive Counter Row */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-rose-50 dark:border-rose-950/50">
                {/* Virtue Toggle */}
                <button
                  onClick={() => toggleExpand(item.id)}
                  className="text-xs text-rose-600 dark:text-rose-400 hover:text-rose-700 flex items-center gap-1 font-semibold"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>فضل هذا الذكر</span>
                  {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>

                {/* Counter & Action Button */}
                <div className="flex items-center gap-2">
                  {currentCount > 0 && !isDone && (
                    <button
                      onClick={() => handleResetDhikr(item.id)}
                      className="p-2 text-slate-400 hover:text-rose-600 rounded-xl"
                      title="إعادة تعيين العداد"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                  )}

                  <button
                    onClick={() => handleIncrement(item.id, item.targetCount)}
                    disabled={isDone}
                    className={`px-6 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all shadow-xs ${
                      isDone
                        ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-200 border border-rose-200 dark:border-rose-900/60 cursor-default'
                        : 'bg-rose-600 hover:bg-rose-700 active:scale-95 text-white shadow-rose-600/25'
                    }`}
                  >
                    {isDone ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-rose-600" />
                        <span>اكتمل ({currentCount}/{item.targetCount})</span>
                      </>
                    ) : (
                      <>
                        <span>تسبيح</span>
                        <span className="font-mono tabular-nums bg-white/20 px-2 py-0.5 rounded-md">
                          {currentCount} / {item.targetCount}
                        </span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Expanded Virtue Details */}
              {isExpanded && (
                <div className="mt-3 p-3.5 rounded-xl bg-rose-50/60 dark:bg-[#1a0f18] border border-rose-100 dark:border-rose-950/60 text-xs text-slate-700 dark:text-rose-200/90 leading-relaxed animate-in fade-in">
                  <div className="font-bold text-rose-700 dark:text-rose-300 mb-1 flex items-center gap-1.5">
                    <Award className="w-3.5 h-3.5" />
                    <span>الفضل والبركة:</span>
                  </div>
                  <p>{item.reward}</p>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
