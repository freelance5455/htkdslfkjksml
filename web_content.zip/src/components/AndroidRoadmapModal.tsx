/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, Smartphone, Shield, Terminal, FileCode, CheckCircle2, Copy, Check } from 'lucide-react';

interface AndroidRoadmapModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidRoadmapModal: React.FC<AndroidRoadmapModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'capacitor' | 'webview' | 'phone' | 'permissions'>('capacitor');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const capacitorCommands = `# 1. In your project directory:
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init ELYSIA com.elysia.assistant --web-dir dist

# 2. Build the web app bundle:
npm run build

# 3. Add the Android platform:
npx cap add android

# 4. Sync web assets into Android project:
npx cap sync android

# 5. Build debug APK using Gradle wrapper:
cd android
./gradlew assembleDebug

# Output APK location:
# android/app/build/outputs/apk/debug/app-debug.apk`;

  const manifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.elysia.assistant">

    <!-- Permissions for ELYSIA voice, internet and network state -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="ELYSIA"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/AppTheme"
        android:usesCleartextTraffic="false">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:screenOrientation="portrait"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale"
            android:theme="@style/AppTheme.NoActionBarLaunch">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

  const mainActivityKotlin = `package com.elysia.assistant

import android.os.Bundle
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import android.Manifest
import android.content.pm.PackageManager

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private val RECORD_AUDIO_REQUEST_CODE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Request runtime microphone permission
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) 
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this, 
                arrayOf(Manifest.permission.RECORD_AUDIO), 
                RECORD_AUDIO_REQUEST_CODE
            )
        }

        webView = findViewById(R.id.webview)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
        }

        // Grant WebRTC / Speech microphone permission to WebView
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                request.grant(request.resources)
            }
        }

        webView.webViewClient = WebViewClient()
        // Load production server or local assets
        webView.loadUrl("https://ais-pre-xxicklexmkmpomqvpsittu-727756775660.asia-southeast1.run.app")
    }
}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[88vh] bg-slate-900 border border-cyan-500/40 rounded-3xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <Smartphone className="w-5 h-5 text-cyan-400" />
            <div>
              <h2 className="text-sm sm:text-base font-orbitron font-bold text-slate-100 tracking-wider">
                Android APK Packaging Guide
              </h2>
              <p className="text-[11px] text-slate-400">Step-by-step roadmap to run ELYSIA natively on Android</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 overflow-x-auto text-xs font-rajdhani font-semibold">
          <button
            onClick={() => setActiveTab('capacitor')}
            className={`px-4 py-2.5 whitespace-nowrap border-b-2 transition-all ${
              activeTab === 'capacitor'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            1. Capacitor CLI (Recommended)
          </button>
          <button
            onClick={() => setActiveTab('webview')}
            className={`px-4 py-2.5 whitespace-nowrap border-b-2 transition-all ${
              activeTab === 'webview'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            2. Native Kotlin / WebView
          </button>
          <button
            onClick={() => setActiveTab('phone')}
            className={`px-4 py-2.5 whitespace-nowrap border-b-2 transition-all ${
              activeTab === 'phone'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            3. Build on Android Phone
          </button>
          <button
            onClick={() => setActiveTab('permissions')}
            className={`px-4 py-2.5 whitespace-nowrap border-b-2 transition-all ${
              activeTab === 'permissions'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            4. Permissions & Limits
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 text-xs text-slate-300 font-sans">
          {activeTab === 'capacitor' && (
            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-cyan-950/20 border border-cyan-500/20">
                <span className="font-semibold text-cyan-300">Fastest Path:</span> Turn this React + Three.js project into a real Android APK using Capacitor (100% free and open-source).
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-orbitron text-[11px] text-slate-400">Terminal Build Commands</span>
                  <button
                    onClick={() => handleCopy(capacitorCommands, 'cap')}
                    className="flex items-center gap-1 text-[11px] text-cyan-400 hover:text-cyan-300"
                  >
                    {copiedKey === 'cap' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedKey === 'cap' ? 'Copied' : 'Copy'}
                  </button>
                </div>
                <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-cyan-300 font-mono text-[11px] overflow-x-auto whitespace-pre">
                  {capacitorCommands}
                </pre>
              </div>

              <div className="space-y-1.5 text-slate-300">
                <p className="font-semibold text-slate-200">How to install the APK on your phone:</p>
                <ol className="list-decimal list-inside space-y-1 text-slate-400 pl-1">
                  <li>Transfer <code className="text-cyan-300">app-debug.apk</code> to your Android phone via USB, Google Drive, or Telegram.</li>
                  <li>On your phone, enable <em>Settings &gt; Security &gt; Install unknown apps</em>.</li>
                  <li>Tap the APK to install. Grant the microphone permission when prompted.</li>
                </ol>
              </div>
            </div>
          )}

          {activeTab === 'webview' && (
            <div className="space-y-3">
              <p className="text-slate-400 leading-relaxed">
                If building with Android Studio or a pure Kotlin project, use this <code className="text-cyan-300">AndroidManifest.xml</code> and <code className="text-cyan-300">MainActivity.kt</code> configuration to ensure WebRTC and speech recognition work correctly inside Android's WebView.
              </p>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-orbitron text-[11px] text-slate-400">AndroidManifest.xml</span>
                  <button
                    onClick={() => handleCopy(manifestXml, 'manifest')}
                    className="flex items-center gap-1 text-[11px] text-cyan-400 hover:text-cyan-300"
                  >
                    {copiedKey === 'manifest' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedKey === 'manifest' ? 'Copied' : 'Copy'}
                  </button>
                </div>
                <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-cyan-300 font-mono text-[11px] overflow-x-auto max-h-48 whitespace-pre">
                  {manifestXml}
                </pre>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-orbitron text-[11px] text-slate-400">MainActivity.kt</span>
                  <button
                    onClick={() => handleCopy(mainActivityKotlin, 'kt')}
                    className="flex items-center gap-1 text-[11px] text-cyan-400 hover:text-cyan-300"
                  >
                    {copiedKey === 'kt' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedKey === 'kt' ? 'Copied' : 'Copy'}
                  </button>
                </div>
                <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-cyan-300 font-mono text-[11px] overflow-x-auto max-h-48 whitespace-pre">
                  {mainActivityKotlin}
                </pre>
              </div>
            </div>
          )}

          {activeTab === 'phone' && (
            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <h3 className="font-semibold text-cyan-400 mb-1 flex items-center gap-1.5">
                  <Terminal className="w-4 h-4" />
                  Building entirely on an Android Phone (No PC Required)
                </h3>
                <p className="text-slate-400 leading-relaxed text-[11px]">
                  You can preview and build directly from an Android device using <strong>Termux</strong> (from F-Droid) or an on-device IDE such as <strong>Acode</strong>.
                </p>
              </div>

              <div className="space-y-2">
                <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
                  <span className="text-cyan-300 font-semibold">Step 1: Install Termux & Node.js</span>
                  <p className="text-[11px] text-slate-400 mt-1">In Termux, run:</p>
                  <code className="block bg-slate-900 p-2 rounded text-cyan-400 font-mono text-[11px] mt-1">
                    pkg update && pkg install nodejs-lts git
                  </code>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
                  <span className="text-cyan-300 font-semibold">Step 2: Preview in Chrome on Phone</span>
                  <p className="text-[11px] text-slate-400 mt-1">Clone or extract the project and run:</p>
                  <code className="block bg-slate-900 p-2 rounded text-cyan-400 font-mono text-[11px] mt-1">
                    npm install && npm run dev
                  </code>
                  <p className="text-[11px] text-slate-400 mt-1">Open <code>http://localhost:3000</code> in Chrome. It will run with full hardware acceleration and microphone access!</p>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
                  <span className="text-cyan-300 font-semibold">Step 3: Add to Home Screen (Instant App)</span>
                  <p className="text-[11px] text-slate-400 mt-1">
                    In Chrome on your phone, tap the three dots (&vellip;) and select <strong>"Add to Home Screen"</strong> / <strong>"Install app"</strong>. ELYSIA will launch full-screen like a native app without browser URL bars!
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'permissions' && (
            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-amber-950/20 border border-amber-500/30 text-amber-200">
                <div className="font-semibold flex items-center gap-1.5 mb-1">
                  <Shield className="w-4 h-4 text-amber-400" />
                  Honest Platform Capabilities & Security Boundaries
                </div>
                <p className="text-[11px] leading-relaxed text-amber-200/90">
                  As required by security guidelines, ELYSIA never makes false claims about unrestricted device control.
                </p>
              </div>

              <div className="space-y-2">
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                  <span className="font-semibold text-slate-200">Continuous Wake-Word ("Hey ELYSIA") in Background</span>
                  <p className="text-slate-400 text-[11px] mt-0.5">
                    Continuous background listening cannot run in a background web browser tab due to privacy and battery sandboxing. In native Android, background voice triggers require a designated Android Foreground Service with an ongoing notification icon and explicit <code className="text-cyan-300">RECORD_AUDIO</code> consent. ELYSIA provides responsive tap-to-talk to respect your battery and privacy.
                  </p>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                  <span className="font-semibold text-slate-200">WhatsApp & Messaging</span>
                  <p className="text-slate-400 text-[11px] mt-0.5">
                    ELYSIA drafts messages intelligently and provides one-tap review in WhatsApp (<code className="text-cyan-300">api.whatsapp.com/send?text=...</code>). It will never covertly send messages or read private messages without explicit authorization.
                  </p>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                  <span className="font-semibold text-slate-200">Zero Local Secret Storage</span>
                  <p className="text-slate-400 text-[11px] mt-0.5">
                    Your Gemini API key is protected securely on the backend server. No secret keys are stored in browser localStorage or bundled into client APK JavaScript files.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-orbitron font-semibold text-xs transition-colors"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
