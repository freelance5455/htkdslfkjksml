import React from "react";
import { Toolbar, MS_WORD_FONTS } from "./Toolbar";

interface RichTextToolbarProps {
  onFormat?: (command: string, value?: string) => void;
  onGenerateMindMap?: () => void;
  onGenerateAudioVideoMindMap?: () => void;
  isGeneratingMindMap?: boolean;
  hasAudioVideoMedia?: boolean;
  selectedFont?: string;
  onFontChange?: (font: string) => void;
}

export const RichTextToolbar: React.FC<RichTextToolbarProps> = ({
  onFormat,
  onGenerateMindMap,
  onGenerateAudioVideoMindMap,
  hasAudioVideoMedia = false,
  selectedFont = "Calibri, sans-serif",
  onFontChange,
}) => {
  return (
    <div className="relative z-10 w-full">
      <Toolbar
        onCommand={onFormat}
        selectedFont={selectedFont}
        onFontChange={onFontChange}
        onGenerateMindMap={onGenerateMindMap}
        hasAudioVideoMedia={hasAudioVideoMedia}
        onGenerateAudioVideoMindMap={onGenerateAudioVideoMindMap}
      />
    </div>
  );
};
