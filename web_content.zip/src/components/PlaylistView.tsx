import React, { useState, useRef } from 'react';
import {
  Plus,
  Trash2,
  Copy,
  VolumeX,
  Volume2,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Music,
  Grid as GridIcon,
  Radio,
  Sliders,
  MoreVertical,
  Edit2
} from 'lucide-react';
import { Project, Track, Clip, InstrumentType, ViewMode } from '../types/daw';
import { engine, PlayheadState } from '../audio/engine';
import { Knob } from './Knob';

interface PlaylistViewProps {
  project: Project;
  playhead: PlayheadState;
  selectedTrackId: string | null;
  selectedClipId: string | null;
  onSelectTrack: (trackId: string) => void;
  onSelectClip: (clipId: string) => void;
  onViewChange: (view: ViewMode) => void;
  onUpdateProject: (updater: (prev: Project) => Project) => void;
}

export const PlaylistView: React.FC<PlaylistViewProps> = ({
  project,
  playhead,
  selectedTrackId,
  selectedClipId,
  onSelectTrack,
  onSelectClip,
  onViewChange,
  onUpdateProject,
}) => {
  const [zoomLevel, setZoomLevel] = useState(48); // pixels per beat (default 48px, so 1 bar = 192px)
  const [snap, setSnap] = useState<number>(1); // snap in beats (1 = 1 beat, 4 = 1 bar, 0.5 = 1/8th)
  const [addTrackOpen, setAddTrackOpen] = useState(false);
  const timelineRef = useRef<HTMLDivElement | null>(null);

  const totalBeats = Math.max(project.loopEnd + 8, 32);
  const totalBars = Math.ceil(totalBeats / 4);

  // Seek timeline by clicking on ruler
  const handleRulerClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickedBeat = Math.max(0, clickX / zoomLevel);
    engine.seekBeat(Math.round(clickedBeat * 2) / 2);
  };

  // Add new track
  const handleAddTrack = (type: InstrumentType) => {
    const trackColors: Record<InstrumentType, string> = {
      drums: '#ff7700',
      synth: '#00e5ff',
      bass: '#e040fb',
      keys: '#ffca28',
    };

    const trackNames: Record<InstrumentType, string> = {
      drums: 'Drum Machine',
      synth: 'Poly Synth',
      bass: '808 Bass',
      keys: 'Electric Keys',
    };

    const newTrack: Track = {
      id: `trk_${Date.now()}`,
      name: `${trackNames[type]} ${project.tracks.length + 1}`,
      type,
      color: trackColors[type],
      volume: 0.85,
      pan: 0,
      muted: false,
      soloed: false,
      synthConfig: {
        osc1Type: type === 'bass' ? 'sine' : type === 'synth' ? 'sawtooth' : 'triangle',
        osc2Type: 'square',
        detune: type === 'synth' ? 10 : 0,
        osc2Mix: 0.3,
        filterCutoff: type === 'bass' ? 1200 : 4000,
        filterRes: 2,
        filterType: 'lowpass',
        attack: 0.01,
        decay: 0.3,
        sustain: 0.6,
        release: 0.3,
        glide: type === 'bass' ? 0.05 : 0,
      },
      fx: {
        eqLow: 0,
        eqMid: 0,
        eqHigh: 0,
        delayTime: 0.25,
        delayFeedback: 0.25,
        delayMix: 0.15,
        reverbDecay: 2.0,
        reverbMix: 0.2,
        distortionDrive: 1,
        distortionMix: 0.1,
      },
      clips: [
        {
          id: `clip_${Date.now()}`,
          trackId: `trk_${Date.now()}`,
          name: `${trackNames[type]} Pattern 1`,
          startBeat: 0,
          durationBeats: 4,
          color: trackColors[type],
          notes: type !== 'drums' ? [] : undefined,
          drumSteps: type === 'drums' ? [] : undefined,
        },
      ],
    };

    onUpdateProject(p => ({
      ...p,
      tracks: [...p.tracks, newTrack],
    }));
    onSelectTrack(newTrack.id);
    onSelectClip(newTrack.clips[0].id);
    setAddTrackOpen(false);
  };

  // Add Clip to track
  const handleAddClip = (trackId: string) => {
    const track = project.tracks.find(t => t.id === trackId);
    if (!track) return;

    // Find first free beat slot
    let lastBeat = 0;
    track.clips.forEach(c => {
      if (c.startBeat + c.durationBeats > lastBeat) {
        lastBeat = c.startBeat + c.durationBeats;
      }
    });

    const newClip: Clip = {
      id: `clip_${Date.now()}`,
      trackId,
      name: `${track.name} Pattern ${track.clips.length + 1}`,
      startBeat: lastBeat,
      durationBeats: 4,
      color: track.color,
      notes: track.type !== 'drums' ? [] : undefined,
      drumSteps: track.type === 'drums' ? [] : undefined,
    };

    onUpdateProject(p => ({
      ...p,
      tracks: p.tracks.map(t =>
        t.id === trackId ? { ...t, clips: [...t.clips, newClip] } : t
      ),
    }));
    onSelectClip(newClip.id);
  };

  // Duplicate Clip
  const handleDuplicateClip = (trackId: string, clipId: string) => {
    const track = project.tracks.find(t => t.id === trackId);
    if (!track) return;
    const clip = track.clips.find(c => c.id === clipId);
    if (!clip) return;

    const newClip: Clip = {
      ...clip,
      id: `clip_${Date.now()}`,
      name: `${clip.name} (Copy)`,
      startBeat: clip.startBeat + clip.durationBeats,
      notes: clip.notes ? clip.notes.map(n => ({ ...n, id: `n_${Date.now()}_${Math.random()}` })) : undefined,
      drumSteps: clip.drumSteps ? clip.drumSteps.map(s => ({ ...s })) : undefined,
    };

    onUpdateProject(p => ({
      ...p,
      tracks: p.tracks.map(t =>
        t.id === trackId ? { ...t, clips: [...t.clips, newClip] } : t
      ),
    }));
    onSelectClip(newClip.id);
  };

  // Delete Clip
  const handleDeleteClip = (trackId: string, clipId: string) => {
    onUpdateProject(p => ({
      ...p,
      tracks: p.tracks.map(t =>
        t.id === trackId ? { ...t, clips: t.clips.filter(c => c.id !== clipId) } : t
      ),
    }));
  };

  // Delete Track
  const handleDeleteTrack = (trackId: string) => {
    if (project.tracks.length <= 1) return; // Keep at least 1 track
    onUpdateProject(p => ({
      ...p,
      tracks: p.tracks.filter(t => t.id !== trackId),
    }));
  };

  // Drag Clip along timeline
  const [dragState, setDragState] = useState<{
    trackId: string;
    clipId: string;
    initialStartBeat: number;
    initialDuration: number;
    startX: number;
    isResizing: boolean;
  } | null>(null);

  const handleClipPointerDown = (
    e: React.PointerEvent,
    trackId: string,
    clip: Clip,
    isResizing: boolean
  ) => {
    e.stopPropagation();
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    onSelectTrack(trackId);
    onSelectClip(clip.id);

    setDragState({
      trackId,
      clipId: clip.id,
      initialStartBeat: clip.startBeat,
      initialDuration: clip.durationBeats,
      startX: e.clientX,
      isResizing,
    });
  };

  const handleClipPointerMove = (e: React.PointerEvent) => {
    if (!dragState) return;
    const dx = e.clientX - dragState.startX;
    const beatDelta = dx / zoomLevel;

    onUpdateProject(p => ({
      ...p,
      tracks: p.tracks.map(t => {
        if (t.id !== dragState.trackId) return t;
        return {
          ...t,
          clips: t.clips.map(c => {
            if (c.id !== dragState.clipId) return c;
            if (dragState.isResizing) {
              const rawDur = dragState.initialDuration + beatDelta;
              const snappedDur = Math.max(1, Math.round(rawDur / snap) * snap);
              return { ...c, durationBeats: snappedDur };
            } else {
              const rawStart = dragState.initialStartBeat + beatDelta;
              const snappedStart = Math.max(0, Math.round(rawStart / snap) * snap);
              return { ...c, startBeat: snappedStart };
            }
          }),
        };
      }),
    }));
  };

  const handleClipPointerUp = (e: React.PointerEvent) => {
    if (dragState) {
      try {
        (e.target as HTMLElement).releasePointerCapture(e.pointerId);
      } catch {
        // ignore
      }
      setDragState(null);
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-[#11141a] overflow-hidden select-none">
      {/* Playlist Sub-Toolbar */}
      <div className="h-10 bg-[#161a23] border-b border-[#252b37] px-4 flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2">
          {/* Add Track Button */}
          <div className="relative">
            <button
              onClick={() => setAddTrackOpen(!addTrackOpen)}
              className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-[#ff7700] hover:bg-[#ff8800] text-black font-semibold text-xs shadow-sm transition-colors"
            >
              <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>Add Track</span>
            </button>

            {addTrackOpen && (
              <div className="absolute left-0 top-full mt-1.5 w-48 bg-[#1e232e] border border-[#2f3747] rounded-xl shadow-xl py-1 z-50 text-xs">
                <button
                  onClick={() => handleAddTrack('drums')}
                  className="w-full text-left px-3 py-2 hover:bg-[#282e3c] flex items-center gap-2 text-[#ff7700]"
                >
                  <GridIcon className="w-4 h-4" />
                  <span className="font-medium text-slate-100">Drum Machine Rack</span>
                </button>
                <button
                  onClick={() => handleAddTrack('synth')}
                  className="w-full text-left px-3 py-2 hover:bg-[#282e3c] flex items-center gap-2 text-[#00e5ff]"
                >
                  <Music className="w-4 h-4" />
                  <span className="font-medium text-slate-100">Polyphonic Synthesizer</span>
                </button>
                <button
                  onClick={() => handleAddTrack('bass')}
                  className="w-full text-left px-3 py-2 hover:bg-[#282e3c] flex items-center gap-2 text-[#e040fb]"
                >
                  <Radio className="w-4 h-4" />
                  <span className="font-medium text-slate-100">808 Bass Synth</span>
                </button>
                <button
                  onClick={() => handleAddTrack('keys')}
                  className="w-full text-left px-3 py-2 hover:bg-[#282e3c] flex items-center gap-2 text-[#ffca28]"
                >
                  <Music className="w-4 h-4" />
                  <span className="font-medium text-slate-100">Electric Piano / Keys</span>
                </button>
              </div>
            )}
          </div>

          {/* Snap Selector */}
          <div className="flex items-center gap-1.5 bg-[#1e232e] border border-[#2f3747] rounded-lg px-2 py-1 text-xs">
            <span className="text-slate-400 font-medium">Snap:</span>
            <select
              value={snap}
              onChange={e => setSnap(Number(e.target.value))}
              className="bg-transparent text-slate-200 font-semibold focus:outline-none cursor-pointer"
            >
              <option value="4" className="bg-[#1e232e]">1 Bar</option>
              <option value="2" className="bg-[#1e232e]">1/2 Bar</option>
              <option value="1" className="bg-[#1e232e]">1 Beat</option>
              <option value="0.5" className="bg-[#1e232e]">1/2 Beat (1/8)</option>
              <option value="0.25" className="bg-[#1e232e]">1/4 Beat (1/16)</option>
            </select>
          </div>
        </div>

        {/* Zoom Controls */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setZoomLevel(z => Math.max(24, z - 8))}
            className="p-1 rounded text-slate-400 hover:text-slate-100 hover:bg-[#232936]"
            title="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <span className="text-[10px] font-mono text-slate-400 tabular-nums w-8 text-center">
            {Math.round((zoomLevel / 48) * 100)}%
          </span>
          <button
            onClick={() => setZoomLevel(z => Math.min(96, z + 8))}
            className="p-1 rounded text-slate-400 hover:text-slate-100 hover:bg-[#232936]"
            title="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Arranger Body: Left Headers + Right Timeline Canvas */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Track Header Column (Fixed width: 220px) */}
        <div className="w-44 sm:w-56 bg-[#161922] border-r border-[#262c38] flex flex-col shrink-0 select-none">
          {/* Top empty cell matching ruler height */}
          <div className="h-8 border-b border-[#262c38] px-3 flex items-center justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            <span>TRACKS ({project.tracks.length})</span>
          </div>

          {/* Track Headers List */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden">
            {project.tracks.map((track) => {
              const isSelected = selectedTrackId === track.id;

              return (
                <div
                  key={track.id}
                  onClick={() => onSelectTrack(track.id)}
                  className={`h-24 border-b border-[#242936] px-2.5 py-1.5 flex flex-col justify-between transition-colors cursor-pointer relative group ${
                    isSelected ? 'bg-[#212634]' : 'hover:bg-[#1a1f2b]'
                  }`}
                >
                  {/* Color strip accent */}
                  <div
                    className="absolute left-0 top-0 bottom-0 w-1"
                    style={{ backgroundColor: track.color }}
                  />

                  {/* Top row: Name & Track Type Badge */}
                  <div className="flex items-center justify-between pl-1">
                    <div className="flex items-center gap-1.5 truncate">
                      {track.type === 'drums' ? (
                        <GridIcon className="w-3.5 h-3.5 shrink-0" style={{ color: track.color }} />
                      ) : (
                        <Music className="w-3.5 h-3.5 shrink-0" style={{ color: track.color }} />
                      )}
                      <span className="font-semibold text-xs text-slate-100 truncate">
                        {track.name}
                      </span>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleAddClip(track.id);
                        }}
                        className="p-1 rounded text-slate-400 hover:text-white hover:bg-[#2e3646]"
                        title="Add Clip"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteTrack(track.id);
                        }}
                        className="p-1 rounded text-slate-500 hover:text-red-400 hover:bg-[#2e3646]"
                        title="Delete Track"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>

                  {/* Middle row: Mute & Solo, Volume Fader */}
                  <div className="flex items-center gap-2 pl-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onUpdateProject(p => ({
                          ...p,
                          tracks: p.tracks.map(t =>
                            t.id === track.id ? { ...t, muted: !t.muted } : t
                          ),
                        }));
                      }}
                      className={`w-6 h-5 rounded text-[10px] font-bold transition-colors ${
                        track.muted
                          ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                          : 'bg-[#262c3a] text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      M
                    </button>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onUpdateProject(p => ({
                          ...p,
                          tracks: p.tracks.map(t =>
                            t.id === track.id ? { ...t, soloed: !t.soloed } : t
                          ),
                        }));
                      }}
                      className={`w-6 h-5 rounded text-[10px] font-bold transition-colors ${
                        track.soloed
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                          : 'bg-[#262c3a] text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      S
                    </button>

                    {/* Volume Slider */}
                    <div className="flex-1 flex items-center gap-1.5" onClick={e => e.stopPropagation()}>
                      <input
                        type="range"
                        min="0"
                        max="1.2"
                        step="0.05"
                        value={track.volume}
                        onChange={(e) => {
                          const val = Number(e.target.value);
                          onUpdateProject(p => ({
                            ...p,
                            tracks: p.tracks.map(t =>
                              t.id === track.id ? { ...t, volume: val } : t
                            ),
                          }));
                        }}
                        className="w-full h-1 bg-[#282f3f] rounded-lg appearance-none cursor-pointer accent-[#ff7700]"
                      />
                      <span className="text-[9px] font-mono text-slate-400 tabular-nums w-6">
                        {Math.round(track.volume * 100)}%
                      </span>
                    </div>
                  </div>

                  {/* Bottom row: Edit in Piano Roll / Drum Sequencer shortcut */}
                  <div className="flex items-center justify-between pl-1 text-[10px]">
                    <span className="text-slate-400">{track.clips.length} clip{track.clips.length !== 1 ? 's' : ''}</span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectTrack(track.id);
                        if (track.clips.length > 0) {
                          onSelectClip(track.clips[0].id);
                        }
                        if (track.type === 'drums') {
                          onViewChange('stepseq');
                        } else {
                          onViewChange('pianoroll');
                        }
                      }}
                      className="px-2 py-0.5 rounded bg-[#282f3f] hover:bg-[#343d52] text-slate-200 font-medium transition-colors"
                    >
                      Edit Notes →
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Timeline Canvas (Scrollable horizontal & vertical) */}
        <div
          ref={timelineRef}
          className="flex-1 overflow-x-auto overflow-y-auto bg-[#101319] relative select-none"
        >
          <div
            style={{ width: totalBeats * zoomLevel }}
            className="min-h-full flex flex-col relative"
          >
            {/* Top Bar Ruler */}
            <div
              onClick={handleRulerClick}
              className="h-8 bg-[#181c26] border-b border-[#262c38] sticky top-0 z-20 flex cursor-pointer"
            >
              {Array.from({ length: totalBars }).map((_, barIdx) => (
                <div
                  key={barIdx}
                  style={{ width: 4 * zoomLevel }}
                  className="h-full border-r border-[#262c38] px-2 flex items-center text-[10px] font-mono text-slate-400 tabular-nums shrink-0"
                >
                  <span className="font-bold text-slate-300">{barIdx + 1}</span>
                  <div className="flex-1 flex justify-evenly opacity-30">
                    <span>.</span>
                    <span>.</span>
                    <span>.</span>
                  </div>
                </div>
              ))}

              {/* Loop Bracket Visualization */}
              {project.isLooping && (
                <div
                  className="absolute top-0 bottom-0 bg-[#ff7700]/15 border-l-2 border-r-2 border-[#ff7700] pointer-events-none"
                  style={{
                    left: project.loopStart * zoomLevel,
                    width: (project.loopEnd - project.loopStart) * zoomLevel,
                  }}
                >
                  <span className="absolute top-0.5 left-1 text-[9px] font-mono font-bold text-[#ff7700]">
                    LOOP
                  </span>
                </div>
              )}
            </div>

            {/* Playhead Cursor Line */}
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-[#ff1744] z-30 pointer-events-none shadow-[0_0_8px_rgba(255,23,68,0.8)]"
              style={{ left: playhead.currentBeat * zoomLevel }}
            >
              {/* Playhead arrow head */}
              <div className="w-3 h-3 bg-[#ff1744] -ml-[5px] rotate-45 transform origin-center shadow-sm" />
            </div>

            {/* Track Lanes */}
            <div className="flex-1 relative">
              {project.tracks.map((track) => (
                <div
                  key={track.id}
                  className="h-24 border-b border-[#1c212c] relative flex items-center"
                  style={{ width: totalBeats * zoomLevel }}
                >
                  {/* Background grid lines per beat */}
                  <div className="absolute inset-0 flex pointer-events-none">
                    {Array.from({ length: totalBeats }).map((_, beatIdx) => (
                      <div
                        key={beatIdx}
                        style={{ width: zoomLevel }}
                        className={`h-full border-r ${
                          beatIdx % 4 === 3
                            ? 'border-[#262c38]'
                            : 'border-[#171c26]'
                        }`}
                      />
                    ))}
                  </div>

                  {/* Render Clips */}
                  {track.clips.map((clip) => {
                    const isClipSelected = selectedClipId === clip.id;
                    const clipWidth = clip.durationBeats * zoomLevel;
                    const clipLeft = clip.startBeat * zoomLevel;

                    return (
                      <div
                        key={clip.id}
                        onPointerDown={(e) => handleClipPointerDown(e, track.id, clip, false)}
                        onPointerMove={handleClipPointerMove}
                        onPointerUp={handleClipPointerUp}
                        onDoubleClick={() => {
                          onSelectTrack(track.id);
                          onSelectClip(clip.id);
                          if (track.type === 'drums') {
                            onViewChange('stepseq');
                          } else {
                            onViewChange('pianoroll');
                          }
                        }}
                        style={{
                          left: clipLeft,
                          width: clipWidth,
                          backgroundColor: `${clip.color}22`,
                          borderColor: isClipSelected ? '#ffffff' : clip.color,
                        }}
                        className={`absolute top-2 bottom-2 rounded-lg border-2 p-1.5 flex flex-col justify-between cursor-grab active:cursor-grabbing transition-shadow z-10 group ${
                          isClipSelected ? 'shadow-lg shadow-black/60 ring-2 ring-white/40' : 'hover:brightness-110'
                        }`}
                      >
                        {/* Clip Header */}
                        <div className="flex items-center justify-between text-[11px] font-bold text-white pointer-events-none truncate">
                          <span className="truncate">{clip.name}</span>
                          <span className="text-[9px] font-mono opacity-70">
                            {clip.durationBeats}b
                          </span>
                        </div>

                        {/* Mini Notes / Pattern Visual Preview */}
                        <div className="flex-1 my-1 rounded bg-black/30 overflow-hidden relative flex items-center px-1 pointer-events-none">
                          {clip.notes && clip.notes.length > 0 ? (
                            <div className="w-full h-full relative">
                              {clip.notes.map((n) => {
                                const relLeft = (n.startBeat / clip.durationBeats) * 100;
                                const relWidth = Math.max(2, (n.durationBeats / clip.durationBeats) * 100);
                                const relTop = 100 - ((n.pitch - 36) / 48) * 100;
                                return (
                                  <div
                                    key={n.id}
                                    className="absolute h-1.5 rounded-sm"
                                    style={{
                                      left: `${relLeft}%`,
                                      width: `${relWidth}%`,
                                      top: `${Math.max(5, Math.min(85, relTop))}%`,
                                      backgroundColor: clip.color,
                                    }}
                                  />
                                );
                              })}
                            </div>
                          ) : clip.drumSteps && clip.drumSteps.length > 0 ? (
                            <div className="w-full flex items-center justify-between px-0.5">
                              {Array.from({ length: 16 }).map((_, stepIdx) => {
                                const hasStep = clip.drumSteps?.some(s => s.step === stepIdx);
                                return (
                                  <div
                                    key={stepIdx}
                                    className={`w-1.5 h-3 rounded-sm ${
                                      hasStep ? 'bg-[#ff7700]' : 'bg-white/10'
                                    }`}
                                  />
                                );
                              })}
                            </div>
                          ) : (
                            <span className="text-[9px] text-slate-500 italic">Empty clip (double-click to edit)</span>
                          )}
                        </div>

                        {/* Quick Action Buttons on Hover */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDuplicateClip(track.id, clip.id);
                              }}
                              className="p-1 rounded bg-[#1e232e] text-slate-300 hover:text-white"
                              title="Duplicate Clip"
                            >
                              <Copy className="w-3 h-3" />
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteClip(track.id, clip.id);
                              }}
                              className="p-1 rounded bg-[#1e232e] text-slate-400 hover:text-red-400"
                              title="Delete Clip"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>

                          {/* Right Resize Handle */}
                          <div
                            onPointerDown={(e) => handleClipPointerDown(e, track.id, clip, true)}
                            className="w-3 h-full cursor-ew-resize flex items-center justify-center opacity-60 hover:opacity-100"
                            title="Resize duration"
                          >
                            <div className="w-1 h-3 rounded bg-white" />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
