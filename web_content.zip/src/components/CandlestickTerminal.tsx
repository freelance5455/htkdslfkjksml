"use client";

import React, { useState, useMemo } from "react";
import {
  OHLCVCandle,
  CoinTechnicalAnalysis,
  calculateEMA,
  calculateVWAPSeries,
  formatPriceNumber,
} from "../services/technicalEngine";
import { TradeTapeExecution, OrderBookLevel } from "../services/tradeTapeService";
import {
  Activity,
  TrendingUp,
  TrendingDown,
  Layers,
  Zap,
  ShieldAlert,
  Target,
} from "lucide-react";

interface CandlestickTerminalProps {
  coin: CoinTechnicalAnalysis;
  candles: OHLCVCandle[];
  orderBook: {
    symbol: string;
    midPrice: number;
    spreadPct: number;
    asks: OrderBookLevel[];
    bids: OrderBookLevel[];
  };
  tradeTape: TradeTapeExecution[];
  onQuickOrder: (side: "LONG" | "SHORT") => void;
}

export function CandlestickTerminal({
  coin,
  candles,
  orderBook,
  tradeTape,
  onQuickOrder,
}: CandlestickTerminalProps) {
  const [timeframe, setTimeframe] = useState<"1m" | "5m" | "15m" | "1H" | "4H">("5m");
  const [showEmaRibbon, setShowEmaRibbon] = useState(true);
  const [showVwapLine, setShowVwapLine] = useState(true);
  const [showVolumeProfile, setShowVolumeProfile] = useState(true);
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);

  const visibleCandles = useMemo(() => {
    const safe = Array.isArray(candles) ? candles : [];
    return safe.slice(-72); // Display last 72 candles for crisp institutional clarity
  }, [candles]);

  const chartGeometry = useMemo(() => {
    if (visibleCandles.length === 0) return null;
    const closes = visibleCandles.map((c) => c.close);
    const ema20 = calculateEMA(closes, 9);
    const ema50 = calculateEMA(closes, 20);
    const vwapSeries = calculateVWAPSeries(visibleCandles);

    let minPrice = Infinity;
    let maxPrice = -Infinity;
    let maxVol = 0;

    for (const c of visibleCandles) {
      if (c.low < minPrice) minPrice = c.low;
      if (c.high > maxPrice) maxPrice = c.high;
      if (c.volume > maxVol) maxVol = c.volume;
    }

    const padding = (maxPrice - minPrice) * 0.08 || minPrice * 0.01;
    const lowBound = minPrice - padding;
    const highBound = maxPrice + padding;
    const priceRange = Math.max(highBound - lowBound, 0.0001);

    return {
      lowBound,
      highBound,
      priceRange,
      maxVol: Math.max(maxVol, 1),
      ema20,
      ema50,
      vwapSeries,
    };
  }, [visibleCandles]);

  const safeAsks = Array.isArray(orderBook?.asks) ? orderBook.asks.slice(0, 10) : [];
  const safeBids = Array.isArray(orderBook?.bids) ? orderBook.bids.slice(0, 10) : [];
  const maxBookTotal = Math.max(
    1,
    ...safeAsks.map((a) => a.totalUsdt),
    ...safeBids.map((b) => b.totalUsdt)
  );

  const totalBidVol = safeBids.reduce((s, b) => s + b.totalUsdt, 0);
  const totalAskVol = safeAsks.reduce((s, a) => s + a.totalUsdt, 0);
  const bidRatioPct = Math.round(
    (totalBidVol / Math.max(1, totalBidVol + totalAskVol)) * 100
  );

  const hoveredCandle =
    hoverIdx !== null && visibleCandles[hoverIdx]
      ? visibleCandles[hoverIdx]
      : visibleCandles[visibleCandles.length - 1];

  return (
    <div dir="rtl" className="space-y-4">
      {/* Top Instrument Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-[#222B3A] bg-[#11161F] p-4">
        <div className="flex items-center gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-xl font-bold text-[#F1F5F9]">
                {coin.symbol}
              </span>
              <span className="rounded bg-[#3B82F6]/15 px-2 py-0.5 text-xs font-semibold text-[#3B82F6]">
                Binance Public + CoinCap WSS
              </span>
            </div>
            <p className="text-xs text-[#94A3B8]">
              סנכרון חי לנרות OHLCV (200 תקופות) מ-Binance/CoinGecko ופרופיל נפח מוסדי
            </p>
          </div>

          <div className="h-8 w-px bg-[#222B3A]" />

          <div>
            <div className="font-mono text-2xl font-extrabold text-[#F1F5F9]">
              ${formatPriceNumber(coin.currentPrice)}
            </div>
            <div
              className={`font-mono text-xs font-semibold ${
                coin.change24hPct >= 0 ? "text-[#00E676]" : "text-[#FF3B69]"
              }`}
            >
              {coin.change24hPct >= 0 ? "+" : ""}
              {coin.change24hPct}% (24ש&apos;)
            </div>
          </div>

          <div className="hidden sm:block h-8 w-px bg-[#222B3A]" />

          <div className="hidden md:flex items-center gap-5 text-xs">
            <div>
              <span className="text-[#64748B] block">גבוה 24ש&apos;</span>
              <span className="font-mono font-semibold text-[#F1F5F9]">
                ${formatPriceNumber(coin.high24h)}
              </span>
            </div>
            <div>
              <span className="text-[#64748B] block">נמוך 24ש&apos;</span>
              <span className="font-mono font-semibold text-[#F1F5F9]">
                ${formatPriceNumber(coin.low24h)}
              </span>
            </div>
            <div>
              <span className="text-[#64748B] block">POC (מוקד נפח)</span>
              <span className="font-mono font-semibold text-[#00E676]">
                ${formatPriceNumber(coin.volumeProfile?.pocPrice || coin.currentPrice)}
              </span>
            </div>
            <div>
              <span className="text-[#64748B] block">ATR (14) תנודתיות</span>
              <span className="font-mono font-semibold text-[#F59E0B]">
                ${formatPriceNumber(coin.atr14)} ({coin.atrPct}%)
              </span>
            </div>
          </div>
        </div>

        {/* Timeframe & Layer Toggles */}
        <div className="flex flex-wrap items-center gap-2">
          {(["1m", "5m", "15m", "1H", "4H"] as const).map((tf) => (
            <button
              key={tf}
              type="button"
              onClick={() => setTimeframe(tf)}
              className={`rounded-lg px-2.5 py-1.5 font-mono text-xs font-semibold transition ${
                timeframe === tf
                  ? "bg-[#3B82F6] text-white"
                  : "bg-[#181F2C] text-[#94A3B8] hover:text-white"
              }`}
            >
              {tf}
            </button>
          ))}
          <button
            type="button"
            onClick={() => setShowVwapLine(!showVwapLine)}
            className={`rounded-lg border px-2.5 py-1.5 text-xs font-semibold transition ${
              showVwapLine
                ? "border-[#A855F7]/60 bg-[#A855F7]/15 text-[#A855F7]"
                : "border-[#222B3A] bg-[#181F2C] text-[#94A3B8]"
            }`}
          >
            VWAP מוסדי (${formatPriceNumber(coin.vwap || coin.currentPrice)})
          </button>
          <button
            type="button"
            onClick={() => setShowEmaRibbon(!showEmaRibbon)}
            className={`rounded-lg border px-2.5 py-1.5 text-xs font-semibold transition ${
              showEmaRibbon
                ? "border-[#3B82F6]/60 bg-[#3B82F6]/15 text-[#3B82F6]"
                : "border-[#222B3A] bg-[#181F2C] text-[#94A3B8]"
            }`}
          >
            רצועת EMA 9/20
          </button>
          <button
            type="button"
            onClick={() => setShowVolumeProfile(!showVolumeProfile)}
            className={`rounded-lg border px-2.5 py-1.5 text-xs font-semibold transition ${
              showVolumeProfile
                ? "border-[#00E676]/60 bg-[#00E676]/15 text-[#00E676]"
                : "border-[#222B3A] bg-[#181F2C] text-[#94A3B8]"
            }`}
          >
            Volume Profile POC
          </button>
        </div>
      </div>

      {/* Main 3-Column Trading Grid: Chart (Left/Center) + OrderBook + TradeTape */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
        {/* Candlestick SVG Chart Canvas (7 cols) */}
        <div className="lg:col-span-7 flex flex-col justify-between rounded-xl border border-[#222B3A] bg-[#11161F] p-4">
          <div>
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-[#222B3A] pb-2.5 text-xs">
              <div className="flex items-center gap-4 font-mono">
                <span className="text-[#94A3B8]">
                  פתיחה:{" "}
                  <strong className="text-[#F1F5F9]">
                    ${formatPriceNumber(hoveredCandle?.open || 0)}
                  </strong>
                </span>
                <span className="text-[#94A3B8]">
                  גבוה:{" "}
                  <strong className="text-[#00E676]">
                    ${formatPriceNumber(hoveredCandle?.high || 0)}
                  </strong>
                </span>
                <span className="text-[#94A3B8]">
                  נמוך:{" "}
                  <strong className="text-[#FF3B69]">
                    ${formatPriceNumber(hoveredCandle?.low || 0)}
                  </strong>
                </span>
                <span className="text-[#94A3B8]">
                  סגירה:{" "}
                  <strong className="text-[#F1F5F9]">
                    ${formatPriceNumber(hoveredCandle?.close || 0)}
                  </strong>
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className="inline-flex items-center gap-1 text-[#3B82F6]">
                  <span className="h-2 w-2 rounded-full bg-[#3B82F6]" />
                  EMA20: ${formatPriceNumber(coin.ema.ema20)}
                </span>
                <span className="inline-flex items-center gap-1 text-[#F59E0B]">
                  <span className="h-2 w-2 rounded-full bg-[#F59E0B]" />
                  EMA50: ${formatPriceNumber(coin.ema.ema50)}
                </span>
              </div>
            </div>

            {chartGeometry ? (
              <div className="relative h-[350px] w-full select-none overflow-hidden rounded-lg bg-[#0B0E14] p-2">
                <svg
                  viewBox="0 0 800 320"
                  className="h-full w-full"
                  onMouseLeave={() => setHoverIdx(null)}
                >
                  {/* Horizontal Grid Lines */}
                  {[0.15, 0.35, 0.55, 0.75, 0.9].map((ratio, idx) => {
                    const y = ratio * 270;
                    const priceAtLine =
                      chartGeometry.highBound -
                      ratio * chartGeometry.priceRange;
                    return (
                      <g key={idx}>
                        <line
                          x1={0}
                          y1={y}
                          x2={730}
                          y2={y}
                          stroke="#181F2C"
                          strokeDasharray="3 3"
                          strokeWidth="1"
                        />
                        <text
                          x={735}
                          y={y + 4}
                          fill="#64748B"
                          fontSize="10"
                          fontFamily="monospace"
                        >
                          ${formatPriceNumber(priceAtLine)}
                        </text>
                      </g>
                    );
                  })}

                  {/* Volume Profile POC Horizontal Line */}
                  {showVolumeProfile && coin.volumeProfile?.pocPrice > 0 && (
                    <g>
                      {(() => {
                        const pocY =
                          ((chartGeometry.highBound -
                            coin.volumeProfile.pocPrice) /
                            chartGeometry.priceRange) *
                          270;
                        const clampedY = Math.max(12, Math.min(265, pocY));
                        return (
                          <>
                            <line
                              x1={0}
                              y1={clampedY}
                              x2={725}
                              y2={clampedY}
                              stroke="#00E676"
                              strokeWidth="1.5"
                              strokeDasharray="6 4"
                            />
                            <rect
                              x={8}
                              y={clampedY - 10}
                              width={118}
                              height={18}
                              rx={4}
                              fill="#00E676"
                              fillOpacity={0.18}
                            />
                            <text
                              x={14}
                              y={clampedY + 3}
                              fill="#00E676"
                              fontSize="10"
                              fontWeight="bold"
                              fontFamily="monospace"
                            >
                              POC ${formatPriceNumber(coin.volumeProfile.pocPrice)}
                            </text>
                          </>
                        );
                      })()}
                    </g>
                  )}

                  {/* Intraday VWAP Polyline */}
                  {showVwapLine && chartGeometry.vwapSeries && (
                    <polyline
                      fill="none"
                      stroke="#A855F7"
                      strokeWidth="2.1"
                      strokeDasharray="4 2"
                      points={chartGeometry.vwapSeries
                        .map((val, i) => {
                          const x =
                            15 +
                            (i / Math.max(1, visibleCandles.length - 1)) * 700;
                          const y =
                            ((chartGeometry.highBound - val) /
                              chartGeometry.priceRange) *
                            270;
                          return `${x},${Math.max(5, Math.min(268, y))}`;
                        })
                        .join(" ")}
                    />
                  )}

                  {/* EMA 9 & EMA 20 Polylines */}
                  {showEmaRibbon && (
                    <>
                      <polyline
                        fill="none"
                        stroke="#3B82F6"
                        strokeWidth="1.8"
                        points={chartGeometry.ema20
                          .map((val, i) => {
                            const x =
                              15 +
                              (i / Math.max(1, visibleCandles.length - 1)) *
                                700;
                            const y =
                              ((chartGeometry.highBound - val) /
                                chartGeometry.priceRange) *
                              270;
                            return `${x},${Math.max(5, Math.min(268, y))}`;
                          })
                          .join(" ")}
                      />
                      <polyline
                        fill="none"
                        stroke="#F59E0B"
                        strokeWidth="1.8"
                        points={chartGeometry.ema50
                          .map((val, i) => {
                            const x =
                              15 +
                              (i / Math.max(1, visibleCandles.length - 1)) *
                                700;
                            const y =
                              ((chartGeometry.highBound - val) /
                                chartGeometry.priceRange) *
                              270;
                            return `${x},${Math.max(5, Math.min(268, y))}`;
                          })
                          .join(" ")}
                      />
                    </>
                  )}

                  {/* Candles + Volume Bars */}
                  {visibleCandles.map((c, idx) => {
                    const x =
                      15 +
                      (idx / Math.max(1, visibleCandles.length - 1)) * 700;
                    const isBull = c.close >= c.open;
                    const color = isBull ? "#00E676" : "#FF3B69";

                    const highY =
                      ((chartGeometry.highBound - c.high) /
                        chartGeometry.priceRange) *
                      270;
                    const lowY =
                      ((chartGeometry.highBound - c.low) /
                        chartGeometry.priceRange) *
                      270;
                    const openY =
                      ((chartGeometry.highBound - c.open) /
                        chartGeometry.priceRange) *
                      270;
                    const closeY =
                      ((chartGeometry.highBound - c.close) /
                        chartGeometry.priceRange) *
                      270;

                    const bodyTop = Math.min(openY, closeY);
                    const bodyHeight = Math.max(2.2, Math.abs(closeY - openY));

                    const volHeight =
                      (c.volume / chartGeometry.maxVol) * 40;

                    return (
                      <g
                        key={c.time + "-" + idx}
                        onMouseEnter={() => setHoverIdx(idx)}
                        className="cursor-crosshair"
                      >
                        {/* Wick */}
                        <line
                          x1={x}
                          y1={highY}
                          x2={x}
                          y2={lowY}
                          stroke={color}
                          strokeWidth="1.2"
                        />
                        {/* Candle Body */}
                        <rect
                          x={x - 3.2}
                          y={bodyTop}
                          width={6.4}
                          height={bodyHeight}
                          fill={color}
                          rx={1}
                        />
                        {/* Bottom Volume Histogram */}
                        <rect
                          x={x - 3}
                          y={318 - volHeight}
                          width={6}
                          height={volHeight}
                          fill={color}
                          fillOpacity={0.28}
                        />
                      </g>
                    );
                  })}
                </svg>
              </div>
            ) : null}
          </div>

          {/* Bottom Action Bar inside Chart Card */}
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-lg bg-[#0B0E14] p-3">
            <div className="flex items-center gap-4 text-xs">
              <span className="flex items-center gap-1 text-[#00E676]">
                <Target className="h-4 w-4" />
                יעד רווח (TP1):{" "}
                <strong className="font-mono">
                  ${formatPriceNumber(coin.takeProfit1)}
                </strong>
              </span>
              <span className="flex items-center gap-1 text-[#FF3B69]">
                <ShieldAlert className="h-4 w-4" />
                קטיעת הפסד (SL):{" "}
                <strong className="font-mono">
                  ${formatPriceNumber(coin.stopLoss)}
                </strong>
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => onQuickOrder("LONG")}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#00E676] px-4 py-2 text-xs font-bold text-[#0B0E14] transition hover:brightness-110"
              >
                <TrendingUp className="h-4 w-4" />
                פתח לונג (LONG) בדמו
              </button>
              <button
                type="button"
                onClick={() => onQuickOrder("SHORT")}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#FF3B69] px-4 py-2 text-xs font-bold text-white transition hover:brightness-110"
              >
                <TrendingDown className="h-4 w-4" />
                פתח שורט (SHORT) בדמו
              </button>
            </div>
          </div>
        </div>

        {/* Live Order Book Depth (Bids & Asks) (2.5 cols) */}
        <div className="lg:col-span-2 flex flex-col justify-between rounded-xl border border-[#222B3A] bg-[#11161F] p-3.5">
          <div>
            <div className="mb-2 flex items-center justify-between border-b border-[#222B3A] pb-2">
              <h3 className="flex items-center gap-1.5 text-sm font-bold text-[#F1F5F9]">
                <Layers className="h-4 w-4 text-[#3B82F6]" />
                ספר פקודות (Order Book)
              </h3>
              <span className="font-mono text-[11px] text-[#94A3B8]">
                מרווח {orderBook?.spreadPct || 0.04}%
              </span>
            </div>

            {/* Bid vs Ask Ratio Bar */}
            <div className="mb-3">
              <div className="mb-1 flex justify-between font-mono text-[11px]">
                <span className="text-[#00E676]">קונים {bidRatioPct}%</span>
                <span className="text-[#FF3B69]">
                  מוכרים {100 - bidRatioPct}%
                </span>
              </div>
              <div className="flex h-1.5 w-full overflow-hidden rounded-full bg-[#FF3B69]/40">
                <div
                  className="bg-[#00E676] transition-all duration-300"
                  style={{ width: `${bidRatioPct}%` }}
                />
              </div>
            </div>

            <div className="grid grid-cols-3 text-[10px] font-semibold text-[#64748B] pb-1">
              <span>מחיר (USDT)</span>
              <span className="text-center">כמות</span>
              <span className="text-left">סה״כ ($)</span>
            </div>

            {/* Asks (Sells) */}
            <div className="space-y-1">
              {safeAsks
                .slice()
                .reverse()
                .slice(0, 7)
                .map((ask, i) => {
                  const widthPct = Math.min(
                    100,
                    Math.round((ask.totalUsdt / maxBookTotal) * 100)
                  );
                  return (
                    <div
                      key={`ask-${i}`}
                      className="relative grid grid-cols-3 items-center py-0.5 font-mono text-[11px]"
                    >
                      <div
                        className="pointer-events-none absolute inset-y-0 left-0 bg-[#FF3B69]/15"
                        style={{ width: `${widthPct}%` }}
                      />
                      <span className="relative z-10 text-[#FF3B69]">
                        {formatPriceNumber(ask.price)}
                      </span>
                      <span className="relative z-10 text-center text-[#F1F5F9]">
                        {ask.size}
                      </span>
                      <span className="relative z-10 text-left text-[#94A3B8]">
                        {(ask.totalUsdt / 1000).toFixed(1)}K
                      </span>
                    </div>
                  );
                })}
            </div>

            {/* Mid Price Divider */}
            <div className="my-2 flex items-center justify-between rounded bg-[#0B0E14] px-2.5 py-1.5 font-mono">
              <span className="text-sm font-extrabold text-[#F1F5F9]">
                ${formatPriceNumber(coin.currentPrice)}
              </span>
              <span className="text-[10px] text-[#00E676]">מחיר הוגן (Mark)</span>
            </div>

            {/* Bids (Buys) */}
            <div className="space-y-1">
              {safeBids.slice(0, 7).map((bid, i) => {
                const widthPct = Math.min(
                  100,
                  Math.round((bid.totalUsdt / maxBookTotal) * 100)
                );
                return (
                  <div
                    key={`bid-${i}`}
                    className="relative grid grid-cols-3 items-center py-0.5 font-mono text-[11px]"
                  >
                    <div
                      className="pointer-events-none absolute inset-y-0 left-0 bg-[#00E676]/15"
                      style={{ width: `${widthPct}%` }}
                    />
                    <span className="relative z-10 text-[#00E676]">
                      {formatPriceNumber(bid.price)}
                    </span>
                    <span className="relative z-10 text-center text-[#F1F5F9]">
                      {bid.size}
                    </span>
                    <span className="relative z-10 text-left text-[#94A3B8]">
                      {(bid.totalUsdt / 1000).toFixed(1)}K
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Real-Time Execution Trade Tape (3 cols) */}
        <div className="lg:col-span-3 flex flex-col justify-between rounded-xl border border-[#222B3A] bg-[#11161F] p-3.5">
          <div>
            <div className="mb-2 flex items-center justify-between border-b border-[#222B3A] pb-2">
              <h3 className="flex items-center gap-1.5 text-sm font-bold text-[#F1F5F9]">
                <Activity className="h-4 w-4 text-[#00E676]" />
                סרט עסקאות בזמן אמת (Trade Tape)
              </h3>
              <span className="inline-flex items-center gap-1 rounded-full bg-[#00E676]/15 px-2 py-0.5 text-[10px] font-semibold text-[#00E676]">
                <Zap className="h-3 w-3" />
                WebSocket חי
              </span>
            </div>

            <div className="grid grid-cols-4 text-[10px] font-semibold text-[#64748B] pb-1.5">
              <span>כיוון</span>
              <span>מחיר ($)</span>
              <span className="text-center">שווי ($)</span>
              <span className="text-left">שעה</span>
            </div>

            <div className="max-h-[345px] space-y-1 overflow-y-auto pr-0.5">
              {(Array.isArray(tradeTape) ? tradeTape : []).map((t) => (
                <div
                  key={t.id}
                  className={`grid grid-cols-4 items-center rounded px-1.5 py-1 font-mono text-[11px] transition ${
                    t.isWhaleTrade
                      ? "border border-[#F59E0B]/50 bg-[#F59E0B]/10"
                      : "bg-[#0B0E14]/60"
                  }`}
                >
                  <span
                    className={`font-bold ${
                      t.side === "BUY" ? "text-[#00E676]" : "text-[#FF3B69]"
                    }`}
                  >
                    {t.side === "BUY" ? "קנייה" : "מכירה"}
                    {t.isWhaleTrade ? " 🐋" : ""}
                  </span>
                  <span className="text-[#F1F5F9]">
                    {formatPriceNumber(t.price)}
                  </span>
                  <span className="text-center text-[#94A3B8]">
                    ${(t.notionalUsdt / 1000).toFixed(1)}K
                  </span>
                  <span className="text-left text-[10px] text-[#64748B]">
                    {new Date(t.timestamp).toLocaleTimeString("he-IL", {
                      hour12: false,
                    })}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-3 rounded-lg border border-[#222B3A] bg-[#0B0E14] p-2.5 text-[11px] text-[#94A3B8]">
            🐋 <strong className="text-[#F59E0B]">זיהוי לוויתנים:</strong> עסקאות
            מעל $35,000 מסומנות אוטומטית ומשוקללות במדד Volume Profile.
          </div>
        </div>
      </div>
    </div>
  );
}
