import React, { useState, useRef, useEffect } from "react";
import { Sparkles, Copy, Check, Download, Video, Hash, FileText, Image as ImageIcon, RefreshCw } from "lucide-react";
import { ContentStudioResult, Language } from "../types";

interface ContentStudioProps {
  language: Language;
}

export const ContentStudio: React.FC<ContentStudioProps> = ({ language }) => {
  const [topic, setTopic] = useState("২০২৬ সালে আর্টিফিশিয়াল ইন্টেলিজেন্স ও ক্যারিয়ার");
  const [format, setFormat] = useState<"youtube" | "shorts">("youtube");
  const [loading, setLoading] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const [result, setResult] = useState<ContentStudioResult>({
    titles: [
      { title: "২০২৬ সালে AI শিখলে চাকরি নিশ্চিত? গোপন সত্য ফাঁস! 🔥", score: "98%", vibe: "Viral & Curious" },
      { title: "AI দিয়ে মাসে লাখ টাকা আয় করার সহজ ৫টি উপায় (Bengali Guide)", score: "94%", vibe: "High Value" },
      { title: "ChatGPT ও Gemini দিয়ে কোডিং শেখার সেরা রুটম্যাপ ২০২৬", score: "91%", vibe: "Educational" },
    ],
    description: `এই ভিডিওতে আমরা জানব ২০২৬ সালে কীভাবে Artificial Intelligence ব্যবহার করে আপনার ক্যারিয়ার ও আয় দ্বিগুণ করতে পারবেন।\n\n📌 টাইমস্ট্যাম্প:\n00:00 - ভূমিকা\n01:30 - সেরা ৩টি AI টুলস\n04:15 - রিয়েল লাইফ আর্নিং স্ট্র্যাটেজি\n07:00 - চূড়ান্ত উপসংহার\n\n👉 লাইক ও সাবস্ক্রাইব করে Ranabir AI পরিবারের সাথে যুক্ত থাকুন!\n#RanabirAI #BengaliAI #Career2026`,
    hashtags: ["#RanabirAI", "#BengaliTech", "#ArtificialIntelligence", "#CareerTips", "#TechBangla", "#CodingBengali", "#FutureTech", "#ViralVideo"],
    thumbnail: {
      headlineText: "AI দিয়ে ক্যারিয়ার বদলে ফেলুন!",
      visualConcept: "High contrast neon studio with bold futuristic typography",
      badgeText: "2026 NEW",
      bgStyle: "cyberpunk",
    },
    reelsCaption: "২০২৬ সালে AI জানলে ক্যারিয়ার নিয়ে চিন্তা নেই! আপনার মতামত কমেন্টে জানান 👇🔥",
  });

  const thumbnailCanvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    drawThumbnail();
  }, [result]);

  const drawThumbnail = () => {
    const canvas = thumbnailCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = 1280;
    canvas.height = 720;

    // Rich YouTube thumbnail gradient
    const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    grad.addColorStop(0, "#090d16");
    grad.addColorStop(0.5, "#171c32");
    grad.addColorStop(1, "#311042");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Dynamic bright glow orbs
    const orb = ctx.createRadialGradient(900, 250, 50, 900, 250, 500);
    orb.addColorStop(0, "rgba(99, 102, 241, 0.45)");
    orb.addColorStop(1, "transparent");
    ctx.fillStyle = orb;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const orb2 = ctx.createRadialGradient(250, 500, 40, 250, 500, 400);
    orb2.addColorStop(0, "rgba(6, 182, 212, 0.35)");
    orb2.addColorStop(1, "transparent");
    ctx.fillStyle = orb2;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Decorative grid accent
    ctx.strokeStyle = "rgba(255, 255, 255, 0.05)";
    ctx.lineWidth = 1;
    for (let x = 0; x < canvas.width; x += 80) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }

    // Badge (e.g., "2026 NEW")
    const badgeText = result.thumbnail.badgeText || "2026 NEW";
    ctx.fillStyle = "#ef4444";
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(80, 80, 210, 56, 16) : ctx.fillRect(80, 80, 210, 56);
    ctx.fill();

    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 28px 'Plus Jakarta Sans', sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(badgeText, 185, 118);

    // Bold Catchy Headline Text
    ctx.textAlign = "left";
    ctx.font = "bold 76px 'Hind Siliguri', 'Plus Jakarta Sans', sans-serif";

    // Text Shadow
    ctx.fillStyle = "rgba(0,0,0,0.85)";
    ctx.fillText(result.thumbnail.headlineText, 84, 304);

    // Main Text
    ctx.fillStyle = "#facc15"; // Yellow high contrast
    ctx.fillText(result.thumbnail.headlineText, 80, 300);

    // Subtag banner
    ctx.fillStyle = "rgba(255, 255, 255, 0.12)";
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(80, 380, 550, 80, 16) : ctx.fillRect(80, 380, 550, 80);
    ctx.fill();
    ctx.strokeStyle = "rgba(255, 255, 255, 0.2)";
    ctx.stroke();

    ctx.fillStyle = "#ffffff";
    ctx.font = "600 36px 'Hind Siliguri', sans-serif";
    ctx.fillText("১০০% ফ্রি ও সহজ সমাধান 🔥", 110, 434);

    // Ranabir branding badge
    ctx.fillStyle = "rgba(11, 15, 25, 0.8)";
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(canvas.width - 320, canvas.height - 110, 260, 54, 14) : ctx.fillRect(canvas.width - 320, canvas.height - 110, 260, 54);
    ctx.fill();
    ctx.strokeStyle = "rgba(99, 102, 241, 0.4)";
    ctx.stroke();

    ctx.fillStyle = "#38bdf8";
    ctx.font = "bold 24px 'Plus Jakarta Sans', sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("Ranabir AI Studio", canvas.width - 190, canvas.height - 75);
  };

  const handleGenerate = async () => {
    if (!topic.trim() || loading) return;
    setLoading(true);

    try {
      const res = await fetch("/api/content-studio", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          topic,
          format,
          language: language === "en" ? "en" : language === "hi" ? "hi" : "bn",
        }),
      });
      const data = await res.json();
      if (data.data) {
        setResult(data.data);
      }
    } catch (e) {
      console.error("Content generation error:", e);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const downloadThumbnail = () => {
    const canvas = thumbnailCanvasRef.current;
    if (!canvas) return;
    const url = canvas.toDataURL("image/png");
    const a = document.createElement("a");
    a.href = url;
    a.download = "youtube-thumbnail.png";
    a.click();
  };

  return (
    <div className="max-w-4xl mx-auto w-full px-3 sm:px-4 py-4 pb-24 space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-indigo-400" />
          <span>Auto Content Studio</span>
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 mt-1">
          এক ক্লিকে তৈরি করুন YouTube Thumbnail, Viral Title, Description এবং Trending Hashtag।
        </p>
      </div>

      {/* Input bar */}
      <div className="glass-panel-elevated rounded-2xl p-4 border border-white/10 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="আপনার ভিডিওর বিষয় বা আইডিয়া লিখুন..."
            className="flex-1 glass-input rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-400 focus:outline-none"
          />

          <button
            onClick={handleGenerate}
            disabled={!topic.trim() || loading}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 disabled:opacity-50 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 transition-all shrink-0"
          >
            {loading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>তৈরি হচ্ছে...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>১-ক্লিকে প্যাকেজ তৈরি</span>
              </>
            )}
          </button>
        </div>

        {/* Format Selector */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400 font-medium">ফরম্যাট:</span>
          <button
            onClick={() => setFormat("youtube")}
            className={`px-3 py-1 rounded-lg font-medium transition-colors ${
              format === "youtube" ? "bg-indigo-600 text-white" : "bg-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            YouTube Video (16:9)
          </button>
          <button
            onClick={() => setFormat("shorts")}
            className={`px-3 py-1 rounded-lg font-medium transition-colors ${
              format === "shorts" ? "bg-indigo-600 text-white" : "bg-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            Reels &amp; Shorts (9:16)
          </button>
        </div>
      </div>

      {/* Grid: Left (Titles, Description, Hashtags), Right (Thumbnail Studio) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left column (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Viral Titles */}
          <div className="glass-panel-elevated rounded-2xl p-4 border border-white/10 space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Video className="w-4 h-4 text-cyan-400" />
              <span>উচ্চ CTR সমৃদ্ধ ভাইরাল টাইটেল</span>
            </h3>

            <div className="space-y-2">
              {result.titles.map((t, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-xl bg-slate-800/60 border border-white/5 flex items-center justify-between gap-3 hover:border-indigo-500/30 transition-all"
                >
                  <div className="min-w-0">
                    <div className="text-xs font-semibold text-white truncate">
                      {t.title}
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
                        CTR Score: {t.score}
                      </span>
                      <span className="text-[10px] text-slate-400 font-medium">
                        {t.vibe}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => copyToClipboard(`title-${idx}`, t.title)}
                    className="p-2 rounded-lg bg-slate-700/80 hover:bg-slate-600 text-slate-300 hover:text-white shrink-0 transition-colors"
                    title="Copy title"
                  >
                    {copiedKey === `title-${idx}` ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Description */}
          <div className="glass-panel-elevated rounded-2xl p-4 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-400" />
                <span>SEO ডেসক্রিপশন</span>
              </h3>
              <button
                onClick={() => copyToClipboard("desc", result.description)}
                className="text-xs px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center gap-1 transition-colors"
              >
                {copiedKey === "desc" ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span className="text-emerald-400">কপি হয়েছে</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span>কপি করুন</span>
                  </>
                )}
              </button>
            </div>

            <div className="p-3 rounded-xl bg-slate-800/60 border border-white/5 text-xs text-slate-200 whitespace-pre-wrap max-h-36 overflow-y-auto leading-relaxed font-mono">
              {result.description}
            </div>
          </div>

          {/* Hashtags */}
          <div className="glass-panel-elevated rounded-2xl p-4 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Hash className="w-4 h-4 text-cyan-400" />
                <span>ট্রেন্ডিং হ্যাশট্যাগ</span>
              </h3>
              <button
                onClick={() => copyToClipboard("tags", result.hashtags.join(" "))}
                className="text-xs px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center gap-1 transition-colors"
              >
                {copiedKey === "tags" ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span className="text-emerald-400">সব কপি হয়েছে</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span>সব কপি করুন</span>
                  </>
                )}
              </button>
            </div>

            <div className="flex flex-wrap gap-1.5">
              {result.hashtags.map((tag, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-medium"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Right column: Auto Thumbnail Studio (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="glass-panel-elevated rounded-2xl p-4 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-amber-400" />
                <span>অটো থাম্বনেইল স্টুডিও</span>
              </h3>

              <button
                onClick={downloadThumbnail}
                className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1 transition-colors shadow-sm"
              >
                <Download className="w-3.5 h-3.5" />
                <span>থাম্বনেইল ডাউনলোড</span>
              </button>
            </div>

            {/* Thumbnail Canvas Preview */}
            <div className="relative aspect-video w-full rounded-xl overflow-hidden bg-black/50 border border-white/10 shadow-lg">
              <canvas
                ref={thumbnailCanvasRef}
                className="w-full h-full object-contain"
              />
            </div>

            <div className="p-3 rounded-xl bg-slate-800/40 border border-white/5 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">থাম্বনেইল হেডলাইন:</span>
                <span className="font-semibold text-white">{result.thumbnail.headlineText}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">ভিজ্যুয়াল কনসেপ্ট:</span>
                <span className="text-slate-300 max-w-[200px] text-right truncate">
                  {result.thumbnail.visualConcept}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
