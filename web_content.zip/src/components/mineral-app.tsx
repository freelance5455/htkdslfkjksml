import { useEffect, useState } from "react";
import { Gem, Locate, X } from "lucide-react";
import { clsx } from "clsx";
import { FieldMap, type BasemapId, type MapFocus } from "@/components/field-map";
import { FieldPanel, type EditorState, type TabId } from "@/components/field-panel";
import { PLACES, placeStopId } from "@/lib/field";
import { useField } from "@/lib/field-store";

const MAPS: Array<{ id: BasemapId; label: string }> = [
  { id: "topo", label: "Topo" },
  { id: "karte", label: "Karte" },
  { id: "satellit", label: "Luft" },
];

export function MineralApp() {
  const load = useField((state) => state.load);
  const finds = useField((state) => state.finds);
  const tours = useField((state) => state.tours);
  const addStop = useField((state) => state.addStop);

  const [basemap, setBasemap] = useState<BasemapId>("topo");
  const [tab, setTab] = useState<TabId>("funde");
  const [sheetOpen, setSheetOpen] = useState(true);
  const [query, setQuery] = useState("");
  const [showPlaces, setShowPlaces] = useState(true);
  const [editor, setEditor] = useState<EditorState | null>(null);
  const [pin, setPin] = useState<{ lat: number; lng: number } | null>(null);
  const [detailKey, setDetailKey] = useState<string | null>(null);
  const [activeTourId, setActiveTourId] = useState<string | null>(null);
  const [recording, setRecording] = useState(false);
  const [userLoc, setUserLoc] = useState<{ lat: number; lng: number } | null>(null);
  const [focus, setFocus] = useState<MapFocus | null>(null);
  const [banner, setBanner] = useState<string | null>(null);
  const [hintOff, setHintOff] = useState(false);

  useEffect(() => {
    void load();
    try {
      setHintOff(localStorage.getItem("ader-hint") === "1");
    } catch {
      setHintOff(false);
    }
  }, [load]);

  const selectedKey = editor ? null : detailKey;
  const placing = !recording;

  function openDetail(key: string) {
    setDetailKey(key);
    setEditor(null);
    setPin(null);
    setActiveTourId(null);
    setRecording(false);
    setSheetOpen(true);
    if (key.startsWith("place:")) setTab("orte");
    else setTab("funde");
    const place = PLACES.find((item) => placeStopId(item.id) === key);
    const find = finds.find((item) => item.id === key);
    const point = place ?? find;
    if (point) setFocus({ lat: point.lat, lng: point.lng, zoom: 12, token: Date.now() });
  }

  function onSelect(key: string) {
    if (recording && activeTourId) {
      const tour = tours.find((item) => item.id === activeTourId);
      if (tour?.fixed) return;
      if (tour?.stopIds.includes(key)) {
        setBanner("Der Punkt ist schon in der Tour.");
        return;
      }
      void addStop(activeTourId, key).then((added) => {
        if (added) setBanner("Punkt angehängt.");
      });
      return;
    }
    openDetail(key);
  }

  function onMapClick(lat: number, lng: number) {
    if (recording) {
      setBanner("Tippe einen Fund oder einen Ort an, keine leere Stelle.");
      return;
    }
    setPin({ lat, lng });
    setEditor((current) => current ?? { id: null });
    setDetailKey(null);
    setActiveTourId(null);
    setTab("funde");
    setSheetOpen(true);
  }

  function locate() {
    if (!navigator.geolocation) {
      setBanner("Standort ist hier nicht verfügbar.");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const next = { lat: position.coords.latitude, lng: position.coords.longitude };
        setUserLoc(next);
        setFocus({ ...next, zoom: 14, token: Date.now() });
      },
      () => setBanner("Standort nicht freigegeben. Setze den Punkt auf der Karte."),
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 20000 },
    );
  }

  const hint = recording
    ? "Aufnahme läuft — tippe Punkte auf der Karte an."
    : editor
      ? "Tipp auf die Karte verschiebt den Fund."
      : hintOff
        ? null
        : "Tipp auf die Karte, um einen Fund einzutragen.";

  return (
    <div className="flex h-dvh flex-col bg-bg text-fg">
      <header className="flex h-14 shrink-0 items-center gap-2 border-b border-border px-3">
        <div className="flex min-w-0 items-center gap-2">
          <span className="grid size-9 shrink-0 place-items-center rounded-md bg-primary text-primary-fg">
            <Gem className="size-5" />
          </span>
          <div className="min-w-0 leading-tight">
            <h1 className="font-display text-lg font-semibold tracking-tight text-fg">Ader</h1>
            <p className="hidden truncate text-xs text-muted sm:block">Mineraliensuche · Österreich</p>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-1">
          <div className="flex rounded-md border border-border bg-surface p-0.5" role="group" aria-label="Kartenstil">
            {MAPS.map((map) => (
              <button
                key={map.id}
                type="button"
                aria-pressed={basemap === map.id}
                onClick={() => setBasemap(map.id)}
                className={clsx(
                  "h-9 rounded-md px-2 text-xs font-medium sm:px-3 sm:text-sm",
                  basemap === map.id ? "bg-primary text-primary-fg" : "text-muted",
                )}
              >
                {map.label}
              </button>
            ))}
          </div>
          <button
            type="button"
            className="grid size-11 place-items-center rounded-md border border-border bg-surface text-fg"
            aria-label="Meinen Standort zeigen"
            onClick={locate}
          >
            <Locate className="size-5" />
          </button>
        </div>
      </header>

      <div className="flex min-h-0 flex-1 flex-col xl:flex-row">
        <div className="relative isolate min-h-0 flex-1">
          <FieldMap
            basemap={basemap}
            finds={finds}
            tours={tours}
            showPlaces={showPlaces}
            selectedKey={selectedKey}
            activeTourId={activeTourId}
            draftPin={editor ? pin : null}
            userLoc={userLoc}
            focus={focus}
            placing={placing}
            onMapClick={onMapClick}
            onSelect={onSelect}
          />
          {hint ? (
            <div className="pointer-events-none absolute inset-x-0 top-3 z-10 flex justify-center px-3">
              <p className="pointer-events-auto flex max-w-md items-start gap-2 rounded-md border border-border bg-surface px-3 py-2 text-sm text-fg">
                <span>{hint}</span>
                {!recording && !editor ? (
                  <button
                    type="button"
                    className="grid size-6 shrink-0 place-items-center text-muted"
                    aria-label="Hinweis schließen"
                    onClick={() => {
                      setHintOff(true);
                      try {
                        localStorage.setItem("ader-hint", "1");
                      } catch {
                        /* ignore */
                      }
                    }}
                  >
                    <X className="size-4" />
                  </button>
                ) : null}
              </p>
            </div>
          ) : null}
          <div className="pointer-events-none absolute bottom-8 left-3 z-10 hidden flex-col gap-1 rounded-md border border-border bg-surface px-3 py-2 text-xs text-muted sm:flex">
            <span className="flex items-center gap-2">
              <i className="inline-block size-2.5 rotate-45 bg-primary" /> Eigener Fund
            </span>
            <span className="flex items-center gap-2">
              <i className="inline-block size-2.5 rotate-45 border border-fg" /> Orientierung
            </span>
            <span className="flex items-center gap-2">
              <i className="inline-block h-0.5 w-4 bg-primary" /> Fixierte Tour
            </span>
          </div>
          {banner ? (
            <div className="absolute inset-x-3 bottom-3 z-10 sm:left-auto sm:max-w-sm">
              <p className="flex items-start gap-2 rounded-md border border-border bg-surface px-3 py-2 text-sm text-fg">
                <span className="flex-1">{banner}</span>
                <button type="button" className="text-muted" aria-label="Meldung schließen" onClick={() => setBanner(null)}>
                  <X className="size-4" />
                </button>
              </p>
            </div>
          ) : null}
          {userLoc && !editor ? (
            <button
              type="button"
              className="absolute left-3 top-16 z-10 h-11 rounded-md border border-border bg-surface px-3 text-sm text-fg"
              onClick={() => {
                setPin(userLoc);
                setEditor({ id: null });
                setDetailKey(null);
                setTab("funde");
                setSheetOpen(true);
              }}
            >
              Fund hier
            </button>
          ) : null}
        </div>

        <FieldPanel
          tab={tab}
          setTab={(next) => {
            setTab(next);
            setDetailKey(null);
            setEditor(null);
            setPin(null);
            setActiveTourId(null);
            setRecording(false);
            setSheetOpen(true);
          }}
          sheetOpen={sheetOpen}
          setSheetOpen={setSheetOpen}
          query={query}
          setQuery={setQuery}
          showPlaces={showPlaces}
          setShowPlaces={setShowPlaces}
          editor={editor}
          pin={pin}
          setPin={setPin}
          detailKey={detailKey}
          activeTourId={activeTourId}
          recording={recording}
          setRecording={setRecording}
          userLoc={userLoc}
          onOpenDetail={openDetail}
          onCloseDetail={() => setDetailKey(null)}
          onOpenEditor={(next) => {
            setEditor(next);
            setDetailKey(null);
            setActiveTourId(null);
            setRecording(false);
            setTab("funde");
            setSheetOpen(true);
            if (next.id) {
              const find = finds.find((item) => item.id === next.id);
              if (find) setPin({ lat: find.lat, lng: find.lng });
            }
          }}
          onCloseEditor={() => {
            setEditor(null);
            setPin(null);
          }}
          onOpenTour={(id) => {
            setActiveTourId(id);
            setTab("touren");
            setEditor(null);
            setDetailKey(null);
            setPin(null);
            setSheetOpen(true);
            const tour = tours.find((item) => item.id === id);
            const first = tour?.stopIds[0];
            if (first) {
              const point = finds.find((item) => item.id === first);
              const place = PLACES.find((item) => placeStopId(item.id) === first);
              const target = point ?? place;
              if (target) setFocus({ lat: target.lat, lng: target.lng, zoom: 10, token: Date.now() });
            }
          }}
          onCloseTour={() => {
            setActiveTourId(null);
            setRecording(false);
          }}
          onSaved={(id) => {
            const saved = pin;
            setEditor(null);
            setPin(null);
            setDetailKey(id);
            setActiveTourId(null);
            setRecording(false);
            setTab("funde");
            setSheetOpen(true);
            if (saved) setFocus({ lat: saved.lat, lng: saved.lng, zoom: 12, token: Date.now() });
            setBanner("Fund liegt auf der Karte.");
          }}
          onBanner={setBanner}
        />
      </div>
    </div>
  );
}
