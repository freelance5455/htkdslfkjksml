import React, { useState, useEffect } from 'react';
import {
  Menu,
  X,
  Mic,
  MicOff,
  MessageSquare,
  Smile,
  Scroll,
  Crown,
  Volume2,
  VolumeX,
  LogOut,
  Shield,
  Trophy,
  Users,
  ChevronRight,
  Wifi,
  Radio,
  Sparkles,
} from 'lucide-react';
import {
  Card,
  Suit,
  GamePlayer,
  PlayedCard,
  GamePhase,
  UserProfile,
} from '../types';
import {
  dealCards,
  isCardLegal,
  determineTrickWinner,
  pickBotCard,
  calculateBotBid,
  getBidPoints,
  getMinimumAllowedBid,
  checkTarneebVictory,
  SUIT_ARABIC,
  SUIT_SYMBOLS,
  SUIT_COLORS,
} from '../utils/tarneebEngine';
import { soundFX } from '../utils/soundEffects';
import { realAudioMic } from '../utils/audioCapture';

interface TarneebGameProps {
  currentUser: UserProfile;
  onExitGame: () => void;
}

export const TarneebGame: React.FC<TarneebGameProps> = ({ currentUser, onExitGame }) => {
  // Players state
  const [players, setPlayers] = useState<GamePlayer[]>([
    {
      id: 'player_south',
      name: currentUser.name,
      avatar: currentUser.avatar,
      score: 11, // Match screenshot example score 11
      team: 1,
      cardsCount: 13,
      level: currentUser.level,
      title: currentUser.title,
      tricksWonThisRound: 0,
      totalRoundPoints: 0,
      isSpeaking: false,
    },
    {
      id: 'player_north',
      name: 'أحمد',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
      score: 4, // Match screenshot example score 4
      team: 1,
      cardsCount: 13,
      level: 18,
      title: 'شريكك الملكي',
      tricksWonThisRound: 0,
      totalRoundPoints: 0,
      isSpeaking: false,
    },
    {
      id: 'player_west',
      name: 'سامي',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
      score: 6, // Match screenshot example score 6
      team: 2,
      cardsCount: 13,
      level: 16,
      title: 'خصم',
      tricksWonThisRound: 0,
      totalRoundPoints: 0,
      isSpeaking: false,
    },
    {
      id: 'player_east',
      name: 'ليلى',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
      score: 2, // Match screenshot example score 2
      team: 2,
      cardsCount: 13,
      level: 17,
      title: 'خصم',
      tricksWonThisRound: 0,
      totalRoundPoints: 0,
      isSpeaking: false,
    },
  ]);

  // Game flow states
  const [phase, setPhase] = useState<GamePhase>('bidding');
  const [trumpSuit, setTrumpSuit] = useState<Suit | null>(null);
  const [currentTurnPlayerId, setCurrentTurnPlayerId] = useState<string>('player_south');
  const [biddingTurnIndex, setBiddingTurnIndex] = useState(0);
  const [currentHighestBid, setCurrentHighestBid] = useState(6);
  const [highestBidderId, setHighestBidderId] = useState<string>('player_north');
  const [dealtHands, setDealtHands] = useState<Record<string, Card[]>>({});
  const [currentTrick, setCurrentTrick] = useState<PlayedCard[]>([]);
  const [ledSuit, setLedSuit] = useState<Suit | null>(null);
  const [roundNumber, setRoundNumber] = useState(1);
  const [trickNumber, setTrickNumber] = useState(1);

  // In-Game UI state
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarActiveTab, setSidebarActiveTab] = useState<'match' | 'chat' | 'settings'>('match');
  const [chatOpen, setChatOpen] = useState(false);
  const [emojiPickerOpen, setEmojiPickerOpen] = useState(false);
  const [activeEmojiReaction, setActiveEmojiReaction] = useState<{ text: string; playerId: string } | null>(null);
  const [micActive, setMicActive] = useState(false);
  const [micLevel, setMicLevel] = useState(0);
  const [isUserSpeaking, setIsUserSpeaking] = useState(false);
  const [customChatMessage, setCustomChatMessage] = useState('');
  const [gameAlertNotice, setGameAlertNotice] = useState<string | null>(null);

  const showGameNotice = (msg: string) => {
    setGameAlertNotice(msg);
    setTimeout(() => setGameAlertNotice(null), 3500);
  };

  const toggleRealMic = async () => {
    soundFX.playButtonClick();
    if (micActive) {
      realAudioMic.stopMicrophone();
      setMicActive(false);
      setIsUserSpeaking(false);
      setMicLevel(0);
      showGameNotice('تم كتم المايك 🎙️');
    } else {
      const res = await realAudioMic.startMicrophone(
        (level) => setMicLevel(level),
        (speaking) => setIsUserSpeaking(speaking)
      );
      setMicActive(true);
      showGameNotice('المايك الحي متصل ويعمل بنجاح! تحدث مع زملائك على الطاولة 🎙️');
    }
  };

  useEffect(() => {
    return () => {
      if (realAudioMic.isActive()) {
        realAudioMic.stopMicrophone();
      }
    };
  }, []);
  const [chatLog, setChatLog] = useState<{ sender: string; text: string; time: string }[]>([
    { sender: 'أحمد', text: 'بالتوفيق يا شريكي، ركز على ورق الطرنيب!', time: '12:01' },
    { sender: 'سامي', text: 'سوق 41 اليوم محسوم لصالحنا 😎', time: '12:02' },
  ]);
  const [movesLogOpen, setMovesLogOpen] = useState(false);
  const [movesHistory, setMovesHistory] = useState<string[]>([
    'تم توزيع 13 ورقة لكل لاعب بنجاح.',
    'المزايدة جارية: الحد الأدنى 2 (أو 3 إذا الرصيد >= 30، 4 إذا >= 40).',
  ]);
  const [statusBanner, setStatusBanner] = useState('دورك الآن • مرحلة المزايدة');
  const [roundResultModal, setRoundResultModal] = useState<{
    show: boolean;
    title: string;
    details: string;
    scoresSummary: any;
    isWinner: boolean;
  }>({ show: false, title: '', details: '', scoresSummary: null, isWinner: false });

  // Custom table style state
  const [tableStyle, setTableStyle] = useState<'emerald' | 'obsidian' | 'ruby'>('emerald');

  // Gemini AI Coach Hint state
  const [isAiHintLoading, setIsAiHintLoading] = useState<boolean>(false);
  const [aiCoachHint, setAiCoachHint] = useState<{
    suggestedCard: { suit: string; rank: string };
    tacticalReason: string;
    riskRating: string;
  } | null>(null);

  const requestGeminiHint = async () => {
    if (phase !== 'playing' || currentTurnPlayerId !== 'player_south') return;
    try {
      setIsAiHintLoading(true);
      soundFX.playButtonClick();

      const southCards = dealtHands['player_south'] || [];
      const team1Score = players.filter((p) => p.team === 1).reduce((sum, p) => sum + p.score, 0);
      const team2Score = players.filter((p) => p.team === 2).reduce((sum, p) => sum + p.score, 0);

      const res = await fetch('/api/gemini/tarneeb-hint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          hand: southCards.map((c) => ({ suit: c.suit, rank: c.rank })),
          trumpSuit,
          currentTrick: currentTrick.map((t) => ({ player: t.playerId, suit: t.card.suit, rank: t.card.rank })),
          playerIndex: 0,
          currentScore: { ourTeam: team1Score, theirTeam: team2Score },
          bid: highestBidderId ? { tricks: currentHighestBid, player: highestBidderId } : null,
        }),
      });

      const data = await res.json();
      if (data.success && data.hint) {
        setAiCoachHint(data.hint);
        soundFX.playVictoryFanfare();
      }
    } catch (e) {
      console.error('Error fetching Gemini Tarneeb hint:', e);
    } finally {
      setIsAiHintLoading(false);
    }
  };

  // Initialize and deal cards on match start
  useEffect(() => {
    startNewRound();
  }, []);

  const startNewRound = () => {
    soundFX.playCardDeal();
    const deal = dealCards(players);
    setDealtHands(deal.dealtHands);
    setPlayers(deal.players);
    setPhase('bidding');
    setCurrentTurnPlayerId('player_south');
    setBiddingTurnIndex(0);
    setCurrentHighestBid(0);
    setHighestBidderId('');
    setTrumpSuit(null);
    setCurrentTrick([]);
    setLedSuit(null);
    setTrickNumber(1);
    setStatusBanner('دورك الآن • مرحلة المزايدة');
  };

  // Turn management for bot bidding
  useEffect(() => {
    if (phase !== 'bidding') return;

    if (currentTurnPlayerId !== 'player_south') {
      const timer = setTimeout(() => {
        handleBotBid(currentTurnPlayerId);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [phase, currentTurnPlayerId]);

  // Turn management for bot playing card
  useEffect(() => {
    if (phase !== 'playing') return;

    if (currentTurnPlayerId !== 'player_south') {
      const timer = setTimeout(() => {
        handleBotPlayCard(currentTurnPlayerId);
      }, 1100);
      return () => clearTimeout(timer);
    }
  }, [phase, currentTurnPlayerId, currentTrick]);

  // Human player places a bid
  const handlePlayerBid = (bid: number | 'pass') => {
    soundFX.playButtonClick();
    const southPlayer = players.find((p) => p.id === 'player_south')!;
    const minAllowed = getMinimumAllowedBid(southPlayer.score);

    if (bid !== 'pass') {
      if (bid < minAllowed) {
        showGameNotice(`⚠️ بسبب وصول رصيدك إلى ${southPlayer.score}، فإن أقل طلب مسموح لك إجباريًا هو ${minAllowed}!`);
        return;
      }
      if (bid <= currentHighestBid) {
        showGameNotice(`⚠️ يجب أن تكون المزايدة أعلى من أعلى طلب حالي (${currentHighestBid})!`);
        return;
      }

      soundFX.playBidSuccess();
      setCurrentHighestBid(bid);
      setHighestBidderId('player_south');
      setMovesHistory((prev) => [
        ...prev,
        `طلب اللاعب ${currentUser.name}: ${bid} (قيمة الطلب: ${getBidPoints(bid)} نقطة)`,
      ]);
    } else {
      setMovesHistory((prev) => [...prev, `اللاعب ${currentUser.name}: بس (Pass)`]);
    }

    // Advance bidding turn
    advanceBiddingTurn();
  };

  const advanceBiddingTurn = () => {
    const turnOrder = ['player_south', 'player_east', 'player_north', 'player_west'];
    const nextIdx = (biddingTurnIndex + 1) % 4;
    setBiddingTurnIndex(nextIdx);

    // If 4 turns passed or highest bid settled
    if (biddingTurnIndex >= 3 && currentHighestBid > 0) {
      finalizeBidding();
    } else {
      setCurrentTurnPlayerId(turnOrder[nextIdx]);
    }
  };

  const handleBotBid = (botId: string) => {
    const botHand = dealtHands[botId] || [];
    const bot = players.find((p) => p.id === botId)!;
    const bidResult = calculateBotBid(botHand, currentHighestBid, bot.score);

    if (bidResult !== 'pass') {
      soundFX.playBidSuccess();
      setCurrentHighestBid(bidResult);
      setHighestBidderId(botId);
      setMovesHistory((prev) => [
        ...prev,
        `طلب ${bot.name}: ${bidResult} (قيمة الطلب: ${getBidPoints(bidResult)} نقطة)`,
      ]);
    } else {
      setMovesHistory((prev) => [...prev, `${bot.name}: بس (Pass)`]);
    }

    advanceBiddingTurn();
  };

  const finalizeBidding = () => {
    const winnerId = highestBidderId || 'player_south';
    const winningBid = currentHighestBid > 0 ? currentHighestBid : 2;
    const winningPlayer = players.find((p) => p.id === winnerId)!;

    if (winnerId === 'player_south') {
      setPhase('trump_selection');
      setStatusBanner(`فزت بالمزايدة بطلب (${winningBid}) • اختر نوع الطرنيب الآن!`);
    } else {
      // Bot picks trump
      const suits: Suit[] = ['spades', 'hearts', 'diamonds', 'clubs'];
      const chosenTrump = suits[Math.floor(Math.random() * suits.length)];
      setTrumpSuit(chosenTrump);
      setPhase('playing');
      setCurrentTurnPlayerId(winnerId);
      setStatusBanner(`طرنيب الجولة: ${SUIT_ARABIC[chosenTrump]} ${SUIT_SYMBOLS[chosenTrump]} • دور ${winningPlayer.name}`);
      setMovesHistory((prev) => [
        ...prev,
        `فاز ${winningPlayer.name} بالمزايدة بطلب ${winningBid}. اختار الطرنيب: ${SUIT_ARABIC[chosenTrump]} ${SUIT_SYMBOLS[chosenTrump]}`,
      ]);
    }
  };

  const handleSelectTrumpSuit = (suit: Suit) => {
    soundFX.playBidSuccess();
    setTrumpSuit(suit);
    setPhase('playing');
    setCurrentTurnPlayerId('player_south');
    setStatusBanner(`اخترت الطرنيب: ${SUIT_ARABIC[suit]} ${SUIT_SYMBOLS[suit]} • دورك لبدء اللمّة الأولى!`);
    setMovesHistory((prev) => [
      ...prev,
      `اخترت الطرنيب: ${SUIT_ARABIC[suit]} ${SUIT_SYMBOLS[suit]} (قيمة المزايدة: ${getBidPoints(currentHighestBid)} نقطة)`,
    ]);
  };

  // Human player plays a card
  const handlePlayCard = (card: Card) => {
    if (phase !== 'playing' || currentTurnPlayerId !== 'player_south') return;

    const southCards = dealtHands['player_south'] || [];
    if (!isCardLegal(card, southCards, ledSuit)) {
      showGameNotice(`⚠️ قانون إجباري: يجب عليك اتباع نوع اللمّة (${ledSuit ? SUIT_ARABIC[ledSuit] : ''}) لأنك تملك ورقة من نفس النوع!`);
      return;
    }

    soundFX.playCardPlay();

    // Remove from south player's hand
    const remaining = southCards.filter((c) => c.id !== card.id);
    setDealtHands((prev) => ({ ...prev, player_south: remaining }));
    setPlayers((prev) =>
      prev.map((p) => (p.id === 'player_south' ? { ...p, cards: remaining, cardsCount: remaining.length } : p))
    );

    const played: PlayedCard = {
      playerId: 'player_south',
      playerPosition: 'bottom',
      card,
    };

    const newTrick = [...currentTrick, played];
    setCurrentTrick(newTrick);

    if (!ledSuit) {
      setLedSuit(card.suit);
    }

    setMovesHistory((prev) => [
      ...prev,
      `لعبت: ${card.rank} ${SUIT_SYMBOLS[card.suit]} (${SUIT_ARABIC[card.suit]})`,
    ]);

    processTrickProgress(newTrick, 'player_south', card.suit);
  };

  const handleBotPlayCard = (botId: string) => {
    const botHand = dealtHands[botId] || [];
    if (botHand.length === 0) return;

    const chosenCard = pickBotCard(botHand, ledSuit, trumpSuit, currentTrick);
    soundFX.playCardPlay();

    const remaining = botHand.filter((c) => c.id !== chosenCard.id);
    setDealtHands((prev) => ({ ...prev, [botId]: remaining }));

    const posMap: Record<string, 'top' | 'left' | 'right'> = {
      player_north: 'top',
      player_west: 'left',
      player_east: 'right',
    };

    const played: PlayedCard = {
      playerId: botId,
      playerPosition: posMap[botId],
      card: chosenCard,
    };

    const newTrick = [...currentTrick, played];
    setCurrentTrick(newTrick);

    const effectiveLedSuit = ledSuit || chosenCard.suit;
    if (!ledSuit) setLedSuit(chosenCard.suit);

    const botPlayer = players.find((p) => p.id === botId)!;
    setMovesHistory((prev) => [
      ...prev,
      `لعب ${botPlayer.name}: ${chosenCard.rank} ${SUIT_SYMBOLS[chosenCard.suit]}`,
    ]);

    processTrickProgress(newTrick, botId, effectiveLedSuit);
  };

  const processTrickProgress = (trick: PlayedCard[], lastPlayerId: string, currentLedSuit: Suit) => {
    if (trick.length === 4) {
      // 4 cards played -> Evaluate Trick Winner
      setTimeout(() => {
        const winner = determineTrickWinner(trick, trumpSuit!, currentLedSuit);
        const winningPlayer = players.find((p) => p.id === winner.playerId)!;

        soundFX.playTrickWin();

        setPlayers((prev) =>
          prev.map((p) =>
            p.id === winner.playerId ? { ...p, tricksWonThisRound: p.tricksWonThisRound + 1 } : p
          )
        );

        setMovesHistory((prev) => [
          ...prev,
          `🏆 فاز باللمّة رقم ${trickNumber}: ${winningPlayer.name} بالورقة ${winner.card.rank} ${SUIT_SYMBOLS[winner.card.suit]}`,
        ]);

        setCurrentTrick([]);
        setLedSuit(null);

        if (trickNumber >= 13) {
          // Round Finished -> Tally points according to TABEONA rules
          finalizeRound();
        } else {
          setTrickNumber((prev) => prev + 1);
          setCurrentTurnPlayerId(winner.playerId);
          setStatusBanner(
            winner.playerId === 'player_south'
              ? 'أنت فزت باللمّة! دورك لقيادة اللمّة التالية'
              : `فاز ${winningPlayer.name} باللمّة • دوره لبدء اللمّة التالية`
          );
        }
      }, 1200);
    } else {
      // Advance to next counter-clockwise player
      const playOrder = ['player_south', 'player_east', 'player_north', 'player_west'];
      const currentIdx = playOrder.indexOf(lastPlayerId);
      const nextPlayerId = playOrder[(currentIdx + 1) % 4];
      setCurrentTurnPlayerId(nextPlayerId);
      const nextPlayer = players.find((p) => p.id === nextPlayerId)!;
      setStatusBanner(nextPlayerId === 'player_south' ? 'دورك الآن للعب ورقة!' : `دور ${nextPlayer.name}...`);
    }
  };

  // Exact TABEONA Round Scoring & Win at 41 Validation!
  const finalizeRound = () => {
    const declarer = players.find((p) => p.id === highestBidderId) || players[0];
    const isTeam1Declarer = declarer.team === 1;

    // Team 1 tricks (South + North)
    const team1Tricks = players
      .filter((p) => p.team === 1)
      .reduce((sum, p) => sum + p.tricksWonThisRound, 0);
    const team2Tricks = players
      .filter((p) => p.team === 2)
      .reduce((sum, p) => sum + p.tricksWonThisRound, 0);

    const bid = currentHighestBid;
    const bidPointsValue = getBidPoints(bid);

    // Points calculation per TABEONA rules:
    // Independent player balances!
    let updatedPlayers = [...players];

    if (isTeam1Declarer) {
      if (team1Tricks >= bid) {
        // Successful bid: declarer gains points
        updatedPlayers = updatedPlayers.map((p) => {
          if (p.id === declarer.id) {
            return { ...p, score: p.score + bidPointsValue };
          }
          if (p.team === 2) {
            return { ...p, score: p.score + (p.tricksWonThisRound > 0 ? p.tricksWonThisRound : 0) };
          }
          return p;
        });
      } else {
        // FAILED BID: e.g. 4 - 16 = -12! Declarer loses bidPointsValue directly!
        updatedPlayers = updatedPlayers.map((p) => {
          if (p.id === declarer.id) {
            return { ...p, score: p.score - bidPointsValue };
          }
          if (p.team === 2) {
            return { ...p, score: p.score + p.tricksWonThisRound };
          }
          return p;
        });
      }
    } else {
      // Team 2 Declarer
      if (team2Tricks >= bid) {
        updatedPlayers = updatedPlayers.map((p) => {
          if (p.id === declarer.id) {
            return { ...p, score: p.score + bidPointsValue };
          }
          if (p.team === 1) {
            return { ...p, score: p.score + p.tricksWonThisRound };
          }
          return p;
        });
      } else {
        // Failed bid
        updatedPlayers = updatedPlayers.map((p) => {
          if (p.id === declarer.id) {
            return { ...p, score: p.score - bidPointsValue };
          }
          if (p.team === 1) {
            return { ...p, score: p.score + p.tricksWonThisRound };
          }
          return p;
        });
      }
    }

    setPlayers(updatedPlayers);

    // Check Victory at 41 Condition!
    const scoresObj = {
      bottom: updatedPlayers.find((p) => p.id === 'player_south')!.score,
      top: updatedPlayers.find((p) => p.id === 'player_north')!.score,
      left: updatedPlayers.find((p) => p.id === 'player_west')!.score,
      right: updatedPlayers.find((p) => p.id === 'player_east')!.score,
    };

    const victoryCheck = checkTarneebVictory(scoresObj);

    if (victoryCheck.hasWinner) {
      soundFX.playVictoryFanfare();
      setRoundResultModal({
        show: true,
        title: '🏆 انتصار ملكي تاريخي بالـ 41!',
        details: victoryCheck.reason || 'وصل اللاعب إلى 41 نقطة وشريكه فوق الصفر!',
        scoresSummary: scoresObj,
        isWinner: true,
      });
      setPhase('game_over');
    } else {
      if (victoryCheck.reason) {
        // Reached 41 but partner below zero!
        showGameNotice(`⚠️ تنبيه قانوني: ${victoryCheck.reason}`);
      }
      setRoundResultModal({
        show: true,
        title: `انتهاء الجولة رقم ${roundNumber}`,
        details: `لمّات فريقك: ${team1Tricks} • لمّات الخصم: ${team2Tricks}`,
        scoresSummary: scoresObj,
        isWinner: false,
      });
      setPhase('round_end');
    }
  };

  const handleSendCustomChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customChatMessage.trim()) return;
    soundFX.playButtonClick();
    setChatLog((prev) => [
      ...prev,
      {
        sender: currentUser.name,
        text: customChatMessage.trim(),
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
    setCustomChatMessage('');
  };

  const handleTriggerEmoji = (emoji: string) => {
    soundFX.playButtonClick();
    setActiveEmojiReaction({ text: emoji, playerId: 'player_south' });
    setEmojiPickerOpen(false);
    setTimeout(() => {
      setActiveEmojiReaction(null);
    }, 2200);
  };

  const southHand = dealtHands['player_south'] || [];
  const southPlayer = players.find((p) => p.id === 'player_south')!;
  const northPlayer = players.find((p) => p.id === 'player_north')!;
  const westPlayer = players.find((p) => p.id === 'player_west')!;
  const eastPlayer = players.find((p) => p.id === 'player_east')!;
  const southMinAllowed = getMinimumAllowedBid(southPlayer.score);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#030604] select-none text-white flex flex-col justify-between font-sans">
      {/* Table Felt Background matching IMG-20261009-WA0001.jpg */}
      <div
        className={`absolute inset-0 transition-colors duration-500 ${
          tableStyle === 'emerald'
            ? 'felt-table'
            : tableStyle === 'obsidian'
            ? 'bg-[radial-gradient(ellipse_at_center,_#111827_0%,_#090d15_60%,_#020408_100%)]'
            : 'bg-[radial-gradient(ellipse_at_center,_#3b0707_0%,_#1f0404_60%,_#090101_100%)]'
        }`}
      />

      {/* Decorative Oval Wood Railing Edge with Gold Inlay */}
      <div className="absolute inset-x-8 inset-y-6 rounded-[120px] md:rounded-[200px] border-[12px] border-[#221608] table-wood-rail shadow-[0_0_50px_rgba(0,0,0,0.95)] pointer-events-none" />
      <div className="absolute inset-x-11 inset-y-9 rounded-[110px] md:rounded-[190px] border border-amber-600/40 pointer-events-none" />

      {/* Table Watermark matching screenshot: Crown + TABEONA in center felt */}
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none opacity-20">
        <Crown className="w-16 h-16 text-amber-400 mb-1" />
        <span className="font-cinzel text-4xl md:text-5xl font-black text-amber-200 tracking-widest">
          TABEONA
        </span>
      </div>

      {/* ========================================================
          1. TOP BAR & SCOREBOARD (أعلى الشاشة والنتيجة)
          Matching exact screenshot format:
             4
           6 - 2
             11
         ======================================================== */}
      <div className="relative z-30 px-6 pt-3 flex items-start justify-between">
        {/* Left: Match Info Box matching IMG-20261009-WA0001.jpg */}
        <div className="bg-[#05110a]/90 backdrop-blur-md border border-amber-500/40 rounded-xl p-2.5 text-right shadow-lg min-w-[140px]">
          <div className="flex items-center gap-1.5 text-amber-300 font-bold text-xs">
            <Crown className="w-3.5 h-3.5 text-amber-400" />
            <span>TABEONA</span>
          </div>
          <div className="text-[11px] text-gray-300 mt-0.5">غرفة: #24451</div>
          <div className="text-[11px] text-emerald-400 font-semibold">طرنيب سوق 41</div>
          <div className="text-[10px] text-amber-300 font-bold mt-0.5 flex items-center gap-1">
            <span>💵 رهان نقدي:</span>
            <span className="font-mono text-emerald-400">$10 USD</span>
          </div>
          <div className="flex items-center gap-1 text-[10px] text-gray-400 mt-1">
            <Wifi className="w-3 h-3 text-emerald-400" />
            <span>متصل (28ms)</span>
          </div>
        </div>

        {/* Center Scoreboard Plaque: Separate Player Balances!
            Matching screenshot:
               4 (North)
             6 - 2 (West - East)
               11 (South)
        */}
        <div className="bg-gradient-to-b from-[#0a2315] to-[#041109] border-2 border-amber-400/80 rounded-2xl px-6 py-2 shadow-2xl flex flex-col items-center min-w-[160px]">
          <div className="text-[10px] font-bold text-amber-400/80 mb-0.5">سجل النقاط المستقلة</div>
          {/* North (Partner) */}
          <div className="font-mono text-base font-black text-amber-300">{northPlayer.score}</div>
          {/* Middle: West - East */}
          <div className="flex items-center gap-4 font-mono text-base font-black text-gray-200">
            <span>{westPlayer.score}</span>
            <span className="text-amber-500 text-xs">-</span>
            <span>{eastPlayer.score}</span>
          </div>
          {/* South (You) */}
          <div className="font-mono text-lg font-black text-amber-400">{southPlayer.score}</div>

          {trumpSuit && (
            <div className="mt-1 pt-1 border-t border-amber-950 text-[10px] text-emerald-300 font-bold flex items-center gap-1">
              <span>الطرنيب:</span>
              <span className={`text-sm ${SUIT_COLORS[trumpSuit]}`}>{SUIT_SYMBOLS[trumpSuit]}</span>
              <span>{SUIT_ARABIC[trumpSuit]}</span>
            </div>
          )}
        </div>

        {/* Right: Hamburger Menu ☰ Button matching screenshot */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              soundFX.playButtonClick();
              setSidebarOpen(true);
            }}
            className="p-2.5 rounded-xl bg-[#06180f]/90 hover:bg-[#0a2718] border border-amber-500/50 text-amber-300 shadow-lg flex items-center gap-2 text-xs font-bold transition-all active:scale-95"
          >
            <Menu className="w-5 h-5 text-amber-400" />
            <span className="hidden md:inline">القائمة</span>
          </button>
        </div>
      </div>

      {/* Floating Game Alert Notice (Replaces browser alerts) */}
      {gameAlertNotice && (
        <div className="absolute top-16 left-1/2 -translate-x-1/2 z-50 px-5 py-2.5 bg-amber-950/95 border-2 border-amber-400 text-amber-100 text-xs font-bold rounded-2xl shadow-[0_0_30px_rgba(245,158,11,0.7)] flex items-center gap-2 animate-in fade-in slide-in-from-top-3">
          <Shield className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{gameAlertNotice}</span>
        </div>
      )}

      {/* ========================================================
          2. TABLE PLAYERS & FELT CENTER (الطاولة واللاعبون)
         ======================================================== */}
      <div className="relative z-20 flex-1 flex items-center justify-center px-4">
        {/* NORTH PLAYER (الشريك - أحمد) */}
        <div className="absolute top-1 flex flex-col items-center">
          <div className="relative">
            <img
              src={northPlayer.avatar}
              alt={northPlayer.name}
              className={`w-14 h-14 rounded-full border-2 border-amber-400 object-cover shadow-lg ${
                currentTurnPlayerId === 'player_north' ? 'ring-4 ring-emerald-400 ring-offset-2 ring-offset-black' : ''
              }`}
            />
            {currentTurnPlayerId === 'player_north' && (
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-400 animate-ping" />
            )}
          </div>
          <div className="text-center mt-1 bg-black/60 px-3 py-0.5 rounded-full border border-amber-900/60">
            <div className="text-xs font-bold text-amber-200">{northPlayer.name}</div>
            <div className="text-[10px] text-emerald-400 font-mono">رصيد: {northPlayer.score}</div>
          </div>
          {/* Cards indicator */}
          <div className="flex -space-x-1.5 mt-1">
            {Array.from({ length: Math.min(13, northPlayer.cardsCount) }).map((_, i) => (
              <div
                key={i}
                className="w-4 h-6 rounded bg-gradient-to-b from-emerald-950 to-black border border-amber-500/50 shadow"
              />
            ))}
          </div>
        </div>

        {/* WEST PLAYER (الخصم - سامي) */}
        <div className="absolute left-6 md:left-12 flex flex-col items-center">
          <div className="relative">
            <img
              src={westPlayer.avatar}
              alt={westPlayer.name}
              className={`w-14 h-14 rounded-full border-2 border-amber-400 object-cover shadow-lg ${
                currentTurnPlayerId === 'player_west' ? 'ring-4 ring-emerald-400 ring-offset-2 ring-offset-black' : ''
              }`}
            />
          </div>
          <div className="text-center mt-1 bg-black/60 px-3 py-0.5 rounded-full border border-amber-900/60">
            <div className="text-xs font-bold text-gray-200">{westPlayer.name}</div>
            <div className="text-[10px] text-emerald-400 font-mono">رصيد: {westPlayer.score}</div>
          </div>
          {/* Cards indicator */}
          <div className="flex -space-x-1.5 mt-1">
            {Array.from({ length: Math.min(13, westPlayer.cardsCount) }).map((_, i) => (
              <div
                key={i}
                className="w-4 h-6 rounded bg-gradient-to-b from-emerald-950 to-black border border-amber-500/50 shadow"
              />
            ))}
          </div>
        </div>

        {/* EAST PLAYER (الخصم - ليلى) */}
        <div className="absolute right-6 md:right-12 flex flex-col items-center">
          <div className="relative">
            <img
              src={eastPlayer.avatar}
              alt={eastPlayer.name}
              className={`w-14 h-14 rounded-full border-2 border-amber-400 object-cover shadow-lg ${
                currentTurnPlayerId === 'player_east' ? 'ring-4 ring-emerald-400 ring-offset-2 ring-offset-black' : ''
              }`}
            />
          </div>
          <div className="text-center mt-1 bg-black/60 px-3 py-0.5 rounded-full border border-amber-900/60">
            <div className="text-xs font-bold text-gray-200">{eastPlayer.name}</div>
            <div className="text-[10px] text-emerald-400 font-mono">رصيد: {eastPlayer.score}</div>
          </div>
          {/* Cards indicator */}
          <div className="flex -space-x-1.5 mt-1">
            {Array.from({ length: Math.min(13, eastPlayer.cardsCount) }).map((_, i) => (
              <div
                key={i}
                className="w-4 h-6 rounded bg-gradient-to-b from-emerald-950 to-black border border-amber-500/50 shadow"
              />
            ))}
          </div>
        </div>

        {/* CENTER TABLE ACTION AREA: TRICK CARDS & STATUS */}
        <div className="relative z-10 flex flex-col items-center justify-center">
          {/* Dynamic Status Pill */}
          <div className="px-5 py-1.5 rounded-full bg-[#05140b]/90 border border-amber-400/70 shadow-lg text-center mb-4">
            <span className="text-xs md:text-sm font-bold text-amber-300 tracking-wide">
              {statusBanner}
            </span>
          </div>

          {/* Current 4 Played Cards in the center trick */}
          <div className="relative w-48 h-36 flex items-center justify-center">
            {currentTrick.map((pc, idx) => {
              const posStyles: Record<string, string> = {
                bottom: 'bottom-0 translate-y-2',
                top: 'top-0 -translate-y-2',
                left: 'left-0 -translate-x-6',
                right: 'right-0 translate-x-6',
              };
              return (
                <div
                  key={pc.card.id}
                  className={`absolute w-14 h-20 bg-gradient-to-b from-amber-50 to-amber-100 rounded-lg shadow-2xl border border-amber-400 text-gray-900 font-bold p-1 flex flex-col justify-between transition-all duration-300 transform scale-100 ${
                    posStyles[pc.playerPosition]
                  }`}
                >
                  <div className={`text-xs ${SUIT_COLORS[pc.card.suit]}`}>
                    {pc.card.rank} {SUIT_SYMBOLS[pc.card.suit]}
                  </div>
                  <div className={`text-center text-xl ${SUIT_COLORS[pc.card.suit]}`}>
                    {SUIT_SYMBOLS[pc.card.suit]}
                  </div>
                  <div className={`text-xs text-right ${SUIT_COLORS[pc.card.suit]}`}>
                    {pc.card.rank}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Trump Suit Picker Modal when you win bidding */}
          {phase === 'trump_selection' && (
            <div className="mt-4 p-4 rounded-2xl bg-[#06180f]/95 border-2 border-amber-400 shadow-2xl flex flex-col items-center">
              <span className="text-xs font-bold text-amber-300 mb-2">اختر نوع الطرنيب للجولة:</span>
              <div className="flex gap-3">
                {(['spades', 'hearts', 'diamonds', 'clubs'] as Suit[]).map((st) => (
                  <button
                    key={st}
                    onClick={() => handleSelectTrumpSuit(st)}
                    className="w-12 h-14 rounded-xl bg-black/60 hover:bg-emerald-950 border border-amber-500 flex flex-col items-center justify-center shadow transition-transform active:scale-90"
                  >
                    <span className={`text-2xl ${SUIT_COLORS[st]}`}>{SUIT_SYMBOLS[st]}</span>
                    <span className="text-[10px] text-gray-300 font-bold">{SUIT_ARABIC[st]}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Emoji Bubble Reaction */}
        {activeEmojiReaction && (
          <div className="absolute bottom-28 z-40 text-4xl animate-bounce">
            {activeEmojiReaction.text}
          </div>
        )}
      </div>

      {/* ========================================================
          3. BOTTOM SECTION: CARDS FAN & BIDDING CONTROLS
          Matches IMG-20261009-WA0001.jpg 1:1
         ======================================================== */}
      <div className="relative z-30 flex flex-col items-center pb-2">
        {/* Live Speaking Indicator when talking into mic */}
        {isUserSpeaking && (
          <div className="mb-1 px-3 py-0.5 rounded-full bg-emerald-950/90 border border-emerald-400 text-emerald-300 text-xs font-bold flex items-center gap-1.5 shadow-[0_0_15px_#10b981] animate-pulse">
            <Mic className="w-3.5 h-3.5 text-emerald-400 animate-bounce" />
            <span>أنت تتحدث في المايك مباشرة ({micLevel}dB)...</span>
          </div>
        )}

        {/* Gemini AI Tactical Coach Bar when playing */}
        {phase === 'playing' && (
          <div className="w-full max-w-xl px-4 flex flex-col items-center gap-1.5 my-1 z-30">
            {aiCoachHint && (
              <div className="w-full bg-[#05160d]/95 border border-amber-500/80 p-2.5 rounded-2xl shadow-2xl text-xs text-amber-200 flex items-center justify-between gap-3 animate-in fade-in slide-in-from-bottom-2">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-black font-black shrink-0 shadow">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-bold text-amber-300 text-[11px] flex items-center gap-1.5">
                      <span>مستشار Gemini التكتيكي:</span>
                      <span className="px-1.5 py-0.5 rounded bg-amber-400/20 text-amber-300 text-[10px] font-black border border-amber-400/40">
                        العب {aiCoachHint.suggestedCard.rank} {SUIT_ARABIC[aiCoachHint.suggestedCard.suit as Suit] || aiCoachHint.suggestedCard.suit} 🎴
                      </span>
                    </div>
                    <div className="text-[11px] text-gray-200 mt-0.5 leading-relaxed">{aiCoachHint.tacticalReason}</div>
                  </div>
                </div>
                <button
                  onClick={() => setAiCoachHint(null)}
                  className="text-gray-400 hover:text-white text-xs px-2 py-1 rounded bg-[#0a2315] hover:bg-[#123924] cursor-pointer"
                >
                  ✕
                </button>
              </div>
            )}

            {currentTurnPlayerId === 'player_south' && !aiCoachHint && (
              <button
                onClick={requestGeminiHint}
                disabled={isAiHintLoading}
                className="px-3.5 py-1 rounded-full bg-gradient-to-r from-amber-500 via-amber-400 to-amber-300 hover:from-amber-400 hover:to-amber-200 text-black font-black text-[11px] flex items-center gap-1.5 shadow-lg shadow-amber-500/20 border border-amber-300/60 transition-all active:scale-95 cursor-pointer disabled:opacity-50"
              >
                <Sparkles className={`w-3.5 h-3.5 ${isAiHintLoading ? 'animate-spin' : ''}`} />
                <span>{isAiHintLoading ? 'استشارة Gemini الذكي...' : '💡 استشارة مستشار Gemini AI التكتيكي'}</span>
              </button>
            )}
          </div>
        )}

        {/* Fan of 13 Cards in your Hand */}
        <div className="relative w-full max-w-4xl h-24 md:h-28 flex items-end justify-center px-4 overflow-visible">
          {southHand.map((card, idx) => {
            const total = southHand.length;
            const offset = idx - (total - 1) / 2;
            const rot = offset * 2.5; // Fan curve
            const translateY = Math.abs(offset) * 2;
            const isLegal = phase === 'playing' ? isCardLegal(card, southHand, ledSuit) : true;
            const isMyTurn = phase === 'playing' && currentTurnPlayerId === 'player_south';
            const isSuggested =
              aiCoachHint &&
              aiCoachHint.suggestedCard.rank === card.rank &&
              aiCoachHint.suggestedCard.suit === card.suit;

            return (
              <div
                key={card.id}
                onClick={() => {
                  if (isMyTurn && isLegal) {
                    handlePlayCard(card);
                    if (isSuggested) setAiCoachHint(null);
                  }
                }}
                className={`w-14 h-22 md:w-16 md:h-24 bg-gradient-to-b from-white via-amber-50 to-amber-100 rounded-xl shadow-xl border border-amber-300/80 font-bold p-1 flex flex-col justify-between cursor-pointer transition-all duration-200 select-none -ml-4 md:-ml-3.5 hover:-translate-y-6 hover:shadow-2xl hover:z-50 ${
                  isSuggested
                    ? 'ring-4 ring-amber-400 shadow-[0_0_25px_rgba(251,191,36,0.9)] -translate-y-4 z-40'
                    : isMyTurn && isLegal
                    ? 'hover:ring-2 hover:ring-emerald-400'
                    : !isLegal && isMyTurn
                    ? 'opacity-40 brightness-75 cursor-not-allowed'
                    : ''
                }`}
                style={{
                  transform: `rotate(${rot}deg) translateY(${translateY}px)`,
                }}
              >
                <div className={`text-xs font-black ${SUIT_COLORS[card.suit]}`}>
                  {card.rank}
                  <div className="text-[10px] leading-3">{SUIT_SYMBOLS[card.suit]}</div>
                </div>
                <div className={`text-center text-lg md:text-xl ${SUIT_COLORS[card.suit]}`}>
                  {SUIT_SYMBOLS[card.suit]}
                </div>
                <div className={`text-xs text-right font-black ${SUIT_COLORS[card.suit]}`}>
                  {card.rank}
                </div>
              </div>
            );
          })}
        </div>

        {/* Bidding Controls Bar matching IMG-20261009-WA0001.jpg
            Enforces minimum bid: 30+ score -> min 3; 40+ score -> min 4!
        */}
        {phase === 'bidding' && currentTurnPlayerId === 'player_south' && (
          <div className="w-full max-w-2xl mt-1 px-4 flex flex-col items-center">
            <div className="flex items-center justify-between w-full text-[11px] font-bold text-amber-300 mb-1 px-2">
              <span>أدنى مزايدة مسموحة: {southMinAllowed}</span>
              <span>اختر مزايدتك الملكية</span>
              <span>أعلى طلب حالي: {currentHighestBid}</span>
            </div>

            {/* Bidding Buttons [7] [8] [9] [10] [11] [12] [13] [بس] + toggle for [2..6] */}
            <div className="flex items-center gap-1.5 md:gap-2 bg-[#06180f]/90 border border-amber-500/50 p-1.5 rounded-2xl shadow-xl">
              {/* Option to bid 2..6 if legal */}
              {[2, 3, 4, 5, 6].map((b) => {
                const disabled = b < southMinAllowed || b <= currentHighestBid;
                return (
                  <button
                    key={b}
                    onClick={() => handlePlayerBid(b)}
                    disabled={disabled}
                    className={`w-9 h-8 rounded-lg font-black text-xs border transition-all ${
                      disabled
                        ? 'opacity-30 bg-gray-900 border-gray-800 text-gray-500 cursor-not-allowed'
                        : 'bg-emerald-950/80 hover:bg-emerald-800 border-amber-500/60 text-amber-300'
                    }`}
                    title={`طلب ${b} = ${getBidPoints(b)} نقطة`}
                  >
                    {b}
                  </button>
                );
              })}

              {/* Standard 7..13 buttons as in screenshot */}
              {[7, 8, 9, 10, 11, 12, 13].map((b) => {
                const disabled = b <= currentHighestBid;
                return (
                  <button
                    key={b}
                    onClick={() => handlePlayerBid(b)}
                    disabled={disabled}
                    className={`w-9 h-8 rounded-lg font-black text-xs border transition-all ${
                      disabled
                        ? 'opacity-30 bg-gray-900 border-gray-800 text-gray-500 cursor-not-allowed'
                        : 'bg-gradient-to-b from-amber-600 to-amber-500 hover:from-amber-500 text-black border-amber-400 shadow'
                    }`}
                    title={`طلب ${b} = ${getBidPoints(b)} نقطة`}
                  >
                    {b}
                  </button>
                );
              })}

              {/* Pass Button: [بس] */}
              <button
                onClick={() => handlePlayerBid('pass')}
                className="px-3 h-8 rounded-lg font-bold text-xs bg-red-950 hover:bg-red-900 border border-red-500/50 text-red-200"
              >
                بس
              </button>
            </div>
          </div>
        )}

        {/* Bottom Left & Right Controls matching IMG-20261009-WA0001.jpg:
            Left: Mic 🎙️, Chat 💬, Emoji 😄
            Right: سجل الحركات 📜
        */}
        <div className="w-full px-8 flex items-center justify-between mt-1">
          {/* Bottom Left Controls */}
          <div className="flex items-center gap-2">
            {/* Mic */}
            <div className="relative flex items-center gap-1">
              <button
                onClick={toggleRealMic}
                className={`p-2 rounded-xl border flex items-center justify-center transition-all ${
                  micActive
                    ? 'bg-emerald-600 border-emerald-400 text-white shadow-[0_0_15px_#10b981]'
                    : 'bg-[#06180f] border-amber-900/60 text-gray-400 hover:text-amber-300'
                }`}
                title={micActive ? `المايك متصل ويعمل حقيقياً (${micLevel}%)` : 'تفعيل المايك الحقيقي'}
              >
                {micActive ? <Mic className="w-4 h-4 animate-pulse" /> : <MicOff className="w-4 h-4" />}
              </button>

              {/* Live equalizer indicator */}
              {micActive && (
                <div className="flex items-end gap-0.5 h-3 px-1">
                  {[0.5, 1, 0.7, 0.4].map((mult, i) => (
                    <span
                      key={i}
                      className="w-1 bg-emerald-400 rounded-full transition-all duration-75"
                      style={{
                        height: `${Math.max(2, Math.min(12, (micLevel / 100) * 12 * mult))}px`,
                      }}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Chat */}
            <button
              onClick={() => {
                soundFX.playButtonClick();
                setChatOpen(!chatOpen);
              }}
              className="p-2 rounded-xl bg-[#06180f] border border-amber-900/60 text-gray-300 hover:text-amber-300"
              title="دردشة المباراة"
            >
              <MessageSquare className="w-4 h-4" />
            </button>

            {/* Emoji */}
            <div className="relative">
              <button
                onClick={() => {
                  soundFX.playButtonClick();
                  setEmojiPickerOpen(!emojiPickerOpen);
                }}
                className="p-2 rounded-xl bg-[#06180f] border border-amber-900/60 text-gray-300 hover:text-amber-300"
                title="إيموجيات سريعة"
              >
                <Smile className="w-4 h-4" />
              </button>

              {emojiPickerOpen && (
                <div className="absolute bottom-12 right-0 bg-[#071910] border border-amber-500/50 rounded-xl p-2 shadow-2xl flex gap-2 z-50">
                  {['👑', '🃏', '🔥', '😂', '👏', '🤝'].map((em) => (
                    <button
                      key={em}
                      onClick={() => handleTriggerEmoji(em)}
                      className="text-2xl hover:scale-125 transition-transform p-1"
                    >
                      {em}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Bottom Right: سجل الحركات */}
          <button
            onClick={() => {
              soundFX.playButtonClick();
              setMovesLogOpen(!movesLogOpen);
            }}
            className="px-3 py-1.5 rounded-xl bg-[#06180f] hover:bg-[#0a2718] border border-amber-900/70 text-amber-300 text-xs font-bold flex items-center gap-1.5 shadow"
          >
            <Scroll className="w-3.5 h-3.5" />
            <span>سجل الحركات</span>
          </button>
        </div>
      </div>

      {/* ========================================================
          4. RIGHT SIDEBAR ☰ القائمة (Matching Section 16 & Screenshot)
         ======================================================== */}
      {sidebarOpen && (
        <div className="fixed inset-y-0 right-0 z-50 w-80 bg-[#07130c] border-l-2 border-amber-500/50 shadow-[0_0_40px_rgba(0,0,0,0.9)] flex flex-col text-right animate-in slide-in-from-right duration-200">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#0c2417] to-[#07160e] p-4 border-b border-amber-500/30 flex items-center justify-between">
            <button
              onClick={() => {
                soundFX.playButtonClick();
                setSidebarOpen(false);
              }}
              className="p-1 rounded-full text-gray-400 hover:text-amber-400"
            >
              <X className="w-5 h-5" />
            </button>
            <h3 className="font-bold text-amber-300 text-base flex items-center gap-2">
              <Menu className="w-4 h-4 text-amber-400" />
              <span>قائمة المباراة</span>
            </h3>
          </div>

          {/* Subtabs matching spec point 16 */}
          <div className="grid grid-cols-3 bg-[#040e08] border-b border-amber-950 p-1 text-xs font-bold">
            <button
              onClick={() => setSidebarActiveTab('match')}
              className={`py-2 text-center rounded-lg ${
                sidebarActiveTab === 'match' ? 'bg-emerald-950 text-amber-300 border border-amber-500/40' : 'text-gray-400'
              }`}
            >
              المباراة
            </button>
            <button
              onClick={() => setSidebarActiveTab('chat')}
              className={`py-2 text-center rounded-lg ${
                sidebarActiveTab === 'chat' ? 'bg-emerald-950 text-amber-300 border border-amber-500/40' : 'text-gray-400'
              }`}
            >
              التواصل
            </button>
            <button
              onClick={() => setSidebarActiveTab('settings')}
              className={`py-2 text-center rounded-lg ${
                sidebarActiveTab === 'settings' ? 'bg-emerald-950 text-amber-300 border border-amber-500/40' : 'text-gray-400'
              }`}
            >
              الإعدادات
            </button>
          </div>

          {/* Body */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 text-xs">
            {sidebarActiveTab === 'match' && (
              <div className="space-y-4">
                {/* 1. Players info */}
                <div className="space-y-2">
                  <h4 className="font-bold text-amber-300">اللاعبون والفرق:</h4>
                  {players.map((p) => (
                    <div
                      key={p.id}
                      className="flex items-center justify-between p-2 rounded-lg bg-[#05110a] border border-amber-950"
                    >
                      <div className="flex items-center gap-2">
                        <img src={p.avatar} alt={p.name} className="w-8 h-8 rounded-full border border-amber-400 object-cover" />
                        <div>
                          <div className="font-bold text-white">{p.name}</div>
                          <div className="text-[10px] text-gray-400">{p.team === 1 ? 'فريقك (1)' : 'فريق الخصم (2)'}</div>
                        </div>
                      </div>
                      <div className="font-mono font-bold text-amber-400">{p.score} نقطة</div>
                    </div>
                  ))}
                </div>

                {/* 2. Round Details */}
                <div className="p-3 bg-[#05110a] rounded-xl border border-amber-950 space-y-1">
                  <div className="font-bold text-amber-300 mb-1">تفاصيل الجولة الحالية:</div>
                  <div className="flex justify-between text-gray-300">
                    <span>اللمّة:</span>
                    <span className="font-bold">{trickNumber} / 13</span>
                  </div>
                  <div className="flex justify-between text-gray-300">
                    <span>أعلى طلب:</span>
                    <span className="font-bold text-amber-400">{currentHighestBid}</span>
                  </div>
                  <div className="flex justify-between text-gray-300">
                    <span>قيمة الطلب:</span>
                    <span className="font-bold text-emerald-400">{getBidPoints(currentHighestBid)} نقطة</span>
                  </div>
                </div>
              </div>
            )}

            {sidebarActiveTab === 'chat' && (
              <div className="space-y-3 h-full flex flex-col justify-between">
                <div className="space-y-2 flex-1 max-h-[45vh] overflow-y-auto">
                  {chatLog.map((c, i) => (
                    <div key={i} className="p-2 rounded-lg bg-[#05110a] border border-amber-950/60">
                      <div className="flex items-center justify-between text-[10px] text-amber-400 font-bold mb-1">
                        <span>{c.sender}</span>
                        <span className="text-gray-500 font-mono">{c.time}</span>
                      </div>
                      <p className="text-gray-200">{c.text}</p>
                    </div>
                  ))}
                </div>

                <form onSubmit={handleSendCustomChat} className="flex gap-2">
                  <input
                    type="text"
                    value={customChatMessage}
                    onChange={(e) => setCustomChatMessage(e.target.value)}
                    placeholder="اكتب رسالة للطاولة..."
                    className="flex-1 bg-[#040e08] border border-amber-900 rounded-lg p-2 text-white text-xs focus:outline-none"
                  />
                  <button type="submit" className="px-3 bg-amber-500 text-black font-bold rounded-lg text-xs">
                    إرسال
                  </button>
                </form>
              </div>
            )}

            {sidebarActiveTab === 'settings' && (
              <div className="space-y-4">
                <div>
                  <h4 className="font-bold text-amber-300 mb-2">شكل قماش الطاولة:</h4>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'emerald', label: 'الزمرد 🟢' },
                      { id: 'obsidian', label: 'الفحم 🖤' },
                      { id: 'ruby', label: 'الياقوت 🔴' },
                    ].map((st) => (
                      <button
                        key={st.id}
                        onClick={() => setTableStyle(st.id as any)}
                        className={`p-2 rounded-lg border text-center font-bold ${
                          tableStyle === st.id
                            ? 'bg-amber-500/20 text-amber-300 border-amber-400'
                            : 'bg-[#05110a] border-amber-950 text-gray-400'
                        }`}
                      >
                        {st.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Safety & Leave Match as specified in point 16 */}
                <div className="pt-4 border-t border-amber-950 space-y-2">
                  <h4 className="font-bold text-red-400">الأمان والمغادرة:</h4>
                  <button
                    onClick={() => {
                      if (confirm('هل أنت متأكد من مغادرة المباراة والعودة للّوبي؟')) {
                        soundFX.playButtonClick();
                        onExitGame();
                      }
                    }}
                    className="w-full py-2.5 rounded-xl bg-red-950/80 hover:bg-red-900 border border-red-500/50 text-red-200 font-bold flex items-center justify-center gap-2"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>مغادرة المباراة والعودة للّوبي</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Floating Moves Log Dialog */}
      {movesLogOpen && (
        <div className="fixed bottom-14 left-8 z-50 w-80 bg-[#07160e]/95 border-2 border-amber-500/60 rounded-2xl p-4 shadow-2xl text-right">
          <div className="flex items-center justify-between pb-2 border-b border-amber-950 mb-2">
            <button onClick={() => setMovesLogOpen(false)} className="text-gray-400 hover:text-amber-400">
              <X className="w-4 h-4" />
            </button>
            <h4 className="font-bold text-xs text-amber-300 flex items-center gap-1.5">
              <Scroll className="w-3.5 h-3.5" />
              سجل حركات الجولة
            </h4>
          </div>
          <div className="space-y-1.5 max-h-48 overflow-y-auto text-[11px] text-gray-300">
            {movesHistory.map((m, i) => (
              <div key={i} className="p-1.5 rounded bg-[#040d07] border border-amber-950/50">
                {m}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Round End & Win at 41 Modal */}
      {roundResultModal.show && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4">
          <div className="relative w-full max-w-md bg-[#07160e] border-2 border-amber-400 rounded-3xl p-6 text-center space-y-4 shadow-[0_0_50px_rgba(245,158,11,0.5)]">
            <Crown className="w-16 h-16 text-amber-400 mx-auto animate-bounce" />
            <h3 className="text-2xl font-black text-amber-300">{roundResultModal.title}</h3>
            <p className="text-xs text-emerald-300 font-semibold">{roundResultModal.details}</p>

            {/* Scores summary */}
            {roundResultModal.scoresSummary && (
              <div className="p-4 bg-[#040e08] rounded-xl border border-amber-950 space-y-1 font-mono text-xs text-right">
                <div className="flex justify-between">
                  <span className="text-gray-400">أحمد (الشريك):</span>
                  <span className="text-amber-400 font-bold">{roundResultModal.scoresSummary.top}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">سامي (الخصم):</span>
                  <span className="text-gray-200">{roundResultModal.scoresSummary.left}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">ليلى (الخصم):</span>
                  <span className="text-gray-200">{roundResultModal.scoresSummary.right}</span>
                </div>
                <div className="flex justify-between font-bold text-amber-300 border-t border-amber-950 pt-1">
                  <span>أنت ({currentUser.name}):</span>
                  <span>{roundResultModal.scoresSummary.bottom}</span>
                </div>
              </div>
            )}

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => {
                  soundFX.playButtonClick();
                  onExitGame();
                }}
                className="flex-1 py-2.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-300 font-bold text-xs"
              >
                العودة للّوبي
              </button>
              <button
                onClick={() => {
                  soundFX.playButtonClick();
                  setRoundResultModal({ ...roundResultModal, show: false });
                  setRoundNumber((r) => r + 1);
                  startNewRound();
                }}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 text-black font-extrabold text-xs shadow-lg"
              >
                الجولة التالية &rarr;
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
