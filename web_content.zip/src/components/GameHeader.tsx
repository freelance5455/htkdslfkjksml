import React from 'react';
import { Sparkles, Settings, ArrowLeft, Plus, Coins, Star } from 'lucide-react';
import { sound } from '../utils/audio';
import { SpecialChallengeType } from '../types/game';

interface GameHeaderProps {
  levelNumber: number;
  moves: number;
  threeStarTarget: number;
  twoStarTarget: number;
  coins: number;
  specialType: SpecialChallengeType;
  maxMoves?: number;
  timeRemaining?: number;
  isDailyChallenge?: boolean;
  onBackToMenu: () => void;
  onOpenSettings: () => void;
  onOpenShop: () => void;
}

export const GameHeader: React.FC<GameHeaderProps> = ({
  levelNumber,
  moves,
  threeStarTarget,
  twoStarTarget,
  coins,
  specialType,
  maxMoves,
  timeRemaining,
  isDailyChallenge = false,
  onBackToMenu,
  onOpenSettings,
  onOpenShop,
}) => {
  // Compute star rating live
  let currentStars = 3;
  if (moves > threeStarTarget) currentStars = 2;
  if (moves > twoStarTarget) currentStars = 1;

  return (
    <header className="w-full max-w-lg mx-auto px-3 pt-2 pb-1 flex flex-col gap-1.5 z-20 select-none shrink-0 touch-manipulation">
      {/* Top Main Bar */}
      <div className="flex items-center justify-between gap-2">
        {/* Menu / Back Button */}
        <button
          onClick={() => {
            sound.playClick();
            onBackToMenu();
          }}
          className="crystal-button min-h-[44px] flex items-center gap-1.5 px-3.5 py-2 rounded-2xl border-slate-700/60 text-slate-200 hover:text-white active:scale-95 transition-all shadow-md shrink-0 touch-manipulation cursor-pointer"
        >
          <ArrowLeft className="w-4.5 h-4.5 text-slate-300" />
          <span className="text-xs font-black tracking-wide">Menu</span>
        </button>

        {/* Level Title & Star Rating */}
        <div className="flex flex-col items-center justify-center">
          <div className="flex items-center gap-1.5">
            {isDailyChallenge ? (
              <span className="text-sm sm:text-base font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-rose-300 via-amber-200 to-yellow-300 flex items-center gap-1 drop-shadow-[0_2px_8px_rgba(244,63,94,0.6)]">
                🔥 DAILY EVENT
              </span>
            ) : (
              <h1 className="text-base sm:text-lg font-black tracking-tight text-white flex items-center gap-1 drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]">
                Level {levelNumber}
              </h1>
            )}
            {specialType !== 'normal' && (
              <span className="text-[9px] uppercase font-black px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/50 shadow-[0_0_8px_rgba(245,158,11,0.4)]">
                {specialType === 'limitedMoves' && 'Moves'}
                {specialType === 'mystery' && 'Mystery'}
                {specialType === 'lockedTube' && 'Locked'}
                {specialType === 'noUndo' && 'No Undo'}
                {specialType === 'timeChallenge' && 'Timer'}
              </span>
            )}
          </div>

          {/* Live Star Meter */}
          <div className="flex items-center gap-1 mt-0.5">
            {[1, 2, 3].map((star) => (
              <Star
                key={star}
                className={`w-3.5 h-3.5 transition-all duration-300 ${
                  star <= currentStars
                    ? 'text-yellow-400 fill-yellow-400 drop-shadow-[0_0_6px_rgba(250,204,21,0.9)]'
                    : 'text-slate-600 fill-slate-800'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Coins Pill & Settings */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={() => {
              sound.playClick();
              onOpenShop();
            }}
            className="crystal-button min-h-[44px] flex items-center gap-1.5 px-3 py-2 rounded-2xl border-amber-500/40 text-amber-300 active:scale-95 transition-all shadow-[0_2px_10px_rgba(245,158,11,0.25)] group touch-manipulation"
          >
            <Coins className="w-4 h-4 text-yellow-400 group-hover:rotate-12 transition-transform drop-shadow-[0_0_4px_rgba(250,204,21,0.7)]" />
            <span className="text-xs font-black tracking-wide">{coins}</span>
            <Plus className="w-3 h-3 text-amber-300 bg-amber-500/40 rounded-full" />
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onOpenSettings();
            }}
            className="crystal-button min-h-[44px] min-w-[44px] flex items-center justify-center p-2 rounded-2xl border-slate-700/60 text-slate-300 hover:text-white active:scale-95 transition-all shadow-md touch-manipulation"
          >
            <Settings className="w-4.5 h-4.5" />
          </button>
        </div>
      </div>

      {/* Sub Info Pill: Moves & Star Target */}
      <div className="crystal-card flex items-center justify-between px-3.5 py-1.5 rounded-xl text-[11px] font-semibold text-slate-300 shadow-md">
        <div className="flex items-center gap-1.5">
          <span className="text-slate-400 font-black uppercase tracking-wider text-[10px]">Moves:</span>
          <span className="text-xs font-black text-cyan-300 px-2 py-0.2 rounded-md bg-cyan-950/80 border border-cyan-500/40 shadow-inner">
            {moves}
          </span>
          {maxMoves !== undefined && (
            <span className="text-[10px] text-amber-400 font-black">
              / {maxMoves} Max
            </span>
          )}
        </div>

        {timeRemaining !== undefined && (
          <div className="flex items-center gap-1 text-rose-400 font-black bg-rose-950/60 px-2 py-0.5 rounded border border-rose-500/40 animate-pulse">
            <span>⏱ {timeRemaining}s</span>
          </div>
        )}

        <div className="flex items-center gap-2 text-[10px] text-slate-400 font-medium">
          <span>3★: <strong className="text-yellow-400 font-black">≤{threeStarTarget}</strong></span>
          <span>2★: <strong className="text-slate-200 font-black">≤{twoStarTarget}</strong></span>
        </div>
      </div>
    </header>
  );
};
