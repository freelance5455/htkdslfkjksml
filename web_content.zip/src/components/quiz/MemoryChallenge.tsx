import React, { useState, useEffect, useRef } from 'react';
import { MEMORY_CHALLENGE_CARDS, MemoryRadiographCard } from '../../data/memoryChallengeData';
import { RadiographCanvas } from './RadiographCanvas';
import { Language } from '../../types';
import { soundManager } from '../../utils/audio';
import { 
  Eye, 
  EyeOff, 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  Sparkles, 
  Award, 
  RotateCcw, 
  Zap, 
  ArrowLeft,
  ChevronRight,
  ShieldAlert
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface Props {
  language: Language;
  soundEnabled: boolean;
  onAddXp: (amount: number) => void;
  onClose: () => void;
}

type StepState = 'ready' | 'flashing' | 'question' | 'reviewed';

export const MemoryChallenge: React.FC<Props> = ({
  language,
  soundEnabled,
  onAddXp,
  onClose
}) => {
  const [deck, setDeck] = useState<MemoryRadiographCard[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [stepState, setStepState] = useState<StepState>('ready');
  const [secondsLeft, setSecondsLeft] = useState<number>(5);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [showImageInReview, setShowImageInReview] = useState(false);

  const timerRef = useRef<number | null>(null);

  // Initialize a random 5-card deck
  useEffect(() => {
    const shuffled = [...MEMORY_CHALLENGE_CARDS].sort(() => 0.5 - Math.random()).slice(0, 5);
    setDeck(shuffled);
    setCurrentIndex(0);
    setScore(0);
    setIsFinished(false);
    setStepState('ready');
  }, []);

  const currentCard = deck[currentIndex];

  // Start 5-second countdown when transitioning to 'flashing'
  useEffect(() => {
    if (stepState === 'flashing') {
      setSecondsLeft(5);
      soundManager.playSlash(soundEnabled);

      timerRef.current = window.setInterval(() => {
        setSecondsLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            setStepState('question');
            soundManager.playTick(soundEnabled);
            return 0;
          }
          soundManager.playTick(soundEnabled);
          return prev - 1;
        });
      }, 1000);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [stepState, soundEnabled]);

  const handleStartRound = () => {
    setSelectedOption(null);
    setShowImageInReview(false);
    setStepState('flashing');
  };

  const handleSelectAnswer = (optionIdx: number) => {
    if (stepState !== 'question' || selectedOption !== null) return;
    setSelectedOption(optionIdx);
    setStepState('reviewed');

    const isCorrect = optionIdx === currentCard.correctIndex;
    if (isCorrect) {
      setScore((s) => s + 1);
      soundManager.playSuccess(soundEnabled);
      onAddXp(50);
    } else {
      soundManager.playError(soundEnabled);
    }
  };

  const handleNextRound = () => {
    if (currentIndex + 1 < deck.length) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedOption(null);
      setShowImageInReview(false);
      setStepState('ready');
      soundManager.playTick(soundEnabled);
    } else {
      // Completed all 5 rounds
      setIsFinished(true);
      const totalBonusXp = score === 5 ? 150 : score * 30;
      onAddXp(totalBonusXp);
      soundManager.playRankUp(soundEnabled);
      try {
        confetti({ particleCount: 100, spread: 80, origin: { y: 0.6 } });
      } catch {}
    }
  };

  const handleRestart = () => {
    const shuffled = [...MEMORY_CHALLENGE_CARDS].sort(() => 0.5 - Math.random()).slice(0, 5);
    setDeck(shuffled);
    setCurrentIndex(0);
    setScore(0);
    setIsFinished(false);
    setSelectedOption(null);
    setShowImageInReview(false);
    setStepState('ready');
    soundManager.playSlash(soundEnabled);
  };

  if (!currentCard) return null;

  return (
    <div className="flex flex-col gap-5 max-w-2xl mx-auto w-full text-right animate-fade-in">
      {/* Header bar */}
      <div className="flex items-center justify-between bg-slate-950/90 p-4 rounded-2xl border border-purple-500/40 shadow-neon-purple">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-purple-900/60 border border-purple-400 flex items-center justify-center text-purple-300">
            <Eye className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-black text-slate-100 flex items-center gap-1.5">
              <span>تحدي الذاكرة الشعاعية (Flash X-Ray Challenge)</span>
              <span className="text-[10px] bg-purple-950 text-purple-300 px-2 py-0.5 rounded-full border border-purple-800 font-mono">
                5 ثوانٍ
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              الجولة {currentIndex + 1} من {deck.length} • النتيجة الحالية: {score}
            </p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="text-xs text-slate-400 hover:text-white bg-slate-900 px-3 py-1.5 rounded-xl border border-purple-900 transition-colors"
        >
          خروج
        </button>
      </div>

      {!isFinished ? (
        <div className="bg-slate-950/90 p-5 md:p-6 rounded-3xl border border-purple-500/40 shadow-2xl relative overflow-hidden">
          {/* Step 1: Ready Screen */}
          {stepState === 'ready' && (
            <div className="text-center py-8 space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-purple-950/80 border border-purple-500/60 mx-auto flex items-center justify-center text-purple-300 shadow-neon-purple">
                <Clock className="w-8 h-8 animate-pulse text-purple-400" />
              </div>

              <div>
                <h4 className="text-lg font-black text-slate-100">
                  الجولة {currentIndex + 1}: استعد للتركيز البصري!
                </h4>
                <p className="text-xs text-slate-300 max-w-md mx-auto mt-2 leading-relaxed">
                  ستظهر صورة إشعاعية أو مقطع سكانير لمدة <strong className="text-yellow-400">5 ثوانٍ فقط</strong> ثم تُحجب في الظلال.
                  احفظ بنية العضو، العلامات الكثافية، وأي شذوذ مرضي بدقة.
                </p>
              </div>

              <div className="flex justify-center pt-2">
                <button
                  onClick={handleStartRound}
                  className="px-8 py-3 bg-gradient-to-r from-purple-600 to-rose-600 hover:from-purple-500 text-white font-black text-xs md:text-sm rounded-xl shadow-neon-purple active:scale-95 transition-all"
                >
                  ابدأ عرض الصورة (5 ثوانٍ) 🔥
                </button>
              </div>
            </div>
          )}

          {/* Step 2: Flashing Image with 5-Second Countdown */}
          {stepState === 'flashing' && (
            <div className="flex flex-col gap-4">
              {/* Animated Countdown Timer Bar */}
              <div className="flex items-center justify-between bg-black/60 px-4 py-2 rounded-xl border border-purple-900/50">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-rose-400 animate-spin" />
                  <span className="text-xs font-bold text-slate-200">
                    الوقت المتبقي لحفظ الصورة:
                  </span>
                </div>
                <div className="flex items-center gap-2 font-mono">
                  <span className="text-lg font-black text-rose-400">
                    {secondsLeft}s
                  </span>
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden border border-purple-900">
                <div
                  className="h-full bg-gradient-to-r from-purple-500 to-rose-500 transition-all duration-1000 ease-linear"
                  style={{ width: `${(secondsLeft / 5) * 100}%` }}
                />
              </div>

              {/* The Radiograph Image */}
              <RadiographCanvas card={currentCard} showOverlayAnnotations={false} />

              <p className="text-center text-xs text-purple-300 font-bold animate-pulse">
                ركز في تفاصيل العظام، الأنسجة الرخوة، والعلامات الشعاعية!
              </p>
            </div>
          )}

          {/* Step 3: Image Masked & Question Options Displayed */}
          {stepState === 'question' && (
            <div className="flex flex-col gap-5">
              {/* Masked Card Banner */}
              <div className="w-full h-40 bg-black/80 rounded-2xl border-2 border-dashed border-purple-900/80 flex flex-col items-center justify-center gap-2 text-center p-4">
                <EyeOff className="w-10 h-10 text-purple-400 opacity-80" />
                <span className="text-xs font-black text-purple-300">
                  تم حجب الصورة الإشعاعية في الظلال!
                </span>
                <span className="text-[11px] text-slate-400">
                  استحضر ما رأيته في الذاكرة واجب عن السؤال أدناه
                </span>
              </div>

              {/* Question */}
              <div>
                <h4 className="text-sm md:text-base font-black text-slate-100 mb-1">
                  ما هو العضو أو التشخيص الشعاعي الدقيق الذي ظهر في الصورة؟
                </h4>
                <p className="text-[11px] text-slate-400">
                  اختر الإجابة الصحيحة لكسب +50 XP
                </p>
              </div>

              {/* Options */}
              <div className="space-y-2.5">
                {currentCard.optionsAr.map((opt, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSelectAnswer(idx)}
                    className="w-full text-right p-3.5 bg-slate-900/70 hover:bg-purple-950/60 border border-purple-900/40 hover:border-purple-500/60 rounded-xl text-xs md:text-sm font-semibold text-slate-200 transition-all active:scale-95 flex items-center justify-between"
                  >
                    <span>{opt}</span>
                    <span className="w-6 h-6 rounded-full border border-purple-700/60 flex items-center justify-center text-xs text-purple-300 font-mono flex-shrink-0 mr-2">
                      {idx + 1}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 4: Reviewed State with Explanation & Option to Re-Inspect Radiograph */}
          {stepState === 'reviewed' && (
            <div className="flex flex-col gap-4">
              {/* Feedback Alert */}
              <div
                className={`p-4 rounded-2xl border text-xs md:text-sm leading-relaxed ${
                  selectedOption === currentCard.correctIndex
                    ? 'bg-emerald-950/70 border-emerald-500 text-emerald-200'
                    : 'bg-rose-950/70 border-rose-500 text-rose-200'
                }`}
              >
                <div className="font-black mb-1 flex items-center gap-1.5 text-base">
                  {selectedOption === currentCard.correctIndex ? (
                    <>
                      <CheckCircle className="w-5 h-5 text-emerald-400" />
                      <span>ذاكرة وبصيرة خارقة! +50 XP</span>
                    </>
                  ) : (
                    <>
                      <AlertCircle className="w-5 h-5 text-rose-400" />
                      <span>لم تصب الهدف! التشخيص الصحيح هو:</span>
                    </>
                  )}
                </div>
                <p className="font-bold text-slate-100 mt-1">
                  {currentCard.optionsAr[currentCard.correctIndex]}
                </p>
                <p className="text-xs text-slate-300 mt-2 font-mono">
                  {currentCard.explanationAr}
                </p>
              </div>

              {/* Toggle Re-inspect radiograph */}
              <div className="flex items-center justify-between bg-black/50 p-3 rounded-xl border border-purple-900/40">
                <span className="text-xs font-bold text-slate-300">
                  هل تريد مراجعة الصورة الإشعاعية مع العلامات التوضيحية؟
                </span>
                <button
                  onClick={() => setShowImageInReview(!showImageInReview)}
                  className="px-3 py-1.5 bg-purple-900/60 hover:bg-purple-800 text-purple-200 text-xs font-bold rounded-lg border border-purple-500/40 transition-colors"
                >
                  {showImageInReview ? 'إخفاء الصورة' : 'إظهار الصورة والشرح'}
                </button>
              </div>

              {/* Radiograph with annotations shown */}
              {showImageInReview && (
                <div className="space-y-2 animate-fade-in">
                  <RadiographCanvas card={currentCard} showOverlayAnnotations={true} />
                  <div className="bg-purple-950/30 p-3 rounded-xl border border-purple-800/40 text-xs text-slate-200">
                    <span className="font-bold text-purple-300 block mb-1">
                      العلامات المفتاحية في الصورة (Signes clés) :
                    </span>
                    <ul className="list-disc list-inside space-y-0.5 text-[11px] text-slate-300">
                      {currentCard.keySigns.map((sign, sIdx) => (
                        <li key={sIdx}>{sign}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              {/* Clinical Field Tip */}
              <div className="bg-emerald-950/20 border border-emerald-900/40 p-3 rounded-xl text-[11px] text-emerald-300">
                <span className="font-bold">💡 نصيحة ميدانية لتقني الأشعة: </span>
                {currentCard.clinicalTipAr}
              </div>

              {/* Next Round Button */}
              <button
                onClick={handleNextRound}
                className="w-full py-3.5 bg-gradient-to-r from-purple-600 to-rose-600 hover:from-purple-500 text-white font-extrabold text-xs md:text-sm rounded-xl shadow-neon-purple active:scale-95 transition-all mt-2"
              >
                {currentIndex + 1 < deck.length ? 'الانتقال إلى الجولة التالية ➔' : 'عرض النتيجة النهائية 🏆'}
              </button>
            </div>
          )}
        </div>
      ) : (
        /* Final Results Screen */
        <div className="bg-slate-950/90 p-8 rounded-3xl border border-purple-500/50 shadow-neon-purple text-center max-w-md mx-auto w-full animate-scale-up">
          <Award className="w-16 h-16 text-yellow-400 mx-auto mb-3 animate-bounce" />
          <h3 className="text-xl font-black text-slate-100 mb-1">
            اكتمل تحدي الذاكرة الشعاعية!
          </h3>
          <p className="text-xs text-purple-300 mb-5">
            نتيجتك: <span className="font-mono text-base font-bold text-yellow-400">{score}</span> من أصل{' '}
            <span className="font-mono text-base font-bold text-slate-200">{deck.length}</span> صور
          </p>

          <div className="bg-black/60 p-4 rounded-2xl border border-purple-900/40 mb-6 text-right text-xs space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">دقة الذاكرة البصرية:</span>
              <span className="font-bold text-purple-300">
                {Math.round((score / deck.length) * 100)}%
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">إجمالي نقاط الخبرة المكتسبة:</span>
              <span className="font-bold text-yellow-400 font-mono">
                +{score * 50 + (score === 5 ? 150 : score * 30)} XP
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">تقييم بصر الصياد:</span>
              <span className="font-bold text-emerald-400">
                {score >= 4 ? 'عين صقر شعاعية (Élite)' : score >= 2 ? 'ممارس واعد' : 'يحتاج لمزيد من التدريب'}
              </span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={handleRestart}
              className="flex-1 py-3 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl shadow-neon-purple transition-all active:scale-95"
            >
              جولة جديدة بصور أخرى
            </button>
            <button
              onClick={onClose}
              className="flex-1 py-3 bg-slate-900 hover:bg-slate-800 text-slate-300 font-bold text-xs rounded-xl border border-purple-900 transition-all active:scale-95"
            >
              العودة إلى ساحة الاختبارات
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
