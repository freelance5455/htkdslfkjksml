import React, { useState } from 'react';
import { QUIZ_QUESTIONS } from '../../data/quizQuestions';
import { QuizQuestion, Language, HunterProfile } from '../../types';
import { soundManager } from '../../utils/audio';
import { MemoryChallenge } from './MemoryChallenge';
import { 
  Trophy, 
  Clock, 
  RotateCcw, 
  CheckCircle, 
  AlertCircle, 
  Award, 
  HelpCircle, 
  Sparkles,
  Zap,
  Target,
  Eye
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface Props {
  profile: HunterProfile;
  language: Language;
  soundEnabled: boolean;
  onAddXp: (amount: number) => void;
  onRecordMistake: (questionId: string) => void;
  onClearMistake: (questionId: string) => void;
}

export const QuizArena: React.FC<Props> = ({
  profile,
  language,
  soundEnabled,
  onAddXp,
  onRecordMistake,
  onClearMistake
}) => {
  const [arenaMode, setArenaMode] = useState<'quick' | 'exam' | 'mistakes' | 'memory'>('quick');
  const [isPlaying, setIsPlaying] = useState(false);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswerChecked, setIsAnswerChecked] = useState(false);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  // Start Quiz
  const handleStartQuiz = (mode: 'quick' | 'exam' | 'mistakes' | 'memory') => {
    setArenaMode(mode);

    if (mode === 'memory') {
      setIsPlaying(true);
      soundManager.playSlash(soundEnabled);
      return;
    }

    let qList: QuizQuestion[] = [];

    if (mode === 'mistakes') {
      qList = QUIZ_QUESTIONS.filter((q) => profile.mistakeQuestionIds.includes(q.id));
      if (qList.length === 0) {
        qList = QUIZ_QUESTIONS.slice(0, 5); // Fallback if no mistakes yet
      }
    } else if (mode === 'exam') {
      // 10 comprehensive questions
      qList = [...QUIZ_QUESTIONS].sort(() => 0.5 - Math.random());
    } else {
      // 5 questions
      qList = [...QUIZ_QUESTIONS].sort(() => 0.5 - Math.random()).slice(0, 5);
    }

    setQuestions(qList);
    setCurrentIndex(0);
    setSelectedAnswer(null);
    setIsAnswerChecked(false);
    setScore(0);
    setIsFinished(false);
    setIsPlaying(true);
    soundManager.playSlash(soundEnabled);
  };

  const handleCheckAnswer = () => {
    if (selectedAnswer === null || questions.length === 0) return;
    const currentQ = questions[currentIndex];
    const isCorrect = selectedAnswer === currentQ.correctIndex;

    setIsAnswerChecked(true);

    if (isCorrect) {
      setScore((prev) => prev + 1);
      soundManager.playSuccess(soundEnabled);
      if (arenaMode === 'mistakes') {
        onClearMistake(currentQ.id);
      }
    } else {
      soundManager.playError(soundEnabled);
      onRecordMistake(currentQ.id);
    }
  };

  const handleNext = () => {
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedAnswer(null);
      setIsAnswerChecked(false);
      soundManager.playTick(soundEnabled);
    } else {
      // Finished Quiz
      setIsFinished(true);
      const xpGained = score * 30 + (score === questions.length ? 100 : 0);
      onAddXp(xpGained);
      soundManager.playRankUp(soundEnabled);
      try {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.6 }
        });
      } catch {}
    }
  };

  const currentQ = questions[currentIndex];

  return (
    <div className="flex flex-col gap-6">
      {/* Arena Banner */}
      <div className="bg-gradient-to-r from-purple-950 via-slate-950 to-rose-950 p-5 rounded-2xl border border-purple-500/40 shadow-neon-purple text-right">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          <div>
            <h2 className="text-xl md:text-2xl font-black text-slate-100 flex items-center gap-2">
              <Trophy className="w-6 h-6 text-yellow-400" />
              <span>ساحة التحديات واختبارات الأشعة (Quiz & Exam Arena)</span>
            </h2>
            <p className="text-xs text-slate-300 mt-1">
              اختر وضع التدريب المفضل: تحدي الذاكرة البصرية، التدريب السريع، محاكاة مسابقات الشبه طبي، أو مراجعة الأخطاء.
            </p>
          </div>

          <div className="bg-black/60 px-3.5 py-1.5 rounded-xl border border-purple-900 text-xs text-purple-300 font-mono">
            الأسئلة المسجلة: {QUIZ_QUESTIONS.length} سؤال
          </div>
        </div>
      </div>

      {!isPlaying ? (
        /* Mode Selection Cards Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* 1. Flash Memory Challenge (NEW FEATURE) */}
          <div className="relative bg-gradient-to-b from-purple-950/80 via-slate-950 to-slate-900 p-5 rounded-2xl border-2 border-cyan-500/60 hover:border-cyan-400 shadow-neon-cyan transition-all flex flex-col justify-between text-right overflow-hidden group">
            {/* Solo Leveling Flash Badge */}
            <div className="absolute top-3 left-3 bg-cyan-950 text-cyan-300 border border-cyan-500/50 text-[10px] font-extrabold px-2 py-0.5 rounded-full font-mono">
              NEW • 5 SECONDS
            </div>

            <div>
              <div className="w-11 h-11 rounded-xl bg-cyan-950/80 flex items-center justify-center text-cyan-300 mb-3 border border-cyan-400/50 group-hover:scale-105 transition-transform">
                <Eye className="w-6 h-6 text-cyan-400 animate-pulse" />
              </div>
              <h3 className="text-base font-black text-slate-100 mb-1 flex items-center gap-1.5">
                <span>تحدي الذاكرة الشعاعية</span>
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed mb-4">
                تظهر صورة إشعاعية لمدة <strong className="text-cyan-300">5 ثوانٍ فقط</strong> ثم تُحجب! اختبر ذاكرتك البصرية وحدد العضو أو التشخيص لكسب نقاط خبرة مضاعفة.
              </p>
            </div>
            <button
              onClick={() => handleStartQuiz('memory')}
              className="w-full py-2.5 bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white font-extrabold text-xs rounded-xl shadow-lg transition-all active:scale-95"
            >
              بدء تحدي الذاكرة (5s) 🔥
            </button>
          </div>

          {/* 2. Quick Practice */}
          <div className="bg-slate-950/80 p-5 rounded-2xl border border-purple-900/40 hover:border-purple-500/60 transition-all flex flex-col justify-between text-right shadow-lg">
            <div>
              <div className="w-10 h-10 rounded-xl bg-purple-900/50 flex items-center justify-center text-purple-300 mb-3 border border-purple-500/30">
                <Zap className="w-5 h-5" />
              </div>
              <h3 className="text-base font-extrabold text-slate-100 mb-1">
                تدريب سريع (5 أسئلة)
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                جولة تدريبية خفيفة وسريعة لتثبيت المعلومات الشعاعية والفيزيائية وكسب نقاط خبرة فورية.
              </p>
            </div>
            <button
              onClick={() => handleStartQuiz('quick')}
              className="w-full py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl shadow-neon-purple transition-all active:scale-95"
            >
              بدء التدريب السريع
            </button>
          </div>

          {/* 3. Exam Simulator */}
          <div className="bg-slate-950/80 p-5 rounded-2xl border border-rose-900/40 hover:border-rose-500/60 transition-all flex flex-col justify-between text-right shadow-lg">
            <div>
              <div className="w-10 h-10 rounded-xl bg-rose-900/50 flex items-center justify-center text-rose-300 mb-3 border border-rose-500/30">
                <Target className="w-5 h-5" />
              </div>
              <h3 className="text-base font-extrabold text-slate-100 mb-1">
                محاكاة مسابقات الشبه طبي
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                امتحان شامل يحاكي امتحانات الترقية والمسابقات الرسمية بالمعاهد الوطنية للشبه طبي DZ.
              </p>
            </div>
            <button
              onClick={() => handleStartQuiz('exam')}
              className="w-full py-2.5 bg-gradient-to-r from-rose-600 to-purple-600 hover:from-rose-500 text-white font-bold text-xs rounded-xl shadow-neon-crimson transition-all active:scale-95"
            >
              بدء الامتحان التجريبي
            </button>
          </div>

          {/* 4. Dungeon of Mistakes */}
          <div className="bg-slate-950/80 p-5 rounded-2xl border border-amber-900/40 hover:border-amber-500/60 transition-all flex flex-col justify-between text-right shadow-lg">
            <div>
              <div className="w-10 h-10 rounded-xl bg-amber-900/50 flex items-center justify-center text-amber-300 mb-3 border border-amber-500/30">
                <RotateCcw className="w-5 h-5" />
              </div>
              <div className="flex items-center justify-between mb-1">
                <h3 className="text-base font-extrabold text-slate-100">
                  سرداب الأخطاء السابقة
                </h3>
                <span className="text-xs bg-amber-950 text-amber-400 px-2 py-0.5 rounded-full border border-amber-800 font-mono">
                  {profile.mistakeQuestionIds.length}
                </span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                إعادة اختبار الأسئلة التي أخطأت فيها سابقاً لضمان عدم تكرار الخطأ في الفحص الحقيقي.
              </p>
            </div>
            <button
              onClick={() => handleStartQuiz('mistakes')}
              className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs rounded-xl shadow-lg transition-all active:scale-95"
            >
              مراجعة وتصحيح الأخطاء
            </button>
          </div>
        </div>
      ) : arenaMode === 'memory' ? (
        /* Flash Memory Challenge Mode */
        <MemoryChallenge
          language={language}
          soundEnabled={soundEnabled}
          onAddXp={onAddXp}
          onClose={() => setIsPlaying(false)}
        />
      ) : !isFinished && currentQ ? (
        /* Active MCQ / Exam Screen */
        <div className="bg-slate-950/90 p-6 rounded-3xl border border-purple-500/40 shadow-neon-purple text-right max-w-2xl mx-auto w-full">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-purple-900/40 pb-3 mb-4">
            <span className="text-xs font-black text-purple-300 font-tech">
              سؤال {currentIndex + 1} من {questions.length}
            </span>
            <span className="text-xs bg-purple-950 text-purple-200 px-3 py-1 rounded-lg border border-purple-800 font-mono">
              النتيجة الحالية: {score}
            </span>
          </div>

          {/* Question Text */}
          <h3 className="text-base md:text-lg font-black text-slate-100 leading-relaxed mb-5">
            {language === 'ar' ? currentQ.questionAr : currentQ.questionFr}
          </h3>

          {/* Options */}
          <div className="space-y-3 mb-6">
            {currentQ.optionsAr.map((opt, idx) => {
              const isSelected = selectedAnswer === idx;
              return (
                <button
                  key={idx}
                  onClick={() => {
                    if (!isAnswerChecked) {
                      setSelectedAnswer(idx);
                      soundManager.playTick(soundEnabled);
                    }
                  }}
                  disabled={isAnswerChecked}
                  className={`w-full text-right p-4 rounded-2xl border text-xs md:text-sm font-semibold transition-all ${
                    isSelected
                      ? 'bg-purple-600/40 border-purple-400 text-white shadow-neon-purple'
                      : 'bg-black/50 border-purple-900/40 text-slate-300 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-full border border-purple-400/50 flex items-center justify-center text-xs font-mono">
                      {idx + 1}
                    </span>
                    <span>{language === 'ar' ? opt : currentQ.optionsFr[idx]}</span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Feedback Explanation */}
          {isAnswerChecked && (
            <div
              className={`p-4 rounded-2xl border text-xs leading-relaxed mb-4 ${
                selectedAnswer === currentQ.correctIndex
                  ? 'bg-emerald-950/70 border-emerald-500 text-emerald-200'
                  : 'bg-rose-950/70 border-rose-500 text-rose-200'
              }`}
            >
              <div className="font-bold mb-1 flex items-center gap-1.5">
                {selectedAnswer === currentQ.correctIndex ? (
                  <>
                    <CheckCircle className="w-4 h-4 text-emerald-400" />
                    <span>إجابة صحيحة خارقة!</span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-4 h-4 text-rose-400" />
                    <span>إجابة خاطئة! التفسير العلمي:</span>
                  </>
                )}
              </div>
              <p>{language === 'ar' ? currentQ.explanationAr : currentQ.explanationFr}</p>
            </div>
          )}

          {/* Action Button */}
          {!isAnswerChecked ? (
            <button
              onClick={handleCheckAnswer}
              disabled={selectedAnswer === null}
              className="w-full py-3.5 bg-gradient-to-r from-purple-600 to-rose-600 hover:from-purple-500 text-white font-extrabold text-xs md:text-sm rounded-xl shadow-lg transition-all active:scale-95 disabled:opacity-50"
            >
              تأكيد الإجابة
            </button>
          ) : (
            <button
              onClick={handleNext}
              className="w-full py-3.5 bg-purple-600 hover:bg-purple-500 text-white font-extrabold text-xs md:text-sm rounded-xl shadow-lg transition-all active:scale-95"
            >
              {currentIndex + 1 < questions.length ? 'السؤال التالي' : 'إنهاء الاختبار'}
            </button>
          )}
        </div>
      ) : (
        /* Results Report */
        <div className="bg-slate-950/90 p-8 rounded-3xl border border-purple-500/50 shadow-neon-purple text-center max-w-md mx-auto w-full">
          <Trophy className="w-16 h-16 text-yellow-400 mx-auto mb-3" />
          <h3 className="text-xl font-black text-slate-100 mb-1">
            اكتمل الاختبار بنجاح!
          </h3>
          <p className="text-xs text-purple-300 mb-4">
            نتيجتك: <span className="font-mono text-base font-bold text-yellow-400">{score}</span> من أصل{' '}
            <span className="font-mono text-base font-bold text-slate-200">{questions.length}</span>
          </p>

          <div className="bg-black/60 p-4 rounded-2xl border border-purple-900/40 mb-6 text-right text-xs space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">نسبة النجاح:</span>
              <span className="font-bold text-purple-300">
                {Math.round((score / questions.length) * 100)}%
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">نقاط الخبرة المكتسبة:</span>
              <span className="font-bold text-yellow-400">
                +{score * 30 + (score === questions.length ? 100 : 0)} XP
              </span>
            </div>
          </div>

          <button
            onClick={() => setIsPlaying(false)}
            className="w-full py-3 bg-gradient-to-r from-purple-600 to-rose-600 text-white font-bold text-xs rounded-xl shadow-neon-purple transition-all active:scale-95"
          >
            العودة إلى قائمة الساحة
          </button>
        </div>
      )}
    </div>
  );
};
