import React from 'react';
import { MemoryRadiographCard } from '../../data/memoryChallengeData';

interface Props {
  card: MemoryRadiographCard;
  showOverlayAnnotations?: boolean;
}

export const RadiographCanvas: React.FC<Props> = ({ card, showOverlayAnnotations = false }) => {
  return (
    <div className="relative w-full h-64 md:h-80 bg-[#040208] rounded-2xl overflow-hidden border-2 border-purple-900/60 shadow-2xl flex items-center justify-center select-none">
      {/* Radiograph Film Header Markers (R / L, Patient orientation markers like in hospital viewing boxes) */}
      <div className="absolute top-3 left-4 text-xs font-mono font-bold text-slate-400 bg-black/60 px-2 py-0.5 rounded border border-slate-800 pointer-events-none z-10">
        R (DROIT)
      </div>
      <div className="absolute top-3 right-4 text-xs font-mono font-bold text-purple-400 bg-black/60 px-2 py-0.5 rounded border border-purple-900/50 pointer-events-none z-10">
        {card.category.toUpperCase()} • 120 kV
      </div>

      {/* Grid overlay for medical monitor effect */}
      <div className="absolute inset-0 bg-[radial-gradient(#1e1035_1px,transparent_1px)] [background-size:16px_16px] opacity-30 pointer-events-none" />

      {/* Procedural High-Fidelity SVG Radiographs */}
      <svg
        viewBox="0 0 400 320"
        className="w-full h-full object-contain filter contrast-125 brightness-95"
      >
        <defs>
          {/* Bone gradient */}
          <linearGradient id="boneGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#cbd5e1" />
            <stop offset="50%" stopColor="#f8fafc" />
            <stop offset="100%" stopColor="#94a3b8" />
          </linearGradient>

          {/* Soft tissue opacity */}
          <radialGradient id="lungField" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#080511" />
            <stop offset="90%" stopColor="#1e1b2e" />
            <stop offset="100%" stopColor="#334155" />
          </radialGradient>

          {/* Hematoma lens gradient */}
          <radialGradient id="hyperdenseHematoma" cx="30%" cy="50%" r="70%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="70%" stopColor="#e2e8f0" />
            <stop offset="100%" stopColor="#64748b" />
          </radialGradient>
        </defs>

        {/* 1. PNEUMOTHORAX */}
        {card.radiographType === 'pneumothorax' && (
          <g>
            {/* Ribcage and mediastinum background */}
            <path d="M 60,60 C 70,180 80,260 140,290" stroke="#cbd5e1" strokeWidth="6" fill="none" opacity="0.6" />
            <path d="M 340,60 C 330,180 320,260 260,290" stroke="#cbd5e1" strokeWidth="6" fill="none" opacity="0.6" />
            {/* Left normal lung with vascular markings */}
            <path d="M 220,70 Q 320,110 320,240 Q 250,270 210,240 Z" fill="#0b0816" stroke="#94a3b8" strokeWidth="2" />
            {/* Pulmonary vascular arborization on left side */}
            <path d="M 230,140 Q 270,130 290,110 M 230,160 Q 280,180 300,210 M 240,180 Q 260,230 270,250" stroke="#64748b" strokeWidth="2" strokeDasharray="2,3" />

            {/* Right lung: hyperlucent avascular space + collapsed lung edge */}
            <path d="M 80,70 Q 180,110 180,240 Q 120,270 80,240 Z" fill="#030106" stroke="#475569" strokeWidth="1" />
            {/* Collapsed visceral pleura line */}
            <path d="M 145,95 Q 160,160 150,235" stroke="#f8fafc" strokeWidth="2.5" fill="none" />
            {/* Retracted lung parenchyma */}
            <path d="M 145,95 Q 160,160 150,235 L 180,240 L 180,110 Z" fill="#1e293b" opacity="0.75" />

            {/* Clavicles */}
            <path d="M 100,55 Q 150,50 190,65" stroke="#f1f5f9" strokeWidth="7" fill="none" strokeLinecap="round" />
            <path d="M 300,55 Q 250,50 210,65" stroke="#f1f5f9" strokeWidth="7" fill="none" strokeLinecap="round" />

            {/* Silhouette of heart slightly shifted */}
            <path d="M 185,150 Q 180,240 230,260 Q 240,240 205,150 Z" fill="#e2e8f0" opacity="0.85" />

            {/* Optional pathological highlight */}
            {showOverlayAnnotations && (
              <g>
                <circle cx="115" cy="110" r="30" stroke="#f43f5e" strokeWidth="2.5" strokeDasharray="4,4" fill="rgba(244,63,94,0.15)" />
                <text x="115" y="80" fill="#f43f5e" fontSize="12" fontWeight="bold" textAnchor="middle">استرواح هوائي نقي</text>
              </g>
            )}
          </g>
        )}

        {/* 2. EPIDURAL HEMATOMA (CT) */}
        {card.radiographType === 'epidural' && (
          <g>
            {/* Skull oval outline */}
            <ellipse cx="200" cy="160" rx="140" ry="120" fill="#0f0c1d" stroke="#f8fafc" strokeWidth="14" />
            {/* Brain parenchyma background */}
            <ellipse cx="200" cy="160" rx="130" ry="110" fill="#1e1e2f" />
            {/* Lateral ventricles compressed */}
            <path d="M 195,130 Q 185,160 195,190" stroke="#06030c" strokeWidth="10" strokeLinecap="round" fill="none" />
            <path d="M 215,120 Q 225,160 215,200" stroke="#06030c" strokeWidth="14" strokeLinecap="round" fill="none" />

            {/* Biconvex Hyperdense Hematoma (White Lens attached to skull) */}
            <path d="M 85,115 Q 135,160 85,205 Q 65,160 85,115 Z" fill="url(#hyperdenseHematoma)" stroke="#f8fafc" strokeWidth="1" />

            {/* Midline shift line */}
            <line x1="200" y1="50" x2="208" y2="270" stroke="#64748b" strokeWidth="2" strokeDasharray="4,4" />

            {showOverlayAnnotations && (
              <g>
                <path d="M 85,115 Q 135,160 85,205" stroke="#f43f5e" strokeWidth="3" fill="none" />
                <text x="150" y="145" fill="#f43f5e" fontSize="11" fontWeight="bold">عدسة محدبة +68 UH</text>
              </g>
            )}
          </g>
        )}

        {/* 3. SHOULDER DISLOCATION */}
        {card.radiographType === 'shoulder_luxation' && (
          <g>
            {/* Clavicle & Acromion */}
            <path d="M 60,60 Q 140,55 190,70" stroke="#f1f5f9" strokeWidth="9" fill="none" strokeLinecap="round" />
            <path d="M 190,70 L 220,80 L 210,110" stroke="#f1f5f9" strokeWidth="8" fill="none" />
            {/* Glenoid fossa (empty!) */}
            <path d="M 195,115 C 200,140 200,165 190,185" stroke="#cbd5e1" strokeWidth="7" fill="none" />
            {/* Coracoid process */}
            <path d="M 175,95 Q 155,105 145,115" stroke="#f1f5f9" strokeWidth="6" fill="none" strokeLinecap="round" />
            {/* Dislocated Humeral Head (down and medial under coracoid) */}
            <circle cx="140" cy="165" r="38" fill="url(#boneGrad)" stroke="#94a3b8" strokeWidth="2" />
            {/* Humeral shaft */}
            <path d="M 125,195 Q 110,250 100,300" stroke="#f1f5f9" strokeWidth="16" fill="none" strokeLinecap="round" />

            {showOverlayAnnotations && (
              <g>
                <circle cx="140" cy="165" r="44" stroke="#f43f5e" strokeWidth="2.5" strokeDasharray="4,4" fill="none" />
                <line x1="195" y1="145" x2="140" y2="165" stroke="#f43f5e" strokeWidth="2" markerEnd="url(#arrow)" />
                <text x="210" y="210" fill="#f43f5e" fontSize="11" fontWeight="bold">خلع تحت الغرابي</text>
              </g>
            )}
          </g>
        )}

        {/* 4. COLLES FRACTURE (WRIST) */}
        {card.radiographType === 'colles_fracture' && (
          <g>
            {/* Ulna */}
            <path d="M 130,290 L 130,120 L 140,90" stroke="#cbd5e1" strokeWidth="14" fill="none" strokeLinecap="round" />
            {/* Radius proximal shaft */}
            <path d="M 230,290 L 230,150" stroke="#f1f5f9" strokeWidth="18" fill="none" strokeLinecap="round" />
            {/* Fractured distal radius with dorsal displacement */}
            <path d="M 245,145 L 260,95 L 210,90 L 215,145 Z" fill="url(#boneGrad)" stroke="#f8fafc" strokeWidth="2" />
            {/* Jagged fracture line */}
            <path d="M 215,145 L 225,150 L 235,142 L 245,148 L 255,143" stroke="#f43f5e" strokeWidth="3" fill="none" />
            {/* Carpal bones */}
            <circle cx="190" cy="70" r="10" fill="#94a3b8" />
            <circle cx="215" cy="65" r="11" fill="#cbd5e1" />
            <circle cx="240" cy="65" r="10" fill="#94a3b8" />

            {showOverlayAnnotations && (
              <g>
                <line x1="265" y1="120" x2="295" y2="105" stroke="#f43f5e" strokeWidth="2.5" />
                <text x="290" y="90" fill="#f43f5e" fontSize="11" fontWeight="bold">انزياح ظهري (شوكة الطعام)</text>
              </g>
            )}
          </g>
        )}

        {/* 5. FEMORAL NECK FRACTURE */}
        {card.radiographType === 'femur_neck' && (
          <g>
            {/* Acetabulum of pelvis */}
            <path d="M 120,70 Q 200,60 220,130 Q 200,190 140,180" stroke="#cbd5e1" strokeWidth="12" fill="none" />
            {/* Obturator foramen */}
            <ellipse cx="140" cy="205" rx="25" ry="30" stroke="#94a3b8" strokeWidth="6" fill="#07040f" />
            {/* Disrupted Shenton line */}
            <path d="M 125,230 Q 155,200 180,185" stroke="#38bdf8" strokeWidth="3" strokeDasharray="3,3" fill="none" />
            {/* Femoral Head in socket */}
            <circle cx="190" cy="130" r="32" fill="url(#boneGrad)" stroke="#cbd5e1" strokeWidth="2" />
            {/* Fracture line through neck */}
            <line x1="205" y1="155" x2="235" y2="190" stroke="#f43f5e" strokeWidth="3.5" />
            {/* Femoral shaft & Greater trochanter shifted upwards */}
            <path d="M 235,175 Q 260,190 250,220 L 235,300" stroke="#f1f5f9" strokeWidth="20" fill="none" strokeLinecap="round" />

            {showOverlayAnnotations && (
              <g>
                <circle cx="220" cy="175" r="28" stroke="#f43f5e" strokeWidth="2" strokeDasharray="4,4" fill="none" />
                <text x="250" y="145" fill="#f43f5e" fontSize="11" fontWeight="bold">كسر عنق الفخذ وانقطاع شنتون</text>
              </g>
            )}
          </g>
        )}

        {/* 6. WATERS VIEW (MAXILLARY SINUSITIS) */}
        {card.radiographType === 'waters_sinus' && (
          <g>
            {/* Skull & Facial outline */}
            <ellipse cx="200" cy="160" rx="125" ry="135" fill="#0a0614" stroke="#94a3b8" strokeWidth="5" />
            {/* Orbits */}
            <circle cx="150" cy="115" r="28" stroke="#cbd5e1" strokeWidth="4" fill="#07040f" />
            <circle cx="250" cy="115" r="28" stroke="#cbd5e1" strokeWidth="4" fill="#07040f" />
            {/* Left clear sinus (Air = Black) */}
            <polygon points="230,160 275,170 250,225" stroke="#f1f5f9" strokeWidth="3" fill="#05020a" />
            {/* Right diseased sinus with Air-Fluid Level */}
            <polygon points="170,160 125,170 150,225" stroke="#f1f5f9" strokeWidth="3" fill="#05020a" />
            {/* Fluid level opacity in lower half */}
            <path d="M 132,185 L 165,185 L 150,225 Z" fill="#e2e8f0" opacity="0.8" />
            {/* Sharp horizontal air-fluid line */}
            <line x1="128" y1="185" x2="168" y2="185" stroke="#f43f5e" strokeWidth="3" />

            {showOverlayAnnotations && (
              <g>
                <line x1="110" y1="185" x2="80" y2="175" stroke="#f43f5e" strokeWidth="2" />
                <text x="90" y="160" fill="#f43f5e" fontSize="11" fontWeight="bold">مستوى سائلي هوائي أفقي</text>
              </g>
            )}
          </g>
        )}

        {/* 7. CARDIOMEGALY */}
        {card.radiographType === 'cardiomegaly' && (
          <g>
            {/* Thorax perimeter */}
            <path d="M 60,60 Q 60,280 130,290" stroke="#94a3b8" strokeWidth="5" fill="none" />
            <path d="M 340,60 Q 340,280 270,290" stroke="#94a3b8" strokeWidth="5" fill="none" />
            {/* Diaphragms */}
            <path d="M 60,280 Q 140,260 200,280 Q 280,260 340,280" stroke="#cbd5e1" strokeWidth="6" fill="none" />

            {/* Normal Heart vs Huge Cardiomegaly Silhouette */}
            <path d="M 160,130 C 140,220 110,250 160,275 C 240,285 300,265 220,130 Z" fill="#e2e8f0" stroke="#f8fafc" strokeWidth="3" opacity="0.9" />

            {/* Thoracic diameter measurement indicator */}
            <line x1="65" y1="270" x2="335" y2="270" stroke="#38bdf8" strokeWidth="2" strokeDasharray="3,3" />
            {/* Cardiac diameter measurement indicator */}
            <line x1="120" y1="250" x2="280" y2="250" stroke="#f43f5e" strokeWidth="2.5" />

            {showOverlayAnnotations && (
              <g>
                <text x="200" y="240" fill="#f43f5e" fontSize="11" fontWeight="bold" textAnchor="middle">عرض القلب &gt; 65% من الصدر</text>
              </g>
            )}
          </g>
        )}

        {/* 8. GALLSTONE ECHO */}
        {card.radiographType === 'gallstone_echo' && (
          <g>
            {/* Sector ultrasound wedge */}
            <path d="M 200,40 L 90,290 A 180,180 0 0,0 310,290 Z" fill="#080413" stroke="#475569" strokeWidth="2" />
            {/* Anechoic Gallbladder lumen (Black fluid) */}
            <ellipse cx="200" cy="180" rx="65" ry="40" fill="#020105" stroke="#94a3b8" strokeWidth="2" />
            {/* Hyperechoic Gallstone (Intense white curved arc) */}
            <path d="M 180,195 Q 200,185 215,195" stroke="#ffffff" strokeWidth="5" fill="none" strokeLinecap="round" />
            {/* Pure black posterior acoustic shadow cone */}
            <polygon points="175,198 220,198 235,285 160,285" fill="#000000" stroke="#1e1035" strokeWidth="1" />

            {showOverlayAnnotations && (
              <g>
                <text x="200" y="245" fill="#f43f5e" fontSize="11" fontWeight="bold" textAnchor="middle">ظل صوتي خلفي نقي</text>
              </g>
            )}
          </g>
        )}

        {/* 9. PNEUMOPERITONEUM */}
        {card.radiographType === 'pneumoperitoneum' && (
          <g>
            {/* Lower chest & Abdomen */}
            {/* Left and right diaphragmatic domes */}
            <path d="M 70,160 Q 140,110 200,150" stroke="#f8fafc" strokeWidth="4" fill="none" />
            <path d="M 200,150 Q 260,110 330,160" stroke="#f8fafc" strokeWidth="4" fill="none" />
            {/* Liver dense opacity under right dome */}
            <path d="M 70,165 Q 140,135 190,165 L 190,290 L 70,290 Z" fill="#475569" opacity="0.8" />
            {/* Subdiaphragmatic sickle crescent of free air (black gap under white dome) */}
            <path d="M 85,160 Q 140,115 185,155 Q 140,135 85,160 Z" fill="#020006" stroke="#f43f5e" strokeWidth="1.5" />

            {showOverlayAnnotations && (
              <g>
                <line x1="140" y1="125" x2="140" y2="90" stroke="#f43f5e" strokeWidth="2" />
                <text x="140" y="80" fill="#f43f5e" fontSize="11" fontWeight="bold" textAnchor="middle">هلال غازي حر (انثقاب)</text>
              </g>
            )}
          </g>
        )}
      </svg>
    </div>
  );
};
