import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2, RotateCcw, Trophy, XCircle } from 'lucide-react';
import type { Lesson, Quiz } from '../../types';
import { saveAttempt } from '../../services/quiz';
import { Button } from '../ui/Button';
import { ProgressBar } from '../ui/Card';
import { cn } from '../../utils/format';
import { useActiveStudy } from '../../hooks/useActiveStudy';

interface AnswerRecord {
  questionId: string;
  correct: boolean;
  chosen: string;
}

export function QuizRunner({
  quiz,
  lesson,
  subjectId,
  onFinish,
}: {
  quiz: Quiz;
  lesson?: Lesson;
  subjectId: string;
  onFinish?: (score: number, total: number) => void;
}) {
  const [index, setIndex] = useState(0);
  const [chosen, setChosen] = useState<string | null>(null);
  const [answers, setAnswers] = useState<AnswerRecord[]>([]);
  const [finished, setFinished] = useState(false);

  const question = quiz.questions[index];
  const total = quiz.questions.length;
  const score = answers.filter((a) => a.correct).length;
  const progress = useMemo(() => Math.round((answers.length / total) * 100), [answers.length, total]);
  useActiveStudy(!finished && Boolean(question), subjectId, 'interactive');

  const check = (value: string, isCorrect: boolean) => {
    if (chosen !== null) return;
    setChosen(value);
    setAnswers((prev) => [...prev, { questionId: question?.id ?? '', correct: isCorrect, chosen: value }]);
  };

  const next = () => {
    if (index + 1 >= total) {
      const finalScore = answers.filter((a) => a.correct).length;
      const wrongQuestionIds = new Set(answers.filter((answer) => !answer.correct).map((answer) => answer.questionId));
      saveAttempt({
        quizId: quiz.id,
        lessonId: lesson?.id,
        subjectId,
        unitId: lesson?.unitId,
        score: finalScore,
        total,
        weakTags: quiz.questions
          .filter((item) => wrongQuestionIds.has(item.id))
          .map((item) => item.topic?.trim() || lesson?.title || item.text.trim().slice(0, 64)),
      });
      setFinished(true);
      onFinish?.(finalScore, total);
      return;
    }
    setIndex((i) => i + 1);
    setChosen(null);
  };

  const restart = () => {
    setIndex(0);
    setChosen(null);
    setAnswers([]);
    setFinished(false);
  };

  if (finished) {
    const percent = Math.round((score / total) * 100);
    const tone = percent >= 80 ? 'ممتاز' : percent >= 50 ? 'جيد — تحتاج مراجعة' : 'يحتاج إعادة';
    return (
      <div className="card p-5 text-center">
        <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-[var(--gold-soft)] text-[#8a5b06] dark:text-[var(--gold)]">
          <Trophy size={26} />
        </div>
        <p className="font-display text-lg text-[var(--ink)]">
          نتيجتك {score} من {total}
        </p>
        <p className="mt-1 text-sm text-[var(--ink-soft)]">
          {percent}% — {tone}
        </p>
        <div className="mx-auto mt-4 max-w-xs">
          <ProgressBar value={percent} color={percent >= 80 ? 'var(--success)' : 'var(--gold)'} />
        </div>

        <div className="mt-5 space-y-2 text-start">
          {quiz.questions.map((q, i) => {
            const record = answers[i];
            return (
              <div
                key={q.id}
                className={cn(
                  'rounded-2xl border p-3 text-[0.8rem]',
                  record?.correct ? 'border-[var(--line)] bg-[var(--surface)]' : 'border-[var(--danger)]/30 bg-[var(--surface-2)]',
                )}
              >
                <div className="flex items-start gap-2">
                  {record?.correct ? (
                    <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-[var(--success)]" />
                  ) : (
                    <XCircle size={16} className="mt-0.5 shrink-0 text-[var(--danger)]" />
                  )}
                  <div>
                    <p className="font-medium text-[var(--ink)]">{q.text}</p>
                    <p className="mt-1 text-[0.75rem] leading-relaxed text-[var(--ink-soft)]">{q.explanation}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <Button variant="outline" icon={<RotateCcw size={16} />} onClick={restart} className="mt-4">
          أعد الاختبار
        </Button>
      </div>
    );
  }

  if (!question) return null;

  const isMcq = question.type === 'mcq';

  return (
    <div className="card p-4">
      <div className="mb-3 flex items-center justify-between gap-2">
        <span className="text-[0.7rem] text-[var(--ink-soft)]">
          سؤال {index + 1} من {total}
        </span>
        <span className="rounded-full bg-[var(--surface-2)] px-2 py-0.5 text-[0.65rem] text-[var(--ink-soft)]">
          {isMcq ? 'اختيار من متعدد' : 'صح / خطأ'}
        </span>
      </div>
      <ProgressBar value={progress} height={4} />

      <motion.p
        key={question.id}
        initial={{ opacity: 0, x: 8 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.2 }}
        className="mb-4 mt-4 font-display text-[1rem] leading-relaxed text-[var(--ink)]"
      >
        {question.text}
      </motion.p>

      <div className="space-y-2">
        {isMcq
          ? (question.options ?? []).map((option, i) => {
              const isAnswer = question.answerIndex === i;
              const selected = chosen === String(i);
              const revealed = chosen !== null;
              return (
                <button
                  key={option}
                  type="button"
                  disabled={revealed}
                  onClick={() => check(String(i), isAnswer)}
                  className={cn(
                    'focus-ring flex w-full items-center gap-2.5 rounded-2xl border px-3 py-2.5 text-start text-[0.85rem] transition-colors',
                    !revealed && 'border-[var(--line)] bg-[var(--surface)] hover:border-[var(--brand)]',
                    revealed && isAnswer && 'border-[var(--success)] bg-[#e6f7ef] text-[#0b6b4f] dark:bg-[#0e3a2f] dark:text-[#6fe3bd]',
                    revealed && selected && !isAnswer && 'border-[var(--danger)] bg-[#fdece2] text-[#a63a12] dark:bg-[#3a1c12] dark:text-[#f5a67f]',
                    revealed && !selected && !isAnswer && 'border-[var(--line)] opacity-65',
                  )}
                >
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-black/5 text-[0.7rem] dark:bg-white/10">
                    {['أ', 'ب', 'ج', 'د'][i] ?? i + 1}
                  </span>
                  {option}
                </button>
              );
            })
          : [
              { label: 'صح', value: true },
              { label: 'خطأ', value: false },
            ].map((option) => {
              const isAnswer = question.answerBool === option.value;
              const selected = chosen === String(option.value);
              const revealed = chosen !== null;
              return (
                <button
                  key={option.label}
                  type="button"
                  disabled={revealed}
                  onClick={() => check(String(option.value), isAnswer)}
                  className={cn(
                    'focus-ring flex w-full items-center justify-between rounded-2xl border px-3 py-3 text-[0.9rem] transition-colors',
                    !revealed && 'border-[var(--line)] hover:border-[var(--brand)]',
                    revealed && isAnswer && 'border-[var(--success)] bg-[#e6f7ef] text-[#0b6b4f] dark:bg-[#0e3a2f] dark:text-[#6fe3bd]',
                    revealed && selected && !isAnswer && 'border-[var(--danger)] bg-[#fdece2] text-[#a63a12]',
                  )}
                >
                  {option.label}
                  {revealed && isAnswer ? <CheckCircle2 size={16} /> : null}
                  {revealed && selected && !isAnswer ? <XCircle size={16} /> : null}
                </button>
              );
            })}
      </div>

      {chosen !== null ? (
        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-3 rounded-2xl bg-[var(--surface-2)] p-3 text-[0.8rem] leading-relaxed text-[var(--ink-soft)]"
        >
          <span className="me-1 font-semibold text-[var(--ink)]">التفسير:</span>
          {question.explanation}
        </motion.div>
      ) : null}

      <div className="mt-4 flex items-center justify-between gap-2">
        <span className="text-[0.7rem] text-[var(--ink-soft)]">
          {answers.length > 0 ? `صحيحة: ${score} من ${answers.length}` : 'اختر إجابة للمتابعة'}
        </span>
        <Button size="sm" onClick={next} disabled={chosen === null}>
          {index + 1 >= total ? 'إظهار النتيجة' : 'السؤال التالي'}
        </Button>
      </div>
    </div>
  );
}
