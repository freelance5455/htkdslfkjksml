import React from 'react';
import { Check, Globe, Music, Volume2, VolumeX, X } from 'lucide-react';
import { sound } from '../utils/sound';
export const SettingsModal = ({ open, settings, onUpdate, onClose, }) => {
    if (!open)
        return null;
    const isAr = settings.language === 'ar';
    return (<div className="absolute inset-0 z-30 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-5" onClick={(e) => {
            if (e.target === e.currentTarget) {
                sound.playClick();
                onClose();
            }
        }}>
      <div dir={isAr ? 'rtl' : 'ltr'} role="dialog" aria-modal="true" aria-label={isAr ? 'الإعدادات' : 'Settings'} className={`relative w-full max-w-[325px] pt-5 ${isAr ? 'font-arabic' : ''}`}>
        {/* Overlapping Top Ribbon Banner */}
        <div className="absolute top-0 inset-x-0 flex justify-center z-10 pointer-events-none">
          <div className="px-8 py-2 rounded-2xl bg-gradient-to-b from-emerald-400 via-emerald-500 to-emerald-700 border-[3px] border-amber-950 shadow-[0_4px_0_#451A03] text-white font-display font-bold text-xl tracking-wide drop-shadow-[0_2px_0_rgba(6,78,59,0.9)]">
            {isAr ? 'الإعدادات' : 'Settings'}
          </div>
        </div>

        {/* Close Button */}
        <button type="button" onClick={() => {
            sound.playClick();
            onClose();
        }} aria-label={isAr ? 'إغلاق' : 'Close'} className={`absolute top-2 ${isAr ? 'left-1' : 'right-1'} z-20 w-11 h-11 rounded-full bg-gradient-to-b from-rose-400 to-rose-600 hover:brightness-105 border-[3px] border-amber-950 shadow-[0_3px_0_#451A03] text-white flex items-center justify-center cursor-pointer transition-transform duration-150 hover:scale-105 active:scale-95 focus-visible:outline-2 focus-visible:outline-yellow-300`}>
          <X className="w-5 h-5 stroke-[3]"/>
        </button>

        {/* Cartoon Wood & Cream Parchment Frame */}
        <div className="rounded-[28px] bg-gradient-to-b from-amber-500 via-amber-600 to-amber-800 border-[3px] border-amber-950 p-2 shadow-[0_10px_0_#451A03,0_24px_50px_rgba(0,0,0,0.55)]">
          <div className="rounded-[20px] bg-gradient-to-b from-amber-50 to-amber-100 border-2 border-amber-800/30 px-4 pt-8 pb-5 text-amber-950 space-y-3.5">
            {/* 1. Background Music Toggle */}
            <div className="flex items-center justify-between gap-3 rounded-2xl bg-white/85 border-2 border-amber-900/15 p-3 shadow-xs">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-b from-fuchsia-400 to-purple-600 border-2 border-purple-950 shadow-[0_2px_0_#3B0764] flex items-center justify-center text-white shrink-0">
                  <Music className="w-5 h-5"/>
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-extrabold text-amber-950 truncate">
                    {isAr ? 'الموسيقى' : 'Music'}
                  </div>
                  <div className="text-[11px] font-semibold text-amber-800/80 truncate">
                    {settings.musicEnabled
            ? isAr
                ? 'مفعّلة'
                : 'Enabled'
            : isAr
                ? 'متوقفة'
                : 'Muted'}
                  </div>
                </div>
              </div>

              <button type="button" role="switch" aria-checked={settings.musicEnabled} onClick={() => {
            const next = !settings.musicEnabled;
            sound.playClick();
            onUpdate({ musicEnabled: next });
        }} className={`relative w-[64px] h-[34px] rounded-full border-2 border-amber-950 transition-colors duration-150 cursor-pointer shrink-0 shadow-[inset_0_2px_4px_rgba(0,0,0,0.25)] focus-visible:outline-2 focus-visible:outline-amber-500 ${settings.musicEnabled
            ? 'bg-gradient-to-b from-emerald-400 to-emerald-600'
            : 'bg-slate-400'}`}>
                <span aria-hidden="true" className={`absolute top-0.5 w-[26px] h-[26px] rounded-full bg-white border-2 border-amber-950 shadow-sm transition-transform duration-150 ${settings.musicEnabled
            ? isAr
                ? 'left-0.5'
                : 'right-0.5'
            : isAr
                ? 'right-0.5'
                : 'left-0.5'}`}/>
              </button>
            </div>

            {/* 2. Sound Effects Toggle */}
            <div className="flex items-center justify-between gap-3 rounded-2xl bg-white/85 border-2 border-amber-900/15 p-3 shadow-xs">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-b from-sky-400 to-blue-600 border-2 border-blue-950 shadow-[0_2px_0_#172554] flex items-center justify-center text-white shrink-0">
                  {settings.sfxEnabled ? (<Volume2 className="w-5 h-5"/>) : (<VolumeX className="w-5 h-5"/>)}
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-extrabold text-amber-950 truncate">
                    {isAr ? 'المؤثرات الصوتية' : 'Sound Effects'}
                  </div>
                  <div className="text-[11px] font-semibold text-amber-800/80 truncate">
                    {settings.sfxEnabled
            ? isAr
                ? 'مفعّلة'
                : 'Enabled'
            : isAr
                ? 'متوقفة'
                : 'Muted'}
                  </div>
                </div>
              </div>

              <button type="button" role="switch" aria-checked={settings.sfxEnabled} onClick={() => {
            const next = !settings.sfxEnabled;
            onUpdate({ sfxEnabled: next });
            if (next) {
                sound.setSfxEnabled(true);
                sound.playClick();
            }
        }} className={`relative w-[64px] h-[34px] rounded-full border-2 border-amber-950 transition-colors duration-150 cursor-pointer shrink-0 shadow-[inset_0_2px_4px_rgba(0,0,0,0.25)] focus-visible:outline-2 focus-visible:outline-amber-500 ${settings.sfxEnabled
            ? 'bg-gradient-to-b from-emerald-400 to-emerald-600'
            : 'bg-slate-400'}`}>
                <span aria-hidden="true" className={`absolute top-0.5 w-[26px] h-[26px] rounded-full bg-white border-2 border-amber-950 shadow-sm transition-transform duration-150 ${settings.sfxEnabled
            ? isAr
                ? 'left-0.5'
                : 'right-0.5'
            : isAr
                ? 'right-0.5'
                : 'left-0.5'}`}/>
              </button>
            </div>

            {/* 3. Language Selector */}
            <div className="rounded-2xl bg-white/85 border-2 border-amber-900/15 p-3 shadow-xs space-y-2.5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-b from-amber-300 to-orange-500 border-2 border-amber-950 shadow-[0_2px_0_#451A03] flex items-center justify-center text-white shrink-0">
                  <Globe className="w-5 h-5"/>
                </div>
                <div className="text-sm font-extrabold text-amber-950">
                  {isAr ? 'لغة اللعبة' : 'Language'}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-amber-900/10 border border-amber-900/15">
                <button type="button" onClick={() => {
            sound.playClick();
            onUpdate({ language: 'ar' });
        }} className={`min-h-[40px] rounded-lg text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${settings.language === 'ar'
            ? 'bg-gradient-to-b from-amber-300 to-orange-500 text-white border-2 border-amber-950 shadow-[0_2px_0_#451A03]'
            : 'text-amber-900 hover:bg-white/60'}`}>
                  {settings.language === 'ar' && <Check className="w-3.5 h-3.5 stroke-[3]"/>}
                  العربية
                </button>
                <button type="button" onClick={() => {
            sound.playClick();
            onUpdate({ language: 'en' });
        }} className={`min-h-[40px] rounded-lg text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${settings.language === 'en'
            ? 'bg-gradient-to-b from-amber-300 to-orange-500 text-white border-2 border-amber-950 shadow-[0_2px_0_#451A03]'
            : 'text-amber-900 hover:bg-white/60'}`}>
                  {settings.language === 'en' && <Check className="w-3.5 h-3.5 stroke-[3]"/>}
                  English
                </button>
              </div>
            </div>

            {/* Done Button */}
            <button type="button" onClick={() => {
            sound.playClick();
            onClose();
        }} className="w-full min-h-[46px] rounded-2xl bg-gradient-to-b from-emerald-400 via-emerald-500 to-emerald-600 hover:brightness-105 border-[3px] border-amber-950 shadow-[0_4px_0_#451A03] text-white font-extrabold text-base tracking-wide cursor-pointer transition-transform duration-150 active:translate-y-0.5 active:shadow-[0_2px_0_#451A03] focus-visible:outline-2 focus-visible:outline-yellow-300">
              {isAr ? 'تم' : 'Done'}
            </button>
          </div>
        </div>
      </div>
    </div>);
};
