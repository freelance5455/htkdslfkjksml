import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Square,
  Image as ImageIcon,
  Mic,
  MicOff,
  X,
  Sparkles,
  Wand2,
  PenTool,
} from 'lucide-react';
import { ChatSettings, MessageImage } from '../types/index.ts';
import { AIAssistModal, AIAssistTab } from './AIAssistModal.tsx';

interface ChatInputProps {
  onSendMessage: (content: string, images: MessageImage[]) => void;
  onStopStreaming: () => void;
  isStreaming: boolean;
  settings: ChatSettings;
  onOpenSettings?: () => void;
  hasMessages: boolean;
}

export const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  onStopStreaming,
  isStreaming,
  settings,
  hasMessages,
}) => {
  const [input, setInput] = useState('');
  const [images, setImages] = useState<MessageImage[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [isAIAssistOpen, setIsAIAssistOpen] = useState(false);
  const [aiAssistTab, setAIAssistTab] = useState<AIAssistTab>('enhance');
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  const handleOpenAIAssist = (tab: AIAssistTab) => {
    setAIAssistTab(tab);
    setIsAIAssistOpen(true);
  };

  const handleApplyAIText = (newText: string, andSend = false) => {
    setInput(newText);
    if (andSend) {
      onSendMessage(newText, images);
      setInput('');
      setImages([]);
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    } else {
      setTimeout(() => {
        textareaRef.current?.focus();
      }, 50);
    }
  };

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const scrollHeight = textareaRef.current.scrollHeight;
      textareaRef.current.style.height = `${Math.min(scrollHeight, 200)}px`;
    }
  }, [input]);

  // Handle image files
  const handleFiles = (files: FileList | File[]) => {
    Array.from(files).forEach((file) => {
      if (!file.type.startsWith('image/')) return;
      if (file.size > 10 * 1024 * 1024) {
        alert('Ukuran gambar maksimal adalah 10MB.');
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        if (base64) {
          setImages((prev) => [
            ...prev,
            {
              id: `img_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
              name: file.name,
              data: base64,
              mimeType: file.type,
              sizeBytes: file.size,
            },
          ]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  // Clipboard paste image support
  const handlePaste = (e: React.ClipboardEvent) => {
    const items = e.clipboardData.items;
    const pastedFiles: File[] = [];
    for (let i = 0; i < items.length; i++) {
      if (items[i].type.startsWith('image/')) {
        const file = items[i].getAsFile();
        if (file) pastedFiles.push(file);
      }
    }
    if (pastedFiles.length > 0) {
      handleFiles(pastedFiles);
    }
  };

  // Speech to text toggle
  const toggleSpeechRecognition = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('Peramban Anda tidak mendukung Speech Recognition (Gunakan Google Chrome atau Edge).');
      return;
    }

    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'id-ID';
      recognition.continuous = true;
      recognition.interimResults = true;

      recognition.onstart = () => {
        setIsRecording(true);
      };

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        setInput((prev) => (prev ? `${prev} ${transcript}` : transcript));
      };

      recognition.onerror = () => {
        setIsRecording(false);
      };

      recognition.onend = () => {
        setIsRecording(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      console.error(err);
      setIsRecording(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    const isNewlineMode = (settings.enterKeyAction || 'newline') === 'newline';
    if (isNewlineMode) {
      // Ctrl+Enter or Cmd+Enter sends the message
      if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        handleSubmit();
      }
      // Regular Enter is allowed through to start a new paragraph naturally!
    } else {
      // Send on Enter, Shift+Enter for newline
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSubmit();
      }
    }
  };

  const handleSubmit = () => {
    if ((!input.trim() && images.length === 0) || isStreaming) return;
    onSendMessage(input.trim(), images);
    setInput('');
    setImages([]);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const starterPrompts = [
    {
      title: 'Koding & Arsitektur',
      prompt: 'Bantu rancang arsitektur clean code di TypeScript dengan contoh implementasi praktis.',
    },
    {
      title: 'Penulisan Bahasa Indonesia',
      prompt: 'Bantu saya menyunting draf artikel formal ini agar selaras dengan kaidah EYD V dan KBBI.',
    },
    {
      title: 'Analisis & Pemecahan Masalah',
      prompt: 'Jelaskan konsep dasar Machine Learning dan Neural Network dengan analogi kehidupan sehari-hari.',
    },
    {
      title: 'Strategi & Ide Bisnis',
      prompt: 'Buatkan kerangka Lean Canvas dan strategi go-to-market untuk produk digital baru.',
    },
  ];

  return (
    <div
      className={`w-full ${
        settings.chatWidth === 'standard' ? 'max-w-4xl' : 'max-w-6xl xl:max-w-7xl'
      } mx-auto px-3 sm:px-4 pb-4`}
    >
      {/* Quick starter chips if chat is empty */}
      {!hasMessages && (
        <div className="mb-4">
          <p className="text-xs text-slate-400 font-medium mb-2 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>Saran Percakapan:</span>
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {starterPrompts.map((p, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setInput(p.prompt);
                  textareaRef.current?.focus();
                }}
                className="text-left p-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 hover:border-indigo-500/50 transition cursor-pointer text-xs"
              >
                <div className="font-semibold text-slate-200">{p.title}</div>
                <div className="text-slate-400 text-[11px] truncate mt-0.5">{p.prompt}</div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input Box Card */}
      <div className="relative rounded-2xl bg-slate-900 border border-slate-700/80 shadow-xl focus-within:border-indigo-500/80 focus-within:ring-2 focus-within:ring-indigo-500/20 transition duration-150">
        {/* Attached images preview bar */}
        {images.length > 0 && (
          <div className="p-2.5 flex items-center gap-2 border-b border-slate-800 overflow-x-auto">
            {images.map((img) => (
              <div
                key={img.id}
                className="relative rounded-lg overflow-hidden border border-slate-700 w-16 h-16 shrink-0 bg-slate-950 group"
              >
                <img src={img.data} alt={img.name} className="w-full h-full object-cover" />
                <button
                  onClick={() => setImages((prev) => prev.filter((i) => i.id !== img.id))}
                  className="absolute top-1 right-1 p-0.5 rounded-full bg-slate-950/80 text-white hover:bg-rose-600 transition"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Text area */}
        <textarea
          ref={textareaRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          onPaste={handlePaste}
          placeholder={
            (settings.enterKeyAction || 'newline') === 'newline'
              ? 'Tanyakan apa saja kepada AI... (Enter untuk paragraf baru, Ctrl+Enter untuk kirim)'
              : 'Tanyakan apa saja kepada AI... (Tekan Enter untuk kirim, Shift+Enter untuk baris baru)'
          }
          rows={1}
          disabled={isStreaming}
          className="w-full bg-transparent text-slate-100 placeholder-slate-400 text-sm sm:text-[15px] p-3.5 pr-12 focus:outline-none resize-none max-h-48"
        />

        {/* Bottom Actions toolbar */}
        <div className="px-3 pb-2.5 flex items-center justify-between">
          <div className="flex items-center gap-1">
            {/* File upload button */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={(e) => e.target.files && handleFiles(e.target.files)}
              accept="image/*"
              multiple
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              title="Lampirkan Gambar (Maks 10MB)"
              className="p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition cursor-pointer"
            >
              <ImageIcon className="w-4 h-4 text-sky-400" />
            </button>

            {/* Mic speech recognition */}
            <button
              type="button"
              onClick={toggleSpeechRecognition}
              title={isRecording ? 'Hentikan Mendengarkan' : 'Input Suara (Bahasa Indonesia)'}
              className={`p-2 rounded-lg transition cursor-pointer ${
                isRecording
                  ? 'bg-rose-500/20 text-rose-400 animate-pulse'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {isRecording ? <Mic className="w-4 h-4 text-rose-400" /> : <Mic className="w-4 h-4" />}
            </button>

            {/* Separator */}
            <div className="h-4 w-px bg-slate-750 mx-1 hidden sm:block" />

            {/* Enhance My Draft button */}
            <button
              type="button"
              onClick={() => handleOpenAIAssist('enhance')}
              title="Sempurnakan draf pesan Anda dengan AI (EYD, kerapian, prompt pro)"
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                input.trim()
                  ? 'bg-indigo-600/25 hover:bg-indigo-600/40 text-indigo-300 border border-indigo-500/40 shadow-xs'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Wand2 className="w-3.5 h-3.5 text-indigo-400" />
              <span className="hidden sm:inline">Sempurnakan Draf</span>
              <span className="sm:hidden">Draf</span>
            </button>

            {/* Write For Me button */}
            <button
              type="button"
              onClick={() => handleOpenAIAssist('write')}
              title="Minta AI menuliskan prompt / pesan lengkap siap kirim"
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition cursor-pointer"
            >
              <PenTool className="w-3.5 h-3.5 text-sky-400" />
              <span className="hidden sm:inline">Tuliskan Untuk Saya</span>
              <span className="sm:hidden">Tulis</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            {/* Stop Streaming Button */}
            {isStreaming ? (
              <button
                type="button"
                onClick={onStopStreaming}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-medium text-xs shadow-md shadow-rose-600/30 transition cursor-pointer"
              >
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>Berhenti</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleSubmit}
                disabled={!input.trim() && images.length === 0}
                title={
                  (settings.enterKeyAction || 'newline') === 'newline'
                    ? 'Kirim Pesan (Ctrl+Enter)'
                    : 'Kirim Pesan (Enter)'
                }
                className="flex items-center justify-center p-2 sm:px-3 sm:py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:hover:bg-indigo-600 text-white font-medium text-xs shadow-md shadow-indigo-600/30 transition cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span className="hidden sm:inline ml-1.5">Kirim</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* AI Writing Assistant Modal (Enhance My Draft & Write For Me) */}
      <AIAssistModal
        isOpen={isAIAssistOpen}
        onClose={() => setIsAIAssistOpen(false)}
        initialTab={aiAssistTab}
        currentInputText={input}
        onApplyText={handleApplyAIText}
        settings={settings}
      />
    </div>
  );
};
