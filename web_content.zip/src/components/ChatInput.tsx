import React, { useState, useRef, useEffect } from 'react';
import { ArrowUp, Square, Mic, MicOff, Sparkles } from 'lucide-react';

interface ChatInputProps {
  onSendMessage: (text: string) => void;
  onStopStreaming: () => void;
  isStreaming: boolean;
  onQuickPrompt?: (prompt: string) => void;
  placeholder?: string;
}

export const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  onStopStreaming,
  isStreaming,
  onQuickPrompt,
  placeholder = 'Ask your tutor anything...',
}) => {
  const [input, setInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [inputWarning, setInputWarning] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Check speech recognition support
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        setInput((prev) => (prev ? `${prev} ${transcript}` : transcript));
      };

      recognition.onend = () => setIsListening(false);
      recognition.onerror = () => setIsListening(false);

      recognitionRef.current = recognition;
    }
  }, []);

  const toggleSpeech = () => {
    if (!recognitionRef.current) {
      alert('Speech recognition is not supported in this browser window.');
      return;
    }
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch (err) {
        console.error('Speech error:', err);
        setIsListening(false);
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (isStreaming) {
      onStopStreaming();
      return;
    }

    const trimmed = input.trim();
    if (!trimmed) {
      // Focus textarea and show helpful visual cue instead of being a dead button
      textareaRef.current?.focus();
      setInputWarning(true);
      setTimeout(() => setInputWarning(false), 2000);
      return;
    }

    onSendMessage(trimmed);
    setInput('');

    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const autoResize = () => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(
        textareaRef.current.scrollHeight,
        180
      )}px`;
    }
  };

  return (
    <div className="p-4 border-t border-slate-200 bg-white/95 backdrop-blur-xs">
      <div className="max-w-4xl mx-auto relative">
        <form
          onSubmit={handleSubmit}
          className={`relative flex items-end border rounded-2xl shadow-xs bg-white transition ${
            inputWarning
              ? 'border-indigo-400 ring-2 ring-indigo-200'
              : 'border-slate-300 focus-within:border-slate-500 focus-within:ring-1 focus-within:ring-slate-400'
          }`}
        >
          <textarea
            ref={textareaRef}
            rows={1}
            value={input}
            onChange={(e) => {
              setInput(e.target.value);
              autoResize();
            }}
            onKeyDown={handleKeyDown}
            placeholder={inputWarning ? 'Please type a question or select a prompt...' : placeholder}
            aria-label="Ask your tutor a question"
            className="w-full py-3.5 pl-4 pr-24 text-sm text-slate-800 placeholder-slate-400 bg-transparent resize-none border-none focus:outline-none max-h-44 leading-relaxed"
          />

          <div className="absolute right-2 bottom-2 flex items-center space-x-1.5">
            <button
              type="button"
              onClick={toggleSpeech}
              aria-label={isListening ? 'Stop voice input' : 'Start voice input'}
              className={`w-8 h-8 rounded-xl flex items-center justify-center transition cursor-pointer ${
                isListening
                  ? 'bg-rose-500 text-white animate-pulse'
                  : 'text-slate-400 hover:text-slate-700 hover:bg-slate-100'
              }`}
              title="Dictate with microphone"
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            {isStreaming ? (
              <button
                type="button"
                onClick={onStopStreaming}
                aria-label="Stop tutor generation"
                className="w-8 h-8 rounded-xl bg-slate-900 text-white flex items-center justify-center hover:bg-slate-800 transition cursor-pointer"
                title="Stop generation"
              >
                <Square className="w-3.5 h-3.5 fill-current" />
              </button>
            ) : (
              <button
                type="submit"
                aria-label="Send question to tutor"
                className={`w-8 h-8 rounded-xl flex items-center justify-center transition cursor-pointer ${
                  input.trim()
                    ? 'bg-slate-900 text-white hover:bg-slate-800 shadow-2xs'
                    : 'bg-slate-200 text-slate-500 hover:bg-slate-300'
                }`}
                title={input.trim() ? 'Send' : 'Type a question'}
              >
                <ArrowUp className="w-4 h-4" />
              </button>
            )}
          </div>
        </form>

        <div className="text-center mt-2">
          <span className="text-[11px] text-slate-400 font-medium">
            MindSparq AI Tutor can make mistakes. Verify critical formulas & study materials.
          </span>
        </div>
      </div>
    </div>
  );
};
