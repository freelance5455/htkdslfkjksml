import React, { useState, useRef, useEffect } from 'react';
import {
  Plus,
  Mic,
  ArrowUp,
  X,
  FileSpreadsheet,
  StopCircle,
  Loader2,
  Square,
  AlertCircle,
  Camera,
  Image as ImageIcon,
  FileText,
  Smartphone,
  FileCode,
  Globe
} from 'lucide-react';
import { Attachment } from '../types/chat';
import { AudioRecorder, transcribeAudio } from '../lib/audioRecorder';
import { parseSpreadsheetFile, fileToBase64 } from '../lib/excelParser';
import { parseZipFileNames, extractStringsFromBinary, formatBytes } from '../lib/fileInspector';
import { detectTextDirection } from '../lib/textDirection';

interface ChatInputProps {
  onSendMessage: (content: string, attachments: Attachment[], useSearch?: boolean) => void;
  isLoading: boolean;
  isLight?: boolean;
  onOpenVoiceModal: () => void;
  onStopGeneration?: () => void;
}

// Fast client-side image compression: downsizes large camera photos to ~150KB within 40ms
async function compressImageFast(file: File, maxDim = 1200, quality = 0.82): Promise<{ base64: string; mimeType: string }> {
  return new Promise((resolve) => {
    if (file.size < 250 * 1024 && !file.type.includes('heic')) {
      fileToBase64(file).then((b64) => resolve({ base64: b64, mimeType: file.type || 'image/jpeg' }));
      return;
    }

    const img = new Image();
    const objectUrl = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(objectUrl);
      let { width, height } = img;
      if (width > maxDim || height > maxDim) {
        if (width > height) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        } else {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
      }
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve({ base64: dataUrl.split(',')[1], mimeType: 'image/jpeg' });
      } else {
        fileToBase64(file).then((b64) => resolve({ base64: b64, mimeType: file.type || 'image/jpeg' }));
      }
    };
    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      fileToBase64(file).then((b64) => resolve({ base64: b64, mimeType: file.type || 'image/jpeg' }));
    };
    img.src = objectUrl;
  });
}

export const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  isLoading,
  isLight = false,
  onOpenVoiceModal,
  onStopGeneration,
}) => {
  const [input, setInput] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [recordSeconds, setRecordSeconds] = useState(0);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [micError, setMicError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [liveWaveBars, setLiveWaveBars] = useState<number[]>([12, 18, 24, 14, 20]);
  const [isPlusMenuOpen, setIsPlusMenuOpen] = useState(false);
  const [isGoogleSearchActive, setIsGoogleSearchActive] = useState(false);

  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const filesInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const recorderRef = useRef<AudioRecorder | null>(null);
  const timerRef = useRef<any>(null);
  const waveAnimRef = useRef<any>(null);
  const plusMenuRef = useRef<HTMLDivElement>(null);

  // Close plus menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (plusMenuRef.current && !plusMenuRef.current.contains(e.target as Node)) {
        setIsPlusMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [input]);

  // Audio waveform animation when recording
  useEffect(() => {
    if (isRecording) {
      waveAnimRef.current = setInterval(() => {
        setLiveWaveBars([
          Math.floor(Math.random() * 16) + 8,
          Math.floor(Math.random() * 22) + 10,
          Math.floor(Math.random() * 26) + 12,
          Math.floor(Math.random() * 20) + 9,
          Math.floor(Math.random() * 16) + 8,
        ]);
      }, 100);
    } else {
      clearInterval(waveAnimRef.current);
      setLiveWaveBars([10, 16, 22, 14, 10]);
    }
    return () => clearInterval(waveAnimRef.current);
  }, [isRecording]);

  // Recording duration timer
  useEffect(() => {
    if (isRecording) {
      setRecordSeconds(0);
      timerRef.current = setInterval(() => {
        setRecordSeconds((s) => s + 1);
      }, 1000);
    } else {
      clearInterval(timerRef.current);
      setRecordSeconds(0);
    }
    return () => clearInterval(timerRef.current);
  }, [isRecording]);

  const handleStartRecording = async () => {
    setMicError(null);
    try {
      if (!recorderRef.current) {
        recorderRef.current = new AudioRecorder();
      }
      await recorderRef.current.start();
      setIsRecording(true);
    } catch (err: any) {
      console.error('Recording start failed:', err);
      setMicError(err.message || 'تعذر تشغيل الميكروفون. يرجى التأكد من منحه الصلاحية في المتصفح.');
      setTimeout(() => setMicError(null), 5000);
    }
  };

  const handleStopRecording = async (shouldTranscribe: boolean) => {
    if (!recorderRef.current || !isRecording) return;

    setIsRecording(false);
    if (!shouldTranscribe) {
      recorderRef.current.cancel();
      return;
    }

    setIsTranscribing(true);
    try {
      const result = await recorderRef.current.stop();
      if (result.durationMs < 400) {
        setMicError('التسجيل قصير جداً، يرجى التحدث بوضوح.');
        setIsTranscribing(false);
        return;
      }

      // Transcribe via Gemini 3.5 Transcribe
      const transcribedText = await transcribeAudio(result.base64, result.mimeType);
      if (transcribedText) {
        setInput((prev) => (prev ? `${prev} ${transcribedText}` : transcribedText));
      } else {
        setMicError('لم يتم التقاط صوت واضح.');
      }
    } catch (err: any) {
      console.error('Transcription error:', err);
      setMicError(err.message || 'فشل تحويل الصوت إلى نص.');
    } finally {
      setIsTranscribing(false);
    }
  };

  // Process uploaded files (images, camera, Excel spreadsheets, docs, PDFs)
  const processFiles = async (files: FileList | File[]) => {
    const newAttachments: Attachment[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const isSpreadsheet =
        file.name.endsWith('.xlsx') ||
        file.name.endsWith('.xls') ||
        file.name.endsWith('.csv') ||
        file.type.includes('spreadsheet') ||
        file.type.includes('csv');

      const isImage = file.type.startsWith('image/');
      const isPdf = file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf');
      const isApk = file.name.toLowerCase().endsWith('.apk') || file.type.includes('android.package-archive');

      if (isSpreadsheet) {
        try {
          const sheetData = await parseSpreadsheetFile(file);
          newAttachments.push({
            id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
            name: file.name,
            type: file.name.endsWith('.csv') ? 'csv' : 'excel',
            mimeType: file.type || 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            size: file.size,
            sheetData,
          });
        } catch (err: any) {
          console.error('Error parsing spreadsheet:', err);
          alert('تعذر قراءة ملف الإكسل: ' + err.message);
        }
      } else if (isImage) {
        try {
          // Fast compression reduces upload size by ~90% and speeds up vision analysis to <1 sec
          const { base64, mimeType } = await compressImageFast(file);
          newAttachments.push({
            id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
            name: file.name,
            type: 'image',
            mimeType,
            size: Math.round(base64.length * 0.75),
            dataUrl: `data:${mimeType};base64,${base64}`,
          });
        } catch (err) {
          console.error('Error reading/compressing image:', err);
        }
      } else if (isPdf) {
        try {
          const base64 = await fileToBase64(file);
          newAttachments.push({
            id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
            name: file.name,
            type: 'pdf',
            mimeType: 'application/pdf',
            size: file.size,
            dataUrl: `data:application/pdf;base64,${base64}`,
          });
        } catch (err) {
          console.error('Error reading PDF file:', err);
        }
      } else if (isApk) {
        try {
          const arrayBuffer = await file.arrayBuffer();
          const entries = parseZipFileNames(arrayBuffer);
          const strings = extractStringsFromBinary(arrayBuffer);
          const sizeStr = formatBytes(file.size);

          let apkReport = `حزمة تطبيق أندرويد (APK): ${file.name}\nحجم الملف: ${sizeStr}\n`;
          if (entries.length > 0) {
            apkReport += `\nملفات ومكونات الحزمة الداخلية (${entries.length} ملف تم فحصها):\n- ` + entries.slice(0, 40).join('\n- ') + '\n';
          }
          if (strings.length > 0) {
            apkReport += `\nعناصر، حزم وصلاحيات مستخرجة من التطبيق:\n` + strings.slice(0, 30).join(', ') + '\n';
          }

          newAttachments.push({
            id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
            name: file.name,
            type: 'apk',
            mimeType: 'application/vnd.android.package-archive',
            size: file.size,
            textContent: apkReport,
            dataUrl: `APK [${sizeStr}]`,
          });
        } catch (err) {
          console.error('Error inspecting APK:', err);
          newAttachments.push({
            id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
            name: file.name,
            type: 'apk',
            mimeType: 'application/vnd.android.package-archive',
            size: file.size,
            textContent: `حزمة تطبيق أندرويد: ${file.name}، الحجم: ${formatBytes(file.size)}`,
          });
        }
      } else {
        // Any other document or file (txt, json, code, markdown, doc, docx, etc.)
        try {
          const text = await file.text();
          const isReadableText = !/[\x00-\x08\x0E-\x1F]/.test(text.slice(0, 1000));
          if (isReadableText) {
            newAttachments.push({
              id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
              name: file.name,
              type: 'document',
              mimeType: file.type || 'text/plain',
              size: file.size,
              textContent: text,
              dataUrl: text.slice(0, 500),
            });
          } else {
            // Binary archive or docx: inspect entries and readable strings
            const arrayBuffer = await file.arrayBuffer();
            const entries = parseZipFileNames(arrayBuffer);
            const strings = extractStringsFromBinary(arrayBuffer);
            let summary = `ملف ثنائي/مستند: ${file.name}، الحجم: ${formatBytes(file.size)}\n`;
            if (entries.length > 0) {
              summary += `محتويات الأرشيف الداخلي: ${entries.slice(0, 25).join(', ')}\n`;
            }
            if (strings.length > 0) {
              summary += `نصوص مستخلصة: ${strings.slice(0, 20).join(' | ')}\n`;
            }

            newAttachments.push({
              id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
              name: file.name,
              type: 'document',
              mimeType: file.type || 'application/octet-stream',
              size: file.size,
              textContent: summary,
              dataUrl: summary.slice(0, 500),
            });
          }
        } catch (err) {
          console.error('Error reading file:', err);
        }
      }
    }

    setAttachments((prev) => [...prev, ...newAttachments]);
    setIsPlusMenuOpen(false);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFiles(e.target.files);
      e.target.value = '';
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files);
    }
  };

  const removeAttachment = (id: string) => {
    setAttachments((prev) => prev.filter((a) => a.id !== id));
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if ((!input.trim() && attachments.length === 0) || isLoading) return;

    onSendMessage(input.trim(), attachments, isGoogleSearchActive);
    setInput('');
    setAttachments([]);
    setIsGoogleSearchActive(false);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const formatTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Has text or attachments?
  const hasContent = input.trim().length > 0 || attachments.length > 0;

  return (
    <div
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className="relative w-full max-w-3xl mx-auto px-4 pb-4 pt-1"
      dir="rtl"
    >
      {/* Hidden File Inputs for 3 Options */}
      {/* 1. Camera Input */}
      <input
        type="file"
        ref={cameraInputRef}
        onChange={handleFileChange}
        accept="image/*"
        capture="environment"
        className="hidden"
      />
      {/* 2. Photo Gallery Input */}
      <input
        type="file"
        ref={galleryInputRef}
        onChange={handleFileChange}
        multiple
        accept="image/*"
        className="hidden"
      />
      {/* 3. Document/Files/APK Input - accept all files */}
      <input
        type="file"
        ref={filesInputRef}
        onChange={handleFileChange}
        multiple
        accept="*/*"
        className="hidden"
      />

      {/* Drag & Drop Visual Indicator */}
      {isDragging && (
        <div className="absolute inset-x-4 inset-y-2 z-30 bg-[#1e1e24]/95 border-2 border-dashed border-blue-500 rounded-full flex flex-col items-center justify-center p-6 text-center pointer-events-none animate-in fade-in">
          <FileSpreadsheet className="w-8 h-8 text-blue-400 animate-bounce mb-2" />
          <p className="text-sm font-semibold text-white">أفلت الملفات هنا للتحليل الفوري</p>
        </div>
      )}

      {/* Mic Error Banner */}
      {micError && (
        <div className="mb-2 p-2.5 bg-rose-950/70 border border-rose-800 text-rose-300 rounded-2xl text-xs flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{micError}</span>
          </div>
          <button onClick={() => setMicError(null)} className="p-1 hover:text-white">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Attachments Preview Bar */}
      {attachments.length > 0 && (
        <div className={`flex flex-wrap gap-2 mb-2 p-2.5 ${isLight ? 'bg-slate-100 border-slate-200' : 'bg-[#212126] border-[#30303a]'} border rounded-2xl`}>
          {attachments.map((att) => (
            <div
              key={att.id}
              className={`flex items-center gap-2 px-3 py-1.5 ${isLight ? 'bg-white border-slate-200 text-slate-800' : 'bg-[#2b2b35] border-[#3d3d4e] text-neutral-200'} border rounded-xl text-xs`}
            >
              {att.type === 'image' && att.dataUrl ? (
                <img src={att.dataUrl} alt="" className="w-6 h-6 rounded-md object-cover" />
              ) : att.type === 'excel' || att.type === 'csv' ? (
                <FileSpreadsheet className="w-4 h-4 text-emerald-500 shrink-0" />
              ) : att.type === 'pdf' ? (
                <span className="flex items-center gap-1">
                  <FileText className="w-4 h-4 text-rose-500 shrink-0" />
                  <span className="text-[9px] bg-rose-500/20 text-rose-500 px-1 py-0.2 rounded font-bold">PDF</span>
                </span>
              ) : att.type === 'apk' ? (
                <span className="flex items-center gap-1">
                  <Smartphone className="w-4 h-4 text-green-500 shrink-0" />
                  <span className="text-[9px] bg-green-500/20 text-green-600 px-1 py-0.2 rounded font-bold">APK</span>
                </span>
              ) : (
                <FileCode className="w-4 h-4 text-cyan-500 shrink-0" />
              )}
              <span className="truncate max-w-[140px] font-medium">{att.name}</span>
              {att.sheetData && (
                <span className="text-[10px] text-emerald-600 bg-emerald-500/15 px-1.5 py-0.5 rounded font-medium">
                  {att.sheetData.totalRows} صف
                </span>
              )}
              <button
                type="button"
                onClick={() => removeAttachment(att.id)}
                className={`${isLight ? 'text-slate-400 hover:text-rose-600' : 'text-neutral-400 hover:text-rose-400'} transition-colors`}
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* The 3-Option Popup Menu for the (+) Button */}
      {isPlusMenuOpen && (
        <div
          ref={plusMenuRef}
          className={`absolute right-6 bottom-20 z-40 ${isLight ? 'bg-white border-[#e5e5e5] shadow-lg' : 'bg-[#212121] border-[#303030] shadow-xl'} border rounded-2xl p-1.5 w-52 animate-in fade-in slide-in-from-bottom-2 duration-150`}
        >
          <div className="space-y-0.5">
            {/* 1. Camera option */}
            <button
              type="button"
              onClick={() => cameraInputRef.current?.click()}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium ${isLight ? 'text-[#202123] hover:bg-[#F7F7F8]' : 'text-[#ececec] hover:bg-[#2a2a2a]'} transition-colors text-right`}
            >
              <div className="w-7 h-7 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 flex items-center justify-center">
                <Camera className="w-4 h-4" />
              </div>
              <span>التقاط صورة بالكاميرا</span>
            </button>

            {/* 2. Photo gallery option */}
            <button
              type="button"
              onClick={() => galleryInputRef.current?.click()}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium ${isLight ? 'text-[#202123] hover:bg-[#F7F7F8]' : 'text-[#ececec] hover:bg-[#2a2a2a]'} transition-colors text-right`}
            >
              <div className="w-7 h-7 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 flex items-center justify-center">
                <ImageIcon className="w-4 h-4" />
              </div>
              <span>إضافة من الصور</span>
            </button>

            {/* 3. Files option */}
            <button
              type="button"
              onClick={() => filesInputRef.current?.click()}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium ${isLight ? 'text-[#202123] hover:bg-[#F7F7F8]' : 'text-[#ececec] hover:bg-[#2a2a2a]'} transition-colors text-right`}
            >
              <div className="w-7 h-7 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 flex items-center justify-center">
                <FileText className="w-4 h-4" />
              </div>
              <span>ملفات</span>
            </button>

            {/* 4. Google Search Verification option */}
            <button
              type="button"
              onClick={() => {
                setIsGoogleSearchActive(true);
                setIsPlusMenuOpen(false);
                textareaRef.current?.focus();
              }}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium ${isLight ? 'text-[#202123] hover:bg-[#F7F7F8]' : 'text-[#ececec] hover:bg-[#2a2a2a]'} transition-colors text-right`}
            >
              <div className="w-7 h-7 rounded-lg bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                <Globe className="w-4 h-4" />
              </div>
              <div className="flex flex-col text-right">
                <span className="font-semibold">البحث على Google</span>
                <span className="text-[10px] text-neutral-400">تحقق سريع من معلومة أو خبر</span>
              </div>
            </button>
          </div>
        </div>
      )}

      {/* Google Search Verification Active Mode Banner */}
      {isGoogleSearchActive && (
        <div className={`mb-2 px-3 py-1.5 rounded-xl border flex items-center justify-between text-xs animate-in fade-in slide-in-from-bottom-1 duration-150 ${
          isLight ? 'bg-blue-50/90 border-blue-200 text-blue-800' : 'bg-blue-950/40 border-blue-800/60 text-blue-300'
        }`}>
          <div className="flex items-center gap-2">
            <Globe className="w-3.5 h-3.5 text-blue-500 animate-spin" />
            <span className="font-medium text-[11px] sm:text-xs">
              وضع التحقق عبر Google مفعل: سيتم البحث في الويب فوراً والتأكد من صحة المعلومة
            </span>
          </div>
          <button
            type="button"
            onClick={() => setIsGoogleSearchActive(false)}
            className="p-1 rounded-md hover:bg-black/5 dark:hover:bg-white/10 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 transition-colors"
            title="إلغاء وضع البحث"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Clean ChatGPT-Style Composer */}
      <div className={`relative ${isLight ? 'bg-white border-[#e5e5e5] shadow-[0_2px_12px_rgba(0,0,0,0.06)] focus-within:border-neutral-400' : 'bg-[#212121] border-[#303030] shadow-[0_2px_12px_rgba(0,0,0,0.25)] focus-within:border-neutral-500'} border rounded-2xl transition-all`}>
        {isRecording ? (
          <div className="flex items-center justify-between px-4 py-3">
            <div className="flex items-center gap-3">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500" />
              </span>
              <span className="text-xs font-semibold text-rose-500 font-mono">
                {formatTimer(recordSeconds)}
              </span>
              {/* Sound wave bars while recording */}
              <div className="flex items-center gap-1 h-5 mr-1">
                {liveWaveBars.map((h, i) => (
                  <div
                    key={i}
                    className="w-1 bg-rose-500 rounded-full transition-all duration-100"
                    style={{ height: `${h}px` }}
                  />
                ))}
              </div>
              <span className={`text-xs ${isLight ? 'text-neutral-500' : 'text-neutral-400'}`}>
                أستمع إليك الآن...
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleStopRecording(false)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium ${isLight ? 'text-neutral-600 hover:bg-neutral-100' : 'text-neutral-300 hover:bg-neutral-800'} transition-colors`}
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={() => handleStopRecording(true)}
                className="px-3.5 py-1.5 rounded-lg text-xs font-medium bg-neutral-900 hover:bg-neutral-800 dark:bg-white dark:text-neutral-900 text-white transition-colors flex items-center gap-1.5 shadow-sm"
              >
                <StopCircle className="w-3.5 h-3.5" />
                <span>إرسال</span>
              </button>
            </div>
          </div>
        ) : isTranscribing ? (
          <div className={`flex items-center justify-center gap-2.5 py-3 ${isLight ? 'text-neutral-600' : 'text-neutral-300'} text-xs font-medium`}>
            <Loader2 className="w-4 h-4 animate-spin text-neutral-500" />
            <span>جاري معالجة الصوت وتحويله إلى نص...</span>
          </div>
        ) : (
          <div className="flex items-end justify-between px-3 py-2 gap-2">
            
            {/* Attachment Button (+) */}
            <button
              type="button"
              onClick={() => setIsPlusMenuOpen(!isPlusMenuOpen)}
              className={`p-2 ${isLight ? 'text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100' : 'text-neutral-400 hover:text-white hover:bg-neutral-800'} rounded-xl transition-colors shrink-0 mb-0.5`}
              title="إرفاق ملفات أو صور"
            >
              <Plus className="w-5 h-5 stroke-[2]" />
            </button>

            {/* Google Search Quick Verification Button */}
            <button
              type="button"
              onClick={() => setIsGoogleSearchActive(!isGoogleSearchActive)}
              className={`p-2 rounded-xl transition-all shrink-0 mb-0.5 flex items-center gap-1.5 ${
                isGoogleSearchActive
                  ? isLight
                    ? 'bg-blue-100/90 text-blue-700 border border-blue-300 shadow-2xs font-semibold'
                    : 'bg-blue-900/50 text-blue-300 border border-blue-700/60 shadow-xs'
                  : isLight
                  ? 'text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100'
                  : 'text-neutral-400 hover:text-white hover:bg-neutral-800'
              }`}
              title={isGoogleSearchActive ? 'إلغاء تفعيل بحث Google' : 'البحث على Google للتحقق من معلومة'}
            >
              <Globe className={`w-4.5 h-4.5 stroke-[2] ${isGoogleSearchActive ? 'text-blue-500 animate-spin' : ''}`} />
              {isGoogleSearchActive && (
                <span className="text-[11px] font-medium hidden sm:inline text-blue-600 dark:text-blue-400">تحقق Google</span>
              )}
            </button>

            {/* Middle: Text Input with auto-direction detection */}
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={isGoogleSearchActive ? 'اكتب المعلومة أو السؤال للتحقق منه عبر بحث Google...' : 'اسأل Onyx AI أي شيء...'}
              rows={1}
              className={`flex-1 bg-transparent border-0 text-sm md:text-base ${isLight ? 'text-[#202123] placeholder-neutral-400' : 'text-[#ececec] placeholder-neutral-500'} focus:outline-none resize-none py-2 px-2 max-h-36 leading-relaxed font-normal ${detectTextDirection(input) === 'rtl' ? 'text-right' : 'text-left'}`}
              dir={detectTextDirection(input)}
            />

            {/* Controls on end: Microphone + Action button */}
            <div className="flex items-center gap-1.5 shrink-0 mb-0.5">
              
              {/* Monochrome Microphone Icon */}
              <button
                type="button"
                onClick={handleStartRecording}
                className={`p-2 ${isLight ? 'text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100' : 'text-neutral-400 hover:text-white hover:bg-neutral-800'} rounded-xl transition-colors`}
                title="تسجيل صوتي"
              >
                <Mic className="w-4.5 h-4.5 stroke-[2]" />
              </button>

              {/* Action Button:
                  - During streaming: stop square button
                  - When input has content: minimal dark send circle
                  - When empty: voice modal button
              */}
              {isLoading ? (
                <button
                  type="button"
                  onClick={onStopGeneration}
                  className="w-8 h-8 rounded-full bg-neutral-900 hover:bg-neutral-800 dark:bg-white dark:hover:bg-neutral-200 text-white dark:text-neutral-900 flex items-center justify-center transition-transform active:scale-95 cursor-pointer shadow-sm"
                  title="إيقاف الرد"
                >
                  <Square className="w-3 h-3 fill-current" />
                </button>
              ) : hasContent ? (
                <button
                  type="button"
                  onClick={() => handleSubmit()}
                  className="w-8 h-8 rounded-full bg-[#0d0d0d] hover:bg-[#202020] dark:bg-white dark:hover:bg-neutral-200 text-white dark:text-neutral-900 flex items-center justify-center transition-all active:scale-95 shadow-sm"
                  title="إرسال"
                >
                  <ArrowUp className="w-4 h-4 stroke-[2.5]" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={onOpenVoiceModal}
                  className={`w-8 h-8 rounded-full ${isLight ? 'bg-neutral-100 hover:bg-neutral-200 text-neutral-700' : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300'} flex items-center justify-center transition-all active:scale-95 group shadow-xs`}
                  title="المحادثة الصوتية التفاعلية"
                >
                  <div className="flex items-center justify-center gap-[2px] h-4">
                    <div className="w-[2.5px] h-2 bg-current rounded-full group-hover:h-3 transition-all" />
                    <div className="w-[2.5px] h-3.5 bg-current rounded-full group-hover:h-4 transition-all" />
                    <div className="w-[2.5px] h-4 bg-current rounded-full group-hover:h-3 transition-all" />
                    <div className="w-[2.5px] h-3 bg-current rounded-full group-hover:h-3.5 transition-all" />
                    <div className="w-[2.5px] h-1.5 bg-current rounded-full group-hover:h-2.5 transition-all" />
                  </div>
                </button>
              )}

            </div>

          </div>
        )}
      </div>

    </div>
  );
};
