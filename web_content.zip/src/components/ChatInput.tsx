import React, { useState, useRef, useEffect } from 'react';
import { Send, Image, X, Mic, MicOff, Sparkles } from 'lucide-react';

interface ChatInputProps {
  onSendMessage: (text: string, image?: { data: string; mimeType: string; previewUrl?: string }) => void;
  isLoading: boolean;
}

export const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, isLoading }) => {
  const [text, setText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [selectedImage, setSelectedImage] = useState<{
    data: string;
    mimeType: string;
    previewUrl: string;
  } | null>(null);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  // Auto resize textarea height
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 140)}px`;
    }
  }, [text]);

  // Voice speech-to-text setup
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'ar-SA';

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setText((prev) => (prev ? `${prev} ${transcript}` : transcript));
        setIsListening(false);
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, []);

  const [notice, setNotice] = useState<string | null>(null);

  const showNotice = (msg: string) => {
    setNotice(msg);
    setTimeout(() => setNotice(null), 4000);
  };

  const toggleListening = () => {
    if (!recognitionRef.current) {
      showNotice('التعرف الصوتي غير مدعوم في متصفحك الحالي. يرجى تجربة متصفح Chrome أو أندرويد.');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      setIsListening(true);
      recognitionRef.current.start();
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showNotice('يرجى اختيار ملف صورة صالح (PNG, JPEG, WebP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const resultStr = reader.result as string;
      const base64Data = resultStr.split(',')[1];
      setSelectedImage({
        data: base64Data,
        mimeType: file.type,
        previewUrl: resultStr,
      });
    };
    reader.readAsDataURL(file);

    // Reset input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeSelectedImage = () => {
    setSelectedImage(null);
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (isLoading || (!text.trim() && !selectedImage)) return;

    onSendMessage(text.trim(), selectedImage || undefined);
    setText('');
    setSelectedImage(null);

    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="w-full bg-[#080E21]/95 backdrop-blur-md border-t border-blue-900/40 p-2 sm:p-3 pb-3 safe-bottom transition-all">
      <div className="max-w-4xl mx-auto">
        {/* Attached image preview bar */}
        {selectedImage && (
          <div className="flex items-center gap-2 mb-2 p-1.5 bg-blue-950/60 border border-blue-800/40 rounded-xl w-fit animate-fade-in">
            <div className="relative w-12 h-12 rounded-lg overflow-hidden border border-blue-500/30">
              <img
                src={selectedImage.previewUrl}
                alt="معاينة الصورة"
                className="w-full h-full object-cover"
              />
              <button
                type="button"
                onClick={removeSelectedImage}
                className="absolute top-0.5 right-0.5 bg-black/70 hover:bg-rose-600 text-white rounded-full p-0.5 transition-colors"
                title="إزالة الصورة"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
            <span className="text-xs text-blue-300 font-medium px-1">
              تم إرفاق صورة لتحليلها مع Mostafa AI
            </span>
          </div>
        )}

        {/* Inline friendly notice if mic/image error occurs */}
        {notice && (
          <div className="mb-2 p-2 rounded-xl bg-blue-950/80 border border-blue-600/50 text-blue-200 text-xs flex items-center justify-between animate-fade-in shadow-md">
            <span>{notice}</span>
            <button
              type="button"
              onClick={() => setNotice(null)}
              className="p-0.5 text-blue-400 hover:text-white"
            >
              ✕
            </button>
          </div>
        )}

        {/* Input & Action Bar */}
        <form onSubmit={handleSubmit} className="flex items-end gap-1.5 sm:gap-2">
          {/* File Input (Hidden) */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImageSelect}
            accept="image/*"
            className="hidden"
          />

          {/* Attach Image Button */}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            title="إرفاق صورة لتحليلها"
            className="flex-shrink-0 p-2.5 sm:p-3 rounded-xl bg-blue-950/60 hover:bg-blue-900/60 text-blue-400 hover:text-cyan-300 border border-blue-900/50 active:scale-95 transition-all"
          >
            <Image className="w-5 h-5" />
          </button>

          {/* Voice Mic Button */}
          <button
            type="button"
            onClick={toggleListening}
            title={isListening ? 'إيقاف التسجيل' : 'تحدث بالصوت (إملاء عربي)'}
            className={`flex-shrink-0 p-2.5 sm:p-3 rounded-xl border transition-all active:scale-95 ${
              isListening
                ? 'bg-rose-600 text-white border-rose-500 animate-pulse'
                : 'bg-blue-950/60 hover:bg-blue-900/60 text-blue-400 hover:text-cyan-300 border-blue-900/50'
            }`}
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* Text Area */}
          <div className="flex-1 relative rounded-2xl bg-[#0F1A38] border border-blue-800/50 focus-within:border-blue-500 focus-within:ring-2 focus-within:ring-blue-500/20 shadow-inner transition-all">
            <textarea
              ref={textareaRef}
              rows={1}
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={isListening ? 'جاري الاستماع لصوتك...' : 'اكتب رسالتك لـ Mostafa AI... (اضغط Enter للإرسال)'}
              disabled={isLoading}
              dir="auto"
              className="w-full bg-transparent text-slate-100 placeholder-slate-400/70 text-sm sm:text-base px-3.5 py-2.5 sm:py-3 focus:outline-none resize-none max-h-36 overflow-y-auto leading-relaxed"
            />
          </div>

          {/* Send Button */}
          <button
            type="submit"
            disabled={isLoading || (!text.trim() && !selectedImage)}
            aria-label="إرسال"
            className={`flex-shrink-0 p-2.5 sm:p-3 rounded-xl font-semibold flex items-center justify-center transition-all duration-200 shadow-md ${
              isLoading || (!text.trim() && !selectedImage)
                ? 'bg-blue-950/40 text-slate-500 border border-blue-950 cursor-not-allowed'
                : 'bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-500 hover:to-blue-600 text-white shadow-blue-600/40 active:scale-95'
            }`}
          >
            {isLoading ? (
              <Sparkles className="w-5 h-5 text-cyan-300 animate-spin" />
            ) : (
              <Send className="w-5 h-5 rotate-180" />
            )}
          </button>
        </form>

        <div className="mt-1 flex items-center justify-between px-2 text-[10px] text-slate-400/60 font-sans">
          <span>متوافق مع الهواتف الذكية وشاشات أندرويد</span>
          <span>مدعوم بنماذج Google Gemini AI الفائقة</span>
        </div>
      </div>
    </div>
  );
};
