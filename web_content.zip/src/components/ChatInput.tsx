import React, { useState, useRef, useEffect } from 'react';
import { Send, Mic, MicOff, Square, Sparkles, CornerDownLeft } from 'lucide-react';
import { createSpeechRecognizer } from '../utils/speech';
import { playSound } from '../utils/soundEffects';

interface ChatInputProps {
  onSendMessage: (text: string) => void;
  isGenerating: boolean;
  onStopGenerating: () => void;
  soundMuted: boolean;
  initialValue?: string;
}

export const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  isGenerating,
  onStopGenerating,
  soundMuted,
  initialValue = '',
}) => {
  const [text, setText] = useState(initialValue);
  const [isRecording, setIsRecording] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if (initialValue) {
      setText(initialValue);
      if (textareaRef.current) {
        textareaRef.current.focus();
      }
    }
  }, [initialValue]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 160)}px`;
    }
  }, [text]);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    const trimmed = text.trim();
    if (!trimmed || isGenerating) return;

    playSound('send', soundMuted);
    onSendMessage(trimmed);
    setText('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const toggleVoiceRecording = () => {
    playSound('click', soundMuted);
    if (isRecording) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsRecording(false);
      return;
    }

    const recognizer = createSpeechRecognizer(
      (transcript) => {
        setText((prev) => (prev ? `${prev} ${transcript}` : transcript));
      },
      (error) => {
        console.warn('Speech error:', error);
        setIsRecording(false);
      },
      () => {
        setIsRecording(false);
      }
    );

    if (recognizer) {
      recognitionRef.current = recognizer;
      try {
        recognizer.start();
        setIsRecording(true);
      } catch (err) {
        console.error('Cannot start recognizer:', err);
      }
    } else {
      alert('La reconnaissance vocale n\'est pas supportée sur ce navigateur.');
    }
  };

  return (
    <div className="relative w-full max-w-4xl mx-auto px-2 sm:px-4 pb-4">
      <form
        onSubmit={handleSubmit}
        className="relative flex items-end gap-2 bg-[#172338]/90 border border-cyan-500/30 rounded-2xl p-2 sm:p-2.5 shadow-2xl shadow-cyan-950/60 backdrop-blur-md focus-within:border-cyan-400 focus-within:ring-2 focus-within:ring-cyan-500/20 transition-all"
      >
        {/* Voice Dictation Button */}
        <button
          type="button"
          onClick={toggleVoiceRecording}
          className={`p-2.5 rounded-xl transition-all shrink-0 ${
            isRecording
              ? 'bg-rose-500 text-white animate-pulse shadow-lg shadow-rose-500/40'
              : 'text-slate-400 hover:text-cyan-300 hover:bg-slate-800/70'
          }`}
          title={isRecording ? 'Arrêter la dictée vocale' : 'Activer la dictée vocale'}
          aria-label="Dictée vocale"
        >
          {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>

        {/* Text Input Area */}
        <textarea
          ref={textareaRef}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
          rows={1}
          placeholder={isRecording ? 'Écoute en cours... parlez maintenant' : 'Écris ton message à GPT-6...'}
          className="w-full bg-transparent text-slate-100 placeholder-slate-400 text-sm sm:text-base py-2 px-1 resize-none focus:outline-none max-h-40 min-h-[44px] leading-relaxed"
        />

        {/* Action Button: Send or Stop */}
        <div className="shrink-0 flex items-center gap-1.5">
          {isGenerating ? (
            <button
              type="button"
              onClick={onStopGenerating}
              className="flex items-center justify-center w-10 h-10 rounded-xl bg-rose-500 hover:bg-rose-600 text-white shadow-lg shadow-rose-500/30 transition-transform active:scale-95"
              title="Arrêter la réponse"
            >
              <Square className="w-4 h-4 fill-white" />
            </button>
          ) : (
            <button
              type="submit"
              disabled={!text.trim()}
              className={`flex items-center justify-center w-10 h-10 rounded-xl transition-all ${
                text.trim()
                  ? 'bg-[#55c8ff] hover:bg-[#38bdf8] text-slate-950 shadow-lg shadow-cyan-400/30 active:scale-95 cursor-pointer font-semibold'
                  : 'bg-slate-800 text-slate-600 cursor-not-allowed'
              }`}
              title="Envoyer (Entrée)"
            >
              <Send className="w-4 h-4 translate-x-0.5" />
            </button>
          )}
        </div>
      </form>

      {/* Keyboard Hint */}
      <div className="flex items-center justify-between px-2 pt-2 text-[11px] text-slate-400">
        <span className="flex items-center gap-1">
          <CornerDownLeft className="w-3 h-3 text-cyan-400 inline" />
          <span><strong className="text-slate-400">Entrée</strong> pour envoyer, <strong className="text-slate-400">Maj+Entrée</strong> pour nouvelle ligne</span>
        </span>
        <span className="text-[10px] text-slate-400 hidden sm:inline">
          GPT-6 v6.4 Quantum Core
        </span>
      </div>
    </div>
  );
};
