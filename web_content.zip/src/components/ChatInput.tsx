import React, { useState, useRef, useEffect } from 'react';
import { Send, Mic, MicOff, Sparkles, CornerDownLeft } from 'lucide-react';

interface ChatInputProps {
  onSendMessage: (text: string) => void;
  isLoading: boolean;
  disabled?: boolean;
}

export const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  isLoading,
  disabled = false,
}) => {
  const [input, setInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize textarea according to text height
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const scrollHeight = textareaRef.current.scrollHeight;
      textareaRef.current.style.height = `${Math.min(scrollHeight, 140)}px`;
    }
  }, [input]);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed || isLoading || disabled) return;

    onSendMessage(trimmed);
    setInput('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  // Web Speech API Voice Recognition (Great for Android phones)
  const toggleSpeechRecognition = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('Pengecaman suara tidak disokong pada pelayar ini.');
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = 'ms-MY';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput((prev) => (prev ? `${prev} ${transcript}` : transcript));
        setIsListening(false);
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch (err) {
      console.error('Speech recognition error:', err);
      setIsListening(false);
    }
  };

  return (
    <div className="w-full bg-[#090317]/95 border-t border-purple-900/40 p-3 sm:p-4 backdrop-blur-lg safe-bottom">
      <div className="max-w-4xl mx-auto">
        <form onSubmit={handleSubmit} className="relative flex items-end gap-2">
          {/* Input field container */}
          <div className="relative flex-1 rounded-2xl bg-[#140828] border border-purple-600/30 focus-within:border-purple-400 focus-within:ring-2 focus-within:ring-purple-500/25 transition-all shadow-[0_4px_20px_rgba(0,0,0,0.5)]">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Tanya apa saja kat HANN AI... (cth: 'Awat hang suka loghat utara?')"
              rows={1}
              disabled={isLoading || disabled}
              className="w-full bg-transparent text-slate-100 placeholder-purple-300/40 text-sm sm:text-base px-4 py-3 resize-none focus:outline-none max-h-[140px] leading-relaxed"
            />

            {/* Helper buttons inside the input box */}
            <div className="flex items-center justify-between px-3 pb-2 pt-0.5 text-xs text-purple-300/50">
              <div className="flex items-center gap-1.5">
                <span className="hidden sm:inline text-[11px]">
                  Tekan <strong>Enter</strong> untuk hantar
                </span>
                <span className="sm:hidden text-[11px]">HANN AI sedia membantu</span>
              </div>
              <div className="flex items-center gap-1">
                {/* Voice input button */}
                <button
                  type="button"
                  onClick={toggleSpeechRecognition}
                  disabled={isLoading}
                  className={`p-1 rounded-lg transition-colors ${
                    isListening
                      ? 'text-red-400 bg-red-950/60 animate-pulse'
                      : 'text-purple-400 hover:text-purple-200 hover:bg-purple-900/30'
                  }`}
                  title={isListening ? 'Mendengar suara...' : 'Guna Suara (Mikrofon)'}
                >
                  {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                </button>
                {input.length > 0 && (
                  <span className="text-[10px] font-mono text-purple-400/70 ml-1">
                    {input.length} aksara
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Butang Hantar (Send Button) */}
          <button
            type="submit"
            disabled={!input.trim() || isLoading || disabled}
            aria-label="Hantar Mesej"
            className={`flex items-center justify-center w-12 h-12 rounded-2xl transition-all shadow-lg shrink-0 ${
              input.trim() && !isLoading && !disabled
                ? 'bg-gradient-to-tr from-purple-600 via-fuchsia-600 to-violet-500 hover:from-purple-500 hover:to-violet-400 text-white shadow-purple-600/40 hover:scale-105 active:scale-95'
                : 'bg-purple-950/40 text-purple-500/40 border border-purple-900/30 cursor-not-allowed'
            }`}
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-purple-300 border-t-transparent rounded-full animate-spin" />
            ) : (
              <Send className="w-5 h-5 transition-transform group-hover:translate-x-0.5" />
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
