import React, { useRef, useEffect, useState } from 'react';
import { Send, Square, Mic, MicOff, Sparkles } from 'lucide-react';
import { getSpeechRecognition } from '../utils/speech';

interface ChatInputProps {
  input: string;
  setInput: (value: string) => void;
  onSend: (text?: string) => void;
  onStop: () => void;
  isLoading: boolean;
}

export const ChatInput: React.FC<ChatInputProps> = ({
  input,
  setInput,
  onSend,
  onStop,
  isLoading,
}) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [isListening, setIsListening] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(false);
  const recognitionRef = useRef<any>(null);

  // Check speech recognition support
  useEffect(() => {
    const recognition = getSpeechRecognition();
    if (recognition) {
      setSpeechSupported(true);
      recognitionRef.current = recognition;

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          setInput(input ? `${input} ${transcript}` : transcript);
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };
    }
  }, [input, setInput]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const scrollHeight = textareaRef.current.scrollHeight;
      textareaRef.current.style.height = `${Math.min(scrollHeight, 180)}px`;
    }
  }, [input]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (!isLoading && input.trim()) {
        onSend();
      }
    }
  };

  const toggleListening = () => {
    if (!recognitionRef.current) return;

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch (err) {
        console.error('Failed to start speech recognition', err);
      }
    }
  };

  return (
    <div className="relative max-w-4xl mx-auto w-full px-4 pb-4">
      <div className="relative rounded-2xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-slate-950/50 focus-within:border-emerald-500 dark:focus-within:border-emerald-500 focus-within:ring-2 focus-within:ring-emerald-500/20 transition-all p-2">
        <textarea
          ref={textareaRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Саволи худро ба Bill AI нависед... (масалан: Созандаат кист? ё савол дар бораи илм, код, таърих)"
          rows={1}
          className="w-full max-h-44 p-2 text-sm bg-transparent outline-none resize-none text-slate-800 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 leading-relaxed"
        />

        <div className="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-800/80">
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            {speechSupported && (
              <button
                type="button"
                onClick={toggleListening}
                className={`p-1.5 rounded-xl transition-all flex items-center gap-1 ${
                  isListening
                    ? 'bg-rose-500 text-white animate-pulse'
                    : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
                title={isListening ? 'Қатъи сабти овоз' : 'Сабти овоз'}
              >
                {isListening ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
                {isListening && <span className="text-[11px] font-medium pr-1">Гӯш мекунад...</span>}
              </button>
            )}

            <span className="hidden sm:inline-flex items-center gap-1 text-[11px] text-slate-400 dark:text-slate-500">
              <Sparkles className="w-3 h-3 text-emerald-500" />
              Ҳамаи саволҳоро посух медиҳад
            </span>
          </div>

          <div className="flex items-center gap-2">
            {isLoading ? (
              <button
                type="button"
                onClick={onStop}
                className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-medium transition-colors"
                title="Боздоштани тавлид"
              >
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>Ист</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => onSend()}
                disabled={!input.trim()}
                className={`flex items-center justify-center p-2 rounded-xl transition-all ${
                  input.trim()
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/30 cursor-pointer active:scale-95'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                }`}
                title="Фиристодани савол"
              >
                <Send className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="text-center mt-2">
        <p className="text-[11px] text-slate-400 dark:text-slate-500">
          Bill AI — Ҳуши сунъии муосири тоҷикӣ. Офаранда ва созандаи ягона:{' '}
          <span className="font-semibold text-slate-700 dark:text-slate-300">
            Мирзоев Билолиддин
          </span>
          .
        </p>
      </div>
    </div>
  );
};
