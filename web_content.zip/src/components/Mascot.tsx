export default function Mascot({ mood = 'happy', size = 150, cheer = false }: { mood?: 'happy' | 'cheer' | 'think'; size?: number; cheer?: boolean }) {
  return (
    <div className={cheer ? 'anim-cheer' : 'anim-bob'} style={{ width: size, height: size }} aria-hidden>
      <svg viewBox="0 0 200 200" width={size} height={size} className="drop-shadow-[0_10px_16px_rgba(0,0,0,.18)]">
        {/* tail feathers */}
        <ellipse cx="100" cy="168" rx="34" ry="16" fill="#f59e0b" />
        <ellipse cx="78" cy="170" rx="16" ry="10" fill="#fbbf24" />
        <ellipse cx="122" cy="170" rx="16" ry="10" fill="#fbbf24" />
        {/* feet */}
        <ellipse cx="82" cy="182" rx="14" ry="7" fill="#f97316" />
        <ellipse cx="118" cy="182" rx="14" ry="7" fill="#f97316" />
        {/* body */}
        <ellipse cx="100" cy="118" rx="62" ry="58" fill="#38bdf8" />
        <ellipse cx="100" cy="132" rx="40" ry="38" fill="#e0f2fe" />
        {/* belly spots */}
        <circle cx="88" cy="138" r="5" fill="#bae6fd" /><circle cx="112" cy="138" r="5" fill="#bae6fd" /><circle cx="100" cy="150" r="5" fill="#bae6fd" />
        {/* wings */}
        <g className="wing-wave"><ellipse cx="42" cy="112" rx="20" ry="34" fill="#0284c7" transform="rotate(18 42 112)" /></g>
        <ellipse cx="158" cy="112" rx="20" ry="34" fill="#0284c7" transform="rotate(-18 158 112)" />
        {/* head */}
        <circle cx="100" cy="62" r="48" fill="#38bdf8" />
        {/* ear tufts */}
        <path d="M62 28 Q52 8 66 14 Q72 22 70 32 Z" fill="#0284c7" />
        <path d="M138 28 Q148 8 134 14 Q128 22 130 32 Z" fill="#0284c7" />
        {/* face patch */}
        <ellipse cx="100" cy="68" rx="36" ry="30" fill="#e0f2fe" />
        {/* eyes */}
        <g className="eyes-blink">
          <circle cx="84" cy="62" r="11" fill="#1e293b" /><circle cx="116" cy="62" r="11" fill="#1e293b" />
          <circle cx="88" cy="58" r="4" fill="white" /><circle cx="120" cy="58" r="4" fill="white" />
          <circle cx="81" cy="66" r="2" fill="white" opacity=".8" /><circle cx="113" cy="66" r="2" fill="white" opacity=".8" />
        </g>
        {/* cheeks */}
        <circle cx="70" cy="78" r="8" fill="#fda4af" opacity=".85" /><circle cx="130" cy="78" r="8" fill="#fda4af" opacity=".85" />
        {/* beak */}
        {mood === 'cheer' ? (
          <path d="M88 76 Q100 92 112 76 Q100 82 88 76Z" fill="#f97316" />
        ) : mood === 'think' ? (
          <ellipse cx="100" cy="80" rx="9" ry="6" fill="#f97316" />
        ) : (
          <path d="M90 76 Q100 86 110 76 Q100 80 90 76Z" fill="#f97316" />
        )}
        {/* graduation cap */}
        <g transform="rotate(-8 100 22)">
          <rect x="72" y="8" width="56" height="10" rx="4" fill="#1e293b" />
          <path d="M100 2 L138 16 L100 30 L62 16 Z" fill="#334155" />
          <circle cx="100" cy="16" r="4" fill="#facc15" />
          <path d="M132 18 Q136 34 128 38" stroke="#facc15" strokeWidth="3" fill="none" strokeLinecap="round" />
          <circle cx="128" cy="40" r="4" fill="#facc15" />
        </g>
        {/* bow tie */}
        <path d="M100 108 L84 100 L84 116 Z" fill="#f43f5e" /><path d="M100 108 L116 100 L116 116 Z" fill="#f43f5e" />
        <circle cx="100" cy="108" r="5" fill="#be123c" />
      </svg>
    </div>
  );
}
