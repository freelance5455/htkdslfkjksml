import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Video, Play, Pause, Download, Share2, Heart, MessageSquare, Bell, DollarSign, Send, Check, Shield, Sparkles, Upload, FileVideo, Plus, X, Search, Filter, HardDrive, CheckCircle2, Maximize2, Tag } from 'lucide-react';
import { offlineCache } from '../lib/offlineCache';
import { tagManagementService } from '../lib/tagManagementService';
import { UploadedMediaItem } from '../types';
import { LazyMediaCard } from './LazyMediaCard';

interface VideoPageViewProps {
  onOpenSupportModal?: () => void;
}

export const VideoPageView: React.FC<VideoPageViewProps> = ({ onOpenSupportModal }) => {
  const [mediaList, setMediaList] = useState<UploadedMediaItem[]>(
    offlineCache.getUploadedMedia().filter(m => m.type === 'video')
  );

  const [searchQuery, setSearchQuery] = useState('');
  const [commentInputs, setCommentInputs] = useState<{ [key: string]: string }>({});
  const [replyInputs, setReplyInputs] = useState<{ [key: string]: { [commentId: string]: string } }>({});
  const [shareNotice, setShareNotice] = useState<string | null>(null);
  const [showUploadDrawer, setShowUploadDrawer] = useState(false);

  // Video Upload Form State
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoPreviewRef = useRef<HTMLVideoElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string | null>(null);
  const [capturedThumbnail, setCapturedThumbnail] = useState<string | null>(null);
  const [videoTitle, setVideoTitle] = useState('');
  const [preacherName, setPreacherName] = useState('Prophet JUHNKRIX SYNVAGORD');
  const [broadcastCategory, setBroadcastCategory] = useState('Altar Miracle Revival');
  const [scriptureRef, setScriptureRef] = useState('Mark 16:17-18');
  const [tagsInput, setTagsInput] = useState('prophetic, sermon, revival, glory');
  const [videoDescription, setVideoDescription] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadSuccessToast, setUploadSuccessToast] = useState<string | null>(null);

  useEffect(() => {
    const handleSync = () => {
      setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'video'));
    };
    const unsubscribe = offlineCache.subscribe(handleSync);
    window.addEventListener('juhnkrix-media-updated', handleSync);
    return () => {
      if (typeof unsubscribe === 'function') unsubscribe();
      window.removeEventListener('juhnkrix-media-updated', handleSync);
    };
  }, []);

  const profile = offlineCache.getProfile();
  const userName = profile.name || 'Prophetic Believer';

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const file = files[0];
    setSelectedFile(file);

    const prevUrl = URL.createObjectURL(file);
    setVideoPreviewUrl(prevUrl);

    // Auto generate title
    if (!videoTitle) {
      const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[_]/g, ' ');
      setVideoTitle(cleanName.charAt(0).toUpperCase() + cleanName.slice(1));
    }
    if (!videoDescription) {
      setVideoDescription(`Anointed video broadcast recording stored directly into the JUHNKRIX MUSIKA sanctuary vault.`);
    }

    // Try auto-capturing a thumbnail frame
    setTimeout(() => {
      captureFrameThumbnail();
    }, 800);
  };

  const captureFrameThumbnail = () => {
    if (!videoPreviewRef.current) return;
    try {
      const video = videoPreviewRef.current;
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 360;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        setCapturedThumbnail(dataUrl);
      }
    } catch (err) {
      console.warn('Thumbnail generation fallback:', err);
    }
  };

  const handleDeviceVideoUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) {
      alert('Please select a video file from your device first.');
      return;
    }

    setIsUploading(true);
    setUploadProgress(20);

    try {
      const progressTimer = setInterval(() => {
        setUploadProgress((prev) => {
          if (prev >= 85) {
            clearInterval(progressTimer);
            return 85;
          }
          return prev + 15;
        });
      }, 150);

      const titleToSave = videoTitle.trim() || selectedFile.name.replace(/\.[^/.]+$/, '');
      const descToSave = `${videoDescription.trim()} [Category: ${broadcastCategory} | Scripture: ${scriptureRef}]`;
      const parsedTags = tagsInput
        .split(',')
        .map((s) => s.trim().toLowerCase().replace(/^#/, ''))
        .filter(Boolean);

      await offlineCache.uploadDeviceMedia(selectedFile, {
        type: 'video',
        title: titleToSave,
        artistOrProphet: preacherName.trim() || 'Prophet JUHNKRIX SYNVAGORD',
        description: descToSave,
        thumbnailUrl: capturedThumbnail || 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=600&q=80',
        tags: parsedTags.length > 0 ? parsedTags : ['prophetic', 'sermon', 'revival', 'video']
      });

      setUploadProgress(100);
      clearInterval(progressTimer);

      setTimeout(() => {
        setIsUploading(false);
        setUploadProgress(0);
        setSelectedFile(null);
        setVideoPreviewUrl(null);
        setCapturedThumbnail(null);
        setVideoTitle('');
        setVideoDescription('');
        setShowUploadDrawer(false);
        setUploadSuccessToast(`✓ Video broadcast "${titleToSave}" uploaded and stored in JUHNKRIX MUSIKA storage!`);
        setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'video'));
        setTimeout(() => setUploadSuccessToast(null), 5000);
      }, 400);
    } catch (err) {
      console.error('Video upload error:', err);
      setIsUploading(false);
      alert('Failed to process video file. Please try again.');
    }
  };

  const handleLike = (id: string) => {
    offlineCache.toggleLikeMedia(id);
    setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'video'));
  };

  const handleDownload = (item: UploadedMediaItem) => {
    offlineCache.incrementDownloadMedia(item.id);
    setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'video'));
    try {
      const a = document.createElement('a');
      a.href = item.url;
      a.download = `${item.title.replace(/\s+/g, '_')}.mp4`;
      a.target = '_blank';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch {
      window.open(item.url, '_blank');
    }
  };

  const handleShare = (item: UploadedMediaItem) => {
    offlineCache.incrementShareMedia(item.id);
    setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'video'));
    navigator.clipboard?.writeText(window.location.href);
    setShareNotice(`Link copied for "${item.title}"!`);
    setTimeout(() => setShareNotice(null), 3000);
  };

  const handleSubscribe = (id: string) => {
    offlineCache.toggleSubscribeMedia(id);
    setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'video'));
  };

  const handleAddComment = (mediaId: string, e: React.FormEvent) => {
    e.preventDefault();
    const text = commentInputs[mediaId];
    if (!text || !text.trim()) return;
    offlineCache.addCommentMedia(mediaId, text.trim(), userName);
    setCommentInputs({ ...commentInputs, [mediaId]: '' });
    setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'video'));
  };

  const handleAddReply = (mediaId: string, commentId: string, e: React.FormEvent) => {
    e.preventDefault();
    const text = replyInputs[mediaId]?.[commentId];
    if (!text || !text.trim()) return;
    offlineCache.addReplyCommentMedia(mediaId, commentId, text.trim(), userName);
    setReplyInputs({
      ...replyInputs,
      [mediaId]: { ...replyInputs[mediaId], [commentId]: '' }
    });
    setMediaList(offlineCache.getUploadedMedia().filter(m => m.type === 'video'));
  };

  const filteredMedia = mediaList.filter(item => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      item.title.toLowerCase().includes(q) ||
      item.description.toLowerCase().includes(q) ||
      item.artistOrProphet.toLowerCase().includes(q)
    );
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-8 max-w-5xl mx-auto pb-20 px-4 sm:px-6"
    >
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-950/90 via-slate-900 to-slate-950 border border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-mono">
              <Shield className="w-3.5 h-3.5 text-amber-400" />
              <span>Prophet JUHNKRIX SYNVAGORD • Inbuilt Video Broadcast Vault</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-extrabold font-serif tracking-tight text-amber-100">
              VIDEO BROADCASTS
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Watch anointed altar broadcast sermons, live miracle services, and prophetic teaching videos. Upload videos directly from your device storage to store permanently in JUHNKRIX MUSIKA inbuilt storage.
            </p>
          </div>
          
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setShowUploadDrawer(!showUploadDrawer)}
              className="flex items-center space-x-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 text-xs font-black shadow-xl shadow-amber-500/30 hover:scale-105 transition-all border border-amber-300"
            >
              <Upload className="w-4 h-4" />
              <span>{showUploadDrawer ? 'Close Uploader' : '📤 Upload Video from Device'}</span>
            </button>
            <button
              onClick={onOpenSupportModal}
              className="flex items-center space-x-2 px-4 py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 text-amber-300 text-xs font-bold border border-amber-500/30 transition-all"
            >
              <DollarSign className="w-4 h-4 text-amber-400" />
              <span>Support Ministry</span>
            </button>
          </div>
        </div>
      </div>

      {/* Upload Success Toast */}
      {uploadSuccessToast && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-emerald-950/90 border border-emerald-500/50 text-emerald-200 text-xs px-5 py-4 rounded-2xl shadow-xl flex items-center justify-between"
        >
          <div className="flex items-center space-x-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span className="font-bold">{uploadSuccessToast}</span>
          </div>
          <span className="text-[11px] font-mono text-emerald-300/80">Reflected Publicly</span>
        </motion.div>
      )}

      {/* Share Notice Toast */}
      {shareNotice && (
        <div className="bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs px-4 py-3 rounded-2xl shadow-lg flex items-center space-x-2">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{shareNotice}</span>
        </div>
      )}

      {/* Dedicated Inbuilt Video Device Uploader Panel */}
      <AnimatePresence>
        {showUploadDrawer && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="bg-slate-900 border-2 border-amber-500/50 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 relative">
              <div className="flex items-center justify-between border-b border-amber-500/20 pb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                    <FileVideo className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-base sm:text-lg font-bold font-serif text-amber-100">
                      Upload Video to Video Page & Inbuilt Storage
                    </h2>
                    <p className="text-xs text-amber-300/80 font-mono">
                      Select video from device storage (.mp4, .webm, .mov, .mkv) • Stored permanently in IndexedDB
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setShowUploadDrawer(false)}
                  className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white border border-amber-500/20"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleDeviceVideoUpload} className="space-y-6">
                {/* File Drop / Select Area */}
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileSelect}
                  accept="video/*,.mp4,.webm,.mov,.mkv"
                  className="hidden"
                />

                <div
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all ${
                    selectedFile
                      ? 'border-emerald-500/60 bg-emerald-950/20'
                      : 'border-amber-500/40 hover:border-amber-400 bg-slate-950/80'
                  }`}
                >
                  {selectedFile ? (
                    <div className="space-y-2">
                      <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/40">
                        <FileVideo className="w-6 h-6" />
                      </div>
                      <p className="text-xs sm:text-sm font-bold text-emerald-200">
                        Selected: {selectedFile.name}
                      </p>
                      <p className="text-[11px] font-mono text-slate-400">
                        Size: {(selectedFile.size / (1024 * 1024)).toFixed(2)} MB • Type: {selectedFile.type || 'video/mp4'}
                      </p>
                      <span className="inline-block px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-mono border border-emerald-500/30">
                        Click to change video
                      </span>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto border border-amber-500/40">
                        <Upload className="w-6 h-6" />
                      </div>
                      <p className="text-xs sm:text-sm font-bold text-amber-200">
                        Click to Select Video File Directly from Device Storage
                      </p>
                      <p className="text-[11px] text-slate-400">
                        Supports MP4, WebM, MOV, MKV formats
                      </p>
                    </div>
                  )}
                </div>

                {/* Video Preview Player with Snapshot */}
                {videoPreviewUrl && (
                  <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/30 space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-[11px] font-mono font-bold text-amber-300 flex items-center space-x-2">
                        <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                        <span>Video Stream Preview (Before Storage)</span>
                      </p>
                      <button
                        type="button"
                        onClick={captureFrameThumbnail}
                        className="px-3 py-1 bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/40 rounded-lg text-[10px] font-mono"
                      >
                        📸 Capture Current Frame as Poster
                      </button>
                    </div>
                    <video
                      ref={videoPreviewRef}
                      controls
                      src={videoPreviewUrl}
                      onLoadedData={captureFrameThumbnail}
                      onSeeked={captureFrameThumbnail}
                      className="w-full max-h-64 rounded-xl object-contain bg-black"
                    />
                  </div>
                )}

                {/* Metadata Fields */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[11px] font-bold text-amber-300 block mb-1">
                      Video Broadcast Title *
                    </label>
                    <input
                      type="text"
                      required
                      value={videoTitle}
                      onChange={(e) => setVideoTitle(e.target.value)}
                      placeholder="e.g. Altar of Power: Prophetic Miracles"
                      className="w-full bg-slate-950 text-amber-100 border border-amber-500/30 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-amber-400 font-bold"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-amber-300 block mb-1">
                      Preacher / Prophet / Speaker
                    </label>
                    <input
                      type="text"
                      value={preacherName}
                      onChange={(e) => setPreacherName(e.target.value)}
                      placeholder="Prophet JUHNKRIX SYNVAGORD"
                      className="w-full bg-slate-950 text-amber-100 border border-amber-500/30 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-amber-300 block mb-1">
                      Broadcast Category
                    </label>
                    <select
                      value={broadcastCategory}
                      onChange={(e) => setBroadcastCategory(e.target.value)}
                      className="w-full bg-slate-950 text-amber-100 border border-amber-500/30 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-amber-400 font-mono"
                    >
                      <option value="Altar Miracle Revival">Altar Miracle Revival & Fire</option>
                      <option value="Prophetic Revelations">Prophetic Revelations & Teaching</option>
                      <option value="Deliverance Warfare">Deliverance Warfare & Breaking Yokes</option>
                      <option value="Midnight Prayer Watch">Midnight Prayer Watch Broadcast</option>
                      <option value="Soaking Atmosphere">Soaking Worship Atmosphere</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-amber-300 block mb-1">
                      Key Scripture Anchor
                    </label>
                    <input
                      type="text"
                      value={scriptureRef}
                      onChange={(e) => setScriptureRef(e.target.value)}
                      placeholder="e.g. Mark 16:17-18, Acts 10:38"
                      className="w-full bg-slate-950 text-amber-100 border border-amber-500/30 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-amber-400 font-mono"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="text-[11px] font-bold text-amber-300 mb-1 flex items-center space-x-1.5">
                      <Tag className="w-3.5 h-3.5 text-amber-400" />
                      <span>Searchable Tags (Comma-Separated, e.g. prophetic, sermon, revival, miracle)</span>
                    </label>
                    <input
                      type="text"
                      value={tagsInput}
                      onChange={(e) => setTagsInput(e.target.value)}
                      placeholder="prophetic, sermon, revival, altar fire, miracles"
                      className="w-full bg-slate-950 text-amber-200 border border-amber-500/40 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-amber-400 font-mono font-bold"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">
                    Spiritual Summary & Prophetic Decrees
                  </label>
                  <textarea
                    rows={2}
                    value={videoDescription}
                    onChange={(e) => setVideoDescription(e.target.value)}
                    placeholder="Enter sermon highlights, altar call details, or deliverance prayers..."
                    className="w-full bg-slate-950 text-amber-100 border border-amber-500/30 rounded-xl px-3.5 py-2 text-xs focus:outline-none focus:border-amber-400"
                  />
                </div>

                {/* Upload Progress Bar */}
                {isUploading && (
                  <div className="space-y-1.5 pt-2">
                    <div className="flex justify-between text-[11px] font-mono text-amber-300">
                      <span>Storing Video into JUHNKRIX MUSIKA Inbuilt Storage...</span>
                      <span>{uploadProgress}%</span>
                    </div>
                    <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-amber-500/30">
                      <div
                        className="h-full bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-300 transition-all duration-200"
                        style={{ width: `${uploadProgress}%` }}
                      />
                    </div>
                  </div>
                )}

                {/* Submit Action */}
                <button
                  type="submit"
                  disabled={isUploading || !selectedFile}
                  className={`w-full py-3.5 rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center space-x-2 transition-all shadow-xl ${
                    isUploading || !selectedFile
                      ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                      : 'bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-400 hover:scale-[1.01] text-slate-950 border border-amber-300 shadow-amber-500/20'
                  }`}
                >
                  <Upload className="w-4 h-4" />
                  <span>
                    {isUploading ? 'Writing Video to Storage...' : 'Save & Publish Video to Video Broadcasts'}
                  </span>
                </button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Search & Filter Toolbar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-900/80 border border-amber-500/20 rounded-2xl p-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-amber-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search video broadcasts, preachers, scriptures..."
            className="w-full bg-slate-950 border border-amber-500/30 rounded-xl pl-9 pr-3 py-2 text-xs text-amber-100 placeholder-slate-400 focus:outline-none focus:border-amber-400"
          />
        </div>
        <div className="flex items-center space-x-3 text-xs font-mono text-slate-400 w-full sm:w-auto justify-end">
          <HardDrive className="w-4 h-4 text-amber-400" />
          <span>{filteredMedia.length} Video Broadcasts Available</span>
        </div>
      </div>

      {/* Video List */}
      <div className="space-y-8">
        {filteredMedia.length === 0 ? (
          <div className="bg-slate-900/80 border border-amber-500/30 rounded-3xl p-12 text-center space-y-4">
            <div className="w-16 h-16 bg-amber-500/20 text-amber-400 rounded-full flex items-center justify-center mx-auto border border-amber-500/40">
              <Video className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold font-serif text-amber-100">
              {searchQuery ? 'No Video Broadcasts Matched Search' : 'No Video Broadcasts Uploaded Yet'}
            </h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Select videos from your device storage using the "Upload Video from Device" button above to store them into JUHNKRIX MUSIKA inbuilt storage and display them here publicly.
            </p>
            <button
              onClick={() => setShowUploadDrawer(true)}
              className="px-5 py-2.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs hover:bg-amber-400 transition-all shadow-lg"
            >
              + Upload First Video Broadcast
            </button>
          </div>
        ) : (
          filteredMedia.map((item) => (
            <LazyMediaCard key={item.id} item={item}>
              {(isLoaded) => (
                <div
                  className="bg-slate-900/90 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 relative overflow-hidden"
                >
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-[10px] font-mono bg-amber-500/20 text-amber-300 px-2.5 py-0.5 rounded-full border border-amber-500/30">
                      🎬 Inbuilt Video Broadcast
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">{item.date}</span>
                  </div>
                  <h3 className="text-lg sm:text-2xl font-bold font-serif text-amber-100">{item.title}</h3>
                  <p className="text-xs text-amber-300/80 font-mono">Streamed by {item.artistOrProphet}</p>
                </div>

                <button
                  onClick={() => handleSubscribe(item.id)}
                  className={`flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all border ${
                    item.isSubscribed
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                      : 'bg-slate-950 text-slate-300 border-slate-700 hover:border-amber-500/40'
                  }`}
                >
                  <Bell className={`w-3.5 h-3.5 ${item.isSubscribed ? 'text-amber-400 fill-amber-400' : ''}`} />
                  <span>{item.isSubscribed ? 'Subscribed' : 'Subscribe'}</span>
                </button>
              </div>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">{item.description}</p>
              {item.tags && item.tags.length > 0 && (
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {item.tags.map((tag, tIdx) => (
                    <span
                      key={tIdx}
                      className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-300 text-[10px] font-mono border border-amber-500/30"
                    >
                      <Tag className="w-2.5 h-2.5 text-amber-400" />
                      <span>#{tag}</span>
                    </span>
                  ))}
                </div>
              )}

              {/* Video HTML5 Player */}
              <div className="rounded-2xl overflow-hidden border border-amber-500/30 bg-slate-950 shadow-2xl">
                <video
                  controls
                  src={item.url}
                  poster={item.thumbnailUrl}
                  preload="metadata"
                  className="w-full max-h-[480px] object-cover bg-black"
                />
              </div>

              {/* Action Bar */}
              <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-amber-500/20 text-xs">
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => handleLike(item.id)}
                    className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-xl border transition-all ${
                      item.isLiked
                        ? 'bg-red-500/20 text-red-300 border-red-500/40 shadow-lg'
                        : 'bg-slate-950 text-slate-300 border-amber-500/20 hover:border-amber-400'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${item.isLiked ? 'text-red-400 fill-red-400' : ''}`} />
                    <span>{item.likes} Likes</span>
                  </button>

                  <button
                    onClick={() => handleDownload(item)}
                    className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-950 text-amber-300 border border-amber-500/30 hover:bg-amber-500/10 transition-all"
                  >
                    <Download className="w-4 h-4" />
                    <span>{item.downloads} Downloads</span>
                  </button>

                  <button
                    onClick={() => handleShare(item)}
                    className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-950 text-amber-300 border border-amber-500/30 hover:bg-amber-500/10 transition-all"
                  >
                    <Share2 className="w-4 h-4" />
                    <span>{item.shares} Shares</span>
                  </button>
                </div>

                <button
                  onClick={onOpenSupportModal}
                  className="flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 font-bold transition-all"
                >
                  <DollarSign className="w-4 h-4 text-amber-400" />
                  <span>Support Video Ministry</span>
                </button>
              </div>

              {/* Comments Section */}
              <div className="space-y-4 pt-4 border-t border-slate-800">
                <div className="flex items-center space-x-2 text-xs font-bold text-amber-200">
                  <MessageSquare className="w-4 h-4 text-amber-400" />
                  <span>Comments & Testimonies ({item.comments.length})</span>
                </div>

                <form onSubmit={(e) => handleAddComment(item.id, e)} className="flex gap-2">
                  <input
                    type="text"
                    value={commentInputs[item.id] || ''}
                    onChange={(e) => setCommentInputs({ ...commentInputs, [item.id]: e.target.value })}
                    placeholder="Leave a comment on this broadcast..."
                    className="flex-1 bg-slate-950 border border-amber-500/30 rounded-xl px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center space-x-1.5 shadow-md"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Post</span>
                  </button>
                </form>

                <div className="space-y-3 pt-2">
                  {item.comments.map((cmt) => (
                    <div key={cmt.id} className="bg-slate-950/60 border border-amber-500/20 p-4 rounded-2xl space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-amber-200">{cmt.author}</span>
                        <span className="text-[10px] text-slate-400 font-mono">{cmt.date}</span>
                      </div>
                      <p className="text-xs text-slate-300">{cmt.text}</p>

                      {cmt.replies && cmt.replies.length > 0 && (
                        <div className="pl-4 sm:pl-6 space-y-2 border-l-2 border-amber-500/30 pt-2">
                          {cmt.replies.map((rep) => (
                            <div key={rep.id} className="bg-slate-900/80 p-3 rounded-xl space-y-1">
                              <div className="flex items-center justify-between text-[11px]">
                                <span className="font-bold text-amber-300">{rep.author}</span>
                                <span className="text-[9px] text-slate-400 font-mono">{rep.date}</span>
                              </div>
                              <p className="text-xs text-slate-300">{rep.text}</p>
                            </div>
                          ))}
                        </div>
                      )}

                      <form
                        onSubmit={(e) => {
                          e.preventDefault();
                          handleAddReply(item.id, cmt.id, e);
                        }}
                        className="flex gap-2 pt-1"
                      >
                        <input
                          type="text"
                          value={replyInputs[item.id]?.[cmt.id] || ''}
                          onChange={(e) =>
                            setReplyInputs({
                              ...replyInputs,
                              [item.id]: { ...(replyInputs[item.id] || {}), [cmt.id]: e.target.value }
                            })
                          }
                          placeholder="Reply to comment..."
                          className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-[11px] text-slate-200 focus:outline-none focus:border-amber-400"
                        />
                        <button
                          type="submit"
                          className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 text-[11px] font-bold"
                        >
                          Reply
                        </button>
                      </form>
                    </div>
                  ))}
                </div>
              </div>
            </div>
              )}
            </LazyMediaCard>
          ))
        )}
      </div>
    </motion.div>
  );
};
