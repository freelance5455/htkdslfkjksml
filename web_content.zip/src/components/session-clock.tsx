import { useEffect, useState } from "react";
import { formatDuration, sessionElapsed } from "@/lib/model";
import { useAppStore, useRuntime } from "@/lib/store";
import { Button, Notice } from "@/components/ui";

export function SessionClock({ prominent = false }: { prominent?: boolean }) {
  const session = useAppStore((state) => state.session);
  const startSession = useAppStore((state) => state.startSession);
  const pauseSession = useAppStore((state) => state.pauseSession);
  const resetSession = useAppStore((state) => state.resetSession);
  const keepAwake = useAppStore((state) => state.keepAwake);
  const wake = useRuntime((state) => state.wake);
  const [now, setNow] = useState<number | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);

  useEffect(() => {
    setNow(Date.now());
    if (!session.running) return;
    const id = window.setInterval(() => setNow(Date.now()), 200);
    return () => window.clearInterval(id);
  }, [session.running]);

  const elapsed = sessionElapsed(session, now);
  const hasTime = elapsed > 0 || session.running;

  return (
    <div>
      <p className="text-xs font-semibold tracking-widest text-faint uppercase">Session</p>
      <p className={prominent ? "font-display text-5xl font-semibold tabular-nums" : "font-display text-4xl font-semibold tabular-nums"}>
        {formatDuration(elapsed)}
      </p>
      <p className="mt-1 text-sm text-muted">
        {session.running ? <span className="text-ok">Timing. </span> : "Stopped. "}
        Same clock on Home and in Tools.
      </p>
      <div className="mt-4 flex flex-wrap gap-2">
        {session.running ? (
          <Button onClick={pauseSession}>Pause</Button>
        ) : (
          <Button onClick={startSession}>Start</Button>
        )}
        {confirmReset ? (
          <>
            <Button
              variant="primary"
              onClick={() => {
                resetSession();
                setConfirmReset(false);
              }}
            >
              Confirm reset
            </Button>
            <Button variant="quiet" onClick={() => setConfirmReset(false)}>
              Cancel
            </Button>
          </>
        ) : (
          <Button variant="quiet" onClick={() => (hasTime ? setConfirmReset(true) : resetSession())} disabled={!hasTime && !session.running}>
            Reset
          </Button>
        )}
      </div>
      {keepAwake ? (
        <div className="mt-3">
          {wake === "on" ? <Notice tone="ok">Screen wake lock is on while this session runs.</Notice> : null}
          {wake === "denied" ? <Notice tone="warn">The browser denied the screen wake lock. The timer still runs.</Notice> : null}
          {wake === "unsupported" ? <Notice>Not available in this version.</Notice> : null}
          {wake === "off" && session.running ? <Notice>Wake lock is off until the browser grants it.</Notice> : null}
        </div>
      ) : null}
    </div>
  );
}
