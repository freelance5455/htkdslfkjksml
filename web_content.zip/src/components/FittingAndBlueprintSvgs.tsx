import React, { useState } from 'react';
import { Layers, Info } from 'lucide-react';
import { LangMode } from '../data/types';
import { FittingSpec } from '../data/pipesAndFittings';

export const FittingGraphic: React.FC<{ type: FittingSpec['svgType'] }> = ({ type }) => {
  const stroke = '#1D4ED8';
  const fill = '#DBEAFE';

  switch (type) {
    case 'elbow90':
      return (
        <svg viewBox="0 0 120 100" className="w-full h-24" aria-hidden="true">
          <path d="M25 75 V45 C25 28 38 20 55 20 H95 V46 H58 C52 46 49 49 49 55 V75 Z" fill={fill} stroke={stroke} strokeWidth="2.5" />
          <rect x="20" y="75" width="34" height="10" rx="2" fill="#93C5FD" stroke={stroke} strokeWidth="2" />
          <rect x="92" y="15" width="10" height="36" rx="2" fill="#93C5FD" stroke={stroke} strokeWidth="2" />
          <text x="68" y="78" fontSize="11" fill="#1E3A8A" fontFamily="monospace" fontWeight="700">90°</text>
        </svg>
      );
    case 'elbow45':
      return (
        <svg viewBox="0 0 120 100" className="w-full h-24" aria-hidden="true">
          <path d="M20 72 H52 L78 46 L94 62 L62 88 H20 Z" fill={fill} stroke={stroke} strokeWidth="2.5" />
          <rect x="14" y="68" width="10" height="24" rx="2" fill="#93C5FD" stroke={stroke} strokeWidth="2" />
          <text x="72" y="34" fontSize="11" fill="#1E3A8A" fontFamily="monospace" fontWeight="700">45°</text>
        </svg>
      );
    case 'tee':
      return (
        <svg viewBox="0 0 120 100" className="w-full h-24" aria-hidden="true">
          <path d="M18 46 H45 V18 H75 V46 H102 V72 H18 Z" fill={fill} stroke={stroke} strokeWidth="2.5" />
          <rect x="12" y="42" width="8" height="34" rx="2" fill="#93C5FD" stroke={stroke} strokeWidth="2" />
          <rect x="100" y="42" width="8" height="34" rx="2" fill="#93C5FD" stroke={stroke} strokeWidth="2" />
          <rect x="41" y="12" width="38" height="8" rx="2" fill="#93C5FD" stroke={stroke} strokeWidth="2" />
        </svg>
      );
    case 'socket':
      return (
        <svg viewBox="0 0 120 100" className="w-full h-24" aria-hidden="true">
          <rect x="18" y="38" width="84" height="28" rx="4" fill={fill} stroke={stroke} strokeWidth="2.5" />
          <line x1="60" y1="38" x2="60" y2="66" stroke={stroke} strokeWidth="2" strokeDasharray="3 3" />
          <path d="M26 52 H52 M68 52 H94" stroke="#1E40AF" strokeWidth="2" />
        </svg>
      );
    case 'reducer':
      return (
        <svg viewBox="0 0 120 100" className="w-full h-24" aria-hidden="true">
          <path d="M18 28 H50 L72 40 H102 V64 H72 L50 76 H18 Z" fill={fill} stroke={stroke} strokeWidth="2.5" />
          <text x="23" y="56" fontSize="10" fill="#1E3A8A" fontFamily="monospace">32</text>
          <text x="80" y="56" fontSize="10" fill="#1E3A8A" fontFamily="monospace">20</text>
        </svg>
      );
    case 'union':
      return (
        <svg viewBox="0 0 120 100" className="w-full h-24" aria-hidden="true">
          <rect x="16" y="38" width="28" height="26" rx="2" fill={fill} stroke={stroke} strokeWidth="2" />
          <rect x="44" y="30" width="32" height="42" rx="4" fill="#93C5FD" stroke={stroke} strokeWidth="2.5" />
          <rect x="76" y="38" width="28" height="26" rx="2" fill={fill} stroke={stroke} strokeWidth="2" />
          <line x1="52" y1="30" x2="52" y2="72" stroke="#1E3A8A" strokeWidth="1.5" />
          <line x1="68" y1="30" x2="68" y2="72" stroke="#1E3A8A" strokeWidth="1.5" />
        </svg>
      );
    case 'valve':
      return (
        <svg viewBox="0 0 120 100" className="w-full h-24" aria-hidden="true">
          <rect x="18" y="48" width="84" height="22" rx="3" fill={fill} stroke={stroke} strokeWidth="2.5" />
          <circle cx="60" cy="59" r="14" fill="#93C5FD" stroke={stroke} strokeWidth="2.5" />
          <line x1="60" y1="45" x2="60" y2="24" stroke={stroke} strokeWidth="3" />
          <rect x="34" y="18" width="52" height="8" rx="4" fill="#DC2626" stroke="#991B1B" strokeWidth="1.5" />
        </svg>
      );
    case 'bend':
      return (
        <svg viewBox="0 0 120 100" className="w-full h-24" aria-hidden="true">
          <path d="M22 82 C22 38 46 20 96 20 V42 C60 42 44 52 44 82 Z" fill={fill} stroke={stroke} strokeWidth="2.5" />
          <text x="64" y="75" fontSize="10" fill="#1E3A8A" fontFamily="monospace">SWEEP</text>
        </svg>
      );
    case 'ptrap':
      return (
        <svg viewBox="0 0 120 100" className="w-full h-24" aria-hidden="true">
          <path d="M26 16 V58 C26 78 58 78 58 58 V46 C58 38 74 38 82 42 H104 V60 H80 C76 60 76 60 76 62 C76 92 8 92 8 58 V16 Z" fill={fill} stroke={stroke} strokeWidth="2" />
          <path d="M12 64 C20 82 64 82 70 64" fill="#38BDF8" opacity="0.45" />
        </svg>
      );
    case 'floortrap':
      return (
        <svg viewBox="0 0 120 100" className="w-full h-24" aria-hidden="true">
          <rect x="32" y="18" width="56" height="8" rx="2" fill="#93C5FD" stroke={stroke} strokeWidth="2" />
          <rect x="36" y="26" width="48" height="54" rx="8" fill={fill} stroke={stroke} strokeWidth="2.5" />
          <rect x="84" y="44" width="24" height="18" fill={fill} stroke={stroke} strokeWidth="2" />
          <rect x="12" y="48" width="24" height="14" fill={fill} stroke={stroke} strokeWidth="2" />
          <path d="M38 56 H82 V76 H38 Z" fill="#38BDF8" opacity="0.4" />
        </svg>
      );
  }
};

export const BlueprintStudio: React.FC<{ lang: LangMode }> = ({ lang }) => {
  const [activeDiagram, setActiveDiagram] = useState<'bathroom' | 'kitchen' | 'riser' | 'symbols'>('bathroom');
  const [showCold, setShowCold] = useState(true);
  const [showHot, setShowHot] = useState(true);
  const [showDrain, setShowDrain] = useState(true);
  const [showDimensions, setShowDimensions] = useState(true);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-2 p-1.5 bg-slate-100 rounded-xl border border-slate-200">
        {[
          { id: 'bathroom', label: lang === 'hi' ? 'बाथरूम लेआउट (Isometric)' : 'Bathroom Blueprint' },
          { id: 'kitchen', label: lang === 'hi' ? 'किचन व ग्रीस ट्रैप' : 'Kitchen & Grease Trap' },
          { id: 'riser', label: lang === 'hi' ? 'टैंक, पंप व राइजर' : 'Riser & Booster Pump' },
          { id: 'symbols', label: lang === 'hi' ? 'ड्रॉइंग सिंबल चार्ट' : 'Blueprint Symbols' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveDiagram(tab.id as typeof activeDiagram)}
            className={`px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 min-h-[40px] ${
              activeDiagram === tab.id
                ? 'bg-blue-700 text-white shadow-sm'
                : 'text-slate-700 hover:bg-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {activeDiagram === 'bathroom' && (
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 border-b border-slate-200 bg-slate-50">
            <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
              <Layers className="w-4 h-4 text-blue-700" />
              <span>
                {lang === 'hi'
                  ? 'बाथरूम वाटर सप्लाई व ड्रेनेज नक्शा (लेयर चुनें)'
                  : 'Interactive Bathroom Rough-In Blueprint (Toggle Layers)'}
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setShowCold(!showCold)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                  showCold ? 'bg-sky-50 border-sky-300 text-sky-800' : 'bg-white border-slate-200 text-slate-500'
                }`}
              >
                Cold (Blue)
              </button>
              <button
                onClick={() => setShowHot(!showHot)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                  showHot ? 'bg-red-50 border-red-300 text-red-800' : 'bg-white border-slate-200 text-slate-500'
                }`}
              >
                Hot (Red)
              </button>
              <button
                onClick={() => setShowDrain(!showDrain)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                  showDrain ? 'bg-slate-800 border-slate-900 text-white' : 'bg-white border-slate-200 text-slate-500'
                }`}
              >
                Soil & Waste (Grey)
              </button>
              <button
                onClick={() => setShowDimensions(!showDimensions)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                  showDimensions ? 'bg-blue-50 border-blue-300 text-blue-800' : 'bg-white border-slate-200 text-slate-500'
                }`}
              >
                Heights (mm)
              </button>
            </div>
          </div>

          <div className="blueprint-grid p-3 sm:p-6 overflow-x-auto">
            <svg viewBox="0 0 860 440" className="w-full min-w-[640px] h-auto">
              {/* Walls & Floor */}
              <rect x="40" y="30" width="780" height="320" fill="none" stroke="#94A3B8" strokeWidth="2" />
              <line x1="40" y1="350" x2="820" y2="350" stroke="#334155" strokeWidth="3" />
              <text x="52" y="368" fontSize="12" fill="#334155" fontFamily="monospace" fontWeight="700">
                FFL (FINISHED FLOOR LEVEL 0.00 mm)
              </text>

              {/* Water Heater */}
              <rect x="650" y="55" width="95" height="115" rx="12" fill="#FFFFFF" stroke="#1E293B" strokeWidth="2.5" />
              <text x="697" y="108" textAnchor="middle" fontSize="11" fill="#0F172A" fontWeight="700">GEYSER</text>
              <text x="697" y="123" textAnchor="middle" fontSize="10" fill="#475569" fontFamily="monospace">50L / 80L</text>

              {/* Shower Area */}
              <circle cx="150" cy="70" r="14" fill="#E0F2FE" stroke="#0284C7" strokeWidth="2" />
              <text x="150" y="50" textAnchor="middle" fontSize="11" fill="#0F172A" fontWeight="700">SHOWER HEAD</text>
              <rect x="128" y="175" width="44" height="24" rx="4" fill="#FFFFFF" stroke="#1E293B" strokeWidth="2" />
              <text x="150" y="191" textAnchor="middle" fontSize="10" fill="#0F172A" fontWeight="700">MIXER</text>

              {/* Wash Basin */}
              <rect x="330" y="195" width="95" height="34" rx="6" fill="#FFFFFF" stroke="#1E293B" strokeWidth="2" />
              <text x="377" y="216" textAnchor="middle" fontSize="11" fill="#0F172A" fontWeight="700">WASH BASIN</text>

              {/* WC Cistern & Bowl */}
              <rect x="525" y="135" width="76" height="105" rx="4" fill="#EFF6FF" stroke="#1D4ED8" strokeWidth="2" />
              <text x="563" y="162" textAnchor="middle" fontSize="10" fill="#1E3A8A" fontWeight="700">CONCEALED</text>
              <text x="563" y="175" textAnchor="middle" fontSize="10" fill="#1E3A8A" fontWeight="700">CISTERN</text>
              <rect x="536" y="246" width="54" height="44" rx="10" fill="#FFFFFF" stroke="#1E293B" strokeWidth="2" />
              <text x="563" y="272" textAnchor="middle" fontSize="10" fill="#0F172A" fontWeight="700">WC</text>

              {/* Cold Water Layer */}
              {showCold && (
                <g>
                  <path
                    d="M800 295 H162 V195 M715 295 V170 M392 295 V245 M545 295 V240 M608 295 V255"
                    fill="none"
                    stroke="#0284C7"
                    strokeWidth="4"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  {/* Main Isolation Ball Valve */}
                  <circle cx="775" cy="295" r="8" fill="#0284C7" />
                  <text x="775" y="280" textAnchor="middle" fontSize="10" fill="#0369A1" fontWeight="700">MAIN VALVE</text>
                  <text x="615" y="248" fontSize="10" fill="#0369A1" fontWeight="700">Shattaf</text>
                </g>
              )}

              {/* Hot Water Layer */}
              {showHot && (
                <g>
                  <path
                    d="M675 170 V275 H138 V195 M362 275 V245"
                    fill="none"
                    stroke="#DC2626"
                    strokeWidth="4"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <text x="480" y="269" fontSize="10" fill="#B91C1C" fontFamily="monospace" fontWeight="700">
                    20mm HOT PPR (LEFT)
                  </text>
                </g>
              )}

              {/* Drainage Layer */}
              {showDrain && (
                <g>
                  {/* Shower & Basin 40/50mm into Floor Trap */}
                  <rect x="242" y="334" width="38" height="28" rx="4" fill="#CBD5E1" stroke="#334155" strokeWidth="2" />
                  <text x="261" y="328" textAnchor="middle" fontSize="10" fill="#334155" fontWeight="700">FLOOR TRAP</text>
                  <path d="M150 350 H242 M377 229 V348 H280 M261 362 V395 H68" fill="none" stroke="#475569" strokeWidth="7" strokeLinejoin="round" />
                  {/* 110mm Soil Stack & WC */}
                  <path d="M563 290 V415 H68" fill="none" stroke="#1E293B" strokeWidth="11" strokeLinejoin="round" />
                  <line x1="68" y1="30" x2="68" y2="425" stroke="#1E293B" strokeWidth="12" />
                  <text x="80" y="55" fontSize="10" fill="#0F172A" fontWeight="700">110mm SOIL + VENT</text>
                  <text x="155" y="390" fontSize="10" fill="#475569" fontFamily="monospace">50mm WASTE (1:50 Slope)</text>
                  <text x="380" y="412" fontSize="10" fill="#0F172A" fontFamily="monospace">110mm SOIL (1:100 Slope)</text>
                </g>
              )}

              {/* Dimension Callouts */}
              {showDimensions && (
                <g fontFamily="monospace" fontSize="10" fill="#1D4ED8" fontWeight="700">
                  <text x="182" y="75">2100 mm</text>
                  <text x="182" y="191">1050 mm (150mm C/C)</text>
                  <text x="377" y="256" textAnchor="middle">550mm Supply / 500mm Drain</text>
                  <text x="563" y="128" textAnchor="middle">1120mm Frame</text>
                  <text x="697" y="47" textAnchor="middle">1800 mm FFL</text>
                </g>
              )}
            </svg>
          </div>
        </div>
      )}

      {activeDiagram === 'kitchen' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 space-y-4">
          <h3 className="text-base font-bold text-slate-900">
            {lang === 'hi'
              ? 'किचन सिंक, डिशवॉशर, RO फिल्टर व ग्रीस ट्रैप डायग्राम'
              : 'Kitchen Sink, RO Filter, Dishwasher & Grease Trap Schematic'}
          </h3>
          <div className="blueprint-grid rounded-xl p-4 overflow-x-auto border border-slate-200">
            <svg viewBox="0 0 780 340" className="w-full min-w-[580px] h-auto">
              <rect x="60" y="70" width="220" height="65" rx="6" fill="#FFFFFF" stroke="#1E293B" strokeWidth="2.5" />
              <text x="170" y="106" textAnchor="middle" fontSize="12" fill="#0F172A" fontWeight="700">KITCHEN SINK BOWL</text>
              <rect x="330" y="135" width="110" height="120" rx="6" fill="#F8FAFC" stroke="#1E293B" strokeWidth="2" />
              <text x="385" y="196" textAnchor="middle" fontSize="11" fill="#0F172A" fontWeight="700">DISHWASHER</text>
              <rect x="520" y="195" width="160" height="90" rx="6" fill="#EFF6FF" stroke="#1D4ED8" strokeWidth="2.5" />
              <text x="600" y="236" textAnchor="middle" fontSize="11" fill="#1E3A8A" fontWeight="700">GREASE TRAP</text>
              <text x="600" y="254" textAnchor="middle" fontSize="10" fill="#1E40AF">(Oil & Fat Separator)</text>

              {/* Supply */}
              <path d="M40 175 H250 V135" fill="none" stroke="#0284C7" strokeWidth="3.5" />
              <path d="M40 195 H150 V135" fill="none" stroke="#DC2626" strokeWidth="3.5" />
              <path d="M250 175 H330" fill="none" stroke="#0284C7" strokeWidth="3" strokeDasharray="5 3" />
              <text x="262" y="166" fontSize="10" fill="#0369A1" fontWeight="700">Tee to RO & DW (450mm)</text>

              {/* Drain */}
              <path d="M170 135 V215 C170 235 200 235 200 215 V200 H260 V255 H520" fill="none" stroke="#475569" strokeWidth="7" strokeLinejoin="round" />
              <path d="M680 255 H750" fill="none" stroke="#1E293B" strokeWidth="8" />
              <text x="310" y="275" fontSize="11" fill="#334155" fontFamily="monospace">50mm uPVC Waste (1:40 Slope)</text>
              <text x="705" y="244" fontSize="10" fill="#0F172A" fontWeight="700">TO GULLY</text>
            </svg>
          </div>
        </div>
      )}

      {activeDiagram === 'riser' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 space-y-4">
          <h3 className="text-base font-bold text-slate-900">
            {lang === 'hi'
              ? 'छत की टंकी, बूस्टर पंप, NRV व मल्टी-फ्लोर राइजर डायग्राम'
              : 'Roof Water Tank, Booster Pump, NRV, PRV & Multi-Floor Riser Diagram'}
          </h3>
          <div className="blueprint-grid rounded-xl p-4 overflow-x-auto border border-slate-200">
            <svg viewBox="0 0 780 370" className="w-full min-w-[580px] h-auto">
              {/* Roof Tank */}
              <rect x="80" y="30" width="190" height="90" rx="8" fill="#DBEAFE" stroke="#1D4ED8" strokeWidth="2.5" />
              <text x="175" y="72" textAnchor="middle" fontSize="12" fill="#1E3A8A" fontWeight="700">ROOF GRP WATER TANK</text>
              <text x="175" y="90" textAnchor="middle" fontSize="10" fill="#1E40AF">Float Valve · Overflow · Vent</text>

              {/* Booster Pump */}
              <rect x="360" y="48" width="130" height="65" rx="8" fill="#FFFFFF" stroke="#1E293B" strokeWidth="2.5" />
              <text x="425" y="78" textAnchor="middle" fontSize="11" fill="#0F172A" fontWeight="700">BOOSTER PUMP</text>
              <text x="425" y="94" textAnchor="middle" fontSize="10" fill="#0284C7" fontFamily="monospace">+ Pressure Vessel</text>

              {/* Pipe from Tank to Pump to Riser */}
              <path d="M270 95 H360 M490 95 H610 V340" fill="none" stroke="#0284C7" strokeWidth="5" />
              <circle cx="315" cy="95" r="7" fill="#1D4ED8" />
              <text x="315" y="118" textAnchor="middle" fontSize="9" fill="#1E3A8A" fontWeight="700">Y-Strainer + Valve</text>
              <circle cx="535" cy="95" r="7" fill="#DC2626" />
              <text x="535" y="118" textAnchor="middle" fontSize="9" fill="#B91C1C" fontWeight="700">NRV + Union</text>

              {/* Floors */}
              {[155, 225, 295].map((y, idx) => (
                <g key={y}>
                  <line x1="80" y1={y + 35} x2="720" y2={y + 35} stroke="#CBD5E1" strokeWidth="1.5" strokeDasharray="4 4" />
                  <path d={`M610 ${y} H470`} fill="none" stroke="#0284C7" strokeWidth="3.5" />
                  {idx === 2 && (
                    <>
                      <polygon points="540,287 554,295 540,303" fill="#059669" />
                      <text x="545" y="280" textAnchor="middle" fontSize="9" fill="#047857" fontWeight="700">PRV (3.5 Bar)</text>
                    </>
                  )}
                  <text x="690" y={y + 4} textAnchor="end" fontSize="11" fill="#334155" fontWeight="700">
                    {idx === 0 ? 'Top Floor (Boosted)' : idx === 1 ? 'Mid Floor' : 'Ground Floor (PRV)'}
                  </text>
                </g>
              ))}
            </svg>
          </div>
        </div>
      )}

      {activeDiagram === 'symbols' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { code: 'GV', name: 'Gate / Isolation Valve', hi: 'गेट वॉल्व (मेन बंद)', desc: 'Bowtie triangle symbol — shuts off main line flow.' },
            { code: 'BV', name: 'Ball Valve (90°)', hi: 'बॉल वॉल्व', desc: 'Bowtie with solid circle — quick quarter-turn shutoff.' },
            { code: 'NRV', name: 'Non-Return (Check) Valve', hi: 'चेक वॉल्व (एकतरफा)', desc: 'Arrow inside line — prevents reverse backflow.' },
            { code: 'PRV', name: 'Pressure Reducing Valve', hi: 'प्रेशर कम करने वाला वॉल्व', desc: 'Valve with spring dome — drops high riser pressure to 3–4 Bar.' },
            { code: 'FD', name: 'Floor Drain / Floor Trap', hi: 'फ्लोर ट्रैप जाली', desc: 'Circle with crosshairs — bathroom floor drain outlet.' },
            { code: 'CO', name: 'Cleanout Plug (Rodding)', hi: 'क्लीनआउट प्लग', desc: 'Square cap symbol — drainage maintenance access point.' },
            { code: 'CW / HW', name: 'Cold / Hot Water Line', hi: 'ठंडा / गर्म पानी लाइन', desc: 'Solid blue line (CW) vs dashed/red line (HW).' },
            { code: 'SP / WP', name: 'Soil Pipe / Waste Pipe', hi: 'सॉइल / वेस्ट ड्रेन', desc: '110mm toilet blackwater (SP) vs 50–75mm greywater (WP).' },
            { code: '1:50 ↘', name: 'Slope / Gradient Arrow', hi: 'ढलान दिशा तीर', desc: 'Shows downward fall direction toward manhole.' },
          ].map((sym) => (
            <div key={sym.code} className="bg-white border border-slate-200 rounded-xl p-4 flex items-start gap-3">
              <div className="w-12 h-12 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center font-mono-num text-xs font-bold text-blue-800 shrink-0">
                {sym.code}
              </div>
              <div className="min-w-0">
                <div className="font-semibold text-sm text-slate-900">{sym.name}</div>
                <div className="text-xs text-blue-700 font-medium">{sym.hi}</div>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">{sym.desc}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="flex items-start gap-2.5 p-3.5 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-900">
        <Info className="w-4 h-4 shrink-0 mt-0.5 text-blue-700" />
        <span>
          {lang === 'hi'
            ? 'साइट नियम: काम शुरू करने से पहले हमेशा अप्रूव्ड IFC ड्रॉइंग रिवीजन चेक करें और हर पाइप पर स्लोप व ऊंचाई FFL से नापें।'
            : 'Site Tip: Always verify the latest Approved IFC Drawing revision and measure every outlet height from the mason’s Finished Floor Level (FFL) mark.'}
        </span>
      </div>
    </div>
  );
};
