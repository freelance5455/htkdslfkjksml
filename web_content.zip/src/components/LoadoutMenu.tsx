import React, { useState } from 'react';
import { CHARACTERS, CharacterDef } from '../game/models/CharacterModels';
import { WEAPON_REGISTRY, WeaponSkin } from '../game/models/WeaponModels';
import { Model3DPreview } from './Model3DPreview';
import { sound } from '../audio/SoundEngine';
import { Users, Crosshair, Check, Shield, Zap, Sparkles, Palette } from 'lucide-react';

interface LoadoutMenuProps {
  activeCharacterId: string;
  onSelectCharacter: (charId: string) => void;
  activePrimaryId: string;
  activeSecondaryId: string;
  onSelectWeapons: (primaryId: string, secondaryId: string) => void;
  onClose: () => void;
  initialTab?: 'operators' | 'armory';
}

export const LoadoutMenu: React.FC<LoadoutMenuProps> = ({
  activeCharacterId,
  onSelectCharacter,
  activePrimaryId,
  activeSecondaryId,
  onSelectWeapons,
  onClose,
  initialTab = 'operators',
}) => {
  const [tab, setTab] = useState<'operators' | 'armory'>(initialTab);
  const [selectedChar, setSelectedChar] = useState<CharacterDef>(
    CHARACTERS.find(c => c.id === activeCharacterId) || CHARACTERS[0]
  );
  const [primaryWeapon, setPrimaryWeapon] = useState<string>(activePrimaryId);
  const [secondaryWeapon, setSecondaryWeapon] = useState<string>(activeSecondaryId);

  // Functional Attachments
  const [optic, setOptic] = useState('holo');
  const [muzzle, setMuzzle] = useState('compensator');
  const [grip, setGrip] = useState('angled');
  const [stock, setStock] = useState('crane');
  const [mag, setMag] = useState('standard');
  const [weaponSkin, setWeaponSkin] = useState<WeaponSkin>('tactical');

  const selectedPrimaryDef = WEAPON_REGISTRY[primaryWeapon] || WEAPON_REGISTRY.rifle;

  // Compute live modified weapon statistics based on attachments
  let modDmg = selectedPrimaryDef.damage;
  let modAcc = 80;
  let modRec = Math.round(100 - selectedPrimaryDef.recoilKick * 1000);
  let modMob = 82;
  let modRng = 75;

  if (optic === 'acog') { modRng += 15; modAcc += 10; modMob -= 8; }
  else if (optic === 'holo') { modAcc += 6; }

  if (muzzle === 'compensator') { modRec += 14; modAcc += 5; }
  else if (muzzle === 'suppressor') { modRec += 5; modDmg -= 2; }
  else if (muzzle === 'fluted') { modDmg += 6; modRng += 10; modMob -= 5; }

  if (grip === 'angled') { modMob += 8; modAcc += 5; }
  else if (grip === 'vertical') { modRec += 10; modAcc += 8; }

  if (stock === 'skeleton') { modMob += 12; modRec -= 6; }
  else if (stock === 'crane') { modRec += 10; modAcc += 6; }

  if (mag === 'extended') { modMob -= 4; }
  else if (mag === 'drum') { modMob -= 12; }

  const handleEquipOperator = () => {
    sound.playUIClick();
    onSelectCharacter(selectedChar.id);
  };

  const handleSaveArmory = () => {
    sound.playUIClick();
    onSelectWeapons(primaryWeapon, secondaryWeapon);
  };

  return (
    <div className="absolute inset-0 z-40 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 select-none">
      <div className="relative w-full max-w-5xl h-[90vh] bg-zinc-950 border border-zinc-800 rounded-2xl flex flex-col overflow-hidden shadow-2xl">
        {/* Header bar */}
        <div className="flex justify-between items-center px-4 sm:px-6 py-3 border-b border-zinc-800 bg-zinc-900/70">
          <div className="flex items-center gap-4">
            <button
              onClick={() => {
                sound.playUIClick();
                onClose();
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700 font-teko text-xl tracking-wider uppercase font-semibold cursor-pointer active:scale-95 transition-all"
            >
              <span className="text-red-500">←</span>
              <span>BACK</span>
            </button>

            <h2 className="text-2xl sm:text-3xl font-teko uppercase text-white font-bold tracking-wider hidden sm:block">
              TACTICAL <span className="text-red-500">LOADOUT HQ</span>
            </h2>

            {/* Tabs */}
            <div className="flex gap-2">
              <button
                onClick={() => {
                  sound.playUIClick();
                  setTab('operators');
                }}
                className={`px-4 py-1.5 rounded-lg font-teko text-xl tracking-wider uppercase transition-all flex items-center gap-2 cursor-pointer ${
                  tab === 'operators'
                    ? 'bg-red-600 text-white shadow-lg shadow-red-600/30'
                    : 'bg-zinc-800 text-zinc-400 hover:text-white'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>OPERATORS</span>
              </button>

              <button
                onClick={() => {
                  sound.playUIClick();
                  setTab('armory');
                }}
                className={`px-4 py-1.5 rounded-lg font-teko text-xl tracking-wider uppercase transition-all flex items-center gap-2 cursor-pointer ${
                  tab === 'armory'
                    ? 'bg-red-600 text-white shadow-lg shadow-red-600/30'
                    : 'bg-zinc-800 text-zinc-400 hover:text-white'
                }`}
              >
                <Crosshair className="w-4 h-4" />
                <span>ARMORY & ATTACHMENTS</span>
              </button>
            </div>
          </div>
        </div>

        {/* --- OPERATORS TAB CONTENT WITH 3D PREVIEW --- */}
        {tab === 'operators' && (
          <div className="flex-1 grid grid-cols-1 md:grid-cols-12 gap-5 p-4 sm:p-6 overflow-y-auto" style={{ WebkitOverflowScrolling: 'touch' }}>
            {/* Operator Cards List (Left) */}
            <div className="md:col-span-5 flex flex-col gap-2.5">
              <span className="text-zinc-500 font-mono-tech text-xs tracking-widest uppercase">
                ACTIVE OPERATORS (4)
              </span>

              {CHARACTERS.map(c => {
                const isSelected = selectedChar.id === c.id;
                const isEquipped = activeCharacterId === c.id;

                return (
                  <div
                    key={c.id}
                    onClick={() => {
                      sound.playUIClick();
                      setSelectedChar(c);
                    }}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'bg-zinc-900 border-red-500 shadow-lg shadow-red-500/20'
                        : 'bg-zinc-900/50 border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-lg flex items-center justify-center font-teko text-2xl font-bold text-white shadow-inner"
                        style={{ backgroundColor: c.color }}
                      >
                        {c.name[0]}
                      </div>
                      <div className="flex flex-col">
                        <span className="text-xl font-teko text-white font-bold tracking-wider leading-none">
                          {c.name}
                        </span>
                        <span className="text-zinc-400 font-mono-tech text-xs">{c.role}</span>
                      </div>
                    </div>

                    {isEquipped && (
                      <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-700 font-mono-tech text-xs font-bold">
                        ACTIVE
                      </span>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Selected Operator 3D Preview & Detail Dossier (Right) */}
            <div className="md:col-span-7 bg-zinc-900/60 rounded-2xl border border-zinc-800 p-5 flex flex-col justify-between">
              <div>
                {/* 3D Character Interactive Preview Canvas */}
                <div className="w-full h-44 sm:h-48 rounded-xl bg-gradient-to-b from-zinc-950 to-zinc-900 border border-zinc-800 relative overflow-hidden mb-4 shadow-inner">
                  <Model3DPreview type="character" id={selectedChar.id} />
                </div>

                <div className="flex items-center justify-between mb-3">
                  <div>
                    <span className="text-red-400 font-mono-tech text-xs tracking-widest uppercase">
                      {selectedChar.role}
                    </span>
                    <h3 className="text-4xl sm:text-5xl font-teko font-extrabold text-white tracking-wide leading-none">
                      {selectedChar.name}
                    </h3>
                  </div>
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center border border-white/20 shadow-lg"
                    style={{ backgroundColor: selectedChar.color }}
                  >
                    <Shield className="w-5 h-5 text-white" />
                  </div>
                </div>

                {/* Perk Box */}
                <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 mb-4">
                  <div className="flex items-center gap-1.5 text-amber-400 font-mono-tech text-xs uppercase mb-0.5 font-bold">
                    <Sparkles className="w-3.5 h-3.5" />
                    SPECIAL PERK: {selectedChar.perk}
                  </div>
                  <p className="text-zinc-300 text-xs font-mono-tech">{selectedChar.perkDesc}</p>
                </div>

                {/* Combat Stats Bars */}
                <div className="flex flex-col gap-2">
                  {[
                    { label: 'SPRINT & MOBILITY', val: selectedChar.stats.speed, icon: Zap },
                    { label: 'HEALTH & VITALITY', val: selectedChar.stats.health, icon: Shield },
                    { label: 'WEAPON HANDLING', val: selectedChar.stats.handling, icon: Crosshair },
                    { label: 'ARMOR PLATING', val: selectedChar.stats.armor, icon: Shield },
                  ].map((s, idx) => (
                    <div key={idx} className="flex flex-col gap-0.5">
                      <div className="flex justify-between font-mono-tech text-[11px] text-zinc-400">
                        <span>{s.label}</span>
                        <span className="text-white font-bold">{s.val}%</span>
                      </div>
                      <div className="h-1.5 bg-zinc-950 rounded-full overflow-hidden p-0.5">
                        <div
                          className="h-full rounded-full transition-all duration-300"
                          style={{ width: `${s.val}%`, backgroundColor: selectedChar.color }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Equip Button */}
              <button
                onClick={handleEquipOperator}
                className="mt-4 w-full py-3 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 text-white font-teko text-2xl tracking-wider uppercase font-bold rounded-xl shadow-xl shadow-red-600/30 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-98"
              >
                <Check className="w-5 h-5" />
                <span>{activeCharacterId === selectedChar.id ? 'OPERATOR ACTIVE' : 'SELECT OPERATOR'}</span>
              </button>
            </div>
          </div>
        )}

        {/* --- ARMORY TAB CONTENT WITH 3D WEAPON PREVIEW & ATTACHMENTS --- */}
        {tab === 'armory' && (
          <div className="flex-1 grid grid-cols-1 md:grid-cols-12 gap-5 p-4 sm:p-6 overflow-y-auto" style={{ WebkitOverflowScrolling: 'touch' }}>
            {/* Primary & Secondary Selector (Left) */}
            <div className="md:col-span-5 flex flex-col gap-3">
              <span className="text-zinc-500 font-mono-tech text-xs tracking-widest uppercase">
                PRIMARY FIREARM
              </span>
              <div className="grid grid-cols-2 gap-2">
                {Object.values(WEAPON_REGISTRY)
                  .filter(w => w.type !== 'pistol')
                  .map(w => (
                    <div
                      key={w.id}
                      onClick={() => {
                        sound.playUIClick();
                        setPrimaryWeapon(w.id);
                      }}
                      className={`p-2.5 rounded-xl border cursor-pointer transition-all ${
                        primaryWeapon === w.id
                          ? 'bg-zinc-900 border-red-500 shadow-lg shadow-red-500/20'
                          : 'bg-zinc-900/40 border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      <span className="text-[10px] font-mono-tech text-red-400 uppercase">{w.type}</span>
                      <h4 className="font-teko text-xl text-white font-bold leading-none">{w.name}</h4>
                      <div className="flex justify-between font-mono-tech text-[9px] text-zinc-400 mt-1.5">
                        <span>DMG: {w.damage}</span>
                        <span>MAG: {w.magSize}</span>
                      </div>
                    </div>
                  ))}
              </div>

              <span className="text-zinc-500 font-mono-tech text-xs tracking-widest uppercase mt-1">
                SECONDARY SIDEARM
              </span>
              <div className="grid grid-cols-2 gap-2">
                {Object.values(WEAPON_REGISTRY).map(w => (
                  <div
                    key={w.id}
                    onClick={() => {
                      sound.playUIClick();
                      setSecondaryWeapon(w.id);
                    }}
                    className={`p-2.5 rounded-xl border cursor-pointer transition-all ${
                      secondaryWeapon === w.id
                        ? 'bg-zinc-900 border-red-500 shadow-lg shadow-red-500/20'
                        : 'bg-zinc-900/40 border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    <span className="text-[10px] font-mono-tech text-cyan-400 uppercase">{w.type}</span>
                    <h4 className="font-teko text-xl text-white font-bold leading-none">{w.name}</h4>
                    <div className="flex justify-between font-mono-tech text-[9px] text-zinc-400 mt-1.5">
                      <span>DMG: {w.damage}</span>
                      <span>ROF: {w.fireRate}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 3D Weapon Preview & Functional Attachments (Right) */}
            <div className="md:col-span-7 bg-zinc-900/60 rounded-2xl border border-zinc-800 p-5 flex flex-col justify-between">
              <div>
                {/* 3D Weapon Model Preview with Live Custom Skin */}
                <div className="w-full h-40 sm:h-44 rounded-xl bg-gradient-to-b from-zinc-950 to-zinc-900 border border-zinc-800 relative overflow-hidden mb-4 shadow-inner">
                  <Model3DPreview type="weapon" id={primaryWeapon} skin={weaponSkin} />
                </div>

                {/* Weapon Skins Picker (Requirement 25) */}
                <div className="mb-3">
                  <div className="flex items-center gap-1.5 text-[10px] font-mono-tech text-amber-400 font-bold mb-1">
                    <Palette className="w-3 h-3" />
                    <span>CUSTOM WEAPON FINISH / CAMO</span>
                  </div>
                  <div className="flex gap-1 overflow-x-auto py-0.5">
                    {[
                      { id: 'tactical', label: 'Tactical (Matte)' },
                      { id: 'urban', label: 'Urban Grey' },
                      { id: 'desert', label: 'Desert Tan' },
                      { id: 'arctic', label: 'Arctic Frost' },
                      { id: 'outbreak', label: 'Outbreak Bio' },
                      { id: 'blackout', label: 'Blackout Gold' },
                      { id: 'industrial', label: 'Industrial Hazard' },
                    ].map(sk => (
                      <button
                        key={sk.id}
                        onClick={() => {
                          sound.playUIClick();
                          setWeaponSkin(sk.id as WeaponSkin);
                        }}
                        className={`px-2.5 py-1 rounded-lg border font-mono-tech text-[10px] whitespace-nowrap cursor-pointer transition-all ${
                          weaponSkin === sk.id
                            ? 'bg-amber-600 border-amber-400 text-white font-bold shadow-md'
                            : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                        }`}
                      >
                        {sk.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Modified Live Stat Bars */}
                <div className="grid grid-cols-3 gap-2 mb-4">
                  <div className="p-2 rounded-lg bg-zinc-950 border border-zinc-800">
                    <span className="font-mono-tech text-[10px] text-zinc-400">DAMAGE</span>
                    <span className="font-teko text-2xl text-red-400 font-bold block leading-none mt-0.5">{modDmg}</span>
                  </div>
                  <div className="p-2 rounded-lg bg-zinc-950 border border-zinc-800">
                    <span className="font-mono-tech text-[10px] text-zinc-400">ACCURACY</span>
                    <span className="font-teko text-2xl text-emerald-400 font-bold block leading-none mt-0.5">{modAcc}%</span>
                  </div>
                  <div className="p-2 rounded-lg bg-zinc-950 border border-zinc-800">
                    <span className="font-mono-tech text-[10px] text-zinc-400">CONTROL</span>
                    <span className="font-teko text-2xl text-cyan-400 font-bold block leading-none mt-0.5">{modRec}%</span>
                  </div>
                </div>

                {/* Attachments Configuration */}
                <div className="flex flex-col gap-2.5">
                  {/* Optic */}
                  <div>
                    <span className="text-[10px] font-mono-tech text-zinc-400 block mb-1">OPTIC ATTACHMENT</span>
                    <div className="grid grid-cols-3 gap-1.5">
                      {[
                        { id: 'iron', label: 'Iron Sights' },
                        { id: 'holo', label: 'Holo Sight (+Acc)' },
                        { id: 'acog', label: 'ACOG 4X (+Rng)' },
                      ].map(o => (
                        <button
                          key={o.id}
                          onClick={() => { sound.playUIClick(); setOptic(o.id); }}
                          className={`py-1.5 px-2 rounded-lg border font-mono-tech text-xs cursor-pointer ${
                            optic === o.id ? 'bg-red-950 border-red-500 text-white' : 'bg-zinc-950 border-zinc-800 text-zinc-400'
                          }`}
                        >
                          {o.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Muzzle */}
                  <div>
                    <span className="text-[10px] font-mono-tech text-zinc-400 block mb-1">BARREL / MUZZLE</span>
                    <div className="grid grid-cols-3 gap-1.5">
                      {[
                        { id: 'compensator', label: 'Compensator (-Recoil)' },
                        { id: 'suppressor', label: 'Suppressor (Stealth)' },
                        { id: 'fluted', label: 'Fluted (+Dmg)' },
                      ].map(b => (
                        <button
                          key={b.id}
                          onClick={() => { sound.playUIClick(); setMuzzle(b.id); }}
                          className={`py-1.5 px-2 rounded-lg border font-mono-tech text-xs cursor-pointer ${
                            muzzle === b.id ? 'bg-red-950 border-red-500 text-white' : 'bg-zinc-950 border-zinc-800 text-zinc-400'
                          }`}
                        >
                          {b.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Magazine Selector */}
                  <div>
                    <span className="text-[10px] font-mono-tech text-zinc-400 block mb-1">MAGAZINE</span>
                    <div className="grid grid-cols-3 gap-1.5">
                      {[
                        { id: 'standard', label: 'Standard' },
                        { id: 'extended', label: 'Extended (+10)' },
                        { id: 'drum', label: 'Drum (+20)' },
                      ].map(m => (
                        <button
                          key={m.id}
                          onClick={() => { sound.playUIClick(); setMag(m.id); }}
                          className={`py-1 px-2 rounded-lg border font-mono-tech text-xs cursor-pointer ${
                            mag === m.id ? 'bg-red-950 border-red-500 text-white' : 'bg-zinc-950 border-zinc-800 text-zinc-400'
                          }`}
                        >
                          {m.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Grip & Stock */}
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-[10px] font-mono-tech text-zinc-400 block mb-1">GRIP</span>
                      <div className="grid grid-cols-2 gap-1">
                        {[
                          { id: 'angled', label: 'Angled (+Mob)' },
                          { id: 'vertical', label: 'Vertical (-Rec)' },
                        ].map(g => (
                          <button
                            key={g.id}
                            onClick={() => { sound.playUIClick(); setGrip(g.id); }}
                            className={`py-1.5 px-2 rounded-lg border font-mono-tech text-xs cursor-pointer ${
                              grip === g.id ? 'bg-red-950 border-red-500 text-white' : 'bg-zinc-950 border-zinc-800 text-zinc-400'
                            }`}
                          >
                            {g.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <span className="text-[10px] font-mono-tech text-zinc-400 block mb-1">STOCK</span>
                      <div className="grid grid-cols-2 gap-1">
                        {[
                          { id: 'crane', label: 'Crane (+Stab)' },
                          { id: 'skeleton', label: 'Skeleton (+Mob)' },
                        ].map(s => (
                          <button
                            key={s.id}
                            onClick={() => { sound.playUIClick(); setStock(s.id); }}
                            className={`py-1.5 px-2 rounded-lg border font-mono-tech text-xs cursor-pointer ${
                              stock === s.id ? 'bg-red-950 border-red-500 text-white' : 'bg-zinc-950 border-zinc-800 text-zinc-400'
                            }`}
                          >
                            {s.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Confirm / Equip Button */}
              <button
                onClick={handleSaveArmory}
                className="mt-4 w-full py-3 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 text-white font-teko text-2xl tracking-wider uppercase font-bold rounded-xl shadow-xl shadow-red-600/30 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-98"
              >
                <Check className="w-5 h-5" />
                <span>EQUIP WEAPONS & ATTACHMENTS</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
