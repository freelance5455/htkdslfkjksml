import React from 'react';
import { SubjectCategory, Topic } from '../types';
import { MasteryBar } from './MasteryBar';
import {
  calculateRetention,
  getDaysUntilReview,
  isDueForReview,
  FORGETTING_INTERVALS,
} from '../utils/spacedRepetition';
import { Clock, Layers, ChevronRight, CheckCircle2, AlertTriangle, Trash2, Calendar } from 'lucide-react';

interface TopicCardProps {
  topic: Topic;
  category?: SubjectCategory;
  onOpenFlashcards: (topic: Topic) => void;
  onStartStudySession: (topic: Topic) => void;
  onDeleteTopic: (topicId: string) => void;
}

export const TopicCard: React.FC<TopicCardProps> = ({
  topic,
  category,
  onOpenFlashcards,
  onStartStudySession,
  onDeleteTopic,
}) => {
  const isDue = isDueForReview(topic.nextReviewDate);
  const daysUntil = getDaysUntilReview(topic.nextReviewDate);
  const retention = calculateRetention(topic.lastReviewedAt, topic.createdAt, topic.stability);

  // Next milestone day target
  const milestoneTargetDay = FORGETTING_INTERVALS[Math.min(topic.stage, FORGETTING_INTERVALS.length - 1)];

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs hover:border-slate-300 dark:hover:border-slate-700 transition-all flex flex-col justify-between space-y-4">
      {/* Top Header: Category and Status */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          {/* Category with color indicator */}
          <div className="flex items-center gap-1.5 min-w-0">
            {category && (
              <span
                className="w-2 h-2 rounded-full shrink-0"
                style={{ backgroundColor: category.color }}
                aria-hidden="true"
              />
            )}
            <span className="font-medium text-slate-700 dark:text-slate-300 truncate">
              {category?.name || 'General'}
            </span>
          </div>

          {/* Due Status Tag */}
          <div className="shrink-0 font-mono text-[11px] font-medium ml-2">
            {isDue ? (
              <span className="flex items-center gap-1 text-rose-600 dark:text-rose-400 font-semibold">
                <AlertTriangle className="w-3.5 h-3.5" />
                {daysUntil === 0 ? 'Due Today' : `Overdue (${Math.abs(daysUntil)}d)`}
              </span>
            ) : daysUntil === 1 ? (
              <span className="text-amber-600 dark:text-amber-400">Due Tomorrow</span>
            ) : (
              <span className="text-slate-500 dark:text-slate-400">Due in {daysUntil}d</span>
            )}
          </div>
        </div>

        {/* Milestone Schedule Target Line */}
        <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400 flex items-center gap-1">
          <span>Target Milestone:</span>
          <strong className="text-indigo-600 dark:text-indigo-400 font-semibold">
            Day {milestoneTargetDay}
          </strong>
        </div>

        {/* Title */}
        <h3 className="text-base font-semibold text-slate-900 dark:text-slate-100 leading-snug pt-1">
          {topic.title}
        </h3>

        {/* Notes preview */}
        {topic.notes && (
          <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 leading-relaxed">
            {topic.notes}
          </p>
        )}
      </div>

      {/* Middle Section: Mastery Bar & Memory Retention */}
      <div className="space-y-3 pt-1">
        <MasteryBar score={topic.masteryScore} currentStage={topic.stage} />

        {/* Retention breakdown row */}
        <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 font-mono pt-1">
          <span>
            Current Retention: <strong className={retention >= 70 ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600 dark:text-amber-400'}>{retention}%</strong>
          </span>
          <span>
            Stability S: <strong>{topic.stability.toFixed(1)}d</strong>
          </span>
          <span>
            Successes: <strong>{topic.consecutiveSuccesses}x</strong>
          </span>
        </div>
      </div>

      {/* Bottom Action Footer */}
      <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2 text-xs">
        {/* Flashcards count & button */}
        <button
          type="button"
          onClick={() => onOpenFlashcards(topic)}
          className="text-xs text-slate-600 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors flex items-center gap-1.5 py-1 px-1 font-medium"
        >
          <Layers className="w-3.5 h-3.5" />
          <span>{topic.flashcards?.length || 0} Flashcards</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onDeleteTopic(topic.id)}
            className="p-1.5 text-slate-400 hover:text-rose-600 rounded-md transition-colors"
            title="Delete Topic"
            aria-label={`Delete ${topic.title}`}
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={() => onStartStudySession(topic)}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 ${
              isDue
                ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200'
            }`}
          >
            <span>{isDue ? 'Review Now' : 'Revise Cards'}</span>
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>
      </div>
    </div>
  );
};
