import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { LayoutList, Map as MapIcon } from "lucide-react";
import { BrowseAreaMap, type AreaCount } from "@/components/area-map";
import { FlyerCard } from "@/components/flyer-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { getRoomContact } from "@/lib/rooms-api";
import {
  downloadTextFile,
  fmtMoney,
  getStoredReferral,
  gmapsHref,
  safeFileName,
  telHref,
  waHref,
  type RoomPublic,
} from "@/lib/rooms-model";
import { errorMessage, isUnauthorized } from "@/lib/utils";

export function BrowseView({
  rooms,
  loading,
  userId,
  signedIn,
}: {
  rooms: RoomPublic[];
  loading: boolean;
  userId: string | null;
  signedIn: boolean;
}) {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [mode, setMode] = useState<"list" | "map">("list");
  const [referral, setReferral] = useState<{ ref: string | null; room: string | null }>({
    ref: null,
    room: null,
  });

  useEffect(() => {
    setReferral(getStoredReferral());
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return rooms;
    return rooms.filter(
      (r) =>
        (r.title || "").toLowerCase().includes(q) ||
        (r.location || "").toLowerCase().includes(q),
    );
  }, [rooms, query]);

  const groups: AreaCount[] = useMemo(() => {
    const map: Record<string, number> = {};
    rooms
      .filter((r) => r.status !== "rented")
      .forEach((r) => {
        const area = (r.location || "Unspecified").trim();
        map[area] = (map[area] || 0) + 1;
      });
    return Object.entries(map).map(([area, count]) => ({ area, count }));
  }, [rooms]);

  const reveal = useMutation({
    mutationFn: async (vars: { roomId: string; kind: "call" | "wa" }) => {
      const stored = getStoredReferral();
      const referrerId =
        stored.ref && stored.room === vars.roomId ? stored.ref : null;
      const contact = await getRoomContact({
        data: { roomId: vars.roomId, referrerId },
      });
      return { ...contact, kind: vars.kind };
    },
    onSuccess: (contact) => {
      if (contact.kind === "call") {
        window.location.href = telHref(contact.phone);
        return;
      }
      if (!contact.whatsapp) {
        toast("This owner did not add a WhatsApp number.");
        return;
      }
      const msg = `Hi, I'm interested in the room: ${contact.title}`;
      window.open(waHref(contact.whatsapp, msg), "_blank", "noopener");
    },
    onError: (err) => {
      if (isUnauthorized(err)) {
        toast("Sign in to view this owner's contact info.");
        void navigate({ to: "/login" });
        return;
      }
      toast(errorMessage(err));
    },
  });

  function requireSignIn(action: string): boolean {
    if (signedIn) return true;
    toast(`Sign in to ${action}.`);
    void navigate({ to: "/login" });
    return false;
  }

  async function shareRoom(room: RoomPublic) {
    if (!requireSignIn("get your personal referral link")) return;
    if (!userId) return;
    const url = `${window.location.origin}${window.location.pathname}?ref=${encodeURIComponent(userId)}&room=${encodeURIComponent(room.id)}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: room.title, url, text: `Room listing: ${room.title}` });
        return;
      }
    } catch (err) {
      if (err instanceof Error && err.name === "AbortError") return;
    }
    try {
      await navigator.clipboard.writeText(url);
      toast("Referral link copied — share it to earn commission.");
    } catch {
      toast(url);
    }
  }

  function downloadFlyer(room: RoomPublic) {
    const lines = [
      room.title,
      room.location + (room.availableFrom ? ` · available from ${room.availableFrom}` : ""),
      `${fmtMoney(room.rent, room.currency)}/month${room.deposit ? ` · deposit ${fmtMoney(room.deposit, room.currency)}` : ""}`,
      "",
      room.description || "",
      "",
      `Map: ${gmapsHref(room.location)}`,
      "",
      "Contact details are private — open this listing in RentDirect and sign in to reveal them.",
    ];
    downloadTextFile(`${safeFileName(room.title)}.txt`, lines.join("\n"));
    toast("Flyer downloaded.");
  }

  return (
    <div>
      {referral.ref ? (
        <div className="mb-4.5 rounded-sm border border-green bg-green-bg px-3.5 py-2.5 text-[13.5px] text-green">
          You're viewing this via a shared link — calling or messaging an owner credits whoever shared it with you.
        </div>
      ) : null}

      <div className="mb-4.5 flex gap-2.5">
        <Input
          id="search-input"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search by title or area…"
          aria-label="Search rooms"
        />
      </div>

      <div className="mb-3.5 flex gap-2">
        <Button
          size="sm"
          variant={mode === "list" ? "brass" : "secondary"}
          onClick={() => setMode("list")}
        >
          <LayoutList className="size-3.5" />
          List
        </Button>
        <Button
          size="sm"
          variant={mode === "map" ? "brass" : "secondary"}
          onClick={() => setMode("map")}
        >
          <MapIcon className="size-3.5" />
          Map
        </Button>
      </div>

      {mode === "map" ? (
        <div className="mb-4.5">
          <p className="mb-3 rounded-sm bg-paper-alt px-3 py-2.5 text-[13px] text-ink-soft">
            Grouped by the area text owners entered — an approximate overview, not a real geographic map. Tap a pin to filter the list.
          </p>
          <BrowseAreaMap
            groups={groups}
            onSelect={(area) => {
              setQuery(area);
              setMode("list");
            }}
          />
        </div>
      ) : null}

      {mode === "list" && loading ? (
        <div className="grid grid-cols-1 gap-4.5 sm:grid-cols-2">
          <Skeleton className="h-64" />
          <Skeleton className="h-64" />
        </div>
      ) : null}

      {mode === "list" && !loading ? (
        filtered.length ? (
          <div className="grid grid-cols-1 gap-4.5 sm:grid-cols-2">
            {filtered.map((room) => (
              <FlyerCard
                key={room.id}
                room={room}
                isOwner={Boolean(userId && room.ownerId === userId)}
                signedIn={signedIn}
                onCall={() => {
                  if (!requireSignIn("view this owner's contact info")) return;
                  reveal.mutate({ roomId: room.id, kind: "call" });
                }}
                onWhatsApp={() => {
                  if (!requireSignIn("view this owner's contact info")) return;
                  reveal.mutate({ roomId: room.id, kind: "wa" });
                }}
                onShare={() => void shareRoom(room)}
                onDownload={() => downloadFlyer(room)}
              />
            ))}
          </div>
        ) : (
          <p className="px-0 py-8 text-center text-sm text-ink-soft">
            {rooms.length
              ? "No rooms match that search."
              : 'No rooms posted yet. Be the first — switch to "List a room".'}
          </p>
        )
      ) : null}
    </div>
  );
}
