/**
 * GODEX v0.0.1 - Technical Activity & Operations Stream
 * Real-time ledger of tool execution, workspace mutations, AST checks, and verification evidence.
 */

import React, { useState } from 'react';
import { 
  Activity, 
  Terminal, 
  FileCode, 
  CheckCircle2, 
  AlertTriangle, 
  Info, 
  Filter, 
  Clock, 
  ShieldCheck,
  ChevronRight,
  ChevronDown,
  Layers
} from 'lucide-react';
import { ActivityLogItem, VerificationReport } from '../types';

interface ActivityLogPanelProps {
  logs: ActivityLogItem[];
  verificationReport: VerificationReport | null;
  onClearLogs?: () => void;
}

export const ActivityLogPanel: React.FC<ActivityLogPanelProps> = ({
  logs,
  verificationReport,
  onClearLogs
}) => {
  const [filterRole, setFilterRole] = useState<string>('all');
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);

  const filteredLogs = logs.filter(log => {
    if (filterRole === 'all') return true;
    return log.role.toLowerCase().includes(filterRole.toLowerCase());
  });

  const getStatusIcon = (status: ActivityLogItem['status']) => {
    switch (status) {
      case 'success':
        return <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />;
      case 'error':
        return <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />;
      case 'warning':
        return <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />;
      default:
        return <Info className="w-3.5 h-3.5 text-cyan-400 shrink-0" />;
    }
  };

  return (
    <div className="h-full flex flex-col bg-[#0A0D14] border-t border-[#1C2230] select-none">
      {/* Activity Header */}
      <div className="h-8 border-b border-[#1C2230] bg-[#0E121A] px-3 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <Activity className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-xs font-mono font-medium text-neutral-200">ACTIVITY & TOOL TELEMETRY</span>
          <span className="px-1.5 py-0.2 rounded bg-[#151C2C] text-[10px] font-mono text-cyan-300">
            {logs.length} events
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Verification Badge */}
          {verificationReport && (
            <div className={`flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-semibold ${
              verificationReport.passed 
                ? 'bg-emerald-950/60 border border-emerald-700/60 text-emerald-300' 
                : 'bg-rose-950/60 border border-rose-700/60 text-rose-300'
            }`}>
              <ShieldCheck className="w-3 h-3" />
              <span>SCORE {verificationReport.score}%</span>
            </div>
          )}

          {/* Filter */}
          <select
            value={filterRole}
            onChange={(e) => setFilterRole(e.target.value)}
            className="bg-[#121824] border border-[#222E46] text-neutral-300 text-[10px] font-mono rounded px-1.5 py-0.5 focus:outline-none"
          >
            <option value="all">All Agents</option>
            <option value="coding">Coding Agent</option>
            <option value="execution">Execution Agent</option>
            <option value="browser">Browser Agent</option>
            <option value="reviewer">Reviewer</option>
          </select>
        </div>
      </div>

      {/* Logs Scrollable Stream */}
      <div className="flex-1 overflow-y-auto p-2 space-y-1.5 font-mono text-xs select-text">
        {filteredLogs.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-4 text-neutral-500 text-xs">
            <Layers className="w-6 h-6 mb-2 text-neutral-600" />
            <span>No technical events recorded yet. Run a prompt to see tool executions.</span>
          </div>
        ) : (
          filteredLogs.map((log, idx) => {
            const isExpanded = expandedLogId === log.id;
            return (
              <div
                key={log.id ? `${log.id}-${idx}` : `act-${idx}`}
                className="p-2 rounded bg-[#0D111A] hover:bg-[#111724] border border-[#182030] transition-colors"
              >
                <div
                  className="flex items-start justify-between cursor-pointer gap-2"
                  onClick={() => setExpandedLogId(isExpanded ? null : log.id)}
                >
                  <div className="flex items-center gap-2 overflow-hidden">
                    {getStatusIcon(log.status)}
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#161F30] text-cyan-300 font-semibold shrink-0">
                      {log.role}
                    </span>
                    <span className="text-neutral-200 text-xs font-medium truncate">{log.action}</span>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 text-neutral-500 text-[10px]">
                    {log.diff && (
                      <span className="text-emerald-400 font-semibold">
                        +{log.diff.additions} / -{log.diff.deletions}
                      </span>
                    )}
                    <span>{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
                    {isExpanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                  </div>
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="mt-2 pt-2 border-t border-[#1C2538] text-[11px] space-y-1 text-neutral-300">
                    {log.details && (
                      <div className="bg-[#080B10] p-2 rounded border border-[#1A2234] whitespace-pre-wrap">
                        {log.details}
                      </div>
                    )}
                    {log.toolCall && (
                      <div className="bg-[#080B10] p-2 rounded border border-[#1A2234]">
                        <div className="text-cyan-400 font-bold mb-1">Tool Call: {log.toolCall.toolName}</div>
                        <div className="text-neutral-400">Args: {JSON.stringify(log.toolCall.args, null, 2)}</div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
