import React, { useState } from "react";
import {
  MapPin,
  Phone,
  Clock,
  Navigation,
  ExternalLink,
  Copy,
  Check,
  MessageCircle,
  Instagram,
  Compass,
} from "lucide-react";
import { RESTAURANT_INFO } from "../data/restaurantInfo";

interface VisitSectionProps {
  onOrderOnline: () => void;
}

export const VisitSection: React.FC<VisitSectionProps> = ({ onOrderOnline }) => {
  const [copiedAddress, setCopiedAddress] = useState(false);

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(RESTAURANT_INFO.address.fullText);
    setCopiedAddress(true);
    setTimeout(() => setCopiedAddress(false), 2500);
  };

  return (
    <section
      id="visit"
      className="py-20 sm:py-28 px-4 sm:px-6 bg-[#FDFBF7] border-b border-[#D8D0C2] relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="max-w-3xl mb-12 sm:mb-16">
          <div className="text-xs font-semibold tracking-[0.25em] uppercase text-[#9BAF82] mb-3 flex items-center gap-2">
            <MapPin className="w-3.5 h-3.5" />
            <span>DASPALLA HILLS · VISAKHAPATNAM</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-5xl lg:text-6xl text-[#17201C] leading-[1.05] tracking-tight mb-4">
            FIND YOUR TABLE
            <br />
            <span className="italic font-light">IN DASPALLA HILLS.</span>
          </h2>
          <p className="text-sm sm:text-base text-[#17201C]/75 font-sans leading-relaxed">
            Quietly nestled in the residential calm of Daspalla Hills, minutes from the shoreline. Drop in for an unhurried morning breakfast, coffee, or a wholesome dinner plate.
          </p>
        </div>

        {/* Realtime Google Map & Location Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-start">
          {/* Left Column: Address, Hours, and Direct Call Actions */}
          <div className="lg:col-span-5 space-y-6">
            {/* Direct Call Highlight Card (One-click direct call) */}
            <div className="p-5 sm:p-6 bg-[#F4F0E7] rounded-sm border border-[#D8D0C2] shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase tracking-widest font-semibold text-[#9BAF82]">
                  Direct Phone Inquiries & Orders
                </span>
                <span className="inline-flex items-center gap-1 text-[10px] text-emerald-700 font-semibold bg-emerald-100/70 px-2 py-0.5 rounded-full">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
                  Lines Open
                </span>
              </div>

              <div>
                <h3 className="font-serif text-2xl text-[#17201C]">
                  Call Kaloreez Kitchen
                </h3>
                <p className="text-xs text-[#17201C]/70 font-sans mt-0.5">
                  Tap the call symbol or phone number below to directly place a call to our host desk.
                </p>
              </div>

              {/* Primary Call Trigger Button: Directly dials phone */}
              <a
                href={`tel:${RESTAURANT_INFO.phone}`}
                className="group flex items-center justify-between p-3.5 rounded-xs bg-[#17201C] text-[#F4F0E7] hover:bg-[#9BAF82] hover:text-[#17201C] transition-all cursor-pointer shadow-sm active:scale-[0.99]"
                title="Tap to place direct call"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-white/15 group-hover:bg-[#17201C]/20 flex items-center justify-center transition-colors">
                    <Phone className="w-4 h-4 text-[#9BAF82] group-hover:text-[#17201C]" />
                  </div>
                  <div>
                    <div className="text-xs uppercase tracking-wider font-medium text-white/70 group-hover:text-[#17201C]/80">
                      Primary Contact
                    </div>
                    <div className="text-sm sm:text-base font-serif font-bold tracking-wide">
                      {RESTAURANT_INFO.phoneDisplay}
                    </div>
                  </div>
                </div>
                <div className="text-[11px] font-sans uppercase tracking-widest px-2.5 py-1 rounded-full bg-white/10 group-hover:bg-[#17201C]/20">
                  Call Now 📞
                </div>
              </a>

              {/* Alternate line if needed */}
              {RESTAURANT_INFO.alternatePhone && (
                <a
                  href={`tel:${RESTAURANT_INFO.alternatePhone}`}
                  className="flex items-center justify-between p-2.5 rounded-xs bg-[#FDFBF7] border border-[#D8D0C2] text-[#17201C] hover:border-[#17201C] transition-all cursor-pointer text-xs font-sans"
                  title="Direct alternate line"
                >
                  <div className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-[#9BAF82]" />
                    <span>Alternate Line: <strong>{RESTAURANT_INFO.alternatePhoneDisplay}</strong></span>
                  </div>
                  <span className="text-[10px] text-[#9BAF82] uppercase tracking-wider font-semibold">
                    Call →
                  </span>
                </a>
              )}
            </div>

            {/* Address & Verified Timings */}
            <div className="p-5 sm:p-6 bg-[#FDFBF7] rounded-sm border border-[#D8D0C2] space-y-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="font-serif text-xl text-[#17201C]">
                    Kaloreez · Daspalla Hills
                  </div>
                  <div className="text-xs font-sans text-[#17201C]/80 leading-relaxed mt-1">
                    {RESTAURANT_INFO.address.line1},<br />
                    {RESTAURANT_INFO.address.line2},<br />
                    {RESTAURANT_INFO.address.city}, {RESTAURANT_INFO.address.state} — {RESTAURANT_INFO.address.pincode}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleCopyAddress}
                  title="Copy full address"
                  className="p-2 rounded-xs border border-[#D8D0C2] text-xs text-[#17201C]/70 hover:text-[#17201C] hover:bg-[#F4F0E7] transition-all shrink-0 flex items-center gap-1.5"
                >
                  {copiedAddress ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-[10px] text-emerald-700 font-medium">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span className="text-[10px]">Copy</span>
                    </>
                  )}
                </button>
              </div>

              {/* Service Timings Breakdown */}
              <div className="pt-3 border-t border-[#D8D0C2]/60 space-y-2 text-xs font-sans text-[#17201C]/80">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-[#9BAF82]" />
                    <span className="font-medium">Dine-in Hours:</span>
                  </div>
                  <span>{RESTAURANT_INFO.hours.dineIn}</span>
                </div>
                <div className="flex items-center justify-between text-[11px] text-[#17201C]/60 pl-5">
                  <span>Breakfast Service:</span>
                  <span>{RESTAURANT_INFO.hours.breakfast}</span>
                </div>
                <div className="flex items-center justify-between text-[11px] text-[#17201C]/60 pl-5">
                  <span>Main Kitchen Hours:</span>
                  <span>{RESTAURANT_INFO.hours.kitchen}</span>
                </div>
              </div>
            </div>

            {/* Verified External Links Grid (Google Maps, WhatsApp, Swiggy, Zomato, Instagram) */}
            <div className="space-y-2">
              <div className="text-[10px] uppercase tracking-widest font-semibold text-[#17201C]/50">
                Platform & Delivery Links
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs font-sans">
                <a
                  href={RESTAURANT_INFO.links.googleMapsDirect}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 rounded-xs bg-[#F4F0E7] border border-[#D8D0C2] hover:border-[#17201C] text-[#17201C] flex items-center justify-between transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <Compass className="w-3.5 h-3.5 text-[#9BAF82]" />
                    <span>Google Maps</span>
                  </div>
                  <ExternalLink className="w-3 h-3 text-[#17201C]/40" />
                </a>

                <a
                  href={RESTAURANT_INFO.links.whatsapp}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 rounded-xs bg-[#F4F0E7] border border-[#D8D0C2] hover:border-[#17201C] text-[#17201C] flex items-center justify-between transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <MessageCircle className="w-3.5 h-3.5 text-[#9BAF82]" />
                    <span>WhatsApp</span>
                  </div>
                  <ExternalLink className="w-3 h-3 text-[#17201C]/40" />
                </a>

                <a
                  href={RESTAURANT_INFO.links.zomato}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 rounded-xs bg-[#F4F0E7] border border-[#D8D0C2] hover:border-[#17201C] text-[#17201C] flex items-center justify-between transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-[#B96D52] font-bold">Z</span>
                    <span>Zomato</span>
                  </div>
                  <ExternalLink className="w-3 h-3 text-[#17201C]/40" />
                </a>

                <a
                  href={RESTAURANT_INFO.links.swiggy}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 rounded-xs bg-[#F4F0E7] border border-[#D8D0C2] hover:border-[#17201C] text-[#17201C] flex items-center justify-between transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-amber-700 font-bold">S</span>
                    <span>Swiggy</span>
                  </div>
                  <ExternalLink className="w-3 h-3 text-[#17201C]/40" />
                </a>

                <a
                  href={RESTAURANT_INFO.links.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 rounded-xs bg-[#F4F0E7] border border-[#D8D0C2] hover:border-[#17201C] text-[#17201C] col-span-2 flex items-center justify-between transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <Instagram className="w-3.5 h-3.5 text-[#B96D52]" />
                    <span>Follow @kaloreez_vizag on Instagram</span>
                  </div>
                  <ExternalLink className="w-3 h-3 text-[#17201C]/40" />
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Real-Time Google Maps Block */}
          <div className="lg:col-span-7 space-y-4">
            <div className="relative bg-[#EAE4D7] rounded-sm overflow-hidden border border-[#D8D0C2] shadow-sm paper-frame">
              {/* Map Header Bar */}
              <div className="bg-[#FDFBF7] px-4 py-3 border-b border-[#D8D0C2] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#9BAF82] animate-ping" />
                  <span className="text-xs font-semibold uppercase tracking-wider text-[#17201C]">
                    Real-time Location & Surroundings
                  </span>
                </div>
                <div className="text-[11px] text-[#17201C]/60 font-mono hidden sm:block">
                  17.7126° N, 83.3228° E
                </div>
              </div>

              {/* Mobile map touch interaction helper */}
              <div className="sm:hidden px-3 py-1.5 bg-[#F4F0E7] text-[10px] text-[#17201C]/70 flex items-center justify-between border-b border-[#D8D0C2]/50">
                <span>💡 Use two fingers to pan map</span>
                <a
                  href={RESTAURANT_INFO.links.googleMapsDirect}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-emerald-800 font-semibold underline"
                >
                  Open in Maps App →
                </a>
              </div>

              {/* Live Interactive Google Map Frame */}
              <div className="relative w-full h-[360px] sm:h-[460px] bg-[#D8D0C2]">
                <iframe
                  title="Kaloreez Google Map Location"
                  src={RESTAURANT_INFO.links.googleMapsEmbed}
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="w-full h-full"
                />

                {/* Floating Map Navigation Badge */}
                <div className="absolute bottom-4 left-4 right-4 sm:right-auto sm:max-w-sm bg-[#FDFBF7]/95 backdrop-blur-md p-3.5 rounded-xs border border-[#D8D0C2] shadow-md flex items-center justify-between gap-3 pointer-events-auto">
                  <div>
                    <div className="font-serif text-sm text-[#17201C] font-semibold">
                      KALOREEZ · Daspalla Hills
                    </div>
                    <div className="text-[11px] text-[#17201C]/70 font-sans">
                      Oota Gadda Rd, Pandurangapuram
                    </div>
                  </div>
                  <a
                    href={RESTAURANT_INFO.links.googleMapsDirect}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#17201C] text-[#F4F0E7] text-[11px] font-medium tracking-wider uppercase hover:bg-[#9BAF82] hover:text-[#17201C] transition-colors shrink-0"
                  >
                    <Navigation className="w-3 h-3" />
                    <span>Directions</span>
                  </a>
                </div>
              </div>

              {/* Map Footer Information */}
              <div className="p-4 bg-[#FDFBF7] border-t border-[#D8D0C2] flex flex-wrap items-center justify-between gap-3 text-xs font-sans text-[#17201C]/70">
                <div className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#9BAF82]" />
                  <span>Ample vehicle parking available on Oota Gadda Road</span>
                </div>
                <div className="flex items-center gap-3">
                  <a
                    href={RESTAURANT_INFO.links.googleMapsDirect}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[11px] text-[#17201C] font-semibold uppercase tracking-wider hover:text-[#9BAF82] flex items-center gap-1 transition-colors"
                  >
                    <span>Open Full Map</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>

            {/* Bottom Direct Action Row: Full width on mobile for effortless touch */}
            <div className="pt-2 grid grid-cols-1 sm:flex sm:flex-wrap items-center gap-2.5 sm:gap-3">
              <a
                href={RESTAURANT_INFO.links.googleMapsDirect}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full bg-[#17201C] text-[#F4F0E7] text-xs font-semibold tracking-widest uppercase hover:bg-[#9BAF82] hover:text-[#17201C] active:scale-98 transition-all shadow-xs"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Navigate on Google Maps</span>
              </a>

              <a
                href={`tel:${RESTAURANT_INFO.phone}`}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full border border-[#17201C] text-[#17201C] text-xs font-semibold tracking-widest uppercase hover:bg-[#17201C] hover:text-[#F4F0E7] active:scale-98 transition-all"
              >
                <Phone className="w-3.5 h-3.5 text-[#9BAF82]" />
                <span>Direct Call ({RESTAURANT_INFO.phoneDisplay})</span>
              </a>

              <button
                type="button"
                onClick={onOrderOnline}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full border border-[#D8D0C2] bg-[#F4F0E7] text-[#17201C] text-xs font-semibold tracking-widest uppercase hover:border-[#17201C] active:scale-98 transition-all cursor-pointer"
              >
                <span>Reserve Table / Pickup</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
