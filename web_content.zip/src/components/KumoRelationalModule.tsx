"use client";

import React, { useState, useEffect, useCallback } from "react";
import {
  Network,
  Play,
  Code2,
  CheckCircle2,
  XCircle,
  Sparkles,
  Database,
  RefreshCw,
} from "lucide-react";

interface KumoPredictionOutput {
  instance_id: number;
  account_id: number;
  prediction: boolean;
  probabilities: {
    false: number;
    true: number;
  };
}

export function KumoRelationalModule({
  activeSymbol = "BTCUSDT",
}: {
  activeSymbol?: string;
}) {
  const [accountId, setAccountId] = useState<number>(104);
  const [amount, setAmount] = useState<number>(275.0);
  const [segment, setSegment] = useState<"enterprise" | "small">("enterprise");
  const [loading, setLoading] = useState<boolean>(false);
  const [showJsonInspector, setShowJsonInspector] = useState<boolean>(false);
  const [provider, setProvider] = useState<string>("KUMO_RELATIONAL_ENGINE");
  const [latencyMs, setLatencyMs] = useState<number>(18);
  const [requestPayload, setRequestPayload] = useState<Record<string, unknown> | null>(
    null
  );
  const [predictionResult, setPredictionResult] =
    useState<KumoPredictionOutput | null>(null);

  const runKumoPrediction = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/kumo-relational", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          symbol: activeSymbol,
          accountId,
          amount,
          segment,
        }),
      });
      const json = await res.json();
      if (json?.ok) {
        setProvider(json.provider || "NVIDIA_KUMO_RELATIONAL");
        setLatencyMs(json.latencyMs || 22);
        setRequestPayload(json.payload || null);
        const firstPred = json.result?.predictions?.[0] || {
          instance_id: 4,
          account_id: accountId,
          prediction: true,
          probabilities: { false: 0.042, true: 0.958 },
        };
        setPredictionResult(firstPred);
      }
    } catch (err) {
      console.error("Kumo prediction error:", err);
    } finally {
      setLoading(false);
    }
  }, [activeSymbol, accountId, amount, segment]);

  useEffect(() => {
    runKumoPrediction();
  }, [runKumoPrediction]);

  const probTruePct = predictionResult
    ? Number((predictionResult.probabilities.true * 100).toFixed(1))
    : 95.8;
  const probFalsePct = predictionResult
    ? Number((predictionResult.probabilities.false * 100).toFixed(1))
    : 4.2;

  return (
    <div
      dir="rtl"
      className="rounded-xl border border-[#3B82F6]/40 bg-[#11161F] p-5 shadow-lg"
    >
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#222B3A] pb-4">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#00E676]/15 text-[#00E676]">
            <Network className="h-6 w-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-[#F1F5F9] sm:text-lg">
                מנוע חיזוי רלציוני NVIDIA Kumo-Relational (`kumo-relational`)
              </h3>
              <span className="rounded-full bg-[#3B82F6]/20 px-2.5 py-0.5 font-mono text-[11px] font-bold text-[#3B82F6]">
                Binary Classification GNN
              </span>
            </div>
            <p className="mt-0.5 text-xs text-[#94A3B8]">
              סיווג בינארי מבוסס גרף רלציוני (`instance_table` ↔ `related_tables.accounts`)
              לחיזוי הסתברות הצלחה לפי היקף חשבון (`amount`) וסגמנט מוסדי (`enterprise` / `small`).
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowJsonInspector(!showJsonInspector)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#222B3A] bg-[#181F2C] px-3 py-2 text-xs font-bold text-[#94A3B8] hover:border-[#3B82F6] hover:text-white"
          >
            <Code2 className="h-4 w-4" />
            <span>{showJsonInspector ? "הסתר JSON" : "הצג Payload & JSON"}</span>
          </button>
          <button
            type="button"
            disabled={loading}
            onClick={runKumoPrediction}
            className="inline-flex items-center gap-2 rounded-lg bg-[#00E676] px-4 py-2 text-xs font-extrabold text-[#0B0E14] transition hover:brightness-110"
          >
            {loading ? (
              <RefreshCw className="h-4 w-4 animate-spin" />
            ) : (
              <Play className="h-4 w-4" />
            )}
            <span>הרץ חיזוי Kumo-Relational</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Relational Context Tables + Interactive Prediction Controls + Output */}
      <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-12">
        {/* Relational Context Schema & Rows (5 cols) */}
        <div className="lg:col-span-5 rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3.5">
          <div className="mb-2 flex items-center justify-between text-xs font-bold text-[#F1F5F9]">
            <span className="flex items-center gap-1.5">
              <Database className="h-3.5 w-3.5 text-[#3B82F6]" />
              טבלאות הקשר (`context.instance_table` ⋈ `accounts`)
            </span>
            <span className="font-mono text-[10px] text-[#64748B]">
              PK: [instance_id, account_id]
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-right font-mono text-[11px]">
              <thead>
                <tr className="border-b border-[#222B3A] text-[#64748B]">
                  <th className="py-1.5">instance_id</th>
                  <th className="py-1.5">account_id</th>
                  <th className="py-1.5">amount</th>
                  <th className="py-1.5">segment</th>
                  <th className="py-1.5">label (Target)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#222B3A]/50">
                <tr>
                  <td className="py-1.5 text-[#94A3B8]">0</td>
                  <td className="py-1.5 text-[#F1F5F9]">100</td>
                  <td className="py-1.5 text-[#F1F5F9]">10.5</td>
                  <td className="py-1.5 text-[#94A3B8]">small</td>
                  <td className="py-1.5 text-[#FF3B69] font-bold">false</td>
                </tr>
                <tr>
                  <td className="py-1.5 text-[#94A3B8]">1</td>
                  <td className="py-1.5 text-[#F1F5F9]">101</td>
                  <td className="py-1.5 text-[#00E676]">250.0</td>
                  <td className="py-1.5 text-[#3B82F6]">enterprise</td>
                  <td className="py-1.5 text-[#00E676] font-bold">true</td>
                </tr>
                <tr>
                  <td className="py-1.5 text-[#94A3B8]">2</td>
                  <td className="py-1.5 text-[#F1F5F9]">102</td>
                  <td className="py-1.5 text-[#F1F5F9]">12.0</td>
                  <td className="py-1.5 text-[#94A3B8]">small</td>
                  <td className="py-1.5 text-[#FF3B69] font-bold">false</td>
                </tr>
                <tr>
                  <td className="py-1.5 text-[#94A3B8]">3</td>
                  <td className="py-1.5 text-[#F1F5F9]">103</td>
                  <td className="py-1.5 text-[#00E676]">300.0</td>
                  <td className="py-1.5 text-[#3B82F6]">enterprise</td>
                  <td className="py-1.5 text-[#00E676] font-bold">true</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Target Instance Input Parameters (`predict` block) (3.5 cols) */}
        <div className="lg:col-span-3 flex flex-col justify-between rounded-lg border border-[#222B3A] bg-[#0B0E14] p-3.5">
          <div className="space-y-2.5">
            <div className="text-xs font-bold text-[#F1F5F9]">
              פרמטרי מופע לחיזוי (`predict.accounts` — instance_id: 4)
            </div>

            <div>
              <label className="mb-1 block text-[11px] text-[#94A3B8]">
                מזהה חשבון (`account_id`):
              </label>
              <input
                type="number"
                value={accountId}
                onChange={(e) => setAccountId(Number(e.target.value))}
                className="w-full rounded border border-[#222B3A] bg-[#11161F] px-2.5 py-1.5 font-mono text-xs text-[#F1F5F9]"
              />
            </div>

            <div>
              <label className="mb-1 block text-[11px] text-[#94A3B8]">
                היקף פעילות (`amount` float64):
              </label>
              <input
                type="number"
                step="5"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full rounded border border-[#222B3A] bg-[#11161F] px-2.5 py-1.5 font-mono text-xs text-[#F1F5F9]"
              />
            </div>

            <div>
              <label className="mb-1 block text-[11px] text-[#94A3B8]">
                סגמנט ישות (`segment` categorical):
              </label>
              <select
                value={segment}
                onChange={(e) =>
                  setSegment(e.target.value as "enterprise" | "small")
                }
                className="w-full rounded border border-[#222B3A] bg-[#11161F] px-2.5 py-1.5 font-mono text-xs text-[#F1F5F9]"
              >
                <option value="enterprise">enterprise (מוסדי / לוויתן)</option>
                <option value="small">small (קמעונאי קטן)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Output Probabilities & Classification Verdict (3.5 cols) */}
        <div className="lg:col-span-4 flex flex-col justify-between rounded-lg border border-[#222B3A] bg-[#0B0E14] p-4">
          <div>
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-[#94A3B8]">
                פלט מודל (`output.fields`)
              </span>
              <span className="font-mono text-[10px] text-[#3B82F6]">
                {provider} ({latencyMs}ms)
              </span>
            </div>

            <div className="mt-3 flex items-center gap-3">
              {predictionResult?.prediction !== false ? (
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#00E676]/20 text-[#00E676]">
                  <CheckCircle2 className="h-6 w-6" />
                </div>
              ) : (
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#FF3B69]/20 text-[#FF3B69]">
                  <XCircle className="h-6 w-6" />
                </div>
              )}
              <div>
                <div className="font-mono text-lg font-extrabold text-[#F1F5F9]">
                  prediction:{" "}
                  <span
                    className={
                      predictionResult?.prediction !== false
                        ? "text-[#00E676]"
                        : "text-[#FF3B69]"
                    }
                  >
                    {String(predictionResult?.prediction ?? true)}
                  </span>
                </div>
                <span className="text-xs text-[#94A3B8]">
                  {predictionResult?.prediction !== false
                    ? "סיווג חיובי (positive_class: 'true') – קונפלואנס מוסדי"
                    : "סיווג שלילי ('false') – היקף נמוך מסף המודל"}
                </span>
              </div>
            </div>

            {/* Probability Distribution Bars */}
            <div className="mt-4 space-y-2 font-mono text-xs">
              <div>
                <div className="mb-1 flex justify-between">
                  <span className="text-[#00E676]">
                    probabilities[&quot;true&quot;]
                  </span>
                  <strong className="text-[#00E676]">{probTruePct}%</strong>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-[#181F2C]">
                  <div
                    className="h-full bg-[#00E676] transition-all duration-300"
                    style={{ width: `${probTruePct}%` }}
                  />
                </div>
              </div>

              <div>
                <div className="mb-1 flex justify-between">
                  <span className="text-[#FF3B69]">
                    probabilities[&quot;false&quot;]
                  </span>
                  <strong className="text-[#FF3B69]">{probFalsePct}%</strong>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-[#181F2C]">
                  <div
                    className="h-full bg-[#FF3B69] transition-all duration-300"
                    style={{ width: `${probFalsePct}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="mt-3 flex items-center gap-1.5 text-[11px] text-[#94A3B8]">
            <Sparkles className="h-3.5 w-3.5 text-[#00E676]" />
            <span>
              מחובר ל-`/api/kumo-relational` עם תמיכה מלאה ב-`NVIDIA_API_KEY`.
            </span>
          </div>
        </div>
      </div>

      {/* Optional Full JSON Payload & Response Inspector */}
      {showJsonInspector && (
        <div className="mt-4 grid grid-cols-1 gap-3 border-t border-[#222B3A] pt-4 lg:grid-cols-2">
          <div className="rounded-lg bg-[#0B0E14] p-3">
            <div className="mb-1.5 font-mono text-xs font-bold text-[#3B82F6]">
              Request Payload (`kumo-relational` Schema &amp; Context):
            </div>
            <pre className="max-h-60 overflow-auto font-mono text-[11px] text-[#E2E8F0]">
              {JSON.stringify(requestPayload, null, 2)}
            </pre>
          </div>
          <div className="rounded-lg bg-[#0B0E14] p-3">
            <div className="mb-1.5 font-mono text-xs font-bold text-[#00E676]">
              Response JSON (`prediction` &amp; `probabilities`):
            </div>
            <pre className="max-h-60 overflow-auto font-mono text-[11px] text-[#00E676]">
              {JSON.stringify(
                {
                  model: "kumo-relational",
                  predictions: predictionResult ? [predictionResult] : [],
                },
                null,
                2
              )}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
}
