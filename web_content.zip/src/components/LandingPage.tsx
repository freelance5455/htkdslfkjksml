import React, { useState, useEffect } from 'react';
import { 
  auth, 
  googleProvider, 
  signInWithPopup, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  syncUserProfile,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  type ConfirmationResult
} from '../firebase';
import { ZahraLogo } from './ZahraLogo';
import { 
  LogIn, 
  UserPlus, 
  Phone, 
  Mail, 
  Lock, 
  User as UserIcon, 
  X, 
  AlertCircle, 
  CheckCircle2, 
  Loader2, 
  Eye, 
  EyeOff, 
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { UserProfile } from '../types';

interface LandingPageProps {
  onAuthSuccess: (profile: UserProfile) => void;
}

type AuthModalType = null | 'login' | 'register' | 'phone';

export const LandingPage: React.FC<LandingPageProps> = ({ onAuthSuccess }) => {
  const [modalType, setModalType] = useState<AuthModalType>(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Email/Password states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Phone states
  const [phoneNumber, setPhoneNumber] = useState('');
  const [countryCode, setCountryCode] = useState('+20'); // Default Egypt, can select Saudi, UAE, etc.
  const [verificationCode, setVerificationCode] = useState('');
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
  const [codeSent, setCodeSent] = useState(false);

  // Reset errors when modal changes
  useEffect(() => {
    setErrorMsg(null);
    setSuccessMsg(null);
    setLoading(false);
  }, [modalType]);

  // Handle Google Sign In
  const handleGoogleSignIn = async () => {
    try {
      setLoading(true);
      setErrorMsg(null);
      const cred = await signInWithPopup(auth, googleProvider);
      const profile = await syncUserProfile(cred.user, {
        displayName: cred.user.displayName || 'عضو زهرة شات',
        photoURL: cred.user.photoURL || undefined
      });
      onAuthSuccess(profile);
    } catch (err: any) {
      console.error('Google Sign-in error:', err);
      if (err.code === 'auth/popup-closed-by-user') {
        setErrorMsg('تم إلغاء تسجيل الدخول بواسطة المستخدم');
      } else if (err.code === 'auth/network-request-failed') {
        setErrorMsg('تعذر الاتصال بالشبكة، يرجى المحاولة لاحقاً');
      } else {
        setErrorMsg(err.message || 'فشل تسجيل الدخول باستخدام Google');
      }
    } finally {
      setLoading(false);
    }
  };

  // Handle Email Login
  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setErrorMsg('يرجى ملء جميع الحقول المطلوبة');
      return;
    }
    try {
      setLoading(true);
      setErrorMsg(null);
      const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
      const profile = await syncUserProfile(cred.user);
      onAuthSuccess(profile);
    } catch (err: any) {
      console.error('Login error:', err);
      if (err.code === 'auth/user-not-found' || err.code === 'auth/invalid-credential' || err.code === 'auth/wrong-password') {
        setErrorMsg('البريد الإلكتروني أو كلمة المرور غير صحيحة');
      } else if (err.code === 'auth/invalid-email') {
        setErrorMsg('صيغة البريد الإلكتروني غير صالحة');
      } else {
        setErrorMsg(err.message || 'حدث خطأ أثناء تسجيل الدخول');
      }
    } finally {
      setLoading(false);
    }
  };

  // Handle New Account Registration
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password || !displayName) {
      setErrorMsg('يرجى إدخال الاسم، البريد الإلكتروني، وكلمة المرور');
      return;
    }
    if (password.length < 6) {
      setErrorMsg('يجب أن تكون كلمة المرور من 6 أحرف أو أرقام على الأقل');
      return;
    }
    try {
      setLoading(true);
      setErrorMsg(null);
      const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
      const profile = await syncUserProfile(cred.user, {
        displayName: displayName.trim(),
        username: email.split('@')[0].replace(/[^a-zA-Z0-9_]/g, '') || `zahra_${Date.now()}`
      });
      setSuccessMsg('تم إنشاء الحساب بنجاح! جاري الدخول...');
      setTimeout(() => {
        onAuthSuccess(profile);
      }, 700);
    } catch (err: any) {
      console.error('Registration error:', err);
      if (err.code === 'auth/email-already-in-use') {
        setErrorMsg('هذا البريد الإلكتروني مستخدم بالفعل');
      } else if (err.code === 'auth/weak-password') {
        setErrorMsg('كلمة المرور ضعيفة جداً');
      } else {
        setErrorMsg(err.message || 'تعذر إنشاء الحساب');
      }
    } finally {
      setLoading(false);
    }
  };

  // Setup phone reCAPTCHA & send verification code
  const handleSendPhoneCode = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanNumber = phoneNumber.replace(/[\s-]/g, '');
    if (!cleanNumber || cleanNumber.length < 7) {
      setErrorMsg('يرجى إدخال رقم هاتف صحيح');
      return;
    }

    const fullPhoneNumber = `${countryCode}${cleanNumber}`;
    try {
      setLoading(true);
      setErrorMsg(null);

      // Create or get existing invisible recaptcha
      let recaptchaVerifier = (window as any).recaptchaVerifier;
      if (!recaptchaVerifier) {
        recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
          size: 'invisible',
          callback: () => {
            // reCAPTCHA solved
          }
        });
        (window as any).recaptchaVerifier = recaptchaVerifier;
      }

      const confirmation = await signInWithPhoneNumber(auth, fullPhoneNumber, recaptchaVerifier);
      setConfirmationResult(confirmation);
      setCodeSent(true);
      setSuccessMsg(`تم إرسال رمز التحقق إلى ${fullPhoneNumber}`);
    } catch (err: any) {
      console.error('Phone sign-in error:', err);
      if (err.code === 'auth/invalid-phone-number') {
        setErrorMsg('رقم الهاتف غير صالح، تأكد من الرمز ورقم الهاتف');
      } else {
        setErrorMsg(err.message || 'تعذر إرسال رمز التحقق لرقم الهاتف');
      }
    } finally {
      setLoading(false);
    }
  };

  // Verify SMS confirmation code
  const handleVerifyPhoneCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!verificationCode || !confirmationResult) {
      setErrorMsg('يرجى إدخال رمز التحقق المكون من 6 أرقام');
      return;
    }

    try {
      setLoading(true);
      setErrorMsg(null);
      const cred = await confirmationResult.confirm(verificationCode.trim());
      const profile = await syncUserProfile(cred.user, {
        displayName: displayName || `مستخدم ${countryCode}${phoneNumber.slice(-4)}`,
        phone: `${countryCode}${phoneNumber}`
      });
      setSuccessMsg('تم التحقق بنجاح! جاري تحويلك...');
      setTimeout(() => {
        onAuthSuccess(profile);
      }, 700);
    } catch (err: any) {
      console.error('Code verification error:', err);
      setErrorMsg('رمز التحقق غير صحيح أو منتهي الصلاحية');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-white flex flex-col items-center justify-center px-4 py-8 select-none">
      
      {/* Invisible container for phone reCAPTCHA */}
      <div id="recaptcha-container"></div>

      {/* Background Ambient Styling - Elegant Floral Cosmic Gradient */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Soft Radial Gradients */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] sm:w-[750px] h-[600px] sm:h-[750px] bg-gradient-to-tr from-rose-950/40 via-fuchsia-950/30 to-amber-950/20 rounded-full blur-3xl opacity-75" />
        <div className="absolute -top-32 -right-32 w-96 h-96 bg-rose-600/15 rounded-full blur-3xl" />
        <div className="absolute -bottom-32 -left-32 w-96 h-96 bg-fuchsia-700/15 rounded-full blur-3xl" />
        
        {/* Subtle decorative blossom dots */}
        <div className="absolute top-1/4 left-1/5 w-1.5 h-1.5 rounded-full bg-rose-400/30 animate-pulse" />
        <div className="absolute top-1/3 right-1/4 w-2 h-2 rounded-full bg-amber-300/30 animate-pulse delay-700" />
        <div className="absolute bottom-1/4 right-1/5 w-1.5 h-1.5 rounded-full bg-fuchsia-400/30 animate-pulse delay-1000" />
        <div className="absolute bottom-1/3 left-1/4 w-2 h-2 rounded-full bg-rose-300/20 animate-pulse delay-500" />
      </div>

      {/* Main Container: Centered Large Circular Icon & Buttons directly beneath */}
      <div className="relative z-10 w-full max-w-sm flex flex-col items-center">
        
        {/* Large Circular Zahra Chat Icon */}
        <div className="mb-6 transform hover:scale-105 transition-transform duration-300">
          <ZahraLogo size="xl" showText={true} pulse={true} />
        </div>

        {/* Action Buttons Directly Under the Icon */}
        <div className="w-full flex flex-col gap-3 mt-4">
          
          {/* 1. Google Sign-In Button */}
          <button
            onClick={handleGoogleSignIn}
            disabled={loading}
            className="w-full flex items-center justify-center gap-3 py-3.5 px-5 rounded-2xl bg-white hover:bg-slate-100 text-slate-900 font-bold shadow-lg shadow-black/25 hover:shadow-xl active:scale-[0.98] transition-all duration-200 border border-slate-200 cursor-pointer disabled:opacity-60"
          >
            {loading ? (
              <Loader2 className="w-5 h-5 animate-spin text-slate-700" />
            ) : (
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
            )}
            <span className="text-sm font-semibold tracking-wide">تسجيل الدخول باستخدام Google</span>
          </button>

          {/* 2. Login Button (تسجيل الدخول) */}
          <button
            onClick={() => setModalType('login')}
            disabled={loading}
            className="w-full flex items-center justify-center gap-3 py-3.5 px-5 rounded-2xl bg-gradient-to-r from-rose-600 via-rose-500 to-fuchsia-600 hover:from-rose-500 hover:to-fuchsia-500 text-white font-bold shadow-lg shadow-rose-900/40 hover:shadow-rose-900/60 active:scale-[0.98] transition-all duration-200 border border-rose-400/20 cursor-pointer disabled:opacity-60"
          >
            <LogIn className="w-5 h-5 text-rose-600" />
            <span className="text-sm font-semibold tracking-wide">تسجيل الدخول</span>
          </button>

          {/* 3. Create Account Button (إنشاء حساب جديد) */}
          <button
            onClick={() => setModalType('register')}
            disabled={loading}
            className="w-full flex items-center justify-center gap-3 py-3.5 px-5 rounded-2xl bg-slate-50/80 hover:bg-slate-100/90 text-rose-600 hover:text-slate-900 font-bold shadow-md shadow-black/30 active:scale-[0.98] transition-all duration-200 border border-slate-200 hover:border-rose-500/40 cursor-pointer disabled:opacity-60"
          >
            <UserPlus className="w-5 h-5 text-rose-500" />
            <span className="text-sm font-semibold tracking-wide">إنشاء حساب جديد</span>
          </button>

          {/* 4. Phone Sign-In Button (التسجيل برقم الهاتف) */}
          <button
            onClick={() => {
              setCodeSent(false);
              setVerificationCode('');
              setModalType('phone');
            }}
            disabled={loading}
            className="w-full flex items-center justify-center gap-3 py-3.5 px-5 rounded-2xl bg-slate-50/60 hover:bg-slate-100/80 text-slate-600 hover:text-slate-900 font-semibold shadow-sm active:scale-[0.98] transition-all duration-200 border border-slate-200 hover:border-slate-200 cursor-pointer disabled:opacity-60"
          >
            <Phone className="w-4 h-4 text-emerald-600" />
            <span className="text-sm tracking-wide">التسجيل برقم الهاتف</span>
          </button>

        </div>

        {/* Subtle Guarantee info */}
        <div className="mt-8 flex items-center gap-2 text-xs text-slate-500">
          <ShieldCheck className="w-4 h-4 text-emerald-500/80" />
          <span>منصة عربية آمنة وموثوقة • تسجيل دخول حقيقي</span>
        </div>

      </div>

      {/* MODAL 1: Email / Password Login */}
      {modalType === 'login' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-sm rounded-3xl bg-slate-50 border border-rose-500/20 p-6 shadow-2xl shadow-rose-950/50">
            
            <button
              onClick={() => setModalType(null)}
              className="absolute top-4 left-4 p-2 text-slate-500 hover:text-slate-900 rounded-full bg-slate-100/60 hover:bg-slate-100 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="text-center mb-6">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center mb-3">
                <LogIn className="w-6 h-6 text-rose-500" />
              </div>
              <h3 className="text-xl font-bold text-slate-900">تسجيل الدخول</h3>
              <p className="text-xs text-slate-500 mt-1">أهلاً بك مجدداً في زهرة شات</p>
            </div>

            {errorMsg && (
              <div className="mb-4 p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center gap-2 text-rose-600 text-xs">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleEmailLogin} className="flex flex-col gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5 text-right">
                  البريد الإلكتروني
                </label>
                <div className="relative">
                  <Mail className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    type="email"
                    required
                    dir="ltr"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full bg-white border border-slate-200 focus:border-rose-500 rounded-xl pr-10 pl-3 py-2.5 text-sm text-slate-900 placeholder-slate-600 focus:outline-none transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5 text-right">
                  كلمة المرور
                </label>
                <div className="relative">
                  <Lock className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    dir="ltr"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-white border border-slate-200 focus:border-rose-500 rounded-xl pr-10 pl-10 py-2.5 text-sm text-slate-900 placeholder-slate-600 focus:outline-none transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-800"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="mt-2 w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-rose-600 to-fuchsia-600 hover:from-rose-500 hover:to-fuchsia-500 text-white font-bold text-sm shadow-lg shadow-rose-950/40 active:scale-95 transition-all disabled:opacity-50 cursor-pointer"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'دخول إلى حسابي'}
              </button>
            </form>

            <div className="mt-5 text-center text-xs text-slate-500">
              ليس لديك حساب؟{' '}
              <button
                onClick={() => setModalType('register')}
                className="text-rose-500 hover:underline font-semibold"
              >
                إنشاء حساب جديد
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: Create New Account */}
      {modalType === 'register' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-sm rounded-3xl bg-slate-50 border border-rose-500/20 p-6 shadow-2xl shadow-rose-950/50 max-h-[90vh] overflow-y-auto">
            
            <button
              onClick={() => setModalType(null)}
              className="absolute top-4 left-4 p-2 text-slate-500 hover:text-slate-900 rounded-full bg-slate-100/60 hover:bg-slate-100 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="text-center mb-6">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-fuchsia-500/10 border border-fuchsia-500/20 flex items-center justify-center mb-3">
                <UserPlus className="w-6 h-6 text-fuchsia-500" />
              </div>
              <h3 className="text-xl font-bold text-slate-900">إنشاء حساب جديد</h3>
              <p className="text-xs text-slate-500 mt-1">انضم إلى مجتمع زهرة شات الراقي</p>
            </div>

            {errorMsg && (
              <div className="mb-4 p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center gap-2 text-rose-600 text-xs">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="mb-4 p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center gap-2 text-emerald-600 text-xs">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{successMsg}</span>
              </div>
            )}

            <form onSubmit={handleRegister} className="flex flex-col gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5 text-right">
                  الاسم المستعار / الاسم الظاهر
                </label>
                <div className="relative">
                  <UserIcon className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    type="text"
                    required
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="مثال: أمير القلوب 🌸"
                    className="w-full bg-white border border-slate-200 focus:border-rose-500 rounded-xl pr-10 pl-3 py-2.5 text-sm text-slate-900 placeholder-slate-600 focus:outline-none transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5 text-right">
                  البريد الإلكتروني
                </label>
                <div className="relative">
                  <Mail className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    type="email"
                    required
                    dir="ltr"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full bg-white border border-slate-200 focus:border-rose-500 rounded-xl pr-10 pl-3 py-2.5 text-sm text-slate-900 placeholder-slate-600 focus:outline-none transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1.5 text-right">
                  كلمة المرور
                </label>
                <div className="relative">
                  <Lock className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    dir="ltr"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="6 أحرف على الأقل"
                    className="w-full bg-white border border-slate-200 focus:border-rose-500 rounded-xl pr-10 pl-10 py-2.5 text-sm text-slate-900 placeholder-slate-600 focus:outline-none transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-800"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-700 leading-relaxed">
                🌸 ستحصل فور تسجيلك على هدية ترحيبية <strong>100 زهرة</strong> مجاناً لاستخدامها في الغرف وإرسال الهدايا!
              </div>

              <button
                type="submit"
                disabled={loading}
                className="mt-2 w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-fuchsia-600 to-rose-600 hover:from-fuchsia-500 hover:to-rose-500 text-white font-bold text-sm shadow-lg shadow-fuchsia-950/40 active:scale-95 transition-all disabled:opacity-50 cursor-pointer"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'إنشاء الحساب فوراً'}
              </button>
            </form>

            <div className="mt-5 text-center text-xs text-slate-500">
              لديك حساب بالفعل؟{' '}
              <button
                onClick={() => setModalType('login')}
                className="text-rose-500 hover:underline font-semibold"
              >
                تسجيل الدخول
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: Phone Sign-In Flow */}
      {modalType === 'phone' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-sm rounded-3xl bg-slate-50 border border-rose-500/20 p-6 shadow-2xl shadow-rose-950/50">
            
            <button
              onClick={() => setModalType(null)}
              className="absolute top-4 left-4 p-2 text-slate-500 hover:text-slate-900 rounded-full bg-slate-100/60 hover:bg-slate-100 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="text-center mb-6">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center mb-3">
                <Phone className="w-6 h-6 text-emerald-600" />
              </div>
              <h3 className="text-xl font-bold text-slate-900">التسجيل برقم الهاتف</h3>
              <p className="text-xs text-slate-500 mt-1">
                {codeSent ? 'أدخل رمز التحقق المرسل لهاتفك' : 'سيتلقى هاتفك رسالة نصية لتأكيد الهوية'}
              </p>
            </div>

            {errorMsg && (
              <div className="mb-4 p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center gap-2 text-rose-600 text-xs">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="mb-4 p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center gap-2 text-emerald-600 text-xs">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{successMsg}</span>
              </div>
            )}

            {!codeSent ? (
              <form onSubmit={handleSendPhoneCode} className="flex flex-col gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1.5 text-right">
                    الاسم المستعار (اختياري)
                  </label>
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="اسمك في زهرة شات"
                    className="w-full bg-white border border-slate-200 focus:border-rose-500 rounded-xl px-3 py-2.5 text-sm text-slate-900 placeholder-slate-600 focus:outline-none transition-colors mb-3"
                  />

                  <label className="block text-xs font-medium text-slate-600 mb-1.5 text-right">
                    رقم الهاتف
                  </label>
                  <div className="flex gap-2" dir="ltr">
                    <select
                      value={countryCode}
                      onChange={(e) => setCountryCode(e.target.value)}
                      className="bg-white border border-slate-200 focus:border-rose-500 rounded-xl px-2.5 py-2.5 text-xs text-slate-900 focus:outline-none"
                    >
                      <option value="+20">🇪🇬 +20 (مصر)</option>
                      <option value="+966">🇸🇦 +966 (السعودية)</option>
                      <option value="+971">🇦🇪 +971 (الإمارات)</option>
                      <option value="+965">🇰🇼 +965 (الكويت)</option>
                      <option value="+974">🇶🇦 +974 (قطر)</option>
                      <option value="+962">🇯🇴 +962 (الأردن)</option>
                      <option value="+964">🇮🇶 +964 (العراق)</option>
                      <option value="+212">🇲🇦 +212 (المغرب)</option>
                      <option value="+213">🇩🇿 +213 (الجزائر)</option>
                      <option value="+1">🇺🇸 +1 (USA)</option>
                    </select>

                    <input
                      type="tel"
                      required
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      placeholder="1012345678"
                      className="flex-1 bg-white border border-slate-200 focus:border-rose-500 rounded-xl px-3 py-2.5 text-sm text-slate-900 placeholder-slate-600 focus:outline-none tracking-wider"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="mt-2 w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm shadow-lg shadow-emerald-950/40 active:scale-95 transition-all disabled:opacity-50 cursor-pointer"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'إرسال رمز التأكيد SMS'}
                </button>
              </form>
            ) : (
              <form onSubmit={handleVerifyPhoneCode} className="flex flex-col gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1.5 text-center">
                    رمز التحقق (6 أرقام)
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    required
                    dir="ltr"
                    value={verificationCode}
                    onChange={(e) => setVerificationCode(e.target.value)}
                    placeholder="123456"
                    className="w-full bg-white border border-slate-200 focus:border-emerald-500 rounded-xl py-3 text-center text-xl font-mono text-emerald-600 placeholder-slate-700 tracking-widest focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm shadow-lg shadow-emerald-950/40 active:scale-95 transition-all disabled:opacity-50 cursor-pointer"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'تأكيد الرمز والدخول'}
                </button>

                <button
                  type="button"
                  onClick={() => setCodeSent(false)}
                  className="text-xs text-slate-500 hover:text-slate-900 text-center mt-1"
                >
                  تغيير رقم الهاتف
                </button>
              </form>
            )}

          </div>
        </div>
      )}

    </div>
  );
};
