import React, { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  AlertCircle,
  Banknote,
  Check,
  Clock,
  Copy,
  History,
  Landmark,
  MessageCircle,
  Plus,
  Send,
  Smartphone,
  X,
} from 'lucide-react';
import { Client, Payment, PaymentMode, StudioSettings } from '../types';
import {
  buildWhatsAppReminderMessage,
  buildWhatsAppUrl,
  formatDateShort,
  formatDateTimeShort,
  formatINR,
  getClientPending,
  getDaysPending,
} from '../utils/formatters';

interface PaymentsViewProps {
  clients: Client[];
  payments: Payment[];
  settings: StudioSettings;
  onAddPaymentClick: () => void;
  onLogReminderSent: (clientId: string, amount: number, message: string) => void;
  onToast: (msg: string) => void;
}

export const PaymentsView: React.FC<PaymentsViewProps> = ({
  clients,
  payments,
  settings,
  onAddPaymentClick,
  onLogReminderSent,
  onToast,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'reminders'>('all');
  const [reminderClient, setReminderClient] = useState<Client | null>(null);
  const [customMessage, setCustomMessage] = useState('');
  const [copied, setCopied] = useState(false);

  const clientMap = useMemo(() => {
    const m = new Map<string, Client>();
    clients.forEach((c) => m.set(c.id, c));
    return m;
  }, [clients]);

  const sortedPayments = useMemo(
    () => [...payments].sort((a, b) => b.date.localeCompare(a.date)),
    [payments]
  );

  const pendingClients = useMemo(
    () =>
      clients
        .filter((c) => getClientPending(c) > 0)
        .sort((a, b) => getDaysPending(b.pendingSince) - getDaysPending(a.pendingSince)),
    [clients]
  );

  const totalReceived = useMemo(
    () => payments.reduce((sum, p) => sum + p.amount, 0),
    [payments]
  );

  const totalPending = useMemo(
    () => pendingClients.reduce((sum, c) => sum + getClientPending(c), 0),
    [pendingClients]
  );

  const openReminderGenerator = (client: Client) => {
    setReminderClient(client);
    setCustomMessage(buildWhatsAppReminderMessage(client, settings));
    setCopied(false);
  };

  const getModeIcon = (mode: PaymentMode) => {
    if (mode === 'UPI') return <Smartphone className="w-4 h-4 text-[#0F172A]" strokeWidth={1.75} />;
    if (mode === 'Bank') return <Landmark className="w-4 h-4 text-[#0F172A]" strokeWidth={1.75} />;
    return <Banknote className="w-4 h-4 text-[#0F172A]" strokeWidth={1.75} />;
  };

  const handleCopyMessage = async () => {
    try {
      await navigator.clipboard.writeText(customMessage);
      setCopied(true);
      onToast('Reminder message copied');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      onToast('Select and copy the message manually');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-0.5">
          <h1 className="font-display text-2xl font-bold text-[#0F172A]">
            Payments &amp; Reminders
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 tabular-nums">
            Collected {formatINR(totalReceived)} · Pending {formatINR(totalPending)}
          </p>
        </div>

        <button
          type="button"
          onClick={onAddPaymentClick}
          className="btn-primary h-11 px-4 text-sm font-semibold inline-flex items-center gap-2 whitespace-nowrap cursor-pointer"
        >
          <Plus className="w-4 h-4" strokeWidth={1.75} />
          <span>Add Payment</span>
        </button>
      </div>

      {/* Segmented Tabs (12px outer, 4px padding -> 8px inner) */}
      <div className="flex sm:inline-flex w-full sm:w-auto p-1 rounded-[12px] border border-slate-200 bg-white gap-1">
        <button
          type="button"
          onClick={() => setActiveTab('all')}
          className={`flex-1 sm:flex-none px-4 py-2 rounded-[8px] text-xs font-semibold whitespace-nowrap transition-colors duration-150 ease-out cursor-pointer ${
            activeTab === 'all'
              ? 'bg-[#0F172A] text-white'
              : 'text-slate-600 hover:text-[#0F172A] hover:bg-slate-50'
          }`}
        >
          All Payments ({payments.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('reminders')}
          className={`flex-1 sm:flex-none px-4 py-2 rounded-[8px] text-xs font-semibold whitespace-nowrap transition-colors duration-150 ease-out cursor-pointer ${
            activeTab === 'reminders'
              ? 'bg-[#0F172A] text-white'
              : 'text-slate-600 hover:text-[#0F172A] hover:bg-slate-50'
          }`}
        >
          Pending Reminders ({pendingClients.length})
        </button>
      </div>

      {/* Single Surface Lists */}
      {activeTab === 'all' ? (
        <section className="surface-card overflow-hidden">
          {sortedPayments.length === 0 ? (
            <div className="p-10 text-center space-y-3">
              <p className="text-sm text-slate-500">No payments logged yet.</p>
              <button
                type="button"
                onClick={onAddPaymentClick}
                className="btn-primary px-4 py-2.5 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" strokeWidth={1.75} />
                <span>Record First Payment</span>
              </button>
            </div>
          ) : (
            <div className="divide-y divide-slate-200">
              {sortedPayments.map((payment) => {
                const client = clientMap.get(payment.clientId);
                return (
                  <div
                    key={payment.id}
                    className="px-5 py-4 flex items-center justify-between gap-4"
                  >
                    <div className="flex items-center gap-3.5 min-w-0">
                      <div className="w-10 h-10 rounded-[8px] border border-slate-200 bg-slate-50 flex items-center justify-center shrink-0">
                        {getModeIcon(payment.mode)}
                      </div>
                      <div className="min-w-0 space-y-0.5">
                        <h2 className="font-display text-sm sm:text-base font-bold text-[#0F172A] truncate">
                          {client?.name ?? 'Client'}
                        </h2>
                        <p className="text-xs text-slate-500 truncate">
                          {formatDateShort(payment.date)} · {payment.mode}
                          {payment.invoiceNumber ? ` · ${payment.invoiceNumber}` : ''}
                          {payment.note ? ` · ${payment.note}` : ''}
                        </p>
                      </div>
                    </div>

                    <div className="text-right shrink-0 space-y-0.5">
                      <p className="font-display text-base font-bold text-emerald-700 tabular-nums">
                        +{formatINR(payment.amount)}
                      </p>
                      <p className="text-[11px] text-slate-500">Received</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      ) : (
        <section className="surface-card overflow-hidden">
          {pendingClients.length === 0 ? (
            <div className="p-10 text-center space-y-1">
              <p className="font-display text-base font-bold text-[#0F172A]">All Clear</p>
              <p className="text-sm text-slate-500">Zero pending balances across clients.</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-200">
              {pendingClients.map((client) => {
                const pending = getClientPending(client);
                const daysPending = getDaysPending(client.pendingSince);
                const isOverdue = daysPending > 3;
                const lastReminder = client.reminderHistory[0];

                return (
                  <div
                    key={client.id}
                    className={`p-5 sm:p-6 space-y-4 ${isOverdue ? 'bg-red-50/40' : ''}`}
                  >
                    <div className="flex flex-wrap items-start justify-between gap-4">
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-center gap-2">
                          {isOverdue ? (
                            <AlertCircle className="w-4 h-4 text-red-600 shrink-0" strokeWidth={1.75} />
                          ) : (
                            <Clock className="w-4 h-4 text-amber-600 shrink-0" strokeWidth={1.75} />
                          )}
                          <span
                            className={`px-2 py-0.5 rounded-[6px] border text-[11px] font-semibold ${
                              isOverdue
                                ? 'bg-red-50 text-red-700 border-red-200'
                                : 'bg-amber-50 text-amber-700 border-amber-200'
                            }`}
                          >
                            {isOverdue ? `Overdue ${daysPending}d` : `Due ${daysPending}d`}
                          </span>
                        </div>
                        <h2 className="font-display text-base sm:text-lg font-bold text-[#0F172A] truncate">
                          {client.name}
                        </h2>
                        <p className="text-xs text-slate-500">
                          {client.projectTitle} · {client.city}
                        </p>
                      </div>

                      <div className="text-right shrink-0 space-y-0.5">
                        <p className="text-xs text-slate-500">Balance Due</p>
                        <p className="font-display text-xl font-bold text-red-600 tabular-nums">
                          {formatINR(pending)}
                        </p>
                      </div>
                    </div>

                    {/* Reminder History separated by 1px border (no nested card) */}
                    <div className="pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-2 text-xs text-slate-500">
                        <History className="w-4 h-4 shrink-0" strokeWidth={1.75} />
                        {lastReminder ? (
                          <span>
                            Last reminded {formatDateTimeShort(lastReminder.sentAt)} (
                            {formatINR(lastReminder.amountReminded)})
                          </span>
                        ) : (
                          <span>No reminder sent yet</span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => openReminderGenerator(client)}
                          className="btn-primary h-9 px-3.5 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                        >
                          <Send className="w-4 h-4" strokeWidth={1.75} />
                          <span>Send Reminder</span>
                        </button>
                        <button
                          type="button"
                          onClick={onAddPaymentClick}
                          className="btn-secondary h-9 px-3.5 text-xs font-semibold cursor-pointer"
                        >
                          Record Paid
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      )}

      {/* WhatsApp Reminder Modal */}
      <AnimatePresence>
        {reminderClient && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.16, ease: 'easeOut' }}
            className="fixed inset-0 z-50 bg-slate-900/40 flex items-end sm:items-center justify-center p-0 sm:p-4"
            onClick={() => setReminderClient(null)}
          >
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 20, opacity: 0 }}
              transition={{ duration: 0.18, ease: 'easeOut' }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-lg surface-card rounded-t-[16px] sm:rounded-[16px] p-6 space-y-4 shadow-xl"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-0.5">
                  <h2 className="font-display text-lg font-bold text-[#0F172A]">
                    WhatsApp Payment Reminder
                  </h2>
                  <p className="text-xs text-slate-500">
                    {reminderClient.name} · Due {formatINR(getClientPending(reminderClient))}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setReminderClient(null)}
                  className="w-8 h-8 rounded-[8px] border border-slate-200 hover:bg-slate-50 flex items-center justify-center text-slate-600 cursor-pointer"
                >
                  <X className="w-4 h-4" strokeWidth={1.75} />
                </button>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-slate-600">
                  Message Preview
                </label>
                <textarea
                  rows={4}
                  value={customMessage}
                  onChange={(e) => setCustomMessage(e.target.value)}
                  className="w-full p-3 text-sm field-input leading-relaxed"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={handleCopyMessage}
                  className="btn-secondary h-10 text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {copied ? (
                    <Check className="w-4 h-4 text-emerald-700" strokeWidth={1.75} />
                  ) : (
                    <Copy className="w-4 h-4" strokeWidth={1.75} />
                  )}
                  <span>{copied ? 'Copied' : 'Copy Message'}</span>
                </button>

                <a
                  href={buildWhatsAppUrl(reminderClient.phone, customMessage)}
                  target="_blank"
                  rel="noreferrer"
                  onClick={() => {
                    onLogReminderSent(
                      reminderClient.id,
                      getClientPending(reminderClient),
                      customMessage
                    );
                  }}
                  className="btn-primary h-10 text-xs font-semibold inline-flex items-center justify-center gap-1.5"
                >
                  <MessageCircle className="w-4 h-4" strokeWidth={1.75} />
                  <span>Open WhatsApp</span>
                </a>
              </div>

              <button
                type="button"
                onClick={() => {
                  onLogReminderSent(
                    reminderClient.id,
                    getClientPending(reminderClient),
                    customMessage
                  );
                  setReminderClient(null);
                }}
                className="w-full h-9 rounded-[8px] text-xs font-medium text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
              >
                Log Reminder Sent &amp; Close
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
