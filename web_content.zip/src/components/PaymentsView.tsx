import React, { useState } from 'react';
import { 
  CreditCard, 
  Search, 
  Filter, 
  Printer, 
  Share2, 
  Wallet, 
  QrCode, 
  Plus, 
  CheckCircle2, 
  Calendar,
  User,
  ArrowDownLeft,
  FileSpreadsheet
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Payment, Customer, Bill, Language, BusinessProfile, PaymentMethod } from '../types';
import { translations } from '../translations';
import { receiptService } from '../services/receiptService';

import { WhatsAppDispatchPayload } from './WhatsAppDispatchModal';

interface PaymentsViewProps {
  payments: Payment[];
  customers: Customer[];
  bills: Bill[];
  activeMonth: string;
  language: Language;
  profile: BusinessProfile;
  onRecordPayment: (params: {
    customerId: string;
    billId?: string;
    amount: number;
    paymentMethod: PaymentMethod;
    upiRefNo?: string;
    billingMonth: string;
    collectedBy: string;
    notes?: string;
    paymentDate?: string;
  }) => void;
  onViewReceipt: (payment: Payment) => void;
  onExportExcel: () => void;
  onOpenWhatsAppModal: (payload: WhatsAppDispatchPayload) => void;
  quickCollectTargetCustomer?: Customer | null;
  quickCollectTargetBill?: Bill | null;
  isCollectModalOpen: boolean;
  setIsCollectModalOpen: (open: boolean) => void;
}

export const PaymentsView: React.FC<PaymentsViewProps> = ({
  payments,
  customers,
  bills,
  activeMonth,
  language,
  profile,
  onRecordPayment,
  onViewReceipt,
  onExportExcel,
  onOpenWhatsAppModal,
  quickCollectTargetCustomer,
  quickCollectTargetBill,
  isCollectModalOpen,
  setIsCollectModalOpen,
}) => {
  const t = translations[language];

  const [searchQuery, setSearchQuery] = useState('');
  const [methodFilter, setMethodFilter] = useState<string>('ALL'); // ALL, CASH, UPI

  // Payment form state
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>(quickCollectTargetCustomer?.id || '');
  const [selectedBillId, setSelectedBillId] = useState<string>(quickCollectTargetBill?.id || '');
  const [amount, setAmount] = useState<number>(quickCollectTargetCustomer?.totalOutstanding || 500);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('UPI');
  const [upiRefNo, setUpiRefNo] = useState<string>('');
  const [paymentDate, setPaymentDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [collectedBy, setCollectedBy] = useState<string>(profile.ownerName || 'Sanjay Panda');
  const [notes, setNotes] = useState<string>('');

  // Update form when target customer changes
  React.useEffect(() => {
    if (quickCollectTargetCustomer) {
      setSelectedCustomerId(quickCollectTargetCustomer.id);
      setAmount(quickCollectTargetCustomer.totalOutstanding || quickCollectTargetCustomer.monthlyAmount);
    }
    if (quickCollectTargetBill) {
      setSelectedBillId(quickCollectTargetBill.id);
      setAmount(quickCollectTargetBill.balanceDue);
    }
  }, [quickCollectTargetCustomer, quickCollectTargetBill]);

  const selectedCustomer = customers.find(c => c.id === selectedCustomerId);
  const customerBills = bills.filter(b => b.customerId === selectedCustomerId && b.status !== 'PAID');

  const filteredPayments = payments.filter(p => {
    const q = searchQuery.toLowerCase().trim();
    const matchQuery = 
      !q ||
      p.receiptNo.toLowerCase().includes(q) ||
      p.customerName.toLowerCase().includes(q) ||
      p.customerCode.toLowerCase().includes(q) ||
      p.mobile.includes(q) ||
      (p.upiRefNo && p.upiRefNo.toLowerCase().includes(q));

    const matchMethod = methodFilter === 'ALL' || p.paymentMethod === methodFilter;

    return matchQuery && matchMethod;
  });

  // KPI Calculations
  const totalCollectedAll = payments.reduce((acc, p) => acc + (p.amount || 0), 0);
  const cashTotal = payments.filter(p => p.paymentMethod === 'CASH').reduce((acc, p) => acc + (p.amount || 0), 0);
  const upiTotal = payments.filter(p => p.paymentMethod === 'UPI').reduce((acc, p) => acc + (p.amount || 0), 0);

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomerId || amount <= 0) return;

    onRecordPayment({
      customerId: selectedCustomerId,
      billId: selectedBillId || undefined,
      amount: Number(amount),
      paymentMethod,
      upiRefNo: paymentMethod === 'UPI' ? upiRefNo : undefined,
      billingMonth: activeMonth,
      collectedBy,
      notes,
      paymentDate,
    });

    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
      });
    } catch {
      // Ignore if confetti fails
    }

    setIsCollectModalOpen(false);
    // Reset fields
    setNotes('');
    setUpiRefNo('');
  };

  return (
    <div className="space-y-6">
      
      {/* Top Header & Collect Action */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <CreditCard className="w-6 h-6 text-emerald-400" />
            <span>{t.payments}</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800">
              {payments.length} Transactions
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Cash &amp; UPI collections register with instant receipt printing and digital reconciliation.
          </p>
        </div>

        {/* Buttons */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={onExportExcel}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold shadow-sm transition"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>Export Register (Excel)</span>
          </button>

          <button
            onClick={() => setIsCollectModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-bold text-xs sm:text-sm shadow-md shadow-emerald-950/40 transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>{t.recordPayment}</span>
          </button>
        </div>
      </div>

      {/* Summary Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
            Total Collections
          </span>
          <span className="text-2xl font-black text-emerald-400 font-mono-num mt-1 block">
            {receiptService.formatCurrency(totalCollectedAll)}
          </span>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Overall all-time collections
          </span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block flex items-center gap-1.5">
            <Wallet className="w-3.5 h-3.5 text-emerald-400" />
            <span>{t.cashCollection}</span>
          </span>
          <span className="text-2xl font-black text-slate-200 font-mono-num mt-1 block">
            {receiptService.formatCurrency(cashTotal)}
          </span>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {payments.filter(p => p.paymentMethod === 'CASH').length} Cash receipts
          </span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block flex items-center gap-1.5">
            <QrCode className="w-3.5 h-3.5 text-cyan-400" />
            <span>{t.upiCollection}</span>
          </span>
          <span className="text-2xl font-black text-cyan-300 font-mono-num mt-1 block">
            {receiptService.formatCurrency(upiTotal)}
          </span>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {payments.filter(p => p.paymentMethod === 'UPI').length} UPI receipts
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-md flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search receipt no, customer, UTR..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-800/80 border border-slate-700 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <div className="flex items-center gap-1.5 self-start sm:self-auto">
          <button
            onClick={() => setMethodFilter('ALL')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              methodFilter === 'ALL' ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            All Methods
          </button>
          <button
            onClick={() => setMethodFilter('CASH')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              methodFilter === 'CASH' ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            Cash Only
          </button>
          <button
            onClick={() => setMethodFilter('UPI')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              methodFilter === 'UPI' ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            UPI Only
          </button>
        </div>
      </div>

      {/* Payments Table */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 shadow-xl overflow-hidden">
        {filteredPayments.length === 0 ? (
          <div className="py-16 text-center text-slate-400">
            <CreditCard className="w-12 h-12 mx-auto text-slate-600 mb-3" />
            <p className="text-sm font-semibold">No payment records found.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-850/80 border-b border-slate-800 text-slate-400">
                <tr>
                  <th className="py-3.5 px-4 font-bold">{t.receiptNumber}</th>
                  <th className="py-3.5 px-4 font-bold">{t.paymentDate}</th>
                  <th className="py-3.5 px-4 font-bold">{t.customerName}</th>
                  <th className="py-3.5 px-4 font-bold">{t.paymentMode}</th>
                  <th className="py-3.5 px-4 font-bold">{t.collectedBy}</th>
                  <th className="py-3.5 px-4 font-bold text-right">{t.paidAmount}</th>
                  <th className="py-3.5 px-4 font-bold text-right">{t.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredPayments.map((p) => {
                  const cust = customers.find(c => c.id === p.customerId);
                  return (
                    <tr key={p.id} className="hover:bg-slate-850/50 transition">
                      <td className="py-3.5 px-4 font-mono text-cyan-300 font-semibold">
                        {p.receiptNo}
                      </td>
                      <td className="py-3.5 px-4 text-slate-300">
                        {receiptService.formatDate(p.paymentDate)}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="font-bold text-slate-100 block">{p.customerName}</span>
                        <span className="text-[11px] font-mono text-slate-400">{p.customerCode} • {cust?.area}</span>
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold ${
                          p.paymentMethod === 'UPI'
                            ? 'bg-cyan-950 text-cyan-400 border border-cyan-800'
                            : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        }`}>
                          {p.paymentMethod}
                        </span>
                        {p.upiRefNo && (
                          <span className="block text-[10px] text-slate-400 font-mono mt-0.5 line-clamp-1">
                            {p.upiRefNo}
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-slate-300">
                        {p.collectedBy}
                      </td>
                      <td className="py-3.5 px-4 text-right font-extrabold text-sm text-emerald-400 font-mono-num">
                        {receiptService.formatCurrency(p.amount)}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => onViewReceipt(p)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition"
                            title={t.printReceipt}
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                          {cust && (
                            <button
                              onClick={() => onOpenWhatsAppModal({
                                mode: 'RECEIPT',
                                customer: cust,
                                payment: p,
                              })}
                              className="p-1.5 rounded-lg bg-emerald-950 hover:bg-emerald-900 text-emerald-400 border border-emerald-800 transition"
                              title="Send WhatsApp Receipt"
                            >
                              <Share2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Record Payment Modal */}
      {isCollectModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
          <div className="w-full max-w-xl rounded-2xl bg-slate-900 border border-slate-700 p-6 shadow-2xl space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-emerald-400" />
                <span>{t.recordPayment}</span>
              </h3>
              <button
                onClick={() => setIsCollectModalOpen(false)}
                className="text-slate-400 hover:text-white text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-4">
              
              {/* Select Customer */}
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Select Customer *
                </label>
                <select
                  required
                  value={selectedCustomerId}
                  onChange={(e) => {
                    const cid = e.target.value;
                    setSelectedCustomerId(cid);
                    const cust = customers.find(c => c.id === cid);
                    if (cust) {
                      setAmount(cust.totalOutstanding > 0 ? cust.totalOutstanding : cust.monthlyAmount);
                    }
                  }}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white"
                >
                  <option value="">-- Choose Customer --</option>
                  {customers.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.customerCode}) - Due: {receiptService.formatCurrency(c.totalOutstanding)} - {c.area}
                    </option>
                  ))}
                </select>
              </div>

              {/* Customer Highlights if Selected */}
              {selectedCustomer && (
                <div className="p-3 rounded-xl bg-slate-850 border border-slate-800 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-slate-200 block">{selectedCustomer.name}</span>
                    <span className="text-slate-400">{selectedCustomer.serviceType} • {selectedCustomer.planName}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">Current Balance</span>
                    <span className={`font-mono-num font-black text-sm ${selectedCustomer.totalOutstanding > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                      {receiptService.formatCurrency(selectedCustomer.totalOutstanding)}
                    </span>
                  </div>
                </div>
              )}

              {/* Amount to collect */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Amount Received (₹) *
                  </label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={amount || ''}
                    onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm font-bold font-mono text-emerald-400"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Payment Date
                  </label>
                  <input
                    type="date"
                    required
                    value={paymentDate}
                    onChange={(e) => setPaymentDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white font-mono"
                  />
                </div>
              </div>

              {/* Payment Method Switch */}
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                  Payment Mode *
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('UPI')}
                    className={`p-3 rounded-xl border flex items-center justify-center gap-2 font-bold text-xs transition ${
                      paymentMethod === 'UPI'
                        ? 'bg-cyan-600/20 border-cyan-500 text-cyan-300 shadow-sm'
                        : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
                    }`}
                  >
                    <QrCode className="w-4 h-4" />
                    <span>UPI (GPay / PhonePe)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('CASH')}
                    className={`p-3 rounded-xl border flex items-center justify-center gap-2 font-bold text-xs transition ${
                      paymentMethod === 'CASH'
                        ? 'bg-emerald-600/20 border-emerald-500 text-emerald-300 shadow-sm'
                        : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Wallet className="w-4 h-4" />
                    <span>Cash Payment</span>
                  </button>
                </div>
              </div>

              {/* If UPI, show QR code and UTR entry */}
              {paymentMethod === 'UPI' && (
                <div className="p-3.5 rounded-xl bg-slate-850 border border-cyan-900/60 space-y-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={receiptService.getUpiQrCodeUrl(profile.upiId, profile.name, amount, 'BILL')}
                      alt="UPI QR"
                      className="w-20 h-20 rounded-lg border border-slate-700 bg-white p-1"
                    />
                    <div>
                      <span className="text-xs font-bold text-white block">
                        Customer can scan QR to pay {receiptService.formatCurrency(amount)}
                      </span>
                      <span className="text-[11px] text-cyan-400 font-mono block mt-0.5">
                        UPI: {profile.upiId}
                      </span>
                      <span className="text-[10px] text-slate-400 block mt-1">
                        Works with PhonePe, Google Pay, Paytm, BHIM, Mobikwik
                      </span>
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">
                      UPI Reference / UTR Number (Optional)
                    </label>
                    <input
                      type="text"
                      value={upiRefNo}
                      onChange={(e) => setUpiRefNo(e.target.value)}
                      placeholder="e.g. 430198273641 or PhonePe Txn ID"
                      className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white font-mono"
                    />
                  </div>
                </div>
              )}

              {/* Collector & Notes */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Collected By
                  </label>
                  <input
                    type="text"
                    value={collectedBy}
                    onChange={(e) => setCollectedBy(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Remarks / Notes
                  </label>
                  <input
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Field visit notes..."
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
                  />
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCollectModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-950/40"
                >
                  Generate Receipt &amp; Save
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
