import React, { useState, useEffect, useRef } from 'react';
import { 
  Timer, 
  Play, 
  Pause, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  Vibrate, 
  Settings, 
  Sparkles, 
  Check, 
  X, 
  Clock, 
  Zap, 
  Heart, 
  ChevronDown, 
  ChevronUp,
  Sliders,
  Hourglass
} from 'lucide-react';
import { playGentleBell, playPacingTick, triggerVibration } from '../utils/audioFeedback';

export type PacingTimerMode = 'repetition' | 'session' | 'stopwatch';

interface DhikrPacingTimerProps {
  dhikrText: string;
  dhikrCount: number;
  currentCount: number;
  isNightReadingActive: boolean;
  onAutoIncrement?: () => void;
  onNotify?: (message: string) => void;
  onPaceCompleted?: () => void;
  onClose?: () => void;
}

export const DhikrPacingTimer: React.FC<DhikrPacingTimerProps> = ({
  dhikrText,
  dhikrCount,
  currentCount,
  isNightReadingActive,
  onAutoIncrement,
  onNotify,
  onPaceCompleted,
  onClose,
}) => {
  // Estimate optimal pacing based on word count (roughly 0.35 - 0.4 seconds per word, minimum 4s)
  const wordCount = (dhikrText || '').trim().split(/\s+/).length;
  const suggestedPaceSeconds = Math.max(4, Math.min(60, Math.round(wordCount * 0.45)));

  // State
  const [mode, setMode] = useState<PacingTimerMode>('repetition');
  const [repIntervalSec, setRepIntervalSec] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('hisn_timer_rep_pace');
      if (saved) return parseInt(saved, 10);
    } catch {}
    return suggestedPaceSeconds;
  });

  // Session duration in seconds (default 2 minutes = 120s)
  const [sessionDurationSec, setSessionDurationSec] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('hisn_timer_session_dur');
      if (saved) return parseInt(saved, 10);
    } catch {}
    return 120;
  });

  const [isRunning, setIsRunning] = useState<boolean>(true);
  const [repElapsedSec, setRepElapsedSec] = useState<number>(0);
  const [sessionRemainingSec, setSessionRemainingSec] = useState<number>(120);
  const [stopwatchElapsedSec, setStopwatchElapsedSec] = useState<number>(0);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [vibrationEnabled, setVibrationEnabled] = useState<boolean>(true);
  const [autoAdvanceRep, setAutoAdvanceRep] = useState<boolean>(false);
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);
  const [repCompletedNotice, setRepCompletedNotice] = useState<boolean>(false);
  const [isMinimized, setIsMinimized] = useState<boolean>(false);

  // Sync session remaining with session duration changes
  useEffect(() => {
    setSessionRemainingSec(sessionDurationSec);
  }, [sessionDurationSec]);

  // Keep track of current repetition changes from outside (e.g., user tapped the tasbeeh counter)
  const prevCountRef = useRef(currentCount);
  useEffect(() => {
    if (prevCountRef.current !== currentCount) {
      prevCountRef.current = currentCount;
      if (mode === 'repetition') {
        // Reset the per-repetition elapsed time smoothly
        setRepElapsedSec(0);
        setRepCompletedNotice(false);
      }
    }
  }, [currentCount, mode]);

  // Main Timer Interval
  useEffect(() => {
    if (!isRunning) return;

    const interval = setInterval(() => {
      if (mode === 'repetition') {
        setRepElapsedSec((prev) => {
          const next = prev + 0.1;
          if (next >= repIntervalSec) {
            // Repetition interval completed!
            if (!repCompletedNotice) {
              setRepCompletedNotice(true);
              if (soundEnabled) playPacingTick(true);
              if (vibrationEnabled) triggerVibration(true, 'light');
              if (onPaceCompleted) onPaceCompleted();

              if (autoAdvanceRep && onAutoIncrement) {
                onAutoIncrement();
                return 0;
              }
            }
            return repIntervalSec;
          }
          return next;
        });
      } else if (mode === 'session') {
        setSessionRemainingSec((prev) => {
          if (prev <= 0.1) {
            setIsRunning(false);
            if (soundEnabled) playGentleBell(true);
            if (vibrationEnabled) triggerVibration(true, 'complete');
            if (onNotify) {
              onNotify('✨ هنيئاً لك! أتممت وقت جلسة التدبر والتمهل بنجاح');
            }
            return 0;
          }
          return Math.max(0, prev - 0.1);
        });
      } else if (mode === 'stopwatch') {
        setStopwatchElapsedSec((prev) => prev + 0.1);
      }
    }, 100);

    return () => clearInterval(interval);
  }, [
    isRunning, 
    mode, 
    repIntervalSec, 
    soundEnabled, 
    vibrationEnabled, 
    autoAdvanceRep, 
    onAutoIncrement, 
    onPaceCompleted, 
    onNotify, 
    repCompletedNotice
  ]);

  // Format MM:SS
  const formatTime = (totalSeconds: number): string => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = Math.floor(totalSeconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleToggleRunning = () => {
    triggerVibration(vibrationEnabled, 'light');
    setIsRunning(!isRunning);
  };

  const handleReset = () => {
    triggerVibration(vibrationEnabled, 'undo');
    if (mode === 'repetition') {
      setRepElapsedSec(0);
      setRepCompletedNotice(false);
    } else if (mode === 'session') {
      setSessionRemainingSec(sessionDurationSec);
      setIsRunning(true);
    } else if (mode === 'stopwatch') {
      setStopwatchElapsedSec(0);
    }
  };

  const repProgress = Math.min(100, Math.round((repElapsedSec / repIntervalSec) * 100));
  const sessionProgress = sessionDurationSec > 0 
    ? Math.min(100, Math.round(((sessionDurationSec - sessionRemainingSec) / sessionDurationSec) * 100))
    : 0;

  // Repetition remaining seconds
  const repSecondsRemaining = Math.max(0, Math.ceil(repIntervalSec - repElapsedSec));

  return (
    <div className={`w-full rounded-2xl border transition-all duration-200 overflow-hidden shadow-sm ${
      isNightReadingActive
        ? 'bg-[#150e09]/95 border-amber-800/40 text-amber-100'
        : 'bg-[#f4faf6]/95 dark:bg-[#031d14]/95 border-emerald-600/25 dark:border-emerald-700/60 text-emerald-950 dark:text-emerald-100'
    }`}>
      {/* Header bar of Pacing Timer */}
      <div className={`px-3 py-2 flex items-center justify-between border-b ${
        isNightReadingActive ? 'border-amber-900/40 bg-amber-950/30' : 'border-emerald-800/15 bg-emerald-900/10'
      }`}>
        <div className="flex items-center gap-2">
          <div className={`p-1.5 rounded-lg flex items-center justify-center ${
            isNightReadingActive ? 'bg-amber-500/20 text-amber-300' : 'bg-emerald-600/20 text-emerald-700 dark:text-emerald-300'
          }`}>
            <Hourglass className={`w-4 h-4 ${isRunning ? 'animate-spin' : ''}`} style={{ animationDuration: '4s' }} />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold font-cairo">مؤقت التمهل والتدبّر</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-md font-tajawal font-medium ${
                isNightReadingActive ? 'bg-amber-400/15 text-amber-300' : 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
              }`}>
                {mode === 'repetition' ? 'إيقاع التسبيحة' : mode === 'session' ? 'وقت الجلسة' : 'عداد التدبر'}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1">
          {/* Audio toggle */}
          <button
            onClick={() => {
              setSoundEnabled(!soundEnabled);
              triggerVibration(vibrationEnabled, 'light');
            }}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              soundEnabled
                ? isNightReadingActive ? 'text-amber-300 bg-amber-950/50' : 'text-emerald-700 dark:text-emerald-300 bg-emerald-900/15'
                : 'text-gray-400 hover:text-gray-600'
            }`}
            title={soundEnabled ? 'كتم تنبيه التمهل' : 'تفعيل رنين التمهل'}
            aria-label="تنبيه الصوت"
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
          </button>

          {/* Settings modal button */}
          <button
            onClick={() => setShowSettingsModal(true)}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              isNightReadingActive ? 'text-amber-300 hover:bg-amber-900/40' : 'text-emerald-700 dark:text-emerald-300 hover:bg-emerald-800/20'
            }`}
            title="خيارات وضبط مؤقت التمهل"
            aria-label="خيارات المؤقت"
          >
            <Sliders className="w-3.5 h-3.5" />
          </button>

          {/* Minimize toggle */}
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              isNightReadingActive ? 'text-amber-400 hover:bg-amber-900/40' : 'text-emerald-700 dark:text-emerald-300 hover:bg-emerald-800/20'
            }`}
            title={isMinimized ? 'توسيع المؤقت' : 'تصغير المؤقت'}
            aria-label="تصغير المؤقت"
          >
            {isMinimized ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
          </button>

          {/* Close button */}
          {onClose && (
            <button
              onClick={onClose}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer text-gray-400 hover:text-gray-600 hover:bg-black/10`}
              title="إخفاء مؤقت التمهل"
              aria-label="إغلاق المؤقت"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Body */}
      {!isMinimized && (
        <div className="p-3 space-y-2.5">
          {/* Mode Switcher Tabs */}
          <div className="flex items-center justify-between gap-1 p-0.5 rounded-xl border bg-black/10 border-black/5 dark:border-white/5">
            <button
              onClick={() => {
                setMode('repetition');
                setIsRunning(true);
                setRepElapsedSec(0);
                triggerVibration(vibrationEnabled, 'light');
              }}
              className={`flex-1 py-1 px-2 rounded-lg text-xs font-bold font-cairo transition-all cursor-pointer text-center ${
                mode === 'repetition'
                  ? isNightReadingActive
                    ? 'bg-amber-500 text-black shadow-xs'
                    : 'bg-emerald-700 dark:bg-emerald-600 text-white shadow-xs'
                  : 'text-gray-600 dark:text-gray-400 hover:text-black dark:hover:text-white'
              }`}
            >
              تمهل التسبيحة ({repIntervalSec}ث)
            </button>
            <button
              onClick={() => {
                setMode('session');
                setIsRunning(true);
                setSessionRemainingSec(sessionDurationSec);
                triggerVibration(vibrationEnabled, 'light');
              }}
              className={`flex-1 py-1 px-2 rounded-lg text-xs font-bold font-cairo transition-all cursor-pointer text-center ${
                mode === 'session'
                  ? isNightReadingActive
                    ? 'bg-amber-500 text-black shadow-xs'
                    : 'bg-emerald-700 dark:bg-emerald-600 text-white shadow-xs'
                  : 'text-gray-600 dark:text-gray-400 hover:text-black dark:hover:text-white'
              }`}
            >
              مؤقت الجلسة ({Math.floor(sessionDurationSec / 60)}د)
            </button>
            <button
              onClick={() => {
                setMode('stopwatch');
                setIsRunning(true);
                triggerVibration(vibrationEnabled, 'light');
              }}
              className={`flex-1 py-1 px-2 rounded-lg text-xs font-bold font-cairo transition-all cursor-pointer text-center ${
                mode === 'stopwatch'
                  ? isNightReadingActive
                    ? 'bg-amber-500 text-black shadow-xs'
                    : 'bg-emerald-700 dark:bg-emerald-600 text-white shadow-xs'
                  : 'text-gray-600 dark:text-gray-400 hover:text-black dark:hover:text-white'
              }`}
            >
              ساعة التأمل
            </button>
          </div>

          {/* Display & Progress depending on Mode */}
          {mode === 'repetition' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-tajawal">
                <div className="flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${repProgress >= 100 ? 'bg-emerald-500 animate-ping' : isRunning ? 'bg-amber-400 animate-pulse' : 'bg-gray-400'}`} />
                  <span className="font-bold">
                    {repProgress >= 100 ? (
                      <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                        <Check className="w-3 h-3 stroke-[3]" />
                        <span>أحسنت! أتممت تمهل هذه التسبيحة</span>
                      </span>
                    ) : (
                      <span>تأنَّ وتدبّر في المعنى بقلبك 🌿</span>
                    )}
                  </span>
                </div>
                <div className="font-mono font-bold text-xs flex items-center gap-1">
                  <span>المتبقي:</span>
                  <span className={`text-sm px-1.5 py-0.5 rounded-md ${
                    isNightReadingActive ? 'bg-amber-950/60 text-amber-300' : 'bg-emerald-900/10 text-emerald-800 dark:text-emerald-300'
                  }`}>
                    {repSecondsRemaining}ث
                  </span>
                </div>
              </div>

              {/* Smooth Progress Bar */}
              <div className="relative w-full h-3 rounded-full bg-black/10 dark:bg-black/30 overflow-hidden border border-black/5 dark:border-white/5">
                <div 
                  className={`h-full rounded-full transition-all duration-150 ${
                    repProgress >= 100
                      ? 'bg-gradient-to-r from-emerald-500 to-emerald-400 shadow-sm'
                      : isNightReadingActive
                        ? 'bg-gradient-to-r from-amber-600 via-amber-500 to-amber-400'
                        : 'bg-gradient-to-r from-emerald-700 via-emerald-600 to-emerald-500'
                  }`}
                  style={{ width: `${repProgress}%` }}
                />
              </div>

              {/* Repetition Quick Presets & Controls */}
              <div className="flex items-center justify-between gap-2 pt-1">
                <div className="flex items-center gap-1 overflow-x-auto pb-0.5">
                  {[
                    { sec: 3, label: '٣ث' },
                    { sec: 5, label: '٥ث' },
                    { sec: 8, label: '٨ث' },
                    { sec: 12, label: '١٢ث' },
                    { sec: suggestedPaceSeconds, label: `ذكي (${suggestedPaceSeconds}ث)` },
                  ].map((preset) => (
                    <button
                      key={preset.sec}
                      onClick={() => {
                        setRepIntervalSec(preset.sec);
                        setRepElapsedSec(0);
                        setRepCompletedNotice(false);
                        try {
                          localStorage.setItem('hisn_timer_rep_pace', preset.sec.toString());
                        } catch {}
                        triggerVibration(vibrationEnabled, 'light');
                      }}
                      className={`px-2 py-0.5 rounded-lg text-[11px] font-tajawal transition-colors cursor-pointer border ${
                        repIntervalSec === preset.sec
                          ? isNightReadingActive
                            ? 'bg-amber-500/25 border-amber-400 text-amber-300 font-bold'
                            : 'bg-emerald-600/20 border-emerald-600 text-emerald-800 dark:text-emerald-300 font-bold'
                          : 'border-transparent text-gray-500 hover:text-black dark:hover:text-white'
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={handleToggleRunning}
                    className={`p-1.5 rounded-xl border flex items-center gap-1 text-xs font-bold font-cairo cursor-pointer transition-all ${
                      isRunning
                        ? 'bg-amber-500/20 border-amber-400/50 text-amber-300 hover:bg-amber-500/30'
                        : 'bg-emerald-600 border-emerald-500 text-white hover:bg-emerald-700 shadow-xs'
                    }`}
                  >
                    {isRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                    <span className="text-[11px]">{isRunning ? 'إيقاف' : 'استئناف'}</span>
                  </button>

                  <button
                    onClick={handleReset}
                    className="p-1.5 rounded-xl border border-gray-400/30 hover:bg-black/10 text-gray-400 hover:text-gray-600 dark:hover:text-white cursor-pointer transition-colors"
                    title="إعادة بدء التمهل"
                    aria-label="إعادة بدء التمهل"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {mode === 'session' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 font-tajawal">الوقت المتبقي للجلسة:</p>
                  <p className={`font-mono text-2xl font-black tracking-wider ${
                    isNightReadingActive ? 'text-amber-300' : 'text-emerald-800 dark:text-emerald-200'
                  }`}>
                    {formatTime(sessionRemainingSec)}
                  </p>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={handleToggleRunning}
                    className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 text-xs font-bold font-cairo cursor-pointer transition-all ${
                      isRunning
                        ? 'bg-amber-500/20 border-amber-400/50 text-amber-300'
                        : 'bg-emerald-600 border-emerald-500 text-white shadow-xs'
                    }`}
                  >
                    {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    <span>{isRunning ? 'إيقاف مؤقت' : 'بدء'}</span>
                  </button>

                  <button
                    onClick={handleReset}
                    className="p-2 rounded-xl border border-gray-400/30 hover:bg-black/10 text-gray-400 hover:text-gray-600 dark:hover:text-white cursor-pointer"
                    title="إعادة ضبط المؤقت"
                    aria-label="إعادة ضبط"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Session Progress Bar */}
              <div className="relative w-full h-2.5 rounded-full bg-black/10 dark:bg-black/30 overflow-hidden border border-black/5 dark:border-white/5">
                <div 
                  className={`h-full rounded-full transition-all duration-150 ${
                    isNightReadingActive
                      ? 'bg-gradient-to-r from-amber-600 to-amber-400'
                      : 'bg-gradient-to-r from-emerald-700 to-emerald-500'
                  }`}
                  style={{ width: `${sessionProgress}%` }}
                />
              </div>

              {/* Session Presets */}
              <div className="flex items-center gap-1.5 overflow-x-auto pt-1">
                <span className="text-[11px] text-gray-500 font-tajawal shrink-0">المدة:</span>
                {[
                  { sec: 60, label: '١ دقيقة' },
                  { sec: 120, label: '٢ دقيقة' },
                  { sec: 180, label: '٣ دقائق' },
                  { sec: 300, label: '٥ دقائق' },
                  { sec: 600, label: '١٠ دقائق' },
                ].map((preset) => (
                  <button
                    key={preset.sec}
                    onClick={() => {
                      setSessionDurationSec(preset.sec);
                      setSessionRemainingSec(preset.sec);
                      setIsRunning(true);
                      try {
                        localStorage.setItem('hisn_timer_session_dur', preset.sec.toString());
                      } catch {}
                      triggerVibration(vibrationEnabled, 'light');
                    }}
                    className={`px-2 py-0.5 rounded-lg text-xs font-tajawal border transition-colors cursor-pointer shrink-0 ${
                      sessionDurationSec === preset.sec
                        ? isNightReadingActive
                          ? 'bg-amber-500/25 border-amber-400 text-amber-300 font-bold'
                          : 'bg-emerald-600/20 border-emerald-600 text-emerald-800 dark:text-emerald-300 font-bold'
                        : 'border-transparent text-gray-500 hover:text-black dark:hover:text-white'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {mode === 'stopwatch' && (
            <div className="flex items-center justify-between pt-1">
              <div>
                <p className="text-[11px] text-gray-500 font-tajawal">الوقت المستغرق في قراءة وتدبر هذا الذكر:</p>
                <p className={`font-mono text-2xl font-black ${
                  isNightReadingActive ? 'text-amber-300' : 'text-emerald-800 dark:text-emerald-200'
                }`}>
                  {formatTime(stopwatchElapsedSec)}
                </p>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={handleToggleRunning}
                  className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 text-xs font-bold font-cairo cursor-pointer transition-all ${
                    isRunning
                      ? 'bg-amber-500/20 border-amber-400/50 text-amber-300'
                      : 'bg-emerald-600 border-emerald-500 text-white shadow-xs'
                  }`}
                >
                  {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  <span>{isRunning ? 'إيقاف' : 'استئناف'}</span>
                </button>
                <button
                  onClick={handleReset}
                  className="p-2 rounded-xl border border-gray-400/30 hover:bg-black/10 text-gray-400 hover:text-gray-600 dark:hover:text-white cursor-pointer"
                  title="تصفير العداد"
                  aria-label="تصفير"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Settings Modal */}
      {showSettingsModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div 
            className="w-full max-w-sm bg-[#042017] dark:bg-[#042017] border border-emerald-600/30 dark:border-emerald-700/60 rounded-3xl p-5 shadow-2xl space-y-3.5 text-right text-emerald-100"
            role="dialog"
            aria-modal="true"
          >
            <div className="flex items-center justify-between pb-2 border-b border-emerald-800/40">
              <div className="flex items-center gap-2">
                <Hourglass className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-extrabold text-white font-cairo">
                  خيارات مؤقت التمهل والتدبر
                </h3>
              </div>
              <button
                onClick={() => setShowSettingsModal(false)}
                className="p-1 rounded-full text-emerald-400 hover:text-white"
                aria-label="إغلاق"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-emerald-300/80 font-tajawal leading-relaxed">
              المؤقت مصمم لمساعدتك على قراءة الأذكار بهدوء وتؤدة وتدبر لمعانيها دون استعجال:
            </p>

            <div className="space-y-3">
              {/* Sound Notification Toggle */}
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/40">
                <div className="flex items-center gap-2">
                  <Volume2 className="w-4 h-4 text-emerald-400" />
                  <div>
                    <p className="text-xs font-bold font-cairo">تنبيه صوتي هادئ</p>
                    <p className="text-[10px] text-emerald-300/60 font-tajawal">رنين نقي لطيف عند انقضاء الوقت</p>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={soundEnabled}
                  onChange={(e) => setSoundEnabled(e.target.checked)}
                  className="w-4 h-4 accent-emerald-500 cursor-pointer"
                />
              </div>

              {/* Vibration Notification Toggle */}
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/40">
                <div className="flex items-center gap-2">
                  <Vibrate className="w-4 h-4 text-emerald-400" />
                  <div>
                    <p className="text-xs font-bold font-cairo">اهتزاز لمسي لطيف</p>
                    <p className="text-[10px] text-emerald-300/60 font-tajawal">نبضة هادئة تفيدك دون النظر للشاشة</p>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={vibrationEnabled}
                  onChange={(e) => setVibrationEnabled(e.target.checked)}
                  className="w-4 h-4 accent-emerald-500 cursor-pointer"
                />
              </div>

              {/* Auto Advance Repetition */}
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/40">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <div>
                    <p className="text-xs font-bold font-cairo">الانتقال التلقائي المتمهل</p>
                    <p className="text-[10px] text-emerald-300/60 font-tajawal">
                      زيادة عداد التسبيح تلقائياً عند انتهاء وقت كل تسبيحة
                    </p>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={autoAdvanceRep}
                  onChange={(e) => setAutoAdvanceRep(e.target.checked)}
                  className="w-4 h-4 accent-amber-500 cursor-pointer"
                />
              </div>

              {/* Suggested pace description */}
              <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs font-tajawal flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold font-cairo block">التمهل الذكي المقترح لهذا الذكر:</span>
                  <span>
                    عدد كلمات هذا الذكر ({wordCount}) كلمة؛ الوقت المقترح لقراءته بتأنٍ وتدبر هو ({suggestedPaceSeconds}) ثوانٍ لكل تكرار.
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={() => setShowSettingsModal(false)}
              className="w-full py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white font-bold text-xs font-cairo transition-all cursor-pointer shadow-md"
            >
              تم
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
