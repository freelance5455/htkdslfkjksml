"use client";

import { useEffect, useState } from "react";
import { buildState, oversStr } from "@/lib/engine";
import { listMatches } from "@/lib/match-repo";
import type { LocalMatch } from "@/lib/local-store";
import { MatchListCard, type MatchCardData } from "./match-card";

function toCard(m: LocalMatch): MatchCardData {
  const state = buildState(m.setup, m.events, m.awards);
  return {
    id: m.id,
    teamA: m.setup.teamA,
    teamB: m.setup.teamB,
    logoA: m.setup.logoA,
    logoB: m.setup.logoB,
    format: m.setup.format,
    overs: m.setup.overs,
    venue: m.setup.venue ?? null,
    date: m.setup.matchDate ?? new Date(m.createdAt).toISOString(),
    status: state.status,
    result: state.result,
    playerOfMatch: state.awards.playerOfMatch ?? null,
    scores: state.innings
      .filter((i) => i.started)
      .map((i) => ({
        team: i.battingTeam,
        line: `${i.runs}/${i.wickets} (${oversStr(i.legalBalls)})`,
      })),
  };
}

/**
 * Matches stored on this device. These render even when the cloud database is
 * unreachable, so a scorer never loses sight of a match in progress.
 */
export function LocalMatches({
  filter = "all",
  serverIds = [],
  emptyMessage,
  heading = "Matches on this device",
}: {
  filter?: "all" | "live" | "completed";
  serverIds?: string[];
  /** Shown when nothing matches the filter. Omit to render nothing. */
  emptyMessage?: string;
  heading?: string;
}) {
  const [cards, setCards] = useState<MatchCardData[] | null>(null);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      const all = (await listMatches()).map(toCard);
      if (alive) setCards(all);
    };
    void load();
    const t = setInterval(() => void load(), 4000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, []);

  if (!cards) return null;

  const visible = cards
    .filter((c) =>
      filter === "live"
        ? c.status !== "completed"
        : filter === "completed"
          ? c.status === "completed"
          : true,
    )
    // Avoid showing a match twice when the server already lists it.
    .filter((c) => !serverIds.includes(c.id));

  if (visible.length === 0) {
    return emptyMessage ? (
      <div className="mc-card px-6 py-10 text-center text-sm text-slate-400">{emptyMessage}</div>
    ) : null;
  }

  return (
    <div className="mt-4">
      <div className="mb-3 flex items-center gap-2">
        <h3 className="text-xs font-black uppercase tracking-widest text-slate-400">
          {heading}
        </h3>
        <span className="rounded bg-slate-800 px-2 py-0.5 text-[10px] font-black text-slate-400">
          {visible.length}
        </span>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {visible.map((m) => (
          <MatchListCard key={m.id} m={m} showScorer />
        ))}
      </div>
    </div>
  );
}
