import React, { useState } from 'react';
import { Sparkles, Wand2, X, Image as ImageIcon, Flame, Zap, Camera, Film, Layers } from 'lucide-react';
import { GeneratedImagePayload } from '../types';

interface PhotoStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImageGenerated: (payload: GeneratedImagePayload) => void;
}

export const PhotoStudioModal: React.FC<PhotoStudioModalProps> = ({
  isOpen,
  onClose,
  onImageGenerated,
}) => {
  const [prompt, setPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16' | '1:1'>('16:9');
  const [style, setStyle] = useState('photorealistic 8k');
  const [isGenerating, setIsGenerating] = useState(false);

  if (!isOpen) return null;

  const PRESET_PROMPTS = [
    {
      title: '💖 Anniversary Celebration',
      prompt: 'A romantic Indian couple celebrating their golden marriage anniversary with red roses, candle lights and golden bokeh in 8k ultra realistic photography',
    },
    {
      title: '🚀 5 Secret AI Websites',
      prompt: 'Viral high CTR YouTube thumbnail featuring a futuristic glowing holographic robot revealing 5 secret websites, neon cyan and gold lighting',
    },
    {
      title: '🍔 Delicious Street Food 4K',
      prompt: 'Crispy mouth-watering Indian street food butter pav bhaji with sizzling melting butter and steam in 8k macro food photography',
    },
    {
      title: '🎮 Pro Esports Neon Battlestation',
      prompt: 'Ultimate dream gaming setup with triple curved monitors, RGB mechanical keyboard, neon purple ambiance and RTX rig',
    },
    {
      title: '👤 Viral Influencer Studio Portrait',
      prompt: 'Close-up studio portrait of a charismatic YouTube creator with cinematic lighting, depth of field and bold expressive emotion',
    },
  ];

  const handleGenerate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!prompt.trim() || isGenerating) return;

    setIsGenerating(true);
    try {
      const res = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt.trim(),
          aspectRatio,
          style,
        }),
      });

      const data = await res.json();
      if (data.payload) {
        onImageGenerated(data.payload);
        onClose();
      } else {
        alert('Failed to generate image. Please try again.');
      }
    } catch (err: any) {
      alert(`Error generating image: ${err?.message || 'Server error'}`);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-zinc-950 border border-cyan-500/30 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 border-b border-white/10 bg-gradient-to-r from-cyan-950/40 via-blue-950/30 to-zinc-950 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-black font-bold shadow-lg shadow-cyan-500/30">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                <span>AI Photo Studio (फोटो प्रॉम्प्ट स्टूडियो)</span>
                <span className="text-[10px] font-mono px-2 py-0.2 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  REAL 8K AI
                </span>
              </h3>
              <p className="text-[11px] text-zinc-400">
                Type your exact prompt to generate real high-definition photos
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {/* Quick Presets */}
          <div>
            <span className="block text-[11px] font-semibold text-zinc-400 mb-1.5">
              Popular Presets (1-Click Chunein):
            </span>
            <div className="flex flex-wrap gap-1.5">
              {PRESET_PROMPTS.map((pr, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setPrompt(pr.prompt)}
                  className="px-2.5 py-1 rounded-xl text-left bg-zinc-900/70 hover:bg-zinc-800 text-[11px] text-zinc-300 border border-white/5 truncate transition-all active:scale-95"
                >
                  {pr.title}
                </button>
              ))}
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleGenerate} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                Photo Prompt (आप कैसा फोटो बनवाना चाहते हैं?) *
              </label>
              <textarea
                rows={3}
                value={prompt}
                onChange={e => setPrompt(e.target.value)}
                placeholder="e.g. A beautiful golden anniversary celebration of an Indian couple with red roses and warm glowing candles, 8k ultra realistic photography..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-500 leading-relaxed resize-none"
              />
            </div>

            {/* Aspect Ratio Selector */}
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                Aspect Ratio (आकार):
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: '16:9', label: '16:9 (YouTube)', desc: 'Landscape / Video' },
                  { id: '9:16', label: '9:16 (Shorts)', desc: 'Vertical / Reels' },
                  { id: '1:1', label: '1:1 (Square)', desc: 'Instagram / Profile' },
                ].map(ar => (
                  <button
                    key={ar.id}
                    type="button"
                    onClick={() => setAspectRatio(ar.id as any)}
                    className={`p-2 rounded-xl text-center border transition-all ${
                      aspectRatio === ar.id
                        ? 'border-cyan-500 bg-cyan-950/40 text-cyan-300 font-bold'
                        : 'border-white/5 bg-zinc-900/60 text-zinc-400 hover:text-white'
                    }`}
                  >
                    <div className="text-xs">{ar.label}</div>
                    <div className="text-[10px] text-zinc-500">{ar.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Style Selector */}
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                Visual Style (स्टाइल):
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'photorealistic 8k', label: '📸 Photorealistic 8K' },
                  { id: 'cinematic 3d pixar', label: '🎬 Cinematic 3D' },
                  { id: 'neon cyberpunk high ctr', label: '⚡ Neon Cyberpunk' },
                  { id: 'digital oil painting', label: '🎨 Digital Masterpiece' },
                ].map(st => (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => setStyle(st.id)}
                    className={`p-2 rounded-xl text-left border text-xs transition-all ${
                      style === st.id
                        ? 'border-cyan-500 bg-cyan-950/40 text-cyan-300 font-bold'
                        : 'border-white/5 bg-zinc-900/60 text-zinc-400 hover:text-white'
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="submit"
              disabled={isGenerating || !prompt.trim()}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs uppercase tracking-wider shadow-lg shadow-cyan-500/25 active:scale-98 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <Sparkles className="w-4 h-4 animate-spin text-black" />
                  <span>Generating Real AI Photo (8K Ultra)...</span>
                </>
              ) : (
                <>
                  <Wand2 className="w-4 h-4" />
                  <span>Create High-Quality Photo 🎨</span>
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
