import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BookOpen, 
  Bookmark, 
  Highlighter, 
  Search, 
  Share2, 
  Copy, 
  Check, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  WifiOff, 
  ChevronRight, 
  ChevronLeft, 
  Trash2, 
  Tag, 
  Layers, 
  Sun, 
  Moon, 
  Type, 
  ShieldCheck,
  Flame,
  X,
  Plus
} from 'lucide-react';
import { OFFLINE_BIBLE_BOOKS, TRANSLATION_LABELS } from '../data/bibleData';
import { BibleBookItem, BibleVerseItem, BibleHighlightRecord, BibleBookmarkRecord, HighlightColor, BibleTranslation } from '../types';
import { offlineCache } from '../lib/offlineCache';

interface OfflineBibleReaderProps {
  onShowToast?: (msg: string) => void;
  onOpenBreakthroughModal?: (entry: { title: string; text: string; category?: string; date?: string }) => void;
}

export const OfflineBibleReader: React.FC<OfflineBibleReaderProps> = ({ onShowToast, onOpenBreakthroughModal }) => {
  const [selectedBookId, setSelectedBookId] = useState<string>('psalms');
  const [selectedChapterNumber, setSelectedChapterNumber] = useState<number>(23);
  const [selectedTranslation, setSelectedTranslation] = useState<BibleTranslation>(() => (offlineCache.getPreferredBibleTranslation() as BibleTranslation) || 'KJV');
  const [activeTab, setActiveTab] = useState<'reader' | 'highlights' | 'bookmarks' | 'search'>('reader');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [fontSize, setFontSize] = useState<'sm' | 'md' | 'lg' | 'xl'>('md');
  const [colorTheme, setColorTheme] = useState<'dark' | 'parchment' | 'midnight'>('dark');
  
  // State for highlighted verses & bookmarks loaded from offlineCache
  const [highlights, setHighlights] = useState<BibleHighlightRecord[]>(() => offlineCache.getBibleHighlights());
  const [bookmarks, setBookmarks] = useState<BibleBookmarkRecord[]>(() => offlineCache.getBibleBookmarks());
  const [offlineStats, setOfflineStats] = useState(() => offlineCache.getOfflineBibleStats());

  // Interactive Selected Verse Toolbar
  const [activeVerse, setActiveVerse] = useState<BibleVerseItem | null>(null);
  const [isAddingNote, setIsAddingNote] = useState<boolean>(false);
  const [bookmarkNoteText, setBookmarkNoteText] = useState<string>('');
  const [bookmarkTagsText, setBookmarkTagsText] = useState<string>('Prophetic, Revelation');
  const [selectedHighlightColor, setSelectedHighlightColor] = useState<HighlightColor>('gold');
  
  // Audio Speech Synthesis state
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [copiedVerseIndex, setCopiedVerseIndex] = useState<number | null>(null);

  useEffect(() => {
    const unsub = offlineCache.subscribe(() => {
      setHighlights(offlineCache.getBibleHighlights());
      setBookmarks(offlineCache.getBibleBookmarks());
      setOfflineStats(offlineCache.getOfflineBibleStats());
    });
    return unsub;
  }, []);

  const currentBook = OFFLINE_BIBLE_BOOKS.find(b => b.id === selectedBookId) || OFFLINE_BIBLE_BOOKS[0];
  const currentChapter = currentBook.chapters.find(c => c.chapterNumber === selectedChapterNumber) || currentBook.chapters[0];

  const handleSelectBook = (bookId: string) => {
    setSelectedBookId(bookId);
    const book = OFFLINE_BIBLE_BOOKS.find(b => b.id === bookId);
    if (book && book.chapters.length > 0) {
      setSelectedChapterNumber(book.chapters[0].chapterNumber);
    }
    setActiveVerse(null);
  };

  const handlePrevChapter = () => {
    const currentIndex = currentBook.chapters.findIndex(c => c.chapterNumber === selectedChapterNumber);
    if (currentIndex > 0) {
      setSelectedChapterNumber(currentBook.chapters[currentIndex - 1].chapterNumber);
      setActiveVerse(null);
    }
  };

  const handleNextChapter = () => {
    const currentIndex = currentBook.chapters.findIndex(c => c.chapterNumber === selectedChapterNumber);
    if (currentIndex < currentBook.chapters.length - 1) {
      setSelectedChapterNumber(currentBook.chapters[currentIndex + 1].chapterNumber);
      setActiveVerse(null);
    }
  };

  const handleHighlightVerse = (verse: BibleVerseItem, color: HighlightColor) => {
    offlineCache.setBibleHighlight({
      bookId: currentBook.id,
      bookName: currentBook.name,
      chapter: currentChapter.chapterNumber,
      verse: verse.verseNumber,
      color,
      verseText: verse.text
    });
    setSelectedHighlightColor(color);
    if (onShowToast) onShowToast(`Verse ${currentBook.name} ${currentChapter.chapterNumber}:${verse.verseNumber} highlighted in ${color.toUpperCase()}`);
  };

  const handleRemoveHighlight = (verseNumber: number) => {
    offlineCache.removeBibleHighlight({
      bookId: currentBook.id,
      chapter: currentChapter.chapterNumber,
      verse: verseNumber
    });
    if (onShowToast) onShowToast(`Highlight removed from verse ${verseNumber}`);
  };

  const handleSaveBookmark = (verse: BibleVerseItem) => {
    const tags = bookmarkTagsText.split(',').map(t => t.trim()).filter(Boolean);
    offlineCache.saveBibleBookmark({
      bookId: currentBook.id,
      bookName: currentBook.name,
      chapter: currentChapter.chapterNumber,
      verse: verse.verseNumber,
      verseText: verse.text,
      title: `${currentBook.name} ${currentChapter.chapterNumber}:${verse.verseNumber}`,
      note: bookmarkNoteText || 'Spiritual soaking revelation',
      tags: tags.length > 0 ? tags : ['Scripture', 'Prophetic'],
      color: selectedHighlightColor
    });
    setIsAddingNote(false);
    setBookmarkNoteText('');
    if (onShowToast) onShowToast(`Bookmarked ${currentBook.name} ${currentChapter.chapterNumber}:${verse.verseNumber} to offline vault!`);
  };

  const handleCopyVerse = (verse: BibleVerseItem) => {
    const textToCopy = `"${verse.text}" — ${currentBook.name} ${currentChapter.chapterNumber}:${verse.verseNumber} (${selectedTranslation})\nJUHNKRIX MUSIKA Offline Scripture Vault`;
    navigator.clipboard.writeText(textToCopy);
    setCopiedVerseIndex(verse.verseNumber);
    setTimeout(() => setCopiedVerseIndex(null), 2500);
    if (onShowToast) onShowToast('Scripture verse copied to clipboard!');
  };

  const handleReadAloud = (textToRead: string) => {
    if ('speechSynthesis' in window) {
      if (isSpeaking) {
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
        return;
      }
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(textToRead);
      utterance.rate = 0.88;
      utterance.pitch = 1.0;
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      setIsSpeaking(true);
      window.speechSynthesis.speak(utterance);
    } else {
      if (onShowToast) onShowToast('Audio speech synthesis is not supported on this browser.');
    }
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  };

  // Color mapping helper
  const getColorClasses = (color: HighlightColor) => {
    switch (color) {
      case 'gold':
        return 'bg-amber-500/25 border-l-4 border-amber-400 text-amber-100';
      case 'emerald':
        return 'bg-emerald-500/25 border-l-4 border-emerald-400 text-emerald-100';
      case 'rose':
        return 'bg-rose-500/25 border-l-4 border-rose-400 text-rose-100';
      case 'azure':
        return 'bg-cyan-500/25 border-l-4 border-cyan-400 text-cyan-100';
      case 'amber':
        return 'bg-orange-500/25 border-l-4 border-orange-400 text-orange-100';
      default:
        return 'bg-amber-500/20 text-amber-100';
    }
  };

  const getBadgeColor = (color: HighlightColor) => {
    switch (color) {
      case 'gold': return 'bg-amber-500 text-slate-950';
      case 'emerald': return 'bg-emerald-500 text-slate-950';
      case 'rose': return 'bg-rose-500 text-white';
      case 'azure': return 'bg-cyan-500 text-slate-950';
      case 'amber': return 'bg-orange-500 text-slate-950';
      default: return 'bg-amber-500 text-slate-950';
    }
  };

  const getFontSizeClass = () => {
    switch (fontSize) {
      case 'sm': return 'text-xs leading-relaxed';
      case 'md': return 'text-sm leading-loose';
      case 'lg': return 'text-base leading-loose';
      case 'xl': return 'text-lg leading-loose font-serif';
    }
  };

  const getThemeContainerClass = () => {
    switch (colorTheme) {
      case 'parchment':
        return 'bg-amber-950/40 text-amber-100 border-amber-500/30';
      case 'midnight':
        return 'bg-slate-950 text-indigo-100 border-indigo-500/30';
      case 'dark':
      default:
        return 'bg-slate-900/90 text-slate-100 border-amber-500/30';
    }
  };

  // Search Results aggregation across all books and verses
  const searchResults: { book: BibleBookItem; chapter: number; verse: BibleVerseItem }[] = [];
  if (searchQuery.trim().length > 1) {
    const q = searchQuery.toLowerCase();
    OFFLINE_BIBLE_BOOKS.forEach(b => {
      b.chapters.forEach(c => {
        c.verses.forEach(v => {
          if (v.text.toLowerCase().includes(q) || (v.propheticNote && v.propheticNote.toLowerCase().includes(q))) {
            searchResults.push({ book: b, chapter: c.chapterNumber, verse: v });
          }
        });
      });
    });
  }

  return (
    <div className="space-y-6 animate-fadeIn max-w-7xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-amber-950/60 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-black uppercase tracking-wider">
              <BookOpen className="w-4 h-4 text-amber-400" />
              <span>OFFLINE SCRIPTURE ENGINE & REVELATION VAULT</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold font-serif text-amber-100">
              Lightweight Offline Bible Reader
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm max-w-2xl">
              100% locally cached Holy Scriptures powered by <code className="text-amber-300 font-mono">offlineCache</code>. Read, highlight, and bookmark prophetic revelation without internet connectivity.
            </p>
          </div>

          {/* Offline Cache Status Badge */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="px-4 py-2.5 rounded-2xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center space-x-2 shadow-lg shadow-emerald-950/40">
              <WifiOff className="w-4 h-4 text-emerald-400 animate-pulse" />
              <div className="flex flex-col">
                <span className="text-[10px] text-emerald-400/80 uppercase font-mono">OFFLINE CACHE STATUS</span>
                <span>100% Synced & Available Offline ({offlineStats.cacheSizeKb} KB)</span>
              </div>
            </div>

            {isSpeaking && (
              <button
                onClick={stopSpeaking}
                className="px-3.5 py-2.5 rounded-2xl bg-rose-500/20 border border-rose-500/40 text-rose-300 hover:bg-rose-500/30 text-xs font-bold flex items-center space-x-1.5 transition-all"
              >
                <VolumeX className="w-4 h-4 text-rose-400" />
                <span>Stop Audio</span>
              </button>
            )}
          </div>
        </div>

        {/* View Switcher Tabs */}
        <div className="flex flex-wrap items-center gap-2 mt-6 pt-4 border-t border-amber-500/20">
          <button
            onClick={() => setActiveTab('reader')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all ${
              activeTab === 'reader'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-900/80 hover:bg-slate-800 text-amber-200/80 border border-amber-500/20'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Bible Reader</span>
          </button>

          <button
            onClick={() => setActiveTab('highlights')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all ${
              activeTab === 'highlights'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-900/80 hover:bg-slate-800 text-amber-200/80 border border-amber-500/20'
            }`}
          >
            <Highlighter className="w-4 h-4 text-amber-400" />
            <span>Highlights ({highlights.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('bookmarks')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all ${
              activeTab === 'bookmarks'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-900/80 hover:bg-slate-800 text-amber-200/80 border border-amber-500/20'
            }`}
          >
            <Bookmark className="w-4 h-4 text-cyan-400" />
            <span>Spiritual Bookmarks ({bookmarks.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('search')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all ${
              activeTab === 'search'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-900/80 hover:bg-slate-800 text-amber-200/80 border border-amber-500/20'
            }`}
          >
            <Search className="w-4 h-4 text-purple-400" />
            <span>Offline Search</span>
          </button>
        </div>
      </div>

      {/* Main Tab Views */}
      {activeTab === 'reader' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Book & Chapter Navigator */}
          <div className="lg:col-span-4 space-y-5">
            <div className="bg-slate-900/90 border-2 border-amber-500/30 rounded-3xl p-5 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-amber-300 uppercase tracking-wider flex items-center space-x-1.5">
                  <Layers className="w-4 h-4 text-amber-400" />
                  <span>Scripture Books</span>
                </span>
                <span className="text-[10px] text-slate-400 font-mono font-bold">
                  {OFFLINE_BIBLE_BOOKS.length} Books Cached
                </span>
              </div>

              {/* Translation Selector */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-bold text-slate-300">Bible Translation</label>
                <select
                  value={selectedTranslation}
                  onChange={(e) => {
                    const val = e.target.value as BibleTranslation;
                    setSelectedTranslation(val);
                    offlineCache.setPreferredBibleTranslation(val);
                  }}
                  className="w-full bg-slate-950 border border-amber-500/30 rounded-xl px-3 py-2 text-xs text-amber-100 font-bold focus:outline-none focus:border-amber-400"
                >
                  {Object.entries(TRANSLATION_LABELS).map(([key, info]) => (
                    <option key={key} value={key} className="bg-slate-950 text-amber-100">
                      {info.name} — {info.tag}
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-slate-400 italic">
                  {TRANSLATION_LABELS[selectedTranslation]?.description}
                </p>
              </div>

              {/* Book List Selection Grid */}
              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {OFFLINE_BIBLE_BOOKS.map((book) => {
                  const isSelected = book.id === selectedBookId;
                  return (
                    <button
                      key={book.id}
                      onClick={() => handleSelectBook(book.id)}
                      className={`w-full p-3 rounded-2xl text-left transition-all flex items-center justify-between border ${
                        isSelected
                          ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold shadow-lg shadow-amber-500/20'
                          : 'bg-slate-950/60 hover:bg-slate-800 text-slate-200 border-slate-800'
                      }`}
                    >
                      <div>
                        <div className="text-xs font-bold">{book.name}</div>
                        <div className={`text-[10px] ${isSelected ? 'text-slate-900' : 'text-slate-400'}`}>
                          {book.testament} • {book.category}
                        </div>
                      </div>
                      <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full ${
                        isSelected ? 'bg-slate-950 text-amber-300' : 'bg-slate-800 text-amber-400'
                      }`}>
                        {book.chapters.length} Chap
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Chapter Buttons Grid */}
              <div className="space-y-2 pt-3 border-t border-slate-800">
                <label className="text-[11px] font-bold text-slate-300">Select Chapter</label>
                <div className="flex flex-wrap gap-2">
                  {currentBook.chapters.map((chap) => {
                    const isSelected = chap.chapterNumber === selectedChapterNumber;
                    return (
                      <button
                        key={chap.chapterNumber}
                        onClick={() => {
                          setSelectedChapterNumber(chap.chapterNumber);
                          setActiveVerse(null);
                        }}
                        className={`w-10 h-10 rounded-xl font-mono text-xs font-bold flex items-center justify-center transition-all border ${
                          isSelected
                            ? 'bg-amber-400 text-slate-950 border-amber-300 font-extrabold shadow-md'
                            : 'bg-slate-950 text-amber-200/80 border-slate-800 hover:border-amber-500/40'
                        }`}
                      >
                        {chap.chapterNumber}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Reader Display Preferences */}
              <div className="pt-3 border-t border-slate-800 space-y-3">
                <div className="flex items-center justify-between text-xs text-slate-300">
                  <span className="flex items-center space-x-1 font-bold">
                    <Type className="w-3.5 h-3.5 text-amber-400" />
                    <span>Font Size</span>
                  </span>
                  <div className="flex items-center space-x-1">
                    {(['sm', 'md', 'lg', 'xl'] as const).map((sz) => (
                      <button
                        key={sz}
                        onClick={() => setFontSize(sz)}
                        className={`px-2 py-1 rounded text-[10px] font-mono uppercase font-bold ${
                          fontSize === sz ? 'bg-amber-500 text-slate-950' : 'bg-slate-950 text-slate-400 hover:text-amber-200'
                        }`}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-300">
                  <span className="flex items-center space-x-1 font-bold">
                    <Sun className="w-3.5 h-3.5 text-amber-400" />
                    <span>Reader Theme</span>
                  </span>
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => setColorTheme('dark')}
                      className={`px-2 py-1 rounded text-[10px] font-bold ${
                        colorTheme === 'dark' ? 'bg-amber-500 text-slate-950' : 'bg-slate-950 text-slate-400'
                      }`}
                    >
                      Sanctuary
                    </button>
                    <button
                      onClick={() => setColorTheme('parchment')}
                      className={`px-2 py-1 rounded text-[10px] font-bold ${
                        colorTheme === 'parchment' ? 'bg-amber-500 text-slate-950' : 'bg-slate-950 text-slate-400'
                      }`}
                    >
                      Parchment
                    </button>
                    <button
                      onClick={() => setColorTheme('midnight')}
                      className={`px-2 py-1 rounded text-[10px] font-bold ${
                        colorTheme === 'midnight' ? 'bg-indigo-500 text-white' : 'bg-slate-950 text-slate-400'
                      }`}
                    >
                      Midnight
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Verses Reading Pane */}
          <div className="lg:col-span-8 space-y-4">
            <div className={`border-2 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 transition-all ${getThemeContainerClass()}`}>
              {/* Chapter Header Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-amber-500/20 pb-4">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-bold text-amber-400 uppercase tracking-wider font-mono">
                      {currentBook.testament} • {selectedTranslation}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold">
                      Offline Mode
                    </span>
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-extrabold font-serif text-amber-100 mt-1">
                    {currentBook.name} {currentChapter.chapterNumber}
                  </h3>
                </div>

                {/* Chapter Navigation Controls */}
                <div className="flex items-center space-x-2">
                  <button
                    onClick={handlePrevChapter}
                    className="p-2.5 rounded-xl bg-slate-950/80 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center space-x-1 transition-all"
                    title="Previous Chapter"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span className="hidden sm:inline">Prev</span>
                  </button>

                  <button
                    onClick={() => {
                      const fullChapterText = currentChapter.verses.map(v => `${v.verseNumber}. ${v.text}`).join(' ');
                      handleReadAloud(`${currentBook.name} chapter ${currentChapter.chapterNumber}. ${fullChapterText}`);
                    }}
                    className={`px-3.5 py-2.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all ${
                      isSpeaking
                        ? 'bg-rose-500 text-white animate-pulse'
                        : 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40'
                    }`}
                  >
                    <Volume2 className="w-4 h-4 text-amber-400" />
                    <span>{isSpeaking ? 'Listening...' : 'Read Chapter'}</span>
                  </button>

                  <button
                    onClick={handleNextChapter}
                    className="p-2.5 rounded-xl bg-slate-950/80 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center space-x-1 transition-all"
                    title="Next Chapter"
                  >
                    <span className="hidden sm:inline">Next</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Verses Flow Display */}
              <div className="space-y-4">
                {currentChapter.verses.map((verse) => {
                  const highlight = highlights.find(
                    h => h.bookId.toLowerCase() === currentBook.id.toLowerCase() && h.chapter === currentChapter.chapterNumber && h.verse === verse.verseNumber
                  );
                  const bookmark = bookmarks.find(
                    b => b.bookId.toLowerCase() === currentBook.id.toLowerCase() && b.chapter === currentChapter.chapterNumber && b.verse === verse.verseNumber
                  );
                  const isSelected = activeVerse?.verseNumber === verse.verseNumber;

                  return (
                    <div
                      key={verse.verseNumber}
                      onClick={() => setActiveVerse(isSelected ? null : verse)}
                      className={`p-4 rounded-2xl transition-all cursor-pointer relative group border ${
                        highlight
                          ? `${getColorClasses(highlight.color)} shadow-md`
                          : isSelected
                          ? 'bg-amber-500/10 border-amber-400/60 shadow-lg'
                          : 'bg-slate-950/40 border-transparent hover:border-amber-500/20 hover:bg-slate-950/70'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <span className="font-mono text-xs font-bold text-amber-400/90 pt-0.5 select-none shrink-0 w-6">
                          {verse.verseNumber}
                        </span>

                        <div className="space-y-2 flex-1">
                          <p className={`${getFontSizeClass()} text-slate-100`}>
                            {verse.text}
                          </p>

                          {/* Prophetic Insight Callout (if present) */}
                          {verse.propheticNote && (
                            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-400/30 text-xs text-amber-200 font-sans flex items-start space-x-2">
                              <Flame className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                              <div>
                                <span className="font-bold text-amber-300">Prophetic Word: </span>
                                <span>{verse.propheticNote}</span>
                              </div>
                            </div>
                          )}

                          {/* Attached Personal Bookmark Note */}
                          {bookmark && (
                            <div className="p-2.5 rounded-xl bg-cyan-950/50 border border-cyan-500/30 text-xs text-cyan-200 flex items-center justify-between">
                              <div className="flex items-center space-x-2">
                                <Bookmark className="w-3.5 h-3.5 text-cyan-400" />
                                <span className="font-bold">{bookmark.note || 'Spiritual Revelation'}</span>
                              </div>
                              <span className="text-[10px] text-cyan-400/70 font-mono">{bookmark.createdAt}</span>
                            </div>
                          )}
                        </div>

                        {/* Quick Action Icons */}
                        <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center space-x-1 shrink-0">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleCopyVerse(verse);
                            }}
                            className="p-1.5 rounded-lg bg-slate-900 text-slate-400 hover:text-amber-300"
                            title="Copy Verse"
                          >
                            {copiedVerseIndex === verse.verseNumber ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>

                      {/* Expanded Verse Toolbar when Clicked */}
                      {isSelected && (
                        <div 
                          onClick={(e) => e.stopPropagation()} 
                          className="mt-4 pt-3 border-t border-amber-500/20 flex flex-wrap items-center justify-between gap-3 animate-fadeIn"
                        >
                          {/* Color Palette Highlighters */}
                          <div className="flex items-center space-x-1.5">
                            <span className="text-[10px] font-bold text-slate-400 uppercase font-mono mr-1">Highlight:</span>
                            {(['gold', 'emerald', 'rose', 'azure', 'amber'] as HighlightColor[]).map((c) => (
                              <button
                                key={c}
                                onClick={() => handleHighlightVerse(verse, c)}
                                className={`w-6 h-6 rounded-full border-2 transition-transform hover:scale-125 ${getBadgeColor(c)} ${
                                  highlight?.color === c ? 'ring-2 ring-white scale-110' : 'border-slate-800'
                                }`}
                                title={`Highlight ${c.toUpperCase()}`}
                              />
                            ))}

                            {highlight && (
                              <button
                                onClick={() => handleRemoveHighlight(verse.verseNumber)}
                                className="text-[10px] text-rose-400 hover:underline ml-2 font-bold"
                              >
                                Clear
                              </button>
                            )}
                          </div>

                          {/* Action Buttons */}
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={() => {
                                handleReadAloud(`${currentBook.name} ${currentChapter.chapterNumber} verse ${verse.verseNumber}. ${verse.text}`);
                              }}
                              className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center space-x-1"
                            >
                              <Volume2 className="w-3.5 h-3.5" />
                              <span>Listen</span>
                            </button>

                            <button
                              onClick={() => setIsAddingNote(!isAddingNote)}
                              className="px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-bold flex items-center space-x-1"
                            >
                              <Bookmark className="w-3.5 h-3.5" />
                              <span>{bookmark ? 'Edit Note' : 'Bookmark & Note'}</span>
                            </button>

                            {onOpenBreakthroughModal && (
                              <button
                                onClick={() => {
                                  onOpenBreakthroughModal({
                                    title: `${currentBook.name} ${currentChapter.chapterNumber}:${verse.verseNumber}`,
                                    text: verse.text,
                                    category: 'Scripture Verse',
                                    date: new Date().toISOString().split('T')[0]
                                  });
                                }}
                                className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 text-xs font-extrabold flex items-center space-x-1 shadow-md shadow-amber-500/20"
                              >
                                <Share2 className="w-3.5 h-3.5" />
                                <span>Share Card</span>
                              </button>
                            )}
                          </div>

                          {/* Adding Bookmark Note Sub-Form */}
                          {isAddingNote && (
                            <div className="w-full mt-2 p-3 bg-slate-950/90 border border-cyan-500/40 rounded-2xl space-y-2">
                              <textarea
                                value={bookmarkNoteText}
                                onChange={(e) => setBookmarkNoteText(e.target.value)}
                                placeholder="Enter personal revelation, prayer petition, or soaking insight..."
                                rows={2}
                                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-xs text-cyan-100 placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                              />
                              <div className="flex items-center justify-between">
                                <input
                                  type="text"
                                  value={bookmarkTagsText}
                                  onChange={(e) => setBookmarkTagsText(e.target.value)}
                                  placeholder="Tags (comma separated)"
                                  className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-[11px] text-slate-300 focus:outline-none w-1/2"
                                />
                                <div className="flex items-center space-x-2">
                                  <button
                                    onClick={() => setIsAddingNote(false)}
                                    className="px-2.5 py-1 text-xs text-slate-400 hover:text-white"
                                  >
                                    Cancel
                                  </button>
                                  <button
                                    onClick={() => handleSaveBookmark(verse)}
                                    className="px-4 py-1.5 bg-cyan-500 text-slate-950 text-xs font-bold rounded-lg hover:bg-cyan-400 shadow-md"
                                  >
                                    Save to Offline Vault
                                  </button>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Highlights Tab */}
      {activeTab === 'highlights' && (
        <div className="bg-slate-900/90 border-2 border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-xl space-y-5">
          <div className="flex items-center justify-between border-b border-amber-500/20 pb-4">
            <div>
              <h3 className="text-xl font-bold font-serif text-amber-100 flex items-center space-x-2">
                <Highlighter className="w-5 h-5 text-amber-400" />
                <span>Saved Scripture Highlights ({highlights.length})</span>
              </h3>
              <p className="text-xs text-slate-400">All highlighted verses are securely persisted in local device cache.</p>
            </div>

            {highlights.length > 0 && (
              <button
                onClick={() => {
                  if (confirm('Clear all offline Bible highlights?')) {
                    offlineCache.saveProfile({ bibleHighlights: [] });
                    if (onShowToast) onShowToast('All highlights cleared');
                  }
                }}
                className="px-3 py-1.5 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/30 text-xs font-bold hover:bg-rose-500/20"
              >
                Clear All
              </button>
            )}
          </div>

          {highlights.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <Highlighter className="w-12 h-12 text-slate-600 mx-auto" />
              <p className="text-sm font-bold text-slate-400">No scripture highlights yet.</p>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Click on any verse in the reader view and pick a color swatch to highlight prophetic promises.
              </p>
              <button
                onClick={() => setActiveTab('reader')}
                className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs shadow-md"
              >
                Open Bible Reader
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {highlights.map((h) => (
                <div
                  key={h.id}
                  className={`p-5 rounded-2xl border space-y-3 flex flex-col justify-between ${getColorClasses(h.color)}`}
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold font-mono">
                        {h.bookName} {h.chapter}:{h.verse}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${getBadgeColor(h.color)}`}>
                        {h.color}
                      </span>
                    </div>
                    <p className="text-xs italic leading-relaxed">"{h.verseText}"</p>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/40 text-[10px]">
                    <span className="font-mono opacity-70">Saved: {h.createdAt}</span>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => {
                          setSelectedBookId(h.bookId);
                          setSelectedChapterNumber(h.chapter);
                          setActiveTab('reader');
                        }}
                        className="font-bold underline hover:text-white"
                      >
                        Read in Context →
                      </button>
                      <button
                        onClick={() => offlineCache.removeBibleHighlight({ id: h.id })}
                        className="p-1 text-rose-400 hover:text-rose-300"
                        title="Delete highlight"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Bookmarks Tab */}
      {activeTab === 'bookmarks' && (
        <div className="bg-slate-900/90 border-2 border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-xl space-y-5">
          <div className="flex items-center justify-between border-b border-amber-500/20 pb-4">
            <div>
              <h3 className="text-xl font-bold font-serif text-amber-100 flex items-center space-x-2">
                <Bookmark className="w-5 h-5 text-cyan-400" />
                <span>Spiritual Bookmarks & Revelation Notes ({bookmarks.length})</span>
              </h3>
              <p className="text-xs text-slate-400">Personal study insights and bookmarked prophetic scripture passages.</p>
            </div>

            {bookmarks.length > 0 && (
              <button
                onClick={() => {
                  if (confirm('Clear all offline Bible bookmarks?')) {
                    offlineCache.saveProfile({ bibleBookmarks: [] });
                    if (onShowToast) onShowToast('All bookmarks cleared');
                  }
                }}
                className="px-3 py-1.5 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/30 text-xs font-bold hover:bg-rose-500/20"
              >
                Clear All
              </button>
            )}
          </div>

          {bookmarks.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <Bookmark className="w-12 h-12 text-slate-600 mx-auto" />
              <p className="text-sm font-bold text-slate-400">No scripture bookmarks yet.</p>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Bookmark verses in the reader to record prayer revelations and tag them for quick access.
              </p>
              <button
                onClick={() => setActiveTab('reader')}
                className="px-4 py-2 rounded-xl bg-cyan-500 text-slate-950 font-bold text-xs shadow-md"
              >
                Explore Scriptures
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {bookmarks.map((bm) => (
                <div
                  key={bm.id}
                  className="bg-slate-950/80 border border-cyan-500/30 p-5 rounded-2xl space-y-3 shadow-md flex flex-col justify-between"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-cyan-300 font-mono">
                        📖 {bm.title || `${bm.bookName} ${bm.chapter}:${bm.verse}`}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">{bm.createdAt}</span>
                    </div>

                    <p className="text-xs text-slate-200 italic leading-relaxed">"{bm.verseText}"</p>

                    {bm.note && (
                      <div className="p-2.5 rounded-xl bg-cyan-950/60 border border-cyan-500/20 text-xs text-cyan-100 space-y-1">
                        <span className="text-[10px] font-bold text-cyan-400 uppercase font-mono">Revelation Note:</span>
                        <p>{bm.note}</p>
                      </div>
                    )}

                    {bm.tags && bm.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {bm.tags.map((tag, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 text-[10px] font-mono"
                          >
                            #{tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-slate-800">
                    <button
                      onClick={() => {
                        setSelectedBookId(bm.bookId);
                        setSelectedChapterNumber(bm.chapter);
                        setActiveTab('reader');
                      }}
                      className="text-xs font-bold text-cyan-300 hover:text-cyan-200 flex items-center space-x-1"
                    >
                      <span>Jump to Chapter</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => offlineCache.removeBibleBookmark(bm.id)}
                      className="p-1.5 text-slate-500 hover:text-rose-400 transition-colors"
                      title="Remove bookmark"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Offline Search Tab */}
      {activeTab === 'search' && (
        <div className="bg-slate-900/90 border-2 border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-xl space-y-5">
          <div className="space-y-2">
            <h3 className="text-xl font-bold font-serif text-amber-100 flex items-center space-x-2">
              <Search className="w-5 h-5 text-purple-400" />
              <span>Instant Offline Scripture Keyword Search</span>
            </h3>
            <p className="text-xs text-slate-400">Search through all cached books, verses, and prophetic notes with zero latency.</p>
          </div>

          <div className="relative">
            <Search className="w-5 h-5 text-amber-400 absolute left-4 top-3.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search words (e.g., 'shepherd', 'glory', 'peace', 'wealth', 'healing')..."
              className="w-full bg-slate-950 border border-amber-500/30 rounded-2xl pl-12 pr-4 py-3.5 text-xs text-amber-100 placeholder-slate-500 focus:outline-none focus:border-amber-400 shadow-inner"
            />
          </div>

          {searchQuery.trim().length > 1 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Search results for <strong>"{searchQuery}"</strong></span>
                <span className="font-mono text-amber-300 font-bold">{searchResults.length} verses found</span>
              </div>

              <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
                {searchResults.map((res, idx) => (
                  <div
                    key={idx}
                    onClick={() => {
                      setSelectedBookId(res.book.id);
                      setSelectedChapterNumber(res.chapter);
                      setActiveTab('reader');
                    }}
                    className="p-4 rounded-2xl bg-slate-950/70 border border-amber-500/20 hover:border-amber-400/60 transition-all cursor-pointer space-y-1.5 group"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-amber-300 font-mono">
                        {res.book.name} {res.chapter}:{res.verse.verseNumber}
                      </span>
                      <span className="text-[10px] text-slate-500 group-hover:text-amber-300 flex items-center space-x-1">
                        <span>Open in Reader</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                    <p className="text-xs text-slate-200 leading-relaxed">
                      {res.verse.text}
                    </p>
                    {res.verse.propheticNote && (
                      <p className="text-[11px] text-amber-400/90 font-mono italic">
                        🔥 Prophetic: {res.verse.propheticNote}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
