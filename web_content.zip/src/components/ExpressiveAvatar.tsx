import React, { useEffect, useState } from "react";
import { EMOTIONS, EmotionKey } from "../types";
import { Volume2, VolumeX, Mic, Heart, Sparkles } from "lucide-react";

interface ExpressiveAvatarProps {
  personaName: string;
  personaRole: string;
  emotionKey: EmotionKey;
  emotionIntensity: number;
  innerThought: string;
  gesture: string;
  isListening: boolean;
  isThinking: boolean;
  isSpeaking: boolean;
  audioLevel: number; // 0 to 1
  voiceEnabled: boolean;
  onToggleVoice: () => void;
  onAffectionTap: () => void;
}

export const ExpressiveAvatar: React.FC<ExpressiveAvatarProps> = ({
  personaName,
  personaRole,
  emotionKey,
  emotionIntensity,
  innerThought,
  gesture,
  isListening,
  isThinking,
  isSpeaking,
  audioLevel,
  voiceEnabled,
  onToggleVoice,
  onAffectionTap,
}) => {
  const emotion = EMOTIONS[emotionKey] || EMOTIONS.empathetic;
  const [isBlinking, setIsBlinking] = useState(false);
  const [heartBurst, setHeartBurst] = useState(false);

  // Natural eye blinking interval
  useEffect(() => {
    const interval = setInterval(() => {
      setIsBlinking(true);
      setTimeout(() => setIsBlinking(false), 160);
    }, 3800);
    return () => clearInterval(interval);
  }, []);

  const handleAvatarClick = () => {
    setHeartBurst(true);
    onAffectionTap();
    setTimeout(() => setHeartBurst(false), 1200);
  };

  // Compute dynamic mouth path based on speaking audioLevel & emotionKey
  const getMouthPath = () => {
    if (isSpeaking) {
      const openAmount = Math.max(6, Math.min(26, audioLevel * 34 + 8));
      return `M 76 126 Q 100 ${126 + openAmount} 124 126 Q 100 ${
        126 - openAmount * 0.35
      } 76 126 Z`;
    }
    if (isListening) {
      return "M 82 126 Q 100 134 118 126";
    }
    switch (emotionKey) {
      case "joyful":
        return "M 72 122 Q 100 146 128 122";
      case "excited":
        return "M 74 120 Q 100 148 126 120 Z";
      case "empathetic":
        return "M 80 127 Q 100 136 120 127";
      case "thoughtful":
        return "M 85 128 Q 102 125 115 128";
      case "curious":
        return "M 84 126 Q 100 135 116 124";
      case "touched":
        return "M 78 125 Q 100 140 122 125";
      case "calm":
      default:
        return "M 78 125 Q 100 137 122 125";
    }
  };

  // Compute eyebrow geometry based on emotion
  const getEyebrows = () => {
    if (isListening) {
      // Raised attentive brows
      return {
        left: "M 56 72 Q 70 63 82 70",
        right: "M 118 70 Q 130 63 144 72",
      };
    }
    switch (emotionKey) {
      case "empathetic":
      case "touched":
        return {
          left: "M 56 75 Q 70 68 82 76",
          right: "M 118 76 Q 130 68 144 75",
        };
      case "excited":
      case "curious":
        return {
          left: "M 56 70 Q 70 60 82 69",
          right: "M 118 67 Q 130 58 144 70",
        };
      case "thoughtful":
        return {
          left: "M 56 74 Q 70 70 82 73",
          right: "M 118 69 Q 130 62 144 71",
        };
      default:
        return {
          left: "M 56 73 Q 70 65 82 72",
          right: "M 118 72 Q 130 65 144 73",
        };
    }
  };

  const brows = getEyebrows();
  const dynamicScale = isSpeaking
    ? 1 + Math.min(0.08, audioLevel * 0.12)
    : isListening
    ? 1.03
    : 1;

  return (
    <div className="relative flex flex-col justify-between rounded-2xl border border-slate-800/90 bg-[#111726] p-5 lg:p-6">
      {/* Top Status & Voice Toggle */}
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span>{personaRole}</span>
            <span aria-hidden="true">·</span>
            <span className={emotion.textClass}>{emotion.labelBn}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums text-slate-400">
              {emotionIntensity}% তীব্রতা
            </span>
          </div>
          <div className="flex items-center gap-2 mt-1">
            <h2 className="text-xl font-semibold tracking-tight text-slate-100">
              {personaName}
            </h2>
            <span className="flex items-center gap-1 rounded-md border border-amber-500/40 bg-amber-500/10 px-1.5 py-0.5 text-[10px] font-mono font-semibold text-amber-300">
              <span className="h-1.5 w-1.5 rounded-full bg-amber-400 animate-pulse" />
              <span>AI</span>
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={onToggleVoice}
          className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
            voiceEnabled
              ? "border-amber-500/40 bg-amber-500/10 text-amber-200 hover:bg-amber-500/20"
              : "border-slate-700 bg-slate-800/70 text-slate-400 hover:text-slate-200"
          }`}
          title={voiceEnabled ? "কণ্ঠস্বর চালু আছে" : "কণ্ঠস্বর বন্ধ আছে"}
        >
          {voiceEnabled ? (
            <>
              <Volume2 className="h-3.5 w-3.5 text-amber-400" />
              <span>কণ্ঠস্বর চালু</span>
            </>
          ) : (
            <>
              <VolumeX className="h-3.5 w-3.5" />
              <span>নীরব</span>
            </>
          )}
        </button>
      </div>

      {/* Central Interactive Companion Stage */}
      <div className="relative my-4 flex flex-col items-center justify-center py-3">
        {/* Ambient Emotion Aura */}
        <div
          className={`pointer-events-none absolute h-56 w-56 rounded-full bg-radial ${emotion.glowClass} blur-2xl transition-all duration-500`}
          style={{
            transform: `scale(${
              isSpeaking || isListening ? 1.15 + audioLevel * 0.25 : 1
            })`,
          }}
        />

        {/* Soundwave Pulse Rings when Speaking or Listening */}
        {(isSpeaking || isListening) && (
          <>
            <div
              className="pointer-events-none absolute h-48 w-48 rounded-full border animate-pulse-ring"
              style={{ borderColor: `${emotion.accentHex}55` }}
            />
            <div
              className="pointer-events-none absolute h-56 w-56 rounded-full border animate-pulse-ring"
              style={{
                borderColor: `${emotion.accentHex}33`,
                animationDelay: "0.6s",
              }}
            />
          </>
        )}

        {/* Clickable Expressive Face SVG */}
        <button
          type="button"
          onClick={handleAvatarClick}
          aria-label="বন্ধুকে ভালোবাসা জানাও"
          className="group relative z-10 cursor-pointer rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-400"
          style={{
            transform: `scale(${dynamicScale})`,
            transition: "transform 150ms cubic-bezier(0.16, 1, 0.3, 1)",
          }}
        >
          <svg
            viewBox="0 0 200 200"
            className="h-44 w-44 lg:h-48 lg:w-48 animate-float drop-shadow-xl"
          >
            <defs>
              <radialGradient id="faceGrad" cx="35%" cy="30%" r="70%">
                <stop offset="0%" stopColor="#1E293B" />
                <stop offset="65%" stopColor="#0F172A" />
                <stop offset="100%" stopColor="#090D16" />
              </radialGradient>
              <linearGradient id="rimGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor={emotion.accentHex} stopOpacity="0.85" />
                <stop offset="50%" stopColor="#38BDF8" stopOpacity="0.35" />
                <stop offset="100%" stopColor={emotion.accentHex} stopOpacity="0.7" />
              </linearGradient>
            </defs>

            {/* Outer Warm Halo Ring */}
            <circle
              cx="100"
              cy="100"
              r="90"
              fill="url(#faceGrad)"
              stroke="url(#rimGrad)"
              strokeWidth={isSpeaking || isListening ? "3.5" : "2"}
            />

            {/* Subtle Inner Cheek Glow / Blush */}
            <ellipse
              cx="60"
              cy="112"
              rx="14"
              ry="8"
              fill={emotion.accentHex}
              opacity={
                emotionKey === "joyful" ||
                emotionKey === "touched" ||
                emotionKey === "excited" ||
                heartBurst
                  ? "0.35"
                  : "0.16"
              }
            />
            <ellipse
              cx="140"
              cy="112"
              rx="14"
              ry="8"
              fill={emotion.accentHex}
              opacity={
                emotionKey === "joyful" ||
                emotionKey === "touched" ||
                emotionKey === "excited" ||
                heartBurst
                  ? "0.35"
                  : "0.16"
              }
            />

            {/* Eyebrows */}
            <path
              d={brows.left}
              fill="none"
              stroke={emotion.accentHex}
              strokeWidth="3.2"
              strokeLinecap="round"
            />
            <path
              d={brows.right}
              fill="none"
              stroke={emotion.accentHex}
              strokeWidth="3.2"
              strokeLinecap="round"
            />

            {/* Eyes */}
            {isBlinking ? (
              <>
                <path
                  d="M 58 94 Q 70 98 82 94"
                  fill="none"
                  stroke="#F8FAFC"
                  strokeWidth="3.5"
                  strokeLinecap="round"
                />
                <path
                  d="M 118 94 Q 130 98 142 94"
                  fill="none"
                  stroke="#F8FAFC"
                  strokeWidth="3.5"
                  strokeLinecap="round"
                />
              </>
            ) : emotionKey === "joyful" || heartBurst ? (
              // Happy smiling arc eyes
              <>
                <path
                  d="M 58 96 Q 70 80 82 96"
                  fill="none"
                  stroke="#F8FAFC"
                  strokeWidth="4"
                  strokeLinecap="round"
                />
                <path
                  d="M 118 96 Q 130 80 142 96"
                  fill="none"
                  stroke="#F8FAFC"
                  strokeWidth="4"
                  strokeLinecap="round"
                />
              </>
            ) : (
              // Expressive luminous eyes with pupil gaze
              <>
                <circle
                  cx={isThinking ? "68" : "70"}
                  cy={isThinking ? "90" : "93"}
                  r={emotionKey === "excited" || emotionKey === "curious" ? "11" : "9.5"}
                  fill="#F8FAFC"
                />
                <circle
                  cx={isThinking ? "66" : "72"}
                  cy={isThinking ? "87" : "91"}
                  r="3.8"
                  fill={emotion.accentHex}
                />
                <circle
                  cx={isThinking ? "65" : "73"}
                  cy={isThinking ? "86" : "89"}
                  r="1.8"
                  fill="#FFFFFF"
                />

                <circle
                  cx={isThinking ? "128" : "130"}
                  cy={isThinking ? "90" : "93"}
                  r={emotionKey === "excited" || emotionKey === "curious" ? "11" : "9.5"}
                  fill="#F8FAFC"
                />
                <circle
                  cx={isThinking ? "126" : "132"}
                  cy={isThinking ? "87" : "91"}
                  r="3.8"
                  fill={emotion.accentHex}
                />
                <circle
                  cx={isThinking ? "125" : "133"}
                  cy={isThinking ? "86" : "89"}
                  r="1.8"
                  fill="#FFFFFF"
                />
              </>
            )}

            {/* Mouth */}
            <path
              d={getMouthPath()}
              fill={
                isSpeaking || emotionKey === "excited"
                  ? `${emotion.accentHex}44`
                  : "none"
              }
              stroke="#F8FAFC"
              strokeWidth="3.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>

          {/* Affection Heart Burst */}
          {heartBurst && (
            <div className="pointer-events-none absolute -top-2 right-2 flex items-center gap-1 text-rose-400 animate-bounce">
              <Heart className="h-5 w-5 fill-rose-400" />
            </div>
          )}
        </button>

        {/* Live Activity Status Line */}
        <div className="mt-2 flex items-center gap-2 text-xs text-slate-300">
          {isListening ? (
            <>
              <Mic className="h-3.5 w-3.5 text-rose-400 animate-pulse" />
              <span className="font-medium text-rose-300">
                মনোযোগ দিয়ে তোমার কথা শুনছি...
              </span>
            </>
          ) : isThinking ? (
            <>
              <Sparkles className="h-3.5 w-3.5 text-amber-300 animate-spin" />
              <span className="text-amber-200">
                অনুভূতিটা বোঝার চেষ্টা করছি...
              </span>
            </>
          ) : isSpeaking ? (
            <>
              <Volume2 className="h-3.5 w-3.5 text-emerald-400 animate-pulse" />
              <span className="text-emerald-300">
                তোমার সাথে কথা বলছি...
              </span>
            </>
          ) : (
            <span className="text-slate-400">{gesture}</span>
          )}
        </div>
      </div>

      {/* Thunder's Transparent Inner Heart Feeling ("মনের অনুভূতি") */}
      <div className="border-t border-slate-800/80 pt-4">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span>Thunder ভাইয়ের মনের কথা (Inner Feeling)</span>
          <span className={emotion.textClass}>{emotion.labelEn}</span>
        </div>
        <p className="mt-1.5 text-sm leading-relaxed text-slate-200 italic">
          “{innerThought}”
        </p>
      </div>
    </div>
  );
};
