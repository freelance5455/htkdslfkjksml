export function BrandMark({ className = "h-11 w-11" }: { className?: string }) {
  return (
    <svg viewBox="0 0 52 52" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="brand-brass" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#f5dba4" />
          <stop offset="48%" stopColor="#e3b974" />
          <stop offset="100%" stopColor="#b98b4a" />
        </linearGradient>
      </defs>
      <circle cx="26" cy="26" r="24.5" fill="#142e28" stroke="url(#brand-brass)" strokeWidth="1.4" />
      <circle cx="26" cy="26" r="20.5" fill="none" stroke="url(#brand-brass)" strokeWidth="0.6" strokeDasharray="1 3.4" opacity="0.8" />
      <path d="M12 36V26.5A14 14 0 0 1 40 26.5V36" fill="none" stroke="url(#brand-brass)" strokeWidth="1.5" strokeLinecap="round" />
      <circle cx="26" cy="26" r="5.2" fill="url(#brand-brass)" opacity="0.22" />
      <circle cx="26" cy="26" r="3.2" fill="#f5dba4" />
      <path d="M26 39V30" stroke="#f5dba4" strokeWidth="1.3" strokeLinecap="round" />
      <path d="M26 31.5C22.5 30 21 27.5 21 24.5C24 25.5 26 28 26 31.5Z" fill="#e3b974" />
      <path d="M26 31.5C29.5 30 31 27.5 31 24.5C28 25.5 26 28 26 31.5Z" fill="#e3b974" opacity="0.75" />
      <path d="M7 39.5H45" stroke="url(#brand-brass)" strokeWidth="1.2" strokeLinecap="round" opacity="0.65" />
      <path d="M23 6.2L24.2 8.7L26 9L24.2 9.4L23 11.9L21.8 9.4L20 9L21.8 8.7Z" fill="#f5dba4" opacity="0.9" />
    </svg>
  );
}

export function Ornament({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 120 12" className={className} aria-hidden="true" fill="none">
      <path d="M2 6H46" stroke="currentColor" strokeWidth="1" strokeLinecap="round" opacity="0.5" />
      <path d="M74 6H118" stroke="currentColor" strokeWidth="1" strokeLinecap="round" opacity="0.5" />
      <path d="M52 6L60 1L68 6L60 11Z" stroke="currentColor" strokeWidth="1" />
      <circle cx="60" cy="6" r="1.4" fill="currentColor" />
    </svg>
  );
}

export function DuneRings({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 300 300" className={className} fill="none" aria-hidden="true">
      {[0, 1, 2, 3, 4].map((i) => (
        <path
          key={i}
          d={`M${20 + i * 6} ${180 - i * 22}C${90 + i * 4} ${120 - i * 16}, ${200 - i * 4} ${148 - i * 12}, ${284 - i * 6} ${92 - i * 14}`}
          stroke="currentColor"
          strokeWidth="0.8"
          opacity={0.6 - i * 0.1}
        />
      ))}
    </svg>
  );
}
