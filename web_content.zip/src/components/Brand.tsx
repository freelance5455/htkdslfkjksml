import { Send } from "lucide-react";

export function Brand({ dark = false }: { dark?: boolean }) {
  return (
    <a href="#top" className={`group inline-flex items-center gap-3 ${dark ? "text-white" : "text-ink"}`} aria-label="MT Radar — на главную">
      <span className="relative grid h-10 w-10 place-items-center overflow-hidden rounded-[14px] bg-accent text-ink shadow-[0_8px_30px_rgba(192,255,114,0.18)] transition-transform duration-300 group-hover:-rotate-6">
        <Send size={18} strokeWidth={2.4} className="-translate-x-px translate-y-px" />
        <span className="absolute inset-x-2 bottom-1 h-px bg-ink/20" />
      </span>
      <span className="flex items-baseline gap-2">
        <span className="font-display text-[17px] font-bold tracking-[-0.04em]">MT/RADAR</span>
        <span className={`rounded-full border px-1.5 py-0.5 text-[8px] font-bold tracking-[0.14em] ${dark ? "border-white/15 text-white/45" : "border-ink/15 text-ink/45"}`}>BETA</span>
      </span>
    </a>
  );
}
