import { forwardRef, useImperativeHandle, useRef } from 'react';
import { EntityRank, OverheadNameplate } from '../game/types';

export interface EntityNameplatesHandle {
  update: (items: OverheadNameplate[]) => void;
}

const POOL_SIZE = 14;

interface SlotRefs {
  root: HTMLDivElement | null;
  badge: HTMLSpanElement | null;
  name: HTMLSpanElement | null;
  lvl: HTMLSpanElement | null;
  track: HTMLDivElement | null;
  trail: HTMLDivElement | null;
  fill: HTMLDivElement | null;
}

function getRankTag(item: OverheadNameplate): { text: string; bg: string; fg: string } | null {
  if (item.isRebel) return { text: 'متمرد!', bg: '#991b1b', fg: '#fecaca' };
  if (item.isSummon) return { text: 'حليف', bg: '#0e7490', fg: '#cffafe' };
  const rank: EntityRank = item.rank;
  if (rank === 'boss' || item.category === 'boss') {
    return {
      text: item.phase === 2 ? 'زعيم ⚡2' : 'زعيم',
      bg: '#9f1239',
      fg: '#fde68a',
    };
  }
  if (rank === 'legendary') return { text: 'أسطوري', bg: '#6b21a8', fg: '#f3e8ff' };
  if (rank === 'elite') return { text: 'نخبة', bg: '#b45309', fg: '#fef3c7' };
  if (rank === 'rare') return { text: 'نادر', bg: '#0369a1', fg: '#e0f2fe' };
  return null;
}

function getHpBarColor(pct: number, isSummon: boolean, isRebel?: boolean): string {
  if (isRebel) return '#dc2626';
  if (isSummon) return '#22d3ee';
  if (pct > 0.6) return '#22c55e';
  if (pct > 0.3) return '#f59e0b';
  return '#ef4444';
}

export const EntityNameplates = forwardRef<EntityNameplatesHandle>(function EntityNameplates(_, ref) {
  const slotsRef = useRef<SlotRefs[]>(
    Array.from({ length: POOL_SIZE }, () => ({
      root: null,
      badge: null,
      name: null,
      lvl: null,
      track: null,
      trail: null,
      fill: null,
    })),
  );

  useImperativeHandle(ref, () => ({
    update(items: OverheadNameplate[]) {
      const count = Math.min(items.length, POOL_SIZE);
      for (let i = 0; i < POOL_SIZE; i++) {
        const slot = slotsRef.current[i];
        if (!slot.root) continue;

        if (i >= count) {
          if (slot.root.style.display !== 'none') {
            slot.root.style.display = 'none';
          }
          continue;
        }

        const item = items[i];
        if (slot.root.style.display !== 'flex') {
          slot.root.style.display = 'flex';
        }
        slot.root.style.transform = `translate3d(${item.screenX.toFixed(1)}px, ${item.screenY.toFixed(1)}px, 0) translate(-50%, -100%) scale(${item.scale.toFixed(3)})`;
        slot.root.style.opacity = item.opacity.toFixed(2);
        slot.root.style.zIndex = item.isTargeted ? '9' : item.category === 'boss' ? '8' : '7';

        if (slot.name && slot.name.textContent !== item.nameAr) {
          slot.name.textContent = item.nameAr;
        }

        const lvlText = `Lv.${item.level}`;
        if (slot.lvl && slot.lvl.textContent !== lvlText) {
          slot.lvl.textContent = lvlText;
        }

        const tag = getRankTag(item);
        if (slot.badge) {
          if (tag) {
            slot.badge.style.display = 'inline-block';
            if (slot.badge.textContent !== tag.text) slot.badge.textContent = tag.text;
            slot.badge.style.backgroundColor = tag.bg;
            slot.badge.style.color = tag.fg;
          } else {
            slot.badge.style.display = 'none';
          }
        }

        const maxHp = Math.max(1, item.maxHp);
        const pct = Math.max(0, Math.min(1, item.displayHp / maxHp));
        const trailPct = Math.max(pct, Math.min(1, item.trailHp / maxHp));

        if (slot.track) {
          const isLarge = item.category === 'boss' || item.rank === 'elite' || item.rank === 'legendary';
          slot.track.style.width = isLarge ? '104px' : '76px';
          slot.track.style.height = isLarge ? '6px' : '5px';
          slot.track.style.borderColor = item.isTargeted
            ? 'rgba(251, 191, 36, 0.95)'
            : item.category === 'boss'
              ? 'rgba(244, 63, 94, 0.85)'
              : 'rgba(15, 23, 42, 0.95)';
        }
        if (slot.trail) {
          slot.trail.style.width = `${(trailPct * 100).toFixed(1)}%`;
        }
        if (slot.fill) {
          slot.fill.style.width = `${(pct * 100).toFixed(1)}%`;
          slot.fill.style.backgroundColor = getHpBarColor(pct, item.isSummon, item.isRebel);
        }
      }
    },
  }));

  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden" style={{ zIndex: 7 }}>
      {Array.from({ length: POOL_SIZE }, (_, idx) => (
        <div
          key={idx}
          ref={(el) => {
            slotsRef.current[idx].root = el;
          }}
          dir="rtl"
          style={{
            display: 'none',
            position: 'absolute',
            left: 0,
            top: 0,
            flexDirection: 'column',
            alignItems: 'center',
            gap: '2px',
            willChange: 'transform, opacity',
            transformOrigin: 'bottom center',
          }}
        >
          <div
            className="flex items-center gap-1 whitespace-nowrap px-1.5 py-0.5 rounded bg-slate-950/75 border border-slate-800/80"
            style={{
              textShadow: '0 1px 2px rgba(0,0,0,0.95)',
              boxShadow: '0 2px 6px rgba(0,0,0,0.45)',
            }}
          >
            <span
              ref={(el) => {
                slotsRef.current[idx].badge = el;
              }}
              className="rounded px-1 text-[9px] font-extrabold leading-tight"
              style={{ display: 'none' }}
            />
            <span
              ref={(el) => {
                slotsRef.current[idx].name = el;
              }}
              className="text-[11px] font-bold text-slate-50 leading-tight"
            />
            <span
              ref={(el) => {
                slotsRef.current[idx].lvl = el;
              }}
              dir="ltr"
              className="font-mono text-[9px] font-bold text-amber-300 leading-tight"
            />
          </div>

          <div
            ref={(el) => {
              slotsRef.current[idx].track = el;
            }}
            dir="ltr"
            className="relative overflow-hidden rounded-full border bg-slate-950/90 shadow"
            style={{ width: '76px', height: '5px' }}
          >
            <div
              ref={(el) => {
                slotsRef.current[idx].trail = el;
              }}
              className="absolute inset-y-0 left-0 bg-amber-200/85"
              style={{ width: '100%' }}
            />
            <div
              ref={(el) => {
                slotsRef.current[idx].fill = el;
              }}
              className="absolute inset-y-0 left-0"
              style={{ width: '100%', backgroundColor: '#22c55e' }}
            />
          </div>
        </div>
      ))}
    </div>
  );
});
