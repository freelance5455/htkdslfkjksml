import React from 'react';
import {
  X,
  Phone,
  MessageSquare,
  Clock,
  RefreshCw,
  Trash2,
  ShieldCheck,
  Send,
} from 'lucide-react';
import { PhoneNumber, SmsMessage } from '../types/index.ts';
import { CountdownBadge } from './CountdownBadge.tsx';
import { OtpChip } from './OtpChip.tsx';

interface SmsThreadModalProps {
  phoneNumber: PhoneNumber;
  messages: SmsMessage[];
  onClose: () => void;
  onRenew: (id: string) => void;
  onRelease: (id: string) => void;
  onSimulateIncomingSms?: (numberId: string) => void;
}

export const SmsThreadModal: React.FC<SmsThreadModalProps> = ({
  phoneNumber,
  messages,
  onClose,
  onRenew,
  onRelease,
  onSimulateIncomingSms,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-lg max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-slate-800">
        {/* HEADER */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between gap-3 bg-blue-50/60">
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base">{phoneNumber.flag}</span>
                <span className="text-base font-bold font-mono text-blue-700">{phoneNumber.number}</span>
              </div>
              <div className="text-xs text-slate-500">
                {phoneNumber.countryName} • {phoneNumber.receivedSmsQty} SMS received
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => onRenew(phoneNumber.id)}
              className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-blue-50 text-xs font-bold text-blue-700 border border-slate-200 hover:border-blue-300 flex items-center gap-1 transition-colors shadow-2xs"
              title="Renew for 24h (15 credits)"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Renew</span>
            </button>
            <button
              onClick={() => onRelease(phoneNumber.id)}
              className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
              title="Release Number"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* STATUS BAR */}
        <div className="bg-slate-50 px-4 py-2 border-b border-slate-200 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-500 font-medium">Rental Expiry:</span>
            <CountdownBadge expiresAt={phoneNumber.expiresAt} showExtendButton={false} />
          </div>

          {phoneNumber.receivedSmsQty === 0 && !phoneNumber.refundIssued && (
            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-700 bg-blue-100/60 px-2 py-0.5 rounded-full">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Auto-Refund Guard</span>
            </span>
          )}
        </div>

        {/* SMS MESSAGES FEED */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.length === 0 ? (
            <div className="text-center py-12 px-4">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center mx-auto mb-3">
                <MessageSquare className="w-6 h-6 animate-pulse" />
              </div>
              <h4 className="text-sm font-bold text-slate-900 mb-1">Waiting for incoming SMS...</h4>
              <p className="text-xs text-slate-500 max-w-xs mx-auto mb-4">
                Use this number on WhatsApp, Telegram, Uber, Discord, or any service. Verification SMS will arrive here instantly.
              </p>
              {onSimulateIncomingSms && (
                <button
                  onClick={() => onSimulateIncomingSms(phoneNumber.id)}
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold inline-flex items-center gap-2 transition-colors cursor-pointer shadow-md shadow-blue-600/20"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send Test SMS to this Line</span>
                </button>
              )}
            </div>
          ) : (
            messages.map((sms) => (
              <div
                key={sms.id}
                className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2 shadow-xs"
              >
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-blue-700">{sms.senderName || sms.fromNumber}</span>
                    <span className="text-slate-500 font-mono text-[11px]">({sms.fromNumber})</span>
                  </div>
                  <span className="text-[11px] text-slate-500 flex items-center gap-1 font-mono">
                    <Clock className="w-3 h-3 text-blue-600" />
                    {new Date(sms.receivedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                <p className="text-xs text-slate-800 leading-relaxed font-sans">{sms.text}</p>

                {sms.extractedOtp && (
                  <div className="pt-1">
                    <OtpChip code={sms.extractedOtp} label="Verification Code" />
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
