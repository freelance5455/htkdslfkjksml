import React, { useState, useEffect } from 'react';
import { 
  X, 
  Volume2, 
  Play, 
  Sparkles, 
  TrendingUp, 
  TrendingDown, 
  Bell, 
  Check, 
  Loader2,
  Clock,
  Repeat,
  Monitor,
  BellRing
} from 'lucide-react';
import { 
  AssetData, 
  ActiveVoiceAlert, 
  SoundEffectType, 
  AudioSettings,
  VoiceAlertPreset 
} from '../types/market';
import { VOICE_ALERT_LIBRARY, SOUND_EFFECT_PRESETS, formatAlertScript } from '../services/voiceLibrary';
import { playChimeSound, executeVoiceAlert } from '../services/audioEngine';
import { fetchGeminiVoiceSuggestions } from '../services/marketApi';

interface VoiceAlertModalProps {
  isOpen: boolean;
  onClose: () => void;
  asset: AssetData | null;
  audioSettings: AudioSettings;
  onSaveAlert: (alert: Omit<ActiveVoiceAlert, 'id' | 'createdAt' | 'triggerCount'>) => void;
  initialPreset?: VoiceAlertPreset | null;
  language: 'fr' | 'en';
}

export const VoiceAlertModal: React.FC<VoiceAlertModalProps> = ({
  isOpen,
  onClose,
  asset,
  audioSettings,
  onSaveAlert,
  initialPreset,
  language,
}) => {
  const [condition, setCondition] = useState<'above' | 'below'>('above');
  const [targetValue, setTargetValue] = useState<number>(() => {
    return asset ? parseFloat((asset.price * 1.02).toFixed(asset.price > 100 ? 2 : 4)) : 0;
  });
  const [selectedChime, setSelectedChime] = useState<SoundEffectType>('bullish');
  const [voiceScript, setVoiceScript] = useState<string>('');
  const [persona, setPersona] = useState<ActiveVoiceAlert['voicePersona']>(audioSettings.selectedPersona);
  const [isGeneratingAiScript, setIsGeneratingAiScript] = useState<boolean>(false);
  const [isAuditioning, setIsAuditioning] = useState<boolean>(false);

  // Repetition Interval & Ceiling options
  const [repeatIntervalMinutes, setRepeatIntervalMinutes] = useState<number>(5);
  const [repeatLimit, setRepeatLimit] = useState<number | 'unlimited'>(3);
  const [screenAlertEffect, setScreenAlertEffect] = useState<'flash_strobe' | 'radar_ping' | 'floating_pip' | 'standard'>('flash_strobe');
  const [sendNotification, setSendNotification] = useState<boolean>(true);

  // Sync script when preset or asset changes
  useEffect(() => {
    if (!asset) return;
    if (initialPreset) {
      setVoiceScript(formatAlertScript(initialPreset.script, asset.symbol, targetValue, asset.price));
      setSelectedChime(initialPreset.defaultChime);
      if (initialPreset.category === 'dump') {
        setCondition('below');
      } else {
        setCondition('above');
      }
    } else {
      const defaultScript = language === 'fr'
        ? `Alerte ${asset.symbol} ! Seuil de ${targetValue.toLocaleString()} dollars atteint.`
        : `Alert on ${asset.symbol}! Target price of ${targetValue.toLocaleString()} reached.`;
      setVoiceScript(defaultScript);
    }
  }, [initialPreset, asset?.id, language]);

  if (!isOpen || !asset) return null;

  // Adjust target price with shortcut buttons
  const applyPctChange = (pct: number) => {
    const newPrice = parseFloat((asset.price * (1 + pct / 100)).toFixed(asset.price > 100 ? 2 : 4));
    setTargetValue(newPrice);
    if (pct < 0) {
      setCondition('below');
      setSelectedChime('bearish');
    } else {
      setCondition('above');
      setSelectedChime('bullish');
    }
    if (language === 'fr') {
      setVoiceScript(`Alerte ${asset.symbol} ! Cours atteint à ${newPrice.toLocaleString()} dollars.`);
    } else {
      setVoiceScript(`Target hit on ${asset.symbol} at ${newPrice.toLocaleString()} dollars.`);
    }
  };

  const handleTestAlert = async () => {
    setIsAuditioning(true);
    await executeVoiceAlert(selectedChime, voiceScript, audioSettings, language);
    setIsAuditioning(false);
  };

  const handleGeminiGenerateScript = async () => {
    setIsGeneratingAiScript(true);
    try {
      const suggestions = await fetchGeminiVoiceSuggestions(
        asset.symbol,
        targetValue,
        condition === 'above' ? 'resistance breakout' : 'support breakdown',
        'urgent dynamic institutional trader alert',
        language
      );
      if (suggestions && suggestions.length > 0) {
        setVoiceScript(suggestions[0].script);
        if (suggestions[0].chime) {
          setSelectedChime(suggestions[0].chime);
        }
      }
    } catch (e) {
      console.warn('Gemini script generation error', e);
    } finally {
      setIsGeneratingAiScript(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveAlert({
      assetId: asset.id,
      assetSymbol: asset.symbol,
      assetName: asset.name,
      condition,
      targetValue,
      baselinePrice: asset.price,
      voiceScript,
      soundChime: selectedChime,
      voicePersona: persona,
      enabled: true,
      repeatMode: repeatLimit === 1 ? 'once' : 'repeat',
      repeatIntervalMinutes,
      repeatLimit,
      screenAlertEffect,
      sendSystemNotification: sendNotification,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-slate-950 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center">
              <Bell className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white font-['Chakra_Petch']">
                CONFIGURER ALERTE VOCALE AVANCÉE
              </h3>
              <p className="text-xs text-slate-400">
                {asset.name} ({asset.symbol}) &bull; Cours actuel: ${asset.price.toLocaleString()}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto flex-1 text-slate-200">
          
          {/* Condition & Target Price */}
          <div className="space-y-2">
            <label className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wide">
              1. Seuil de Déclenchement & Sens
            </label>
            
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  setCondition('above');
                  setSelectedChime('bullish');
                }}
                className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer ${
                  condition === 'above'
                    ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <span>Prix &ge; Supérieur à (Hausse)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setCondition('below');
                  setSelectedChime('bearish');
                }}
                className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer ${
                  condition === 'below'
                    ? 'bg-rose-500/20 border-rose-500/50 text-rose-300'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <TrendingDown className="w-4 h-4 text-rose-400" />
                <span>Prix &le; Inférieur à (Baisse)</span>
              </button>
            </div>

            {/* Price Input */}
            <div className="relative mt-2">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500 font-mono font-bold">
                $
              </div>
              <input
                type="number"
                step="any"
                value={targetValue}
                onChange={(e) => setTargetValue(parseFloat(e.target.value) || 0)}
                className="w-full pl-8 pr-4 py-2 bg-slate-900 border border-slate-700/80 rounded-xl text-white font-mono text-base font-bold focus:outline-none focus:border-amber-500"
                required
              />
            </div>

            {/* Quick shortcuts */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-[10px] text-slate-500 font-mono">CALCUL RAPIDE:</span>
              {[
                { label: '+1%', val: 1 },
                { label: '+2%', val: 2 },
                { label: '+5%', val: 5 },
                { label: '-1%', val: -1 },
                { label: '-2%', val: -2 },
                { label: '-5%', val: -5 },
              ].map((btn) => (
                <button
                  key={btn.label}
                  type="button"
                  onClick={() => applyPctChange(btn.val)}
                  className={`px-2 py-0.8 rounded text-[11px] font-mono font-semibold transition-colors cursor-pointer ${
                    btn.val > 0
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/20'
                      : 'bg-rose-500/10 text-rose-400 border border-rose-500/30 hover:bg-rose-500/20'
                  }`}
                >
                  {btn.label}
                </button>
              ))}
            </div>
          </div>

          {/* Automated Repeat Interval & Redundancy Ceiling */}
          <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
            <label className="text-xs font-mono font-bold text-amber-400 uppercase tracking-wide flex items-center gap-1.5">
              <Repeat className="w-3.5 h-3.5 text-amber-400" />
              <span>2. Répétition Automatique & Plafond de Redondance</span>
            </label>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <span className="text-slate-400 text-[11px] block mb-1">Fréquence de rappel :</span>
                <select
                  value={repeatIntervalMinutes}
                  onChange={(e) => setRepeatIntervalMinutes(Number(e.target.value))}
                  className="w-full p-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono"
                >
                  <option value={1}>Toutes les 1 min</option>
                  <option value={5}>Toutes les 5 min</option>
                  <option value={15}>Toutes les 15 min</option>
                  <option value={30}>Toutes les 30 min</option>
                  <option value={60}>Toutes les 1 heure</option>
                </select>
              </div>

              <div>
                <span className="text-slate-400 text-[11px] block mb-1">Plafond de redondance :</span>
                <select
                  value={repeatLimit}
                  onChange={(e) => {
                    const val = e.target.value === 'unlimited' ? 'unlimited' : Number(e.target.value);
                    setRepeatLimit(val);
                  }}
                  className="w-full p-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono"
                >
                  <option value={1}>1 fois (Unique)</option>
                  <option value={3}>Jusqu'à 3 fois</option>
                  <option value={5}>Jusqu'à 5 fois</option>
                  <option value={10}>Jusqu'à 10 fois</option>
                  <option value="unlimited">Illimité (en continu)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Innovative Screen Alert Mode & System Push Notification */}
          <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
            <label className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wide flex items-center gap-1.5">
              <Monitor className="w-3.5 h-3.5 text-cyan-400" />
              <span>3. Effet Visuel Écran & Notification Système</span>
            </label>

            <div>
              <span className="text-slate-400 text-[11px] block mb-1">Effet visuel à l'écran (Screen Alert) :</span>
              <select
                value={screenAlertEffect}
                onChange={(e) => setScreenAlertEffect(e.target.value as any)}
                className="w-full p-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-mono"
              >
                <option value="flash_strobe">⚡ Flash Strobe Néon Plein Écran</option>
                <option value="radar_ping">🎯 Radar Sonar Ping Tactique</option>
                <option value="floating_pip">📱 Mini-Widget Flottant PIP</option>
                <option value="standard">🔔 Bannière HUD Standard</option>
              </select>
            </div>

            <div className="flex items-center justify-between pt-1">
              <div>
                <span className="text-xs font-semibold text-white block">Notification Système (Bureau / Mobile)</span>
                <span className="text-[11px] text-slate-400">Alerte même avec l'onglet en arrière-plan</span>
              </div>
              <input
                type="checkbox"
                checked={sendNotification}
                onChange={(e) => setSendNotification(e.target.checked)}
                className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
              />
            </div>
          </div>

          {/* Sound Chime & Voice Script */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wide">
                4. Carillon & Message Parlé
              </label>
              <button
                type="button"
                onClick={handleGeminiGenerateScript}
                disabled={isGeneratingAiScript}
                className="text-xs px-2.5 py-1 rounded-lg bg-purple-500/20 border border-purple-500/40 text-purple-300 hover:text-white flex items-center gap-1 font-medium cursor-pointer"
              >
                {isGeneratingAiScript ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3 text-purple-400" />}
                <span>{isGeneratingAiScript ? 'IA...' : 'Générer avec Gemini'}</span>
              </button>
            </div>

            {/* Chime selectors */}
            <div className="grid grid-cols-4 gap-1.5">
              {SOUND_EFFECT_PRESETS.slice(0, 4).map((snd) => (
                <button
                  key={snd.id}
                  type="button"
                  onClick={() => {
                    setSelectedChime(snd.id);
                    playChimeSound(snd.id, audioSettings.volume);
                  }}
                  className={`p-1.5 rounded-lg border text-center transition-all cursor-pointer ${
                    selectedChime === snd.id
                      ? 'bg-amber-500/20 border-amber-500/60 text-amber-300'
                      : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  <span className="font-semibold text-[11px] block truncate">{snd.name.split(' ')[0]}</span>
                </button>
              ))}
            </div>

            <textarea
              rows={2}
              value={voiceScript}
              onChange={(e) => setVoiceScript(e.target.value)}
              className="w-full p-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs font-mono focus:outline-none focus:border-amber-500"
              required
            />
          </div>

          {/* Test Alert Button */}
          <button
            type="button"
            onClick={handleTestAlert}
            disabled={isAuditioning}
            className={`w-full py-2.5 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold cursor-pointer transition-colors ${
              isAuditioning ? 'bg-amber-500 text-slate-950 animate-pulse' : 'bg-slate-900 border-slate-700 text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Play className="w-3.5 h-3.5" />
            <span>{isAuditioning ? 'Écoute...' : 'Tester l\'annonce complète (Son + Voix)'}</span>
          </button>

          {/* Footer Submit */}
          <div className="pt-2 border-t border-slate-800 flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="w-1/3 py-2.5 rounded-xl bg-slate-900 text-slate-400 hover:text-white text-xs font-semibold"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="w-2/3 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2"
            >
              <Check className="w-4 h-4" />
              <span>Activer cette Alerte</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
