import React, { useState, useEffect } from 'react';
import { QuickReportSummary, TopSellingProductItem } from '../types/business';
import { StorageService } from '../db/storage';
import {
  TrendingUp,
  TrendingDown,
  Minus,
  Package,
  AlertTriangle,
  CheckCircle2,
  PlusCircle,
  ArrowRight,
  Flame,
  RotateCcw,
  Sparkles,
  ShoppingBag,
  ListOrdered,
  Zap,
  Activity,
} from 'lucide-react';

interface QuickReportProps {
  lang: 'bn' | 'en';
  currency?: string;
  onNavigate: (view: string, data?: any) => void;
  onRefreshMetrics?: () => void;
}

export const QuickReport: React.FC<QuickReportProps> = ({
  lang,
  currency = '৳',
  onNavigate,
  onRefreshMetrics,
}) => {
  const [report, setReport] = useState<QuickReportSummary>(
    StorageService.getQuickReportTopProducts(3)
  );
  const [isRefreshing, setIsRefreshing] = useState(false);

  const refreshData = () => {
    setIsRefreshing(true);
    const updated = StorageService.getQuickReportTopProducts(3);
    setReport(updated);
    if (onRefreshMetrics) {
      onRefreshMetrics();
    }
    setTimeout(() => setIsRefreshing(false), 300);
  };

  useEffect(() => {
    refreshData();
  }, []);

  const handleLoadDemoSales = () => {
    StorageService.seedSampleMonthlySales();
    refreshData();
  };

  const getRankBadge = (index: number) => {
    switch (index) {
      case 0:
        return (
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-500 via-amber-400 to-yellow-300 text-white font-black flex items-center justify-center shadow-sm text-xs shrink-0 border border-white">
            1
          </div>
        );
      case 1:
        return (
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-slate-400 via-slate-300 to-slate-200 text-slate-800 font-black flex items-center justify-center shadow-2xs text-xs shrink-0 border border-white">
            2
          </div>
        );
      case 2:
        return (
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-amber-700 via-amber-600 to-amber-500 text-white font-black flex items-center justify-center shadow-2xs text-xs shrink-0 border border-white">
            3
          </div>
        );
      default:
        return (
          <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-700 font-bold flex items-center justify-center text-xs shrink-0">
            {index + 1}
          </div>
        );
    }
  };

  const getUrgencyBadge = (item: TopSellingProductItem) => {
    switch (item.replenishmentUrgency) {
      case 'critical':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-red-100 text-red-700 text-[11px] font-bold shrink-0">
            <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-pulse" />
            {lang === 'bn' ? 'স্টক শেষ (জরুরী)' : 'Out of Stock'}
          </span>
        );
      case 'warning':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[11px] font-bold shrink-0">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
            {lang === 'bn' ? 'সীমিত স্টক' : 'Low Stock'}
          </span>
        );
      case 'caution':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-700 text-[11px] font-bold shrink-0">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
            {lang === 'bn' ? 'উচ্চ চাহিদা' : 'High Velocity'}
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 text-[11px] font-bold shrink-0">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            {lang === 'bn' ? 'পর্যাপ্ত মজুদ' : 'Healthy Stock'}
          </span>
        );
    }
  };

  // Trend indicator showing monthly popularity shift vs last month
  const renderTrendIndicator = (item: TopSellingProductItem) => {
    switch (item.growthDirection) {
      case 'up':
        return (
          <div
            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] font-extrabold bg-emerald-50 text-emerald-700 border border-emerald-200/90 shadow-2xs shrink-0 cursor-default"
            title={
              lang === 'bn'
                ? `গত মাসের চেয়ে ${item.growthLabel} বেশি বিক্রি হয়েছে (গত মাসে ${item.lastMonthQuantitySold} পিস)`
                : `+${item.growthPercentage}% growth vs last month (${item.lastMonthQuantitySold} pcs sold)`
            }
          >
            <TrendingUp className="w-3.5 h-3.5 text-emerald-600 stroke-[2.5]" />
            <span>{item.growthLabel}</span>
          </div>
        );
      case 'down':
        return (
          <div
            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] font-extrabold bg-rose-50 text-rose-700 border border-rose-200/90 shadow-2xs shrink-0 cursor-default"
            title={
              lang === 'bn'
                ? `গত মাসের চেয়ে ${item.growthLabel} কম বিক্রি হয়েছে (গত মাসে ${item.lastMonthQuantitySold} পিস)`
                : `${item.growthLabel} drop vs last month (${item.lastMonthQuantitySold} pcs sold)`
            }
          >
            <TrendingDown className="w-3.5 h-3.5 text-rose-600 stroke-[2.5]" />
            <span>{item.growthLabel}</span>
          </div>
        );
      case 'new':
        return (
          <div
            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] font-extrabold bg-amber-50 text-amber-800 border border-amber-200/90 shadow-2xs shrink-0 cursor-default"
            title={
              lang === 'bn'
                ? 'গত মাসে এই পণ্যটির কোনো বিক্রি ছিল না, চলতি মাসে নতুন সেরা বিক্রিত তালিকায় এসেছে'
                : 'New entry in the best-sellers list this month'
            }
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500 fill-amber-300" />
            <span>{lang === 'bn' ? 'নতুন (New)' : 'New'}</span>
          </div>
        );
      default:
        return (
          <div
            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] font-extrabold bg-slate-100 text-slate-600 border border-slate-200/90 shrink-0 cursor-default"
            title={
              lang === 'bn'
                ? `গত মাসের সমান বিক্রি (${item.lastMonthQuantitySold} পিস)`
                : `Same volume as last month (${item.lastMonthQuantitySold} pcs)`
            }
          >
            <Minus className="w-3.5 h-3.5 text-slate-500 stroke-[2.5]" />
            <span>০%</span>
          </div>
        );
    }
  };

  return (
    <section className="bg-white rounded-3xl border border-slate-200/90 shadow-xs overflow-hidden transition-all hover:border-indigo-200">
      {/* Top Header Bar */}
      <div className="p-4 sm:p-5 border-b border-slate-100 bg-gradient-to-r from-slate-50 via-white to-indigo-50/30 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-bold shadow-md shadow-indigo-600/20 shrink-0">
            <ListOrdered className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-800 font-extrabold text-[10px] tracking-wide uppercase">
                {lang === 'bn' ? 'কুইক রিপোর্ট' : 'Quick Report'}
              </span>
              <span className="text-xs font-semibold text-slate-500 flex items-center gap-1">
                <span>•</span>
                <span>{report.monthName}</span>
              </span>
              <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-100">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                {lang === 'bn' ? 'লেনদেন উপাত্ত ভিত্তিক' : 'From Transaction Data'}
              </span>
            </div>
            <h3 className="font-extrabold text-slate-900 text-base sm:text-lg tracking-tight mt-0.5">
              {lang === 'bn'
                ? 'চলতি মাসের শীর্ষ ৩ বিক্রিত পণ্য ও ট্রেন্ড বৃদ্ধি'
                : 'Top 3 Best-Selling Products & Popularity Shift'}
            </h3>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={refreshData}
            title={lang === 'bn' ? 'লেনদেন উপাত্ত রিফ্রেশ করুন' : 'Refresh from transactions'}
            className="p-2 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 transition-colors cursor-pointer text-xs flex items-center gap-1 shadow-2xs"
          >
            <RotateCcw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span className="text-[11px] font-medium hidden sm:inline">
              {lang === 'bn' ? 'রিফ্রেশ' : 'Refresh'}
            </span>
          </button>

          <button
            onClick={() => onNavigate('product_profit')}
            className="px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200/80 font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <span>{lang === 'bn' ? 'সকল পণ্যের রিপোর্ট' : 'All Products Report'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Clean List Format Body */}
      {report.topProducts.length === 0 ? (
        /* Empty State */
        <div className="py-8 px-4 text-center bg-slate-50/50">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-500 mx-auto flex items-center justify-center mb-3">
            <ShoppingBag className="w-6 h-6" />
          </div>
          <h4 className="font-bold text-slate-800 text-sm">
            {lang === 'bn'
              ? 'চলতি মাসে কোনো বিক্রয় লেনদেন পাওয়া যায়নি'
              : 'No sales transactions recorded for this month yet'}
          </h4>
          <p className="text-xs text-slate-500 max-w-md mx-auto mt-1 mb-4">
            {lang === 'bn'
              ? 'নতুন বিক্রি রেকর্ড করলে লেনদেন উপাত্ত কোয়েরি করে শীর্ষ ৩টি সেরা বিক্রিত পণ্য ও তাদের গত মাসের তুলনায় জনপ্রিয়তার শিফট প্রদর্শিত হবে।'
              : 'Record new sales transactions to automatically identify top sellers by quantity and view month-over-month popularity trends.'}
          </p>
          <div className="flex flex-wrap items-center justify-center gap-2">
            <button
              onClick={() => onNavigate('sales')}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs cursor-pointer flex items-center gap-1.5"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{lang === 'bn' ? 'নতুন বিক্রয় লেনদেন' : 'New Sale Transaction'}</span>
            </button>
            <button
              onClick={handleLoadDemoSales}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-xs cursor-pointer flex items-center gap-1.5"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>{lang === 'bn' ? 'ডেমো লেনদেন যোগ করুন' : 'Load Demo Transactions'}</span>
            </button>
          </div>
        </div>
      ) : (
        /* Clean List Format */
        <div className="divide-y divide-slate-100">
          {report.topProducts.map((item, index) => (
            <div
              key={item.productId}
              className="p-4 sm:px-6 sm:py-4.5 hover:bg-slate-50/80 transition-colors flex flex-col md:flex-row md:items-center md:justify-between gap-3.5 group"
            >
              {/* Left Column: Rank + Product Photo + Title Details */}
              <div className="flex items-center gap-3.5 min-w-0 flex-1">
                {/* Clean Rank Badge */}
                {getRankBadge(index)}

                {/* Product Thumbnail */}
                <div className="w-12 h-12 rounded-xl bg-white border border-slate-200 overflow-hidden shrink-0 flex items-center justify-center shadow-2xs">
                  {item.frontPhoto ? (
                    <img
                      src={item.frontPhoto}
                      alt={item.productName}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                  ) : (
                    <Package className="w-6 h-6 text-slate-400" />
                  )}
                </div>

                {/* Name, Brand, Model & Category */}
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-100 shrink-0">
                      {item.brand}
                    </span>
                    <span className="text-xs font-bold text-slate-800 truncate">
                      {item.modelNumber}
                    </span>
                    <span className="text-[11px] text-slate-400">•</span>
                    <span className="text-[11px] text-slate-500 font-medium">
                      {item.category}
                    </span>
                  </div>

                  <p className="text-xs text-slate-500 truncate mt-0.5">
                    {item.productName}
                  </p>

                  {/* Replenishment Guidance Callout */}
                  <p className="text-[11px] text-slate-600 mt-1 flex items-center gap-1 leading-snug">
                    <Zap className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                    <span>{item.replenishmentRecommendation}</span>
                  </p>
                </div>
              </div>

              {/* Right Column: Quantity Sold + Visual Trend Shift + Revenue + Stock Status & Action */}
              <div className="flex flex-wrap items-center justify-between md:justify-end gap-3 sm:gap-4 shrink-0 pl-11 md:pl-0">
                {/* Quantity Sold Metric + Visual Trend Arrow / Percentage Growth */}
                <div className="text-left md:text-right">
                  <div className="flex items-center md:justify-end gap-1.5">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block leading-tight">
                      {lang === 'bn' ? 'চলতি মাসে বিক্রি' : 'Sold Quantity'}
                    </span>
                  </div>

                  <div className="flex items-center md:justify-end gap-2 mt-0.5">
                    <div className="flex items-baseline gap-1">
                      <span className="text-base sm:text-lg font-black text-indigo-700">
                        {item.quantitySold}
                      </span>
                      <span className="text-xs font-semibold text-slate-500">
                        {lang === 'bn' ? 'পিস' : 'pcs'}
                      </span>
                    </div>

                    {/* Visual Indicator: Trend Arrow & Percentage Growth Shift */}
                    {renderTrendIndicator(item)}
                  </div>

                  <span className="text-[11px] font-medium text-slate-500 block">
                    {currency} {item.totalSalesValue.toLocaleString()}
                    {item.lastMonthQuantitySold > 0 ? (
                      <span className="text-[10px] text-slate-400 ml-1 hidden sm:inline">
                        (গত মাসে {item.lastMonthQuantitySold} পিস)
                      </span>
                    ) : (
                      <span className="text-[10px] text-amber-600 ml-1 hidden sm:inline">
                        (গত মাসে ০ পিস)
                      </span>
                    )}
                  </span>
                </div>

                {/* Stock Level & Urgency Badge */}
                <div className="text-left md:text-right min-w-[130px]">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block leading-tight">
                    {lang === 'bn' ? 'বর্তমান মজুদ' : 'Current Stock'}
                  </span>
                  <div className="mt-1 flex items-center md:justify-end gap-2">
                    <span
                      className={`text-xs font-extrabold ${
                        item.currentStock === 0
                          ? 'text-red-600'
                          : item.currentStock <= item.alertLimit
                          ? 'text-amber-600'
                          : 'text-emerald-700'
                      }`}
                    >
                      {item.currentStock} {lang === 'bn' ? 'পিস' : 'pcs'}
                    </span>
                    {getUrgencyBadge(item)}
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-0.5">
                    সতর্কতা সীমা: {item.alertLimit} pcs
                  </span>
                </div>

                {/* Action: Quick Replenish Stock Button */}
                <button
                  onClick={() =>
                    onNavigate('products', { openStockAdd: item.productId })
                  }
                  className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs cursor-pointer transition-all shrink-0"
                  title={
                    lang === 'bn'
                      ? 'এই পণ্যের নতুন মজুদ যোগ করুন'
                      : 'Add new stock replenishment'
                  }
                >
                  <PlusCircle className="w-3.5 h-3.5" />
                  <span>{lang === 'bn' ? '+ স্টক যোগ' : '+ Stock'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Clean Bottom Summary Bar with Trend Legend */}
      {report.topProducts.length > 0 && (
        <div className="p-3.5 sm:px-6 bg-slate-50/80 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2.5 text-xs text-slate-600">
          <div className="flex flex-wrap items-center gap-2">
            <TrendingUp className="w-4 h-4 text-indigo-600 shrink-0" />
            <span className="font-semibold text-slate-800">
              {lang === 'bn'
                ? `চলতি মাসে শীর্ষ ৩টি পণ্য থেকে মোট ${report.totalUnitsSoldInMonth} পিস বিক্রি হয়েছে (${currency} ${report.totalSalesValueInMonth.toLocaleString()})`
                : `Total ${report.totalUnitsSoldInMonth} units sold from top 3 products (${currency} ${report.totalSalesValueInMonth.toLocaleString()})`}
            </span>
            <span className="text-slate-400 hidden sm:inline">•</span>
            <span className="text-[11px] text-slate-500 flex items-center gap-1">
              <Activity className="w-3.5 h-3.5 text-indigo-500" />
              <span>{lang === 'bn' ? 'গত মাসের তুলনায় শিফট সূচক সক্রিয়' : 'vs last month popularity shift'}</span>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigate('products')}
              className="text-indigo-600 hover:text-indigo-700 font-bold flex items-center gap-1 cursor-pointer"
            >
              <span>{lang === 'bn' ? 'সকল পণ্যের মজুদ দেখুন' : 'View Full Inventory'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </section>
  );
};

// Also export QuickReportCard for compatibility
export const QuickReportCard = QuickReport;
export default QuickReport;
