import React, { useState } from 'react';
import { Phone, MessageSquare, Flashlight, Plus, Trash2, Smartphone, ExternalLink, X, User } from 'lucide-react';
import { Contact } from '../types';

interface PhoneActionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  contacts: Contact[];
  onAddContact: (contact: Omit<Contact, 'id'>) => void;
  onDeleteContact: (id: string) => void;
  onInitiateCall: (contact: Contact) => void;
  onInitiateWhatsApp: (contact: Contact) => void;
  isFlashlightOn: boolean;
  onToggleFlashlight: () => void;
  flashlightSupported: boolean;
}

export const PhoneActionsModal: React.FC<PhoneActionsModalProps> = ({
  isOpen,
  onClose,
  contacts,
  onAddContact,
  onDeleteContact,
  onInitiateCall,
  onInitiateWhatsApp,
  isFlashlightOn,
  onToggleFlashlight,
  flashlightSupported,
}) => {
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newRelationship, setNewRelationship] = useState('');

  if (!isOpen) return null;

  const handleCreateContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newPhone) return;
    onAddContact({
      name: newName.trim(),
      phone: newPhone.trim(),
      relationship: newRelationship.trim() || undefined,
    });
    setNewName('');
    setNewPhone('');
    setNewRelationship('');
  };

  const appShortcuts = [
    { name: 'WhatsApp', icon: MessageSquare, url: 'https://web.whatsapp.com', scheme: 'whatsapp://' },
    { name: 'YouTube', icon: ExternalLink, url: 'https://youtube.com', scheme: 'vnd.youtube:' },
    { name: 'Maps', icon: ExternalLink, url: 'https://maps.google.com', scheme: 'geo:0,0' },
    { name: 'Calculator', icon: Smartphone, url: 'https://www.google.com/search?q=calculator', scheme: 'calculator:' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-950/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg bg-gray-900 border border-cyan-500/40 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-gray-950/90 border-b border-cyan-500/30">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-cyan-400" />
            <h3 className="font-tech text-base tracking-wide uppercase text-cyan-100">
              COMMUNICATIONS & DEVICE CONTROL
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-cyan-400 hover:bg-cyan-500/20"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 p-4 overflow-y-auto space-y-4">
          {/* Hardware Quick Actions: Flashlight */}
          <div className="p-3.5 rounded-xl bg-gray-950/60 border border-cyan-500/30 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-xl border ${
                isFlashlightOn
                  ? 'bg-amber-500/20 border-amber-400 text-amber-300 glow-gold'
                  : 'bg-gray-800 border-gray-700 text-gray-400'
              }`}>
                <Flashlight className="w-5 h-5" />
              </div>
              <div>
                <div className="font-tech text-sm text-cyan-200">DEVICE FLASHLIGHT / TORCH</div>
                <div className="text-xs text-cyan-400/60">
                  {flashlightSupported
                    ? (isFlashlightOn ? 'Torch active' : 'Torch standby')
                    : 'Web torch fallback emulation (Camera flash requires supported mobile browser)'}
                </div>
              </div>
            </div>
            <button
              onClick={onToggleFlashlight}
              className={`px-4 py-1.5 rounded-xl text-xs font-tech font-bold uppercase transition-colors cursor-pointer ${
                isFlashlightOn
                  ? 'bg-amber-400 text-gray-950 glow-gold'
                  : 'bg-gray-800 hover:bg-gray-700 text-cyan-300 border border-cyan-500/30'
              }`}
            >
              {isFlashlightOn ? 'Turn Off' : 'Turn On'}
            </button>
          </div>

          {/* Missed Call Auto-Responder (Part 11 - Roman Punjabi) */}
          <div className="p-3.5 rounded-xl bg-cyan-950/40 border border-cyan-400/40 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-cyan-400" />
                <span className="font-tech text-xs uppercase text-cyan-200 font-bold">
                  Missed Call Auto-Responder (Roman Punjabi)
                </span>
              </div>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-900 text-cyan-300 font-mono-tech">
                PART 11
              </span>
            </div>
            <div className="p-2.5 rounded-lg bg-gray-950 border border-cyan-500/20 text-xs font-mono-tech text-cyan-100 select-all leading-relaxed">
              "Haanji, mai thoda busy aa. Je koi kam aa te msg kar do, mai free ho ke karda wa tanu."
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  navigator.clipboard.writeText("Haanji, mai thoda busy aa. Je koi kam aa te msg kar do, mai free ho ke karda wa tanu.");
                }}
                className="flex-1 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400 text-cyan-200 text-xs font-tech uppercase transition-colors cursor-pointer"
              >
                Copy Punjabi Response
              </button>
              <button
                onClick={() => {
                  window.open(`https://wa.me/?text=${encodeURIComponent("Haanji, mai thoda busy aa. Je koi kam aa te msg kar do, mai free ho ke karda wa tanu.")}`, '_blank');
                }}
                className="flex-1 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400 text-emerald-200 text-xs font-tech uppercase transition-colors cursor-pointer"
              >
                Send via WhatsApp
              </button>
            </div>
          </div>

          {/* Quick App Launcher */}
          <div>
            <div className="text-xs font-tech text-cyan-300 uppercase mb-2">Instant App Shortcuts</div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {appShortcuts.map((app) => (
                <a
                  key={app.name}
                  href={app.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 rounded-xl bg-gray-950 border border-cyan-500/20 hover:border-cyan-400/60 flex flex-col items-center justify-center gap-1.5 transition-colors group"
                >
                  <app.icon className="w-4 h-4 text-cyan-400 group-hover:scale-110 transition-transform" />
                  <span className="text-xs text-cyan-200 font-medium">{app.name}</span>
                </a>
              ))}
            </div>
          </div>

          {/* Local Contacts for Voice Calling */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-tech text-cyan-300 uppercase">
                Voice Calling Contacts (Private & Local Only)
              </span>
              <span className="text-[11px] text-cyan-400/60">Never uploaded to cloud</span>
            </div>

            {/* Add Contact Form */}
            <form onSubmit={handleCreateContact} className="p-3 bg-gray-950/80 rounded-xl border border-cyan-500/20 mb-3 space-y-2">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <input
                  type="text"
                  placeholder="Name (e.g. Papa)"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="px-3 py-1.5 bg-gray-900 border border-cyan-500/30 rounded-lg text-xs text-cyan-100 focus:outline-none focus:border-cyan-400"
                  required
                />
                <input
                  type="tel"
                  placeholder="Phone number"
                  value={newPhone}
                  onChange={(e) => setNewPhone(e.target.value)}
                  className="px-3 py-1.5 bg-gray-900 border border-cyan-500/30 rounded-lg text-xs text-cyan-100 focus:outline-none focus:border-cyan-400"
                  required
                />
                <input
                  type="text"
                  placeholder="Role/Tag (e.g. Dad)"
                  value={newRelationship}
                  onChange={(e) => setNewRelationship(e.target.value)}
                  className="px-3 py-1.5 bg-gray-900 border border-cyan-500/30 rounded-lg text-xs text-cyan-100 focus:outline-none focus:border-cyan-400"
                />
              </div>
              <button
                type="submit"
                className="w-full py-1.5 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200 border border-cyan-500/40 rounded-lg font-tech text-xs uppercase flex items-center justify-center gap-1 transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Save Contact for Voice Calls
              </button>
            </form>

            {/* Contact list */}
            <div className="space-y-2">
              {contacts.map((contact) => (
                <div
                  key={contact.id}
                  className="p-2.5 rounded-xl bg-gray-950/50 border border-cyan-500/20 flex items-center justify-between hover:border-cyan-500/40 transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-cyan-950 border border-cyan-500/30 text-cyan-300">
                      <User className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-cyan-100 flex items-center gap-1.5">
                        {contact.name}
                        {contact.relationship && (
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-900/50 text-cyan-300 font-mono-tech">
                            {contact.relationship}
                          </span>
                        )}
                      </div>
                      <div className="text-xs font-mono-tech text-cyan-400/70">{contact.phone}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => onInitiateCall(contact)}
                      title={`Call ${contact.name}`}
                      className="p-2 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 transition-colors"
                    >
                      <Phone className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onInitiateWhatsApp(contact)}
                      title={`WhatsApp ${contact.name}`}
                      className="p-2 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 transition-colors"
                    >
                      <MessageSquare className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onDeleteContact(contact.id)}
                      className="p-2 rounded-lg text-red-400 hover:bg-red-500/10 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer info */}
        <div className="p-3 bg-gray-950/90 border-t border-cyan-500/20 text-[11px] text-cyan-300/60 leading-relaxed">
          <span className="text-cyan-300 font-semibold">Try Voice:</span> "Jarvis, call Papa" or "Jarvis, WhatsApp par Papa ko call karo". Calls use native system intents (<code className="text-cyan-400">tel:</code> & WhatsApp URI).
        </div>
      </div>
    </div>
  );
};
