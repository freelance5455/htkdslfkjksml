import React, { useState, useEffect } from 'react';
import { 
  X, 
  Download, 
  Upload, 
  Database, 
  Cloud, 
  Store, 
  Lock, 
  Check, 
  RefreshCw, 
  ShieldAlert,
  Save,
  CheckCircle2,
  HardDrive
} from 'lucide-react';
import { StoreProfile, FirebaseSyncSettings } from '../../types';
import { storageService } from '../../services/storageService';
import { firebaseService } from '../../services/firebaseService';

interface BackupSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  storeProfile: StoreProfile;
  onUpdateStoreProfile: (profile: StoreProfile) => void;
  firebaseSettings: FirebaseSyncSettings;
  onUpdateFirebaseSettings: (settings: FirebaseSyncSettings) => void;
  onDataRestored: () => void;
}

export const BackupSyncModal: React.FC<BackupSyncModalProps> = ({
  isOpen,
  onClose,
  storeProfile,
  onUpdateStoreProfile,
  firebaseSettings,
  onUpdateFirebaseSettings,
  onDataRestored,
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'backup' | 'firebase'>('profile');

  // Profile Form
  const [name, setName] = useState(storeProfile.name);
  const [tagline, setTagline] = useState(storeProfile.tagline);
  const [address, setAddress] = useState(storeProfile.address);
  const [phone, setPhone] = useState(storeProfile.phone);
  const [receiptFooter, setReceiptFooter] = useState(storeProfile.receiptFooterMessage);
  const [pin, setPin] = useState(storeProfile.ownerPin);
  const [profileSaved, setProfileSaved] = useState(false);

  // Firebase Form
  const [fbProjectId, setFbProjectId] = useState(firebaseSettings.projectId);
  const [fbApiKey, setFbApiKey] = useState(firebaseSettings.apiKey);
  const [fbAutoSync, setFbAutoSync] = useState(firebaseSettings.autoSync);
  const [fbSaved, setFbSaved] = useState(false);

  // Sync form inputs when storeProfile updates from cloud or other devices
  useEffect(() => {
    setName(storeProfile.name || '');
    setTagline(storeProfile.tagline || '');
    setAddress(storeProfile.address || '');
    setPhone(storeProfile.phone || '');
    setReceiptFooter(storeProfile.receiptFooterMessage || '');
    setPin(storeProfile.ownerPin || '1234');
  }, [storeProfile]);

  // Backup state
  const [backupStatus, setBackupStatus] = useState<string | null>(null);

  if (!isOpen) return null;

  // Handle Save Profile
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateStoreProfile({
      ...storeProfile,
      name: name.trim(),
      tagline: tagline.trim(),
      address: address.trim(),
      phone: phone.trim(),
      receiptFooterMessage: receiptFooter.trim(),
      ownerPin: pin.trim() || '1234',
    });
    setProfileSaved(true);
    setTimeout(() => setProfileSaved(false), 2000);
  };

  // Handle Save Firebase
  const handleSaveFirebase = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateFirebaseSettings({
      ...firebaseSettings,
      projectId: fbProjectId.trim(),
      apiKey: fbApiKey.trim(),
      isConfigured: !!fbProjectId.trim(),
      autoSync: fbAutoSync,
      lastSyncedAt: new Date().toISOString(),
    });
    setFbSaved(true);
    setTimeout(() => setFbSaved(false), 2000);
  };

  // Export JSON Backup
  const handleExportBackup = () => {
    try {
      const json = storageService.exportBackupData();
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      const dateStr = new Date().toISOString().split('T')[0];
      a.download = `mudir_dokan_backup_${dateStr}.json`;
      a.click();
      URL.revokeObjectURL(url);
      setBackupStatus('ডাটা ব্যাকআপ ফাইল সফলভাবে ডাউনলোড হয়েছে!');
    } catch (e) {
      setBackupStatus('ব্যাকআপ তৈরি করতে সমস্যা হয়েছে');
    }
  };

  // Import JSON Backup
  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const success = storageService.importBackupData(content);
      if (success) {
        setBackupStatus('ডাটা সফলভাবে রিস্টোর হয়েছে!');
        onDataRestored();
      } else {
        setBackupStatus('ভুল বা অকার্যকর ব্যাকআপ ফাইল');
      }
    };
    reader.readAsText(file);
  };

  // Reset to default
  const handleResetData = () => {
    if (confirm('আপনি কি নিশ্চিত যে সকল হিসাব মুছে ডেমো ডাটায় ফিরে যেতে চান?')) {
      storageService.resetToDefault();
      onDataRestored();
      setBackupStatus('ডাটাবেস সফলভাবে রিসেট হয়েছে!');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col">
        
        {/* Header */}
        <div className="bg-emerald-800 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Store className="w-5 h-5 text-emerald-300" />
            <h3 className="font-bold text-base">দোকান সেটিং ও ডাটা ব্যাকআপ</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-emerald-200 hover:text-white hover:bg-emerald-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Links */}
        <div className="flex border-b border-slate-200 bg-slate-50 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('profile')}
            className={`flex-1 py-3 text-center border-b-2 transition ${
              activeTab === 'profile'
                ? 'border-emerald-700 text-emerald-900 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            দোকানের পরিচিতি
          </button>
          <button
            onClick={() => setActiveTab('backup')}
            className={`flex-1 py-3 text-center border-b-2 transition ${
              activeTab === 'backup'
                ? 'border-emerald-700 text-emerald-900 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            ব্যাকআপ ও রিস্টোর
          </button>
          <button
            onClick={() => setActiveTab('firebase')}
            className={`flex-1 py-3 text-center border-b-2 transition ${
              activeTab === 'firebase'
                ? 'border-emerald-700 text-emerald-900 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Firebase ক্লাউড সিঙ্ক
          </button>
        </div>

        {/* Tab Contents */}
        <div className="p-5 max-h-[70vh] overflow-y-auto">
          
          {/* TAB 1: STORE PROFILE */}
          {activeTab === 'profile' && (
            <form onSubmit={handleSaveProfile} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  দোকানের নাম (ক্যাশ মেমোর শীর্ষে থাকবে)*
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-semibold"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  দোকানের স্লোগান / বিবরণ
                </label>
                <input
                  type="text"
                  value={tagline}
                  onChange={(e) => setTagline(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    মোবাইল নম্বর
                  </label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    মালিকের সিকিউরিটি পিন (৪ ডিজিট)
                  </label>
                  <input
                    type="password"
                    maxLength={6}
                    value={pin}
                    onChange={(e) => setPin(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  দোকানের ঠিকানা
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  ক্যাশ মেমোর নিচের শুভেচ্ছা বার্তা
                </label>
                <input
                  type="text"
                  value={receiptFooter}
                  onChange={(e) => setReceiptFooter(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-4 py-2 bg-emerald-800 text-white rounded-lg font-semibold hover:bg-emerald-700"
                >
                  {profileSaved ? <Check className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
                  <span>{profileSaved ? 'সংরক্ষিত হয়েছে' : 'সেভ করুন'}</span>
                </button>
              </div>
            </form>
          )}

          {/* TAB 2: BACKUP & RESTORE */}
          {activeTab === 'backup' && (
            <div className="space-y-4 text-xs">
              
              {/* Local DB Status */}
              <div className="bg-emerald-50 border border-emerald-300 p-3.5 rounded-xl flex items-start gap-3">
                <HardDrive className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-emerald-950 text-xs">
                    লোকাল অফলাইন ডাটাবেস সম্পূর্ণ সক্রিয়
                  </h4>
                  <p className="text-[11px] text-emerald-800 mt-0.5">
                    ইন্টারনেট সংযোগ ছাড়াও আপনার বিক্রয়, মেমো ও হিসাব নিরবচ্ছিন্নভাবে স্বয়ংক্রিয়ভাবে ব্রাউজারে সুরক্ষিত থাকে।
                  </p>
                </div>
              </div>

              {/* Export Backup */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex items-center justify-between gap-4">
                <div>
                  <h4 className="font-bold text-slate-800">ডাটা ব্যাকআপ ডাউনলোড (Export)</h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    আপনার দোকানের পণ্য, মেমো, ক্রয় ও খরচের সম্পূর্ণ ব্যাকআপ ফাইল (.json) ডাউনলোড করুন।
                  </p>
                </div>
                <button
                  onClick={handleExportBackup}
                  className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-semibold shrink-0"
                >
                  <Download className="w-4 h-4" />
                  <span>ব্যাকআপ ডাউনলোড</span>
                </button>
              </div>

              {/* Import Backup */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex items-center justify-between gap-4">
                <div>
                  <h4 className="font-bold text-slate-800">ডাটা রিস্টোর করুন (Import)</h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    পূর্বে ডাউনলোড করা ব্যাকআপ ফাইল নির্বাচন করে পুনরায় ডাটা রিস্টোর করুন।
                  </p>
                </div>
                <label className="flex items-center gap-1.5 px-3.5 py-2 bg-blue-700 hover:bg-blue-800 text-white rounded-lg font-semibold shrink-0 cursor-pointer">
                  <Upload className="w-4 h-4" />
                  <span>ফাইল নির্বাচন</span>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleImportBackup}
                    className="hidden"
                  />
                </label>
              </div>

              {/* Reset Database */}
              <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-center justify-between">
                <div>
                  <span className="font-bold text-red-900 block">ডাটাবেস রিসেট</span>
                  <span className="text-[11px] text-red-700">ডেমো পণ্যের তালিকায় ফিরে যান</span>
                </div>
                <button
                  onClick={handleResetData}
                  className="px-3 py-1.5 bg-red-600 text-white rounded-lg hover:bg-red-700 font-semibold"
                >
                  রিসেট করুন
                </button>
              </div>

              {backupStatus && (
                <div className="p-2.5 rounded-lg bg-emerald-100 text-emerald-900 font-semibold text-center text-xs">
                  {backupStatus}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: FIREBASE CLOUD SYNC */}
          {activeTab === 'firebase' && (
            <div className="space-y-4 text-xs">
              <div className="bg-emerald-50 border border-emerald-300 p-3.5 rounded-xl flex items-start gap-3">
                <Cloud className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-emerald-950 text-xs">
                      Firebase ক্লাউড ইন্টিগ্রেশন সম্পন্ন!
                    </h4>
                    <span className="px-2 py-0.5 bg-emerald-200 text-emerald-800 rounded-full text-[10px] font-bold">
                      সংযুক্ত
                    </span>
                  </div>
                  <p className="text-[11px] text-emerald-800 mt-1">
                    আপনার প্রোজেক্ট <strong>unifour1211</strong> সরাসরি অ্যাপে যুক্ত করা হয়েছে। প্রতিটি পণ্য ও বিক্রয় মেমো স্বয়ংক্রিয়ভাবে ক্লাউডে এবং অফলাইনে সংরক্ষিত হয়।
                  </p>
                </div>
              </div>

              {/* Instant Cloud Action Buttons */}
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-3">
                <div className="font-bold text-slate-800 flex items-center gap-1.5 text-xs">
                  <Database className="w-4 h-4 text-emerald-700" />
                  <span>ক্লাউড সিঙ্ক্রোনাইজেশন ও ব্যাকআপ অ্যাকশন</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={async () => {
                      setBackupStatus('ক্লাউডে আপলোড হচ্ছে, অপেক্ষা করুন...');
                      const res = await firebaseService.uploadAllToCloud({
                        products: storageService.getProducts(),
                        invoices: storageService.getInvoices(),
                        expenses: storageService.getExpenses(),
                        purchases: storageService.getPurchases(),
                        storeProfile: storageService.getStoreProfile(),
                      });
                      setBackupStatus(res.message);
                    }}
                    className="flex items-center justify-center gap-1.5 px-3 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-semibold shadow-xs transition"
                  >
                    <Upload className="w-4 h-4" />
                    <span>ক্লাউডে সব ডাটা আপলোড করুন</span>
                  </button>

                  <button
                    type="button"
                    onClick={async () => {
                      setBackupStatus('ক্লাউড থেকে ডাটা নামানো হচ্ছে...');
                      const res = await firebaseService.downloadAllFromCloud();
                      if (res.success && res.data) {
                        if (res.data.products && res.data.products.length > 0) {
                          storageService.saveProducts(res.data.products);
                        }
                        if (res.data.invoices && res.data.invoices.length > 0) {
                          storageService.saveInvoices(res.data.invoices);
                        }
                        if (res.data.profile && res.data.profile.name) {
                          storageService.saveStoreProfileLocally(res.data.profile);
                          onUpdateStoreProfile(res.data.profile);
                        }
                        onDataRestored();
                      }
                      setBackupStatus(res.message);
                    }}
                    className="flex items-center justify-center gap-1.5 px-3 py-2.5 bg-blue-700 hover:bg-blue-800 text-white rounded-lg font-semibold shadow-xs transition"
                  >
                    <Download className="w-4 h-4" />
                    <span>ক্লাউড থেকে ডাটা নামিয়ে আনুন</span>
                  </button>
                </div>
              </div>

              {/* Firebase Guide Box */}
              <div className="bg-amber-50 border border-amber-200 p-3 rounded-xl text-[11px] text-amber-900 space-y-1">
                <span className="font-bold block">💡 আর কিছু লাগবে কি?</span>
                <p>
                  অ্যাপের কোডে Firebase API Key এবং Project ID সম্পূর্ণ সেটআপ করা হয়ে গেছে। আপনার কেবল একটি কাজ করতে হবে:
                </p>
                <ol className="list-decimal list-inside space-y-0.5 text-amber-800 pt-0.5">
                  <li><a href="https://console.firebase.google.com" target="_blank" rel="noreferrer" className="underline font-bold text-amber-900">Firebase Console</a> এ যান এবং <strong>unifour1211</strong> প্রোজেক্টে ঢুকুন।</li>
                  <li>বাম পাশের মেনু থেকে <strong>Cloud Firestore</strong> তৈরি (Create Database) করুন।</li>
                  <li><strong>Rules</strong> ট্যাবে গিয়ে নিয়মটি দিন: <code className="bg-amber-100 px-1 py-0.5 rounded font-mono font-bold text-red-700">allow read, write: if true;</code> এবং <strong>Publish</strong> করুন।</li>
                </ol>
              </div>

              {/* Form config for project */}
              <form onSubmit={handleSaveFirebase} className="space-y-3 pt-1 border-t border-slate-200">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Firebase Project ID:
                  </label>
                  <input
                    type="text"
                    value={fbProjectId}
                    onChange={(e) => setFbProjectId(e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg font-mono text-xs"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    Firebase Web API Key:
                  </label>
                  <input
                    type="text"
                    value={fbApiKey}
                    onChange={(e) => setFbApiKey(e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg font-mono text-xs"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="autosync"
                    checked={fbAutoSync}
                    onChange={(e) => setFbAutoSync(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <label htmlFor="autosync" className="text-slate-700 font-medium">
                    প্রতিটি বিক্রয় সম্পন্ন হওয়ার সাথে সাথে ব্যাকগ্রাউন্ড ক্লাউড সিঙ্ক চালু রাখুন
                  </label>
                </div>

                <div className="flex justify-end pt-1">
                  <button
                    type="submit"
                    className="flex items-center gap-1.5 px-4 py-2 bg-emerald-800 text-white rounded-lg font-semibold hover:bg-emerald-700"
                  >
                    {fbSaved ? <Check className="w-4 h-4 text-emerald-200" /> : <Save className="w-4 h-4" />}
                    <span>{fbSaved ? 'সংরক্ষিত হয়েছে' : 'সেটিংস সেভ করুন'}</span>
                  </button>
                </div>
              </form>

              {backupStatus && (
                <div className="p-2.5 rounded-lg bg-emerald-100 text-emerald-900 font-semibold text-center text-xs">
                  {backupStatus}
                </div>
              )}
            </div>
          )}

        </div>

        {/* Developer Credit Note */}
        <div className="bg-slate-50 border-t border-slate-200 px-5 py-3 text-center text-[11px] text-slate-500">
          Designed and Developed with ❤️ by <span className="font-bold text-emerald-800">Sheikh Akash</span>
        </div>

      </div>
    </div>
  );
};
