import React, { useState, useRef } from 'react';
import {
  X,
  Palette,
  Upload,
  Sun,
  Moon,
  Monitor,
  PenTool,
  Download,
  UploadCloud,
  RotateCcw,
  Check,
  Shield,
  Hand,
  Sparkles,
  Shapes,
} from 'lucide-react';
import { AppSettings } from '../../canvas/types';
import { M3_PRESETS, generateM3Theme, applyM3ThemeToCss } from '../../theme/m3Theme';
import { extractColorsFromImage } from '../../theme/colorExtractor';
import { exportFullBackup, importFullBackup } from '../../storage/db';
import { PWAInstallButton } from '../PWAInstallButton';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSaveSettings: (newSettings: AppSettings) => void;
  onRefreshBoards?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  onRefreshBoards,
}) => {
  const [activeTab, setActiveTab] = useState<'theme' | 'stylus' | 'backup'>('theme');
  const [currentSettings, setCurrentSettings] = useState<AppSettings>(settings);
  const [extractedPalette, setExtractedPalette] = useState<string[]>([]);
  const [isExtracting, setIsExtracting] = useState(false);
  const [backupStatus, setBackupStatus] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const backupInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const updateSetting = <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => {
    const updated = { ...currentSettings, [key]: value };
    setCurrentSettings(updated);
    onSaveSettings(updated);

    // Apply live theme preview
    if (key === 'themeMode' || key === 'presetKey' || key === 'customSeedHex' || key === 'colorSchemePreference') {
      applyThemeLive(updated);
    }
  };

  const applyThemeLive = (s: AppSettings) => {
    let seed = '#1E88E5';
    if (s.themeMode === 'preset') {
      const p = M3_PRESETS.find(item => item.id === s.presetKey) || M3_PRESETS[0];
      seed = p.seedHex;
    } else {
      seed = s.customSeedHex || '#1E88E5';
    }

    const { light, dark } = generateM3Theme(seed);
    const isDark =
      s.colorSchemePreference === 'dark' ||
      (s.colorSchemePreference === 'system' &&
        typeof window !== 'undefined' &&
        window.matchMedia('(prefers-color-scheme: dark)').matches);

    applyM3ThemeToCss(isDark ? dark : light, isDark);
  };

  const handleWallpaperUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsExtracting(true);
    try {
      const result = await extractColorsFromImage(file);
      setExtractedPalette(result.palette);

      // Save wallpaper preview as data url
      const reader = new FileReader();
      reader.onload = (re) => {
        const dataUrl = re.target?.result as string;
        const updated: AppSettings = {
          ...currentSettings,
          themeMode: 'auto',
          customSeedHex: result.dominantHex,
          wallpaperData: dataUrl,
        };
        setCurrentSettings(updated);
        onSaveSettings(updated);
        applyThemeLive(updated);
      };
      reader.readAsDataURL(file);
    } catch (err) {
      console.error('Wallpaper extraction error:', err);
    } finally {
      setIsExtracting(false);
    }
  };

  const handleResetTheme = () => {
    const reset: AppSettings = {
      ...currentSettings,
      themeMode: 'preset',
      presetKey: 'ocean-blue',
      customSeedHex: '#1E88E5',
      wallpaperData: undefined,
      colorSchemePreference: 'system',
    };
    setCurrentSettings(reset);
    onSaveSettings(reset);
    applyThemeLive(reset);
  };

  const handleExportBackup = async () => {
    try {
      const backupJson = await exportFullBackup();
      const blob = new Blob([backupJson], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.download = `xvboard_backup_${new Date().toISOString().slice(0, 10)}.json`;
      a.href = url;
      a.click();
      URL.revokeObjectURL(url);
      setBackupStatus('Backup exported successfully');
      setTimeout(() => setBackupStatus(null), 3000);
    } catch (err) {
      setBackupStatus('Export failed: ' + (err as Error).message);
    }
  };

  const handleImportBackup = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        const res = await importFullBackup(text);
        setBackupStatus(`Imported ${res.boardsCount} boards successfully!`);
        if (onRefreshBoards) onRefreshBoards();
        setTimeout(() => setBackupStatus(null), 3500);
      } catch (err) {
        setBackupStatus('Import error: ' + (err as Error).message);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
      <div className="flex flex-col w-full max-w-2xl max-h-[90vh] rounded-3xl bg-[var(--md-sys-color-surface-container)] text-[var(--md-sys-color-on-surface)] shadow-2xl border border-[var(--md-sys-color-outline-variant)] overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[var(--md-sys-color-outline-variant)]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] flex items-center justify-center font-bold">
              xv
            </div>
            <div>
              <h2 className="text-lg font-bold">xvBOARD Settings</h2>
              <p className="text-xs text-[var(--md-sys-color-on-surface-variant)]">Material You theming & stylus configuration</p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close Settings"
            className="p-2 rounded-full hover:bg-[var(--md-sys-color-surface-container-high)] text-[var(--md-sys-color-on-surface-variant)] transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* M3 Segmented Navigation Tabs */}
        <div className="flex border-b border-[var(--md-sys-color-outline-variant)] px-6 pt-2 bg-[var(--md-sys-color-surface-container-low)]">
          <button
            onClick={() => setActiveTab('theme')}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition ${
              activeTab === 'theme'
                ? 'border-[var(--md-sys-color-primary)] text-[var(--md-sys-color-primary)]'
                : 'border-transparent text-[var(--md-sys-color-on-surface-variant)] hover:text-[var(--md-sys-color-on-surface)]'
            }`}
          >
            <Palette className="w-4 h-4" />
            <span>Material You Theme</span>
          </button>
          <button
            onClick={() => setActiveTab('stylus')}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition ${
              activeTab === 'stylus'
                ? 'border-[var(--md-sys-color-primary)] text-[var(--md-sys-color-primary)]'
                : 'border-transparent text-[var(--md-sys-color-on-surface-variant)] hover:text-[var(--md-sys-color-on-surface)]'
            }`}
          >
            <PenTool className="w-4 h-4" />
            <span>Stylus & Palm Rejection</span>
          </button>
          <button
            onClick={() => setActiveTab('backup')}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition ${
              activeTab === 'backup'
                ? 'border-[var(--md-sys-color-primary)] text-[var(--md-sys-color-primary)]'
                : 'border-transparent text-[var(--md-sys-color-on-surface-variant)] hover:text-[var(--md-sys-color-on-surface)]'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>Backup & PWA</span>
          </button>
        </div>

        {/* Body content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">

          {/* TAB 1: THEME */}
          {activeTab === 'theme' && (
            <div className="space-y-6">
              
              {/* Appearance (Light / Dark / System) */}
              <div>
                <label className="block text-xs font-semibold text-[var(--md-sys-color-on-surface-variant)] uppercase tracking-wider mb-2">
                  Appearance
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['system', 'light', 'dark'] as const).map((mode) => (
                    <button
                      key={mode}
                      onClick={() => updateSetting('colorSchemePreference', mode)}
                      className={`flex items-center justify-center gap-2 py-2.5 rounded-2xl text-xs font-medium border transition ${
                        currentSettings.colorSchemePreference === mode
                          ? 'bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)] border-[var(--md-sys-color-primary)]'
                          : 'bg-[var(--md-sys-color-surface-container-high)] text-[var(--md-sys-color-on-surface)] border-transparent hover:border-[var(--md-sys-color-outline-variant)]'
                      }`}
                    >
                      {mode === 'system' && <Monitor className="w-4 h-4" />}
                      {mode === 'light' && <Sun className="w-4 h-4" />}
                      {mode === 'dark' && <Moon className="w-4 h-4" />}
                      <span className="capitalize">{mode}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Theme Source Mode: Preset / Manual / Automatic */}
              <div>
                <label className="block text-xs font-semibold text-[var(--md-sys-color-on-surface-variant)] uppercase tracking-wider mb-2">
                  Dynamic Theming Mode
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => updateSetting('themeMode', 'preset')}
                    className={`py-2 px-3 rounded-2xl text-xs font-medium border text-center transition ${
                      currentSettings.themeMode === 'preset'
                        ? 'bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)] border-[var(--md-sys-color-primary)]'
                        : 'bg-[var(--md-sys-color-surface-container-high)] text-[var(--md-sys-color-on-surface)] border-transparent'
                    }`}
                  >
                    M3 Presets
                  </button>
                  <button
                    onClick={() => updateSetting('themeMode', 'manual')}
                    className={`py-2 px-3 rounded-2xl text-xs font-medium border text-center transition ${
                      currentSettings.themeMode === 'manual'
                        ? 'bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)] border-[var(--md-sys-color-primary)]'
                        : 'bg-[var(--md-sys-color-surface-container-high)] text-[var(--md-sys-color-on-surface)] border-transparent'
                    }`}
                  >
                    Custom Color
                  </button>
                  <button
                    onClick={() => updateSetting('themeMode', 'auto')}
                    className={`py-2 px-3 rounded-2xl text-xs font-medium border text-center transition ${
                      currentSettings.themeMode === 'auto'
                        ? 'bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)] border-[var(--md-sys-color-primary)]'
                        : 'bg-[var(--md-sys-color-surface-container-high)] text-[var(--md-sys-color-on-surface)] border-transparent'
                    }`}
                  >
                    Wallpaper (Auto)
                  </button>
                </div>
              </div>

              {/* MODE A: PRESETS */}
              {currentSettings.themeMode === 'preset' && (
                <div className="space-y-3">
                  <label className="block text-xs font-medium text-[var(--md-sys-color-on-surface-variant)]">
                    Choose a Material 3 Tonal Palette
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                    {M3_PRESETS.map((preset) => {
                      const isSelected = currentSettings.presetKey === preset.id;
                      return (
                        <button
                          key={preset.id}
                          onClick={() => {
                            const updated = {
                              ...currentSettings,
                              presetKey: preset.id,
                              customSeedHex: preset.seedHex,
                            };
                            setCurrentSettings(updated);
                            onSaveSettings(updated);
                            applyThemeLive(updated);
                          }}
                          className={`flex items-center gap-2.5 p-2.5 rounded-2xl border text-left transition ${
                            isSelected
                              ? 'bg-[var(--md-sys-color-surface-container-highest)] border-[var(--md-sys-color-primary)] ring-1 ring-[var(--md-sys-color-primary)]'
                              : 'bg-[var(--md-sys-color-surface-container-high)] border-transparent hover:border-[var(--md-sys-color-outline-variant)]'
                          }`}
                        >
                          <div
                            className="w-7 h-7 rounded-full shrink-0 flex items-center justify-center text-white shadow-sm"
                            style={{ backgroundColor: preset.seedHex }}
                          >
                            {isSelected && <Check className="w-4 h-4" />}
                          </div>
                          <span className="text-xs font-medium truncate">{preset.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* MODE B: MANUAL COLOR PICKER */}
              {currentSettings.themeMode === 'manual' && (
                <div className="space-y-3 p-4 rounded-2xl bg-[var(--md-sys-color-surface-container-high)]">
                  <label className="block text-xs font-medium text-[var(--md-sys-color-on-surface)]">
                    Pick Custom Seed Accent Color
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={currentSettings.customSeedHex}
                      onChange={(e) => updateSetting('customSeedHex', e.target.value)}
                      className="w-12 h-12 rounded-2xl border border-[var(--md-sys-color-outline)] cursor-pointer bg-transparent"
                    />
                    <div className="flex-1">
                      <input
                        type="text"
                        value={currentSettings.customSeedHex}
                        onChange={(e) => updateSetting('customSeedHex', e.target.value)}
                        placeholder="#1E88E5"
                        className="w-full px-3 py-2 text-sm rounded-xl bg-[var(--md-sys-color-surface-container)] border border-[var(--md-sys-color-outline)] font-mono text-[var(--md-sys-color-on-surface)]"
                      />
                      <p className="text-[11px] text-[var(--md-sys-color-on-surface-variant)] mt-1">
                        Full light & dark tonal palettes are mathematically generated from this seed.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* MODE C: AUTOMATIC WALLPAPER EXTRACTION */}
              {currentSettings.themeMode === 'auto' && (
                <div className="space-y-4 p-4 rounded-2xl bg-[var(--md-sys-color-surface-container-high)]">
                  <div>
                    <h4 className="text-xs font-bold text-[var(--md-sys-color-on-surface)]">Browser-Side Wallpaper Color Extraction</h4>
                    <p className="text-xs text-[var(--md-sys-color-on-surface-variant)] mt-0.5">
                      Upload any image or wallpaper to extract dynamic Material You accent palettes.
                    </p>
                  </div>

                  <input
                    type="file"
                    ref={fileInputRef}
                    accept="image/*"
                    onChange={handleWallpaperUpload}
                    className="hidden"
                  />

                  <div className="flex items-center gap-4">
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isExtracting}
                      className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] text-xs font-medium hover:opacity-90 transition disabled:opacity-50"
                    >
                      <Upload className="w-4 h-4" />
                      <span>{isExtracting ? 'Analyzing Image...' : 'Upload Wallpaper'}</span>
                    </button>

                    {currentSettings.wallpaperData && (
                      <div className="w-12 h-12 rounded-xl overflow-hidden border border-[var(--md-sys-color-outline)] shrink-0">
                        <img
                          src={currentSettings.wallpaperData}
                          alt="Wallpaper preview"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}
                  </div>

                  {extractedPalette.length > 0 && (
                    <div className="space-y-1.5 pt-2">
                      <span className="text-[11px] font-medium text-[var(--md-sys-color-on-surface-variant)]">
                        Extracted Dominant Swatches (Tap to activate):
                      </span>
                      <div className="flex gap-2">
                        {extractedPalette.map((hex, idx) => (
                          <button
                            key={idx}
                            onClick={() => updateSetting('customSeedHex', hex)}
                            className={`w-9 h-9 rounded-full border-2 flex items-center justify-center shadow-sm transition ${
                              currentSettings.customSeedHex.toLowerCase() === hex.toLowerCase()
                                ? 'border-[var(--md-sys-color-on-surface)] scale-110'
                                : 'border-transparent'
                            }`}
                            style={{ backgroundColor: hex }}
                          >
                            {currentSettings.customSeedHex.toLowerCase() === hex.toLowerCase() && (
                              <Check className="w-4 h-4 text-white drop-shadow" />
                            )}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Reset Theme button */}
              <div className="pt-2 flex justify-end">
                <button
                  onClick={handleResetTheme}
                  className="flex items-center gap-1.5 text-xs font-medium text-[var(--md-sys-color-on-surface-variant)] hover:text-[var(--md-sys-color-on-surface)] transition"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset to Default Theme</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: STYLUS & PALM REJECTION */}
          {activeTab === 'stylus' && (
            <div className="space-y-5">
              
              {/* Palm Rejection Sensitivity */}
              <div className="p-4 rounded-2xl bg-[var(--md-sys-color-surface-container-high)] space-y-3">
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-[var(--md-sys-color-primary)]" />
                  <span className="text-xs font-bold uppercase tracking-wider">Palm Rejection Sensitivity</span>
                </div>
                <p className="text-xs text-[var(--md-sys-color-on-surface-variant)]">
                  Filters broad touch contacts from the side of your hand while inking with a stylus.
                </p>
                <div className="grid grid-cols-4 gap-2">
                  {(['high', 'medium', 'low', 'off'] as const).map((lvl) => (
                    <button
                      key={lvl}
                      onClick={() => {
                        const updated = {
                          ...currentSettings,
                          stylusSettings: {
                            ...currentSettings.stylusSettings,
                            palmRejectionSensitivity: lvl,
                          },
                        };
                        setCurrentSettings(updated);
                        onSaveSettings(updated);
                      }}
                      className={`py-2 rounded-xl text-xs font-medium border capitalize text-center transition ${
                        currentSettings.stylusSettings.palmRejectionSensitivity === lvl
                          ? 'bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)] border-[var(--md-sys-color-primary)]'
                          : 'bg-[var(--md-sys-color-surface-container)] text-[var(--md-sys-color-on-surface)] border-transparent'
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>

              {/* Pen-Only Inking Mode */}
              <div className="flex items-center justify-between p-4 rounded-2xl bg-[var(--md-sys-color-surface-container-high)]">
                <div className="space-y-0.5 max-w-[80%]">
                  <div className="flex items-center gap-2">
                    <Hand className="w-4 h-4 text-[var(--md-sys-color-primary)]" />
                    <span className="text-sm font-semibold">Pen-Only Inking Mode</span>
                  </div>
                  <p className="text-xs text-[var(--md-sys-color-on-surface-variant)]">
                    Only active stylus (`pointerType = &quot;pen&quot;`) draws on the canvas. Fingers always pan and zoom.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={currentSettings.stylusSettings.penOnlyInking}
                  onChange={(e) => {
                    const updated = {
                      ...currentSettings,
                      stylusSettings: {
                        ...currentSettings.stylusSettings,
                        penOnlyInking: e.target.checked,
                      },
                    };
                    setCurrentSettings(updated);
                    onSaveSettings(updated);
                  }}
                  className="w-5 h-5 rounded accent-[var(--md-sys-color-primary)] cursor-pointer"
                />
              </div>

              {/* Pressure Sensitivity */}
              <div className="flex items-center justify-between p-4 rounded-2xl bg-[var(--md-sys-color-surface-container-high)]">
                <div className="space-y-0.5 max-w-[80%]">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[var(--md-sys-color-primary)]" />
                    <span className="text-sm font-semibold">Pressure-Sensitive Stroke Thickness</span>
                  </div>
                  <p className="text-xs text-[var(--md-sys-color-on-surface-variant)]">
                    Dynamically modulates line thickness based on physical stylus tip pressure.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={currentSettings.stylusSettings.pressureSensitivity}
                  onChange={(e) => {
                    const updated = {
                      ...currentSettings,
                      stylusSettings: {
                        ...currentSettings.stylusSettings,
                        pressureSensitivity: e.target.checked,
                      },
                    };
                    setCurrentSettings(updated);
                    onSaveSettings(updated);
                  }}
                  className="w-5 h-5 rounded accent-[var(--md-sys-color-primary)] cursor-pointer"
                />
              </div>

              {/* Stylus Hover Cursor */}
              <div className="flex items-center justify-between p-4 rounded-2xl bg-[var(--md-sys-color-surface-container-high)]">
                <div className="space-y-0.5 max-w-[80%]">
                  <div className="flex items-center gap-2">
                    <PenTool className="w-4 h-4 text-[var(--md-sys-color-primary)]" />
                    <span className="text-sm font-semibold">Stylus Hover Target Ring</span>
                  </div>
                  <p className="text-xs text-[var(--md-sys-color-on-surface-variant)]">
                    Displays a real-time cursor ring matching your brush size when the stylus hovers above the screen.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={currentSettings.stylusSettings.showHoverCursor}
                  onChange={(e) => {
                    const updated = {
                      ...currentSettings,
                      stylusSettings: {
                        ...currentSettings.stylusSettings,
                        showHoverCursor: e.target.checked,
                      },
                    };
                    setCurrentSettings(updated);
                    onSaveSettings(updated);
                  }}
                  className="w-5 h-5 rounded accent-[var(--md-sys-color-primary)] cursor-pointer"
                />
              </div>

              {/* Shape Recognition */}
              <div className="flex items-center justify-between p-4 rounded-2xl bg-[var(--md-sys-color-surface-container-high)] border border-[var(--md-sys-color-outline-variant)]/50">
                <div className="space-y-0.5 max-w-[80%]">
                  <div className="flex items-center gap-2">
                    <Shapes className="w-4 h-4 text-[var(--md-sys-color-primary)]" />
                    <span className="text-sm font-semibold">Shape Recognition</span>
                  </div>
                  <p className="text-xs text-[var(--md-sys-color-on-surface-variant)]">
                    Automatically converts rough hand-drawn lines, circles, ovals, rectangles, squares, triangles and arrows into clean geometric shapes.
                  </p>
                </div>
                <input
                  type="checkbox"
                  id="toggle-shape-recognition"
                  checked={!!currentSettings.shapeRecognition}
                  onChange={(e) => {
                    updateSetting('shapeRecognition', e.target.checked);
                  }}
                  className="w-5 h-5 rounded accent-[var(--md-sys-color-primary)] cursor-pointer"
                />
              </div>

            </div>
          )}

          {/* TAB 3: BACKUP & PWA */}
          {activeTab === 'backup' && (
            <div className="space-y-5">
              
              {/* Full DB Backup & Restore */}
              <div className="p-4 rounded-2xl bg-[var(--md-sys-color-surface-container-high)] space-y-3">
                <h4 className="text-sm font-bold">Complete Local Storage Backup</h4>
                <p className="text-xs text-[var(--md-sys-color-on-surface-variant)]">
                  Export all boards, drawings, and preferences to a single JSON archive, or restore from a previous backup.
                </p>

                <div className="flex flex-wrap gap-3 pt-2">
                  <button
                    onClick={handleExportBackup}
                    className="flex items-center gap-2 px-4 py-2 rounded-full bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] text-xs font-medium hover:opacity-95 transition"
                  >
                    <Download className="w-4 h-4" />
                    <span>Export All Boards (.json)</span>
                  </button>

                  <input
                    type="file"
                    ref={backupInputRef}
                    accept=".json"
                    onChange={handleImportBackup}
                    className="hidden"
                  />

                  <button
                    onClick={() => backupInputRef.current?.click()}
                    className="flex items-center gap-2 px-4 py-2 rounded-full bg-[var(--md-sys-color-surface-container-highest)] text-[var(--md-sys-color-on-surface)] text-xs font-medium hover:bg-[var(--md-sys-color-outline-variant)] transition"
                  >
                    <UploadCloud className="w-4 h-4" />
                    <span>Restore Backup Archive</span>
                  </button>
                </div>

                {backupStatus && (
                  <div className="p-3 rounded-xl bg-[var(--md-sys-color-primary-container)] text-[var(--md-sys-color-on-primary-container)] text-xs font-medium animate-in fade-in">
                    {backupStatus}
                  </div>
                )}
              </div>

              {/* Progressive Web App (PWA) Section */}
              <div className="p-4 rounded-2xl bg-[var(--md-sys-color-surface-container-high)] space-y-3">
                <h4 className="text-sm font-bold">Install & Offline Shell</h4>
                <p className="text-xs text-[var(--md-sys-color-on-surface-variant)]">
                  xvBOARD runs fully offline using Service Workers and local IndexedDB. Install it on your tablet for a native full-screen experience.
                </p>
                <div className="pt-1">
                  <PWAInstallButton />
                </div>
              </div>

            </div>
          )}

        </div>

        {/* Footer */}
        <div className="flex items-center justify-end px-6 py-3 border-t border-[var(--md-sys-color-outline-variant)] bg-[var(--md-sys-color-surface-container-low)]">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-full bg-[var(--md-sys-color-primary)] text-[var(--md-sys-color-on-primary)] text-sm font-medium hover:opacity-95 transition active:scale-95"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
