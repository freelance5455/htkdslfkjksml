import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Search, X, MessageSquare, Clock, ArrowRight } from 'lucide-react';
import { ChatSession } from '../types/index.ts';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  sessions: ChatSession[];
  onSelectSession: (id: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  sessions,
  onSelectSession,
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  const searchResults = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();

    const results: Array<{
      session: ChatSession;
      matchedMessages: Array<{
        id: string;
        content: string;
        role: 'user' | 'model';
        timestamp: number;
      }>;
    }> = [];

    for (const session of sessions) {
      const titleMatch = session.title.toLowerCase().includes(q);
      const matchedMessages = session.messages.filter((m) =>
        m.content.toLowerCase().includes(q)
      );

      if (titleMatch || matchedMessages.length > 0) {
        results.push({
          session,
          matchedMessages: matchedMessages.slice(0, 3), // preview first 3
        });
      }
    }

    return results;
  }, [sessions, query]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 p-3 sm:p-4 bg-black/70 backdrop-blur-xs">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col max-h-[80vh] overflow-hidden">
        {/* Search Input Bar */}
        <div className="p-3.5 border-b border-slate-800 flex items-center gap-2.5 bg-slate-950/80">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Cari pesan atau topik percakapan..."
            className="w-full bg-transparent text-sm text-slate-100 placeholder-slate-400 focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded-md text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="text-xs text-slate-400 hover:text-white px-2 py-1 rounded bg-slate-800"
          >
            Esc
          </button>
        </div>

        {/* Results List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {!query.trim() ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              Ketik kata kunci untuk mencari di seluruh riwayat obrolan lokal Anda.
            </div>
          ) : searchResults.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              Tidak ditemukan hasil untuk "{query}".
            </div>
          ) : (
            searchResults.map(({ session, matchedMessages }) => (
              <div
                key={session.id}
                onClick={() => {
                  onSelectSession(session.id);
                  onClose();
                }}
                className="group p-3 rounded-xl bg-slate-850/60 hover:bg-slate-800 border border-slate-800 hover:border-indigo-500/50 cursor-pointer transition"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2 font-semibold text-xs text-slate-200 group-hover:text-indigo-300">
                    <MessageSquare className="w-3.5 h-3.5 text-indigo-400" />
                    <span>{session.title}</span>
                  </div>
                  <div className="flex items-center gap-1 text-[11px] text-slate-400">
                    <Clock className="w-3 h-3 text-slate-400" />
                    <span>
                      {new Date(session.updatedAt).toLocaleDateString('id-ID', {
                        day: 'numeric',
                        month: 'short',
                      })}
                    </span>
                    <ArrowRight className="w-3 h-3 ml-1 text-slate-400 group-hover:text-indigo-400 transition" />
                  </div>
                </div>

                {/* Snippets */}
                {matchedMessages.length > 0 && (
                  <div className="space-y-1 mt-1 pl-5 border-l border-slate-700/60">
                    {matchedMessages.map((m) => (
                      <div key={m.id} className="text-[11px] text-slate-400 line-clamp-1">
                        <span className="font-semibold text-slate-400">
                          {m.role === 'user' ? 'Anda: ' : 'AI: '}
                        </span>
                        {m.content}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
