import { useEffect, useMemo, useRef, useState } from 'react';
import { allSearchablePages, getPageSearchText } from '../policeContent';
import PoliceIcon from './PoliceIcon';

interface SearchModalProps { isOpen: boolean; onClose: () => void; onNavigate: (id: string) => void; }

const SearchModal = ({ isOpen, onClose, onNavigate }: SearchModalProps) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setQuery('');
      requestAnimationFrame(() => inputRef.current?.focus());
    }
  }, [isOpen]);

  const results = useMemo(() => {
    const term = query.trim().toLowerCase();
    if (!term) return allSearchablePages.slice(0, 8);
    return allSearchablePages.filter((page) => getPageSearchText(page).includes(term)).sort((a, b) => {
      const aTitle = a.title.toLowerCase().startsWith(term) ? 0 : 1;
      const bTitle = b.title.toLowerCase().startsWith(term) ? 0 : 1;
      return aTitle - bTitle || a.title.localeCompare(b.title);
    }).slice(0, 20);
  }, [query]);

  if (!isOpen) return null;

  return (
    <div className="search-backdrop" role="dialog" aria-modal="true" aria-label="Search knowledge base" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <div className="search-dialog">
        <div className="search-input-row">
          <PoliceIcon name="search" className="h-6 w-6" />
          <input ref={inputRef} value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search law, powers, policy, equipment or scenarios..." />
          <button onClick={onClose} aria-label="Close search"><PoliceIcon name="close" className="h-5 w-5" /></button>
        </div>
        <div className="search-summary">{query ? `${results.length} result${results.length === 1 ? '' : 's'} for “${query}”` : 'Suggested pages'}</div>
        <div className="search-results">
          {results.length ? results.map((page) => (
            <button key={page.id} onClick={() => onNavigate(page.id)}>
              <span className="search-result-icon"><PoliceIcon name="document" className="h-5 w-5" /></span>
              <span><strong>{page.title}</strong><small>{page.category} · {page.summary}</small></span>
              <PoliceIcon name="chevron" className="h-4 w-4" />
            </button>
          )) : <div className="search-empty"><PoliceIcon name="search" className="h-9 w-9" /><strong>No matching guidance</strong><span>Try “arrest”, “search”, “force” or “video”.</span></div>}
        </div>
        <div className="search-help"><span>Search is not case sensitive and indexes full page text.</span><kbd>Esc to close</kbd></div>
      </div>
    </div>
  );
};

export default SearchModal;