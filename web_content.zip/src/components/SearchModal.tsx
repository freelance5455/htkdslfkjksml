import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { Ebook } from '../types';
import {
  Search,
  X,
  Clock,
  Trash2,
  ChevronRight,
  BookOpen,
  Check
} from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose }) => {
  const {
    ebooks,
    setSelectedEbook,
    recentSearches,
    addRecentSearch,
    clearRecentSearches,
    addToCart,
    purchasedBookIds,
    hasAccessToBook
  } = useApp();

  const [query, setQuery] = useState('');
  const [selectedLang, setSelectedLang] = useState<string>('All');
  const [freeOnly, setFreeOnly] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Filter books
  const filteredBooks = ebooks.filter((book) => {
    const matchesText =
      book.title.toLowerCase().includes(query.toLowerCase()) ||
      book.subtitle.toLowerCase().includes(query.toLowerCase()) ||
      book.targetExam.toLowerCase().includes(query.toLowerCase()) ||
      book.author.toLowerCase().includes(query.toLowerCase()) ||
      book.categoryId.toLowerCase().includes(query.toLowerCase()) ||
      book.subCategory.toLowerCase().includes(query.toLowerCase());

    const matchesLang =
      selectedLang === 'All' ||
      book.language.toLowerCase().includes(selectedLang.toLowerCase());

    const matchesFree = !freeOnly || book.isFree;

    return matchesText && matchesLang && matchesFree;
  });

  const handleSelectBook = (book: Ebook) => {
    if (query.trim()) {
      addRecentSearch(query);
    }
    setSelectedEbook(book);
    onClose();
  };

  const handleSearchShortcut = (term: string) => {
    setQuery(term);
    addRecentSearch(term);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-4 sm:pt-14 px-3 sm:px-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-950/80 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[85vh] z-10 animate-in fade-in zoom-in-95 duration-150">
        {/* Search Input Bar */}
        <div className="p-3 sm:p-4 bg-[#0B192C] text-white flex items-center gap-3 border-b border-[#1E3E62]">
          <Search className="w-5 h-5 text-amber-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && query.trim()) {
                addRecentSearch(query);
              }
            }}
            placeholder="Search exams (e.g. ADRE, Assam Police, Railway, SSC, ITI)..."
            className="w-full bg-transparent text-white placeholder-slate-400 text-sm sm:text-base outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-slate-400 hover:text-white rounded-full"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="text-xs text-slate-300 hover:text-amber-400 px-2.5 py-1 rounded-md bg-slate-800 transition-colors shrink-0"
          >
            ESC
          </button>
        </div>

        {/* Filter Pills */}
        <div className="px-3 sm:px-4 py-2 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-2 overflow-x-auto text-xs">
          <div className="flex items-center gap-1.5 shrink-0">
            <span className="text-slate-500 font-semibold mr-1">Language:</span>
            {['All', 'Assamese', 'English', 'Hindi'].map((lang) => (
              <button
                key={lang}
                onClick={() => setSelectedLang(lang)}
                className={`px-2.5 py-1 rounded-full text-xs font-medium transition-colors ${
                  selectedLang === lang
                    ? 'bg-[#0B192C] text-white font-bold'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>

          <label className="flex items-center gap-1.5 shrink-0 cursor-pointer select-none text-slate-700 font-semibold">
            <input
              type="checkbox"
              checked={freeOnly}
              onChange={(e) => setFreeOnly(e.target.checked)}
              className="rounded text-amber-500 focus:ring-amber-400"
            />
            <span className="text-emerald-700">Free Ebooks Only</span>
          </label>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-4">
          {/* Recent Searches & Popular Tags (shown when query is short) */}
          {!query && (
            <div>
              {recentSearches.length > 0 && (
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-slate-400" /> Recent Searches
                    </span>
                    <button
                      onClick={clearRecentSearches}
                      className="text-[11px] text-red-500 hover:text-red-700 flex items-center gap-1 font-medium"
                    >
                      <Trash2 className="w-3 h-3" /> Clear
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {recentSearches.map((term) => (
                      <button
                        key={term}
                        onClick={() => handleSearchShortcut(term)}
                        className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-amber-100 hover:text-amber-900 text-slate-700 text-xs font-medium transition-colors"
                      >
                        {term}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-2">
                  Popular Exam Topics
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    'ADRE Grade III 2026',
                    'Assam Police SI (UB/AB)',
                    'RRB NTPC CBT-1 & 2',
                    'Assam GK Encyclopedia',
                    'SSC CGL English',
                    'RRB ALP Technician',
                    'Assam Budget 2026-27'
                  ].map((topic) => (
                    <button
                      key={topic}
                      onClick={() => handleSearchShortcut(topic)}
                      className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:border-amber-400 hover:bg-amber-50/50 text-slate-800 text-xs font-medium transition-all"
                    >
                      {topic}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Search Results */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                {query ? `Results for "${query}" (${filteredBooks.length})` : `All Exam Ebooks (${filteredBooks.length})`}
              </span>
            </div>

            {filteredBooks.length === 0 ? (
              <div className="py-12 text-center text-slate-500">
                <BookOpen className="w-12 h-12 mx-auto text-slate-300 mb-2" />
                <p className="font-semibold text-slate-700">No matching ebooks found</p>
                <p className="text-xs text-slate-400 mt-1">
                  Try searching with terms like "Police", "Railway", "Assam", "SSC", or reset filters.
                </p>
                <button
                  onClick={() => {
                    setQuery('');
                    setSelectedLang('All');
                    setFreeOnly(false);
                  }}
                  className="mt-3 text-xs text-amber-600 font-bold hover:underline"
                >
                  Clear all search filters
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                {filteredBooks.map((book) => {
                  const owned = hasAccessToBook(book.id);
                  return (
                    <div
                      key={book.id}
                      className="group p-2.5 sm:p-3 rounded-xl border border-slate-200 hover:border-amber-400 bg-white hover:bg-amber-50/20 transition-all flex items-center justify-between gap-3 shadow-xs"
                    >
                      {/* Left: Book Cover Thumbnail */}
                      <div
                        onClick={() => handleSelectBook(book)}
                        className={`w-12 h-16 sm:w-14 sm:h-20 rounded-md bg-gradient-to-br ${book.coverGradient} flex flex-col justify-between p-1.5 text-white shrink-0 shadow-sm cursor-pointer group-hover:scale-105 transition-transform`}
                      >
                        <span className="text-[7px] font-extrabold uppercase tracking-tight text-amber-300 truncate">
                          {book.targetExam}
                        </span>
                        <span className="text-[8px] font-bold leading-tight line-clamp-2">
                          {book.title}
                        </span>
                        <span className="text-[7px] bg-black/40 px-1 rounded text-center">
                          {book.format}
                        </span>
                      </div>

                      {/* Middle: Title & Meta */}
                      <div
                        onClick={() => handleSelectBook(book)}
                        className="flex-1 min-w-0 cursor-pointer"
                      >
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-1.5 py-0.2 rounded">
                            {book.targetExam}
                          </span>
                          <span className="text-[10px] font-semibold text-slate-500">
                            {book.language}
                          </span>
                          {book.isFree && (
                            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.2 rounded">
                              FREE
                            </span>
                          )}
                        </div>
                        <h4 className="text-xs sm:text-sm font-bold text-[#0B192C] group-hover:text-blue-900 transition-colors line-clamp-1 mt-0.5">
                          {book.title}
                        </h4>
                        <p className="text-[11px] text-slate-500 line-clamp-1">
                          {book.publisher} • {book.pageCount} Pages • ★ {book.rating}
                        </p>
                      </div>

                      {/* Right: Price & Action */}
                      <div className="shrink-0 text-right flex flex-col items-end gap-1">
                        <div className="flex items-center gap-1.5">
                          {book.isFree ? (
                            <span className="text-xs sm:text-sm font-extrabold text-emerald-600">
                              FREE
                            </span>
                          ) : (
                            <>
                              <span className="text-xs sm:text-sm font-extrabold text-[#0B192C]">
                                ₹{book.price}
                              </span>
                              <span className="text-[10px] text-slate-400 line-through hidden sm:inline">
                                ₹{book.originalPrice}
                              </span>
                            </>
                          )}
                        </div>

                        {owned ? (
                          <button
                            onClick={() => handleSelectBook(book)}
                            className="text-[11px] font-bold bg-emerald-100 text-emerald-800 hover:bg-emerald-200 px-2.5 py-1 rounded-md transition-colors flex items-center gap-1"
                          >
                            <Check className="w-3 h-3 text-emerald-600" /> Read
                          </button>
                        ) : (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              addToCart(book);
                            }}
                            className="text-[11px] font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 px-2.5 py-1 rounded-md transition-colors shadow-xs"
                          >
                            Add to Cart
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
