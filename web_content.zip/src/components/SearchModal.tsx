import React, { useState } from 'react';
import { Search, X, User, Hash, ArrowRight, ShieldCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { UserProfile } from '../types';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectUser: (userId: string) => void;
}

const TRENDING_TAGS = [
  { tag: 'FaceLookApp', count: '14.2K posts' },
  { tag: 'AndroidPackaging', count: '8.4K posts' },
  { tag: 'MobileReels', count: '29.1K posts' },
  { tag: 'FreeApkWorkflow', count: '5.2K posts' },
  { tag: 'FirebaseDatabase', count: '12.8K posts' },
];

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectUser,
}) => {
  const { allUsers } = useAuth();
  const [queryText, setQueryText] = useState('');

  if (!isOpen) return null;

  const filteredUsers = queryText.trim()
    ? allUsers.filter(u => 
        u.displayName.toLowerCase().includes(queryText.toLowerCase()) ||
        u.username.toLowerCase().includes(queryText.toLowerCase()) ||
        u.bio?.toLowerCase().includes(queryText.toLowerCase())
      )
    : [];

  const handleUserClick = (userId: string) => {
    onSelectUser(userId);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-start justify-center p-3 sm:p-4 pt-12 sm:pt-16 animate-in fade-in duration-150">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-150">
        
        {/* Search Input Bar */}
        <div className="p-3.5 border-b border-slate-200 flex items-center gap-2.5">
          <Search className="w-5 h-5 text-[#1877F2] shrink-0" />
          <input
            type="text"
            value={queryText}
            onChange={(e) => setQueryText(e.target.value)}
            placeholder="Search users by name, @handle or topic..."
            className="w-full text-slate-800 placeholder-slate-400 text-sm sm:text-base focus:outline-hidden"
            autoFocus
          />
          {queryText && (
            <button
              onClick={() => setQueryText('')}
              className="text-slate-400 hover:text-slate-600 p-1"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="text-xs font-bold text-slate-500 hover:text-slate-800 px-2 py-1 rounded-md"
          >
            Cancel
          </button>
        </div>

        {/* Results Area */}
        <div className="max-h-[65vh] overflow-y-auto p-3">
          
          {queryText.trim() ? (
            <div>
              <p className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 px-2">
                Users ({filteredUsers.length})
              </p>

              {filteredUsers.length === 0 ? (
                <div className="text-center py-8 text-slate-500 text-sm">
                  No users found matching "{queryText}"
                </div>
              ) : (
                <div className="space-y-1">
                  {filteredUsers.map((u: UserProfile) => (
                    <div
                      key={u.id}
                      onClick={() => handleUserClick(u.id)}
                      className="p-2.5 rounded-xl hover:bg-slate-50 flex items-center justify-between cursor-pointer group transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={u.photoURL}
                          alt={u.displayName}
                          className="w-10 h-10 rounded-full object-cover ring-1 ring-slate-200"
                        />
                        <div>
                          <p className="font-bold text-sm text-slate-900 group-hover:text-[#1877F2] transition-colors flex items-center gap-1">
                            {u.displayName}
                            {u.isVerified && <span className="text-blue-500 text-xs">✓</span>}
                            {u.role === 'admin' && (
                              <span className="text-[10px] bg-amber-50 text-amber-700 font-bold px-1 rounded-sm">Admin</span>
                            )}
                          </p>
                          <p className="text-xs text-slate-500">@{u.username}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 text-xs text-blue-600 font-semibold group-hover:translate-x-1 transition-transform">
                        <span>Profile</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div>
              {/* Community Suggested Users */}
              <div className="mb-4">
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 px-2">
                  Featured Creators
                </p>
                <div className="space-y-1">
                  {allUsers.slice(0, 3).map((u) => (
                    <div
                      key={u.id}
                      onClick={() => handleUserClick(u.id)}
                      className="p-2.5 rounded-xl hover:bg-slate-50 flex items-center justify-between cursor-pointer group transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={u.photoURL}
                          alt={u.displayName}
                          className="w-10 h-10 rounded-full object-cover ring-1 ring-slate-200"
                        />
                        <div>
                          <p className="font-bold text-sm text-slate-900 group-hover:text-[#1877F2] transition-colors flex items-center gap-1">
                            {u.displayName}
                            {u.isVerified && <span className="text-blue-500 text-xs">✓</span>}
                          </p>
                          <p className="text-xs text-slate-500">@{u.username}</p>
                        </div>
                      </div>
                      <span className="text-xs font-bold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-full group-hover:bg-[#1877F2] group-hover:text-white transition-colors">
                        View
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Trending Hashtags */}
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 px-2">
                  Trending on FaceLook
                </p>
                <div className="space-y-1">
                  {TRENDING_TAGS.map((item, idx) => (
                    <div
                      key={idx}
                      onClick={() => setQueryText(item.tag)}
                      className="p-2.5 rounded-xl hover:bg-slate-50 flex items-center justify-between cursor-pointer transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full bg-blue-50 text-[#1877F2] flex items-center justify-center font-bold">
                          <Hash className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="font-bold text-xs text-slate-800">#{item.tag}</p>
                          <p className="text-[11px] text-slate-400">{item.count}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
