import { useState } from 'react'
import { db } from '../db/database'
import { round2 } from '../lib/format'

export default function ProductForm({ product, onClose, onSaved }) {
  const [form, setForm] = useState({
    name: product?.name || '',
    category: product?.category || '',
    barcode: product?.barcode || '',
    mrp: product?.mrp ?? 0,
    price: product?.price ?? 0,
    stock: product?.stock ?? 0,
  })
  const [error, setError] = useState('')
  const isEdit = Boolean(product?.id)

  function set(k, v) {
    setForm((f) => ({ ...f, [k]: v }))
  }

  async function save() {
    if (!form.name.trim()) return setError('Product name chahiye')
    if (!form.barcode.trim()) return setError('Barcode chahiye')
    const payload = { ...form, stock: round2(form.stock) }

    try {
      if (isEdit) {
        await db.products.update(product.id, payload)
      } else {
        await db.products.add(payload)
      }
      onSaved()
    } catch (e) {
      setError(`Save nahi hua: ${e.name === 'ConstraintError' ? 'Duplicate barcode. Check karo.' : (e.message || e)}`)
    }
  }

  return (
    <div className="scanner-overlay" role="dialog" aria-modal="true">
      <div className="scanner-card form-card">
        <div className="scanner-header">
          <strong>{isEdit ? 'Edit Product' : 'Naya Product'}</strong>
          <button className="btn btn-ghost" aria-label="Band karo" onClick={onClose}>
            ✕
          </button>
        </div>

        {['name', 'category', 'barcode'].map((key) => (
          <label className="field" key={key}>
            <span className="field-label">{key === 'name' ? 'Name' : key === 'category' ? 'Category' : 'Barcode'}</span>
            <input
              className="input"
              value={form[key]}
              onChange={(e) => set(key, e.target.value)}
              placeholder={key === 'category' ? 'e.g. Ration, Milk, Sabzi' : ''}
            />
          </label>
        ))}

        <div className="row">
          <label className="field grow">
            <span className="field-label">MRP</span>
            <input
              className="input"
              type="number"
              inputMode="decimal"
              value={form.mrp}
              onChange={(e) => set('mrp', Number(e.target.value))}
            />
          </label>
          <label className="field grow">
            <span className="field-label">Sale Price</span>
            <input
              className="input"
              type="number"
              inputMode="decimal"
              value={form.price}
              onChange={(e) => set('price', Number(e.target.value))}
            />
          </label>
        </div>

        <label className="field">
          <span className="field-label">Stock quantity</span>
          <input
            className="input"
            type="number"
            inputMode="decimal"
            step="any"
            value={form.stock}
            onChange={(e) => set('stock', Number(e.target.value))}
          />
          <span className="field-hint muted small">Kilo/gram ke liye decimal likho, e.g. 2.5</span>
        </label>

        {error && <p className="error">{error}</p>}

        <button className="btn btn-primary btn-big" onClick={save}>
          {isEdit ? 'Save (update)' : 'Add Product'}
        </button>
      </div>
    </div>
  )
}