import React, { useState } from 'react';
import {
  TrendingUp,
  BarChart2,
  ListOrdered,
  Award,
  Layers,
  ArrowUpRight,
  ArrowDownLeft,
  Receipt,
} from 'lucide-react';
import { CalculatedProduct, StoreData, Transaction } from '../types';
import { aggregatePeriod } from '../utils/storage';
import { formatMoney, formatNumber, formatDisplayDate } from '../utils/formatters';
import { feedback } from '../utils/haptics';

interface ReportsViewProps {
  store: StoreData;
  calculated: Record<string, CalculatedProduct>;
  onViewReceipt: (txn: Transaction) => void;
  soundEnabled?: boolean;
  hapticsEnabled?: boolean;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  store,
  calculated,
  onViewReceipt,
  soundEnabled = true,
  hapticsEnabled = true,
}) => {
  const [subTab, setSubTab] = useState<'sum' | 'ana' | 'txn'>('sum');
  const [period, setPeriod] = useState<'day' | 'month' | 'year'>('month');

  const calcList = Object.values(calculated);
  const totalRev = calcList.reduce((s, x) => s + x.rev, 0);
  const totalCogs = calcList.reduce((s, x) => s + x.cogs, 0);
  const totalProfit = totalRev - totalCogs;
  const overallMargin = totalRev > 0 ? (totalProfit / totalRev) * 100 : 0;

  // Period data
  const periodRows = aggregatePeriod(store, period);
  const sliceCount = period === 'day' ? 30 : period === 'month' ? 14 : 10;
  const displayRows = periodRows.slice(-sliceCount);
  const reversedRows = [...displayRows].reverse();

  const totalBuy = displayRows.reduce((s, r) => s + r.buy, 0);
  const totalRRev = displayRows.reduce((s, r) => s + r.rev, 0);
  const totalRCogs = displayRows.reduce((s, r) => s + r.cogs, 0);
  const totalRProfit = totalRRev - totalRCogs;

  // Top products
  const topRevenueProducts = [...calcList].sort((a, b) => b.rev - a.rev).slice(0, 8);
  const maxProdRev = Math.max(1, ...(topRevenueProducts.map((p) => p.rev)));
  const topProfitProduct = [...calcList].sort((a, b) => b.profit - a.profit)[0];
  const slowestMover = [...calcList].sort((a, b) => a.sold - b.sold)[0];

  // Best month
  const monthlyData = aggregatePeriod(store, 'month');
  const bestMonth = [...monthlyData].sort((a, b) => b.pr - a.pr)[0];

  // Category summary
  const catSummary: Record<string, { rev: number; cogs: number; profit: number; value: number }> = {};
  calcList.forEach((item) => {
    const c = item.p.cat || 'General';
    if (!catSummary[c]) {
      catSummary[c] = { rev: 0, cogs: 0, profit: 0, value: 0 };
    }
    catSummary[c].rev += item.rev;
    catSummary[c].cogs += item.cogs;
    catSummary[c].profit += item.profit;
    catSummary[c].value += item.stockValue;
  });

  const productMap = Object.fromEntries(store.products.map((p) => [p.id, p]));

  return (
    <div className="space-y-4 pb-20">
      {/* Sub Tabs */}
      <div className="flex gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 text-xs">
        {[
          { id: 'sum', label: 'Financial Register', icon: BarChart2 },
          { id: 'ana', label: 'Business Insights', icon: TrendingUp },
          { id: 'txn', label: 'All Transactions', icon: ListOrdered },
        ].map((t) => {
          const Icon = t.icon;
          const isActive = subTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => {
                setSubTab(t.id as any);
                feedback.vibrateSoft(hapticsEnabled);
                feedback.playTap(soundEnabled);
              }}
              className={`flex-1 py-2 px-2 rounded-xl font-semibold flex items-center justify-center gap-1.5 transition ${
                isActive
                  ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {subTab === 'sum' && (
        <div className="space-y-4">
          {/* Period selector */}
          <div className="flex items-center justify-between">
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Time Granularity
            </div>
            <div className="flex gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs">
              {(
                [
                  ['day', 'Daily'],
                  ['month', 'Monthly'],
                  ['year', 'Yearly'],
                ] as const
              ).map(([p, label]) => (
                <button
                  key={p}
                  onClick={() => {
                    setPeriod(p);
                    feedback.vibrateSoft(hapticsEnabled);
                  }}
                  className={`px-3 py-1 rounded-lg font-medium transition ${
                    period === p
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs font-bold'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Register Table */}
          <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <div className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300">
                Period Register Breakdown
              </div>
              <span className="text-[11px] text-slate-400">Past {displayRows.length} periods</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 text-[11px]">
                    <th className="text-left font-medium pb-2 whitespace-nowrap">Period</th>
                    <th className="text-right font-medium pb-2 whitespace-nowrap">Purchases</th>
                    <th className="text-right font-medium pb-2 whitespace-nowrap">Revenue</th>
                    <th className="text-right font-medium pb-2 whitespace-nowrap">Cost</th>
                    <th className="text-right font-medium pb-2 whitespace-nowrap">Net Profit</th>
                    <th className="text-right font-medium pb-2 whitespace-nowrap">Margin</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {reversedRows.map((row) => (
                    <tr key={row.key} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="py-2.5 font-semibold text-slate-800 dark:text-slate-200 whitespace-nowrap font-mono text-[11px]">
                        {row.key}
                      </td>
                      <td className="py-2.5 text-right text-slate-600 dark:text-slate-300 whitespace-nowrap">
                        {formatMoney(row.buy, store.cur)}
                      </td>
                      <td className="py-2.5 text-right font-semibold text-slate-900 dark:text-white whitespace-nowrap">
                        {formatMoney(row.rev, store.cur)}
                      </td>
                      <td className="py-2.5 text-right text-slate-500 whitespace-nowrap">
                        {formatMoney(row.cogs, store.cur)}
                      </td>
                      <td
                        className={`py-2.5 text-right font-bold whitespace-nowrap ${
                          row.pr >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-500'
                        }`}
                      >
                        {formatMoney(row.pr, store.cur)}
                      </td>
                      <td className="py-2.5 text-right font-medium text-slate-600 dark:text-slate-400 whitespace-nowrap">
                        {row.margin.toFixed(0)}%
                      </td>
                    </tr>
                  ))}

                  {/* Summary row */}
                  <tr className="font-bold border-t-2 border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60">
                    <td className="py-2.5 font-bold text-slate-900 dark:text-white">TOTAL</td>
                    <td className="py-2.5 text-right text-slate-900 dark:text-white">
                      {formatMoney(totalBuy, store.cur)}
                    </td>
                    <td className="py-2.5 text-right text-slate-900 dark:text-white">
                      {formatMoney(totalRRev, store.cur)}
                    </td>
                    <td className="py-2.5 text-right text-slate-600 dark:text-slate-300">
                      {formatMoney(totalRCogs, store.cur)}
                    </td>
                    <td
                      className={`py-2.5 text-right ${
                        totalRProfit >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-500'
                      }`}
                    >
                      {formatMoney(totalRProfit, store.cur)}
                    </td>
                    <td className="py-2.5 text-right text-slate-900 dark:text-white">
                      {totalRRev > 0 ? ((totalRProfit / totalRRev) * 100).toFixed(0) : 0}%
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {subTab === 'ana' && (
        <div className="space-y-4">
          {/* Executive Insights Banner */}
          <div className="p-4 rounded-3xl bg-linear-to-br from-slate-900 to-slate-800 text-white shadow-md">
            <div className="flex items-center gap-2 text-xs font-bold text-red-400 uppercase tracking-wider mb-2">
              <Award className="w-4 h-4" />
              Store Intelligence
            </div>
            <div className="text-sm space-y-1.5 leading-relaxed text-slate-200">
              <div>
                Overall store gross margin is <strong className="text-emerald-400">{overallMargin.toFixed(1)}%</strong> on {formatMoney(totalRev, store.cur)} total invoiced sales.
              </div>
              {topProfitProduct && (
                <div>
                  Highest profit generator: <strong className="text-white">{topProfitProduct.p.name}</strong> ({formatMoney(topProfitProduct.profit, store.cur)} net profit).
                </div>
              )}
              {bestMonth && (
                <div>
                  Most lucrative month: <strong className="text-amber-300">{bestMonth.key}</strong> ({formatMoney(bestMonth.pr, store.cur)} profit).
                </div>
              )}
              {slowestMover && (
                <div className="text-xs text-slate-400 mt-2">
                  Slowest moving product: <span className="text-slate-300">{slowestMover.p.name}</span> ({formatNumber(slowestMover.sold)} {slowestMover.p.unit} sold so far).
                </div>
              )}
            </div>
          </div>

          {/* Revenue by Product Progress Bars */}
          <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-3">
              Top Selling Products by Revenue
            </div>

            <div className="space-y-3">
              {topRevenueProducts.map((item) => {
                const pct = (item.rev / maxProdRev) * 100;
                return (
                  <div key={item.p.id} className="text-xs">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-semibold text-slate-800 dark:text-slate-200 truncate pr-2">
                        {item.p.name}
                      </span>
                      <span className="font-bold text-slate-900 dark:text-white shrink-0">
                        {formatMoney(item.rev, store.cur)}
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-blue-600 dark:bg-blue-500 h-full rounded-full transition-all duration-500"
                        style={{ width: `${Math.max(3, pct)}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-[10px] text-slate-400 mt-0.5">
                      <span>{formatNumber(item.sold)} {item.p.unit} sold</span>
                      <span className="text-emerald-600 dark:text-emerald-400 font-medium">
                        Profit: {formatMoney(item.profit, store.cur)}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* By Category Breakdown */}
          <div className="p-4 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
            <div className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-3">
              Category Performance
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 text-[11px]">
                    <th className="text-left font-medium pb-2">Category</th>
                    <th className="text-right font-medium pb-2">Revenue</th>
                    <th className="text-right font-medium pb-2">Profit</th>
                    <th className="text-right font-medium pb-2">Stock Value</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {Object.entries(catSummary).map(([catName, stats]) => (
                    <tr key={catName}>
                      <td className="py-2.5 font-semibold text-slate-800 dark:text-slate-200">
                        {catName}
                      </td>
                      <td className="py-2.5 text-right font-semibold text-slate-900 dark:text-white">
                        {formatMoney(stats.rev, store.cur)}
                      </td>
                      <td
                        className={`py-2.5 text-right font-bold ${
                          stats.profit >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-500'
                        }`}
                      >
                        {formatMoney(stats.profit, store.cur)}
                      </td>
                      <td className="py-2.5 text-right text-slate-500">
                        {formatMoney(stats.value, store.cur)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {subTab === 'txn' && (
        <div className="space-y-2.5">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            All Chronological Entries ({store.txns.length})
          </div>

          {store.txns.slice(0, 50).map((t) => {
            const p = productMap[t.pid];
            const isSale = t.type === 'S';
            const total = t.qty * t.rate;

            return (
              <div
                key={t.id}
                className="p-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                      isSale ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-100 text-blue-700'
                    }`}
                  >
                    {isSale ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownLeft className="w-4 h-4" />}
                  </div>
                  <div>
                    <div className="font-semibold text-slate-900 dark:text-white">
                      {p ? p.name : 'Unknown Item'}
                    </div>
                    <div className="text-[11px] text-slate-400">
                      {t.date} • {t.cust || (isSale ? 'Customer' : 'Supplier')}
                    </div>
                  </div>
                </div>

                <div className="text-right flex items-center gap-3">
                  <div>
                    <div className={`font-bold ${isSale ? 'text-emerald-600' : 'text-blue-600'}`}>
                      {formatMoney(total, store.cur)}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      {t.qty} × {formatMoney(t.rate, store.cur)}
                    </div>
                  </div>
                  <button
                    onClick={() => onViewReceipt(t)}
                    className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-red-600 transition"
                    title="View Receipt"
                  >
                    <Receipt className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
