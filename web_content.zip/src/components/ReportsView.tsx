import React, { useMemo, useState } from 'react';
import type { ReportPayload, SalesStatementPayload, StoreData } from '../types';
import { fmtDateTime, fmtInt, fmtMoney, toDateKey } from '../utils';
import { Icon } from './Icon';
import { CustomDatePicker, CustomSelect } from './SharedUI';
import { SheetPrintPreviewModal, SheetPreviewTarget } from './SheetPrintPreview';

interface ReportsViewProps {
  data: StoreData;
  t: Record<string, string>;
  onPrintReport: (report: ReportPayload) => void;
  onPrintStatement: (statement: SalesStatementPayload) => void;
}

type StatementPeriod = 'today' | 'week' | 'last30' | 'this_month' | 'specific_month' | 'year' | 'custom';
type ReportTab = 'shop' | 'statement' | 'inventory' | 'category' | 'movement' | 'profit' | 'expenses';

const MONTH_NAMES = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

export const ReportsView: React.FC<ReportsViewProps> = ({ data, t, onPrintReport, onPrintStatement }) => {
  const [tab, setTab] = useState<ReportTab>('shop');
  const [previewTarget, setPreviewTarget] = useState<SheetPreviewTarget | null>(null);

  const now = new Date();
  const [period, setPeriod] = useState<StatementPeriod>('today');
  const [selMonth, setSelMonth] = useState<string>(String(now.getMonth()));
  const [selYear, setSelYear] = useState<string>(String(now.getFullYear()));
  const [customStart, setCustomStart] = useState<string>(toDateKey(new Date(now.getFullYear(), now.getMonth(), 1)));
  const [customEnd, setCustomEnd] = useState<string>(toDateKey(now));

  const [catFilter, setCatFilter] = useState<string>('all');
  const [stockStatusFilter, setStockStatusFilter] = useState<'all' | 'in_stock' | 'low' | 'out'>('all');

  const availableYears = useMemo(() => {
    const years = new Set<number>([now.getFullYear(), now.getFullYear() - 1, now.getFullYear() + 1]);
    data.sales.forEach((s) => years.add(new Date(s.date).getFullYear()));
    (data.expenses || []).forEach((e) => years.add(new Date(e.date).getFullYear()));
    return Array.from(years)
      .sort((a, b) => b - a)
      .map((y) => ({ value: String(y), label: String(y) }));
  }, [data.sales, data.expenses, now]);

  const monthOptions = useMemo(() => MONTH_NAMES.map((m, idx) => ({ value: String(idx), label: m })), []);

  const categoryFilterOptions = useMemo(
    () => [
      { value: 'all', label: t.allCategories },
      ...data.categories.map((c) => ({ value: c.name, label: c.name })),
    ],
    [data.categories, t.allCategories]
  );

  const statementRange = useMemo(() => {
    const today = new Date();
    const todayKey = toDateKey(today);

    if (period === 'today') {
      return {
        startKey: todayKey,
        endKey: todayKey,
        label: `Today (${today.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })})`,
        fileTag: `today-${todayKey}`,
      };
    }
    if (period === 'week') {
      const start = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 6);
      const startKey = toDateKey(start);
      return {
        startKey,
        endKey: todayKey,
        label: `Last 7 Days (${start.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} – ${today.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })})`,
        fileTag: `week-${startKey}-to-${todayKey}`,
      };
    }
    if (period === 'last30') {
      const start = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 29);
      const startKey = toDateKey(start);
      return {
        startKey,
        endKey: todayKey,
        label: `Last 30 Days (${start.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} – ${today.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })})`,
        fileTag: `30days-${startKey}-to-${todayKey}`,
      };
    }
    if (period === 'this_month') {
      const y = today.getFullYear();
      const m = today.getMonth();
      const startKey = toDateKey(new Date(y, m, 1));
      const endKey = toDateKey(new Date(y, m + 1, 0));
      return {
        startKey,
        endKey,
        label: `${MONTH_NAMES[m]} ${y}`,
        fileTag: `month-${y}-${String(m + 1).padStart(2, '0')}`,
      };
    }
    if (period === 'specific_month') {
      const y = Number(selYear) || today.getFullYear();
      const m = Number(selMonth) || 0;
      const startKey = toDateKey(new Date(y, m, 1));
      const endKey = toDateKey(new Date(y, m + 1, 0));
      return {
        startKey,
        endKey,
        label: `${MONTH_NAMES[m]} ${y}`,
        fileTag: `month-${y}-${String(m + 1).padStart(2, '0')}`,
      };
    }
    if (period === 'year') {
      const y = Number(selYear) || today.getFullYear();
      return {
        startKey: `${y}-01-01`,
        endKey: `${y}-12-31`,
        label: `Full Year ${y}`,
        fileTag: `year-${y}`,
      };
    }
    const s = customStart || todayKey;
    const e = customEnd || todayKey;
    return {
      startKey: s <= e ? s : e,
      endKey: s <= e ? e : s,
      label: `${s <= e ? s : e} to ${s <= e ? e : s}`,
      fileTag: `custom-${s}-to-${e}`,
    };
  }, [period, selMonth, selYear, customStart, customEnd]);

  const filteredStockProducts = useMemo(() => {
    return data.products.filter((p) => {
      if (catFilter !== 'all' && p.category !== catFilter) return false;
      const minLimit = p.minStock ?? data.settings.defaultLowStockLimit;
      if (stockStatusFilter === 'in_stock' && p.quantity <= 0) return false;
      if (stockStatusFilter === 'low' && (p.quantity === 0 || p.quantity > minLimit)) return false;
      if (stockStatusFilter === 'out' && p.quantity !== 0) return false;
      return true;
    });
  }, [data.products, catFilter, stockStatusFilter, data.settings.defaultLowStockLimit]);

  const categoryStockRows = useMemo(() => {
    const map: Record<string, { items: number; qty: number; cost: number; retail: number }> = {};
    data.categories.forEach((c) => {
      map[c.name] = { items: 0, qty: 0, cost: 0, retail: 0 };
    });
    data.products.forEach((p) => {
      const key = p.category || 'Other';
      if (!map[key]) map[key] = { items: 0, qty: 0, cost: 0, retail: 0 };
      map[key].items += 1;
      map[key].qty += p.quantity;
      map[key].cost += p.quantity * p.purchasePrice;
      map[key].retail += p.quantity * p.sellingPrice;
    });
    return Object.entries(map)
      .filter(([cat]) => catFilter === 'all' || cat === catFilter)
      .map(([cat, v]) => ({
        category: cat,
        productCount: v.items,
        totalUnits: v.qty,
        costValue: v.cost,
        retailValue: v.retail,
        potentialProfit: v.retail - v.cost,
      }));
  }, [data.categories, data.products, catFilter]);

  const statementPayload: SalesStatementPayload = useMemo(() => {
    const { startKey, endKey, label } = statementRange;
    const periodSales = data.sales
      .filter((s) => {
        const dk = toDateKey(s.date);
        return dk >= startKey && dk <= endKey;
      })
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    const periodExpenses = (data.expenses || []).filter((ex) => {
      const dk = toDateKey(ex.date);
      return dk >= startKey && dk <= endKey;
    });

    let itemsCount = 0;
    let subtotal = 0;
    let discount = 0;
    let grandTotal = 0;
    let paid = 0;
    let due = 0;
    let grossProfit = 0;
    const payMap: Record<string, { count: number; amount: number }> = {};

    const rows = periodSales.map((s, idx) => {
      const itemQty = s.items.reduce((sum, it) => sum + it.qty, 0);
      itemsCount += itemQty;
      subtotal += s.subtotal;
      discount += s.discount;
      grandTotal += s.grandTotal;
      paid += s.paidAmount;
      due += s.dueAmount;
      grossProfit += s.profit;

      const pm = s.paymentMethod || 'Cash';
      if (!payMap[pm]) payMap[pm] = { count: 0, amount: 0 };
      payMap[pm].count += 1;
      payMap[pm].amount += s.grandTotal;

      return {
        sl: idx + 1,
        date: fmtDateTime(s.date),
        invoiceNo: s.invoiceNo,
        customerName: s.customerName,
        itemsCount: itemQty,
        paymentMethod: t[pm] || pm,
        subtotal: s.subtotal,
        discount: s.discount,
        grandTotal: s.grandTotal,
        paidAmount: s.paidAmount,
        dueAmount: s.dueAmount,
        profit: s.profit,
      };
    });

    const expensesTotal = periodExpenses.reduce((sum, ex) => sum + Number(ex.amount || 0), 0);
    const cogs = grandTotal - grossProfit;
    const marginPct = grandTotal > 0 ? (grossProfit / grandTotal) * 100 : 0;
    const netProfit = grossProfit - expensesTotal;

    const paymentBreakdown = Object.entries(payMap).map(([method, v]) => ({
      method: t[method] || method,
      count: v.count,
      amount: v.amount,
    }));

    const stockRows = filteredStockProducts.map((p, idx) => {
      const minLimit = p.minStock ?? data.settings.defaultLowStockLimit;
      const status = p.quantity === 0 ? 'Out of Stock' : p.quantity <= minLimit ? 'Low Stock' : 'In Stock';
      return {
        sl: idx + 1,
        name: p.name + (p.model ? ` (${p.model})` : ''),
        code: p.barcode || p.sku || '-',
        category: p.category,
        quantity: p.quantity,
        purchasePrice: p.purchasePrice,
        sellingPrice: p.sellingPrice,
        costValue: p.quantity * p.purchasePrice,
        retailValue: p.quantity * p.sellingPrice,
        status,
      };
    });

    return {
      title: tab === 'shop' ? `${t.shopStatement} — ${label}` : `${t.salesStatement} — ${label}`,
      periodLabel: label,
      generatedAt: fmtDateTime(new Date().toISOString()),
      summary: {
        ordersCount: periodSales.length,
        itemsCount,
        subtotal,
        discount,
        grandTotal,
        paid,
        due,
        cogs,
        grossProfit,
        marginPct,
        expenses: expensesTotal,
        netProfit,
      },
      paymentBreakdown,
      ...(tab === 'shop' ? { categorySummary: categoryStockRows, stockRows } : {}),
      rows,
    };
  }, [data.sales, data.expenses, statementRange, t, tab, filteredStockProducts, categoryStockRows, data.settings.defaultLowStockLimit]);

  const reportPayload: ReportPayload = useMemo(() => {
    if (tab === 'inventory') {
      const totalUnits = filteredStockProducts.reduce((s, p) => s + p.quantity, 0);
      const totalCost = filteredStockProducts.reduce((s, p) => s + p.quantity * p.purchasePrice, 0);
      const totalRetail = filteredStockProducts.reduce((s, p) => s + p.quantity * p.sellingPrice, 0);
      const isCatSpecific = catFilter !== 'all';
      return {
        title: isCatSpecific ? `${catFilter} — Product List Sheet` : t.repInventory,
        sheetBanner: isCatSpecific
          ? `${catFilter} Product List Table (${filteredStockProducts.length} products · ${totalUnits} units)`
          : undefined,
        categoryName: isCatSpecific ? catFilter : undefined,
        subtitle: `${catFilter === 'all' ? t.allCategories : catFilter} · ${filteredStockProducts.length} products · ${totalUnits} units`,
        summaryCards: [
          { label: 'Products Listed', value: fmtInt(filteredStockProducts.length) },
          { label: 'Total Stock Units', value: fmtInt(totalUnits) },
          { label: 'Stock Cost Value', value: fmtMoney(totalCost) },
          { label: 'Stock Retail Value', value: fmtMoney(totalRetail) },
        ],
        headers: ['SL #', t.productName, t.barcode, t.category, t.quantity, t.purchasePrice, t.sellingPrice, t.costValue, t.retailValue, t.status],
        rows: filteredStockProducts.map((p, idx) => {
          const minLimit = p.minStock ?? data.settings.defaultLowStockLimit;
          const st = p.quantity === 0 ? 'Out of Stock' : p.quantity <= minLimit ? 'Low Stock' : 'In Stock';
          return [
            idx + 1,
            p.name + (p.model ? ` (${p.model})` : ''),
            p.barcode || p.sku || '-',
            p.category,
            p.quantity,
            p.purchasePrice.toFixed(2),
            p.sellingPrice.toFixed(2),
            (p.quantity * p.purchasePrice).toFixed(2),
            (p.quantity * p.sellingPrice).toFixed(2),
            st,
          ];
        }),
        totalsRow: ['', 'GRAND TOTAL', '', `${filteredStockProducts.length} items`, totalUnits, '-', '-', totalCost.toFixed(2), totalRetail.toFixed(2), ''],
      };
    }
    if (tab === 'category') {
      const totalProds = categoryStockRows.reduce((s, r) => s + r.productCount, 0);
      const totalUnits = categoryStockRows.reduce((s, r) => s + r.totalUnits, 0);
      const totalCost = categoryStockRows.reduce((s, r) => s + r.costValue, 0);
      const totalRetail = categoryStockRows.reduce((s, r) => s + r.retailValue, 0);
      return {
        title: t.repCategory,
        subtitle: `${categoryStockRows.length} categories`,
        summaryCards: [
          { label: 'Categories', value: fmtInt(categoryStockRows.length) },
          { label: 'Total Products', value: fmtInt(totalProds) },
          { label: 'Total Units', value: fmtInt(totalUnits) },
          { label: 'Potential Profit', value: fmtMoney(totalRetail - totalCost) },
        ],
        headers: ['SL #', t.category, t.totalProducts, t.units, t.costValue, t.retailValue, t.potentialProfit],
        rows: categoryStockRows.map((c, idx) => [
          idx + 1,
          c.category,
          c.productCount,
          c.totalUnits,
          c.costValue.toFixed(2),
          c.retailValue.toFixed(2),
          c.potentialProfit.toFixed(2),
        ]),
        totalsRow: ['', 'GRAND TOTAL', totalProds, totalUnits, totalCost.toFixed(2), totalRetail.toFixed(2), (totalRetail - totalCost).toFixed(2)],
      };
    }
    if (tab === 'movement') {
      return {
        title: t.repMovement,
        subtitle: `${data.movements.length} recorded movements`,
        headers: ['SL #', t.date, t.productName, t.movementType, t.prevQty, t.change, t.newQty, t.reason],
        rows: data.movements.map((m, idx) => [
          idx + 1,
          fmtDateTime(m.date),
          m.productName,
          t[m.type] || m.type,
          m.prevQty,
          m.delta >= 0 ? `+${m.delta}` : m.delta,
          m.newQty,
          m.reason || '-',
        ]),
      };
    }
    if (tab === 'expenses') {
      const exps = data.expenses || [];
      const totalExp = exps.reduce((s, e) => s + Number(e.amount || 0), 0);
      return {
        title: t.repExpenses,
        subtitle: `${exps.length} expense entries`,
        summaryCards: [
          { label: 'Total Entries', value: fmtInt(exps.length) },
          { label: 'Total Expenses', value: fmtMoney(totalExp) },
        ],
        headers: ['SL #', t.date, t.expenseTitle, t.expenseCategory, t.paymentMethod, t.amount, t.notes],
        rows: exps.map((ex, idx) => [
          idx + 1,
          toDateKey(ex.date),
          ex.title,
          t[`exp_${ex.category}`] || ex.category,
          t[ex.paymentMethod] || ex.paymentMethod,
          Number(ex.amount).toFixed(2),
          ex.notes || '-',
        ]),
        totalsRow: ['', 'GRAND TOTAL', '', '', '', totalExp.toFixed(2), ''],
      };
    }
    const totalRev = data.sales.reduce((s, x) => s + x.grandTotal, 0);
    const totalProfit = data.sales.reduce((s, x) => s + x.profit, 0);
    const totalCost = totalRev - totalProfit;
    const avgMargin = totalRev > 0 ? ((totalProfit / totalRev) * 100).toFixed(1) : '0.0';
    return {
      title: t.repProfit,
      subtitle: `${data.sales.length} invoices`,
      summaryCards: [
        { label: 'Invoices', value: fmtInt(data.sales.length) },
        { label: 'Revenue', value: fmtMoney(totalRev) },
        { label: 'Cost (COGS)', value: fmtMoney(totalCost) },
        { label: 'Gross Profit', value: fmtMoney(totalProfit) },
      ],
      headers: ['SL #', t.invoiceNo, t.date, t.customer, t.revenue, t.costValue, t.profit, t.marginPct],
      rows: data.sales.map((s, idx) => {
        const cost = s.grandTotal - s.profit;
        const margin = s.grandTotal > 0 ? ((s.profit / s.grandTotal) * 100).toFixed(1) : '0.0';
        return [idx + 1, s.invoiceNo, fmtDateTime(s.date), s.customerName, s.grandTotal.toFixed(2), cost.toFixed(2), s.profit.toFixed(2), `${margin}%`];
      }),
      totalsRow: ['', 'GRAND TOTAL', '', '', totalRev.toFixed(2), totalCost.toFixed(2), totalProfit.toFixed(2), `${avgMargin}%`],
    };
  }, [tab, filteredStockProducts, categoryStockRows, data.movements, data.expenses, data.sales, data.settings.defaultLowStockLimit, catFilter, t]);

  const exportStatementCsv = () => {
    const esc = (val: string | number) => `"${String(val).replace(/"/g, '""')}"`;
    const st = statementPayload;
    const lines: string[] = [
      [data.settings.storeName || 'My Store', tab === 'shop' ? 'COMPLETE SHOP & STOCK STATEMENT' : 'SALES STATEMENT'].map(esc).join(','),
      ['Statement Period', st.periodLabel, 'Generated At', st.generatedAt].map(esc).join(','),
      '',
      ['SALES SUMMARY', 'Invoices', 'Items Sold', 'Gross Sales', 'Discounts', 'Net Sales', 'Paid Collected', 'Due', 'Cost (COGS)', 'Gross Profit', 'Expenses', 'Net Profit']
        .map(esc)
        .join(','),
      [
        'TOTAL',
        st.summary.ordersCount,
        st.summary.itemsCount,
        st.summary.subtotal.toFixed(2),
        st.summary.discount.toFixed(2),
        st.summary.grandTotal.toFixed(2),
        st.summary.paid.toFixed(2),
        st.summary.due.toFixed(2),
        st.summary.cogs.toFixed(2),
        st.summary.grossProfit.toFixed(2),
        st.summary.expenses.toFixed(2),
        st.summary.netProfit.toFixed(2),
      ]
        .map(esc)
        .join(','),
    ];

    if (st.categorySummary && st.categorySummary.length > 0) {
      lines.push('');
      lines.push(['CATEGORY STOCK SUMMARY', 'Products Count', 'Stock Units', 'Cost Value', 'Retail Value', 'Potential Profit'].map(esc).join(','));
      st.categorySummary.forEach((c) => {
        lines.push([c.category, c.productCount, c.totalUnits, c.costValue.toFixed(2), c.retailValue.toFixed(2), c.potentialProfit.toFixed(2)].map(esc).join(','));
      });
    }

    if (st.stockRows && st.stockRows.length > 0) {
      lines.push('');
      lines.push(['PRODUCT STOCK REGISTER'].map(esc).join(','));
      lines.push(['SL #', 'Product Name', 'Barcode / SKU', 'Category', 'Qty', 'Purchase Price', 'Selling Price', 'Cost Value', 'Retail Value', 'Status'].map(esc).join(','));
      st.stockRows.forEach((p) => {
        lines.push(
          [p.sl, p.name, p.code, p.category, p.quantity, p.purchasePrice.toFixed(2), p.sellingPrice.toFixed(2), p.costValue.toFixed(2), p.retailValue.toFixed(2), p.status]
            .map(esc)
            .join(',')
        );
      });
    }

    lines.push('');
    lines.push(['SALES INVOICES LEDGER'].map(esc).join(','));
    lines.push(['SL #', 'Date & Time', 'Invoice #', 'Customer', 'Items', 'Payment Method', 'Subtotal', 'Discount', 'Net Total', 'Paid', 'Due', 'Profit'].map(esc).join(','));
    st.rows.forEach((r) => {
      lines.push(
        [
          r.sl,
          r.date,
          r.invoiceNo,
          r.customerName,
          r.itemsCount,
          r.paymentMethod,
          r.subtotal.toFixed(2),
          r.discount.toFixed(2),
          r.grandTotal.toFixed(2),
          r.paidAmount.toFixed(2),
          r.dueAmount.toFixed(2),
          r.profit.toFixed(2),
        ]
          .map(esc)
          .join(',')
      );
    });
    lines.push(
      [
        '',
        'GRAND TOTAL',
        `${st.summary.ordersCount} invoices`,
        '',
        st.summary.itemsCount,
        '',
        st.summary.subtotal.toFixed(2),
        st.summary.discount.toFixed(2),
        st.summary.grandTotal.toFixed(2),
        st.summary.paid.toFixed(2),
        st.summary.due.toFixed(2),
        st.summary.grossProfit.toFixed(2),
      ]
        .map(esc)
        .join(',')
    );

    const blob = new Blob(['\uFEFF' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${tab === 'shop' ? 'shop-statement' : 'sales-statement'}-${statementRange.fileTag}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportGenericCsv = () => {
    const esc = (val: string | number) => `"${String(val).replace(/"/g, '""')}"`;
    const lines = [
      [data.settings.storeName || 'My Store', reportPayload.title].map(esc).join(','),
      ['Generated', fmtDateTime(new Date().toISOString())].map(esc).join(','),
      '',
      reportPayload.headers.map(esc).join(','),
      ...reportPayload.rows.map((r) => r.map(esc).join(',')),
      ...(reportPayload.totalsRow ? [reportPayload.totalsRow.map(esc).join(',')] : []),
    ];
    const blob = new Blob(['\uFEFF' + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${tab}-statement-${toDateKey(new Date())}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const tabs: [ReportTab, string][] = [
    ['shop', t.shopStatement],
    ['statement', t.salesStatement],
    ['inventory', t.repInventory],
    ['category', t.repCategory],
    ['movement', t.repMovement],
    ['profit', t.repProfit],
    ['expenses', t.repExpenses],
  ];

  const periodOptions: [StatementPeriod, string][] = [
    ['today', t.today],
    ['week', t.last7Days],
    ['last30', t.last30Days],
    ['this_month', t.thisMonth],
    ['specific_month', t.specificMonth],
    ['year', t.fullYear],
    ['custom', t.customRange],
  ];

  const isStatementView = tab === 'shop' || tab === 'statement';
  const showsStockFilters = tab === 'shop' || tab === 'inventory' || tab === 'category';

  return (
    <div className="space-y-4">
      {/* Top Tabs & Direct Download / Print Controls */}
      <div className="surface-card p-4 flex flex-wrap gap-3 items-center justify-between">
        <div className="flex flex-wrap gap-2">
          {tabs.map(([id, label]) => (
            <button
              type="button"
              key={id}
              onClick={() => setTab(id)}
              className={`option-chip ${tab === id ? 'option-chip-active' : ''}`}
            >
              {label}
            </button>
          ))}
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={isStatementView ? exportStatementCsv : exportGenericCsv}
            className="btn-secondary px-3.5 py-2 text-xs"
          >
            <Icon name="download" className="w-4 h-4 text-emerald-600" />
            <span>{t.downloadStatementCsv}</span>
          </button>
          <button
            type="button"
            onClick={() =>
              setPreviewTarget(
                isStatementView
                  ? { kind: 'statement', statement: statementPayload }
                  : { kind: 'report', report: reportPayload }
              )
            }
            className="btn-dark px-4 py-2 text-xs"
          >
            <Icon name="print" className="w-4 h-4" />
            <span>{t.printStatement}</span>
          </button>
        </div>
      </div>

      {/* Period & Category / Stock Filters */}
      {(isStatementView || showsStockFilters) && (
        <div className="surface-card p-4 space-y-3">
          {isStatementView && (
            <div className="flex flex-wrap items-center gap-2">
              {periodOptions.map(([id, label]) => (
                <button
                  type="button"
                  key={id}
                  onClick={() => setPeriod(id)}
                  className={`option-chip ${period === id ? 'option-chip-active' : ''}`}
                >
                  {label}
                </button>
              ))}
            </div>
          )}

          {isStatementView && period === 'specific_month' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-100 max-w-md">
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">Select Month</label>
                <CustomSelect value={selMonth} onChange={setSelMonth} options={monthOptions} />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">Select Year</label>
                <CustomSelect value={selYear} onChange={setSelYear} options={availableYears} />
              </div>
            </div>
          )}

          {isStatementView && period === 'year' && (
            <div className="pt-2 border-t border-slate-100 max-w-[200px]">
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Select Year</label>
              <CustomSelect value={selYear} onChange={setSelYear} options={availableYears} />
            </div>
          )}

          {isStatementView && period === 'custom' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-100 max-w-md">
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">{t.startDate}</label>
                <CustomDatePicker value={customStart} onChange={setCustomStart} allowClear={false} />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-500 mb-1">{t.endDate}</label>
                <CustomDatePicker value={customEnd} onChange={setCustomEnd} allowClear={false} />
              </div>
            </div>
          )}

          {showsStockFilters && (
            <div className={`flex flex-wrap items-center gap-3 ${isStatementView ? 'pt-2 border-t border-slate-100' : ''}`}>
              <div className="w-full sm:w-64">
                <CustomSelect value={catFilter} onChange={setCatFilter} options={categoryFilterOptions} searchable />
              </div>
              {tab !== 'category' && (
                <div className="flex flex-wrap gap-1.5">
                  {(
                    [
                      ['all', 'All Stock'],
                      ['in_stock', 'Available In Stock'],
                      ['low', t.lowStock],
                      ['out', t.outOfStock],
                    ] as const
                  ).map(([id, label]) => (
                    <button
                      type="button"
                      key={id}
                      onClick={() => setStockStatusFilter(id)}
                      className={`option-chip ${stockStatusFilter === id ? 'option-chip-active' : ''}`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Statement Sheet View */}
      {isStatementView ? (
        <div className="space-y-4">
          <div className="surface-card overflow-hidden">
            {/* Formal Sheet Header */}
            <div className="bg-slate-900 text-white px-5 py-4 flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-widest text-blue-300">
                  {data.settings.storeName || 'My Store'}
                </p>
                <h3 className="text-lg font-extrabold tracking-tight mt-0.5">
                  {tab === 'shop' ? 'COMPLETE SHOP & STOCK STATEMENT' : 'SALES STATEMENT SHEET'}
                </h3>
              </div>
              <div className="text-left sm:text-right text-xs tabular-nums">
                <p className="font-bold text-white">{statementPayload.periodLabel}</p>
                <p className="text-slate-300 mt-0.5">Generated: {statementPayload.generatedAt}</p>
              </div>
            </div>

            {/* Executive Summary Ledger Cells */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 border-b border-slate-200 divide-y sm:divide-y-0 divide-x divide-slate-200 bg-slate-50/70 tabular-nums">
              <div className="p-3.5">
                <p className="text-[11px] font-semibold text-slate-500">Period Invoices</p>
                <p className="text-lg font-extrabold text-slate-900 mt-0.5">{fmtInt(statementPayload.summary.ordersCount)}</p>
                <p className="text-[11px] text-slate-400">{fmtInt(statementPayload.summary.itemsCount)} items sold</p>
              </div>
              <div className="p-3.5">
                <p className="text-[11px] font-semibold text-slate-500">Net Sales Total</p>
                <p className="text-lg font-extrabold text-blue-700 mt-0.5">{fmtMoney(statementPayload.summary.grandTotal)}</p>
                <p className="text-[11px] text-slate-400">Disc: {fmtMoney(statementPayload.summary.discount)}</p>
              </div>
              <div className="p-3.5">
                <p className="text-[11px] font-semibold text-slate-500">Cash Collected</p>
                <p className="text-lg font-extrabold text-emerald-700 mt-0.5">{fmtMoney(statementPayload.summary.paid)}</p>
                <p className="text-[11px] text-rose-600 font-semibold">Due: {fmtMoney(statementPayload.summary.due)}</p>
              </div>
              <div className="p-3.5">
                <p className="text-[11px] font-semibold text-slate-500">Cost (COGS)</p>
                <p className="text-lg font-extrabold text-slate-800 mt-0.5">{fmtMoney(statementPayload.summary.cogs)}</p>
                <p className="text-[11px] text-slate-400">Margin: {statementPayload.summary.marginPct.toFixed(1)}%</p>
              </div>
              <div className="p-3.5">
                <p className="text-[11px] font-semibold text-slate-500">Gross Profit</p>
                <p className="text-lg font-extrabold text-emerald-600 mt-0.5">{fmtMoney(statementPayload.summary.grossProfit)}</p>
                <p className="text-[11px] text-slate-400">Before expenses</p>
              </div>
              <div className="p-3.5">
                <p className="text-[11px] font-semibold text-slate-500">Net Profit</p>
                <p className={`text-lg font-extrabold mt-0.5 ${statementPayload.summary.netProfit >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                  {fmtMoney(statementPayload.summary.netProfit)}
                </p>
                <p className="text-[11px] text-slate-400">Exp: {fmtMoney(statementPayload.summary.expenses)}</p>
              </div>
            </div>

            {statementPayload.paymentBreakdown.length > 0 && (
              <div className="px-5 py-3 bg-white border-b border-slate-200 flex flex-wrap items-center gap-3 text-xs tabular-nums">
                <span className="font-bold text-slate-600">Payment Summary:</span>
                {statementPayload.paymentBreakdown.map((pm) => (
                  <span
                    key={pm.method}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 border border-slate-200 font-semibold text-slate-800"
                  >
                    <span>{pm.method}</span>
                    <span className="text-slate-400">({pm.count})</span>
                    <span className="font-bold text-blue-700">{fmtMoney(pm.amount)}</span>
                  </span>
                ))}
              </div>
            )}

            {/* Category Stock Section (in Complete Shop Statement) */}
            {tab === 'shop' && statementPayload.categorySummary && (
              <div className="border-b border-slate-200">
                <div className="px-4 py-2.5 bg-slate-100 border-b border-slate-200 flex items-center justify-between">
                  <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-700">
                    Category-Wise Stock Breakdown
                  </h4>
                  <span className="text-xs font-semibold text-slate-500 tabular-nums">
                    {statementPayload.categorySummary.length} categories
                  </span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs sm:text-sm text-left tabular-nums border-collapse">
                    <thead className="bg-slate-50 text-slate-700 text-xs font-bold border-b border-slate-200">
                      <tr>
                        <th className="px-3 py-2.5 border-r border-slate-200 text-center w-12">SL #</th>
                        <th className="px-3 py-2.5 border-r border-slate-200">{t.category}</th>
                        <th className="px-3 py-2.5 border-r border-slate-200 text-right">Products</th>
                        <th className="px-3 py-2.5 border-r border-slate-200 text-right">Units in Stock</th>
                        <th className="px-3 py-2.5 border-r border-slate-200 text-right">{t.costValue}</th>
                        <th className="px-3 py-2.5 border-r border-slate-200 text-right">{t.retailValue}</th>
                        <th className="px-3 py-2.5 text-right">{t.potentialProfit}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {statementPayload.categorySummary.map((c, idx) => (
                        <tr key={c.category} className="odd:bg-white even:bg-slate-50/40">
                          <td className="px-3 py-2 border-r border-slate-200 text-center text-slate-500 font-semibold">{idx + 1}</td>
                          <td className="px-3 py-2 border-r border-slate-200 font-bold text-slate-900">{c.category}</td>
                          <td className="px-3 py-2 border-r border-slate-200 text-right font-semibold">{c.productCount}</td>
                          <td className="px-3 py-2 border-r border-slate-200 text-right font-bold text-blue-700">{c.totalUnits}</td>
                          <td className="px-3 py-2 border-r border-slate-200 text-right">{fmtMoney(c.costValue)}</td>
                          <td className="px-3 py-2 border-r border-slate-200 text-right font-semibold">{fmtMoney(c.retailValue)}</td>
                          <td className="px-3 py-2 text-right font-bold text-emerald-700">{fmtMoney(c.potentialProfit)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Product Stock Section (in Complete Shop Statement) */}
            {tab === 'shop' && statementPayload.stockRows && (
              <div className="border-b border-slate-200">
                <div className="px-4 py-2.5 bg-slate-100 border-b border-slate-200 flex items-center justify-between">
                  <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-700">
                    Available Product Stock Sheet
                  </h4>
                  <span className="text-xs font-semibold text-slate-500 tabular-nums">
                    {statementPayload.stockRows.length} products
                  </span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs sm:text-sm text-left tabular-nums border-collapse">
                    <thead className="bg-slate-50 text-slate-700 text-xs font-bold border-b border-slate-200">
                      <tr>
                        <th className="px-3 py-2.5 border-r border-slate-200 text-center w-12">SL #</th>
                        <th className="px-3 py-2.5 border-r border-slate-200 whitespace-nowrap">{t.productName}</th>
                        <th className="px-3 py-2.5 border-r border-slate-200 whitespace-nowrap">Barcode / SKU</th>
                        <th className="px-3 py-2.5 border-r border-slate-200 whitespace-nowrap">{t.category}</th>
                        <th className="px-3 py-2.5 border-r border-slate-200 text-right whitespace-nowrap">In Stock</th>
                        <th className="px-3 py-2.5 border-r border-slate-200 text-right whitespace-nowrap">Cost</th>
                        <th className="px-3 py-2.5 border-r border-slate-200 text-right whitespace-nowrap">Price</th>
                        <th className="px-3 py-2.5 border-r border-slate-200 text-right whitespace-nowrap">Stock Value</th>
                        <th className="px-3 py-2.5 whitespace-nowrap">{t.status}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {statementPayload.stockRows.length === 0 ? (
                        <tr>
                          <td colSpan={9} className="text-center py-8 text-slate-400">
                            No matching products in stock.
                          </td>
                        </tr>
                      ) : (
                        statementPayload.stockRows.map((p) => (
                          <tr key={p.sl + p.code} className="odd:bg-white even:bg-slate-50/40">
                            <td className="px-3 py-2 border-r border-slate-200 text-center text-slate-500 font-semibold">{p.sl}</td>
                            <td className="px-3 py-2 border-r border-slate-200 font-bold text-slate-900 whitespace-nowrap">{p.name}</td>
                            <td className="px-3 py-2 border-r border-slate-200 font-mono text-xs text-slate-600 whitespace-nowrap">{p.code}</td>
                            <td className="px-3 py-2 border-r border-slate-200 whitespace-nowrap">{p.category}</td>
                            <td className="px-3 py-2 border-r border-slate-200 text-right font-extrabold text-blue-700">{p.quantity}</td>
                            <td className="px-3 py-2 border-r border-slate-200 text-right">{fmtMoney(p.purchasePrice)}</td>
                            <td className="px-3 py-2 border-r border-slate-200 text-right font-semibold">{fmtMoney(p.sellingPrice)}</td>
                            <td className="px-3 py-2 border-r border-slate-200 text-right font-bold">{fmtMoney(p.costValue)}</td>
                            <td className="px-3 py-2 whitespace-nowrap font-bold text-xs">
                              <span
                                className={
                                  p.status === 'Out of Stock'
                                    ? 'text-rose-600'
                                    : p.status === 'Low Stock'
                                    ? 'text-amber-600'
                                    : 'text-emerald-700'
                                }
                              >
                                {p.status}
                              </span>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Structured Bordered Sales Ledger Table */}
            <div>
              {tab === 'shop' && (
                <div className="px-4 py-2.5 bg-slate-100 border-b border-slate-200 flex items-center justify-between">
                  <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-700">
                    Sales Invoices Ledger ({statementPayload.periodLabel})
                  </h4>
                  <span className="text-xs font-semibold text-slate-500 tabular-nums">
                    {statementPayload.rows.length} invoices
                  </span>
                </div>
              )}
              <div className="overflow-x-auto">
                <table className="w-full text-xs sm:text-sm text-left tabular-nums border-collapse">
                  <thead className="bg-slate-100 text-slate-700 text-xs font-bold border-b border-slate-300">
                    <tr>
                      <th className="px-3 py-3 border-r border-slate-200 text-center w-12">SL #</th>
                      <th className="px-3 py-3 border-r border-slate-200 whitespace-nowrap">Date & Time</th>
                      <th className="px-3 py-3 border-r border-slate-200 whitespace-nowrap">Invoice #</th>
                      <th className="px-3 py-3 border-r border-slate-200 whitespace-nowrap">Customer</th>
                      <th className="px-3 py-3 border-r border-slate-200 text-right whitespace-nowrap">Items</th>
                      <th className="px-3 py-3 border-r border-slate-200 whitespace-nowrap">Method</th>
                      <th className="px-3 py-3 border-r border-slate-200 text-right whitespace-nowrap">Subtotal</th>
                      <th className="px-3 py-3 border-r border-slate-200 text-right whitespace-nowrap">Disc.</th>
                      <th className="px-3 py-3 border-r border-slate-200 text-right whitespace-nowrap">Net Total</th>
                      <th className="px-3 py-3 border-r border-slate-200 text-right whitespace-nowrap">Paid</th>
                      <th className="px-3 py-3 border-r border-slate-200 text-right whitespace-nowrap">Due</th>
                      <th className="px-3 py-3 text-right whitespace-nowrap">Profit</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {statementPayload.rows.length === 0 ? (
                      <tr>
                        <td colSpan={12} className="text-center py-12 text-slate-400">
                          No sales recorded for {statementPayload.periodLabel}.
                        </td>
                      </tr>
                    ) : (
                      statementPayload.rows.map((r) => (
                        <tr key={r.invoiceNo + r.sl} className="hover:bg-blue-50/30 odd:bg-white even:bg-slate-50/40">
                          <td className="px-3 py-2.5 border-r border-slate-200 text-center font-semibold text-slate-500">{r.sl}</td>
                          <td className="px-3 py-2.5 border-r border-slate-200 text-xs text-slate-600 whitespace-nowrap">{r.date}</td>
                          <td className="px-3 py-2.5 border-r border-slate-200 font-mono font-bold text-blue-700 whitespace-nowrap">{r.invoiceNo}</td>
                          <td className="px-3 py-2.5 border-r border-slate-200 font-medium text-slate-800 whitespace-nowrap">{r.customerName}</td>
                          <td className="px-3 py-2.5 border-r border-slate-200 text-right">{r.itemsCount}</td>
                          <td className="px-3 py-2.5 border-r border-slate-200 whitespace-nowrap">{r.paymentMethod}</td>
                          <td className="px-3 py-2.5 border-r border-slate-200 text-right">{fmtMoney(r.subtotal)}</td>
                          <td className="px-3 py-2.5 border-r border-slate-200 text-right text-slate-500">{fmtMoney(r.discount)}</td>
                          <td className="px-3 py-2.5 border-r border-slate-200 text-right font-bold text-slate-900">{fmtMoney(r.grandTotal)}</td>
                          <td className="px-3 py-2.5 border-r border-slate-200 text-right text-emerald-700 font-semibold">{fmtMoney(r.paidAmount)}</td>
                          <td className="px-3 py-2.5 border-r border-slate-200 text-right text-rose-600 font-semibold">
                            {r.dueAmount > 0 ? fmtMoney(r.dueAmount) : '-'}
                          </td>
                          <td className="px-3 py-2.5 text-right font-bold text-emerald-700">{fmtMoney(r.profit)}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                  {statementPayload.rows.length > 0 && (
                    <tfoot className="bg-slate-900 text-white font-bold text-xs sm:text-sm border-t-2 border-slate-400">
                      <tr>
                        <td colSpan={4} className="px-3 py-3 border-r border-slate-700 uppercase tracking-wide">
                          Grand Total ({statementPayload.summary.ordersCount} Invoices)
                        </td>
                        <td className="px-3 py-3 border-r border-slate-700 text-right">{statementPayload.summary.itemsCount}</td>
                        <td className="px-3 py-3 border-r border-slate-700">-</td>
                        <td className="px-3 py-3 border-r border-slate-700 text-right">{fmtMoney(statementPayload.summary.subtotal)}</td>
                        <td className="px-3 py-3 border-r border-slate-700 text-right">{fmtMoney(statementPayload.summary.discount)}</td>
                        <td className="px-3 py-3 border-r border-slate-700 text-right text-blue-300">{fmtMoney(statementPayload.summary.grandTotal)}</td>
                        <td className="px-3 py-3 border-r border-slate-700 text-right text-emerald-300">{fmtMoney(statementPayload.summary.paid)}</td>
                        <td className="px-3 py-3 border-r border-slate-700 text-right text-rose-300">{fmtMoney(statementPayload.summary.due)}</td>
                        <td className="px-3 py-3 text-right text-emerald-300">{fmtMoney(statementPayload.summary.grossProfit)}</td>
                      </tr>
                    </tfoot>
                  )}
                </table>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="surface-card overflow-hidden">
          <div className="bg-slate-900 text-white px-5 py-4 flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-widest text-blue-300">
                {data.settings.storeName || 'My Store'}
              </p>
              <h3 className="text-base sm:text-lg font-extrabold">{reportPayload.title}</h3>
            </div>
            <div className="text-xs text-slate-300 tabular-nums text-left sm:text-right">
              {reportPayload.subtitle && <p className="font-bold text-white">{reportPayload.subtitle}</p>}
              <p>{reportPayload.rows.length} rows</p>
            </div>
          </div>

          {reportPayload.summaryCards && (
            <div className="grid grid-cols-2 sm:grid-cols-4 border-b border-slate-200 divide-x divide-slate-200 bg-slate-50/80 tabular-nums">
              {reportPayload.summaryCards.map((c) => (
                <div key={c.label} className="p-3.5">
                  <p className="text-[11px] font-semibold text-slate-500">{c.label}</p>
                  <p className="text-lg font-extrabold text-slate-900 mt-0.5">{c.value}</p>
                </div>
              ))}
            </div>
          )}

          <div className="overflow-x-auto">
            <table className="w-full text-xs sm:text-sm text-left tabular-nums border-collapse">
              <thead className="bg-slate-100 text-xs font-bold text-slate-700 border-b border-slate-300">
                <tr>
                  {reportPayload.headers.map((h, i) => (
                    <th key={i} className="px-3.5 py-3 border-r last:border-r-0 border-slate-200 whitespace-nowrap">
                      {h}
                    </th>
                  ))}
                {tab === 'category' && (
                  <th className="px-3.5 py-3 whitespace-nowrap text-right">Product List</th>
                )}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {reportPayload.rows.length === 0 ? (
                  <tr>
                    <td colSpan={reportPayload.headers.length + (tab === 'category' ? 1 : 0)} className="text-center py-10 text-slate-400">
                      {t.noData}
                    </td>
                  </tr>
                ) : (
                  reportPayload.rows.map((r, i) => (
                    <tr key={i} className="hover:bg-blue-50/30 odd:bg-white even:bg-slate-50/40 transition-colors">
                      {r.map((cell, j) => (
                        <td key={j} className="px-3.5 py-2.5 border-r last:border-r-0 border-slate-200 whitespace-nowrap">
                          {cell}
                        </td>
                      ))}
                      {tab === 'category' && (
                        <td className="px-3.5 py-2.5 text-right whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => {
                              setCatFilter(String(r[1]));
                              setTab('inventory');
                            }}
                            className="btn-secondary px-2.5 py-1 text-[11px] text-blue-700"
                          >
                            View Sheet ({r[2]})
                          </button>
                        </td>
                      )}
                    </tr>
                  ))
                )}
              </tbody>
              {reportPayload.totalsRow && reportPayload.rows.length > 0 && (
                <tfoot className="bg-slate-900 text-white font-bold text-xs sm:text-sm border-t-2 border-slate-400">
                  <tr>
                    {reportPayload.totalsRow.map((cell, j) => (
                      <td key={j} className="px-3.5 py-3 border-r last:border-r-0 border-slate-700 whitespace-nowrap">
                        {cell}
                      </td>
                    ))}
                    {tab === 'category' && <td className="px-3.5 py-3" />}
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </div>
      )}

      {/* White Page Excel/Salary-Sheet Print Preview Overlay */}
      <SheetPrintPreviewModal
        target={previewTarget}
        settings={data.settings}
        onClose={() => setPreviewTarget(null)}
        onTriggerNativePrint={(target) => {
          if (target.kind === 'statement') {
            onPrintStatement(target.statement);
          } else {
            onPrintReport(target.report);
          }
        }}
      />
    </div>
  );
};
