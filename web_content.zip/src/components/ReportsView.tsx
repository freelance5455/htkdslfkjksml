import React, { useMemo, useState } from 'react';
import { Download, FileSpreadsheet, Plus, Printer } from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  calculateOverallCommitteeTotals,
  calculateOverallLoanTotals,
  formatMoney,
  runDynamicReport,
  toCsvString,
} from '../engine/calculations';
import type { CustomReportConfig } from '../types/app';

export function downloadTextFile(filename: string, content: string, mime = 'text/plain;charset=utf-8') {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export const ReportsView: React.FC = () => {
  const { snapshot, setActiveRoute, setSettingsSection } = useApp();
  const {
    loanPersons,
    loanTransactions,
    committees,
    committeeTransactions,
    customRecords,
    fields,
    reports,
    settings,
  } = snapshot;

  const publishedReports = reports.filter((r) => r.status === 'published');
  const [selectedReportId, setSelectedReportId] = useState<string>('builtin-loan');

  const loanTotals = calculateOverallLoanTotals(loanPersons, loanTransactions);
  const commTotals = calculateOverallCommitteeTotals(committees, committeeTransactions);

  const activeCustomReport: CustomReportConfig | undefined = useMemo(() => {
    if (selectedReportId === 'builtin-loan') {
      return {
        id: 'builtin-loan',
        name: 'Loan Transactions Report',
        sourceType: 'loan',
        fieldIds: ['date', 'personName', 'type', 'amount', 'paymentMethod', 'transactionRef', 'remarks'],
        filters: [],
        sortBy: 'date',
        sortDir: 'desc',
        calculation: 'sum',
        status: 'published',
        createdAt: '',
        updatedAt: '',
      };
    }
    if (selectedReportId === 'builtin-committee') {
      return {
        id: 'builtin-committee',
        name: 'Committee Transactions Report',
        sourceType: 'committee',
        fieldIds: ['date', 'committeeName', 'personName', 'type', 'amount', 'paymentMethod', 'paymentRef', 'remarks'],
        filters: [],
        sortBy: 'date',
        sortDir: 'desc',
        calculation: 'sum',
        status: 'published',
        createdAt: '',
        updatedAt: '',
      };
    }
    return publishedReports.find((r) => r.id === selectedReportId);
  }, [selectedReportId, publishedReports]);

  const reportOutput = useMemo(() => {
    if (!activeCustomReport) return null;
    return runDynamicReport({
      report: activeCustomReport,
      loanPersons,
      loanTransactions,
      committees,
      committeeTransactions,
      customRecords,
      fields,
    });
  }, [activeCustomReport, loanPersons, loanTransactions, committees, committeeTransactions, customRecords, fields]);

  const handleExportCsv = () => {
    if (!reportOutput || !activeCustomReport) return;
    const csv = toCsvString(reportOutput.columns, reportOutput.rows);
    const safeName = activeCustomReport.name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    downloadTextFile(`${safeName}.csv`, csv, 'text/csv;charset=utf-8');
  };

  return (
    <div className="space-y-6">
      {/* Top Controls */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 flex flex-wrap items-center justify-between gap-4 no-print">
        <div className="flex flex-wrap items-center gap-3">
          <div>
            <label htmlFor="report-picker" className="block text-xs font-semibold text-slate-600 mb-1">
              Select Report
            </label>
            <select
              id="report-picker"
              value={selectedReportId}
              onChange={(e) => setSelectedReportId(e.target.value)}
              className="px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white min-w-[240px]"
            >
              <option value="builtin-loan">Built-in: Loan Transactions Report</option>
              <option value="builtin-committee">Built-in: Committee Ledger Report</option>
              {publishedReports.map((r) => (
                <option key={r.id} value={r.id}>
                  Custom: {r.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => {
              setActiveRoute('settings');
              setSettingsSection('reports');
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Reports Builder</span>
          </button>
          <button
            type="button"
            onClick={handleExportCsv}
            disabled={!reportOutput}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 cursor-pointer disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Export CSV</span>
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Print / PDF</span>
          </button>
        </div>
      </div>

      {/* Print header */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-200 pb-4">
          <div>
            <div className="text-xs font-semibold text-emerald-700">
              {settings.appName} · {settings.appSubtitle}
            </div>
            <h2 className="font-display text-xl font-bold text-slate-900 mt-0.5">
              {activeCustomReport?.name || 'Report'}
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Generated {new Date().toLocaleString()} · {reportOutput?.rows.length || 0} row(s)
            </p>
          </div>
          <div className="text-right text-xs text-slate-600 space-y-1 font-mono-num">
            <div>Remaining Loan Payable: {formatMoney(loanTotals.remainingPayable, settings)}</div>
            <div>Committee Receivable: {formatMoney(commTotals.totalReceivable, settings)}</div>
          </div>
        </div>

        {/* Grouped summary if configured */}
        {reportOutput?.groupedSummary && reportOutput.groupedSummary.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {reportOutput.groupedSummary.map((g) => (
              <div key={g.group} className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                <div className="text-xs font-semibold text-slate-700 truncate">{g.group}</div>
                <div className="mt-1 font-mono-num text-sm font-bold text-slate-900">
                  {g.count} record(s) · {formatMoney(g.aggregate, settings)}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Data Table */}
        {!reportOutput || reportOutput.rows.length === 0 ? (
          <div className="py-12 text-center text-sm text-slate-500 flex flex-col items-center gap-2">
            <FileSpreadsheet className="w-8 h-8 text-slate-300" aria-hidden="true" />
            <span>No records match this report criteria.</span>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                  {reportOutput.columns.map((col) => (
                    <th key={col.key} className="py-2.5 px-3 whitespace-nowrap">
                      {col.label}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {reportOutput.rows.map((row) => (
                  <tr key={row.id}>
                    {reportOutput.columns.map((col) => {
                      const val = row[col.key];
                      const isNum = typeof val === 'number';
                      return (
                        <td
                          key={col.key}
                          className={`py-2.5 px-3 ${isNum ? 'font-mono-num font-medium text-slate-900' : 'text-slate-700'}`}
                        >
                          {isNum && col.key === 'amount'
                            ? formatMoney(val, settings)
                            : Array.isArray(val)
                              ? val.join(', ')
                              : String(val ?? '-')}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
              {activeCustomReport && activeCustomReport.calculation !== 'none' && (
                <tfoot>
                  <tr className="border-t-2 border-slate-200 bg-slate-50 font-bold text-sm">
                    <td colSpan={Math.max(1, reportOutput.columns.length - 1)} className="py-3 px-3 text-slate-700 uppercase text-xs">
                      {activeCustomReport.calculation} Total
                    </td>
                    <td className="py-3 px-3 font-mono-num text-emerald-700">
                      {activeCustomReport.calculation === 'count'
                        ? reportOutput.totalAggregate
                        : formatMoney(reportOutput.totalAggregate, settings)}
                    </td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
