import { useMemo, useState, useEffect, lazy, Suspense } from 'react'
import {
  changeFor,
  db,
  customerBalance,
  findProductByBarcode,
  nameKey,
  saveBill,
  searchProducts,
  voidBill,
} from '../db/database'
import { inr, today, fmtQty, fmtTime, round2 } from '../lib/format'
import BillReceipt from './BillReceipt'

const BarcodeScanner = lazy(() => import('./BarcodeScanner'))

export default function SellerBill({ onBack }) {
  const [items, setItems] = useState([])
  const [scanning, setScanning] = useState(false)
  const [manualScan, setManualScan] = useState(false)
  const [manualCode, setManualCode] = useState('')
  const [searching, setSearching] = useState(false)
  const [query, setQuery] = useState('')
  const [quick, setQuick] = useState([])
  const [payMode, setPayMode] = useState(null)
  const [customerName, setCustomerName] = useState('')
  const [customerPhone, setCustomerPhone] = useState('')
  const [cashGiven, setCashGiven] = useState('')
  const [customers, setCustomers] = useState([])
  const [savedBill, setSavedBill] = useState(null)
  const [error, setError] = useState('')
  const [beep] = useState(() => {
    let ctx = null
    return () => {
      if (typeof window === 'undefined' || !('AudioContext' in window)) return
      if (!ctx) ctx = new AudioContext()
      if (ctx.state === 'suspended') ctx.resume()
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      osc.connect(gain)
      gain.connect(ctx.destination)
      osc.frequency.value = 880
      gain.gain.value = 0.15
      osc.start()
      osc.stop(ctx.currentTime + 0.12)
    }
  })

  const total = round2(items.reduce((s, i) => s + i.price * i.qty, 0))
  const overStock = items.filter((i) => i.qty > i.stock)
  const change = changeFor(total, cashGiven)
  const short = payMode === 'CASH' && cashGiven !== '' && change < 0

  useEffect(() => {
    searchProducts('').then(setQuick)
  }, [savedBill])

  useEffect(() => {
    if (payMode !== 'UDHAR') return undefined
    let alive = true
    ;(async () => {
      const all = await db.customers.toArray()
      const withBal = await Promise.all(
        all.map(async (c) => ({ ...c, ...(await customerBalance(c.id)) })),
      )
      if (alive) setCustomers(withBal.sort((a, b) => a.name.localeCompare(b.name)))
    })()
    return () => {
      alive = false
    }
  }, [payMode])

  const customerMatches = useMemo(() => {
    if (payMode !== 'UDHAR') return []
    const q = nameKey(customerName)
    if (!q) return customers.slice(0, 5)
    return customers.filter((c) => nameKey(c.name).includes(q)).slice(0, 5)
  }, [payMode, customerName, customers])

  const knownCustomer = useMemo(
    () => customers.find((c) => nameKey(c.name) === nameKey(customerName)) || null,
    [customerName, customers],
  )

  function pickCustomer(c) {
    setCustomerName(c.name)
    setCustomerPhone(c.phone || '')
    setError('')
  }

  function addItem(product, qty = 1) {
    setItems((prev) => {
      const idx = prev.findIndex((i) => i.productId === product.id)
      const stock = Number(product.stock) || 0
      if (idx >= 0) {
        const next = [...prev]
        next[idx] = { ...next[idx], qty: next[idx].qty + qty, stock }
        return next
      }
      return [
        ...prev,
        {
          productId: product.id,
          name: product.name,
          price: Number(product.price) || 0,
          mrp: Number(product.mrp) || 0,
          stock,
          qty,
        },
      ]
    })
  }

  async function handleScan(code) {
    const p = await findProductByBarcode(code)
    if (p) {
      beep()
      addItem(p)
      setScanning(false)
      setError('')
    } else {
      setScanning(false)
      setError(`Barcode ${code} product me nahi hai. Admin → Products me add karo.`)
      setTimeout(() => setError(''), 4000)
    }
  }

  function changeQty(productId, delta) {
    setItems((prev) =>
      prev
        .map((i) =>
          i.productId === productId ? { ...i, qty: round2(i.qty + delta) } : i,
        )
        .filter((i) => i.qty > 0),
    )
  }

  function setQty(productId, qty) {
    const n = Number(qty)
    if (!Number.isFinite(n) || n < 0) return
    setItems((prev) =>
      prev
        .map((i) => (i.productId === productId ? { ...i, qty: round2(n) } : i))
        .filter((i) => i.qty > 0),
    )
  }

  function removeItem(productId) {
    setItems((prev) => prev.filter((i) => i.productId !== productId))
  }

  function openPay() {
    if (items.length === 0) return
    setError('')
    setPayMode('CASH')
  }

  async function confirmPay() {
    if (!payMode) return
    if (payMode === 'UDHAR' && !customerName.trim()) {
      setError('Udhar ke liye customer naam chahiye')
      return
    }
    if (short) {
      setError(`${inr(total)} chahiye, ${inr(cashGiven)} mile — ${inr(-change)} baaki hai`)
      return
    }
    try {
      const saved = await saveBill({
        items,
        total,
        payMode,
        customerName,
        customerPhone,
        cashGiven,
      })
      const settings = await db.settings.bulkGet([
        'shopName',
        'shopAddress',
        'shopPhone',
      ])
      setSavedBill({
        id: saved.id,
        billNo: saved.billNo,
        items,
        total,
        payMode,
        customerName: saved.customerName || '',
        cashGiven: saved.cashGiven,
        changeReturned: saved.changeReturned,
        createdAt: saved.createdAt,
        shopName: settings[0]?.value || 'Mera Kirana',
        shopAddress: settings[1]?.value || '',
        shopPhone: settings[2]?.value || '',
      })
      setItems([])
      setCustomerName('')
      setCustomerPhone('')
      setCashGiven('')
      setPayMode(null)
    } catch (e) {
      setError(e.message)
    }
  }

  function cancelBill() {
    if (items.length > 0 && !window.confirm('Bill khaali karna hai?')) return
    setItems([])
    setPayMode(null)
    setCustomerName('')
    setCustomerPhone('')
    setCashGiven('')
  }

  async function voidSavedBill() {
    const reason = window.prompt('Void ka reason (optional):', 'Galat bill')
    if (reason === null) return
    try {
      await voidBill(savedBill.id, reason.trim())
      setSavedBill(null)
      setError('')
    } catch (e) {
      setError(e.message || 'Void nahi hua')
    }
  }

  if (savedBill) {
    return (
      <BillReceipt
        bill={savedBill}
        onNewBill={() => setSavedBill(null)}
        onBack={onBack}
        onVoid={savedBill.id ? voidSavedBill : null}
      />
    )
  }

  return (
    <div className="seller">
      <header className="topbar">
        <button className="btn btn-ghost" onClick={onBack}>
          ←
        </button>
        <strong>Bill — {today()} {fmtTime(new Date().toISOString())}</strong>
      </header>

      <div className="seller-actions">
        <button className="btn btn-primary btn-big" onClick={() => setScanning(true)}>
          📷 Scan Barcode
        </button>
        <button
          className={`btn ${manualScan ? 'btn-primary' : 'btn-outline'} btn-big`}
          onClick={() => {
            setManualScan((s) => !s)
            setManualCode('')
          }}
        >
          ⌨️ Barcode Type Karo
        </button>
        <button className="btn btn-outline btn-big" onClick={() => setSearching((s) => !s)}>
          🔍 Search Product
        </button>
      </div>

      {error && <p className="error">{error}</p>}

      {manualScan && (
        <label className="field">
          <span className="field-label">Barcode number type karo, phir Enter dabao</span>
          <input
            className="input"
            autoFocus
            value={manualCode}
            onChange={(e) => setManualCode(e.target.value)}
            onKeyDown={(e) => {
              if (e.key !== 'Enter') return
              const code = manualCode.trim()
              if (!code) return
              setManualCode('')
              handleScan(code)
            }}
            placeholder="e.g. 8901234567890"
          />
        </label>
      )}

      {searching && (
        <div className="search-area">
          <input
            className="input"
            placeholder="Naam / barcode type karo…"
            autoFocus
            value={query}
            onChange={(e) => {
              setQuery(e.target.value)
              searchProducts(e.target.value).then(setQuick)
            }}
          />
          <div className="quick-grid">
            {quick.slice(0, 30).map((p) => (
              <button key={p.id} className="quick-btn" onClick={() => addItem(p)}>
                <span className="quick-name">{p.name}</span>
                <span className="quick-price">{inr(p.price)}</span>
              </button>
            ))}
            {quick.length === 0 && <p className="muted">Koi product nahi mila</p>}
          </div>
        </div>
      )}

      <ul className="list cart">
        {items.map((i) => (
          <li key={i.productId} className="list-item cart-item">
            <div className="item-main">
              <div className="item-title">{i.name}</div>
              <div className="item-sub muted">{inr(i.price)} × {fmtQty(i.qty)}</div>
              <div className="item-sub muted small">Stock: {fmtQty(i.stock)}</div>
              {i.qty > i.stock && (
                <div className="item-sub small balance-due">
                  Stock {fmtQty(i.stock)} me se {fmtQty(round2(i.qty - i.stock))} zyada — Stock tab me update karo
                </div>
              )}
            </div>
            <div className="item-price">{inr(round2(i.price * i.qty))}</div>
            <div className="stepper">
              <button
                className="btn btn-small"
                aria-label="Qty kam karo"
                onClick={() => changeQty(i.productId, -1)}
              >
                −
              </button>
              <input
                className="qty-input"
                type="number"
                inputMode="decimal"
                step="any"
                aria-label={`${i.name} qty`}
                value={i.qty}
                onChange={(e) => setQty(i.productId, e.target.value)}
              />
              <button
                className="btn btn-small"
                aria-label="Qty badhao"
                onClick={() => changeQty(i.productId, 1)}
              >
                +
              </button>
            </div>
            <button
              className="btn btn-small btn-danger"
              aria-label={`${i.name} hatao`}
              onClick={() => removeItem(i.productId)}
            >
              ✕
            </button>
          </li>
        ))}
      </ul>

      {items.length === 0 && !searching && (
        <p className="muted center pad">Product scan karo ya search karke add karo</p>
      )}

      {payMode ? (
        <div className="pay-overlay" role="dialog" aria-modal="true">
          <div className="pay-card">
            <div className="pay-total">
              <span>Total</span>
              <span>{inr(total)}</span>
            </div>

            {overStock.length > 0 && (
              <p className="error">
                {overStock.length} item ka stock {overStock
                  .map((i) => `${i.name} (${i.qty}/${i.stock})`)
                  .join(', ')} — stock update nahi kiya gaya. Bill banayenge?
              </p>
            )}

            <div className="seg">
              {['CASH', 'UPI', 'UDHAR'].map((m) => (
                <button
                  key={m}
                  className={`seg-btn ${payMode === m ? 'active' : ''}`}
                  onClick={() => setPayMode(m)}
                >
                  {m}
                </button>
              ))}
            </div>

            {payMode === 'CASH' && (
              <>
                <label className="field">
                  <span className="field-label">Customer ne kitne diye?</span>
                  <div className="row">
                    <input
                      className="input grow"
                      type="number"
                      inputMode="decimal"
                      value={cashGiven}
                      onChange={(e) => setCashGiven(e.target.value)}
                      placeholder={inr(total)}
                    />
                    <button className="btn btn-outline" onClick={() => setCashGiven('')}>
                      Exact
                    </button>
                  </div>
                </label>

                {short ? (
                  <p className="error">
                    {inr(total - cashGiven)} baaki hai — pura paisa mila nahi
                  </p>
                ) : (
                  change > 0 && (
                    <div className="stat-card cash">
                      <div className="stat-label">Wapas dena hai (Change)</div>
                      <div className="stat-value">{inr(change)}</div>
                    </div>
                  )
                )}
              </>
            )}

            {payMode === 'UDHAR' && (
              <>
                <label className="field">
                  <span className="field-label">Customer naam</span>
                  <input
                    className="input"
                    autoFocus
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Naam likho ya neeche se chuno"
                  />
                </label>

                {customerMatches.length > 0 && (
                  <div className="quick-grid pay-cust-grid">
                    {customerMatches.map((c) => (
                      <button
                        key={c.id}
                        className={`quick-btn ${knownCustomer?.id === c.id ? 'active' : ''}`}
                        onClick={() => pickCustomer(c)}
                      >
                        <span className="quick-name">{c.name}</span>
                        <span className={`quick-price ${c.balance > 0 ? 'due' : ''}`}>
                          {c.balance > 0 ? `Laan ${inr(c.balance)}` : 'Koi laan nahi'}
                        </span>
                      </button>
                    ))}
                  </div>
                )}

                {knownCustomer && (
                  <p className="small green">
                    {knownCustomer.name} pehle se list me hai
                    {knownCustomer.balance > 0 && ` — ab total laan ${inr(knownCustomer.balance + total)} hoga`}
                  </p>
                )}

                <label className="field">
                  <span className="field-label">Phone (optional)</span>
                  <input
                    className="input"
                    inputMode="tel"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="98765 43210"
                  />
                </label>
              </>
            )}

            {error && <p className="error">{error}</p>}

            <div className="pay-actions">
              <button className="btn btn-ghost btn-big" onClick={() => setPayMode(null)}>
                ← Back
              </button>
              <button className="btn btn-primary btn-big" onClick={confirmPay}>
                ✓ Bill Save ({inr(total)})
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="bill-footer">
          <div className="bill-total">
            <span>Total</span>
            <span className="total-val">{inr(total)}</span>
          </div>
          {overStock.length > 0 && (
            <p className="small balance-due center">
              ⚠ {overStock.length} item stock se zyada hai. Bill ban jayega, stock 0 ho jayega.
            </p>
          )}
          <div className="bill-actions">
            <button className="btn btn-ghost btn-big" onClick={cancelBill}>
              🗑 New
            </button>
            <button
              className="btn btn-primary btn-big"
              disabled={items.length === 0}
              onClick={openPay}
            >
              Pay →
            </button>
          </div>
        </div>
      )}

      {scanning && (
        <Suspense
          fallback={
            <div className="scanner-loading">
              <div className="spinner" />
              <p className="muted">Camera khul raha hai…</p>
            </div>
          }
        >
          <BarcodeScanner onScan={handleScan} onClose={() => setScanning(false)} />
        </Suspense>
      )}
    </div>
  )
}