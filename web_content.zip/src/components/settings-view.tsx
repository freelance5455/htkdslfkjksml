import { ScreenHeader } from "@/components/phone-shell";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { getAiStatus } from "@/lib/ai/server";
import { useAppStore } from "@/lib/store";
import type { AutoDeleteDays, HandleMode, LisaVoiceId, Personality } from "@/lib/types";
import { useEffect, useState, type ReactNode } from "react";

export function SettingsView() {
  const settings = useAppStore((s) => s.settings);
  const updateSettings = useAppStore((s) => s.updateSettings);
  const events = useAppStore((s) => s.events);
  const setOverlay = useAppStore((s) => s.setOverlay);
  const [aiOn, setAiOn] = useState<boolean | null>(null);

  useEffect(() => {
    let alive = true;
    void getAiStatus().then((r) => {
      if (alive) setAiOn(r.available);
    });
    return () => {
      alive = false;
    };
  }, []);

  return (
    <div className="pb-8">
      <ScreenHeader title="Settings" subtitle="Calling, AI, privacy" />

      <Section title="Calling">
        <Row label="Default phone app" hint="ROLE_DIALER is an Android system role. Not available in this browser.">
          <span className="text-xs text-subtle">Browser</span>
        </Row>
        <Row label="Confirm before Lisa handles" hint="Always show Answer / Lisa Handles / Reject first.">
          <Switch
            checked={settings.confirmBeforeLisaHandles}
            onChange={(v) => updateSettings({ confirmBeforeLisaHandles: v })}
            label="Confirm before Lisa handles"
          />
        </Row>
        <Row label="Unknown callers">
          <Select
            value={settings.unknownCallers}
            onChange={(v) => updateSettings({ unknownCallers: v as HandleMode })}
            options={[
              ["never", "Never"],
              ["ask", "Ask me first"],
              ["allow", "Always"],
            ]}
          />
        </Row>
        <Row label="Known contacts">
          <Select
            value={settings.knownContacts}
            onChange={(v) => updateSettings({ knownContacts: v as HandleMode })}
            options={[
              ["never", "Never let Lisa handle"],
              ["ask", "Ask me first"],
              ["allow", "Allow Lisa"],
            ]}
          />
        </Row>
        <p className="px-5 pt-1 text-xs text-subtle">
          Per-contact rules in Contacts override these. Emergency numbers are never auto-handled.
        </p>
      </Section>

      <Section title="AI">
        <Row label="AI provider" hint={aiOn === false ? "xAI is unavailable in this environment." : "xAI Grok — key stays on the server."}>
          <Select
            value={settings.aiProvider}
            onChange={(v) => updateSettings({ aiProvider: v as "xai" | "lisa_assistant" })}
            options={[
              ["xai", "xAI Grok"],
              ["lisa_assistant", "Lisa assistant (later)"],
            ]}
          />
        </Row>
        <Row label="Voice">
          <Select
            value={settings.voiceId}
            onChange={(v) => updateSettings({ voiceId: v as LisaVoiceId })}
            options={[
              ["luna", "Luna"],
              ["carina", "Carina"],
              ["eve", "Eve"],
              ["iris", "Iris"],
              ["ara", "Ara"],
            ]}
          />
        </Row>
        <Row label={`Speaking speed  ${settings.speakingSpeed.toFixed(2)}x`}>
          <input
            type="range"
            min={0.85}
            max={1.15}
            step={0.05}
            value={settings.speakingSpeed}
            onChange={(e) => updateSettings({ speakingSpeed: Number(e.target.value) })}
            className="w-28 accent-accent"
          />
        </Row>
        <Row label="Personality">
          <Select
            value={settings.personality}
            onChange={(v) => updateSettings({ personality: v as Personality })}
            options={[
              ["professional", "Professional"],
              ["warm", "Warm"],
              ["concise", "Concise"],
            ]}
          />
        </Row>
        <Row label="Max AI call duration">
          <Select
            value={String(settings.maxAiCallMinutes)}
            onChange={(v) => updateSettings({ maxAiCallMinutes: Number(v) })}
            options={[
              ["2", "2 min"],
              ["5", "5 min"],
              ["10", "10 min"],
              ["15", "15 min"],
            ]}
          />
        </Row>
        <Row label="Answers for">
          <input
            value={settings.ownerName}
            onChange={(e) => updateSettings({ ownerName: e.target.value })}
            className="h-9 w-28 rounded-sm border border-border bg-muted px-2 text-sm outline-none"
          />
        </Row>
      </Section>

      <Section title="Privacy">
        <Row label="Save AI call transcripts">
          <Switch
            checked={settings.saveTranscripts}
            onChange={(v) => updateSettings({ saveTranscripts: v })}
            label="Save transcripts"
          />
        </Row>
        <Row label="Save call summaries">
          <Switch
            checked={settings.saveSummaries}
            onChange={(v) => updateSettings({ saveSummaries: v })}
            label="Save summaries"
          />
        </Row>
        <Row
          label="Save recordings"
          hint="Off. Android does not give third-party apps the cellular voice stream, and this app does not record calls."
        >
          <Switch checked={false} onChange={() => undefined} disabled label="Save recordings" />
        </Row>
        <Row label="Auto-delete AI data">
          <Select
            value={String(settings.autoDeleteDays)}
            onChange={(v) => updateSettings({ autoDeleteDays: Number(v) as AutoDeleteDays })}
            options={[
              ["0", "Never"],
              ["7", "7 days"],
              ["30", "30 days"],
              ["90", "90 days"],
            ]}
          />
        </Row>
        <div className="px-5 pt-2">
          <Button variant="outline" className="w-full" onClick={() => setOverlay({ kind: "confirm-delete" })}>
            Delete all AI call data
          </Button>
        </div>
      </Section>

      <Section title="Lisa integration">
        <Row
          label="Enable Lisa connection"
          hint="Talks to com.lisa.assistant through a private, non-exported channel when both apps are installed."
        >
          <Switch
            checked={settings.lisaIntegrationEnabled}
            onChange={(v) => updateSettings({ lisaIntegrationEnabled: v })}
            label="Enable Lisa connection"
          />
        </Row>
        <Row label="Connection status">
          <span className="text-xs text-subtle">
            {settings.lisaIntegrationEnabled ? "Waiting for Lisa assistant" : "Off"}
          </span>
        </Row>
        <Row label="Sync call summaries">
          <Switch
            checked={settings.syncSummaries}
            onChange={(v) => updateSettings({ syncSummaries: v })}
            disabled={!settings.lisaIntegrationEnabled}
            label="Sync summaries"
          />
        </Row>
        {settings.lisaIntegrationEnabled && events.length > 0 ? (
          <ul className="px-5 pt-2 text-xs text-muted-foreground">
            {events.slice(0, 5).map((e) => (
              <li key={e.id} className="border-t border-border py-2">
                {e.type.replaceAll("_", " ")}
              </li>
            ))}
          </ul>
        ) : null}
      </Section>

      <Section title="Platform">
        <div className="px-5">
          <Button variant="muted" className="w-full" onClick={() => setOverlay({ kind: "capabilities" })}>
            What Android actually allows
          </Button>
        </div>
      </Section>
    </div>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mb-6">
      <h2 className="px-5 pb-2 text-xs tracking-[0.16em] text-subtle uppercase">{title}</h2>
      <div className="divide-y divide-border border-y border-border bg-card">{children}</div>
    </section>
  );
}

function Row({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <div className="flex items-center gap-3 px-5 py-3">
      <div className="min-w-0 flex-1">
        <p className="text-sm">{label}</p>
        {hint ? <p className="mt-0.5 text-xs leading-snug text-subtle">{hint}</p> : null}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

function Select({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (v: string) => void;
  options: [string, string][];
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="h-9 max-w-[11rem] rounded-sm border border-border bg-muted px-2 text-sm outline-none"
    >
      {options.map(([v, l]) => (
        <option key={v} value={v}>
          {l}
        </option>
      ))}
    </select>
  );
}
