import React, { useState, useMemo } from 'react';
import { 
  Trophy, 
  Crown, 
  Medal, 
  Flame, 
  Coins, 
  TrendingUp, 
  Sparkles, 
  ChevronRight, 
  Award, 
  Clock, 
  Info, 
  ArrowUpRight, 
  ShieldCheck,
  CheckCircle2,
  X
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { User, MembershipTier } from '../../types';

interface GlobalLeaderboardProps {
  onOpenTasks?: () => void;
  onOpenWallet?: () => void;
  onOpenMembership?: () => void;
}

type TabType = 'balance' | 'lifetime' | 'streak';

export const GlobalLeaderboard: React.FC<GlobalLeaderboardProps> = ({
  onOpenTasks,
  onOpenWallet,
  onOpenMembership,
}) => {
  const { allUsers, currentUser, membershipPlans } = useApp();
  const [activeTab, setActiveTab] = useState<TabType>('balance');
  const [showAllRanks, setShowAllRanks] = useState(false);
  const [isRulesModalOpen, setIsRulesModalOpen] = useState(false);

  // Merge currentUser dynamically with allUsers to guarantee real-time reflection
  const leaderboardUsers = useMemo(() => {
    const userMap = new Map<string, User>();

    // Add all existing users
    allUsers.forEach((u) => {
      userMap.set(u.id, u);
    });

    // Overwrite with currentUser's latest live data
    if (currentUser) {
      userMap.set(currentUser.id, currentUser);
    }

    const list = Array.from(userMap.values()).filter((u) => u.isActive);

    // Sort according to active tab
    return list.sort((a, b) => {
      if (activeTab === 'balance') {
        return (b.coins || 0) - (a.coins || 0);
      } else if (activeTab === 'lifetime') {
        return (b.lifetimeCoins || 0) - (a.lifetimeCoins || 0);
      } else {
        return (b.checkinStreak || 0) - (a.checkinStreak || 0);
      }
    });
  }, [allUsers, currentUser, activeTab]);

  // Find Current User's current rank
  const currentUserRankIndex = useMemo(() => {
    if (!currentUser) return -1;
    return leaderboardUsers.findIndex((u) => u.id === currentUser.id);
  }, [leaderboardUsers, currentUser]);

  const currentUserRank = currentUserRankIndex !== -1 ? currentUserRankIndex + 1 : null;
  const nextUserAhead = currentUserRankIndex > 0 ? leaderboardUsers[currentUserRankIndex - 1] : null;

  // Podium Users (Top 3)
  const top1 = leaderboardUsers[0];
  const top2 = leaderboardUsers[1];
  const top3 = leaderboardUsers[2];

  // List users (4th and beyond)
  const restUsers = useMemo(() => {
    const list = leaderboardUsers.slice(3);
    return showAllRanks ? list : list.slice(0, 7);
  }, [leaderboardUsers, showAllRanks]);

  const getTierColor = (tier: MembershipTier) => {
    switch (tier) {
      case 'vip4':
      case 'pro':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      case 'vip3':
      case 'premium':
        return 'bg-purple-500/20 text-purple-300 border-purple-500/40';
      case 'vip2':
        return 'bg-sky-500/20 text-sky-300 border-sky-500/40';
      case 'vip1':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  const getTierLabel = (tier: MembershipTier) => {
    const plan = membershipPlans.find((p) => p.id === tier);
    return plan ? plan.name.split(' ')[0] : 'Basic';
  };

  return (
    <div className="p-2.5 sm:p-4 md:p-5 rounded-2xl sm:rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-2.5 sm:space-y-4 relative overflow-hidden">
      
      {/* Decorative gradient glow */}
      <div className="absolute top-0 right-1/4 w-52 h-52 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-44 h-44 bg-purple-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header with Title & Rules button */}
      <div className="flex items-center justify-between gap-2 relative z-10">
        <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
          <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl sm:rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-500 text-slate-950 flex items-center justify-center font-black shadow-lg shadow-amber-500/20 shrink-0">
            <Trophy className="w-4 h-4 sm:w-5 sm:h-5 fill-current" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <h3 className="text-xs sm:text-base font-black text-white tracking-tight">
                Global Leaderboard
              </h3>
              <span className="px-1.5 sm:px-2 py-0.2 sm:py-0.5 rounded-full text-[8px] sm:text-[9px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1 shrink-0">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>Live</span>
              </span>
            </div>
            <p className="text-[9px] sm:text-[11px] text-slate-400 truncate">
              Top earners and daily champions in Task Earn Pro
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setIsRulesModalOpen(true)}
          className="min-h-[40px] px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-slate-100 text-[10px] sm:text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer border border-slate-700/60 shrink-0"
          title="Leaderboard rules & weekly prize distribution"
        >
          <Info className="w-3.5 h-3.5" />
          <span className="text-[10px] sm:text-[11px]">Prizes</span>
        </button>
      </div>

      {/* Weekly Season Prize Banner */}
      <div className="p-2.5 sm:p-3.5 rounded-xl sm:rounded-2xl bg-gradient-to-r from-amber-950/40 via-purple-950/40 to-slate-900 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-2 sm:gap-2.5 relative z-10 text-xs">
        <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
          <div className="p-1.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40 shrink-0">
            <Sparkles className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1 sm:gap-1.5 flex-wrap">
              <span className="font-black text-amber-300 text-[11px] sm:text-xs">Season #4 Championship</span>
              <span className="text-[9px] sm:text-[10px] font-mono px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-bold shrink-0">
                10,000 Coins Pool
              </span>
            </div>
            <p className="text-[10px] sm:text-[11px] text-slate-300 line-clamp-1 sm:line-clamp-none">
              Top 3 win mega prizes this Sunday! 1st: +2,500 • 2nd: +1,500 • 3rd: +1,000
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1 text-[10px] sm:text-[11px] font-mono font-bold text-slate-300 bg-slate-950/60 px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-xl border border-slate-800 self-start sm:self-auto shrink-0">
          <Clock className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-amber-400" />
          <span>Ends in 2d 14h</span>
        </div>
      </div>

      {/* Category Tabs: Balance / Lifetime / Streak */}
      <div className="grid grid-cols-3 gap-1 p-1 rounded-2xl bg-slate-950 border border-slate-800/80 relative z-10 text-xs font-bold">
        <button
          type="button"
          onClick={() => setActiveTab('balance')}
          className={`min-h-[44px] py-1.5 px-1 sm:px-2 rounded-xl transition-all flex items-center justify-center gap-1 sm:gap-1.5 cursor-pointer text-center text-[10px] sm:text-xs ${
            activeTab === 'balance'
              ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-600/25'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Coins className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-amber-300" />
          <span className="truncate">Balance</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('lifetime')}
          className={`min-h-[44px] py-1.5 px-1 sm:px-2 rounded-xl transition-all flex items-center justify-center gap-1 sm:gap-1.5 cursor-pointer text-center text-[10px] sm:text-xs ${
            activeTab === 'lifetime'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md shadow-purple-600/25'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Trophy className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-yellow-300" />
          <span className="truncate">All-Time</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('streak')}
          className={`min-h-[44px] py-1.5 px-1 sm:px-2 rounded-xl transition-all flex items-center justify-center gap-1 sm:gap-1.5 cursor-pointer text-center text-[10px] sm:text-xs ${
            activeTab === 'streak'
              ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-black shadow-md shadow-amber-500/25'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Flame className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-orange-400 fill-current" />
          <span className="truncate">Streaks</span>
        </button>
      </div>

      {/* TOP 3 PODIUM */}
      <div className="pt-1.5 sm:pt-2 pb-1 relative z-10">
        <div className="grid grid-cols-3 gap-1.5 sm:gap-3 items-end max-w-md mx-auto">
          
          {/* #2 Silver (Left) */}
          {top2 && (
            <div className={`p-2 sm:p-3 rounded-xl sm:rounded-2xl border text-center flex flex-col items-center justify-between transition-all ${
              currentUser?.id === top2.id
                ? 'bg-slate-800/90 border-slate-400 ring-2 ring-slate-400/40'
                : 'bg-slate-950/80 border-slate-700/60'
            }`}>
              <div className="relative mb-1.5 sm:mb-2">
                <img
                  src={top2.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                  alt={top2.name}
                  className="w-10 h-10 sm:w-14 sm:h-14 rounded-full object-cover border-2 border-slate-300 shadow-md"
                />
                <span className="absolute -bottom-1 -right-1 w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-slate-300 text-slate-950 font-black text-[10px] sm:text-xs flex items-center justify-center border-2 border-slate-900 shadow-sm">
                  2
                </span>
              </div>

              <div className="w-full space-y-0.5">
                <span className="text-[11px] sm:text-xs font-bold text-white truncate block">
                  {top2.name.split(' ')[0]}
                </span>
                {top2.username && (
                  <span className="text-[9px] sm:text-[10px] font-semibold text-amber-400 truncate block">
                    {top2.username}
                  </span>
                )}
                <span className={`text-[8px] sm:text-[9px] font-bold px-1 sm:px-1.5 py-0.2 rounded-full border ${getTierColor(top2.membershipTier)}`}>
                  {getTierLabel(top2.membershipTier)}
                </span>
                <div className="pt-0.5 sm:pt-1">
                  <span className="text-[11px] sm:text-sm font-black text-amber-300 block">
                    {activeTab === 'streak' ? `${top2.checkinStreak || 0}d` : `${(activeTab === 'lifetime' ? top2.lifetimeCoins : top2.coins).toLocaleString()} C`}
                  </span>
                  <span className="text-[8px] sm:text-[9px] font-bold text-slate-400 block">+1,500 Prize</span>
                </div>
              </div>

              <div className="w-full mt-1.5 sm:mt-2 py-0.5 sm:py-1 bg-slate-800/80 rounded-lg text-[9px] sm:text-[10px] font-black text-slate-300">
                🥈 2nd Place
              </div>
            </div>
          )}

          {/* #1 Gold (Center, Elevated) */}
          {top1 && (
            <div className={`p-2.5 sm:p-3.5 rounded-2xl sm:rounded-3xl border text-center flex flex-col items-center justify-between transition-all transform -translate-y-2 relative shadow-xl shadow-amber-500/10 ${
              currentUser?.id === top1.id
                ? 'bg-amber-950/30 border-amber-400 ring-2 ring-amber-400/50'
                : 'bg-gradient-to-b from-amber-950/40 via-slate-900 to-slate-950 border-amber-500/60'
            }`}>
              {/* Crown on top */}
              <div className="absolute -top-3 text-amber-400 animate-bounce">
                <Crown className="w-5 h-5 sm:w-6 sm:h-6 fill-current filter drop-shadow-md" />
              </div>

              <div className="relative mb-1.5 sm:mb-2 mt-1 sm:mt-2">
                <img
                  src={top1.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100'}
                  alt={top1.name}
                  className="w-12 h-12 sm:w-16 sm:h-16 rounded-full object-cover border-2 border-amber-400 shadow-lg shadow-amber-500/30"
                />
                <span className="absolute -bottom-1 -right-1 w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-amber-400 text-slate-950 font-black text-[10px] sm:text-xs flex items-center justify-center border-2 border-slate-900 shadow-sm">
                  1
                </span>
              </div>

              <div className="w-full space-y-0.5">
                <span className="text-xs sm:text-sm font-black text-white truncate block">
                  {top1.name.split(' ')[0]}
                </span>
                {top1.username && (
                  <span className="text-[9px] sm:text-[10px] font-semibold text-amber-400 truncate block">
                    {top1.username}
                  </span>
                )}
                <span className={`text-[8px] sm:text-[9px] font-bold px-1 sm:px-1.5 py-0.2 rounded-full border ${getTierColor(top1.membershipTier)}`}>
                  {getTierLabel(top1.membershipTier)}
                </span>
                <div className="pt-0.5 sm:pt-1">
                  <span className="text-xs sm:text-base font-black text-amber-400 block">
                    {activeTab === 'streak' ? `${top1.checkinStreak || 0} Days` : `${(activeTab === 'lifetime' ? top1.lifetimeCoins : top1.coins).toLocaleString()} C`}
                  </span>
                  <span className="text-[9px] sm:text-[10px] font-bold text-amber-300 block">+2,500 Grand Prize</span>
                </div>
              </div>

              <div className="w-full mt-1.5 sm:mt-2 py-0.5 sm:py-1 bg-gradient-to-r from-amber-500 to-yellow-500 rounded-xl text-[9px] sm:text-[10px] font-black text-slate-950 shadow-md">
                👑 1st Champion
              </div>
            </div>
          )}

          {/* #3 Bronze (Right) */}
          {top3 && (
            <div className={`p-2 sm:p-3 rounded-xl sm:rounded-2xl border text-center flex flex-col items-center justify-between transition-all ${
              currentUser?.id === top3.id
                ? 'bg-amber-950/20 border-amber-700 ring-2 ring-amber-700/40'
                : 'bg-slate-950/80 border-amber-900/40'
            }`}>
              <div className="relative mb-1.5 sm:mb-2">
                <img
                  src={top3.avatar || 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=100'}
                  alt={top3.name}
                  className="w-10 h-10 sm:w-14 sm:h-14 rounded-full object-cover border-2 border-amber-700 shadow-md"
                />
                <span className="absolute -bottom-1 -right-1 w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-amber-700 text-amber-100 font-black text-[10px] sm:text-xs flex items-center justify-center border-2 border-slate-900 shadow-sm">
                  3
                </span>
              </div>

              <div className="w-full space-y-0.5">
                <span className="text-[11px] sm:text-xs font-bold text-white truncate block">
                  {top3.name.split(' ')[0]}
                </span>
                {top3.username && (
                  <span className="text-[9px] sm:text-[10px] font-semibold text-amber-400 truncate block">
                    {top3.username}
                  </span>
                )}
                <span className={`text-[8px] sm:text-[9px] font-bold px-1 sm:px-1.5 py-0.2 rounded-full border ${getTierColor(top3.membershipTier)}`}>
                  {getTierLabel(top3.membershipTier)}
                </span>
                <div className="pt-0.5 sm:pt-1">
                  <span className="text-[11px] sm:text-sm font-black text-amber-300 block">
                    {activeTab === 'streak' ? `${top3.checkinStreak || 0}d` : `${(activeTab === 'lifetime' ? top3.lifetimeCoins : top3.coins).toLocaleString()} C`}
                  </span>
                  <span className="text-[8px] sm:text-[9px] font-bold text-slate-400 block">+1,000 Prize</span>
                </div>
              </div>

              <div className="w-full mt-1.5 sm:mt-2 py-0.5 sm:py-1 bg-amber-950/80 border border-amber-800/40 rounded-lg text-[9px] sm:text-[10px] font-black text-amber-300">
                🥉 3rd Place
              </div>
            </div>
          )}

        </div>
      </div>

      {/* CURRENT USER STANDING NOTIFICATION */}
      {currentUser && (
        <div className="p-2.5 sm:p-3.5 rounded-xl sm:rounded-2xl bg-gradient-to-r from-emerald-950/50 via-slate-900 to-slate-950 border border-emerald-500/40 shadow-md flex items-center justify-between gap-2.5 sm:gap-3 relative z-10 text-xs">
          <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center font-black text-[11px] sm:text-xs shrink-0">
              #{currentUserRank || '-'}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="font-bold text-white truncate text-[11px] sm:text-xs">Your Standing</span>
                <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 text-[9px] sm:text-[10px] font-bold">
                  Rank #{currentUserRank}
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-300 truncate">
                {nextUserAhead ? (
                  <span>
                    Only <strong className="text-amber-300">{Math.max(0, (activeTab === 'streak' ? (nextUserAhead.checkinStreak - currentUser.checkinStreak) : (nextUserAhead.coins - currentUser.coins)))} {activeTab === 'streak' ? 'days' : 'coins'}</strong> to surpass #{currentUserRank! - 1} {nextUserAhead.name.split(' ')[0]}!
                  </span>
                ) : (
                  <span>🏆 Outstanding! You are leading the global leaderboard!</span>
                )}
              </p>
            </div>
          </div>

          {onOpenTasks && (
            <button
              type="button"
              onClick={onOpenTasks}
              className="min-h-[40px] py-1.5 px-2.5 sm:px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] sm:text-[11px] shrink-0 transition-colors flex items-center justify-center gap-1 cursor-pointer shadow-xs active:scale-95"
            >
              <span>Climb</span>
              <ArrowUpRight className="w-3 h-3" />
            </button>
          )}
        </div>
      )}

      {/* RANKS 4 AND BEYOND LIST */}
      <div className="space-y-1.5 relative z-10">
        <div className="flex items-center justify-between text-[10px] sm:text-[11px] text-slate-400 font-semibold px-2">
          <span>Rank & Participant</span>
          <span>{activeTab === 'streak' ? 'Streak Days' : 'Balance'}</span>
        </div>

        <div className="space-y-1 sm:space-y-1.5">
          {restUsers.map((user, idx) => {
            const rank = idx + 4;
            const isMe = currentUser?.id === user.id;

            return (
              <div
                key={user.id}
                className={`p-2 sm:p-3 rounded-xl sm:rounded-2xl border transition-all flex items-center justify-between gap-2 sm:gap-3 ${
                  isMe
                    ? 'bg-emerald-500/15 border-emerald-500/50 shadow-sm'
                    : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-800/40'
                }`}
              >
                {/* Left: Rank, Avatar, Name & Tier */}
                <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
                  <span className={`w-5 sm:w-6 text-center text-[11px] sm:text-xs font-black ${
                    isMe ? 'text-emerald-400 font-extrabold' : 'text-slate-400'
                  }`}>
                    #{rank}
                  </span>

                  <img
                    src={user.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=80'}
                    alt={user.name}
                    className="w-7 h-7 sm:w-8 sm:h-8 rounded-full object-cover border border-slate-700 shrink-0"
                  />

                  <div className="min-w-0">
                    <div className="flex items-center gap-1 sm:gap-1.5 flex-wrap">
                      <span className={`text-[11px] sm:text-xs font-bold truncate ${isMe ? 'text-emerald-300' : 'text-slate-200'}`}>
                        {user.name}
                      </span>
                      {user.username && (
                        <span className="text-[9px] sm:text-[10px] font-semibold text-amber-400 truncate">
                          {user.username}
                        </span>
                      )}
                      {isMe && (
                        <span className="px-1.5 py-0.2 rounded-full text-[8px] sm:text-[9px] font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          You
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1 sm:gap-1.5 text-[9px] sm:text-[10px]">
                      <span className={`px-1 sm:px-1.5 py-0.2 rounded-full border ${getTierColor(user.membershipTier)}`}>
                        {getTierLabel(user.membershipTier)}
                      </span>
                      <span className="text-amber-400 font-semibold flex items-center gap-0.5">
                        <Flame className="w-2.5 h-2.5 fill-current" />
                        <span>{user.checkinStreak || 0}d</span>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right: Balance / Score */}
                <div className="text-right shrink-0">
                  <span className="text-[11px] sm:text-xs font-black text-amber-300 flex items-center justify-end gap-1">
                    {activeTab === 'streak' ? (
                      <>
                        <Flame className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-orange-400 fill-current" />
                        <span>{user.checkinStreak || 0}d</span>
                      </>
                    ) : (
                      <>
                        <Coins className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-amber-400" />
                        <span>{(activeTab === 'lifetime' ? user.lifetimeCoins : user.coins).toLocaleString()}</span>
                      </>
                    )}
                  </span>
                  <span className="text-[9px] sm:text-[10px] text-slate-400 block">
                    {rank <= 10 ? '+500 Prize' : 'Rank Points'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* View All / Collapse toggle */}
        {leaderboardUsers.length > 7 && (
          <button
            type="button"
            onClick={() => setShowAllRanks(!showAllRanks)}
            className="w-full min-h-[44px] py-2 sm:py-2.5 rounded-xl bg-slate-800/60 hover:bg-slate-800 text-slate-300 font-bold text-[11px] sm:text-xs transition-colors cursor-pointer border border-slate-800 text-center flex items-center justify-center"
          >
            {showAllRanks ? 'Show Less' : `View Full Leaderboard (${leaderboardUsers.length} Competitors)`}
          </button>
        )}
      </div>

      {/* Rules Modal */}
      {isRulesModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative space-y-4">
            <button
              onClick={() => setIsRulesModalOpen(false)}
              className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40">
                <Trophy className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-black text-white">Championship Season Rules</h3>
                <p className="text-xs text-slate-400">Fair play and weekly distribution</p>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
                <h4 className="font-black text-amber-300 text-xs flex items-center gap-1.5">
                  <Crown className="w-3.5 h-3.5 fill-current" />
                  <span>Prize Distribution</span>
                </h4>
                <ul className="space-y-1 text-slate-400 text-[11px]">
                  <li>🥇 <strong>1st Place</strong>: +2,500 Coins</li>
                  <li>🥈 <strong>2nd Place</strong>: +1,500 Coins</li>
                  <li>🥉 <strong>3rd Place</strong>: +1,000 Coins</li>
                  <li>🎖️ <strong>Top 4 - 10</strong>: +500 Coins each</li>
                </ul>
              </div>

              <div className="space-y-2 text-[11px] text-slate-400">
                <p>• <strong>Reset Cycle</strong>: The leaderboard cycle resets every Sunday at 11:59 PM UTC.</p>
                <p>• <strong>Instant Crediting</strong>: Winners receive bonus coins directly in their Task Earn Pro wallet.</p>
                <p>• <strong>Fair Play</strong>: All automated or fraudulent activity leads to disqualification.</p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsRulesModalOpen(false)}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-colors cursor-pointer"
            >
              Got It
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
