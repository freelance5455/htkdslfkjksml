import React from 'react';
import { JobPosting } from '../types/job';
import { JobCard } from './JobCard';
import { useTheme } from '../context/ThemeContext';
import { Bookmark, Sparkles, ArrowRight } from 'lucide-react';

interface SavedJobsProps {
  allJobs: JobPosting[];
  savedJobIds: string[];
  onToggleSave: (jobId: string) => void;
  onOpenDetail: (job: JobPosting) => void;
  onReportJob?: (job: JobPosting) => void;
  onExploreMore: () => void;
}

export const SavedJobs: React.FC<SavedJobsProps> = ({
  allJobs,
  savedJobIds,
  onToggleSave,
  onOpenDetail,
  onReportJob,
  onExploreMore
}) => {
  const { theme } = useTheme();
  const isDark = theme === 'dark';
  const savedJobs = allJobs.filter((job) => savedJobIds.includes(job.id));

  return (
    <div
      className={`flex-1 flex flex-col p-3 sm:p-5 space-y-4 transition-colors ${
        isDark ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'
      }`}
    >
      {/* Header */}
      <div
        className={`p-4 rounded-2xl flex items-center justify-between border shadow-sm transition-colors ${
          isDark
            ? 'bg-slate-900 border-slate-800 text-white'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 ${
              isDark
                ? 'bg-amber-500/20 border-amber-500/30 text-amber-400'
                : 'bg-amber-100 border-amber-200 text-amber-600'
            }`}
          >
            <Bookmark className="w-5 h-5 fill-current" />
          </div>
          <div>
            <h1
              className={`text-base font-bold flex items-center gap-2 ${
                isDark ? 'text-white' : 'text-slate-900'
              }`}
            >
              <span>Saved Vacancies</span>
              <span
                className={`px-2 py-0.5 text-[10px] font-bold rounded-full border ${
                  isDark
                    ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
                    : 'bg-indigo-100 text-indigo-700 border-indigo-200'
                }`}
              >
                {savedJobs.length} Bookmarked
              </span>
            </h1>
            <p className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              Synced across your devices with Cloud Firestore & local cache
            </p>
          </div>
        </div>
      </div>

      {/* Jobs listing */}
      <div className="space-y-3">
        {savedJobs.length > 0 ? (
          savedJobs.map((job) => (
            <JobCard
              key={job.id}
              job={job}
              isSaved={true}
              onToggleSave={onToggleSave}
              onOpenDetail={onOpenDetail}
              onReportJob={onReportJob}
            />
          ))
        ) : (
          <div
            className={`rounded-2xl p-8 text-center space-y-3 border transition-colors ${
              isDark
                ? 'bg-slate-900 border-slate-800 text-white'
                : 'bg-white border-slate-200 text-slate-900 shadow-sm'
            }`}
          >
            <Bookmark
              className={`w-10 h-10 mx-auto ${
                isDark ? 'text-slate-600' : 'text-slate-300'
              }`}
            />
            <h3
              className={`text-sm font-bold ${
                isDark ? 'text-white' : 'text-slate-900'
              }`}
            >
              No Saved Jobs Yet
            </h3>
            <p
              className={`text-xs max-w-sm mx-auto ${
                isDark ? 'text-slate-400' : 'text-slate-500'
              }`}
            >
              Tap the bookmark icon on any Government or Private job vacancy to save it for quick reference and tracking.
            </p>
            <button
              onClick={onExploreMore}
              className="mt-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl inline-flex items-center gap-1.5 shadow-sm transition-all"
            >
              <span>Explore All Jobs</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
