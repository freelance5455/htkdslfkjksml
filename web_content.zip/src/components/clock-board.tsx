import { BRASILIA, clockParts, localTimeZone, sentenceCase, type ClockParts } from "@/lib/time";

type Props = {
  now: Date | null;
};

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-paper px-3 py-3">
      <p className="text-xs font-medium tracking-wide text-muted uppercase">{label}</p>
      <p className="mt-1 font-display text-2xl leading-none text-ink capitalize tabular-nums">{value}</p>
    </div>
  );
}

export function ClockBoard({ now }: Props) {
  const zone = BRASILIA;
  const parts: ClockParts | null = now ? clockParts(now, zone) : null;
  const here = localTimeZone();
  const local = now && here !== zone ? clockParts(now, here) : null;

  return (
    <section className="rounded-card border border-line bg-card p-5 shadow-card sm:p-7 lg:col-span-3">
      <div className="flex items-baseline justify-between gap-3">
        <p className="text-sm font-medium text-muted">Horário de Brasília</p>
        <p className="text-sm text-muted tabular-nums">{parts ? `${parts.second}s` : "—"}</p>
      </div>

      <p
        className="mt-3 flex items-start font-display text-7xl leading-none text-ink tabular-nums sm:text-8xl"
        aria-live="off"
      >
        {parts ? (
          <>
            <span>{parts.hour}</span>
            <span className="px-1 text-clay" aria-hidden="true">
              :
            </span>
            <span>{parts.minute}</span>
          </>
        ) : (
          <span className="text-paper-deep">00:00</span>
        )}
      </p>
      <p className="sr-only">
        {parts
          ? `${parts.hour} horas e ${parts.minute} minutos, ${parts.weekday}, ${parts.day} de ${parts.month} de ${parts.year}`
          : "Carregando horário"}
      </p>

      <p className="mt-4 font-display text-2xl text-ink sm:text-3xl">
        {parts ? sentenceCase(parts.weekday) : "—"}
      </p>
      <p className="text-muted">
        {parts ? `${parts.day} de ${parts.month}` : "Sincronizando o relógio"}
      </p>

      <div className="mt-6 grid grid-cols-2 gap-2 sm:grid-cols-4">
        <Stat label="Data" value={parts ? `${parts.day} ${parts.monthShort}` : "—"} />
        <Stat label="Minutos" value={parts ? parts.minute : "—"} />
        <Stat label="Ano" value={parts ? parts.year : "—"} />
        <Stat label="Segundos" value={parts ? parts.second : "—"} />
      </div>

      {local ? (
        <p className="mt-4 text-sm text-muted">
          No seu fuso, agora são{" "}
          <span className="font-medium text-ink tabular-nums">
            {local.hour}:{local.minute}
          </span>
          .
        </p>
      ) : null}
    </section>
  );
}
