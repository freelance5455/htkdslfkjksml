import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Activity,
  Layers,
  ChevronDown,
  X,
  Maximize2,
  Minimize2,
  Clock,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  ArrowUp,
  ArrowDown,
  MinusCircle,
  Shield,
  RefreshCw,
  Info,
  Radio,
  Volume2,
} from 'lucide-react';
import { soundManager } from '../utils/soundEffects';
import { voiceNarrator } from '../utils/voiceNarrator';

interface CandleData {
  time: number;
  timeFormatted: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

interface SupportResistanceLevel {
  label: string;
  price: number;
  type: 'RESISTANCE' | 'PIVOT' | 'SUPPORT';
  strength: number;
}

interface ScanAnalysis {
  decision: 'UP' | 'DOWN' | 'PASS';
  reasons: string[];
  trend: string;
  confidenceScore: number;
  disclaimer: string;
}

interface ScanResponse {
  success: boolean;
  pair: string;
  marketType: 'REAL' | 'OTC';
  dataSource: string;
  dataSourceLimitation: string;
  livePrice: number;
  timestamp: number;
  timeframe: string;
  candleStartTime: string;
  nextCandleStartTime: string;
  nextCandleEndTime: string;
  candles: CandleData[];
  supportResistance: SupportResistanceLevel[];
  analysis: ScanAnalysis;
  error?: string;
}

interface QuotexFloatingScannerProps {
  isOpen: boolean;
  onClose: () => void;
  defaultPair?: string;
  onSelectSignal?: (signalData: any) => void;
}

const SUPPORTED_PAIRS = [
  { symbol: 'EUR/USD', name: 'Euro / US Dollar', type: 'REAL', decimals: 5 },
  { symbol: 'GBP/USD', name: 'British Pound / US Dollar', type: 'REAL', decimals: 5 },
  { symbol: 'USD/JPY', name: 'US Dollar / Japanese Yen', type: 'REAL', decimals: 3 },
  { symbol: 'AUD/USD', name: 'Australian Dollar / US Dollar', type: 'REAL', decimals: 5 },
  { symbol: 'EUR/USD OTC', name: 'EUR/USD (Quotex OTC)', type: 'OTC', decimals: 5 },
  { symbol: 'GBP/USD OTC', name: 'GBP/USD (Quotex OTC)', type: 'OTC', decimals: 5 },
  { symbol: 'USD/JPY OTC', name: 'USD/JPY (Quotex OTC)', type: 'OTC', decimals: 3 },
  { symbol: 'USD/INR OTC', name: 'USD/INR (Quotex OTC)', type: 'OTC', decimals: 3 },
  { symbol: 'BTC/USD OTC', name: 'Bitcoin (Quotex OTC)', type: 'OTC', decimals: 1 },
];

export const QuotexFloatingScanner: React.FC<QuotexFloatingScannerProps> = ({
  isOpen,
  onClose,
  defaultPair = 'EUR/USD',
  onSelectSignal,
}) => {
  const [selectedPair, setSelectedPair] = useState<string>(defaultPair);
  const [marketCategory, setMarketCategory] = useState<'REAL' | 'OTC'>(
    defaultPair.includes('OTC') ? 'OTC' : 'REAL'
  );
  const [isScanning, setIsScanning] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [data, setData] = useState<ScanResponse | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(60);
  const [isPairDropdownOpen, setIsPairDropdownOpen] = useState(false);
  const [showDataSourceInfo, setShowDataSourceInfo] = useState(false);

  // Sync category when pair changes
  useEffect(() => {
    setMarketCategory(selectedPair.includes('OTC') ? 'OTC' : 'REAL');
  }, [selectedPair]);

  // Live seconds countdown to next candle open
  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const secLeft = 60 - now.getSeconds();
      setSecondsRemaining(secLeft);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Execute Market Scan
  const executeScan = async () => {
    if (isScanning) return;
    setIsScanning(true);
    setErrorMsg(null);
    soundManager.playPip();

    try {
      const response = await fetch('/api/market-scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pair: selectedPair,
          marketType: marketCategory,
          timeframe: '1 Minute',
        }),
      });

      if (!response.ok) {
        throw new Error('MARKET DATA UNAVAILABLE');
      }

      const result: ScanResponse = await response.json();
      if (!result.success || !result.candles || result.candles.length === 0) {
        throw new Error(result.error || 'MARKET DATA UNAVAILABLE');
      }

      // Allow minimum 1.2s smooth scanning animation loop
      await new Promise((resolve) => setTimeout(resolve, 1200));

      setData(result);
      soundManager.playSignalAlert();
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'MARKET DATA UNAVAILABLE');
      soundManager.playNotification();
    } finally {
      setIsScanning(false);
    }
  };

  // Perform initial scan upon opening
  useEffect(() => {
    if (isOpen && !data && !isScanning) {
      executeScan();
    }
  }, [isOpen, selectedPair]);

  // Chart Coordinates Calculation
  const candles = data?.candles || [];
  const sRLevels = data?.supportResistance || [];
  const decimals = selectedPair.includes('JPY') ? 3 : selectedPair.includes('BTC') ? 1 : 5;

  const { minPrice, maxPrice, priceRange } = useMemo(() => {
    if (candles.length === 0) {
      return { minPrice: 1.0, maxPrice: 1.01, priceRange: 0.01 };
    }
    let min = Infinity;
    let max = -Infinity;
    candles.forEach((c) => {
      if (c.low < min) min = c.low;
      if (c.high > max) max = c.high;
    });
    sRLevels.forEach((lvl) => {
      if (lvl.price < min) min = lvl.price;
      if (lvl.price > max) max = lvl.price;
    });
    const padding = (max - min) * 0.12 || 0.0005;
    return {
      minPrice: min - padding,
      maxPrice: max + padding,
      priceRange: max - min + padding * 2 || 0.001,
    };
  }, [candles, sRLevels]);

  const chartWidth = 560;
  const chartHeight = 220;
  const candleWidth = 10;
  const candleSpacing = candles.length > 0 ? chartWidth / candles.length : 20;

  const getY = (price: number) => {
    return chartHeight - ((price - minPrice) / priceRange) * (chartHeight - 30) - 15;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md transition-all">
      {/* Floating Panel Container with Dark Navy Theme */}
      <div
        className={`w-full max-w-2xl bg-[#070e22] border-2 border-[#00ff88]/40 rounded-2xl shadow-[0_0_50px_rgba(0,255,136,0.25)] flex flex-col overflow-hidden transition-all duration-200 ${
          isMinimized ? 'h-auto max-h-[140px]' : 'max-h-[95vh]'
        }`}
      >
        {/* TOP BAR: Dark Navy with Neon Accents */}
        <div className="bg-[#0b142c] border-b border-[#00ff88]/30 px-3 py-2.5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-[#00ff88] animate-pulse shadow-[0_0_8px_#00ff88]" />
            <span className="font-mono font-black text-sm text-[#00ff88] tracking-wider uppercase flex items-center gap-1.5">
              <span>QUOTEX MARKET SCANNER</span>
            </span>

            {/* Market Type Badge */}
            <span
              className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold border ${
                marketCategory === 'REAL'
                  ? 'bg-blue-950/80 text-blue-400 border-blue-500/50'
                  : 'bg-emerald-950/80 text-[#00ff88] border-[#00ff88]/50'
              }`}
            >
              {marketCategory === 'REAL' ? 'REAL FOREX MARKET' : 'QUOTEX OTC BROKER'}
            </span>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => setShowDataSourceInfo(!showDataSourceInfo)}
              className="p-1 rounded text-zinc-400 hover:text-[#00ff88] transition-colors"
              title="Data Source & Limitation Disclosures"
            >
              <Info className="w-4 h-4" />
            </button>
            <button
              onClick={() => setIsMinimized(!isMinimized)}
              className="p-1 rounded text-zinc-400 hover:text-white transition-colors"
            >
              {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded text-zinc-400 hover:text-red-400 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Data Source Disclosure Popover */}
        {showDataSourceInfo && (
          <div className="bg-[#050b1a] border-b border-[#00ff88]/30 px-3 py-2 text-[11px] text-zinc-300 font-mono space-y-1">
            <div className="flex items-center gap-1 text-[#00ff88] font-bold">
              <Shield className="w-3.5 h-3.5" />
              <span>MARKET DATA INTEGRITY DISCLOSURE</span>
            </div>
            <div>
              <strong>Active Data Source:</strong> {data?.dataSource || 'Interbank Spot & Broker OTC'}
            </div>
            <div className="text-zinc-400 text-[10px] leading-tight">
              <strong>Limitation:</strong> {data?.dataSourceLimitation || 'Forex interbank spot markets and Quotex OTC feeds operate on distinct algorithms and liquidity sessions.'}
            </div>
          </div>
        )}

        {/* HEADER STATS: Market Name, Live Price, Candle Countdown */}
        <div className="bg-[#081226] border-b border-[#122348] px-3.5 py-2 flex items-center justify-between flex-wrap gap-2">
          {/* Pair Selector Dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsPairDropdownOpen(!isPairDropdownOpen)}
              className="flex items-center gap-1.5 bg-[#0e1a38] hover:bg-[#14244d] border border-[#00ff88]/40 px-2.5 py-1 rounded-lg text-white font-mono font-bold text-xs transition-colors"
            >
              <span>{selectedPair}</span>
              <ChevronDown className="w-3.5 h-3.5 text-[#00ff88]" />
            </button>

            {isPairDropdownOpen && (
              <div className="absolute top-full left-0 mt-1 w-56 bg-[#091329] border border-[#00ff88]/50 rounded-xl shadow-2xl z-30 py-1 font-mono text-xs max-h-60 overflow-y-auto">
                <div className="px-2.5 py-1 text-[10px] text-zinc-400 uppercase font-bold tracking-wider">
                  Real Forex Markets
                </div>
                {SUPPORTED_PAIRS.filter((p) => p.type === 'REAL').map((p) => (
                  <button
                    key={p.symbol}
                    onClick={() => {
                      setSelectedPair(p.symbol);
                      setIsPairDropdownOpen(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 hover:bg-[#11244d] flex items-center justify-between ${
                      selectedPair === p.symbol ? 'text-[#00ff88] font-bold bg-[#0d1d3f]' : 'text-zinc-300'
                    }`}
                  >
                    <span>{p.symbol}</span>
                    <span className="text-[10px] text-zinc-500">REAL</span>
                  </button>
                ))}
                <div className="px-2.5 py-1 text-[10px] text-zinc-400 uppercase font-bold tracking-wider mt-1 border-t border-[#14244d]">
                  Quotex OTC Markets
                </div>
                {SUPPORTED_PAIRS.filter((p) => p.type === 'OTC').map((p) => (
                  <button
                    key={p.symbol}
                    onClick={() => {
                      setSelectedPair(p.symbol);
                      setIsPairDropdownOpen(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 hover:bg-[#11244d] flex items-center justify-between ${
                      selectedPair === p.symbol ? 'text-[#00ff88] font-bold bg-[#0d1d3f]' : 'text-zinc-300'
                    }`}
                  >
                    <span>{p.symbol}</span>
                    <span className="text-[10px] text-emerald-400">OTC</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Live Price Display */}
          <div className="flex items-center gap-1.5 font-mono">
            <span className="text-[10px] text-zinc-400">PRICE:</span>
            <span className="text-sm font-extrabold text-[#00ff88] tabular-nums tracking-wide shadow-sm">
              {data?.livePrice ? data.livePrice.toFixed(decimals) : '---.-----'}
            </span>
          </div>

          {/* Candle Countdown Timer */}
          <div className="flex items-center gap-1.5 font-mono bg-[#0c1836] border border-[#182b58] px-2 py-0.5 rounded-md text-xs">
            <Clock className="w-3.5 h-3.5 text-amber-400 animate-spin" style={{ animationDuration: '6s' }} />
            <span className="text-[10px] text-zinc-400">CLOSE IN:</span>
            <span className="font-bold text-amber-300 tabular-nums">{secondsRemaining}s</span>
          </div>
        </div>

        {/* MAIN BODY: Candlestick Chart & Large Circular Neon Scan Button */}
        {!isMinimized && (
          <div className="p-3 sm:p-4 flex flex-col gap-3 overflow-y-auto">
            {/* Chart Canvas with Large Circular Scan Button Embedded on the Right */}
            <div className="relative w-full bg-[#050b1a] border border-[#0f224a] rounded-xl overflow-hidden shadow-inner flex flex-col">
              {/* Top Chart Status Bar */}
              <div className="px-2.5 py-1 bg-[#09142e] border-b border-[#0f224a] flex items-center justify-between text-[10px] font-mono text-zinc-400">
                <div className="flex items-center gap-2">
                  <span>TF: 1M CANDLE</span>
                  <span>•</span>
                  <span>S/R MAP: 5 LEVELS</span>
                </div>
                <div className="flex items-center gap-1 text-[#00ff88]">
                  <Activity className="w-3 h-3" />
                  <span>ALGORITHM ACTIVE</span>
                </div>
              </div>

              {/* Chart SVG Viewport */}
              <div className="relative w-full h-[220px] bg-[#050b1a]">
                {/* SVG Definitions for Glowing Neon Filter */}
                <svg
                  viewBox={`0 0 ${chartWidth} ${chartHeight}`}
                  className="w-full h-full select-none"
                  preserveAspectRatio="none"
                >
                  <defs>
                    <filter id="neonGreenGlow" x="-20%" y="-20%" width="140%" height="140%">
                      <feGaussianBlur stdDeviation="3" result="blur" />
                      <feMerge>
                        <feMergeNode in="blur" />
                        <feMergeNode in="blur" />
                        <feMergeNode in="SourceGraphic" />
                      </feMerge>
                    </filter>
                    <linearGradient id="scanBeam" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#00ff88" stopOpacity="0" />
                      <stop offset="70%" stopColor="#00ff88" stopOpacity="0.25" />
                      <stop offset="100%" stopColor="#00ff88" stopOpacity="0.6" />
                    </linearGradient>
                  </defs>

                  {/* Dark Navy Grid Lines */}
                  {[0.2, 0.4, 0.6, 0.8].map((pct, idx) => (
                    <line
                      key={`grid-${idx}`}
                      x1="0"
                      y1={chartHeight * pct}
                      x2={chartWidth}
                      y2={chartHeight * pct}
                      stroke="#0f224a"
                      strokeWidth="0.8"
                      strokeDasharray="4 4"
                    />
                  ))}

                  {/* GLOWING NEON-GREEN HORIZONTAL SUPPORT & RESISTANCE LINES */}
                  {sRLevels.map((lvl, idx) => {
                    const y = getY(lvl.price);
                    const isPivot = lvl.type === 'PIVOT';
                    return (
                      <g key={`sr-${idx}`}>
                        {/* Outer Glow Line */}
                        <line
                          x1="0"
                          y1={y}
                          x2={chartWidth}
                          y2={y}
                          stroke="#00ff88"
                          strokeWidth={isPivot ? '1.2' : '2'}
                          strokeDasharray={isPivot ? '4 3' : 'none'}
                          filter="url(#neonGreenGlow)"
                          opacity="0.9"
                        />
                        {/* Bright Core Line */}
                        <line
                          x1="0"
                          y1={y}
                          x2={chartWidth}
                          y2={y}
                          stroke="#ffffff"
                          strokeWidth="0.8"
                          opacity="0.7"
                        />
                        {/* S/R Label badge */}
                        <rect
                          x="6"
                          y={y - 8}
                          width="80"
                          height="14"
                          fill="#050b1a"
                          stroke="#00ff88"
                          strokeWidth="1"
                          rx="3"
                          opacity="0.85"
                        />
                        <text
                          x="10"
                          y={y + 2.5}
                          fill="#00ff88"
                          fontSize="8.5"
                          fontFamily="monospace"
                          fontWeight="bold"
                        >
                          {lvl.label}: {lvl.price.toFixed(decimals)}
                        </text>
                      </g>
                    );
                  })}

                  {/* REALISTIC CANDLESTICKS (Green & Red) */}
                  {candles.map((c, idx) => {
                    const x = idx * candleSpacing + candleSpacing / 2;
                    const openY = getY(c.open);
                    const closeY = getY(c.close);
                    const highY = getY(c.high);
                    const lowY = getY(c.low);
                    const isGreen = c.close >= c.open;
                    const color = isGreen ? '#00e676' : '#ff3366';
                    const candleTop = Math.min(openY, closeY);
                    const candleHeight = Math.max(Math.abs(closeY - openY), 2);

                    return (
                      <g key={c.time}>
                        {/* Candle Wick */}
                        <line
                          x1={x}
                          y1={highY}
                          x2={x}
                          y2={lowY}
                          stroke={color}
                          strokeWidth="1.2"
                          opacity="0.9"
                        />
                        {/* Candle Body */}
                        <rect
                          x={x - candleWidth / 2}
                          y={candleTop}
                          width={candleWidth}
                          height={candleHeight}
                          fill={color}
                          rx="1.5"
                        />
                      </g>
                    );
                  })}

                  {/* Scanning Laser Beam overlay during active scan */}
                  {isScanning && (
                    <rect
                      x="0"
                      y="0"
                      width={chartWidth}
                      height={chartHeight}
                      fill="url(#scanBeam)"
                      className="animate-pulse"
                      opacity="0.5"
                    />
                  )}
                </svg>

                {/* LARGE CIRCULAR NEON-GREEN SCAN BUTTON ON THE RIGHT SIDE */}
                <div className="absolute right-3 top-1/2 -translate-y-1/2 flex flex-col items-center gap-1.5 z-20">
                  <button
                    onClick={executeScan}
                    disabled={isScanning}
                    className={`group relative w-20 h-20 sm:w-24 sm:h-24 rounded-full flex flex-col items-center justify-center transition-all transform active:scale-95 cursor-pointer ${
                      isScanning
                        ? 'cursor-wait shadow-[0_0_35px_#00ff88]'
                        : 'hover:scale-105 shadow-[0_0_25px_rgba(0,255,136,0.6)]'
                    }`}
                  >
                    {/* Concentric Glowing Outer Ring */}
                    <div
                      className={`absolute inset-0 rounded-full border-2 border-[#00ff88] ${
                        isScanning ? 'animate-ping opacity-60' : 'opacity-80 group-hover:opacity-100'
                      }`}
                    />

                    {/* Rotating Scanner Radar Ring */}
                    <div
                      className={`absolute -inset-1.5 rounded-full border-2 border-dashed border-[#00ff88] ${
                        isScanning ? 'animate-spin' : 'opacity-50'
                      }`}
                      style={{ animationDuration: '2.5s' }}
                    />

                    {/* Inner Glowing Core Button */}
                    <div className="w-full h-full rounded-full bg-gradient-to-b from-[#00ff88] to-[#00b05b] border-2 border-white flex flex-col items-center justify-center text-slate-950 font-black shadow-inner">
                      {isScanning ? (
                        <>
                          <RefreshCw className="w-6 h-6 animate-spin text-slate-950 mb-0.5" />
                          <span className="text-[10px] font-mono font-black tracking-tight uppercase leading-none">
                            SCANNING
                          </span>
                        </>
                      ) : (
                        <>
                          <Radio className="w-6 h-6 text-slate-950 animate-pulse mb-0.5" />
                          <span className="text-xs sm:text-sm font-mono font-black tracking-wider uppercase leading-none">
                            SCAN
                          </span>
                        </>
                      )}
                    </div>
                  </button>

                  {/* Text: WILL SCAN THE MARKET */}
                  <div className="text-center">
                    <span className="text-[9px] sm:text-[10px] font-mono font-black text-[#00ff88] tracking-widest uppercase drop-shadow-[0_0_6px_#00ff88]">
                      WILL SCAN THE MARKET
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* ERROR NOTIFICATION: MARKET DATA UNAVAILABLE */}
            {errorMsg && (
              <div className="w-full bg-red-950/80 border border-red-500 rounded-xl p-3 flex items-center gap-2.5 text-red-200 font-mono text-xs shadow-lg">
                <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 animate-bounce" />
                <div>
                  <div className="font-bold text-red-300">MARKET DATA UNAVAILABLE</div>
                  <div className="text-[11px] text-red-200/80 leading-tight">
                    Could not connect to technical market feed. Fabricated data is disabled by strict integrity protocol.
                  </div>
                </div>
              </div>
            )}

            {/* SCAN RESULTS PANEL: UP, DOWN, or PASS with analytical reasons */}
            {data && data.analysis && !errorMsg && (
              <div className="bg-[#09142e] border border-[#00ff88]/40 rounded-xl p-3 shadow-md space-y-2.5">
                {/* Result Title & Decision Badge */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-mono font-bold text-zinc-400 uppercase">
                      SCAN RESULT:
                    </span>
                    <span
                      className={`text-sm font-mono font-black px-3 py-0.5 rounded-lg flex items-center gap-1.5 shadow-md ${
                        data.analysis.decision === 'UP'
                          ? 'bg-emerald-950 text-[#00ff88] border border-[#00ff88]'
                          : data.analysis.decision === 'DOWN'
                          ? 'bg-red-950 text-red-400 border border-red-500'
                          : 'bg-zinc-900 text-amber-300 border border-amber-500'
                      }`}
                    >
                      {data.analysis.decision === 'UP' && <ArrowUp className="w-4 h-4 stroke-[3]" />}
                      {data.analysis.decision === 'DOWN' && <ArrowDown className="w-4 h-4 stroke-[3]" />}
                      {data.analysis.decision === 'PASS' && <MinusCircle className="w-4 h-4 stroke-[3]" />}
                      <span>{data.analysis.decision === 'PASS' ? 'PASS (NO SETUP)' : data.analysis.decision}</span>
                    </span>

                    {/* Voice Spoken Verdict Button */}
                    <button
                      onClick={() => {
                        soundManager.playPip();
                        voiceNarrator.speak(
                          `Market scanner verdict for ${data.pair}. Decision is ${data.analysis.decision}. ${data.analysis.reasons[0] || ''}. Next candle opens at ${data.nextCandleStartTime}.`,
                          true
                        );
                      }}
                      className="px-2 py-0.5 rounded-lg bg-[#0d1e3d] hover:bg-[#142d5c] border border-[#00ff88]/50 text-[#00ff88] text-[10px] font-mono font-bold flex items-center gap-1 cursor-pointer transition-colors shadow-sm"
                      title="Listen to what the market scanner is saying"
                    >
                      <Volume2 className="w-3 h-3 text-[#00ff88] animate-pulse" />
                      <span>SPEAK</span>
                    </button>
                  </div>

                  {/* Confidence / Quality Indicator */}
                  <div className="text-right font-mono text-xs">
                    <span className="text-zinc-400 text-[10px]">CONFLUENCE: </span>
                    <span className="font-bold text-[#00ff88]">{data.analysis.confidenceScore}%</span>
                  </div>
                </div>

                {/* Analytical Reasons Breakdown */}
                <div className="bg-[#050b1a] border border-[#142650] rounded-lg p-2.5 space-y-1.5 text-xs font-mono">
                  <div className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">
                    TECHNICAL CONFLUENCE REASONS:
                  </div>
                  {data.analysis.reasons.map((reason, idx) => (
                    <div key={idx} className="flex items-start gap-1.5 text-zinc-200 text-[11px]">
                      <span className="text-[#00ff88] font-bold">›</span>
                      <span>{reason}</span>
                    </div>
                  ))}
                </div>

                {/* Timeframe & Candle Execution Schedule */}
                <div className="grid grid-cols-2 gap-2 text-center font-mono text-[11px] bg-[#070e24] p-2 rounded-lg border border-[#142650]">
                  <div>
                    <span className="text-[9px] text-zinc-400 block uppercase">CURRENT CANDLE</span>
                    <strong className="text-zinc-200">{data.candleStartTime}</strong>
                  </div>
                  <div>
                    <span className="text-[9px] text-[#00ff88] block uppercase">NEXT CANDLE OPEN</span>
                    <strong className="text-[#00ff88]">{data.nextCandleStartTime}</strong>
                  </div>
                </div>

                {/* Refresh Option for Next Signal */}
                <button
                  onClick={executeScan}
                  disabled={isScanning}
                  className="w-full py-2.5 px-3 bg-[#0a1c3d] hover:bg-[#112d60] border-2 border-[#00ff88]/60 hover:border-[#00ff88] text-[#00ff88] rounded-xl text-xs font-mono font-black tracking-wider transition-all flex items-center justify-center gap-2 shadow-[0_0_16px_rgba(0,255,136,0.3)] active:scale-95 cursor-pointer"
                >
                  <RefreshCw className={`w-4 h-4 ${isScanning ? 'animate-spin' : ''}`} />
                  <span>🔄 REFRESH FOR NEXT SIGNAL</span>
                </button>

                {/* Compliance Disclaimer */}
                <div className="text-[9.5px] font-mono text-zinc-500 leading-tight text-center">
                  ⚠️ {data.analysis.disclaimer}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
