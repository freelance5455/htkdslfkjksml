import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  ArrowLeft,
  Camera,
  Search,
  ArrowUpDown,
  Upload,
  Calendar,
  X,
  FileImage,
  Download,
} from 'lucide-react';
import { Carpeta, Foto } from '../types';
import {
  obtenerCarpeta,
  listarFotos,
  guardarFoto,
  formatearFecha,
  exportarCarpetaIndividualZip,
} from '../db/storage';

interface CarpetaViewProps {
  carpetaId: string;
  onVolver: () => void;
  onAbrirCamara: () => void;
  onVerFoto: (fotoId: string) => void;
}

export const CarpetaView: React.FC<CarpetaViewProps> = ({
  carpetaId,
  onVolver,
  onAbrirCamara,
  onVerFoto,
}) => {
  const [carpeta, setCarpeta] = useState<Carpeta | null>(null);
  const [fotos, setFotos] = useState<Foto[]>([]);
  const [cargando, setCargando] = useState(true);

  // Búsqueda y orden
  const [busqueda, setBusqueda] = useState('');
  const [mostrarBuscador, setMostrarBuscador] = useState(false);
  const [antiguasPrimero, setAntiguasPrimero] = useState(false);
  const [mostrarMenuOrden, setMostrarMenuOrden] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const cargarDatos = async () => {
    setCargando(true);
    try {
      const c = await obtenerCarpeta(carpetaId);
      if (c) {
        setCarpeta(c);
        const f = await listarFotos(carpetaId);
        setFotos(f);
      }
    } catch (err) {
      console.error('Error al cargar contenido de carpeta:', err);
    } finally {
      setCargando(false);
    }
  };

  useEffect(() => {
    cargarDatos();
  }, [carpetaId]);

  // Fotos filtradas y ordenadas
  const fotosFiltradas = useMemo(() => {
    let lista = [...fotos];
    if (busqueda.trim()) {
      const q = busqueda.trim().toLowerCase();
      lista = lista.filter(
        (f) =>
          f.nombre.toLowerCase().includes(q) ||
          formatearFecha(f.fecha).toLowerCase().includes(q)
      );
    }
    if (antiguasPrimero) {
      lista.sort((a, b) => a.fecha - b.fecha);
    } else {
      lista.sort((a, b) => b.fecha - a.fecha);
    }
    return lista;
  }, [fotos, busqueda, antiguasPrimero]);

  // Subir fotos directamente desde archivo si lo desea
  const handleArchivoSeleccionado = (e: React.ChangeEvent<HTMLInputElement>) => {
    const archivos = e.target.files;
    if (!archivos || archivos.length === 0) return;

    Array.from(archivos).forEach((archivo) => {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const dataUrl = event.target?.result as string;
        if (dataUrl) {
          // Obtener dimensiones reales
          const img = new Image();
          img.onload = async () => {
            await guardarFoto(carpetaId, {
              nombre: archivo.name,
              dataUrl,
              tamanoBytes: archivo.size,
              ancho: img.width,
              alto: img.height,
            });
            await cargarDatos();
          };
          img.src = dataUrl;
        }
      };
      reader.readAsDataURL(archivo);
    });

    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const [descargandoZip, setDescargandoZip] = useState(false);

  const handleDescargarZip = async () => {
    if (fotos.length === 0) {
      alert('Esta carpeta aún no tiene fotos para exportar.');
      return;
    }
    setDescargandoZip(true);
    try {
      const { blob, nombreArchivo } = await exportarCarpetaIndividualZip(carpetaId);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = nombreArchivo;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Error al exportar carpeta en ZIP:', err);
    } finally {
      setDescargandoZip(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col pb-28 transition-colors">
      {/* TopAppBar Requerimiento 11 */}
      <header className="sticky top-0 z-30 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 shadow-xs">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
          {mostrarBuscador ? (
            <div className="flex-1 flex items-center gap-2">
              <Search size={18} className="text-amber-500 shrink-0" />
              <input
                type="text"
                autoFocus
                value={busqueda}
                onChange={(e) => setBusqueda(e.target.value)}
                placeholder="Buscar fecha ej. 20261103 o nombre…"
                className="w-full bg-transparent text-sm font-medium outline-hidden text-slate-900 dark:text-slate-100 placeholder-slate-400"
              />
              <button
                onClick={() => {
                  setBusqueda('');
                  setMostrarBuscador(false);
                }}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X size={18} />
              </button>
            </div>
          ) : (
            <>
              <div className="flex items-center gap-2 min-w-0">
                <button
                  onClick={onVolver}
                  aria-label="Atrás"
                  className="p-2 -ml-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                >
                  <ArrowLeft size={22} />
                </button>
                <div className="min-w-0">
                  <h1 className="text-base md:text-lg font-bold text-slate-900 dark:text-white truncate">
                    {carpeta?.nombre || 'Cargando…'}
                  </h1>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                    {fotos.length} {fotos.length === 1 ? 'foto registrada' : 'fotos registradas'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <button
                  onClick={() => setMostrarBuscador(true)}
                  aria-label="Buscar foto"
                  className="p-2.5 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                >
                  <Search size={20} />
                </button>

                {/* Menú Ordenar Requerimiento 30 */}
                <div className="relative">
                  <button
                    onClick={() => setMostrarMenuOrden(!mostrarMenuOrden)}
                    aria-label="Ordenar fotos"
                    className="p-2.5 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                  >
                    <ArrowUpDown size={20} />
                  </button>

                  {mostrarMenuOrden && (
                    <div
                      className="absolute right-0 mt-2 w-48 bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 py-1.5 z-40 animate-fadeIn"
                      onClick={() => setMostrarMenuOrden(false)}
                    >
                      <button
                        onClick={() => setAntiguasPrimero(false)}
                        className={`w-full text-left px-4 py-2.5 text-xs font-semibold flex items-center justify-between ${
                          !antiguasPrimero
                            ? 'text-amber-600 dark:text-amber-400 bg-amber-50/60 dark:bg-amber-950/20'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                        }`}
                      >
                        <span>Más recientes</span>
                        {!antiguasPrimero && '✓'}
                      </button>
                      <button
                        onClick={() => setAntiguasPrimero(true)}
                        className={`w-full text-left px-4 py-2.5 text-xs font-semibold flex items-center justify-between ${
                          antiguasPrimero
                            ? 'text-amber-600 dark:text-amber-400 bg-amber-50/60 dark:bg-amber-950/20'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                        }`}
                      >
                        <span>Más antiguas</span>
                        {antiguasPrimero && '✓'}
                      </button>
                    </div>
                  )}
                </div>

                {/* Subir archivo secundario */}
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  ref={fileInputRef}
                  onChange={handleArchivoSeleccionado}
                  className="hidden"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  title="Subir fotos desde el dispositivo"
                  className="p-2.5 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                >
                  <Upload size={20} />
                </button>

                <button
                  onClick={handleDescargarZip}
                  disabled={descargandoZip || fotos.length === 0}
                  title="Descargar fotos de este vehículo en ZIP"
                  aria-label="Descargar carpeta en ZIP"
                  className="p-2.5 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition disabled:opacity-30"
                >
                  <Download size={20} className={descargandoZip ? 'animate-bounce text-amber-500' : 'text-amber-500'} />
                </button>
              </div>
            </>
          )}
        </div>
      </header>

      {/* Contenido / Cuadrícula Requerimiento 11 & 12 */}
      <main className="max-w-4xl mx-auto w-full px-2 sm:px-4 pt-4">
        {cargando ? (
          <div className="py-20 flex flex-col items-center justify-center text-slate-400 space-y-3">
            <div className="w-10 h-10 border-4 border-amber-500 border-t-transparent rounded-full animate-spin" />
            <p className="text-sm font-medium">Cargando fotos del vehículo…</p>
          </div>
        ) : fotos.length === 0 ? (
          /* Estado Vacío Requerimiento 12 */
          <div className="py-16 md:py-24 px-6 text-center max-w-sm mx-auto flex flex-col items-center space-y-5">
            <div className="w-24 h-24 rounded-3xl bg-amber-500/10 dark:bg-amber-500/15 text-amber-500 flex items-center justify-center shadow-inner">
              <Camera size={48} strokeWidth={1.5} />
            </div>

            <div className="space-y-1.5">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Aún no hay fotos</h2>
              <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
                Toca el botón <span className="font-semibold text-amber-600 dark:text-amber-400">📷</span> para tomar
                la primera foto con la cámara del taller.
              </p>
            </div>

            <div className="pt-2 w-full flex flex-col gap-2.5">
              <button
                onClick={onAbrirCamara}
                className="w-full py-3 px-5 rounded-2xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-sm shadow-md shadow-amber-600/25 active:scale-98 transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Camera size={18} />
                Tomar foto ahora
              </button>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full py-2.5 px-4 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-800 transition flex items-center justify-center gap-1.5"
              >
                <Upload size={14} />
                O subir desde archivos
              </button>
            </div>
          </div>
        ) : fotosFiltradas.length === 0 ? (
          <div className="py-16 text-center text-slate-400 space-y-2">
            <p className="text-base font-semibold text-slate-700 dark:text-slate-300">
              No hay fotos que coincidan con "{busqueda}"
            </p>
            <button
              onClick={() => setBusqueda('')}
              className="text-xs text-amber-600 dark:text-amber-400 font-semibold underline"
            >
              Borrar filtro
            </button>
          </div>
        ) : (
          /* Cuadrícula de fotos 3 columnas fija */
          <div className="grid grid-cols-3 sm:grid-cols-3 md:grid-cols-4 gap-1.5 sm:gap-2">
            {fotosFiltradas.map((foto, idx) => (
              <div
                key={foto.id}
                onClick={() => onVerFoto(foto.id)}
                className="group relative aspect-square bg-slate-200 dark:bg-slate-800 rounded-xl overflow-hidden cursor-pointer shadow-xs hover:shadow-md transition active:scale-98 border border-black/5 dark:border-white/5"
              >
                <img
                  src={foto.dataUrl}
                  alt={foto.nombre}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />

                {/* Sombra inferior y etiqueta con fecha */}
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-1.5 flex items-end justify-between opacity-90 group-hover:opacity-100 transition">
                  <span className="text-[10px] sm:text-xs text-white font-mono truncate">
                    {formatearFecha(foto.fecha).split(' ')[1]}
                  </span>
                  <span className="text-[9px] px-1 py-0.5 rounded-sm bg-black/50 text-white/90 font-mono">
                    #{idx + 1}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Botón Flotante de Cámara Requerimiento 13 */}
      <div className="fixed bottom-6 right-6 z-30 flex items-center gap-3">
        <button
          onClick={() => fileInputRef.current?.click()}
          aria-label="Subir foto"
          className="w-12 h-12 rounded-2xl bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 shadow-lg flex items-center justify-center active:scale-95 transition cursor-pointer"
        >
          <Upload size={20} />
        </button>

        <button
          onClick={onAbrirCamara}
          aria-label="Tomar foto con cámara"
          className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white shadow-xl shadow-amber-600/40 flex items-center justify-center active:scale-95 transition cursor-pointer group"
        >
          <Camera size={26} className="group-hover:scale-110 transition-transform" />
        </button>
      </div>
    </div>
  );
};
