import React, { useState, useEffect } from 'react';
import { DeviceSettings } from '../types/jarvis';
import { hardwareBridge } from '../utils/hardwareBridge';
import {
  Flashlight,
  Vibrate,
  Volume2,
  VolumeX,
  Volume1,
  Moon,
  BatteryCharging,
  BatteryMedium,
  Compass,
  Sliders,
  Sun,
  ShieldAlert,
  BellOff,
  Radio,
  Check,
} from 'lucide-react';

interface AndroidQuickSettingsProps {
  settings: DeviceSettings;
  onUpdateSettings: (updates: Partial<DeviceSettings>) => void;
  onVoiceAnnounce: (msg: string) => void;
}

export const AndroidQuickSettings: React.FC<AndroidQuickSettingsProps> = ({
  settings,
  onUpdateSettings,
  onVoiceAnnounce,
}) => {
  const [batteryState, setBatteryState] = useState<{ level: number; charging: boolean } | null>(null);
  const [coords, setCoords] = useState<{ latitude: number; longitude: number } | null>(null);
  const [torchActive, setTorchActive] = useState(settings.flashlight);

  // Load battery telemetry
  useEffect(() => {
    hardwareBridge.getBatteryStatus().then((info) => {
      if (info) setBatteryState(info);
      else setBatteryState({ level: 86, charging: true }); // Realistic Android default
    });
  }, []);

  // Load Geolocation
  useEffect(() => {
    hardwareBridge.getCoordinates().then((loc) => {
      if (loc) setCoords(loc);
      else setCoords({ latitude: 34.0194, longitude: -118.4912 }); // Malibu Point coordinate
    });
  }, []);

  const toggleFlashlight = async () => {
    const next = !torchActive;
    setTorchActive(next);
    onUpdateSettings({ flashlight: next });
    hardwareBridge.vibrate(50);
    const success = await hardwareBridge.setFlashlight(next);
    if (next) {
      hardwareBridge.playJarvisTone('ack');
      onVoiceAnnounce('Flashlight torch activated, Sir.');
    } else {
      hardwareBridge.playJarvisTone('complete');
      onVoiceAnnounce('Flashlight extinguished.');
    }
  };

  const cycleSoundMode = () => {
    let nextMode: 'normal' | 'vibrate' | 'silent' = 'normal';
    if (settings.soundMode === 'normal') nextMode = 'vibrate';
    else if (settings.soundMode === 'vibrate') nextMode = 'silent';
    else nextMode = 'normal';

    onUpdateSettings({ soundMode: nextMode });
    hardwareBridge.vibrate([40, 40]);
    hardwareBridge.playJarvisTone('ack');
    onVoiceAnnounce(`Sound profile switched to ${nextMode}.`);
  };

  const toggleBatterySaver = () => {
    const next = !settings.batterySaver;
    onUpdateSettings({ batterySaver: next });
    hardwareBridge.vibrate(40);
    hardwareBridge.playJarvisTone('ack');
    onVoiceAnnounce(next ? 'Preserving auxiliary power. Battery saver engaged.' : 'Full performance profile restored.');
  };

  const toggleVibration = () => {
    const next = !settings.vibrate;
    onUpdateSettings({ vibrate: next });
    if (next) hardwareBridge.vibrate([50, 40, 80]);
  };

  const toggleDND = () => {
    const next = !settings.dnd;
    onUpdateSettings({ dnd: next });
    hardwareBridge.vibrate(40);
    hardwareBridge.playJarvisTone('ack');
    onVoiceAnnounce(next ? 'Do not disturb enabled. Filtering non-critical notifications.' : 'Do not disturb deactivated.');
  };

  const toggleNightMode = () => {
    const next = !settings.nightMode;
    onUpdateSettings({ nightMode: next });
    hardwareBridge.vibrate(30);
  };

  return (
    <div className="bg-gray-900/90 border border-cyan-500/30 rounded-2xl p-4 sm:p-6 backdrop-blur-md shadow-2xl">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-gray-800 pb-4 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-cyan-950 border border-cyan-500/40 text-cyan-400">
              <Sliders className="w-5 h-5" />
            </span>
            <h2 className="font-orbitron text-lg font-bold tracking-wider text-slate-100 uppercase">
              Android Device Control Deck
            </h2>
          </div>
          <p className="text-xs text-slate-400 font-rajdhani mt-0.5">
            Direct Android hardware toggles, sensor telemetry, and power profile
          </p>
        </div>

        <span className="text-[10px] font-mono-code px-2 py-0.5 rounded border border-emerald-500/30 bg-emerald-950/40 text-emerald-300 uppercase">
          HARDWARE SYNCED
        </span>
      </div>

      {/* Live Android Telemetry Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-4">
        <div className="p-3 rounded-xl bg-gray-950/80 border border-gray-800 flex items-center gap-3">
          <div className="p-2 rounded-lg bg-cyan-950/50 text-cyan-400">
            {batteryState?.charging ? (
              <BatteryCharging className="w-5 h-5 text-emerald-400 animate-pulse" />
            ) : (
              <BatteryMedium className="w-5 h-5 text-cyan-400" />
            )}
          </div>
          <div>
            <span className="text-[10px] font-mono-code text-slate-500 uppercase block">Battery</span>
            <span className="font-mono-code text-sm font-bold text-slate-200">
              {batteryState ? `${batteryState.level}%` : '86%'} {batteryState?.charging && '⚡'}
            </span>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-gray-950/80 border border-gray-800 flex items-center gap-3">
          <div className="p-2 rounded-lg bg-cyan-950/50 text-cyan-400">
            <Compass className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <span className="text-[10px] font-mono-code text-slate-500 uppercase block">GPS Fix</span>
            <span className="font-mono-code text-xs text-slate-300 block truncate">
              {coords ? `${coords.latitude}, ${coords.longitude}` : 'Malibu Sector'}
            </span>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-gray-950/80 border border-gray-800 flex items-center gap-3">
          <div className="p-2 rounded-lg bg-cyan-950/50 text-cyan-400">
            <Radio className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <span className="text-[10px] font-mono-code text-slate-500 uppercase block">Network</span>
            <span className="font-mono-code text-xs text-emerald-400 font-bold block">
              5G ULTRA // STARK-LINK
            </span>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-gray-950/80 border border-gray-800 flex items-center gap-3">
          <div className="p-2 rounded-lg bg-cyan-950/50 text-cyan-400">
            <Sun className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <span className="text-[10px] font-mono-code text-slate-500 uppercase block">Display</span>
            <span className="font-mono-code text-xs text-slate-300 block">
              {settings.brightness}% Brightness
            </span>
          </div>
        </div>
      </div>

      {/* Android Quick Settings Grid (Tiles) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4">
        {/* Flashlight Torch */}
        <button
          onClick={toggleFlashlight}
          className={`p-3.5 rounded-xl border text-left transition-all flex items-center justify-between group ${
            torchActive
              ? 'bg-amber-500/20 border-amber-400 text-amber-300 shadow-lg shadow-amber-500/10'
              : 'bg-gray-950/80 border-gray-800 text-slate-400 hover:border-cyan-500/40'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <Flashlight className={`w-5 h-5 ${torchActive ? 'text-amber-300 animate-pulse' : 'text-slate-400'}`} />
            <div>
              <h4 className="text-xs font-orbitron font-bold uppercase text-slate-200">Flashlight</h4>
              <span className="text-[10px] font-mono-code text-slate-500">
                {torchActive ? 'Illuminating' : 'Off'}
              </span>
            </div>
          </div>
          <span className={`w-2.5 h-2.5 rounded-full ${torchActive ? 'bg-amber-400' : 'bg-gray-700'}`} />
        </button>

        {/* Sound Mode */}
        <button
          onClick={cycleSoundMode}
          className="p-3.5 rounded-xl border bg-gray-950/80 border-gray-800 hover:border-cyan-500/40 text-slate-400 text-left transition-all flex items-center justify-between"
        >
          <div className="flex items-center gap-2.5">
            {settings.soundMode === 'normal' ? (
              <Volume2 className="w-5 h-5 text-cyan-400" />
            ) : settings.soundMode === 'vibrate' ? (
              <Volume1 className="w-5 h-5 text-amber-400" />
            ) : (
              <VolumeX className="w-5 h-5 text-red-400" />
            )}
            <div>
              <h4 className="text-xs font-orbitron font-bold uppercase text-slate-200">Sound Mode</h4>
              <span className="text-[10px] font-mono-code text-cyan-400 uppercase">
                {settings.soundMode}
              </span>
            </div>
          </div>
          <span className="text-[10px] font-mono-code text-slate-600">Cycle</span>
        </button>

        {/* Battery Saver */}
        <button
          onClick={toggleBatterySaver}
          className={`p-3.5 rounded-xl border text-left transition-all flex items-center justify-between ${
            settings.batterySaver
              ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
              : 'bg-gray-950/80 border-gray-800 text-slate-400 hover:border-cyan-500/40'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <BatteryMedium className={`w-5 h-5 ${settings.batterySaver ? 'text-emerald-400' : 'text-slate-400'}`} />
            <div>
              <h4 className="text-xs font-orbitron font-bold uppercase text-slate-200">Power Saver</h4>
              <span className="text-[10px] font-mono-code text-slate-500">
                {settings.batterySaver ? 'Active Protocol' : 'Disabled'}
              </span>
            </div>
          </div>
          <span className={`w-2.5 h-2.5 rounded-full ${settings.batterySaver ? 'bg-emerald-400' : 'bg-gray-700'}`} />
        </button>

        {/* Haptics / Vibration */}
        <button
          onClick={toggleVibration}
          className={`p-3.5 rounded-xl border text-left transition-all flex items-center justify-between ${
            settings.vibrate
              ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
              : 'bg-gray-950/80 border-gray-800 text-slate-400 hover:border-cyan-500/40'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <Vibrate className={`w-5 h-5 ${settings.vibrate ? 'text-cyan-400' : 'text-slate-400'}`} />
            <div>
              <h4 className="text-xs font-orbitron font-bold uppercase text-slate-200">Haptics</h4>
              <span className="text-[10px] font-mono-code text-slate-500">
                {settings.vibrate ? 'Tactile Feedback' : 'Silent'}
              </span>
            </div>
          </div>
          <span className={`w-2.5 h-2.5 rounded-full ${settings.vibrate ? 'bg-cyan-400' : 'bg-gray-700'}`} />
        </button>

        {/* Do Not Disturb */}
        <button
          onClick={toggleDND}
          className={`p-3.5 rounded-xl border text-left transition-all flex items-center justify-between ${
            settings.dnd
              ? 'bg-purple-500/20 border-purple-400 text-purple-300'
              : 'bg-gray-950/80 border-gray-800 text-slate-400 hover:border-cyan-500/40'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <BellOff className={`w-5 h-5 ${settings.dnd ? 'text-purple-400' : 'text-slate-400'}`} />
            <div>
              <h4 className="text-xs font-orbitron font-bold uppercase text-slate-200">DND Mode</h4>
              <span className="text-[10px] font-mono-code text-slate-500">
                {settings.dnd ? 'Alerts Filtered' : 'Accept All'}
              </span>
            </div>
          </div>
          <span className={`w-2.5 h-2.5 rounded-full ${settings.dnd ? 'bg-purple-400' : 'bg-gray-700'}`} />
        </button>

        {/* Night / Dark Mode */}
        <button
          onClick={toggleNightMode}
          className={`p-3.5 rounded-xl border text-left transition-all flex items-center justify-between ${
            settings.nightMode
              ? 'bg-indigo-500/20 border-indigo-400 text-indigo-300'
              : 'bg-gray-950/80 border-gray-800 text-slate-400 hover:border-cyan-500/40'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <Moon className={`w-5 h-5 ${settings.nightMode ? 'text-indigo-400' : 'text-slate-400'}`} />
            <div>
              <h4 className="text-xs font-orbitron font-bold uppercase text-slate-200">Stealth HUD</h4>
              <span className="text-[10px] font-mono-code text-slate-500">
                {settings.nightMode ? 'OLED Black' : 'Stark Cyan'}
              </span>
            </div>
          </div>
          <span className={`w-2.5 h-2.5 rounded-full ${settings.nightMode ? 'bg-indigo-400' : 'bg-gray-700'}`} />
        </button>
      </div>

      {/* Fine-Tuning Sliders */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-3.5 rounded-xl bg-gray-950/60 border border-gray-800">
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-mono-code text-slate-400 flex items-center gap-1.5">
              <Sun className="w-3.5 h-3.5 text-amber-400" />
              Brightness Level
            </span>
            <span className="text-xs font-mono-code text-cyan-300">{settings.brightness}%</span>
          </div>
          <input
            type="range"
            min="10"
            max="100"
            value={settings.brightness}
            onChange={(e) => onUpdateSettings({ brightness: parseInt(e.target.value) })}
            className="w-full h-1.5 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
          />
        </div>

        <div>
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-mono-code text-slate-400 flex items-center gap-1.5">
              <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
              System Audio Volume
            </span>
            <span className="text-xs font-mono-code text-cyan-300">{settings.volume}%</span>
          </div>
          <input
            type="range"
            min="0"
            max="100"
            value={settings.volume}
            onChange={(e) => onUpdateSettings({ volume: parseInt(e.target.value) })}
            className="w-full h-1.5 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
          />
        </div>
      </div>
    </div>
  );
};
