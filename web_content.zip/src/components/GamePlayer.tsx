import { useEffect, useRef } from "react";
import type { GameConfig } from "../lib/models";
import { makeGame } from "../lib/engine";

interface Props {
  config: GameConfig;
  className?: string;
  onThumb?: (dataUrl: string) => void;
}

export default function GamePlayer({ config, className, onThumb }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const thumbRef = useRef(onThumb);
  thumbRef.current = onThumb;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const handle = makeGame(canvas, config);
    let captured = false;
    const t = setTimeout(() => {
      if (!captured && thumbRef.current) {
        try {
          captured = true;
          thumbRef.current(canvas.toDataURL("image/png"));
        } catch {
          /* cross-origin taint — impossible here, but safe */
        }
      }
    }, 900);
    return () => {
      clearTimeout(t);
      handle.destroy();
    };
  }, [config]);

  return (
    <canvas
      ref={canvasRef}
      className={className ?? "block w-full h-auto"}
      style={{ aspectRatio: "3 / 2", touchAction: "none", cursor: "crosshair" }}
      aria-label={`Playable preview of ${config.title}`}
    />
  );
}
