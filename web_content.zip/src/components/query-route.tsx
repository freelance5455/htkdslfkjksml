"use client";

import { useSyncExternalStore, type ReactNode } from "react";
import Link from "next/link";

/**
 * Resolves an `?id=` query parameter for a statically exported page.
 *
 * Pages are pre-rendered at build time with no query string, so reading
 * `location.search` during hydration would disagree with the server markup.
 * `useSyncExternalStore` solves this properly: React uses the server snapshot
 * (`null`) while hydrating and switches to the real value immediately after,
 * so there is never a hydration mismatch.
 */

function subscribe(onChange: () => void) {
  window.addEventListener("popstate", onChange);
  return () => window.removeEventListener("popstate", onChange);
}

function getSnapshot(): string {
  return typeof window === "undefined" ? "" : window.location.search;
}

/** Hydration-safe: matches the prerendered HTML, which has no query string. */
function getServerSnapshot(): string {
  return "";
}

export function useQueryParam(key: string): string | null {
  const search = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
  return new URLSearchParams(search).get(key);
}

export function QueryIdRoute({
  children,
  emptyTitle,
  backHref,
  backLabel,
}: {
  children: (id: string) => ReactNode;
  emptyTitle: string;
  backHref: string;
  backLabel: string;
}) {
  const id = useQueryParam("id");

  if (!id) {
    return (
      <main className="mx-auto max-w-md px-4 py-16 text-center">
        <p className="text-sm font-bold text-slate-300">{emptyTitle}</p>
        <Link href={backHref} className="mt-3 inline-block text-sm text-emerald-400 underline">
          {backLabel}
        </Link>
      </main>
    );
  }

  return <>{children(id)}</>;
}
