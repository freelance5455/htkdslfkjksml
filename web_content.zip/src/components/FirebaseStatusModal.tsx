import React from 'react';
import { ShieldCheck, Database, Key, Sparkles, CheckCircle2, AlertCircle, X, ExternalLink } from 'lucide-react';
import { Language, SystemStatus } from '../types';
import { translations } from '../translations/translations';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  systemStatus: SystemStatus | null;
}

export const FirebaseStatusModal: React.FC<Props> = ({ isOpen, onClose, language, systemStatus }) => {
  if (!isOpen) return null;

  const t = translations[language].firebaseModal;
  const isFbConfigured = systemStatus?.firebase?.configured ?? false;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-emerald-100 overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 to-teal-700 text-white p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-2 mb-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-400 text-emerald-950 uppercase tracking-wide">
              {language === 'am' ? 'የስርዓት አወቃቀር' : 'System Architecture'}
            </span>
          </div>
          <h2 className="text-xl font-bold">{t.title}</h2>
          <p className="text-emerald-100 text-xs mt-1">{t.subtitle}</p>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-slate-700 text-sm">
          {/* Current Working Status */}
          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200">
            <div className="flex items-start space-x-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <h3 className="font-bold text-emerald-900 text-base">{t.statusRunning}</h3>
                <p className="text-emerald-800 text-xs mt-1 leading-relaxed">{t.statusDesc}</p>
              </div>
            </div>
          </div>

          {/* Matrix of capabilities */}
          <div>
            <h4 className="font-semibold text-slate-900 mb-3 text-xs uppercase tracking-wider">
              {t.featureListTitle}
            </h4>
            <div className="space-y-2.5">
              {/* Gemini AI */}
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-slate-800 text-xs">{t.featureGemini}</div>
                    <div className="text-[11px] text-slate-500">
                      {language === 'am' ? 'ሞዴል፦ gemini-3.8-flash (Server Proxy)' : 'Model: gemini-3.8-flash (Server Proxy)'}
                    </div>
                  </div>
                </div>
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                  <CheckCircle2 className="w-3 h-3 mr-1" />
                  {t.featureGeminiStatus}
                </span>
              </div>

              {/* Cloud Firestore */}
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
                    <Database className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-slate-800 text-xs">{t.featureFirestore}</div>
                    <div className="text-[11px] text-slate-500">
                      {isFbConfigured ? 'firebase-applet-config.json connected' : 'Local Storage active (Firestore ready)'}
                    </div>
                  </div>
                </div>
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  isFbConfigured ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                }`}>
                  {isFbConfigured ? (
                    <>
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      {language === 'am' ? 'የተገናኘ' : 'Connected'}
                    </>
                  ) : (
                    <>
                      <AlertCircle className="w-3 h-3 mr-1" />
                      {t.featureFirestoreStatus}
                    </>
                  )}
                </span>
              </div>

              {/* Firebase Auth */}
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
                    <Key className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-slate-800 text-xs">{t.featureAuth}</div>
                    <div className="text-[11px] text-slate-500">
                      {language === 'am' ? 'የጉግል መለያ ማረጋገጫ' : 'Google Authentication Flow'}
                    </div>
                  </div>
                </div>
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-200 text-slate-700">
                  {t.featureAuthStatus}
                </span>
              </div>
            </div>
          </div>

          {/* Blueprint & Security Rules Explanation */}
          <div className="p-4 rounded-2xl bg-teal-50 border border-teal-200 text-xs space-y-2">
            <div className="flex items-center space-x-2 text-teal-900 font-bold">
              <ShieldCheck className="w-4 h-4 text-teal-700" />
              <span>{t.blueprintTitle}</span>
            </div>
            <p className="text-teal-800 leading-relaxed">{t.blueprintDesc}</p>
            <div className="flex flex-wrap gap-2 pt-1 font-mono text-[10px]">
              <span className="px-2 py-0.5 rounded bg-teal-100 text-teal-800">/firebase-blueprint.json</span>
              <span className="px-2 py-0.5 rounded bg-teal-100 text-teal-800">/firestore.rules</span>
              <span className="px-2 py-0.5 rounded bg-teal-100 text-teal-800">server.ts (/api/gemini/*)</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm transition-colors shadow-sm"
          >
            {t.closeBtn}
          </button>
        </div>
      </div>
    </div>
  );
};
