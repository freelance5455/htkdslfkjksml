import React, { useState } from 'react';
import { 
  ThumbsUp, 
  MessageCircle, 
  Share2, 
  MoreHorizontal, 
  Bookmark, 
  Trash2, 
  Flag, 
  Link, 
  Volume2, 
  VolumeX, 
  Play, 
  Pause,
  Send,
  ShieldCheck,
  Check
} from 'lucide-react';
import { Post, ReactionType } from '../types';
import { useAuth } from '../context/AuthContext';
import { useSocial } from '../context/SocialContext';
import { SafeVideo } from './SafeVideo';

interface PostCardProps {
  post: Post;
  onOpenProfile?: (userId: string) => void;
}

const REACTIONS: { type: ReactionType; label: string; emoji: string; color: string }[] = [
  { type: 'like', label: 'Like', emoji: '👍', color: 'text-blue-600' },
  { type: 'love', label: 'Love', emoji: '❤️', color: 'text-rose-500' },
  { type: 'haha', label: 'Haha', emoji: '😆', color: 'text-amber-500' },
  { type: 'wow', label: 'Wow', emoji: '😮', color: 'text-amber-500' },
  { type: 'sad', label: 'Sad', emoji: '😢', color: 'text-amber-500' },
  { type: 'angry', label: 'Angry', emoji: '😡', color: 'text-red-600' },
];

export const PostCard: React.FC<PostCardProps> = ({ post, onOpenProfile }) => {
  const { user, isAdmin } = useAuth();
  const { 
    reactToPost, 
    deletePost, 
    addComment, 
    getCommentsForPost, 
    toggleSavePost, 
    reportContent 
  } = useSocial();

  const [showReactionsMenu, setShowReactionsMenu] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);

  // Video state
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(true);
  const videoRef = React.useRef<HTMLVideoElement>(null);

  const isAuthor = user?.id === post.authorId;
  const canDelete = isAuthor || isAdmin;

  const currentReaction = post.userReaction 
    ? REACTIONS.find(r => r.type === post.userReaction) 
    : null;

  const comments = getCommentsForPost(post.id);

  const handleVideoClick = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  const toggleSound = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!videoRef.current) return;
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleShare = async () => {
    const postUrl = window.location.origin + '/#post-' + post.id;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `FaceLook - Post by ${post.authorName}`,
          text: post.content.slice(0, 100),
          url: postUrl,
        });
        return;
      } catch {}
    }

    // Fallback: clipboard copy
    navigator.clipboard.writeText(postUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleSendComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    await addComment(post.id, commentText.trim());
    setCommentText('');
  };

  return (
    <article className="bg-white rounded-2xl border border-slate-200/90 shadow-xs mb-3.5 sm:mb-4 overflow-hidden transition-all hover:border-slate-300">
      
      {/* Header */}
      <div className="p-3.5 sm:p-4 flex items-center justify-between">
        <div 
          onClick={() => onOpenProfile && onOpenProfile(post.authorId)}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <img
            src={post.authorPhotoURL}
            alt={post.authorName}
            className="w-10 h-10 rounded-full object-cover ring-1 ring-slate-200 group-hover:ring-[#1877F2] transition-colors"
          />
          <div>
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="font-bold text-sm text-slate-900 group-hover:text-[#1877F2] transition-colors">
                {post.authorName}
              </span>
              {post.authorIsAdmin && (
                <span className="inline-flex items-center gap-0.5 bg-blue-50 text-[#1877F2] text-[10px] font-bold px-1.5 py-0.2 rounded-md">
                  <ShieldCheck className="w-3 h-3" />
                  Admin
                </span>
              )}
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-500">
              <span>@{post.authorUsername}</span>
              <span>•</span>
              <span>{formatTimeAgo(post.createdAt)}</span>
              <span>•</span>
              <span className="text-[10px] uppercase font-semibold text-slate-400">
                {post.privacy}
              </span>
            </div>
          </div>
        </div>

        {/* 3-dots Menu */}
        <div className="relative">
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="w-8 h-8 rounded-full hover:bg-slate-100 flex items-center justify-center text-slate-500 transition-colors cursor-pointer"
          >
            <MoreHorizontal className="w-5 h-5" />
          </button>

          {showMenu && (
            <div 
              className="absolute right-0 mt-1 w-48 bg-white rounded-xl shadow-xl border border-slate-100 py-1.5 z-30 animate-in fade-in zoom-in-95"
              onClick={() => setShowMenu(false)}
            >
              <button
                onClick={() => toggleSavePost(post.id)}
                className="w-full px-3 py-2 text-left text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer font-medium"
              >
                <Bookmark className="w-4 h-4 text-slate-500" />
                <span>{post.isSaved ? 'Unsave post' : 'Save post'}</span>
              </button>

              <button
                onClick={handleShare}
                className="w-full px-3 py-2 text-left text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer font-medium"
              >
                <Link className="w-4 h-4 text-slate-500" />
                <span>{copiedLink ? 'Link copied!' : 'Copy link'}</span>
              </button>

              <button
                onClick={() => reportContent('post', post.id, 'User flagged this content', post.authorName)}
                className="w-full px-3 py-2 text-left text-xs text-amber-700 hover:bg-amber-50 flex items-center gap-2 cursor-pointer font-medium"
              >
                <Flag className="w-4 h-4 text-amber-600" />
                <span>Report post</span>
              </button>

              {canDelete && (
                <>
                  <div className="border-t border-slate-100 my-1"></div>
                  <button
                    onClick={() => deletePost(post.id)}
                    className="w-full px-3 py-2 text-left text-xs text-rose-600 hover:bg-rose-50 flex items-center gap-2 cursor-pointer font-medium"
                  >
                    <Trash2 className="w-4 h-4 text-rose-500" />
                    <span>Delete post</span>
                  </button>
                </>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Content Text */}
      {post.content && (
        <div className="px-3.5 sm:px-4 pb-3 text-slate-800 text-sm sm:text-base leading-relaxed whitespace-pre-line">
          {post.content}
        </div>
      )}

      {/* Media Display */}
      {post.mediaType === 'image' && post.mediaUrl && (
        <div className="bg-slate-950 flex items-center justify-center max-h-[500px] overflow-hidden">
          <img
            src={post.mediaUrl}
            alt="Post media"
            className="w-full h-auto max-h-[500px] object-cover hover:scale-[1.01] transition-transform duration-300"
            loading="lazy"
          />
        </div>
      )}

      {post.mediaType === 'video' && post.mediaUrl && (
        <div 
          onClick={handleVideoClick}
          className="relative bg-black aspect-video max-h-[480px] flex items-center justify-center cursor-pointer group"
        >
          <SafeVideo
            ref={videoRef}
            src={post.mediaUrl}
            className="w-full h-full object-contain"
            autoPlay
            loop
            muted={isMuted}
            playsInline
          />

          {/* Video controls overlay */}
          <div className="absolute inset-0 bg-transparent flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            <div className="w-12 h-12 rounded-full bg-black/60 text-white flex items-center justify-center backdrop-blur-xs">
              {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 translate-x-0.5" />}
            </div>
          </div>

          {/* Mute button */}
          <button
            onClick={toggleSound}
            className="absolute bottom-3 right-3 w-8 h-8 rounded-full bg-black/70 hover:bg-black/90 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>
      )}

      {/* Reaction & Comment Counts Bar */}
      <div className="px-3.5 sm:px-4 py-2 border-b border-slate-100 flex items-center justify-between text-xs text-slate-500">
        <div className="flex items-center gap-1.5">
          <div className="flex -space-x-1">
            <span className="w-4 h-4 rounded-full bg-[#1877F2] text-white flex items-center justify-center text-[10px] ring-1 ring-white">👍</span>
            <span className="w-4 h-4 rounded-full bg-rose-500 text-white flex items-center justify-center text-[10px] ring-1 ring-white">❤️</span>
          </div>
          <span className="font-medium text-slate-600 ml-1">
            {post.likesCount > 0 ? post.likesCount : 'Be first to like'}
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button 
            onClick={() => setShowComments(!showComments)}
            className="hover:underline cursor-pointer"
          >
            {post.commentsCount} {post.commentsCount === 1 ? 'comment' : 'comments'}
          </button>
          <span>{post.sharesCount} shares</span>
        </div>
      </div>

      {/* Interactive Action Bar (Like, Comment, Share) */}
      <div className="relative px-2 py-1 flex items-center justify-between">
        
        {/* Floating Facebook Reaction Bar on Hover / Long press */}
        {showReactionsMenu && (
          <div 
            onMouseEnter={() => setShowReactionsMenu(true)}
            onMouseLeave={() => setShowReactionsMenu(false)}
            className="absolute -top-12 left-2 bg-white rounded-full shadow-2xl border border-slate-200 px-2 py-1.5 flex items-center gap-1.5 z-30 animate-in fade-in zoom-in-95 duration-100"
          >
            {REACTIONS.map((r) => (
              <button
                key={r.type}
                onClick={() => {
                  reactToPost(post.id, r.type);
                  setShowReactionsMenu(false);
                }}
                className="w-8 h-8 rounded-full hover:scale-130 transition-transform flex items-center justify-center text-xl cursor-pointer"
                title={r.label}
              >
                <span>{r.emoji}</span>
              </button>
            ))}
          </div>
        )}

        {/* Like Button */}
        <div 
          className="relative flex-1"
          onMouseEnter={() => setShowReactionsMenu(true)}
          onMouseLeave={() => setShowReactionsMenu(false)}
        >
          <button
            onClick={() => reactToPost(post.id, 'like')}
            className={`w-full py-2 rounded-lg flex items-center justify-center gap-1.5 font-semibold text-xs sm:text-sm hover:bg-slate-50 transition-colors cursor-pointer ${
              currentReaction ? currentReaction.color : 'text-slate-600'
            }`}
          >
            {currentReaction ? (
              <>
                <span className="text-base">{currentReaction.emoji}</span>
                <span>{currentReaction.label}</span>
              </>
            ) : (
              <>
                <ThumbsUp className="w-4 h-4" />
                <span>Like</span>
              </>
            )}
          </button>
        </div>

        {/* Comment Button */}
        <button
          onClick={() => setShowComments(!showComments)}
          className="flex-1 py-2 rounded-lg flex items-center justify-center gap-1.5 font-semibold text-xs sm:text-sm text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer"
        >
          <MessageCircle className="w-4 h-4" />
          <span>Comment</span>
        </button>

        {/* Share Button */}
        <button
          onClick={handleShare}
          className="flex-1 py-2 rounded-lg flex items-center justify-center gap-1.5 font-semibold text-xs sm:text-sm text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer"
        >
          {copiedLink ? (
            <>
              <Check className="w-4 h-4 text-emerald-600" />
              <span className="text-emerald-600">Copied!</span>
            </>
          ) : (
            <>
              <Share2 className="w-4 h-4" />
              <span>Share</span>
            </>
          )}
        </button>
      </div>

      {/* Comments Drawer */}
      {showComments && (
        <div className="border-t border-slate-100 bg-slate-50/70 p-3 sm:p-4 space-y-3">
          
          {/* New comment input */}
          <form onSubmit={handleSendComment} className="flex items-center gap-2">
            <img
              src={user?.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=240&auto=format&fit=crop&q=80'}
              alt="Me"
              className="w-8 h-8 rounded-full object-cover shrink-0 ring-1 ring-slate-200"
            />
            <div className="flex-1 relative">
              <input
                type="text"
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="Write a comment..."
                className="w-full bg-white rounded-full py-1.5 pl-3.5 pr-10 text-xs sm:text-sm border border-slate-200 focus:outline-hidden focus:border-[#1877F2]"
              />
              <button
                type="submit"
                disabled={!commentText.trim()}
                className="absolute right-1.5 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-[#1877F2] text-white flex items-center justify-center disabled:opacity-40 cursor-pointer"
              >
                <Send className="w-3 h-3" />
              </button>
            </div>
          </form>

          {/* Comments List */}
          <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
            {comments.map((comm) => (
              <div key={comm.id} className="flex items-start gap-2.5">
                <img
                  src={comm.authorPhotoURL}
                  alt={comm.authorName}
                  className="w-7 h-7 rounded-full object-cover shrink-0 ring-1 ring-slate-200 mt-0.5"
                />
                <div className="flex-1">
                  <div className="bg-white rounded-2xl px-3 py-2 border border-slate-100 shadow-2xs">
                    <p className="font-bold text-xs text-slate-900 leading-tight">
                      {comm.authorName}
                    </p>
                    <p className="text-xs text-slate-700 mt-0.5 leading-relaxed">
                      {comm.text}
                    </p>
                  </div>
                  <div className="flex items-center gap-3 px-2 pt-0.5 text-[10px] text-slate-400">
                    <span>{formatTimeAgo(comm.createdAt)}</span>
                    <button className="font-semibold text-slate-500 hover:underline cursor-pointer">
                      Like
                    </button>
                    <button className="font-semibold text-slate-500 hover:underline cursor-pointer">
                      Reply
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

        </div>
      )}

    </article>
  );
};

function formatTimeAgo(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diffSec = Math.floor((now.getTime() - date.getTime()) / 1000);

  if (diffSec < 60) return 'Just now';
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m`;
  const diffHrs = Math.floor(diffMin / 60);
  if (diffHrs < 24) return `${diffHrs}h`;
  const diffDays = Math.floor(diffHrs / 24);
  if (diffDays < 7) return `${diffDays}d`;
  return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}
