import { useRef, useState } from "react";
import { cn } from "../utils/cn";
import { INITIAL_ENABLED, SUBSCRIPTIONS } from "../data/subscriptions";
import { SubscriptionCard } from "./SubscriptionCard";
import {
  BatteryIcon,
  BoltIcon,
  CheckIcon,
  FeedIcon,
  HomeIcon,
  RefreshIcon,
  SearchIcon,
  ServersIcon,
  SlidersIcon,
  SignalIcon,
  WifiIcon,
  XIcon,
} from "./icons";

type TabId = "home" | "servers" | "subscriptions" | "settings";

type TabDef = { id: TabId; label: string; Icon: typeof HomeIcon };

const TABS: TabDef[] = [
  { id: "home", label: "Home", Icon: HomeIcon },
  { id: "servers", label: "Servers", Icon: ServersIcon },
  { id: "subscriptions", label: "Subscriptions", Icon: FeedIcon },
  { id: "settings", label: "Settings", Icon: SlidersIcon },
];

function Placeholder({ t, onOpen }: { t: TabDef; onOpen: () => void }) {
  return (
    <main className="relative z-10 flex flex-1 flex-col items-center justify-center px-10 pb-8 text-center">
      <div className="flex h-16 w-16 items-center justify-center rounded-[20px] border border-white/10 bg-white/[0.05] text-slate-400 shadow-[0_10px_30px_-12px_rgba(0,0,0,0.8)] backdrop-blur">
        <t.Icon className="h-7 w-7" />
      </div>
      <h2 className="mt-4 font-display text-[16px] font-semibold text-white">{t.label} screen</h2>
      <p className="mt-1.5 text-[11px] leading-relaxed text-slate-400">
        Not included in this showcase — the mockup focuses on the{" "}
        <span className="font-medium text-[#00D4FF]">Subscriptions</span> screen.
      </p>
      <button
        type="button"
        onClick={onOpen}
        className="mt-5 cursor-pointer rounded-full bg-gradient-to-r from-[#00D4FF] to-[#8B5CF6] px-4 py-2 text-[11px] font-semibold text-[#051018] shadow-[0_6px_20px_-6px_rgba(0,212,255,0.6)] transition active:scale-95"
      >
        Open Subscriptions
      </button>
    </main>
  );
}

export function PhoneScreen() {
  const [tab, setTab] = useState<TabId>("subscriptions");
  const [enabled, setEnabled] = useState<Set<string>>(new Set(INITIAL_ENABLED));
  const [pings, setPings] = useState<Record<string, number>>(() =>
    Object.fromEntries(SUBSCRIPTIONS.map((s) => [s.id, s.ping]))
  );
  const [query, setQuery] = useState("");
  const [refreshing, setRefreshing] = useState(false);
  const [toast, setToast] = useState<{ id: number; msg: string } | null>(null);
  const toastTimer = useRef<number | null>(null);

  const showToast = (msg: string) => {
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    setToast({ id: Date.now(), msg });
    toastTimer.current = window.setTimeout(() => setToast(null), 2200);
  };

  const toggle = (id: string) => {
    const turningOn = !enabled.has(id);
    setEnabled((prev) => {
      const next = new Set(prev);
      if (turningOn) next.add(id);
      else next.delete(id);
      return next;
    });
    const sub = SUBSCRIPTIONS.find((s) => s.id === id);
    if (sub) showToast(turningOn ? `“${sub.name}” enabled · routes added` : `“${sub.name}” disabled`);
  };

  const refresh = () => {
    if (refreshing) return;
    setRefreshing(true);
    window.setTimeout(() => {
      setPings(
        Object.fromEntries(
          SUBSCRIPTIONS.map((s) => [
            s.id,
            Math.max(12, Math.min(120, Math.round(s.ping * (0.8 + Math.random() * 0.4)))),
          ])
        )
      );
      setRefreshing(false);
      showToast("All sources synced · updated just now");
    }, 1100);
  };

  const q = query.trim().toLowerCase();
  const shown = SUBSCRIPTIONS.filter((s) => `${s.name} ${s.url} ${s.badges.join(" ")}`.toLowerCase().includes(q));
  const activeCount = enabled.size;
  const inactiveTab = TABS.find((t) => t.id === tab && t.id !== "subscriptions");

  return (
    <div className="relative flex h-full w-full flex-col overflow-hidden rounded-[42px] bg-[#0A0E27]">
      {/* ambient screen lighting */}
      <div className="pointer-events-none absolute -top-24 left-1/2 h-64 w-[130%] -translate-x-1/2 rounded-full bg-[#00D4FF]/[0.13] blur-[70px]" />
      <div className="pointer-events-none absolute -bottom-28 -right-16 h-72 w-72 rounded-full bg-[#8B5CF6]/[0.15] blur-[80px]" />
      <div className="pointer-events-none absolute inset-0 bg-grid grid-fade" />

      {/* status bar */}
      <div className="relative z-20 flex h-11 shrink-0 items-center justify-between px-7 pt-1.5">
        <span className="font-display text-[13px] font-semibold tracking-tight text-slate-100">09:41</span>
        <div className="flex items-center gap-1.5 text-slate-200">
          <SignalIcon className="h-3.5 w-3.5" />
          <WifiIcon className="h-3.5 w-3.5" />
          <BatteryIcon className="h-[14px] w-[14px]" />
        </div>
      </div>

      {/* dynamic island */}
      <div className="pointer-events-none absolute left-1/2 top-[13px] z-30 flex h-[25px] w-[96px] -translate-x-1/2 items-center justify-end rounded-full bg-black pr-2 shadow-[inset_0_0_4px_rgba(255,255,255,0.08)]">
        <span className="h-2 w-2 rounded-full bg-[#101A3E] ring-1 ring-white/10" />
      </div>

      {tab === "subscriptions" ? (
        <>
          {/* header */}
          <header className="relative z-10 shrink-0 px-4 pb-2.5 pt-2">
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-[12px] bg-gradient-to-br from-[#00E9FF] via-[#3B82F6] to-[#8B5CF6] shadow-[0_4px_18px_-4px_rgba(0,212,255,0.55)] ring-1 ring-inset ring-white/30">
                <BoltIcon className="h-[18px] w-[18px] text-white drop-shadow" />
              </div>
              <div className="leading-tight">
                <p className="font-display text-[14px] font-bold tracking-tight text-white">
                  LTE{" "}
                  <span className="bg-gradient-to-r from-[#00D4FF] to-[#A855F7] bg-clip-text text-transparent">
                    VPN
                  </span>
                </p>
                <p className="font-mono text-[8.5px] tracking-[0.2em] text-slate-500">CLIENT · v4.2.1</p>
              </div>
              <button
                type="button"
                onClick={refresh}
                title="Sync all sources"
                className="ml-auto flex h-9 w-9 cursor-pointer items-center justify-center rounded-[12px] border border-white/10 bg-white/[0.06] text-slate-300 backdrop-blur transition hover:bg-white/[0.1] hover:text-white active:scale-90"
              >
                <RefreshIcon className={cn("h-4 w-4", refreshing && "animate-spin [animation-duration:0.8s]")} />
              </button>
            </div>

            <div className="mt-3 flex items-start justify-between gap-2">
              <div className="min-w-0">
                <h1 className="font-display text-[19px] font-bold leading-tight tracking-tight text-white">
                  Subscriptions
                </h1>
                <p className="mt-0.5 truncate text-[10.5px] text-slate-400">
                  Auto-updated from GitHub / GitLab / Codeberg
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-1.5 pt-1">
                <span className="rounded-full border border-white/10 bg-white/[0.05] px-2 py-[3px] font-mono text-[8.5px] text-slate-400">
                  12 sources
                </span>
                <span className="flex items-center gap-1 rounded-full border border-[#00D4FF]/35 bg-[#00D4FF]/10 px-2 py-[3px] font-mono text-[8.5px] text-[#7EE6FF]">
                  <span className="h-1 w-1 animate-pulse rounded-full bg-[#00D4FF]" />
                  {activeCount} on
                </span>
              </div>
            </div>

            {/* search */}
            <div className="relative mt-3">
              <SearchIcon className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search sources, protocols, URLs…"
                className="h-9 w-full rounded-[12px] border border-white/10 bg-white/[0.05] pl-9 pr-9 text-[11.5px] text-slate-100 outline-none backdrop-blur transition placeholder:text-slate-500 focus:border-[#00D4FF]/50 focus:bg-white/[0.07] focus:shadow-[0_0_0_3px_rgba(0,212,255,0.12)]"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => setQuery("")}
                  className="absolute right-2 top-1/2 flex h-5 w-5 -translate-y-1/2 cursor-pointer items-center justify-center rounded-full text-slate-400 transition hover:bg-white/10 hover:text-white"
                >
                  <XIcon className="h-3 w-3" />
                </button>
              )}
            </div>
          </header>

          {/* scrollable card list */}
          <main className="scroll-hide relative z-10 flex-1 overflow-y-auto px-4 pb-3 pt-1">
            <div className="flex flex-col gap-2.5">
              {shown.map((s, i) => (
                <div key={s.id} style={{ animation: `fade-up 0.5s ${i * 45}ms cubic-bezier(0.22,0.9,0.3,1) both` }}>
                  <SubscriptionCard
                    sub={s}
                    enabled={enabled.has(s.id)}
                    ping={pings[s.id]}
                    onToggle={toggle}
                    onToast={showToast}
                  />
                </div>
              ))}

              {shown.length === 0 && (
                <div className="flex flex-col items-center rounded-[20px] border border-dashed border-white/10 bg-white/[0.03] px-6 py-10 text-center">
                  <SearchIcon className="h-6 w-6 text-slate-500" />
                  <p className="mt-3 text-[12px] font-medium text-slate-300">No sources match “{query}”</p>
                  <p className="mt-1 text-[10px] text-slate-500">Try a protocol (VLESS, Xray) or a host name.</p>
                  <button
                    type="button"
                    onClick={() => setQuery("")}
                    className="mt-4 cursor-pointer rounded-full border border-[#00D4FF]/40 bg-[#00D4FF]/10 px-3.5 py-1.5 text-[10.5px] font-semibold text-[#00D4FF] transition hover:bg-[#00D4FF]/20 active:scale-95"
                  >
                    Clear search
                  </button>
                </div>
              )}
            </div>

            <footer className="pb-2 pt-4 text-center font-mono text-[9px] tracking-[0.14em] text-slate-500/80">
              — end of list · sources checked hourly —
            </footer>
          </main>
        </>
      ) : (
        /* placeholder screens for the other tabs */
        <>{inactiveTab && <Placeholder t={inactiveTab} onOpen={() => setTab("subscriptions")} />}</>
      )}

      {/* bottom nav */}
      <nav className="relative z-20 shrink-0 border-t border-white/[0.07] bg-[#080C22]/85 px-2 pb-4 pt-2 backdrop-blur-xl">
        <div className="grid grid-cols-4">
          {TABS.map((t) => {
            const active = tab === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id)}
                className="group relative flex cursor-pointer flex-col items-center gap-1 py-1"
              >
                {active && (
                  <span className="absolute -top-[7px] h-[3px] w-9 rounded-full bg-gradient-to-r from-[#00D4FF] to-[#A855F7] shadow-[0_0_12px_rgba(0,212,255,0.8)]" />
                )}
                <t.Icon
                  className={cn(
                    "h-[19px] w-[19px] transition-all",
                    active
                      ? "text-[#00D4FF] drop-shadow-[0_0_8px_rgba(0,212,255,0.7)]"
                      : "text-slate-500 group-hover:text-slate-300"
                  )}
                />
                <span
                  className={cn(
                    "text-[9px] font-medium tracking-wide transition-colors",
                    active ? "text-slate-100" : "text-slate-500 group-hover:text-slate-300"
                  )}
                >
                  {t.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* film grain */}
      <div className="noise-layer pointer-events-none absolute inset-0 z-30 opacity-[0.05]" />

      {/* toast */}
      {toast && (
        <div
          key={toast.id}
          className="absolute bottom-[86px] left-1/2 z-40 flex items-center gap-2 rounded-full border border-[#00D4FF]/30 bg-[#0B1132]/95 py-2 pl-3 pr-4 shadow-[0_8px_30px_-6px_rgba(0,0,0,0.7),0_0_20px_-4px_rgba(0,212,255,0.35)] backdrop-blur"
          style={{ animation: "toast-in 0.28s cubic-bezier(0.2,0.9,0.3,1.15) both" }}
        >
          <CheckIcon className="h-3.5 w-3.5 shrink-0 text-[#00D4FF]" />
          <span className="max-w-[280px] truncate text-[10.5px] font-medium text-slate-100">{toast.msg}</span>
        </div>
      )}
    </div>
  );
}
