import { Award, Crown, Trophy } from "lucide-react";
import type { ScoreEntry } from "@/game/types";
import { formatScore, formatTime } from "@/lib/scores";

const rankStyles = [
  "border-[#c8a061] bg-[#e3b974] text-[#3c2d1b]",
  "border-[#aeb5b0] bg-[#d9dbd2] text-[#3a453f]",
  "border-[#b98965] bg-[#d3a37f] text-[#432e21]",
];

export function ScoreTable({
  scores,
  highlightId,
  limit = 8,
  dense = false,
  dark = false,
}: {
  scores: ScoreEntry[];
  highlightId?: string | null;
  limit?: number;
  dense?: boolean;
  dark?: boolean;
}) {
  if (scores.length === 0) {
    return (
      <div
        className={`flex flex-col items-center justify-center rounded-2xl border border-dashed px-4 py-6 text-center ${
          dark ? "border-[#f0d9a8]/20 bg-[#f0d9a8]/5" : "border-ink/15 bg-ink/[0.025]"
        }`}
      >
        <Trophy className={`mb-2 h-6 w-6 ${dark ? "text-[#e3b974]/70" : "text-gold-deep/70"}`} />
        <p className={`text-xs font-medium ${dark ? "text-sand-100" : "text-ink"}`}>لا مسارات مسجّلة بعد</p>
        <p className={`mt-1 text-[10px] leading-relaxed ${dark ? "text-sand-200/60" : "text-ink-muted"}`}>
          كن أول من يوقظ الأضرحة ويترك أثرًا في الرمال
        </p>
      </div>
    );
  }

  return (
    <ol className="space-y-1">
      {scores.slice(0, limit).map((entry, index) => {
        const highlight = entry.id === highlightId;
        return (
          <li
            key={entry.id}
            className={`group flex items-center gap-2.5 rounded-xl border px-2 py-1.5 transition-colors ${
              highlight
                ? dark
                  ? "border-[#e3b974]/45 bg-[#e3b974]/12"
                  : "border-[#b98b4a]/45 bg-[#e3b974]/20"
                : dark
                  ? "border-transparent hover:border-[#f0d9a8]/15 hover:bg-white/[0.035]"
                  : "border-transparent hover:border-ink/10 hover:bg-white/40"
            }`}
          >
            <span
              className={`nums flex h-5 w-5 shrink-0 items-center justify-center rounded-md border text-[10px] font-semibold ${
                rankStyles[index] ?? (dark ? "border-[#f0d9a8]/20 text-[#d8c9aa]" : "border-ink/10 text-ink-muted")
              }`}
            >
              {index + 1}
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <p className={`truncate text-[11px] font-medium ${dark ? "text-sand-50" : "text-ink"}`}>
                  {entry.name || "مسافر"}
                </p>
                {highlight && (
                  <span className="rounded bg-[#b98b4a] px-1 py-px text-[7px] font-semibold text-[#fff8e9]">هذه الجولة</span>
                )}
                {index === 0 && <Crown className="h-3 w-3 shrink-0 text-[#c09350]" />}
              </div>
              {!dense && (
                <p className={`mt-0.5 text-[8.5px] ${dark ? "text-sand-200/50" : "text-ink-faint"}`}>
                  دورة {entry.cycles} · {entry.kills} ظل · {formatTime(entry.time)}
                </p>
              )}
            </div>
            <span className={`nums text-[11px] font-semibold ${dark ? "text-[#f5dba4]" : "text-ink-soft"}`}>
              {formatScore(entry.score)}
            </span>
          </li>
        );
      })}
    </ol>
  );
}

export function BestRunBadge({ scores, dark = false }: { scores: ScoreEntry[]; dark?: boolean }) {
  const best = scores[0];
  return (
    <div
      className={`flex items-center gap-2.5 rounded-2xl border px-3 py-2 ${
        dark ? "border-[#f0d9a8]/20 bg-[#102620]/60" : "border-ink/10 bg-white/45"
      }`}
    >
      <div className="flex h-7 w-7 items-center justify-center rounded-full border border-[#e3b974]/40 bg-[#e3b974]/15">
        <Award className="h-3.5 w-3.5 text-[#c09350]" />
      </div>
      <div className="min-w-0">
        <p className={`text-[8px] uppercase tracking-[0.16em] ${dark ? "text-sand-200/55" : "text-ink-faint"}`}>
          أفضل مسار
        </p>
        <p className={`nums text-xs font-semibold ${dark ? "text-sand-50" : "text-ink"}`}>
          {best ? `${formatScore(best.score)} نقطة` : "— لم تُسجّل بعد —"}
        </p>
      </div>
    </div>
  );
}
