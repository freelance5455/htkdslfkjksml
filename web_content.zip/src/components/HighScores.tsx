import type { ScoreEntry } from "@/lib/storage";

interface Props {
  scores: ScoreEntry[];
  onClose: () => void;
  onClear: () => void;
}

const MODE_LABEL: Record<string, string> = {
  tap: "انتخاب",
  type: "تایپ",
  meaning: "معنی",
};

export default function HighScores({ scores, onClose, onClear }: Props) {
  return (
    <div className="flex h-full w-full items-center justify-center overflow-y-auto p-4">
      <div className="glass w-full max-w-lg rounded-3xl p-4">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="font-display text-xl font-black">🏆 جدول رکوردها</h3>
          <button
            onClick={onClose}
            className="grid h-8 w-8 place-items-center rounded-lg bg-white/10 text-sm transition active:scale-90"
            aria-label="بستن"
          >
            ✕
          </button>
        </div>

        {scores.length === 0 ? (
          <p className="py-8 text-center text-sm text-slate-500">هنوز رکوردی ثبت نشده است.</p>
        ) : (
          <ul className="max-h-[52vh] divide-y divide-white/5 overflow-y-auto">
            {scores.map((s, i) => (
              <li key={s.id} className="flex items-center gap-2.5 py-2 text-sm">
                <span
                  className={`grid h-7 w-7 shrink-0 place-items-center rounded-lg font-display text-xs font-black ${
                    i === 0
                      ? "bg-amber-400/30 text-amber-200"
                      : i === 1
                        ? "bg-slate-300/25 text-slate-100"
                        : i === 2
                          ? "bg-orange-500/25 text-orange-200"
                          : "bg-white/5 text-slate-400"
                  }`}
                >
                  {i + 1}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-bold">{s.name || "بازیکن"}</span>
                  <span className="block truncate text-[11px] text-slate-400">
                    {s.lessonTitle} • {MODE_LABEL[s.mode] ?? s.mode} • {s.mastered} کلمه • دقت{" "}
                    {s.accuracy}٪
                  </span>
                </span>
                <span className="shrink-0 font-display text-lg font-black text-cyan-300">
                  {s.score}
                </span>
              </li>
            ))}
          </ul>
        )}

        <button
          onClick={onClear}
          className="mt-3 w-full rounded-xl border border-rose-400/40 px-3 py-2 text-xs font-bold text-rose-300 transition active:scale-95"
        >
          پاک کردن رکوردها
        </button>
      </div>
    </div>
  );
}
