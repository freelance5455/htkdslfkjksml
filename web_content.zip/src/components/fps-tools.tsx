import { useState } from "react";
import { FpsChart, CompareChart } from "@/components/charts";
import { Button, Field, Notice } from "@/components/ui";
import { formatWhen, isFpsTarget, presetLabel } from "@/lib/model";
import { useAppStore, useSelectedGame } from "@/lib/store";

export function FpsLogTool({ compact = false }: { compact?: boolean }) {
  const game = useSelectedGame();
  const logs = useAppStore((state) => state.fpsLogs);
  const refresh = useAppStore((state) => state.refreshSample);
  const addFpsLog = useAppStore((state) => state.addFpsLog);
  const removeFpsLog = useAppStore((state) => state.removeFpsLog);
  const [measured, setMeasured] = useState("");
  const [note, setNote] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const visible = (game ? logs.filter((entry) => entry.gameId === game.id) : logs).slice(0, compact ? 8 : 20);
  const chart = [...visible].reverse().map((entry) => ({
    label: formatWhen(entry.at),
    measured: entry.measuredFps,
    target: entry.targetFps,
  }));

  function save() {
    const value = Number(measured);
    if (!Number.isFinite(value) || value < 1 || value > 1000) {
      setError("Enter a measured FPS from 1 to 1000.");
      setSaved(false);
      return;
    }
    const target = game && isFpsTarget(game.fpsTarget) ? game.fpsTarget : 60;
    const ok = addFpsLog({
      gameId: game?.id ?? null,
      measuredFps: value,
      targetFps: target,
      refreshHz: refresh?.displayHz ?? null,
      note: note.trim(),
    });
    if (!ok) {
      setError("That measurement was not saved.");
      setSaved(false);
      return;
    }
    setMeasured("");
    setNote("");
    setError(null);
    setSaved(true);
  }

  return (
    <div className="stack">
      <Field label="Measured FPS" hint={game ? `Saved against ${game.name}. Target stored with the row: ${game.fpsTarget}.` : "No profile selected. The row is still saved."} error={error}>
        <input className="field-input tabular-nums" inputMode="decimal" value={measured} onChange={(event) => setMeasured(event.target.value)} placeholder="What you measured" />
      </Field>
      <Field label="Note" hint="Optional. Where the number came from.">
        <input className="field-input" value={note} maxLength={200} onChange={(event) => setNote(event.target.value)} placeholder="In-game counter, 30 second count…" />
      </Field>
      <Button onClick={save}>Save measurement</Button>
      {saved ? <Notice tone="ok">Saved in the manual log on this device.</Notice> : null}
      <p className="text-xs text-faint">These points are numbers you entered. The chart does not read the game.</p>
      {chart.length > 0 ? <FpsChart data={chart} /> : <p className="text-sm text-muted">No measurements yet.</p>}
      {visible.length > 0 ? (
        <ul className="divide-y divide-line">
          {visible.map((entry) => (
            <li key={entry.id} className="flex items-start justify-between gap-3 py-3">
              <div>
                <p className="font-semibold tabular-nums">{entry.measuredFps} measured · target {entry.targetFps}</p>
                <p className="text-sm text-faint">
                  {formatWhen(entry.at)}
                  {entry.refreshHz != null ? ` · refresh sample ${entry.refreshHz} Hz` : ""}
                  {entry.note ? ` · ${entry.note}` : ""}
                </p>
              </div>
              <Button variant="ghost" className="shrink-0 px-2" onClick={() => removeFpsLog(entry.id)}>
                Remove
              </Button>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

export function CompareTool() {
  const game = useSelectedGame();
  const compares = useAppStore((state) => state.compares);
  const addCompare = useAppStore((state) => state.addCompare);
  const removeCompare = useAppStore((state) => state.removeCompare);
  const [label, setLabel] = useState("");
  const [measured, setMeasured] = useState("");
  const [note, setNote] = useState("");
  const [error, setError] = useState<string | null>(null);

  function save() {
    const value = Number(measured);
    if (!Number.isFinite(value) || value < 1 || value > 1000) {
      setError("Enter the measured FPS for this run.");
      return;
    }
    const ok = addCompare({
      label,
      gameId: game?.id ?? null,
      preset: game ? presetLabel(game.preset) : "No profile",
      measuredFps: value,
      targetFps: game?.fpsTarget ?? 60,
      note: note.trim(),
    });
    if (!ok) {
      setError("That comparison was not saved.");
      return;
    }
    setLabel("");
    setMeasured("");
    setNote("");
    setError(null);
  }

  const chart = [...compares].slice(0, 8).reverse().map((entry) => ({
    label: entry.label.slice(0, 12),
    measured: entry.measuredFps,
  }));

  return (
    <div className="stack">
      <Field label="Run label" error={error}>
        <input className="field-input" value={label} maxLength={60} onChange={(event) => setLabel(event.target.value)} placeholder="Balanced, shadows low" />
      </Field>
      <Field label="Measured FPS" hint="Type the FPS you observed. This is not a benchmark runner.">
        <input className="field-input tabular-nums" inputMode="decimal" value={measured} onChange={(event) => setMeasured(event.target.value)} />
      </Field>
      <Field label="Note">
        <input className="field-input" value={note} maxLength={200} onChange={(event) => setNote(event.target.value)} />
      </Field>
      <Button onClick={save}>Add to comparison log</Button>
      {chart.length > 0 ? <CompareChart data={chart} /> : <p className="text-sm text-muted">Add two or more runs to compare them.</p>}
      <ul className="divide-y divide-line">
        {compares.map((entry) => (
          <li key={entry.id} className="flex items-start justify-between gap-3 py-3">
            <div>
              <p className="font-semibold">{entry.label}</p>
              <p className="text-sm text-muted tabular-nums">
                {entry.measuredFps} measured · target {entry.targetFps} · {entry.preset}
              </p>
              <p className="text-xs text-faint">{formatWhen(entry.at)}{entry.note ? ` · ${entry.note}` : ""}</p>
            </div>
            <Button variant="ghost" className="shrink-0 px-2" onClick={() => removeCompare(entry.id)}>
              Remove
            </Button>
          </li>
        ))}
      </ul>
    </div>
  );
}
