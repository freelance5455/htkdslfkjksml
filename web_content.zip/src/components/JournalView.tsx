import React, { useState } from 'react';
import { BookOpen, Check, Edit3 } from 'lucide-react';
import {
  ALL_TRAITS,
  PUP_ADULT_AGE_SEC,
  TRAIT_NOTES,
  formatDurationShort,
  formatLocationLabel,
} from '../data/kennelConstants';
import { isPup } from '../engine/simulation';
import { GameState, UniqueTrait } from '../types/kennel';
import { DogPortrait } from './DogPortrait';

interface JournalViewProps {
  state: GameState;
  onSelectDog: (dogId: string) => void;
  onRenameDog: (dogId: string, newName: string) => void;
  onUpdateNotes: (dogId: string, notes: string) => void;
  onToggleTrait: (dogId: string, trait: UniqueTrait) => void;
}

export const JournalView: React.FC<JournalViewProps> = ({
  state,
  onSelectDog,
  onRenameDog,
  onUpdateNotes,
  onToggleTrait,
}) => {
  const selectedDog =
    state.dogs.find((d) => d.id === state.journalSelectedDogId) ?? state.dogs[0] ?? null;

  const [editingName, setEditingName] = useState(false);
  const [nameDraft, setNameDraft] = useState('');
  const [showDeceased, setShowDeceased] = useState(false);

  const findDogName = (id: string | null) => {
    if (!id) return 'Unknown / Market Lineage';
    return (
      state.dogs.find((d) => d.id === id)?.name ??
      state.deceased.find((d) => d.id === id)?.name ??
      'Past Kennel Dog'
    );
  };

  return (
    <div className="space-y-6">
      <section className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-4 border-b border-[#DFDBD0]">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-semibold text-[#1C1B18]">
            Kennel Genetics &amp; Trait Journal
          </h1>
          <p className="mt-1 text-sm text-[#5C584F]">
            Track inherited coat &amp; pattern alleles, behavioral observations, pack alliances, and each dingo&apos;s unique traits.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setShowDeceased((v) => !v)}
          className="min-h-[40px] px-3.5 py-2 text-xs font-medium rounded-lg border border-[#D8D3C6] bg-white text-[#1C1B18] hover:bg-[#EFECE4] self-start sm:self-auto cursor-pointer"
        >
          {showDeceased ? 'View Active Roster' : `Past Lineage (${state.deceased.length})`}
        </button>
      </section>

      {showDeceased ? (
        <section className="rounded-2xl bg-white border border-[#DFDBD0] p-5 space-y-3">
          <h2 className="font-display text-xl font-semibold text-[#1C1B18]">
            Deceased Lineage Archive
          </h2>
          {state.deceased.length === 0 ? (
            <p className="text-sm text-[#5C584F]">No dogs have passed away in this kennel yet.</p>
          ) : (
            <div className="divide-y divide-[#EFECE4]">
              {state.deceased.map((rec) => (
                <div key={rec.id} className="py-3">
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <span className="font-semibold text-base text-[#1C1B18]">{rec.name}</span>
                    <span className="font-mono-tabular text-xs text-[#5C584F]">
                      Gen {rec.generation} · Lived {formatDurationShort(rec.ageAtDeathSec)} · {rec.cause}
                    </span>
                  </div>
                  <p className="text-xs text-[#5C584F] capitalize mt-0.5">
                    {rec.gender} · {rec.coat} · {rec.bodyType} · {rec.pattern}
                  </p>
                  <p className="text-xs text-[#4A463E] mt-1">
                    Traits: {rec.traits.join(', ')}
                  </p>
                </div>
              ))}
            </div>
          )}
        </section>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Dog Selector List */}
          <aside className="lg:col-span-4 rounded-2xl bg-white border border-[#DFDBD0] p-3 space-y-1.5">
            <div className="px-2 py-1 text-xs font-semibold text-[#5C584F]">
              Housed Dogs ({state.dogs.length})
            </div>
            {state.dogs.length === 0 ? (
              <p className="px-2 py-4 text-sm text-[#7A7467]">No dogs housed.</p>
            ) : (
              state.dogs.map((dog) => {
                const active = selectedDog?.id === dog.id;
                const pup = isPup(dog);
                return (
                  <button
                    key={dog.id}
                    type="button"
                    onClick={() => {
                      onSelectDog(dog.id);
                      setEditingName(false);
                    }}
                    className={`w-full text-left px-3 py-2.5 rounded-xl transition-colors cursor-pointer ${
                      active
                        ? 'bg-[#1F4E3D] text-white'
                        : 'hover:bg-[#EFECE4] text-[#1C1B18]'
                    }`}
                  >
                    <div className="flex items-baseline justify-between gap-2">
                      <span className="font-semibold text-sm truncate">{dog.name}</span>
                      <span
                        className={`text-[11px] font-mono-tabular ${
                          active ? 'text-white/80' : 'text-[#5C584F]'
                        }`}
                      >
                        {formatLocationLabel(dog.location)}
                      </span>
                    </div>
                    <div
                      className={`text-xs capitalize mt-0.5 ${
                        active ? 'text-white/80' : 'text-[#5C584F]'
                      }`}
                    >
                      {dog.gender} · {pup ? 'Pup' : 'Adult'} · {dog.discoveredTraits.length}/{dog.traits.length} traits logged
                    </div>
                  </button>
                );
              })
            )}
          </aside>

          {/* Selected Dog Detailed Journal Page */}
          <div className="lg:col-span-8">
            {!selectedDog ? (
              <div className="rounded-2xl bg-white border border-[#DFDBD0] p-8 text-center text-sm text-[#5C584F]">
                Select a dog to inspect their genetics, behavior metrics, and tracked traits.
              </div>
            ) : (
              <div className="space-y-5">
                {/* Identity & Portrait */}
                <section className="rounded-2xl bg-white border border-[#DFDBD0] p-5">
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-start">
                    <div className="md:col-span-5">
                      <DogPortrait
                        name={selectedDog.name}
                        genetics={selectedDog.genetics}
                        isPup={isPup(selectedDog)}
                      />
                    </div>
                    <div className="md:col-span-7 space-y-3">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        {editingName ? (
                          <form
                            onSubmit={(e) => {
                              e.preventDefault();
                              onRenameDog(selectedDog.id, nameDraft);
                              setEditingName(false);
                            }}
                            className="flex items-center gap-2 w-full"
                          >
                            <input
                              type="text"
                              value={nameDraft}
                              onChange={(e) => setNameDraft(e.target.value)}
                              maxLength={24}
                              autoFocus
                              className="flex-1 rounded-lg border border-[#1F4E3D] px-3 py-1.5 text-base font-semibold text-[#1C1B18] focus:outline-none"
                            />
                            <button
                              type="submit"
                              className="min-h-[38px] px-3 py-1.5 text-xs font-semibold rounded-lg bg-[#1F4E3D] text-white cursor-pointer"
                            >
                              Save
                            </button>
                          </form>
                        ) : (
                          <>
                            <h2 className="font-display text-2xl font-semibold text-[#1C1B18]">
                              {selectedDog.name}
                            </h2>
                            <button
                              type="button"
                              onClick={() => {
                                setNameDraft(selectedDog.name);
                                setEditingName(true);
                              }}
                              className="inline-flex items-center gap-1 min-h-[36px] px-2.5 py-1 text-xs font-medium rounded-lg border border-[#D8D3C6] text-[#5C584F] hover:text-[#1C1B18] hover:bg-[#EFECE4] cursor-pointer"
                            >
                              <Edit3 className="w-3.5 h-3.5" aria-hidden="true" />
                              <span>Rename</span>
                            </button>
                          </>
                        )}
                      </div>

                      <div className="text-xs text-[#5C584F] font-mono-tabular flex flex-wrap gap-x-3 gap-y-1">
                        <span className="capitalize">{selectedDog.gender}</span>
                        <span>·</span>
                        <span>{isPup(selectedDog) ? 'Pup (<1h)' : 'Adult'}</span>
                        <span>·</span>
                        <span>Age {formatDurationShort(selectedDog.ageSeconds)} / {formatDurationShort(selectedDog.lifespanSeconds)}</span>
                        <span>·</span>
                        <span>Gen {selectedDog.generation}</span>
                      </div>

                      {/* Genetics Block */}
                      <div className="rounded-xl bg-[#F7F5F0] border border-[#E5E1D6] p-3 text-xs space-y-1.5">
                        <div className="font-semibold text-[#1C1B18]">Genetics &amp; Appearance</div>
                        <div className="text-[#4A463E] capitalize">
                          Coat: <strong>{selectedDog.genetics.coat}</strong> ({selectedDog.genetics.coatAlleles.join(' / ')})
                        </div>
                        <div className="text-[#4A463E] capitalize">
                          Build: <strong>{selectedDog.genetics.bodyType}</strong> ({selectedDog.genetics.bodyAlleles.join(' / ')})
                        </div>
                        <div className="text-[#4A463E] capitalize">
                          Adult Pattern: <strong>{selectedDog.genetics.pattern}</strong> ({selectedDog.genetics.patternAlleles.join(' / ')})
                          {isPup(selectedDog) && (
                            <span className="block text-[#9A5B13] mt-0.5 normal-case">
                              Currently visually patternless as a pup; markings emerge at {formatDurationShort(PUP_ADULT_AGE_SEC)} adulthood.
                            </span>
                          )}
                        </div>
                        {(selectedDog.motherId || selectedDog.fatherId) && (
                          <div className="text-[#5C584F] pt-1 border-t border-[#E5E1D6]">
                            Parents: {findDogName(selectedDog.motherId)} × {findDogName(selectedDog.fatherId)}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </section>

                {/* Stats, Biology & Skills */}
                <section className="rounded-2xl bg-white border border-[#DFDBD0] p-5 space-y-4">
                  <h3 className="font-display text-lg font-semibold text-[#1C1B18]">
                    Condition, Biology &amp; Skills
                  </h3>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono-tabular">
                    {[
                      { label: 'Health', val: selectedDog.stats.health },
                      { label: 'Mood', val: selectedDog.stats.mood },
                      { label: 'Energy', val: selectedDog.stats.energy },
                      { label: 'Stress', val: selectedDog.stats.stress },
                      { label: 'Hunger', val: selectedDog.stats.hunger },
                      { label: 'Thirst', val: selectedDog.stats.thirst },
                      { label: 'Dominance', val: selectedDog.stats.dominance },
                      { label: 'Aggression', val: selectedDog.stats.aggression },
                      { label: 'Playfulness', val: selectedDog.stats.playfulness },
                      { label: 'Intelligence', val: selectedDog.stats.intelligence },
                      { label: 'Mating Drive', val: selectedDog.stats.matingDrive },
                      { label: 'Fertility', val: selectedDog.stats.fertility },
                    ].map((s) => (
                      <div key={s.label} className="rounded-xl bg-[#F7F5F0] border border-[#E5E1D6] p-2.5">
                        <div className="text-[#5C584F] font-sans">{s.label}</div>
                        <div className="text-sm font-semibold text-[#1C1B18] mt-0.5">
                          {Math.round(s.val)}%
                        </div>
                      </div>
                    ))}
                  </div>

                  {selectedDog.gender === 'female' && !isPup(selectedDog) && (
                    <p className="text-xs text-[#4A463E] font-mono-tabular">
                      {selectedDog.pregnantRemainingSec !== null
                        ? `Gestating litter · Birth in ${formatDurationShort(selectedDog.pregnantRemainingSec)}`
                        : selectedDog.fertilityCooldownSec > 0
                        ? `Post-mating fertility reset · Begins rising again in ${formatDurationShort(selectedDog.fertilityCooldownSec)}`
                        : selectedDog.stats.fertility >= 74
                        ? 'Fertility at receptive peak.'
                        : 'Fertility climbing toward peak window.'}
                    </p>
                  )}

                  <div className="pt-3 border-t border-[#EFECE4]">
                    <div className="text-xs font-semibold text-[#5C584F] mb-2">Skills</div>
                    <div className="flex flex-wrap gap-x-5 gap-y-1 text-xs font-mono-tabular text-[#1C1B18]">
                      <span>Foraging: {Math.round(selectedDog.skills.foraging)}</span>
                      <span>Tracking: {Math.round(selectedDog.skills.tracking)}</span>
                      <span>Agility: {Math.round(selectedDog.skills.agility)}</span>
                      <span>Watchfulness: {Math.round(selectedDog.skills.watchfulness)}</span>
                      <span>Social Grace: {Math.round(selectedDog.skills.socialGrace)}</span>
                    </div>
                  </div>
                </section>

                {/* Unique Trait Tracker */}
                <section className="rounded-2xl bg-white border border-[#DFDBD0] p-5 space-y-3">
                  <div className="flex items-baseline justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-[#1F4E3D]" aria-hidden="true" />
                      <h3 className="font-display text-lg font-semibold text-[#1C1B18]">
                        Unique Traits Registry
                      </h3>
                    </div>
                    <span className="text-xs font-mono-tabular text-[#5C584F]">
                      {selectedDog.discoveredTraits.length} logged
                    </span>
                  </div>
                  <p className="text-xs text-[#5C584F]">
                    Traits marked Observed were automatically confirmed from behavior you witnessed or may be tagged manually as you study {selectedDog.name}.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                    {ALL_TRAITS.map((trait) => {
                      const isObserved = selectedDog.discoveredTraits.includes(trait);
                      return (
                        <button
                          key={trait}
                          type="button"
                          onClick={() => onToggleTrait(selectedDog.id, trait)}
                          className={`text-left rounded-xl border p-3 transition-colors cursor-pointer ${
                            isObserved
                              ? 'bg-[#1F4E3D]/8 border-[#1F4E3D]/40 text-[#1C1B18]'
                              : 'bg-[#F7F5F0] border-[#E5E1D6] text-[#5C584F] hover:bg-[#EFECE4]'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs font-semibold capitalize">{trait}</span>
                            {isObserved && (
                              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#1F4E3D]">
                                <Check className="w-3 h-3" aria-hidden="true" />
                                Observed
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-[#5C584F] mt-1 leading-snug">
                            {TRAIT_NOTES[trait]}
                          </p>
                        </button>
                      );
                    })}
                  </div>
                </section>

                {/* Pack Alliances & Field Notes */}
                <section className="rounded-2xl bg-white border border-[#DFDBD0] p-5 space-y-4">
                  <h3 className="font-display text-lg font-semibold text-[#1C1B18]">
                    Pack Bonds &amp; Handler Notes
                  </h3>

                  <div className="text-xs text-[#4A463E] space-y-1">
                    <div className="font-semibold text-[#1C1B18]">Relationship to You:</div>
                    <div className="font-mono-tabular">
                      Trust {Math.round(selectedDog.playerRel.trust)} · Curiosity {Math.round(selectedDog.playerRel.curiosity)} · Fear {Math.round(selectedDog.playerRel.fear)} · Anger {Math.round(selectedDog.playerRel.anger)} ({selectedDog.playerRel.interactionCount} encounters)
                    </div>
                  </div>

                  {Object.keys(selectedDog.pairRelations).length > 0 && (
                    <div className="text-xs space-y-1">
                      <div className="font-semibold text-[#1C1B18]">Other Dogs:</div>
                      <div className="flex flex-wrap gap-x-4 gap-y-1 font-mono-tabular text-[#4A463E]">
                        {Object.entries(selectedDog.pairRelations).map(([otherId, rel]) => {
                          const other = state.dogs.find((d) => d.id === otherId);
                          if (!other) return null;
                          return (
                            <span key={otherId}>
                              {other.name}: Affinity {Math.round(rel.affinity)}
                              {rel.isAlly ? ' (Ally)' : rel.tension > 45 ? ' (Tense)' : ''}
                            </span>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="block text-xs font-semibold text-[#1C1B18] mb-1.5">
                      Handler Field Notes
                    </label>
                    <textarea
                      rows={3}
                      value={selectedDog.notes}
                      onChange={(e) => onUpdateNotes(selectedDog.id, e.target.value)}
                      placeholder="Record lineage plans, triggers, or behavioral patterns..."
                      className="w-full rounded-xl border border-[#D8D3C6] bg-[#F7F5F0] p-3 text-sm text-[#1C1B18] focus:outline-none focus:border-[#1F4E3D]"
                    />
                  </div>
                </section>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
