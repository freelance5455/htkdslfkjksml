import { useCallback, useRef } from "react";
import { BANDS, GAIN_MAX, GAIN_MIN, formatDb } from "@/lib/eq/bands";
import { cn } from "@/lib/utils";

type EqFadersProps = {
  gains: number[];
  onChange: (index: number, value: number) => void;
  disabled?: boolean;
};

export function EqFaders({ gains, onChange, disabled }: EqFadersProps) {
  return (
    <div className="relative z-10 grid h-full grid-cols-10 gap-0 px-4 pb-1 pt-4 sm:gap-1 sm:px-7">
      {BANDS.map((band, index) => (
        <Fader
          key={band.freq}
          label={band.label}
          value={gains[index] ?? 0}
          disabled={disabled}
          onChange={(value) => onChange(index, value)}
        />
      ))}
    </div>
  );
}

type FaderProps = {
  label: string;
  value: number;
  onChange: (value: number) => void;
  disabled?: boolean;
};

function Fader({ label, value, onChange, disabled }: FaderProps) {
  const trackRef = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);

  const valueFromY = useCallback((clientY: number) => {
    const track = trackRef.current;
    if (!track) return value;
    const rect = track.getBoundingClientRect();
    const t = (clientY - rect.top) / rect.height;
    const db = GAIN_MAX - t * (GAIN_MAX - GAIN_MIN);
    return Math.min(GAIN_MAX, Math.max(GAIN_MIN, db));
  }, [value]);

  const t = (GAIN_MAX - value) / (GAIN_MAX - GAIN_MIN);

  return (
    <div className="flex h-full min-w-0 flex-col items-center">
      <div
        ref={trackRef}
        role="slider"
        aria-label={`${label} Hz`}
        aria-valuemin={GAIN_MIN}
        aria-valuemax={GAIN_MAX}
        aria-valuenow={Number(value.toFixed(1))}
        aria-valuetext={`${formatDb(value)} dB`}
        aria-disabled={disabled}
        tabIndex={disabled ? -1 : 0}
        className={cn(
          "relative flex min-h-44 w-full flex-1 cursor-ns-resize touch-none items-stretch justify-center outline-none focus-visible:ring-2 focus-visible:ring-ring/70",
          disabled && "cursor-not-allowed opacity-50",
        )}
        onPointerDown={(event) => {
          if (disabled) return;
          dragging.current = true;
          event.currentTarget.setPointerCapture(event.pointerId);
          onChange(valueFromY(event.clientY));
        }}
        onPointerMove={(event) => {
          if (!dragging.current) return;
          onChange(valueFromY(event.clientY));
        }}
        onPointerUp={() => {
          dragging.current = false;
        }}
        onDoubleClick={() => !disabled && onChange(0)}
        onKeyDown={(event) => {
          if (disabled) return;
          if (event.key === "ArrowUp") {
            event.preventDefault();
            onChange(Math.min(GAIN_MAX, value + 0.5));
          }
          if (event.key === "ArrowDown") {
            event.preventDefault();
            onChange(Math.max(GAIN_MIN, value - 0.5));
          }
          if (event.key === "Home") onChange(0);
        }}
      >
        <div className="relative h-full w-1 rounded-full bg-elevated">
          <div
            className="absolute left-1/2 h-0.5 w-3 -translate-x-1/2 bg-border-strong"
            style={{ top: "50%" }}
          />
        </div>
        <div
          className="absolute left-1/2 h-4 w-7 -translate-x-1/2 -translate-y-1/2 rounded-sm bg-primary shadow-[var(--shadow-border)]"
          style={{ top: `${t * 100}%` }}
        />
      </div>
      <span className="mt-3 font-mono text-xs tabular-nums text-subtle">
        {label}
      </span>
    </div>
  );
}
