import { RotateCcw } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { EqGraphic } from "@/components/eq/eq-graphic";
import { EqFaders } from "@/components/eq/eq-faders";
import { Knob } from "@/components/eq/knob";
import { LockOverlay } from "@/components/eq/lock-overlay";
import { OutputModeSwitch } from "@/components/eq/output-mode";
import { Player } from "@/components/eq/player";
import { PresetsRow } from "@/components/eq/presets-row";
import { Button } from "@/components/ui/button";
import type { OutputMode } from "@/lib/eq/bands";
import { getDemoUrl } from "@/lib/eq/demo-track";
import {
  isMobileUserAgent,
  listOutputDevices,
  pickDeviceForMode,
  preferredModeFromDevices,
} from "@/lib/eq/devices";
import { getEngine } from "@/lib/eq/engine";
import { PRESETS } from "@/lib/eq/presets";
import { eqIsLocked, useEqStore } from "@/lib/eq/store";
import { cn } from "@/lib/utils";

export function Studio() {
  const store = useEqStore();
  const locked = eqIsLocked(store.outputMode);
  const fileUrl = useRef<string | null>(null);
  const [dragging, setDragging] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const boot = async () => {
      await useEqStore.persist.rehydrate();
      if (cancelled) return;
      useEqStore.getState().markHydrated();

      const mobile = isMobileUserAgent();
      const devices = await listOutputDevices();
      if (cancelled) return;
      const preferred = preferredModeFromDevices(devices, mobile);
      const current = useEqStore.getState();
      if (
        (preferred === "wired" || preferred === "bluetooth") &&
        current.outputMode === "speaker"
      ) {
        const match = pickDeviceForMode(devices, preferred);
        current.setOutputMode(preferred, match?.label ?? null);
      } else if (
        mobile &&
        current.outputMode === "wired" &&
        preferred === "speaker"
      ) {
        current.setOutputMode("speaker", "Phone speaker");
      }
    };
    void boot();

    const onDeviceChange = () => {
      void (async () => {
        const devices = await listOutputDevices();
        const preferred = preferredModeFromDevices(devices, isMobileUserAgent());
        if (preferred === "wired" || preferred === "bluetooth") {
          const match = pickDeviceForMode(devices, preferred);
          useEqStore.getState().setOutputMode(preferred, match?.label ?? null);
        }
      })();
    };
    navigator.mediaDevices?.addEventListener?.("devicechange", onDeviceChange);
    return () => {
      cancelled = true;
      navigator.mediaDevices?.removeEventListener?.(
        "devicechange",
        onDeviceChange,
      );
    };
  }, []);

  useEffect(() => {
    const engine = getEngine();
    if (!engine) return;
    engine.setEnabled(!locked);
    engine.setGains(store.gains);
    engine.setBass(store.bass);
    engine.setTreble(store.treble);
    engine.setPreamp(store.preamp);
    engine.setVolume(store.volume);
  }, [
    locked,
    store.gains,
    store.bass,
    store.treble,
    store.preamp,
    store.volume,
  ]);

  useEffect(() => {
    let cancelled = false;
    const applySink = async () => {
      const engine = getEngine();
      if (!engine) return;
      const devices = await listOutputDevices();
      if (cancelled) return;
      const match = pickDeviceForMode(devices, store.outputMode);
      await engine.setSink(match?.deviceId ?? "");
    };
    void applySink();
    return () => {
      cancelled = true;
    };
  }, [store.outputMode]);

  useEffect(() => {
    const engine = getEngine();
    if (!engine) return;
    const audio = engine.audio;
    const onTime = () =>
      useEqStore.getState().setPlayback({
        currentTime: audio.currentTime,
        duration: Number.isFinite(audio.duration) ? audio.duration : 0,
        isPlaying: !audio.paused,
      });
    const onEnded = () =>
      useEqStore.getState().setPlayback({ isPlaying: false });
    audio.addEventListener("timeupdate", onTime);
    audio.addEventListener("ended", onEnded);
    audio.addEventListener("play", onTime);
    audio.addEventListener("pause", onTime);
    return () => {
      audio.removeEventListener("timeupdate", onTime);
      audio.removeEventListener("ended", onEnded);
      audio.removeEventListener("play", onTime);
      audio.removeEventListener("pause", onTime);
    };
  }, []);

  const loadSrc = useCallback(async (url: string, kind: "demo" | "file", name: string) => {
    const engine = getEngine();
    if (!engine) return;
    await engine.resume();
    engine.audio.src = url;
    engine.audio.loop = true;
    await engine.audio.play();
    useEqStore.getState().setPlayback({
      isPlaying: true,
      sourceKind: kind,
      fileName: name,
      currentTime: 0,
      duration: Number.isFinite(engine.audio.duration) ? engine.audio.duration : 0,
    });
  }, []);

  const playDemo = useCallback(async () => {
    const url = getDemoUrl();
    await loadSrc(url, "demo", "Demo mix");
  }, [loadSrc]);

  const loadFile = useCallback(
    async (file: File) => {
      if (fileUrl.current) URL.revokeObjectURL(fileUrl.current);
      const url = URL.createObjectURL(file);
      fileUrl.current = url;
      await loadSrc(url, "file", file.name);
    },
    [loadSrc],
  );

  const playPause = useCallback(async () => {
    const engine = getEngine();
    if (!engine) return;
    if (store.sourceKind === "none") {
      await playDemo();
      return;
    }
    await engine.resume();
    if (engine.audio.paused) {
      await engine.audio.play();
    } else {
      engine.audio.pause();
    }
  }, [playDemo, store.sourceKind]);

  const seek = useCallback((time: number) => {
    const engine = getEngine();
    if (!engine) return;
    engine.audio.currentTime = time;
    useEqStore.getState().setPlayback({ currentTime: time });
  }, []);

  const setMode = useCallback((mode: OutputMode) => {
    store.setOutputMode(mode, null);
  }, [store]);

  const onPreset = useCallback((id: string) => {
    const preset = PRESETS.find((item) => item.id === id);
    if (preset) store.applyPreset(preset);
  }, [store]);

  return (
    <div
      className="mx-auto flex min-h-dvh w-full max-w-6xl flex-col gap-6 overflow-x-hidden px-4 py-6 sm:px-6 sm:py-8"
      onDragOver={(event) => {
        event.preventDefault();
        setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={(event) => {
        event.preventDefault();
        setDragging(false);
        const file = event.dataTransfer.files[0];
        if (file && file.type.startsWith("audio")) void loadFile(file);
      }}
    >
      <header className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-widest text-subtle">
            Graphic equalizer
          </p>
          <h1 className="mt-1 text-4xl font-medium tracking-tight text-fg sm:text-5xl">
            SIGNAL
          </h1>
          <p className="mt-2 max-w-md text-sm text-muted">
            Ten bands, dedicated bass and treble. Live only on wired headphones
            or Bluetooth — never the phone speaker.
          </p>
        </div>
        <div className="flex w-full flex-col items-stretch gap-2 sm:w-80">
          <OutputModeSwitch value={store.outputMode} onChange={setMode} />
          <p className="text-right font-mono text-xs uppercase tracking-widest text-subtle">
            {locked ? "Bypassed" : store.outputLabel ?? "EQ live"}
          </p>
        </div>
      </header>

      <div className="flex min-w-0 flex-col gap-5 lg:flex-row">
        <aside className="flex w-full shrink-0 flex-col gap-5 rounded-2xl bg-surface p-5 shadow-[var(--shadow-border)] lg:w-72 lg:p-6">
          <div className="flex justify-around gap-2">
            <Knob
              label="Bass"
              value={store.bass}
              onChange={store.setBass}
              disabled={locked}
            />
            <Knob
              label="Treble"
              value={store.treble}
              onChange={store.setTreble}
              disabled={locked}
            />
          </div>
          <div className="h-px bg-border" />
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium uppercase tracking-widest text-muted">
              Curve
            </p>
            <Button type="button" variant="ghost" size="sm" onClick={store.reset}>
              <RotateCcw className="size-3.5" />
              Flat
            </Button>
          </div>
          <PresetsRow
            activeId={store.presetId === "custom" ? "" : store.presetId}
            onSelect={onPreset}
            disabled={locked}
          />
        </aside>

        <section
          className={cn(
            "relative h-80 min-w-0 flex-1 overflow-hidden rounded-2xl bg-surface shadow-[var(--shadow-border)] md:h-96",
            dragging && "ring-2 ring-accent/40",
          )}
        >
          <EqGraphic
            gains={store.gains}
            bass={store.bass}
            treble={store.treble}
            locked={locked}
            playing={store.isPlaying}
          />
          <EqFaders
            gains={store.gains}
            onChange={store.setGain}
            disabled={locked}
          />
          <LockOverlay
            visible={locked}
            onChooseWired={() => setMode("wired")}
            onChooseBluetooth={() => setMode("bluetooth")}
          />
        </section>
      </div>

      <Player
        isPlaying={store.isPlaying}
        sourceKind={store.sourceKind}
        fileName={store.fileName}
        currentTime={store.currentTime}
        duration={store.duration}
        volume={store.volume}
        preamp={store.preamp}
        onPlayPause={() => void playPause()}
        onDemo={() => void playDemo()}
        onFile={(file) => void loadFile(file)}
        onSeek={seek}
        onVolume={store.setVolume}
        onPreamp={store.setPreamp}
      />
    </div>
  );
}
