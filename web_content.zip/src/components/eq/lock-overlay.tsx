import { Headphones } from "lucide-react";

type LockOverlayProps = {
  visible: boolean;
  onChooseWired: () => void;
  onChooseBluetooth: () => void;
};

export function LockOverlay({
  visible,
  onChooseWired,
  onChooseBluetooth,
}: LockOverlayProps) {
  if (!visible) return null;

  return (
    <div className="absolute inset-3 z-20 flex items-center justify-center rounded-xl bg-bg/80 p-6 text-center">
      <div className="max-w-sm">
        <div className="mx-auto flex size-12 items-center justify-center rounded-full bg-elevated shadow-[var(--shadow-border)]">
          <Headphones className="size-5 text-accent" strokeWidth={1.75} />
        </div>
        <h2 className="mt-4 text-lg font-medium tracking-tight text-fg">
          Speakers are locked
        </h2>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          SIGNAL only equalizes wired headphones or Bluetooth devices. Phone and
          laptop speakers stay flat.
        </p>
        <div className="mt-5 flex flex-col gap-2 sm:flex-row sm:justify-center">
          <button
            type="button"
            onClick={onChooseWired}
            className="h-11 rounded-md bg-primary px-4 text-sm font-medium text-primary-fg transition-transform duration-150 ease-out hover:opacity-90 active:scale-[0.96]"
          >
            Using wired headphones
          </button>
          <button
            type="button"
            onClick={onChooseBluetooth}
            className="h-11 rounded-md bg-elevated px-4 text-sm font-medium text-fg shadow-[var(--shadow-border)] transition-transform duration-150 ease-out hover:shadow-[var(--shadow-border-hover)] active:scale-[0.96]"
          >
            Using Bluetooth
          </button>
        </div>
      </div>
    </div>
  );
}
