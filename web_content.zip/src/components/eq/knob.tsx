import { useCallback, useId, useRef } from "react";
import { GAIN_MAX, GAIN_MIN, formatDb } from "@/lib/eq/bands";
import { cn } from "@/lib/utils";

type KnobProps = {
  label: string;
  value: number;
  onChange: (value: number) => void;
  disabled?: boolean;
};

const START = -225;
const SWEEP = 270;

export function Knob({ label, value, onChange, disabled }: KnobProps) {
  const id = useId();
  const drag = useRef<{ y: number; value: number } | null>(null);
  const angle = START + ((value - GAIN_MIN) / (GAIN_MAX - GAIN_MIN)) * SWEEP;

  const pointerDown = useCallback(
    (event: React.PointerEvent<HTMLDivElement>) => {
      if (disabled) return;
      event.currentTarget.setPointerCapture(event.pointerId);
      drag.current = { y: event.clientY, value };
    },
    [disabled, value],
  );

  const pointerMove = useCallback(
    (event: React.PointerEvent<HTMLDivElement>) => {
      if (!drag.current) return;
      const delta = drag.current.y - event.clientY;
      const next = drag.current.value + delta * 0.08;
      onChange(Math.min(GAIN_MAX, Math.max(GAIN_MIN, next)));
    },
    [onChange],
  );

  const pointerUp = useCallback(() => {
    drag.current = null;
  }, []);

  return (
    <div className={cn("flex flex-col items-center gap-3", disabled && "opacity-40")}>
      <div
        role="slider"
        id={id}
        aria-label={label}
        aria-valuemin={GAIN_MIN}
        aria-valuemax={GAIN_MAX}
        aria-valuenow={Number(value.toFixed(1))}
        aria-valuetext={`${formatDb(value)} dB`}
        aria-disabled={disabled}
        tabIndex={disabled ? -1 : 0}
        className="relative size-28 touch-none rounded-full outline-none focus-visible:ring-2 focus-visible:ring-ring/70 focus-visible:ring-offset-2 focus-visible:ring-offset-bg"
        onPointerDown={pointerDown}
        onPointerMove={pointerMove}
        onPointerUp={pointerUp}
        onPointerCancel={pointerUp}
        onDoubleClick={() => !disabled && onChange(0)}
        onKeyDown={(event) => {
          if (disabled) return;
          if (event.key === "ArrowUp" || event.key === "ArrowRight") {
            event.preventDefault();
            onChange(Math.min(GAIN_MAX, value + 0.5));
          }
          if (event.key === "ArrowDown" || event.key === "ArrowLeft") {
            event.preventDefault();
            onChange(Math.max(GAIN_MIN, value - 0.5));
          }
          if (event.key === "Home") onChange(0);
        }}
      >
        <svg viewBox="0 0 120 120" className="size-full">
          <circle cx="60" cy="60" r="52" fill="var(--color-elevated)" />
          <circle
            cx="60"
            cy="60"
            r="52"
            fill="none"
            stroke="color-mix(in oklab, var(--color-fg) 10%, transparent)"
            strokeWidth="1"
          />
          {Array.from({ length: 19 }, (_, i) => {
            const a = ((START + (i / 18) * SWEEP) * Math.PI) / 180;
            const inner = i % 3 === 0 ? 40 : 44;
            return (
              <line
                key={i}
                x1={60 + Math.cos(a) * inner}
                y1={60 + Math.sin(a) * inner}
                x2={60 + Math.cos(a) * 48}
                y2={60 + Math.sin(a) * 48}
                stroke="color-mix(in oklab, var(--color-fg) 28%, transparent)"
                strokeWidth={i % 3 === 0 ? 1.4 : 1}
              />
            );
          })}
          <circle cx="60" cy="60" r="34" fill="var(--color-surface)" />
          <circle
            cx="60"
            cy="60"
            r="34"
            fill="none"
            stroke="color-mix(in oklab, var(--color-fg) 12%, transparent)"
          />
          <line
            x1="60"
            y1="60"
            x2={60 + Math.cos((angle * Math.PI) / 180) * 26}
            y2={60 + Math.sin((angle * Math.PI) / 180) * 26}
            stroke="var(--color-accent)"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
          <circle cx="60" cy="60" r="4" fill="var(--color-accent)" />
        </svg>
      </div>
      <div className="text-center">
        <p className="text-xs font-medium uppercase tracking-widest text-muted">{label}</p>
        <p className="mt-1 font-mono text-sm tabular-nums text-fg">{formatDb(value)} dB</p>
      </div>
    </div>
  );
}
