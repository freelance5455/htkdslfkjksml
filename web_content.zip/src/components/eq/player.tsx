import { Pause, Play, Upload, Volume2 } from "lucide-react";
import { useRef } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { formatDb } from "@/lib/eq/bands";
import { cn } from "@/lib/utils";

type PlayerProps = {
  isPlaying: boolean;
  sourceKind: "none" | "demo" | "file";
  fileName: string | null;
  currentTime: number;
  duration: number;
  volume: number;
  preamp: number;
  onPlayPause: () => void;
  onDemo: () => void;
  onFile: (file: File) => void;
  onSeek: (time: number) => void;
  onVolume: (value: number) => void;
  onPreamp: (value: number) => void;
};

export function Player({
  isPlaying,
  sourceKind,
  fileName,
  currentTime,
  duration,
  volume,
  preamp,
  onPlayPause,
  onDemo,
  onFile,
  onSeek,
  onVolume,
  onPreamp,
}: PlayerProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const title =
    sourceKind === "file"
      ? fileName ?? "Loaded track"
      : sourceKind === "demo"
        ? "Demo mix"
        : "No track loaded";

  return (
    <section className="rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)] sm:p-5">
      <div className="flex items-center gap-3">
        <Button
          type="button"
          size="icon"
          onClick={onPlayPause}
          aria-label={isPlaying ? "Pause" : "Play"}
          className="shrink-0"
        >
          {isPlaying ? (
            <Pause className="size-4" />
          ) : (
            <Play className="size-4 translate-x-px" />
          )}
        </Button>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium text-fg">{title}</p>
          <p className="font-mono text-xs tabular-nums text-subtle">
            {formatTime(currentTime)} / {formatTime(duration)}
          </p>
        </div>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          aria-label="Load audio file"
          onClick={() => inputRef.current?.click()}
        >
          <Upload className="size-4" />
        </Button>
        <input
          ref={inputRef}
          type="file"
          accept="audio/*,.mp3,.wav,.flac,.ogg,.m4a,.aac"
          className="sr-only"
          onChange={(event) => {
            const file = event.target.files?.[0];
            if (file) onFile(file);
            event.currentTarget.value = "";
          }}
        />
      </div>

      <div className="mt-3">
        <Button type="button" variant="secondary" size="sm" onClick={onDemo}>
          Play demo mix
        </Button>
      </div>

      <div className="mt-4">
        <Slider
          min={0}
          max={Math.max(duration, 0.01)}
          step={0.01}
          value={[Math.min(currentTime, duration)]}
          onValueChange={([time]) => onSeek(time ?? 0)}
          aria-label="Seek"
        />
      </div>

      <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <label className="flex items-center gap-3">
          <Volume2 className="size-4 shrink-0 text-muted" />
          <Slider
            min={0}
            max={1}
            step={0.01}
            value={[volume]}
            onValueChange={([v]) => onVolume(v ?? 0)}
            aria-label="Volume"
          />
        </label>
        <label className="flex items-center gap-3">
          <span className="w-14 shrink-0 text-xs font-medium uppercase tracking-widest text-muted">
            Preamp
          </span>
          <Slider
            min={-12}
            max={12}
            step={0.1}
            value={[preamp]}
            onValueChange={([v]) => onPreamp(v ?? 0)}
            aria-label="Preamp"
          />
          <span className="w-12 text-right font-mono text-xs tabular-nums text-subtle">
            {formatDb(preamp)}
          </span>
        </label>
      </div>

      <p
        className={cn(
          "mt-3 text-xs text-subtle",
          sourceKind === "none" && "text-muted",
        )}
      >
        Drop an audio file anywhere on this panel, or start the demo mix to hear
        the curve.
      </p>
    </section>
  );
}

function formatTime(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}
