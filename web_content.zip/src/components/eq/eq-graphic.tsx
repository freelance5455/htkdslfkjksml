import { useEffect, useMemo, useRef, useState } from "react";
import { BANDS, GAIN_MAX, GAIN_MIN } from "@/lib/eq/bands";
import { getEngine } from "@/lib/eq/engine";
import { computeResponseDb, logspace } from "@/lib/eq/response";

const FREQS = logspace(160);
const PAD_X = 28;
const PAD_TOP = 16;
const PAD_BOTTOM = 36;

type EqGraphicProps = {
  gains: number[];
  bass: number;
  treble: number;
  locked: boolean;
  playing: boolean;
};

export function EqGraphic({ gains, bass, treble, locked, playing }: EqGraphicProps) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const specRef = useRef<SVGPathElement>(null);
  const [size, setSize] = useState({ w: 0, h: 0 });

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const apply = () => {
      const rect = el.getBoundingClientRect();
      setSize({ w: Math.round(rect.width), h: Math.round(rect.height) });
    };
    apply();
    const observer = new ResizeObserver(apply);
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  const layout = useMemo(() => layoutFor(size.w, size.h), [size.w, size.h]);
  const curve = useMemo(() => {
    if (!layout) return null;
    const db = computeResponseDb(gains, bass, treble, FREQS);
    return buildCurve(layout, db);
  }, [layout, gains, bass, treble]);

  useEffect(() => {
    if (!layout) return;
    let frame = 0;
    let running = true;
    const smooth = new Float32Array(FREQS.length);

    const draw = () => {
      if (!running) return;
      const path = specRef.current;
      if (path && playing) {
        const engine = getEngine();
        if (engine) {
          const bins = engine.getSpectrum();
          const nyquist = engine.nyquist();
          for (let i = 0; i < FREQS.length; i++) {
            const f = FREQS[i] ?? 20;
            const bin = Math.min(bins.length - 1, (f / nyquist) * bins.length);
            const i0 = Math.floor(bin);
            const i1 = Math.min(bins.length - 1, i0 + 1);
            const frac = bin - i0;
            const v = ((bins[i0] ?? 0) * (1 - frac) + (bins[i1] ?? 0) * frac) / 255;
            smooth[i] = (smooth[i] ?? 0) * 0.72 + v * 0.28;
          }
          path.setAttribute("d", spectrumPath(layout, smooth));
        }
      } else if (path) {
        path.setAttribute("d", "");
      }
      frame = requestAnimationFrame(draw);
    };
    frame = requestAnimationFrame(draw);
    return () => {
      running = false;
      cancelAnimationFrame(frame);
    };
  }, [layout, playing]);

  return (
    <div ref={wrapRef} className="pointer-events-none absolute inset-0">
      {layout && curve ? (
        <svg width={layout.width} height={layout.height} className="size-full text-fg">
          {[-12, -6, 0, 6, 12].map((db) => {
            const y = layout.yForDb(db);
            return (
              <line
                key={db}
                x1={layout.plotLeft}
                x2={layout.plotRight}
                y1={y}
                y2={y}
                stroke="currentColor"
                strokeOpacity={db === 0 ? 0.18 : 0.06}
                strokeDasharray={db === 0 ? undefined : "3 5"}
              />
            );
          })}
          <path
            ref={specRef}
            fill="var(--color-accent)"
            fillOpacity="0.16"
            stroke="none"
          />
          <path
            d={curve.fill}
            fill="var(--color-accent)"
            fillOpacity={locked ? 0.06 : 0.12}
            stroke="none"
          />
          <path
            d={curve.line}
            fill="none"
            stroke="var(--color-primary)"
            strokeOpacity={locked ? 0.35 : 0.92}
            strokeWidth="1.75"
            strokeLinejoin="round"
            strokeLinecap="round"
          />
          {curve.dots.map((dot, i) => (
            <circle
              key={BANDS[i]?.freq}
              cx={dot.x}
              cy={dot.y}
              r="3.2"
              fill="var(--color-primary)"
              fillOpacity={locked ? 0.4 : 1}
            />
          ))}
          {[-12, 0, 12].map((db) => (
            <text
              key={`lbl-${db}`}
              x={8}
              y={layout.yForDb(db) + 3}
              fill="var(--color-subtle)"
              fontSize="10"
              fontFamily="var(--font-mono)"
            >
              {db > 0 ? `+${db}` : `${db}`}
            </text>
          ))}
        </svg>
      ) : null}
    </div>
  );
}

type Layout = {
  width: number;
  height: number;
  plotLeft: number;
  plotRight: number;
  x0: number;
  x1: number;
  yForDb: (db: number) => number;
  xForFreq: (freq: number) => number;
};

function layoutFor(width: number, height: number): Layout | null {
  if (width < 8 || height < 8) return null;
  const plotLeft = PAD_X;
  const plotRight = width - PAD_X;
  const colW = (plotRight - plotLeft) / BANDS.length;
  const x0 = plotLeft + colW / 2;
  const x1 = plotRight - colW / 2;
  const minL = Math.log10(BANDS[0].freq);
  const maxL = Math.log10(BANDS[BANDS.length - 1].freq);
  const yForDb = (db: number) => {
    const t = (GAIN_MAX - db) / (GAIN_MAX - GAIN_MIN);
    return PAD_TOP + t * (height - PAD_TOP - PAD_BOTTOM);
  };
  const xForFreq = (freq: number) => {
    const clamped = Math.min(
      BANDS[BANDS.length - 1].freq,
      Math.max(BANDS[0].freq, freq),
    );
    const t = (Math.log10(clamped) - minL) / (maxL - minL);
    return x0 + t * (x1 - x0);
  };
  return { width, height, plotLeft, plotRight, x0, x1, yForDb, xForFreq };
}

function buildCurve(layout: Layout, db: Float32Array) {
  const pts = Array.from(FREQS, (freq, i) => ({
    x: layout.xForFreq(freq),
    y: layout.yForDb(db[i] ?? 0),
  }));
  const line = polyline(pts);
  const zeroY = layout.yForDb(0);
  const fill = `${line} L ${pts[pts.length - 1]?.x ?? 0} ${zeroY} L ${pts[0]?.x ?? 0} ${zeroY} Z`;
  const dots = BANDS.map((band) => {
    let best = 0;
    let bestDist = Infinity;
    for (let i = 0; i < FREQS.length; i++) {
      const dist = Math.abs((FREQS[i] ?? 0) - band.freq);
      if (dist < bestDist) {
        bestDist = dist;
        best = i;
      }
    }
    return {
      x: layout.xForFreq(band.freq),
      y: layout.yForDb(db[best] ?? 0),
    };
  });
  return { line, fill, dots };
}

function spectrumPath(layout: Layout, mag: Float32Array): string {
  const bottom = layout.height - 4;
  const top = PAD_TOP;
  const pts = Array.from(FREQS, (freq, i) => ({
    x: layout.xForFreq(freq),
    y: bottom - (mag[i] ?? 0) * (bottom - top) * 0.9,
  }));
  const line = polyline(pts);
  return `${line} L ${pts[pts.length - 1]?.x ?? 0} ${bottom} L ${pts[0]?.x ?? 0} ${bottom} Z`;
}

function polyline(points: { x: number; y: number }[]): string {
  if (points.length === 0) return "";
  const first = points[0];
  if (!first) return "";
  let d = `M ${first.x.toFixed(2)} ${first.y.toFixed(2)}`;
  for (let i = 1; i < points.length; i++) {
    const p = points[i];
    if (!p) continue;
    d += ` L ${p.x.toFixed(2)} ${p.y.toFixed(2)}`;
  }
  return d;
}
