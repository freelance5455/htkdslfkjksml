import { Bluetooth, Headphones, Speaker } from "lucide-react";
import { OUTPUT_MODES, type OutputMode } from "@/lib/eq/bands";
import { cn } from "@/lib/utils";

const ICONS = {
  wired: Headphones,
  bluetooth: Bluetooth,
  speaker: Speaker,
} as const;

type OutputModeSwitchProps = {
  value: OutputMode;
  onChange: (mode: OutputMode) => void;
};

export function OutputModeSwitch({ value, onChange }: OutputModeSwitchProps) {
  return (
    <div
      className="grid grid-cols-3 rounded-full bg-elevated p-1 shadow-[var(--shadow-border)]"
      role="tablist"
      aria-label="Output device"
    >
      {OUTPUT_MODES.map((mode) => {
        const Icon = ICONS[mode.id];
        const active = mode.id === value;
        return (
          <button
            key={mode.id}
            type="button"
            role="tab"
            aria-selected={active}
            title={mode.hint}
            onClick={() => onChange(mode.id)}
            className={cn(
              "flex h-10 items-center justify-center gap-2 rounded-full px-2 text-xs font-medium transition-[background-color,color] duration-150 ease-out",
              active ? "bg-surface text-fg shadow-[var(--shadow-border)]" : "text-muted hover:text-fg",
            )}
          >
            <Icon className="size-3.5" strokeWidth={1.75} />
            <span className="hidden sm:inline">{mode.label}</span>
          </button>
        );
      })}
    </div>
  );
}
