import { PRESETS } from "@/lib/eq/presets";
import { cn } from "@/lib/utils";

type PresetsRowProps = {
  activeId: string;
  onSelect: (id: string) => void;
  disabled?: boolean;
};

export function PresetsRow({ activeId, onSelect, disabled }: PresetsRowProps) {
  return (
    <div className="flex flex-wrap gap-2">
      {PRESETS.map((preset) => {
        const active = preset.id === activeId;
        return (
          <button
            key={preset.id}
            type="button"
            disabled={disabled}
            onClick={() => onSelect(preset.id)}
            className={cn(
              "h-10 shrink-0 rounded-full px-4 text-sm font-medium transition-[background-color,color,box-shadow,opacity] duration-150 ease-out",
              active
                ? "bg-primary text-primary-fg"
                : "bg-elevated text-muted shadow-[var(--shadow-border)] hover:text-fg",
              disabled && "opacity-40",
            )}
          >
            {preset.name}
          </button>
        );
      })}
    </div>
  );
}
