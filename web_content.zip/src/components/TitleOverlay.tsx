import { Volume2, VolumeX } from 'lucide-react';

interface TitleOverlayProps {
  bestScore: number;
  isMuted: boolean;
  onStart: () => void;
  onToggleMute: () => void;
}

export function TitleOverlay({
  bestScore,
  isMuted,
  onStart,
  onToggleMute,
}: TitleOverlayProps) {
  return (
    <div className="absolute inset-0 z-10 flex flex-col justify-between p-4 sm:p-6 pointer-events-none">
      {/* Top bar: Best Score + Mute toggle */}
      <div className="flex items-start justify-between gap-4">
        <div className="bg-[#122419]/92 border-2 border-[#3c6047] px-3 py-1.5 text-xs sm:text-sm tracking-wide">
          <span className="text-[#9ec2a5]">BEST </span>
          <span className="font-pixel-display text-[#facc15] tabular-nums">
            {bestScore.toLocaleString()}
          </span>
        </div>

        <button
          type="button"
          onClick={onToggleMute}
          aria-label={isMuted ? 'Unmute sound' : 'Mute sound'}
          className="pointer-events-auto pixel-btn flex h-11 w-11 items-center justify-center bg-[#172b1e] text-[#f4f7ec] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#facc15]"
        >
          {isMuted ? <VolumeX className="h-5 w-5 text-[#9ec2a5]" /> : <Volume2 className="h-5 w-5 text-[#facc15]" />}
        </button>
      </div>

      {/* Center-top hero title lockup over live railway backdrop */}
      <div className="my-auto flex flex-col items-center text-center">
        <div className="pixel-panel pointer-events-auto max-w-md w-full px-5 py-6 sm:px-8 sm:py-7">
          {/* Bespoke inline pixel-art emblem + title lockup */}
          <div className="mx-auto mb-3 flex items-center justify-center gap-3">
            {/* Pixel Vietnamese Nón Lá icon */}
            <svg
              width="48"
              height="36"
              viewBox="0 0 16 12"
              className="pixelated shrink-0"
              aria-hidden="true"
            >
              <rect x="7" y="0" width="2" height="1" fill="#4a0c0a" />
              <rect x="5" y="1" width="6" height="2" fill="#4a0c0a" />
              <rect x="3" y="3" width="10" height="2" fill="#4a0c0a" />
              <rect x="1" y="5" width="14" height="2" fill="#4a0c0a" />
              <rect x="0" y="7" width="16" height="2" fill="#4a0c0a" />
              <rect x="6" y="1" width="4" height="2" fill="#da251d" />
              <rect x="4" y="3" width="8" height="2" fill="#da251d" />
              <rect x="2" y="5" width="12" height="2" fill="#da251d" />
              <rect x="1" y="7" width="14" height="1" fill="#da251d" />
              <rect x="1" y="8" width="14" height="1" fill="#9e1712" />
              {/* Yellow 5-point pixel star */}
              <rect x="7" y="3" width="2" height="1" fill="#facc15" />
              <rect x="5" y="4" width="6" height="1" fill="#facc15" />
              <rect x="6" y="5" width="4" height="1" fill="#facc15" />
              <rect x="5" y="6" width="2" height="1" fill="#facc15" />
              <rect x="9" y="6" width="2" height="1" fill="#facc15" />
              <rect x="7" y="4" width="2" height="1" fill="#fef08a" />
            </svg>

            {/* Pixel Three-Leaf Clover icon */}
            <svg
              width="32"
              height="32"
              viewBox="0 0 12 12"
              className="pixelated shrink-0"
              aria-hidden="true"
            >
              <rect x="4" y="1" width="4" height="4" fill="#14532d" />
              <rect x="1" y="4" width="4" height="4" fill="#14532d" />
              <rect x="7" y="4" width="4" height="4" fill="#14532d" />
              <rect x="5" y="8" width="2" height="3" fill="#14532d" />
              <rect x="5" y="2" width="2" height="2" fill="#22c55e" />
              <rect x="2" y="5" width="2" height="2" fill="#22c55e" />
              <rect x="8" y="5" width="2" height="2" fill="#22c55e" />
              <rect x="5" y="8" width="1" height="2" fill="#4ade80" />
              <rect x="5" y="2" width="1" height="1" fill="#86efac" />
              <rect x="2" y="5" width="1" height="1" fill="#86efac" />
              <rect x="8" y="5" width="1" height="1" fill="#86efac" />
            </svg>
          </div>

          <h1 className="font-pixel-ui text-3xl sm:text-4xl font-bold tracking-tight text-[#f4f7ec] drop-shadow-[0_3px_0_#09130c]">
            BEN TÔ NA MƯ
          </h1>

          <p className="mt-2.5 text-sm sm:text-base text-[#c6dec9]">
            Stand 3s on MARAU <span aria-hidden="true">·</span> Dodge trains &amp; rainbow NPCs
          </p>

          <div className="mt-5 flex justify-center">
            <button
              type="button"
              onClick={onStart}
              className="pixel-btn min-h-[48px] w-full sm:w-auto bg-[#da251d] px-8 py-3 font-pixel-display text-base sm:text-lg font-bold text-[#fef08a] whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#facc15]"
            >
              Start Game
            </button>
          </div>
        </div>
      </div>

      {/* Single flat control hint line */}
      <div className="flex justify-center">
        <p className="bg-[#0e1c13]/88 border border-[#3c6047] px-3 py-1.5 text-center text-xs sm:text-sm text-[#c6dec9]">
          Buttons, Swipe or WASD Move <span aria-hidden="true">·</span> Hold 3s on MARAU <span aria-hidden="true">·</span> Esc Pause
        </p>
      </div>
    </div>
  );
}
