import React from 'react';
import { Play, Globe, Users, Sparkles, UserCheck, Flag } from 'lucide-react';
import {
  AUTOMATED_LEVELS,
  HYPERCARS,
  NetworkMode,
  VehicleCustomization,
} from '../types/game';

interface TitleOverlayProps {
  customization: VehicleCustomization;
  levelIndex: number;
  customLaps: number;
  driverName: string;
  driverAge: number;
  networkMode: NetworkMode;
  roomCode: string;
  participantCount: number;
  onStartRace: () => void;
  onSelectNetworkMode: (mode: NetworkMode) => void;
  onChangeCustomLaps: (laps: number) => void;
  onOpenCustomizeDock: () => void;
  onOpenProfileDock: () => void;
}

export const TitleOverlay: React.FC<TitleOverlayProps> = ({
  customization,
  levelIndex,
  customLaps,
  driverName,
  driverAge,
  networkMode,
  roomCode,
  participantCount,
  onStartRace,
  onSelectNetworkMode,
  onChangeCustomLaps,
  onOpenCustomizeDock,
  onOpenProfileDock,
}) => {
  const car = HYPERCARS.find((c) => c.id === customization.carId) || HYPERCARS[0];
  const level = AUTOMATED_LEVELS[levelIndex] || AUTOMATED_LEVELS[0];

  return (
    <div className="fixed inset-0 z-10 pointer-events-none flex flex-col justify-between pt-16 pb-28 px-6">
      {/* Upper Negative Space + Bespoke SVG Title Lockup */}
      <div className="max-w-2xl mx-auto text-center pointer-events-auto">
        {/* Bespoke Inline SVG Motorsport Emblem & Title Lockup */}
        <div className="inline-flex flex-col items-center">
          <svg
            width="440"
            height="72"
            viewBox="0 0 440 72"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="w-[300px] sm:w-[420px] h-auto drop-shadow-[0_6px_24px_rgba(0,0,0,0.85)]"
            role="img"
            aria-label="Apex Horizon GT Motorsport"
          >
            {/* Dynamic Aerodynamic Speed Wing Lines */}
            <path
              d="M62 20H168L154 26H74L62 20Z"
              fill="#F59E0B"
            />
            <path
              d="M378 20H272L286 26H366L378 20Z"
              fill="#F59E0B"
            />
            {/* Center Crest Shield */}
            <path
              d="M220 4L244 16L236 32H204L196 16L220 4Z"
              fill="#090D16"
              stroke="#F59E0B"
              strokeWidth="2"
            />
            <path
              d="M220 9L233 16L228 26H212L207 16L220 9Z"
              fill="#EF4444"
            />
            {/* Crisp SVG Typography Lockup */}
            <text
              x="220"
              y="54"
              textAnchor="middle"
              fill="#F8FAFC"
              fontFamily="Chakra Petch, sans-serif"
              fontWeight="700"
              fontSize="28"
              letterSpacing="4"
            >
              APEX HORIZON
            </text>
            <text
              x="220"
              y="69"
              textAnchor="middle"
              fill="#94A3B8"
              fontFamily="Plus Jakarta Sans, sans-serif"
              fontWeight="600"
              fontSize="8.5"
              letterSpacing="2.4"
            >
              OFFICIAL GT MOTORSPORT & HYPERCAR SERIES · 19 CARS
            </text>
          </svg>
        </div>

        {/* Unboxed Spec Summary Line (Zero-Pill Discipline) */}
        <div className="mt-2 flex flex-wrap items-center justify-center gap-2 text-xs text-slate-300 bg-[#090d16]/85 px-4 py-1.5 rounded-lg border border-white/10">
          <span className="font-semibold text-white">{car.name}</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono-tabular text-amber-400">{car.horsepower} HP</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono-tabular">{car.topSpeedKmh} KM/H</span>
          <span aria-hidden="true">·</span>
          <span className="text-cyan-300">{level.name}</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono-tabular text-emerald-300">
            {driverName} ({driverAge}y)
          </span>
          <span aria-hidden="true">·</span>
          <span className="font-mono-tabular">{participantCount} Grid Racers</span>
        </div>
      </div>

      {/* Center 3D Viewport stays 100% unobstructed so player admires the rotating 3D Hypercar */}
      <div />

      {/* Lower Launch CTA Cluster above the Collapsible Bottom Control Dock */}
      <div className="max-w-2xl mx-auto w-full flex flex-col items-center gap-2.5 pointer-events-auto">
        <div className="flex flex-wrap items-center justify-center gap-2">
          {/* Primary Start Race Button */}
          <button
            onClick={onStartRace}
            className="px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-[0.99] text-slate-950 font-display font-bold text-base tracking-wide flex items-center gap-2 shadow-xl transition-all cursor-pointer whitespace-nowrap"
          >
            <Play className="w-5 h-5 fill-current" />
            <span>START RACE (ENTER)</span>
          </button>

          {/* Direct Lap Count Selector on Title Screen */}
          <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-[#090d16]/92 border border-white/15">
            <Flag className="w-3.5 h-3.5 text-amber-400 ml-1" />
            <button
              onClick={() => onChangeCustomLaps(Math.max(1, customLaps - 1))}
              className="w-6 h-6 rounded-md bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center justify-center border border-white/10 cursor-pointer"
              title="Decrease Laps"
            >
              -
            </button>
            <span className="font-mono-tabular text-xs font-bold text-amber-300 px-1.5 whitespace-nowrap">
              {customLaps} {customLaps === 1 ? 'Lap' : 'Laps'} (~1m/Lap)
            </span>
            <button
              onClick={() => onChangeCustomLaps(Math.min(25, customLaps + 1))}
              className="w-6 h-6 rounded-md bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center justify-center border border-white/10 cursor-pointer"
              title="Increase Laps"
            >
              +
            </button>
          </div>

          {/* Mode Selector: Offline Career vs Live Multiplayer */}
          <div className="flex items-center p-1 rounded-xl bg-[#090d16]/92 border border-white/15">
            <button
              onClick={() => onSelectNetworkMode('offline')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
                networkMode === 'offline'
                  ? 'bg-slate-800 text-white border border-white/15'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Users className="w-3.5 h-3.5 text-amber-400" />
              <span>Offline Grid</span>
            </button>
            <button
              onClick={() => onSelectNetworkMode('multiplayer')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
                networkMode === 'multiplayer'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Globe className="w-3.5 h-3.5 text-cyan-400" />
              <span>Multiplayer ({roomCode})</span>
            </button>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-2">
          <button
            onClick={onOpenCustomizeDock}
            className="px-3.5 py-2 rounded-xl bg-[#090d16]/92 hover:bg-slate-800 text-slate-200 border border-white/15 text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Customize & Add Players</span>
          </button>

          <button
            onClick={onOpenProfileDock}
            className="px-3.5 py-2 rounded-xl bg-[#090d16]/92 hover:bg-slate-800 text-emerald-300 border border-emerald-400/30 text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer"
          >
            <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Edit Driver Name & Age ({driverName}, {driverAge})</span>
          </button>
        </div>

        {/* Single Flat Control-Hint Line */}
        <p className="text-xs text-slate-300 bg-[#090d16]/85 px-4 py-1 rounded-md border border-white/10 text-center whitespace-nowrap overflow-x-auto max-w-full">
          WASD / Arrows Drive <span aria-hidden="true">·</span> Shift Nitro Boost{' '}
          <span aria-hidden="true">·</span> Space Drift <span aria-hidden="true">·</span> C Camera{' '}
          <span aria-hidden="true">·</span> H Toggle Dock <span aria-hidden="true">·</span> Esc Pause
        </p>
      </div>
    </div>
  );
};
