import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { SecretGossipLogo } from './SecretGossipLogo';
import { Language, TRANSLATIONS } from '../utils/translations';
import { Check, ArrowRight } from 'lucide-react';

interface LanguageSelectionScreenProps {
  onComplete?: () => void;
}

export const LanguageSelectionScreen: React.FC<LanguageSelectionScreenProps> = ({ onComplete }) => {
  const { language, setLanguage, setHasSelectedLanguage } = useApp();
  const [selected, setSelected] = useState<Language>(language || 'hinglish');

  const langOptions: { id: Language; label: string; sub: string; desc: string; icon: string; badge?: string }[] = [
    {
      id: 'hinglish',
      label: 'Hinglish',
      sub: 'Campus Wali Bolchal',
      desc: 'Mix of Hindi & English. Perfect for hostel banter, crushes & college secrets!',
      icon: '🇮🇳',
      badge: 'Popular on Campus 🔥'
    },
    {
      id: 'en',
      label: 'English',
      sub: 'Standard English',
      desc: 'Universal academic English interface across all universities.',
      icon: '🌐'
    },
    {
      id: 'hi',
      label: 'हिन्दी',
      sub: 'शुद्ध हिन्दी',
      desc: 'कॉलेज और हॉस्टल के सीक्रेट्स अपनी मातृभाषा हिन्दी में पढ़ें।',
      icon: '🇮🇳'
    }
  ];

  const handleConfirm = () => {
    setLanguage(selected);
    setHasSelectedLanguage(true);
    if (onComplete) onComplete();
  };

  const t = TRANSLATIONS[selected];

  return (
    <div className="min-h-screen w-full bg-[#05060b] text-slate-100 flex flex-col justify-center items-center p-4 sm:p-6 relative overflow-hidden">
      
      {/* Background Ambience */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[550px] bg-gradient-to-tr from-cyan-600/15 via-purple-600/15 to-transparent rounded-full blur-[110px] pointer-events-none" />

      {/* Main Container */}
      <div className="w-full max-w-md bg-[#0a0d18]/92 backdrop-blur-2xl border border-cyan-500/35 rounded-3xl p-5 sm:p-7 shadow-[0_0_50px_rgba(6,182,212,0.18)] relative z-10 space-y-5 my-auto">
        
        {/* Brand Logo & Header */}
        <div className="text-center flex flex-col items-center space-y-2">
          <SecretGossipLogo size="lg" />
          <div className="pt-2">
            <h2 className="font-display font-black text-xl text-slate-100 tracking-tight">
              {t.selectLanguageTitle}
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-xs leading-relaxed">
              {t.selectLanguageSubtitle}
            </p>
          </div>
        </div>

        {/* Language Options Cards */}
        <div className="space-y-3">
          {langOptions.map((opt) => {
            const isSelected = selected === opt.id;
            return (
              <div
                key={opt.id}
                onClick={() => setSelected(opt.id)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer relative overflow-hidden ${
                  isSelected
                    ? 'bg-gradient-to-r from-cyan-950/50 via-indigo-950/40 to-slate-900 border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.25)] scale-[1.01]'
                    : 'bg-slate-900/60 border-slate-800/80 hover:border-slate-700 hover:bg-slate-900/90'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <span className="text-2xl mt-0.5">{opt.icon}</span>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-display font-bold text-sm text-slate-100">
                          {opt.label}
                        </h4>
                        <span className="text-[10px] text-slate-400 font-medium">
                          ({opt.sub})
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 leading-snug mt-1">
                        {opt.desc}
                      </p>
                    </div>
                  </div>

                  {/* Radio tick indicator */}
                  <div className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 mt-0.5 transition-all ${
                    isSelected ? 'border-cyan-400 bg-cyan-500 text-slate-950 shadow-sm' : 'border-slate-700 bg-slate-950'
                  }`}>
                    {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </div>
                </div>

                {opt.badge && (
                  <span className="inline-block mt-2 font-mono text-[9px] font-bold text-amber-300 bg-amber-950/80 border border-amber-500/40 rounded-full px-2 py-0.5">
                    {opt.badge}
                  </span>
                )}
              </div>
            );
          })}
        </div>

        {/* Continue Button */}
        <button
          onClick={handleConfirm}
          className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 via-indigo-600 to-purple-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-display font-extrabold text-xs tracking-wide transition-all shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2 active:scale-98"
        >
          <span>{t.continueBtn} {selected === 'hi' ? 'हिन्दी' : selected === 'hinglish' ? 'Hinglish' : 'English'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        <p className="text-[10px] text-slate-500 text-center">
          You can change your language anytime from your profile or header.
        </p>
      </div>
    </div>
  );
};
