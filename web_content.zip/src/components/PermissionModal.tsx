import React from 'react';
import { AlertTriangle, Lock, ShieldAlert, X } from 'lucide-react';
import { TaskItem } from '../types.ts';

interface PermissionModalProps {
  task: TaskItem;
  onApprove: (taskId: string) => void;
  onReject: (taskId: string, reason?: string) => void;
  onClose: () => void;
}

export const PermissionModal: React.FC<PermissionModalProps> = ({
  task,
  onApprove,
  onReject,
  onClose,
}) => {
  const step = task.pendingPermissionStep;
  if (!step) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-lg w-full p-6 shadow-xl space-y-4 font-mono text-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div className="flex items-center gap-2.5 text-amber-700">
            <ShieldAlert className="w-5 h-5" />
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider font-sans">
              Security Boundary Challenge
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="bg-amber-50 p-4 rounded-xl border border-amber-300 text-amber-900 space-y-2 font-sans">
          <div className="flex items-center gap-2 font-mono font-bold text-xs">
            <Lock className="w-3.5 h-3.5 text-amber-700" />
            <span>OPERATOR AUTHORIZATION REQUIRED</span>
          </div>
          <p className="text-xs text-slate-700 leading-relaxed">
            Task <strong className="text-slate-900 font-mono">{task.title}</strong> paused at Step #{step.stepNumber}{' '}
            (<strong>{step.title}</strong>).
          </p>
          <p className="text-xs text-slate-700 leading-relaxed">
            The autonomous kernel requests permission to invoke tool{' '}
            <strong className="text-sky-800 font-mono">"{step.toolName}"</strong> under the{' '}
            <span className="font-mono px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-300 font-bold">
              ELEVATED BOUNDARY
            </span>{' '}
            policy.
          </p>
        </div>

        {/* Payload Preview */}
        {step.toolInput && (
          <div>
            <label className="block text-[11px] text-slate-600 mb-1.5 font-bold">Execution Input Arguments:</label>
            <pre className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-800 max-h-40 overflow-auto scrollbar-thin">
              {JSON.stringify(step.toolInput, null, 2)}
            </pre>
          </div>
        )}

        <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-3">
          <button
            id="modal-reject-permission-btn"
            onClick={() => onReject(task.id, 'Declined by human operator via clearance dialog')}
            className="px-4 py-2.5 rounded-xl bg-white hover:bg-rose-50 hover:text-rose-700 text-slate-700 font-medium transition-all border border-slate-300 text-xs"
          >
            DENY CLEARANCE
          </button>
          <button
            id="modal-approve-permission-btn"
            onClick={() => onApprove(task.id)}
            className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-xs transition-all text-xs"
          >
            AUTHORIZE & PROCEED
          </button>
        </div>
      </div>
    </div>
  );
};
