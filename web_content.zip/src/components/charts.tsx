import { useEffect, useState } from "react";
import { CartesianGrid, Cell, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { compactHuf, formatDay, formatMoney, formatNumber } from "@/lib/format";
import type { Bucket } from "@/lib/portfolio-math";

const PIE = ["var(--color-pine)", "var(--color-ink)", "var(--color-clay)", "var(--color-muted)"];

function useMounted() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  return mounted;
}

function useStill() {
  const [still, setStill] = useState(false);
  useEffect(() => {
    const query = window.matchMedia("(prefers-reduced-motion: reduce)");
    const apply = () => setStill(query.matches);
    apply();
    query.addEventListener("change", apply);
    return () => query.removeEventListener("change", apply);
  }, []);
  return still;
}

const tipStyle = {
  background: "var(--color-surface)",
  border: "1px solid var(--color-line)",
  borderRadius: 12,
  color: "var(--color-ink)",
  fontSize: 13,
};

export function Donut({ rows }: { rows: Bucket[] }) {
  const mounted = useMounted();
  const total = rows.reduce((sum, row) => sum + row.huf, 0);
  if (!mounted || rows.length === 0) return <div className="h-52" />;
  return (
    <div className="relative h-52">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie data={rows} dataKey="huf" nameKey="label" innerRadius={62} outerRadius={88} stroke="var(--color-bg)" strokeWidth={3} isAnimationActive={false}>
            {rows.map((row, index) => (
              <Cell key={row.id} fill={PIE[index % PIE.length]} />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
      <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-xs text-muted">összesen</span>
        <span className="font-serif text-xl tabular-nums">{compactHuf(total)}</span>
      </div>
    </div>
  );
}

export function CapitalChart({ rows }: { rows: { date: string; toke: number; ertek: number | null }[] }) {
  const mounted = useMounted();
  const still = useStill();
  if (!mounted) return <div className="h-72" />;
  return (
    <div className="h-72 w-full min-w-0">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={rows} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
          <CartesianGrid stroke="var(--color-line)" vertical={false} />
          <XAxis dataKey="date" tickFormatter={(value: string) => value.slice(0, 7)} minTickGap={32} tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} />
          <YAxis tickFormatter={(value: number) => compactHuf(value).replace(" Ft", "")} width={56} tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} />
          <Tooltip
            contentStyle={tipStyle}
            labelFormatter={(label) => formatDay(String(label))}
            formatter={(value, name) => [formatMoney(Number(value ?? 0), "HUF"), name === "toke" ? "Befizetett tőke" : "Érték"]}
          />
          <Line type="monotone" dataKey="toke" name="toke" stroke="var(--color-clay)" strokeWidth={2} dot={false} isAnimationActive={!still} />
          <Line type="monotone" dataKey="ertek" name="ertek" stroke="var(--color-pine)" strokeWidth={2.4} dot={false} connectNulls={false} isAnimationActive={!still} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export function ClassChart({
  rows,
}: {
  rows: { date: string; etf: number | null; reszveny: number | null; kripto: number | null }[];
}) {
  const mounted = useMounted();
  const still = useStill();
  if (!mounted) return <div className="h-72" />;
  return (
    <div className="h-72 w-full min-w-0">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={rows} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
          <CartesianGrid stroke="var(--color-line)" vertical={false} />
          <XAxis dataKey="date" tickFormatter={(value: string) => value.slice(0, 7)} minTickGap={32} tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} />
          <YAxis tickFormatter={(value: number) => formatNumber(value, 0)} width={56} tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} />
          <Tooltip
            contentStyle={tipStyle}
            labelFormatter={(label) => formatDay(String(label))}
            formatter={(value, name) => [`${formatNumber(Number(value ?? 0), 0)} USD`, name === "etf" ? "ETF" : name === "kripto" ? "Kripto" : "Részvény"]}
          />
          <Line type="monotone" dataKey="etf" name="etf" stroke="var(--color-pine)" strokeWidth={2.2} dot={false} connectNulls isAnimationActive={!still} />
          <Line type="monotone" dataKey="reszveny" name="reszveny" stroke="var(--color-ink)" strokeWidth={2.2} dot={false} connectNulls isAnimationActive={!still} />
          <Line type="monotone" dataKey="kripto" name="kripto" stroke="var(--color-clay)" strokeWidth={2.2} dot={false} connectNulls isAnimationActive={!still} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
