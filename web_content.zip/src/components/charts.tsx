import { useEffect, useState } from "react";

type Point = { label: string; measured: number; target: number };

const tooltipStyle = {
  background: "var(--color-surface)",
  border: "1px solid var(--color-line)",
  borderRadius: 12,
  color: "var(--color-fg)",
  fontSize: 12,
};

export function FpsChart({ data }: { data: Point[] }) {
  const [mod, setMod] = useState<typeof import("recharts") | null>(null);
  useEffect(() => {
    let live = true;
    void import("recharts").then((loaded) => {
      if (live) setMod(loaded);
    });
    return () => {
      live = false;
    };
  }, []);

  if (!mod) return <div className="grid h-52 place-items-center text-sm text-muted">Chart loading…</div>;
  const { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } = mod;
  return (
    <div className="h-52 w-full min-w-0 text-primary">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
          <CartesianGrid stroke="var(--color-line)" vertical={false} />
          <XAxis dataKey="label" tick={{ fill: "var(--color-faint)", fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fill: "var(--color-faint)", fontSize: 11 }} axisLine={false} tickLine={false} width={32} />
          <Tooltip contentStyle={tooltipStyle} />
          <Line type="monotone" dataKey="measured" name="Measured" stroke="currentColor" strokeWidth={2} dot={false} isAnimationActive={false} />
          <Line type="monotone" dataKey="target" name="Target" stroke="var(--color-faint)" strokeDasharray="4 4" dot={false} isAnimationActive={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export function CompareChart({ data }: { data: { label: string; measured: number }[] }) {
  const [mod, setMod] = useState<typeof import("recharts") | null>(null);
  useEffect(() => {
    let live = true;
    void import("recharts").then((loaded) => {
      if (live) setMod(loaded);
    });
    return () => {
      live = false;
    };
  }, []);
  if (!mod) return <div className="grid h-52 place-items-center text-sm text-muted">Chart loading…</div>;
  const { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } = mod;
  return (
    <div className="h-52 w-full min-w-0 text-primary">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
          <CartesianGrid stroke="var(--color-line)" vertical={false} />
          <XAxis dataKey="label" tick={{ fill: "var(--color-faint)", fontSize: 11 }} axisLine={false} tickLine={false} interval={0} />
          <YAxis tick={{ fill: "var(--color-faint)", fontSize: 11 }} axisLine={false} tickLine={false} width={32} />
          <Tooltip contentStyle={tooltipStyle} />
          <Bar dataKey="measured" name="Measured FPS" fill="currentColor" radius={[6, 6, 0, 0]} isAnimationActive={false} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
