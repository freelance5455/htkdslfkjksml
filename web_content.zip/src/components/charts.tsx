import { useEffect, useState } from "react";
import { Cell, CartesianGrid, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { formatKrw, formatMan } from "@/lib/format";

function useMounted() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  return mounted;
}

function useReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    setReduced(window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  }, []);
  return reduced;
}

const tooltipStyle = {
  background: "var(--color-surface)",
  border: "1px solid var(--color-line)",
  borderRadius: 12,
  fontSize: 12,
  color: "var(--color-fg)",
};

export function Donut({
  data,
}: {
  data: { id: string; name: string; value: number; color: string }[];
}) {
  const mounted = useMounted();
  const reduced = useReducedMotion();
  if (!mounted) return <div className="h-56" />;
  if (data.length === 0) {
    return <div className="grid h-56 place-items-center text-sm text-muted">표시할 자산이 없습니다</div>;
  }
  return (
    <div className="relative h-56">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            dataKey="value"
            nameKey="name"
            innerRadius="68%"
            outerRadius="92%"
            paddingAngle={1.5}
            stroke="none"
            isAnimationActive={!reduced}
          >
            {data.map((entry) => (
              <Cell key={entry.id} fill={entry.color} />
            ))}
          </Pie>
          <Tooltip
            formatter={(value) => formatKrw(Number(value ?? 0))}
            contentStyle={tooltipStyle}
          />
        </PieChart>
      </ResponsiveContainer>
      <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-xs text-muted">평가액</span>
        <span className="text-sm font-semibold tabular-nums">{formatMan(data.reduce((sum, item) => sum + item.value, 0))}</span>
      </div>
    </div>
  );
}

type TrendRow = {
  label: string;
  fx: number | null;
  sp500: number | null;
  nasdaq: number | null;
  portfolio: number | null;
};

export function TrendChart({ rows }: { rows: TrendRow[] }) {
  const mounted = useMounted();
  const reduced = useReducedMotion();
  if (!mounted) return <div className="h-64" />;
  if (rows.length === 0) {
    return <div className="grid h-64 place-items-center text-sm text-muted">시세를 불러오면 차트가 그려집니다</div>;
  }
  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={rows} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
          <CartesianGrid stroke="var(--color-line)" vertical={false} />
          <XAxis dataKey="label" minTickGap={28} tick={{ fill: "var(--color-muted)", fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis
            width={36}
            tick={{ fill: "var(--color-muted)", fontSize: 11 }}
            axisLine={false}
            tickLine={false}
            domain={["auto", "auto"]}
          />
          <Tooltip
            contentStyle={tooltipStyle}
            formatter={(value, name) => {
              const n = Number(value ?? NaN);
              return [Number.isFinite(n) ? n.toFixed(1) : "-", String(name)];
            }}
          />
          <Line type="monotone" dataKey="portfolio" name="내 자산" stroke="var(--color-c1)" strokeWidth={2.25} dot={false} connectNulls isAnimationActive={!reduced} />
          <Line type="monotone" dataKey="sp500" name="S&P500" stroke="var(--color-c8)" strokeWidth={1.75} dot={false} connectNulls isAnimationActive={!reduced} />
          <Line type="monotone" dataKey="nasdaq" name="나스닥100" stroke="var(--color-c3)" strokeWidth={1.75} dot={false} connectNulls isAnimationActive={!reduced} />
          <Line type="monotone" dataKey="fx" name="환율" stroke="var(--color-c5)" strokeWidth={1.75} dot={false} connectNulls isAnimationActive={!reduced} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export function OutlookChart({
  rows,
}: {
  rows: { label: string; low: number; mid: number; high: number }[];
}) {
  const mounted = useMounted();
  const reduced = useReducedMotion();
  if (!mounted) return <div className="h-64" />;
  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={rows} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
          <CartesianGrid stroke="var(--color-line)" vertical={false} />
          <XAxis dataKey="label" minTickGap={24} tick={{ fill: "var(--color-muted)", fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis
            width={48}
            tick={{ fill: "var(--color-muted)", fontSize: 11 }}
            axisLine={false}
            tickLine={false}
            tickFormatter={(value) => formatMan(Number(value))}
          />
          <Tooltip
            contentStyle={tooltipStyle}
            formatter={(value, name) => [formatKrw(Number(value ?? 0)), String(name)]}
          />
          <Line type="monotone" dataKey="low" name="비관" stroke="var(--color-c5)" strokeWidth={1.75} dot={false} isAnimationActive={!reduced} />
          <Line type="monotone" dataKey="mid" name="평균" stroke="var(--color-c1)" strokeWidth={2.25} dot={false} isAnimationActive={!reduced} />
          <Line type="monotone" dataKey="high" name="낙관" stroke="var(--color-c3)" strokeWidth={1.75} dot={false} isAnimationActive={!reduced} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
