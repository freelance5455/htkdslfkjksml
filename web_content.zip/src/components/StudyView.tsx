import React, { useState, useEffect } from "react";
import { motion, AnimatePresence, useMotionValue, useTransform } from "motion/react";
import {
  BookOpen,
  RotateCw,
  CheckCircle2,
  XCircle,
  Shuffle,
  Plus,
  Sparkles,
  Trash2,
  ChevronLeft,
  ChevronRight,
  Lightbulb,
  Volume2,
  VolumeX,
  Award,
  Check,
  RefreshCcw,
  Layers,
  FileQuestion,
  Flame,
  Search
} from "lucide-react";
import { Flashcard, Note } from "../types";

interface StudyViewProps {
  flashcards: Flashcard[];
  notes: Note[];
  onUpdateFlashcards: (cards: Flashcard[]) => void;
  onOpenNewCardModal: () => void;
}

type StudyMode = "flashcard" | "quiz" | "list";
type FilterMode = "all" | "unmastered" | "mastered";

export const StudyView: React.FC<StudyViewProps> = ({
  flashcards,
  notes,
  onUpdateFlashcards,
  onOpenNewCardModal,
}) => {
  const [mode, setMode] = useState<StudyMode>("flashcard");
  const [filterMode, setFilterMode] = useState<FilterMode>("all");
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [aiGenerating, setAiGenerating] = useState(false);
  const [selectedNoteForAi, setSelectedNoteForAi] = useState<string>("");
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  // Quiz Mode State
  const [quizQuestions, setQuizQuestions] = useState<
    Array<{
      question: string;
      correctAnswer: string;
      options: string[];
      cardId: string;
    }>
  >([]);
  const [quizIndex, setQuizIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [quizScore, setQuizScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);
  const [userAnswers, setUserAnswers] = useState<
    Array<{ question: string; selected: string; correct: string; isCorrect: boolean }>
  >([]);

  // Filtered Cards
  const activeCards = flashcards.filter((card) => {
    if (filterMode === "unmastered") return !card.mastered;
    if (filterMode === "mastered") return card.mastered;
    return true;
  });

  const totalCards = activeCards.length;
  const currentCard = totalCards > 0 ? activeCards[currentIndex % totalCards] : null;
  const masteredCount = flashcards.filter((c) => c.mastered).length;
  const unmasteredCount = flashcards.filter((c) => !c.mastered).length;
  const progressPercent = flashcards.length > 0 ? Math.round((masteredCount / flashcards.length) * 100) : 0;

  // Haptic Feedback
  const triggerHaptic = (duration = 15) => {
    if (typeof navigator !== "undefined" && "vibrate" in navigator) {
      try {
        navigator.vibrate(duration);
      } catch (e) {}
    }
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Text to Speech
  const handleSpeak = (text: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (!("speechSynthesis" in window)) {
      showToast("Tarayıcınızda sesli okuma desteği bulunamadı.");
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = "tr-TR";
      utterance.rate = 0.95;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
      triggerHaptic(10);
    } catch (err) {
      setIsSpeaking(false);
    }
  };

  // Stop speaking when card changes or mode changes
  useEffect(() => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  }, [currentIndex, isFlipped, mode]);

  // Navigate Flashcards
  const handleNext = () => {
    triggerHaptic(10);
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev + 1) % Math.max(1, totalCards));
  };

  const handlePrev = () => {
    triggerHaptic(10);
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev - 1 + totalCards) % Math.max(1, totalCards));
  };

  const handleShuffle = () => {
    triggerHaptic(20);
    setIsFlipped(false);
    const shuffled = [...flashcards].sort(() => Math.random() - 0.5);
    onUpdateFlashcards(shuffled);
    setCurrentIndex(0);
    showToast("🔀 Kartlar karıştırıldı!");
  };

  const markMastered = (mastered: boolean) => {
    if (!currentCard) return;
    triggerHaptic(mastered ? 30 : 20);
    const updated = flashcards.map((c) =>
      c.id === currentCard.id ? { ...c, mastered } : c
    );
    onUpdateFlashcards(updated);
    showToast(mastered ? "🎉 'Öğrenildi' olarak işaretlendi!" : "🔄 'Tekrar Edilecek' olarak kaydedildi.");
    handleNext();
  };

  const deleteCurrentCard = (cardId: string) => {
    triggerHaptic(25);
    if (confirm("Bu çalışma kartı silinsin mi?")) {
      const updated = flashcards.filter((c) => c.id !== cardId);
      onUpdateFlashcards(updated);
      if (currentIndex >= updated.length && updated.length > 0) {
        setCurrentIndex(updated.length - 1);
      }
      setIsFlipped(false);
      showToast("🗑️ Kart silindi.");
    }
  };

  // AI Flashcard Generator
  const handleGenerateAiFromNote = async () => {
    if (!selectedNoteForAi) {
      showToast("Lütfen kart üretmek için bir not seçin.");
      return;
    }

    const note = notes.find((n) => n.id === selectedNoteForAi);
    if (!note) return;

    setAiGenerating(true);
    try {
      const res = await fetch("/api/gemini/generate-flashcards", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: note.title, content: note.content }),
      });
      const data = await res.json();
      if (data.flashcards && Array.isArray(data.flashcards)) {
        const newCards: Flashcard[] = data.flashcards.map((fc: any) => ({
          id: `fc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          noteId: note.id,
          question: fc.question,
          answer: fc.answer,
          mastered: false,
        }));
        onUpdateFlashcards([...flashcards, ...newCards]);
        showToast(`✨ ${newCards.length} yeni çalışma kartı eklendi!`);
        triggerHaptic(40);
      } else {
        showToast(data.error || "Kart üretilemedi.");
      }
    } catch (err) {
      console.error(err);
      showToast("Yapay zeka kart üretme bağlantı hatası.");
    } finally {
      setAiGenerating(false);
    }
  };

  // Setup Quiz Mode
  const startQuiz = () => {
    if (flashcards.length < 2) {
      showToast("Quiz başlatmak için en az 2 çalışma kartı gereklidir.");
      return;
    }

    triggerHaptic(30);
    // Shuffle cards and create multiple choice questions
    const shuffledCards = [...flashcards].sort(() => Math.random() - 0.5);
    const questions = shuffledCards.map((card) => {
      // Pick 3 random distractor answers from other cards
      const otherAnswers = flashcards
        .filter((c) => c.id !== card.id)
        .map((c) => c.answer);
      const shuffledDistractors = otherAnswers.sort(() => Math.random() - 0.5).slice(0, 3);
      
      const allOptions = [...shuffledDistractors, card.answer].sort(() => Math.random() - 0.5);

      return {
        question: card.question,
        correctAnswer: card.answer,
        options: allOptions,
        cardId: card.id,
      };
    });

    setQuizQuestions(questions);
    setQuizIndex(0);
    setSelectedAnswer(null);
    setQuizScore(0);
    setUserAnswers([]);
    setQuizFinished(false);
    setMode("quiz");
  };

  const handleSelectQuizAnswer = (option: string) => {
    if (selectedAnswer !== null) return;
    setSelectedAnswer(option);

    const currentQ = quizQuestions[quizIndex];
    const isCorrect = option === currentQ.correctAnswer;

    triggerHaptic(isCorrect ? 35 : 60);

    if (isCorrect) {
      setQuizScore((prev) => prev + 1);
      const updated = flashcards.map((c) =>
        c.id === currentQ.cardId ? { ...c, mastered: true } : c
      );
      onUpdateFlashcards(updated);
    }

    setUserAnswers((prev) => [
      ...prev,
      {
        question: currentQ.question,
        selected: option,
        correct: currentQ.correctAnswer,
        isCorrect,
      },
    ]);
  };

  const handleNextQuizQuestion = () => {
    triggerHaptic(15);
    setSelectedAnswer(null);
    if (quizIndex + 1 < quizQuestions.length) {
      setQuizIndex((prev) => prev + 1);
    } else {
      setQuizFinished(true);
      triggerHaptic(50);
    }
  };

  // Drag Gesture Transforms for Swipe Left / Right
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-200, 200], [-18, 18]);
  const opacity = useTransform(x, [-200, -100, 0, 100, 200], [0.6, 0.9, 1, 0.9, 0.6]);

  const handleDragEnd = (_: any, info: any) => {
    const swipeThreshold = 100;
    if (info.offset.x > swipeThreshold) {
      markMastered(true);
    } else if (info.offset.x < -swipeThreshold) {
      markMastered(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto py-4 sm:py-6 px-3 sm:px-4 space-y-4 sm:space-y-6 animate-in fade-in">
      {/* Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-5 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 bg-slate-900/95 text-white dark:bg-slate-100 dark:text-slate-900 rounded-2xl shadow-xl text-xs font-bold flex items-center gap-2 border border-slate-700/50 backdrop-blur-md"
          >
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Header & Mode Navigation Bar */}
      <div className="bg-white dark:bg-slate-800/90 rounded-3xl p-4 sm:p-5 border border-slate-200 dark:border-slate-700/80 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-100 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold shrink-0">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <span>Öğrenme & Hafıza Kartları</span>
                {masteredCount > 0 && (
                  <span className="flex items-center gap-1 text-[11px] font-extrabold text-amber-500 bg-amber-50 dark:bg-amber-950/40 px-2 py-0.5 rounded-full border border-amber-200 dark:border-amber-800">
                    <Flame className="w-3 h-3 fill-amber-500" />
                    <span>{masteredCount} Usta</span>
                  </span>
                )}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Aralıklı tekrar (Leitner) yöntemiyle öğrenin, test çözün ve pekiştirin.
              </p>
            </div>
          </div>

          {/* Action Tools */}
          <div className="flex items-center gap-2">
            <button
              onClick={onOpenNewCardModal}
              className="flex items-center gap-1.5 px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Yeni Kart</span>
            </button>

            {flashcards.length >= 2 && (
              <button
                onClick={startQuiz}
                className="flex items-center gap-1.5 px-3 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-all cursor-pointer"
                title="Çalışma Kartlarından Quiz Sınavı Başlat"
              >
                <FileQuestion className="w-4 h-4" />
                <span>Quiz Başlat</span>
              </button>
            )}

            {flashcards.length > 1 && mode === "flashcard" && (
              <button
                onClick={handleShuffle}
                title="Kartları Karıştır"
                className="p-2 rounded-xl bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors cursor-pointer"
              >
                <Shuffle className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Mode Selector Tabs (Flashcard, Quiz, Liste) */}
        <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-700/60">
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-900/60 rounded-2xl border border-slate-200/60 dark:border-slate-800">
            <button
              onClick={() => {
                triggerHaptic(10);
                setMode("flashcard");
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                mode === "flashcard"
                  ? "bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-xs"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
              }`}
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>Kart Çevir</span>
            </button>

            <button
              onClick={() => {
                triggerHaptic(10);
                if (quizQuestions.length === 0) startQuiz();
                else setMode("quiz");
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                mode === "quiz"
                  ? "bg-white dark:bg-slate-800 text-purple-600 dark:text-purple-400 shadow-xs"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
              }`}
            >
              <FileQuestion className="w-3.5 h-3.5" />
              <span>Quiz Modu</span>
            </button>

            <button
              onClick={() => {
                triggerHaptic(10);
                setMode("list");
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                mode === "list"
                  ? "bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-xs"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Kart Listesi ({flashcards.length})</span>
            </button>
          </div>

          {/* Filter Chips (Hepsi, Öğrenilecek, Öğrenilen) */}
          {mode === "flashcard" && flashcards.length > 0 && (
            <div className="hidden sm:flex items-center gap-1 text-[11px] font-semibold">
              <button
                onClick={() => {
                  triggerHaptic(10);
                  setFilterMode("all");
                  setCurrentIndex(0);
                }}
                className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                  filterMode === "all"
                    ? "bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 font-bold"
                    : "text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                }`}
              >
                Tümü ({flashcards.length})
              </button>
              <button
                onClick={() => {
                  triggerHaptic(10);
                  setFilterMode("unmastered");
                  setCurrentIndex(0);
                }}
                className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                  filterMode === "unmastered"
                    ? "bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 font-bold"
                    : "text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                }`}
              >
                Tekrar ({unmasteredCount})
              </button>
              <button
                onClick={() => {
                  triggerHaptic(10);
                  setFilterMode("mastered");
                  setCurrentIndex(0);
                }}
                className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                  filterMode === "mastered"
                    ? "bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold"
                    : "text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                }`}
              >
                Öğrenilen ({masteredCount})
              </button>
            </div>
          )}
        </div>

        {/* Global Progress bar */}
        {flashcards.length > 0 && (
          <div>
            <div className="flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1.5">
              <span>Genel Başarı Durumu</span>
              <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                {masteredCount} / {flashcards.length} Öğrenildi (%{progressPercent})
              </span>
            </div>
            <div className="w-full bg-slate-100 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-blue-500 via-indigo-500 to-emerald-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 1. FLASHCARD INTERACTIVE STAGE (FLIP & SWIPE MODE) */}
      {/* ========================================================================= */}
      {mode === "flashcard" && (
        <>
          {totalCards === 0 ? (
            <div className="text-center py-16 px-4 bg-white dark:bg-slate-800/40 rounded-3xl border border-dashed border-slate-300 dark:border-slate-700 space-y-3">
              <Lightbulb className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
              <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">
                {filterMode !== "all"
                  ? "Bu filtrede kart bulunamadı"
                  : "Henüz Çalışma Kartı Yok"}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
                {filterMode !== "all"
                  ? "Tüm kartları görüntülemek için filtreyi temizleyin."
                  : "Ezberlemek ve öğrenmek istediğiniz konular için kartlar ekleyin veya yapay zekanın notlarınızdan otomatik kart üretmesini sağlayın."}
              </p>
              <div className="flex items-center justify-center gap-2 pt-2">
                {filterMode !== "all" ? (
                  <button
                    onClick={() => setFilterMode("all")}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-sm cursor-pointer"
                  >
                    Filtreyi Temizle (Tümü)
                  </button>
                ) : (
                  <button
                    onClick={onOpenNewCardModal}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-sm cursor-pointer"
                  >
                    Manuel Kart Ekle
                  </button>
                )}
              </div>
            </div>
          ) : (
            currentCard && (
              <div className="space-y-4">
                {/* Mobile Swipe / Gesture Hint Banner */}
                <div className="flex items-center justify-between text-[11px] text-slate-400 px-1">
                  <span className="flex items-center gap-1 text-rose-500 dark:text-rose-400">
                    <span>← Sola Kaydır:</span> <strong>Tekrar Et</strong>
                  </span>
                  <span className="text-slate-400">Dokun: Çevir</span>
                  <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                    <strong>Öğrendim</strong> <span>:Sağa Kaydır →</span>
                  </span>
                </div>

                {/* The 3D Interactive Flip & Draggable Card */}
                <motion.div
                  style={{ x, rotate, opacity }}
                  drag="x"
                  dragConstraints={{ left: 0, right: 0 }}
                  dragElastic={0.7}
                  onDragEnd={handleDragEnd}
                  onClick={() => {
                    triggerHaptic(15);
                    setIsFlipped(!isFlipped);
                  }}
                  className={`relative min-h-[300px] sm:min-h-[340px] rounded-3xl p-6 sm:p-8 border shadow-lg transition-colors duration-300 cursor-pointer flex flex-col justify-between select-none ${
                    isFlipped
                      ? "bg-gradient-to-br from-emerald-50/90 to-teal-50/80 dark:from-emerald-950/40 dark:to-slate-800 border-emerald-300 dark:border-emerald-700/80"
                      : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700"
                  }`}
                >
                  {/* Card Top Pill: Mode & TTS Voice */}
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-[11px] font-black px-3 py-1 rounded-full uppercase tracking-wider ${
                        isFlipped
                          ? "bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700"
                          : "bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-300 border border-blue-300 dark:border-blue-700"
                      }`}
                    >
                      {isFlipped ? "Cevap / Arka Yüz" : "Soru / Ön Yüz"}
                    </span>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={(e) =>
                          handleSpeak(isFlipped ? currentCard.answer : currentCard.question, e)
                        }
                        className={`p-2 rounded-xl border transition-all cursor-pointer ${
                          isSpeaking
                            ? "bg-blue-600 text-white border-blue-600 animate-pulse"
                            : "bg-slate-100 dark:bg-slate-700/80 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-600 hover:bg-slate-200"
                        }`}
                        title="Sesli Oku (Türkçe Telaffuz)"
                      >
                        {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                      </button>

                      <div className="flex items-center gap-1.5 text-xs text-slate-400">
                        <RotateCw className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Çevir</span>
                      </div>
                    </div>
                  </div>

                  {/* Card Center Content */}
                  <div className="py-6 text-center my-auto px-2">
                    <p className="text-lg sm:text-2xl font-bold text-slate-900 dark:text-white leading-relaxed">
                      {isFlipped ? currentCard.answer : currentCard.question}
                    </p>
                  </div>

                  {/* Card Bottom Status & Delete */}
                  <div className="flex items-center justify-between text-xs pt-3 border-t border-slate-200/70 dark:border-slate-700/60 text-slate-400">
                    <span>
                      {currentCard.mastered ? (
                        <span className="text-emerald-600 dark:text-emerald-400 font-extrabold flex items-center gap-1">
                          <CheckCircle2 className="w-4 h-4" /> Öğrenildi (Usta)
                        </span>
                      ) : (
                        <span className="text-rose-500 dark:text-rose-400 font-semibold flex items-center gap-1">
                          <XCircle className="w-4 h-4" /> Tekrar edilecek
                        </span>
                      )}
                    </span>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteCurrentCard(currentCard.id);
                      }}
                      className="text-slate-400 hover:text-rose-500 p-1.5 rounded-lg transition-colors cursor-pointer"
                      title="Bu kartı sil"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </motion.div>

                {/* Answer feedback buttons (Tekrar Et vs Öğrendim) */}
                <div className="grid grid-cols-2 gap-3 pt-1">
                  <button
                    type="button"
                    onClick={() => markMastered(false)}
                    className="py-3.5 px-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 active:scale-95 transition-all shadow-xs cursor-pointer"
                  >
                    <XCircle className="w-4 h-4 sm:w-5 sm:h-5 text-rose-500" />
                    <span>Tekrar Et (Sola)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => markMastered(true)}
                    className="py-3.5 px-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 active:scale-95 transition-all shadow-xs cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-500" />
                    <span>Öğrendim (Sağa)</span>
                  </button>
                </div>

                {/* Navigation Controls */}
                <div className="flex items-center justify-between pt-1">
                  <button
                    onClick={handlePrev}
                    className="flex items-center gap-1 px-4 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>Önceki</span>
                  </button>

                  <span className="text-xs text-slate-500 dark:text-slate-400 font-bold">
                    Kart {((currentIndex % totalCards) + 1)} / {totalCards}
                  </span>

                  <button
                    onClick={handleNext}
                    className="flex items-center gap-1 px-4 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors cursor-pointer"
                  >
                    <span>Sonraki</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )
          )}
        </>
      )}

      {/* ========================================================================= */}
      {/* 2. QUIZ / MULTIPLE CHOICE EXAM TEST MODE */}
      {/* ========================================================================= */}
      {mode === "quiz" && (
        <div className="space-y-4">
          {quizFinished ? (
            /* Quiz Results Summary Card */
            <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-700 text-center space-y-5 shadow-sm animate-in zoom-in-95">
              <div className="w-16 h-16 bg-purple-100 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 rounded-3xl flex items-center justify-center mx-auto shadow-inner">
                <Award className="w-8 h-8" />
              </div>

              <div>
                <h3 className="text-xl font-black text-slate-900 dark:text-white">
                  Quiz Tamamlandı!
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Kartlarınızdan oluşturulan çoktan seçmeli sınav performansınız:
                </p>
              </div>

              {/* Score Display */}
              <div className="p-4 bg-purple-50/70 dark:bg-purple-950/30 rounded-2xl border border-purple-200 dark:border-purple-800/80 max-w-sm mx-auto">
                <div className="text-3xl font-black text-purple-700 dark:text-purple-300 font-mono">
                  {quizScore} / {quizQuestions.length}
                </div>
                <div className="text-xs font-bold text-purple-600 dark:text-purple-400 mt-1">
                  Başarı Oranı: %{Math.round((quizScore / quizQuestions.length) * 100)}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <button
                  onClick={startQuiz}
                  className="px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-2xl text-xs font-bold shadow-md shadow-purple-600/20 active:scale-95 transition-all cursor-pointer flex items-center gap-2"
                >
                  <RefreshCcw className="w-4 h-4" />
                  <span>Tekrar Çöz</span>
                </button>

                <button
                  onClick={() => setMode("flashcard")}
                  className="px-5 py-2.5 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 rounded-2xl text-xs font-bold active:scale-95 transition-all cursor-pointer"
                >
                  Kartlara Dön
                </button>
              </div>

              {/* Breakdown List */}
              <div className="text-left pt-4 border-t border-slate-100 dark:border-slate-700/60 space-y-2.5">
                <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  Cevaplarınızın Detayı ({userAnswers.length} Soru):
                </h4>
                <div className="max-h-60 overflow-y-auto space-y-2 pr-1">
                  {userAnswers.map((ua, idx) => (
                    <div
                      key={idx}
                      className={`p-3 rounded-2xl border text-xs ${
                        ua.isCorrect
                          ? "bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200"
                          : "bg-rose-50/50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-800 text-rose-900 dark:text-rose-200"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2 font-bold mb-1">
                        <span>{idx + 1}. {ua.question}</span>
                        {ua.isCorrect ? (
                          <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                        ) : (
                          <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                        )}
                      </div>
                      <div className="text-[11px] space-y-0.5">
                        <p>
                          <span className="opacity-75">Seçiminiz:</span> <strong>{ua.selected}</strong>
                        </p>
                        {!ua.isCorrect && (
                          <p className="text-emerald-700 dark:text-emerald-300">
                            <span className="opacity-75">Doğru Cevap:</span> <strong>{ua.correct}</strong>
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : quizQuestions.length > 0 ? (
            /* Active Quiz Question Card */
            <div className="bg-white dark:bg-slate-800 rounded-3xl p-5 sm:p-7 border border-slate-200 dark:border-slate-700 shadow-md space-y-5">
              {/* Question Header & Progress */}
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/60 px-3 py-1 rounded-full border border-purple-200 dark:border-purple-800">
                  Soru {quizIndex + 1} / {quizQuestions.length}
                </span>

                <span className="text-slate-500 font-bold font-mono">
                  Puan: {quizScore} Doğru
                </span>
              </div>

              {/* Question Text */}
              <div className="py-3">
                <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white leading-relaxed">
                  {quizQuestions[quizIndex].question}
                </h3>
              </div>

              {/* Options Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {quizQuestions[quizIndex].options.map((option, idx) => {
                  const isSelected = selectedAnswer === option;
                  const isCorrectAnswer = option === quizQuestions[quizIndex].correctAnswer;
                  
                  let buttonStyle = "bg-slate-50 dark:bg-slate-700/60 border-slate-200 dark:border-slate-600 text-slate-800 dark:text-slate-200 hover:border-purple-300";

                  if (selectedAnswer !== null) {
                    if (isCorrectAnswer) {
                      buttonStyle = "bg-emerald-100 dark:bg-emerald-950/80 border-emerald-500 text-emerald-900 dark:text-emerald-200 font-bold ring-2 ring-emerald-500/20";
                    } else if (isSelected) {
                      buttonStyle = "bg-rose-100 dark:bg-rose-950/80 border-rose-500 text-rose-900 dark:text-rose-200 font-bold";
                    } else {
                      buttonStyle = "opacity-50 bg-slate-50 dark:bg-slate-700/30 border-slate-200 dark:border-slate-700 text-slate-400";
                    }
                  }

                  return (
                    <button
                      key={idx}
                      type="button"
                      disabled={selectedAnswer !== null}
                      onClick={() => handleSelectQuizAnswer(option)}
                      className={`p-3.5 rounded-2xl border text-left text-xs sm:text-sm transition-all flex items-start gap-2.5 cursor-pointer ${buttonStyle}`}
                    >
                      <span className="w-5 h-5 rounded-full bg-slate-200 dark:bg-slate-600 text-slate-700 dark:text-slate-300 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                        {String.fromCharCode(65 + idx)}
                      </span>
                      <span className="flex-1 leading-snug">{option}</span>
                    </button>
                  );
                })}
              </div>

              {/* Feedback & Next Button */}
              {selectedAnswer !== null && (
                <div className="pt-3 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between animate-in fade-in">
                  <div className="text-xs font-bold">
                    {selectedAnswer === quizQuestions[quizIndex].correctAnswer ? (
                      <span className="text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4" /> Doğru Cevap! Tebrikler.
                      </span>
                    ) : (
                      <span className="text-rose-600 dark:text-rose-400 flex items-center gap-1.5">
                        <XCircle className="w-4 h-4" /> Yanlış! Doğru cevap işaretlendi.
                      </span>
                    )}
                  </div>

                  <button
                    onClick={handleNextQuizQuestion}
                    className="px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-2xl text-xs font-bold shadow-md shadow-purple-600/20 active:scale-95 transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <span>{quizIndex + 1 < quizQuestions.length ? "Sonraki Soru" : "Sonucu Gör"}</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-12 bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700">
              <p className="text-xs text-slate-500">Quiz başlatmak için yeterli kart bulunamadı.</p>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. CARD LIST & MANAGEMENT MODE */}
      {/* ========================================================================= */}
      {mode === "list" && (
        <div className="bg-white dark:bg-slate-800 rounded-3xl p-5 border border-slate-200 dark:border-slate-700 shadow-sm space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Kartlar arasında ara (soru veya cevap)..."
                className="w-full pl-9 pr-4 py-2 rounded-xl text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 text-slate-800 dark:text-slate-200"
              />
            </div>

            <button
              onClick={onOpenNewCardModal}
              className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-all cursor-pointer flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Yeni</span>
            </button>
          </div>

          {/* Cards Table / List */}
          <div className="divide-y divide-slate-100 dark:divide-slate-700/60 max-h-[480px] overflow-y-auto pr-1">
            {flashcards
              .filter(
                (c) =>
                  c.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
                  c.answer.toLowerCase().includes(searchQuery.toLowerCase())
              )
              .map((card, idx) => (
                <div key={card.id} className="py-3 flex items-center justify-between gap-3 group">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-[10px] font-mono text-slate-400">#{idx + 1}</span>
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                        {card.question}
                      </h4>
                      {card.mastered ? (
                        <span className="text-[9px] font-extrabold px-1.5 py-0.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 rounded-md">
                          Öğrenildi
                        </span>
                      ) : (
                        <span className="text-[9px] font-extrabold px-1.5 py-0.5 bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 rounded-md">
                          Tekrar
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                      {card.answer}
                    </p>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleSpeak(`${card.question}. Cevap: ${card.answer}`)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-slate-700 cursor-pointer"
                      title="Sesli Dinle"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const updated = flashcards.map((c) =>
                          c.id === card.id ? { ...c, mastered: !c.mastered } : c
                        );
                        onUpdateFlashcards(updated);
                        triggerHaptic(15);
                      }}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-slate-700 cursor-pointer"
                      title="Durumu Değiştir"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => deleteCurrentCard(card.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-slate-700 cursor-pointer"
                      title="Kartı Sil"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* AI Flashcard Generator from existing notes */}
      {notes.length > 0 && (
        <div className="p-4 bg-gradient-to-tr from-blue-50/70 via-indigo-50/60 to-purple-50/60 dark:from-blue-950/30 dark:via-indigo-950/20 dark:to-purple-950/20 rounded-3xl border border-blue-200/80 dark:border-blue-800/60 space-y-3 shadow-xs">
          <div className="flex items-center gap-2 text-xs font-bold text-blue-900 dark:text-blue-200">
            <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span>Notlarından Yapay Zeka ile Otomatik Çalışma Kartı Üret</span>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-2">
            <select
              value={selectedNoteForAi}
              onChange={(e) => setSelectedNoteForAi(e.target.value)}
              className="w-full sm:flex-1 text-xs bg-white dark:bg-slate-800 border border-blue-300 dark:border-blue-700 rounded-xl px-3 py-2 text-slate-800 dark:text-slate-200 focus:outline-none"
            >
              <option value="">Kart üretilecek bir not seçin...</option>
              {notes.map((n) => (
                <option key={n.id} value={n.id}>
                  {n.title || "Başlıksız Not"} ({n.category})
                </option>
              ))}
            </select>

            <button
              onClick={handleGenerateAiFromNote}
              disabled={aiGenerating || !selectedNoteForAi}
              className="w-full sm:w-auto px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm active:scale-95 transition-all whitespace-nowrap cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{aiGenerating ? "Üretiliyor..." : "Kart Üret"}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
