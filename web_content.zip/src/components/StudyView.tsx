import React, { useState } from 'react';
import {
  ChevronDown,
  ChevronUp,
  Search,
  Sparkles,
  RotateCcw,
  Check,
  Plus,
  Trash2,
  Undo2,
  Film,
  FileText,
  SlidersHorizontal,
} from 'lucide-react';
import {
  MaterialStatus,
  StartedChaptersStore,
  StatusStore,
  SubItem,
  SubItemStore,
  SubjectKey,
} from '../types';
import { SUBJECT_CONFIGS, SUBJECT_KEYS } from '../data/batchData';
import {
  calculateOverallStats,
  calculateSubjectStats,
  getAllSubjectMaterials,
  getChapterBaseMaterials,
  getChapterMaterials,
  getMaterialPriority,
  getMaterialProgress,
  getSubjectChapterProgress,
  isChapterStarted,
  makeStatusKey,
} from '../utils/trackerLogic';

interface StudyViewProps {
  currentSubject: SubjectKey;
  onSelectSubject: (subj: SubjectKey) => void;
  statusStore: StatusStore;
  subItemStore: SubItemStore;
  startedStore: StartedChaptersStore;
  onUpdateStatus: (key: string, value: MaterialStatus) => void;
  onUpdateSubItems: (subject: string, chapter: string, material: string, items: SubItem[]) => void;
  onStartChapter: (subject: string, chapter: string) => void;
  onBulkApply: (label: string, updates: Record<string, MaterialStatus>) => void;
  onOpenBacklogWithFilter?: (filter: 'all' | 'L' | 'M' | 'T') => void;
}

export const StudyView: React.FC<StudyViewProps> = ({
  currentSubject,
  onSelectSubject,
  statusStore,
  subItemStore,
  startedStore,
  onUpdateStatus,
  onUpdateSubItems,
  onStartChapter,
  onBulkApply,
  onOpenBacklogWithFilter,
}) => {
  const [openChapters, setOpenChapters] = useState<Record<string, boolean>>({});
  const [openSubs, setOpenSubs] = useState<Record<string, boolean>>({});
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'started' | 'unstarted' | 'completed'>('all');
  const [showQuickMark, setShowQuickMark] = useState(false);
  const [quickMarkMaterial, setQuickMarkMaterial] = useState('');
  const [toastMessage, setToastMessage] = useState<{ text: string; onUndo?: () => void } | null>(null);
  const [countInputs, setCountInputs] = useState<Record<string, string>>({});
  const [subItemInputs, setSubItemInputs] = useState<Record<string, string>>({});

  const config = SUBJECT_CONFIGS[currentSubject];
  const allSubjectMaterials = getAllSubjectMaterials(currentSubject);
  const overallStats = calculateOverallStats(statusStore, startedStore, subItemStore);
  const subjectStats = calculateSubjectStats(currentSubject, statusStore, startedStore, subItemStore);

  // Started chapters for current subject
  const currentStartedChapters = config.chapters.filter((ch) =>
    isChapterStarted(startedStore, currentSubject, ch)
  );

  const toggleChapterOpen = (chapter: string) => {
    setOpenChapters((prev) => ({ ...prev, [chapter]: !prev[chapter] }));
  };

  const toggleSubOpen = (key: string) => {
    setOpenSubs((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // Helper for lecture/dpp items
  const getSubItems = (subject: string, chapter: string, material: string): SubItem[] => {
    return subItemStore[subject]?.[chapter]?.[material] || [];
  };

  const cycleStatus = (subject: string, chapter: string, material: string) => {
    const key = makeStatusKey(subject, chapter, material);
    const cur = getMaterialProgress(subject, chapter, material, statusStore, subItemStore).status;
    const next: MaterialStatus = cur === 'pending' ? 'partial' : cur === 'partial' ? 'done' : 'pending';
    onUpdateStatus(key, next);

    const existing = getSubItems(subject, chapter, material);
    if (existing.length > 0 && (next === 'done' || next === 'pending')) {
      onUpdateSubItems(
        subject,
        chapter,
        material,
        existing.map((it) => ({ ...it, done: next === 'done' }))
      );
    }
  };

  // Set count for lectures or DPP
  const handleSetCount = (subject: string, chapter: string, material: string) => {
    const inputKey = `${subject}|${chapter}|${material}`;
    const count = parseInt(countInputs[inputKey] || '0', 10);
    if (count <= 0 || count > 150) return;

    const existing = getSubItems(subject, chapter, material);
    const prefix = material === 'Lectures' ? 'Lecture' : 'DPP';
    const updated: SubItem[] = [];

    for (let i = 0; i < count; i++) {
      updated.push({
        name: `${prefix} ${i + 1}`,
        done: !!(existing[i] && existing[i].done),
      });
    }

    onUpdateSubItems(subject, chapter, material, updated);

    // Sync overall material status
    const allDone = updated.length > 0 && updated.every((x) => x.done);
    const anyDone = updated.some((x) => x.done);
    const matKey = makeStatusKey(subject, chapter, material);
    onUpdateStatus(matKey, allDone ? 'done' : anyDone ? 'partial' : 'pending');

    setCountInputs((prev) => ({ ...prev, [inputKey]: '' }));
  };

  // Toggle single tick in lecture/DPP
  const handleToggleTick = (subject: string, chapter: string, material: string, index: number) => {
    const items = [...getSubItems(subject, chapter, material)];
    if (!items[index]) return;
    items[index] = { ...items[index], done: !items[index].done };

    onUpdateSubItems(subject, chapter, material, items);

    // Sync status
    const allDone = items.length > 0 && items.every((x) => x.done);
    const anyDone = items.some((x) => x.done);
    const matKey = makeStatusKey(subject, chapter, material);
    onUpdateStatus(matKey, allDone ? 'done' : anyDone ? 'partial' : 'pending');
  };

  // Mark all ticks in lecture/DPP as done/undone
  const handleAllTicks = (subject: string, chapter: string, material: string, done: boolean) => {
    const items = getSubItems(subject, chapter, material).map((item) => ({ ...item, done }));
    onUpdateSubItems(subject, chapter, material, items);

    const matKey = makeStatusKey(subject, chapter, material);
    onUpdateStatus(matKey, done ? 'done' : 'pending');
  };

  // Custom subitem add (e.g. KPP sheet)
  const handleAddCustomSubItem = (subject: string, chapter: string, material: string) => {
    const inputKey = `${subject}|${chapter}|${material}`;
    const name = (subItemInputs[inputKey] || '').trim();
    if (!name) return;

    const items = [...getSubItems(subject, chapter, material), { name, done: false }];
    onUpdateSubItems(subject, chapter, material, items);

    const anyDone = items.some((x) => x.done);
    const allDone = items.length > 0 && items.every((x) => x.done);
    const matKey = makeStatusKey(subject, chapter, material);
    onUpdateStatus(matKey, allDone ? 'done' : anyDone ? 'partial' : 'pending');

    setSubItemInputs((prev) => ({ ...prev, [inputKey]: '' }));
  };

  const handleToggleCustomSubItem = (subject: string, chapter: string, material: string, index: number) => {
    const items = [...getSubItems(subject, chapter, material)];
    if (!items[index]) return;
    items[index] = { ...items[index], done: !items[index].done };

    onUpdateSubItems(subject, chapter, material, items);

    const allDone = items.length > 0 && items.every((x) => x.done);
    const anyDone = items.some((x) => x.done);
    const matKey = makeStatusKey(subject, chapter, material);
    onUpdateStatus(matKey, allDone ? 'done' : anyDone ? 'partial' : 'pending');
  };

  const handleDeleteCustomSubItem = (subject: string, chapter: string, material: string, index: number) => {
    const items = getSubItems(subject, chapter, material).filter((_, i) => i !== index);
    onUpdateSubItems(subject, chapter, material, items);

    const allDone = items.length > 0 && items.every((x) => x.done);
    const anyDone = items.some((x) => x.done);
    const matKey = makeStatusKey(subject, chapter, material);
    onUpdateStatus(matKey, allDone ? 'done' : anyDone ? 'partial' : 'pending');
  };

  // Bulk chapter action (All materials in chapter -> Done / Reset)
  const handleBulkChapter = (chapter: string, targetStatus: MaterialStatus) => {
    const updates: Record<string, MaterialStatus> = {};
    const baseMaterials = getChapterBaseMaterials(currentSubject, chapter);
    baseMaterials.forEach((mat) => {
      updates[makeStatusKey(currentSubject, chapter, mat)] = targetStatus;
      const existing = getSubItems(currentSubject, chapter, mat);
      if (existing.length > 0) {
        onUpdateSubItems(
          currentSubject,
          chapter,
          mat,
          existing.map((it) => ({ ...it, done: targetStatus === 'done' }))
        );
      }
    });
    updates[makeStatusKey(currentSubject, chapter, 'Lectures')] = targetStatus;
    const existingLectures = getSubItems(currentSubject, chapter, 'Lectures');
    if (existingLectures.length > 0) {
      onUpdateSubItems(
        currentSubject,
        chapter,
        'Lectures',
        existingLectures.map((it) => ({ ...it, done: targetStatus === 'done' }))
      );
    }
    onBulkApply(`${chapter}: All materials ${targetStatus}`, updates);
  };

  // Quick mark execution across all started chapters for selected material
  const handleQuickMarkGo = (targetStatus: MaterialStatus) => {
    const targetMat = quickMarkMaterial || 'Lectures';
    if (currentStartedChapters.length === 0) {
      setToastMessage({ text: 'Start a chapter first. Only started chapters change.' });
      setTimeout(() => setToastMessage(null), 3000);
      return;
    }

    const updates: Record<string, MaterialStatus> = {};
    let affectedCount = 0;
    currentStartedChapters.forEach((ch) => {
      const chMats = getChapterMaterials(currentSubject, ch);
      if (!chMats.includes(targetMat)) return;
      affectedCount++;
      updates[makeStatusKey(currentSubject, ch, targetMat)] = targetStatus;
      const existing = getSubItems(currentSubject, ch, targetMat);
      if (existing.length > 0) {
        onUpdateSubItems(
          currentSubject,
          ch,
          targetMat,
          existing.map((it) => ({ ...it, done: targetStatus === 'done' }))
        );
      }
    });

    onBulkApply(
      `Set ${targetMat} ${targetStatus} in ${affectedCount} started chapters`,
      updates
    );
  };

  // Filtered chapters
  const filteredChapters = config.chapters.filter((chapter) => {
    const matchesSearch = chapter.toLowerCase().includes(searchQuery.toLowerCase());
    if (!matchesSearch) return false;

    const started = isChapterStarted(startedStore, currentSubject, chapter);
    if (statusFilter === 'started') return started;
    if (statusFilter === 'unstarted') return !started;
    if (statusFilter === 'completed') {
      if (!started) return false;
      const chMats = getChapterMaterials(currentSubject, chapter);
      return chMats.every(
        (mat) =>
          getMaterialProgress(currentSubject, chapter, mat, statusStore, subItemStore).status ===
          'done'
      );
    }
    return true;
  });

  return (
    <div className="space-y-4 pb-20">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-16 sm:bottom-6 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-xl bg-zinc-800 text-white text-xs font-semibold shadow-2xl border border-zinc-700 flex items-center gap-3 animate-in fade-in slide-in-from-bottom-2">
          <span>{toastMessage.text}</span>
          {toastMessage.onUndo && (
            <button
              onClick={toastMessage.onUndo}
              className="px-2.5 py-1 rounded-lg bg-orange-500 text-white font-bold hover:bg-orange-600 transition-colors"
            >
              Undo
            </button>
          )}
        </div>
      )}

      {/* Overall Progress Bar */}
      <div className="rounded-2xl border border-[#262433] bg-[#141419]/90 p-3.5 backdrop-blur-sm">
        <div className="flex items-center justify-between text-xs mb-1.5">
          <span className="text-[#9a9aa8] font-medium">Overall Progress (all 4 subjects)</span>
          <div className="flex items-center gap-2">
            <span className="font-bold text-[#ff6b3d] text-[13px] tabular-nums">
              {overallStats.percent}%
            </span>
            <span className="text-[11px] text-[#84848f] font-medium tabular-nums">
              {overallStats.total > 0
                ? overallStats.partial > 0
                  ? `${overallStats.done}/${overallStats.total} done · ${overallStats.partial} partial`
                  : `${overallStats.done}/${overallStats.total} done`
                : 'Start chapters to track'}
            </span>
          </div>
        </div>
        <div className="h-2 w-full bg-[#1d1d24] rounded-full overflow-hidden flex">
          <div
            style={{ width: `${(overallStats.done / (overallStats.total || 1)) * 100}%` }}
            className="h-full bg-[#34d17f] transition-all duration-300 rounded-l-full"
          />
          <div
            style={{ width: `${(overallStats.partial / (overallStats.total || 1)) * 100}%` }}
            className="h-full bg-[#f2a93a] transition-all duration-300"
          />
        </div>
      </div>

      {/* Individual Subject Cards with Circular Progress Bars */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        {SUBJECT_KEYS.map((subjKey) => {
          const cfg = SUBJECT_CONFIGS[subjKey];
          const isActive = currentSubject === subjKey;
          const prog = getSubjectChapterProgress(subjKey, startedStore, statusStore, subItemStore);

          const radius = 21;
          const circumference = 2 * Math.PI * radius;
          const strokeDashoffset =
            circumference - (Math.min(100, Math.max(0, prog.percent)) / 100) * circumference;

          return (
              <button
                key={subjKey}
                type="button"
                onClick={() => onSelectSubject(subjKey)}
                style={{
                  borderColor: isActive ? cfg.color : '#262433',
                  boxShadow: isActive ? `0 8px 24px -6px ${cfg.color}35` : undefined,
                }}
                className={`relative p-3 rounded-2xl border text-left flex items-center justify-between gap-2 transition-all cursor-pointer overflow-hidden ${
                  isActive
                    ? 'bg-gradient-to-br from-[#1d192b] via-[#15141d] to-[#111116]'
                    : 'bg-[#141419]/90 hover:bg-[#191921] opacity-85 hover:opacity-100'
                }`}
              >
                {/* Left Info */}
                <div className="min-w-0 flex-1 space-y-1">
                  <div className="flex items-center gap-1.5">
                    <span
                      style={{ backgroundColor: cfg.color }}
                      className="w-2 h-2 rounded-full flex-shrink-0"
                    />
                    <span className="text-[13px] font-extrabold text-white truncate">
                      {cfg.name}
                    </span>
                  </div>

                  <div className="text-[11px] font-semibold text-zinc-300">
                    {prog.completedChapters}/{prog.totalChapters}{' '}
                    <span className="text-zinc-500 font-medium">ch</span>
                  </div>

                  <div className="text-[10px] font-medium text-zinc-400 truncate">
                    {prog.activeChapters > 0
                      ? `${prog.activeChapters} in progress`
                      : prog.completedChapters > 0
                      ? 'All started done'
                      : 'Tap to track'}
                  </div>
                </div>

                {/* Right Circular Progress Bar */}
                <div className="relative w-[52px] h-[52px] flex-shrink-0 flex items-center justify-center">
                  <svg className="w-[52px] h-[52px] -rotate-90" viewBox="0 0 52 52">
                    {/* Background Track Circle */}
                    <circle
                      cx="26"
                      cy="26"
                      r={radius}
                      fill="none"
                      stroke="#23232e"
                      strokeWidth="4.5"
                    />
                    {/* Animated Progress Ring */}
                    <circle
                      cx="26"
                      cy="26"
                      r={radius}
                      fill="none"
                      stroke={cfg.color}
                      strokeWidth="4.5"
                      strokeLinecap="round"
                      strokeDasharray={circumference}
                      strokeDashoffset={strokeDashoffset}
                      className="transition-all duration-500 ease-out"
                    />
                  </svg>
                  <span className="absolute text-[11px] font-extrabold text-white tracking-tight">
                    {prog.percent}%
                  </span>
                </div>
              </button>
          );
        })}
      </div>

      {/* Subject Stats Tiles */}
      <div className="grid grid-cols-3 gap-2">
        <div className="p-2.5 rounded-xl border border-zinc-800/80 bg-zinc-900/40 text-center">
          <div className="text-xl font-extrabold text-emerald-400 leading-none">
            {subjectStats.done}
          </div>
          <div className="text-[10px] text-zinc-400 uppercase font-semibold mt-1">Done</div>
        </div>
        <div className="p-2.5 rounded-xl border border-zinc-800/80 bg-zinc-900/40 text-center">
          <div className="text-xl font-extrabold text-amber-400 leading-none">
            {subjectStats.partial}
          </div>
          <div className="text-[10px] text-zinc-400 uppercase font-semibold mt-1">Partial</div>
        </div>
        <div className="p-2.5 rounded-xl border border-zinc-800/80 bg-zinc-900/40 text-center">
          <div className="text-xl font-extrabold text-zinc-400 leading-none">
            {subjectStats.pending}
          </div>
          <div className="text-[10px] text-zinc-400 uppercase font-semibold mt-1">Pending</div>
        </div>
      </div>

      {/* Quick Mark Accordion */}
      <div className="rounded-2xl border border-zinc-800 bg-zinc-900/40 overflow-hidden">
        <button
          onClick={() => setShowQuickMark(!showQuickMark)}
          className="w-full px-3.5 py-2.5 flex items-center justify-between text-xs font-semibold text-zinc-300 hover:text-white transition-colors"
        >
          <div className="flex items-center gap-1.5">
            <span className="text-amber-400">⚡</span>
            <span>Quick Mark Batch Action</span>
          </div>
          <span className="text-zinc-400 text-xs">
            {showQuickMark ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </span>
        </button>

        {showQuickMark && (
          <div className="px-3.5 pb-3 pt-1 border-t border-zinc-800/80 space-y-2.5 text-xs">
            <div className="flex flex-wrap items-center gap-2 text-zinc-300">
              <span>Set</span>
              <select
                value={quickMarkMaterial || 'Lectures'}
                onChange={(e) => setQuickMarkMaterial(e.target.value)}
                className="bg-zinc-950 border border-zinc-700 rounded-lg px-2.5 py-1 text-white text-xs focus:outline-none focus:border-orange-500"
              >
                {allSubjectMaterials.map((m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))}
              </select>
              <span>
                in all <strong className="text-white">{currentStartedChapters.length}</strong> started{' '}
                {config.name} chapters:
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => handleQuickMarkGo('done')}
                className="px-3 py-1.5 rounded-full text-xs font-bold bg-emerald-950/80 border border-emerald-600/70 text-emerald-300 hover:bg-emerald-900 transition-colors"
              >
                ✓ Set All Done
              </button>
              <button
                onClick={() => handleQuickMarkGo('pending')}
                className="px-3 py-1.5 rounded-full text-xs font-bold bg-zinc-800 border border-zinc-700 text-zinc-300 hover:bg-zinc-700 transition-colors"
              >
                ○ Reset to Pending
              </button>
            </div>

            <p className="text-[10px] text-zinc-500">
              Only started chapters change. Action has instant 10s undo protection.
            </p>
          </div>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder={`Search ${config.chapters.length} ${config.name} chapters...`}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-zinc-700"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as any)}
          className="bg-zinc-900 border border-zinc-800 rounded-xl px-2.5 py-1.5 text-xs text-zinc-300 focus:outline-none focus:border-zinc-700"
        >
          <option value="all">All Chapters</option>
          <option value="started">Started</option>
          <option value="unstarted">Unstarted</option>
          <option value="completed">Completed</option>
        </select>
      </div>

      {/* Chapter Cards List */}
      <div className="space-y-2">
        {filteredChapters.map((chapter) => {
          const started = isChapterStarted(startedStore, currentSubject, chapter);
          const isOpen = !!openChapters[chapter];

          if (!started) {
            return (
              <div
                key={chapter}
                className="p-3 rounded-2xl border border-zinc-800/60 bg-zinc-950/40 flex items-center justify-between gap-3 text-xs opacity-75 hover:opacity-100 transition-opacity"
              >
                <span className="font-medium text-zinc-400 line-clamp-1">{chapter}</span>
                <button
                  onClick={() => onStartChapter(currentSubject, chapter)}
                  className="px-3 py-1 rounded-full text-xs font-semibold bg-orange-500/10 border border-orange-500/40 text-orange-400 hover:bg-orange-500/20 whitespace-nowrap transition-colors flex items-center gap-1"
                >
                  <Plus className="w-3 h-3" /> Start
                </button>
              </div>
            );
          }

          // Compute chapter completed materials count (including Lectures & sub-items)
          const chMaterials = getChapterMaterials(currentSubject, chapter);
          const chBaseMaterials = getChapterBaseMaterials(currentSubject, chapter);
          const doneMats = chMaterials.filter(
            (m) =>
              getMaterialProgress(currentSubject, chapter, m, statusStore, subItemStore).status ===
              'done'
          ).length;
          const isAllCompleted = doneMats === chMaterials.length;

          return (
            <div
              key={chapter}
              className="rounded-2xl border border-zinc-800 bg-zinc-900/60 overflow-hidden shadow-sm"
            >
              {/* Chapter Header */}
              <div
                onClick={() => toggleChapterOpen(chapter)}
                className="px-3.5 py-3 flex items-center justify-between gap-3 cursor-pointer hover:bg-zinc-800/30 transition-colors"
              >
                <div className="flex items-center gap-2 min-w-0">
                  <span className="text-xs font-semibold text-white truncate">{chapter}</span>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                      isAllCompleted
                        ? 'bg-emerald-950/80 border-emerald-500/80 text-emerald-300'
                        : 'bg-zinc-800 border-zinc-700 text-zinc-400'
                    }`}
                  >
                    {doneMats}/{chMaterials.length}
                  </span>
                  <ChevronDown
                    className={`w-3.5 h-3.5 text-zinc-500 transition-transform duration-200 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </div>
              </div>

              {/* Chapter Body */}
              {isOpen && (
                <div className="px-3.5 pb-3 border-t border-zinc-800/60 divide-y divide-zinc-800/40 text-xs">
                  {/* Bulk chapter action bar */}
                  <div className="py-2 flex items-center justify-between gap-2">
                    <span className="text-[11px] text-zinc-400 font-medium">All materials:</span>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleBulkChapter(chapter, 'done')}
                        className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950/80 border border-emerald-600/60 text-emerald-300 hover:bg-emerald-900 transition-colors"
                      >
                        ✓ Done
                      </button>
                      <button
                        onClick={() => handleBulkChapter(chapter, 'pending')}
                        className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-zinc-800 border border-zinc-700 text-zinc-400 hover:bg-zinc-700 transition-colors"
                      >
                        ○ Reset
                      </button>
                    </div>
                  </div>

                  {/* 1. Lectures Row */}
                  {(() => {
                    const subKey = `${currentSubject}|${chapter}|Lectures`;
                    const isSubOpen = !!openSubs[subKey];
                    const items = getSubItems(currentSubject, chapter, 'Lectures');
                    const watchedCount = items.filter((x) => x.done).length;
                    const val = getMaterialProgress(
                      currentSubject,
                      chapter,
                      'Lectures',
                      statusStore,
                      subItemStore
                    ).status;

                    return (
                      <div className="py-2.5 space-y-2">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-medium text-zinc-200 flex items-center gap-1.5">
                            <span>🎬</span>
                            <span>Lectures</span>
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-orange-500/15 text-orange-300 border border-orange-500/30">
                              T1
                            </span>
                          </span>

                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => cycleStatus(currentSubject, chapter, 'Lectures')}
                              className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border transition-colors ${
                                val === 'done'
                                  ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300'
                                  : val === 'partial'
                                  ? 'bg-amber-950/80 border-amber-500 text-amber-300'
                                  : 'bg-zinc-800/80 border-zinc-700 text-zinc-400'
                              }`}
                            >
                              {val}
                            </button>
                            <button
                              onClick={() => toggleSubOpen(subKey)}
                              className="text-zinc-500 hover:text-zinc-300 p-0.5"
                              title="Toggle lecture ticks"
                            >
                              <ChevronDown
                                className={`w-3.5 h-3.5 transition-transform ${
                                  isSubOpen ? 'rotate-180' : ''
                                }`}
                              />
                            </button>
                          </div>
                        </div>

                        {/* Expandable Lecture Tracker */}
                        {isSubOpen && (
                          <div className="pl-3 border-l-2 border-zinc-800 space-y-2.5 pt-1">
                            {items.length === 0 ? (
                              <p className="text-[11px] text-zinc-500">
                                Set how many lectures there are to tick them off individually.
                              </p>
                            ) : (
                              <>
                                <div className="flex items-center gap-2">
                                  <span
                                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                                      watchedCount === items.length
                                        ? 'bg-emerald-950 border-emerald-500 text-emerald-300'
                                        : 'bg-zinc-800 border-zinc-700 text-zinc-400'
                                    }`}
                                  >
                                    {watchedCount}/{items.length} watched
                                  </span>
                                  {watchedCount < items.length && (
                                    <button
                                      type="button"
                                      onClick={() => onOpenBacklogWithFilter?.('L')}
                                      className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-950/80 border border-amber-500/80 text-amber-300 hover:bg-amber-900/80 transition-colors cursor-pointer"
                                      title="Review lecture backlog flashcards"
                                    >
                                      backlog {items.length - watchedCount}
                                    </button>
                                  )}
                                </div>

                                {/* Lecture numbered bubbles */}
                                <div className="grid grid-cols-6 sm:grid-cols-10 gap-1.5">
                                  {items.map((lec, idx) => (
                                    <button
                                      key={idx}
                                      onClick={() =>
                                        handleToggleTick(currentSubject, chapter, 'Lectures', idx)
                                      }
                                      className={`h-7 rounded-lg text-xs font-bold border transition-all ${
                                        lec.done
                                          ? 'bg-emerald-950 border-emerald-500 text-emerald-300 shadow-sm'
                                          : 'bg-zinc-950 border-zinc-800 text-zinc-500 hover:border-zinc-700'
                                      }`}
                                    >
                                      {idx + 1}
                                    </button>
                                  ))}
                                </div>

                                <div className="flex gap-2">
                                  <button
                                    onClick={() =>
                                      handleAllTicks(currentSubject, chapter, 'Lectures', true)
                                    }
                                    className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-950 border border-emerald-600 text-emerald-300 hover:bg-emerald-900"
                                  >
                                    ✓ All watched
                                  </button>
                                  <button
                                    onClick={() =>
                                      handleAllTicks(currentSubject, chapter, 'Lectures', false)
                                    }
                                    className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-zinc-800 border border-zinc-700 text-zinc-400 hover:bg-zinc-700"
                                  >
                                    ○ Reset ticks
                                  </button>
                                </div>
                              </>
                            )}

                            {/* Set Count Input */}
                            <div className="flex gap-1.5 max-w-xs pt-1">
                              <input
                                type="number"
                                min="1"
                                max="150"
                                placeholder={
                                  items.length ? 'Change lecture count' : 'Total lectures (e.g. 14)'
                                }
                                value={countInputs[subKey] || ''}
                                onChange={(e) =>
                                  setCountInputs((prev) => ({ ...prev, [subKey]: e.target.value }))
                                }
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') {
                                    handleSetCount(currentSubject, chapter, 'Lectures');
                                  }
                                }}
                                className="flex-1 bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-purple-500"
                              />
                              <button
                                onClick={() => handleSetCount(currentSubject, chapter, 'Lectures')}
                                className="px-3 py-1 rounded-lg bg-purple-700 text-white font-semibold text-xs hover:bg-purple-600 transition-colors"
                              >
                                Set
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })()}

                  {/* 2. DPP Row (With count & bubble grid) */}
                  {(() => {
                    const subKey = `${currentSubject}|${chapter}|DPP`;
                    const isSubOpen = !!openSubs[subKey];
                    const items = getSubItems(currentSubject, chapter, 'DPP');
                    const doneCount = items.filter((x) => x.done).length;
                    const val = getMaterialProgress(
                      currentSubject,
                      chapter,
                      'DPP',
                      statusStore,
                      subItemStore
                    ).status;

                    return (
                      <div className="py-2.5 space-y-2">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-medium text-zinc-200 flex items-center gap-1.5">
                            <span>DPP</span>
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-orange-500/15 text-orange-300 border border-orange-500/30">
                              T1
                            </span>
                          </span>
                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => cycleStatus(currentSubject, chapter, 'DPP')}
                              className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border transition-colors ${
                                val === 'done'
                                  ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300'
                                  : val === 'partial'
                                  ? 'bg-amber-950/80 border-amber-500 text-amber-300'
                                  : 'bg-zinc-800/80 border-zinc-700 text-zinc-400'
                              }`}
                            >
                              {val}
                            </button>
                            <button
                              onClick={() => toggleSubOpen(subKey)}
                              className="text-zinc-500 hover:text-zinc-300 p-0.5"
                              title="Toggle DPP ticks"
                            >
                              <ChevronDown
                                className={`w-3.5 h-3.5 transition-transform ${
                                  isSubOpen ? 'rotate-180' : ''
                                }`}
                              />
                            </button>
                          </div>
                        </div>

                        {/* Expandable DPP Tracker */}
                        {isSubOpen && (
                          <div className="pl-3 border-l-2 border-zinc-800 space-y-2.5 pt-1">
                            {items.length === 0 ? (
                              <p className="text-[11px] text-zinc-500">
                                Set how many DPPs there are to tick them off one by one.
                              </p>
                            ) : (
                              <>
                                <div className="flex items-center gap-2">
                                  <span
                                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                                      doneCount === items.length
                                        ? 'bg-emerald-950 border-emerald-500 text-emerald-300'
                                        : 'bg-zinc-800 border-zinc-700 text-zinc-400'
                                    }`}
                                  >
                                    {doneCount}/{items.length} DPP done
                                  </span>
                                  {doneCount < items.length && (
                                    <button
                                      type="button"
                                      onClick={() => onOpenBacklogWithFilter?.('M')}
                                      className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-950/80 border border-amber-500/80 text-amber-300 hover:bg-amber-900/80 transition-colors cursor-pointer"
                                      title="Review material backlog flashcards"
                                    >
                                      backlog {items.length - doneCount}
                                    </button>
                                  )}
                                </div>

                                <div className="grid grid-cols-6 sm:grid-cols-10 gap-1.5">
                                  {items.map((dpp, idx) => (
                                    <button
                                      key={idx}
                                      onClick={() =>
                                        handleToggleTick(currentSubject, chapter, 'DPP', idx)
                                      }
                                      className={`h-7 rounded-lg text-xs font-bold border transition-all ${
                                        dpp.done
                                          ? 'bg-emerald-950 border-emerald-500 text-emerald-300 shadow-sm'
                                          : 'bg-zinc-950 border-zinc-800 text-zinc-500 hover:border-zinc-700'
                                      }`}
                                    >
                                      {idx + 1}
                                    </button>
                                  ))}
                                </div>

                                <div className="flex gap-2">
                                  <button
                                    onClick={() => handleAllTicks(currentSubject, chapter, 'DPP', true)}
                                    className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-950 border border-emerald-600 text-emerald-300 hover:bg-emerald-900"
                                  >
                                    ✓ All done
                                  </button>
                                  <button
                                    onClick={() =>
                                      handleAllTicks(currentSubject, chapter, 'DPP', false)
                                    }
                                    className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-zinc-800 border border-zinc-700 text-zinc-400 hover:bg-zinc-700"
                                  >
                                    ○ Reset ticks
                                  </button>
                                </div>
                              </>
                            )}

                            {/* Set Count Input */}
                            <div className="flex gap-1.5 max-w-xs pt-1">
                              <input
                                type="number"
                                min="1"
                                max="150"
                                placeholder={
                                  items.length ? 'Change DPP count' : 'Total DPP count (e.g. 10)'
                                }
                                value={countInputs[subKey] || ''}
                                onChange={(e) =>
                                  setCountInputs((prev) => ({ ...prev, [subKey]: e.target.value }))
                                }
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') {
                                    handleSetCount(currentSubject, chapter, 'DPP');
                                  }
                                }}
                                className="flex-1 bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-orange-500"
                              />
                              <button
                                onClick={() => handleSetCount(currentSubject, chapter, 'DPP')}
                                className="px-3 py-1 rounded-lg bg-orange-600 text-white font-semibold text-xs hover:bg-orange-500 transition-colors"
                              >
                                Set
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })()}

                  {/* 3. KPP Practice Sheet (Physics special customizable sheet list) */}
                  {currentSubject === 'phy' && (
                    <div className="py-2.5 space-y-2">
                      {(() => {
                        const mat = 'KPP Practice Sheet';
                        const subKey = `phy|${chapter}|${mat}`;
                        const isSubOpen = !!openSubs[subKey];
                        const items = getSubItems('phy', chapter, mat);
                        const val = getMaterialProgress(
                          'phy',
                          chapter,
                          mat,
                          statusStore,
                          subItemStore
                        ).status;

                        return (
                          <>
                            <div className="flex items-center justify-between gap-2">
                              <span className="font-medium text-zinc-200 flex items-center gap-1.5">
                                <span>{mat}</span>
                                <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-orange-500/15 text-orange-300 border border-orange-500/30">
                                  T1
                                </span>
                              </span>
                              <div className="flex items-center gap-1.5">
                                <button
                                  onClick={() => cycleStatus('phy', chapter, mat)}
                                  className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border transition-colors ${
                                    val === 'done'
                                      ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300'
                                      : val === 'partial'
                                      ? 'bg-amber-950/80 border-amber-500 text-amber-300'
                                      : 'bg-zinc-800/80 border-zinc-700 text-zinc-400'
                                  }`}
                                >
                                  {val}
                                </button>
                                <button
                                  onClick={() => toggleSubOpen(subKey)}
                                  className="text-zinc-500 hover:text-zinc-300 p-0.5"
                                  title="Add or manage KPP sheets"
                                >
                                  <ChevronDown
                                    className={`w-3.5 h-3.5 transition-transform ${
                                      isSubOpen ? 'rotate-180' : ''
                                    }`}
                                  />
                                </button>
                              </div>
                            </div>

                            {isSubOpen && (
                              <div className="pl-3 border-l-2 border-zinc-800 space-y-2 pt-1">
                                {items.map((sub, idx) => (
                                  <div
                                    key={idx}
                                    className="flex items-center justify-between gap-2 py-0.5"
                                  >
                                    <span className="text-zinc-300 text-xs truncate">{sub.name}</span>
                                    <div className="flex items-center gap-1.5">
                                      <button
                                        onClick={() =>
                                          handleToggleCustomSubItem('phy', chapter, mat, idx)
                                        }
                                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold border transition-colors ${
                                          sub.done
                                            ? 'bg-emerald-950 border-emerald-500 text-emerald-300'
                                            : 'bg-zinc-800 border-zinc-700 text-zinc-400'
                                        }`}
                                      >
                                        {sub.done ? 'done' : 'pending'}
                                      </button>
                                      <button
                                        onClick={() =>
                                          handleDeleteCustomSubItem('phy', chapter, mat, idx)
                                        }
                                        className="text-zinc-600 hover:text-rose-400 p-0.5"
                                        title="Delete sheet"
                                      >
                                        <Trash2 className="w-3 h-3" />
                                      </button>
                                    </div>
                                  </div>
                                ))}

                                <div className="flex gap-1.5 max-w-xs pt-1">
                                  <input
                                    type="text"
                                    placeholder="e.g. KPP 25 or Part 2"
                                    value={subItemInputs[subKey] || ''}
                                    onChange={(e) =>
                                      setSubItemInputs((prev) => ({
                                        ...prev,
                                        [subKey]: e.target.value,
                                      }))
                                    }
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter') {
                                        handleAddCustomSubItem('phy', chapter, mat);
                                      }
                                    }}
                                    className="flex-1 bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-indigo-500"
                                  />
                                  <button
                                    onClick={() => handleAddCustomSubItem('phy', chapter, mat)}
                                    className="px-3 py-1 rounded-lg bg-indigo-600 text-white font-semibold text-xs hover:bg-indigo-500 transition-colors"
                                  >
                                    + Add
                                  </button>
                                </div>
                              </div>
                            )}
                          </>
                        );
                      })()}
                    </div>
                  )}

                  {/* 4. Other Materials (Sorted by Priority Tier: Tier 2 -> Tier 3) */}
                  {[...chBaseMaterials]
                    .filter((m) => m !== 'DPP' && (currentSubject !== 'phy' || m !== 'KPP Practice Sheet'))
                    .sort((a, b) => getMaterialPriority(a).rank - getMaterialPriority(b).rank)
                    .map((material) => {
                      const matKey = makeStatusKey(currentSubject, chapter, material);
                      const val = statusStore[matKey] || 'pending';
                      const prio = getMaterialPriority(material);

                      return (
                        <div
                          key={material}
                          className="py-2.5 flex items-center justify-between gap-2"
                        >
                          <span className="font-medium text-zinc-300 flex items-center gap-1.5">
                            <span>{material}</span>
                            <span
                              className={`px-1.5 py-0.2 rounded text-[9px] font-bold border ${
                                prio.tier === 1
                                  ? 'bg-orange-500/15 text-orange-300 border-orange-500/30'
                                  : prio.tier === 2
                                  ? 'bg-purple-500/15 text-purple-300 border-purple-500/30'
                                  : 'bg-zinc-800/80 text-zinc-400 border-zinc-700/60'
                              }`}
                            >
                              T{prio.tier}
                            </span>
                          </span>
                          <button
                            onClick={() => cycleStatus(currentSubject, chapter, material)}
                            className={`px-3 py-1 rounded-full text-xs font-bold border transition-colors ${
                              val === 'done'
                                ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300 shadow-sm'
                                : val === 'partial'
                                ? 'bg-amber-950/80 border-amber-500 text-amber-300'
                                : 'bg-zinc-800/80 border-zinc-700 text-zinc-400 hover:text-zinc-200'
                            }`}
                          >
                            {val}
                          </button>
                        </div>
                      );
                    })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
