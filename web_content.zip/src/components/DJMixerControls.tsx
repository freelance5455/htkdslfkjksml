/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Sliders, Activity, RefreshCw } from 'lucide-react';
import { audioEngine } from '../services/audioEngine';
import { EQState } from '../types';

interface DJMixerControlsProps {
  eq: EQState;
  onEQChange: (eq: EQState) => void;
  crossfader: number;
  onCrossfaderChange: (val: number) => void;
  bpm: number;
}

export const DJMixerControls: React.FC<DJMixerControlsProps> = ({
  eq,
  onEQChange,
  crossfader,
  onCrossfaderChange,
  bpm,
}) => {
  const [leftVu, setLeftVu] = useState(0);
  const [rightVu, setRightVu] = useState(0);

  // Poll VU levels at 60fps
  useEffect(() => {
    let animId: number;
    const updateVU = () => {
      setLeftVu(audioEngine.leftLevel);
      setRightVu(audioEngine.rightLevel);
      animId = requestAnimationFrame(updateVU);
    };
    animId = requestAnimationFrame(updateVU);
    return () => cancelAnimationFrame(animId);
  }, []);

  const handleLowChange = (val: number) => {
    const updated = { ...eq, low: val };
    onEQChange(updated);
    audioEngine.setEQ(updated);
  };

  const handleMidChange = (val: number) => {
    const updated = { ...eq, mid: val };
    onEQChange(updated);
    audioEngine.setEQ(updated);
  };

  const handleHighChange = (val: number) => {
    const updated = { ...eq, high: val };
    onEQChange(updated);
    audioEngine.setEQ(updated);
  };

  const handleFilterChange = (val: number) => {
    const updated = { ...eq, filter: val };
    onEQChange(updated);
    audioEngine.setEQ(updated);
  };

  const resetEQ = () => {
    const neutral: EQState = { low: 0, mid: 0, high: 0, filter: 0 };
    onEQChange(neutral);
    audioEngine.setEQ(neutral);
  };

  const ledCount = 10;

  return (
    <div className="p-4 rounded-3xl bg-[#0d0e18]/95 border border-purple-500/30 shadow-[0_10px_35px_rgba(0,0,0,0.8)]">
      {/* Header */}
      <div className="flex items-center justify-between mb-4 pb-2 border-b border-purple-500/20">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-purple-400" />
          <span className="text-[12px] font-bold tracking-widest text-purple-300 font-dj uppercase">
            STUDIO DJ MIXER &amp; EQ
          </span>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-zinc-800/80 border border-zinc-700">
            <Activity className="w-3 h-3 text-cyan-400 animate-pulse" />
            <span className="text-[11px] font-mono font-bold text-cyan-300">{bpm} BPM</span>
          </div>
          <button
            onClick={resetEQ}
            className="p-1 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
            title="Reset All EQ to Neutral"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-4 items-center">
        {/* 3-Band Rotary EQ Strip (Columns 1-7) */}
        <div className="col-span-8 grid grid-cols-3 gap-2">
          
          {/* HIGH / TREBLE */}
          <div className="flex flex-col items-center p-2 rounded-xl bg-zinc-900/60 border border-zinc-800">
            <span className="text-[10px] font-bold text-cyan-400 mb-1 font-dj">HI</span>
            <input
              type="range"
              min="-12"
              max="12"
              step="1"
              value={eq.high}
              onChange={(e) => handleHighChange(parseFloat(e.target.value))}
              className="w-full dj-slider cursor-pointer"
            />
            <span className="text-[10px] font-mono text-zinc-400 mt-1">
              {eq.high > 0 ? `+${eq.high}dB` : `${eq.high}dB`}
            </span>
          </div>

          {/* MID */}
          <div className="flex flex-col items-center p-2 rounded-xl bg-zinc-900/60 border border-zinc-800">
            <span className="text-[10px] font-bold text-purple-400 mb-1 font-dj">MID</span>
            <input
              type="range"
              min="-12"
              max="12"
              step="1"
              value={eq.mid}
              onChange={(e) => handleMidChange(parseFloat(e.target.value))}
              className="w-full dj-slider cursor-pointer"
            />
            <span className="text-[10px] font-mono text-zinc-400 mt-1">
              {eq.mid > 0 ? `+${eq.mid}dB` : `${eq.mid}dB`}
            </span>
          </div>

          {/* LOW / BASS */}
          <div className="flex flex-col items-center p-2 rounded-xl bg-zinc-900/60 border border-zinc-800">
            <span className="text-[10px] font-bold text-red-400 mb-1 font-dj">LOW</span>
            <input
              type="range"
              min="-12"
              max="12"
              step="1"
              value={eq.low}
              onChange={(e) => handleLowChange(parseFloat(e.target.value))}
              className="w-full dj-slider cursor-pointer"
            />
            <span className="text-[10px] font-mono text-zinc-400 mt-1">
              {eq.low > 0 ? `+${eq.low}dB` : `${eq.low}dB`}
            </span>
          </div>

          {/* DJ FILTER SWEEP (Full width under the 3 EQs) */}
          <div className="col-span-3 flex flex-col items-center p-2.5 rounded-xl bg-gradient-to-r from-cyan-950/30 via-zinc-900/80 to-purple-950/30 border border-zinc-700/60 mt-1">
            <div className="w-full flex items-center justify-between mb-1 px-1">
              <span className="text-[9px] font-bold text-cyan-400 tracking-wider">LPF (BASS)</span>
              <span className="text-[10px] font-bold text-white font-dj">DJ FILTER SWEEP</span>
              <span className="text-[9px] font-bold text-purple-400 tracking-wider">HPF (SIZZLE)</span>
            </div>
            <input
              type="range"
              min="-100"
              max="100"
              step="2"
              value={eq.filter}
              onChange={(e) => handleFilterChange(parseFloat(e.target.value))}
              className="w-full dj-slider cursor-pointer"
            />
            <div className="w-full flex justify-between text-[9px] font-mono text-zinc-400 mt-1">
              <span>-100</span>
              <span className={eq.filter === 0 ? 'text-cyan-400 font-bold' : ''}>
                {eq.filter === 0 ? 'CENTER 0' : eq.filter > 0 ? `+${eq.filter}` : eq.filter}
              </span>
              <span>+100</span>
            </div>
          </div>

        </div>

        {/* Dual LED Peak VU Meters (Columns 9-12) */}
        <div className="col-span-4 flex items-center justify-center gap-3 p-3 rounded-2xl bg-black/60 border border-zinc-800">
          
          {/* Left Meter */}
          <div className="flex flex-col items-center gap-1">
            <div className="flex flex-col-reverse gap-0.5">
              {Array.from({ length: ledCount }).map((_, i) => {
                const threshold = (i + 1) / ledCount;
                const isLit = leftVu >= threshold;
                let colorClass = 'bg-zinc-800';
                if (isLit) {
                  if (i >= 8) colorClass = 'bg-red-500 shadow-[0_0_8px_#ff0055]';
                  else if (i >= 6) colorClass = 'bg-amber-400 shadow-[0_0_6px_#ffaa00]';
                  else colorClass = 'bg-cyan-400 shadow-[0_0_6px_#00f0ff]';
                }
                return <div key={i} className={`w-3.5 h-1.5 rounded-xs transition-colors duration-75 ${colorClass}`} />;
              })}
            </div>
            <span className="text-[9px] font-bold font-mono text-cyan-300">L</span>
          </div>

          {/* Center DB Markings */}
          <div className="flex flex-col justify-between h-[82px] text-[8px] font-mono text-zinc-500 py-0.5 text-center">
            <span className="text-red-400 font-bold">+3</span>
            <span>0</span>
            <span>-6</span>
            <span>-12</span>
            <span>-24</span>
          </div>

          {/* Right Meter */}
          <div className="flex flex-col items-center gap-1">
            <div className="flex flex-col-reverse gap-0.5">
              {Array.from({ length: ledCount }).map((_, i) => {
                const threshold = (i + 1) / ledCount;
                const isLit = rightVu >= threshold;
                let colorClass = 'bg-zinc-800';
                if (isLit) {
                  if (i >= 8) colorClass = 'bg-red-500 shadow-[0_0_8px_#ff0055]';
                  else if (i >= 6) colorClass = 'bg-amber-400 shadow-[0_0_6px_#ffaa00]';
                  else colorClass = 'bg-purple-400 shadow-[0_0_6px_#b026ff]';
                }
                return <div key={i} className={`w-3.5 h-1.5 rounded-xs transition-colors duration-75 ${colorClass}`} />;
              })}
            </div>
            <span className="text-[9px] font-bold font-mono text-purple-300">R</span>
          </div>

        </div>
      </div>

      {/* Crossfader Section */}
      <div className="mt-4 pt-3 border-t border-purple-500/20">
        <div className="flex items-center justify-between text-[10px] font-bold font-dj uppercase mb-1.5 px-1">
          <span className="text-cyan-400">DECK A (MASTER)</span>
          <span className="text-zinc-400 tracking-widest">CROSSFADER</span>
          <span className="text-purple-400">DECK B (FX)</span>
        </div>
        <div className="relative flex items-center px-2">
          <input
            type="range"
            min="-1"
            max="1"
            step="0.05"
            value={crossfader}
            onChange={(e) => onCrossfaderChange(parseFloat(e.target.value))}
            className="w-full dj-slider cursor-pointer"
          />
        </div>
        <div className="flex justify-between text-[9px] font-mono text-zinc-500 px-2 mt-1">
          <span>A 100%</span>
          <span className={crossfader === 0 ? 'text-white font-bold' : ''}>CENTER</span>
          <span>B 100%</span>
        </div>
      </div>

    </div>
  );
};
