import React, { useState } from 'react';
import { Confession } from '../types';
import { useApp } from '../context/AppContext';
import { formatTimeAgo } from '../utils/security';
import { 
  Flame, 
  ThumbsDown, 
  MessageSquare, 
  Share2, 
  Bookmark, 
  AlertTriangle, 
  Sparkles, 
  Send, 
  Lock,
  MessageCircle,
  Eye
} from 'lucide-react';

interface Props {
  confession: Confession;
}

const CATEGORY_COLORS: Record<string, { label: string; text: string; bg: string }> = {
  love: { label: 'Love & Crush', text: 'text-pink-400', bg: 'bg-pink-500/10 border-pink-500/30' },
  funny: { label: 'Campus Humor', text: 'text-amber-400', bg: 'bg-amber-500/10 border-amber-500/30' },
  stress: { label: 'Exam & Stress', text: 'text-indigo-400', bg: 'bg-indigo-500/10 border-indigo-500/30' },
  secret: { label: 'Deep Secret', text: 'text-cyan-400', bg: 'bg-cyan-500/10 border-cyan-500/30' },
  campus: { label: 'Campus Life', text: 'text-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/30' },
  hottake: { label: 'Hot Take', text: 'text-rose-400', bg: 'bg-rose-500/10 border-rose-500/30' },
};

export const ConfessionCard: React.FC<Props> = ({ confession }) => {
  const { 
    likeConfession, 
    dislikeConfession, 
    bookmarkConfession, 
    addComment, 
    setShareTargetConfession, 
    setIsShareModalOpen,
    setReportTargetConfession,
    setIsReportModalOpen,
    setActiveWhisperPartner,
    setIsDirectWhisperModalOpen,
  } = useApp();

  const [showComments, setShowComments] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [commentError, setCommentError] = useState('');
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);

  const categoryInfo = CATEGORY_COLORS[confession.category] || CATEGORY_COLORS.secret;

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    setIsSubmittingComment(true);
    setCommentError('');
    const res = addComment(confession.id, newComment);
    setIsSubmittingComment(false);

    if (res.success) {
      setNewComment('');
    } else {
      setCommentError(res.message);
    }
  };

  const handleOpenDirectWhisper = () => {
    setActiveWhisperPartner({
      confessionId: confession.id,
      authorName: confession.authorAvatarName,
      authorEmoji: confession.authorAvatarEmoji,
      snippet: confession.content.slice(0, 80) + '...',
    });
    setIsDirectWhisperModalOpen(true);
  };

  const handleShareClick = () => {
    setShareTargetConfession(confession);
    setIsShareModalOpen(true);
  };

  const handleReportClick = () => {
    setReportTargetConfession(confession);
    setIsReportModalOpen(true);
  };

  return (
    <div className={`relative bg-slate-900/70 border rounded-2xl p-4 sm:p-5 transition-all duration-300 ${
      confession.isBoosted 
        ? 'border-cyan-500/60 shadow-lg shadow-cyan-500/15 bg-gradient-to-b from-cyan-950/20 to-slate-900/90' 
        : 'border-slate-800 hover:border-slate-700/80 shadow-sm'
    }`}>
      
      {/* Boosted indicator banner if featured */}
      {confession.isBoosted && (
        <div className="flex items-center gap-1.5 mb-2.5 text-[11px] font-medium text-cyan-300">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin" style={{ animationDuration: '6s' }} />
          <span>Super-Charged Whisper (Boosted)</span>
        </div>
      )}

      {/* Card Header: Avatar Persona + Metadata */}
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-slate-800/90 border border-slate-700/80 flex items-center justify-center text-xl shadow-inner shrink-0">
            {confession.authorAvatarEmoji}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-sm text-slate-100">
                {confession.authorAvatarName}
              </span>
              <span 
                className="text-[10px] font-mono text-slate-500 tracking-wider hover:text-slate-300 transition-colors cursor-help"
                title="Cryptographic zero-knowledge hash. Identity is masked from admins."
              >
                {confession.authorHash}
              </span>
            </div>
            
            {/* Unboxed Metadata with typographic dots */}
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <span className={categoryInfo.text}>{categoryInfo.label}</span>
              <span aria-hidden="true">·</span>
              <span>{formatTimeAgo(confession.timestamp)}</span>
              <span aria-hidden="true">·</span>
              <span className="text-slate-300 truncate max-w-[120px]">
                {confession.isCampusOnly ? `🔒 ${confession.collegeName.split(' ')[0]}` : confession.collegeName.split(' ')[0]}
              </span>
            </div>
          </div>
        </div>

        {/* Report Menu */}
        <button
          onClick={handleReportClick}
          className="text-slate-500 hover:text-rose-400 p-1 rounded-lg transition-colors"
          title="Report inappropriate content"
        >
          <AlertTriangle className="w-4 h-4" />
        </button>
      </div>

      {/* Confession Body with optional preset background */}
      <div className="my-3">
        <p className="text-slate-200 text-sm sm:text-base leading-relaxed tracking-normal whitespace-pre-wrap font-sans">
          {confession.content}
        </p>
      </div>

      {/* Card Stats & Action Bar */}
      <div className="flex items-center justify-between pt-3 mt-2 border-t border-slate-800/70 text-slate-400 text-xs">
        
        {/* Left: Like / Dislike */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => likeConfession(confession.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-all ${
              confession.userLiked 
                ? 'bg-rose-500/20 border-rose-500/50 text-rose-300 shadow-sm shadow-rose-500/20' 
                : 'bg-slate-800/60 border-slate-800 hover:border-slate-700 text-slate-300'
            }`}
          >
            <Flame className={`w-4 h-4 ${confession.userLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
            <span className="font-semibold tabular-nums">{confession.likes}</span>
          </button>

          <button
            onClick={() => dislikeConfession(confession.id)}
            className={`p-1.5 rounded-lg border transition-all ${
              confession.userDisliked 
                ? 'bg-slate-700/60 border-slate-600 text-slate-200' 
                : 'bg-slate-800/40 border-slate-800 hover:border-slate-700 text-slate-500 hover:text-slate-300'
            }`}
            title="Downvote"
          >
            <ThumbsDown className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Right: Comments, Anonymous DM, Share, Bookmark */}
        <div className="flex items-center gap-1">
          
          {/* Comments Toggle */}
          <button
            onClick={() => setShowComments(!showComments)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border transition-all ${
              showComments 
                ? 'bg-cyan-500/10 border-cyan-500/40 text-cyan-300' 
                : 'bg-slate-800/50 border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span className="tabular-nums font-medium">{confession.commentsCount}</span>
          </button>

          {/* Anonymous DM / Direct Whisper */}
          <button
            onClick={handleOpenDirectWhisper}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-indigo-950/40 border border-indigo-900/60 hover:border-indigo-700 text-indigo-300 transition-all"
            title="Direct Anonymous Whisper"
          >
            <MessageCircle className="w-3.5 h-3.5 text-indigo-400" />
            <span className="text-[11px] hidden sm:inline">Whisper</span>
          </button>

          {/* Share as Aesthetic Story Card */}
          <button
            onClick={handleShareClick}
            className="p-1.5 rounded-lg bg-slate-800/50 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-200 transition-all"
            title="Share as aesthetic card"
          >
            <Share2 className="w-3.5 h-3.5" />
          </button>

          {/* Bookmark */}
          <button
            onClick={() => bookmarkConfession(confession.id)}
            className={`p-1.5 rounded-lg border transition-all ${
              confession.isBookmarked 
                ? 'bg-amber-500/20 border-amber-500/50 text-amber-300' 
                : 'bg-slate-800/50 border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
            title="Save to bookmarks"
          >
            <Bookmark className={`w-3.5 h-3.5 ${confession.isBookmarked ? 'fill-amber-400 text-amber-400' : ''}`} />
          </button>

        </div>

      </div>

      {/* Inline Comments Section */}
      {showComments && (
        <div className="mt-4 pt-3 border-t border-slate-800/60 space-y-3">
          
          {/* New Comment Input */}
          <form onSubmit={handleCommentSubmit} className="space-y-1.5">
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Write an anonymous reply..."
                className="flex-1 bg-slate-950/80 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/20"
              />
              <button
                type="submit"
                disabled={isSubmittingComment || !newComment.trim()}
                className="px-3 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold disabled:opacity-50 transition-all flex items-center gap-1 shrink-0"
              >
                <Send className="w-3 h-3" />
                <span className="hidden xs:inline">Reply</span>
              </button>
            </div>
            {commentError && (
              <p className="text-[11px] text-rose-400">{commentError}</p>
            )}
          </form>

          {/* Existing Comments List */}
          {confession.comments.length === 0 ? (
            <p className="text-center py-3 text-xs text-slate-500">
              No replies yet. Be the first to whisper back anonymously!
            </p>
          ) : (
            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {confession.comments.map(c => (
                <div key={c.id} className="p-2.5 rounded-xl bg-slate-950/50 border border-slate-800/60 text-xs">
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                    <div className="flex items-center gap-1.5">
                      <span>{c.authorAvatarEmoji}</span>
                      <span className="font-semibold text-slate-300">{c.authorAvatarName}</span>
                      <span className="font-mono text-[9px] text-slate-600">{c.authorHash}</span>
                    </div>
                    <span>{formatTimeAgo(c.timestamp)}</span>
                  </div>
                  <p className="text-slate-200 text-xs pl-5">{c.content}</p>
                </div>
              ))}
            </div>
          )}

        </div>
      )}

    </div>
  );
};
