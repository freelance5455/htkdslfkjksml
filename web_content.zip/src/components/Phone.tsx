import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  store,
  useStore,
  levelOf,
  netWorth,
  clickReward,
  stamina,
  restMs,
  type PhoneApp,
} from "../lib/store";
import { CATALOG, itemById } from "../lib/catalog";
import { toFa } from "../lib/fa";
import { boop, fanfare } from "../lib/sound";
import { fmt } from "./Hud";
import { CoinIcon } from "./icons";
import { accentById, shapeRadius, wallpaperById } from "../lib/phoneOS";
import { ControlCentre, LockScreen, SettingsApp as OSSettings, StatusBar } from "./PhoneOS";
import {
  AparatApp,
  CrashApp,
  DataApp,
  MatchApp,
  StoreApp,
  VpnApp,
  fmtData,
} from "./PhoneApps";

/* ================================================================== */
/*  app registry                                                       */
/* ================================================================== */
type AppDef = { id: Exclude<PhoneApp, null>; name: string; emoji: string; tint: string };

/** pre-installed, always on the home screen */
const BUILTIN: AppDef[] = [
  { id: "store", name: "جیکو پلی", emoji: "🏪", tint: "linear-gradient(160deg,#6FE3A6,#21A179)" },
  { id: "data", name: "اینترنت", emoji: "📶", tint: "linear-gradient(160deg,#5EE7DF,#0E9AA7)" },
  { id: "wallet", name: "کیف پول", emoji: "💳", tint: "linear-gradient(160deg,#5AA9E6,#2C6FBB)" },
  { id: "shop", name: "فروشگاه", emoji: "🛍️", tint: "linear-gradient(160deg,#FFC93C,#F08A24)" },
  { id: "jobs", name: "شغل‌ها", emoji: "💼", tint: "linear-gradient(160deg,#7ED9A0,#2E9E63)" },
  { id: "stats", name: "آمار", emoji: "📊", tint: "linear-gradient(160deg,#C4A6FF,#7E52D8)" },
  { id: "camera", name: "دوربین", emoji: "📸", tint: "linear-gradient(160deg,#FF9AAE,#E0476B)" },
  { id: "chat", name: "پیام‌ها", emoji: "💬", tint: "linear-gradient(160deg,#8FE3D8,#2C9C8E)" },
  { id: "settings", name: "تنظیمات", emoji: "⚙️", tint: "linear-gradient(160deg,#B6BECB,#6C7684)" },
];

/** only appear once downloaded from جیکو پلی */
const DOWNLOADABLE: Record<string, AppDef> = {
  crash: { id: "crash", name: "انفجار", emoji: "🚀", tint: "linear-gradient(160deg,#FF7A59,#D7263D)" },
  match: { id: "match", name: "حدس مسابقات", emoji: "⚽", tint: "linear-gradient(160deg,#34D399,#059669)" },
  vpn: { id: "vpn", name: "جیکو VPN", emoji: "🛡️", tint: "linear-gradient(160deg,#818CF8,#4338CA)" },
  aparat: { id: "aparat", name: "آپارات", emoji: "🎬", tint: "linear-gradient(160deg,#F87171,#DC2626)" },
};

const ALL_APPS: AppDef[] = [...BUILTIN, ...Object.values(DOWNLOADABLE)];

/* ================================================================== */
/*  small building blocks (phone-sized)                                */
/* ================================================================== */
function Row({
  label,
  value,
  tint,
}: {
  label: string;
  value: string;
  tint?: string;
}) {
  return (
    <div className="flex items-center justify-between rounded-xl bg-white px-2.5 py-2 ring-1 ring-slate-900/8">
      <span className="text-[11px] font-bold text-slate-500">{label}</span>
      <span className="text-[12px] font-black tabular-nums" style={{ color: tint ?? "#0f172a" }}>
        {value}
      </span>
    </div>
  );
}

function PBtn({
  children,
  onClick,
  tone = "primary",
  disabled,
}: {
  children: ReactNode;
  onClick: () => void;
  tone?: "primary" | "ghost" | "danger";
  disabled?: boolean;
}) {
  const tones = {
    primary: "bg-gradient-to-b from-amber-400 to-amber-500 text-amber-950",
    ghost: "bg-slate-100 text-slate-700 ring-1 ring-slate-900/8",
    danger: "bg-gradient-to-b from-rose-500 to-rose-600 text-white",
  };
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={() => {
        if (disabled) return;
        boop();
        onClick();
      }}
      className={`w-full rounded-xl px-3 py-2 text-[11.5px] font-extrabold transition active:scale-[0.97] ${
        disabled ? "bg-slate-200 text-slate-400" : tones[tone]
      }`}
    >
      {children}
    </button>
  );
}

/* ================================================================== */
/*  APPS                                                               */
/* ================================================================== */
function WalletApp() {
  const points = useStore((s) => s.points);
  const bank = useStore((s) => s.bank);
  const loan = useStore((s) => s.loan);
  const worth = useStore(netWorth);
  const [amt, setAmt] = useState(100);

  return (
    <div className="flex flex-col gap-2">
      <div className="rounded-2xl bg-gradient-to-br from-sky-500 to-indigo-600 p-3 text-white">
        <div className="text-[9.5px] font-bold opacity-80">موجودی کل</div>
        <div className="text-2xl font-black tabular-nums">{toFa(worth)}</div>
        <div className="mt-1.5 flex justify-between text-[9.5px] font-bold opacity-85">
          <span>جیب {toFa(points)}</span>
          <span>بانک {bank === null ? "—" : toFa(bank)}</span>
        </div>
      </div>

      {bank === null ? (
        <PBtn onClick={() => store.openAccount()}>افتتاح حساب — {toFa(50)}</PBtn>
      ) : (
        <>
          <div className="rounded-xl bg-white p-2.5 ring-1 ring-slate-900/8">
            <div className="mb-1.5 flex justify-between text-[10.5px] font-bold text-slate-500">
              <span>مبلغ</span>
              <span className="text-slate-900">{toFa(amt)}</span>
            </div>
            <input
              type="range"
              min={25}
              max={Math.max(100, Math.max(points, bank))}
              step={25}
              value={Math.min(amt, Math.max(100, Math.max(points, bank)))}
              onChange={(e) => setAmt(Number(e.target.value))}
              className="w-full accent-amber-500"
            />
            <div className="mt-2 grid grid-cols-2 gap-1.5">
              <PBtn disabled={points < amt} onClick={() => store.deposit(amt)}>
                واریز ↓
              </PBtn>
              <PBtn tone="ghost" disabled={bank < amt} onClick={() => store.withdraw(amt)}>
                برداشت ↑
              </PBtn>
            </div>
          </div>

          <PBtn tone="ghost" disabled={bank <= 0} onClick={() => store.collectInterest()}>
            دریافت سود روزانه ۱٪
          </PBtn>

          {loan ? (
            <>
              <Row label="بدهی وام" value={toFa(loan.amount)} tint="#e11d48" />
              <PBtn disabled={points < loan.amount} onClick={() => store.repayLoan()}>
                تسویه وام
              </PBtn>
            </>
          ) : (
            <PBtn tone="ghost" onClick={() => store.takeLoan(levelOf(store.get().earned) * 500)}>
              گرفتن وام
            </PBtn>
          )}
        </>
      )}

      <PBtn tone="ghost" onClick={() => store.goWheel()}>
        🎡 گردونه‌ی شانس
      </PBtn>
    </div>
  );
}

function ShopApp() {
  return (
    <div className="flex flex-col gap-2">
      <div className="rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 p-3 text-amber-950">
        <div className="text-[11px] font-black">فروشگاه جیکو</div>
        <div className="text-[9.5px] font-bold opacity-75">
          رنگ، کلاه، عینک، گردنی، آب‌نبات و ارتقاها
        </div>
      </div>
      <div className="grid grid-cols-4 gap-1.5">
        {CATALOG.slice(0, 12).map((i) => (
          <div
            key={i.id}
            className="aspect-square rounded-xl ring-1 ring-slate-900/10"
            style={{ background: `linear-gradient(145deg,${i.tint},${i.tint2 ?? i.tint})` }}
          />
        ))}
      </div>
      <PBtn onClick={() => store.setShop(true)}>باز کردن فروشگاه کامل</PBtn>
    </div>
  );
}

function JobsApp() {
  const earned = useStore((s) => s.earned);
  const jobs = useStore((s) => s.jobsSinceRest);
  const st = useStore(stamina);
  const lvl = levelOf(earned);

  const items = [
    { id: "sweep", n: "رفتگری", e: "🧹", d: "۶۰ هر زباله", live: true, lock: false },
    { id: "heist", n: "دزدی", e: "🕵️", d: "۱۸۰–۴۲۰", live: true, lock: false },
    { id: "taxi", n: "مسافرکشی", e: "🚕", d: "تا ۴۶۰", live: false, lock: lvl < 3 },
    { id: "dooz", n: "دوز", e: "⭕", d: "شرط ۵۰", live: false, lock: false },
    { id: "casino", n: "قمار", e: "🎰", d: "تا ×۲۰", live: false, lock: false },
  ] as const;

  return (
    <div className="flex flex-col gap-1.5">
      <Row label="کار تا خواب" value={`${toFa(jobs)}/${toFa(st)}`} />
      {items.map((j) => (
        <button
          key={j.id}
          type="button"
          disabled={j.lock}
          onClick={() => {
            boop();
            if (j.live) store.startPlay(j.id as "sweep" | "heist");
            else store.openPanel(j.id as "taxi" | "dooz" | "casino");
          }}
          className={`flex items-center gap-2 rounded-xl bg-white p-2 text-right ring-1 ring-slate-900/8 transition active:scale-[0.98] ${
            j.lock ? "opacity-45" : ""
          }`}
        >
          <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-slate-100 text-lg">
            {j.e}
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-[11.5px] font-black text-slate-900">{j.n}</span>
            <span className="block text-[9.5px] font-bold text-emerald-600">{j.d}</span>
          </span>
          <span className="text-[10px] font-black text-amber-600">
            {j.lock ? `سطح ${toFa(3)}` : "▶"}
          </span>
        </button>
      ))}
    </div>
  );
}

function StatsApp() {
  const s = useStore((v) => v.stats);
  const earned = useStore((v) => v.earned);
  const pokes = useStore((v) => v.pokes);
  const pet = useStore((v) => v.pet);
  const reward = useStore(clickReward);
  const rest = useStore(restMs);

  return (
    <div className="flex flex-col gap-1.5">
      <div className="rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-600 p-3 text-white">
        <div className="text-[9.5px] font-bold opacity-80">سطح جیکو</div>
        <div className="text-2xl font-black tabular-nums">{toFa(levelOf(earned))}</div>
        <div className="text-[9.5px] font-bold opacity-80">{toFa(earned)} پوینت کل</div>
      </div>
      <Row label="کل ضربه‌ها" value={toFa(pokes)} />
      <Row label="پوینت هر ۳ کلیک" value={toFa(reward)} tint="#b45309" />
      <Row label="مدت خواب" value={fmt(rest)} />
      <Row label="شیفت رفتگری" value={toFa(s.shifts)} />
      <Row label="سرقت موفق" value={toFa(s.heists)} />
      <Row label="برد بازی" value={toFa(s.wins)} />
      <Row label="تخم مزرعه" value={toFa(s.eggs)} />
      <Row label="سن" value={`${toFa(pet.age)} سال`} />
      <Row label="کد شناسنامه" value={toFa(pet.code)} />
    </div>
  );
}

function CameraApp() {
  const album = useStore((s) => s.album);
  const tint = (id: string | null) => itemById(id);

  return (
    <div className="flex flex-col gap-2">
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-b from-amber-200 to-orange-300 p-4 text-center">
        <div className="text-4xl">🐥</div>
        <div className="mt-1 text-[10px] font-black text-amber-900">
          جیکو رو همون‌طور که هست عکس بگیر
        </div>
      </div>
      <PBtn
        onClick={() => {
          store.snap();
          fanfare();
        }}
      >
        📸 گرفتن عکس
      </PBtn>

      {album.length === 0 ? (
        <div className="py-4 text-center text-[10.5px] font-bold text-slate-400">
          هنوز عکسی نگرفتی
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-1.5">
          {album.map((a) => (
            <button
              key={a.id}
              type="button"
              onClick={() => {
                store.removeShot(a.id);
                boop();
              }}
              className="relative aspect-square overflow-hidden rounded-xl ring-1 ring-slate-900/10"
              style={{
                background: `linear-gradient(160deg, ${tint(a.color)?.tint ?? "#FFC629"}, ${
                  tint(a.color)?.tint2 ?? "#FFD84D"
                })`,
              }}
            >
              <span className="absolute inset-0 grid place-items-center text-2xl">🐥</span>
              <span className="absolute right-0.5 bottom-0.5 flex gap-px text-[8px]">
                {a.hat && <span>🎩</span>}
                {a.glasses && <span>👓</span>}
                {a.neck && <span>🎀</span>}
                {a.buddy && <span>🍭</span>}
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

const REPLIES = [
  "جیـــک جیـــک!",
  "گشنمه، یه چیزی بده بخورم 🍕",
  "امروز چندتا پوینت گرفتیم؟",
  "بریم باشگاه؟ می‌خوام بزرگ شم 🏋️",
  "اون کلاهه رو برام بخر دیگه 🥺",
  "دیشب خواب دیدم پرواز کردم!",
  "دزدی نکنیم‌ها، پلیس می‌گیره 🚔",
  "دوستت دارم 💛",
];

function ChatApp() {
  const msgs = useStore((s) => s.msgs);
  const name = useStore((s) => s.pet.name);
  const endRef = useRef<HTMLDivElement>(null);
  const [text, setText] = useState("");

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "end" });
  }, [msgs.length]);

  const send = () => {
    const t = text.trim();
    if (!t) return;
    store.pushMsg("me", t.slice(0, 60));
    setText("");
    boop();
    window.setTimeout(() => {
      store.pushMsg("jeeko", REPLIES[Math.floor(Math.random() * REPLIES.length)]);
    }, 700);
  };

  return (
    <div className="flex h-full flex-col gap-2">
      <div className="flex items-center gap-2 rounded-xl bg-white p-2 ring-1 ring-slate-900/8">
        <span className="grid size-7 place-items-center rounded-full bg-amber-200 text-base">🐥</span>
        <span className="text-[11.5px] font-black text-slate-900">{name}</span>
        <span className="mr-auto size-2 rounded-full bg-emerald-500" />
      </div>

      <div className="flex min-h-[130px] flex-1 flex-col gap-1.5 overflow-y-auto">
        {msgs.length === 0 && (
          <div className="py-6 text-center text-[10.5px] font-bold text-slate-400">
            یه پیام بفرست…
          </div>
        )}
        {msgs.map((m) => (
          <div
            key={m.id}
            className={`max-w-[82%] rounded-2xl px-2.5 py-1.5 text-[11px] leading-4 font-bold ${
              m.from === "me"
                ? "self-start bg-amber-400 text-amber-950"
                : "self-end bg-white text-slate-800 ring-1 ring-slate-900/8"
            }`}
          >
            {m.text}
          </div>
        ))}
        <div ref={endRef} />
      </div>

      <div className="flex gap-1.5">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
          maxLength={60}
          placeholder="پیام…"
          className="min-w-0 flex-1 rounded-xl bg-white px-2.5 py-2 text-[11px] font-bold text-slate-900 ring-1 ring-slate-900/8 outline-none"
        />
        <button
          type="button"
          onClick={send}
          className="shrink-0 rounded-xl bg-amber-500 px-3 text-[11px] font-black text-amber-950 active:scale-95"
        >
          ↑
        </button>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  home screen                                                        */
/* ================================================================== */
function HomeScreen() {
  const points = useStore((s) => s.points);
  const unread = useStore((s) => s.msgs.filter((m) => m.from === "jeeko").length);
  const installed = useStore((s) => s.installed);
  const data = useStore((s) => s.data);
  const vpnOn = useStore((s) => s.vpnOn);
  const os = useStore((s) => s.os);

  const wp = wallpaperById(os.wallpaper);
  const accent = accentById(os.accent);
  const radius = shapeRadius(os.iconShape);

  const available: AppDef[] = useMemo(
    () => [...BUILTIN, ...installed.map((i) => DOWNLOADABLE[i]).filter(Boolean)],
    [installed],
  );

  // user order first, then anything new, minus hidden and docked
  const gridApps = useMemo(() => {
    const byId = new Map(available.map((a) => [a.id as string, a]));
    const seq = os.order.filter((i) => byId.has(i));
    for (const a of available) if (!seq.includes(a.id)) seq.push(a.id);
    return seq
      .filter((i) => !os.hidden.includes(i) && !os.dock.includes(i))
      .map((i) => byId.get(i)!)
      .filter(Boolean);
  }, [available, os.order, os.hidden, os.dock]);

  const dockApps = useMemo(
    () => os.dock.map((i) => available.find((a) => a.id === i)).filter(Boolean) as AppDef[],
    [available, os.dock],
  );

  const label = wp.dark ? "text-white/90" : "text-slate-700";

  const Icon = ({ a }: { a: AppDef }) => (
    <button
      type="button"
      onClick={() => {
        store.openApp(a.id);
        boop();
      }}
      className="group flex flex-col items-center gap-1"
    >
      <span
        className={`relative grid aspect-square w-full place-items-center text-xl shadow-lg ring-1 ring-white/25 transition group-active:scale-90 ${
          os.saver ? "" : "duration-150"
        }`}
        style={{ background: a.tint, borderRadius: radius }}
      >
        {a.emoji}
        {a.id === "chat" && unread > 0 && (
          <span className="absolute -top-1 -right-1 grid size-4 place-items-center rounded-full bg-rose-500 text-[8px] font-black text-white ring-2 ring-white/80">
            {toFa(Math.min(9, unread))}
          </span>
        )}
      </span>
      {os.labels && (
        <span className={`text-[8.5px] font-bold ${label}`}>{a.name}</span>
      )}
    </button>
  );

  return (
    <div className="flex h-full flex-col">
      {/* widget */}
      <div
        className={`mb-3 rounded-2xl p-2.5 ring-1 backdrop-blur ${
          wp.dark ? "bg-white/12 ring-white/20" : "bg-white/80 ring-white/60"
        }`}
      >
        <div className="flex items-center gap-2">
          <span className="text-2xl">🐥</span>
          <div className="min-w-0 flex-1">
            <div className={`text-[10.5px] font-black ${wp.dark ? "text-white/85" : "text-slate-800"}`}>
              موجودی جیکو
            </div>
            <div
              className="inline-flex items-center gap-1 text-[14px] font-black tabular-nums"
              style={{ color: accent.color }}
            >
              <CoinIcon className="size-3.5" />
              {toFa(points)}
            </div>
          </div>
          <div className="shrink-0 text-left">
            <div className={`text-[9px] font-black ${wp.dark ? "text-white/70" : "text-slate-500"}`}>
              📶 {fmtData(data)}
            </div>
            {vpnOn && <div className="text-[9px] font-black text-emerald-400">🛡️ VPN</div>}
          </div>
        </div>
      </div>

      {/* app grid */}
      <div
        className="grid gap-x-2 gap-y-3"
        style={{ gridTemplateColumns: `repeat(${os.gridCols}, minmax(0,1fr))` }}
      >
        {gridApps.map((a) => (
          <Icon key={a.id} a={a} />
        ))}
      </div>

      {gridApps.length === 0 && (
        <div className={`py-8 text-center text-[10.5px] font-bold ${label}`}>
          همه‌ی برنامه‌ها مخفی‌ان — از تنظیمات برشون گردون
        </div>
      )}

      {/* bottom dock */}
      {dockApps.length > 0 && (
        <div className="mt-auto pt-3">
          <div
            className={`grid gap-2 rounded-3xl p-2 ring-1 backdrop-blur ${
              wp.dark ? "bg-white/12 ring-white/20" : "bg-white/70 ring-white/60"
            }`}
            style={{ gridTemplateColumns: `repeat(${dockApps.length}, minmax(0,1fr))` }}
          >
            {dockApps.map((a) => (
              <button
                key={a.id}
                type="button"
                onClick={() => {
                  store.openApp(a.id);
                  boop();
                }}
                className="grid aspect-square place-items-center text-xl shadow-md ring-1 ring-white/25 transition active:scale-90"
                style={{ background: a.tint, borderRadius: radius }}
              >
                {a.emoji}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ================================================================== */
/*  the device                                                         */
/* ================================================================== */
export function Phone() {
  const phone = useStore((s) => s.phone);
  const app = useStore((s) => s.phoneApp);
  const os = useStore((s) => s.os);
  const unlocked = useStore((s) => s.unlocked);
  const installed = useStore((s) => s.installed);
  const [cc, setCC] = useState(false);

  const wp = wallpaperById(os.wallpaper);
  const accent = accentById(os.accent);
  const locked = os.lockEnabled && !unlocked;

  useEffect(() => {
    if (phone !== "open") return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      if (cc) setCC(false);
      else if (store.get().phoneApp) store.openApp(null);
      else store.closePhone();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phone, cc]);

  // close the control centre whenever the phone is put away
  useEffect(() => {
    if (phone !== "open") setCC(false);
  }, [phone]);

  const allApps = useMemo(
    () =>
      [...BUILTIN, ...installed.map((i) => DOWNLOADABLE[i]).filter(Boolean)].map((a) => ({
        id: a.id as string,
        name: a.name,
        emoji: a.emoji,
      })),
    [installed],
  );

  if (phone !== "open") return null;

  const current = ALL_APPS.find((a) => a.id === app);
  const headerTxt = wp.dark ? "text-white" : "text-slate-800";

  return (
    <div className="pointer-events-auto fixed inset-0 z-45 flex flex-col items-center justify-center gap-3 px-4 py-4">
      <div className="fade-in absolute inset-0 bg-slate-950/75" onClick={() => store.closePhone()} />

      {/* ---------------- device ---------------- */}
      <div
        className="phone-in relative flex w-full max-w-[330px] flex-col overflow-hidden rounded-[2.4rem] bg-slate-950 p-[7px] shadow-[0_30px_80px_-20px_rgba(0,0,0,0.9)] ring-1 ring-white/15"
        style={{ height: "min(76dvh, 660px)" }}
      >
        {/* side buttons */}
        <span className="absolute top-28 -right-[3px] h-14 w-[3px] rounded-l bg-slate-700" />
        <span className="absolute top-24 -left-[3px] h-9 w-[3px] rounded-r bg-slate-700" />
        <span className="absolute top-36 -left-[3px] h-9 w-[3px] rounded-r bg-slate-700" />

        {/* screen */}
        <div
          className={`relative flex min-h-0 flex-1 flex-col overflow-hidden rounded-[2rem] ${
            wp.dark ? "os-dark" : ""
          } ${os.saver ? "os-saver" : ""}`}
          style={{ background: wp.css }}
        >
          {locked ? (
            <LockScreen />
          ) : (
            <>
              <StatusBar dark={wp.dark} />

              {/* app header */}
              {current && (
                <div className="flex shrink-0 items-center gap-2 px-3 py-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      store.openApp(null);
                      boop();
                    }}
                    className={`grid size-7 place-items-center rounded-lg text-[13px] font-black ring-1 active:scale-95 ${
                      wp.dark
                        ? "bg-white/15 text-white ring-white/20"
                        : "bg-white/80 text-slate-700 ring-slate-900/8"
                    }`}
                  >
                    ›
                  </button>
                  <span className={`text-[12px] font-black ${headerTxt}`}>
                    {current.emoji} {current.name}
                  </span>
                  <button
                    type="button"
                    aria-label="مرکز کنترل"
                    onClick={() => {
                      setCC(true);
                      boop();
                    }}
                    className={`mr-auto grid size-7 place-items-center rounded-lg text-[12px] ring-1 active:scale-95 ${
                      wp.dark
                        ? "bg-white/15 text-white ring-white/20"
                        : "bg-white/80 text-slate-700 ring-slate-900/8"
                    }`}
                  >
                    ⌃
                  </button>
                </div>
              )}

              {/* pull-down handle on the home screen */}
              {!current && (
                <button
                  type="button"
                  aria-label="مرکز کنترل"
                  onClick={() => {
                    setCC(true);
                    boop();
                  }}
                  className="mx-auto mt-0.5 h-1 w-12 shrink-0 rounded-full bg-current opacity-25"
                  style={{ color: wp.dark ? "#fff" : "#0f172a" }}
                />
              )}

              {/* content */}
              <div className="no-scrollbar min-h-0 flex-1 overflow-y-auto px-3 pt-2 pb-3">
                {app === null && <HomeScreen />}
                {app === "wallet" && <WalletApp />}
                {app === "shop" && <ShopApp />}
                {app === "jobs" && <JobsApp />}
                {app === "stats" && <StatsApp />}
                {app === "camera" && <CameraApp />}
                {app === "chat" && <ChatApp />}
                {app === "settings" && <OSSettings allApps={allApps} />}
                {app === "store" && <StoreApp />}
                {app === "data" && <DataApp />}
                {app === "vpn" && <VpnApp />}
                {app === "crash" && <CrashApp />}
                {app === "match" && <MatchApp />}
                {app === "aparat" && <AparatApp />}
              </div>

              {/* home indicator */}
              <button
                type="button"
                aria-label="صفحه اصلی گوشی"
                onClick={() => {
                  store.openApp(null);
                  boop();
                }}
                className="mx-auto mb-1.5 h-1.5 w-24 shrink-0 rounded-full transition active:opacity-80"
                style={{ background: wp.dark ? "rgba(255,255,255,0.45)" : "rgba(15,23,42,0.35)" }}
              />

              {cc && <ControlCentre onClose={() => setCC(false)} />}
            </>
          )}
        </div>
      </div>

      {/* ---------------- put-away button ---------------- */}
      <button
        type="button"
        onClick={() => {
          store.closePhone();
          boop();
        }}
        className="pointer-events-auto relative inline-flex shrink-0 items-center gap-1.5 rounded-2xl px-5 py-2.5 text-[12.5px] font-extrabold text-white shadow-lg transition hover:-translate-y-0.5 active:translate-y-0"
        style={{ background: accent.color }}
      >
        <span className="text-base">📵</span>
        کنار گذاشتن گوشی
      </button>
    </div>
  );
}
