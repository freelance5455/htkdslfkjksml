import React, { useState } from 'react';
import { 
  Sparkles, 
  ArrowRight, 
  CheckCircle2, 
  TrendingUp, 
  ShieldCheck, 
  Smartphone, 
  CreditCard, 
  Truck, 
  Bot, 
  Store, 
  BarChart3, 
  Zap, 
  Layers, 
  Check, 
  HelpCircle,
  ShoppingBag,
  Sliders,
  DollarSign
} from 'lucide-react';
import { AppView, Language, PricingPlan } from '../../types';
import { pricingPlans } from '../../data/initialData';

interface SaaSMarketingProps {
  language: Language;
  onEnterDashboard: () => void;
  onExploreStorefront: () => void;
  onOpenCreateStoreWizard: () => void;
}

export const SaaSMarketing: React.FC<SaaSMarketingProps> = ({
  language,
  onEnterDashboard,
  onExploreStorefront,
  onOpenCreateStoreWizard,
}) => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [monthlyOrders, setMonthlyOrders] = useState<number>(350);
  const [averageOrderValue, setAverageOrderValue] = useState<number>(1800);
  const [activeFeatureTab, setActiveFeatureTab] = useState<'storefront' | 'payments' | 'courier' | 'ai'>('storefront');

  // Interactive preview state on landing page
  const [previewColor, setPreviewColor] = useState<string>('#059669'); // Emerald
  const [previewHeadline, setPreviewHeadline] = useState<string>('Artisanal Fashion & Lifestyle');

  const isBn = language === 'bn';

  // Calculator calculations
  const estimatedRevenue = monthlyOrders * averageOrderValue;
  const traditionalAgencyCost = 180000; // 1.8 Lakh BDT setup + maintenance
  const shanjuCost = billingCycle === 'monthly' ? 500 * 12 : 5000;
  const savings = traditionalAgencyCost - shanjuCost;

  return (
    <div className="bg-slate-950 text-slate-100 min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28 border-b border-slate-800">
        {/* Ambient background glow */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-emerald-600/20 via-teal-500/15 to-blue-600/15 blur-[120px] rounded-full pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            {/* Pill Tag */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900 border border-emerald-500/30 text-emerald-400 text-xs font-semibold mb-6 shadow-sm">
              <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-ping"></span>
              <span>
                {isBn 
                  ? '🚀 বাংলাদেশের ১ নম্বর আধুনিক মাল্টি-টেন্যান্ট কমার্স ইঞ্জিন' 
                  : '🚀 Next-Gen Multi-Tenant Cloud Commerce OS'}
              </span>
            </div>

            {/* Headline */}
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight">
              {isBn ? (
                <>
                  আপনার অনলাইন ই-কমার্স স্টোর চালু করুন <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400">
                    মাত্র ২ মিনিটে, কোডিং ছাড়া
                  </span>
                </>
              ) : (
                <>
                  Build, Sell & Scale Your E-Commerce Brand <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400">
                    With Modern Cloud SaaS
                  </span>
                </>
              )}
            </h1>

            {/* Subtitle */}
            <p className="mt-6 text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl mx-auto">
              {isBn 
                ? 'বিকাশ, নগদ ও কার্ড পেমেন্ট গেটওয়ে, লাইভ থিম কাস্টমাইজার, পাঠাও/স্টিডফাস্ট কুরিয়ার অটোমেশন এবং এআই কমার্স সহকারীসহ সম্পূর্ণ রেডিমেড সল্যুশন।'
                : 'Complete all-in-one platform featuring ultra-fast storefronts, instant bKash/Nagad/Card checkout, live visual theme builder, Courier API dispatch, and AI copilot.'}
            </p>

            {/* CTA Buttons */}
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3.5">
              <button
                id="hero-create-store-wizard-btn"
                onClick={onOpenCreateStoreWizard}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 hover:from-emerald-300 hover:to-cyan-300 text-slate-950 font-black text-sm shadow-xl shadow-emerald-500/30 transition-all transform hover:-translate-y-0.5 hover:scale-[1.02]"
              >
                <Sparkles className="w-4 h-4 text-slate-950" />
                {isBn ? '🚀 আপনার ওয়েবসাইট তৈরি করুন (ফ্রি)' : '🚀 Create Your Free Website'}
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                id="hero-start-trial-btn"
                onClick={onEnterDashboard}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white border border-slate-700 text-sm font-semibold transition-all"
              >
                <BarChart3 className="w-4 h-4 text-emerald-400" />
                {isBn ? 'মার্চেন্ট ড্যাশবোর্ড' : 'Merchant Dashboard'}
              </button>

              <button
                id="hero-explore-store-btn"
                onClick={onExploreStorefront}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-700/80 text-sm font-medium transition-all"
              >
                <ShoppingBag className="w-4 h-4 text-cyan-400" />
                {isBn ? 'লাইভ স্টোর দেখুন' : 'Live Storefront'}
              </button>
            </div>

            {/* Trust Badges */}
            <div className="mt-8 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-400">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>{isBn ? 'কোন ক্রেডিট কার্ড লাগবে না' : 'No Credit Card Required'}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>{isBn ? '০% ট্রানজেকশন ফি (গ্রোথ প্ল্যান)' : '0% Platform Fee on Growth'}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>{isBn ? 'বিকাশ ও নগদ অটোমেটেড পেমেন্ট' : 'Native bKash & Nagad Integration'}</span>
              </div>
            </div>
          </div>

          {/* Platform Live Stats Bar */}
          <div className="mt-14 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 text-center">
              <div className="text-2xl sm:text-3xl font-black text-emerald-400">৳৪৫০M+</div>
              <div className="text-xs text-slate-400 mt-1">{isBn ? 'মোট প্রসেসড সেলস' : 'Total GMV Processed'}</div>
            </div>
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 text-center">
              <div className="text-2xl sm:text-3xl font-black text-white">১২,৫০০+</div>
              <div className="text-xs text-slate-400 mt-1">{isBn ? 'সক্রিয় উদ্যোক্তা ও মার্চেন্ট' : 'Active Merchants'}</div>
            </div>
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 text-center">
              <div className="text-2xl sm:text-3xl font-black text-cyan-400">০.৫ সেকেন্ড</div>
              <div className="text-xs text-slate-400 mt-1">{isBn ? 'দ্রুততম মোবাইল পেজ লোড' : 'Sub-Second Edge Load'}</div>
            </div>
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 text-center">
              <div className="text-2xl sm:text-3xl font-black text-emerald-400">৯৯.৯৯%</div>
              <div className="text-xs text-slate-400 mt-1">{isBn ? 'ক্লাউড আপটাইম গ্যারান্টি' : 'Cloud SLA Uptime'}</div>
            </div>
          </div>
        </div>
      </section>

      {/* How Anyone Can Launch Their Own Website Section */}
      <section className="py-16 bg-slate-900 border-y border-slate-800 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-emerald-500/5 via-transparent to-transparent pointer-events-none"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-bold border border-emerald-500/20 mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isBn ? 'সবার জন্য উন্মুক্ত মাল্টি-টেন্যান্ট ইঞ্জিন' : 'Open Multi-Tenant Platform for Everyone'}</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
              {isBn 
                ? 'এখানে এসে যে কেউ নিজের ওয়েবসাইট তৈরি করতে পারবে তো?' 
                : 'Can Anyone Come Here and Build Their Own Website?'}
            </h2>
            <p className="mt-3 text-sm sm:text-base text-slate-300 leading-relaxed">
              {isBn 
                ? 'হ্যাঁ, অবশ্যই! Shanju এমনভাবে তৈরি করা হয়েছে যাতে যে কোনো উদ্যোক্তা কোনো প্রোগ্রামিং বা কোডিং না জেনেও মাত্র ৩ মিনিটে নিজের ব্র্যান্ডেড ওয়েবসাইট লাইভ করতে পারেন।' 
                : 'Yes, absolutely! Shanju empowers any entrepreneur, small business, or enterprise to spin up their own fully isolated e-commerce website with dedicated domain, inventory, and payment gateways in under 3 minutes.'}
            </p>
          </div>

          {/* 3 Step Visual Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Step 1 */}
            <div className="bg-slate-950/70 border border-slate-800 hover:border-emerald-500/50 rounded-2xl p-6 transition-all duration-300 group flex flex-col justify-between">
              <div>
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-black text-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  ০১
                </div>
                <h3 className="text-lg font-bold text-white mb-2">
                  {isBn ? '১. স্টোরের নাম ও সাবডোমেন দিন' : '1. Store Name & Subdomain'}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {isBn 
                    ? 'আপনার ব্যবসার নাম লিখলেই সাথে সাথে পেয়ে যাবেন একটি ফ্রি ক্লাউড সাবডোমেন (যেমন: yourbrand.shanju.cloud) এবং ফ্রি SSL সিকিউরিটি সার্টিফিকেট।' 
                    : 'Instantly claim your free branded cloud subdomain with global high-speed edge CDN and automated SSL.'}
                </p>
              </div>

              <div className="mt-5 p-3 rounded-xl bg-slate-900 border border-slate-800 text-[11px] font-mono text-emerald-400 flex items-center justify-between">
                <span>brand.shanju.cloud</span>
                <span className="text-[10px] font-bold text-emerald-500 bg-emerald-500/10 px-1.5 py-0.5 rounded">✓ Free SSL</span>
              </div>
            </div>

            {/* Step 2 */}
            <div className="bg-slate-950/70 border border-slate-800 hover:border-emerald-500/50 rounded-2xl p-6 transition-all duration-300 group flex flex-col justify-between">
              <div>
                <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-black text-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  ০২
                </div>
                <h3 className="text-lg font-bold text-white mb-2">
                  {isBn ? '২. ব্র্যান্ডের রঙ ও থিম সাজান' : '2. Customize Theme & Look'}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {isBn 
                    ? 'কোনো কোডিং ছাড়াই লাইভ কালার প্যালেট, নোটিফিকেশন বার, হিরো ব্যানার ও লোগো পরিবর্তন করুন। সাথে সাথে মোবাইল প্রিভিউতে পরিবর্তন দেখুন।' 
                    : 'Pick brand colors, announcement banners, typography, and responsive hero banners with immediate live mobile & desktop preview.'}
                </p>
              </div>

              <div className="mt-5 flex items-center gap-1.5 pt-1">
                <span className="w-5 h-5 rounded-full bg-emerald-500 border border-white"></span>
                <span className="w-5 h-5 rounded-full bg-blue-600 border border-white"></span>
                <span className="w-5 h-5 rounded-full bg-rose-500 border border-white"></span>
                <span className="w-5 h-5 rounded-full bg-amber-500 border border-white"></span>
                <span className="w-5 h-5 rounded-full bg-purple-600 border border-white"></span>
                <span className="text-[11px] text-slate-400 ml-2 font-medium">{isBn ? 'লাইভ প্রিভিউ' : 'Live palette'}</span>
              </div>
            </div>

            {/* Step 3 */}
            <div className="bg-slate-950/70 border border-slate-800 hover:border-emerald-500/50 rounded-2xl p-6 transition-all duration-300 group flex flex-col justify-between">
              <div>
                <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/30 text-purple-400 font-black text-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  ০৩
                </div>
                <h3 className="text-lg font-bold text-white mb-2">
                  {isBn ? '৩. পণ্য আপলোড ও পেমেন্ট রিসিভ' : '3. Add Products & Accept Payments'}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {isBn 
                    ? 'এআই সহকারীর সাহায্যে আকর্ষণীয় বিবরণীসহ পণ্য আপলোড করুন। বিকাশ, নগদ, কার্ড কিংবা ক্যাশ অন ডেলিভারিতে তাৎক্ষণিক পেমেন্ট গ্রহণ করুন।' 
                    : 'Use AI to generate product copy in seconds. Accept bKash, Nagad, Visa/Mastercard, and Cash on Delivery seamlessly.'}
                </p>
              </div>

              <div className="mt-5 flex items-center gap-2 text-[10px] font-bold text-slate-300">
                <span className="px-2 py-1 bg-pink-600/30 text-pink-300 border border-pink-500/40 rounded-lg">bKash</span>
                <span className="px-2 py-1 bg-orange-600/30 text-orange-300 border border-orange-500/40 rounded-lg">Nagad</span>
                <span className="px-2 py-1 bg-slate-800 text-slate-300 border border-slate-700 rounded-lg">COD</span>
              </div>
            </div>
          </div>

          {/* Interactive Launch Button Banner */}
          <div className="mt-10 p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-teal-950/60 border border-emerald-500/30 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-2xl">
            <div>
              <h4 className="text-xl font-black text-white">
                {isBn ? 'আপনিও কি এখনই আপনার ওয়েবসাইট তৈরি করতে চান?' : 'Ready to Launch Your Own Custom Website Today?'}
              </h4>
              <p className="text-xs text-slate-300 mt-1 max-w-xl">
                {isBn 
                  ? 'নিচের বাটনে ক্লিক করুন এবং সরাসরি ৩টি সহজ ধাপে আপনার নিজস্ব স্টোর চালু করে ফেলুন।' 
                  : 'Click below to launch your multi-tenant store wizard and test drive your live storefront immediately.'}
              </p>
            </div>

            <button
              id="section-open-store-wizard-btn"
              onClick={onOpenCreateStoreWizard}
              className="px-7 py-3.5 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 text-slate-950 font-extrabold text-xs shadow-xl shadow-emerald-500/30 flex items-center gap-2 shrink-0 transition-transform hover:scale-105 active:scale-95"
            >
              <Sparkles className="w-4 h-4 text-slate-950" />
              <span>{isBn ? 'আপনার ওয়েবসাইট তৈরি করুন (ফ্রি)' : 'Launch My Store Website (Free)'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Interactive Feature Architecture Showcase */}
      <section className="py-20 bg-slate-900/60 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-white">
              {isBn ? 'সবকিছু এক প্ল্যাটফর্মে — কোনো এক্সটার্নাল প্লাগিনের ঝামেলা নেই' : 'Enterprise Power, Built for Agile Merchants'}
            </h2>
            <p className="mt-3 text-sm sm:text-base text-slate-400">
              {isBn 
                ? 'স্টোরফ্রন্ট ডিজাইন থেকে শুরু করে পেমেন্ট রিসিভ ও কাস্টমার ট্র্যাকিং — সব সমন্বিত।'
                : 'Replace 8 fragmented subscriptions with one unified high-converting e-commerce SaaS.'}
            </p>
          </div>

          {/* Interactive Showcase Tabs */}
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            <button
              onClick={() => setActiveFeatureTab('storefront')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeFeatureTab === 'storefront'
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Store className="w-4 h-4" />
              {isBn ? '১. ড্র্যাগ-অ্যান্ড-ড্রপ কাস্টমাইজার' : '1. Storefront Builder'}
            </button>
            <button
              onClick={() => setActiveFeatureTab('payments')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeFeatureTab === 'payments'
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              {isBn ? '২. বিকাশ, নগদ ও কার্ড গেটওয়ে' : '2. Instant Gateways'}
            </button>
            <button
              onClick={() => setActiveFeatureTab('courier')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeFeatureTab === 'courier'
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Truck className="w-4 h-4" />
              {isBn ? '৩. অটোমেটেড কুরিয়ার এপিআই' : '3. Courier Integration'}
            </button>
            <button
              onClick={() => setActiveFeatureTab('ai')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeFeatureTab === 'ai'
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Bot className="w-4 h-4" />
              {isBn ? '৪. এআই কমার্স কপাইলট' : '4. AI Commerce Copilot'}
            </button>
          </div>

          {/* Tab Content Display */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-6 lg:p-8 max-w-5xl mx-auto shadow-2xl">
            {activeFeatureTab === 'storefront' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                <div>
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 text-xs font-semibold mb-3">
                    <Sliders className="w-3.5 h-3.5" />
                    {isBn ? 'লাইভ ডিজাইন প্রিভিউ' : 'Visual Storefront Editor'}
                  </div>
                  <h3 className="text-xl sm:text-2xl font-bold text-white">
                    {isBn ? 'আপনার ব্র্যান্ডের নিজস্ব রঙ ও স্টাইলে সাজান' : 'Customize Colors, Layouts & Themes Live'}
                  </h3>
                  <p className="mt-3 text-sm text-slate-300 leading-relaxed">
                    {isBn 
                      ? 'যেকোনো কোডিং ছাড়াই ব্র্যান্ড কালার, অ্যানাউন্সমেন্ট বার, হিরো ব্যানার এবং ফন্ট পরিবর্তন করুন। মোবাইল ও ট্যাবলেটে সরাসরি প্রিভিউ দেখুন।'
                      : 'Zero CSS required. Change primary branding palette, promotional tickers, hero typography, and checkout flows with real-time responsive updates.'}
                  </p>

                  <div className="mt-6 space-y-3">
                    <label className="text-xs font-semibold text-slate-400 block">
                      {isBn ? 'ইন্টারেক্টিভ রঙ টেস্ট করুন:' : 'Try Live Palette Changer:'}
                    </label>
                    <div className="flex items-center gap-3">
                      {[
                        { name: 'Emerald', hex: '#059669' },
                        { name: 'Blue', hex: '#2563eb' },
                        { name: 'Rose', hex: '#e11d48' },
                        { name: 'Amber', hex: '#d97706' },
                        { name: 'Purple', hex: '#7c3aed' },
                      ].map((c) => (
                        <button
                          key={c.name}
                          onClick={() => setPreviewColor(c.hex)}
                          className={`w-8 h-8 rounded-full border-2 transition-transform ${
                            previewColor === c.hex ? 'scale-110 border-white ring-2 ring-emerald-400' : 'border-slate-700'
                          }`}
                          style={{ backgroundColor: c.hex }}
                          title={c.name}
                        />
                      ))}
                    </div>

                    <div className="pt-3">
                      <label className="text-xs font-semibold text-slate-400 block mb-1.5">
                        {isBn ? 'স্টোর হেডলাইন পরিবর্তন করে দেখুন:' : 'Change headline text:'}
                      </label>
                      <input
                        type="text"
                        value={previewHeadline}
                        onChange={(e) => setPreviewHeadline(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                  </div>
                </div>

                {/* Simulated Device Frame */}
                <div className="bg-slate-900 border border-slate-700/80 rounded-xl p-4 shadow-xl">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-[11px] text-slate-400">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                      <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                    </div>
                    <span className="bg-slate-800 px-3 py-0.5 rounded-md font-mono text-[10px]">
                      mystore.shanju.cloud
                    </span>
                  </div>

                  <div className="mt-4 rounded-lg overflow-hidden border border-slate-800 bg-slate-950 p-4">
                    {/* Simulated Announcement */}
                    <div 
                      className="py-1 px-3 text-[10px] text-white text-center font-semibold rounded mb-3 transition-colors"
                      style={{ backgroundColor: previewColor }}
                    >
                      {isBn ? '🎉 সকল অর্ডারে ফ্রি ডেলিভারি কোড: FREESHIP' : '🎉 Free Express Delivery with code FREESHIP'}
                    </div>

                    <div className="py-6 px-4 bg-slate-900 rounded-lg text-center border border-slate-800">
                      <h4 className="font-extrabold text-base text-white">{previewHeadline}</h4>
                      <p className="text-xs text-slate-400 mt-1">Discover curated handcrafted pieces.</p>
                      <button 
                        className="mt-3 px-4 py-1.5 rounded text-[11px] font-bold text-white transition-colors"
                        style={{ backgroundColor: previewColor }}
                      >
                        {isBn ? 'কালেকশন দেখুন' : 'Shop Collection'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeFeatureTab === 'payments' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                <div>
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 text-xs font-semibold mb-3">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    {isBn ? 'সম্পূর্ণ নিরাপদ ট্রানজেকশন' : 'PCI-DSS Compliant & Ready'}
                  </div>
                  <h3 className="text-xl sm:text-2xl font-bold text-white">
                    {isBn ? 'বিকাশ, নগদ, ভিসা ও ক্যাশ অন ডেলিভারি' : 'Local & Global Multi-Currency Checkout'}
                  </h3>
                  <p className="mt-3 text-sm text-slate-300 leading-relaxed">
                    {isBn 
                      ? 'বাংলাদেশি গ্রাহকদের জন্য বিকাশ ও নগদের ইনস্ট্যান্ট পেমেন্ট গেটওয়ে, পাশাপাশি আন্তর্জাতিক ক্রেডিট কার্ড ও ক্যাশ অন ডেলিভারি (COD) ফিচার প্রস্তুত।'
                      : 'Frictionless checkout with 1-click bKash direct payment, Nagad, Mastercard, Visa, and Cash on Delivery with built-in fraud screening.'}
                  </p>
                  <ul className="mt-4 space-y-2 text-xs text-slate-300">
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span>{isBn ? 'অটোমেটেড ইনস্ট্যান্ট পেমেন্ট ভেরিফিকেশন ও এসএমএস নোটিফিকেশন' : 'Automated instant payment verification & SMS alert'}</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span>{isBn ? 'অর্ডার প্রসেসিংয়ে কোনো ড্রপ-অফ নেই (৯৪% কমপ্লিশন রেট)' : 'Zero checkout drop-off with saved customer addresses'}</span>
                    </li>
                  </ul>
                </div>

                <div className="space-y-3">
                  <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-pink-600/20 text-pink-400 flex items-center justify-center font-black text-sm">
                        bKash
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">bKash Direct Merchant API</div>
                        <div className="text-[11px] text-slate-400">Instant Tokenized Settlement</div>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 font-semibold">Active</span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-orange-600/20 text-orange-400 flex items-center justify-center font-black text-sm">
                        Nagad
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">Nagad Digital Wallet</div>
                        <div className="text-[11px] text-slate-400">Secure Direct Checkout</div>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 font-semibold">Active</span>
                  </div>

                  <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-blue-600/20 text-blue-400 flex items-center justify-center font-bold text-sm">
                        Cards
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">Visa, Mastercard & AMEX</div>
                        <div className="text-[11px] text-slate-400">Global multi-currency payment</div>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 font-semibold">Active</span>
                  </div>
                </div>
              </div>
            )}

            {activeFeatureTab === 'courier' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                <div>
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 text-xs font-semibold mb-3">
                    <Truck className="w-3.5 h-3.5" />
                    {isBn ? 'কুরিয়ার অটোমেশন' : 'One-Click Courier Dispatch'}
                  </div>
                  <h3 className="text-xl sm:text-2xl font-bold text-white">
                    {isBn ? 'পাঠাও, স্টিডফাস্ট ও রেডএক্স ইন্টিগ্রেশন' : 'Automated Courier API & Tracking'}
                  </h3>
                  <p className="mt-3 text-sm text-slate-300 leading-relaxed">
                    {isBn 
                      ? 'প্রতিটি নতুন অর্ডার এক ক্লিকেই পাঠিয়ে দিন আপনার পছন্দের কুরিয়ার সার্ভিসে। বারকোড ও ইনভয়েস অটো প্রিন্ট হবে এবং কাস্টমার এসএমএসে ট্র্যাকিং লিংক পাবে।'
                      : 'Generate consignments with Pathao Courier, Steadfast, and RedX in one click. Instant thermal shipping label generation and SMS tracking updates.'}
                  </p>
                </div>

                <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800 font-semibold text-slate-300">
                    <span>Order #ORD-84920</span>
                    <span className="text-emerald-400">Dispatch Ready</span>
                  </div>
                  <div className="text-xs space-y-1 text-slate-300">
                    <p><span className="text-slate-500">Destination:</span> House 42, Road 11, Banani, Dhaka</p>
                    <p><span className="text-slate-500">Consignment:</span> Steadfast Courier (STF-992314)</p>
                  </div>
                  <div className="pt-2 flex gap-2">
                    <button className="flex-1 py-1.5 bg-emerald-600 rounded-lg text-xs font-bold text-white hover:bg-emerald-500">
                      {isBn ? 'ইনভয়েস প্রিন্ট করুন' : 'Print Thermal Label'}
                    </button>
                    <button className="px-3 py-1.5 bg-slate-800 rounded-lg text-xs font-semibold text-slate-300 border border-slate-700">
                      {isBn ? 'ট্র্যাক' : 'Track'}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {activeFeatureTab === 'ai' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                <div>
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 text-xs font-semibold mb-3">
                    <Sparkles className="w-3.5 h-3.5" />
                    {isBn ? 'এআই চালিত সহকারী' : 'Powered by Gemini AI'}
                  </div>
                  <h3 className="text-xl sm:text-2xl font-bold text-white">
                    {isBn ? 'পণ্য বিবরণী ও ফেসবুক অ্যাড লিখুন সেকেন্ডে' : 'AI Commerce Copilot for Merchants'}
                  </h3>
                  <p className="mt-3 text-sm text-slate-300 leading-relaxed">
                    {isBn 
                      ? 'শুধু পণ্যের নাম ও মূল ফিচার লিখুন — আমাদের এআই সহকারী আকর্ষণীয় প্রোডাক্ট ডেসক্রিপশন, ফেসবুক অ্যাড কপি এবং এসইও মেটাট্যাগ তৈরি করে দেবে।'
                      : 'Generate persuasive product descriptions, TikTok & Facebook ad captions, and automated customer service responses in seconds.'}
                  </p>
                </div>

                <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 text-xs space-y-2">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold">
                    <Bot className="w-4 h-4" />
                    <span>Gemini AI Product Optimizer</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 font-mono text-[11px] leading-relaxed">
                    &quot;প্রিমিয়াম জ্যাকার্ড সিল্ক ফ্যাব্রিক ও নিখুঁত কলার সূচিকর্ম — আপনার উৎসবের দিনগুলোতে যোগ করবে রাজকীয় আভিজাত্য। সীমিত স্টক!&quot;
                  </div>
                  <div className="text-[10px] text-slate-500 flex justify-between">
                    <span>Generated in 0.4s</span>
                    <span className="text-emerald-400 font-semibold">Ready to apply to catalog</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Interactive Store ROI Calculator */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 text-xs font-semibold mb-3">
                <TrendingUp className="w-3.5 h-3.5" />
                {isBn ? 'ইন্টারেক্টিভ আরওআই ক্যালকুলেটর' : 'Interactive ROI Calculator'}
              </div>
              <h3 className="text-2xl sm:text-3xl font-extrabold text-white">
                {isBn ? 'দেখুন Shanju ব্যবহারে আপনার কত টাকা বাঁচবে' : 'Calculate Your Monthly Cost Savings'}
              </h3>
              <p className="mt-2 text-sm text-slate-400">
                {isBn 
                  ? 'কাস্টম সফ্টওয়্যার এজেন্সি বা একাধিক ফ্র্যাগমেন্টেড প্লাগিনের খরচের চেয়ে ৮০% কম খরচে সবকিছু পাবেন।'
                  : 'Compare the total cost of custom web developers and plugin fees versus an all-in-one managed SaaS engine.'}
              </p>

              {/* Sliders */}
              <div className="mt-6 space-y-6">
                <div>
                  <div className="flex justify-between text-xs font-semibold text-slate-300 mb-2">
                    <span>{isBn ? 'মাসিক আনুমানিক অর্ডার সংখ্যা:' : 'Estimated Monthly Orders:'}</span>
                    <span className="text-emerald-400 font-bold text-sm">{monthlyOrders.toLocaleString()} Orders</span>
                  </div>
                  <input
                    type="range"
                    min="50"
                    max="5000"
                    step="50"
                    value={monthlyOrders}
                    onChange={(e) => setMonthlyOrders(Number(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs font-semibold text-slate-300 mb-2">
                    <span>{isBn ? 'গড় অর্ডার মূল্য (AOV):' : 'Average Order Value (AOV):'}</span>
                    <span className="text-emerald-400 font-bold text-sm">৳{averageOrderValue.toLocaleString()}</span>
                  </div>
                  <input
                    type="range"
                    min="500"
                    max="10000"
                    step="100"
                    value={averageOrderValue}
                    onChange={(e) => setAverageOrderValue(Number(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                  />
                </div>
              </div>
            </div>

            {/* Calculations Card */}
            <div className="lg:col-span-5 bg-slate-950 border border-slate-800 rounded-2xl p-6">
              <div className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
                {isBn ? 'মাসিক আনুমানিক বিক্রয়' : 'Projected Monthly Sales'}
              </div>
              <div className="text-3xl font-black text-white mt-1">
                ৳{estimatedRevenue.toLocaleString()}
              </div>

              <div className="mt-6 pt-4 border-t border-slate-800 space-y-3 text-xs">
                <div className="flex justify-between text-slate-300">
                  <span>{isBn ? 'কাস্টম এজেন্সি/হোস্টিং খরচ:' : 'Custom Agency/Hosting Cost:'}</span>
                  <span className="font-semibold line-through text-slate-500">৳১,৮০,০০০/বছর</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Shanju Growth Plan:</span>
                  <span className="font-bold text-emerald-400">৳{shanjuCost.toLocaleString()}/বছর</span>
                </div>
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-center">
                  <span className="text-xs font-semibold text-emerald-400 block">
                    {isBn ? 'আপনার আনুমানিক বার্ষিক সাশ্রয়:' : 'Your Estimated Annual Savings:'}
                  </span>
                  <span className="text-2xl font-black text-white">৳{savings.toLocaleString()}</span>
                </div>
              </div>

              <button
                onClick={onEnterDashboard}
                className="w-full mt-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/25 transition-all"
              >
                {isBn ? 'বিনামূল্যে স্টোর তৈরি শুরু করুন' : 'Start Your Store Today'}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 border-t border-slate-800 bg-slate-900/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-3xl font-extrabold text-white">
              {isBn ? 'স্বচ্ছ ও সহজ মূল্য তালিকা' : 'Transparent, Scalable SaaS Plans'}
            </h2>
            <p className="mt-3 text-sm text-slate-400">
              {isBn 
                ? 'কোন লুকানো চার্জ নেই। যেকোনো সময় আপগ্রেড বা বাতিল করার পূর্ণ স্বাধীনতা।'
                : 'Choose the plan that fits your current volume. Upgrade seamlessly as your orders surge.'}
            </p>

            {/* Monthly / Yearly Toggle */}
            <div className="mt-6 inline-flex items-center gap-2 p-1 rounded-xl bg-slate-800 border border-slate-700">
              <button
                id="billing-toggle-monthly"
                onClick={() => setBillingCycle('monthly')}
                className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  billingCycle === 'monthly' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                {isBn ? 'মাসিক বিলিং' : 'Monthly'}
              </button>
              <button
                id="billing-toggle-yearly"
                onClick={() => setBillingCycle('yearly')}
                className={`flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  billingCycle === 'yearly' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>{isBn ? 'বার্ষিক বিলিং' : 'Yearly'}</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-400 text-slate-950 font-bold">
                  {isBn ? '২০% ছাড়' : '20% OFF'}
                </span>
              </button>
            </div>
          </div>

          {/* Pricing Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {pricingPlans.map((plan: PricingPlan) => {
              const price = billingCycle === 'monthly' ? plan.priceMonthly : Math.round(plan.priceYearly / 12);

              return (
                <div
                  key={plan.id}
                  className={`relative rounded-3xl p-6 sm:p-8 flex flex-col justify-between transition-all ${
                    plan.popular
                      ? 'bg-slate-900 border-2 border-emerald-500 shadow-2xl shadow-emerald-500/10 scale-100 md:-translate-y-2'
                      : 'bg-slate-950 border border-slate-800'
                  }`}
                >
                  {plan.popular && (
                    <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-black text-[11px] uppercase tracking-wider shadow">
                      {isBn ? 'সর্বাধিক জনপ্রিয়' : 'Most Popular'}
                    </div>
                  )}

                  <div>
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-bold text-white">
                        {isBn ? plan.nameBn : plan.name}
                      </h3>
                      <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">
                        {plan.limits.stores} {plan.limits.stores === 1 ? 'Store' : 'Stores'}
                      </span>
                    </div>

                    <p className="mt-2 text-xs text-slate-400 min-h-[36px]">
                      {isBn ? plan.taglineBn : plan.tagline}
                    </p>

                    <div className="mt-6 flex items-baseline gap-1.5">
                      <span className="text-4xl font-black text-white">
                        {price === 0 ? (isBn ? 'ফ্রি' : 'Free') : `৳${price.toLocaleString()}`}
                      </span>
                      <span className="text-xs text-slate-400">
                        {price === 0 ? (isBn ? '(১ মাস ফ্রি ট্রায়াল)' : '(1 Mo Trial)') : `/${isBn ? 'মাস' : 'month'}`}
                      </span>
                    </div>
                    {billingCycle === 'yearly' && price > 0 && (
                      <div className="text-[11px] text-emerald-400 font-medium mt-1">
                        ৳{plan.priceYearly.toLocaleString()} {isBn ? 'প্রতি বছর হিসেবে বিল করা হবে' : 'billed annually'}
                      </div>
                    )}
                    {plan.id === 'growth' && (
                      <div className="mt-3 px-3 py-1 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[11px] font-semibold flex items-center gap-1.5 w-fit">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                        <span>{isBn ? 'লাইভ সাপোর্ট: সকাল ৯:০০ - রাত ১১:০০' : 'Live Support: 9:00 AM - 11:00 PM'}</span>
                      </div>
                    )}

                    <div className="mt-8 pt-6 border-t border-slate-800/80 space-y-3">
                      {(isBn ? plan.featuresBn : plan.features).map((feat, idx) => (
                        <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-300">
                          <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                          <span>{feat}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="mt-8 pt-4">
                    <button
                      onClick={onEnterDashboard}
                      className={`w-full py-3 rounded-xl font-bold text-xs transition-all ${
                        plan.popular
                          ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/30'
                          : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
                      }`}
                    >
                      {isBn ? 'এই প্ল্যানে শুরু করুন' : 'Select Plan'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Merchant Success Stories & Testimonials */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-slate-800">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-2xl sm:text-3xl font-bold text-white">
            {isBn ? 'সফল উদ্যোক্তাদের বাস্তব অভিজ্ঞতা' : 'Trusted by Fast-Scaling D2C Brands'}
          </h2>
          <p className="mt-2 text-sm text-slate-400">
            {isBn ? 'Shanju এর ক্লাউড ইঞ্জিনে প্রতিদিন লাখ লাখ টাকার অর্ডার প্রসেস হচ্ছে।' : 'Hear from brand founders growing their sales effortlessly.'}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
            <div className="flex items-center gap-1 text-amber-400 mb-3">
              {'★★★★★'}
            </div>
            <p className="text-xs text-slate-300 italic leading-relaxed">
              &quot;আগে ফেসবুক পেজে ম্যানুয়ালি মেসেজ নিয়ে অর্ডার করতে গিয়ে অনেক কাস্টমার ড্রপ হত। Shanju এ আসার পর বিকাশ অটোমেটেড চেকআউটের মাধ্যমে আমাদের সেলস ৩ গুণ বৃদ্ধি পেয়েছে!&quot;
            </p>
            <div className="mt-4 pt-4 border-t border-slate-800 flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-emerald-600 flex items-center justify-center font-bold text-xs text-white">
                আর
              </div>
              <div>
                <div className="text-xs font-bold text-white">রফিকুল ইসলাম</div>
                <div className="text-[11px] text-slate-400">Founder, Aura Lifestyle BD</div>
              </div>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
            <div className="flex items-center gap-1 text-amber-400 mb-3">
              {'★★★★★'}
            </div>
            <p className="text-xs text-slate-300 italic leading-relaxed">
              &quot;The one-click Courier API dispatch is an absolute lifesaver. We pack 200+ gadget orders a day and generate Steadfast labels in 30 seconds.&quot;
            </p>
            <div className="mt-4 pt-4 border-t border-slate-800 flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-blue-600 flex items-center justify-center font-bold text-xs text-white">
                SK
              </div>
              <div>
                <div className="text-xs font-bold text-white">Siam Khan</div>
                <div className="text-[11px] text-slate-400">CEO, TechVerse Gadgets</div>
              </div>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800">
            <div className="flex items-center gap-1 text-amber-400 mb-3">
              {'★★★★★'}
            </div>
            <p className="text-xs text-slate-300 italic leading-relaxed">
              &quot;AI ডেসক্রিপশন জেনারেটর দিয়ে আমাদের অর্গানিক পণ্যের স্বাস্থ্য উপকারিতা মুহূর্তেই সুন্দর বাংলায় ফুটিয়ে তোলা যায়। কাস্টমারদের আস্থা অনেক বেড়েছে।&quot;
            </p>
            <div className="mt-4 pt-4 border-t border-slate-800 flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-teal-600 flex items-center justify-center font-bold text-xs text-white">
                এন
              </div>
              <div>
                <div className="text-xs font-bold text-white">নুসরাত পারভীন</div>
                <div className="text-[11px] text-slate-400">Co-Founder, Green Basket Organics</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pre-Footer Final Call to Action */}
      <section className="py-16 bg-gradient-to-b from-slate-900 to-slate-950 border-t border-slate-800 text-center">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            {isBn ? 'আপনার স্বপ্নের ই-কমার্স ব্যবসা আজই শুরু করুন' : 'Start Your Dream E-Commerce Business Today'}
          </h2>
          <p className="mt-3 text-sm text-slate-300 max-w-xl mx-auto">
            {isBn 
              ? 'কোনো ক্রেডিট কার্ড লাগবে না। মাত্র ৩টি সহজ ধাপে সম্পূর্ণ ওয়েবসাইট ও মার্চেন্ট ড্যাশবোর্ড পেয়ে যান।'
              : 'Zero setup fees, no technical setup required. Claim your free subdomain and start selling in 3 minutes.'}
          </p>
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              id="footer-cta-wizard-btn"
              onClick={onOpenCreateStoreWizard}
              className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-400 hover:from-emerald-300 hover:to-teal-300 text-slate-950 font-black text-sm shadow-xl shadow-emerald-500/25 transition-transform hover:scale-105 active:scale-95 flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-slate-950" />
              <span>{isBn ? 'ফ্রি ওয়েবসাইট তৈরি করুন 🚀' : 'Create Your Free Store Website 🚀'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-800 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center text-slate-950 font-bold">
                <Store className="w-4 h-4" />
              </div>
              <span className="font-extrabold text-lg text-white">Shanju</span>
              <span className="text-xs text-slate-500">© 2026 SaaS Commerce Engine</span>
            </div>

            <div className="flex items-center gap-6 text-xs text-slate-400">
              <button onClick={onEnterDashboard} className="hover:text-white">
                {isBn ? 'মার্চেন্ট ড্যাশবোর্ড' : 'Merchant Console'}
              </button>
              <button onClick={onExploreStorefront} className="hover:text-white">
                {isBn ? 'কাস্টমার স্টোর' : 'Live Storefront'}
              </button>
              <span className="text-slate-600">•</span>
              <span>PCI-DSS & SSL Verified</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
