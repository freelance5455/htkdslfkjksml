import React, { useEffect, useState } from 'react';
import { Flame, Shield, Calendar, Sparkles, Check, X, Zap, RefreshCw, Trophy } from 'lucide-react';
import { UserProfile } from '../types';
import { sound } from '../services/sound';
import { storage } from '../services/storage';

interface StreakCelebrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: UserProfile;
  streakResult?: {
    isFirstOpenToday: boolean;
    streakExtended: boolean;
    streakProtectedByFreeze: boolean;
    streakBroken: boolean;
    currentStreak: number;
    freezesLeft: number;
    yesterdayStreak: number;
  } | null;
  onProfileUpdated?: () => void;
}

export const StreakCelebrationModal: React.FC<StreakCelebrationModalProps> = ({
  isOpen,
  onClose,
  profile,
  streakResult,
  onProfileUpdated,
}) => {
  const [displayCount, setDisplayCount] = useState(() => streakResult?.yesterdayStreak || profile.streak);
  const [hasAnimated, setHasAnimated] = useState(false);
  const [buyMessage, setBuyMessage] = useState<string | null>(null);

  const targetCount = profile.streak || 1;
  const isExtended = streakResult?.streakExtended ?? true;
  const isFreezeProtected = streakResult?.streakProtectedByFreeze ?? false;

  // On open: sound celebration and number ticker animation
  useEffect(() => {
    if (isOpen) {
      sound.triggerCelebration(80, 70);
      sound.levelUp();

      const startCount = streakResult?.streakExtended
        ? Math.max(0, targetCount - 1)
        : targetCount;
      setDisplayCount(startCount);

      if (startCount !== targetCount) {
        const timer = setTimeout(() => {
          setDisplayCount(targetCount);
          sound.correct();
          setHasAnimated(true);
        }, 500);
        return () => clearTimeout(timer);
      } else {
        setHasAnimated(true);
      }
    } else {
      setHasAnimated(false);
      setBuyMessage(null);
    }
  }, [isOpen, targetCount, streakResult]);

  if (!isOpen) return null;

  // 7-day week schedule generator
  const getWeekDays = () => {
    const today = new Date();
    // 0 = Sun, 1 = Mon ...
    const dayOfWeek = today.getDay(); // 0-6
    // Map to Monday as start (0 = Mon, 6 = Sun)
    const currentMonIndex = (dayOfWeek + 6) % 7;
    const dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

    return dayNames.map((name, idx) => {
      const isPast = idx < currentMonIndex;
      const isToday = idx === currentMonIndex;
      const isFuture = idx > currentMonIndex;

      return {
        name,
        isPast,
        isToday,
        isFuture,
        // Mark past days within streak as completed
        completed: isToday || (isPast && currentMonIndex - idx < targetCount),
      };
    });
  };

  const weekDays = getWeekDays();

  // Milestone quotes for aspirants
  const getMilestoneMessage = (streak: number) => {
    if (streak >= 30) {
      return {
        badge: 'Cadre Vanguard (Top 1%)',
        quote: '30+ Days of ironclad resolve! You are on track for top ranking in Bangladesh Civil Service.',
      };
    }
    if (streak >= 14) {
      return {
        badge: 'Fortnight Champion',
        quote: '14 consecutive days of linguistic mastery! Neuroplasticity and recall retention are at peak.',
      };
    }
    if (streak >= 7) {
      return {
        badge: '1-Week Ebbinghaus Shield',
        quote: '7 days strong! You have crossed the steepest drop of the forgetting curve.',
      };
    }
    if (streak >= 3) {
      return {
        badge: 'Consistent Aspirant',
        quote: '3 days of momentum! Routine beats motivation every single time.',
      };
    }
    return {
      badge: 'Spark of Excellence',
      quote: 'Day 1 completed! Return tomorrow to keep the flame burning and build your competitive edge.',
    };
  };

  const milestone = getMilestoneMessage(targetCount);

  // Buy freeze handler
  const handleBuyFreeze = () => {
    const res = storage.buyStreakFreeze(100);
    setBuyMessage(res.message);
    if (res.success) {
      sound.correct();
      if (onProfileUpdated) onProfileUpdated();
    } else {
      sound.wrong();
    }
    setTimeout(() => setBuyMessage(null), 3000);
  };

  const handleReplayEffect = () => {
    sound.triggerCelebration(90, 80);
    sound.levelUp();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-sm sm:max-w-md bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-700/60 rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 text-slate-800 dark:text-slate-100"
        role="dialog"
        aria-modal="true"
        aria-labelledby="streak-modal-title"
      >
        {/* Decorative Top Sunburst & Fire Ambient Background */}
        <div className="absolute top-0 inset-x-0 h-44 bg-gradient-to-b from-amber-500/25 via-orange-500/15 to-transparent pointer-events-none" />
        <div className="absolute -top-12 -right-12 w-44 h-44 bg-orange-500/20 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -top-12 -left-12 w-44 h-44 bg-amber-400/20 rounded-full blur-2xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3.5 right-3.5 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-all z-10"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="relative p-6 sm:p-7 flex flex-col items-center text-center">
          
          {/* Animated Blazing Flame Avatar */}
          <div className="relative my-2 flex items-center justify-center">
            {/* Pulsing Aura Rings */}
            <span className="absolute w-28 h-28 rounded-full bg-orange-400/25 dark:bg-orange-500/20 animate-ping opacity-75" />
            <span className="absolute w-24 h-24 rounded-full bg-gradient-to-tr from-amber-400 to-red-500 opacity-20 blur-md animate-pulse" />
            
            {/* Duolingo-style Flame Container */}
            <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-3xl bg-gradient-to-b from-amber-400 via-orange-500 to-red-600 flex items-center justify-center shadow-[0_10px_25px_-5px_rgba(249,115,22,0.5)] border-4 border-amber-200 dark:border-amber-400/40">
              <Flame className="w-12 h-12 sm:w-14 sm:h-14 fill-white text-amber-200 drop-shadow-md animate-[bounce_1.5s_infinite]" />
              
              {/* Sparkle Badges */}
              <Sparkles className="absolute -top-2 -right-2 w-6 h-6 text-yellow-300 animate-spin" style={{ animationDuration: '6s' }} />
            </div>
          </div>

          {/* Celebratory Heading */}
          <div className="mt-3">
            <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-black tracking-wide uppercase bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-700/80 mb-1.5 shadow-sm">
              <Sparkles className="w-3 h-3 text-amber-600 dark:text-amber-400" />
              {isFreezeProtected ? 'Freeze Saved Your Streak!' : isExtended ? 'Daily Streak Extended!' : 'Daily Streak Active!'}
            </span>
            <div className="flex items-baseline justify-center gap-2">
              <span className="text-4xl sm:text-5xl font-black tracking-tight text-slate-900 dark:text-white transition-all duration-500">
                {displayCount}
              </span>
              <span className="text-xl sm:text-2xl font-extrabold text-orange-600 dark:text-orange-400">
                {displayCount === 1 ? 'Day' : 'Days'}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-xs">
              {milestone.quote}
            </p>
          </div>

          {/* 7-Day Interactive Week Calendar Tracker */}
          <div className="w-full mt-5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-2xl p-3 sm:p-4">
            <div className="flex items-center justify-between text-xs font-bold text-slate-600 dark:text-slate-300 mb-3 px-1">
              <span className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-amber-500" />
                This Week's Record
              </span>
              <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
                Active Today
              </span>
            </div>

            <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
              {weekDays.map((day, idx) => (
                <div key={idx} className="flex flex-col items-center gap-1.5">
                  <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500">
                    {day.name}
                  </span>
                  <div
                    className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center font-black text-xs transition-all ${
                      day.isToday
                        ? 'bg-gradient-to-tr from-amber-500 to-orange-500 text-white shadow-md shadow-orange-500/30 scale-105 ring-2 ring-amber-300 dark:ring-amber-500'
                        : day.completed
                        ? 'bg-emerald-100 dark:bg-emerald-950/80 border border-emerald-300 dark:border-emerald-700 text-emerald-700 dark:text-emerald-300'
                        : 'bg-slate-100 dark:bg-slate-800/80 border border-dashed border-slate-300 dark:border-slate-700 text-slate-400'
                    }`}
                  >
                    {day.isToday ? (
                      <Flame className="w-4 h-4 fill-current animate-pulse text-yellow-200" />
                    ) : day.completed ? (
                      <Check className="w-4 h-4 stroke-[3]" />
                    ) : (
                      <span className="w-1.5 h-1.5 rounded-full bg-slate-300 dark:bg-slate-600" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Streak Freeze & Milestone Perks */}
          <div className="w-full mt-3.5 flex flex-col gap-2">
            <div className="flex items-center justify-between p-3 rounded-2xl bg-cyan-50/70 dark:bg-cyan-950/40 border border-cyan-200 dark:border-cyan-800/70 text-left">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-cyan-500/20 dark:bg-cyan-900/60 border border-cyan-300 dark:border-cyan-700 flex items-center justify-center text-cyan-600 dark:text-cyan-300 shrink-0">
                  <Shield className="w-5 h-5 fill-cyan-400/30" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-black text-cyan-950 dark:text-cyan-200">
                      Streak Freezes
                    </span>
                    <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-md bg-cyan-200/80 dark:bg-cyan-900 text-cyan-800 dark:text-cyan-200">
                      {profile.streakFreezes ?? 2} / 3 Armed
                    </span>
                  </div>
                  <p className="text-[11px] text-cyan-800/80 dark:text-cyan-300/80 leading-tight">
                    Preserves your streak if you miss a study day.
                  </p>
                </div>
              </div>

              {(profile.streakFreezes ?? 0) < 3 && (
                <button
                  onClick={handleBuyFreeze}
                  disabled={(profile.xp ?? 0) < 100}
                  className={`text-[11px] font-black px-2.5 py-1.5 rounded-xl border transition-all shrink-0 ${
                    (profile.xp ?? 0) >= 100
                      ? 'bg-cyan-600 hover:bg-cyan-700 text-white border-cyan-700 shadow-sm'
                      : 'bg-slate-200 dark:bg-slate-800 text-slate-400 border-slate-300 dark:border-slate-700 cursor-not-allowed'
                  }`}
                  title="Equip 1 Streak Freeze for 100 XP"
                >
                  +1 (100 XP)
                </button>
              )}
            </div>

            {buyMessage && (
              <div className="text-xs font-bold text-cyan-700 dark:text-cyan-300 animate-in fade-in">
                {buyMessage}
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="w-full mt-5 flex items-center gap-2">
            <button
              onClick={handleReplayEffect}
              className="p-3 rounded-2xl bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 border border-amber-300 dark:border-amber-700/60 hover:scale-105 active:scale-95 transition-all"
              title="Replay Celebration FX & Confetti"
            >
              <Sparkles className="w-5 h-5" />
            </button>

            <button
              onClick={onClose}
              className="flex-1 py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-sm tracking-wide shadow-lg shadow-emerald-600/30 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
            >
              <Zap className="w-4 h-4 fill-current text-yellow-300" />
              Keep Practicing Today
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
