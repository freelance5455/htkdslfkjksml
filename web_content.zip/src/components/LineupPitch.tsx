import React, { useState } from 'react';
import { Match, TeamLineup } from '../types';
import { Shirt, UserCheck, Shield } from 'lucide-react';

interface LineupPitchProps {
  match: Match;
}

export const LineupPitch: React.FC<LineupPitchProps> = ({ match }) => {
  const [selectedTeam, setSelectedTeam] = useState<'home' | 'away'>('home');
  const homeLineup = match.lineup.home;
  const awayLineup = match.lineup.away;
  const activeLineup: TeamLineup = selectedTeam === 'home' ? homeLineup : awayLineup;
  const teamName = selectedTeam === 'home' ? match.homeTeam.name : match.awayTeam.name;
  const teamLogo = selectedTeam === 'home' ? match.homeTeam.logo : match.awayTeam.logo;

  // Group players by position
  const gk = activeLineup.startingXI.filter((p) => p.position === 'GK');
  const df = activeLineup.startingXI.filter((p) => p.position === 'DF');
  const mf = activeLineup.startingXI.filter((p) => p.position === 'MF');
  const fw = activeLineup.startingXI.filter((p) => p.position === 'FW');

  return (
    <div className="space-y-4">
      {/* Team Toggle */}
      <div className="flex items-center justify-between bg-[#0c101a] p-1.5 rounded-xl border border-slate-800">
        <button
          onClick={() => setSelectedTeam('home')}
          className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all ${
            selectedTeam === 'home'
              ? 'bg-rose-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <img src={match.homeTeam.logo} alt="" className="w-4 h-4 object-contain" />
          <span>{match.homeTeam.name}</span>
          <span className="text-[10px] bg-black/30 px-1.5 py-0.2 rounded font-mono">
            {homeLineup.formation}
          </span>
        </button>

        <button
          onClick={() => setSelectedTeam('away')}
          className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all ${
            selectedTeam === 'away'
              ? 'bg-rose-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <img src={match.awayTeam.logo} alt="" className="w-4 h-4 object-contain" />
          <span>{match.awayTeam.name}</span>
          <span className="text-[10px] bg-black/30 px-1.5 py-0.2 rounded font-mono">
            {awayLineup.formation}
          </span>
        </button>
      </div>

      {/* Coach & Formation Banner */}
      <div className="flex items-center justify-between text-xs text-slate-300 px-3 py-2 bg-[#141a29] rounded-xl border border-slate-800">
        <div className="flex items-center gap-2">
          <UserCheck className="w-4 h-4 text-emerald-400" />
          <span>المدرب: <strong className="text-white">{activeLineup.coach}</strong></span>
        </div>
        <div className="flex items-center gap-1.5 font-mono text-rose-400 font-bold">
          <span>الخطة: {activeLineup.formation}</span>
        </div>
      </div>

      {/* Realistic Football Pitch Canvas */}
      <div className="relative w-full aspect-[4/5] sm:aspect-[16/10] bg-gradient-to-b from-emerald-900 via-emerald-800 to-emerald-950 rounded-2xl border-2 border-emerald-600/40 p-3 sm:p-4 overflow-hidden shadow-2xl flex flex-col justify-between select-none">
        {/* Pitch Lines & Markings */}
        <div className="absolute inset-2 border-2 border-white/20 rounded-lg pointer-events-none" />
        {/* Center line */}
        <div className="absolute top-1/2 left-2 right-2 h-0.5 bg-white/20 -translate-y-1/2 pointer-events-none" />
        {/* Center circle */}
        <div className="absolute top-1/2 left-1/2 w-28 h-28 -translate-x-1/2 -translate-y-1/2 border-2 border-white/20 rounded-full pointer-events-none" />
        {/* Center dot */}
        <div className="absolute top-1/2 left-1/2 w-2 h-2 -translate-x-1/2 -translate-y-1/2 bg-white/40 rounded-full pointer-events-none" />
        {/* Penalty Box Top */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 w-44 h-16 border-2 border-t-0 border-white/20 rounded-b-lg pointer-events-none" />
        {/* Penalty Box Bottom */}
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-44 h-16 border-2 border-b-0 border-white/20 rounded-t-lg pointer-events-none" />

        {/* Attackers (FW) */}
        <div className="relative z-10 flex justify-around items-center pt-2">
          {fw.map((p) => (
            <PlayerBadge key={p.number} player={p} isHome={selectedTeam === 'home'} />
          ))}
        </div>

        {/* Midfielders (MF) */}
        <div className="relative z-10 flex justify-around items-center py-2">
          {mf.map((p) => (
            <PlayerBadge key={p.number} player={p} isHome={selectedTeam === 'home'} />
          ))}
        </div>

        {/* Defenders (DF) */}
        <div className="relative z-10 flex justify-around items-center py-2">
          {df.map((p) => (
            <PlayerBadge key={p.number} player={p} isHome={selectedTeam === 'home'} />
          ))}
        </div>

        {/* Goalkeeper (GK) */}
        <div className="relative z-10 flex justify-center items-center pb-2">
          {gk.map((p) => (
            <PlayerBadge key={p.number} player={p} isHome={selectedTeam === 'home'} isGK />
          ))}
        </div>
      </div>

      {/* Substitutes Bench */}
      {activeLineup.substitutes && activeLineup.substitutes.length > 0 && (
        <div className="bg-[#111726] p-3 rounded-xl border border-slate-800">
          <span className="text-xs font-bold text-slate-400 block mb-2">دكة البدلاء:</span>
          <div className="flex flex-wrap gap-2">
            {activeLineup.substitutes.map((sub) => (
              <div
                key={sub.number}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#192236] border border-slate-700/60 text-xs text-slate-200"
              >
                <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-300 font-mono text-[10px] flex items-center justify-center font-bold">
                  {sub.number}
                </span>
                <span>{sub.name}</span>
                <span className="text-[10px] text-slate-400">({sub.position})</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

const PlayerBadge: React.FC<{
  player: { number: number; name: string; isCaptain?: boolean; yellowCard?: boolean; goals?: number };
  isHome: boolean;
  isGK?: boolean;
}> = ({ player, isHome, isGK }) => {
  return (
    <div className="flex flex-col items-center group cursor-pointer">
      <div
        className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center text-xs font-black shadow-lg border-2 transition-transform group-hover:scale-110 ${
          isGK
            ? 'bg-amber-500 text-slate-950 border-amber-300'
            : isHome
            ? 'bg-rose-600 text-white border-rose-300'
            : 'bg-blue-600 text-white border-blue-300'
        }`}
      >
        <span>{player.number}</span>
        {player.isCaptain && (
          <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-amber-400 text-black text-[9px] font-black flex items-center justify-center border border-black">
            C
          </span>
        )}
      </div>
      <div className="mt-1 bg-black/80 backdrop-blur-xs px-2 py-0.5 rounded-md text-[10px] sm:text-xs font-bold text-white text-center shadow whitespace-nowrap max-w-[85px] sm:max-w-[110px] truncate border border-white/10">
        {player.name}
      </div>
      {player.goals && player.goals > 0 && (
        <span className="text-[10px] text-amber-300 font-black">⚽ {player.goals}</span>
      )}
      {player.yellowCard && (
        <span className="w-2.5 h-3.5 bg-yellow-400 rounded-xs mt-0.5 shadow" />
      )}
    </div>
  );
};
