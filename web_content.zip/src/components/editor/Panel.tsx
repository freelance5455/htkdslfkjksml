import { useState } from "react";
import {
  HSL_CHANNELS,
  PRESETS,
  applyTone,
  defaultAdjustments,
  developEqual,
  formatSigned,
  type Adjustments,
  type HslKey,
} from "@/lib/photo/model";
import type { HistData } from "@/lib/photo/renderer";
import { useEditor } from "@/store/editor";
import { cn } from "@/lib/cn";
import { Histogram } from "@/components/editor/Histogram";
import { SliderRow, TextButton } from "@/components/editor/controls";

const TABS = [
  { id: "basic", label: "Basic" },
  { id: "color", label: "Color" },
  { id: "tone", label: "Tone" },
  { id: "hsl", label: "HSL" },
  { id: "effects", label: "Effects" },
  { id: "presets", label: "Presets" },
] as const;

type TabId = (typeof TABS)[number]["id"];

type SliderSpec = {
  key: keyof Adjustments;
  label: string;
  min: number;
  max: number;
  step: number;
  format?: (value: number) => string;
};

const BASIC: SliderSpec[] = [
  { key: "exposure", label: "Exposure", min: -3, max: 3, step: 0.01, format: (value) => `${value > 0 ? "+" : ""}${value.toFixed(2)}` },
  { key: "contrast", label: "Contrast", min: -100, max: 100, step: 1 },
  { key: "highlights", label: "Highlights", min: -100, max: 100, step: 1 },
  { key: "shadows", label: "Shadows", min: -100, max: 100, step: 1 },
  { key: "whites", label: "Whites", min: -100, max: 100, step: 1 },
  { key: "blacks", label: "Blacks", min: -100, max: 100, step: 1 },
];

const COLOR: SliderSpec[] = [
  { key: "temperature", label: "Temp", min: -100, max: 100, step: 1 },
  { key: "tint", label: "Tint", min: -100, max: 100, step: 1 },
  { key: "vibrance", label: "Vibrance", min: -100, max: 100, step: 1 },
  { key: "saturation", label: "Saturation", min: -100, max: 100, step: 1 },
];

const GRADE: SliderSpec[] = [
  { key: "gradeShadowHue", label: "Shadow hue", min: 0, max: 360, step: 1, format: (value) => `${Math.round(value)}°` },
  { key: "gradeShadowSat", label: "Shadow sat", min: 0, max: 100, step: 1, format: (value) => `${Math.round(value)}` },
  { key: "gradeHighlightHue", label: "High hue", min: 0, max: 360, step: 1, format: (value) => `${Math.round(value)}°` },
  { key: "gradeHighlightSat", label: "High sat", min: 0, max: 100, step: 1, format: (value) => `${Math.round(value)}` },
  { key: "gradeBalance", label: "Balance", min: -100, max: 100, step: 1 },
];

const TONE: SliderSpec[] = [
  { key: "toneShadows", label: "Shadows", min: -100, max: 100, step: 1 },
  { key: "toneDarks", label: "Darks", min: -100, max: 100, step: 1 },
  { key: "toneLights", label: "Lights", min: -100, max: 100, step: 1 },
  { key: "toneHighlights", label: "Highlights", min: -100, max: 100, step: 1 },
];

const EFFECTS: SliderSpec[] = [
  { key: "clarity", label: "Clarity", min: -100, max: 100, step: 1 },
  { key: "texture", label: "Texture", min: -100, max: 100, step: 1 },
  { key: "dehaze", label: "Dehaze", min: -100, max: 100, step: 1 },
  { key: "sharpen", label: "Sharpen", min: 0, max: 100, step: 1, format: (value) => `${Math.round(value)}` },
  { key: "vignette", label: "Vignette", min: -100, max: 100, step: 1 },
  { key: "grain", label: "Grain", min: 0, max: 100, step: 1, format: (value) => `${Math.round(value)}` },
  { key: "fade", label: "Fade", min: 0, max: 100, step: 1, format: (value) => `${Math.round(value)}` },
];

function formatOf(spec: SliderSpec) {
  return spec.format ?? formatSigned;
}

export function Panel({
  hist,
  onAuto,
  onClose,
}: {
  hist: HistData | null;
  onAuto: () => void;
  onClose: () => void;
}) {
  const [tab, setTab] = useState<TabId>("basic");
  const [channel, setChannel] = useState<HslKey>("red");
  const [presetName, setPresetName] = useState("");
  const photo = useEditor((state) => state.photos.find((item) => item.id === state.activeId));
  const presets = useEditor((state) => state.userPresets);
  const beginGesture = useEditor((state) => state.beginGesture);
  const commitGesture = useEditor((state) => state.commitGesture);
  const patch = useEditor((state) => state.patch);
  const setHsl = useEditor((state) => state.setHsl);
  const applyPreset = useEditor((state) => state.applyPreset);
  const savePreset = useEditor((state) => state.savePreset);
  const deletePreset = useEditor((state) => state.deletePreset);
  const clipWarn = useEditor((state) => state.clipWarn);
  const setClipWarn = useEditor((state) => state.setClipWarn);

  const adjustments = photo?.adjustments;

  function renderSliders(specs: SliderSpec[]) {
    if (!adjustments) return null;
    const defaults = defaultAdjustments();
    return specs.map((spec) => {
      const value = adjustments[spec.key];
      if (typeof value !== "number") return null;
      const resetValue = defaults[spec.key];
      return (
        <SliderRow
          key={spec.key}
          label={spec.label}
          value={value}
          min={spec.min}
          max={spec.max}
          step={spec.step}
          format={formatOf(spec)}
          onBegin={beginGesture}
          onChange={(next) => patch({ [spec.key]: next })}
          onCommit={commitGesture}
          onReset={() => {
            if (typeof resetValue !== "number") return;
            commitGesture();
            beginGesture();
            patch({ [spec.key]: resetValue });
            commitGesture();
          }}
        />
      );
    });
  }

  return (
    <aside className="flex h-72 shrink-0 flex-col border-t border-border bg-surface md:h-full md:w-80 md:border-t-0 md:border-l">
      <div className="shrink-0 border-b border-border px-3 py-3">
        <Histogram data={hist} clip={clipWarn} onClip={() => setClipWarn(!clipWarn)} />
      </div>
      <div className="lumen-scroll flex shrink-0 gap-1 overflow-x-auto border-b border-border px-2">
        {TABS.map((item) => (
          <button
            key={item.id}
            type="button"
            aria-pressed={tab === item.id}
            onClick={() => setTab(item.id)}
            className={cn(
              "relative h-11 shrink-0 px-3 text-sm transition-colors duration-150",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-steel",
              tab === item.id ? "text-fg" : "text-muted hover:text-fg",
            )}
          >
            {item.label}
            {tab === item.id && <span className="absolute inset-x-3 bottom-0 h-px bg-steel" />}
          </button>
        ))}
        <button
          type="button"
          onClick={onClose}
          className="ml-auto hidden h-11 shrink-0 px-3 text-xs text-muted hover:text-fg md:inline"
        >
          Hide
        </button>
      </div>
      <div className="lumen-scroll min-h-0 flex-1 overflow-y-auto px-3 py-3">
        {!adjustments && <p className="text-sm text-muted">Import a photo to start developing.</p>}
        {adjustments && tab === "basic" && (
          <div>
            <div className="mb-2 flex items-center justify-between">
              <p className="text-xs text-subtle">Light</p>
              <TextButton onClick={onAuto}>Auto</TextButton>
            </div>
            {renderSliders(BASIC)}
          </div>
        )}
        {adjustments && tab === "color" && (
          <div>
            {renderSliders(COLOR)}
            <p className="mt-4 mb-2 text-xs text-subtle">Color grade</p>
            {renderSliders(GRADE)}
          </div>
        )}
        {adjustments && tab === "tone" && (
          <div>
            <Curve adjustments={adjustments} />
            <div className="mt-3">{renderSliders(TONE)}</div>
          </div>
        )}
        {adjustments && tab === "hsl" && (
          <div>
            <div className="mb-3 grid grid-cols-4 gap-2">
              {HSL_CHANNELS.map((item) => (
                <button
                  key={item.key}
                  type="button"
                  aria-pressed={channel === item.key}
                  onClick={() => setChannel(item.key)}
                  className={cn(
                    "flex h-11 items-center justify-center gap-2 rounded-sm text-xs",
                    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-steel",
                    channel === item.key ? "bg-surface-2 text-fg" : "text-muted hover:bg-surface-2 hover:text-fg",
                  )}
                >
                  <span className="size-2.5 rounded-full" style={{ background: item.swatch }} />
                  {item.label}
                </button>
              ))}
            </div>
            {(["h", "s", "l"] as const).map((key) => (
              <SliderRow
                key={key}
                label={key === "h" ? "Hue" : key === "s" ? "Sat" : "Lum"}
                value={adjustments.hsl[channel][key]}
                min={-100}
                max={100}
                step={1}
                format={formatSigned}
                onBegin={beginGesture}
                onChange={(value) => setHsl(channel, key, value)}
                onCommit={commitGesture}
                onReset={() => {
                  commitGesture();
                  beginGesture();
                  setHsl(channel, key, 0);
                  commitGesture();
                }}
              />
            ))}
          </div>
        )}
        {adjustments && tab === "effects" && <div>{renderSliders(EFFECTS)}</div>}
        {adjustments && tab === "presets" && (
          <div>
            <div className="grid grid-cols-2 gap-2">
              {PRESETS.map((preset) => {
                const active = developEqual(preset.adjustments, adjustments);
                return (
                  <button
                    key={preset.id}
                    type="button"
                    aria-pressed={active}
                    onClick={() => applyPreset(preset.adjustments)}
                    className={cn(
                      "flex min-h-11 flex-col items-start justify-center rounded-sm px-3 py-2 text-left",
                      "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-steel",
                      active ? "bg-surface-2 text-fg" : "hover:bg-surface-2",
                    )}
                  >
                    <span className="text-sm">{preset.name}</span>
                    <span className="text-xs text-pretty text-subtle">{preset.blurb}</span>
                  </button>
                );
              })}
            </div>
            {presets.length > 0 && (
              <div className="mt-4">
                <p className="mb-2 text-xs text-subtle">Yours</p>
                <div className="flex flex-col gap-1">
                  {presets.map((preset) => {
                    const active = developEqual(preset.adjustments, adjustments);
                    return (
                      <div key={preset.id} className="flex items-center gap-2">
                        <button
                          type="button"
                          aria-pressed={active}
                          onClick={() => applyPreset(preset.adjustments)}
                          className={cn(
                            "h-11 min-w-0 flex-1 truncate rounded-sm px-3 text-left text-sm",
                            "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-steel",
                            active ? "bg-surface-2 text-fg" : "hover:bg-surface-2",
                          )}
                        >
                          {preset.name}
                        </button>
                        <button
                          type="button"
                          className="h-11 rounded-sm px-3 text-xs text-muted hover:bg-surface-2 hover:text-fg"
                          onClick={() => deletePreset(preset.id)}
                        >
                          Delete
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
            <form
              className="mt-4 flex gap-2"
              onSubmit={(event) => {
                event.preventDefault();
                savePreset(presetName);
                setPresetName("");
              }}
            >
              <input
                value={presetName}
                onChange={(event) => setPresetName(event.target.value)}
                placeholder="Name this look"
                maxLength={32}
                aria-label="Preset name"
                className="h-11 min-w-0 flex-1 rounded-sm border border-border bg-bg px-3 text-sm text-fg outline-none placeholder:text-subtle focus-visible:ring-2 focus-visible:ring-steel"
              />
              <button
                type="submit"
                disabled={!presetName.trim()}
                className="h-11 rounded-sm bg-fg px-3 text-sm text-bg disabled:opacity-35"
              >
                Save
              </button>
            </form>
            <p className="mt-3 text-xs text-pretty text-subtle">Looks keep the current crop and rotation.</p>
          </div>
        )}
      </div>
    </aside>
  );
}

function Curve({ adjustments }: { adjustments: Adjustments }) {
  const points: string[] = [];
  for (let i = 0; i <= 40; i += 1) {
    const t = i / 40;
    const y = applyTone(
      t,
      adjustments.toneShadows / 100,
      adjustments.toneDarks / 100,
      adjustments.toneLights / 100,
      adjustments.toneHighlights / 100,
    );
    const xPos = 8 + t * 84;
    const yPos = 8 + (1 - y) * 84;
    points.push(`${xPos.toFixed(2)},${yPos.toFixed(2)}`);
  }
  return (
    <svg viewBox="0 0 100 100" className="h-32 w-full rounded-sm bg-bg text-fg" aria-hidden>
      <line x1="8" y1="92" x2="92" y2="8" stroke="currentColor" strokeOpacity="0.18" strokeWidth="1" />
      <polyline
        points={points.join(" ")}
        fill="none"
        stroke="currentColor"
        strokeWidth="1.6"
        vectorEffect="non-scaling-stroke"
      />
    </svg>
  );
}
