import React, { useState, useRef, useEffect } from 'react';
import { X, Play, Pause, RotateCcw, Check, Scissors, ChevronLeft, ChevronRight } from 'lucide-react';
import { TimelineClip, SourceMedia } from '../../types/editor';
import { formatTime } from '../../utils/time';

interface TrimModalProps {
  clip: TimelineClip;
  media: SourceMedia;
  onApply: (clipId: string, newStart: number, newEnd: number) => void;
  onClose: () => void;
}

export const TrimModal: React.FC<TrimModalProps> = ({
  clip,
  media,
  onApply,
  onClose,
}) => {
  const [startSec, setStartSec] = useState(clip.sourceIn);
  const [endSec, setEndSec] = useState(clip.sourceOut);
  const [currentTime, setCurrentTime] = useState(clip.sourceIn);
  const [isPlaying, setIsPlaying] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const isDraggingStart = useRef(false);
  const isDraggingEnd = useRef(false);

  const duration = media.duration || 10;

  // Video playback loop within [startSec, endSec]
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleTimeUpdate = () => {
      setCurrentTime(video.currentTime);
      if (video.currentTime >= endSec) {
        video.currentTime = startSec;
      }
    };

    video.addEventListener('timeupdate', handleTimeUpdate);
    return () => {
      video.removeEventListener('timeupdate', handleTimeUpdate);
    };
  }, [startSec, endSec]);

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;

    if (isPlaying) {
      video.pause();
      setIsPlaying(false);
    } else {
      if (video.currentTime < startSec || video.currentTime >= endSec) {
        video.currentTime = startSec;
      }
      video.play();
      setIsPlaying(true);
    }
  };

  const handleSeek = (time: number) => {
    const clamped = Math.max(0, Math.min(duration, time));
    const video = videoRef.current;
    if (video) {
      video.currentTime = clamped;
      setCurrentTime(clamped);
    }
  };

  const handleNudgeStart = (delta: number) => {
    const next = Math.max(0, Math.min(endSec - 0.2, Number((startSec + delta).toFixed(2))));
    setStartSec(next);
    handleSeek(next);
  };

  const handleNudgeEnd = (delta: number) => {
    const next = Math.min(duration, Math.max(startSec + 0.2, Number((endSec + delta).toFixed(2))));
    setEndSec(next);
    handleSeek(next);
  };

  const handleReset = () => {
    setStartSec(0);
    setEndSec(duration);
    handleSeek(0);
  };

  const handleTrackMouseDown = (e: React.MouseEvent) => {
    if (!trackRef.current) return;
    const rect = trackRef.current.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const clickedTime = ratio * duration;
    handleSeek(clickedTime);
  };

  // Drag handles
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!trackRef.current) return;
      const rect = trackRef.current.getBoundingClientRect();
      const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
      const posSec = ratio * duration;

      if (isDraggingStart.current) {
        const next = Math.max(0, Math.min(endSec - 0.2, posSec));
        setStartSec(next);
        handleSeek(next);
      } else if (isDraggingEnd.current) {
        const next = Math.min(duration, Math.max(startSec + 0.2, posSec));
        setEndSec(next);
        handleSeek(next);
      }
    };

    const handleMouseUp = () => {
      isDraggingStart.current = false;
      isDraggingEnd.current = false;
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [duration, startSec, endSec]);

  const leftPercent = (startSec / duration) * 100;
  const rightPercent = (1 - endSec / duration) * 100;
  const currentPercent = (currentTime / duration) * 100;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="w-full sm:max-w-2xl bg-[#161B22] border-t sm:border border-[#1F242D] rounded-t-3xl sm:rounded-3xl p-5 sm:p-6 flex flex-col gap-5 shadow-2xl max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#1F242D] pb-3">
          <div className="flex items-center gap-2">
            <Scissors className="w-5 h-5 text-[#00E5FF]" />
            <h3 className="text-base font-bold text-white">Precision Trim Clip</h3>
            <span className="text-xs text-[#8B949E] truncate max-w-[180px]">{media.name}</span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-[#8B949E] hover:text-white hover:bg-[#1F242D] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Video Player Preview */}
        <div className="relative aspect-video w-full rounded-2xl bg-black overflow-hidden flex items-center justify-center border border-[#1F242D]">
          <video
            ref={videoRef}
            src={media.url}
            playsInline
            className="w-full h-full object-contain"
          />

          {/* Center Play/Pause button */}
          <button
            onClick={togglePlay}
            className="absolute w-12 h-12 rounded-full bg-black/60 hover:bg-[#00E5FF] hover:text-black text-white flex items-center justify-center transition-all backdrop-blur-sm shadow-xl"
          >
            {isPlaying ? (
              <Pause className="w-5 h-5 fill-current" />
            ) : (
              <Play className="w-5 h-5 fill-current ml-0.5" />
            )}
          </button>

          {/* Time display HUD */}
          <div className="absolute bottom-3 left-3 px-3 py-1 rounded-lg bg-black/70 backdrop-blur-md text-xs font-mono text-[#00E5FF] border border-[#00E5FF]/20">
            {formatTime(currentTime)} / {formatTime(duration)}
          </div>

          <div className="absolute bottom-3 right-3 px-3 py-1 rounded-lg bg-black/70 backdrop-blur-md text-xs font-mono text-white/90">
            Trimmed: {(endSec - startSec).toFixed(2)}s
          </div>
        </div>

        {/* Trimming Filmstrip Track */}
        <div className="flex flex-col gap-2 pt-1">
          <div className="flex items-center justify-between text-xs text-[#8B949E]">
            <span>Drag handles or use nudge buttons</span>
            <span className="font-mono text-[#00E5FF]">
              Range: {formatTime(startSec)} → {formatTime(endSec)}
            </span>
          </div>

          <div
            ref={trackRef}
            onMouseDown={handleTrackMouseDown}
            className="relative h-16 w-full rounded-xl bg-[#0B0E14] border border-[#1F242D] overflow-hidden select-none cursor-pointer"
          >
            {/* Filmstrip background mockup frames */}
            <div className="absolute inset-0 flex">
              {Array.from({ length: 8 }).map((_, idx) => (
                <div
                  key={idx}
                  className="flex-1 h-full border-r border-[#1F242D]/40 bg-[#12161E] flex items-center justify-center overflow-hidden opacity-40"
                >
                  {media.thumbnailUrl && (
                    <img
                      src={media.thumbnailUrl}
                      alt=""
                      className="w-full h-full object-cover filter brightness-75"
                    />
                  )}
                </div>
              ))}
            </div>

            {/* Inactive Left Mask */}
            <div
              className="absolute top-0 bottom-0 left-0 bg-black/70 backdrop-blur-[1px] pointer-events-none"
              style={{ width: `${leftPercent}%` }}
            />

            {/* Inactive Right Mask */}
            <div
              className="absolute top-0 bottom-0 right-0 bg-black/70 backdrop-blur-[1px] pointer-events-none"
              style={{ width: `${rightPercent}%` }}
            />

            {/* Active Highlight Band */}
            <div
              className="absolute top-0 bottom-0 border-y-2 border-[#00E5FF] pointer-events-none"
              style={{
                left: `${leftPercent}%`,
                right: `${rightPercent}%`,
              }}
            />

            {/* Left Draggable Trim Handle */}
            <div
              onMouseDown={(e) => {
                e.stopPropagation();
                isDraggingStart.current = true;
              }}
              style={{ left: `${leftPercent}%` }}
              className="absolute top-0 bottom-0 w-5 -ml-2.5 bg-[#00E5FF] hover:bg-[#33ebff] rounded cursor-ew-resize z-20 flex items-center justify-center shadow-lg active:scale-105"
            >
              <div className="w-1 h-6 bg-black rounded-full" />
            </div>

            {/* Right Draggable Trim Handle */}
            <div
              onMouseDown={(e) => {
                e.stopPropagation();
                isDraggingEnd.current = true;
              }}
              style={{ right: `${rightPercent}%` }}
              className="absolute top-0 bottom-0 w-5 -mr-2.5 bg-[#00E5FF] hover:bg-[#33ebff] rounded cursor-ew-resize z-20 flex items-center justify-center shadow-lg active:scale-105"
            >
              <div className="w-1 h-6 bg-black rounded-full" />
            </div>

            {/* Playhead Needle indicator */}
            <div
              style={{ left: `${currentPercent}%` }}
              className="absolute top-0 bottom-0 w-0.5 bg-[#FF4A5A] pointer-events-none z-10"
            >
              <div className="w-2.5 h-2.5 bg-[#FF4A5A] rounded-full -ml-1 -mt-1 shadow" />
            </div>
          </div>
        </div>

        {/* Nudge Controls */}
        <div className="grid grid-cols-2 gap-3 pt-1">
          {/* Start Nudge */}
          <div className="p-3 rounded-xl bg-[#0B0E14] border border-[#1F242D] flex flex-col gap-2">
            <span className="text-[11px] font-semibold text-[#8B949E] uppercase tracking-wider">Start Point (In)</span>
            <div className="flex items-center justify-between">
              <span className="text-sm font-mono font-bold text-white">{formatTime(startSec)}</span>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => handleNudgeStart(-0.1)}
                  className="px-2 py-1 bg-[#1F242D] hover:bg-[#2A313D] text-xs font-mono rounded text-[#8B949E] hover:text-white"
                >
                  -0.1s
                </button>
                <button
                  onClick={() => handleNudgeStart(0.1)}
                  className="px-2 py-1 bg-[#1F242D] hover:bg-[#2A313D] text-xs font-mono rounded text-[#8B949E] hover:text-white"
                >
                  +0.1s
                </button>
              </div>
            </div>
          </div>

          {/* End Nudge */}
          <div className="p-3 rounded-xl bg-[#0B0E14] border border-[#1F242D] flex flex-col gap-2">
            <span className="text-[11px] font-semibold text-[#8B949E] uppercase tracking-wider">End Point (Out)</span>
            <div className="flex items-center justify-between">
              <span className="text-sm font-mono font-bold text-white">{formatTime(endSec)}</span>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => handleNudgeEnd(-0.1)}
                  className="px-2 py-1 bg-[#1F242D] hover:bg-[#2A313D] text-xs font-mono rounded text-[#8B949E] hover:text-white"
                >
                  -0.1s
                </button>
                <button
                  onClick={() => handleNudgeEnd(0.1)}
                  className="px-2 py-1 bg-[#1F242D] hover:bg-[#2A313D] text-xs font-mono rounded text-[#8B949E] hover:text-white"
                >
                  +0.1s
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Action Buttons */}
        <div className="flex items-center justify-between pt-2 border-t border-[#1F242D]">
          <button
            onClick={handleReset}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#1F242D] hover:bg-[#2A313D] text-xs font-semibold text-[#8B949E] hover:text-white transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Clip</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-[#1F242D] hover:bg-[#2A313D] text-xs font-semibold text-white transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={() => onApply(clip.id, startSec, endSec)}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#00E5FF] hover:bg-[#33ebff] text-xs font-bold text-black shadow-lg shadow-[#00E5FF]/20 transition-all cursor-pointer"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              <span>Apply Trim</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
