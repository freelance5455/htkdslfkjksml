import React from 'react';
import {
  Film,
  Music,
  Type,
  Smile,
  Wand2,
  Sparkles,
  ArrowLeftRight,
  Maximize2,
  Sliders,
  Gauge,
  Key,
  Layers,
  Square,
  Pipette,
} from 'lucide-react';
import { Language, translations } from '../../i18n/translations';

export type ActiveToolType =
  | 'none'
  | 'media'
  | 'audio'
  | 'text'
  | 'stickers'
  | 'effects'
  | 'filters'
  | 'transitions'
  | 'canvas'
  | 'adjust'
  | 'speed'
  | 'keyframe'
  | 'overlay'
  | 'mask'
  | 'chromakey';

interface ToolBarProps {
  activeTool: ActiveToolType;
  onSelectTool: (tool: ActiveToolType) => void;
  language: Language;
}

export const ToolBar: React.FC<ToolBarProps> = ({
  activeTool,
  onSelectTool,
  language,
}) => {
  const t = translations[language];

  const tools: { id: ActiveToolType; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'adjust', label: t.toolAdjust, icon: Sliders },
    { id: 'filters', label: t.toolFilters, icon: Sparkles },
    { id: 'effects', label: t.toolEffects, icon: Wand2 },
    { id: 'transitions', label: t.toolTransitions, icon: ArrowLeftRight },
    { id: 'text', label: t.toolText, icon: Type },
    { id: 'stickers', label: t.toolStickers, icon: Smile },
    { id: 'audio', label: t.toolAudio, icon: Music },
    { id: 'speed', label: t.toolSpeed, icon: Gauge },
    { id: 'keyframe', label: t.toolKeyframe, icon: Key },
    { id: 'overlay', label: t.toolOverlay, icon: Layers },
    { id: 'mask', label: t.toolMask, icon: Square },
    { id: 'chromakey', label: t.toolChromaKey, icon: Pipette },
    { id: 'canvas', label: t.toolCanvas, icon: Maximize2 },
  ];

  return (
    <nav className="w-full bg-[#0e0e11] border-t border-white/[0.08] text-white select-none py-1.5 px-3 overflow-x-auto scrollbar-none z-20 shrink-0">
      <div className="flex items-center gap-1 sm:gap-1.5 min-w-max mx-auto justify-start sm:justify-center">
        {tools.map((item) => {
          const Icon = item.icon;
          const isActive = activeTool === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTool(isActive ? 'none' : item.id)}
              className={`relative flex flex-col items-center justify-center py-1.5 px-3 rounded-xl transition-all active:scale-95 ${
                isActive
                  ? 'bg-amber-400/15 text-amber-300 font-bold border border-amber-400/40 shadow-sm shadow-amber-500/20'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-white/[0.04] border border-transparent'
              }`}
            >
              <Icon className={`w-4 h-4 mb-1 transition-colors ${isActive ? 'text-amber-400' : 'text-neutral-400'}`} />
              <span className="text-[10px] tracking-tight whitespace-nowrap">{item.label}</span>
              {isActive && (
                <span className="absolute -top-1 w-1.5 h-1.5 rounded-full bg-amber-400 shadow-sm shadow-amber-400" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
