import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Header } from '../common/Header';
import { VideoPreview } from './VideoPreview';
import { Timeline } from './Timeline';
import { ToolBar, ActiveToolType } from './ToolBar';
import { AdjustTool } from './tools/AdjustTool';
import { FiltersTool } from './tools/FiltersTool';
import { EffectsTool } from './tools/EffectsTool';
import { TransitionsTool } from './tools/TransitionsTool';
import { TextTool } from './tools/TextTool';
import { StickersTool } from './tools/StickersTool';
import { AudioTool } from './tools/AudioTool';
import { SpeedTool } from './tools/SpeedTool';
import { KeyframeTool } from './tools/KeyframeTool';
import { OverlayTool } from './tools/OverlayTool';
import { MaskTool } from './tools/MaskTool';
import { ChromaKeyTool } from './tools/ChromaKeyTool';
import { CanvasTool } from './tools/CanvasTool';
import { ExportModal } from './ExportModal';
import { Project, Clip, Track, ExportedProjectRecord, UserSubscription, ClipFilter, ColorAdjustments } from '../../types/editor';
import { Language } from '../../i18n/translations';
import { audioEngine } from '../../services/audioEngine';
import { mediaCache } from '../../services/videoRenderer';

const DEFAULT_ADJUSTMENTS: ColorAdjustments = {
  brightness: 0,
  contrast: 0,
  saturation: 0,
  exposure: 0,
  highlights: 0,
  shadows: 0,
  temperature: 0,
  tint: 0,
  sharpness: 0,
  vignette: 0,
  grain: 0,
  hue: 0,
};

interface EditorScreenProps {
  project: Project;
  subscription: UserSubscription;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onOpenPremium: () => void;
  onBackToHome: () => void;
  onSaveProject: (project: Project) => void;
  onExportSuccess: (record: ExportedProjectRecord) => void;
  previewProxyQuality: 'full' | 'half' | 'quarter';
  onOpenShare?: () => void;
}

export const EditorScreen: React.FC<EditorScreenProps> = ({
  project: initialProject,
  subscription,
  language,
  onLanguageChange,
  onOpenPremium,
  onBackToHome,
  onSaveProject,
  onExportSuccess,
  previewProxyQuality,
  onOpenShare,
}) => {
  const [project, setProject] = useState<Project>(initialProject);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [selectedClipId, setSelectedClipId] = useState<string | null>(
    initialProject.clips.length > 0 ? initialProject.clips[0].id : null
  );
  const [activeTool, setActiveTool] = useState<ActiveToolType>('none');
  const [isExportOpen, setIsExportOpen] = useState(false);

  // Undo / Redo history stack
  const historyRef = useRef<Project[]>([initialProject]);
  const historyIndexRef = useRef<number>(0);

  const pushHistory = useCallback((newProject: Project) => {
    const nextHistory = historyRef.current.slice(0, historyIndexRef.current + 1);
    nextHistory.push(newProject);
    if (nextHistory.length > 30) nextHistory.shift();
    historyRef.current = nextHistory;
    historyIndexRef.current = nextHistory.length - 1;
    setProject(newProject);
    onSaveProject(newProject);
  }, [onSaveProject]);

  const handleUndo = () => {
    if (historyIndexRef.current > 0) {
      historyIndexRef.current--;
      const prev = historyRef.current[historyIndexRef.current];
      setProject(prev);
      onSaveProject(prev);
    }
  };

  const handleRedo = () => {
    if (historyIndexRef.current < historyRef.current.length - 1) {
      historyIndexRef.current++;
      const next = historyRef.current[historyIndexRef.current];
      setProject(next);
      onSaveProject(next);
    }
  };

  const canUndo = historyIndexRef.current > 0;
  const canRedo = historyIndexRef.current < historyRef.current.length - 1;

  // Selected clip helper
  const selectedClip = project.clips.find(c => c.id === selectedClipId);

  // Playback timer loop
  useEffect(() => {
    let animId: number;
    let lastStamp = performance.now();

    const loop = (timestamp: number) => {
      const delta = (timestamp - lastStamp) / 1000;
      lastStamp = timestamp;

      if (isPlaying) {
        setCurrentTime((prev) => {
          const next = prev + delta;
          if (next >= project.duration) {
            setIsPlaying(false);
            mediaCache.pauseAllVideos();
            return 0;
          }
          return next;
        });
      } else {
        mediaCache.pauseAllVideos();
      }

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, project.duration]);

  // Sync Audio playback with current time
  useEffect(() => {
    audioEngine.syncPlayback(project, currentTime, isPlaying);
  }, [currentTime, isPlaying, project]);

  // Update a single clip in state and history
  const handleUpdateClip = (updatedClip: Clip) => {
    const updatedClips = project.clips.map(c => c.id === updatedClip.id ? updatedClip : c);
    const newProject = { ...project, clips: updatedClips };
    pushHistory(newProject);
  };

  // Apply filter to all visual clips in project
  const handleApplyFilterToAll = (filter?: ClipFilter) => {
    const updatedClips = project.clips.map(c => {
      if (c.type === 'video' || c.type === 'image') {
        return { ...c, filter };
      }
      return c;
    });
    pushHistory({ ...project, clips: updatedClips });
  };

  // Smart tool selection: Auto-bind visible video clip when opening visual tools
  const handleSelectTool = (tool: ActiveToolType) => {
    setActiveTool(tool);
    if (['filters', 'adjust', 'speed', 'effects', 'keyframe', 'transitions', 'chroma', 'mask'].includes(tool)) {
      const isVisual = selectedClip && (selectedClip.type === 'video' || selectedClip.type === 'image');
      if (!isVisual) {
        const visualAtPlayhead = project.clips.find(
          c => (c.type === 'video' || c.type === 'image') && currentTime >= c.start && currentTime < (c.start + c.duration)
        );
        if (visualAtPlayhead) {
          setSelectedClipId(visualAtPlayhead.id);
        } else {
          const firstVisual = project.clips.find(c => c.type === 'video' || c.type === 'image');
          if (firstVisual) {
            setSelectedClipId(firstVisual.id);
            setCurrentTime(firstVisual.start + Math.min(0.5, firstVisual.duration / 2));
          }
        }
      }
    }
  };

  // Split clip at current playhead
  const handleSplitClip = (clipId: string, splitTime: number) => {
    const clip = project.clips.find(c => c.id === clipId);
    if (!clip) return;

    const firstDuration = splitTime - clip.start;
    const secondDuration = clip.duration - firstDuration;
    if (firstDuration < 0.2 || secondDuration < 0.2) return;

    const firstClip: Clip = {
      ...clip,
      duration: Number(firstDuration.toFixed(2)),
    };

    const secondClip: Clip = {
      ...clip,
      id: `clip_${Date.now()}`,
      start: Number(splitTime.toFixed(2)),
      duration: Number(secondDuration.toFixed(2)),
      sourceStart: clip.sourceStart + firstDuration * clip.speed,
    };

    const updatedClips = project.clips
      .map(c => (c.id === clipId ? firstClip : c))
      .concat(secondClip);

    pushHistory({ ...project, clips: updatedClips });
    setSelectedClipId(secondClip.id);
  };

  // Trim clip start or duration
  const handleTrimClip = (clipId: string, newStart: number, newDuration: number) => {
    const updatedClips = project.clips.map(c => {
      if (c.id === clipId) {
        return {
          ...c,
          start: newStart,
          duration: newDuration,
        };
      }
      return c;
    });

    // Recalculate project total duration if clips extend beyond
    let maxEnd = 5;
    updatedClips.forEach(c => {
      maxEnd = Math.max(maxEnd, c.start + c.duration);
    });

    pushHistory({
      ...project,
      duration: Number(maxEnd.toFixed(2)),
      clips: updatedClips,
    });
  };

  // Duplicate clip
  const handleDuplicateClip = (clipId: string) => {
    const clip = project.clips.find(c => c.id === clipId);
    if (!clip) return;

    const newClip: Clip = {
      ...clip,
      id: `clip_${Date.now()}`,
      start: clip.start + clip.duration + 0.1,
    };

    const maxEnd = Math.max(project.duration, newClip.start + newClip.duration);
    pushHistory({
      ...project,
      duration: Number(maxEnd.toFixed(2)),
      clips: [...project.clips, newClip],
    });
    setSelectedClipId(newClip.id);
  };

  // Delete clip
  const handleDeleteClip = (clipId: string) => {
    const remaining = project.clips.filter(c => c.id !== clipId);
    pushHistory({ ...project, clips: remaining });
    setSelectedClipId(remaining.length > 0 ? remaining[0].id : null);
  };

  // Update track config
  const handleUpdateTrack = (updatedTrack: Track) => {
    const updatedTracks = project.tracks.map(t => t.id === updatedTrack.id ? updatedTrack : t);
    pushHistory({ ...project, tracks: updatedTracks });
  };

  // Add new Text layer
  const handleAddNewText = () => {
    const textTrack = project.tracks.find(t => t.type === 'text') || project.tracks[0];
    const newClip: Clip = {
      id: `clip_text_${Date.now()}`,
      trackId: textTrack.id,
      trackType: 'text',
      name: 'Text Title',
      type: 'text',
      sourceUrl: '',
      start: currentTime,
      duration: 3.5,
      sourceStart: 0,
      sourceDuration: 3.5,
      speed: 1.0,
      reverse: false,
      x: 0,
      y: 0,
      scale: 1.0,
      rotation: 0,
      opacity: 1.0,
      flipH: false,
      flipV: false,
      blendMode: 'normal',
      volume: 1.0,
      muted: false,
      fadeIn: 0.2,
      fadeOut: 0.2,
      adjustments: {
        brightness: 0, contrast: 0, saturation: 0, exposure: 0, highlights: 0,
        shadows: 0, temperature: 0, tint: 0, sharpness: 0, vignette: 0, grain: 0, hue: 0,
      },
      effects: [],
      mask: { type: 'none', x: 50, y: 50, width: 80, height: 80, rotation: 0, feather: 10, inverted: false },
      chromaKey: { enabled: false, color: '#00ff00', similarity: 35, smoothness: 15, spillReduction: 30 },
      keyframes: [],
      textConfig: {
        content: 'CLIPORA',
        fontFamily: "'Plus Jakarta Sans', sans-serif",
        fontSize: 44,
        color: '#ffffff',
        gradient: { enabled: true, start: '#f59e0b', end: '#f43f5e', angle: 45 },
        bold: true,
        italic: false,
        alignment: 'center',
        letterSpacing: 2,
        stroke: { enabled: true, color: '#000000', width: 2 },
        shadow: { enabled: true, color: 'rgba(0,0,0,0.8)', blur: 8, offsetX: 0, offsetY: 3 },
        background: { enabled: false, color: '#000', opacity: 0.5, borderRadius: 6, padding: 6 },
        animation: 'bounce',
      },
    };

    pushHistory({
      ...project,
      duration: Math.max(project.duration, currentTime + 3.5),
      clips: [...project.clips, newClip],
    });
    setSelectedClipId(newClip.id);
  };

  // Add new Sticker layer
  const handleAddSticker = (emojiOrUrl: string, isCustom: boolean) => {
    const stickerTrack = project.tracks.find(t => t.type === 'sticker') || project.tracks[0];
    const newClip: Clip = {
      id: `clip_stk_${Date.now()}`,
      trackId: stickerTrack.id,
      trackType: 'sticker',
      name: isCustom ? 'Sticker' : emojiOrUrl,
      type: 'sticker',
      sourceUrl: isCustom ? emojiOrUrl : '',
      start: currentTime,
      duration: 3.0,
      sourceStart: 0,
      sourceDuration: 3.0,
      speed: 1.0,
      reverse: false,
      x: 0,
      y: 0,
      scale: 1.0,
      rotation: 0,
      opacity: 1.0,
      flipH: false,
      flipV: false,
      blendMode: 'normal',
      volume: 1.0,
      muted: false,
      fadeIn: 0.2,
      fadeOut: 0.2,
      adjustments: {
        brightness: 0, contrast: 0, saturation: 0, exposure: 0, highlights: 0,
        shadows: 0, temperature: 0, tint: 0, sharpness: 0, vignette: 0, grain: 0, hue: 0,
      },
      effects: [],
      mask: { type: 'none', x: 50, y: 50, width: 80, height: 80, rotation: 0, feather: 10, inverted: false },
      chromaKey: { enabled: false, color: '#00ff00', similarity: 35, smoothness: 15, spillReduction: 30 },
      keyframes: [],
      stickerConfig: {
        emojiOrUrl,
        isCustomImage: isCustom,
        category: 'General',
      },
    };

    pushHistory({
      ...project,
      duration: Math.max(project.duration, currentTime + 3.0),
      clips: [...project.clips, newClip],
    });
    setSelectedClipId(newClip.id);
  };

  // Add Audio Clip
  const handleAddAudioClip = (name: string, url: string, blob: Blob, duration: number) => {
    const audioTrack = project.tracks.find(t => t.type === 'audio') || project.tracks[0];
    const newClip: Clip = {
      id: `clip_aud_${Date.now()}`,
      trackId: audioTrack.id,
      trackType: 'audio',
      name,
      type: 'audio',
      sourceUrl: url,
      blob,
      start: currentTime,
      duration,
      sourceStart: 0,
      sourceDuration: duration,
      speed: 1.0,
      reverse: false,
      x: 0,
      y: 0,
      scale: 1.0,
      rotation: 0,
      opacity: 1.0,
      flipH: false,
      flipV: false,
      blendMode: 'normal',
      volume: 1.0,
      muted: false,
      fadeIn: 0.3,
      fadeOut: 0.5,
      adjustments: {
        brightness: 0, contrast: 0, saturation: 0, exposure: 0, highlights: 0,
        shadows: 0, temperature: 0, tint: 0, sharpness: 0, vignette: 0, grain: 0, hue: 0,
      },
      effects: [],
      mask: { type: 'none', x: 50, y: 50, width: 80, height: 80, rotation: 0, feather: 10, inverted: false },
      chromaKey: { enabled: false, color: '#00ff00', similarity: 35, smoothness: 15, spillReduction: 30 },
      keyframes: [],
    };

    pushHistory({
      ...project,
      duration: Math.max(project.duration, currentTime + duration),
      clips: [...project.clips, newClip],
    });
    setSelectedClipId(newClip.id);
  };

  // Extract Audio from selected Video
  const handleExtractAudioFromVideo = async () => {
    if (!selectedClip || selectedClip.type !== 'video' || !selectedClip.blob) return;
    try {
      const { blob, url, duration } = await audioEngine.extractAudioFromVideo(selectedClip.blob);
      handleAddAudioClip(`${selectedClip.name} Audio`, url, blob, duration);
      // Mute the video clip
      handleUpdateClip({ ...selectedClip, muted: true });
    } catch (e) {
      console.error('Audio extraction error', e);
    }
  };

  // Freeze Frame: snapshots frame at playhead and inserts 2s freeze image
  const handleFreezeFrame = () => {
    if (!selectedClip) return;
    const freezeClip: Clip = {
      ...selectedClip,
      id: `clip_freeze_${Date.now()}`,
      name: `${selectedClip.name} Freeze`,
      start: currentTime,
      duration: 2.0,
      speed: 1.0,
    };
    pushHistory({
      ...project,
      duration: Math.max(project.duration, currentTime + 2.0),
      clips: [...project.clips, freezeClip],
    });
  };

  // Add PIP Overlay media
  const handleAddOverlayMedia = (file: File) => {
    const url = URL.createObjectURL(file);
    const isVideo = file.type.startsWith('video');
    const overlayTrack = project.tracks.find(t => t.type === 'overlay') || project.tracks[0];

    const newClip: Clip = {
      id: `clip_pip_${Date.now()}`,
      trackId: overlayTrack.id,
      trackType: 'overlay',
      name: `PIP: ${file.name.substring(0, 15)}`,
      type: isVideo ? 'video' : 'image',
      sourceUrl: url,
      blob: file,
      start: currentTime,
      duration: 4.0,
      sourceStart: 0,
      sourceDuration: 4.0,
      speed: 1.0,
      reverse: false,
      x: 0,
      y: 0,
      scale: 0.65,
      rotation: 0,
      opacity: 1.0,
      flipH: false,
      flipV: false,
      blendMode: 'normal',
      volume: 1.0,
      muted: false,
      fadeIn: 0.2,
      fadeOut: 0.2,
      adjustments: {
        brightness: 0, contrast: 0, saturation: 0, exposure: 0, highlights: 0,
        shadows: 0, temperature: 0, tint: 0, sharpness: 0, vignette: 0, grain: 0, hue: 0,
      },
      effects: [],
      mask: { type: 'none', x: 50, y: 50, width: 80, height: 80, rotation: 0, feather: 10, inverted: false },
      chromaKey: { enabled: false, color: '#00ff00', similarity: 35, smoothness: 15, spillReduction: 30 },
      keyframes: [],
    };

    pushHistory({
      ...project,
      duration: Math.max(project.duration, currentTime + 4.0),
      clips: [...project.clips, newClip],
    });
    setSelectedClipId(newClip.id);
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-neutral-950 text-white overflow-hidden">
      {/* 1. Top Header */}
      <Header
        language={language}
        onLanguageChange={onLanguageChange}
        isPremium={subscription.isPremium}
        onOpenPremium={onOpenPremium}
        isInEditor={true}
        projectName={project.name}
        onBackToHome={onBackToHome}
        onUndo={handleUndo}
        onRedo={handleRedo}
        canUndo={canUndo}
        canRedo={canRedo}
        onOpenExport={() => setIsExportOpen(true)}
        onOpenShare={onOpenShare}
      />

      {/* 2. Center Video Canvas Preview */}
      <div className="flex-1 min-h-[160px] max-h-[46vh] sm:max-h-[50vh] relative flex items-center justify-center bg-black/80 overflow-hidden">
        <VideoPreview
          project={project}
          currentTime={currentTime}
          isPlaying={isPlaying}
          isPremium={subscription.isPremium}
          selectedClip={selectedClip}
          previewProxyQuality={previewProxyQuality}
          onTogglePlay={() => setIsPlaying(!isPlaying)}
          onSeek={(t) => setCurrentTime(t)}
          onUpdateClipTransform={(id, x, y) => {
            if (selectedClip && selectedClip.id === id) {
              handleUpdateClip({ ...selectedClip, x, y });
            }
          }}
          language={language}
        />
      </div>

      {/* 3. Interactive Active Tool Panel (Slides up when a tool is selected) */}
      {activeTool !== 'none' && (
        <div className="w-full bg-neutral-900 border-t border-neutral-800 animate-in slide-in-from-bottom-2 duration-150 z-20 shadow-2xl shrink-0 max-h-44 sm:max-h-52 overflow-y-auto">
          {/* Quick Close Header for active tool */}
          <div className="flex items-center justify-between px-3 py-1 bg-neutral-950/90 border-b border-neutral-800 sticky top-0 z-30">
            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
              {activeTool}
            </span>
            <button
              onClick={() => setActiveTool('none')}
              className="px-2 py-0.5 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white text-[10px] font-bold transition-colors"
            >
              {language === 'hi' ? 'पैनल बंद करें ✕' : 'Close Panel ✕'}
            </button>
          </div>
          {activeTool === 'adjust' && (
            <AdjustTool
              adjustments={
                (selectedClip && (selectedClip.type === 'video' || selectedClip.type === 'image')
                  ? selectedClip
                  : project.clips.find(c => (c.type === 'video' || c.type === 'image'))
                )?.adjustments || DEFAULT_ADJUSTMENTS
              }
              onChange={(adj) => {
                const target = (selectedClip && (selectedClip.type === 'video' || selectedClip.type === 'image'))
                  ? selectedClip
                  : project.clips.find(c => (c.type === 'video' || c.type === 'image'));
                if (target) {
                  handleUpdateClip({ ...target, adjustments: adj });
                }
              }}
              language={language}
            />
          )}

          {activeTool === 'filters' && (
            <FiltersTool
              currentFilter={
                (selectedClip && (selectedClip.type === 'video' || selectedClip.type === 'image')
                  ? selectedClip
                  : project.clips.find(c => (c.type === 'video' || c.type === 'image'))
                )?.filter
              }
              onChange={(flt) => {
                const target = (selectedClip && (selectedClip.type === 'video' || selectedClip.type === 'image'))
                  ? selectedClip
                  : project.clips.find(c => (c.type === 'video' || c.type === 'image'));
                if (target) {
                  handleUpdateClip({ ...target, filter: flt });
                  if (selectedClipId !== target.id) {
                    setSelectedClipId(target.id);
                  }
                }
              }}
              onApplyToAll={handleApplyFilterToAll}
              selectedClip={
                selectedClip && (selectedClip.type === 'video' || selectedClip.type === 'image')
                  ? selectedClip
                  : project.clips.find(c => (c.type === 'video' || c.type === 'image'))
              }
              availableClips={project.clips.filter(c => c.type === 'video' || c.type === 'image')}
              onSelectClip={(id) => setSelectedClipId(id)}
              language={language}
            />
          )}

          {activeTool === 'effects' && selectedClip && (
            <EffectsTool
              effects={selectedClip.effects || []}
              onChange={(effs) => handleUpdateClip({ ...selectedClip, effects: effs })}
              language={language}
            />
          )}

          {activeTool === 'transitions' && selectedClip && (
            <TransitionsTool
              currentTransition={selectedClip.transition}
              onChange={(tr) => handleUpdateClip({ ...selectedClip, transition: tr })}
              language={language}
            />
          )}

          {activeTool === 'text' && (
            <TextTool
              config={selectedClip?.textConfig}
              onChange={(cfg) => selectedClip && handleUpdateClip({ ...selectedClip, textConfig: cfg })}
              onAddNewText={handleAddNewText}
              language={language}
            />
          )}

          {activeTool === 'stickers' && (
            <StickersTool
              onAddSticker={handleAddSticker}
              language={language}
            />
          )}

          {activeTool === 'audio' && (
            <AudioTool
              selectedClip={selectedClip}
              onUpdateClip={handleUpdateClip}
              onAddAudioClip={handleAddAudioClip}
              onExtractAudioFromVideo={selectedClip?.type === 'video' ? handleExtractAudioFromVideo : undefined}
              language={language}
            />
          )}

          {activeTool === 'speed' && selectedClip && (
            <SpeedTool
              clip={selectedClip}
              onChange={handleUpdateClip}
              onFreezeFrame={handleFreezeFrame}
              language={language}
            />
          )}

          {activeTool === 'keyframe' && selectedClip && (
            <KeyframeTool
              clip={selectedClip}
              currentTime={currentTime}
              onChange={handleUpdateClip}
              language={language}
            />
          )}

          {activeTool === 'overlay' && (
            <OverlayTool
              clip={selectedClip}
              onChange={handleUpdateClip}
              onAddOverlayMedia={handleAddOverlayMedia}
              language={language}
            />
          )}

          {activeTool === 'mask' && selectedClip && (
            <MaskTool
              mask={selectedClip.mask}
              onChange={(mask) => handleUpdateClip({ ...selectedClip, mask })}
              language={language}
            />
          )}

          {activeTool === 'chromakey' && selectedClip && (
            <ChromaKeyTool
              config={selectedClip.chromaKey}
              onChange={(ck) => handleUpdateClip({ ...selectedClip, chromaKey: ck })}
              language={language}
            />
          )}

          {activeTool === 'canvas' && (
            <CanvasTool
              aspectRatio={project.aspectRatio}
              background={project.background}
              onAspectRatioChange={(ratio) => pushHistory({ ...project, aspectRatio: ratio })}
              onBackgroundChange={(bg) => pushHistory({ ...project, background: bg })}
              language={language}
            />
          )}
        </div>
      )}

      {/* 4. Multi-Layer Timeline */}
      <Timeline
        project={project}
        currentTime={currentTime}
        selectedClipId={selectedClipId}
        onSelectClip={(id) => setSelectedClipId(id)}
        onSeek={(t) => setCurrentTime(t)}
        onSplitClip={handleSplitClip}
        onTrimClip={handleTrimClip}
        onDuplicateClip={handleDuplicateClip}
        onDeleteClip={handleDeleteClip}
        onUpdateTrack={handleUpdateTrack}
        language={language}
      />

      {/* 5. Bottom Tools Category Ribbon */}
      <ToolBar
        activeTool={activeTool}
        onSelectTool={handleSelectTool}
        language={language}
      />

      {/* 6. Export Modal */}
      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        project={project}
        subscription={subscription}
        onOpenPremium={onOpenPremium}
        onExportSuccess={(rec) => {
          onExportSuccess(rec);
        }}
        language={language}
      />
    </div>
  );
};
