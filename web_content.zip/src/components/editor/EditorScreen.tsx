import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Project,
  TimelineClip,
  SourceMedia,
  AspectRatioType
} from '../../types/editor';
import { EditorTopBar } from './EditorTopBar';
import { VideoPreview } from './VideoPreview';
import { EditingToolbar } from './EditingToolbar';
import { Timeline } from './Timeline';
import { TrimModal } from './TrimModal';
import { ExportModal } from './ExportModal';
import { AndroidCodeViewerModal } from '../android/AndroidCodeViewerModal';
import { saveProject } from '../../services/storage';
import { generateSampleVideo, processUploadedVideo } from '../../utils/sampleGenerator';
import { Film, Plus, Sparkles, X } from 'lucide-react';

interface EditorScreenProps {
  initialProject: Project;
  onNavigateBack: () => void;
}

export const EditorScreen: React.FC<EditorScreenProps> = ({
  initialProject,
  onNavigateBack,
}) => {
  const [project, setProject] = useState<Project>(initialProject);
  const [activeClipId, setActiveClipId] = useState<string | null>(
    initialProject.clips[0]?.id || null
  );
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  // Modals state
  const [showTrimModal, setShowTrimModal] = useState<boolean>(false);
  const [showExportModal, setShowExportModal] = useState<boolean>(false);
  const [showAndroidCodeModal, setShowAndroidCodeModal] = useState<boolean>(false);
  const [showMediaPicker, setShowMediaPicker] = useState<boolean>(false);
  const [isImporting, setIsImporting] = useState<boolean>(false);

  // Undo / Redo History
  const [history, setHistory] = useState<Project[]>([initialProject]);
  const [historyIndex, setHistoryIndex] = useState<number>(0);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const playTimerRef = useRef<number | null>(null);

  // Recalculate timelineStart for all clips sequentially
  const normalizeTimeline = useCallback((clips: TimelineClip[]): TimelineClip[] => {
    let acc = 0;
    return clips.map((clip) => {
      const dur = (clip.sourceOut - clip.sourceIn) / (clip.speed || 1.0);
      const updated = { ...clip, timelineStart: acc };
      acc += dur;
      return updated;
    });
  }, []);

  // Total timeline duration
  const totalDuration = project.clips.reduce(
    (acc, c) => acc + (c.sourceOut - c.sourceIn) / (c.speed || 1.0),
    0
  );

  // Active clip reference
  const activeClip = project.clips.find((c) => c.id === activeClipId) || project.clips[0] || null;

  // Push new state to history & save
  const updateProjectWithHistory = useCallback((newProject: Project) => {
    const normalizedClips = normalizeTimeline(newProject.clips);
    const cleaned = {
      ...newProject,
      clips: normalizedClips,
      updatedAt: Date.now(),
    };

    setProject(cleaned);
    saveProject(cleaned);

    setHistory((prev) => {
      const upToCurrent = prev.slice(0, historyIndex + 1);
      return [...upToCurrent, cleaned];
    });
    setHistoryIndex((prev) => prev + 1);
  }, [historyIndex, normalizeTimeline]);

  // Undo / Redo handlers
  const handleUndo = () => {
    if (historyIndex > 0) {
      const prev = history[historyIndex - 1];
      setHistoryIndex(historyIndex - 1);
      setProject(prev);
      saveProject(prev);
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      const next = history[historyIndex + 1];
      setHistoryIndex(historyIndex + 1);
      setProject(next);
      saveProject(next);
    }
  };

  // Find clip at timeline time
  const findClipAtTime = useCallback((time: number): TimelineClip | null => {
    for (const clip of project.clips) {
      const clipDur = (clip.sourceOut - clip.sourceIn) / (clip.speed || 1.0);
      if (time >= clip.timelineStart && time <= clip.timelineStart + clipDur) {
        return clip;
      }
    }
    return project.clips[project.clips.length - 1] || null;
  }, [project.clips]);

  // Playback timer loop
  useEffect(() => {
    if (isPlaying) {
      const startTimestamp = performance.now();
      const initialTime = currentTime;

      const loop = () => {
        const elapsed = (performance.now() - startTimestamp) / 1000;
        const nextTime = initialTime + elapsed;

        if (nextTime >= totalDuration) {
          setCurrentTime(totalDuration);
          setIsPlaying(false);
        } else {
          setCurrentTime(nextTime);
          const currentClip = findClipAtTime(nextTime);
          if (currentClip && currentClip.id !== activeClipId) {
            setActiveClipId(currentClip.id);
          }
          playTimerRef.current = requestAnimationFrame(loop);
        }
      };

      playTimerRef.current = requestAnimationFrame(loop);
      return () => {
        if (playTimerRef.current) cancelAnimationFrame(playTimerRef.current);
      };
    }
  }, [isPlaying, currentTime, totalDuration, activeClipId, findClipAtTime]);

  const handleTogglePlay = () => {
    if (totalDuration === 0) return;
    if (isPlaying) {
      setIsPlaying(false);
    } else {
      if (currentTime >= totalDuration) {
        setCurrentTime(0);
      }
      setIsPlaying(true);
    }
  };

  const handleSeekTimeline = (time: number) => {
    const clamped = Math.max(0, Math.min(totalDuration, time));
    setCurrentTime(clamped);
    const target = findClipAtTime(clamped);
    if (target && target.id !== activeClipId) {
      setActiveClipId(target.id);
    }
  };

  // Split Tool Handler
  const handleSplitClip = () => {
    if (!activeClip) return;
    const clipOffset = currentTime - activeClip.timelineStart;
    const clipDur = (activeClip.sourceOut - activeClip.sourceIn) / (activeClip.speed || 1.0);

    // Validate that split is inside the clip (at least 0.2s from ends)
    if (clipOffset <= 0.2 || clipOffset >= clipDur - 0.2) {
      alert('Split point must be at least 0.2s from the start or end of the clip.');
      return;
    }

    const splitSourceTime = activeClip.sourceIn + clipOffset * (activeClip.speed || 1.0);

    const clipA: TimelineClip = {
      ...activeClip,
      id: `clip_${Date.now()}_a`,
      sourceOut: splitSourceTime,
    };

    const clipB: TimelineClip = {
      ...activeClip,
      id: `clip_${Date.now()}_b`,
      sourceIn: splitSourceTime,
      color: '#00E5FF',
    };

    const clipIdx = project.clips.findIndex((c) => c.id === activeClip.id);
    const updatedClips = [...project.clips];
    updatedClips.splice(clipIdx, 1, clipA, clipB);

    updateProjectWithHistory({
      ...project,
      clips: updatedClips,
    });

    setActiveClipId(clipB.id);
  };

  // Trim Apply Handler
  const handleApplyTrim = (clipId: string, newStart: number, newEnd: number) => {
    const updatedClips = project.clips.map((c) => {
      if (c.id === clipId) {
        return {
          ...c,
          sourceIn: newStart,
          sourceOut: newEnd,
        };
      }
      return c;
    });

    updateProjectWithHistory({
      ...project,
      clips: updatedClips,
    });

    setShowTrimModal(false);
  };

  // Delete Clip Handler
  const handleDeleteClip = () => {
    if (!activeClip) return;
    const updatedClips = project.clips.filter((c) => c.id !== activeClip.id);
    updateProjectWithHistory({
      ...project,
      clips: updatedClips,
    });
    setActiveClipId(updatedClips[0]?.id || null);
    setCurrentTime(0);
  };

  // Reorder Clips
  const handleMoveClipLeft = (index: number) => {
    if (index <= 0) return;
    const updated = [...project.clips];
    const temp = updated[index - 1];
    updated[index - 1] = updated[index];
    updated[index] = temp;
    updateProjectWithHistory({ ...project, clips: updated });
  };

  const handleMoveClipRight = (index: number) => {
    if (index >= project.clips.length - 1) return;
    const updated = [...project.clips];
    const temp = updated[index + 1];
    updated[index + 1] = updated[index];
    updated[index] = temp;
    updateProjectWithHistory({ ...project, clips: updated });
  };

  // Aspect Ratio & Speed Handlers
  const handleChangeAspectRatio = (ratio: AspectRatioType) => {
    updateProjectWithHistory({ ...project, aspectRatio: ratio });
  };

  const handleChangeSpeed = (speed: number) => {
    if (!activeClip) return;
    const updatedClips = project.clips.map((c) =>
      c.id === activeClip.id ? { ...c, speed } : c
    );
    updateProjectWithHistory({ ...project, clips: updatedClips });
  };

  const handleToggleMute = () => {
    if (!activeClip) return;
    const updatedClips = project.clips.map((c) =>
      c.id === activeClip.id ? { ...c, volume: c.volume === 0 ? 1.0 : 0 } : c
    );
    updateProjectWithHistory({ ...project, clips: updatedClips });
  };

  // Media Import from User Device
  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsImporting(true);
    setShowMediaPicker(false);

    try {
      const newMediaMap = { ...project.mediaMap };
      const newClips = [...project.clips];

      for (let i = 0; i < files.length; i++) {
        const media = await processUploadedVideo(files[i]);
        newMediaMap[media.id] = media;
        newClips.push({
          id: `clip_${Date.now()}_${i}`,
          mediaId: media.id,
          sourceIn: 0,
          sourceOut: media.duration,
          timelineStart: 0,
          speed: 1.0,
          volume: 1.0,
          color: ['#00E5FF', '#FF4A5A', '#A855F7', '#22C55E'][newClips.length % 4],
        });
      }

      updateProjectWithHistory({
        ...project,
        mediaMap: newMediaMap,
        clips: newClips,
      });

      if (newClips.length > 0) {
        setActiveClipId(newClips[newClips.length - 1].id);
      }
    } catch (err) {
      console.error(err);
      alert('Could not import selected video file.');
    } finally {
      setIsImporting(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Add Sample Clip
  const handleAddSampleClip = async (theme: 'sunset' | 'cyberpunk' | 'skate') => {
    setIsImporting(true);
    setShowMediaPicker(false);

    try {
      const title =
        theme === 'sunset'
          ? 'Golden Sunset Coast'
          : theme === 'cyberpunk'
          ? 'Cyber Neon Grid'
          : 'Skatepark Stunt Run';

      const media = await generateSampleVideo(title, theme, 4.5);
      const newMediaMap = { ...project.mediaMap, [media.id]: media };
      const newClip: TimelineClip = {
        id: `clip_${Date.now()}`,
        mediaId: media.id,
        sourceIn: 0.5,
        sourceOut: 4.0,
        timelineStart: 0,
        speed: 1.0,
        volume: 1.0,
        color: theme === 'sunset' ? '#f43f5e' : theme === 'cyberpunk' ? '#00e5ff' : '#fbbf24',
      };

      updateProjectWithHistory({
        ...project,
        mediaMap: newMediaMap,
        clips: [...project.clips, newClip],
      });

      setActiveClipId(newClip.id);
    } catch (err) {
      console.error(err);
    } finally {
      setIsImporting(false);
    }
  };

  // Determine if split tool can be clicked
  const canSplit = Boolean(
    activeClip &&
      currentTime > activeClip.timelineStart + 0.2 &&
      currentTime <
        activeClip.timelineStart +
          (activeClip.sourceOut - activeClip.sourceIn) / (activeClip.speed || 1.0) -
          0.2
  );

  return (
    <div className="h-screen w-full bg-[#0B0E14] text-[#F0F3F6] flex flex-col overflow-hidden">
      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="video/mp4,video/webm,video/quicktime,video/*"
        multiple
        className="hidden"
        onChange={handleFileSelect}
      />

      {/* Top Bar */}
      <EditorTopBar
        project={project}
        canUndo={historyIndex > 0}
        canRedo={historyIndex < history.length - 1}
        onUndo={handleUndo}
        onRedo={handleRedo}
        onNavigateBack={onNavigateBack}
        onUpdateProjectName={(name) => updateProjectWithHistory({ ...project, name })}
        onOpenExport={() => setShowExportModal(true)}
        onOpenAndroidCode={() => setShowAndroidCodeModal(true)}
      />

      {/* Video Preview Canvas */}
      <VideoPreview
        project={project}
        activeClip={activeClip}
        currentTime={currentTime}
        totalDuration={totalDuration}
        isPlaying={isPlaying}
        onTogglePlay={handleTogglePlay}
        onSeekTimeline={handleSeekTimeline}
      />

      {/* Editing Toolbar */}
      <EditingToolbar
        activeClip={activeClip}
        aspectRatio={project.aspectRatio}
        onOpenMediaPicker={() => setShowMediaPicker(true)}
        onOpenTrim={() => setShowTrimModal(true)}
        onSplitClip={handleSplitClip}
        onDeleteClip={handleDeleteClip}
        onChangeAspectRatio={handleChangeAspectRatio}
        onChangeSpeed={handleChangeSpeed}
        onToggleMute={handleToggleMute}
        canSplit={canSplit}
      />

      {/* Bottom Timeline */}
      <Timeline
        project={project}
        activeClipId={activeClipId}
        currentTime={currentTime}
        totalDuration={totalDuration}
        onSelectClip={(id) => setActiveClipId(id)}
        onSeekTimeline={handleSeekTimeline}
        onOpenMediaPicker={() => setShowMediaPicker(true)}
        onMoveClipLeft={handleMoveClipLeft}
        onMoveClipRight={handleMoveClipRight}
      />

      {/* Trim Modal */}
      {showTrimModal && activeClip && project.mediaMap[activeClip.mediaId] && (
        <TrimModal
          clip={activeClip}
          media={project.mediaMap[activeClip.mediaId]}
          onApply={handleApplyTrim}
          onClose={() => setShowTrimModal(false)}
        />
      )}

      {/* Export Modal */}
      {showExportModal && (
        <ExportModal
          project={project}
          onClose={() => setShowExportModal(false)}
        />
      )}

      {/* Android Kotlin Code Viewer Modal */}
      {showAndroidCodeModal && (
        <AndroidCodeViewerModal onClose={() => setShowAndroidCodeModal(false)} />
      )}

      {/* Media Picker Sheet */}
      {showMediaPicker && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="w-full sm:max-w-md bg-[#161B22] border-t sm:border border-[#1F242D] rounded-t-3xl sm:rounded-3xl p-6 flex flex-col gap-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#1F242D] pb-3">
              <div className="flex items-center gap-2">
                <Film className="w-5 h-5 text-[#FF4A5A]" />
                <h3 className="text-base font-bold text-white">Add Video Media</h3>
              </div>
              <button
                onClick={() => setShowMediaPicker(false)}
                className="w-8 h-8 rounded-lg flex items-center justify-center text-[#8B949E] hover:text-white hover:bg-[#1F242D]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex flex-col gap-3">
              {/* Device Import */}
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-3 p-3.5 rounded-2xl bg-[#FF4A5A] hover:bg-[#ff3b4c] text-white font-semibold text-xs shadow-lg shadow-[#FF4A5A]/20 transition-all cursor-pointer"
              >
                <Plus className="w-5 h-5 stroke-[2.5]" />
                <div className="flex flex-col text-left">
                  <span>Import from Phone / Storage</span>
                  <span className="text-[10px] text-white/80 font-normal">Select MP4, WebM, or MOV videos</span>
                </div>
              </button>

              <div className="relative flex py-1 items-center">
                <div className="flex-grow border-t border-[#1F242D]" />
                <span className="flex-shrink mx-3 text-[11px] font-semibold text-[#8B949E] uppercase">
                  Or Add Ready Sample Clips
                </span>
                <div className="flex-grow border-t border-[#1F242D]" />
              </div>

              {/* Sample Clips buttons */}
              <div className="grid grid-cols-1 gap-2">
                <button
                  onClick={() => handleAddSampleClip('sunset')}
                  className="flex items-center justify-between p-3 rounded-xl bg-[#0B0E14] hover:bg-[#1F242D] border border-[#1F242D] text-left transition-colors cursor-pointer"
                >
                  <div className="flex flex-col">
                    <span className="text-xs font-bold text-white">Golden Sunset Coast</span>
                    <span className="text-[10px] text-[#8B949E]">Warm natural lighting cinematic scene</span>
                  </div>
                  <Sparkles className="w-4 h-4 text-[#f43f5e]" />
                </button>

                <button
                  onClick={() => handleAddSampleClip('cyberpunk')}
                  className="flex items-center justify-between p-3 rounded-xl bg-[#0B0E14] hover:bg-[#1F242D] border border-[#1F242D] text-left transition-colors cursor-pointer"
                >
                  <div className="flex flex-col">
                    <span className="text-xs font-bold text-white">Neo Cyber Grid</span>
                    <span className="text-[10px] text-[#8B949E]">High-tech neon perspective skyline</span>
                  </div>
                  <Sparkles className="w-4 h-4 text-[#00E5FF]" />
                </button>

                <button
                  onClick={() => handleAddSampleClip('skate')}
                  className="flex items-center justify-between p-3 rounded-xl bg-[#0B0E14] hover:bg-[#1F242D] border border-[#1F242D] text-left transition-colors cursor-pointer"
                >
                  <div className="flex flex-col">
                    <span className="text-xs font-bold text-white">Skatepark Stunt Run</span>
                    <span className="text-[10px] text-[#8B949E]">Action sports dynamic ramp movement</span>
                  </div>
                  <Sparkles className="w-4 h-4 text-[#fbbf24]" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Importing Spinner */}
      {isImporting && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="p-6 rounded-3xl bg-[#161B22] border border-[#00E5FF]/40 flex items-center gap-4 shadow-2xl">
            <div className="w-7 h-7 border-3 border-[#00E5FF] border-t-transparent rounded-full animate-spin" />
            <div className="flex flex-col">
              <span className="text-sm font-bold text-white">Importing Video Clip...</span>
              <span className="text-xs text-[#8B949E]">Extracting duration, resolution & thumbnail</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
