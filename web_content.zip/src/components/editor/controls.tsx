import * as Tooltip from "@radix-ui/react-tooltip";
import type { ReactNode } from "react";
import { cn } from "@/lib/cn";

export function IconButton({
  label,
  pressed,
  disabled,
  onClick,
  children,
  className,
}: {
  label: string;
  pressed?: boolean;
  disabled?: boolean;
  onClick?: () => void;
  children: ReactNode;
  className?: string;
}) {
  return (
    <Tooltip.Root>
      <Tooltip.Trigger asChild>
        <button
          type="button"
          aria-label={label}
          aria-pressed={pressed}
          disabled={disabled}
          onClick={onClick}
          className={cn(
            "inline-flex size-11 shrink-0 items-center justify-center rounded-sm text-muted",
            "transition-colors duration-150 hover:bg-surface-2 hover:text-fg",
            "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-steel",
            "disabled:pointer-events-none disabled:opacity-35",
            pressed && "bg-surface-2 text-fg",
            className,
          )}
        >
          {children}
        </button>
      </Tooltip.Trigger>
      <Tooltip.Portal>
        <Tooltip.Content
          side="bottom"
          sideOffset={6}
          className="z-50 rounded-sm bg-fg px-2 py-1 text-xs text-bg"
        >
          {label}
        </Tooltip.Content>
      </Tooltip.Portal>
    </Tooltip.Root>
  );
}

export function SliderRow({
  label,
  value,
  min,
  max,
  step,
  format,
  onBegin,
  onChange,
  onCommit,
  onReset,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  format: (value: number) => string;
  onBegin: () => void;
  onChange: (value: number) => void;
  onCommit: () => void;
  onReset: () => void;
}) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div className="grid grid-cols-[6rem_minmax(0,1fr)_3rem] items-center gap-2">
      <button
        type="button"
        className="truncate text-left text-xs text-muted hover:text-fg"
        onDoubleClick={onReset}
        title="Double-click to reset"
      >
        {label}
      </button>
      <div className="relative flex h-11 items-center">
        <div className="pointer-events-none absolute inset-x-0 h-px bg-border" />
        <div
          className="pointer-events-none absolute left-0 h-px bg-steel"
          style={{ width: `${Math.min(100, Math.max(0, pct))}%` }}
        />
        <input
          className="lumen-range relative z-10 w-full"
          type="range"
          aria-label={label}
          aria-valuetext={format(value)}
          min={min}
          max={max}
          step={step}
          value={value}
          onPointerDown={onBegin}
          onKeyDown={onBegin}
          onChange={(event) => onChange(Number(event.target.value))}
          onPointerUp={onCommit}
          onKeyUp={onCommit}
          onBlur={onCommit}
        />
      </div>
      <span className="text-right font-mono text-xs tabular-nums text-fg">{format(value)}</span>
    </div>
  );
}

export function TextButton({
  children,
  onClick,
  disabled,
  pressed,
}: {
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  pressed?: boolean;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      aria-pressed={pressed}
      onClick={onClick}
      className={cn(
        "inline-flex h-11 items-center justify-center rounded-sm px-3 text-sm text-fg",
        "transition-colors duration-150 hover:bg-surface-2",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-steel",
        "disabled:pointer-events-none disabled:opacity-35",
        pressed && "bg-surface-2",
      )}
    >
      {children}
    </button>
  );
}
