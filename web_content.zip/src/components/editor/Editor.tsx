import { useEffect, useRef, useState } from "react";
import * as Tooltip from "@radix-ui/react-tooltip";
import {
  ChevronDown,
  CircleHelp,
  ClipboardPaste,
  Copy,
  Crop,
  Download,
  Eye,
  ImagePlus,
  PanelRight,
  Redo2,
  RefreshCcw,
  SquareSplitHorizontal,
  Trash2,
  Undo2,
} from "lucide-react";
import { isEdited, suggestAuto } from "@/lib/photo/model";
import type { HistData } from "@/lib/photo/renderer";
import {
  createSamplePhotos,
  loadImports,
  loadSampleAdjustments,
  loadUserPresets,
  persistLibrary,
  photosFromFiles,
  SAMPLES,
} from "@/lib/photo/library";
import { useEditor } from "@/store/editor";
import { Filmstrip } from "@/components/editor/Filmstrip";
import { IconButton } from "@/components/editor/controls";
import { Panel } from "@/components/editor/Panel";
import { Stage, type StageHandle } from "@/components/editor/Stage";

function isTextField(target: EventTarget | null) {
  if (!(target instanceof HTMLElement)) return false;
  if (target.tagName === "TEXTAREA" || target.isContentEditable) return true;
  return target instanceof HTMLInputElement && ["text", "search", "number"].includes(target.type);
}

export function Editor() {
  const stageRef = useRef<StageHandle>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const [hist, setHist] = useState<HistData | null>(null);
  const [panelOpen, setPanelOpen] = useState(true);
  const [helpOpen, setHelpOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [armRemove, setArmRemove] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [dropping, setDropping] = useState(false);
  const photos = useEditor((state) => state.photos);
  const activeId = useEditor((state) => state.activeId);
  const photo = photos.find((item) => item.id === activeId) ?? null;
  const compare = useEditor((state) => state.compare);
  const cropMode = useEditor((state) => state.cropMode);
  const undoStack = useEditor((state) => state.undoStack);
  const redoStack = useEditor((state) => state.redoStack);
  const status = useEditor((state) => state.status);
  const setStatus = useEditor((state) => state.setStatus);

  useEffect(() => {
    let cancel = false;
    void (async () => {
      const [imports, presets, samples] = await Promise.all([
        loadImports(),
        Promise.resolve(loadUserPresets()),
        Promise.resolve(loadSampleAdjustments()),
      ]);
      if (cancel) return;
      useEditor.getState().hydrate([...createSamplePhotos(samples), ...imports], presets);
    })();
    return () => {
      cancel = true;
    };
  }, []);

  useEffect(() => {
    let timer = 0;
    const unsubscribe = useEditor.subscribe((state) => {
      if (!state.hydrated) return;
      window.clearTimeout(timer);
      timer = window.setTimeout(() => persistLibrary(state.photos, state.userPresets), 400);
    });
    return () => {
      unsubscribe();
      window.clearTimeout(timer);
    };
  }, []);

  useEffect(() => {
    if (!status) return;
    const timer = window.setTimeout(() => setStatus(""), 2000);
    return () => window.clearTimeout(timer);
  }, [status, setStatus]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const state = useEditor.getState();
      const text = isTextField(event.target);
      const meta = event.metaKey || event.ctrlKey;
      if (meta && event.key.toLowerCase() === "z") {
        event.preventDefault();
        if (event.shiftKey) state.redo();
        else state.undo();
        return;
      }
      if (meta && event.key.toLowerCase() === "e") {
        event.preventDefault();
        void exportAs("image/jpeg");
        return;
      }
      if (text) return;
      if (event.key === "\\") {
        event.preventDefault();
        if (!event.repeat) state.setHoldBefore(true);
        return;
      }
      if (event.key.toLowerCase() === "c") {
        state.setCropMode(!state.cropMode);
        return;
      }
      if (event.key.toLowerCase() === "j") {
        state.setClipWarn(!state.clipWarn);
        return;
      }
      if (event.key === "0") {
        state.setView(1, { x: 0, y: 0 });
        return;
      }
      if (event.key === "1") {
        stageRef.current?.zoomActual();
        return;
      }
      if (event.key === "=" || event.key === "+") {
        state.setView(Math.min(12, state.zoom * 1.25), state.pan);
        return;
      }
      if (event.key === "-" || event.key === "_") {
        state.setView(Math.max(0.2, state.zoom / 1.25), state.pan);
        return;
      }
      const range = event.target instanceof HTMLInputElement && event.target.type === "range";
      if (range) return;
      if (event.key === "ArrowRight" || event.key === "ArrowLeft") {
        const index = state.photos.findIndex((item) => item.id === state.activeId);
        const next = event.key === "ArrowRight" ? index + 1 : index - 1;
        const photoNext = state.photos[next];
        if (photoNext) state.setActive(photoNext.id);
      }
    };
    const onKeyUp = (event: KeyboardEvent) => {
      if (event.key === "\\") useEditor.getState().setHoldBefore(false);
    };
    const clearHold = () => useEditor.getState().setHoldBefore(false);
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", clearHold);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", clearHold);
    };
  }, []);

  async function importFiles(files: File[]) {
    const items = await photosFromFiles(files);
    useEditor.getState().addPhotos(items);
  }

  async function exportAs(mime: "image/jpeg" | "image/png") {
    const current = useEditor.getState().active();
    if (!current || exporting) return;
    setExporting(true);
    setExportOpen(false);
    try {
      const blob = await stageRef.current?.exportFrame(mime);
      if (!blob) {
        useEditor.getState().setStatus("Export failed");
        return;
      }
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      const ext = mime === "image/png" ? "png" : "jpg";
      const slug = current.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
      link.href = url;
      link.download = `lumen-${slug || "photo"}.${ext}`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
      useEditor.getState().setStatus(ext === "png" ? "PNG exported" : "JPEG exported");
    } finally {
      setExporting(false);
    }
  }

  function onAuto() {
    const image = stageRef.current?.getSource();
    const current = useEditor.getState().active();
    if (!image || !current) return;
    const suggestion = suggestAuto(image, current.width, current.height);
    if (suggestion) useEditor.getState().auto(suggestion);
  }

  const missingSamples = SAMPLES.some((sample) => !photos.some((item) => item.id === sample.id));
  const edited = photo ? isEdited(photo.adjustments) : false;

  return (
    <Tooltip.Provider delayDuration={400}>
      <div
        className="lumen-app relative flex h-dvh flex-col overflow-hidden bg-bg text-fg"
        onDragOver={(event) => {
          if (![...event.dataTransfer.types].includes("Files")) return;
          event.preventDefault();
          setDropping(true);
        }}
        onDragLeave={() => setDropping(false)}
        onDrop={(event) => {
          if (!event.dataTransfer.files.length) return;
          event.preventDefault();
          setDropping(false);
          void importFiles([...event.dataTransfer.files]);
        }}
        onPaste={(event) => {
          const files = [...event.clipboardData.files];
          if (!files.length) return;
          event.preventDefault();
          void importFiles(files);
        }}
      >
        <header className="flex h-12 shrink-0 items-center gap-1 border-b border-border bg-surface px-2 sm:px-3">
          <div className="mr-1 flex items-baseline gap-2 px-1">
            <span className="text-base font-semibold tracking-tight">Lumen</span>
            <span className="hidden text-xs text-subtle sm:inline">Develop</span>
          </div>
          <p className="mr-auto hidden min-w-0 truncate text-sm text-muted sm:block">
            {photo ? photo.name : "No photo"}
            {edited && <span className="ml-2 text-steel">Edited</span>}
          </p>
          <IconButton label="Import photos" onClick={() => fileRef.current?.click()}>
            <ImagePlus className="size-4" />
          </IconButton>
          <IconButton label="Undo" disabled={!undoStack.length} onClick={() => useEditor.getState().undo()}>
            <Undo2 className="size-4" />
          </IconButton>
          <IconButton label="Redo" disabled={!redoStack.length} onClick={() => useEditor.getState().redo()}>
            <Redo2 className="size-4" />
          </IconButton>
          <IconButton
            label={compare === "before" ? "Showing original" : "Show original"}
            pressed={compare === "before"}
            onClick={() => useEditor.getState().setCompare(compare === "before" ? "off" : "before")}
          >
            <Eye className="size-4" />
          </IconButton>
          <IconButton
            label="Split compare"
            pressed={compare === "split"}
            onClick={() => useEditor.getState().setCompare(compare === "split" ? "off" : "split")}
            className="hidden sm:inline-flex"
          >
            <SquareSplitHorizontal className="size-4" />
          </IconButton>
          <IconButton
            label={panelOpen ? "Hide adjustments" : "Show adjustments"}
            pressed={panelOpen}
            onClick={() => setPanelOpen((open) => !open)}
            className="hidden md:inline-flex"
          >
            <PanelRight className="size-4" />
          </IconButton>
          <IconButton
            label="Crop and straighten"
            pressed={cropMode}
            onClick={() => {
              const next = !cropMode;
              useEditor.getState().setCropMode(next);
              if (next && window.matchMedia("(max-width: 767px)").matches) setPanelOpen(false);
              if (!next) setPanelOpen(true);
            }}
          >
            <Crop className="size-4" />
          </IconButton>
          <div className="hidden items-center md:flex">
            <IconButton label="Copy settings" onClick={() => useEditor.getState().copyLook()}>
              <Copy className="size-4" />
            </IconButton>
            <IconButton label="Paste settings" onClick={() => useEditor.getState().pasteLook()}>
              <ClipboardPaste className="size-4" />
            </IconButton>
            <IconButton label="Reset adjustments" onClick={() => useEditor.getState().reset()}>
              <RefreshCcw className="size-4" />
            </IconButton>
            <IconButton
              label={armRemove ? "Click again to remove" : "Remove photo"}
              disabled={!photo}
              pressed={armRemove}
              onClick={() => {
                if (!photo) return;
                if (!armRemove) {
                  setArmRemove(true);
                  window.setTimeout(() => setArmRemove(false), 2400);
                  return;
                }
                useEditor.getState().removePhoto(photo.id);
                setArmRemove(false);
              }}
            >
              <Trash2 className="size-4" />
            </IconButton>
            <IconButton label="Shortcuts" pressed={helpOpen} onClick={() => setHelpOpen((open) => !open)}>
              <CircleHelp className="size-4" />
            </IconButton>
          </div>
          <div className="relative md:hidden">
            <IconButton label="More" pressed={moreOpen} onClick={() => setMoreOpen((open) => !open)}>
              <ChevronDown className="size-4" />
            </IconButton>
            {moreOpen && (
              <div className="absolute right-0 z-30 mt-1 w-52 rounded-md border border-border bg-surface p-1">
                <MenuRow label="Copy settings" onClick={() => { useEditor.getState().copyLook(); setMoreOpen(false); }} />
                <MenuRow label="Paste settings" onClick={() => { useEditor.getState().pasteLook(); setMoreOpen(false); }} />
                <MenuRow label="Split compare" onClick={() => { useEditor.getState().setCompare(compare === "split" ? "off" : "split"); setMoreOpen(false); }} />
                <MenuRow label="Reset adjustments" onClick={() => { useEditor.getState().reset(); setMoreOpen(false); }} />
                <MenuRow
                  label={armRemove ? "Confirm remove" : "Remove photo"}
                  onClick={() => {
                    if (!photo) return;
                    if (!armRemove) {
                      setArmRemove(true);
                      return;
                    }
                    useEditor.getState().removePhoto(photo.id);
                    setArmRemove(false);
                    setMoreOpen(false);
                  }}
                />
                <MenuRow label="Shortcuts" onClick={() => { setHelpOpen(true); setMoreOpen(false); }} />
                {missingSamples && (
                  <MenuRow label="Restore samples" onClick={() => { useEditor.getState().restoreSamples(); setMoreOpen(false); }} />
                )}
              </div>
            )}
          </div>
          <div className="relative flex shrink-0">
            <button
              type="button"
              disabled={!photo || exporting}
              onClick={() => void exportAs("image/jpeg")}
              className="inline-flex h-9 items-center gap-2 rounded-l-sm bg-fg px-3 text-sm text-bg disabled:opacity-35"
            >
              <Download className="size-4" />
              <span className="hidden sm:inline">{exporting ? "Exporting" : "Export"}</span>
            </button>
            <button
              type="button"
              aria-label="Export options"
              disabled={!photo || exporting}
              onClick={() => setExportOpen((open) => !open)}
              className="inline-flex h-9 items-center rounded-r-sm border-l border-bg/20 bg-fg px-2 text-bg disabled:opacity-35"
            >
              <ChevronDown className="size-4" />
            </button>
            {exportOpen && (
              <div className="absolute right-0 z-30 mt-1 w-40 rounded-md border border-border bg-surface p-1">
                <MenuRow label="JPEG" onClick={() => void exportAs("image/jpeg")} />
                <MenuRow label="PNG" onClick={() => void exportAs("image/png")} />
              </div>
            )}
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={(event) => {
              const files = [...(event.target.files ?? [])];
              event.target.value = "";
              void importFiles(files);
            }}
          />
        </header>
        <div className="flex min-h-0 flex-1 flex-col md:flex-row">
          <Stage ref={stageRef} onHistogram={setHist} />
          {panelOpen && <Panel hist={hist} onAuto={onAuto} onClose={() => setPanelOpen(false)} />}
        </div>
        <div className="flex items-center border-t border-border bg-surface md:hidden">
          <button
            type="button"
            className="h-11 flex-1 text-sm text-muted"
            onClick={() => setPanelOpen((open) => !open)}
          >
            {panelOpen ? "Hide adjustments" : "Show adjustments"}
          </button>
        </div>
        <Filmstrip />
        {helpOpen && (
          <div className="absolute inset-0 z-40 flex items-end justify-center bg-bg/60 p-4 sm:items-center" onClick={() => setHelpOpen(false)}>
            <div
              className="w-full max-w-md rounded-xl border border-border bg-surface p-4"
              onClick={(event) => event.stopPropagation()}
            >
              <div className="mb-3 flex items-center justify-between">
                <h2 className="text-base font-medium">Shortcuts</h2>
                <button type="button" className="h-11 rounded-sm px-3 text-sm text-muted hover:text-fg" onClick={() => setHelpOpen(false)}>
                  Close
                </button>
              </div>
              <dl className="grid grid-cols-[7rem_1fr] gap-y-2 text-sm">
                <dt className="font-mono text-xs text-steel">\</dt>
                <dd className="text-muted">Hold to see the original</dd>
                <dt className="font-mono text-xs text-steel">C</dt>
                <dd className="text-muted">Crop and straighten</dd>
                <dt className="font-mono text-xs text-steel">J</dt>
                <dd className="text-muted">Highlight clipping</dd>
                <dt className="font-mono text-xs text-steel">0 / 1</dt>
                <dd className="text-muted">Fit, then actual pixels</dd>
                <dt className="font-mono text-xs text-steel">Arrows</dt>
                <dd className="text-muted">Previous or next photo</dd>
                <dt className="font-mono text-xs text-steel">Ctrl Z</dt>
                <dd className="text-muted">Undo, Shift to redo</dd>
                <dt className="font-mono text-xs text-steel">Scroll</dt>
                <dd className="text-muted">Zoom toward the pointer</dd>
              </dl>
              <p className="mt-4 text-xs text-pretty text-subtle">
                Double-click a slider name to reset it. Drag the photo to pan. Import stays in this browser.
              </p>
            </div>
          </div>
        )}
        {dropping && (
          <div className="pointer-events-none absolute inset-4 z-40 flex items-center justify-center rounded-xl border border-steel bg-bg/80">
            <p className="text-sm text-fg">Drop to import</p>
          </div>
        )}
      </div>
    </Tooltip.Provider>
  );
}

function MenuRow({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex h-11 w-full items-center rounded-sm px-3 text-left text-sm text-fg hover:bg-surface-2"
    >
      {label}
    </button>
  );
}
