import React, { useState } from 'react';
import {
  X,
  Download,
  Share2,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCcw,
  Sparkles,
  Settings,
  Film
} from 'lucide-react';
import { Project, ExportSettings } from '../../types/editor';
import { videoExportEngine, RenderProgress } from '../../services/videoMerger';
import { formatTime } from '../../utils/time';

interface ExportModalProps {
  project: Project;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ project, onClose }) => {
  const [resolution, setResolution] = useState<'720p' | '1080p'>('1080p');
  const [quality, setQuality] = useState<'standard' | 'high'>('high');
  const [isExporting, setIsExporting] = useState(false);
  const [progress, setProgress] = useState<RenderProgress | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [exportedResult, setExportedResult] = useState<{
    blob: Blob;
    url: string;
    duration: number;
  } | null>(null);

  const totalClips = project.clips.length;
  const totalDuration = project.clips.reduce(
    (acc, c) => acc + (c.sourceOut - c.sourceIn) / (c.speed || 1.0),
    0
  );

  const handleStartExport = async () => {
    setIsExporting(true);
    setError(null);
    setProgress({
      progress: 0,
      currentClipIndex: 1,
      totalClips,
      statusText: 'Initializing video merger pipeline...',
    });

    try {
      const settings: ExportSettings = {
        resolution,
        quality,
        format: 'mp4',
        fps: 30,
      };

      const result = await videoExportEngine.exportProject(project, settings, (p) => {
        setProgress(p);
      });

      setExportedResult(result);
    } catch (err: unknown) {
      if (err instanceof Error) {
        setError(err.message || 'Export failed.');
      } else {
        setError('An unexpected error occurred during export.');
      }
    } finally {
      setIsExporting(false);
    }
  };

  const handleCancelExport = () => {
    videoExportEngine.cancel();
    setIsExporting(false);
    setProgress(null);
  };

  const handleDownload = () => {
    if (!exportedResult) return;
    const a = document.createElement('a');
    a.href = exportedResult.url;
    const cleanName = project.name.toLowerCase().replace(/[^a-z0-9]/g, '_');
    a.download = `${cleanName}_${resolution}.mp4`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleShare = async () => {
    if (!exportedResult) return;
    try {
      const file = new File([exportedResult.blob], `${project.name}.mp4`, {
        type: exportedResult.blob.type || 'video/mp4',
      });
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: project.name,
          text: 'Edited with CutPro — Pro Video Editor & Slideshow Maker',
        });
      } else {
        handleDownload();
      }
    } catch {
      handleDownload();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-[#161B22] border border-[#1F242D] rounded-3xl p-6 flex flex-col gap-5 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#1F242D] pb-3">
          <div className="flex items-center gap-2">
            <Film className="w-5 h-5 text-[#00E5FF]" />
            <h3 className="text-base font-bold text-white">Export Video Project</h3>
          </div>
          {!isExporting && (
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg flex items-center justify-center text-[#8B949E] hover:text-white hover:bg-[#1F242D] transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Content depending on state */}
        {exportedResult ? (
          /* State 1: Export Complete */
          <div className="flex flex-col gap-4">
            <div className="p-4 rounded-2xl bg-[#00E5FF]/10 border border-[#00E5FF]/30 flex items-center gap-3">
              <CheckCircle2 className="w-6 h-6 text-[#00E5FF] shrink-0" />
              <div className="flex flex-col">
                <span className="text-sm font-bold text-white">Export Successful!</span>
                <span className="text-xs text-[#8B949E]">
                  Merged {totalClips} clips into single MP4 · Duration: {formatTime(exportedResult.duration)}
                </span>
              </div>
            </div>

            {/* In-modal video player */}
            <div className="relative aspect-video w-full rounded-2xl bg-black overflow-hidden border border-[#1F242D]">
              <video
                src={exportedResult.url}
                controls
                autoPlay
                playsInline
                className="w-full h-full object-contain"
              />
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={handleDownload}
                className="flex items-center justify-center gap-2 py-3 bg-[#00E5FF] hover:bg-[#33ebff] text-black font-bold text-sm rounded-xl shadow-lg shadow-[#00E5FF]/20 transition-all cursor-pointer"
              >
                <Download className="w-4 h-4 stroke-[2.5]" />
                <span>Save to Device</span>
              </button>

              <button
                onClick={handleShare}
                className="flex items-center justify-center gap-2 py-3 bg-[#1F242D] hover:bg-[#2A313D] text-white font-semibold text-sm rounded-xl border border-white/10 transition-colors cursor-pointer"
              >
                <Share2 className="w-4 h-4 text-[#00E5FF]" />
                <span>Share Video</span>
              </button>
            </div>

            <button
              onClick={onClose}
              className="w-full py-2.5 text-xs text-[#8B949E] hover:text-white transition-colors"
            >
              Return to Editor
            </button>
          </div>
        ) : isExporting ? (
          /* State 2: Rendering in Progress */
          <div className="flex flex-col gap-5 py-4">
            <div className="flex flex-col items-center text-center gap-2">
              <div className="w-12 h-12 rounded-full border-3 border-[#00E5FF] border-t-transparent animate-spin flex items-center justify-center" />
              <h4 className="text-base font-bold text-white mt-2">Merging & Rendering Video</h4>
              <p className="text-xs text-[#8B949E] font-mono">
                {progress?.statusText || 'Processing frames...'}
              </p>
            </div>

            {/* Progress Bar */}
            <div className="flex flex-col gap-2">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-[#8B949E]">
                  Clip {progress?.currentClipIndex} of {progress?.totalClips}
                </span>
                <span className="text-[#00E5FF] font-bold">{progress?.progress || 0}%</span>
              </div>
              <div className="w-full h-3 rounded-full bg-[#0B0E14] border border-[#1F242D] overflow-hidden p-0.5">
                <div
                  className="h-full bg-gradient-to-r from-[#FF4A5A] to-[#00E5FF] rounded-full transition-all duration-300"
                  style={{ width: `${progress?.progress || 0}%` }}
                />
              </div>
            </div>

            <div className="p-3 rounded-xl bg-[#0B0E14] border border-[#1F242D] flex items-center justify-between text-xs text-[#8B949E]">
              <span>Hardware Acceleration</span>
              <span className="text-white font-mono">Active (Canvas2D + WebAudio)</span>
            </div>

            <button
              onClick={handleCancelExport}
              className="w-full py-2.5 rounded-xl bg-[#FF4A5A]/20 hover:bg-[#FF4A5A]/30 text-[#FF4A5A] text-xs font-bold transition-colors cursor-pointer"
            >
              Cancel Export
            </button>
          </div>
        ) : (
          /* State 3: Export Configuration */
          <div className="flex flex-col gap-4">
            {error && (
              <div className="p-3 rounded-xl bg-[#FF4A5A]/10 border border-[#FF4A5A]/30 flex items-center gap-2 text-xs text-[#FF4A5A]">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Resolution Selector */}
            <div className="flex flex-col gap-2">
              <label className="text-xs font-semibold text-[#8B949E] uppercase tracking-wider">
                Output Resolution
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setResolution('1080p')}
                  className={`p-3 rounded-xl border flex flex-col items-start gap-1 transition-all ${
                    resolution === '1080p'
                      ? 'bg-[#00E5FF]/10 border-[#00E5FF] text-white shadow-sm'
                      : 'bg-[#0B0E14] border-[#1F242D] text-[#8B949E] hover:border-[#2A313D]'
                  }`}
                >
                  <span className="text-sm font-bold text-white">1080p Full HD</span>
                  <span className="text-[11px] text-[#8B949E]">1920 × 1080 (Recommended)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setResolution('720p')}
                  className={`p-3 rounded-xl border flex flex-col items-start gap-1 transition-all ${
                    resolution === '720p'
                      ? 'bg-[#00E5FF]/10 border-[#00E5FF] text-white shadow-sm'
                      : 'bg-[#0B0E14] border-[#1F242D] text-[#8B949E] hover:border-[#2A313D]'
                  }`}
                >
                  <span className="text-sm font-bold text-white">720p HD</span>
                  <span className="text-[11px] text-[#8B949E]">1280 × 720 (Faster)</span>
                </button>
              </div>
            </div>

            {/* Quality Selector */}
            <div className="flex flex-col gap-2">
              <label className="text-xs font-semibold text-[#8B949E] uppercase tracking-wider">
                Encoding Quality & Bitrate
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setQuality('high')}
                  className={`p-2.5 rounded-xl border text-xs font-semibold transition-all ${
                    quality === 'high'
                      ? 'bg-[#00E5FF]/10 border-[#00E5FF] text-white'
                      : 'bg-[#0B0E14] border-[#1F242D] text-[#8B949E]'
                  }`}
                >
                  High (8 Mbps)
                </button>

                <button
                  type="button"
                  onClick={() => setQuality('standard')}
                  className={`p-2.5 rounded-xl border text-xs font-semibold transition-all ${
                    quality === 'standard'
                      ? 'bg-[#00E5FF]/10 border-[#00E5FF] text-white'
                      : 'bg-[#0B0E14] border-[#1F242D] text-[#8B949E]'
                  }`}
                >
                  Standard (4.5 Mbps)
                </button>
              </div>
            </div>

            {/* Project Summary Specs */}
            <div className="p-3.5 rounded-xl bg-[#0B0E14] border border-[#1F242D] flex flex-col gap-2 text-xs">
              <div className="flex justify-between text-[#8B949E]">
                <span>Timeline Clips:</span>
                <span className="text-white font-mono">{totalClips} segments</span>
              </div>
              <div className="flex justify-between text-[#8B949E]">
                <span>Estimated Duration:</span>
                <span className="text-[#00E5FF] font-mono font-bold">
                  {formatTime(totalDuration)}
                </span>
              </div>
              <div className="flex justify-between text-[#8B949E]">
                <span>Format:</span>
                <span className="text-white font-mono">MP4 (H.264 / AAC)</span>
              </div>
            </div>

            {/* Primary Action Button */}
            <div className="pt-2">
              <button
                onClick={handleStartExport}
                disabled={totalClips === 0}
                className="w-full py-3.5 bg-[#00E5FF] hover:bg-[#33ebff] active:scale-[0.98] text-black font-bold text-sm rounded-xl shadow-lg shadow-[#00E5FF]/20 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                <span>Start MP4 Export</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
