import React, { useState, useEffect } from 'react';
import {
  X,
  Download,
  AlertTriangle,
  CheckCircle2,
  Cpu,
  RefreshCw,
  HardDrive,
  Play,
  Sparkles,
  Crown,
} from 'lucide-react';
import { Project, ExportSettings, ExportedProjectRecord, UserSubscription } from '../../types/editor';
import { Language, translations } from '../../i18n/translations';
import { inspectDeviceHardware, isResolutionSupported, DeviceCapability } from '../../services/deviceCapability';
import { exportEngine, ExportProgress } from '../../services/exportEngine';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: Project;
  subscription: UserSubscription;
  onOpenPremium: () => void;
  onExportSuccess: (record: ExportedProjectRecord) => void;
  language: Language;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  project,
  subscription,
  onOpenPremium,
  onExportSuccess,
  language,
}) => {
  const [resolution, setResolution] = useState<'480p' | '720p' | '1080p' | '1440p' | '4k' | '8k'>('1080p');
  const [fps, setFps] = useState<number>(30);
  const [bitratePreset, setBitratePreset] = useState<'low' | 'medium' | 'high' | 'very-high'>('medium');
  const [hardware, setHardware] = useState<DeviceCapability | null>(null);

  const [isExporting, setIsExporting] = useState(false);
  const [progress, setProgress] = useState<ExportProgress | null>(null);
  const [exportedRecord, setExportedRecord] = useState<ExportedProjectRecord | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      const cap = inspectDeviceHardware();
      setHardware(cap);
      setProgress(null);
      setExportedRecord(null);
      setErrorMessage(null);
      setIsExporting(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;
  const t = translations[language];

  // Resolutions configuration
  const resolutions = [
    { id: '480p' as const, label: '480p SD', w: 854, h: 480, badge: 'Fast' },
    { id: '720p' as const, label: '720p HD', w: 1280, h: 720, badge: 'Standard' },
    { id: '1080p' as const, label: '1080p Full HD', w: 1920, h: 1080, badge: 'Recommended' },
    { id: '1440p' as const, label: '1440p 2K', w: 2560, h: 1440, badge: 'Crisp' },
    { id: '4k' as const, label: '4K Ultra HD', w: 3840, h: 2160, badge: 'Ultra' },
    { id: '8k' as const, label: '8K Cinematic', w: 7680, h: 4320, badge: 'Extreme' },
  ];

  const currentResConfig = resolutions.find(r => r.id === resolution) || resolutions[2];
  const resSupport = isResolutionSupported(resolution);

  // Estimate file size based on duration, resolution, and bitrate preset
  const estimateFileSizeMB = () => {
    let mbps = 5;
    if (bitratePreset === 'low') mbps = 2.5;
    else if (bitratePreset === 'medium') mbps = 5;
    else if (bitratePreset === 'high') mbps = 10;
    else if (bitratePreset === 'very-high') mbps = 20;

    if (resolution === '4k') mbps = Math.max(mbps, 30);
    if (resolution === '8k') mbps = Math.max(mbps, 60);

    const totalSeconds = project.duration || 5;
    const megabytes = (mbps * totalSeconds) / 8;
    return megabytes.toFixed(1);
  };

  const handleStartExport = async () => {
    setIsExporting(true);
    setErrorMessage(null);

    // Calculate dimensions based on project aspect ratio
    let targetW = currentResConfig.w;
    let targetH = currentResConfig.h;

    if (project.aspectRatio === '9:16') {
      targetW = currentResConfig.h;
      targetH = currentResConfig.w;
    } else if (project.aspectRatio === '1:1') {
      targetW = currentResConfig.h;
      targetH = currentResConfig.h;
    }

    const settings: ExportSettings = {
      resolution,
      width: targetW,
      height: targetH,
      fps,
      bitratePreset,
      format: 'mp4',
      includeWatermark: false,
    };

    try {
      const record = await exportEngine.exportProject(
        project,
        settings,
        true,
        (prog) => setProgress(prog)
      );
      setExportedRecord(record);
      setIsExporting(false);
      onExportSuccess(record);
    } catch (err: unknown) {
      setIsExporting(false);
      const msg = err instanceof Error ? err.message : 'Export failed';
      setErrorMessage(msg);
    }
  };

  const handleCancelExport = () => {
    exportEngine.cancel();
    setIsExporting(false);
    setProgress(null);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-2xl p-5 sm:p-6 text-white shadow-2xl flex flex-col overflow-hidden max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-black">
              <Download className="w-4 h-4 stroke-[2.5]" />
            </div>
            <div>
              <h2 className="text-lg font-bold">{t.exportTitle}</h2>
              <p className="text-xs text-neutral-400">100% Local On-Device Rendering</p>
            </div>
          </div>
          {!isExporting && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto py-4 space-y-4 pr-1">
          {/* Result view when export is complete */}
          {exportedRecord ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto ring-4 ring-emerald-500/10">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">{t.exportComplete}</h3>
                <p className="text-xs text-neutral-400 font-mono mt-1">
                  {exportedRecord.resolution} • {exportedRecord.fps} FPS • ≈ {(exportedRecord.fileSize / (1024 * 1024)).toFixed(1)} MB
                </p>
              </div>

              {/* Inline Video Preview */}
              <video
                src={exportedRecord.videoUrl}
                controls
                autoPlay
                className="w-full max-h-48 rounded-xl bg-black object-contain border border-neutral-800"
              />

              <div className="flex items-center justify-center gap-2 pt-2">
                <a
                  href={exportedRecord.videoUrl}
                  download={`${project.name.replace(/\s+/g, '_')}_clipora.mp4`}
                  className="py-3 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-black font-extrabold text-xs shadow-lg shadow-amber-500/25 flex items-center gap-2 active:scale-95 transition-all"
                >
                  <Download className="w-4 h-4 stroke-[3]" />
                  <span>{t.downloadVideo}</span>
                </a>
                <button
                  onClick={onClose}
                  className="py-3 px-4 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold"
                >
                  {t.close}
                </button>
              </div>
            </div>
          ) : isExporting ? (
            /* Progress view during rendering */
            <div className="py-8 text-center space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mx-auto">
                <RefreshCw className="w-7 h-7 text-amber-400 animate-spin" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">{t.exportingProgress}</h3>
                <p className="text-xs text-neutral-400 mt-1">
                  Rendering frames with hardware Canvas & WebAudio API
                </p>
              </div>

              {progress && (
                <div className="space-y-2 max-w-sm mx-auto">
                  <div className="w-full bg-neutral-800 rounded-full h-2.5 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-amber-500 to-orange-500 h-full rounded-full transition-all duration-150"
                      style={{ width: `${progress.percent}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[11px] text-neutral-400 font-mono">
                    <span>{progress.percent}%</span>
                    <span>Frame {progress.frame} / {progress.totalFrames}</span>
                    <span>{progress.timeRemainingSec}s left</span>
                  </div>
                </div>
              )}

              <button
                onClick={handleCancelExport}
                className="py-2 px-4 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-red-400 text-xs font-semibold"
              >
                {t.cancelExport}
              </button>
            </div>
          ) : (
            /* Settings Selection before starting export */
            <>
              {/* Error banner if any */}
              {errorMessage && (
                <div className="p-3 rounded-xl bg-red-950/80 border border-red-800 text-xs text-red-300 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Hardware Capability Info */}
              <div className="bg-neutral-950/70 p-3 rounded-xl border border-neutral-800 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-emerald-400" />
                  <span className="font-semibold text-neutral-200">{t.deviceCapability}:</span>
                </div>
                <span className="text-[11px] font-mono text-emerald-400 font-bold">
                  {hardware?.supports8K ? '8K & 4K Ready' : '4K Ready'}
                </span>
              </div>

              {/* Resolution options */}
              <div>
                <label className="text-xs font-semibold text-neutral-300 block mb-2">
                  {t.resolution}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {resolutions.map((r) => {
                    const isSelected = resolution === r.id;
                    const isSupported = r.id === '8k' ? hardware?.supports8K : true;

                    return (
                      <button
                        key={r.id}
                        type="button"
                        onClick={() => setResolution(r.id)}
                        className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all ${
                          isSelected
                            ? 'border-amber-400 bg-amber-500/15 text-white ring-1 ring-amber-400'
                            : 'border-neutral-800 bg-neutral-950/60 text-neutral-400 hover:border-neutral-700'
                        } ${!isSupported ? 'opacity-50' : ''}`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-bold text-neutral-200">{r.id.toUpperCase()}</span>
                          <span className="text-[9px] font-mono px-1 rounded bg-neutral-800 text-neutral-400">
                            {r.badge}
                          </span>
                        </div>
                        <span className="text-[10px] text-neutral-500 font-mono">{r.w}x{r.h}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 8K / 4K Hardware Warning if applicable */}
              {resSupport.warning && (
                <div className="p-2.5 rounded-xl bg-amber-950/40 border border-amber-800/60 text-[11px] text-amber-300 flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{resSupport.warning}</span>
                </div>
              )}

              {/* Frame Rate & Bitrate Row */}
              <div className="grid grid-cols-2 gap-3">
                {/* Frame Rate */}
                <div>
                  <label className="text-xs font-semibold text-neutral-300 block mb-1.5">
                    {t.frameRate}
                  </label>
                  <select
                    value={fps}
                    onChange={(e) => setFps(Number(e.target.value))}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                  >
                    <option value={24}>24 FPS (Cinematic)</option>
                    <option value={25}>25 FPS (PAL)</option>
                    <option value={30}>30 FPS (Standard)</option>
                    <option value={60}>60 FPS (Ultra Smooth)</option>
                  </select>
                </div>

                {/* Bitrate / Quality */}
                <div>
                  <label className="text-xs font-semibold text-neutral-300 block mb-1.5">
                    {t.bitrate}
                  </label>
                  <select
                    value={bitratePreset}
                    onChange={(e) => setBitratePreset(e.target.value as typeof bitratePreset)}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-white"
                  >
                    <option value="low">Low (Small size)</option>
                    <option value="medium">Medium (Recommended)</option>
                    <option value="high">High (HQ Creator)</option>
                    <option value="very-high">Very High (Master)</option>
                  </select>
                </div>
              </div>

              {/* Estimated File Size */}
              <div className="bg-neutral-950/60 p-3 rounded-xl border border-neutral-800 flex items-center justify-between text-xs">
                <span className="text-neutral-400">{t.estimatedSize}:</span>
                <span className="font-mono text-amber-400 font-bold">≈ {estimateFileSizeMB()} MB</span>
              </div>

              {/* 100% Free & No Watermark Banner */}
              <div className="bg-emerald-950/40 p-3 rounded-xl border border-emerald-500/30 flex items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="text-emerald-300 font-bold">
                    {language === 'hi' ? 'बिना वॉटरमार्क के 100% मुफ़्त एक्सपोर्ट' : '100% Free Export • No Watermark'}
                  </span>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold shrink-0">
                  NO WATERMARK
                </span>
              </div>

              {/* Start Export Button */}
              <button
                onClick={handleStartExport}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-orange-500 via-amber-500 to-amber-600 hover:from-orange-400 hover:to-amber-500 text-black font-extrabold text-sm shadow-xl shadow-orange-500/25 active:scale-[0.99] transition-all flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4 stroke-[3]" />
                <span>{t.startExport}</span>
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
