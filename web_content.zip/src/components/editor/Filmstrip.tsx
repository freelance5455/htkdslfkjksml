import { isEdited } from "@/lib/photo/model";
import { useEditor } from "@/store/editor";
import { cn } from "@/lib/cn";

export function Filmstrip() {
  const photos = useEditor((state) => state.photos);
  const activeId = useEditor((state) => state.activeId);
  const setActive = useEditor((state) => state.setActive);

  return (
    <div className="flex h-20 shrink-0 items-center gap-2 border-t border-border bg-surface px-3">
      <span className="hidden w-12 shrink-0 font-mono text-xs tabular-nums text-subtle sm:block">
        {photos.length ? `${Math.max(1, photos.findIndex((photo) => photo.id === activeId) + 1)}/${photos.length}` : "0"}
      </span>
      <div className="lumen-scroll flex min-w-0 flex-1 items-center gap-2 overflow-x-auto">
        {photos.map((photo) => {
          const active = photo.id === activeId;
          const edited = isEdited(photo.adjustments);
          return (
            <button
              key={photo.id}
              type="button"
              aria-label={photo.name}
              aria-current={active ? "true" : undefined}
              onClick={() => setActive(photo.id)}
              className={cn(
                "relative h-14 w-20 shrink-0 overflow-hidden rounded-sm",
                "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-steel",
                active ? "ring-2 ring-steel" : "opacity-75 hover:opacity-100",
              )}
            >
              <img src={photo.src} alt="" draggable={false} className="h-full w-full object-cover" />
              {edited && <span className="absolute top-1 right-1 size-1.5 rounded-full bg-fg" />}
            </button>
          );
        })}
        {!photos.length && <p className="text-sm text-muted">No photos in the tray</p>}
      </div>
    </div>
  );
}
