import React, { useState, useRef } from 'react';
import {
  Plus,
  Scissors,
  Split,
  Combine,
  Crop,
  Gauge,
  Trash2,
  ChevronUp,
  Volume2,
  VolumeX
} from 'lucide-react';
import { TimelineClip, AspectRatioType } from '../../types/editor';

interface EditingToolbarProps {
  activeClip: TimelineClip | null;
  aspectRatio: AspectRatioType;
  onOpenMediaPicker: () => void;
  onOpenTrim: () => void;
  onSplitClip: () => void;
  onDeleteClip: () => void;
  onChangeAspectRatio: (ratio: AspectRatioType) => void;
  onChangeSpeed: (speed: number) => void;
  onToggleMute: () => void;
  canSplit: boolean;
}

export const EditingToolbar: React.FC<EditingToolbarProps> = ({
  activeClip,
  aspectRatio,
  onOpenMediaPicker,
  onOpenTrim,
  onSplitClip,
  onDeleteClip,
  onChangeAspectRatio,
  onChangeSpeed,
  onToggleMute,
  canSplit,
}) => {
  const [showCropMenu, setShowCropMenu] = useState(false);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);

  const ratios: { label: string; value: AspectRatioType }[] = [
    { label: '16:9 (Landscape)', value: '16:9' },
    { label: '9:16 (Portrait / Reels)', value: '9:16' },
    { label: '1:1 (Square)', value: '1:1' },
    { label: '4:5 (Feed)', value: '4:5' },
  ];

  const speeds = [0.5, 1.0, 1.5, 2.0];

  return (
    <div className="relative bg-[#161B22] border-t border-[#1F242D] px-2 sm:px-4 py-2 flex items-center justify-between shrink-0 select-none z-20">
      {/* Popovers for Aspect Ratio and Speed */}
      {showCropMenu && (
        <div className="absolute bottom-16 left-1/3 -translate-x-1/2 bg-[#1F242D] border border-white/10 rounded-2xl p-2 flex flex-col gap-1 shadow-2xl z-40 min-w-[180px]">
          <span className="text-[10px] font-bold text-[#8B949E] uppercase tracking-wider px-2 py-1">
            Canvas Aspect Ratio
          </span>
          {ratios.map((r) => (
            <button
              key={r.value}
              onClick={() => {
                onChangeAspectRatio(r.value);
                setShowCropMenu(false);
              }}
              className={`px-3 py-1.5 text-xs text-left rounded-xl transition-colors font-medium flex items-center justify-between ${
                aspectRatio === r.value
                  ? 'bg-[#00E5FF] text-black font-bold'
                  : 'text-white hover:bg-[#2A313D]'
              }`}
            >
              <span>{r.label}</span>
            </button>
          ))}
        </div>
      )}

      {showSpeedMenu && activeClip && (
        <div className="absolute bottom-16 left-1/2 -translate-x-1/2 bg-[#1F242D] border border-white/10 rounded-2xl p-2 flex flex-col gap-1 shadow-2xl z-40 min-w-[140px]">
          <span className="text-[10px] font-bold text-[#8B949E] uppercase tracking-wider px-2 py-1">
            Playback Speed
          </span>
          {speeds.map((s) => (
            <button
              key={s}
              onClick={() => {
                onChangeSpeed(s);
                setShowSpeedMenu(false);
              }}
              className={`px-3 py-1.5 text-xs text-left rounded-xl transition-colors font-medium flex items-center justify-between ${
                activeClip.speed === s
                  ? 'bg-[#00E5FF] text-black font-bold'
                  : 'text-white hover:bg-[#2A313D]'
              }`}
            >
              <span>{s}x</span>
              {s === 1.0 && <span className="text-[10px] opacity-70">Normal</span>}
            </button>
          ))}
        </div>
      )}

      {/* Main Action Strip */}
      <div className="flex items-center gap-1 sm:gap-2 overflow-x-auto w-full justify-around sm:justify-center">
        {/* Media Button */}
        <button
          onClick={onOpenMediaPicker}
          className="flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl text-[#8B949E] hover:text-white hover:bg-[#1F242D] transition-colors"
        >
          <Plus className="w-5 h-5 text-[#FF4A5A]" />
          <span className="text-[10px] font-medium tracking-tight">Media</span>
        </button>

        {/* Trim Button */}
        <button
          onClick={onOpenTrim}
          disabled={!activeClip}
          className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-colors ${
            activeClip
              ? 'text-[#8B949E] hover:text-[#00E5FF] hover:bg-[#1F242D] cursor-pointer'
              : 'text-[#8B949E]/30 cursor-not-allowed'
          }`}
        >
          <Scissors className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight">Trim</span>
        </button>

        {/* Split Button */}
        <button
          onClick={onSplitClip}
          disabled={!canSplit}
          className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-colors ${
            canSplit
              ? 'text-[#8B949E] hover:text-[#00E5FF] hover:bg-[#1F242D] cursor-pointer'
              : 'text-[#8B949E]/30 cursor-not-allowed'
          }`}
          title="Split clip at playhead"
        >
          <Split className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight">Split</span>
        </button>

        {/* Aspect Ratio / Crop Button */}
        <button
          onClick={() => {
            setShowCropMenu(!showCropMenu);
            setShowSpeedMenu(false);
          }}
          className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-colors ${
            showCropMenu
              ? 'bg-[#1F242D] text-[#00E5FF]'
              : 'text-[#8B949E] hover:text-white hover:bg-[#1F242D]'
          }`}
        >
          <Crop className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight">Ratio</span>
        </button>

        {/* Speed Button */}
        <button
          onClick={() => {
            setShowSpeedMenu(!showSpeedMenu);
            setShowCropMenu(false);
          }}
          disabled={!activeClip}
          className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-colors ${
            !activeClip
              ? 'text-[#8B949E]/30 cursor-not-allowed'
              : showSpeedMenu
              ? 'bg-[#1F242D] text-[#00E5FF]'
              : 'text-[#8B949E] hover:text-white hover:bg-[#1F242D]'
          }`}
        >
          <Gauge className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight">
            {activeClip?.speed && activeClip.speed !== 1 ? `${activeClip.speed}x` : 'Speed'}
          </span>
        </button>

        {/* Volume Mute Toggle */}
        <button
          onClick={onToggleMute}
          disabled={!activeClip}
          className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-colors ${
            !activeClip
              ? 'text-[#8B949E]/30 cursor-not-allowed'
              : activeClip.volume === 0
              ? 'text-[#FF4A5A] hover:bg-[#1F242D]'
              : 'text-[#8B949E] hover:text-white hover:bg-[#1F242D]'
          }`}
          title={activeClip?.volume === 0 ? 'Unmute Audio' : 'Mute Audio'}
        >
          {activeClip?.volume === 0 ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
          <span className="text-[10px] font-medium tracking-tight">Audio</span>
        </button>

        {/* Delete Button */}
        <button
          onClick={onDeleteClip}
          disabled={!activeClip}
          className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-colors ${
            activeClip
              ? 'text-[#8B949E] hover:text-[#FF4A5A] hover:bg-[#FF4A5A]/10 cursor-pointer'
              : 'text-[#8B949E]/30 cursor-not-allowed'
          }`}
          title="Delete selected clip"
        >
          <Trash2 className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight">Delete</span>
        </button>
      </div>
    </div>
  );
};
