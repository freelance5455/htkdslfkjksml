import { useEffect, useRef } from "react";
import type { HistData } from "@/lib/photo/renderer";

export function Histogram({
  data,
  clip,
  onClip,
}: {
  data: HistData | null;
  clip: boolean;
  onClip: () => void;
}) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.max(1, Math.round(canvas.clientWidth * dpr));
    const height = Math.max(1, Math.round(canvas.clientHeight * dpr));
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, width, height);
    if (!data) return;

    const fill = (values: number[], color: string) => {
      ctx.beginPath();
      ctx.moveTo(0, height);
      values.forEach((value, index) => {
        const x = (index / Math.max(1, values.length - 1)) * width;
        const y = height - value * height * 0.94;
        ctx.lineTo(x, y);
      });
      ctx.lineTo(width, height);
      ctx.closePath();
      ctx.fillStyle = color;
      ctx.fill();
    };

    ctx.globalCompositeOperation = "lighter";
    fill(data.r, "rgba(196, 92, 84, 0.9)");
    fill(data.g, "rgba(112, 168, 112, 0.8)");
    fill(data.b, "rgba(98, 132, 186, 0.9)");
    ctx.globalCompositeOperation = "source-over";
    ctx.beginPath();
    data.l.forEach((value, index) => {
      const x = (index / Math.max(1, data.l.length - 1)) * width;
      const y = height - value * height * 0.94;
      if (index === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.strokeStyle = "rgba(243, 243, 244, 0.85)";
    ctx.lineWidth = Math.max(1, dpr);
    ctx.stroke();
  }, [data]);

  return (
    <div className="flex items-center gap-3">
      <div className="relative h-16 min-w-0 flex-1 overflow-hidden rounded-sm bg-bg">
        <canvas ref={ref} className="h-full w-full" aria-hidden />
        {!data && (
          <span className="absolute inset-0 flex items-center justify-center text-xs text-subtle">
            Histogram
          </span>
        )}
      </div>
      <button
        type="button"
        aria-pressed={clip}
        onClick={onClip}
        className={
          "h-11 shrink-0 rounded-sm px-3 text-xs transition-colors duration-150 " +
          "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-steel " +
          (clip ? "bg-surface-2 text-fg" : "text-muted hover:bg-surface-2 hover:text-fg")
        }
      >
        Clipping
      </button>
    </div>
  );
}
