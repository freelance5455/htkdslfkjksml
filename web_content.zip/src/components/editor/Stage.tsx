import { forwardRef, useEffect, useImperativeHandle, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import {
  Check,
  FlipHorizontal2,
  RotateCcw,
  RotateCw,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import {
  ASPECTS,
  defaultCrop,
  displaySize,
  layoutImage,
  normRatioFor,
  resizeCrop,
  type CropHandle,
} from "@/lib/photo/model";
import { PhotoRenderer, type HistData, type RenderRequest } from "@/lib/photo/renderer";
import { useEditor } from "@/store/editor";
import { cn } from "@/lib/cn";
import { SliderRow, TextButton } from "@/components/editor/controls";

export type StageHandle = {
  exportFrame: (mime: "image/jpeg" | "image/png") => Promise<Blob | null>;
  getSource: () => HTMLImageElement | null;
  zoomActual: () => void;
};

const HANDLES: { id: CropHandle; x: string; y: string }[] = [
  { id: "nw", x: "0%", y: "0%" },
  { id: "n", x: "50%", y: "0%" },
  { id: "ne", x: "100%", y: "0%" },
  { id: "e", x: "100%", y: "50%" },
  { id: "se", x: "100%", y: "100%" },
  { id: "s", x: "50%", y: "100%" },
  { id: "sw", x: "0%", y: "100%" },
  { id: "w", x: "0%", y: "50%" },
];

const CURSOR: Record<CropHandle, string> = {
  move: "move",
  nw: "nwse-resize",
  se: "nwse-resize",
  ne: "nesw-resize",
  sw: "nesw-resize",
  n: "ns-resize",
  s: "ns-resize",
  e: "ew-resize",
  w: "ew-resize",
};

function sameHist(a: HistData | null, b: HistData | null) {
  if (!a || !b) return false;
  for (let i = 0; i < a.l.length; i += 4) {
    if (Math.abs((a.l[i] ?? 0) - (b.l[i] ?? 0)) > 0.03) return false;
    if (Math.abs((a.r[i] ?? 0) - (b.r[i] ?? 0)) > 0.03) return false;
    if (Math.abs((a.g[i] ?? 0) - (b.g[i] ?? 0)) > 0.03) return false;
  }
  return true;
}

export const Stage = forwardRef<StageHandle, { onHistogram: (data: HistData | null) => void }>(
  function Stage({ onHistogram }, ref) {
    const wrapRef = useRef<HTMLDivElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const rendererRef = useRef<PhotoRenderer | null>(null);
    const imageRef = useRef<HTMLImageElement | null>(null);
    const histRef = useRef<HistData | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [ready, setReady] = useState(false);
    const [cssSize, setCssSize] = useState({ w: 0, h: 0 });
    const photo = useEditor((state) => state.photos.find((item) => item.id === state.activeId) ?? null);
    const zoom = useEditor((state) => state.zoom);
    const pan = useEditor((state) => state.pan);
    const cropMode = useEditor((state) => state.cropMode);
    const compare = useEditor((state) => state.compare);
    const split = useEditor((state) => state.split);
    const clipWarn = useEditor((state) => state.clipWarn);
    const holdBefore = useEditor((state) => state.holdBefore);
    const status = useEditor((state) => state.status);
    const setView = useEditor((state) => state.setView);
    const setSplit = useEditor((state) => state.setSplit);
    const setCrop = useEditor((state) => state.setCrop);
    const setCropMode = useEditor((state) => state.setCropMode);
    const beginGesture = useEditor((state) => state.beginGesture);
    const commitGesture = useEditor((state) => state.commitGesture);
    const patch = useEditor((state) => state.patch);
    const rotate = useEditor((state) => state.rotate);
    const toggleFlip = useEditor((state) => state.toggleFlip);
    const setAspect = useEditor((state) => state.setAspect);
    const applyPreset = useEditor((state) => state.applyPreset);

    useEffect(() => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      try {
        rendererRef.current = new PhotoRenderer(canvas);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Could not start the renderer.");
        return;
      }
      const observer = new ResizeObserver(() => {
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        const w = canvas.clientWidth;
        const h = canvas.clientHeight;
        canvas.width = Math.max(1, Math.round(w * dpr));
        canvas.height = Math.max(1, Math.round(h * dpr));
        setCssSize((prev) => (prev.w === w && prev.h === h ? prev : { w, h }));
      });
      observer.observe(canvas);
      return () => {
        observer.disconnect();
        rendererRef.current?.destroy();
        rendererRef.current = null;
      };
    }, []);

    useEffect(() => {
      if (!photo) {
        setReady(false);
        return;
      }
      let cancel = false;
      const image = new Image();
      if (!photo.src.startsWith("blob:")) image.crossOrigin = "anonymous";
      image.onload = () => {
        if (cancel) return;
        imageRef.current = image;
        try {
          rendererRef.current?.setSource(image, 2048);
          setError(null);
          setReady(true);
        } catch (err) {
          setError(err instanceof Error ? err.message : "Could not read that photo.");
        }
      };
      image.onerror = () => {
        if (!cancel) setError("This frame couldn’t be opened.");
      };
      setReady(false);
      image.src = photo.src;
      return () => {
        cancel = true;
      };
    }, [photo?.id, photo?.src]);

    function requestFor(renderer: PhotoRenderer): RenderRequest | null {
      if (!photo) return null;
      const canvas = renderer.canvasSize();
      return {
        adjustments: photo.adjustments,
        naturalW: photo.width,
        naturalH: photo.height,
        compareOriginal: holdBefore || compare === "before",
        split: !holdBefore && compare === "split" ? split : -1,
        cropMode,
        clipWarn: clipWarn && !holdBefore && compare !== "before",
        viewW: canvas.w,
        viewH: canvas.h,
        zoom,
        panX: pan.x * canvas.dpr,
        panY: pan.y * canvas.dpr,
        mode: "screen",
      };
    }

    useEffect(() => {
      const renderer = rendererRef.current;
      if (!renderer || !photo || !ready) return;
      const req = requestFor(renderer);
      if (!req || req.viewW < 2 || req.viewH < 2) return;
      renderer.render(req);
      const next = renderer.readHistogram(req);
      if (!sameHist(histRef.current, next)) {
        histRef.current = next;
        onHistogram(next);
      }
    }, [photo, zoom, pan, cropMode, compare, split, clipWarn, holdBefore, ready, cssSize, onHistogram]);

    function zoomActual() {
      const renderer = rendererRef.current;
      if (!renderer || !photo) return;
      const size = displaySize(photo.width, photo.height, photo.adjustments, cropMode);
      const view = renderer.canvasSize();
      const fit = Math.min(view.w / size.dispW, view.h / size.dispH);
      setView(fit > 0 ? 1 / fit : 1, { x: 0, y: 0 });
    }

    useImperativeHandle(ref, () => ({
      getSource: () => imageRef.current,
      zoomActual,
      exportFrame: (mime) => {
        const renderer = rendererRef.current;
        if (!renderer || !photo) return Promise.resolve(null);
        const req = requestFor(renderer);
        if (!req) return Promise.resolve(null);
        return renderer.exportBlob(req, mime);
      },
    }));

    useEffect(() => {
      const wrap = wrapRef.current;
      if (!wrap) return;
      const onWheel = (event: WheelEvent) => {
        event.preventDefault();
        const state = useEditor.getState();
        const current = state.photos.find((item) => item.id === state.activeId);
        if (!current) return;
        const bounds = wrap.getBoundingClientRect();
        const size = displaySize(current.width, current.height, current.adjustments, state.cropMode);
        const layout = layoutImage({
          viewW: bounds.width,
          viewH: bounds.height,
          imgW: size.dispW,
          imgH: size.dispH,
          zoom: state.zoom,
          panX: state.pan.x,
          panY: state.pan.y,
        });
        const nextZoom = Math.min(12, Math.max(0.2, state.zoom * Math.exp(-event.deltaY * 0.0012)));
        const cx = event.clientX - bounds.left;
        const cy = event.clientY - bounds.top;
        const u = (cx - layout.x) / layout.w;
        const v = (cy - layout.y) / layout.h;
        const next = layoutImage({
          viewW: bounds.width,
          viewH: bounds.height,
          imgW: size.dispW,
          imgH: size.dispH,
          zoom: nextZoom,
          panX: 0,
          panY: 0,
        });
        const newLeft = cx - u * next.w;
        const newTop = cy - v * next.h;
        state.setView(nextZoom, {
          x: newLeft - (bounds.width - next.w) / 2,
          y: newTop - (bounds.height - next.h) / 2,
        });
      };
      wrap.addEventListener("wheel", onWheel, { passive: false });
      return () => wrap.removeEventListener("wheel", onWheel);
    }, []);

    const size = photo ? displaySize(photo.width, photo.height, photo.adjustments, cropMode) : null;
    const frame = photo ? displaySize(photo.width, photo.height, photo.adjustments, true) : null;
    const imageRect =
      size && cssSize.w > 0
        ? layoutImage({
            viewW: cssSize.w,
            viewH: cssSize.h,
            imgW: size.dispW,
            imgH: size.dispH,
            zoom,
            panX: pan.x,
            panY: pan.y,
          })
        : null;
    const dpr = cssSize.w > 0 && canvasRef.current ? canvasRef.current.width / cssSize.w : 1;
    const percent =
      size && imageRect ? Math.round((imageRect.w * dpr / size.dispW) * 100) : 0;

    function beginPan(event: ReactPointerEvent) {
      if (event.button !== 0) return;
      const target = event.target as HTMLElement;
      if (target.dataset.crop || target.dataset.split) return;
      const startX = event.clientX;
      const startY = event.clientY;
      const startPan = useEditor.getState().pan;
      event.currentTarget.setPointerCapture(event.pointerId);
      const move = (ev: PointerEvent) => {
        useEditor.getState().setView(useEditor.getState().zoom, {
          x: startPan.x + ev.clientX - startX,
          y: startPan.y + ev.clientY - startY,
        });
      };
      const up = () => {
        window.removeEventListener("pointermove", move);
        window.removeEventListener("pointerup", up);
      };
      window.addEventListener("pointermove", move);
      window.addEventListener("pointerup", up);
    }

    function beginCrop(event: ReactPointerEvent, handle: CropHandle) {
      if (!photo || !imageRect) return;
      event.stopPropagation();
      const start = { ...photo.adjustments.crop };
      const origin = pointInImage(event.clientX, event.clientY);
      if (!origin) return;
      beginGesture();
      event.currentTarget.setPointerCapture(event.pointerId);
      const ratio = normRatioFor(photo.adjustments.aspect, frame?.frameW ?? 1, frame?.frameH ?? 1);
      const move = (ev: PointerEvent) => {
        const next = pointInImage(ev.clientX, ev.clientY);
        if (!next) return;
        setCrop(resizeCrop(start, handle, next.x - origin.x, next.y - origin.y, ratio));
      };
      const up = () => {
        commitGesture();
        window.removeEventListener("pointermove", move);
        window.removeEventListener("pointerup", up);
      };
      window.addEventListener("pointermove", move);
      window.addEventListener("pointerup", up);
    }

    function pointInImage(clientX: number, clientY: number) {
      const wrap = wrapRef.current;
      if (!wrap || !imageRect || imageRect.w === 0 || imageRect.h === 0) return null;
      const bounds = wrap.getBoundingClientRect();
      return {
        x: (clientX - bounds.left - imageRect.x) / imageRect.w,
        y: (clientY - bounds.top - imageRect.y) / imageRect.h,
      };
    }

    function beginSplit(event: ReactPointerEvent) {
      event.stopPropagation();
      const move = (ev: PointerEvent) => {
        const point = pointInImage(ev.clientX, ev.clientY);
        if (!point) return;
        setSplit(Math.min(0.98, Math.max(0.02, point.x)));
      };
      const up = () => {
        window.removeEventListener("pointermove", move);
        window.removeEventListener("pointerup", up);
      };
      window.addEventListener("pointermove", move);
      window.addEventListener("pointerup", up);
    }

    return (
      <div className="flex min-h-0 min-w-0 flex-1 flex-col">
        <div
          ref={wrapRef}
          className={cn("relative min-h-0 flex-1 touch-none overflow-hidden", cropMode ? "cursor-default" : "cursor-grab")}
          onPointerDown={beginPan}
          onDoubleClick={(event) => {
            const target = event.target as HTMLElement;
            if (target.dataset.crop || target.dataset.split) return;
            if (zoom === 1 && pan.x === 0 && pan.y === 0) zoomActual();
            else setView(1, { x: 0, y: 0 });
          }}
        >
          <canvas ref={canvasRef} className="h-full w-full" />
          {!photo && (
            <div className="absolute inset-0 flex items-center justify-center px-6 text-center">
              <p className="max-w-sm text-sm text-pretty text-muted">
                Drop photos here, or import from your library. Sample frames can be restored from the menu.
              </p>
            </div>
          )}
          {error && (
            <div className="absolute inset-x-0 top-4 flex justify-center px-4">
              <p className="rounded-md bg-surface px-3 py-2 text-sm text-fg">{error}</p>
            </div>
          )}
          {cropMode && imageRect && photo && (
            <div
              data-crop="move"
              className="crop-grid absolute z-10 border border-fg"
              style={{
                left: imageRect.x + photo.adjustments.crop.x * imageRect.w,
                top: imageRect.y + photo.adjustments.crop.y * imageRect.h,
                width: photo.adjustments.crop.w * imageRect.w,
                height: photo.adjustments.crop.h * imageRect.h,
                boxShadow: "0 0 0 9999px color-mix(in oklab, var(--color-bg) 62%, transparent)",
                cursor: "move",
              }}
              onPointerDown={(event) => beginCrop(event, "move")}
            >
              {HANDLES.map((handle) => (
                <button
                  key={handle.id}
                  type="button"
                  data-crop={handle.id}
                  aria-label={`Crop ${handle.id}`}
                  className="absolute z-20 size-11 -translate-x-1/2 -translate-y-1/2"
                  style={{ left: handle.x, top: handle.y, cursor: CURSOR[handle.id] }}
                  onPointerDown={(event) => beginCrop(event, handle.id)}
                >
                  <span className="mx-auto block size-3 rounded-full border border-bg bg-fg" />
                </button>
              ))}
            </div>
          )}
          {compare === "split" && !holdBefore && imageRect && (
            <div
              data-split="true"
              className="absolute z-20 w-11 -translate-x-1/2 cursor-ew-resize"
              style={{ left: imageRect.x + split * imageRect.w, top: imageRect.y, height: imageRect.h }}
              onPointerDown={beginSplit}
            >
              <div className="mx-auto h-full w-px bg-fg" />
            </div>
          )}
          <div className="pointer-events-none absolute bottom-3 left-3 flex items-center gap-1">
            <div className="pointer-events-auto flex items-center rounded-md bg-surface">
              <button type="button" aria-label="Zoom out" className="inline-flex size-11 items-center justify-center text-muted hover:text-fg" onClick={() => setView(Math.max(0.2, zoom / 1.25), pan)}>
                <ZoomOut className="size-4" />
              </button>
              <span className="w-12 text-center font-mono text-xs tabular-nums text-fg">{percent}%</span>
              <button type="button" aria-label="Zoom in" className="inline-flex size-11 items-center justify-center text-muted hover:text-fg" onClick={() => setView(Math.min(12, zoom * 1.25), pan)}>
                <ZoomIn className="size-4" />
              </button>
              <button type="button" aria-label="Fit" className="h-11 px-2 text-xs text-muted hover:text-fg" onClick={() => setView(1, { x: 0, y: 0 })}>
                Fit
              </button>
              <button
                type="button"
                aria-label="Actual pixels"
                className="h-11 px-2 text-xs text-muted hover:text-fg"
                onClick={zoomActual}
              >
                1:1
              </button>
            </div>
          </div>
          {status && (
            <div className="pointer-events-none absolute top-3 left-1/2 -translate-x-1/2 rounded-full bg-fg px-3 py-1 text-xs text-bg">
              {status}
            </div>
          )}
        </div>
        {cropMode && photo && (
          <div className="shrink-0 border-t border-border bg-surface px-3 py-2">
            <div className="lumen-scroll flex gap-1 overflow-x-auto">
              {ASPECTS.map((aspect) => (
                <button
                  key={aspect.id}
                  type="button"
                  aria-pressed={photo.adjustments.aspect === aspect.id}
                  onClick={() => setAspect(aspect.id)}
                  className={cn(
                    "h-11 shrink-0 rounded-sm px-3 text-sm",
                    photo.adjustments.aspect === aspect.id ? "bg-surface-2 text-fg" : "text-muted hover:bg-surface-2 hover:text-fg",
                  )}
                >
                  {aspect.label}
                </button>
              ))}
            </div>
            <SliderRow
              label="Straighten"
              value={photo.adjustments.straighten}
              min={-30}
              max={30}
              step={0.1}
              format={(value) => `${value > 0 ? "+" : ""}${value.toFixed(1)}°`}
              onBegin={beginGesture}
              onChange={(value) => patch({ straighten: value })}
              onCommit={commitGesture}
              onReset={() => {
                commitGesture();
                beginGesture();
                patch({ straighten: 0 });
                commitGesture();
              }}
            />
            <div className="flex flex-wrap items-center gap-1">
              <TextButton onClick={() => rotate(-1)}>
                <RotateCcw className="mr-2 size-4" /> Left
              </TextButton>
              <TextButton onClick={() => rotate(1)}>
                <RotateCw className="mr-2 size-4" /> Right
              </TextButton>
              <TextButton pressed={photo.adjustments.flip} onClick={toggleFlip}>
                <FlipHorizontal2 className="mr-2 size-4" /> Flip
              </TextButton>
              <TextButton
                onClick={() =>
                  applyPreset(
                    { ...photo.adjustments, crop: defaultCrop(), aspect: "free", straighten: 0 },
                    true,
                  )
                }
              >
                Reset crop
              </TextButton>
              <button
                type="button"
                onClick={() => setCropMode(false)}
                className="ml-auto inline-flex h-11 items-center gap-2 rounded-sm bg-fg px-4 text-sm text-bg"
              >
                <Check className="size-4" /> Done
              </button>
            </div>
          </div>
        )}
      </div>
    );
  },
);
