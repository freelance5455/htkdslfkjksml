import React, { useRef } from 'react';
import {
  Plus,
  ChevronLeft,
  ChevronRight,
  GripVertical
} from 'lucide-react';
import { Project, TimelineClip } from '../../types/editor';
import { formatTimeShort } from '../../utils/time';

interface TimelineProps {
  project: Project;
  activeClipId: string | null;
  currentTime: number; // in seconds
  totalDuration: number;
  onSelectClip: (clipId: string) => void;
  onSeekTimeline: (time: number) => void;
  onOpenMediaPicker: () => void;
  onMoveClipLeft: (clipIndex: number) => void;
  onMoveClipRight: (clipIndex: number) => void;
}

export const Timeline: React.FC<TimelineProps> = ({
  project,
  activeClipId,
  currentTime,
  totalDuration,
  onSelectClip,
  onSeekTimeline,
  onOpenMediaPicker,
  onMoveClipLeft,
  onMoveClipRight,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  // Pixels per second zoom factor (minimum 40px/sec for comfortable mobile and desktop view)
  const pxPerSec = Math.max(36, 600 / Math.max(8, totalDuration));

  const handleTimelineClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const scrollLeft = containerRef.current.scrollLeft;
    const clickX = e.clientX - rect.left + scrollLeft - 80; // Offset by Add button width
    const targetTime = Math.max(0, Math.min(totalDuration, clickX / pxPerSec));
    onSeekTimeline(targetTime);
  };

  const playheadLeft = 80 + currentTime * pxPerSec;

  return (
    <div className="h-44 sm:h-48 bg-[#0B0E14] border-t border-[#1F242D] flex flex-col shrink-0 select-none relative">
      {/* Time Ruler */}
      <div className="h-6 border-b border-[#1F242D] bg-[#12161E]/90 flex items-center px-4 overflow-hidden relative">
        <div
          className="absolute left-20 right-0 h-full flex items-center pointer-events-none"
          style={{ width: `${Math.max(800, totalDuration * pxPerSec + 200)}px` }}
        >
          {Array.from({ length: Math.ceil(totalDuration) + 10 }).map((_, sec) => {
            if (sec % 2 !== 0 && sec % 5 !== 0) return null;
            return (
              <div
                key={sec}
                className="absolute flex flex-col items-center"
                style={{ left: `${sec * pxPerSec}px` }}
              >
                <div className="h-2 w-px bg-[#1F242D]" />
                <span className="text-[9px] font-mono text-[#8B949E] mt-0.5">
                  {sec}s
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Interactive Timeline Track Scroll Area */}
      <div
        ref={containerRef}
        onClick={handleTimelineClick}
        className="flex-1 overflow-x-auto overflow-y-hidden flex items-center px-4 relative py-3"
      >
        {/* Playhead Needle */}
        <div
          style={{ left: `${playheadLeft}px` }}
          className="absolute top-0 bottom-0 w-0.5 bg-[#FF4A5A] z-30 pointer-events-none transition-all duration-75"
        >
          {/* Playhead Cap Badge */}
          <div className="absolute -top-1 -translate-x-1/2 px-1.5 py-0.5 rounded bg-[#FF4A5A] text-[9px] font-mono font-bold text-white shadow-md">
            {formatTimeShort(currentTime)}
          </div>
          {/* Bottom indicator */}
          <div className="absolute bottom-0 -translate-x-1/2 w-2 h-2 rounded-full bg-[#FF4A5A]" />
        </div>

        {/* Coral-Red Add Media Button at start of track */}
        <div className="mr-3 shrink-0">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onOpenMediaPicker();
            }}
            className="w-16 h-24 rounded-2xl bg-[#FF4A5A] hover:bg-[#ff3b4c] active:scale-95 text-white flex flex-col items-center justify-center gap-1.5 shadow-lg shadow-[#FF4A5A]/20 transition-all cursor-pointer"
            title="Add Media to Timeline"
          >
            <Plus className="w-6 h-6 stroke-[2.5]" />
            <span className="text-[10px] font-bold">Add</span>
          </button>
        </div>

        {/* Clips Track Strip */}
        <div className="flex items-center gap-1.5 h-24 relative">
          {project.clips.map((clip, idx) => {
            const isSelected = activeClipId === clip.id;
            const media = project.mediaMap[clip.mediaId];
            const clipDuration = (clip.sourceOut - clip.sourceIn) / (clip.speed || 1.0);
            const clipWidth = Math.max(70, clipDuration * pxPerSec);

            return (
              <div
                key={clip.id}
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectClip(clip.id);
                  onSeekTimeline(clip.timelineStart);
                }}
                style={{ width: `${clipWidth}px` }}
                className={`relative h-24 rounded-xl overflow-hidden border-2 transition-all flex flex-col justify-between p-1.5 cursor-pointer shrink-0 ${
                  isSelected
                    ? 'border-[#00E5FF] bg-[#161B22] shadow-lg shadow-cyan-950/40'
                    : 'border-[#1F242D] bg-[#12161E] hover:border-[#2A313D]'
                }`}
              >
                {/* Background Video Frame Thumbnail */}
                {media?.thumbnailUrl && (
                  <div className="absolute inset-0 opacity-30 pointer-events-none overflow-hidden">
                    <img
                      src={media.thumbnailUrl}
                      alt=""
                      className="w-full h-full object-cover filter brightness-90"
                    />
                  </div>
                )}

                {/* Top Clip Info Row */}
                <div className="relative z-10 flex items-center justify-between">
                  <span className="text-[10px] font-bold text-white truncate max-w-[80px]">
                    {media?.name || `Clip ${idx + 1}`}
                  </span>
                  <span className="text-[9px] font-mono font-semibold px-1 py-0.5 rounded bg-black/60 text-[#00E5FF]">
                    {clipDuration.toFixed(1)}s
                  </span>
                </div>

                {/* Bottom Clip Controls (Reorder Left/Right) */}
                <div className="relative z-10 flex items-center justify-between mt-auto">
                  <div className="flex items-center gap-0.5">
                    {idx > 0 && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onMoveClipLeft(idx);
                        }}
                        className="p-1 rounded bg-black/60 hover:bg-[#00E5FF] hover:text-black text-[#8B949E] transition-colors"
                        title="Move Clip Left"
                      >
                        <ChevronLeft className="w-3 h-3" />
                      </button>
                    )}
                    {idx < project.clips.length - 1 && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onMoveClipRight(idx);
                        }}
                        className="p-1 rounded bg-black/60 hover:bg-[#00E5FF] hover:text-black text-[#8B949E] transition-colors"
                        title="Move Clip Right"
                      >
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    )}
                  </div>

                  {clip.speed !== 1 && (
                    <span className="text-[9px] font-mono text-white/80 bg-black/50 px-1 rounded">
                      {clip.speed}x
                    </span>
                  )}
                </div>

                {/* Selected Indicator Outline & Handles */}
                {isSelected && (
                  <div className="absolute inset-0 border-2 border-[#00E5FF] rounded-xl pointer-events-none flex justify-between">
                    <div className="w-1.5 h-full bg-[#00E5FF]" />
                    <div className="w-1.5 h-full bg-[#00E5FF]" />
                  </div>
                )}
              </div>
            );
          })}

          {project.clips.length === 0 && (
            <div className="flex items-center text-xs text-[#8B949E] italic pl-2">
              Timeline is empty. Tap &quot;Add&quot; to import video clips.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
