import React, { useRef, useState, useEffect } from 'react';
import {
  Scissors,
  Copy,
  Trash2,
  ZoomIn,
  ZoomOut,
  Eye,
  EyeOff,
  Film,
  Type,
  Smile,
  Music,
  Layers,
  SkipBack,
  Sparkles,
} from 'lucide-react';
import { Project, Track, Clip, TrackType } from '../../types/editor';
import { Language, translations } from '../../i18n/translations';

interface TimelineProps {
  project: Project;
  currentTime: number;
  selectedClipId: string | null;
  onSelectClip: (clipId: string | null) => void;
  onSeek: (time: number) => void;
  onSplitClip: (clipId: string, splitTime: number) => void;
  onTrimClip: (clipId: string, newStart: number, newDuration: number) => void;
  onDuplicateClip: (clipId: string) => void;
  onDeleteClip: (clipId: string) => void;
  onUpdateTrack: (track: Track) => void;
  language: Language;
}

export const Timeline: React.FC<TimelineProps> = ({
  project,
  currentTime,
  selectedClipId,
  onSelectClip,
  onSeek,
  onSplitClip,
  onTrimClip,
  onDuplicateClip,
  onDeleteClip,
  onUpdateTrack,
  language,
}) => {
  const [zoom, setZoom] = useState(65); // pixels per second (30px to 140px)
  const [isScrubbing, setIsScrubbing] = useState(false);
  const [trimmingHandle, setTrimmingHandle] = useState<{ clipId: string; side: 'start' | 'end'; originX: number; origStart: number; origDur: number } | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);
  const tracksScrollRef = useRef<HTMLDivElement>(null);
  const t = translations[language];

  const totalDuration = Math.max(project.duration, 12);
  const timelinePixelWidth = Math.max(1400, totalDuration * zoom);

  // Track Type Metadata and Styles
  const getTrackMetadata = (type: TrackType, idx: number) => {
    switch (type) {
      case 'video':
        return {
          code: `V${idx + 1}`,
          icon: Film,
          gradient: 'from-amber-600/40 via-amber-700/30 to-amber-900/40 border-amber-500/70 text-amber-100',
          badgeColor: 'text-amber-400',
        };
      case 'overlay':
        return {
          code: `V${idx + 1}`,
          icon: Layers,
          gradient: 'from-emerald-600/40 via-emerald-700/30 to-emerald-900/40 border-emerald-500/70 text-emerald-100',
          badgeColor: 'text-emerald-400',
        };
      case 'text':
        return {
          code: `T${idx + 1}`,
          icon: Type,
          gradient: 'from-sky-600/40 via-blue-700/30 to-indigo-900/40 border-sky-500/70 text-sky-100',
          badgeColor: 'text-sky-400',
        };
      case 'sticker':
        return {
          code: `S${idx + 1}`,
          icon: Smile,
          gradient: 'from-pink-600/40 via-rose-700/30 to-rose-900/40 border-pink-500/70 text-pink-100',
          badgeColor: 'text-pink-400',
        };
      case 'audio':
        return {
          code: `A${idx + 1}`,
          icon: Music,
          gradient: 'from-purple-600/40 via-violet-700/30 to-indigo-950/40 border-purple-500/70 text-purple-100',
          badgeColor: 'text-purple-400',
        };
    }
  };

  // Playhead scrubbing
  const handleRulerMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!tracksScrollRef.current) return;
    const rect = tracksScrollRef.current.getBoundingClientRect();
    const scrollLeft = tracksScrollRef.current.scrollLeft;
    const clickX = e.clientX - rect.left + scrollLeft;
    const time = Math.max(0, Math.min(project.duration, clickX / zoom));
    onSeek(Number(time.toFixed(3)));
    setIsScrubbing(true);
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (isScrubbing && tracksScrollRef.current) {
      const rect = tracksScrollRef.current.getBoundingClientRect();
      const scrollLeft = tracksScrollRef.current.scrollLeft;
      const clickX = e.clientX - rect.left + scrollLeft;
      const time = Math.max(0, Math.min(project.duration, clickX / zoom));
      onSeek(Number(time.toFixed(3)));
    } else if (trimmingHandle) {
      const deltaPx = e.clientX - trimmingHandle.originX;
      const deltaSec = deltaPx / zoom;
      const clip = project.clips.find(c => c.id === trimmingHandle.clipId);
      if (!clip) return;

      if (trimmingHandle.side === 'start') {
        const proposedStart = Math.max(0, trimmingHandle.origStart + deltaSec);
        const proposedDur = Math.max(0.3, trimmingHandle.origDur - deltaSec);
        onTrimClip(clip.id, Number(proposedStart.toFixed(2)), Number(proposedDur.toFixed(2)));
      } else {
        const proposedDur = Math.max(0.3, trimmingHandle.origDur + deltaSec);
        onTrimClip(clip.id, trimmingHandle.origStart, Number(proposedDur.toFixed(2)));
      }
    }
  };

  const handleMouseUp = () => {
    setIsScrubbing(false);
    setTrimmingHandle(null);
  };

  useEffect(() => {
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isScrubbing, trimmingHandle, zoom, project.duration]);

  // Selected clip object
  const selectedClip = project.clips.find(c => c.id === selectedClipId);

  // Split selected clip at playhead
  const handleSplit = () => {
    if (selectedClip && currentTime > selectedClip.start && currentTime < (selectedClip.start + selectedClip.duration)) {
      onSplitClip(selectedClip.id, currentTime);
    }
  };

  // Generate ruler time marks
  const rulerMarks = [];
  const step = zoom < 50 ? 2 : 1;
  for (let s = 0; s <= totalDuration + 2; s += step) {
    rulerMarks.push(s);
  }

  return (
    <div ref={containerRef} className="w-full bg-[#0a0a0c] border-t border-white/[0.08] flex flex-col select-none text-white shrink-0">
      
      {/* Studio Timeline Quick Action Ribbon */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-[#121216] border-b border-white/[0.06] text-xs">
        
        {/* Left tools: Split, Duplicate, Delete, Reset to Start */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onSeek(0)}
            className="p-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white transition-colors"
            title="Rewind to Start (00:00)"
          >
            <SkipBack className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={handleSplit}
            disabled={!selectedClip || currentTime <= selectedClip.start || currentTime >= (selectedClip.start + selectedClip.duration)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-neutral-900 hover:bg-neutral-800 disabled:opacity-25 border border-white/5 hover:border-amber-400/40 text-neutral-200 transition-all font-semibold text-[11px] active:scale-95"
            title={t.split}
          >
            <Scissors className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-bold">{t.split}</span>
          </button>

          <button
            onClick={() => selectedClipId && onDuplicateClip(selectedClipId)}
            disabled={!selectedClipId}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-neutral-900 hover:bg-neutral-800 disabled:opacity-25 border border-white/5 text-neutral-300 hover:text-white transition-all font-semibold text-[11px] active:scale-95"
            title={t.duplicate}
          >
            <Copy className="w-3.5 h-3.5 text-neutral-400" />
            <span className="hidden sm:inline">{t.duplicate}</span>
          </button>

          <button
            onClick={() => selectedClipId && onDeleteClip(selectedClipId)}
            disabled={!selectedClipId}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-neutral-900 hover:bg-red-950/60 disabled:opacity-25 border border-white/5 hover:border-red-500/40 text-red-400 transition-all font-semibold text-[11px] active:scale-95"
            title={t.delete}
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{t.delete}</span>
          </button>

          {selectedClip && (
            <span className="hidden md:inline text-[10px] font-mono text-neutral-400 pl-2 border-l border-white/10 truncate max-w-[140px]">
              {selectedClip.name}
            </span>
          )}
        </div>

        {/* Right tools: Zoom Slider with numeric scale */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setZoom(z => Math.max(30, z - 15))}
            className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          
          <input
            type="range"
            min={30}
            max={140}
            value={zoom}
            onChange={(e) => setZoom(Number(e.target.value))}
            className="w-16 sm:w-24 h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-amber-400"
          />
          
          <button
            onClick={() => setZoom(z => Math.min(140, z + 15))}
            className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>

          <span className="text-[9px] font-mono text-neutral-500 w-8 text-right hidden sm:inline">
            {Math.round((zoom / 60) * 100)}%
          </span>
        </div>
      </div>

      {/* Main Multi-Track NLE Workspace */}
      <div className="flex w-full h-36 sm:h-44 overflow-hidden shrink-0">
        
        {/* Left Track Headers column */}
        <div className="w-24 sm:w-32 bg-[#0e0e12] border-r border-white/[0.08] flex flex-col pt-6 shrink-0 z-20 shadow-md">
          {project.tracks.map((track, idx) => {
            const meta = getTrackMetadata(track.type, idx);
            const Icon = meta.icon;
            return (
              <div
                key={track.id}
                className="h-9 px-2 flex items-center justify-between border-b border-white/[0.04] text-[11px]"
              >
                <div className="flex items-center gap-1.5 truncate">
                  <span className={`text-[9px] font-mono font-bold ${meta.badgeColor}`}>
                    {meta.code}
                  </span>
                  <Icon className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                  <span className="truncate text-neutral-300 font-medium text-[10px]">{track.name}</span>
                </div>
                <div className="flex items-center gap-0.5">
                  <button
                    onClick={() => onUpdateTrack({ ...track, visible: !track.visible })}
                    className="p-1 text-neutral-500 hover:text-white transition-colors"
                    title={track.visible ? 'Hide Track' : 'Show Track'}
                  >
                    {track.visible ? (
                      <Eye className="w-3 h-3 text-neutral-400" />
                    ) : (
                      <EyeOff className="w-3 h-3 text-red-400" />
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Scrollable Tracks & Timeline Ruler Area */}
        <div
          ref={tracksScrollRef}
          className="flex-1 overflow-x-auto overflow-y-hidden relative bg-[#09090c] scrollbar-none"
        >
          {/* Ruler */}
          <div
            onMouseDown={handleRulerMouseDown}
            className="h-6 bg-[#0e0e12] border-b border-white/[0.08] relative cursor-pointer sticky top-0 z-10 select-none"
            style={{ width: `${timelinePixelWidth}px` }}
          >
            {rulerMarks.map((sec) => (
              <div
                key={sec}
                className="absolute top-0 flex flex-col items-center pointer-events-none"
                style={{ left: `${sec * zoom}px` }}
              >
                <div className="h-2 w-[1px] bg-neutral-700" />
                <span className="text-[9px] font-mono text-neutral-500 -translate-x-1/2">
                  {sec}s
                </span>
              </div>
            ))}
          </div>

          {/* Precision Laser Playhead Needle */}
          <div
            className="absolute top-0 bottom-0 pointer-events-none z-30 flex flex-col items-center"
            style={{ left: `${currentTime * zoom}px` }}
          >
            <div className="w-3 h-3 bg-amber-400 rotate-45 -mt-1 shadow-lg shadow-amber-400/60 ring-1 ring-white/50" />
            <div className="w-[1.5px] h-full bg-amber-400 shadow-md shadow-amber-400/80" />
          </div>

          {/* Tracks Content Rows */}
          <div className="relative" style={{ width: `${timelinePixelWidth}px` }}>
            {project.tracks.map((track, idx) => {
              const meta = getTrackMetadata(track.type, idx);
              const trackClips = project.clips.filter(c => c.trackId === track.id);

              return (
                <div
                  key={track.id}
                  className="h-9 relative border-b border-white/[0.04] bg-[#09090c]/50"
                >
                  {trackClips.map((clip) => {
                    const isSelected = clip.id === selectedClipId;
                    const left = clip.start * zoom;
                    const width = Math.max(16, clip.duration * zoom);

                    return (
                      <div
                        key={clip.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectClip(clip.id);
                        }}
                        className={`absolute top-1 bottom-1 rounded-lg border bg-gradient-to-r ${meta.gradient} flex items-center justify-between px-2 cursor-pointer transition-all overflow-hidden shadow-sm ${
                          isSelected
                            ? 'ring-2 ring-amber-400 border-white text-white shadow-lg shadow-amber-400/20 z-10'
                            : 'hover:brightness-125'
                        }`}
                        style={{ left: `${left}px`, width: `${width}px` }}
                      >
                        {/* Trim Handle Left */}
                        {isSelected && (
                          <div
                            onMouseDown={(e) => {
                              e.stopPropagation();
                              setTrimmingHandle({
                                clipId: clip.id,
                                side: 'start',
                                originX: e.clientX,
                                origStart: clip.start,
                                origDur: clip.duration,
                              });
                            }}
                            className="absolute left-0 top-0 bottom-0 w-3 bg-amber-400 hover:bg-amber-300 cursor-ew-resize flex items-center justify-center text-black font-mono text-[8px] font-bold z-20"
                            title="Trim Start"
                          >
                            ❙
                          </div>
                        )}

                        {/* Clip Label & Indicators */}
                        <div className="flex items-center gap-1.5 truncate pointer-events-none pl-1">
                          <span className="truncate text-[10px] font-semibold tracking-tight text-white drop-shadow-sm">
                            {clip.name}
                          </span>
                          {clip.filter && (
                            <span className="text-[8px] font-mono px-1 rounded bg-black/40 text-amber-300 shrink-0">
                              FX
                            </span>
                          )}
                          {clip.keyframes && clip.keyframes.length > 0 && (
                            <span className="text-[8px] font-mono px-1 rounded bg-black/40 text-cyan-300 shrink-0">
                              ◆ KF
                            </span>
                          )}
                        </div>

                        {/* Audio Waveform decoration for audio clips */}
                        {clip.type === 'audio' && (
                          <div className="flex items-center gap-0.5 opacity-40 pointer-events-none pr-1">
                            <span className="h-3 w-0.5 bg-white rounded-full" />
                            <span className="h-4 w-0.5 bg-white rounded-full" />
                            <span className="h-2 w-0.5 bg-white rounded-full" />
                            <span className="h-5 w-0.5 bg-white rounded-full" />
                            <span className="h-3 w-0.5 bg-white rounded-full" />
                          </div>
                        )}

                        {/* Trim Handle Right */}
                        {isSelected && (
                          <div
                            onMouseDown={(e) => {
                              e.stopPropagation();
                              setTrimmingHandle({
                                clipId: clip.id,
                                side: 'end',
                                originX: e.clientX,
                                origStart: clip.start,
                                origDur: clip.duration,
                              });
                            }}
                            className="absolute right-0 top-0 bottom-0 w-3 bg-amber-400 hover:bg-amber-300 cursor-ew-resize flex items-center justify-center text-black font-mono text-[8px] font-bold z-20"
                            title="Trim End"
                          >
                            ❙
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
