import React, { useState } from 'react';
import {
  ArrowLeft,
  Undo2,
  Redo2,
  Download,
  Code,
  Edit2,
  Check
} from 'lucide-react';
import { Project } from '../../types/editor';

interface EditorTopBarProps {
  project: Project;
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  onNavigateBack: () => void;
  onUpdateProjectName: (name: string) => void;
  onOpenExport: () => void;
  onOpenAndroidCode: () => void;
}

export const EditorTopBar: React.FC<EditorTopBarProps> = ({
  project,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  onNavigateBack,
  onUpdateProjectName,
  onOpenExport,
  onOpenAndroidCode,
}) => {
  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState(project.name);

  const handleSaveName = () => {
    if (nameInput.trim()) {
      onUpdateProjectName(nameInput.trim());
    } else {
      setNameInput(project.name);
    }
    setIsEditingName(false);
  };

  return (
    <header className="h-14 px-3 sm:px-5 border-b border-[#1F242D] bg-[#161B22] flex items-center justify-between shrink-0 z-30 select-none">
      {/* Left: Back button & Project Title */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          onClick={onNavigateBack}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-[#1F242D] hover:bg-[#2A313D] text-white text-xs font-semibold transition-colors shrink-0"
        >
          <ArrowLeft className="w-4 h-4" />
          <span className="hidden sm:inline">Projects</span>
        </button>

        {isEditingName ? (
          <div className="flex items-center gap-1.5">
            <input
              type="text"
              value={nameInput}
              autoFocus
              onChange={(e) => setNameInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSaveName();
                if (e.key === 'Escape') setIsEditingName(false);
              }}
              className="bg-[#0B0E14] border border-[#00E5FF] px-2.5 py-1 text-xs font-semibold text-white rounded-lg outline-none max-w-[160px] sm:max-w-[220px]"
            />
            <button
              onClick={handleSaveName}
              className="p-1 rounded-md bg-[#00E5FF] text-black hover:bg-[#33ebff]"
            >
              <Check className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          <div
            onClick={() => {
              setNameInput(project.name);
              setIsEditingName(true);
            }}
            className="flex items-center gap-1.5 px-2 py-1 rounded-lg hover:bg-[#1F242D] cursor-pointer group transition-colors min-w-0"
          >
            <span className="text-sm font-bold text-white truncate max-w-[120px] sm:max-w-[220px]">
              {project.name}
            </span>
            <Edit2 className="w-3 h-3 text-[#8B949E] group-hover:text-[#00E5FF] shrink-0" />
          </div>
        )}
      </div>

      {/* Center: Undo & Redo Controls */}
      <div className="flex items-center gap-1">
        <button
          onClick={onUndo}
          disabled={!canUndo}
          className={`w-9 h-9 flex items-center justify-center rounded-xl transition-colors ${
            canUndo
              ? 'text-white hover:bg-[#1F242D] cursor-pointer'
              : 'text-[#8B949E]/40 cursor-not-allowed'
          }`}
          title="Undo action"
        >
          <Undo2 className="w-4 h-4" />
        </button>

        <button
          onClick={onRedo}
          disabled={!canRedo}
          className={`w-9 h-9 flex items-center justify-center rounded-xl transition-colors ${
            canRedo
              ? 'text-white hover:bg-[#1F242D] cursor-pointer'
              : 'text-[#8B949E]/40 cursor-not-allowed'
          }`}
          title="Redo action"
        >
          <Redo2 className="w-4 h-4" />
        </button>
      </div>

      {/* Right: Android Code & Export buttons */}
      <div className="flex items-center gap-2">
        <button
          onClick={onOpenAndroidCode}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#1F242D] hover:bg-[#2A313D] text-[#00E5FF] text-xs font-semibold border border-[#00E5FF]/20 transition-all shrink-0"
          title="View Android Kotlin & ExoPlayer code"
        >
          <Code className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Android Studio</span>
        </button>

        <button
          onClick={onOpenExport}
          disabled={project.clips.length === 0}
          className={`flex items-center gap-2 px-4 py-1.5 rounded-xl text-xs font-bold transition-all shadow-md shrink-0 ${
            project.clips.length > 0
              ? 'bg-[#00E5FF] hover:bg-[#33ebff] text-black shadow-[#00E5FF]/20 cursor-pointer'
              : 'bg-[#1F242D] text-[#8B949E] cursor-not-allowed'
          }`}
        >
          <Download className="w-3.5 h-3.5 stroke-[2.5]" />
          <span>Export</span>
        </button>
      </div>
    </header>
  );
};
