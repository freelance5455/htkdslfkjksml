import React, { useRef, useEffect } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  SkipBack,
  SkipForward,
  Maximize2
} from 'lucide-react';
import { Project, TimelineClip } from '../../types/editor';
import { formatTime } from '../../utils/time';

interface VideoPreviewProps {
  project: Project;
  activeClip: TimelineClip | null;
  currentTime: number; // in timeline seconds
  totalDuration: number;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onSeekTimeline: (time: number) => void;
}

export const VideoPreview: React.FC<VideoPreviewProps> = ({
  project,
  activeClip,
  currentTime,
  totalDuration,
  isPlaying,
  onTogglePlay,
  onSeekTimeline,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const activeMedia = activeClip ? project.mediaMap[activeClip.mediaId] : null;

  // Sync video element with active clip and timeline position
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !activeClip || !activeMedia) return;

    // Calculate source media time for this clip
    // offset in this clip = (currentTime - activeClip.timelineStart) * speed
    const clipOffset = Math.max(0, currentTime - activeClip.timelineStart);
    const targetSourceTime = activeClip.sourceIn + clipOffset * (activeClip.speed || 1.0);

    // Only update if difference > 0.15s to avoid stutter during regular playback
    if (Math.abs(video.currentTime - targetSourceTime) > 0.25) {
      video.currentTime = Math.min(activeClip.sourceOut, Math.max(activeClip.sourceIn, targetSourceTime));
    }

    video.playbackRate = activeClip.speed || 1.0;
    video.volume = activeClip.volume ?? 1.0;

    if (isPlaying && video.paused) {
      video.play().catch(() => {});
    } else if (!isPlaying && !video.paused) {
      video.pause();
    }
  }, [currentTime, activeClip, activeMedia, isPlaying]);

  const handleScrubberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onSeekTimeline(parseFloat(e.target.value));
  };

  const handleStep = (delta: number) => {
    onSeekTimeline(Math.max(0, Math.min(totalDuration, currentTime + delta)));
  };

  const handleFullscreen = () => {
    if (containerRef.current) {
      if (document.fullscreenElement) {
        document.exitFullscreen();
      } else {
        containerRef.current.requestFullscreen();
      }
    }
  };

  // Aspect ratio classes
  const aspectClass =
    project.aspectRatio === '9:16'
      ? 'aspect-[9/16] max-h-[460px]'
      : project.aspectRatio === '1:1'
      ? 'aspect-square max-h-[380px]'
      : project.aspectRatio === '4:5'
      ? 'aspect-[4/5] max-h-[420px]'
      : 'aspect-video max-h-[360px]';

  return (
    <div
      ref={containerRef}
      className="flex-1 bg-black flex flex-col items-center justify-center p-3 sm:p-5 relative overflow-hidden select-none"
    >
      {/* Video Framing Box */}
      <div className={`relative w-full ${aspectClass} rounded-2xl bg-[#0B0E14] border border-[#1F242D] shadow-2xl flex items-center justify-center overflow-hidden group`}>
        {activeMedia ? (
          <video
            ref={videoRef}
            src={activeMedia.url}
            playsInline
            muted={false}
            className="w-full h-full object-contain pointer-events-none"
          />
        ) : (
          <div className="flex flex-col items-center justify-center gap-2 text-[#8B949E] p-6 text-center">
            <span className="text-sm font-semibold">No media in timeline</span>
            <span className="text-xs">Add video clips using the &apos;+ Add&apos; button below</span>
          </div>
        )}

        {/* Center Tap-to-Play Overlay */}
        {activeMedia && (
          <button
            onClick={onTogglePlay}
            className="absolute inset-0 flex items-center justify-center bg-transparent group-hover:bg-black/20 transition-all cursor-pointer"
          >
            <div className={`w-14 h-14 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-white flex items-center justify-center shadow-2xl transition-transform duration-200 ${isPlaying ? 'opacity-0 group-hover:opacity-100 scale-90' : 'opacity-100 scale-100'}`}>
              {isPlaying ? (
                <Pause className="w-6 h-6 fill-current" />
              ) : (
                <Play className="w-6 h-6 fill-current ml-0.5 text-[#00E5FF]" />
              )}
            </div>
          </button>
        )}

        {/* Floating Top Badge with Clip Name & Speed */}
        {activeClip && activeMedia && (
          <div className="absolute top-3 left-3 px-2.5 py-1 rounded-lg bg-black/70 backdrop-blur-md text-[11px] font-mono text-white/90 border border-white/10 flex items-center gap-2">
            <span className="truncate max-w-[140px]">{activeMedia.name}</span>
            {activeClip.speed !== 1 && (
              <span className="text-[#00E5FF] font-bold">{activeClip.speed}x</span>
            )}
          </div>
        )}

        {/* Fullscreen Trigger */}
        <button
          onClick={handleFullscreen}
          className="absolute top-3 right-3 p-1.5 rounded-lg bg-black/70 backdrop-blur-md text-[#8B949E] hover:text-white transition-colors"
          title="Toggle Fullscreen"
        >
          <Maximize2 className="w-4 h-4" />
        </button>
      </div>

      {/* Playback Transport & Scrubber Bar */}
      <div className="w-full max-w-xl flex flex-col gap-2 mt-3 px-2">
        {/* Scrubber slider */}
        <div className="flex items-center gap-3">
          <input
            type="range"
            min={0}
            max={Math.max(0.1, totalDuration)}
            step={0.05}
            value={currentTime}
            onChange={handleScrubberChange}
            className="flex-1 h-1.5 bg-[#1F242D] rounded-lg appearance-none cursor-pointer accent-[#00E5FF]"
          />
        </div>

        {/* Transport buttons & Time indicators */}
        <div className="flex items-center justify-between text-xs font-mono">
          {/* Time readout */}
          <div className="flex items-center gap-1.5 tabular-nums text-sm font-semibold">
            <span className="text-[#00E5FF]">{formatTime(currentTime)}</span>
            <span className="text-[#8B949E]">/</span>
            <span className="text-[#8B949E]">{formatTime(totalDuration)}</span>
          </div>

          {/* Quick Playback controls */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleStep(-1.0)}
              className="p-1.5 rounded-lg hover:bg-[#1F242D] text-[#8B949E] hover:text-white transition-colors"
              title="Skip back 1s"
            >
              <SkipBack className="w-4 h-4" />
            </button>

            <button
              onClick={onTogglePlay}
              className="w-8 h-8 rounded-full bg-[#1F242D] hover:bg-[#00E5FF] hover:text-black text-white flex items-center justify-center transition-all cursor-pointer"
            >
              {isPlaying ? (
                <Pause className="w-4 h-4 fill-current" />
              ) : (
                <Play className="w-4 h-4 fill-current ml-0.5" />
              )}
            </button>

            <button
              onClick={() => handleStep(1.0)}
              className="p-1.5 rounded-lg hover:bg-[#1F242D] text-[#8B949E] hover:text-white transition-colors"
              title="Skip forward 1s"
            >
              <SkipForward className="w-4 h-4" />
            </button>

            <button
              onClick={() => onSeekTimeline(0)}
              className="p-1.5 rounded-lg hover:bg-[#1F242D] text-[#8B949E] hover:text-white transition-colors"
              title="Seek to start"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
