import React, { useRef, useEffect, useState } from 'react';
import { Play, Pause, SkipBack, SkipForward, Maximize2, Minimize2, Move, RotateCcw, Monitor, Crosshair } from 'lucide-react';
import { Project, Clip } from '../../types/editor';
import { VideoRenderer, mediaCache } from '../../services/videoRenderer';
import { Language, translations } from '../../i18n/translations';

interface VideoPreviewProps {
  project: Project;
  currentTime: number;
  isPlaying: boolean;
  isPremium: boolean;
  selectedClip?: Clip;
  previewProxyQuality: 'full' | 'half' | 'quarter';
  onTogglePlay: () => void;
  onSeek: (time: number) => void;
  onUpdateClipTransform?: (clipId: string, x: number, y: number) => void;
  language: Language;
}

export const VideoPreview: React.FC<VideoPreviewProps> = ({
  project,
  currentTime,
  isPlaying,
  isPremium,
  selectedClip,
  previewProxyQuality,
  onTogglePlay,
  onSeek,
  onUpdateClipTransform,
  language,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<VideoRenderer | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isMoveMode, setIsMoveMode] = useState(false);
  const [showSafeGuides, setShowSafeGuides] = useState(false);

  const isDraggingRef = useRef(false);
  const dragStartRef = useRef<{ mouseX: number; mouseY: number; startX: number; startY: number }>({
    mouseX: 0,
    mouseY: 0,
    startX: 0,
    startY: 0,
  });

  const t = translations[language];

  // Aspect ratio dimensions
  const getAspectRatioDimensions = () => {
    switch (project.aspectRatio) {
      case '9:16': return { w: 1080, h: 1920 };
      case '16:9': return { w: 1920, h: 1080 };
      case '1:1': return { w: 1080, h: 1080 };
      case '4:5': return { w: 1080, h: 1350 };
      case '4:3': return { w: 1440, h: 1080 };
      case '3:4': return { w: 1080, h: 1440 };
      default: return { w: project.customWidth || 1920, h: project.customHeight || 1080 };
    }
  };

  const { w: baseW, h: baseH } = getAspectRatioDimensions();

  // Apply preview proxy factor for performance
  const proxyScale = previewProxyQuality === 'quarter' ? 0.25 : previewProxyQuality === 'half' ? 0.5 : 1.0;
  const renderW = Math.floor(baseW * proxyScale);
  const renderH = Math.floor(baseH * proxyScale);

  useEffect(() => {
    if (canvasRef.current) {
      if (!rendererRef.current) {
        rendererRef.current = new VideoRenderer(canvasRef.current);
      }
      rendererRef.current.setSize(renderW, renderH);
      rendererRef.current.renderFrame(project, currentTime, isPremium, proxyScale, isPlaying);
    }
  }, [project, currentTime, isPremium, renderW, renderH, proxyScale, isPlaying]);

  // When paused, ensure all video decoding stops
  useEffect(() => {
    if (!isPlaying && rendererRef.current && canvasRef.current) {
      mediaCache.pauseAllVideos();
      rendererRef.current.renderFrame(project, currentTime, isPremium, proxyScale, false);
    }
  }, [isPlaying]);

  // Format SMPTE timecode HH:MM:SS:FF
  const formatTimecode = (sec: number) => {
    const totalMs = Math.floor(sec * 1000);
    const m = Math.floor(totalMs / 60000);
    const s = Math.floor((totalMs % 60000) / 1000);
    const f = Math.floor(((totalMs % 1000) / 1000) * (project.fps || 30));
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}:${String(f).padStart(2, '0')}`;
  };

  // Step 1 frame (1/30 sec)
  const stepFrame = (direction: 'back' | 'forward') => {
    const frameTime = 1 / (project.fps || 30);
    const next = direction === 'forward'
      ? Math.min(project.duration, currentTime + frameTime)
      : Math.max(0, currentTime - frameTime);
    onSeek(Number(next.toFixed(3)));
  };

  // Canvas interactive drag to reposition selected clip ONLY when Move Mode is turned on
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isMoveMode || !selectedClip || !onUpdateClipTransform) return;
    isDraggingRef.current = true;
    dragStartRef.current = {
      mouseX: e.clientX,
      mouseY: e.clientY,
      startX: selectedClip.x || 0,
      startY: selectedClip.y || 0,
    };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDraggingRef.current || !selectedClip || !onUpdateClipTransform || !canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const dx = ((e.clientX - dragStartRef.current.mouseX) / (rect.width || 1)) * 100;
    const dy = ((e.clientY - dragStartRef.current.mouseY) / (rect.height || 1)) * 100;
    const newX = Math.round(dragStartRef.current.startX + dx);
    const newY = Math.round(dragStartRef.current.startY + dy);
    onUpdateClipTransform(selectedClip.id, newX, newY);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    isDraggingRef.current = false;
    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch (err) {}
  };

  // Reset selected clip to dead center (0, 0)
  const handleResetCenter = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (selectedClip && onUpdateClipTransform) {
      onUpdateClipTransform(selectedClip.id, 0, 0);
    }
  };

  const isClipShifted = selectedClip && (Math.abs(selectedClip.x || 0) > 1 || Math.abs(selectedClip.y || 0) > 1);

  return (
    <div
      ref={containerRef}
      className={`relative w-full h-full flex flex-col items-center justify-between bg-[#08080a] p-2 select-none overflow-hidden ${
        isFullscreen ? 'fixed inset-0 z-50 bg-black' : ''
      }`}
    >
      {/* Broadcast Monitor Top Status Bar */}
      <div className="w-full flex items-center justify-between px-2 pt-0.5 z-20 pointer-events-auto shrink-0 text-xs">
        <div className="flex items-center gap-2">
          {/* Format aspect pill */}
          <div className="flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded-md bg-[#121216] border border-white/10 text-neutral-300">
            <Monitor className="w-3 h-3 text-amber-400" />
            <span className="font-bold">{project.aspectRatio}</span>
            <span className="text-neutral-500">·</span>
            <span className="text-neutral-400">{project.fps || 30} FPS</span>
          </div>

          {/* Safe Margins Toggle */}
          <button
            onClick={() => setShowSafeGuides(!showSafeGuides)}
            className={`p-1 rounded-md border text-[10px] flex items-center gap-1 transition-colors ${
              showSafeGuides
                ? 'bg-amber-400/20 text-amber-300 border-amber-400/40'
                : 'bg-[#121216] text-neutral-400 border-white/10 hover:text-white'
            }`}
            title="Toggle Broadcast Safe Title & Action Guides"
          >
            <Crosshair className="w-3 h-3" />
            <span className="hidden md:inline">Guides</span>
          </button>

          {/* Reset Center button if clip was shifted */}
          {isClipShifted && (
            <button
              onClick={handleResetCenter}
              className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30 transition-all shadow-sm"
              title="Reset clip position to center (0, 0)"
            >
              <RotateCcw className="w-3 h-3" />
              <span>{language === 'hi' ? 'सेंटर करें (0, 0)' : 'Snap Center'}</span>
            </button>
          )}
        </div>

        {/* Move / Transform Mode Toggle */}
        {selectedClip && (selectedClip.trackType === 'overlay' || selectedClip.type === 'text' || selectedClip.type === 'sticker') && (
          <button
            onClick={() => setIsMoveMode(!isMoveMode)}
            className={`flex items-center gap-1 text-[10px] font-bold px-2.5 py-0.5 rounded-md border transition-all ${
              isMoveMode
                ? 'bg-amber-400 text-black border-amber-300 shadow-md shadow-amber-400/30'
                : 'bg-[#121216] text-neutral-400 border-white/10 hover:text-white'
            }`}
          >
            <Move className="w-3 h-3" />
            <span>{isMoveMode ? (language === 'hi' ? 'ड्रैग चालू' : 'Move Active') : (language === 'hi' ? 'स्थान बदलें' : 'Move Clip')}</span>
          </button>
        )}
      </div>

      {/* Main Canvas Viewport Monitor - Strictly contained, NEVER overflows into buttons */}
      <div className="relative flex-1 w-full min-h-0 flex items-center justify-center p-1 overflow-hidden my-1">
        <div
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onClick={() => {
            if (!isMoveMode) {
              onTogglePlay();
            }
          }}
          className={`relative flex items-center justify-center rounded-xl overflow-hidden border border-white/[0.08] bg-black shadow-2xl transition-all ${
            isMoveMode ? 'ring-2 ring-amber-400 cursor-move' : 'cursor-pointer group'
          }`}
          style={{
            aspectRatio: `${baseW} / ${baseH}`,
            maxWidth: '100%',
            maxHeight: '100%',
            width: baseW >= baseH ? '100%' : 'auto',
            height: baseH > baseW ? '100%' : 'auto',
          }}
        >
          <canvas
            ref={canvasRef}
            width={renderW}
            height={renderH}
            className="w-full h-full object-contain pointer-events-none"
          />

          {/* Broadcast Safe Guides (Optional Overlays) */}
          {showSafeGuides && (
            <div className="absolute inset-0 pointer-events-none z-10">
              {/* 90% Action Safe */}
              <div className="absolute inset-[5%] border border-cyan-400/40 border-dashed" />
              {/* 80% Title Safe */}
              <div className="absolute inset-[10%] border border-amber-400/40 border-dashed" />
              {/* Crosshair Center */}
              <div className="absolute inset-0 m-auto w-4 h-4 flex items-center justify-center">
                <div className="w-4 h-[1px] bg-amber-400/60" />
                <div className="h-4 w-[1px] bg-amber-400/60 absolute" />
              </div>
            </div>
          )}

          {/* Subtle Center Play Icon when paused */}
          {!isPlaying && !isMoveMode && (
            <div className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-black/60 backdrop-blur-md border border-white/20 flex items-center justify-center text-white pointer-events-none shadow-2xl group-hover:scale-110 transition-transform">
              <Play className="w-5 h-5 fill-white ml-0.5" />
            </div>
          )}
        </div>
      </div>

      {/* Broadcast Studio Transport Bar (Fixed directly beneath monitor, strictly contained) */}
      <div className="w-full max-w-md flex items-center justify-between px-3 py-1.5 rounded-xl bg-[#111114] border border-white/[0.08] text-white backdrop-blur-md z-10 shrink-0 mb-0.5 shadow-lg">
        {/* Frame Step Back, Transport Play/Pause, Frame Step Forward */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => stepFrame('back')}
            className="p-1.5 rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
            title="Step 1 Frame Back (1/30s)"
          >
            <SkipBack className="w-3.5 h-3.5" />
          </button>
          
          <button
            onClick={onTogglePlay}
            className="p-1.5 rounded-lg bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-extrabold transition-all shadow-md shadow-amber-400/25 active:scale-95"
            title={isPlaying ? 'Pause (Space)' : 'Play (Space)'}
          >
            {isPlaying ? <Pause className="w-4 h-4 fill-black" /> : <Play className="w-4 h-4 fill-black ml-0.5" />}
          </button>

          <button
            onClick={() => stepFrame('forward')}
            className="p-1.5 rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
            title="Step 1 Frame Forward (1/30s)"
          >
            <SkipForward className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* High-Precision SMPTE Timecode display */}
        <div className="flex items-center gap-1.5 font-mono text-[11px] font-bold text-neutral-300 tabular-nums">
          <span className="text-amber-400">{formatTimecode(currentTime)}</span>
          <span className="text-neutral-600">/</span>
          <span className="text-neutral-400">{formatTimecode(project.duration)}</span>
        </div>

        {/* Fullscreen & Proxy Indicator */}
        <div className="flex items-center gap-1.5">
          <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-neutral-900 border border-white/5 text-neutral-400">
            {previewProxyQuality.toUpperCase()}
          </span>
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-1.5 rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors"
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen Monitor'}
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>
    </div>
  );
};
