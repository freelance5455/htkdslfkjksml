import React, { useState } from 'react';
import { Sparkles, Ban, Check, CopyCheck } from 'lucide-react';
import { ClipFilter, Clip } from '../../../types/editor';
import { BUILTIN_FILTERS } from '../../../services/sampleMedia';
import { Language, translations } from '../../../i18n/translations';

interface FiltersToolProps {
  currentFilter?: ClipFilter;
  onChange: (filter?: ClipFilter) => void;
  onApplyToAll?: (filter?: ClipFilter) => void;
  selectedClip?: Clip;
  availableClips?: Clip[];
  onSelectClip?: (clipId: string) => void;
  language: Language;
}

export const FiltersTool: React.FC<FiltersToolProps> = ({
  currentFilter,
  onChange,
  onApplyToAll,
  selectedClip,
  availableClips = [],
  onSelectClip,
  language,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [copiedToAll, setCopiedToAll] = useState(false);
  const t = translations[language];

  const categories = [
    { id: 'all', label: language === 'hi' ? 'सभी' : 'All' },
    { id: 'Cinematic', label: language === 'hi' ? 'सिनेमैटिक' : 'Cinematic' },
    { id: 'Vintage', label: language === 'hi' ? 'विंटेज' : 'Vintage' },
    { id: 'Black & White', label: language === 'hi' ? 'ब्लैक & व्हाइट' : 'B&W' },
    { id: 'Portrait', label: language === 'hi' ? 'पोर्ट्रेट' : 'Portrait' },
    { id: 'Social', label: language === 'hi' ? 'रील्स / सोशल' : 'Social' },
    { id: 'Film', label: language === 'hi' ? 'फिल्म' : 'Film' },
  ];

  const filteredList = selectedCategory === 'all'
    ? BUILTIN_FILTERS
    : BUILTIN_FILTERS.filter(f => f.category === selectedCategory);

  const handleSelectFilter = (filter: ClipFilter) => {
    onChange({
      ...filter,
      intensity: currentFilter?.intensity ?? 85,
    });
  };

  const handleIntensityChange = (intensity: number) => {
    if (currentFilter) {
      onChange({ ...currentFilter, intensity });
    }
  };

  const handleApplyToAll = () => {
    if (onApplyToAll) {
      onApplyToAll(currentFilter);
      setCopiedToAll(true);
      setTimeout(() => setCopiedToAll(false), 2000);
    }
  };

  return (
    <div className="p-3 sm:p-4 text-white space-y-3">
      {/* Top Header: Clip Selector, Intensity & Apply to All */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-neutral-800">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider">
              {language === 'hi' ? 'कलर ग्रेडिंग एवं फ़िल्टर्स' : 'Color Filters'}
            </h4>
            {selectedClip && (
              <p className="text-[10px] text-amber-400 font-mono">
                {language === 'hi' ? 'क्लिप: ' : 'Clip: '}
                <span className="text-neutral-300 font-bold">{selectedClip.name}</span>
              </p>
            )}
          </div>
        </div>

        {/* Intensity Slider & Apply to All Button */}
        <div className="flex items-center gap-3">
          {currentFilter && (
            <div className="flex items-center gap-1.5 bg-neutral-950 px-2.5 py-1 rounded-lg border border-neutral-800">
              <span className="text-[11px] text-neutral-400 font-semibold">{t.intensity}:</span>
              <span className="text-[11px] font-mono text-amber-400 font-bold w-7 text-right">
                {currentFilter.intensity}%
              </span>
              <input
                type="range"
                min={10}
                max={100}
                value={currentFilter.intensity}
                onChange={(e) => handleIntensityChange(Number(e.target.value))}
                className="w-20 sm:w-28 h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
            </div>
          )}

          {onApplyToAll && (
            <button
              onClick={handleApplyToAll}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-xs font-semibold text-neutral-200 hover:text-white transition-all shadow-sm"
              title="Apply filter to all video clips in project"
            >
              {copiedToAll ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-[10px] text-emerald-400 font-bold">
                    {language === 'hi' ? 'सब पर लागू!' : 'Applied All!'}
                  </span>
                </>
              ) : (
                <>
                  <CopyCheck className="w-3.5 h-3.5 text-amber-400" />
                  <span className="text-[10px]">
                    {language === 'hi' ? 'सभी पर लगाएं' : 'Apply to All'}
                  </span>
                </>
              )}
            </button>
          )}
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-2.5 py-1 rounded-full whitespace-nowrap font-semibold transition-all ${
              selectedCategory === cat.id
                ? 'bg-amber-400 text-black font-bold shadow-md shadow-amber-400/20'
                : 'bg-neutral-900 text-neutral-400 hover:bg-neutral-800 hover:text-white border border-neutral-800'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Filters Horizontal Scroller Cards */}
      <div className="flex items-center gap-2.5 overflow-x-auto pb-2 pt-1">
        {/* Original / Reset Filter Button */}
        <button
          onClick={() => onChange(undefined)}
          className={`flex-shrink-0 w-20 h-24 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all ${
            !currentFilter
              ? 'border-amber-400 bg-amber-500/20 text-amber-300 ring-2 ring-amber-400/50'
              : 'border-neutral-800 bg-neutral-950/70 text-neutral-400 hover:border-neutral-700'
          }`}
        >
          <div className="w-8 h-8 rounded-full bg-neutral-900 flex items-center justify-center border border-neutral-800">
            <Ban className="w-4 h-4 text-neutral-400" />
          </div>
          <span className="text-[10px] font-bold">
            {language === 'hi' ? 'ओरिजिनल' : 'Original'}
          </span>
        </button>

        {/* Filter Cards */}
        {filteredList.map((filter) => {
          const isSelected = currentFilter?.id === filter.id;
          return (
            <button
              key={filter.id}
              onClick={() => handleSelectFilter(filter)}
              className={`flex-shrink-0 w-24 h-24 rounded-xl border p-2 flex flex-col justify-between text-left transition-all ${
                isSelected
                  ? 'border-amber-400 bg-amber-500/25 text-white ring-2 ring-amber-400 shadow-lg shadow-amber-500/20'
                  : 'border-neutral-800 bg-neutral-950/80 text-neutral-400 hover:border-neutral-700 hover:text-neutral-200'
              }`}
            >
              {/* Filter Visual Swatch */}
              <div
                className="w-full h-11 rounded-lg mb-1 shadow-inner relative overflow-hidden border border-white/10"
                style={{
                  background: 'linear-gradient(135deg, #f59e0b 0%, #ec4899 50%, #06b6d4 100%)',
                  filter: filter.cssFilter,
                }}
              >
                {isSelected && (
                  <div className="absolute top-1 right-1 w-4 h-4 rounded-full bg-amber-400 text-black flex items-center justify-center">
                    <Check className="w-3 h-3 stroke-[3]" />
                  </div>
                )}
              </div>
              <div>
                <p className="text-[10px] font-bold text-white truncate">{filter.name}</p>
                <p className="text-[8px] text-amber-400/90 font-mono truncate">{filter.category}</p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
