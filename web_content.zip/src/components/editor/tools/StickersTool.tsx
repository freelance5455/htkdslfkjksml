import React, { useRef } from 'react';
import { Smile, Upload, Plus, Heart, Star, Sparkles, ArrowRight, Bell } from 'lucide-react';
import { Language, translations } from '../../../i18n/translations';

interface StickersToolProps {
  onAddSticker: (emojiOrUrl: string, isCustom: boolean) => void;
  language: Language;
}

export const StickersTool: React.FC<StickersToolProps> = ({
  onAddSticker,
  language,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const t = translations[language];

  const emojis = ['🔥', '✨', '⚡', '💯', '❤️', '🎉', '🚀', '⭐', '🎬', '👏', '😍', '👀', '🎯', '💡', '🏆', '💎'];
  const badges = ['SUBSCRIBE', 'LIKE', 'BELL', 'SHARE', 'NEW', 'PRO', '100%'];
  const shapes = ['➜', '➔', '➤', '★', '♥', '💬', '🔺', '🔹', '⚡'];

  const handleCustomUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    onAddSticker(url, true);
  };

  return (
    <div className="p-3 sm:p-4 text-white space-y-3">
      <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
        <div className="flex items-center gap-2">
          <Smile className="w-4 h-4 text-amber-400" />
          <h4 className="text-xs font-bold uppercase tracking-wider">{t.toolStickers}</h4>
        </div>
        <button
          onClick={() => fileInputRef.current?.click()}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-neutral-200 transition-colors"
        >
          <Upload className="w-3.5 h-3.5 text-amber-400" />
          <span>{language === 'hi' ? 'PNG स्टिकर अपलोड' : 'Upload PNG'}</span>
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/png,image/webp,image/svg+xml"
          className="hidden"
          onChange={handleCustomUpload}
        />
      </div>

      {/* Creator Badges */}
      <div>
        <p className="text-[10px] text-neutral-400 uppercase font-semibold mb-1.5">
          {language === 'hi' ? 'क्रिएटर बैज' : 'Creator Badges'}
        </p>
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {badges.map((b) => (
            <button
              key={b}
              onClick={() => onAddSticker(b, false)}
              className="flex-shrink-0 px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 hover:border-amber-400 text-xs font-black text-amber-400 tracking-wider shadow-sm transition-transform active:scale-95"
            >
              {b}
            </button>
          ))}
        </div>
      </div>

      {/* Trending Emojis */}
      <div>
        <p className="text-[10px] text-neutral-400 uppercase font-semibold mb-1.5">
          {language === 'hi' ? 'इमोजी एवं सिम्बल' : 'Trending Icons & Shapes'}
        </p>
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {emojis.map((emoji) => (
            <button
              key={emoji}
              onClick={() => onAddSticker(emoji, false)}
              className="flex-shrink-0 w-9 h-9 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-amber-400 flex items-center justify-center text-lg transition-transform hover:scale-110 active:scale-95"
            >
              {emoji}
            </button>
          ))}
          {shapes.map((s) => (
            <button
              key={s}
              onClick={() => onAddSticker(s, false)}
              className="flex-shrink-0 w-9 h-9 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-amber-400 flex items-center justify-center text-amber-400 font-bold text-base transition-transform hover:scale-110 active:scale-95"
            >
              {s}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
