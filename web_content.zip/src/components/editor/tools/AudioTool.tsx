import React, { useState, useRef, useEffect } from 'react';
import { Music, Mic, Volume2, VolumeX, Upload, Sparkles, Scissors, Play, Square } from 'lucide-react';
import { audioEngine } from '../../../services/audioEngine';
import { createSoundEffects, generateSyntheticMusicTrack, audioBufferToWavBlob } from '../../../services/sampleMedia';
import { Language, translations } from '../../../i18n/translations';
import { Clip } from '../../../types/editor';

interface AudioToolProps {
  selectedClip?: Clip;
  onUpdateClip: (clip: Clip) => void;
  onAddAudioClip: (name: string, url: string, blob: Blob, duration: number) => void;
  onExtractAudioFromVideo?: () => void;
  language: Language;
}

export const AudioTool: React.FC<AudioToolProps> = ({
  selectedClip,
  onUpdateClip,
  onAddAudioClip,
  onExtractAudioFromVideo,
  language,
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordDuration, setRecordDuration] = useState(0);
  const [audioError, setAudioError] = useState<string | null>(null);
  const recordTimerRef = useRef<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const t = translations[language];

  // Sound effects generator
  const soundEffects = [
    { id: 'sfx_whoosh', name: 'Dynamic Whoosh', cat: 'Transition' },
    { id: 'sfx_pop', name: 'Soft Pop', cat: 'Motion' },
    { id: 'sfx_ding', name: 'Bright Bell', cat: 'Highlight' },
    { id: 'sfx_shutter', name: 'Camera Shutter', cat: 'Snapshot' },
    { id: 'sfx_swish', name: 'High Swish', cat: 'Swoosh' },
  ];

  const handleAddSFX = (sfxId: string, name: string) => {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AudioCtx();
    const sfxList = createSoundEffects(ctx);
    const target = sfxList.find(s => s.id === sfxId);
    if (target) {
      const buffer = target.generator(ctx);
      const wavBlob = audioBufferToWavBlob(buffer);
      const url = URL.createObjectURL(wavBlob);
      onAddAudioClip(name, url, wavBlob, target.duration);
    }
  };

  const handleAddSyntheticMusic = (title: string, duration: number) => {
    const blob = generateSyntheticMusicTrack(title, duration);
    const url = URL.createObjectURL(blob);
    onAddAudioClip(title, url, blob, duration);
  };

  const handleStartRecording = async () => {
    setAudioError(null);
    try {
      await audioEngine.startVoiceRecording();
      setIsRecording(true);
      setRecordDuration(0);
      recordTimerRef.current = window.setInterval(() => {
        setRecordDuration(d => d + 0.1);
      }, 100);
    } catch (e) {
      setAudioError(t.micPermission);
    }
  };

  const handleStopRecording = async () => {
    if (recordTimerRef.current) {
      clearInterval(recordTimerRef.current);
    }
    try {
      const { blob, url, duration } = await audioEngine.stopVoiceRecording();
      setIsRecording(false);
      onAddAudioClip(
        language === 'hi' ? 'वॉइस रिकॉर्डिंग' : 'Voiceover Clip',
        url,
        blob,
        Math.max(1, duration)
      );
    } catch (e) {
      console.error(e);
      setIsRecording(false);
    }
  };

  const handleUploadAudio = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    onAddAudioClip(file.name.substring(0, 18), url, file, 6.0);
  };

  return (
    <div className="p-3 sm:p-4 text-white space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
        <div className="flex items-center gap-2">
          <Music className="w-4 h-4 text-amber-400" />
          <h4 className="text-xs font-bold uppercase tracking-wider">{t.audioTitle}</h4>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-neutral-200 transition-colors"
          >
            <Upload className="w-3.5 h-3.5 text-amber-400" />
            <span>{language === 'hi' ? 'ऑडियो फ़ाइल' : 'Import Music'}</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="audio/*"
            className="hidden"
            onChange={handleUploadAudio}
          />
        </div>
      </div>

      {audioError && (
        <div className="p-2.5 rounded-xl bg-red-950/80 border border-red-800 text-xs text-red-300">
          {audioError}
        </div>
      )}

      {/* Selected clip volume & fade controls (if an audio/video clip is selected) */}
      {selectedClip && (selectedClip.type === 'audio' || selectedClip.type === 'video') && (
        <div className="bg-neutral-950/70 p-3 rounded-xl border border-neutral-800/80 space-y-2.5">
          <div className="flex items-center justify-between text-xs font-semibold">
            <span className="text-neutral-300 truncate max-w-[200px]">
              {selectedClip.name}
            </span>
            <button
              onClick={() => onUpdateClip({ ...selectedClip, muted: !selectedClip.muted })}
              className={`p-1.5 rounded-lg flex items-center gap-1 text-[11px] ${
                selectedClip.muted ? 'bg-red-950 text-red-400' : 'bg-neutral-800 text-neutral-300'
              }`}
            >
              {selectedClip.muted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
              <span>{selectedClip.muted ? t.mute : t.unmute}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <div>
              <div className="flex items-center justify-between text-[10px] text-neutral-400 mb-1">
                <span>{t.volume}</span>
                <span className="font-mono text-amber-400">{Math.round(selectedClip.volume * 100)}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={2}
                step={0.05}
                value={selectedClip.volume}
                onChange={(e) => onUpdateClip({ ...selectedClip, volume: Number(e.target.value) })}
                className="w-full h-1.5 bg-neutral-800 rounded appearance-none cursor-pointer"
              />
            </div>
            <div>
              <div className="flex items-center justify-between text-[10px] text-neutral-400 mb-1">
                <span>{t.fadeIn}</span>
                <span className="font-mono text-amber-400">{selectedClip.fadeIn}s</span>
              </div>
              <input
                type="range"
                min={0}
                max={4}
                step={0.1}
                value={selectedClip.fadeIn}
                onChange={(e) => onUpdateClip({ ...selectedClip, fadeIn: Number(e.target.value) })}
                className="w-full h-1.5 bg-neutral-800 rounded appearance-none cursor-pointer"
              />
            </div>
            <div>
              <div className="flex items-center justify-between text-[10px] text-neutral-400 mb-1">
                <span>{t.fadeOut}</span>
                <span className="font-mono text-amber-400">{selectedClip.fadeOut}s</span>
              </div>
              <input
                type="range"
                min={0}
                max={4}
                step={0.1}
                value={selectedClip.fadeOut}
                onChange={(e) => onUpdateClip({ ...selectedClip, fadeOut: Number(e.target.value) })}
                className="w-full h-1.5 bg-neutral-800 rounded appearance-none cursor-pointer"
              />
            </div>
          </div>
        </div>
      )}

      {/* Voice Recorder & Sound FX Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Voiceover Recording */}
        <div className="bg-neutral-950/60 p-3 rounded-xl border border-neutral-800/80 flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-white block">{t.recordVoice}</span>
            <span className="text-[10px] text-neutral-400 font-mono">
              {isRecording ? `${recordDuration.toFixed(1)}s recording...` : (language === 'hi' ? 'माइक से डबिंग' : 'Direct microphone input')}
            </span>
          </div>
          {!isRecording ? (
            <button
              onClick={handleStartRecording}
              className="py-1.5 px-3 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-red-600/20 active:scale-95 transition-all"
            >
              <Mic className="w-3.5 h-3.5" />
              <span>{t.startRecording}</span>
            </button>
          ) : (
            <button
              onClick={handleStopRecording}
              className="py-1.5 px-3 rounded-lg bg-white text-black font-bold text-xs flex items-center gap-1.5 animate-pulse"
            >
              <Square className="w-3.5 h-3.5 fill-black" />
              <span>{t.stopRecording}</span>
            </button>
          )}
        </div>

        {/* Extract Audio from Video Clip (if video is selected) */}
        {onExtractAudioFromVideo && (
          <div className="bg-neutral-950/60 p-3 rounded-xl border border-neutral-800/80 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-white block">{t.extractAudio}</span>
              <span className="text-[10px] text-neutral-400">{language === 'hi' ? 'अलग ट्रैक बनाएं' : 'Separate audio track'}</span>
            </div>
            <button
              onClick={onExtractAudioFromVideo}
              className="py-1.5 px-3 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-amber-400 font-bold text-xs flex items-center gap-1.5 transition-colors"
            >
              <Scissors className="w-3.5 h-3.5" />
              <span>{t.extractAudio}</span>
            </button>
          </div>
        )}
      </div>

      {/* Royalty Free Music Presets & SFX Library */}
      <div>
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider">
            {language === 'hi' ? 'रॉयल्टी-फ्री ट्रैक्स एवं साउंड इफेक्ट्स' : 'Royalty-Free Tracks & SFX'}
          </span>
        </div>
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <button
            onClick={() => handleAddSyntheticMusic('Lofi Chill Vibes', 10)}
            className="flex-shrink-0 px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 hover:border-amber-400 text-xs font-medium text-amber-300 flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Lofi Chill (10s)</span>
          </button>
          <button
            onClick={() => handleAddSyntheticMusic('Upbeat Rhythm', 10)}
            className="flex-shrink-0 px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 hover:border-amber-400 text-xs font-medium text-amber-300 flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Upbeat Beat (10s)</span>
          </button>
          {soundEffects.map((s) => (
            <button
              key={s.id}
              onClick={() => handleAddSFX(s.id, s.name)}
              className="flex-shrink-0 px-2.5 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-xs text-neutral-300 flex items-center gap-1"
            >
              <span>+</span>
              <span>{s.name}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
