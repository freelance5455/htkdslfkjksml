import React from 'react';
import { Square, Circle, Split, Ban, FlipHorizontal } from 'lucide-react';
import { MaskConfig } from '../../../types/editor';
import { Language, translations } from '../../../i18n/translations';

interface MaskToolProps {
  mask: MaskConfig;
  onChange: (mask: MaskConfig) => void;
  language: Language;
}

export const MaskTool: React.FC<MaskToolProps> = ({
  mask,
  onChange,
  language,
}) => {
  const t = translations[language];

  const types: { id: MaskConfig['type']; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'none', label: t.maskNone, icon: Ban },
    { id: 'rectangle', label: t.maskRect, icon: Square },
    { id: 'circle', label: t.maskCircle, icon: Circle },
    { id: 'linear', label: t.maskLinear, icon: Split },
  ];

  return (
    <div className="p-3 sm:p-4 text-white">
      <div className="flex items-center justify-between mb-3 pb-2 border-b border-neutral-800">
        <h4 className="text-xs font-bold uppercase tracking-wider">{t.maskTitle}</h4>
        {mask.type !== 'none' && (
          <button
            onClick={() => onChange({ ...mask, inverted: !mask.inverted })}
            className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-semibold transition-colors ${
              mask.inverted ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'bg-neutral-800 text-neutral-400'
            }`}
          >
            <FlipHorizontal className="w-3.5 h-3.5" />
            <span>{t.invertMask}</span>
          </button>
        )}
      </div>

      <div className="grid grid-cols-4 gap-2 mb-3">
        {types.map((m) => {
          const Icon = m.icon;
          const isSelected = mask.type === m.id;
          return (
            <button
              key={m.id}
              onClick={() => onChange({ ...mask, type: m.id })}
              className={`p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all ${
                isSelected
                  ? 'border-amber-400 bg-amber-500/15 text-white font-bold'
                  : 'border-neutral-800 bg-neutral-950/70 text-neutral-400 hover:border-neutral-700'
              }`}
            >
              <Icon className={`w-5 h-5 ${isSelected ? 'text-amber-400' : 'text-neutral-400'}`} />
              <span className="text-[10px] text-center">{m.label}</span>
            </button>
          );
        })}
      </div>

      {mask.type !== 'none' && (
        <div className="grid grid-cols-2 gap-3 bg-neutral-950/60 p-3 rounded-xl border border-neutral-800/80">
          <div>
            <div className="flex items-center justify-between text-[11px] mb-1">
              <span className="text-neutral-300">{t.feather}</span>
              <span className="font-mono text-amber-400">{mask.feather}px</span>
            </div>
            <input
              type="range"
              min={0}
              max={50}
              value={mask.feather}
              onChange={(e) => onChange({ ...mask, feather: Number(e.target.value) })}
              className="w-full h-1.5 bg-neutral-800 rounded appearance-none cursor-pointer"
            />
          </div>
          <div>
            <div className="flex items-center justify-between text-[11px] mb-1">
              <span className="text-neutral-300">{t.rotate}</span>
              <span className="font-mono text-amber-400">{mask.rotation}°</span>
            </div>
            <input
              type="range"
              min={-180}
              max={180}
              value={mask.rotation}
              onChange={(e) => onChange({ ...mask, rotation: Number(e.target.value) })}
              className="w-full h-1.5 bg-neutral-800 rounded appearance-none cursor-pointer"
            />
          </div>
        </div>
      )}
    </div>
  );
};
