import React from 'react';
import { Wand2, Activity, Zap } from 'lucide-react';
import { VisualEffect } from '../../../types/editor';
import { BUILTIN_EFFECTS } from '../../../services/sampleMedia';
import { Language, translations } from '../../../i18n/translations';

interface EffectsToolProps {
  effects: VisualEffect[];
  onChange: (effects: VisualEffect[]) => void;
  language: Language;
}

export const EffectsTool: React.FC<EffectsToolProps> = ({
  effects,
  onChange,
  language,
}) => {
  const t = translations[language];

  const handleToggleEffect = (eff: { id: string; name: string; type: string; defaultIntensity: number; defaultSpeed: number }) => {
    const exists = effects.find(e => e.type === eff.type);
    if (exists) {
      onChange(effects.filter(e => e.type !== eff.type));
    } else {
      const newEffect: VisualEffect = {
        id: `eff_${Date.now()}`,
        type: eff.type,
        name: eff.name,
        intensity: eff.defaultIntensity,
        speed: eff.defaultSpeed,
      };
      onChange([...effects, newEffect]);
    }
  };

  const handleUpdateEffectParam = (type: string, key: 'intensity' | 'speed', val: number) => {
    onChange(
      effects.map(e => (e.type === type ? { ...e, [key]: val } : e))
    );
  };

  return (
    <div className="p-3 sm:p-4 text-white">
      <div className="flex items-center justify-between mb-3 pb-2 border-b border-neutral-800">
        <div className="flex items-center gap-2">
          <Wand2 className="w-4 h-4 text-amber-400" />
          <h4 className="text-xs font-bold uppercase tracking-wider">{t.toolEffects}</h4>
        </div>
        <span className="text-[11px] text-neutral-400 font-mono">
          {effects.length} {language === 'hi' ? 'सक्रिय' : 'active'}
        </span>
      </div>

      {/* Effects list */}
      <div className="flex items-center gap-2.5 overflow-x-auto pb-2">
        {BUILTIN_EFFECTS.map((eff) => {
          const active = effects.find(e => e.type === eff.type);
          return (
            <div
              key={eff.id}
              className={`flex-shrink-0 w-36 rounded-xl border p-2.5 transition-all ${
                active
                  ? 'border-amber-400 bg-amber-500/15'
                  : 'border-neutral-800 bg-neutral-950/70 hover:border-neutral-700'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold text-white line-clamp-1">{eff.name}</span>
                <button
                  onClick={() => handleToggleEffect(eff)}
                  className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold transition-colors ${
                    active ? 'bg-amber-400 text-black' : 'bg-neutral-800 text-neutral-400 hover:text-white'
                  }`}
                >
                  {active ? '✓' : '+'}
                </button>
              </div>

              {active ? (
                <div className="space-y-1.5 mt-2 pt-2 border-t border-neutral-800/80">
                  <div className="flex items-center justify-between text-[9px] text-neutral-300">
                    <span>{t.intensity}</span>
                    <span className="font-mono text-amber-400">{active.intensity}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={active.intensity}
                    onChange={(e) => handleUpdateEffectParam(eff.type, 'intensity', Number(e.target.value))}
                    className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer"
                  />
                  <div className="flex items-center justify-between text-[9px] text-neutral-300">
                    <span>{t.speed}</span>
                    <span className="font-mono text-amber-400">{active.speed}%</span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={active.speed}
                    onChange={(e) => handleUpdateEffectParam(eff.type, 'speed', Number(e.target.value))}
                    className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer"
                  />
                </div>
              ) : (
                <p className="text-[10px] text-neutral-500 line-clamp-2">
                  Click + to add live {eff.name.toLowerCase()} shader
                </p>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
