import React from 'react';
import { Key, Plus, Trash2, Crosshair, Sparkles } from 'lucide-react';
import { Clip, Keyframe } from '../../../types/editor';
import { Language, translations } from '../../../i18n/translations';

interface KeyframeToolProps {
  clip: Clip;
  currentTime: number; // in project timeline seconds
  onChange: (clip: Clip) => void;
  language: Language;
}

export const KeyframeTool: React.FC<KeyframeToolProps> = ({
  clip,
  currentTime,
  onChange,
  language,
}) => {
  const t = translations[language];
  const relativeTime = Math.max(0, Math.min(clip.duration, currentTime - clip.start));

  const existingKeyframeIndex = (clip.keyframes || []).findIndex(
    k => Math.abs(k.time - relativeTime) < 0.15
  );
  const currentKeyframe = existingKeyframeIndex >= 0 ? clip.keyframes[existingKeyframeIndex] : null;

  const handleToggleKeyframe = () => {
    const list = [...(clip.keyframes || [])];
    if (existingKeyframeIndex >= 0) {
      list.splice(existingKeyframeIndex, 1);
    } else {
      const newKf: Keyframe = {
        id: `kf_${Date.now()}`,
        time: Number(relativeTime.toFixed(2)),
        x: clip.x || 0,
        y: clip.y || 0,
        scale: clip.scale || 1.0,
        rotation: clip.rotation || 0,
        opacity: clip.opacity ?? 1.0,
      };
      list.push(newKf);
      list.sort((a, b) => a.time - b.time);
    }
    onChange({ ...clip, keyframes: list });
  };

  const handleUpdateCurrentKeyframe = (key: keyof Keyframe, value: number) => {
    if (!currentKeyframe) return;
    const list = clip.keyframes.map((k, idx) => 
      idx === existingKeyframeIndex ? { ...k, [key]: value } : k
    );
    onChange({ ...clip, keyframes: list });
  };

  return (
    <div className="p-3 sm:p-4 text-white space-y-3">
      <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
        <div className="flex items-center gap-2">
          <Key className="w-4 h-4 text-amber-400" />
          <h4 className="text-xs font-bold uppercase tracking-wider">{t.keyframeTitle}</h4>
        </div>
        <button
          onClick={handleToggleKeyframe}
          className={`py-1.5 px-3 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
            currentKeyframe
              ? 'bg-red-950/80 border border-red-800 text-red-300'
              : 'bg-amber-500 text-black shadow-md shadow-amber-500/20'
          }`}
        >
          {currentKeyframe ? <Trash2 className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5 stroke-[3]" />}
          <span>{currentKeyframe ? t.removeKeyframe : t.addKeyframe}</span>
        </button>
      </div>

      <p className="text-[11px] text-neutral-400">
        {t.keyframeHelp}
      </p>

      {currentKeyframe ? (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 bg-neutral-950/70 p-3 rounded-xl border border-amber-500/30">
          <div>
            <div className="flex justify-between text-[10px] text-neutral-400 mb-1">
              <span>Pos X</span>
              <span className="font-mono text-amber-400">{currentKeyframe.x}%</span>
            </div>
            <input
              type="range"
              min={-100}
              max={100}
              value={currentKeyframe.x}
              onChange={(e) => handleUpdateCurrentKeyframe('x', Number(e.target.value))}
              className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer"
            />
          </div>
          <div>
            <div className="flex justify-between text-[10px] text-neutral-400 mb-1">
              <span>Pos Y</span>
              <span className="font-mono text-amber-400">{currentKeyframe.y}%</span>
            </div>
            <input
              type="range"
              min={-100}
              max={100}
              value={currentKeyframe.y}
              onChange={(e) => handleUpdateCurrentKeyframe('y', Number(e.target.value))}
              className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer"
            />
          </div>
          <div>
            <div className="flex justify-between text-[10px] text-neutral-400 mb-1">
              <span>Scale</span>
              <span className="font-mono text-amber-400">{currentKeyframe.scale.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              min={0.2}
              max={3.0}
              step={0.05}
              value={currentKeyframe.scale}
              onChange={(e) => handleUpdateCurrentKeyframe('scale', Number(e.target.value))}
              className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer"
            />
          </div>
          <div>
            <div className="flex justify-between text-[10px] text-neutral-400 mb-1">
              <span>Rotation</span>
              <span className="font-mono text-amber-400">{currentKeyframe.rotation}°</span>
            </div>
            <input
              type="range"
              min={-180}
              max={180}
              value={currentKeyframe.rotation}
              onChange={(e) => handleUpdateCurrentKeyframe('rotation', Number(e.target.value))}
              className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer"
            />
          </div>
        </div>
      ) : (
        <div className="flex items-center gap-2 overflow-x-auto py-2">
          <span className="text-[10px] text-neutral-500 font-mono">
            {clip.keyframes?.length || 0} {language === 'hi' ? 'कीफ़्रेम सेट हैं' : 'keyframes on this clip.'}
          </span>
          {clip.keyframes?.map((kf, i) => (
            <span
              key={kf.id}
              className="px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-[10px] font-mono text-amber-300"
            >
              #{i + 1} @ {kf.time}s
            </span>
          ))}
        </div>
      )}
    </div>
  );
};
