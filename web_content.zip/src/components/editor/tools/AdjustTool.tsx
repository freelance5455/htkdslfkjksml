import React from 'react';
import { RotateCcw, Sliders } from 'lucide-react';
import { ColorAdjustments } from '../../../types/editor';
import { Language, translations } from '../../../i18n/translations';

interface AdjustToolProps {
  adjustments: ColorAdjustments;
  onChange: (adjustments: ColorAdjustments) => void;
  language: Language;
}

export const AdjustTool: React.FC<AdjustToolProps> = ({
  adjustments,
  onChange,
  language,
}) => {
  const t = translations[language];

  const updateField = (key: keyof ColorAdjustments, value: number) => {
    onChange({ ...adjustments, [key]: value });
  };

  const handleReset = () => {
    onChange({
      brightness: 0,
      contrast: 0,
      saturation: 0,
      exposure: 0,
      highlights: 0,
      shadows: 0,
      temperature: 0,
      tint: 0,
      sharpness: 0,
      vignette: 0,
      grain: 0,
      hue: 0,
    });
  };

  const sliders: { key: keyof ColorAdjustments; label: string; min: number; max: number; unit?: string }[] = [
    { key: 'brightness', label: t.brightness, min: -100, max: 100 },
    { key: 'contrast', label: t.contrast, min: -100, max: 100 },
    { key: 'saturation', label: t.saturation, min: -100, max: 100 },
    { key: 'exposure', label: t.exposure, min: -100, max: 100 },
    { key: 'highlights', label: t.highlights, min: -100, max: 100 },
    { key: 'shadows', label: t.shadows, min: -100, max: 100 },
    { key: 'temperature', label: t.temperature, min: -100, max: 100 },
    { key: 'tint', label: t.tint, min: -100, max: 100 },
    { key: 'sharpness', label: t.sharpness, min: 0, max: 100 },
    { key: 'vignette', label: t.vignette, min: 0, max: 100 },
    { key: 'grain', label: t.grain, min: 0, max: 100 },
    { key: 'hue', label: t.hue, min: -180, max: 180, unit: '°' },
  ];

  return (
    <div className="p-3 sm:p-4 text-white">
      <div className="flex items-center justify-between mb-3 pb-2 border-b border-neutral-800">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-amber-400" />
          <h4 className="text-xs font-bold uppercase tracking-wider">{t.toolAdjust}</h4>
        </div>
        <button
          onClick={handleReset}
          className="flex items-center gap-1 text-[11px] font-semibold text-neutral-400 hover:text-amber-400 transition-colors"
        >
          <RotateCcw className="w-3 h-3" />
          <span>{t.reset}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-3 max-h-48 overflow-y-auto pr-1">
        {sliders.map(({ key, label, min, max, unit }) => {
          const val = adjustments[key] || 0;
          return (
            <div key={key} className="bg-neutral-950/60 p-2 rounded-xl border border-neutral-800/80">
              <div className="flex items-center justify-between text-[11px] mb-1">
                <span className="text-neutral-300 font-medium">{label}</span>
                <span className="font-mono text-amber-400">{val > 0 ? `+${val}` : val}{unit || ''}</span>
              </div>
              <input
                type="range"
                min={min}
                max={max}
                value={val}
                onChange={(e) => updateField(key, Number(e.target.value))}
                className="w-full h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer"
              />
            </div>
          );
        })}
      </div>
    </div>
  );
};
