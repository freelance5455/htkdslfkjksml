import React, { useRef } from 'react';
import { Layers, FlipHorizontal, FlipVertical, RotateCw, Plus, Upload } from 'lucide-react';
import { Clip, BlendMode } from '../../../types/editor';
import { Language, translations } from '../../../i18n/translations';

interface OverlayToolProps {
  clip?: Clip;
  onChange: (clip: Clip) => void;
  onAddOverlayMedia: (file: File) => void;
  language: Language;
}

export const OverlayTool: React.FC<OverlayToolProps> = ({
  clip,
  onChange,
  onAddOverlayMedia,
  language,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const t = translations[language];

  const blendModes: BlendMode[] = [
    'normal', 'multiply', 'screen', 'overlay', 'darken', 'lighten', 'color-dodge', 'difference'
  ];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onAddOverlayMedia(file);
    }
  };

  return (
    <div className="p-3 sm:p-4 text-white space-y-3">
      <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-amber-400" />
          <h4 className="text-xs font-bold uppercase tracking-wider">{t.toolOverlay}</h4>
        </div>
        <button
          onClick={() => fileInputRef.current?.click()}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500 text-black text-xs font-bold shadow-md shadow-amber-500/20 active:scale-95 transition-all"
        >
          <Plus className="w-3.5 h-3.5 stroke-[3]" />
          <span>{language === 'hi' ? 'PIP मीडिया जोड़ें' : 'Add PIP Media'}</span>
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="video/*,image/*"
          className="hidden"
          onChange={handleFileUpload}
        />
      </div>

      {clip ? (
        <div className="space-y-3">
          {/* Spatial Sliders */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 bg-neutral-950/60 p-3 rounded-xl border border-neutral-800/80">
            <div>
              <div className="flex justify-between text-[10px] text-neutral-400 mb-1">
                <span>Scale</span>
                <span className="font-mono text-amber-400">{clip.scale.toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min={0.2}
                max={3.0}
                step={0.05}
                value={clip.scale}
                onChange={(e) => onChange({ ...clip, scale: Number(e.target.value) })}
                className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-[10px] text-neutral-400 mb-1">
                <span>{t.opacity}</span>
                <span className="font-mono text-amber-400">{Math.round(clip.opacity * 100)}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={clip.opacity}
                onChange={(e) => onChange({ ...clip, opacity: Number(e.target.value) })}
                className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-[10px] text-neutral-400 mb-1">
                <span>Pos X</span>
                <span className="font-mono text-amber-400">{clip.x}%</span>
              </div>
              <input
                type="range"
                min={-100}
                max={100}
                value={clip.x}
                onChange={(e) => onChange({ ...clip, x: Number(e.target.value) })}
                className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-[10px] text-neutral-400 mb-1">
                <span>Pos Y</span>
                <span className="font-mono text-amber-400">{clip.y}%</span>
              </div>
              <input
                type="range"
                min={-100}
                max={100}
                value={clip.y}
                onChange={(e) => onChange({ ...clip, y: Number(e.target.value) })}
                className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer"
              />
            </div>
          </div>

          {/* Flips & Blend Mode */}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => onChange({ ...clip, flipH: !clip.flipH })}
                className={`p-2 rounded-lg border text-xs font-semibold flex items-center gap-1 transition-colors ${
                  clip.flipH ? 'border-amber-400 bg-amber-500/15 text-amber-300' : 'border-neutral-800 bg-neutral-900 text-neutral-400'
                }`}
              >
                <FlipHorizontal className="w-3.5 h-3.5" />
                <span>{t.flipH}</span>
              </button>
              <button
                onClick={() => onChange({ ...clip, flipV: !clip.flipV })}
                className={`p-2 rounded-lg border text-xs font-semibold flex items-center gap-1 transition-colors ${
                  clip.flipV ? 'border-amber-400 bg-amber-500/15 text-amber-300' : 'border-neutral-800 bg-neutral-900 text-neutral-400'
                }`}
              >
                <FlipVertical className="w-3.5 h-3.5" />
                <span>{t.flipV}</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[11px] text-neutral-400">{t.blendMode}:</span>
              <select
                value={clip.blendMode}
                onChange={(e) => onChange({ ...clip, blendMode: e.target.value as BlendMode })}
                className="bg-neutral-950 border border-neutral-800 rounded-lg px-2.5 py-1 text-xs text-white uppercase font-mono"
              >
                {blendModes.map((bm) => (
                  <option key={bm} value={bm}>
                    {bm}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      ) : (
        <p className="text-xs text-neutral-500 py-2 text-center">
          {language === 'hi' ? 'टाइमलाइन पर ओवरले क्लिप चुनें या ऊपर दिए बटन से नई PIP जोड़ें।' : 'Select an overlay clip on the timeline or click Add PIP Media.'}
        </p>
      )}
    </div>
  );
};
