import React from 'react';
import { Gauge, RotateCcw, Snowflake, Play } from 'lucide-react';
import { Clip } from '../../../types/editor';
import { Language, translations } from '../../../i18n/translations';

interface SpeedToolProps {
  clip: Clip;
  onChange: (clip: Clip) => void;
  onFreezeFrame?: () => void;
  language: Language;
}

export const SpeedTool: React.FC<SpeedToolProps> = ({
  clip,
  onChange,
  onFreezeFrame,
  language,
}) => {
  const t = translations[language];

  const presets = [0.2, 0.5, 1.0, 1.5, 2.0, 4.0, 8.0];

  const handleSpeedChange = (newSpeed: number) => {
    const ratio = clip.speed / newSpeed;
    const newDuration = Math.max(0.5, clip.duration * ratio);
    onChange({
      ...clip,
      speed: newSpeed,
      duration: Number(newDuration.toFixed(2)),
    });
  };

  return (
    <div className="p-3 sm:p-4 text-white space-y-3">
      <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
        <div className="flex items-center gap-2">
          <Gauge className="w-4 h-4 text-amber-400" />
          <h4 className="text-xs font-bold uppercase tracking-wider">{t.toolSpeed}</h4>
        </div>
        <span className="font-mono text-xs font-bold text-amber-400">{clip.speed}x</span>
      </div>

      {/* Speed Slider */}
      <div className="bg-neutral-950/60 p-3 rounded-xl border border-neutral-800/80">
        <div className="flex items-center justify-between text-[11px] mb-2">
          <span className="text-neutral-400">Slow-mo (0.1x)</span>
          <span className="text-neutral-400">Fast (10x)</span>
        </div>
        <input
          type="range"
          min={0.1}
          max={10.0}
          step={0.1}
          value={clip.speed}
          onChange={(e) => handleSpeedChange(Number(e.target.value))}
          className="w-full h-1.5 bg-neutral-800 rounded appearance-none cursor-pointer"
        />

        {/* Preset quick buttons */}
        <div className="flex items-center justify-between gap-1 mt-3">
          {presets.map((p) => (
            <button
              key={p}
              onClick={() => handleSpeedChange(p)}
              className={`flex-1 py-1 rounded-lg text-[10px] font-mono font-bold transition-all ${
                clip.speed === p
                  ? 'bg-amber-400 text-black shadow-sm'
                  : 'bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white'
              }`}
            >
              {p}x
            </button>
          ))}
        </div>
      </div>

      {/* Reverse & Freeze Frame */}
      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={() => onChange({ ...clip, reverse: !clip.reverse })}
          className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-colors ${
            clip.reverse
              ? 'border-amber-400 bg-amber-500/15 text-amber-300'
              : 'border-neutral-800 bg-neutral-950/70 text-neutral-300 hover:border-neutral-700'
          }`}
        >
          <RotateCcw className="w-4 h-4" />
          <span>{t.reverse}</span>
        </button>

        {onFreezeFrame && (
          <button
            onClick={onFreezeFrame}
            className="py-2 px-3 rounded-xl border border-neutral-800 bg-neutral-950/70 hover:border-neutral-700 text-xs font-semibold text-neutral-300 flex items-center justify-center gap-2 transition-colors"
          >
            <Snowflake className="w-4 h-4 text-cyan-400" />
            <span>{t.freeze}</span>
          </button>
        )}
      </div>
    </div>
  );
};
