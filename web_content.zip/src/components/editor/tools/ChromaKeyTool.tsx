import React from 'react';
import { Pipette, Check, Sparkles, AlertCircle } from 'lucide-react';
import { ChromaKeyConfig } from '../../../types/editor';
import { Language, translations } from '../../../i18n/translations';

interface ChromaKeyToolProps {
  config: ChromaKeyConfig;
  onChange: (config: ChromaKeyConfig) => void;
  language: Language;
}

export const ChromaKeyTool: React.FC<ChromaKeyToolProps> = ({
  config,
  onChange,
  language,
}) => {
  const t = translations[language];

  const presets = ['#00ff00', '#0000ff', '#ff00ff', '#00e5ff', '#000000', '#ffffff'];

  return (
    <div className="p-3 sm:p-4 text-white">
      <div className="flex items-center justify-between mb-3 pb-2 border-b border-neutral-800">
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider">{t.chromaKeyTitle}</h4>
          <p className="text-[10px] text-neutral-400">{t.chromaHelp}</p>
        </div>
        <label className="relative inline-flex items-center cursor-pointer">
          <input
            type="checkbox"
            checked={config.enabled}
            onChange={(e) => onChange({ ...config, enabled: e.target.checked })}
            className="sr-only peer"
          />
          <div className="w-9 h-5 bg-neutral-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
        </label>
      </div>

      {config.enabled ? (
        <div className="space-y-3">
          {/* Key Color Picker */}
          <div className="bg-neutral-950/60 p-3 rounded-xl border border-neutral-800/80">
            <span className="text-[11px] font-semibold text-neutral-300 block mb-2">{t.pickColor}</span>
            <div className="flex items-center gap-2">
              {presets.map((c) => (
                <button
                  key={c}
                  onClick={() => onChange({ ...config, color: c })}
                  className="w-7 h-7 rounded-full border border-neutral-700 flex items-center justify-center transition-transform hover:scale-110"
                  style={{ backgroundColor: c }}
                >
                  {config.color.toLowerCase() === c.toLowerCase() && (
                    <Check className={`w-3.5 h-3.5 ${c === '#ffffff' ? 'text-black' : 'text-white'}`} />
                  )}
                </button>
              ))}
              <div className="flex items-center gap-1.5 ml-2">
                <input
                  type="color"
                  value={config.color}
                  onChange={(e) => onChange({ ...config, color: e.target.value })}
                  className="w-7 h-7 rounded cursor-pointer bg-transparent border-0"
                />
                <span className="text-[10px] font-mono text-neutral-400 uppercase">{config.color}</span>
              </div>
            </div>
          </div>

          {/* Sliders: Similarity, Smoothness, Spill */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-neutral-950/60 p-2.5 rounded-xl border border-neutral-800/80">
              <div className="flex items-center justify-between text-[11px] mb-1">
                <span className="text-neutral-300">{t.similarity}</span>
                <span className="font-mono text-amber-400">{config.similarity}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={config.similarity}
                onChange={(e) => onChange({ ...config, similarity: Number(e.target.value) })}
                className="w-full h-1.5 bg-neutral-800 rounded appearance-none cursor-pointer"
              />
            </div>

            <div className="bg-neutral-950/60 p-2.5 rounded-xl border border-neutral-800/80">
              <div className="flex items-center justify-between text-[11px] mb-1">
                <span className="text-neutral-300">{t.smoothness}</span>
                <span className="font-mono text-amber-400">{config.smoothness}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={config.smoothness}
                onChange={(e) => onChange({ ...config, smoothness: Number(e.target.value) })}
                className="w-full h-1.5 bg-neutral-800 rounded appearance-none cursor-pointer"
              />
            </div>

            <div className="bg-neutral-950/60 p-2.5 rounded-xl border border-neutral-800/80">
              <div className="flex items-center justify-between text-[11px] mb-1">
                <span className="text-neutral-300">{t.spillReduction}</span>
                <span className="font-mono text-amber-400">{config.spillReduction}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={config.spillReduction}
                onChange={(e) => onChange({ ...config, spillReduction: Number(e.target.value) })}
                className="w-full h-1.5 bg-neutral-800 rounded appearance-none cursor-pointer"
              />
            </div>
          </div>
        </div>
      ) : (
        <p className="text-xs text-neutral-500 py-3 text-center">
          {language === 'hi' ? 'ग्रीन या ब्लू बैकग्राउंड हटाने के लिए क्रोमा की टॉगल चालू करें।' : 'Enable toggle above to remove green screen or solid backdrops.'}
        </p>
      )}
    </div>
  );
};
