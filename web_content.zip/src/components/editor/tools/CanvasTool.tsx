import React from 'react';
import { Smartphone, Youtube, Instagram, Film, Palette, Layers } from 'lucide-react';
import { AspectRatioType, BackgroundConfig } from '../../../types/editor';
import { Language, translations } from '../../../i18n/translations';

interface CanvasToolProps {
  aspectRatio: AspectRatioType;
  background: BackgroundConfig;
  onAspectRatioChange: (ratio: AspectRatioType) => void;
  onBackgroundChange: (bg: BackgroundConfig) => void;
  language: Language;
}

export const CanvasTool: React.FC<CanvasToolProps> = ({
  aspectRatio,
  background,
  onAspectRatioChange,
  onBackgroundChange,
  language,
}) => {
  const t = translations[language];

  const ratios: { id: AspectRatioType; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: '9:16', label: '9:16 Reels', icon: Smartphone },
    { id: '16:9', label: '16:9 YouTube', icon: Youtube },
    { id: '1:1', label: '1:1 Square', icon: Instagram },
    { id: '4:5', label: '4:5 Feed', icon: Instagram },
    { id: '4:3', label: '4:3 TV', icon: Film },
    { id: '3:4', label: '3:4 Portrait', icon: Smartphone },
  ];

  const bgColors = ['#000000', '#0f172a', '#18181b', '#312e81', '#4c0519', '#064e3b', '#ffffff'];

  return (
    <div className="p-3 sm:p-4 text-white space-y-3">
      <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
        <h4 className="text-xs font-bold uppercase tracking-wider">{t.toolCanvas} & {t.aspectRatio}</h4>
        <span className="font-mono text-xs text-amber-400 font-bold">{aspectRatio}</span>
      </div>

      {/* Ratio Selector */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
        {ratios.map((r) => {
          const Icon = r.icon;
          const isSelected = aspectRatio === r.id;
          return (
            <button
              key={r.id}
              onClick={() => onAspectRatioChange(r.id)}
              className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all ${
                isSelected
                  ? 'border-amber-400 bg-amber-500/15 text-white font-bold'
                  : 'border-neutral-800 bg-neutral-950/70 text-neutral-400 hover:border-neutral-700'
              }`}
            >
              <Icon className={`w-4 h-4 ${isSelected ? 'text-amber-400' : 'text-neutral-500'}`} />
              <span className="text-[10px]">{r.label}</span>
            </button>
          );
        })}
      </div>

      {/* Canvas Background Color */}
      <div className="bg-neutral-950/60 p-2.5 rounded-xl border border-neutral-800/80 flex items-center justify-between">
        <span className="text-xs font-semibold text-neutral-300">
          {language === 'hi' ? 'बैकग्राउंड रंग' : 'Background Color'}
        </span>
        <div className="flex items-center gap-2">
          {bgColors.map((c) => (
            <button
              key={c}
              onClick={() => onBackgroundChange({ type: 'color', color: c })}
              className={`w-5 h-5 rounded-full border border-neutral-700 transition-transform ${
                background.color === c ? 'scale-125 ring-2 ring-amber-400' : ''
              }`}
              style={{ backgroundColor: c }}
            />
          ))}
          <input
            type="color"
            value={background.color || '#000000'}
            onChange={(e) => onBackgroundChange({ type: 'color', color: e.target.value })}
            className="w-5 h-5 rounded cursor-pointer bg-transparent border-0"
          />
        </div>
      </div>
    </div>
  );
};
