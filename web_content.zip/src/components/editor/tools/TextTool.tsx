import React, { useRef } from 'react';
import { Type, AlignLeft, AlignCenter, AlignRight, Bold, Italic, Palette, Sparkles, Plus, Upload } from 'lucide-react';
import { TextConfig } from '../../../types/editor';
import { Language, translations } from '../../../i18n/translations';

interface TextToolProps {
  config?: TextConfig;
  onChange: (config: TextConfig) => void;
  onAddNewText: () => void;
  language: Language;
}

export const TextTool: React.FC<TextToolProps> = ({
  config,
  onChange,
  onAddNewText,
  language,
}) => {
  const fontUploadRef = useRef<HTMLInputElement>(null);
  const t = translations[language];

  const fonts = [
    { name: 'Plus Jakarta Sans', family: "'Plus Jakarta Sans', sans-serif" },
    { name: 'Tiro Hindi', family: "'Tiro Devanagari Hindi', serif" },
    { name: 'Rozha Devanagari', family: "'Rozha One', serif" },
    { name: 'JetBrains Mono', family: "'JetBrains Mono', monospace" },
    { name: 'Impact Heavy', family: 'Impact, sans-serif' },
    { name: 'Georgia Serif', family: 'Georgia, serif' },
  ];

  const animations: TextConfig['animation'][] = [
    'none', 'typewriter', 'bounce', 'pop', 'fade', 'slide', 'zoom', 'shake'
  ];

  const colorPresets = ['#ffffff', '#f59e0b', '#ef4444', '#10b981', '#3b82f6', '#ec4899', '#000000'];

  const handleCustomFontUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const fontName = `UserFont_${Date.now()}`;
    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as ArrayBuffer;
      const font = new FontFace(fontName, result);
      font.load().then((loadedFont) => {
        document.fonts.add(loadedFont);
        if (config) {
          onChange({ ...config, fontFamily: fontName });
        }
      });
    };
    reader.readAsArrayBuffer(file);
  };

  if (!config) {
    return (
      <div className="p-4 text-center text-white">
        <p className="text-xs text-neutral-400 mb-3">
          {language === 'hi' ? 'कोई टेक्स्ट क्लिप नहीं चुनी गई है।' : 'No text clip selected.'}
        </p>
        <button
          onClick={onAddNewText}
          className="py-2.5 px-5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-black font-extrabold text-xs shadow-lg shadow-amber-500/20 inline-flex items-center gap-2"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>{language === 'hi' ? 'नया टेक्स्ट जोड़ें' : 'Add New Text'}</span>
        </button>
      </div>
    );
  }

  return (
    <div className="p-3 sm:p-4 text-white space-y-3">
      {/* Top action: Content & Add */}
      <div className="flex items-center justify-between gap-2 pb-2 border-b border-neutral-800">
        <input
          type="text"
          value={config.content}
          onChange={(e) => onChange({ ...config, content: e.target.value })}
          placeholder="Enter text..."
          className="flex-1 bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-400"
        />
        <button
          onClick={onAddNewText}
          className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-amber-400 text-xs font-bold flex items-center gap-1 shrink-0"
          title="Add another text layer"
        >
          <Plus className="w-4 h-4" />
          <span className="hidden sm:inline">Add</span>
        </button>
      </div>

      {/* Row 1: Font & Formatting */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        <div className="flex items-center gap-1.5">
          <select
            value={config.fontFamily}
            onChange={(e) => onChange({ ...config, fontFamily: e.target.value })}
            className="flex-1 bg-neutral-950 border border-neutral-800 rounded-lg px-2.5 py-1.5 text-xs text-white"
          >
            {fonts.map((f) => (
              <option key={f.family} value={f.family}>
                {f.name}
              </option>
            ))}
          </select>
          <button
            onClick={() => fontUploadRef.current?.click()}
            className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300"
            title="Import custom TTF/WOFF font"
          >
            <Upload className="w-3.5 h-3.5" />
          </button>
          <input
            ref={fontUploadRef}
            type="file"
            accept=".ttf,.woff,.woff2,.otf"
            className="hidden"
            onChange={handleCustomFontUpload}
          />
        </div>

        {/* Alignment, Bold, Italic */}
        <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded-lg border border-neutral-800">
          <button
            onClick={() => onChange({ ...config, bold: !config.bold })}
            className={`p-1.5 rounded ${config.bold ? 'bg-amber-500/20 text-amber-400' : 'text-neutral-400'}`}
          >
            <Bold className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onChange({ ...config, italic: !config.italic })}
            className={`p-1.5 rounded ${config.italic ? 'bg-amber-500/20 text-amber-400' : 'text-neutral-400'}`}
          >
            <Italic className="w-3.5 h-3.5" />
          </button>
          <div className="h-4 w-[1px] bg-neutral-800 mx-1" />
          <button
            onClick={() => onChange({ ...config, alignment: 'left' })}
            className={`p-1.5 rounded ${config.alignment === 'left' ? 'bg-amber-500/20 text-amber-400' : 'text-neutral-400'}`}
          >
            <AlignLeft className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onChange({ ...config, alignment: 'center' })}
            className={`p-1.5 rounded ${config.alignment === 'center' ? 'bg-amber-500/20 text-amber-400' : 'text-neutral-400'}`}
          >
            <AlignCenter className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onChange({ ...config, alignment: 'right' })}
            className={`p-1.5 rounded ${config.alignment === 'right' ? 'bg-amber-500/20 text-amber-400' : 'text-neutral-400'}`}
          >
            <AlignRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Row 2: Colors & Animations */}
      <div className="flex flex-wrap items-center justify-between gap-2 bg-neutral-950/60 p-2.5 rounded-xl border border-neutral-800/80">
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-neutral-400 font-semibold">Color:</span>
          {colorPresets.map((c) => (
            <button
              key={c}
              onClick={() => onChange({ ...config, color: c, gradient: { enabled: false, start: c, end: c, angle: 0 } })}
              className="w-5 h-5 rounded-full border border-neutral-700 transition-transform hover:scale-110"
              style={{ backgroundColor: c }}
            />
          ))}
          <input
            type="color"
            value={config.color}
            onChange={(e) => onChange({ ...config, color: e.target.value })}
            className="w-5 h-5 rounded cursor-pointer bg-transparent border-0 ml-1"
          />
        </div>

        {/* Animation dropdown */}
        <div className="flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span className="text-[10px] text-neutral-400">Motion:</span>
          <select
            value={config.animation}
            onChange={(e) => onChange({ ...config, animation: e.target.value as TextConfig['animation'] })}
            className="bg-neutral-900 border border-neutral-800 rounded px-2 py-1 text-[11px] text-amber-300 font-semibold uppercase"
          >
            {animations.map((a) => (
              <option key={a} value={a}>
                {a}
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
};
