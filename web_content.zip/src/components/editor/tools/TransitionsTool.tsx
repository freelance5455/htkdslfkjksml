import React from 'react';
import { ArrowLeftRight, Clock, Ban } from 'lucide-react';
import { TransitionConfig } from '../../../types/editor';
import { Language, translations } from '../../../i18n/translations';

interface TransitionsToolProps {
  currentTransition?: TransitionConfig;
  onChange: (transition?: TransitionConfig) => void;
  language: Language;
}

export const TransitionsTool: React.FC<TransitionsToolProps> = ({
  currentTransition,
  onChange,
  language,
}) => {
  const t = translations[language];

  const transitionsList: { type: TransitionConfig['type']; label: string }[] = [
    { type: 'dissolve', label: 'Dissolve' },
    { type: 'fade', label: 'Fade to Black' },
    { type: 'zoom-in', label: 'Zoom In' },
    { type: 'zoom-out', label: 'Zoom Out' },
    { type: 'slide-left', label: 'Slide Left' },
    { type: 'slide-right', label: 'Slide Right' },
    { type: 'slide-up', label: 'Slide Up' },
    { type: 'push', label: 'Push' },
    { type: 'wipe', label: 'Wipe Cut' },
    { type: 'blur', label: 'Blur Dissolve' },
    { type: 'spin', label: 'Spin' },
    { type: 'flash', label: 'White Flash' },
    { type: 'glitch', label: 'Digital Glitch' },
  ];

  return (
    <div className="p-3 sm:p-4 text-white space-y-3">
      <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
        <div className="flex items-center gap-2">
          <ArrowLeftRight className="w-4 h-4 text-amber-400" />
          <h4 className="text-xs font-bold uppercase tracking-wider">{t.toolTransitions}</h4>
        </div>
        {currentTransition && currentTransition.type !== 'none' && (
          <div className="flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-neutral-400" />
            <span className="font-mono text-xs text-amber-400 font-bold">
              {currentTransition.duration}s
            </span>
            <input
              type="range"
              min={0.2}
              max={2.0}
              step={0.1}
              value={currentTransition.duration}
              onChange={(e) => onChange({ ...currentTransition, duration: Number(e.target.value) })}
              className="w-20 h-1.5 bg-neutral-800 rounded appearance-none cursor-pointer"
            />
          </div>
        )}
      </div>

      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        <button
          onClick={() => onChange(undefined)}
          className={`flex-shrink-0 w-24 h-20 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all ${
            !currentTransition || currentTransition.type === 'none'
              ? 'border-amber-400 bg-amber-500/15 text-amber-300'
              : 'border-neutral-800 bg-neutral-950/70 text-neutral-400 hover:border-neutral-700'
          }`}
        >
          <Ban className="w-4 h-4" />
          <span className="text-[10px] font-bold">None</span>
        </button>

        {transitionsList.map((tr) => {
          const isSelected = currentTransition?.type === tr.type;
          return (
            <button
              key={tr.type}
              onClick={() => onChange({ type: tr.type, duration: currentTransition?.duration || 0.6 })}
              className={`flex-shrink-0 w-24 h-20 rounded-xl border p-2 flex flex-col items-center justify-center text-center transition-all ${
                isSelected
                  ? 'border-amber-400 bg-amber-500/20 text-white ring-1 ring-amber-400'
                  : 'border-neutral-800 bg-neutral-950/70 text-neutral-400 hover:border-neutral-700'
              }`}
            >
              <ArrowLeftRight className={`w-4 h-4 mb-1 ${isSelected ? 'text-amber-400' : 'text-neutral-500'}`} />
              <span className="text-[10px] font-bold line-clamp-1">{tr.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
