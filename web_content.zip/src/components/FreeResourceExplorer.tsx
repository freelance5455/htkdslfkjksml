import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  BookOpen,
  CheckCircle2,
  Code,
  ExternalLink,
  Film,
  Globe,
  Headphones,
  Info,
  Layers,
  Lock,
  Search,
  Server,
  ShieldCheck,
  Sparkles,
  Terminal,
} from 'lucide-react';
import { api } from '../services/api.ts';
import type { FreeResourceCategory, FreeResourceItem, FreeResourceResult } from '../types.ts';

const CATEGORIES: { key: FreeResourceCategory | 'all'; label: string; icon: React.ReactNode }[] = [
  { key: 'all', label: 'All Resources', icon: <Sparkles className="w-3.5 h-3.5" /> },
  { key: 'ai_tools', label: 'AI Tools', icon: <Terminal className="w-3.5 h-3.5 text-purple-600" /> },
  { key: 'courses', label: 'Courses', icon: <BookOpen className="w-3.5 h-3.5 text-indigo-600" /> },
  { key: 'developer_tools', label: 'Developer Tools', icon: <Code className="w-3.5 h-3.5 text-emerald-600" /> },
  { key: 'hosting', label: 'Free Hosting', icon: <Server className="w-3.5 h-3.5 text-sky-600" /> },
  { key: 'legal_streaming', label: 'Legal Movies & TV', icon: <Film className="w-3.5 h-3.5 text-rose-600" /> },
  { key: 'music', label: 'Free Music & Audio', icon: <Headphones className="w-3.5 h-3.5 text-amber-600" /> },
  { key: 'open_source', label: 'Open Source Software', icon: <Layers className="w-3.5 h-3.5 text-teal-600" /> },
];

export const FreeResourceExplorer: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<FreeResourceCategory | 'all'>('all');
  const [mustBeGenuinelyFree, setMustBeGenuinelyFree] = useState(true);
  const [noCardRequired, setNoCardRequired] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<FreeResourceResult | null>(null);

  const executeSearch = async (queryText = searchQuery, cat = selectedCategory) => {
    setIsLoading(true);
    try {
      const res = await api.discoverFreeResources({
        query: queryText,
        category: cat === 'all' ? undefined : cat,
        mustBeGenuinelyFree,
        noPaymentCardRequired: noCardRequired,
      });
      setResult(res);
    } catch (err) {
      console.error('Free resource discovery failed:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    executeSearch(searchQuery, selectedCategory);
  }, [selectedCategory, mustBeGenuinelyFree, noCardRequired]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    executeSearch(searchQuery, selectedCategory);
  };

  return (
    <div id="free-resource-explorer-pane" className="space-y-5">
      {/* Header Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200">
                <Globe className="w-4 h-4" />
              </span>
              <h2 className="text-base font-bold text-slate-900 tracking-tight">
                Verified Free & Legal Resource Discovery
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-1 max-w-2xl">
              Authentic, copyright-compliant internet resources verified for genuine ₹0 cost.
              Zero piracy, zero paywall bypassing, and zero mandatory credit-card trials.
            </p>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs">
            <span className="px-2.5 py-1 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center gap-1.5 font-semibold">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              100% LEGAL & COPYRIGHT SAFE
            </span>
          </div>
        </div>

        {/* Search Input Bar */}
        <form onSubmit={handleSearchSubmit} className="mt-4 flex flex-col sm:flex-row gap-2.5">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              id="free-resource-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search e.g. 'AI tools', 'Harvard courses', 'movie streaming', 'hosting', 'blender'..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-sky-500 focus:ring-2 focus:ring-sky-100"
            />
          </div>
          <button
            type="submit"
            disabled={isLoading}
            className="px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold uppercase tracking-wider transition-all disabled:opacity-50 shadow-xs"
          >
            {isLoading ? 'Searching...' : 'Search'}
          </button>
        </form>

        {/* Categories Bar */}
        <div className="mt-4 flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.key}
              onClick={() => setSelectedCategory(cat.key)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs whitespace-nowrap transition-all ${
                selectedCategory === cat.key
                  ? 'bg-sky-50 text-sky-900 border border-sky-300 font-bold shadow-xs'
                  : 'bg-slate-50 text-slate-600 border border-slate-200 hover:bg-slate-100 font-medium'
              }`}
            >
              {cat.icon}
              <span>{cat.label}</span>
            </button>
          ))}
        </div>

        {/* Filters */}
        <div className="mt-3.5 pt-3 border-t border-slate-100 flex flex-wrap items-center gap-4 text-xs font-mono text-slate-600">
          <label className="flex items-center gap-2 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={mustBeGenuinelyFree}
              onChange={(e) => setMustBeGenuinelyFree(e.target.checked)}
              className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
            />
            <span>Genuinely ₹0 / Permanently Free Tier</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={noCardRequired}
              onChange={(e) => setNoCardRequired(e.target.checked)}
              className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
            />
            <span>No Credit Card / Payment Required Upfront</span>
          </label>
        </div>
      </div>

      {/* Piracy / Refusal Boundary Banner */}
      {result && !result.legalCompliancePassed && (
        <div className="bg-rose-50 border border-rose-200 rounded-2xl p-5 shadow-xs">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div className="space-y-2">
              <h3 className="text-sm font-bold text-rose-900 font-mono">
                SECURITY & COPYRIGHT BOUNDARY TRIGGERED
              </h3>
              <p className="text-xs text-rose-800 leading-relaxed">
                {result.refusalReason}
              </p>
              {result.suggestedLegalAlternatives && (
                <div className="mt-3 pt-3 border-t border-rose-200/60">
                  <span className="text-[11px] font-mono font-bold text-rose-900 block mb-1.5">
                    VERIFIED LEGAL ALTERNATIVES:
                  </span>
                  <ul className="space-y-1 text-xs text-rose-800 list-disc list-inside">
                    {result.suggestedLegalAlternatives.map((alt, i) => (
                      <li key={i}>{alt}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Discovery Results Grid */}
      {result && result.legalCompliancePassed && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs font-mono text-slate-500 px-1">
            <span>
              SURFACED {result.totalFound} VERIFIED ENTITIES (SEARCH: &quot;{result.query || selectedCategory}&quot;)
            </span>
            <span className="text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              INTEGRITY CONTRACT CONFIRMED
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {result.resources.map((item) => (
              <div
                key={item.id}
                className="bg-white border border-slate-200 hover:border-sky-300 rounded-2xl p-5 shadow-xs flex flex-col justify-between transition-all"
              >
                <div>
                  {/* Top Badges */}
                  <div className="flex items-start justify-between gap-2 mb-2.5">
                    <span className="text-xs font-bold font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-700 uppercase tracking-wide">
                      {item.category.replace('_', ' ')}
                    </span>
                    <span
                      className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded border ${
                        item.pricingModel === 'OPEN_SOURCE'
                          ? 'bg-teal-50 text-teal-800 border-teal-200'
                          : item.pricingModel === 'PERMANENTLY_FREE'
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : 'bg-sky-50 text-sky-800 border-sky-200'
                      }`}
                    >
                      {item.pricingModel}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
                    {item.name}
                  </h3>
                  <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                    {item.description}
                  </p>

                  {/* Access details checklist */}
                  <div className="mt-3.5 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-[11px] font-mono text-slate-600">
                    <div className="flex items-center gap-1.5">
                      <span className={item.access.paymentCardRequired ? 'text-rose-600' : 'text-emerald-600'}>
                        {item.access.paymentCardRequired ? '✕ Card Required' : '✓ No Card Needed'}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-700">
                        {item.access.signupRequired ? 'Account Signup' : 'No Account Needed'}
                      </span>
                    </div>
                    <div className="col-span-2 text-slate-500 truncate" title={item.access.usageLimits}>
                      Limits: {item.access.usageLimits}
                    </div>
                  </div>

                  {item.verificationNote && (
                    <div className="mt-2.5 p-2 rounded-lg bg-slate-50 border border-slate-200 text-[11px] text-slate-600 leading-snug">
                      <span className="font-bold text-slate-700">Verification: </span>
                      {item.verificationNote}
                    </div>
                  )}
                </div>

                {/* Direct Link */}
                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[10px] font-mono text-slate-400">
                    STATUS: {item.currentAvailability}
                  </span>
                  <a
                    href={item.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs font-bold text-sky-600 hover:text-sky-800 hover:underline"
                  >
                    <span>Visit Official Source</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            ))}
          </div>

          {result.totalFound === 0 && (
            <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center text-slate-500 font-mono text-xs">
              No resources found matching the specified query and filters. Try searching for &quot;ai&quot;, &quot;courses&quot;, or &quot;blender&quot;.
            </div>
          )}
        </div>
      )}
    </div>
  );
};
