import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { LeaveRequest, LeaveType } from '../../types';
import {
  Calendar,
  Plus,
  CheckCircle2,
  XCircle,
  Clock,
  UserCheck,
  X,
  FileText,
  AlertCircle,
} from 'lucide-react';

export const LeaveManagerView: React.FC = () => {
  const { leaveRequests, createLeaveRequest, reviewLeaveRequest, currentUser } = useApp();

  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [selectedType, setSelectedType] = useState<LeaveType>('Annual Paid Leave');
  const [startDate, setStartDate] = useState('2026-11-12');
  const [endDate, setEndDate] = useState('2026-11-16');
  const [daysCount, setDaysCount] = useState('4');
  const [reason, setReason] = useState('');
  const [handoverTo, setHandoverTo] = useState('Marcus Holloway');

  const [reviewModalRequest, setReviewModalRequest] = useState<LeaveRequest | null>(null);
  const [reviewComment, setReviewComment] = useState('');

  const handleApplyLeave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) return;

    createLeaveRequest({
      leaveType: selectedType,
      startDate,
      endDate,
      daysCount: parseInt(daysCount, 10) || 1,
      reason: reason.trim(),
      handoverTo,
    });

    setIsApplyModalOpen(false);
    setReason('');
  };

  const handleReviewSubmit = (status: 'approved' | 'rejected') => {
    if (!reviewModalRequest) return;
    reviewLeaveRequest(reviewModalRequest.id, status, reviewComment);
    setReviewModalRequest(null);
    setReviewComment('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Staff Leave Management & Approval Portal
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Submit automated leave requisitions, track remaining paid balances, and process administrative approvals.
          </p>
        </div>

        <button
          onClick={() => setIsApplyModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-xs"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Apply for Leave</span>
        </button>
      </div>

      {/* Leave Balance Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
            Annual Paid Leave
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
            14 <span className="text-xs font-normal text-slate-500">/ 20 days remaining</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">6 days utilized this academic year</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
            Sick & Medical Leave
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-700 mt-1 tabular-nums">
            8 <span className="text-xs font-normal text-slate-500">/ 10 days remaining</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Doctor certificate required for &gt;2 days</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
            Casual Emergency Leave
          </div>
          <div className="text-2xl font-bold font-mono text-amber-700 mt-1 tabular-nums">
            4 <span className="text-xs font-normal text-slate-500">/ 5 days remaining</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Single-day urgent personal matters</div>
        </div>
      </div>

      {/* Leave Requests Queue Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900">
            Staff Leave Requisitions & Approvals
          </h2>
          <span className="text-xs text-slate-500 font-mono">
            {leaveRequests.filter((l) => l.status === 'pending').length} pending action
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Employee</th>
                <th className="py-3 px-4">Leave Type</th>
                <th className="py-3 px-4">Duration & Dates</th>
                <th className="py-3 px-4">Reason & Handover</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Approval Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {leaveRequests.map((req) => (
                <tr key={req.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3.5 px-4 font-semibold text-slate-900">
                    {req.employeeName}
                    <div className="text-[11px] text-slate-400">{req.department}</div>
                  </td>
                  <td className="py-3.5 px-4 text-slate-700 font-medium">
                    {req.leaveType}
                  </td>
                  <td className="py-3.5 px-4 font-mono text-slate-700">
                    <div className="font-semibold">{req.daysCount} days</div>
                    <div className="text-[11px] text-slate-400">{req.startDate} to {req.endDate}</div>
                  </td>
                  <td className="py-3.5 px-4 max-w-xs text-slate-600">
                    <p className="line-clamp-1">{req.reason}</p>
                    <div className="text-[11px] text-slate-400">
                      Handover: <span className="text-slate-700 font-medium">{req.handoverTo}</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-center font-medium">
                    {req.status === 'pending' && (
                      <span className="text-amber-700">Pending Review</span>
                    )}
                    {req.status === 'approved' && (
                      <span className="text-emerald-700">Approved</span>
                    )}
                    {req.status === 'rejected' && (
                      <span className="text-red-700">Declined</span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    {req.status === 'pending' ? (
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => {
                            setReviewModalRequest(req);
                            setReviewComment('Request approved for academic schedule coverage.');
                          }}
                          className="px-2.5 py-1 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors"
                        >
                          Review
                        </button>
                      </div>
                    ) : (
                      <div className="text-[11px] text-slate-400 font-mono">
                        by {req.reviewedBy?.split(' ')[0]}
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* APPLY FOR LEAVE MODAL */}
      {isApplyModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h2 className="text-base font-bold text-slate-900">Submit Leave Requisition</h2>
              <button
                onClick={() => setIsApplyModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleApplyLeave} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Leave Category</label>
                <select
                  value={selectedType}
                  onChange={(e) => setSelectedType(e.target.value as LeaveType)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500 bg-white"
                >
                  <option value="Annual Paid Leave">Annual Paid Leave</option>
                  <option value="Sick / Medical Leave">Sick / Medical Leave</option>
                  <option value="Casual Emergency Leave">Casual Emergency Leave</option>
                  <option value="Academic Research Leave">Academic Research Leave</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Start Date</label>
                  <input
                    type="date"
                    required
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">End Date</label>
                  <input
                    type="date"
                    required
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Total Days</label>
                  <input
                    type="number"
                    min={1}
                    max={30}
                    required
                    value={daysCount}
                    onChange={(e) => setDaysCount(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Handover Colleague</label>
                  <input
                    type="text"
                    required
                    value={handoverTo}
                    onChange={(e) => setHandoverTo(e.target.value)}
                    placeholder="e.g. Prof. Arthur Pendelton"
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Reason for Leave Request</label>
                <textarea
                  rows={3}
                  required
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Provide context regarding research paper, medical appointment, or personal arrangements..."
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500 resize-none leading-relaxed"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsApplyModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold transition-colors shadow-xs"
                >
                  Submit Requisition
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* REVIEW LEAVE MODAL */}
      {reviewModalRequest && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h2 className="text-base font-bold text-slate-900">Review Leave Application</h2>
              <button
                onClick={() => setReviewModalRequest(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs mb-4">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="font-bold text-slate-900">{reviewModalRequest.employeeName}</div>
                <div className="text-slate-600">{reviewModalRequest.department} · {reviewModalRequest.leaveType}</div>
                <div className="font-mono text-slate-500 mt-1">
                  {reviewModalRequest.daysCount} days ({reviewModalRequest.startDate} to {reviewModalRequest.endDate})
                </div>
                <p className="mt-2 text-slate-700 italic bg-white p-2 rounded border border-slate-200">
                  "{reviewModalRequest.reason}"
                </p>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Administrative Remarks / Review Comment</label>
                <textarea
                  rows={2}
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  placeholder="e.g. Approved. Department teaching roster adjusted."
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500 resize-none"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                onClick={() => handleReviewSubmit('rejected')}
                className="px-3.5 py-2 text-red-700 hover:bg-red-50 border border-red-200 rounded-lg font-semibold transition-colors"
              >
                Decline Request
              </button>
              <button
                onClick={() => handleReviewSubmit('approved')}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold transition-colors shadow-xs"
              >
                Approve Requisition
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
