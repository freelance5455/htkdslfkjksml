import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TaskItem, TaskStatus, TaskPriority } from '../../types';
import {
  CheckSquare,
  Plus,
  Calendar,
  AlertCircle,
  Clock,
  Filter,
  CheckCircle2,
  X,
  User,
  ArrowRight,
  List,
  Columns3,
} from 'lucide-react';

export const TaskManagerView: React.FC = () => {
  const { tasks, createTask, updateTaskStatus, toggleSubtask, availableUsers } = useApp();

  const [viewMode, setViewMode] = useState<'kanban' | 'table'>('kanban');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  // Form states
  const [title, setTitle] = useState('');
  const [project, setProject] = useState('Campus Procurement 2026');
  const [assigneeName, setAssigneeName] = useState(availableUsers[0].name);
  const [priority, setPriority] = useState<TaskPriority>('medium');
  const [dueDate, setDueDate] = useState('2026-11-05');
  const [description, setDescription] = useState('');
  const [tagInput, setTagInput] = useState('Operations');

  const filteredTasks = tasks.filter((t) => {
    return selectedPriority === 'all' || t.priority === selectedPriority;
  });

  const columns: { id: TaskStatus; label: string }[] = [
    { id: 'todo', label: 'To Do' },
    { id: 'in_progress', label: 'In Progress' },
    { id: 'in_review', label: 'Under Review' },
    { id: 'done', label: 'Completed' },
  ];

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    createTask({
      title: title.trim(),
      project,
      assigneeName,
      priority,
      dueDate,
      description: description.trim() || 'Coordinate task deliverables and review milestones.',
      tags: tagInput.split(',').map((t) => t.trim()).filter(Boolean),
    });

    setIsCreateModalOpen(false);
    setTitle('');
    setDescription('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Task & Project Delegation
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Assign deliverables to faculty and administrative team members, monitor sprint deadlines, and track subtask checklists.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Segmented Kanban vs Table switch */}
          <div className="flex items-center p-1 bg-slate-100 rounded-lg">
            <button
              onClick={() => setViewMode('kanban')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5 ${
                viewMode === 'kanban'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Columns3 className="w-3.5 h-3.5" />
              <span>Kanban</span>
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5 ${
                viewMode === 'table'
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>Table</span>
            </button>
          </div>

          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Delegate Task</span>
          </button>
        </div>
      </div>

      {/* Filter strip */}
      <div className="flex items-center gap-2 text-xs">
        <span className="text-slate-400 font-medium">Priority Filter:</span>
        {['all', 'high', 'medium', 'low'].map((p) => (
          <button
            key={p}
            onClick={() => setSelectedPriority(p)}
            className={`px-3 py-1 rounded-md font-medium capitalize transition-colors ${
              selectedPriority === p
                ? 'bg-slate-900 text-white'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            {p}
          </button>
        ))}
      </div>

      {/* VIEW 1: KANBAN BOARD */}
      {viewMode === 'kanban' && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5">
          {columns.map((col) => {
            const colTasks = filteredTasks.filter((t) => t.status === col.id);
            return (
              <div key={col.id} className="bg-slate-100/70 rounded-xl p-3.5 border border-slate-200/80 flex flex-col">
                <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">{col.label}</span>
                    <span className="bg-white border border-slate-200 text-slate-600 text-[11px] font-mono px-2 py-0.2 rounded-full font-semibold">
                      {colTasks.length}
                    </span>
                  </div>
                </div>

                <div className="space-y-3 flex-1 overflow-y-auto">
                  {colTasks.length === 0 ? (
                    <div className="py-8 text-center text-[11px] text-slate-400 border border-dashed border-slate-200 rounded-lg bg-white/50">
                      No tasks in this lane
                    </div>
                  ) : (
                    colTasks.map((task) => {
                      const completedCount = task.subtasks.filter((s) => s.completed).length;
                      return (
                        <div
                          key={task.id}
                          className="bg-white p-4 rounded-xl border border-slate-200 hover:border-indigo-300 transition-all shadow-2xs space-y-3"
                        >
                          <div>
                            <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                              <span className="font-medium text-slate-500 truncate max-w-[130px]">
                                {task.project}
                              </span>
                              <span
                                className={`font-semibold capitalize text-[10px] ${
                                  task.priority === 'high'
                                    ? 'text-red-700'
                                    : task.priority === 'medium'
                                    ? 'text-amber-700'
                                    : 'text-slate-600'
                                }`}
                              >
                                {task.priority} Priority
                              </span>
                            </div>

                            <h4 className="text-xs font-bold text-slate-900 leading-snug">
                              {task.title}
                            </h4>
                            <p className="text-[11px] text-slate-600 mt-1 line-clamp-2 leading-relaxed">
                              {task.description}
                            </p>
                          </div>

                          {/* Subtasks Checklist */}
                          {task.subtasks.length > 0 && (
                            <div className="pt-2 border-t border-slate-100 space-y-1.5">
                              <div className="flex justify-between items-center text-[10px] text-slate-400 font-semibold uppercase">
                                <span>Subtasks</span>
                                <span className="font-mono">{completedCount}/{task.subtasks.length}</span>
                              </div>
                              {task.subtasks.map((st) => (
                                <button
                                  type="button"
                                  key={st.id}
                                  onClick={() => toggleSubtask(task.id, st.id)}
                                  className="w-full flex items-start gap-2 text-[11px] text-left hover:bg-slate-50 p-1 rounded transition-colors"
                                >
                                  <input
                                    type="checkbox"
                                    checked={st.completed}
                                    readOnly
                                    className="mt-0.5 rounded text-indigo-600 focus:ring-0"
                                  />
                                  <span
                                    className={`leading-tight ${
                                      st.completed ? 'line-through text-slate-400' : 'text-slate-700'
                                    }`}
                                  >
                                    {st.title}
                                  </span>
                                </button>
                              ))}
                            </div>
                          )}

                          {/* Footer with Assignee & Deadline */}
                          <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                            <div className="flex items-center gap-1.5 truncate max-w-[140px]">
                              <img
                                src={task.assignee.avatar}
                                alt={task.assignee.name}
                                referrerPolicy="no-referrer"
                                className="w-5 h-5 rounded-full object-cover border border-slate-200"
                              />
                              <span className="text-[11px] text-slate-700 font-medium truncate">
                                {task.assignee.name}
                              </span>
                            </div>

                            <div className="text-[10px] font-mono text-slate-400">
                              Due {task.dueDate.slice(5)}
                            </div>
                          </div>

                          {/* Move lane action */}
                          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
                            <span className="text-slate-400 font-medium">Move lane:</span>
                            <div className="flex gap-1">
                              {columns.map((c) => {
                                if (c.id === task.status) return null;
                                return (
                                  <button
                                    key={c.id}
                                    onClick={() => updateTaskStatus(task.id, c.id)}
                                    className="px-2 py-0.5 text-[10px] bg-slate-100 hover:bg-slate-200 text-slate-700 rounded transition-colors"
                                  >
                                    {c.label.slice(0, 4)}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* VIEW 2: DENSE TABLE */}
      {viewMode === 'table' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Task Deliverable</th>
                <th className="py-3 px-4">Project</th>
                <th className="py-3 px-4">Assignee</th>
                <th className="py-3 px-4 text-center">Priority</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Deadline</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTasks.map((t) => (
                <tr key={t.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3.5 px-4 font-semibold text-slate-900">{t.title}</td>
                  <td className="py-3.5 px-4 text-slate-600">{t.project}</td>
                  <td className="py-3.5 px-4 flex items-center gap-2">
                    <img
                      src={t.assignee.avatar}
                      alt={t.assignee.name}
                      referrerPolicy="no-referrer"
                      className="w-5 h-5 rounded-full object-cover"
                    />
                    <span className="text-slate-800 font-medium">{t.assignee.name}</span>
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <span
                      className={`capitalize font-semibold text-[11px] ${
                        t.priority === 'high'
                          ? 'text-red-700'
                          : t.priority === 'medium'
                          ? 'text-amber-700'
                          : 'text-slate-600'
                      }`}
                    >
                      {t.priority}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <select
                      value={t.status}
                      onChange={(e) => updateTaskStatus(t.id, e.target.value as TaskStatus)}
                      className="bg-slate-100 border border-slate-200 rounded px-2 py-0.5 text-xs font-semibold text-slate-700"
                    >
                      <option value="todo">To Do</option>
                      <option value="in_progress">In Progress</option>
                      <option value="in_review">In Review</option>
                      <option value="done">Done</option>
                    </select>
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono text-slate-500">
                    {t.dueDate}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* CREATE TASK MODAL */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h2 className="text-base font-bold text-slate-900">Delegate Project Task</h2>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateTask} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Task Title</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Conduct annual lab hardware safety certification"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Project Name</label>
                  <input
                    type="text"
                    required
                    value={project}
                    onChange={(e) => setProject(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Assignee</label>
                  <select
                    value={assigneeName}
                    onChange={(e) => setAssigneeName(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500 bg-white"
                  >
                    {availableUsers.map((u) => (
                      <option key={u.id} value={u.name}>
                        {u.name} ({u.title})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Priority</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as TaskPriority)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500 bg-white"
                  >
                    <option value="high">High Priority</option>
                    <option value="medium">Medium Priority</option>
                    <option value="low">Low Priority</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Due Date</label>
                  <input
                    type="date"
                    required
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tags (comma separated)</label>
                <input
                  type="text"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  placeholder="Compliance, STEM, Logistics"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Description & Scope</label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Clarify deliverable acceptance criteria..."
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500 resize-none"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold transition-colors shadow-xs"
                >
                  Create Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
