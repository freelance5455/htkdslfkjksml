import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Clock,
  LogIn,
  LogOut,
  Calendar,
  CheckCircle2,
  Building,
  ShieldCheck,
  TrendingUp,
} from 'lucide-react';

export const StaffAttendanceView: React.FC = () => {
  const { punchLogs, isOnDuty, clockInTime, punchIn, punchOut, currentUser } = useApp();

  const [currentTime, setCurrentTime] = useState<string>('');
  const [currentDateStr, setCurrentDateStr] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      setCurrentDateStr(
        now.toLocaleDateString(undefined, {
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric',
        })
      );
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Staff Attendance & Biometric Punch Clock
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Real-time shift clock-in and clock-out logs, on-duty time tracking, and campus gateway authentication.
          </p>
        </div>
      </div>

      {/* Hero Punch Card & Live Clock */}
      <div className="bg-gradient-to-r from-slate-900 to-indigo-950 text-white rounded-2xl p-6 sm:p-8 shadow-md border border-slate-800">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Live Clock Display */}
          <div className="text-center md:text-left">
            <div className="text-xs font-semibold uppercase tracking-widest text-indigo-300">
              Campus Time & Workstation Punch
            </div>
            <div className="text-3xl sm:text-4xl font-mono font-bold tracking-tight mt-1 text-white tabular-nums">
              {currentTime || '08:23:45 AM'}
            </div>
            <div className="text-xs text-slate-300 mt-1 font-medium">{currentDateStr}</div>

            {/* Current Employee Status */}
            <div className="mt-4 inline-flex items-center gap-2 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700 text-xs">
              <span className={`w-2.5 h-2.5 rounded-full ${isOnDuty ? 'bg-emerald-400 animate-pulse' : 'bg-slate-400'}`} />
              <span className="font-semibold">{currentUser.name}</span>
              <span className="text-slate-400">·</span>
              <span className={isOnDuty ? 'text-emerald-300 font-medium' : 'text-slate-400'}>
                {isOnDuty ? `Active Shift (Clocked in at ${clockInTime})` : 'Currently Off-Duty'}
              </span>
            </div>
          </div>

          {/* Punch Button */}
          <div>
            {isOnDuty ? (
              <button
                onClick={punchOut}
                className="px-6 py-3.5 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold text-sm flex items-center gap-2 transition-all shadow-lg hover:shadow-red-900/30 active:scale-98"
              >
                <LogOut className="w-5 h-5" />
                <span>Punch Out & End Shift</span>
              </button>
            ) : (
              <button
                onClick={punchIn}
                className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-sm flex items-center gap-2 transition-all shadow-lg hover:shadow-emerald-900/30 active:scale-98"
              >
                <LogIn className="w-5 h-5" />
                <span>Punch In & Start Duty</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Staff Punch Logs Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900">
            Staff Daily Punch Ledger & Biometric Audit Trail
          </h2>
          <span className="text-xs text-slate-500 font-mono">
            {punchLogs.length} audit entries
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Staff Member</th>
                <th className="py-3 px-4">Department</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4 font-mono text-center">Clock In</th>
                <th className="py-3 px-4 font-mono text-center">Clock Out</th>
                <th className="py-3 px-4 font-mono text-center">Logged Hours</th>
                <th className="py-3 px-4 text-right">Shift State</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {punchLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3.5 px-4 font-semibold text-slate-900">
                    {log.employeeName}
                    <div className="text-[11px] text-slate-400 font-mono">{log.employeeId}</div>
                  </td>
                  <td className="py-3.5 px-4 text-slate-600">{log.department}</td>
                  <td className="py-3.5 px-4 font-mono text-slate-600">{log.date}</td>
                  <td className="py-3.5 px-4 font-mono font-medium text-slate-900 text-center">
                    {log.clockIn}
                  </td>
                  <td className="py-3.5 px-4 font-mono text-slate-600 text-center">
                    {log.clockOut || '—'}
                  </td>
                  <td className="py-3.5 px-4 font-mono font-bold text-slate-800 text-center tabular-nums">
                    {log.totalHours ? `${log.totalHours.toFixed(1)} hrs` : 'In Progress'}
                  </td>
                  <td className="py-3.5 px-4 text-right font-medium">
                    {log.status === 'on_duty' && (
                      <span className="text-emerald-700">Active On-Duty</span>
                    )}
                    {log.status === 'completed' && (
                      <span className="text-slate-600">Completed Shift</span>
                    )}
                    {log.status === 'overtime' && (
                      <span className="text-indigo-700">Overtime Logged</span>
                    )}
                    {log.status === 'late_arrival' && (
                      <span className="text-amber-700">Late Arrival</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
