import React, { useState } from 'react';
import {
  Brain,
  Database,
  Layers,
  Plus,
  Search,
  Star,
  Tag,
  Trash2,
} from 'lucide-react';
import { MemoryEntry } from '../types.ts';

interface MemoryExplorerProps {
  memories: MemoryEntry[];
  onSaveMemory: (entry: { key: string; content: string; type: string; importance: number; tags: string[] }) => Promise<void>;
  onDeleteMemory: (id: string) => Promise<void>;
}

export const MemoryExplorer: React.FC<MemoryExplorerProps> = ({
  memories,
  onSaveMemory,
  onDeleteMemory,
}) => {
  const [filterType, setFilterType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  // New Memory Form State
  const [newKey, setNewKey] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newType, setNewType] = useState('knowledge');
  const [newImportance, setNewImportance] = useState(7);
  const [newTags, setNewTags] = useState('system, manual');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const filteredMemories = memories.filter((mem) => {
    if (filterType !== 'all' && mem.type !== filterType) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        mem.key.toLowerCase().includes(q) ||
        mem.content.toLowerCase().includes(q) ||
        mem.tags.some((t) => t.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKey.trim() || !newContent.trim()) return;
    setIsSubmitting(true);
    try {
      const tagList = newTags
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean);
      await onSaveMemory({
        key: newKey.trim(),
        content: newContent.trim(),
        type: newType,
        importance: Number(newImportance),
        tags: tagList,
      });
      setNewKey('');
      setNewContent('');
      setIsAdding(false);
    } catch (err) {
      console.error('Failed to create memory:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div id="memory-explorer-panel" className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white border border-slate-200 p-5 rounded-2xl shadow-xs">
        <div>
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2 font-sans">
            <Database className="w-5 h-5 text-sky-600" />
            JARVIS Memory System
          </h2>
          <p className="text-xs text-slate-600 font-mono mt-0.5">
            Hierarchical memory supporting short-term conversation, persistent context, task history, and knowledge vectors.
          </p>
        </div>

        <button
          onClick={() => setIsAdding(true)}
          className="px-4 py-2.5 rounded-xl bg-sky-700 hover:bg-sky-800 text-white text-xs font-mono font-semibold flex items-center gap-2 transition-all shadow-xs"
        >
          <Plus className="w-3.5 h-3.5" />
          STORE NEW MEMORY
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white border border-slate-200 p-3.5 rounded-xl font-mono text-xs shadow-xs">
        {/* Type Filter Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto">
          {['all', 'long_term', 'knowledge', 'short_term', 'task_history'].map((t) => (
            <button
              key={t}
              onClick={() => setFilterType(t)}
              className={`px-3 py-1.5 rounded-lg uppercase text-[11px] transition-all font-semibold ${
                filterType === t
                  ? 'bg-sky-50 text-sky-900 border border-sky-300 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {t.replace('_', ' ')}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search memories..."
            className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 text-xs focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500/30 transition-all placeholder:text-slate-400"
          />
        </div>
      </div>

      {/* Memories Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredMemories.map((mem) => (
          <div
            key={mem.id}
            className="bg-white border border-slate-200 rounded-2xl p-5 flex flex-col justify-between hover:border-sky-300 hover:shadow-xs transition-all"
          >
            <div>
              <div className="flex items-start justify-between gap-2 mb-2">
                <span className="font-mono text-xs font-bold text-slate-900 truncate pr-2">
                  {mem.key}
                </span>
                <span className="px-2.5 py-1 rounded-md bg-slate-50 border border-slate-200 text-[10px] font-mono text-sky-800 uppercase font-semibold">
                  {mem.type.replace('_', ' ')}
                </span>
              </div>

              <p className="text-xs text-slate-700 leading-relaxed font-sans mb-3.5">{mem.content}</p>

              {/* Tags */}
              <div className="flex flex-wrap items-center gap-1.5 mb-3.5">
                {mem.tags.map((t, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded-md bg-slate-50 text-slate-600 border border-slate-200 text-[10px] font-mono font-medium"
                  >
                    #{t}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] font-mono text-slate-500">
              <span className="flex items-center gap-1.5 text-amber-700 font-semibold">
                <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                Weight: {mem.importance}/10
              </span>

              <button
                onClick={() => onDeleteMemory(mem.id)}
                title="Delete memory"
                className="p-1.5 rounded-md hover:bg-rose-50 hover:text-rose-600 text-slate-400 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add Memory Modal */}
      {isAdding && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-md w-full p-6 shadow-xl space-y-4 font-mono text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 font-sans">
                <Database className="w-4 h-4 text-sky-600" />
                Store Knowledge Memory
              </h3>
              <button
                onClick={() => setIsAdding(false)}
                className="text-slate-400 hover:text-slate-700 px-2 py-1 rounded-lg hover:bg-slate-100 transition-colors"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreate} className="space-y-3.5 font-sans text-xs">
              <div>
                <label className="block text-[11px] font-mono text-slate-600 mb-1.5 font-bold">Memory Key / Identifier:</label>
                <input
                  type="text"
                  required
                  value={newKey}
                  onChange={(e) => setNewKey(e.target.value)}
                  placeholder="e.g. operator_preferences"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-mono text-xs focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500/30"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono text-slate-600 mb-1.5 font-bold">Content / Document Data:</label>
                <textarea
                  rows={4}
                  required
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  placeholder="Enter context, rules, or insights..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 text-xs focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500/30"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-mono text-slate-600 mb-1.5 font-bold">Memory Type:</label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value)}
                    className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-mono text-xs focus:outline-none focus:border-sky-500"
                  >
                    <option value="knowledge">Knowledge</option>
                    <option value="long_term">Long-Term</option>
                    <option value="short_term">Short-Term</option>
                    <option value="task_history">Task History</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-mono text-slate-600 mb-1.5 font-bold">Importance (1-10):</label>
                  <input
                    type="number"
                    min={1}
                    max={10}
                    value={newImportance}
                    onChange={(e) => setNewImportance(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-mono text-xs focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-mono text-slate-600 mb-1.5 font-bold">Tags (comma separated):</label>
                <input
                  type="text"
                  value={newTags}
                  onChange={(e) => setNewTags(e.target.value)}
                  placeholder="policy, security, general"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-mono text-xs focus:outline-none focus:border-sky-500"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2.5 font-mono">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-3.5 py-2 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 rounded-lg bg-sky-700 hover:bg-sky-800 text-white font-bold transition-all shadow-xs disabled:opacity-50"
                >
                  {isSubmitting ? 'Saving...' : 'Save to Memory'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
