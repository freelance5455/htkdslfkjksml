import React, { useState } from 'react';
import { 
  X, 
  Sparkles, 
  Mic, 
  Save, 
  Play, 
  Volume2, 
  Zap, 
  Sliders, 
  Check, 
  Globe2 
} from 'lucide-react';
import { CustomVoice, Language, PersonaId, VoiceSettings } from '../types/tts';
import { SUPPORTED_LANGUAGES } from '../constants/languages';
import { VOICE_PERSONAS } from '../constants/personas';
import { offlineAudioEngine } from '../utils/offlineAudioSynth';

interface CustomVoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveVoice: (voice: Omit<CustomVoice, 'id' | 'userId' | 'createdAt'>) => void;
  initialLanguage?: Language;
}

export const CustomVoiceModal: React.FC<CustomVoiceModalProps> = ({
  isOpen,
  onClose,
  onSaveVoice,
  initialLanguage,
}) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [basePersona, setBasePersona] = useState<PersonaId>('female');
  const [languageCode, setLanguageCode] = useState(initialLanguage?.code || 'ta-IN');
  const [speed, setSpeed] = useState(1.0);
  const [pitch, setPitch] = useState(0);
  const [stability, setStability] = useState(80);
  const [clarity, setClarity] = useState(90);
  const [effects, setEffects] = useState<VoiceSettings['effects']>({
    alienModulation: false,
    arenaEcho: false,
    subBassPunch: false,
    whisperFilter: false,
    sodaSparkle: false,
  });
  const [sampleText, setSampleText] = useState('வணக்கம்! இது எனது புதிய தனிப்பயனாக்கப்பட்ட குரல் வடிவம்.');
  const [isPlayingPreview, setIsPlayingPreview] = useState(false);

  if (!isOpen) return null;

  const handleTestPreview = () => {
    setIsPlayingPreview(true);
    offlineAudioEngine.speak(
      sampleText || 'Testing custom voice tuning.',
      languageCode,
      basePersona,
      {
        speed,
        pitch,
        stability,
        clarity,
        effects,
      },
      () => setIsPlayingPreview(true),
      () => setIsPlayingPreview(false),
      () => setIsPlayingPreview(false)
    );
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onSaveVoice({
      name: name.trim(),
      description: description.trim() || 'Custom tuned voice model',
      basePersona,
      languageCode,
      speed,
      pitch,
      stability,
      clarity,
      effects,
      sampleText,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-md animate-in fade-in overflow-y-auto">
      <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl max-w-xl w-full p-6 shadow-2xl relative space-y-5 animate-in zoom-in-95 my-auto max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-violet-600/10 text-violet-600 dark:text-violet-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-zinc-900 dark:text-white">
                Create Custom Voice Model
              </h3>
              <p className="text-xs text-zinc-500 dark:text-zinc-400">
                Tune timbre, acoustics, speed and pitch into a reusable persona
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSave} className="space-y-4">
          {/* Voice Name & Tagline */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                Custom Voice Name *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Tamil Bedtime Storyteller"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-zinc-900 dark:text-white"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
                Language
              </label>
              <select
                value={languageCode}
                onChange={(e) => setLanguageCode(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-zinc-900 dark:text-white"
              >
                {SUPPORTED_LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code}>
                    {l.flag} {l.name} ({l.nativeName})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 block mb-1">
              Description &amp; Intended Use
            </label>
            <input
              type="text"
              placeholder="e.g. Gentle motherly voice for bedtime stories and lullabies"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-zinc-900 dark:text-white"
            />
          </div>

          {/* Base Persona selector */}
          <div>
            <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 block mb-1.5">
              Base Vocal Foundation
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {VOICE_PERSONAS.map((p) => {
                const isSoda = p.id === 'soda';
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => {
                      setBasePersona(p.id);
                      if (isSoda) {
                        setSpeed(1.15);
                        setPitch(4);
                        setEffects((prev) => ({ ...prev, sodaSparkle: true }));
                      }
                    }}
                    className={`p-2 rounded-xl text-left border text-xs transition-all relative ${
                      basePersona === p.id
                        ? isSoda
                          ? 'border-amber-500 bg-amber-500/10 text-amber-600 dark:text-amber-300 font-bold ring-1 ring-amber-500'
                          : 'border-violet-500 bg-violet-50 dark:bg-violet-950/40 text-violet-700 dark:text-violet-300 font-bold'
                        : 'border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400'
                    }`}
                  >
                    <div className="truncate flex items-center gap-1">
                      {isSoda ? '🥤 Soda Pop' : p.name.split(' ')[0]}
                    </div>
                    <div className="text-[10px] text-zinc-400 font-normal capitalize">
                      {isSoda ? 'Fizzy Pop' : p.gender}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Tuning Sliders */}
          <div className="p-4 bg-zinc-50 dark:bg-zinc-950/60 rounded-2xl border border-zinc-200 dark:border-zinc-800 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <div className="flex justify-between text-[11px] font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  <span>Speed Multiplier</span>
                  <span className="font-mono text-violet-500">{speed.toFixed(2)}x</span>
                </div>
                <input
                  type="range"
                  min="0.4"
                  max="2.5"
                  step="0.05"
                  value={speed}
                  onChange={(e) => setSpeed(parseFloat(e.target.value))}
                  className="w-full accent-violet-600 h-1.5 bg-zinc-200 dark:bg-zinc-700 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  <span>Pitch Tuning</span>
                  <span className="font-mono text-cyan-500">{pitch > 0 ? `+${pitch}` : pitch} st</span>
                </div>
                <input
                  type="range"
                  min="-10"
                  max="10"
                  step="1"
                  value={pitch}
                  onChange={(e) => setPitch(parseInt(e.target.value, 10))}
                  className="w-full accent-cyan-600 h-1.5 bg-zinc-200 dark:bg-zinc-700 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  <span>Stability</span>
                  <span>{stability}%</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="100"
                  value={stability}
                  onChange={(e) => setStability(parseInt(e.target.value, 10))}
                  className="w-full accent-violet-600 h-1.5 bg-zinc-200 dark:bg-zinc-700 rounded-lg cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] font-semibold text-zinc-600 dark:text-zinc-400 mb-1">
                  <span>Clarity &amp; Presence</span>
                  <span>{clarity}%</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="100"
                  value={clarity}
                  onChange={(e) => setClarity(parseInt(e.target.value, 10))}
                  className="w-full accent-violet-600 h-1.5 bg-zinc-200 dark:bg-zinc-700 rounded-lg cursor-pointer"
                />
              </div>
            </div>

            {/* DSP Effects checkboxes */}
            <div className="pt-2 border-t border-zinc-200 dark:border-zinc-800 grid grid-cols-2 sm:grid-cols-5 gap-2">
              <label className="flex items-center gap-1.5 text-xs text-amber-600 dark:text-amber-400 font-semibold cursor-pointer">
                <input
                  type="checkbox"
                  checked={effects.sodaSparkle || false}
                  onChange={(e) => setEffects({ ...effects, sodaSparkle: e.target.checked })}
                  className="accent-amber-500 rounded"
                />
                <span>🥤 Soda Sparkle</span>
              </label>

              <label className="flex items-center gap-1.5 text-xs text-zinc-600 dark:text-zinc-400 cursor-pointer">
                <input
                  type="checkbox"
                  checked={effects.alienModulation}
                  onChange={(e) => setEffects({ ...effects, alienModulation: e.target.checked })}
                  className="accent-violet-600 rounded"
                />
                <span>Alien Ring Mod</span>
              </label>

              <label className="flex items-center gap-1.5 text-xs text-zinc-600 dark:text-zinc-400 cursor-pointer">
                <input
                  type="checkbox"
                  checked={effects.subBassPunch}
                  onChange={(e) => setEffects({ ...effects, subBassPunch: e.target.checked })}
                  className="accent-violet-600 rounded"
                />
                <span>Sub-Bass Rumble</span>
              </label>

              <label className="flex items-center gap-1.5 text-xs text-zinc-600 dark:text-zinc-400 cursor-pointer">
                <input
                  type="checkbox"
                  checked={effects.arenaEcho}
                  onChange={(e) => setEffects({ ...effects, arenaEcho: e.target.checked })}
                  className="accent-violet-600 rounded"
                />
                <span>Arena Echo</span>
              </label>

              <label className="flex items-center gap-1.5 text-xs text-zinc-600 dark:text-zinc-400 cursor-pointer">
                <input
                  type="checkbox"
                  checked={effects.whisperFilter}
                  onChange={(e) => setEffects({ ...effects, whisperFilter: e.target.checked })}
                  className="accent-violet-600 rounded"
                />
                <span>Whisper Filter</span>
              </label>
            </div>
          </div>

          {/* Test Voice Preview Bar */}
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={sampleText}
              onChange={(e) => setSampleText(e.target.value)}
              placeholder="Type test text..."
              className="flex-1 px-3 py-2 text-xs bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 rounded-xl text-zinc-900 dark:text-white"
            />
            <button
              type="button"
              onClick={handleTestPreview}
              disabled={isPlayingPreview}
              className="px-3 py-2 rounded-xl text-xs font-bold bg-zinc-200 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 hover:bg-zinc-300 dark:hover:bg-zinc-700 flex items-center gap-1.5 shrink-0"
            >
              <Play className="w-3.5 h-3.5" />
              <span>{isPlayingPreview ? 'Playing...' : 'Test Voice'}</span>
            </button>
          </div>

          {/* Submit */}
          <div className="flex justify-end gap-2 pt-2 border-t border-zinc-200 dark:border-zinc-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-xl"
            >
              Cancel
            </button>

            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold bg-violet-600 hover:bg-violet-500 text-white rounded-xl shadow-md shadow-violet-600/30 flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Custom Voice</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
