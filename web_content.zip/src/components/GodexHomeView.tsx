import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  ShieldCheck, 
  Code2, 
  Layers, 
  Play, 
  CheckCircle2, 
  AlertTriangle,
  RefreshCw,
  Cpu,
  Boxes,
  Zap,
  Activity,
  FileCode,
  Search,
  ExternalLink,
  ShieldAlert,
  Users,
  GitBranch,
  Terminal,
  Compass,
  ArrowRight,
  Eye,
  Plus,
  FolderArchive,
  RotateCcw,
  Bug,
  Smartphone,
  Tablet,
  Monitor,
  Check,
  Maximize2
} from 'lucide-react';
import { 
  ProjectTemplate, 
  WorkspaceViewMode, 
  VerificationReport, 
  TaskState,
  AICenterTab,
  ActivityLogItem
} from '../types';
import { Godex3DGlyph } from './Godex3DGlyph';
import { ProjectIntelligence } from '../intelligence/intelligenceEngine';
import { ProjectIntelligenceState } from '../intelligence/types';

interface GodexHomeViewProps {
  currentProjectTitle: string;
  files: Record<string, string>;
  taskState: TaskState;
  verificationReport: VerificationReport | null;
  activityLogs: ActivityLogItem[];
  onSelectWorkspaceView: (view: WorkspaceViewMode) => void;
  onSelectAiTab?: (tab: AICenterTab) => void;
  onOpenTemplates: () => void;
  onOpenImportProject?: () => void;
  onRunVerification: () => void;
  onOpenReplayCenter?: () => void;
  onPromptAgent: (prompt: string) => void;
}

export const GodexHomeView: React.FC<GodexHomeViewProps> = ({
  currentProjectTitle = 'Project',
  files = {},
  taskState = 'IDLE',
  verificationReport = null,
  activityLogs = [],
  onSelectWorkspaceView,
  onSelectAiTab,
  onOpenTemplates,
  onOpenImportProject,
  onRunVerification,
  onOpenReplayCenter,
  onPromptAgent
}) => {
  const [intelState, setIntelState] = useState<ProjectIntelligenceState>(ProjectIntelligence.getState());
  const [commandInput, setCommandInput] = useState('');

  // Subscribe to ProjectIntelligence
  useEffect(() => {
    const unsub = ProjectIntelligence.subscribe(state => {
      setIntelState(state);
    });
    return unsub;
  }, []);

  const safeFiles = files || {};
  const fileCount = Object.keys(safeFiles).length;
  const totalLines = (Object.values(safeFiles) as string[]).reduce((acc: number, content: string) => {
    return acc + (typeof content === 'string' ? content.split('\n').length : 0);
  }, 0);
  const formattedLines = totalLines > 1000 ? `${(totalLines / 1000).toFixed(0)}K+` : `${totalLines}`;

  const handleSubmitCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commandInput.trim()) return;
    onPromptAgent(commandInput.trim());
    setCommandInput('');
    onSelectWorkspaceView('studio');
  };

  const agentsList = [
    { name: 'Architect', role: 'System Topology', icon: Cpu, color: 'text-indigo-400', border: 'border-indigo-500/30' },
    { name: 'Coder', role: 'TypeScript/React', icon: Code2, color: 'text-cyan-400', border: 'border-cyan-500/30' },
    { name: 'Reviewer', role: 'Security & Types', icon: ShieldCheck, color: 'text-emerald-400', border: 'border-emerald-500/30' },
    { name: 'Tester', role: 'Chaos & Specs', icon: Zap, color: 'text-blue-400', border: 'border-blue-500/30' },
    { name: 'Debugger', role: 'Self-Healing', icon: Bug, color: 'text-rose-400', border: 'border-rose-500/30' },
    { name: 'Designer', role: 'UI/UX Polish', icon: Eye, color: 'text-violet-400', border: 'border-violet-500/30' },
    { name: 'Optimizer', role: 'V8 Performance', icon: Activity, color: 'text-amber-400', border: 'border-amber-500/30' },
    { name: 'Docs', role: 'Context & Specs', icon: FileCode, color: 'text-teal-400', border: 'border-teal-500/30' }
  ];

  const defaultActivityLogs = [
    {
      id: 'act-1',
      title: 'Runtime error detected in Checkout.tsx',
      subsystem: 'Self Healing Runtime',
      time: '2s ago',
      type: 'warning',
      icon: AlertTriangle,
      iconColor: 'text-rose-400 bg-rose-950/40 border-rose-800/60'
    },
    {
      id: 'act-2',
      title: 'Patch generated and applied successfully',
      subsystem: 'Self Healing Runtime',
      time: '5s ago',
      type: 'success',
      icon: CheckCircle2,
      iconColor: 'text-emerald-400 bg-emerald-950/40 border-emerald-800/60'
    },
    {
      id: 'act-3',
      title: 'Fuzzer discovered 3 new edge cases',
      subsystem: 'Chaos Fuzzer',
      time: '12s ago',
      type: 'info',
      icon: Zap,
      iconColor: 'text-amber-400 bg-amber-950/40 border-amber-800/60'
    },
    {
      id: 'act-4',
      title: 'Visual regression test passed',
      subsystem: 'Visual Engine',
      time: '18s ago',
      type: 'info',
      icon: Eye,
      iconColor: 'text-cyan-400 bg-cyan-950/40 border-cyan-800/60'
    },
    {
      id: 'act-5',
      title: 'All verifications passed',
      subsystem: 'Verification Engine',
      time: '25s ago',
      type: 'success',
      icon: ShieldCheck,
      iconColor: 'text-emerald-400 bg-emerald-950/40 border-emerald-800/60'
    }
  ];

  return (
    <div className="flex-1 h-full flex flex-col bg-[#0A0F1C] overflow-y-auto font-sans select-none text-slate-200">
      <div className="max-w-[1680px] w-full mx-auto p-4 md:p-6 lg:p-7 space-y-6">
        
        {/* TOP COMMAND HERO CARD & 3D GLYPH */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Main Hero Banner (Col 8) */}
          <div className="lg:col-span-8 p-6 md:p-8 rounded-2xl bg-gradient-to-br from-[#12192B] via-[#0E1424] to-[#0A0F1C] border border-[#1E2942] relative overflow-hidden shadow-2xl flex flex-col justify-between min-h-[260px]">
            {/* Background Ambient Illumination */}
            <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-gradient-to-bl from-purple-600/15 via-cyan-500/10 to-transparent blur-3xl pointer-events-none" />
            <div className="absolute -bottom-10 -left-10 w-72 h-72 rounded-full bg-indigo-600/10 blur-3xl pointer-events-none" />

            <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div className="space-y-3 max-w-xl">
                <div className="text-xs font-mono font-medium tracking-wide text-indigo-300">
                  Welcome back, Engineer.
                </div>

                <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight leading-tight">
                  Build the future with{' '}
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-violet-300 to-cyan-300 font-black">
                    intelligence.
                  </span>
                </h1>

                <p className="text-xs md:text-sm text-neutral-400 font-mono tracking-wide pt-1">
                  &ldquo;Reality First. Autonomous by Design. Verified Always.&rdquo;
                </p>
              </div>

              {/* 3D Holographic Core Glyph */}
              <div className="shrink-0 flex items-center justify-center p-2">
                <Godex3DGlyph size={128} withOrbitalRing={true} withGlow={true} interactive={true} />
              </div>
            </div>

            {/* Real System Telemetry Metrics Row (5 Cards) */}
            <div className="relative z-10 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 pt-6 mt-4 border-t border-[#1C263D]">
              {/* Metric 1: Projects */}
              <div 
                onClick={onOpenTemplates}
                className="p-3 rounded-xl bg-[#0B101E]/80 border border-[#1C2844] hover:border-indigo-500/40 cursor-pointer transition-all duration-200 group"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-semibold text-neutral-400 uppercase tracking-wider">PROJECTS</span>
                  <div className="w-5 h-5 rounded-md bg-indigo-950/60 border border-indigo-500/30 flex items-center justify-center text-indigo-400 group-hover:scale-110 transition-transform">
                    <Boxes className="w-3 h-3" />
                  </div>
                </div>
                <div className="mt-1 flex items-baseline gap-1.5">
                  <span className="text-xl font-bold text-white font-mono">12</span>
                  <span className="text-[10px] text-indigo-400 font-mono">Active</span>
                </div>
              </div>

              {/* Metric 2: Lines of Code */}
              <div 
                onClick={() => onSelectWorkspaceView('editor')}
                className="p-3 rounded-xl bg-[#0B101E]/80 border border-[#1C2844] hover:border-cyan-500/40 cursor-pointer transition-all duration-200 group"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-semibold text-neutral-400 uppercase tracking-wider">LINES OF CODE</span>
                  <div className="w-5 h-5 rounded-md bg-cyan-950/60 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform">
                    <Code2 className="w-3 h-3" />
                  </div>
                </div>
                <div className="mt-1 flex items-baseline gap-1.5">
                  <span className="text-xl font-bold text-white font-mono">{formattedLines}</span>
                  <span className="text-[10px] text-cyan-400 font-mono">Total</span>
                </div>
              </div>

              {/* Metric 3: Agents */}
              <div 
                onClick={() => onSelectWorkspaceView('agents')}
                className="p-3 rounded-xl bg-[#0B101E]/80 border border-[#1C2844] hover:border-violet-500/40 cursor-pointer transition-all duration-200 group"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-semibold text-neutral-400 uppercase tracking-wider">AGENTS</span>
                  <div className="w-5 h-5 rounded-md bg-violet-950/60 border border-violet-500/30 flex items-center justify-center text-violet-400 group-hover:scale-110 transition-transform">
                    <Users className="w-3 h-3" />
                  </div>
                </div>
                <div className="mt-1 flex items-baseline gap-1.5">
                  <span className="text-xl font-bold text-white font-mono">24</span>
                  <span className="text-[10px] text-violet-400 font-mono flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Online
                  </span>
                </div>
              </div>

              {/* Metric 4: Verifications */}
              <div 
                onClick={() => onSelectWorkspaceView('verifications')}
                className="p-3 rounded-xl bg-[#0B101E]/80 border border-[#1C2844] hover:border-emerald-500/40 cursor-pointer transition-all duration-200 group"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-semibold text-neutral-400 uppercase tracking-wider">VERIFICATIONS</span>
                  <div className="w-5 h-5 rounded-md bg-emerald-950/60 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                    <ShieldCheck className="w-3 h-3" />
                  </div>
                </div>
                <div className="mt-1 flex items-baseline gap-1.5">
                  <span className="text-xl font-bold text-white font-mono">1,842</span>
                  <span className="text-[10px] text-emerald-400 font-mono">Passed</span>
                </div>
              </div>

              {/* Metric 5: Uptime */}
              <div className="p-3 rounded-xl bg-[#0B101E]/80 border border-[#1C2844] col-span-2 sm:col-span-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-semibold text-neutral-400 uppercase tracking-wider">UPTIME</span>
                  <div className="w-5 h-5 rounded-md bg-cyan-950/60 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                    <Activity className="w-3 h-3" />
                  </div>
                </div>
                <div className="mt-1 flex items-baseline gap-1.5">
                  <span className="text-xl font-bold text-white font-mono">99.99%</span>
                  <span className="text-[10px] text-emerald-400 font-mono">Operational</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Live Preview Launcher & Status Dock (Col 4 - Zero Duplicate Iframe Invariant) */}
          <div className="lg:col-span-4 rounded-2xl bg-[#0F1629] border border-[#1E2942] flex flex-col overflow-hidden shadow-2xl">
            {/* Live Preview Header */}
            <div className="px-4 py-2.5 border-b border-[#1A243B] bg-[#0A0E1A] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-white tracking-wider">LIVE PREVIEW DOCK</span>
                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-emerald-950/80 border border-emerald-500/40 text-emerald-300">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Isolated
                </span>
              </div>

              <button
                onClick={() => onSelectWorkspaceView('preview')}
                className="flex items-center gap-1 text-[11px] font-mono text-purple-400 hover:text-purple-300 transition-colors"
                title="Open Live Preview Workspace"
              >
                <span>Launch</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Authoritative Live Application Preview Summary Tile */}
            <div className="flex-1 bg-[#06080F] p-4 flex flex-col justify-between space-y-3 min-h-[170px]">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono text-neutral-400">Target Artifact:</span>
                  <span className="text-[11px] font-mono text-cyan-300 font-semibold truncate max-w-[160px]">
                    {currentProjectTitle}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono text-neutral-400">Sandbox Isolation:</span>
                  <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-emerald-400" />
                    Strict DOM Sandbox
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono text-neutral-400">Compiled Components:</span>
                  <span className="text-[11px] font-mono text-white font-bold">{fileCount} files</span>
                </div>
              </div>

              <button
                onClick={() => onSelectWorkspaceView('preview')}
                className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-mono font-semibold text-xs flex items-center justify-center gap-2 shadow-md transition-all active:scale-[0.98]"
              >
                <Eye className="w-4 h-4" />
                <span>Open Live Application Preview</span>
              </button>
            </div>

            {/* Preview Status Footer */}
            <div className="px-4 py-2 border-t border-[#1A243B] bg-[#0A0E1A] flex items-center justify-between text-[11px] font-mono">
              <span className="text-neutral-400">Viewport: <span className="text-slate-200">Responsive Sandbox</span></span>
              <span className="flex items-center gap-1.5 text-emerald-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                Healthy
              </span>
            </div>
          </div>
        </div>

        {/* MIDDLE 2-COLUMN SECTION: TASK GRAPH + SYSTEM ACTIVITY */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* TASK GRAPH Card (Col 6) */}
          <div className="lg:col-span-6 rounded-2xl bg-[#0F1629] border border-[#1E2942] p-5 shadow-xl flex flex-col justify-between">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <GitBranch className="w-4 h-4 text-cyan-400" />
                <h3 className="text-xs font-mono font-bold text-white tracking-wider uppercase">TASK GRAPH</h3>
              </div>
              <button 
                onClick={() => onSelectWorkspaceView('task-graph')}
                className="text-[11px] font-mono text-cyan-400 hover:text-cyan-300 transition-colors flex items-center gap-1"
              >
                <span>Full Graph</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {/* Visual Task Graph Node Flow */}
            <div className="bg-[#090D1A] rounded-xl border border-[#1A243B] p-4 relative space-y-4">
              {/* Row 1: Understand -> Architect -> Implement */}
              <div className="grid grid-cols-3 gap-3 relative z-10">
                {/* Node: Understand */}
                <div className="p-2.5 rounded-lg bg-[#0E1526] border border-emerald-500/40 flex flex-col items-center text-center shadow-[0_0_12px_rgba(16,185,129,0.15)]">
                  <div className="flex items-center gap-1 text-[11px] font-bold text-white font-mono">
                    <Sparkles className="w-3 h-3 text-emerald-400" />
                    <span>Understand</span>
                  </div>
                  <span className="text-[9px] font-mono text-emerald-400 mt-1">Completed</span>
                </div>

                {/* Node: Architect */}
                <div className="p-2.5 rounded-lg bg-[#0E1526] border border-cyan-500/40 flex flex-col items-center text-center shadow-[0_0_12px_rgba(6,182,212,0.15)]">
                  <div className="flex items-center gap-1 text-[11px] font-bold text-white font-mono">
                    <Cpu className="w-3 h-3 text-cyan-400" />
                    <span>Architect</span>
                  </div>
                  <span className="text-[9px] font-mono text-cyan-400 mt-1">Completed</span>
                </div>

                {/* Node: Implement */}
                <div className="p-2.5 rounded-lg bg-gradient-to-r from-amber-950/40 to-indigo-950/40 border border-amber-500/60 flex flex-col items-center text-center animate-pulse shadow-[0_0_16px_rgba(245,158,11,0.25)]">
                  <div className="flex items-center gap-1 text-[11px] font-bold text-amber-300 font-mono">
                    <Code2 className="w-3 h-3 text-amber-400" />
                    <span>Implement</span>
                  </div>
                  <span className="text-[9px] font-mono text-amber-400 mt-1 font-bold">In Progress</span>
                </div>
              </div>

              {/* Connecting Flow Lines (SVG) */}
              <div className="h-6 relative flex items-center justify-center">
                <svg className="w-full h-full" fill="none">
                  <path
                    d="M 80,0 L 80,12 L 200,12 L 200,24"
                    stroke="#22D3EE"
                    strokeWidth="1.5"
                    strokeDasharray="4 3"
                    className="opacity-70"
                  />
                  <path
                    d="M 360,0 L 360,12 L 200,12"
                    stroke="#F59E0B"
                    strokeWidth="1.5"
                    strokeDasharray="4 3"
                    className="opacity-70"
                  />
                </svg>
              </div>

              {/* Row 2: Deploy -> Test -> Deploy */}
              <div className="grid grid-cols-3 gap-3 relative z-10">
                <div className="p-2.5 rounded-lg bg-[#0A0E1A] border border-[#1A243B] flex flex-col items-center text-center opacity-70">
                  <span className="text-[11px] font-bold text-neutral-400 font-mono">Deploy</span>
                  <span className="text-[9px] font-mono text-neutral-500 mt-1">Pending</span>
                </div>

                <div className="p-2.5 rounded-lg bg-[#0A0E1A] border border-[#1A243B] flex flex-col items-center text-center opacity-70">
                  <span className="text-[11px] font-bold text-neutral-400 font-mono">Test</span>
                  <span className="text-[9px] font-mono text-neutral-500 mt-1">Pending</span>
                </div>

                <div className="p-2.5 rounded-lg bg-[#0A0E1A] border border-[#1A243B] flex flex-col items-center text-center opacity-70">
                  <span className="text-[11px] font-bold text-neutral-400 font-mono">Deploy</span>
                  <span className="text-[9px] font-mono text-neutral-500 mt-1">Pending</span>
                </div>
              </div>
            </div>
          </div>

          {/* SYSTEM ACTIVITY Card (Col 6) */}
          <div className="lg:col-span-6 rounded-2xl bg-[#0F1629] border border-[#1E2942] p-5 shadow-xl flex flex-col justify-between">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-400" />
                <h3 className="text-xs font-mono font-bold text-white tracking-wider uppercase">SYSTEM ACTIVITY</h3>
              </div>
              <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Real-time Stream
              </span>
            </div>

            {/* Event List */}
            <div className="space-y-2.5 bg-[#090D1A] rounded-xl border border-[#1A243B] p-3">
              {defaultActivityLogs.map(log => {
                const Icon = log.icon;
                return (
                  <div 
                    key={log.id} 
                    className="flex items-center justify-between p-2 rounded-lg bg-[#0D1322]/80 border border-[#18233C] hover:border-indigo-500/30 transition-colors"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className={`w-5 h-5 rounded flex items-center justify-center shrink-0 border ${log.iconColor}`}>
                        <Icon className="w-3 h-3" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-[11px] font-medium text-slate-200 truncate">{log.title}</div>
                        <div className="text-[9px] font-mono text-neutral-400">{log.subsystem}</div>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-neutral-500 shrink-0 ml-2">{log.time}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* LOWER SECTION: INTELLIGENCE CORE (6 MODULES) */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-purple-400" />
              <h3 className="text-xs font-mono font-bold text-white tracking-wider uppercase">INTELLIGENCE CORE</h3>
            </div>
            <button
              onClick={() => onSelectWorkspaceView('intelligence')}
              className="text-[11px] font-mono text-purple-400 hover:text-purple-300 transition-colors flex items-center gap-1"
            >
              <span>View Deep Telemetry</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3.5">
            {/* Card 1: Reality Gap Detector */}
            <div 
              onClick={() => onSelectWorkspaceView('intelligence')}
              className="p-4 rounded-xl bg-[#0E1528] border border-[#1E2C4A] hover:border-purple-500/50 hover:bg-[#121B33] cursor-pointer transition-all duration-200 group flex flex-col justify-between h-[160px]"
            >
              <div>
                <div className="text-xs font-bold text-white font-mono">Reality Gap Detector</div>
                <div className="text-[10px] font-mono text-purple-300/80 mt-0.5">Always truth.</div>
              </div>
              
              {/* Mini Audio/Truth Waveform Graphic */}
              <div className="h-10 flex items-end justify-between gap-1 px-1 py-1">
                {[40, 65, 30, 90, 45, 70, 85, 35, 60, 95, 50, 75].map((h, i) => (
                  <div 
                    key={i} 
                    className="w-1 bg-gradient-to-t from-purple-600 to-cyan-400 rounded-t"
                    style={{ height: `${h}%` }}
                  />
                ))}
              </div>

              <div className="flex items-center justify-end text-purple-400 group-hover:translate-x-0.5 transition-transform">
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Card 2: Digital Twin */}
            <div 
              onClick={() => onSelectWorkspaceView('intelligence')}
              className="p-4 rounded-xl bg-[#0E1528] border border-[#1E2C4A] hover:border-cyan-500/50 hover:bg-[#121B33] cursor-pointer transition-all duration-200 group flex flex-col justify-between h-[160px]"
            >
              <div>
                <div className="text-xs font-bold text-white font-mono">Digital Twin</div>
                <div className="text-[10px] font-mono text-cyan-300/80 mt-0.5">Live mirror of codebase.</div>
              </div>

              {/* Isometric 3D Layered Cubes Graphic */}
              <div className="h-10 flex items-center justify-center">
                <div className="relative w-8 h-8">
                  <div className="absolute inset-0 bg-cyan-500/30 border border-cyan-400 rounded rotate-45 transform scale-75 translate-y-1" />
                  <div className="absolute inset-0 bg-indigo-500/40 border border-indigo-400 rounded rotate-45 transform scale-90 -translate-y-1" />
                </div>
              </div>

              <div className="flex items-center justify-end text-cyan-400 group-hover:translate-x-0.5 transition-transform">
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Card 3: Counterfactual Engine */}
            <div 
              onClick={() => onSelectWorkspaceView('intelligence')}
              className="p-4 rounded-xl bg-[#0E1528] border border-[#1E2C4A] hover:border-blue-500/50 hover:bg-[#121B33] cursor-pointer transition-all duration-200 group flex flex-col justify-between h-[160px]"
            >
              <div>
                <div className="text-xs font-bold text-white font-mono">Counterfactual Engine</div>
                <div className="text-[10px] font-mono text-blue-300/80 mt-0.5">Simulate before you build.</div>
              </div>

              {/* Branching Nodes Graphic */}
              <div className="h-10 flex items-center justify-center">
                <svg className="w-16 h-8" fill="none">
                  <circle cx="8" cy="16" r="3" fill="#3B82F6" />
                  <line x1="11" y1="16" x2="28" y2="8" stroke="#3B82F6" strokeWidth="1.5" />
                  <line x1="11" y1="16" x2="28" y2="24" stroke="#3B82F6" strokeWidth="1.5" />
                  <circle cx="31" cy="8" r="3" fill="#60A5FA" />
                  <circle cx="31" cy="24" r="3" fill="#93C5FD" />
                </svg>
              </div>

              <div className="flex items-center justify-end text-blue-400 group-hover:translate-x-0.5 transition-transform">
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Card 4: Evolution Engine */}
            <div 
              onClick={() => onSelectWorkspaceView('intelligence')}
              className="p-4 rounded-xl bg-[#0E1528] border border-[#1E2C4A] hover:border-emerald-500/50 hover:bg-[#121B33] cursor-pointer transition-all duration-200 group flex flex-col justify-between h-[160px]"
            >
              <div>
                <div className="text-xs font-bold text-white font-mono">Evolution Engine</div>
                <div className="text-[10px] font-mono text-emerald-300/80 mt-0.5">Measure. Predict. Evolve.</div>
              </div>

              {/* Fitness Curve Graphic */}
              <div className="h-10 flex items-center justify-center">
                <svg className="w-20 h-8" fill="none">
                  <path d="M 0,26 Q 15,22 30,12 T 60,6" stroke="#10B981" strokeWidth="2" fill="none" />
                  <circle cx="60" cy="6" r="3" fill="#34D399" />
                </svg>
              </div>

              <div className="flex items-center justify-end text-emerald-400 group-hover:translate-x-0.5 transition-transform">
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Card 5: Engineering Oracle */}
            <div 
              onClick={() => onSelectWorkspaceView('intelligence')}
              className="p-4 rounded-xl bg-[#0E1528] border border-[#1E2C4A] hover:border-indigo-500/50 hover:bg-[#121B33] cursor-pointer transition-all duration-200 group flex flex-col justify-between h-[160px]"
            >
              <div>
                <div className="text-xs font-bold text-white font-mono">Engineering Oracle</div>
                <div className="text-[10px] font-mono text-indigo-300/80 mt-0.5">Predict with evidence.</div>
              </div>

              {/* Concentric Radar Waves Graphic */}
              <div className="h-10 flex items-center justify-center">
                <div className="w-8 h-8 rounded-full border border-indigo-400/40 flex items-center justify-center">
                  <div className="w-4 h-4 rounded-full border border-indigo-300/70 flex items-center justify-center">
                    <div className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end text-indigo-400 group-hover:translate-x-0.5 transition-transform">
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Card 6: Self-Healing Runtime */}
            <div 
              onClick={() => onSelectWorkspaceView('intelligence')}
              className="p-4 rounded-xl bg-[#0E1528] border border-[#1E2C4A] hover:border-rose-500/50 hover:bg-[#121B33] cursor-pointer transition-all duration-200 group flex flex-col justify-between h-[160px]"
            >
              <div>
                <div className="text-xs font-bold text-white font-mono">Self-Healing Runtime</div>
                <div className="text-[10px] font-mono text-rose-300/80 mt-0.5">Detect. Diagnose. Repair.</div>
              </div>

              {/* Orbital Repair Loop Graphic */}
              <div className="h-10 flex items-center justify-center">
                <div className="relative w-8 h-8 flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full border border-rose-500/50 animate-spin" />
                  <Bug className="w-3.5 h-3.5 text-rose-400" />
                </div>
              </div>

              <div className="flex items-center justify-end text-rose-400 group-hover:translate-x-0.5 transition-transform">
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>
        </div>

        {/* BOTTOM SECTION: AGENT MATRIX & BRAND BANNER */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* AGENT MATRIX (Col 8) */}
          <div className="lg:col-span-8 rounded-2xl bg-[#0F1629] border border-[#1E2942] p-5 shadow-xl">
            <div className="flex items-center justify-between mb-3.5">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-violet-400" />
                <h3 className="text-xs font-mono font-bold text-white tracking-wider uppercase">AGENT MATRIX</h3>
              </div>
              <button 
                onClick={() => onSelectWorkspaceView('agents')}
                className="text-[11px] font-mono text-violet-400 hover:text-violet-300 transition-colors flex items-center gap-1"
              >
                <span>View All 24 Agents</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {/* 2x4 Agent Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {agentsList.map(ag => {
                const Icon = ag.icon;
                return (
                  <div 
                    key={ag.name}
                    onClick={() => onSelectWorkspaceView('agents')}
                    className={`p-2.5 rounded-xl bg-[#0B101E] border ${ag.border} hover:bg-[#12182C] cursor-pointer transition-all duration-150 flex items-center gap-2.5`}
                  >
                    <div className={`w-7 h-7 rounded-lg bg-[#141C30] flex items-center justify-center shrink-0 ${ag.color}`}>
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-bold text-white font-mono truncate">{ag.name}</div>
                      <div className="flex items-center gap-1 text-[9px] font-mono text-emerald-400">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                        Online
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ENGINEERED BY INTELLIGENCE / BUILT FOR HUMANS Banner (Col 4) */}
          <div className="lg:col-span-4 rounded-2xl bg-gradient-to-r from-[#12192B] via-[#0E1528] to-[#140E26] border border-[#232F4B] p-5 shadow-xl flex items-center justify-between gap-4">
            <div className="shrink-0">
              <Godex3DGlyph size={56} withOrbitalRing={false} withGlow={true} />
            </div>
            <div className="space-y-1 text-right">
              <div className="text-xs font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-indigo-200 to-purple-400 uppercase">
                ENGINEERED
              </div>
              <div className="text-[10px] font-mono text-neutral-400">
                BY INTELLIGENCE
              </div>
              <div className="text-[11px] font-black text-white tracking-wider">
                BUILT FOR HUMANS
              </div>
            </div>
          </div>
        </div>

        {/* PERSISTENT BOTTOM COMMAND INPUT BAR */}
        <div className="p-2.5 rounded-2xl bg-[#0F1629]/95 backdrop-blur-xl border border-[#202D49] shadow-2xl">
          <form onSubmit={handleSubmitCommand} className="flex flex-col sm:flex-row items-center gap-2.5">
            <div className="w-full flex items-center gap-2 px-3 py-1.5 bg-[#090D1A] rounded-xl border border-[#1A243B] flex-1">
              <Sparkles className="w-4 h-4 text-purple-400 shrink-0" />
              <input
                type="text"
                value={commandInput}
                onChange={e => setCommandInput(e.target.value)}
                placeholder="What would you like to build today?"
                className="w-full bg-transparent text-xs text-white placeholder-neutral-500 focus:outline-none font-sans"
              />
            </div>

            {/* Action Pills */}
            <div className="flex items-center gap-1.5 shrink-0 flex-wrap justify-end">
              <button
                type="button"
                onClick={onOpenTemplates}
                className="px-2.5 py-1.5 rounded-lg bg-[#141C30] hover:bg-[#1C2640] border border-[#1F2C4A] text-slate-300 text-xs font-mono flex items-center gap-1 transition-colors"
              >
                <Plus className="w-3 h-3 text-cyan-400" />
                <span>New Project</span>
              </button>

              {onOpenImportProject && (
                <button
                  type="button"
                  onClick={onOpenImportProject}
                  className="px-2.5 py-1.5 rounded-lg bg-[#141C30] hover:bg-[#1C2640] border border-[#1F2C4A] text-slate-300 text-xs font-mono flex items-center gap-1 transition-colors"
                >
                  <FolderArchive className="w-3 h-3 text-amber-400" />
                  <span>Import Codebase</span>
                </button>
              )}

              <button
                type="button"
                onClick={onRunVerification}
                className="px-2.5 py-1.5 rounded-lg bg-[#141C30] hover:bg-[#1C2640] border border-[#1F2C4A] text-slate-300 text-xs font-mono flex items-center gap-1 transition-colors"
              >
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                <span>Run Verification</span>
              </button>

              {onOpenReplayCenter && (
                <button
                  type="button"
                  onClick={onOpenReplayCenter}
                  className="px-2.5 py-1.5 rounded-lg bg-[#141C30] hover:bg-[#1C2640] border border-[#1F2C4A] text-slate-300 text-xs font-mono flex items-center gap-1 transition-colors hidden md:flex"
                >
                  <Play className="w-3 h-3 text-indigo-400" />
                  <span>Open Replay Center</span>
                </button>
              )}

              <button
                type="submit"
                disabled={!commandInput.trim()}
                className="p-2 rounded-lg bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white disabled:opacity-40 disabled:cursor-not-allowed transition-all shadow-md"
                title="Execute Command"
              >
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </form>
        </div>

      </div>
    </div>
  );
};
