import React, { useState, useEffect } from 'react';
import { Flashcard, ReviewRating, Topic } from '../types';
import { RotateCw, HelpCircle, ArrowLeft, CheckCircle2, ChevronRight, Award, Zap, RotateCcw } from 'lucide-react';
import { getMasteryTier } from '../utils/spacedRepetition';

interface FlashcardReviewSessionProps {
  topic: Topic;
  onFinishSession: (updatedFlashcards: Flashcard[], ratings: { cardId: string; rating: ReviewRating }[]) => void;
  onCancel: () => void;
}

export const FlashcardReviewSession: React.FC<FlashcardReviewSessionProps> = ({
  topic,
  onFinishSession,
  onCancel,
}) => {
  const [cards, setCards] = useState<Flashcard[]>(topic.flashcards || []);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [sessionRatings, setSessionRatings] = useState<{ cardId: string; rating: ReviewRating }[]>([]);
  const [isCompleted, setIsCompleted] = useState(false);

  const currentCard = cards[currentIndex];
  const progressPct = cards.length > 0 ? Math.round(((currentIndex) / cards.length) * 100) : 0;

  // Keyboard navigation support
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isCompleted) return;

      if (e.code === 'Space' || e.code === 'Enter') {
        e.preventDefault();
        setIsFlipped((prev) => !prev);
      } else if (isFlipped) {
        if (e.key === '1') handleRate('again');
        else if (e.key === '2') handleRate('hard');
        else if (e.key === '3') handleRate('good');
        else if (e.key === '4') handleRate('easy');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isFlipped, isCompleted, currentIndex]);

  const handleRate = (rating: ReviewRating) => {
    if (!currentCard) return;

    const newRatingEntry = { cardId: currentCard.id, rating };
    const updatedRatings = [...sessionRatings, newRatingEntry];
    setSessionRatings(updatedRatings);

    // Update current card stats
    const updatedCards = cards.map((c, idx) => {
      if (idx === currentIndex) {
        return {
          ...c,
          reviewCount: c.reviewCount + 1,
          lastReviewedAt: new Date().toISOString(),
          ratingHistory: [...c.ratingHistory, rating],
        };
      }
      return c;
    });
    setCards(updatedCards);

    // Advance to next card or complete
    if (currentIndex + 1 < cards.length) {
      setCurrentIndex((prev) => prev + 1);
      setIsFlipped(false);
      setShowHint(false);
    } else {
      setIsCompleted(true);
    }
  };

  const handleFinish = () => {
    onFinishSession(cards, sessionRatings);
  };

  if (!cards || cards.length === 0) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-8 max-w-xl mx-auto text-center space-y-4">
        <HelpCircle className="w-12 h-12 text-slate-400 mx-auto" />
        <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100">
          No Flashcards for this Topic Yet
        </h3>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Create flashcards to test your active recall and reinforce memory traces for {topic.title}.
        </p>
        <button
          onClick={onCancel}
          className="px-4 py-2 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-lg text-xs font-medium hover:bg-slate-800 transition-colors"
        >
          Back to Topics
        </button>
      </div>
    );
  }

  // Session Completed Summary Screen
  if (isCompleted) {
    const goodEasyCount = sessionRatings.filter((r) => r.rating === 'good' || r.rating === 'easy').length;
    const accuracy = Math.round((goodEasyCount / sessionRatings.length) * 100);

    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 max-w-xl mx-auto shadow-sm space-y-6 text-center animate-in fade-in duration-300">
        <div className="w-16 h-16 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center justify-center mx-auto ring-8 ring-emerald-50/50 dark:ring-emerald-950/20">
          <Award className="w-8 h-8" />
        </div>

        <div>
          <span className="text-xs uppercase tracking-wider font-semibold text-emerald-600 dark:text-emerald-400">
            Revision Session Complete
          </span>
          <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mt-1">
            {topic.title}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Active retrieval reconsolidates synaptic connections and resets the forgetting curve.
          </p>
        </div>

        {/* Performance metrics */}
        <div className="grid grid-cols-3 gap-3 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800 text-left">
          <div>
            <div className="text-xs text-slate-500 dark:text-slate-400">Cards Reviewed</div>
            <div className="text-xl font-bold font-mono text-slate-900 dark:text-slate-100 mt-0.5">
              {sessionRatings.length}
            </div>
          </div>
          <div>
            <div className="text-xs text-slate-500 dark:text-slate-400">Recall Success</div>
            <div className="text-xl font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-0.5">
              {accuracy}%
            </div>
          </div>
          <div>
            <div className="text-xs text-slate-500 dark:text-slate-400">Next Milestone</div>
            <div className="text-xl font-bold font-mono text-indigo-600 dark:text-indigo-400 mt-0.5">
              Stage {Math.min(topic.stage + 1, 6)}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-center gap-3 pt-2">
          <button
            onClick={() => {
              setCurrentIndex(0);
              setIsFlipped(false);
              setSessionRatings([]);
              setIsCompleted(false);
            }}
            className="px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Repeat Session
          </button>
          <button
            onClick={handleFinish}
            className="px-5 py-2 text-xs font-medium text-white bg-slate-900 dark:bg-indigo-600 hover:bg-slate-800 dark:hover:bg-indigo-500 rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
          >
            Save Progress & Exit
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      {/* Top Session Bar */}
      <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 px-1">
        <button
          onClick={onCancel}
          className="flex items-center gap-1.5 hover:text-slate-900 dark:hover:text-slate-100 transition-colors"
          aria-label="Exit study session"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Exit Session</span>
        </button>

        <div className="flex items-center gap-3">
          <span className="font-medium text-slate-800 dark:text-slate-200 truncate max-w-[200px]">
            {topic.title}
          </span>
          <span className="text-slate-300 dark:text-slate-700">|</span>
          <span className="font-mono tabular-nums font-semibold text-slate-700 dark:text-slate-300">
            Card {currentIndex + 1} of {cards.length}
          </span>
        </div>
      </div>

      {/* Progress Track */}
      <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
        <div
          className="bg-indigo-600 dark:bg-indigo-500 h-full transition-all duration-300"
          style={{ width: `${progressPct}%` }}
        />
      </div>

      {/* Interactive 3D Flip Card */}
      <div
        className="perspective-1000 w-full min-h-[340px] cursor-pointer selection:bg-none"
        onClick={() => setIsFlipped((prev) => !prev)}
        role="button"
        tabIndex={0}
        aria-label="Flashcard. Click or press space to flip between question and answer."
      >
        <div
          className={`relative w-full min-h-[340px] transform-style-3d transition-transform duration-500 ease-out ${
            isFlipped ? 'rotate-y-180' : ''
          }`}
        >
          {/* Card Front (Prompt / Question) */}
          <div className="absolute inset-0 backface-hidden bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 flex flex-col justify-between shadow-sm">
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
              <span className="font-semibold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider text-[10px]">
                Concept Prompt
              </span>
              <span className="flex items-center gap-1 text-[11px] text-slate-500">
                <RotateCw className="w-3 h-3 text-slate-500" /> Click or Space to reveal
              </span>
            </div>

            <div className="py-6 my-auto text-center">
              <p className="text-lg md:text-xl font-medium text-slate-900 dark:text-slate-100 leading-relaxed max-w-lg mx-auto">
                {currentCard.front}
              </p>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800 text-xs">
              {currentCard.hint ? (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowHint((prev) => !prev);
                  }}
                  className="text-xs text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 flex items-center gap-1 font-medium"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  {showHint ? 'Hide Hint' : 'Show Hint'}
                </button>
              ) : (
                <span />
              )}

              <span className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                Space to Flip
              </span>
            </div>

            {/* Hint Box */}
            {showHint && currentCard.hint && (
              <div
                onClick={(e) => e.stopPropagation()}
                className="mt-3 p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-lg text-xs text-amber-800 dark:text-amber-200 text-left animate-in fade-in"
              >
                <strong className="font-semibold">Hint: </strong>
                {currentCard.hint}
              </div>
            )}
          </div>

          {/* Card Back (Answer / Solution) */}
          <div className="absolute inset-0 backface-hidden rotate-y-180 bg-slate-900 dark:bg-slate-950 text-white border border-slate-800 rounded-2xl p-8 flex flex-col justify-between shadow-md">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span className="font-semibold text-emerald-400 uppercase tracking-wider text-[10px]">
                Retrieved Answer
              </span>
              <span className="flex items-center gap-1 text-[11px] text-slate-400">
                <RotateCw className="w-3 h-3 text-slate-400" /> Click to flip back
              </span>
            </div>

            <div className="py-6 my-auto text-left">
              <p className="text-base md:text-lg text-slate-100 whitespace-pre-line leading-relaxed max-w-lg mx-auto">
                {currentCard.back}
              </p>
            </div>

            <div className="pt-4 border-t border-slate-800 text-xs text-slate-400 text-center">
              <span>Rate how easily you retrieved this information:</span>
            </div>
          </div>
        </div>
      </div>

      {/* Spaced Repetition Rating Deck (Visible when card is flipped or always accessible) */}
      <div className="pt-2">
        {isFlipped ? (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {/* 1. Again (Failed) */}
            <button
              onClick={() => handleRate('again')}
              className="p-3 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/50 border border-rose-200 dark:border-rose-800 rounded-xl text-left transition-colors group"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-rose-700 dark:text-rose-300">
                  Again
                </span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 bg-rose-200/60 dark:bg-rose-800/60 rounded text-rose-800 dark:text-rose-200">
                  Key 1
                </span>
              </div>
              <p className="text-[11px] text-rose-600/80 dark:text-rose-400">
                Forgot · Reset Day 1
              </p>
            </button>

            {/* 2. Hard */}
            <button
              onClick={() => handleRate('hard')}
              className="p-3 bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/50 border border-amber-200 dark:border-amber-800 rounded-xl text-left transition-colors group"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-amber-700 dark:text-amber-300">
                  Hard
                </span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 bg-amber-200/60 dark:bg-amber-800/60 rounded text-amber-800 dark:text-amber-200">
                  Key 2
                </span>
              </div>
              <p className="text-[11px] text-amber-600/80 dark:text-amber-400">
                Struggled · Shorter interval
              </p>
            </button>

            {/* 3. Good */}
            <button
              onClick={() => handleRate('good')}
              className="p-3 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 border border-emerald-200 dark:border-emerald-800 rounded-xl text-left transition-colors group"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-emerald-700 dark:text-emerald-300">
                  Good
                </span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 bg-emerald-200/60 dark:bg-emerald-800/60 rounded text-emerald-800 dark:text-emerald-200">
                  Key 3
                </span>
              </div>
              <p className="text-[11px] text-emerald-600/80 dark:text-emerald-400">
                Correct · Next milestone
              </p>
            </button>

            {/* 4. Easy */}
            <button
              onClick={() => handleRate('easy')}
              className="p-3 bg-sky-50 dark:bg-sky-950/40 hover:bg-sky-100 dark:hover:bg-sky-900/50 border border-sky-200 dark:border-sky-800 rounded-xl text-left transition-colors group"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-sky-700 dark:text-sky-300">
                  Easy
                </span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 bg-sky-200/60 dark:bg-sky-800/60 rounded text-sky-800 dark:text-sky-200">
                  Key 4
                </span>
              </div>
              <p className="text-[11px] text-sky-600/80 dark:text-sky-400">
                Instant · Bonus stability
              </p>
            </button>
          </div>
        ) : (
          <div className="text-center py-2">
            <button
              onClick={() => setIsFlipped(true)}
              className="px-6 py-2.5 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-xl text-xs font-medium hover:bg-slate-800 transition-colors shadow-xs"
            >
              Flip to Check Answer (Space)
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
