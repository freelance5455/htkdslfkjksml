import React, { useState, useEffect } from 'react';
import { X, FolderPlus, Edit2 } from 'lucide-react';
import { Folder } from '../types';

interface FolderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (folderName: string, folderToEdit?: Folder | null) => void;
  folderToEdit?: Folder | null;
}

export const FolderModal: React.FC<FolderModalProps> = ({
  isOpen,
  onClose,
  onSave,
  folderToEdit,
}) => {
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  const isEditing = !!folderToEdit;

  useEffect(() => {
    if (folderToEdit) {
      setName(folderToEdit.name);
      setError('');
    } else {
      setName('');
      setError('');
    }
  }, [folderToEdit, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('कृपया इलाके या फोल्डर का नाम लिखें।');
      return;
    }

    onSave(name.trim(), folderToEdit);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden border border-orange-100">
        <div className="bg-gradient-to-r from-orange-600 to-amber-600 px-5 py-3.5 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            {isEditing ? <Edit2 className="w-5 h-5 text-yellow-300" /> : <FolderPlus className="w-5 h-5 text-yellow-300" />}
            <h2 className="text-base sm:text-lg font-bold">
              {isEditing ? 'फोल्डर का नाम बदलें' : 'नया इलाका / फोल्डर बनाएं'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-orange-100 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl font-medium">
              {error}
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              इलाके या फोल्डर का नाम
            </label>
            <input
              type="text"
              autoFocus
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="उदा. शांति नगर, वार्ड 2, मेन बाजार..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-orange-500 focus:border-orange-500 text-sm font-medium"
            />
            <p className="mt-1.5 text-[11px] text-slate-500">
              ग्राहकों को उनके क्षेत्र के अनुसार अलग-अलग रखने में मदद मिलेगी।
            </p>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-sm hover:bg-slate-50 transition cursor-pointer"
            >
              रद्द करें
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-sm shadow-sm transition active:scale-95 cursor-pointer"
            >
              {isEditing ? 'नाम सुरक्षित करें' : 'फोल्डर बनाएं'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
