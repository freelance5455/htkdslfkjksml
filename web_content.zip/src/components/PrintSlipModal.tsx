import React from 'react';
import { X, Printer, ShieldCheck } from 'lucide-react';
import { CnicRecord, CnicBatchStats } from '../types/cnic';

interface PrintSlipModalProps {
  records: CnicRecord[];
  stats: CnicBatchStats;
  onClose: () => void;
}

export const PrintSlipModal: React.FC<PrintSlipModalProps> = ({ records, stats, onClose }) => {
  const handlePrint = () => {
    window.print();
  };

  const currentDate = new Date().toLocaleDateString('en-PK', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
  const currentTime = new Date().toLocaleTimeString('en-PK', {
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-200 my-8">
        {/* Header (No-print controls) */}
        <div className="bg-slate-900 text-white px-5 py-3.5 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <Printer className="w-4 h-4 text-emerald-400" />
            <span className="font-semibold text-sm">Batch Verification Print Preview</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-[#07843e] hover:bg-[#066a32] text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document */}
        <div id="printable-slip" className="p-8 font-sans text-slate-800 bg-white">
          {/* Document Header */}
          <div className="border-b-2 border-[#087d3e] pb-4 mb-6 flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded bg-[#087d3e] text-white flex items-center justify-center font-bold text-sm">
                  JC
                </div>
                <h2 className="text-xl font-bold tracking-tight text-slate-900">
                  JazzCash CNIC Verification Summary
                </h2>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Batch CNIC format verification & duplicate integrity report
              </p>
            </div>
            <div className="text-right text-xs text-slate-500">
              <div>Date: <strong className="text-slate-800">{currentDate}</strong></div>
              <div>Time: <strong className="text-slate-800">{currentTime}</strong></div>
              <div className="font-mono text-[11px] text-slate-400 mt-0.5">Ref: JC-VER-{Date.now().toString().slice(-6)}</div>
            </div>
          </div>

          {/* KPI Summary Block */}
          <div className="grid grid-cols-4 gap-3 p-4 bg-slate-50 rounded-xl border border-slate-200 mb-6 text-center">
            <div>
              <div className="text-[11px] uppercase font-semibold text-slate-500">Total Checked</div>
              <div className="text-xl font-bold font-mono text-slate-900">{stats.total}</div>
            </div>
            <div>
              <div className="text-[11px] uppercase font-semibold text-emerald-700">Valid Format</div>
              <div className="text-xl font-bold font-mono text-emerald-700">{stats.valid}</div>
            </div>
            <div>
              <div className="text-[11px] uppercase font-semibold text-amber-700">Duplicates</div>
              <div className="text-xl font-bold font-mono text-amber-700">{stats.duplicate}</div>
            </div>
            <div>
              <div className="text-[11px] uppercase font-semibold text-red-700">Invalid</div>
              <div className="text-xl font-bold font-mono text-red-700">{stats.invalid}</div>
            </div>
          </div>

          {/* Demographic Breakdown */}
          <div className="text-xs border border-slate-200 rounded-lg p-3 mb-6 bg-white flex justify-between">
            <div>
              <span className="text-slate-500">Gender Ratio:</span>{' '}
              <strong className="text-slate-800">Male: {stats.maleCount}</strong> ·{' '}
              <strong className="text-slate-800">Female: {stats.femaleCount}</strong>
            </div>
            <div>
              <span className="text-slate-500">Accuracy Score:</span>{' '}
              <strong className="text-emerald-700 font-mono">
                {stats.total > 0 ? Math.round((stats.valid / stats.total) * 100) : 0}% Compliant
              </strong>
            </div>
          </div>

          {/* Table of Checked CNICs (up to 20 for receipt preview) */}
          <div className="mb-6">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
              Verified Entries ({records.length > 25 ? `Showing first 25 of ${records.length}` : `${records.length} items`})
            </h4>
            <table className="w-full text-xs text-left border-collapse border border-slate-200">
              <thead>
                <tr className="bg-slate-100 text-slate-600 font-semibold border-b border-slate-200">
                  <th className="p-1.5 border-r border-slate-200 w-8 text-center">#</th>
                  <th className="p-1.5 border-r border-slate-200 font-mono">CNIC Number</th>
                  <th className="p-1.5 border-r border-slate-200">Status</th>
                  <th className="p-1.5 border-r border-slate-200">Province</th>
                  <th className="p-1.5">Gender</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
                {records.slice(0, 25).map((r, i) => (
                  <tr key={r.id}>
                    <td className="p-1.5 border-r border-slate-200 text-center text-slate-400 font-normal">
                      {i + 1}
                    </td>
                    <td className="p-1.5 border-r border-slate-200 font-semibold text-slate-900">
                      {r.cnicFormatted || r.cnicRaw}
                    </td>
                    <td className="p-1.5 border-r border-slate-200 font-sans">
                      <span className={r.isValid ? 'text-emerald-800' : 'text-red-700'}>
                        {r.status}
                      </span>
                    </td>
                    <td className="p-1.5 border-r border-slate-200 font-sans text-slate-600">
                      {r.provinceName}
                    </td>
                    <td className="p-1.5 font-sans text-slate-600">
                      {r.gender}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {records.length > 25 && (
              <p className="text-[10px] text-slate-400 italic mt-1.5 text-center">
                ... and {records.length - 25} more records included in full CSV download.
              </p>
            )}
          </div>

          {/* Verification Signatures & Stamp Box */}
          <div className="grid grid-cols-2 gap-8 pt-6 border-t border-slate-200 mt-6 text-xs text-slate-600">
            <div>
              <p className="font-semibold text-slate-700">Prepared By (Agent / Operator):</p>
              <div className="h-14 border-b border-dashed border-slate-400 mt-2"></div>
              <p className="text-[10px] text-slate-400 mt-1">Signature & Branchless Banking ID</p>
            </div>
            <div>
              <p className="font-semibold text-slate-700">Compliance / Verification Stamp:</p>
              <div className="h-14 border-b border-dashed border-slate-400 mt-2"></div>
              <p className="text-[10px] text-slate-400 mt-1">Official JazzCash Verification Officer</p>
            </div>
          </div>

          {/* Legal disclaimer */}
          <div className="text-[10px] text-slate-400 mt-6 pt-3 border-t border-slate-100 text-center">
            JazzCash CNIC Checker · Formatted according to Pakistan NADRA standards · Official account verification requires biometric teller authentication. Support WhatsApp: 03333997576.
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between print:hidden">
          <span className="text-xs text-slate-500">
            Tip: Press Ctrl+P or Cmd+P to save as PDF
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-700 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
