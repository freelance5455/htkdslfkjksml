import React from 'react';
import { GameState, CareerTrack } from '../game/types';
import { getCurrentCareerPosition } from '../game/engine';
import { CAREER_TRACKS_INFO } from '../game/careers';
import { Sparkles, Heart, Baby, Home, Car, Shield, Briefcase, Award, Shirt } from 'lucide-react';

interface CharacterShowcaseProps {
  gameState: GameState;
  onOpenRename?: () => void;
}

export const CharacterShowcase: React.FC<CharacterShowcaseProps> = ({
  gameState,
  onOpenRename
}) => {
  const {
    playerName,
    partnerName,
    mood,
    energy,
    hunger,
    fitnessLevel,
    assets,
    path,
    married,
    engaged,
    pregnancyDaysRemaining,
    children,
    currentCareerTrack,
    currentCareerTier,
    familyMood
  } = gameState;

  const currentPos = getCurrentCareerPosition(gameState);

  // 1. Determine Player Outfit & Look
  let playerOutfitName = 'كاجوال شبابي أنيق';
  let playerOutfitIcon = '👕';
  let playerAvatarEmoji = '👨🏻';
  let playerStyleBadge = 'عادي';

  if (path === 'dark' && gameState.gang >= 2) {
    playerOutfitName = 'بدلة زعيم مخملية سوداء';
    playerOutfitIcon = '🕶️';
    playerAvatarEmoji = '🧔🏻‍♂️';
    playerStyleBadge = 'عالم الظلام';
  } else if (currentCareerTrack === 'tech' && currentCareerTier >= 2) {
    playerOutfitName = 'هودي برمجي وسماعات رأس';
    playerOutfitIcon = '🎧';
    playerAvatarEmoji = '👨🏻‍💻';
    playerStyleBadge = 'تقني محترف';
  } else if (currentCareerTrack === 'corporate' && currentCareerTier >= 2) {
    playerOutfitName = currentCareerTier >= 4 ? 'بدلة كبار المدراء التنفيذيين' : 'بدلة إدارية وربطة عنق';
    playerOutfitIcon = '👔';
    playerAvatarEmoji = '👨🏻‍💼';
    playerStyleBadge = 'إدارة ومؤسسات';
  } else if (currentCareerTrack === 'logistics' && currentCareerTier <= 2) {
    playerOutfitName = 'سترة دليفري وخوذة سلامة';
    playerOutfitIcon = '⛑️';
    playerAvatarEmoji = '🛵';
    playerStyleBadge = 'لوجستيات وتوصيل';
  } else if (fitnessLevel >= 5) {
    playerOutfitName = 'ملابس رياضية وجسم رياضي';
    playerOutfitIcon = '🎽';
    playerAvatarEmoji = '🏋🏻‍♂️';
    playerStyleBadge = 'فورمة رياضية';
  } else if (currentCareerTrack === 'commerce' && currentCareerTier >= 3) {
    playerOutfitName = 'بليزر تجار وساعة فاخرة';
    playerOutfitIcon = '⌚';
    playerAvatarEmoji = '🤵🏻‍♂️';
    playerStyleBadge = 'رجل أعمال';
  }

  // 2. Player Expression / Emotion
  let playerExpression = 'راضي ومبتسم 😊';
  let playerAura = 'border-slate-800 from-slate-900 to-slate-950';

  if (energy < 20 || hunger < 20) {
    playerExpression = 'مرهق وبحاجة لراحة وجوع 🥱';
    playerAura = 'border-amber-900/50 from-amber-950/20 to-slate-950';
  } else if (mood >= 75) {
    playerExpression = 'متحمس وفي أوج تألقه 🌟';
    playerAura = 'border-amber-500/40 from-amber-950/30 via-slate-900 to-slate-950 shadow-lg shadow-amber-500/10';
  } else if (mood < 35) {
    playerExpression = 'محبط وقلق 😔';
    playerAura = 'border-purple-900/50 from-purple-950/20 to-slate-950';
  }

  // 3. Partner Outfit & Look
  let partnerOutfit = 'إطلالة رقيقة محبوبة';
  let partnerEmoji = '👩🏻';
  let partnerExpression = 'مرتاحة وسعيدة';

  if (married) {
    if (pregnancyDaysRemaining > 0) {
      partnerOutfit = 'فستان حمل واسع وأنيق 🤰';
      partnerEmoji = '🤰🏻';
      partnerExpression = `حامل (باقي ${pregnancyDaysRemaining} أيام)`;
    } else {
      partnerOutfit = 'أزياء بيت الزوجية الدافئة';
      partnerEmoji = '👰🏻‍♀️';
      partnerExpression = familyMood >= 75 ? 'فخورة ببيتها وزوجها 💖' : 'مستقرة';
    }
  } else if (engaged) {
    partnerOutfit = 'فستان خطوبة ودبلة ذهبية 💍';
    partnerEmoji = '💍 👩🏻‍🦰';
    partnerExpression = 'متشوقة ليوم الزفاف';
  }

  // 4. Housing & Vehicle Badges
  const houseName = assets.includes('villa')
    ? '🏰 فيلا فاخرة بحديقة'
    : assets.includes('home')
    ? '🏠 شقة تمليك مستقرة'
    : assets.includes('flat')
    ? '🏢 شقة إيجار'
    : '📦 سكن بداية متواضع';

  const vehicleName = assets.includes('luxcar')
    ? '🏎️ سيارة رياضية فارهة'
    : assets.includes('car')
    ? '🚗 سيارة عائلية'
    : assets.includes('bike')
    ? '🛵 موتوسيكل سريع'
    : '🚶‍♂️ مواصلات عامة ومشي';

  return (
    <aside className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 shadow-xl space-y-4 text-right">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
            <Sparkles className="w-4 h-4" />
          </span>
          <div>
            <h3 className="text-xs font-black text-slate-100">المظهر وشخصيات العائلة</h3>
            <span className="text-[10px] text-slate-400">يتأثر تلقائياً بأفعالك ووظيفتك</span>
          </div>
        </div>
        <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-amber-300 border border-slate-700 font-bold">
          تفاعلي حي
        </span>
      </div>

      {/* Main Couple Stage View */}
      <div className={`p-4 rounded-2xl bg-gradient-to-b ${playerAura} border relative overflow-hidden transition-all duration-300`}>
        <div className="flex items-center justify-around gap-2 my-2">
          {/* Player Visual */}
          <div className="flex flex-col items-center text-center">
            <div className="relative group">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-tr from-slate-800 to-slate-700 border-2 border-amber-400/50 flex items-center justify-center text-3xl sm:text-4xl shadow-xl transition transform group-hover:scale-105">
                {playerAvatarEmoji}
              </div>
              <span className="absolute -bottom-1 -right-1 p-1 rounded-full bg-slate-900 border border-amber-500 text-xs" title={playerOutfitName}>
                {playerOutfitIcon}
              </span>
            </div>
            <span className="text-xs font-bold text-slate-100 mt-2">{playerName}</span>
            <span className="text-[10px] text-amber-300 font-medium">{playerStyleBadge}</span>
          </div>

          {/* Heart / Bond Center */}
          <div className="flex flex-col items-center justify-center">
            <div className={`p-2 rounded-full ${married ? 'bg-rose-500/20 text-rose-400' : 'bg-slate-800 text-slate-400'} border border-rose-500/30 animate-pulse`}>
              <Heart className="w-4 h-4 fill-rose-500/30" />
            </div>
            <span className="text-[9px] text-slate-400 mt-1 font-mono">
              {married ? 'عش الزوجية' : engaged ? 'مخطوبان' : 'قصة حب'}
            </span>
          </div>

          {/* Partner Visual */}
          <div className="flex flex-col items-center text-center">
            <div className="relative group">
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-tr from-pink-950/60 to-rose-900/40 border-2 border-rose-400/50 flex items-center justify-center text-3xl sm:text-4xl shadow-xl transition transform group-hover:scale-105">
                {partnerEmoji}
              </div>
              {pregnancyDaysRemaining > 0 && (
                <span className="absolute -top-1 -right-1 px-1.5 py-0.2 rounded-full bg-rose-600 text-[9px] text-white font-bold animate-ping">
                  حمل
                </span>
              )}
            </div>
            <span className="text-xs font-bold text-slate-100 mt-2">{partnerName}</span>
            <span className="text-[10px] text-rose-300 font-medium truncate max-w-[80px]">
              {married ? 'الزوجة' : engaged ? 'الخطيبة' : 'الحبيبة'}
            </span>
          </div>
        </div>

        {/* Dynamic Status Badges */}
        <div className="mt-3 pt-3 border-t border-slate-800/80 space-y-1.5 text-[11px]">
          <div className="flex items-center justify-between text-slate-300">
            <span className="text-slate-400 flex items-center gap-1">
              <Shirt className="w-3 h-3 text-cyan-400" />
              مظهر {playerName}:
            </span>
            <span className="font-semibold text-cyan-200">{playerOutfitName}</span>
          </div>

          <div className="flex items-center justify-between text-slate-300">
            <span className="text-slate-400">الحالة النفسية:</span>
            <span className="font-semibold text-slate-200">{playerExpression}</span>
          </div>

          <div className="flex items-center justify-between text-slate-300">
            <span className="text-slate-400 flex items-center gap-1">
              <Heart className="w-3 h-3 text-rose-400" />
              إطلالة {partnerName}:
            </span>
            <span className="font-semibold text-rose-200">{partnerOutfit}</span>
          </div>
        </div>
      </div>

      {/* Children Visual Stage (If any) */}
      {children.length > 0 && (
        <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-200 flex items-center gap-1.5">
              <Baby className="w-4 h-4 text-purple-400" />
              <span>أطفال الأسرة ({children.length})</span>
            </span>
            <span className="text-[10px] text-purple-300">جيل المستقبل</span>
          </div>

          <div className="flex flex-wrap gap-2 pt-1">
            {children.map((kid) => (
              <div
                key={kid.id}
                className="flex items-center gap-2 p-2 rounded-xl bg-slate-900 border border-slate-800/90 text-xs flex-1 min-w-[120px]"
              >
                <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-lg shrink-0">
                  {kid.gender === 'boy' ? '🧒' : '👧'}
                </div>
                <div className="overflow-hidden">
                  <div className="font-bold text-slate-100 truncate text-[11px]">{kid.name}</div>
                  <div className="text-[9px] text-slate-400">
                    {kid.stage === 'nursery' ? 'روضة' : kid.stage === 'primary' ? 'ابتدائي' : kid.stage === 'preparatory' ? 'إعدادي' : kid.stage === 'secondary' ? 'ثانوي' : 'جامعة'}
                    {kid.lastGrade ? ` • ${kid.lastGrade.split(' ')[0]}` : ''}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Living Environment & Vehicle Status */}
      <div className="grid grid-cols-2 gap-2 text-[10px]">
        <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800">
          <span className="text-slate-400 flex items-center gap-1 mb-0.5">
            <Home className="w-3 h-3 text-amber-400" />
            السكن الحالي:
          </span>
          <span className="font-bold text-slate-200 block truncate">{houseName}</span>
        </div>

        <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800">
          <span className="text-slate-400 flex items-center gap-1 mb-0.5">
            <Car className="w-3 h-3 text-cyan-400" />
            وسيلة التنقل:
          </span>
          <span className="font-bold text-slate-200 block truncate">{vehicleName}</span>
        </div>
      </div>

      {/* Career badge */}
      <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800 text-[11px] flex items-center justify-between">
        <span className="text-slate-400 flex items-center gap-1">
          <Briefcase className="w-3.5 h-3.5 text-amber-400" />
          المهنة الحالية:
        </span>
        <span className="font-bold text-amber-300 truncate max-w-[150px]">{currentPos.title}</span>
      </div>
    </aside>
  );
};
