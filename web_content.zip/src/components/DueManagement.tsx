import React, { useState, useEffect } from 'react';
import { Customer, PaymentMethod, SaleInvoice } from '../types/business';
import { StorageService } from '../db/storage';
import {
  BadgeAlert,
  ArrowLeft,
  Phone,
  MessageCircle,
  CreditCard,
  Calendar,
  X,
  CheckCircle2,
  DollarSign,
  Clock,
  Receipt,
  User,
} from 'lucide-react';

interface DueManagementProps {
  lang: 'bn' | 'en';
  onBack: () => void;
  onViewInvoice?: (invoice: SaleInvoice) => void;
  initialCustomerId?: string;
}

export const DueManagement: React.FC<DueManagementProps> = ({
  lang,
  onBack,
  onViewInvoice,
  initialCustomerId,
}) => {
  const [dueList, setDueList] = useState(StorageService.getDueCustomers());
  const [selectedForCollection, setSelectedForCollection] = useState<{
    customer: Customer;
    dueAmount: number;
    latestInvoiceId?: string;
    latestInvoiceNumber?: string;
  } | null>(null);

  // Collect form state
  const [collectAmount, setCollectAmount] = useState<number | ''>('');
  const [collectMethod, setCollectMethod] = useState<'Cash' | 'bKash' | 'Nagad' | 'Bank'>('Cash');
  const [collectNote, setCollectNote] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const refreshDueList = () => {
    setDueList(StorageService.getDueCustomers());
  };

  useEffect(() => {
    refreshDueList();
    if (initialCustomerId) {
      const match = StorageService.getDueCustomers().find((d) => d.customer.id === initialCustomerId);
      if (match) {
        setSelectedForCollection(match);
        setCollectAmount(match.dueAmount);
      }
    }
  }, [initialCustomerId]);

  const handleOpenCollection = (item: any) => {
    setSelectedForCollection(item);
    setCollectAmount(item.dueAmount);
    setCollectMethod('Cash');
    setCollectNote('');
    setSuccessMessage('');
  };

  const handleConfirmCollection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedForCollection) return;
    const amount = Number(collectAmount);
    if (!amount || amount <= 0) return;

    StorageService.recordDuePayment({
      customerId: selectedForCollection.customer.id,
      customerName: selectedForCollection.customer.name,
      invoiceId: selectedForCollection.latestInvoiceId,
      invoiceNumber: selectedForCollection.latestInvoiceNumber,
      amount: amount,
      paymentMethod: collectMethod,
      note: collectNote.trim() || undefined,
    });

    setSuccessMessage(`৳${amount.toLocaleString()} সফলভাবে আদায় হয়েছে!`);
    setTimeout(() => {
      setSelectedForCollection(null);
      setSuccessMessage('');
      refreshDueList();
    }, 1200);
  };

  // WhatsApp Reminder message
  const handleWhatsAppReminder = (item: any) => {
    const profile = StorageService.getBusinessProfile();
    const shopName = profile?.businessName || 'Business Management';
    const text = encodeURIComponent(
      `আসসালামু আলাইকুম ${item.customer.name} ভাই,\n${shopName} থেকে বিনীতভাবে স্মরণ করিয়ে দেওয়া হচ্ছে যে, আপনার কাছে ৳${item.dueAmount.toLocaleString()} টাকা বাকি রয়েছে${item.latestInvoiceNumber ? ` (চালান: ${item.latestInvoiceNumber})` : ''}। অনুগ্রহ করে সুবিধাজনক সময়ে বাকি টাকা পরিশোধ করার জন্য অনুরোধ করা হলো।\nধন্যবাদ!`
    );
    const phone = item.customer.phone.replace(/[^0-9]/g, '');
    window.open(`https://wa.me/${phone}?text=${text}`, '_blank');
  };

  const totalOutstandingDue = dueList.reduce((sum, d) => sum + d.dueAmount, 0);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-24 font-sans">
      {/* Top Header */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-20 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                <BadgeAlert className="w-6 h-6 text-orange-600" />
                <span>{lang === 'bn' ? 'বাকি আদায়ের অ্যালার্ট ও খতিয়ান' : 'Due Collection Center'}</span>
              </h1>
              <p className="text-xs text-slate-500">
                {lang === 'bn'
                  ? `মোট বাকি: ৳${totalOutstandingDue.toLocaleString()} (${dueList.length} জন কাস্টমার)`
                  : `Total Due: ৳${totalOutstandingDue.toLocaleString()} (${dueList.length} customers)`}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-4">
        {dueList.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 max-w-md mx-auto shadow-xs">
            <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-3">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="font-bold text-slate-900 text-base">কোন বকেয়া বাকি নেই!</h3>
            <p className="text-xs text-slate-500 mt-1">
              সব কাস্টমারের বিল পরিশোধিত রয়েছে।
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {dueList.map((item) => (
              <div
                key={item.customer.id}
                className="bg-white rounded-3xl p-5 border-2 border-orange-200/80 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span className="px-2.5 py-1 rounded-xl bg-orange-50 text-orange-800 text-xs font-bold border border-orange-200">
                      বাকি: ৳{item.dueAmount.toLocaleString()}
                    </span>
                    {item.overdueDays > 0 && (
                      <span className="text-[11px] text-slate-500 font-medium flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        <span>{item.overdueDays} দিন ধরে বাকি</span>
                      </span>
                    )}
                  </div>

                  <h3 className="font-bold text-slate-900 text-base leading-tight mt-1">
                    {item.customer.name}
                  </h3>
                  <p className="text-xs text-slate-500 font-mono mt-0.5">{item.customer.phone}</p>
                  {item.customer.address && (
                    <p className="text-xs text-slate-400 mt-0.5">{item.customer.address}</p>
                  )}

                  {item.latestInvoiceNumber && (
                    <div className="mt-3 p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between text-xs">
                      <div>
                        <span className="text-[10px] text-slate-400 block font-medium">সর্বশেষ চালান</span>
                        <span className="font-mono font-bold text-indigo-700">{item.latestInvoiceNumber}</span>
                      </div>
                      {item.dueDate && (
                        <div className="text-right">
                          <span className="text-[10px] text-slate-400 block font-medium">সম্ভাব্য তারিখ</span>
                          <span className="font-bold text-slate-700">{item.dueDate}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <a
                      href={`tel:${item.customer.phone}`}
                      className="p-2.5 rounded-xl bg-blue-50 text-blue-700 hover:bg-blue-100 transition-colors shadow-2xs"
                      title="Call Customer"
                    >
                      <Phone className="w-4 h-4" />
                    </a>
                    <button
                      onClick={() => handleWhatsAppReminder(item)}
                      className="p-2.5 rounded-xl bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition-colors shadow-2xs cursor-pointer"
                      title="Send WhatsApp Due Reminder"
                    >
                      <MessageCircle className="w-4 h-4" />
                    </button>
                  </div>

                  <button
                    onClick={() => handleOpenCollection(item)}
                    className="flex-1 py-2.5 px-4 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-extrabold text-xs shadow-md shadow-orange-500/20 flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <CreditCard className="w-4 h-4" />
                    <span>টাকা আদায় করুন</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* PAYMENT COLLECTION MODAL */}
      {selectedForCollection && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl p-6 border border-slate-100">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-orange-600" />
                <span>বাকি টাকা আদায় / গ্রহণ</span>
              </h3>
              <button
                onClick={() => setSelectedForCollection(null)}
                className="text-slate-400 hover:text-slate-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {successMessage ? (
              <div className="py-8 text-center space-y-2">
                <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto animate-bounce" />
                <h4 className="font-bold text-slate-900 text-base">{successMessage}</h4>
                <p className="text-xs text-slate-500">কাস্টমার বাকি ও ক্যাশ ব্যালেন্স আপডেট হয়েছে।</p>
              </div>
            ) : (
              <form onSubmit={handleConfirmCollection} className="space-y-4">
                <div className="p-3 bg-orange-50 rounded-2xl border border-orange-200">
                  <span className="text-xs font-bold text-slate-900 block">
                    {selectedForCollection.customer.name}
                  </span>
                  <span className="text-xs text-slate-500 block">
                    মোবাইল: {selectedForCollection.customer.phone}
                  </span>
                  <div className="mt-2 flex justify-between text-xs font-extrabold text-orange-900 pt-2 border-t border-orange-200">
                    <span>বর্তমান বকেয়া বাকি:</span>
                    <span>৳{selectedForCollection.dueAmount.toLocaleString()}</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    আদায়কৃত টাকার পরিমাণ (৳) * (আংশিক বা সম্পূর্ণ)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max={selectedForCollection.dueAmount}
                    required
                    value={collectAmount}
                    onChange={(e) => setCollectAmount(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 font-extrabold text-lg text-emerald-700 focus:ring-2 focus:ring-orange-500/20"
                  />
                  <div className="flex gap-2 mt-2">
                    <button
                      type="button"
                      onClick={() => setCollectAmount(selectedForCollection.dueAmount)}
                      className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-bold text-slate-700 cursor-pointer"
                    >
                      সম্পূর্ণ পরিশোধ (৳{selectedForCollection.dueAmount})
                    </button>
                    {selectedForCollection.dueAmount > 500 && (
                      <button
                        type="button"
                        onClick={() => setCollectAmount(Math.round(selectedForCollection.dueAmount / 2))}
                        className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-bold text-slate-700 cursor-pointer"
                      >
                        অর্ধেক পরিশোধ
                      </button>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    পরিশোধের মাধ্যম
                  </label>
                  <div className="grid grid-cols-4 gap-1.5">
                    {(['Cash', 'bKash', 'Nagad', 'Bank'] as const).map((m) => (
                      <button
                        key={m}
                        type="button"
                        onClick={() => setCollectMethod(m)}
                        className={`py-1.5 rounded-xl text-xs font-bold border cursor-pointer ${
                          collectMethod === m
                            ? 'bg-slate-900 text-white border-slate-900'
                            : 'bg-white text-slate-700 border-slate-200'
                        }`}
                      >
                        {m}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    মন্তব্য / নোট (ঐচ্ছিক)
                  </label>
                  <input
                    type="text"
                    value={collectNote}
                    onChange={(e) => setCollectNote(e.target.value)}
                    placeholder="যেমন: দোকানে এসে নগদে জমা দিয়েছেন"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-medium"
                  />
                </div>

                <div className="pt-2 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedForCollection(null)}
                    className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs shadow-md shadow-orange-500/20"
                  >
                    আদায় নিশ্চিত করুন
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
