import { useEffect, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { AudioLines, Clapperboard, House, Plus, Search, Users } from "lucide-react";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getMe } from "@/lib/cutegirls/api";
import type { Me } from "@/lib/cutegirls/model";
import { useSalon } from "@/lib/cutegirls/store";
import { LoginScreen, Onboard, Splash } from "./auth-screens";
import { Composer } from "./composer";

const NAV = [
  { to: "/", label: "الساحة", icon: House },
  { to: "/reels", label: "ريلز", icon: Clapperboard },
  { to: "/subliminals", label: "سيبلمنال", icon: AudioLines },
  { to: "/groups", label: "المجموعات", icon: Users },
  { to: "/search", label: "بحث", icon: Search },
] as const;

export function Shell({ children }: { children: React.ReactNode }) {
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <Splash />;
  if (!user) return <LoginScreen />;
  return <Authed>{children}</Authed>;
}

function Authed({ children }: { children: React.ReactNode }) {
  const tick = useSalon((s) => s.tick);
  const [me, setMe] = useState<Me | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    getMe()
      .then((result) => {
        if (live) {
          setMe(result);
          setError(null);
        }
      })
      .catch((err: unknown) => {
        if (live) setError(err instanceof Error ? err.message : "تعذر التحميل");
      });
    return () => {
      live = false;
    };
  }, [tick]);

  if (error === "Unauthorized") return <LoginScreen />;
  if (error) {
    return (
      <main className="grid min-h-dvh place-items-center px-6 text-center">
        <div>
          <h1 className="font-display text-3xl">تعذر فتح الصالون</h1>
          <p className="mt-2 text-sm text-mute">{error}</p>
        </div>
      </main>
    );
  }
  if (!me) return <Splash label="نقرأ بطاقتك" />;
  if (!me.profile) return <Onboard me={me} onDone={() => useSalon.getState().bump()} />;
  return <Frame me={me}>{children}</Frame>;
}

function Frame({ me, children }: { me: Me; children: React.ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const openCompose = useSalon((s) => s.openCompose);
  const profile = me.profile;
  if (!profile) return null;
  const joined = me.groups.filter((group) => group.joined);

  return (
    <div className="mx-auto grid min-h-dvh w-full max-w-6xl grid-cols-1 md:grid-cols-[15rem_minmax(0,1fr)] xl:grid-cols-[15rem_minmax(0,1fr)_17rem]">
      <aside className="sticky top-0 z-20 hidden h-dvh flex-col gap-6 px-4 py-6 md:flex">
        <Link to="/" className="px-2">
          <p className="text-xs tracking-widest text-rose">SALON</p>
          <span className="font-display text-3xl leading-none">CUTEGIRLS</span>
        </Link>
        <nav className="flex flex-col gap-1">
          {NAV.map((item) => {
            const active = item.to === "/" ? path === "/" : path.startsWith(item.to);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`flex min-h-11 items-center gap-3 rounded-2xl px-3 text-sm ${
                  active ? "bg-paper font-medium text-ink shadow-card" : "text-mute hover:bg-paper/70"
                }`}
              >
                <Icon className="size-4" strokeWidth={1.75} />
                {item.label}
              </Link>
            );
          })}
          <button
            type="button"
            className="mt-3 inline-flex min-h-11 items-center justify-center gap-2 rounded-full bg-rose px-4 text-sm font-medium text-paper"
            onClick={() => openCompose()}
          >
            <Plus className="size-4" />
            نشر
          </button>
        </nav>
        <div className="mt-auto space-y-3">
          <Link to="/u/$username" params={{ username: profile.username }} className="block truncate px-2 text-sm">
            @{profile.username}
          </Link>
          <UserButton />
        </div>
      </aside>
      <div className="min-w-0 px-4 pb-28 pt-4 md:px-2 md:pb-10 md:pt-6">
        <div className="mb-4 flex items-center justify-between md:hidden">
          <Link to="/" className="font-display text-2xl">
            CUTEGIRLS
          </Link>
          <div className="flex items-center gap-4">
            <Link to="/search" search={{ q: "" }} aria-label="بحث" className="grid size-11 place-items-center text-ink">
              <Search className="size-5" />
            </Link>
            <Link to="/u/$username" params={{ username: profile.username }} className="text-sm text-rose">
              حسابي
            </Link>
          </div>
        </div>
        {children}
      </div>
      <aside className="sticky top-0 hidden h-dvh flex-col gap-4 px-4 py-6 xl:flex">
        <Link to="/search" search={{ q: "" }} className="flex min-h-11 items-center rounded-full bg-paper px-4 text-sm text-mute shadow-card">
          بحث عن حساب
        </Link>
        <div className="rounded-3xl bg-paper p-4 shadow-card">
          <h2 className="font-display text-xl">غرفك</h2>
          <ul className="mt-3 space-y-2">
            {joined.map((group) => (
              <li key={group.slug}>
                <Link to="/groups/$slug" params={{ slug: group.slug }} className="flex min-h-11 items-center justify-between gap-2 text-sm">
                  <span className="truncate">{group.name}</span>
                  <span className="tabular-nums text-mute">{group.members}</span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <p className="px-1 text-xs leading-6 text-mute">
          المنشورات ظاهرة لكل من في الصالون. اسمك على البطاقة هو اسم قناتك.
        </p>
      </aside>
      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-ink/10 bg-paper/95 px-2 pt-1 pb-2 backdrop-blur md:hidden">
        <div className="mx-auto grid max-w-lg grid-cols-5">
          {NAV.slice(0, 2).map((item) => (
            <NavIcon key={item.to} item={item} path={path} />
          ))}
          <button type="button" className="grid place-items-center" onClick={() => openCompose()} aria-label="نشر">
            <span className="grid size-11 place-items-center rounded-full bg-rose text-paper">
              <Plus className="size-5" />
            </span>
          </button>
          {NAV.slice(2, 4).map((item) => (
            <NavIcon key={item.to} item={item} path={path} />
          ))}
        </div>
      </nav>
      <Composer groups={joined} />
    </div>
  );
}

function NavIcon({
  item,
  path,
}: {
  item: (typeof NAV)[number];
  path: string;
}) {
  const active = item.to === "/" ? path === "/" : path.startsWith(item.to);
  const Icon = item.icon;
  return (
    <Link to={item.to} className={`grid min-h-12 place-items-center ${active ? "text-rose" : "text-mute"}`} aria-label={item.label}>
      <Icon className="size-5" strokeWidth={1.75} />
    </Link>
  );
}
