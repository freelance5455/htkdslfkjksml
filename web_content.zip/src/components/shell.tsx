import { Link, useRouterState } from "@tanstack/react-router";
import { Landmark, LayoutDashboard, Menu, Repeat, Target, Wallet } from "lucide-react";
import type { ReactNode } from "react";
import { usePortfolio } from "@/lib/portfolio-context";

const LINKS = [
  { to: "/", label: "Áttekintés", icon: LayoutDashboard, exact: true },
  { to: "/eszkozok", label: "Eszközök", icon: Wallet, exact: false },
  { to: "/mozgasok", label: "Mozgások", icon: Landmark, exact: false },
  { to: "/celok", label: "Célok", icon: Target, exact: false },
  { to: "/dijak", label: "Előfizetések", icon: Repeat, exact: false },
  { to: "/beolvasas", label: "Beolvasás", icon: Menu, exact: false },
] as const;

const MOBILE = [
  { to: "/", label: "Áttekintés", icon: LayoutDashboard, exact: true },
  { to: "/eszkozok", label: "Eszközök", icon: Wallet, exact: false },
  { to: "/celok", label: "Célok", icon: Target, exact: false },
  { to: "/dijak", label: "Díjak", icon: Repeat, exact: false },
  { to: "/meg", label: "Még", icon: Menu, exact: false },
] as const;

function Item({
  to,
  label,
  icon: Icon,
  exact,
  compact,
}: {
  to: "/" | "/eszkozok" | "/mozgasok" | "/celok" | "/dijak" | "/beolvasas" | "/meg";
  label: string;
  icon: typeof Wallet;
  exact: boolean;
  compact?: boolean;
}) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const on = exact ? pathname === to : pathname === to;
  return (
    <Link
      to={to}
      aria-current={on ? "page" : undefined}
      className={`flex items-center gap-3 rounded-lg text-sm ${
        compact ? "h-14 flex-col justify-center gap-1 px-1 text-xs" : "h-11 px-3"
      } ${on ? "bg-on-pine/15 text-on-pine" : "text-on-pine/80 hover:bg-on-pine/10"}`}
    >
      <Icon className="size-4" aria-hidden="true" />
      {label}
    </Link>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  const { state, dismissSample, clearAll } = usePortfolio();
  return (
    <div className="min-h-screen">
      <a
        href="#tartalom"
        className="sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-50 focus:rounded-lg focus:bg-surface focus:px-3 focus:py-2"
      >
        Ugrás a tartalomhoz
      </a>
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 flex-col bg-pine text-on-pine md:flex">
        <div className="px-5 pt-7 pb-6">
          <div className="flex items-center gap-3">
            <span className="grid size-9 place-items-center rounded-lg bg-on-pine font-serif text-lg text-pine">Sz</span>
            <div>
              <p className="font-serif text-xl leading-none">Számvetés</p>
              <p className="mt-1 text-xs text-on-pine/70">TBSZ, kripto, célok</p>
            </div>
          </div>
        </div>
        <nav className="flex flex-1 flex-col gap-1 px-3" aria-label="Főmenü">
          {LINKS.map((link) => (
            <Item key={link.to} {...link} />
          ))}
        </nav>
        <p className="px-5 pb-6 text-xs text-on-pine/60">A számok a böngészőben maradnak.</p>
      </aside>
      <div className="md:pl-60">
        <header className="flex items-center gap-3 bg-pine px-4 py-3 text-on-pine md:hidden">
          <span className="grid size-9 place-items-center rounded-lg bg-on-pine font-serif text-lg text-pine">Sz</span>
          <p className="font-serif text-xl">Számvetés</p>
        </header>
        <main id="tartalom" className="mx-auto w-full max-w-6xl px-4 pt-6 pb-24 md:px-8 md:pt-10 md:pb-12">
          {state.sample ? (
            <div className="mb-6 flex flex-col gap-3 rounded-2xl border border-line bg-surface px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
              <p className="text-sm">
                Mintaállomány, hogy látni lehessen a szerkezetet. Amit beírsz, csak ezen a gépen marad.
              </p>
              <div className="flex gap-2">
                <button type="button" className="btn btn-ghost" onClick={dismissSample}>
                  Megtartom
                </button>
                <button type="button" className="btn btn-primary" onClick={clearAll}>
                  Üres lap
                </button>
              </div>
            </div>
          ) : null}
          {children}
          <p className="mt-16 text-xs text-muted">
            Nem befektetési tanács, és TBSZ-adót nem számol. Az árak késhetnek. A Lightyear-kivonat a böngészőben
            bomlik szöveggé, nem töltjük fel.
          </p>
        </main>
      </div>
      <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 bg-pine px-1 pb-1 text-on-pine md:hidden" aria-label="Mobilmenü">
        {MOBILE.map((link) => (
          <Item key={link.to} {...link} compact />
        ))}
      </nav>
    </div>
  );
}
