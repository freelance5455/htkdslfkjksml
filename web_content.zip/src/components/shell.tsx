import { Link, useRouterState } from "@tanstack/react-router";
import { BookOpen, FlaskConical, ListChecks, Orbit } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { hydrateVespera } from "@/lib/store";

const NAV = [
  { to: "/", label: "Path", icon: BookOpen, match: (p: string) => p === "/" || p.startsWith("/lessons") },
  { to: "/sky", label: "Sky", icon: Orbit, match: (p: string) => p.startsWith("/sky") },
  { to: "/labs", label: "Labs", icon: FlaskConical, match: (p: string) => p.startsWith("/labs") },
  { to: "/quiz", label: "Quiz", icon: ListChecks, match: (p: string) => p.startsWith("/quiz") },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    hydrateVespera();
  }, []);

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-20 border-b border-line bg-bg/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-5 py-3">
          <Link to="/" className="group flex items-baseline gap-3">
            <span className="font-display text-2xl tracking-tight text-fg">Vespera</span>
            <span className="hidden text-xs uppercase tracking-widest text-faint sm:inline">Night school</span>
          </Link>
          <nav className="hidden items-center gap-1 md:flex" aria-label="Sections">
            {NAV.map((item) => {
              const on = item.match(path);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={`rounded-full px-4 py-2 text-sm transition-colors duration-200 ${on ? "text-gold" : "text-muted hover:text-fg"}`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl px-5 pt-8 pb-28 md:pb-16">{children}</main>
      <nav
        className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-bg/95 backdrop-blur-md md:hidden"
        aria-label="Sections"
      >
        <ul className="mx-auto grid max-w-lg grid-cols-4">
          {NAV.map((item) => {
            const on = item.match(path);
            const Icon = item.icon;
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className={`flex h-16 flex-col items-center justify-center gap-1 text-xs ${on ? "text-gold" : "text-faint"}`}
                >
                  <Icon className="size-5" strokeWidth={1.75} aria-hidden />
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}
