import { Link, useRouterState } from "@tanstack/react-router";
import { BookOpenText, House, Library, Signpost, SquareCheckBig } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { CREDIT } from "@/data/credit";
import { useStudy } from "@/lib/study-store";

const NAV = [
  { to: "/", label: "الرئيسية", icon: House },
  { to: "/manuale", label: "المنهج", icon: BookOpenText },
  { to: "/segnali", label: "الإشارات", icon: Signpost },
  { to: "/esame", label: "الامتحان", icon: SquareCheckBig },
  { to: "/glossario", label: "القاموس", icon: Library },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  useEffect(() => {
    void useStudy.persist.rehydrate();
  }, []);

  return (
    <div className="min-h-screen pb-24 md:pb-10">
      <header className="sticky top-0 z-30 border-b border-line bg-bg/95 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-4 py-3">
          <Link to="/" className="min-w-0">
            <p className="text-xs tracking-widest text-primary">PATENTE B</p>
            <p className="truncate text-lg font-semibold leading-tight">الرخصة الإيطالية</p>
          </Link>
          <nav className="hidden items-center gap-1 md:flex">
            {NAV.slice(1).map((item) => {
              const on = path === item.to || (item.to !== "/" && path.startsWith(item.to));
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={`rounded-full px-3 py-2 text-sm ${on ? "bg-primary text-primary-fg" : "text-ink hover:bg-soft"}`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-4 py-6">{children}</main>
      <footer className="mx-auto hidden max-w-5xl px-4 pb-8 text-sm text-muted md:block">{CREDIT}</footer>
      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface md:hidden">
        <ul className="grid grid-cols-5">
          {NAV.map((item) => {
            const on = item.to === "/" ? path === "/" : path.startsWith(item.to);
            const Icon = item.icon;
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className={`flex min-h-16 flex-col items-center justify-center gap-1 text-xs ${on ? "text-primary" : "text-muted"}`}
                >
                  <Icon size={18} aria-hidden />
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}
