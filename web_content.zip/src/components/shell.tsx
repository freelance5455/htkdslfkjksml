import { useEffect, useState, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Gauge, House, Library, MousePointerClick, Settings, Wrench } from "lucide-react";
import { applyAppearance } from "@/lib/appearance";
import { stopClicker, useClickerRuntime } from "@/lib/clicker-runtime";
import { useAppStore, useRuntime } from "@/lib/store";
import { SearchBar } from "@/components/search-bar";
import { SessionWake } from "@/components/session-wake";
import { cn } from "@/components/ui";

const NAV = [
  { to: "/", label: "Home", icon: House, exact: true },
  { to: "/games", label: "Games", icon: Library, exact: false },
  { to: "/boost", label: "Boost", icon: Gauge, exact: false },
  { to: "/clicker", label: "Clicker", long: "Auto Clicker", icon: MousePointerClick, exact: false },
  { to: "/tools", label: "Tools", icon: Wrench, exact: false },
  { to: "/settings", label: "Settings", icon: Settings, exact: false },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const hash = useRouterState({ select: (state) => state.location.hash });
  const theme = useAppStore((state) => state.theme);
  const accent = useAppStore((state) => state.accent);
  const background = useAppStore((state) => state.background);
  const density = useAppStore((state) => state.density);
  const motion = useAppStore((state) => state.motion);
  const phase = useClickerRuntime((state) => state.phase);
  const taps = useClickerRuntime((state) => state.taps);
  const storageMode = useRuntime((state) => state.storageMode);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const unsub = useAppStore.persist.onFinishHydration(() => {
      document.documentElement.dataset.ffReady = "1";
      setReady(true);
    });
    if (useAppStore.persist.hasHydrated()) {
      document.documentElement.dataset.ffReady = "1";
      setReady(true);
    } else {
      void useAppStore.persist.rehydrate();
    }
    return unsub;
  }, []);

  useEffect(() => {
    if (!ready) return;
    applyAppearance({ theme, accent, background, density, motion });
    const resolved = theme === "system";
    if (!resolved) return;
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => applyAppearance({ theme, accent, background, density, motion });
    media.addEventListener("change", onChange);
    return () => media.removeEventListener("change", onChange);
  }, [ready, theme, accent, background, density, motion]);

  useEffect(() => {
    if (!hash) return;
    const id = decodeURIComponent(hash.replace(/^#/, ""));
    if (!id || id.startsWith("g-")) return;
    document.getElementById(id)?.scrollIntoView({ block: "start" });
  }, [hash, pathname]);

  const live = phase !== "stopped";

  return (
    <>
      <a className="skip-link" href="#content">
        Skip to content
      </a>
      <SessionWake />
      <header className="sticky top-0 z-30 border-b border-line bg-bg">
        <div className="mx-auto flex w-full max-w-3xl items-center gap-3 px-4 py-3">
          <Link to="/" className="shrink-0 rounded-md">
            <span className="block font-display text-sm font-semibold tracking-widest">FRAMEFORGE</span>
            <span className="block text-xs font-semibold tracking-widest text-primary">BOOYAH</span>
          </Link>
          <SearchBar />
        </div>
      </header>
      <main id="content" className={cn("app-main stack", live && "is-live")}>
        {storageMode === "memory" ? (
          <p role="status" className="panel text-sm text-primary">
            This browser refused local storage. Changes stay in this tab only and will be lost on refresh.
          </p>
        ) : null}
        {storageMode === "unreadable" ? (
          <p role="alert" className="panel text-sm text-primary">
            Saved data could not be read. You are seeing defaults until the next successful save.
          </p>
        ) : null}
        {children}
      </main>
      {live ? (
        <div className="fixed right-3 left-3 z-50" style={{ bottom: "calc(4.6rem + env(safe-area-inset-bottom))" }}>
          <button
            type="button"
            className="flex min-h-14 w-full items-center justify-between rounded-xl bg-primary px-4 text-primary-fg"
            onClick={() => stopClicker("Stopped from the emergency control.")}
          >
            <span className="text-left">
              <span className="block text-xs font-semibold tracking-widest uppercase">
                {phase === "paused" ? "Paused" : phase === "preview" ? "Previewing" : "Running in this app"}
              </span>
              <span className="block text-sm tabular-nums">{taps} practice taps</span>
            </span>
            <span className="font-display text-lg font-semibold">Stop</span>
          </button>
        </div>
      ) : null}
      <nav className="app-dock fixed inset-x-0 bottom-0 z-40" aria-label="Primary">
        <ul className="mx-auto flex w-full max-w-3xl">
          {NAV.map((item) => {
            const active = item.exact ? pathname === item.to : pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <li key={item.to} className="min-w-0 flex-1">
                <Link
                  to={item.to}
                  aria-current={active ? "page" : undefined}
                  aria-label={"long" in item ? item.long : item.label}
                  className={cn(
                    "flex min-h-14 flex-col items-center justify-center gap-0.5 px-0.5 text-xs font-semibold",
                    active ? "text-primary" : "text-faint",
                  )}
                >
                  <Icon className="size-5" strokeWidth={1.75} aria-hidden="true" />
                  <span className="max-w-full truncate">{item.label}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </>
  );
}

export function NotFound() {
  return (
    <div className="stack">
      <h1 className="font-display text-3xl font-semibold">Page not found</h1>
      <p className="text-muted">That screen is not part of FrameForge.</p>
      <Link to="/" className="text-sm font-semibold text-primary">
        Go home
      </Link>
    </div>
  );
}
