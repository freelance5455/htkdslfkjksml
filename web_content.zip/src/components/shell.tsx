import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";
import {
  BookOpen,
  Clock3,
  Compass,
  Home,
  LayoutGrid,
  Moon,
  Pause,
  Play,
  Search,
  SkipBack,
  SkipForward,
  Sun,
} from "lucide-react";
import { Mark } from "@/components/mark";
import { checkPrayerAlerts } from "@/lib/alerts";
import { cn } from "@/lib/cn";
import { usePlayer } from "@/lib/player";
import { usePrefs } from "@/lib/prefs";

const NAV = [
  { to: "/", label: "الرئيسية", icon: Home, exact: true },
  { to: "/quran", label: "المصحف", icon: BookOpen, exact: false },
  { to: "/prayer", label: "الصلاة", icon: Clock3, exact: false },
  { to: "/adhkar", label: "الأذكار", icon: Compass, exact: false },
  { to: "/more", label: "المزيد", icon: LayoutGrid, exact: false },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const theme = usePrefs((s) => s.theme);
  const setTheme = usePrefs((s) => s.setTheme);
  const player = usePlayer();
  const clip = player.playlist[player.index];

  useEffect(() => {
    const id = window.setInterval(() => {
      void checkPrayerAlerts(new Date());
    }, 15000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 border-b border-line bg-ivory/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-5xl items-center gap-3 px-4 py-3">
          <Link to="/" className="flex min-h-11 items-center gap-2">
            <span className="grid size-10 place-items-center rounded-xl bg-emerald-deep text-gold">
              <Mark className="size-6" />
            </span>
            <span>
              <span className="block text-lg font-bold leading-none text-emerald-deep">توبة</span>
              <span className="text-[0.7rem] tracking-widest text-gold">TAWBAH</span>
            </span>
          </Link>
          <p className="hidden flex-1 text-sm text-muted md:block">طريقك إلى التوبة والعبادة والعلم والطمأنينة</p>
          <div className="ms-auto flex items-center gap-1">
            <Link
              to="/search"
              aria-label="بحث"
              className="grid size-11 place-items-center rounded-xl text-ink hover:bg-emerald-soft"
            >
              <Search className="size-5" />
            </Link>
            <button
              type="button"
              aria-label={theme === "dark" ? "الوضع النهاري" : "الوضع الليلي"}
              className="grid size-11 place-items-center rounded-xl text-ink hover:bg-emerald-soft"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            >
              {theme === "dark" ? <Sun className="size-5" /> : <Moon className="size-5" />}
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto grid max-w-5xl md:grid-cols-[220px_1fr]">
        <nav className="hidden border-l border-line p-3 md:block">
          <ul className="sticky top-24 space-y-1">
            {NAV.map((item) => {
              const active = item.exact ? path === item.to : path === item.to || path.startsWith(`${item.to}/`);
              const Icon = item.icon;
              return (
                <li key={item.to}>
                  <Link
                    to={item.to}
                    className={cn(
                      "flex min-h-11 items-center gap-2 rounded-xl px-3 text-sm font-semibold",
                      active ? "bg-emerald-deep text-btn-fg" : "text-ink hover:bg-emerald-soft",
                    )}
                  >
                    <Icon className="size-4" />
                    {item.label}
                  </Link>
                </li>
              );
            })}
            <MoreLinks path={path} />
          </ul>
        </nav>
        <main className="safe-pb min-w-0">{children}</main>
      </div>

      {clip && (
        <div className="fixed inset-x-0 z-40 border-t border-line bg-card/95 px-3 py-2 backdrop-blur md:bottom-3 md:mx-auto md:max-w-xl md:rounded-2xl md:border bottom-[calc(4.4rem+env(safe-area-inset-bottom))]">
          <div className="mx-auto flex max-w-3xl items-center gap-2">
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-bold">{clip.title}</p>
              {player.error && <p className="truncate text-xs text-danger">{player.error}</p>}
            </div>
            <button type="button" className="grid size-11 place-items-center" aria-label="السابق" onClick={() => player.prev()}>
              <SkipForward className="size-5" />
            </button>
            <button
              type="button"
              className="grid size-11 place-items-center rounded-full bg-btn text-btn-fg"
              aria-label={player.playing ? "إيقاف" : "تشغيل"}
              onClick={() => player.toggle()}
            >
              {player.playing ? <Pause className="size-5" /> : <Play className="size-5" />}
            </button>
            <button type="button" className="grid size-11 place-items-center" aria-label="التالي" onClick={() => player.next()}>
              <SkipBack className="size-5" />
            </button>
          </div>
        </div>
      )}

      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-card/95 backdrop-blur md:hidden">
        <ul className="grid grid-cols-5 pb-[env(safe-area-inset-bottom)]">
          {NAV.map((item) => {
            const active = item.exact ? path === item.to : path === item.to || path.startsWith(`${item.to}/`);
            const Icon = item.icon;
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className={cn(
                    "flex min-h-14 flex-col items-center justify-center gap-0.5 text-[0.68rem] font-semibold",
                    active ? "text-emerald" : "text-muted",
                  )}
                >
                  <Icon className="size-5" />
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}

function MoreLinks({ path }: { path: string }) {
  const links = [
    ["/reciters", "التلاوات"],
    ["/adhan", "الأذان"],
    ["/tasbeeh", "السبحة"],
    ["/prophets", "قصص الأنبياء"],
    ["/sunnah", "السنن"],
    ["/seerah", "السيرة"],
    ["/names", "الأسماء الحسنى"],
    ["/learn", "تعليم الإسلام"],
    ["/hadith", "الحديث"],
    ["/companions", "الصحابة والعلماء"],
    ["/qibla", "القبلة والتقويم"],
    ["/quiz", "الاختبارات"],
    ["/progress", "المتابعة"],
    ["/settings", "الإعدادات"],
  ] as const;
  return (
    <li className="pt-3">
      <p className="px-3 pb-1 text-xs font-bold text-gold">الأقسام</p>
      <ul className="space-y-0.5">
        {links.map(([to, label]) => (
          <li key={to}>
            <Link
              to={to}
              className={cn(
                "block rounded-lg px-3 py-2 text-sm",
                path === to || path.startsWith(`${to}/`) ? "bg-gold-soft font-semibold" : "text-muted hover:bg-ivory-2",
              )}
            >
              {label}
            </Link>
          </li>
        ))}
      </ul>
    </li>
  );
}
