import { Link, useRouterState } from "@tanstack/react-router";
import { ChevronRight, ClipboardList, House, Settings, Tags } from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { useHydrated } from "@/lib/flock/store";

const NAV = [
  { to: "/", label: "النظرة", icon: House },
  { to: "/flock", label: "القطيع", icon: Tags },
  { to: "/log", label: "السجلات", icon: ClipboardList },
  { to: "/more", label: "الإعدادات", icon: Settings },
] as const;

function navActive(path: string, to: string) {
  if (to === "/") return path === "/";
  if (to === "/flock") return path === "/flock" || path.startsWith("/sheep");
  return path === to || path.startsWith(`${to}/`);
}

export function AppShell({
  title,
  backTo,
  action,
  children,
}: {
  title: string;
  backTo?: "/" | "/flock" | "/log" | "/more";
  action?: ReactNode;
  children: ReactNode;
}) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  useHydrated();

  return (
    <div className="min-h-dvh overflow-x-hidden bg-background text-foreground">
      <div className="mx-auto flex min-h-dvh w-full max-w-lg min-w-0 flex-col">
        <header className="sticky top-0 z-20 flex items-center gap-2 border-b border-border bg-background px-4 pt-safe pb-3">
          {backTo ? (
            <Link
              to={backTo}
              aria-label="رجوع"
              className="flex size-11 items-center justify-center rounded-lg text-foreground"
            >
              <ChevronRight className="size-5" />
            </Link>
          ) : null}
          <h1 className="min-w-0 flex-1 truncate text-lg font-semibold leading-tight">
            {title}
          </h1>
          {action ? <div className="shrink-0">{action}</div> : null}
        </header>
        <main className="rise min-w-0 flex-1 px-4 py-4 pb-nav">{children}</main>
      </div>
      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-background pb-[env(safe-area-inset-bottom)]">
        <div className="mx-auto grid max-w-lg grid-cols-4">
          {NAV.map((item) => {
            const active = navActive(path, item.to);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "flex min-h-14 flex-col items-center justify-center gap-1 text-xs font-medium",
                  active ? "text-foreground" : "text-muted-foreground",
                )}
              >
                <Icon className="size-5" strokeWidth={1.75} />
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
