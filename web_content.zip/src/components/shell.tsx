import { Link, Navigate, useRouterState } from "@tanstack/react-router";
import {
  ChartNoAxesColumn,
  FileCheck,
  House,
  Library,
  MessagesSquare,
  Shield,
  WifiOff,
} from "lucide-react";
import type { ReactNode } from "react";
import { t } from "@/content/copy";
import { useEdu } from "@/components/edu-provider";
import { RedirectToSignIn, UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { useLocale, type Locale } from "@/lib/locale";
import { cn } from "@/lib/cn";
import { useOnline } from "@/lib/use-online";

const links = [
  { to: "/", key: "home", icon: House, exact: true },
  { to: "/learn", key: "learn", icon: Library, exact: false },
  { to: "/exams", key: "exams", icon: FileCheck, exact: false },
  { to: "/tutor", key: "tutor", icon: MessagesSquare, exact: false },
  { to: "/progress", key: "progress", icon: ChartNoAxesColumn, exact: false },
] as const;

export function LanguageToggle({ locale, onChange }: { locale: Locale; onChange: (locale: Locale) => void }) {
  return (
    <div className="flex rounded-md border border-line bg-card p-0.5" role="group" aria-label={t(locale, "language")}>
      {(
        [
          ["en", "English"],
          ["am", "አማርኛ"],
        ] as const
      ).map(([value, label]) => (
        <button
          key={value}
          type="button"
          aria-pressed={locale === value}
          onClick={() => onChange(value)}
          className={cn(
            "min-h-11 rounded-md px-3 text-sm font-semibold transition-[background-color,color] duration-[var(--motion-fast)] ease-[var(--ease-smooth-out)]",
            locale === value ? "bg-teal text-card" : "text-muted",
          )}
        >
          {label}
        </button>
      ))}
    </div>
  );
}

function Brand({ locale }: { locale: Locale }) {
  return (
    <Link to="/" className="flex min-h-11 items-center gap-2">
      <span className="grid h-9 w-9 place-items-center rounded-md bg-teal text-sm font-semibold text-card">ሄ</span>
      <span className="leading-tight">
        <span className="block max-w-32 truncate text-sm font-semibold sm:max-w-none">{t(locale, "brand")}</span>
        <span className="hidden text-sm text-muted sm:block">{t(locale, "tagline")}</span>
      </span>
    </Link>
  );
}

export function AppFrame({ children }: { children: ReactNode }) {
  const { user, isPending } = useCurrentUserState();
  const { profile, loading } = useEdu();
  const locale = useLocale((state) => state.locale);
  if (isPending || (user && loading)) return <ScreenSkeleton label={t(locale, "loading")} />;
  if (!user) return <RedirectToSignIn />;
  if (!profile) return <Navigate to="/welcome" />;
  return <Shell>{children}</Shell>;
}

export function ScreenSkeleton({ label }: { label: string }) {
  return (
    <main className="mx-auto flex min-h-dvh max-w-3xl flex-col gap-4 px-4 py-8">
      <p className="text-sm text-muted">{label}</p>
      <div className="h-24 animate-pulse rounded-2xl bg-paper-2" />
      <div className="grid grid-cols-2 gap-3">
        <div className="h-28 animate-pulse rounded-2xl bg-paper-2" />
        <div className="h-28 animate-pulse rounded-2xl bg-paper-2" />
      </div>
    </main>
  );
}

function Shell({ children }: { children: ReactNode }) {
  const locale = useLocale((state) => state.locale);
  const { profile, setLanguage } = useEdu();
  const online = useOnline();
  const path = useRouterState({ select: (state) => state.location.pathname });

  return (
    <div className="min-h-dvh bg-paper text-ink">
      <header className="sticky top-0 z-20 border-b border-line bg-paper/95 backdrop-blur-sm">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-2">
          <Brand locale={locale} />
          <div className="flex items-center gap-2">
            {!online ? (
              <span className="inline-flex min-h-11 items-center gap-1 text-sm font-semibold text-danger">
                <WifiOff className="size-4" aria-hidden="true" />
                {t(locale, "offline")}
              </span>
            ) : null}
            <LanguageToggle locale={locale} onChange={setLanguage} />
          </div>
        </div>
      </header>
      <div className="mx-auto grid max-w-5xl md:grid-cols-[13.5rem_minmax(0,1fr)]">
        <aside className="hidden border-r border-line px-3 py-6 md:block">
          <nav className="flex flex-col gap-1">
            {links.map((item) => {
              const active = item.exact ? path === item.to : path === item.to || path.startsWith(`${item.to}/`);
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "flex min-h-11 items-center gap-2 rounded-md px-3 text-sm font-semibold",
                    active ? "bg-foam text-teal-deep" : "text-ink hover:bg-paper-2",
                  )}
                >
                  <Icon className="size-4" aria-hidden="true" />
                  {t(locale, item.key)}
                </Link>
              );
            })}
            {profile?.role === "admin" ? (
              <Link
                to="/admin"
                className={cn(
                  "flex min-h-11 items-center gap-2 rounded-md px-3 text-sm font-semibold",
                  path.startsWith("/admin") ? "bg-foam text-teal-deep" : "text-ink hover:bg-paper-2",
                )}
              >
                <Shield className="size-4" aria-hidden="true" />
                {t(locale, "admin")}
              </Link>
            ) : null}
          </nav>
          <div className="mt-8">
            <UserButton />
          </div>
        </aside>
        <main className="px-4 pb-28 pt-5 md:px-8 md:pb-12 md:pt-8">{children}</main>
      </div>
      <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-card pb-[env(safe-area-inset-bottom)] md:hidden">
        <ul className="mx-auto grid max-w-lg grid-cols-5">
          {links.map((item) => {
            const active = item.exact ? path === item.to : path === item.to || path.startsWith(`${item.to}/`);
            const Icon = item.icon;
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className={cn(
                    "flex min-h-14 flex-col items-center justify-center gap-0.5 text-sm font-semibold",
                    active ? "text-teal" : "text-muted",
                  )}
                >
                  <Icon className="size-5" aria-hidden="true" />
                  {t(locale, item.key)}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}

export function PageTitle({ title, lede }: { title: string; lede?: string }) {
  return (
    <header className="mb-6">
      <h1 className="text-2xl font-semibold tracking-tight text-ink">{title}</h1>
      {lede ? <p className="mt-2 max-w-prose text-muted">{lede}</p> : null}
    </header>
  );
}
