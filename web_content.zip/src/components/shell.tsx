import type { ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

const LINKS = [
  { to: "/", label: "Home", exact: true },
  { to: "/create", label: "Create storyboard", exact: false },
  { to: "/storyboards", label: "My storyboards", exact: false },
  { to: "/settings", label: "Settings", exact: true },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (state) => state.location.pathname });
  return (
    <div className="min-h-dvh">
      <header className="sticky top-0 z-20 border-b border-line bg-bg/95">
        <div className="mx-auto flex w-full max-w-5xl flex-col gap-3 px-4 py-3">
          <Link to="/" className="font-display text-xl leading-none font-medium tracking-tight">
            Storyboard AI
          </Link>
          <nav className="flex gap-2 overflow-x-auto pb-1">
            {LINKS.map((link) => {
              const on =
                link.exact
                  ? path === link.to
                  : link.to === "/storyboards"
                    ? path.startsWith("/storyboards")
                    : path === link.to || path.startsWith(`${link.to}/`);
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  className={cn(
                    "inline-flex min-h-11 shrink-0 items-center rounded-md px-3 text-sm font-medium",
                    on ? "bg-accent text-accent-fg" : "text-muted",
                  )}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl px-4 py-6 pb-16">{children}</main>
    </div>
  );
}
