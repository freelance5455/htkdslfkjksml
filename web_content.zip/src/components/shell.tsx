import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, Moon, Search, Sun, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Crest } from "@/components/motif";

const NAV = [
  { to: "/", label: "الرئيسية", exact: true },
  { to: "/names", label: "أسماء الله الحسنى", exact: false },
  { to: "/quran", label: "القرآن والتدبر", exact: false },
  { to: "/hadith", label: "السنة النبوية", exact: false },
  { to: "/library", label: "المكتبة", exact: false },
  { to: "/media", label: "المحاضرات والوسائط", exact: true },
  { to: "/creation", label: "التأمل في الخلق", exact: false },
  { to: "/behavior", label: "الإيمان والسلوك", exact: false },
  { to: "/campaign", label: "الأنشطة والفعاليات", exact: true },
  { to: "/contests", label: "المسابقات", exact: true },
  { to: "/about", label: "من نحن", exact: true },
] as const;

function ThemeToggle() {
  function toggle() {
    const next = document.documentElement.classList.toggle("dark");
    localStorage.setItem("li-annahu-theme", next ? "dark" : "light");
  }

  return (
    <button
      type="button"
      onClick={toggle}
      className="inline-flex size-11 items-center justify-center rounded-full border border-line bg-surface"
      aria-label="تبديل المظهر"
    >
      <Sun className="hidden size-5 dark:block" />
      <Moon className="size-5 dark:hidden" />
    </button>
  );
}

function Intro() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    try {
      if (!localStorage.getItem("li-annahu-intro")) setOpen(true);
    } catch {
      setOpen(false);
    }
  }, []);

  if (!open) return null;

  function close() {
    localStorage.setItem("li-annahu-intro", "1");
    setOpen(false);
  }

  return (
    <div className="no-print fixed inset-0 z-50 flex items-center justify-center bg-canvas px-4">
      <div className="geo-fade pointer-events-none absolute inset-0 opacity-40" />
      <div className="relative max-w-xl text-center">
        <Crest className="spin-slow mx-auto size-24" />
        <p className="mt-6 text-sm text-olive">منصة تعليمية للتعظيم والمحبة</p>
        <h1 className="mt-3 font-display text-5xl leading-tight text-primary">لأنّه الله، نحبّه ونعظّمه</h1>
        <p className="mt-4 text-lg leading-relaxed text-muted">
          كلما ازددنا معرفة بربنا، ازددنا له محبة وتعظيمًا.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <button type="button" onClick={close} className="rounded-full bg-primary px-6 py-3 text-primary-fg">
            ادخل
          </button>
          <button type="button" onClick={close} className="rounded-full border border-line px-6 py-3">
            تخطي
          </button>
        </div>
      </div>
    </div>
  );
}

export function SiteShell({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (state) => state.location.pathname });

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") setOpen(false);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <>
      <Intro />
      <a
        href="#content"
        className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:m-3 focus:rounded-full focus:bg-surface focus:px-4 focus:py-2"
      >
        تخطي إلى المحتوى
      </a>
      <header className="no-print sticky top-0 z-40 border-b border-line bg-canvas/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <Link to="/" className="flex min-w-0 items-center gap-3">
            <Crest className="size-11 shrink-0" />
            <span className="min-w-0">
              <span className="block truncate font-display text-2xl leading-none text-primary">لأنّه الله</span>
              <span className="mt-1 block text-xs text-olive">نحبّه ونعظّمه</span>
            </span>
          </Link>
          <div className="ms-auto flex items-center gap-2">
            <Link
              to="/search"
              search={{ q: "" }}
              className="inline-flex size-11 items-center justify-center rounded-full border border-line bg-surface"
              aria-label="البحث"
            >
              <Search className="size-5" />
            </Link>
            <ThemeToggle />
            <button
              type="button"
              className="inline-flex size-11 items-center justify-center rounded-full border border-line bg-surface lg:hidden"
              aria-expanded={open}
              aria-controls="mobile-nav"
              onClick={() => setOpen((value) => !value)}
            >
              {open ? <X className="size-5" /> : <Menu className="size-5" />}
              <span className="sr-only">القائمة</span>
            </button>
          </div>
        </div>
        <nav className="mx-auto hidden max-w-6xl gap-1 overflow-x-auto px-4 pb-3 lg:flex" aria-label="الأقسام">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              activeOptions={{ exact: item.exact }}
              className="shrink-0 rounded-full px-3 py-2 text-sm text-muted"
              activeProps={{ className: "shrink-0 rounded-full bg-soft px-3 py-2 text-sm font-medium text-primary" }}
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </header>
      {open ? (
        <div className="no-print fixed inset-0 z-50 lg:hidden">
          <button type="button" className="absolute inset-0 bg-ink/40" aria-label="إغلاق القائمة" onClick={() => setOpen(false)} />
          <nav
            id="mobile-nav"
            className="absolute inset-y-0 start-0 flex w-80 max-w-[86%] flex-col gap-1 overflow-y-auto bg-surface p-4 shadow-none"
            aria-label="قائمة الأقسام"
          >
            <p className="px-2 pb-2 font-display text-2xl text-primary">الأقسام</p>
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                activeOptions={{ exact: item.exact }}
                className="rounded-2xl px-3 py-3 text-base"
                activeProps={{ className: "rounded-2xl bg-soft px-3 py-3 text-base text-primary" }}
              >
                {item.label}
              </Link>
            ))}
            <Link to="/search" search={{ q: "" }} className="rounded-2xl px-3 py-3">
              البحث
            </Link>
          </nav>
        </div>
      ) : null}
      <div id="content">{children}</div>
      <footer className="no-print mt-16 border-t border-line">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 md:grid-cols-4">
          <div className="md:col-span-2">
            <p className="font-display text-3xl text-primary">لأنّه الله، نحبّه ونعظّمه</p>
            <p className="mt-3 max-w-md text-sm leading-7 text-muted">
              منصة تعليمية مستقلة تُعرّف بأسماء الله والحملة الدعوية من المصادر العلنية. ليست الموقع الرسمي لوزارة الأوقاف، ولا تدّعي اعتمادًا حكوميًا.
            </p>
          </div>
          <div>
            <p className="text-sm font-medium text-olive">أقسام</p>
            <ul className="mt-3 space-y-2 text-sm">
              <li><Link to="/names">الأسماء الحسنى</Link></li>
              <li><Link to="/quran">القرآن والتدبر</Link></li>
              <li><Link to="/hadith">السنة</Link></li>
              <li><Link to="/creation">التأمل في الخلق</Link></li>
              <li><Link to="/campaign">الحملة</Link></li>
            </ul>
          </div>
          <div>
            <p className="text-sm font-medium text-olive">مراجع وسياسة</p>
            <ul className="mt-3 space-y-2 text-sm">
              <li><Link to="/about">المنهج والمصادر</Link></li>
              <li><Link to="/privacy">الخصوصية</Link></li>
              <li><Link to="/report">الإبلاغ عن خطأ</Link></li>
              <li><Link to="/guide">البحث في المحتوى</Link></li>
              <li>
                <a href="https://x.com/SyMOfE" rel="noreferrer">حساب الوزارة</a>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-line py-4 text-center text-xs leading-6 text-muted">
          المحتوى الشرعي يُراجع بشريًا قبل الاعتماد. التقدم التعليمي يُحفظ على جهازك فقط.
        </div>
      </footer>
    </>
  );
}
