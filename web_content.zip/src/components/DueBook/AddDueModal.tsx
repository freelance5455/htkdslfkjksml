import React, { useState, useEffect } from 'react';
import { 
  X, 
  Plus, 
  Minus,
  Trash2, 
  User, 
  Phone, 
  ShoppingBag, 
  AlertCircle,
  Check,
  BookOpen,
  Edit3,
  Calendar,
  Clock
} from 'lucide-react';
import { Product, CartItem, UnitType, SaleInvoice } from '../../types';
import { toBnNum } from '../../utils/formatters';

interface AddDueModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onSaveDue: (invoiceData: Omit<SaleInvoice, 'id' | 'invoiceNo' | 'createdAt'>) => void;
  onUpdateDue?: (invoiceId: string, invoiceData: Partial<SaleInvoice>) => void;
  initialInvoice?: SaleInvoice | null;
  initialCustomerName?: string;
  initialCustomerPhone?: string;
  cashierName: string;
}

const COMMON_UNITS: UnitType[] = ['কেজি', 'গ্রাম', 'লিটার', 'মিলি', 'প্যাকেট', 'পিস', 'ডজন', 'হালি', 'বস্তা', 'বক্স'];

export const AddDueModal: React.FC<AddDueModalProps> = ({
  isOpen,
  onClose,
  products,
  onSaveDue,
  onUpdateDue,
  initialInvoice,
  initialCustomerName = '',
  initialCustomerPhone = '',
  cashierName,
}) => {
  const isEditMode = Boolean(initialInvoice);

  // Customer info
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');

  // Current item being added
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const [itemName, setItemName] = useState('');
  const [itemQuantity, setItemQuantity] = useState<string>('১');
  const [itemUnit, setItemUnit] = useState<UnitType>('কেজি');
  const [itemPrice, setItemPrice] = useState<string>('');

  // Items in this due voucher
  const [dueItems, setDueItems] = useState<CartItem[]>([]);

  // Financials
  const [discount, setDiscount] = useState<string>('০');
  const [paidAmount, setPaidAmount] = useState<string>('০');
  const [notes, setNotes] = useState('');

  // Error message
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Populate form based on initialInvoice or initialCustomer props
  useEffect(() => {
    if (!isOpen) return;

    if (initialInvoice) {
      setCustomerName(initialInvoice.customerName || '');
      setCustomerPhone(initialInvoice.customerPhone || '');
      setDueItems(initialInvoice.items ? initialInvoice.items.map(it => ({ ...it })) : []);
      setDiscount(toBnNum(initialInvoice.discount || 0));
      setPaidAmount(toBnNum(initialInvoice.paidAmount || 0));
      setNotes(initialInvoice.notes || '');
    } else {
      setCustomerName(initialCustomerName || '');
      setCustomerPhone(initialCustomerPhone || '');
      setDueItems([]);
      setDiscount('০');
      setPaidAmount('০');
      setNotes('');
      setSelectedProductId('');
      setItemName('');
      setItemQuantity('১');
      setItemPrice('');
    }
    setErrorMsg(null);
  }, [isOpen, initialInvoice, initialCustomerName, initialCustomerPhone]);

  if (!isOpen) return null;

  // Handle product dropdown selection
  const handleProductSelect = (productId: string) => {
    setSelectedProductId(productId);
    if (!productId) {
      setItemName('');
      setItemPrice('');
      return;
    }
    const prod = products.find(p => p.id === productId);
    if (prod) {
      setItemName(prod.nameBn);
      setItemUnit(prod.unit);
      setItemPrice(String(prod.sellPrice));
    }
  };

  // Convert Bengali numerals if typed to english for math
  const parseNum = (val: string | number): number => {
    if (typeof val === 'number') return isNaN(val) ? 0 : val;
    if (!val) return 0;
    const bnToEnMap: Record<string, string> = {
      '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4',
      '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9'
    };
    const normalized = String(val).replace(/[০-৯]/g, (d) => bnToEnMap[d] || d);
    const parsed = parseFloat(normalized);
    return isNaN(parsed) ? 0 : parsed;
  };

  // Add item to due list
  const handleAddItem = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMsg(null);

    const name = itemName.trim();
    if (!name) {
      setErrorMsg('পণ্যের নাম প্রদান করুন');
      return;
    }

    const qty = parseNum(itemQuantity);
    if (qty <= 0) {
      setErrorMsg('সঠিক পরিমাণ উল্লেখ করুন');
      return;
    }

    const price = parseNum(itemPrice);
    if (price < 0) {
      setErrorMsg('সঠিক মূল্য নির্ধারণ করুন');
      return;
    }

    const matchedProd = products.find(p => p.id === selectedProductId || p.nameBn.trim().toLowerCase() === name.toLowerCase());

    const newItem: CartItem = {
      id: 'due-item-' + Date.now() + Math.random().toString().slice(2, 6),
      productId: matchedProd ? matchedProd.id : 'custom-' + Date.now(),
      nameBn: name,
      nameEn: matchedProd ? matchedProd.nameEn : name,
      category: matchedProd ? matchedProd.category : 'অন্যান্য',
      purchasePrice: matchedProd ? matchedProd.purchasePrice : Math.round(price * 0.85),
      sellPrice: price,
      unit: itemUnit,
      quantity: qty,
      discount: 0,
      lineTotal: +(qty * price).toFixed(2),
      lineCost: +(qty * (matchedProd ? matchedProd.purchasePrice : price * 0.85)).toFixed(2),
    };

    setDueItems(prev => [...prev, newItem]);

    // Reset input fields
    setSelectedProductId('');
    setItemName('');
    setItemQuantity('১');
    setItemPrice('');
  };

  // Inline quantity changer
  const handleQuantityDelta = (itemId: string, delta: number) => {
    setDueItems(prev => prev.map(item => {
      if (item.id === itemId) {
        const newQty = Math.max(0.25, +(item.quantity + delta).toFixed(2));
        const lineTotal = +(newQty * item.sellPrice).toFixed(2);
        const lineCost = +(newQty * item.purchasePrice).toFixed(2);
        return {
          ...item,
          quantity: newQty,
          lineTotal,
          lineCost,
        };
      }
      return item;
    }));
  };

  // Remove item
  const handleRemoveItem = (id: string) => {
    setDueItems(prev => prev.filter(i => i.id !== id));
  };

  // Append timestamp log to notes
  const handleAppendTimeNote = () => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' });
    const dateStr = now.toLocaleDateString('bn-BD');
    const stamp = `[${dateStr}, ${timeStr} এ পণ্য নিল]`;
    setNotes(prev => prev ? `${prev} | ${stamp}: ` : `${stamp}: `);
  };

  // Calculations
  const subtotal = dueItems.reduce((sum, item) => sum + item.lineTotal, 0);
  const discountVal = parseNum(discount);
  const netTotal = Math.max(0, +(subtotal - discountVal).toFixed(2));
  const paidVal = parseNum(paidAmount);
  const dueAmount = Math.max(0, +(netTotal - paidVal).toFixed(2));
  const totalCost = dueItems.reduce((sum, item) => sum + item.lineCost, 0);
  const grossProfit = +(netTotal - totalCost).toFixed(2);

  // Form submit
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const name = customerName.trim();
    if (!name) {
      setErrorMsg('দয়া করে গ্রাহকের নাম লিখুন');
      return;
    }

    if (dueItems.length === 0) {
      setErrorMsg('গ্রাহক কি কি পণ্য বাকি নিল তা যোগ করুন');
      return;
    }

    if (dueAmount < 0) {
      setErrorMsg('বাকি টাকার পরিমাণ সঠিক নয়');
      return;
    }

    if (isEditMode && initialInvoice && onUpdateDue) {
      // EDIT MODE: Update existing invoice
      onUpdateDue(initialInvoice.id, {
        customerName: name,
        customerPhone: customerPhone.trim(),
        items: dueItems,
        subtotal,
        discount: discountVal,
        netTotal,
        paidAmount: paidVal,
        changeAmount: 0,
        dueAmount,
        totalCost,
        grossProfit,
        status: dueAmount === 0 ? 'PAID' : (paidVal > 0 ? 'PARTIAL' : 'DUE'),
        notes: notes.trim() || undefined,
      });
    } else {
      // CREATE MODE: Add new invoice
      onSaveDue({
        customerName: name,
        customerPhone: customerPhone.trim(),
        items: dueItems,
        subtotal,
        discount: discountVal,
        netTotal,
        paidAmount: paidVal,
        changeAmount: 0,
        dueAmount,
        paymentMethod: 'DUE',
        cashierName,
        totalCost,
        grossProfit,
        status: dueAmount === 0 ? 'PAID' : (paidVal > 0 ? 'PARTIAL' : 'DUE'),
        notes: notes.trim() || undefined,
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden my-6 flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className={`text-white p-4 flex items-center justify-between shrink-0 transition-colors ${
          isEditMode ? 'bg-amber-800' : 'bg-amber-700'
        }`}>
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-black/20 rounded-xl">
              {isEditMode ? (
                <Edit3 className="w-5 h-5 text-amber-200" />
              ) : (
                <BookOpen className="w-5 h-5 text-amber-200" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base sm:text-lg">
                  {isEditMode ? 'বাকির খাতা এডিট ও পণ্য আপডেট' : 'নতুন বাকির খাতা এন্ট্রি'}
                </h3>
                {isEditMode && initialInvoice && (
                  <span className="text-[11px] bg-amber-950/60 px-2 py-0.5 rounded-full font-mono text-amber-200 border border-amber-500/40">
                    {initialInvoice.invoiceNo}
                  </span>
                )}
              </div>
              <p className="text-xs text-amber-200/90">
                {isEditMode 
                  ? 'গ্রাহক নতুন পণ্য নিলে যোগ করুন বা আগের পণ্যের পরিমাণ ও নগদ জমা আপডেট করুন' 
                  : 'গ্রাহকের নাম ও কি কি পণ্য কতো পরিমাণ বাকি নিল তা লিখে রাখুন'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-amber-200 hover:text-white hover:bg-black/20 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form Body */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 overflow-y-auto space-y-5 text-xs sm:text-sm">
          
          {errorMsg && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              <span className="font-semibold text-xs">{errorMsg}</span>
            </div>
          )}

          {isEditMode && (
            <div className="p-3 bg-amber-50 border border-amber-300/80 rounded-xl flex items-center justify-between text-xs text-amber-900">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-700 shrink-0" />
                <span>
                  <strong>এডিটিং মোড:</strong> যারা দিনে ২-৩ বার বা পরবর্তীতে এসে পণ্য নেয়, তাদের এই তালিকায় নতুন পণ্য যোগ করতে পারবেন।
                </span>
              </div>
              <button
                type="button"
                onClick={handleAppendTimeNote}
                className="shrink-0 px-2.5 py-1 bg-amber-700 hover:bg-amber-800 text-white rounded-lg text-[11px] font-semibold flex items-center gap-1 shadow-2xs"
                title="নোটে বর্তমান সময় ও তারিখ যুক্ত করুন"
              >
                <Calendar className="w-3 h-3" />
                <span>+ তারিখ/সময় নোট যোগ</span>
              </button>
            </div>
          )}

          {/* Section 1: Customer Details */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
            <h4 className="font-bold text-slate-800 flex items-center gap-2 text-xs uppercase tracking-wider text-amber-900">
              <User className="w-3.5 h-3.5 text-amber-700" />
              <span>১. গ্রাহকের পরিচিতি</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  গ্রাহকের নাম <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="যেমন: মো: রফিক উদ্দিন, আলমগীর ভাই"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm font-semibold focus:ring-2 focus:ring-amber-600 focus:outline-hidden"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  মোবাইল নম্বর (ঐচ্ছিক)
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="tel"
                    placeholder="০১৭১২-৩৪৫৬৭৮"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-white border border-slate-300 rounded-lg text-sm font-mono focus:ring-2 focus:ring-amber-600 focus:outline-hidden"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Products Taken on Credit */}
          <div className="bg-amber-50/60 p-4 rounded-xl border border-amber-200 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-amber-950 flex items-center gap-2 text-xs uppercase tracking-wider">
                <ShoppingBag className="w-3.5 h-3.5 text-amber-800" />
                <span>২. {isEditMode ? 'আরো পণ্য বাকি যোগ করুন বা তালিকা পরিবর্তন করুন' : 'কি কি পণ্য ও কতো পরিমাণ বাকি নিল'}</span>
              </h4>
              <span className="text-[11px] text-amber-800 font-medium">
                দোকানের পণ্য সিলেক্ট করুন অথবা নাম লিখে দিন
              </span>
            </div>

            {/* Product selection fields */}
            <div className="bg-white p-3.5 rounded-xl border border-amber-200 shadow-2xs space-y-3">
              
              {/* Select from existing store items */}
              <div>
                <label className="block text-slate-600 font-semibold mb-1 text-[11px]">
                  দোকানের বিদ্যমান পণ্য থেকে সিলেক্ট করুন (সহজ উপায়):
                </label>
                <select
                  value={selectedProductId}
                  onChange={(e) => handleProductSelect(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-amber-600"
                >
                  <option value="">-- তালিকার পণ্য পছন্দ করুন (অথবা নিচে নতুন লিখুন) --</option>
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.nameBn} — বর্তমান দর: ৳{p.sellPrice}/{p.unit} (স্টক: {p.stock} {p.unit})
                    </option>
                  ))}
                </select>
              </div>

              {/* Custom item name, quantity, unit, price */}
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-end">
                <div className="sm:col-span-5">
                  <label className="block text-slate-700 font-semibold mb-1 text-[11px]">
                    পণ্যের নাম <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="যেমন: দেশি পেঁয়াজ, চিনি, ডিম"
                    value={itemName}
                    onChange={(e) => {
                      setItemName(e.target.value);
                      setSelectedProductId('');
                    }}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-amber-600"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-slate-700 font-semibold mb-1 text-[11px]">
                    পরিমাণ <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="যেমন: ২ বা ১.৫"
                    value={itemQuantity}
                    onChange={(e) => setItemQuantity(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-bold text-center focus:ring-2 focus:ring-amber-600"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-slate-700 font-semibold mb-1 text-[11px]">
                    একক
                  </label>
                  <select
                    value={itemUnit}
                    onChange={(e) => setItemUnit(e.target.value as UnitType)}
                    className="w-full px-2 py-2 border border-slate-300 rounded-lg text-xs bg-white focus:ring-2 focus:ring-amber-600"
                  >
                    {COMMON_UNITS.map(u => (
                      <option key={u} value={u}>{u}</option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-slate-700 font-semibold mb-1 text-[11px]">
                    একক দর (৳) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="৳ দর"
                    value={itemPrice}
                    onChange={(e) => setItemPrice(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-bold focus:ring-2 focus:ring-amber-600"
                  />
                </div>

                <div className="sm:col-span-1">
                  <button
                    type="button"
                    onClick={() => handleAddItem()}
                    className="w-full py-2 bg-amber-700 hover:bg-amber-800 text-white rounded-lg flex items-center justify-center font-bold shadow-xs transition"
                    title="পণ্যটি বাকির তালিকায় যোগ করুন"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Items Table with quantity adjustment */}
            {dueItems.length === 0 ? (
              <div className="p-4 text-center bg-white/80 rounded-xl border border-dashed border-amber-300 text-amber-800 text-xs">
                এখনো কোনো পণ্য যোগ করা হয়নি। উপরের ফর্ম থেকে পণ্যের নাম, পরিমাণ ও দর লিখে <span className="font-bold">+ যোগ করুন</span> চাপুন।
              </div>
            ) : (
              <div className="bg-white rounded-xl border border-amber-200 overflow-hidden shadow-2xs">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-amber-100/70 text-amber-900 border-b border-amber-200 font-bold">
                      <th className="py-2 px-3">ক্রমিক</th>
                      <th className="py-2 px-3">পণ্যের বিবরণ</th>
                      <th className="py-2 px-3 text-center">পরিমাণ ও পরিবর্তন</th>
                      <th className="py-2 px-3 text-right">একক দর</th>
                      <th className="py-2 px-3 text-right">মোট টাকা</th>
                      <th className="py-2 px-3 text-center w-10">মুছুন</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-amber-100">
                    {dueItems.map((item, idx) => (
                      <tr key={item.id} className="hover:bg-amber-50/50">
                        <td className="py-2.5 px-3 text-slate-500 font-mono text-center">
                          {toBnNum(idx + 1)}
                        </td>
                        <td className="py-2.5 px-3 font-semibold text-slate-900">
                          {item.nameBn}
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <div className="inline-flex items-center gap-1.5 bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-200">
                            <button
                              type="button"
                              onClick={() => handleQuantityDelta(item.id, -1)}
                              className="p-0.5 hover:bg-amber-200 rounded text-amber-900 font-bold transition"
                              title="পরিমাণ ১ কমান"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="font-bold text-amber-950 font-mono px-1 min-w-[3rem] text-center">
                              {toBnNum(item.quantity)} {item.unit}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleQuantityDelta(item.id, 1)}
                              className="p-0.5 hover:bg-amber-200 rounded text-amber-900 font-bold transition"
                              title="পরিমাণ ১ বাড়ান"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono text-slate-700">
                          ৳{toBnNum(item.sellPrice)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                          ৳{toBnNum(item.lineTotal)}
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(item.id)}
                            className="p-1 text-red-500 hover:text-red-700 hover:bg-red-50 rounded transition"
                            title="মুছে ফেলুন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="bg-amber-50 font-bold text-amber-950 border-t border-amber-200">
                      <td colSpan={4} className="py-2 px-3 text-right">মোট পণ্যের বিল:</td>
                      <td className="py-2 px-3 text-right font-mono font-bold text-sm text-amber-900">
                        ৳{toBnNum(subtotal)}
                      </td>
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}
          </div>

          {/* Section 3: Financials & Due Calculation */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
            <h4 className="font-bold text-slate-800 text-xs uppercase tracking-wider text-amber-900">
              ৩. টাকার হিসাব ও বাকি সমন্বয়
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  সর্বমোট পণ্যের বিল:
                </label>
                <div className="px-3 py-2 bg-slate-100 border border-slate-300 rounded-lg font-mono font-bold text-sm text-slate-800">
                  ৳ {toBnNum(subtotal)}
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  ছাড় / ডিসকাউন্ট (ঐচ্ছিক):
                </label>
                <input
                  type="text"
                  placeholder="০"
                  value={discount}
                  onChange={(e) => setDiscount(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm font-mono font-semibold focus:ring-2 focus:ring-amber-600"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  নগদ জমা / দেওয়া টাকা (ঐচ্ছিক):
                </label>
                <input
                  type="text"
                  placeholder="০"
                  value={paidAmount}
                  onChange={(e) => setPaidAmount(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-sm font-mono font-semibold focus:ring-2 focus:ring-amber-600"
                />
              </div>
            </div>

            {/* Total Due Highlight Card */}
            <div className="p-3 bg-amber-100/80 border border-amber-300 rounded-xl flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-amber-900 block">
                  গ্রাহকের মোট বকেয়া / বাকি থাকবে:
                </span>
                <span className="text-[11px] text-amber-800">
                  (মোট বিল {toBnNum(subtotal)} ৳ {discountVal > 0 ? `- ছাড় ${toBnNum(discountVal)} ৳ ` : ''}{paidVal > 0 ? `- জমা ${toBnNum(paidVal)} ৳` : ''})
                </span>
              </div>
              <div className="text-xl sm:text-2xl font-bold font-mono text-amber-800 tabular-nums">
                ৳ {toBnNum(dueAmount)}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-slate-700 font-semibold">
                  বিশেষ বিবরণ / তারিখ নোট (ঐচ্ছিক):
                </label>
                <button
                  type="button"
                  onClick={handleAppendTimeNote}
                  className="text-[11px] text-amber-800 hover:text-amber-900 font-semibold flex items-center gap-1"
                >
                  <Clock className="w-3 h-3" />
                  <span>+ সময় স্ট্যাম্প যুক্ত করুন</span>
                </button>
              </div>
              <textarea
                rows={2}
                placeholder="যেমন: সকালে ২ কেজি ডাল নিল, বিকেলে আবার ১ কেজি চিনি ও বিস্কুট নিল"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-amber-600"
              />
            </div>
          </div>

          {/* Footer Action Buttons */}
          <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold transition"
            >
              বাতিল
            </button>
            <button
              type="submit"
              className={`flex items-center gap-2 px-5 py-2.5 text-white rounded-xl font-bold shadow-md transition ${
                isEditMode ? 'bg-amber-800 hover:bg-amber-900' : 'bg-amber-700 hover:bg-amber-800'
              }`}
            >
              <Check className="w-4 h-4 text-amber-200" />
              <span>{isEditMode ? 'পরিবর্তন ও আপডেট সংরক্ষণ করুন' : 'বাকির খাতায় সেভ করুন'}</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
