import React, { useState, useMemo } from 'react';
import { 
  BookOpen, 
  Search, 
  Phone, 
  User, 
  Clock, 
  MessageSquare, 
  CheckCircle2, 
  DollarSign, 
  Share2, 
  X,
  AlertCircle,
  Plus,
  ReceiptText,
  Package,
  Calendar,
  Edit3
} from 'lucide-react';
import { CustomerDueRecord, SaleInvoice, StoreProfile, Product } from '../../types';
import { formatBengaliDateTime, toBnNum } from '../../utils/formatters';
import { AddDueModal } from './AddDueModal';

interface DueBookViewProps {
  customerDues: CustomerDueRecord[];
  onPayDue: (invoiceId: string, amount: number, notes?: string) => void;
  onUpdateDue?: (invoiceId: string, invoiceData: Partial<SaleInvoice>) => void;
  storeProfile: StoreProfile;
  invoices: SaleInvoice[];
  products: Product[];
  onAddNewDue: (invoiceData: Omit<SaleInvoice, 'id' | 'invoiceNo' | 'createdAt'>) => void;
  onViewReceipt?: (invoice: SaleInvoice) => void;
  cashierName?: string;
}

export const DueBookView: React.FC<DueBookViewProps> = ({
  customerDues,
  onPayDue,
  onUpdateDue,
  storeProfile,
  invoices,
  products,
  onAddNewDue,
  onViewReceipt,
  cashierName = 'মালিক',
}) => {
  const [search, setSearch] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerDueRecord | null>(null);
  const [isAddDueOpen, setIsAddDueOpen] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<SaleInvoice | null>(null);
  const [prefilledCustomer, setPrefilledCustomer] = useState<{ name: string; phone: string } | null>(null);

  // Payment modal state
  const [payInvoiceId, setPayInvoiceId] = useState<string>('');
  const [payAmount, setPayAmount] = useState<string>('');
  const [payNotes, setPayNotes] = useState<string>('');

  const filteredCustomers = useMemo(() => {
    return customerDues.filter((c) => {
      const q = search.toLowerCase().trim();
      if (!q) return true;
      return (
        c.customerName.toLowerCase().includes(q) ||
        (c.customerPhone && c.customerPhone.includes(q))
      );
    });
  }, [customerDues, search]);

  const totalOutstandingDue = useMemo(() => {
    return customerDues.reduce((sum, c) => sum + c.totalDue, 0);
  }, [customerDues]);

  // Send WhatsApp reminder with complete item list and quantities
  const handleSendReminder = (customer: CustomerDueRecord) => {
    // Collect all items across customer's due invoices
    const allItemsSummary: string[] = [];
    customer.invoices.forEach((inv) => {
      if (inv.items && inv.items.length > 0) {
        inv.items.forEach((item) => {
          allItemsSummary.push(`• ${item.nameBn}: ${item.quantity} ${item.unit} (৳${item.lineTotal})`);
        });
      }
    });

    const itemsSection = allItemsSummary.length > 0
      ? `\n*বাকি নেওয়া পণ্যসমূহ:*\n${allItemsSummary.join('\n')}\n`
      : '';

    const message = `শ্রদ্ধেয় ${customer.customerName},
${storeProfile.name} থেকে সালাম ও শুভেচ্ছা।

আপনার পূর্ববর্তী কেনাকাটার অবশিষ্ট বকেয়া বাকি রয়েছে মোট: *৳ ${customer.totalDue}*।
${itemsSection}
অনুরোধপূর্বক সুবিধাজনক সময়ে বাকি টাকা পরিশোধ করে দোকান পরিচালনাকে বেগবান রাখুন।

দোকানের ঠিকানা: ${storeProfile.address}
মোবাইল: ${storeProfile.phone}
ধন্যবাদ!`;

    const encoded = encodeURIComponent(message);
    const cleanPhone = customer.customerPhone.replace(/[^0-9]/g, '');
    const url = cleanPhone ? `https://wa.me/88${cleanPhone}?text=${encoded}` : `https://wa.me/?text=${encoded}`;
    window.open(url, '_blank');
  };

  const handleOpenPayment = (customer: CustomerDueRecord, invoiceId: string, dueAmt: number) => {
    setSelectedCustomer(customer);
    setPayInvoiceId(invoiceId);
    setPayAmount(String(dueAmt));
    setPayNotes('');
  };

  const handleSubmitPayment = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(payAmount);
    if (!payInvoiceId || isNaN(amt) || amt <= 0) {
      alert('সঠিক টাকার অঙ্ক প্রদান করুন');
      return;
    }
    onPayDue(payInvoiceId, amt, payNotes);
    setPayInvoiceId('');
    setSelectedCustomer(null);
  };

  const handleOpenReceiptForInvoice = (invoiceId: string) => {
    if (!onViewReceipt) return;
    const inv = invoices.find(i => i.id === invoiceId);
    if (inv) {
      onViewReceipt(inv);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Header with Title, Total Due and Add Due Button */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-amber-700" />
            <span>ডিজিটাল বাকির খাতা (Customer Due Ledger)</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            কে কে বাকি নিল, কি কি পণ্য ও কতো পরিমাণ নিল তার বিস্তারিত হিসাব ও তাগাদা
          </p>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
          {/* Total Outstanding Card */}
          <div className="bg-amber-50 border border-amber-300 px-4 py-2 rounded-2xl flex items-center gap-2.5 shadow-2xs">
            <div className="p-1.5 rounded-xl bg-amber-100 text-amber-900">
              <AlertCircle className="w-4 h-4 text-amber-700" />
            </div>
            <div>
              <span className="text-[10px] font-semibold text-amber-900 uppercase tracking-wider block">
                সর্বমোট পাওনা বাকি
              </span>
              <span className="text-lg sm:text-xl font-bold font-mono text-amber-800 tabular-nums">
                ৳ {toBnNum(totalOutstandingDue)}
              </span>
            </div>
          </div>

          {/* New Due Button */}
          <button
            onClick={() => setIsAddDueOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-amber-700 hover:bg-amber-800 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md transition shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>নতুন বাকি এন্ট্রি</span>
          </button>
        </div>
      </div>

      {/* Search Input */}
      <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="কাস্টমারের নাম অথবা ফোন নম্বর দিয়ে বাকির খাতা খুঁজুন..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-amber-600 focus:bg-white"
          />
        </div>
      </div>

      {/* Customers List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredCustomers.length === 0 ? (
          <div className="col-span-full py-16 text-center bg-white rounded-2xl border border-dashed border-slate-300 p-6 space-y-3">
            <CheckCircle2 className="w-12 h-12 text-emerald-600 mx-auto" />
            <h4 className="font-bold text-slate-800 text-base">কোনো গ্রাহকের বাকি নেই!</h4>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              দোকানে কারো বকেয়া বাকি নেই অথবা সার্চের সাথে কোনো গ্রাহক মিলছে না। নতুন কোনো গ্রাহক বাকি নিলে উপরের <strong>"নতুন বাকি এন্ট্রি"</strong> বাটনে চাপ দিন।
            </p>
            <button
              onClick={() => setIsAddDueOpen(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-700 hover:bg-amber-800 text-white rounded-xl text-xs font-bold transition shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>প্রথম বাকির এন্ট্রি যোগ করুন</span>
            </button>
          </div>
        ) : (
          filteredCustomers.map((customer, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs hover:border-amber-400 transition flex flex-col justify-between"
            >
              <div>
                {/* Customer Info Header */}
                <div className="flex items-start justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center font-bold text-sm">
                      {customer.customerName.charAt(0) || 'ক'}
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 text-sm">{customer.customerName}</h3>
                      <div className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                        <Phone className="w-3 h-3 text-slate-400" />
                        <span>{customer.customerPhone || 'মোবাইল নেই'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">মোট বাকি</span>
                    <div className="text-base font-bold font-mono text-amber-700 tabular-nums">
                      ৳{toBnNum(customer.totalDue)}
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const customerInv = invoices.find(i => i.id === customer.invoices[0]?.invoiceId);
                        if (customerInv) {
                          setEditingInvoice(customerInv);
                        } else {
                          setPrefilledCustomer({ name: customer.customerName, phone: customer.customerPhone });
                          setIsAddDueOpen(true);
                        }
                      }}
                      className="mt-1 px-2 py-0.5 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-300 rounded-md text-[10px] font-semibold flex items-center gap-1 ml-auto transition"
                      title="এই গ্রাহকের বাকি হিসেবে আরো পণ্য যোগ করুন"
                    >
                      <Plus className="w-2.5 h-2.5 text-amber-700" />
                      <span>+ পণ্য যোগ</span>
                    </button>
                  </div>
                </div>

                {/* Due Invoices with Products & Quantities Breakdown */}
                <div className="mt-3 space-y-2.5">
                  <div className="flex items-center justify-between text-[11px] font-semibold text-slate-600">
                    <span>বকেয়া মেমো ({toBnNum(customer.invoices.length)} টি):</span>
                    <span className="text-[10px] text-amber-800 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                      পণ্য ও পরিমাণ তালিকা
                    </span>
                  </div>

                  <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                    {customer.invoices.map((inv) => (
                      <div
                        key={inv.invoiceId}
                        className="p-2.5 bg-slate-50 hover:bg-amber-50/40 rounded-xl text-xs border border-slate-200/80 transition space-y-2"
                      >
                        {/* Memo header */}
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-mono font-bold text-slate-800">{inv.invoiceNo}</div>
                            <div className="text-[10px] text-slate-400 flex items-center gap-1">
                              <Calendar className="w-2.5 h-2.5" />
                              <span>{new Date(inv.date).toLocaleDateString('bn-BD')}</span>
                            </div>
                          </div>

                          <div className="text-right">
                            <span className="font-mono font-bold text-amber-800 text-sm">
                              ৳{toBnNum(inv.dueAmount)} বাকি
                            </span>
                            {inv.paidAmount !== undefined && inv.paidAmount > 0 && (
                              <div className="text-[10px] text-emerald-700 font-medium">
                                (জমা: ৳{toBnNum(inv.paidAmount)})
                              </div>
                            )}
                          </div>
                        </div>

                        {/* List of Products & Quantities taken on Credit */}
                        {inv.items && inv.items.length > 0 ? (
                          <div className="pt-1.5 border-t border-slate-200/60">
                            <span className="text-[10px] font-bold text-slate-600 block mb-1">
                              কি কি পণ্য বাকি নিয়েছে:
                            </span>
                            <div className="flex flex-wrap gap-1">
                              {inv.items.map((it, itemIdx) => (
                                <span
                                  key={itemIdx}
                                  className="inline-flex items-center gap-1 px-2 py-0.5 bg-white text-slate-800 border border-amber-200 rounded-md text-[11px]"
                                >
                                  <span className="font-semibold text-slate-900">{it.nameBn}</span>
                                  <span className="text-amber-800 font-bold bg-amber-100/70 px-1 rounded">
                                    {toBnNum(it.quantity)} {it.unit}
                                  </span>
                                  <span className="text-slate-500 font-mono text-[10px]">
                                    (৳{toBnNum(it.lineTotal)})
                                  </span>
                                </span>
                              ))}
                            </div>
                          </div>
                        ) : (
                          <div className="text-[10px] text-slate-400 italic">
                            (মেমোর সাধারণ বকেয়া হিসাব)
                          </div>
                        )}

                        {/* Notes if available */}
                        {inv.notes && (
                          <div className="text-[10px] text-slate-600 bg-amber-100/50 p-1.5 rounded border border-amber-200/50">
                            <strong>নোট:</strong> {inv.notes}
                          </div>
                        )}

                        {/* Actions for this invoice */}
                        <div className="pt-1 flex items-center justify-end gap-1.5 flex-wrap">
                          {onViewReceipt && (
                            <button
                              type="button"
                              onClick={() => handleOpenReceiptForInvoice(inv.invoiceId)}
                              className="px-2 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded text-[11px] font-semibold flex items-center gap-1 transition"
                              title="ক্যাশ মেমো দেখুন"
                            >
                              <ReceiptText className="w-3 h-3" />
                              <span>মেমো</span>
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => {
                              const fullInv = invoices.find(i => i.id === inv.invoiceId);
                              if (fullInv) {
                                setEditingInvoice(fullInv);
                              }
                            }}
                            className="px-2 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 rounded text-[11px] font-semibold flex items-center gap-1 transition"
                            title="পণ্য যোগ বা হিসাব এডিট করুন"
                          >
                            <Edit3 className="w-3 h-3 text-amber-700" />
                            <span>এডিট / পণ্য যোগ</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleOpenPayment(customer, inv.invoiceId, inv.dueAmount)}
                            className="px-2.5 py-1 bg-emerald-800 hover:bg-emerald-700 text-white rounded text-[11px] font-semibold transition"
                          >
                            পরিশোধ গ্রহণ
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Bottom WhatsApp Reminder Button */}
              <div className="mt-4 pt-3 border-t border-slate-100">
                <button
                  onClick={() => handleSendReminder(customer)}
                  className="w-full py-2 px-3 bg-green-50 text-green-800 border border-green-300 hover:bg-green-100 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition"
                >
                  <Share2 className="w-3.5 h-3.5 text-green-700" />
                  <span>হোয়াটসঅ্যাপে বাকি ও পণ্যের তাগাদা পাঠান</span>
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Due Payment Modal */}
      {selectedCustomer && payInvoiceId && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 pb-2">
              <h3 className="font-bold text-slate-900 text-sm">বাকি টাকা পরিশোধ গ্রহণ</h3>
              <button
                onClick={() => {
                  setSelectedCustomer(null);
                  setPayInvoiceId('');
                }}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs space-y-1">
              <div className="flex justify-between">
                <span>গ্রাহক:</span>
                <span className="font-semibold text-slate-800">{selectedCustomer.customerName}</span>
              </div>
            </div>

            <form onSubmit={handleSubmitPayment} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  পরিশোধের পরিমাণ (টাকা):
                </label>
                <input
                  type="number"
                  value={payAmount}
                  onChange={(e) => setPayAmount(e.target.value)}
                  className="w-full px-3 py-2 text-base font-bold font-mono border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-600"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  নোট / মন্তব্য (ঐচ্ছিক):
                </label>
                <input
                  type="text"
                  placeholder="যেমন: নগদ পরিশোধ করল"
                  value={payNotes}
                  onChange={(e) => setPayNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedCustomer(null);
                    setPayInvoiceId('');
                  }}
                  className="flex-1 py-2 bg-slate-100 text-slate-700 rounded-lg font-medium"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-emerald-800 text-white rounded-lg font-bold hover:bg-emerald-700"
                >
                  পরিশোধ গ্রহণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add / Edit Due Modal */}
      <AddDueModal
        isOpen={isAddDueOpen || Boolean(editingInvoice)}
        onClose={() => {
          setIsAddDueOpen(false);
          setEditingInvoice(null);
          setPrefilledCustomer(null);
        }}
        products={products}
        onSaveDue={onAddNewDue}
        onUpdateDue={onUpdateDue}
        initialInvoice={editingInvoice}
        initialCustomerName={prefilledCustomer?.name || ''}
        initialCustomerPhone={prefilledCustomer?.phone || ''}
        cashierName={cashierName}
      />

    </div>
  );
};
