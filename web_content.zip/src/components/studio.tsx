import { useEffect, useMemo, useState } from "react";
import { Download, History, PenLine, RotateCcw, SquarePen } from "lucide-react";
import { generateApp } from "@/lib/generate-app";

type Saved = {
  id: string;
  title: string;
  brief: string;
  html: string;
};

const STARTERS = [
  {
    label: "Do‘kon",
    brief:
      "O‘zbekcha kichik bozor ilovasi: 8 ta mahsulot, qidiruv, savat va jami summa. Narxlar so‘mda. Mahsulot qo‘shish va olib tashlash ishlasin.",
  },
  {
    label: "Kun tartibi",
    brief:
      "Kunlik reja: vazifa qo‘shish, belgilash, o‘chirish. Bugungi sana ko‘rinsin. Ma’lumot shu brauzerda saqlansin.",
  },
  {
    label: "Menyu",
    brief:
      "Choyxona menyusi: taomlar bo‘limlari, narx, tanlangan taomlar ro‘yxati va hisob. Dizayn iliq, qog‘ozdek.",
  },
  {
    label: "Viktorina",
    brief:
      "O‘zbekiston haqida 8 savollik viktorina. Har savolda 4 variant, oxirida ball va qayta boshlash.",
  },
  {
    label: "Moliya",
    brief:
      "Oddiy xarajat daftari: kirim va chiqim qo‘shish, qoldiq, oxirgi 10 yozuv. So‘mda hisoblansin.",
  },
  {
    label: "Eslatma",
    brief:
      "Rangli eslatmalar doskasi: yangi eslatma, tahrir, o‘chirish. Ma’lumot sahifani yangilaganda ham qolsin.",
  },
];

const STORAGE_KEY = "cheksiz-shelf";

function readShelf(): Saved[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Saved[];
    return Array.isArray(parsed) ? parsed.slice(0, 8) : [];
  } catch {
    return [];
  }
}

function titleOf(html: string, brief: string) {
  const match = html.match(/<title>([^<]{1,80})<\/title>/i);
  const title = match?.[1]?.trim();
  if (title) return title;
  return brief.slice(0, 42);
}

export function Studio() {
  const [brief, setBrief] = useState(STARTERS[0].brief);
  const [note, setNote] = useState("");
  const [html, setHtml] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [shelf, setShelf] = useState<Saved[]>([]);
  const [showShelf, setShowShelf] = useState(false);
  const [frameKey, setFrameKey] = useState(0);

  useEffect(() => {
    setShelf(readShelf());
  }, []);

  const title = useMemo(() => (html ? titleOf(html, brief) : "Hali sahifa yo‘q"), [html, brief]);

  function persist(next: Saved) {
    const list = [next, ...readShelf().filter((item) => item.id !== next.id)].slice(0, 8);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
    setShelf(list);
  }

  async function run(instruction: string, previous?: string) {
    const text = instruction.trim();
    if (text.length < 2 || busy) return;
    setBusy(true);
    setError("");
    try {
      const result = await generateApp({ data: { brief: text, previousHtml: previous } });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      setHtml(result.html);
      setFrameKey((n) => n + 1);
      setNote("");
      persist({
        id: crypto.randomUUID(),
        title: titleOf(result.html, text),
        brief: text,
        html: result.html,
      });
    } catch {
      setError("Ulanish uzildi. Yana bir marta bosing.");
    } finally {
      setBusy(false);
    }
  }

  function download() {
    if (!html) return;
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${title.replace(/[^\p{L}\p{N}]+/gu, "-").replace(/^-|-$/g, "") || "ilova"}.html`;
    link.click();
    URL.revokeObjectURL(url);
  }

  function reset() {
    setHtml("");
    setNote("");
    setError("");
    setBrief("");
  }

  return (
    <main className="mx-auto grid min-h-screen w-full max-w-6xl grid-cols-1 gap-4 px-4 py-4 lg:grid-cols-[22rem_minmax(0,1fr)] lg:px-6 lg:py-6">
      <section className="flex min-w-0 flex-col gap-4">
        <header className="px-1 pt-2">
          <p className="text-xs font-medium tracking-widest text-copper uppercase">Ustaxona</p>
          <h1 className="font-display text-5xl leading-none font-medium text-ink">Cheksiz</h1>
          <p className="mt-2 max-w-xs text-sm leading-relaxed text-muted">
            Veb-ilovani so‘zlab bering. Kredit yo‘q — har safar yasash tugmasini bosing.
          </p>
        </header>

        <div className="flex w-full gap-2 overflow-x-auto pb-1">
          {STARTERS.map((item) => (
            <button
              key={item.label}
              type="button"
              onClick={() => setBrief(item.brief)}
              className="shrink-0 rounded-full border border-line bg-paper px-3 py-2 text-sm text-ink"
            >
              {item.label}
            </button>
          ))}
        </div>

        <label className="flex flex-col gap-2 rounded-card border border-line bg-paper p-3">
          <span className="flex items-center gap-2 text-sm font-medium">
            <PenLine className="size-4 text-copper" aria-hidden="true" />
            Nima yasaymiz
          </span>
          <textarea
            value={brief}
            onChange={(event) => setBrief(event.target.value)}
            rows={7}
            placeholder="Masalan: oilaviy taomlar daftari, retsept qo‘shish va qidiruv bilan."
            className="min-h-36 resize-none bg-transparent text-sm leading-relaxed outline-none"
          />
          <button
            type="button"
            disabled={busy || brief.trim().length < 2}
            onClick={() => run(brief)}
            className="inline-flex h-12 items-center justify-center rounded-full bg-copper px-4 text-sm font-medium text-copper-ink disabled:opacity-50"
          >
            {busy ? "Terilmoqda…" : "Yasash"}
          </button>
        </label>

        {html ? (
          <label className="flex flex-col gap-2 rounded-card border border-line bg-paper p-3">
            <span className="flex items-center gap-2 text-sm font-medium">
              <SquarePen className="size-4 text-copper" aria-hidden="true" />
              Shu ilovani o‘zgartirish
            </span>
            <textarea
              value={note}
              onChange={(event) => setNote(event.target.value)}
              rows={3}
              placeholder="Masalan: tun rejimini qo‘sh, tugmalarni kattaroq qil."
              className="resize-none bg-transparent text-sm leading-relaxed outline-none"
            />
            <button
              type="button"
              disabled={busy || note.trim().length < 2}
              onClick={() => run(note, html)}
              className="inline-flex h-11 items-center justify-center rounded-full border border-ink px-4 text-sm font-medium disabled:opacity-50"
            >
              Qo‘llash
            </button>
          </label>
        ) : null}

        {error ? (
          <p className="rounded-card border border-line bg-paper px-3 py-2 text-sm text-copper" role="alert">
            {error}
          </p>
        ) : null}

        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={download}
            disabled={!html}
            className="inline-flex h-11 items-center gap-2 rounded-full border border-line bg-paper px-4 text-sm disabled:opacity-40"
          >
            <Download className="size-4" aria-hidden="true" />
            HTML
          </button>
          <button
            type="button"
            onClick={() => setShowShelf((open) => !open)}
            className="inline-flex h-11 items-center gap-2 rounded-full border border-line bg-paper px-4 text-sm"
          >
            <History className="size-4" aria-hidden="true" />
            Javon
          </button>
          <button
            type="button"
            onClick={reset}
            className="inline-flex h-11 items-center gap-2 rounded-full border border-line bg-paper px-4 text-sm"
          >
            <RotateCcw className="size-4" aria-hidden="true" />
            Toza
          </button>
        </div>

        {showShelf ? (
          <ul className="flex flex-col gap-2">
            {shelf.length === 0 ? (
              <li className="text-sm text-muted">Hali saqlangan ilova yo‘q.</li>
            ) : (
              shelf.map((item) => (
                <li key={item.id}>
                  <button
                    type="button"
                    onClick={() => {
                      setHtml(item.html);
                      setBrief(item.brief);
                      setFrameKey((n) => n + 1);
                      setError("");
                    }}
                    className="w-full rounded-card border border-line bg-paper px-3 py-3 text-left"
                  >
                    <span className="block text-sm font-medium">{item.title}</span>
                    <span className="mt-1 block truncate text-xs text-muted">{item.brief}</span>
                  </button>
                </li>
              ))
            )}
          </ul>
        ) : null}
      </section>

      <section className="flex min-h-[70vh] min-w-0 flex-col overflow-hidden rounded-card border border-line bg-ink">
        <div className="flex items-center justify-between gap-3 px-4 py-3 text-copper-ink">
          <p className="truncate font-display text-lg">{title}</p>
          <span className="shrink-0 text-xs tracking-wide text-line uppercase">Ko‘rinish</span>
        </div>
        <div className="relative min-h-0 flex-1 bg-paper">
          {html ? (
            <iframe
              key={frameKey}
              title={title}
              sandbox="allow-scripts allow-forms"
              srcDoc={html}
              className="h-full min-h-[70vh] w-full bg-paper"
            />
          ) : (
            <div className="flex h-full min-h-[70vh] flex-col justify-end p-6">
              <p className="font-display text-4xl leading-tight text-ink">Bo‘sh stanok.</p>
              <p className="mt-2 max-w-sm text-sm leading-relaxed text-muted">
                Chapdan buyruq yozing yoki tayyor namunani bosing. Tayyor sahifa shu yerda ochiladi.
              </p>
            </div>
          )}
          {busy ? (
            <div className="absolute inset-x-0 top-0 h-1 overflow-hidden bg-line">
              <div className="bar-slide h-full w-1/3 bg-copper" />
            </div>
          ) : null}
        </div>
      </section>
    </main>
  );
}
