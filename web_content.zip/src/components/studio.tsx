import { useEffect, useId, useRef, useState } from "react";
import { Loader2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  pollVideo,
  refineScene,
  startVideo,
  studioStatus,
  type Aspect,
  type Duration,
  type ModelChoice,
  type Resolution,
} from "@/lib/video";
import { cn } from "@/lib/utils";

const HISTORY_KEY = "toma.clips";
const JOB_KEY = "toma.job";

const PRESETS = [
  {
    title: "Faro",
    prompt:
      "Plano general de un faro de piedra sobre un acantilado gallego al anochecer. El haz gira y abre la niebla. Olas lentas abajo. Cámara fija, grano suave de película.",
  },
  {
    title: "Mercado",
    prompt:
      "Plano medio en un mercado de la Ciudad de México al mediodía. Vapor de elotes, una bicicleta cruza de izquierda a derecha y la cámara la sigue un momento. Luz dura, colores naturales.",
  },
  {
    title: "Torno",
    prompt:
      "Primer plano de unas manos en un torno de cerámica. El barro sube y toma forma de cuenco. Luz lateral cálida, fondo de taller desenfocado, movimiento lento.",
  },
  {
    title: "Tren",
    prompt:
      "Un tren nocturno cruza un puente de hierro sobre un río. Las ventanas iluminadas se reflejan en el agua. La cámara avanza en paralelo, ligera niebla.",
  },
] as const;

type Clip = {
  id: string;
  prompt: string;
  url: string;
  aspect: Aspect;
  duration: number;
  createdAt: number;
};

type Job = {
  requestId: string;
  prompt: string;
  aspect: Aspect;
  duration: number;
  startedAt: number;
};

type Still =
  | { kind: "none" }
  | { kind: "file"; name: string; dataUrl: string }
  | { kind: "url"; url: string };

const ASPECTS: Aspect[] = ["16:9", "9:16", "1:1"];
const DURATIONS: Duration[] = [6, 8, 10];
const RESOLUTIONS: { id: Resolution; label: string }[] = [
  { id: "480p", label: "Ligera" },
  { id: "720p", label: "Nítida" },
];

function isClip(value: unknown): value is Clip {
  if (!value || typeof value !== "object") return false;
  const clip = value as Clip;
  return (
    typeof clip.id === "string" &&
    typeof clip.prompt === "string" &&
    typeof clip.url === "string" &&
    clip.url.startsWith("https://") &&
    (clip.aspect === "16:9" || clip.aspect === "9:16" || clip.aspect === "1:1") &&
    typeof clip.duration === "number" &&
    typeof clip.createdAt === "number"
  );
}

function loadHistory(): Clip[] {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    if (!raw) return [];
    const data = JSON.parse(raw) as unknown;
    if (!Array.isArray(data)) return [];
    return data.filter(isClip).slice(0, 12);
  } catch {
    return [];
  }
}

function loadJob(): Job | null {
  try {
    const raw = sessionStorage.getItem(JOB_KEY);
    if (!raw) return null;
    const job = JSON.parse(raw) as Job;
    if (!job?.requestId || Date.now() - job.startedAt > 8 * 60 * 1000) return null;
    return job;
  } catch {
    return null;
  }
}

function formatElapsed(ms: number) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const minutes = Math.floor(total / 60);
  const seconds = total % 60;
  return `${minutes}:${seconds.toString().padStart(2, "0")}`;
}

function frameClass(aspect: Aspect) {
  if (aspect === "9:16") return "aspect-[9/16] h-[min(68dvh,640px)] w-auto max-w-full";
  if (aspect === "1:1") return "aspect-square w-full max-w-xl";
  return "aspect-video w-full";
}

async function fileToDataUrl(file: File) {
  if (file.size > 12_000_000) throw new Error("La foto pesa demasiado.");
  const bitmap = await createImageBitmap(file);
  const max = 1024;
  const scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("No se pudo leer la foto.");
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  let url = canvas.toDataURL("image/jpeg", 0.82);
  if (url.length > 900_000) url = canvas.toDataURL("image/jpeg", 0.6);
  if (url.length > 1_150_000) throw new Error("La foto sigue siendo demasiado pesada.");
  return url;
}

function Chip({
  pressed,
  children,
  onClick,
  disabled,
}: {
  pressed: boolean;
  children: string;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      aria-pressed={pressed}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "min-h-11 rounded-md px-3 text-sm font-medium tabular-nums transition-[background-color,color] duration-150",
        "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
        "disabled:opacity-40",
        pressed ? "bg-accent text-ink" : "bg-raised text-muted hover:text-fg",
      )}
    >
      {children}
    </button>
  );
}

export function Studio() {
  const promptId = useId();
  const urlId = useId();
  const fileRef = useRef<HTMLInputElement>(null);
  const stageRef = useRef<HTMLElement>(null);

  const [prompt, setPrompt] = useState("");
  const [aspect, setAspect] = useState<Aspect>("16:9");
  const [duration, setDuration] = useState<Duration>(6);
  const [resolution, setResolution] = useState<Resolution>("720p");
  const [model, setModel] = useState<ModelChoice>("lite");
  const [sound, setSound] = useState(true);
  const [photoOpen, setPhotoOpen] = useState(false);
  const [still, setStill] = useState<Still>({ kind: "none" });
  const [available, setAvailable] = useState<boolean | null>(null);
  const [refining, setRefining] = useState(false);
  const [starting, setStarting] = useState(false);
  const [error, setError] = useState("");
  const [job, setJob] = useState<Job | null>(null);
  const [history, setHistory] = useState<Clip[]>([]);
  const [active, setActive] = useState<Clip | null>(null);
  const [now, setNow] = useState(0);

  useEffect(() => {
    setHistory(loadHistory());
    const saved = loadJob();
    if (saved) setJob(saved);
    else sessionStorage.removeItem(JOB_KEY);
    void studioStatus()
      .then((status) => setAvailable(status.available))
      .catch(() => setAvailable(false));
  }, []);

  useEffect(() => {
    if (!job) return;
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    setNow(Date.now());
    return () => window.clearInterval(id);
  }, [job]);

  useEffect(() => {
    if (!job) return;
    const current = job;
    let cancelled = false;
    let attempts = 0;
    let timer = 0;

    const finish = (url: string) => {
      const clip: Clip = {
        id: current.requestId,
        prompt: current.prompt,
        url,
        aspect: current.aspect,
        duration: current.duration,
        createdAt: Date.now(),
      };
      setActive(clip);
      setHistory((prev) => {
        const next = [clip, ...prev.filter((item) => item.id !== clip.id)].slice(0, 12);
        localStorage.setItem(HISTORY_KEY, JSON.stringify(next));
        return next;
      });
      sessionStorage.removeItem(JOB_KEY);
      setJob(null);
      const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      stageRef.current?.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "center" });
    };

    const fail = (message: string) => {
      setError(message);
      sessionStorage.removeItem(JOB_KEY);
      setJob(null);
    };

    const loop = async () => {
      if (cancelled) return;
      attempts += 1;
      if (attempts > 80 || Date.now() - current.startedAt > 8 * 60 * 1000) {
        fail("La toma tardó demasiado. Prueba de nuevo con 6 segundos.");
        return;
      }
      try {
        const res = await pollVideo({ data: { requestId: current.requestId } });
        if (cancelled) return;
        if (res.ok && res.status === "done") {
          finish(res.url);
          return;
        }
        if (!res.ok) {
          fail(res.error);
          return;
        }
      } catch (err) {
        if (attempts > 6) {
          fail(err instanceof Error ? err.message : "Se perdió el contacto con la toma.");
          return;
        }
      }
      timer = window.setTimeout(() => void loop(), 4000);
    };

    timer = window.setTimeout(() => void loop(), 2000);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [job]);

  const imageUrl = still.kind === "file" ? still.dataUrl : still.kind === "url" ? still.url.trim() : "";
  const busy = starting || refining || job !== null;
  const frameAspect = job ? job.aspect : (active?.aspect ?? aspect);
  const elapsed = job ? formatElapsed((now || Date.now()) - job.startedAt) : "";

  async function onFile(file: File | undefined) {
    if (!file) return;
    setError("");
    try {
      const dataUrl = await fileToDataUrl(file);
      setStill({ kind: "file", name: file.name, dataUrl });
      setPhotoOpen(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "No se pudo usar esa foto. Prueba con JPG o PNG.");
    }
  }

  function clearStill() {
    setStill({ kind: "none" });
    if (fileRef.current) fileRef.current.value = "";
  }

  async function refine() {
    if (busy || prompt.trim().length < 3) return;
    setRefining(true);
    setError("");
    try {
      const res = await refineScene({ data: { idea: prompt } });
      if (!res.ok) setError(res.error);
      else setPrompt(res.prompt);
    } catch (err) {
      setError(err instanceof Error ? err.message : "No se pudo afinar la idea.");
    } finally {
      setRefining(false);
    }
  }

  async function generate() {
    if (busy || available === false || prompt.trim().length < 3) return;
    setStarting(true);
    setError("");
    try {
      const res = await startVideo({
        data: {
          prompt,
          duration,
          aspectRatio: imageUrl ? aspect : aspect,
          resolution,
          model,
          sound,
          imageUrl,
        },
      });
      if (!res.ok) {
        setError(res.error);
        return;
      }
      const next: Job = {
        requestId: res.requestId,
        prompt: prompt.trim(),
        aspect,
        duration,
        startedAt: Date.now(),
      };
      sessionStorage.setItem(JOB_KEY, JSON.stringify(next));
      setActive(null);
      setJob(next);
    } catch (err) {
      setError(err instanceof Error ? err.message : "No se pudo empezar el video.");
    } finally {
      setStarting(false);
    }
  }

  function removeClip(id: string) {
    setHistory((prev) => {
      const next = prev.filter((item) => item.id !== id);
      localStorage.setItem(HISTORY_KEY, JSON.stringify(next));
      return next;
    });
    setActive((current) => (current?.id === id ? null : current));
  }

  return (
    <main className="mx-auto w-full max-w-6xl px-4 py-6 pb-[max(1.5rem,env(safe-area-inset-bottom))] sm:px-6 lg:px-8">
      <header className="mb-6 flex flex-wrap items-end justify-between gap-3 border-b border-line pb-5">
        <div>
          <p className="text-sm text-muted">Generador de videos</p>
          <h1 className="font-serif text-5xl leading-none tracking-tight italic">Toma</h1>
        </div>
        <p className="text-sm text-muted tabular-nums">
          {duration} s · {aspect} · {resolution}
        </p>
      </header>

      {available === false && (
        <p role="status" className="mb-4 rounded-lg border border-line bg-surface px-4 py-3 text-sm text-muted">
          Ahora mismo no se puede generar video en este espacio.
        </p>
      )}

      <div className="grid items-start gap-6 lg:grid-cols-[minmax(0,24rem)_minmax(0,1fr)]">
        <form
          className="rounded-xl border border-line bg-surface p-4 max-lg:pb-24"
          onSubmit={(event) => {
            event.preventDefault();
            void generate();
          }}
        >
          <div className="flex items-baseline justify-between gap-3">
            <label htmlFor={promptId} className="text-sm font-medium text-muted">
              Escena
            </label>
            <span className="text-xs text-faint tabular-nums">{prompt.length}/1000</span>
          </div>
          <textarea
            id={promptId}
            value={prompt}
            maxLength={1000}
            onChange={(event) => setPrompt(event.target.value)}
            onKeyDown={(event) => {
              if ((event.metaKey || event.ctrlKey) && event.key === "Enter") {
                event.preventDefault();
                void generate();
              }
            }}
            placeholder="Un tren de noche cruza un puente. Las ventanas iluminadas se reflejan en el río."
            className="mt-2 min-h-32 w-full resize-y rounded-md border border-line bg-raised px-3 py-3 text-sm text-fg placeholder:text-faint focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
          />

          <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
            {PRESETS.map((preset) => (
              <button
                key={preset.title}
                type="button"
                onClick={() => setPrompt(preset.prompt)}
                className="min-h-11 shrink-0 rounded-md bg-raised px-3 text-sm text-muted hover:text-fg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
              >
                {preset.title}
              </button>
            ))}
          </div>

          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <fieldset disabled={Boolean(imageUrl)} className="min-w-0 disabled:opacity-40">
              <legend className="mb-2 text-sm font-medium text-muted">Relación</legend>
              <div className="flex flex-wrap gap-2">
                {ASPECTS.map((item) => (
                  <Chip key={item} pressed={aspect === item} onClick={() => setAspect(item)}>
                    {item}
                  </Chip>
                ))}
              </div>
            </fieldset>
            <fieldset>
              <legend className="mb-2 text-sm font-medium text-muted">Duración</legend>
              <div className="flex flex-wrap gap-2">
                {DURATIONS.map((item) => (
                  <Chip key={item} pressed={duration === item} onClick={() => setDuration(item)}>
                    {`${item} s`}
                  </Chip>
                ))}
              </div>
            </fieldset>
            <fieldset>
              <legend className="mb-2 text-sm font-medium text-muted">Nitidez</legend>
              <div className="flex flex-wrap gap-2">
                {RESOLUTIONS.map((item) => (
                  <Chip key={item.id} pressed={resolution === item.id} onClick={() => setResolution(item.id)}>
                    {item.label}
                  </Chip>
                ))}
              </div>
            </fieldset>
            <fieldset>
              <legend className="mb-2 text-sm font-medium text-muted">Modelo</legend>
              <div className="flex flex-wrap gap-2">
                <Chip pressed={model === "lite"} onClick={() => setModel("lite")}>
                  Ágil
                </Chip>
                <Chip pressed={model === "studio"} onClick={() => setModel("studio")}>
                  Estudio
                </Chip>
              </div>
            </fieldset>
          </div>

          <fieldset className="mt-4">
            <legend className="mb-2 text-sm font-medium text-muted">Sonido</legend>
            <div className="flex flex-wrap gap-2">
              <Chip pressed={sound} onClick={() => setSound(true)}>
                Con audio
              </Chip>
              <Chip pressed={!sound} onClick={() => setSound(false)}>
                En silencio
              </Chip>
            </div>
          </fieldset>

          <p className="mt-4 text-xs text-faint">
            Ágil gasta menos créditos. Cada video tarda cerca de un minuto.
          </p>

          {error && (
            <p role="alert" className="mt-3 text-sm text-danger">
              {error}
            </p>
          )}

          <div className="fixed inset-x-0 bottom-0 z-20 flex gap-2 border-t border-line bg-bg px-4 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] lg:static lg:inset-auto lg:z-auto lg:mt-4 lg:border-0 lg:bg-transparent lg:p-0">
            <Button
              type="button"
              variant="quiet"
              className="shrink-0"
              onClick={() => void refine()}
              disabled={busy || prompt.trim().length < 3}
            >
              {refining ? "Afinando…" : "Afinar idea"}
            </Button>
            <Button
              type="submit"
              className="flex-1"
              disabled={busy || available === false || prompt.trim().length < 3}
            >
              {starting || job ? (
                <>
                  <Loader2 className="size-4 animate-spin" />
                  Generando…
                </>
              ) : (
                "Generar video"
              )}
            </Button>
          </div>

          <div className="mt-4">
            <button
              type="button"
              aria-expanded={photoOpen}
              onClick={() => setPhotoOpen((open) => !open)}
              className="min-h-11 text-sm font-medium text-muted underline-offset-4 hover:text-fg hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
            >
              {photoOpen ? "Ocultar foto de partida" : "Animar una foto"}
            </button>
            {photoOpen && (
              <div className="mt-3 rounded-lg border border-line bg-bg p-3">
                <p className="text-sm text-muted">
                  La foto es el primer fotograma. Describe el movimiento, no la imagen.
                </p>
                <div className="mt-3 flex flex-wrap items-center gap-3">
                  <label className="inline-flex min-h-11 cursor-pointer items-center rounded-md border border-line bg-raised px-3 text-sm text-fg hover:bg-surface">
                    Elegir foto
                    <input
                      ref={fileRef}
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      className="sr-only"
                      onChange={(event) => void onFile(event.target.files?.[0])}
                    />
                  </label>
                  {still.kind === "file" && (
                    <span className="max-w-40 truncate text-sm text-muted">{still.name}</span>
                  )}
                  {still.kind !== "none" && (
                    <button
                      type="button"
                      onClick={clearStill}
                      className="inline-flex min-h-11 min-w-11 items-center justify-center text-muted hover:text-fg"
                      aria-label="Quitar foto"
                    >
                      <X className="size-4" />
                    </button>
                  )}
                </div>
                {still.kind === "file" && (
                  <img
                    src={still.dataUrl}
                    alt=""
                    className="mt-3 h-24 w-24 rounded-md object-cover"
                  />
                )}
                <label htmlFor={urlId} className="mt-3 block text-sm text-muted">
                  O un enlace https
                </label>
                <input
                  id={urlId}
                  type="url"
                  inputMode="url"
                  placeholder="https://"
                  value={still.kind === "url" ? still.url : ""}
                  onChange={(event) => setStill({ kind: "url", url: event.target.value })}
                  className="mt-2 min-h-11 w-full rounded-md border border-line bg-raised px-3 text-sm text-fg placeholder:text-faint focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                />
                {imageUrl && (
                  <p className="mt-2 text-xs text-faint">Con foto, el encuadre sale de la imagen.</p>
                )}
              </div>
            )}
          </div>
          <p className="sr-only" role="status" aria-live="polite">
            {job ? `Exponiendo ${elapsed}` : refining ? "Afinando la escena" : ""}
          </p>
        </form>

        <section ref={stageRef} className="rounded-lg border border-line bg-surface p-3" aria-label="Visor">
          <div className="flex justify-center">
            <div className={cn("relative overflow-hidden rounded-md bg-stage", frameClass(frameAspect))}>
              <span className="pointer-events-none absolute top-3 left-3 size-4 border-t border-l border-fg/30" />
              <span className="pointer-events-none absolute top-3 right-3 size-4 border-t border-r border-fg/30" />
              <span className="pointer-events-none absolute bottom-3 left-3 size-4 border-b border-l border-fg/30" />
              <span className="pointer-events-none absolute right-3 bottom-3 size-4 border-r border-b border-fg/30" />

              {job ? (
                <div className="flex h-full flex-col items-center justify-center px-6 text-center">
                  <p className="text-sm text-muted">Exponiendo</p>
                  <p className="mt-1 font-serif text-4xl text-fg tabular-nums">{elapsed}</p>
                  <div className="absolute inset-x-0 bottom-0 h-px overflow-hidden">
                    <div className="animate-expose h-full w-1/3 bg-accent" />
                  </div>
                </div>
              ) : active ? (
                <video
                  key={active.url}
                  src={active.url}
                  controls
                  playsInline
                  autoPlay
                  className="h-full w-full bg-stage object-contain"
                />
              ) : (
                <div className="flex h-full items-center justify-center px-6">
                  <p className="line-clamp-6 max-w-[32ch] text-center font-serif text-lg text-muted italic">
                    {prompt.trim() || "Aquí se proyecta el video"}
                  </p>
                </div>
              )}
            </div>
          </div>

          {active && !job && (
            <div className="mt-3 flex flex-wrap items-start justify-between gap-3 px-1">
              <p className="line-clamp-3 max-w-prose font-serif text-base text-fg italic">{active.prompt}</p>
              <a
                href={active.url}
                target="_blank"
                rel="noreferrer"
                className="inline-flex min-h-11 shrink-0 items-center rounded-md border border-line bg-raised px-3 text-sm text-fg hover:bg-bg"
              >
                Abrir archivo
              </a>
            </div>
          )}
        </section>
      </div>

      {history.length > 0 && (
        <section className="mt-8" aria-label="Videos recientes">
          <div className="mb-3 flex items-baseline justify-between gap-3">
            <h2 className="text-sm font-medium text-muted">Videos recientes</h2>
            <p className="text-xs text-faint">En este navegador. El enlace puede caducar.</p>
          </div>
          <ul className="flex gap-3 overflow-x-auto pb-2">
            {history.map((clip) => (
              <li key={clip.id} className="w-56 shrink-0">
                <div
                  className={cn(
                    "flex h-full flex-col rounded-lg border bg-surface p-3",
                    active?.id === clip.id ? "border-fg/30" : "border-line",
                  )}
                >
                  <button
                    type="button"
                    onClick={() => {
                      setActive(clip);
                      setError("");
                    }}
                    className="flex-1 text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                  >
                    <p className="line-clamp-3 text-sm text-fg">{clip.prompt}</p>
                    <p className="mt-2 text-xs text-muted tabular-nums">
                      {clip.duration} s · {clip.aspect}
                    </p>
                  </button>
                  <button
                    type="button"
                    onClick={() => removeClip(clip.id)}
                    className="mt-2 min-h-11 self-start text-xs text-faint hover:text-fg"
                  >
                    Quitar
                  </button>
                </div>
              </li>
            ))}
          </ul>
        </section>
      )}
    </main>
  );
}
