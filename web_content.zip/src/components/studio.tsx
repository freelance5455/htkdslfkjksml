import { useEffect, useRef, useState, type DragEvent } from "react";
import { Camera, Download, Film, Pause, Play, Smartphone, Upload } from "lucide-react";
import { drawFrame } from "@/lib/draw-frame";
import { deliverFile, exportClip } from "@/lib/export-clip";
import { probeClip, seekTo } from "@/lib/media";
import { startScore } from "@/lib/music";
import { planEdit } from "@/lib/plan.functions";
import {
  formatTime,
  interpretPrompt,
  NEUTRAL_RECIPE,
  recipeNotes,
  windowFor,
  type EditRecipe,
} from "@/lib/recipe";
import { recordSampleReel } from "@/lib/sample-reel";

type Clip = {
  url: string;
  name: string;
  duration: number;
  width: number;
  height: number;
};

type Busy = "sample" | "plan" | "save" | null;
type Via = "grok" | "device" | null;

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

const PRESETS = [
  {
    label: "Trailer",
    prompt: "Cinematic trailer. Letterbox, slow push-in, film grain, title “Tonight”, soft score.",
  },
  {
    label: "Golden hour",
    prompt: "Warm golden-hour grade, a little slower, gentle fade, title “Sunday”.",
  },
  {
    label: "Noir",
    prompt: "Black and white noir, high contrast, heavy vignette, no music.",
  },
  {
    label: "Hype",
    prompt: "Fast vivid recap with a punchy beat. Keep it bright and tight.",
  },
  {
    label: "Dream",
    prompt: "Soft dreamy fade, slow motion, airy music, title “Stay”.",
  },
  {
    label: "Silent story",
    prompt: "Mute the clip, monochrome, no music, caption “just us”.",
  },
];

function formatBytes(bytes: number) {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function frameStyle(width: number, height: number) {
  return { aspectRatio: `${width} / ${height}` };
}

export function Studio() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);
  const clipRef = useRef<Clip | null>(null);
  const recipeRef = useRef<EditRecipe | null>(null);
  const scoreStop = useRef<(() => void) | null>(null);
  const audioRef = useRef<AudioContext | null>(null);
  const toggleRef = useRef<() => void>(() => {});
  const cancelSave = useRef(false);

  const [clip, setClip] = useState<Clip | null>(null);
  const [prompt, setPrompt] = useState("");
  const [recipe, setRecipe] = useState<EditRecipe | null>(null);
  const [applied, setApplied] = useState("");
  const [via, setVia] = useState<Via>(null);
  const [status, setStatus] = useState("Add a clip. It stays on this phone.");
  const [busy, setBusy] = useState<Busy>(null);
  const [progress, setProgress] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [playhead, setPlayhead] = useState(0);
  const [installOpen, setInstallOpen] = useState(false);
  const [installed, setInstalled] = useState(false);
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);

  clipRef.current = clip;
  recipeRef.current = recipe;

  useEffect(() => {
    const saved = window.localStorage.getItem("onecut-prompt");
    if (saved) setPrompt(saved);
    const standalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (navigator as Navigator & { standalone?: boolean }).standalone === true;
    setInstalled(standalone);
    const onPrompt = (event: Event) => {
      event.preventDefault();
      setDeferred(event as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    if (import.meta.env.PROD && "serviceWorker" in navigator) {
      void navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  useEffect(() => {
    const video = videoRef.current;
    if (!video || !clip) return;
    video.src = clip.url;
    video.playsInline = true;
    const plan = recipeRef.current ?? NEUTRAL_RECIPE;
    video.playbackRate = plan.speed;
    video.volume = plan.sourceGain;
    const onReady = () => {
      const { start } = windowFor(recipeRef.current ?? NEUTRAL_RECIPE, clip.duration);
      void seekTo(video, Math.min(start + 0.04, clip.duration - 0.05)).catch(() => undefined);
      setPlayhead(start);
    };
    const onTime = () => {
      const current = clipRef.current;
      if (!current) return;
      const { start, end } = windowFor(recipeRef.current ?? NEUTRAL_RECIPE, current.duration);
      if (!video.paused && video.currentTime >= end - 0.04) video.currentTime = start;
      setPlayhead(video.currentTime);
      setPlaying(!video.paused);
    };
    const onPause = () => setPlaying(false);
    const onPlay = () => setPlaying(true);
    video.addEventListener("loadeddata", onReady);
    video.addEventListener("timeupdate", onTime);
    video.addEventListener("pause", onPause);
    video.addEventListener("play", onPlay);
    return () => {
      video.removeEventListener("loadeddata", onReady);
      video.removeEventListener("timeupdate", onTime);
      video.removeEventListener("pause", onPause);
      video.removeEventListener("play", onPlay);
    };
  }, [clip]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const plan = recipe ?? NEUTRAL_RECIPE;
    video.playbackRate = plan.speed;
    video.preservesPitch = true;
    video.volume = plan.sourceGain;
  }, [recipe]);

  useEffect(() => {
    let frame = 0;
    const paint = () => {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      const current = clipRef.current;
      if (canvas && video && current && video.readyState >= 2) {
        const rect = canvas.getBoundingClientRect();
        const dpr = Math.min(2, window.devicePixelRatio || 1);
        const w = Math.max(2, Math.round(rect.width * dpr));
        const h = Math.max(2, Math.round(rect.height * dpr));
        if (canvas.width !== w || canvas.height !== h) {
          canvas.width = w;
          canvas.height = h;
        }
        const ctx = canvas.getContext("2d");
        if (ctx && w > 0 && h > 0) {
          const plan = recipeRef.current ?? NEUTRAL_RECIPE;
          const { start, end } = windowFor(plan, current.duration);
          drawFrame(ctx, video, plan, video.currentTime, start, end);
        }
      }
      frame = requestAnimationFrame(paint);
    };
    frame = requestAnimationFrame(paint);
    return () => cancelAnimationFrame(frame);
  }, []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.code !== "Space") return;
      const tag = (event.target as HTMLElement | null)?.tagName;
      if (tag === "TEXTAREA" || tag === "INPUT" || tag === "BUTTON") return;
      event.preventDefault();
      toggleRef.current();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  function replaceClip(next: Clip | null) {
    setClip((prev) => {
      if (prev?.url && prev.url !== next?.url) URL.revokeObjectURL(prev.url);
      return next;
    });
    setPlaying(false);
    scoreStop.current?.();
    scoreStop.current = null;
  }

  async function loadFile(file: File) {
    if (file.type && !file.type.startsWith("video/")) {
      setStatus("Choose a video file.");
      return;
    }
    const url = URL.createObjectURL(file);
    try {
      const meta = await probeClip(url);
      if (!Number.isFinite(meta.duration) || meta.duration <= 0 || !meta.width) {
        throw new Error("empty");
      }
      replaceClip({
        url,
        name: file.name || "Clip",
        duration: meta.duration,
        width: meta.width,
        height: meta.height,
      });
      setRecipe(null);
      setApplied("");
      setVia(null);
      setStatus(
        file.size > 120 * 1024 * 1024
          ? "Large clip loaded. Saving may take a while."
          : "Clip loaded. Describe the cut.",
      );
    } catch {
      URL.revokeObjectURL(url);
      setStatus("That file couldn’t be read. Try an MP4 or WebM.");
    }
  }

  function onPick(list: FileList | null) {
    const file = list?.[0];
    if (file) void loadFile(file);
  }

  function onDrop(event: DragEvent<HTMLDivElement>) {
    event.preventDefault();
    const file = event.dataTransfer.files[0];
    if (file) void loadFile(file);
  }

  async function useSample() {
    setBusy("sample");
    setProgress(0);
    setStatus("Making a 5-second sample reel…");
    try {
      const sample = await recordSampleReel(setProgress);
      replaceClip(sample);
      setRecipe(null);
      setApplied("");
      setVia(null);
      setStatus("Sample reel ready. Describe the cut, then press Cut.");
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Couldn’t make a sample.");
    } finally {
      setBusy(null);
      setProgress(0);
    }
  }

  async function ensureAudio() {
    if (!audioRef.current) audioRef.current = new AudioContext();
    if (audioRef.current.state === "suspended") await audioRef.current.resume();
    return audioRef.current;
  }

  function stopScore() {
    scoreStop.current?.();
    scoreStop.current = null;
  }

  async function playFrom(plan: EditRecipe) {
    const video = videoRef.current;
    const current = clipRef.current;
    if (!video || !current) return;
    stopScore();
    const { start } = windowFor(plan, current.duration);
    video.playbackRate = plan.speed;
    video.preservesPitch = true;
    video.volume = plan.sourceGain;
    try {
      await seekTo(video, start);
      await video.play();
      setPlaying(true);
      if (plan.music !== "none") {
        const ctx = await ensureAudio();
        scoreStop.current = startScore(ctx, ctx.destination, plan.music, plan.musicGain);
      }
    } catch {
      setPlaying(false);
      setStatus("Press play to preview. The browser held back autoplay.");
    }
  }

  async function togglePlay() {
    const video = videoRef.current;
    if (!video || !clipRef.current) return;
    if (!video.paused) {
      video.pause();
      stopScore();
      setPlaying(false);
      return;
    }
    await playFrom(recipeRef.current ?? NEUTRAL_RECIPE);
  }

  toggleRef.current = () => {
    void togglePlay();
  };

  async function cut() {
    const text = prompt.trim();
    if (!clipRef.current) {
      setStatus("Add a clip first.");
      return;
    }
    if (text.length < 2) {
      setStatus("Describe the cut in a sentence.");
      return;
    }
    setBusy("plan");
    setStatus("Reading your prompt…");
    let next = interpretPrompt(text);
    let planned: Via = "device";
    try {
      const remote = await planEdit({ data: { prompt: text } });
      if (remote.ok) {
        next = remote.recipe;
        planned = "grok";
      }
    } catch {
      planned = "device";
    }
    const current = clipRef.current;
    const capped = current ? windowFor(next, current.duration).capped : false;
    setRecipe(next);
    setVia(planned);
    setApplied(text);
    setBusy(null);
    const where = planned === "grok" ? "Planned with Grok." : "Planned on this phone.";
    setStatus(capped ? `${where} Held to 40 seconds so saving stays reliable.` : `${where} Preview it, then save.`);
    void playFrom(next);
  }

  async function save() {
    const current = clipRef.current;
    const plan = recipeRef.current;
    if (!current || !plan) return;
    const video = videoRef.current;
    video?.pause();
    stopScore();
    setPlaying(false);
    cancelSave.current = false;
    setBusy("save");
    setProgress(0);
    setStatus("Saving plays the cut in real time.");
    try {
      const result = await exportClip(current.url, plan, setProgress, () => cancelSave.current);
      if (cancelSave.current) {
        setStatus("Save cancelled.");
        return;
      }
      const how = await deliverFile(result.blob, result.filename);
      const size = formatBytes(result.blob.size);
      if (how === "dismissed") setStatus("Share closed. You can save again.");
      else if (how === "shared") setStatus(`Sent ${size}. Keep it from the share sheet.`);
      else setStatus(`Saved ${size}. Look in Downloads.`);
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Couldn’t save the video.");
    } finally {
      setBusy(null);
    }
  }

  async function installNow() {
    if (!deferred) return;
    await deferred.prompt();
    const choice = await deferred.userChoice;
    setDeferred(null);
    if (choice.outcome === "accepted") {
      setInstalled(true);
      setInstallOpen(false);
    }
  }

  const plan = recipe ?? NEUTRAL_RECIPE;
  const span = clip ? windowFor(plan, clip.duration) : { start: 0, end: 0, capped: false };
  const scrub =
    clip && span.end > span.start
      ? Math.max(0, Math.min(1000, Math.round(((playhead - span.start) / (span.end - span.start)) * 1000)))
      : 0;
  const dirty = prompt.trim() !== applied || !recipe;
  const outputSeconds = clip ? (span.end - span.start) / plan.speed : 0;

  return (
    <div className="safe-page mx-auto flex min-h-dvh w-full max-w-5xl flex-col gap-6 pb-28 lg:px-8 lg:pb-8">
      <header className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <p className="text-xs font-medium tracking-wide text-subtle">Free on your phone</p>
          <h1 className="font-display text-3xl font-medium tracking-tight text-fg">OneCut</h1>
        </div>
        {installed ? null : (
          <button
            type="button"
            className="press inline-flex min-h-11 shrink-0 items-center gap-2 rounded-control border border-line px-3 text-sm font-medium text-fg"
            onClick={() => setInstallOpen(true)}
          >
            <Smartphone className="size-4" aria-hidden="true" />
            Install
          </button>
        )}
      </header>

      <div className="grid items-start gap-6 lg:grid-cols-[minmax(0,420px)_minmax(0,1fr)]">
        <section className="min-w-0 lg:sticky lg:top-6">
          <p className="mb-4 hidden max-w-md text-sm text-muted lg:block">
            One prompt sets the grade, pace, titles, and score. The video never leaves this phone.
          </p>
          <div
            className={`stage relative mx-auto overflow-hidden rounded-card border border-line bg-bg ${clip ? "" : "stage-empty"}`}
            style={clip ? frameStyle(clip.width, clip.height) : undefined}
            onDragOver={(event) => event.preventDefault()}
            onDrop={onDrop}
          >
            <div className="absolute inset-0">
              <video ref={videoRef} className="absolute inset-0 h-full w-full opacity-0" playsInline preload="auto" />
              <canvas ref={canvasRef} className="relative z-10 h-full w-full" />
              {clip ? (
                <button
                  type="button"
                  className="press absolute bottom-3 left-3 z-20 inline-flex size-11 items-center justify-center rounded-full bg-accent text-accent-fg"
                  onClick={() => void togglePlay()}
                  aria-label={playing ? "Pause" : "Play"}
                >
                  {playing ? <Pause className="size-4" /> : <Play className="size-4" />}
                </button>
              ) : (
                <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-4 p-4 text-center">
                  <p className="font-display text-2xl text-fg">Add a clip</p>
                  <p className="max-w-xs text-sm text-muted">Upload, record, or try the sample street at dusk.</p>
                  <div className="flex flex-wrap items-center justify-center gap-2">
                    <button
                      type="button"
                      className="press inline-flex min-h-11 items-center gap-2 rounded-control bg-accent px-4 text-sm font-medium text-accent-fg"
                      onClick={() => fileRef.current?.click()}
                    >
                      <Upload className="size-4" aria-hidden="true" />
                      Upload
                    </button>
                    <button
                      type="button"
                      className="press inline-flex min-h-11 items-center gap-2 rounded-control border border-line bg-surface px-4 text-sm font-medium text-fg"
                      onClick={() => cameraRef.current?.click()}
                    >
                      <Camera className="size-4" aria-hidden="true" />
                      Camera
                    </button>
                    <button
                      type="button"
                      className="press inline-flex min-h-11 items-center gap-2 rounded-control border border-line bg-surface px-4 text-sm font-medium text-fg"
                      onClick={() => void useSample()}
                      disabled={busy !== null}
                    >
                      <Film className="size-4" aria-hidden="true" />
                      Sample
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {clip ? (
            <div className="mt-3">
              <div className="mb-1 flex items-center justify-between text-xs text-muted tabular-nums">
                <span>{formatTime(Math.max(0, playhead - span.start))}</span>
                <span className="truncate px-3 text-subtle">{clip.name}</span>
                <span>{formatTime(outputSeconds)}</span>
              </div>
              <input
                type="range"
                min={0}
                max={1000}
                value={Number.isFinite(scrub) ? scrub : 0}
                aria-label="Scrub the cut"
                className="w-full"
                onChange={(event) => {
                  const video = videoRef.current;
                  if (!video || !clip) return;
                  const { start, end } = windowFor(plan, clip.duration);
                  const time = start + (Number(event.target.value) / 1000) * (end - start);
                  video.currentTime = time;
                  setPlayhead(time);
                }}
              />
            </div>
          ) : null}
        </section>

        <section className="flex min-w-0 flex-col gap-4">
          {clip ? (
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                className="press inline-flex min-h-11 items-center gap-2 rounded-control border border-line px-3 text-sm text-fg"
                onClick={() => fileRef.current?.click()}
              >
                <Upload className="size-4" aria-hidden="true" />
                Replace
              </button>
              <button
                type="button"
                className="press inline-flex min-h-11 items-center gap-2 rounded-control border border-line px-3 text-sm text-fg"
                onClick={() => void useSample()}
                disabled={busy !== null}
              >
                <Film className="size-4" aria-hidden="true" />
                Sample
              </button>
            </div>
          ) : null}

          <label className="flex flex-col gap-2" htmlFor="prompt">
            <span className="text-sm font-medium text-fg">One prompt</span>
            <textarea
              id="prompt"
              value={prompt}
              maxLength={500}
              rows={4}
              placeholder="Warm cinematic grade, slow the middle, title “Sunday”, soft score."
              className="min-h-28 w-full resize-none rounded-card border border-line bg-surface px-4 py-3 text-base text-fg outline-none placeholder:text-subtle"
              onChange={(event) => {
                setPrompt(event.target.value);
                window.localStorage.setItem("onecut-prompt", event.target.value);
              }}
            />
          </label>

          <div className="flex min-w-0 gap-2 overflow-x-auto pb-1">
            {PRESETS.map((preset) => (
              <button
                key={preset.label}
                type="button"
                className="press inline-flex min-h-11 shrink-0 items-center rounded-control border border-line px-3 text-sm text-muted"
                onClick={() => {
                  setPrompt(preset.prompt);
                  window.localStorage.setItem("onecut-prompt", preset.prompt);
                }}
              >
                {preset.label}
              </button>
            ))}
          </div>

          {recipe ? (
            <div className="rounded-card border border-line bg-surface p-4">
              <p className="text-sm text-fg">{recipe.summary || "Cut ready."}</p>
              <p className="mt-1 text-xs text-subtle">{via === "grok" ? "Read by Grok" : "Read on this phone"}</p>
              <ul className="mt-3 flex flex-col gap-1 text-sm text-muted">
                {clip ? recipeNotes(recipe, clip.duration).map((note) => <li key={note}>{note}</li>) : null}
              </ul>
            </div>
          ) : null}

          <p className="min-h-5 text-sm text-muted" aria-live="polite">
            {status}
          </p>
          {busy === "sample" || busy === "save" ? (
            <div
              className="h-1 overflow-hidden rounded-full bg-elevated"
              role="progressbar"
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={Math.round(progress * 100)}
            >
              <div className="h-full bg-accent" style={{ width: `${Math.round(progress * 100)}%` }} />
            </div>
          ) : null}

          <div className="action-bar fixed inset-x-0 bottom-0 z-30 border-t border-line bg-bg px-4 pt-3 lg:static lg:border-0 lg:bg-transparent lg:px-0 lg:py-0">
            <div className="flex gap-2">
              <button
                type="button"
                className={`press inline-flex min-h-11 items-center justify-center rounded-control px-4 text-sm font-medium disabled:opacity-40 ${
                  recipe && !dirty
                    ? "border border-line text-fg"
                    : "flex-1 bg-accent text-accent-fg"
                }`}
                onClick={() => void cut()}
                disabled={busy !== null || prompt.trim().length < 2}
              >
                {busy === "plan" ? "Reading prompt…" : recipe && !dirty ? "Cut again" : "Cut"}
              </button>
              {recipe ? (
                busy === "save" ? (
                  <button
                    type="button"
                    className="press inline-flex min-h-11 flex-1 items-center justify-center rounded-control border border-line px-4 text-sm font-medium text-fg"
                    onClick={() => {
                      cancelSave.current = true;
                    }}
                  >
                    Cancel save
                  </button>
                ) : (
                  <button
                    type="button"
                    className={`press inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-control px-4 text-sm font-medium disabled:opacity-40 ${
                      dirty ? "border border-line text-fg" : "bg-accent text-accent-fg"
                    }`}
                    onClick={() => void save()}
                    disabled={busy !== null || dirty}
                  >
                    <Download className="size-4" aria-hidden="true" />
                    Save video
                  </button>
                )
              ) : null}
            </div>
          </div>
        </section>
      </div>

      <input
        ref={fileRef}
        type="file"
        accept="video/*"
        className="sr-only"
        onChange={(event) => {
          onPick(event.target.files);
          event.target.value = "";
        }}
      />
      <input
        ref={cameraRef}
        type="file"
        accept="video/*"
        capture="environment"
        className="sr-only"
        onChange={(event) => {
          onPick(event.target.files);
          event.target.value = "";
        }}
      />

      {installOpen ? (
        <div
          className="fixed inset-0 z-40 flex items-end justify-center bg-bg/80 p-4 sm:items-center"
          onClick={() => setInstallOpen(false)}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="install-title"
            className="w-full max-w-md rounded-card border border-line bg-surface p-5"
            onClick={(event) => event.stopPropagation()}
          >
            <h2 id="install-title" className="font-display text-2xl font-medium text-fg">
              Install on your phone
            </h2>
            <p className="mt-2 text-sm text-muted">
              There isn’t an APK to sideload. Android and iPhone install OneCut from the browser onto your home
              screen, and it opens full screen like any other app. Your clips still stay on the device.
            </p>
            {deferred ? (
              <button
                type="button"
                className="press mt-4 inline-flex min-h-11 w-full items-center justify-center rounded-control bg-accent px-4 text-sm font-medium text-accent-fg"
                onClick={() => void installNow()}
              >
                Install OneCut
              </button>
            ) : null}
            <div className="mt-4 grid gap-4 text-sm text-muted sm:grid-cols-2">
              <div>
                <p className="font-medium text-fg">Android</p>
                <ol className="mt-1 list-decimal pl-4">
                  <li>Open OneCut in Chrome.</li>
                  <li>Tap the menu.</li>
                  <li>Choose Install app or Add to Home screen.</li>
                </ol>
              </div>
              <div>
                <p className="font-medium text-fg">iPhone</p>
                <ol className="mt-1 list-decimal pl-4">
                  <li>Open OneCut in Safari.</li>
                  <li>Tap Share.</li>
                  <li>Choose Add to Home Screen.</li>
                </ol>
              </div>
            </div>
            <button
              type="button"
              className="press mt-4 inline-flex min-h-11 w-full items-center justify-center rounded-control border border-line text-sm font-medium text-fg"
              onClick={() => setInstallOpen(false)}
            >
              Close
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
