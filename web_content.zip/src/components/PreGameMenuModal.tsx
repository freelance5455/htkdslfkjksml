import React, { useState } from 'react';
import { DifficultyMode } from '../game/types';
import { Sparkles, Shield, Clock, BookOpen, Heart, User } from 'lucide-react';
import { playClickSound } from '../utils/audio';

interface PreGameMenuModalProps {
  initialPlayerName: string;
  initialPartnerName: string;
  onStart: (config: {
    playerName: string;
    partnerName: string;
    difficulty: DifficultyMode;
    timeSpeed: 'slow' | 'normal';
    launchTutorial: boolean;
  }) => void;
}

export const PreGameMenuModal: React.FC<PreGameMenuModalProps> = ({
  initialPlayerName,
  initialPartnerName,
  onStart
}) => {
  const [playerName, setPlayerName] = useState(initialPlayerName || 'محمد');
  const [partnerName, setPartnerName] = useState(initialPartnerName || 'أروى');
  const [difficulty, setDifficulty] = useState<DifficultyMode>('realistic');
  const [timeSpeed, setTimeSpeed] = useState<'slow' | 'normal'>('slow');
  const [launchTutorial, setLaunchTutorial] = useState(true);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    playClickSound();
    onStart({
      playerName: playerName.trim() || 'محمد',
      partnerName: partnerName.trim() || 'أروى',
      difficulty,
      timeSpeed,
      launchTutorial
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-3xl p-6 shadow-2xl text-right animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="p-2.5 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Sparkles className="w-6 h-6" />
            </span>
            <div>
              <h2 className="text-xl font-bold text-amber-300">تخصيص بداية رحلة الحياة</h2>
              <p className="text-xs text-slate-400">حدد أسماء الشخصيات وقواعد اللعبة قبل الانطلاق</p>
            </div>
          </div>
          <span className="text-xs px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
            الإصدار المطور v6
          </span>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {/* Names */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 mb-1.5">
                <User className="w-4 h-4 text-emerald-400" />
                <span>اسمك (اللاعب):</span>
              </label>
              <input
                type="text"
                required
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value)}
                placeholder="مثال: محمد"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition"
              />
            </div>
            <div>
              <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 mb-1.5">
                <Heart className="w-4 h-4 text-rose-400" />
                <span>اسم شريكة حياتك (البنت):</span>
              </label>
              <input
                type="text"
                required
                value={partnerName}
                onChange={(e) => setPartnerName(e.target.value)}
                placeholder="مثال: أروى"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-rose-400 focus:ring-1 focus:ring-rose-400 transition"
              />
            </div>
          </div>

          {/* Difficulty Selection */}
          <div>
            <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 mb-2">
              <Shield className="w-4 h-4 text-amber-400" />
              <span>مستوى الصعوبة الاقتصادية:</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setDifficulty('realistic')}
                className={`p-3 rounded-2xl border text-right transition ${
                  difficulty === 'realistic'
                    ? 'bg-amber-500/15 border-amber-500 text-amber-200'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="font-bold text-xs">⚖️ متوازن وواقعي</div>
                <div className="text-[10px] text-slate-400 mt-1 leading-relaxed">موصى به، دخل ومصاريف محسوبة</div>
              </button>

              <button
                type="button"
                onClick={() => setDifficulty('survival')}
                className={`p-3 rounded-2xl border text-right transition ${
                  difficulty === 'survival'
                    ? 'bg-red-500/15 border-red-500 text-red-200'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="font-bold text-xs">🔥 كفاح شديد</div>
                <div className="text-[10px] text-slate-400 mt-1 leading-relaxed">أجور أصعب ومصاريف معيشة أعلى</div>
              </button>

              <button
                type="button"
                onClick={() => setDifficulty('relaxed')}
                className={`p-3 rounded-2xl border text-right transition ${
                  difficulty === 'relaxed'
                    ? 'bg-emerald-500/15 border-emerald-500 text-emerald-200'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="font-bold text-xs">🌱 مريح وتجريبي</div>
                <div className="text-[10px] text-slate-400 mt-1 leading-relaxed">تجميع أموال واستقرار أسرع</div>
              </button>
            </div>
          </div>

          {/* Time Speed */}
          <div>
            <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 mb-2">
              <Clock className="w-4 h-4 text-cyan-400" />
              <span>سرعة مرور الوقت في اللعبة:</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setTimeSpeed('slow')}
                className={`p-3 rounded-2xl border text-right transition ${
                  timeSpeed === 'slow'
                    ? 'bg-cyan-500/15 border-cyan-500 text-cyan-200'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="font-bold text-xs">⏳ وقت هادئ وبطيء (مطلوب)</div>
                <div className="text-[10px] text-slate-400 mt-1">الأفعال تأخذ دقائق محسوبة لتستمتع بكل يوم</div>
              </button>

              <button
                type="button"
                onClick={() => setTimeSpeed('normal')}
                className={`p-3 rounded-2xl border text-right transition ${
                  timeSpeed === 'normal'
                    ? 'bg-cyan-500/15 border-cyan-500 text-cyan-200'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="font-bold text-xs">⏩ سرعة عادية</div>
                <div className="text-[10px] text-slate-400 mt-1">الأيام تمضي بنسق متسارع</div>
              </button>
            </div>
          </div>

          {/* Tutorial Checkbox */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-950 border border-slate-800">
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-amber-400" />
              <span className="text-xs text-slate-200">عرض الدليل الإرشادي والتوتوريل في البداية</span>
            </div>
            <input
              type="checkbox"
              checked={launchTutorial}
              onChange={(e) => setLaunchTutorial(e.target.checked)}
              className="w-4 h-4 rounded text-amber-500 accent-amber-500 bg-slate-900 border-slate-700 cursor-pointer"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 text-slate-950 font-black text-sm shadow-lg shadow-amber-500/20 hover:brightness-110 active:scale-[0.98] transition flex items-center justify-center gap-2"
          >
            <span>ابدأ رحلة الحياة الآن</span>
            <span>🚀</span>
          </button>
        </form>
      </div>
    </div>
  );
};
