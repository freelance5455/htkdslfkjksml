import React, { useState, useRef, useEffect } from 'react';
import {
  Volume2,
  VolumeX,
  Play,
  Pause,
  RotateCcw,
  Download,
  Sparkles,
  Settings2,
  Music,
  Check,
  ChevronDown,
} from 'lucide-react';
import { VOICE_OPTIONS, VOICE_STYLES } from '../data/presets';
import { VoicePersona } from '../types';

interface AudioNarratorProps {
  storyText: string;
  onAudioGenerated?: () => void;
}

export const AudioNarrator: React.FC<AudioNarratorProps> = ({ storyText, onAudioGenerated }) => {
  const [selectedVoice, setSelectedVoice] = useState<VoicePersona>('Kore');
  const [stylePrompt, setStylePrompt] = useState(VOICE_STYLES[0].prompt);
  const [customStyle, setCustomStyle] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);

  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [audioError, setAudioError] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [showVoiceSettings, setShowVoiceSettings] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Stop playback when story changes significantly or unmount
  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
      }
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, []);

  // Update speed
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = playbackSpeed;
    }
  }, [playbackSpeed]);

  // Waveform animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let phase = 0;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const bars = 36;
      const barWidth = canvas.width / bars - 2;

      for (let i = 0; i < bars; i++) {
        let height = 6;
        if (isPlaying) {
          // Dynamic procedural waveform based on phase and bar position
          const wave1 = Math.sin(phase + i * 0.35);
          const wave2 = Math.cos(phase * 1.5 + i * 0.2);
          const norm = Math.abs((wave1 + wave2) / 2);
          height = Math.max(6, norm * (canvas.height - 8));
        } else if (audioUrl) {
          // Static soft wave preview
          height = 6 + Math.sin(i * 0.4) * 10;
        }

        const x = i * (barWidth + 2);
        const y = (canvas.height - height) / 2;

        const gradient = ctx.createLinearGradient(0, y, 0, y + height);
        if (isPlaying) {
          gradient.addColorStop(0, '#f59e0b');
          gradient.addColorStop(1, '#d97706');
        } else {
          gradient.addColorStop(0, '#57534e');
          gradient.addColorStop(1, '#44403c');
        }

        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.roundRect(x, y, barWidth, height, 2);
        ctx.fill();
      }

      if (isPlaying) {
        phase += 0.12;
      }
      animationFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isPlaying, audioUrl]);

  const handleGenerateAudio = async () => {
    if (!storyText.trim()) return;

    setIsLoadingAudio(true);
    setAudioError(null);

    // Stop current audio if playing
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
    }

    try {
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: storyText,
          voiceName: selectedVoice,
          stylePrompt: stylePrompt,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to generate speech narration');
      }

      const audioSrc = `data:audio/wav;base64,${data.audioData}`;
      setAudioUrl(audioSrc);
      setCurrentTime(0);

      // Initialize audio element
      const audio = new Audio(audioSrc);
      audio.playbackRate = playbackSpeed;

      audio.onloadedmetadata = () => {
        setDuration(audio.duration || 0);
      };

      audio.ontimeupdate = () => {
        setCurrentTime(audio.currentTime);
      };

      audio.onended = () => {
        setIsPlaying(false);
        setCurrentTime(0);
      };

      audio.onerror = () => {
        setAudioError('Failed to playback generated audio.');
        setIsPlaying(false);
      };

      audioRef.current = audio;
      audio.play().then(() => {
        setIsPlaying(true);
      }).catch((e) => {
        console.warn('Auto-play blocked or interrupted:', e);
        setIsPlaying(false);
      });

      if (onAudioGenerated) onAudioGenerated();
    } catch (err: any) {
      console.error('Audio generation error:', err);
      setAudioError(err.message || 'Failed to synthesize narration audio.');
    } finally {
      setIsLoadingAudio(false);
    }
  };

  const togglePlayPause = () => {
    if (!audioRef.current) {
      handleGenerateAudio();
      return;
    }

    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch(console.error);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = parseFloat(e.target.value);
    setCurrentTime(newTime);
    if (audioRef.current) {
      audioRef.current.currentTime = newTime;
    }
  };

  const handleDownload = () => {
    if (!audioUrl) return;
    const a = document.createElement('a');
    a.href = audioUrl;
    a.download = `story-narration-${selectedVoice.toLowerCase()}.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="rounded-2xl border border-stone-800 bg-stone-900/70 backdrop-blur-sm p-5 sm:p-6 shadow-xl space-y-4">
      {/* Header and Read Aloud Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/25 text-amber-400">
            <Volume2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-display text-base font-semibold text-stone-100 tracking-wide">
                Expressive AI Story Narration
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
                gemini-3.8-flash-tts
              </span>
            </div>
            <p className="text-xs text-stone-400">
              Voice: <strong className="text-stone-200">{selectedVoice}</strong> ({VOICE_OPTIONS.find((v) => v.id === selectedVoice)?.gender}) • Lyrical cadence & natural breathing
            </p>
          </div>
        </div>

        {/* Read Aloud Trigger */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={() => setShowVoiceSettings(!showVoiceSettings)}
            className="p-2 rounded-xl bg-stone-950/80 hover:bg-stone-800 text-stone-400 hover:text-stone-200 border border-stone-800 transition-colors"
            title="Configure voice persona and delivery style"
          >
            <Settings2 className="w-4 h-4" />
          </button>

          <button
            onClick={audioUrl ? togglePlayPause : handleGenerateAudio}
            disabled={isLoadingAudio || !storyText.trim()}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-stone-950 font-semibold text-xs sm:text-sm tracking-wide shadow-lg shadow-amber-500/20 transition-all hover:scale-105 active:scale-95 disabled:opacity-50 flex items-center gap-2"
          >
            {isLoadingAudio ? (
              <>
                <div className="w-4 h-4 rounded-full border-2 border-stone-950 border-t-transparent animate-spin" />
                <span>Synthesizing Voice...</span>
              </>
            ) : isPlaying ? (
              <>
                <Pause className="w-4 h-4 fill-stone-950" />
                <span>Pause Narration</span>
              </>
            ) : audioUrl ? (
              <>
                <Play className="w-4 h-4 fill-stone-950" />
                <span>Play Narration</span>
              </>
            ) : (
              <>
                <Volume2 className="w-4 h-4" />
                <span>Read Aloud</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Voice Configuration Accordion */}
      {showVoiceSettings && (
        <div className="p-4 rounded-xl bg-stone-950/80 border border-stone-800 space-y-4 animate-fadeIn">
          <div className="space-y-2">
            <label className="text-xs font-semibold text-stone-300 flex items-center gap-1.5">
              <Music className="w-3.5 h-3.5 text-amber-500" />
              Select Voice Persona
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2">
              {VOICE_OPTIONS.map((v) => (
                <button
                  key={v.id}
                  onClick={() => setSelectedVoice(v.id)}
                  className={`p-2.5 rounded-xl text-left border transition-all ${
                    selectedVoice === v.id
                      ? 'bg-amber-500/15 border-amber-500 text-stone-100 shadow-sm shadow-amber-500/20'
                      : 'bg-stone-900 border-stone-800 text-stone-400 hover:border-stone-700 hover:text-stone-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-xs text-stone-200">{v.name}</span>
                    <span className="text-[10px] text-stone-500">{v.gender}</span>
                  </div>
                  <p className="text-[11px] text-stone-400 mt-1 line-clamp-2 leading-tight">
                    {v.description}
                  </p>
                </button>
              ))}
            </div>
          </div>

          {/* Delivery Style */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-stone-300">
                Delivery Style & Emotional Color
              </label>
              <button
                onClick={() => setCustomStyle(!customStyle)}
                className="text-[11px] text-amber-400 hover:underline"
              >
                {customStyle ? 'Use Presets' : 'Custom Prompt'}
              </button>
            </div>

            {customStyle ? (
              <input
                type="text"
                value={stylePrompt}
                onChange={(e) => setStylePrompt(e.target.value)}
                placeholder="e.g. Somber Victorian scholar narrating forbidden discoveries..."
                className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-xs text-stone-200 focus:outline-none focus:border-amber-500"
              />
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {VOICE_STYLES.map((style, idx) => (
                  <button
                    key={idx}
                    onClick={() => setStylePrompt(style.prompt)}
                    className={`p-2 rounded-lg text-left text-xs border transition-colors ${
                      stylePrompt === style.prompt
                        ? 'bg-amber-500/10 border-amber-500/60 text-amber-200'
                        : 'bg-stone-900 border-stone-800 text-stone-400 hover:text-stone-300'
                    }`}
                  >
                    <span className="font-medium text-stone-200">{style.label}</span>
                    <p className="text-[10px] text-stone-400 line-clamp-1">{style.prompt}</p>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Audio Visualizer & Wave Canvas */}
      <div className="p-3.5 rounded-xl bg-stone-950/90 border border-stone-800/80 space-y-3">
        <div className="h-12 w-full flex items-center justify-center">
          <canvas
            ref={canvasRef}
            width={380}
            height={44}
            className="w-full h-full max-h-12"
          />
        </div>

        {/* Scrub bar & Timeline */}
        <div className="space-y-1">
          <input
            type="range"
            min={0}
            max={duration || 100}
            step={0.1}
            value={currentTime}
            onChange={handleSeek}
            disabled={!audioUrl}
            className="w-full h-1.5 bg-stone-800 rounded-lg appearance-none cursor-pointer accent-amber-500 disabled:opacity-30"
          />
          <div className="flex items-center justify-between text-[11px] text-stone-400">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* Controls row */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-stone-800/60 text-xs">
          {/* Play/Pause + Re-synth */}
          <div className="flex items-center gap-2">
            <button
              onClick={togglePlayPause}
              disabled={isLoadingAudio || !storyText.trim()}
              className="p-2 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 transition-colors disabled:opacity-40"
              title={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            </button>

            {audioUrl && (
              <button
                onClick={handleGenerateAudio}
                disabled={isLoadingAudio}
                className="px-2.5 py-1.5 rounded-lg bg-stone-900 hover:bg-stone-800 text-stone-300 text-xs border border-stone-800 transition-colors flex items-center gap-1"
                title="Re-synthesize speech (useful if you changed words)"
              >
                <RotateCcw className="w-3 h-3 text-stone-400" />
                <span className="hidden sm:inline">Re-narrate</span>
              </button>
            )}
          </div>

          {/* Speed chips */}
          <div className="flex items-center gap-1 bg-stone-900 p-1 rounded-lg border border-stone-800">
            {[0.8, 1.0, 1.25, 1.5].map((speed) => (
              <button
                key={speed}
                onClick={() => setPlaybackSpeed(speed)}
                className={`px-2 py-0.5 rounded text-[10px] font-medium transition-colors ${
                  playbackSpeed === speed
                    ? 'bg-amber-500 text-stone-950 font-semibold'
                    : 'text-stone-400 hover:text-stone-200'
                }`}
              >
                {speed}x
              </button>
            ))}
          </div>

          {/* Download Audio */}
          {audioUrl && (
            <button
              onClick={handleDownload}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-stone-900 hover:bg-stone-800 text-stone-300 border border-stone-800 transition-colors text-xs"
              title="Download narrated audio as WAV"
            >
              <Download className="w-3.5 h-3.5 text-stone-400" />
              <span>Save Audio</span>
            </button>
          )}
        </div>
      </div>

      {/* Error Message */}
      {audioError && (
        <div className="p-3 rounded-xl bg-red-950/40 border border-red-800/60 text-red-300 text-xs text-center">
          {audioError}
        </div>
      )}
    </div>
  );
};
