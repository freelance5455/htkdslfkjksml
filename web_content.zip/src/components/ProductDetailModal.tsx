import React, { useState } from 'react';
import { Product, AppLanguage } from '../types';
import { formatPKR } from '../utils/storage';
import { X, Plus, Minus, ShoppingBag, CheckCircle2, AlertCircle, Share2 } from 'lucide-react';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  quantityInCart: number;
  onAddToCart: (product: Product) => void;
  onUpdateQuantity: (productId: string, quantity: number) => void;
  language: AppLanguage;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  quantityInCart,
  onAddToCart,
  onUpdateQuantity,
  language
}) => {
  if (!product) return null;
  const isUrdu = language === 'ur';
  const [copied, setCopied] = useState(false);

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `${product.urduName} - اویس بلال سٹور`,
        text: `اویس بلال سٹور (03017144300): ${product.urduName} (${product.unit}) - قیمت: Rs. ${product.price}`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(`${product.urduName} (${product.unit}) - قیمت: Rs. ${product.price} | اویس بلال سٹور 03017144300`);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl max-h-[90vh] flex flex-col">
        {/* Modal Header */}
        <div className="relative aspect-4/3 w-full bg-slate-100">
          <img
            src={product.image}
            alt={product.urduName || product.name}
            className="w-full h-full object-cover"
          />
          <button
            onClick={onClose}
            className="absolute top-3 right-3 w-9 h-9 rounded-full bg-black/50 text-white flex items-center justify-center hover:bg-black/70 transition"
          >
            <X className="w-5 h-5" />
          </button>
          {product.badge && (
            <span className="absolute bottom-3 left-3 bg-amber-500 text-emerald-950 font-bold text-xs px-3 py-1 rounded-full shadow-md">
              {product.badge}
            </span>
          )}
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 flex-1 overflow-y-auto">
          <div className="flex items-center justify-between gap-2 mb-2">
            <span className="text-xs bg-emerald-100 text-emerald-800 font-semibold px-2.5 py-0.5 rounded-full">
              {product.unit}
            </span>
            <div className="flex items-center gap-1">
              {product.inStock ? (
                <span className="flex items-center gap-1 text-xs text-emerald-700 font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {isUrdu ? 'دستیاب ہے' : 'In Stock'}
                </span>
              ) : (
                <span className="flex items-center gap-1 text-xs text-red-600 font-bold">
                  <AlertCircle className="w-3.5 h-3.5" />
                  {isUrdu ? 'آؤٹ آف اسٹاک' : 'Out of Stock'}
                </span>
              )}
            </div>
          </div>

          <h2 className="text-xl font-bold text-slate-900 leading-snug">
            {product.urduName}
          </h2>
          <p className="text-sm text-slate-500 font-medium mt-0.5">
            {product.name}
          </p>

          {/* Pricing */}
          <div className="flex items-baseline gap-3 my-3">
            <span className="text-2xl font-black text-emerald-800">
              {formatPKR(product.price, isUrdu)}
            </span>
            {product.originalPrice && product.originalPrice > product.price && (
              <span className="text-sm text-slate-400 line-through">
                {formatPKR(product.originalPrice, isUrdu)}
              </span>
            )}
          </div>

          {/* Descriptions */}
          <div className="bg-slate-50 rounded-2xl p-3 border border-slate-100 text-sm space-y-1.5 text-slate-700">
            {product.urduDescription && (
              <p className="font-urdu leading-relaxed text-slate-800">
                {product.urduDescription}
              </p>
            )}
            {product.description && (
              <p className="text-xs text-slate-500 font-normal">
                {product.description}
              </p>
            )}
          </div>

          {/* Village Delivery Note */}
          <div className="mt-3 p-2.5 rounded-xl bg-amber-50 border border-amber-200/80 text-amber-900 text-xs flex items-center justify-between">
            <span>ہمارے گاؤں اور قریبی دیہات کے لیے ہوم ڈیلیوری۔</span>
            <button
              onClick={handleShare}
              className="text-amber-800 font-bold flex items-center gap-1 text-[11px] underline ml-2"
            >
              <Share2 className="w-3.5 h-3.5" />
              {copied ? 'کاپی ہوگیا' : 'شیئر کریں'}
            </button>
          </div>
        </div>

        {/* Modal Footer / Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3">
          {product.inStock ? (
            quantityInCart > 0 ? (
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center gap-2 bg-emerald-700 text-white rounded-2xl p-1.5 px-3">
                  <button
                    onClick={() => onUpdateQuantity(product.id, quantityInCart - 1)}
                    className="w-8 h-8 flex items-center justify-center rounded-xl hover:bg-emerald-800 transition"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-8 text-center font-bold text-sm">
                    {quantityInCart}
                  </span>
                  <button
                    onClick={() => onUpdateQuantity(product.id, quantityInCart + 1)}
                    className="w-8 h-8 flex items-center justify-center rounded-xl hover:bg-emerald-800 transition"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                <button
                  onClick={onClose}
                  className="bg-emerald-800 text-white font-bold px-5 py-2.5 rounded-2xl text-xs shadow-md"
                >
                  {isUrdu ? 'کارٹ دیکھیں' : 'View Cart'}
                </button>
              </div>
            ) : (
              <button
                onClick={() => onAddToCart(product)}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-2xl shadow-md flex items-center justify-center gap-2 text-sm transition active:scale-98"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>{isUrdu ? 'کارٹ میں شامل کریں' : 'Add to Cart'}</span>
              </button>
            )
          ) : (
            <button
              disabled
              className="w-full bg-slate-200 text-slate-500 font-bold py-3 rounded-2xl cursor-not-allowed text-xs"
            >
              {isUrdu ? 'یہ سامان فی الحال موجود نہیں ہے' : 'Currently Unavailable'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
