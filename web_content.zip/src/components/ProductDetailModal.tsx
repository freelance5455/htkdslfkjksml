import React, { useState } from 'react';
import { X, Star, Heart, Check, Shield, Truck, RotateCcw, Plus, Minus, MessageSquarePlus } from 'lucide-react';
import { Product, CurrencyCode, Review } from '../types';
import { formatPrice } from '../utils/currency';

interface ProductDetailModalProps {
  product: Product | null;
  activeCurrency: CurrencyCode;
  isWishlisted: boolean;
  reviews: Review[];
  onClose: () => void;
  onToggleWishlist: (productId: string) => void;
  onAddToCart: (product: Product, quantity: number) => void;
  onAddReview: (review: Omit<Review, 'id' | 'date'>) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  activeCurrency,
  isWishlisted,
  reviews,
  onClose,
  onToggleWishlist,
  onAddToCart,
  onAddReview
}) => {
  if (!product) return null;

  const [quantity, setQuantity] = useState(1);
  const [justAdded, setJustAdded] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'specs' | 'reviews'>('overview');

  // Review submission state
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [newAuthor, setNewAuthor] = useState('');
  const [newRating, setNewRating] = useState(5);
  const [newTitle, setNewTitle] = useState('');
  const [newComment, setNewComment] = useState('');

  const productReviews = reviews.filter((r) => r.productId === product.id);

  const handleAdd = () => {
    onAddToCart(product, quantity);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 2000);
  };

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAuthor.trim() || !newComment.trim()) return;

    onAddReview({
      productId: product.id,
      author: newAuthor.trim(),
      rating: newRating,
      title: newTitle.trim() || 'Verified Customer Review',
      comment: newComment.trim(),
      verifiedPurchase: true
    });

    setNewAuthor('');
    setNewTitle('');
    setNewComment('');
    setShowReviewForm(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-stone-200 relative flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 rounded-full bg-white/90 text-stone-600 hover:text-stone-900 hover:bg-stone-100 transition-colors cursor-pointer shadow-sm border border-stone-200"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-0 md:gap-8">
          {/* Left Column: Product Image */}
          <div className="md:col-span-6 bg-stone-100 flex items-center justify-center relative p-4 sm:p-6 md:p-8">
            <img
              src={product.image}
              alt={product.name}
              referrerPolicy="no-referrer"
              className="w-full h-auto max-h-[460px] object-cover rounded-xl shadow-sm"
            />
            {product.badge && (
              <span className="absolute top-6 left-6 bg-[#2D2A26] text-white text-xs uppercase tracking-wider font-semibold px-3 py-1 rounded">
                {product.badge}
              </span>
            )}
          </div>

          {/* Right Column: Information & Actions */}
          <div className="md:col-span-6 p-6 sm:p-8 flex flex-col justify-between">
            <div>
              {/* Category & Room */}
              <div className="flex items-center gap-2 text-xs text-stone-500 uppercase tracking-widest font-medium mb-1.5">
                <span>{product.category}</span>
                <span aria-hidden="true">·</span>
                <span>{product.room}</span>
              </div>

              {/* Title & Arabic name */}
              <h2 className="font-serif text-2xl sm:text-3xl text-stone-900 leading-snug">
                {product.name}
              </h2>
              {product.arabicSubtitle && (
                <p className="text-stone-500 font-serif text-sm mt-0.5">
                  {product.arabicSubtitle}
                </p>
              )}

              {/* Rating */}
              <div className="flex items-center gap-2 mt-2.5">
                <div className="flex items-center text-amber-500">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.floor(product.rating)
                          ? 'fill-amber-400 text-amber-400'
                          : 'text-stone-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-xs font-semibold text-stone-800 tabular-nums">
                  {product.rating}
                </span>
                <span className="text-xs text-stone-500">
                  ({productReviews.length + product.reviewsCount} customer reviews)
                </span>
              </div>

              {/* Price */}
              <div className="mt-4 flex items-baseline gap-3">
                <span className="text-2xl font-bold text-stone-900 tabular-nums">
                  {formatPrice(product.priceUsd, activeCurrency)}
                </span>
                {product.originalPriceUsd && (
                  <span className="text-sm text-stone-400 line-through tabular-nums">
                    {formatPrice(product.originalPriceUsd, activeCurrency)}
                  </span>
                )}
                <span className="text-xs text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-medium">
                  In Stock ({product.stockCount} units available)
                </span>
              </div>

              {/* Navigation Tabs */}
              <div className="flex items-center gap-4 border-b border-stone-200 mt-6 text-xs font-semibold">
                <button
                  onClick={() => setActiveTab('overview')}
                  className={`pb-2 transition-colors cursor-pointer ${
                    activeTab === 'overview'
                      ? 'border-b-2 border-stone-900 text-stone-900'
                      : 'text-stone-500 hover:text-stone-800'
                  }`}
                >
                  Overview
                </button>
                <button
                  onClick={() => setActiveTab('specs')}
                  className={`pb-2 transition-colors cursor-pointer ${
                    activeTab === 'specs'
                      ? 'border-b-2 border-stone-900 text-stone-900'
                      : 'text-stone-500 hover:text-stone-800'
                  }`}
                >
                  Materials & Care
                </button>
                <button
                  onClick={() => setActiveTab('reviews')}
                  className={`pb-2 transition-colors cursor-pointer ${
                    activeTab === 'reviews'
                      ? 'border-b-2 border-stone-900 text-stone-900'
                      : 'text-stone-500 hover:text-stone-800'
                  }`}
                >
                  Reviews ({productReviews.length})
                </button>
              </div>

              {/* Tab Contents */}
              <div className="mt-4 min-h-[120px] text-xs text-stone-600 leading-relaxed">
                {activeTab === 'overview' && (
                  <div>
                    <p className="mb-3">{product.description}</p>
                    <ul className="space-y-1.5 list-disc list-inside text-stone-700">
                      {product.features.map((feature, i) => (
                        <li key={i}>{feature}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {activeTab === 'specs' && (
                  <div className="space-y-3">
                    <div>
                      <span className="font-semibold text-stone-800 block">Materials:</span>
                      <p>{product.materials}</p>
                    </div>
                    <div>
                      <span className="font-semibold text-stone-800 block">Dimensions:</span>
                      <p>{product.dimensions}</p>
                    </div>
                    <div>
                      <span className="font-semibold text-stone-800 block">Care Guide:</span>
                      <p>{product.careInstructions}</p>
                    </div>
                  </div>
                )}

                {activeTab === 'reviews' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-stone-800">Verified Testimonials</span>
                      <button
                        onClick={() => setShowReviewForm(!showReviewForm)}
                        className="text-stone-900 font-semibold underline hover:text-stone-700 cursor-pointer flex items-center gap-1"
                      >
                        <MessageSquarePlus className="w-3.5 h-3.5" />
                        <span>{showReviewForm ? 'Cancel' : 'Write a Review'}</span>
                      </button>
                    </div>

                    {showReviewForm && (
                      <form onSubmit={handleSubmitReview} className="bg-stone-50 p-3.5 rounded-lg border border-stone-200 space-y-2.5">
                        <div>
                          <label className="block text-[11px] font-semibold text-stone-700 mb-0.5">Your Name</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. Fatima A."
                            value={newAuthor}
                            onChange={(e) => setNewAuthor(e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-white border border-stone-300 rounded text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-semibold text-stone-700 mb-0.5">Rating</label>
                          <div className="flex gap-1 text-amber-500">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <button
                                type="button"
                                key={star}
                                onClick={() => setNewRating(star)}
                                className="cursor-pointer"
                              >
                                <Star className={`w-4 h-4 ${star <= newRating ? 'fill-amber-400 text-amber-400' : 'text-stone-300'}`} />
                              </button>
                            ))}
                          </div>
                        </div>
                        <div>
                          <label className="block text-[11px] font-semibold text-stone-700 mb-0.5">Headline</label>
                          <input
                            type="text"
                            placeholder="Summarize your experience..."
                            value={newTitle}
                            onChange={(e) => setNewTitle(e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-white border border-stone-300 rounded text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-semibold text-stone-700 mb-0.5">Your Feedback</label>
                          <textarea
                            required
                            rows={2}
                            placeholder="How is the texture, weight, craftsmanship?"
                            value={newComment}
                            onChange={(e) => setNewComment(e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-white border border-stone-300 rounded text-xs"
                          />
                        </div>
                        <button
                          type="submit"
                          className="px-3 py-1.5 bg-stone-900 text-white rounded text-xs font-medium hover:bg-stone-800 cursor-pointer"
                        >
                          Submit Review
                        </button>
                      </form>
                    )}

                    {productReviews.length === 0 ? (
                      <p className="text-stone-500 italic">No customer reviews yet. Be the first to share your thoughts!</p>
                    ) : (
                      <div className="space-y-3 max-h-48 overflow-y-auto pr-1">
                        {productReviews.map((rev) => (
                          <div key={rev.id} className="border-b border-stone-100 pb-2.5">
                            <div className="flex items-center justify-between text-[11px] text-stone-500">
                              <span className="font-semibold text-stone-800">{rev.author}</span>
                              <span>{rev.date}</span>
                            </div>
                            <div className="flex items-center gap-1 text-amber-400 my-0.5">
                              {[...Array(rev.rating)].map((_, i) => (
                                <Star key={i} className="w-3 h-3 fill-amber-400 text-amber-400" />
                              ))}
                            </div>
                            <p className="font-medium text-stone-800 text-xs">{rev.title}</p>
                            <p className="text-stone-600 text-xs mt-0.5">{rev.comment}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Bottom Actions: Quantity Stepper, Add to Bag, Wishlist */}
            <div className="mt-6 pt-5 border-t border-stone-200">
              <div className="flex items-center gap-3">
                {/* Quantity Stepper */}
                <div className="flex items-center border border-stone-300 rounded-lg bg-stone-50">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-2.5 text-stone-600 hover:text-stone-900 cursor-pointer"
                    aria-label="Decrease quantity"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="px-3 text-xs font-semibold tabular-nums text-stone-900">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(Math.min(product.stockCount, quantity + 1))}
                    className="p-2.5 text-stone-600 hover:text-stone-900 cursor-pointer"
                    aria-label="Increase quantity"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Add to Bag Button */}
                <button
                  onClick={handleAdd}
                  disabled={!product.inStock}
                  className={`flex-1 py-3 px-4 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    justAdded
                      ? 'bg-emerald-700 text-white'
                      : 'bg-[#2D2A26] hover:bg-stone-850 text-white shadow-sm'
                  }`}
                >
                  {justAdded ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Added to Bag</span>
                    </>
                  ) : (
                    <>
                      <span>Add to Bag</span>
                      <span className="opacity-80">·</span>
                      <span className="tabular-nums">
                        {formatPrice(product.priceUsd * quantity, activeCurrency)}
                      </span>
                    </>
                  )}
                </button>

                {/* Wishlist Button */}
                <button
                  onClick={() => onToggleWishlist(product.id)}
                  className={`p-3 rounded-lg border transition-colors cursor-pointer ${
                    isWishlisted
                      ? 'border-rose-200 bg-rose-50 text-rose-600'
                      : 'border-stone-300 bg-white text-stone-600 hover:text-stone-900 hover:bg-stone-50'
                  }`}
                  aria-label="Wishlist toggle"
                >
                  <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-rose-500' : ''}`} />
                </button>
              </div>

              {/* Guarantees */}
              <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-stone-100 text-[11px] text-stone-500 text-center">
                <div className="flex flex-col items-center gap-1">
                  <Truck className="w-3.5 h-3.5 text-stone-400" />
                  <span>Free Express Delivery</span>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <RotateCcw className="w-3.5 h-3.5 text-stone-400" />
                  <span>30-Day Pure Return</span>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <Shield className="w-3.5 h-3.5 text-stone-400" />
                  <span>10-Year Craft Warranty</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
