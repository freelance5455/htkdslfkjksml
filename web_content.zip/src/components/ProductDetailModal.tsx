import React, { useState } from 'react';
import { 
  X, 
  ShoppingBag, 
  Zap, 
  ShieldCheck, 
  CheckCircle2, 
  AlertTriangle, 
  Truck, 
  Download, 
  Layers, 
  Star,
  Plus,
  Minus
} from 'lucide-react';
import { Product } from '../types';
import { useStore } from '../context/StoreContext';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({ product, onClose }) => {
  const { addToCart, buyNow } = useStore();
  const [quantity, setQuantity] = useState(1);

  if (!product) return null;

  const isOutOfStock = product.stock <= 0;
  const isLowStock = product.stock > 0 && product.stock <= product.minStockAlert;

  const handleAddToCart = () => {
    addToCart(product, quantity);
    onClose();
  };

  const handleBuyNow = () => {
    onClose();
    buyNow(product);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 z-10 p-2 text-slate-400 hover:text-slate-800 bg-white/80 hover:bg-white rounded-full transition-colors shadow-xs"
          aria-label="Fechar janela"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          
          {/* Left Column: Image & Media */}
          <div className="bg-slate-100 relative min-h-[280px] md:min-h-full flex items-center justify-center overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
              onError={(e) => { (e.target as HTMLElement).style.display = 'none'; }}
            />

            {/* Overlaid Badges */}
            <div className="absolute top-4 left-4 flex flex-col gap-1.5 items-start">
              {isOutOfStock ? (
                <span className="px-2.5 py-1 rounded bg-rose-600 text-white text-xs font-bold shadow-xs">
                  Esgotado
                </span>
              ) : isLowStock ? (
                <span className="px-2.5 py-1 rounded bg-amber-500 text-white text-xs font-bold shadow-xs flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Apenas {product.stock} un. restantes</span>
                </span>
              ) : (
                <span className="px-2.5 py-1 rounded bg-emerald-700 text-white text-xs font-medium shadow-xs">
                  {product.stock} unidades disponíveis
                </span>
              )}

              {product.type === 'digital' ? (
                <span className="px-2 py-0.5 rounded bg-purple-700/80 backdrop-blur-xs text-white text-[11px] font-medium flex items-center gap-1">
                  <Download className="w-3 h-3" />
                  <span>Download Instantâneo</span>
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded bg-blue-700/80 backdrop-blur-xs text-white text-[11px] font-medium flex items-center gap-1">
                  <Truck className="w-3 h-3" />
                  <span>Envio Postal Moçambique</span>
                </span>
              )}
            </div>
          </div>

          {/* Right Column: Contiguous Purchase Module */}
          <div className="p-6 md:p-8 flex flex-col justify-between space-y-6">
            
            <div className="space-y-4">
              
              {/* Category, SKU & Rating */}
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-semibold text-emerald-700 uppercase tracking-wider text-[11px]">
                  {product.category}
                </span>
                <span className="font-mono text-slate-400">SKU: {product.sku}</span>
              </div>

              {/* Title */}
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 leading-snug">
                {product.name}
              </h2>

              {/* Price Row */}
              <div className="flex items-baseline gap-2 pt-1 border-t border-slate-100">
                <span className="text-2xl sm:text-3xl font-extrabold font-mono text-slate-900 tabular-nums">
                  {product.price.toLocaleString('pt-MZ')} MT
                </span>
                {product.originalPrice && (
                  <span className="text-sm text-slate-400 line-through font-mono tabular-nums">
                    {product.originalPrice.toLocaleString('pt-MZ')} MT
                  </span>
                )}
                <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded ml-auto">
                  Taxas: 0 MT
                </span>
              </div>

              {/* Description */}
              <p className="text-xs text-slate-600 leading-relaxed">
                {product.description}
              </p>

              {/* Included Features */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <div className="text-xs font-bold text-slate-900">
                  O que está incluso:
                </div>
                <ul className="space-y-1.5 text-xs text-slate-600">
                  {product.features.map((feat, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Format / Delivery note */}
              {product.weightOrFormat && (
                <div className="text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                  <strong>Especificação:</strong> {product.weightOrFormat}
                </div>
              )}
            </div>

            {/* Quantity Stepper & Buy Action Buttons */}
            <div className="space-y-3 pt-4 border-t border-slate-100">
              
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-700">Quantidade:</span>
                
                <div className="flex items-center gap-2 border border-slate-200 rounded-lg p-1 bg-slate-50">
                  <button
                    onClick={() => setQuantity(q => Math.max(1, q - 1))}
                    disabled={quantity <= 1 || isOutOfStock}
                    className="p-1 text-slate-600 hover:bg-white rounded transition-colors disabled:opacity-30"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="font-mono text-xs font-bold text-slate-900 px-2 min-w-8 text-center">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(q => Math.min(product.stock, q + 1))}
                    disabled={quantity >= product.stock || isOutOfStock}
                    className="p-1 text-slate-600 hover:bg-white rounded transition-colors disabled:opacity-30"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  onClick={handleAddToCart}
                  disabled={isOutOfStock}
                  className="py-3 px-4 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 text-slate-800 font-semibold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Adicionar</span>
                </button>

                <button
                  onClick={handleBuyNow}
                  disabled={isOutOfStock}
                  className="py-3 px-4 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5"
                >
                  <Zap className="w-4 h-4" />
                  <span>Comprar Agora</span>
                </button>
              </div>

              {/* Security note */}
              <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500 pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Pagamento verificado pelo gateway EscalePay Moçambique</span>
              </div>

            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
