import React, { useEffect, useState } from 'react';
import {
  X,
  ShoppingBag,
  ArrowUpRight,
  ArrowLeft,
  Minus,
  Plus,
  CheckCircle2,
  AlertCircle,
  ImageOff,
} from 'lucide-react';
import { Product } from '../types/store';
import { formatCurrency, getDiscountPercent, getEffectivePrice } from '../lib/formatters';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, size: string, color: string, quantity: number) => void;
  onBuyNow: (product: Product, size: string, color: string, quantity: number) => void;
}

export function ProductDetailModal({
  product,
  onClose,
  onAddToCart,
  onBuyNow,
}: ProductDetailModalProps) {
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [imgFailed, setImgFailed] = useState(false);

  useEffect(() => {
    if (product) {
      setSelectedSize(product.sizes[0] || 'M');
      setSelectedColor(product.colors[0] || 'Standard');
      setQuantity(1);
      setImgFailed(false);
    }
  }, [product]);

  if (!product) return null;

  const effectivePrice = getEffectivePrice(product);
  const discountPct = getDiscountPercent(product.price, product.discountPrice);
  const outOfStock = product.stock <= 0;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/55 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-label={product.name}
    >
      <div className="relative bg-white w-full max-w-4xl border border-neutral-200 shadow-2xl grid grid-cols-1 md:grid-cols-2 overflow-hidden my-auto">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 left-4 z-10 inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-white/95 border border-neutral-200 text-xs font-medium text-[#0A0A0A] hover:bg-[#0A0A0A] hover:text-white transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back</span>
        </button>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close product details"
          className="absolute top-4 right-4 z-10 w-9 h-9 rounded-full bg-white/90 border border-neutral-200 flex items-center justify-center text-[#0A0A0A] hover:bg-[#0A0A0A] hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Left: Product Imagery */}
        <div className="bg-[#F6F6F6] aspect-[3/4] md:aspect-auto md:min-h-[520px] relative">
          {!imgFailed && product.imageUrl ? (
            <img
              src={product.imageUrl}
              alt={product.name}
              referrerPolicy="no-referrer"
              onError={() => setImgFailed(true)}
              className="w-full h-full object-cover object-center"
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center">
              <ImageOff className="w-8 h-8 text-neutral-400 mb-2" />
              <span className="text-sm text-neutral-500">{product.name}</span>
            </div>
          )}
        </div>

        {/* Right: Contiguous Purchase Module */}
        <div className="p-6 sm:p-8 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-neutral-500 mb-2">
              <span>{product.category}</span>
              <span aria-hidden="true">·</span>
              <span>{product.gender}</span>
              {product.isNewArrival && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="text-[#0A0A0A] font-semibold">New Arrival</span>
                </>
              )}
            </div>

            <h2 className="font-display text-2xl sm:text-3xl font-semibold text-[#0A0A0A] leading-tight mb-3">
              {product.name}
            </h2>

            <div className="flex items-baseline gap-3 mb-4 tabular-nums">
              <span className="text-2xl font-semibold text-[#0A0A0A]">
                {formatCurrency(effectivePrice)}
              </span>
              {discountPct > 0 && (
                <>
                  <span className="text-sm text-neutral-400 line-through">
                    {formatCurrency(product.price)}
                  </span>
                  <span className="text-xs font-semibold text-[#0A0A0A]">
                    Save {discountPct}%
                  </span>
                </>
              )}
            </div>

            <div className="flex items-center gap-2 text-xs mb-5">
              {outOfStock ? (
                <span className="inline-flex items-center gap-1.5 text-red-700 font-medium">
                  <AlertCircle className="w-3.5 h-3.5" />
                  Currently Out of Stock
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 text-neutral-700 font-medium tabular-nums">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#0A0A0A]" />
                  In Stock — {product.stock} available for dispatch
                </span>
              )}
            </div>

            <p className="text-sm text-neutral-600 leading-relaxed mb-6">
              {product.description}
            </p>

            {/* Color Selection */}
            <div className="mb-5">
              <div className="text-xs font-medium text-neutral-700 mb-2">
                Color: <span className="text-[#0A0A0A] font-semibold">{selectedColor}</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {product.colors.map((color) => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => setSelectedColor(color)}
                    className={`px-3.5 py-1.5 text-xs font-medium rounded-full border transition-colors cursor-pointer ${
                      selectedColor === color
                        ? 'bg-[#0A0A0A] text-white border-[#0A0A0A]'
                        : 'bg-white text-neutral-700 border-neutral-200 hover:border-neutral-400'
                    }`}
                  >
                    {color}
                  </button>
                ))}
              </div>
            </div>

            {/* Size Selection */}
            <div className="mb-6">
              <div className="text-xs font-medium text-neutral-700 mb-2">
                Size: <span className="text-[#0A0A0A] font-semibold">{selectedSize}</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    type="button"
                    onClick={() => setSelectedSize(size)}
                    className={`min-w-[44px] h-10 px-3 text-xs font-semibold rounded-md border transition-colors cursor-pointer ${
                      selectedSize === size
                        ? 'bg-[#0A0A0A] text-white border-[#0A0A0A]'
                        : 'bg-white text-neutral-700 border-neutral-200 hover:border-neutral-400'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Quantity & Actions */}
          <div className="pt-5 border-t border-neutral-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-neutral-600">Quantity</span>
              <div className="inline-flex items-center border border-neutral-200 rounded-full">
                <button
                  type="button"
                  disabled={quantity <= 1 || outOfStock}
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  aria-label="Decrease quantity"
                  className="w-9 h-9 flex items-center justify-center text-neutral-700 hover:text-[#0A0A0A] disabled:opacity-40 cursor-pointer"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="w-8 text-center text-xs font-semibold tabular-nums">
                  {quantity}
                </span>
                <button
                  type="button"
                  disabled={quantity >= product.stock || outOfStock}
                  onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))}
                  aria-label="Increase quantity"
                  className="w-9 h-9 flex items-center justify-center text-neutral-700 hover:text-[#0A0A0A] disabled:opacity-40 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="button"
                disabled={outOfStock}
                onClick={() => {
                  onAddToCart(product, selectedSize, selectedColor, quantity);
                  onClose();
                }}
                className="inline-flex items-center justify-center gap-2 py-3 px-5 rounded-full border border-[#0A0A0A] text-[#0A0A0A] text-xs font-semibold hover:bg-neutral-100 disabled:opacity-40 cursor-pointer"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Add to Cart</span>
              </button>
              <button
                type="button"
                disabled={outOfStock}
                onClick={() => {
                  onBuyNow(product, selectedSize, selectedColor, quantity);
                  onClose();
                }}
                className="inline-flex items-center justify-center gap-2 py-3 px-5 rounded-full bg-[#0A0A0A] text-white text-xs font-semibold hover:bg-neutral-800 disabled:opacity-40 cursor-pointer"
              >
                <span>Buy Now</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
