import React, { useState } from 'react';
import { 
  Building2, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  Lock, 
  RefreshCw, 
  Edit3, 
  CreditCard,
  Check,
  X,
  Info
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const SbiBankVerificationCard: React.FC = () => {
  const { sbiBankAccount, linkSbiBankAccount, unlinkSbiBankAccount, currentUser } = useApp();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [accountName, setAccountName] = useState(currentUser?.name || '');
  const [accountNumber, setAccountNumber] = useState('');
  const [confirmAccountNumber, setConfirmAccountNumber] = useState('');
  const [ifscCode, setIfscCode] = useState('SBIN0001234');
  const [consent, setConsent] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isLinked = !!sbiBankAccount && sbiBankAccount.status === 'verified';

  const handleLinkSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!accountName.trim() || accountName.trim().length < 3) {
      setErrorMsg('Please enter your full official name as registered with SBI.');
      return;
    }

    if (!/^\d{9,18}$/.test(accountNumber.trim())) {
      setErrorMsg('Please enter a valid SBI account number (9 to 18 numeric digits).');
      return;
    }

    if (accountNumber.trim() !== confirmAccountNumber.trim()) {
      setErrorMsg('Account number and confirmation account number do not match.');
      return;
    }

    const cleanIfsc = ifscCode.trim().toUpperCase();
    if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(cleanIfsc)) {
      setErrorMsg('Please enter a valid 11-character Indian Financial System Code (IFSC), e.g. SBIN0001234.');
      return;
    }

    if (!consent) {
      setErrorMsg('Please accept the Penny-Drop verification authorization consent.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const res = linkSbiBankAccount(accountName, accountNumber, cleanIfsc);
      setIsSubmitting(false);
      if (res.success) {
        setSuccessMsg(res.message);
        setTimeout(() => {
          setIsModalOpen(false);
          setAccountNumber('');
          setConfirmAccountNumber('');
          setSuccessMsg(null);
        }, 1500);
      } else {
        setErrorMsg(res.message);
      }
    }, 800);
  };

  return (
    <div className="p-5 rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-blue-950/40 border border-blue-500/40 shadow-xl shadow-blue-950/20 space-y-4 relative overflow-hidden group hover:border-blue-400/60 transition-all">
      {/* Glow accent */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-start justify-between gap-3 relative z-10">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400 shadow-inner">
            <Building2 className="w-5 h-5 text-blue-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-black text-white">SBI Bank Account Verification</h3>
              <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider border ${
                isLinked 
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                  : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
              }`}>
                {isLinked ? 'Verified & Linked' : 'Verification Required'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              State Bank of India (SBI) Direct Instant Payout Routing
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            setErrorMsg(null);
            setSuccessMsg(null);
            setIsModalOpen(true);
          }}
          className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-md active:scale-95 shrink-0"
        >
          <Edit3 className="w-3.5 h-3.5" />
          <span>{isLinked ? 'Change Bank' : 'Verify SBI Bank'}</span>
        </button>
      </div>

      {/* Linked Account Details or Unlinked State */}
      {isLinked && sbiBankAccount ? (
        <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3 relative z-10">
          <div className="flex items-center justify-between flex-wrap gap-2 text-xs">
            <div>
              <span className="text-[10px] text-slate-400 block font-semibold uppercase tracking-wider">Account Holder Name</span>
              <span className="font-black text-white text-sm">{sbiBankAccount.accountHolderName}</span>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block font-semibold uppercase tracking-wider">Verification Protocol</span>
              <span className="text-[11px] font-mono text-emerald-400 font-bold flex items-center gap-1 justify-end">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                NPCI Penny-Drop Synced
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-2 border-t border-slate-850 text-xs">
            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">Masked Account Number</span>
              <span className="font-mono font-black text-blue-300 text-xs">{sbiBankAccount.maskedAccountNumber}</span>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">Bank IFSC Code</span>
              <span className="font-mono font-bold text-slate-200">{sbiBankAccount.ifscCode}</span>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 col-span-2 sm:col-span-1">
              <span className="text-[10px] text-slate-400 block">Withdrawal Eligibility</span>
              <span className="font-bold text-emerald-400 flex items-center gap-1">
                <Check className="w-3 h-3 text-emerald-400" />
                Eligible for Instant Cashout
              </span>
            </div>
          </div>
        </div>
      ) : (
        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/25 space-y-2 text-xs text-amber-200 relative z-10">
          <div className="flex items-center gap-2 font-bold">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>No Verified SBI Bank Account Linked</span>
          </div>
          <p className="text-[11px] text-slate-300 leading-relaxed">
            Link your SBI savings or current account to enable secure withdrawals up to ₹50,000 daily. Accounts are verified via legitimate NPCI Penny-Drop without asking for confidential credentials.
          </p>
        </div>
      )}

      {/* Strict Security Compliance Banner */}
      <div className="p-3 rounded-2xl bg-slate-950/90 border border-slate-800 text-[11px] text-slate-400 flex items-start gap-2.5 relative z-10">
        <Lock className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
        <div>
          <strong className="text-slate-200 block">100% Secure RBI & NPCI Fintech Guidelines:</strong>
          <span>We <strong>never</strong> collect, prompt, or store your SBI Internet Banking Password, ATM PIN, CVV number, or SMS OTPs. Verification uses certified non-intrusive Penny-Drop name matching.</span>
        </div>
      </div>

      {/* Linking Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="max-w-md w-full bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-blue-500/50 rounded-3xl p-5 sm:p-6 space-y-4">
            
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-blue-400" />
                <h3 className="font-black text-white text-base">Link & Verify SBI Bank Account</h3>
              </div>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleLinkSubmit} className="space-y-3.5 text-xs">
              
              <div>
                <label className="text-[11px] font-bold text-slate-300 block mb-1">
                  Account Holder Full Name (as per SBI records)
                </label>
                <input
                  type="text"
                  value={accountName}
                  onChange={(e) => setAccountName(e.target.value)}
                  placeholder="e.g. Subhodip Garai"
                  required
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-600 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-300 block mb-1">
                  SBI Account Number
                </label>
                <input
                  type="password"
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  placeholder="Enter 9 to 18 digit account number"
                  required
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-600 font-mono focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-300 block mb-1">
                  Confirm SBI Account Number
                </label>
                <input
                  type="text"
                  value={confirmAccountNumber}
                  onChange={(e) => setConfirmAccountNumber(e.target.value)}
                  placeholder="Re-enter account number"
                  required
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-600 font-mono focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-300 block mb-1">
                  SBI IFSC Code
                </label>
                <input
                  type="text"
                  value={ifscCode}
                  onChange={(e) => setIfscCode(e.target.value.toUpperCase())}
                  placeholder="e.g. SBIN0001234"
                  required
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-600 font-mono uppercase focus:outline-none focus:border-blue-500"
                />
                <span className="text-[10px] text-slate-500 mt-0.5 block">State Bank of India IFSC code always starts with SBIN</span>
              </div>

              <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-[10px] text-slate-300 flex items-start gap-2">
                <input
                  type="checkbox"
                  id="sbiConsent"
                  checked={consent}
                  onChange={(e) => setConsent(e.target.checked)}
                  className="mt-0.5 rounded border-slate-700 bg-slate-900 text-blue-500 cursor-pointer"
                />
                <label htmlFor="sbiConsent" className="cursor-pointer">
                  I authorize Task Earn Pro to verify my SBI bank details via authorized NPCI Penny-Drop service for processing earnings payouts.
                </label>
              </div>

              {errorMsg && (
                <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {successMsg && (
                <div className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{successMsg}</span>
                </div>
              )}

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold hover:bg-slate-750 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-black shadow-lg shadow-blue-600/20 transition-all cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? 'Verifying...' : 'Verify & Link Now'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
