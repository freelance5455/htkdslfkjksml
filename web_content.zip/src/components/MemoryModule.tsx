import React, { useState } from 'react';
import {
  Brain,
  Plus,
  Trash2,
  Edit3,
  Download,
  ShieldCheck,
  Search,
  Check,
  X,
  AlertCircle,
} from 'lucide-react';
import type { MemoryCategory, PersonalMemory } from '../types';
import { validateMemoryInput } from '../utils/rajuEngine';

interface MemoryModuleProps {
  memories: PersonalMemory[];
  memoryConsentEnabled: boolean;
  onToggleGlobalConsent: (enabled: boolean) => void;
  onAddMemory: (mem: { title: string; content: string; category: MemoryCategory; userConsented: true }) => Promise<void>;
  onUpdateMemory: (id: string, updates: { title: string; content: string; category: MemoryCategory }) => Promise<void>;
  onDeleteMemory: (id: string) => Promise<void>;
  onClearConversationHistory: () => Promise<void>;
  onExportPersonalData: () => void;
}

const CATEGORIES: MemoryCategory[] = ['Preference', 'Study Goal', 'Language', 'Project', 'Personal'];

export const MemoryModule: React.FC<MemoryModuleProps> = ({
  memories,
  memoryConsentEnabled,
  onToggleGlobalConsent,
  onAddMemory,
  onUpdateMemory,
  onDeleteMemory,
  onClearConversationHistory,
  onExportPersonalData,
}) => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<MemoryCategory>('Study Goal');
  const [explicitConsent, setExplicitConsent] = useState(true);
  const [filterCat, setFilterCat] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editContent, setEditContent] = useState('');
  const [editCategory, setEditCategory] = useState<MemoryCategory>('Preference');
  const [historyClearedBanner, setHistoryClearedBanner] = useState(false);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    const validation = validateMemoryInput({
      title,
      content,
      category,
      userConsented: explicitConsent && memoryConsentEnabled,
    });

    if (!validation.valid || !validation.sanitized) {
      setErrorMsg(validation.error || 'Please verify memory fields and explicit consent.');
      return;
    }

    await onAddMemory(validation.sanitized);
    setTitle('');
    setContent('');
  };

  const startEditing = (mem: PersonalMemory) => {
    setEditingId(mem.id);
    setEditTitle(mem.title);
    setEditContent(mem.content);
    setEditCategory(mem.category);
  };

  const saveEdit = async (id: string) => {
    setErrorMsg(null);
    const validation = validateMemoryInput({
      title: editTitle,
      content: editContent,
      category: editCategory,
      userConsented: true,
    });
    if (!validation.valid || !validation.sanitized) {
      setErrorMsg(validation.error || 'Invalid update input.');
      return;
    }
    await onUpdateMemory(id, {
      title: validation.sanitized.title,
      content: validation.sanitized.content,
      category: validation.sanitized.category,
    });
    setEditingId(null);
  };

  const filteredMemories = memories.filter((m) => {
    const matchesCat = filterCat === 'All' || m.category === filterCat;
    const matchesSearch =
      !searchQuery.trim() ||
      m.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.content.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">
            Personal Memory Vault
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Consent-first context memory shared across Web, PWA, and Android. You control everything RAJU AI remembers.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={onExportPersonalData}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#0B102B] border border-slate-700 hover:border-cyan-400 text-xs font-semibold text-slate-100 transition whitespace-nowrap shrink-0"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            Export Personal Data
          </button>

          <button
            type="button"
            onClick={async () => {
              await onClearConversationHistory();
              setHistoryClearedBanner(true);
              setTimeout(() => setHistoryClearedBanner(false), 3500);
            }}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-rose-950/60 border border-rose-500/40 hover:bg-rose-900/60 text-xs font-semibold text-rose-200 transition whitespace-nowrap shrink-0"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Clear Chat History
          </button>
        </div>
      </div>

      {historyClearedBanner && (
        <div className="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-xs text-emerald-200 flex items-center justify-between">
          <span>Conversation history has been cleared across your session.</span>
          <button type="button" onClick={() => setHistoryClearedBanner(false)} className="underline">
            Close
          </button>
        </div>
      )}

      {/* Privacy & Global Consent Bar */}
      <div className="p-4 rounded-2xl bg-[#0B102B]/90 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <ShieldCheck className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
          <div>
            <h3 className="text-sm font-semibold text-white">
              Explicit User Memory Consent
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              RAJU AI never stores sensitive information without your explicit approval. Toggle off to pause memory storage and context injection.
            </p>
          </div>
        </div>

        <label className="inline-flex items-center gap-2.5 cursor-pointer shrink-0">
          <input
            type="checkbox"
            checked={memoryConsentEnabled}
            onChange={(e) => onToggleGlobalConsent(e.target.checked)}
            aria-label="Enable Personal Memory Storage"
            className="w-4 h-4 rounded border-slate-600 bg-slate-900 text-cyan-500"
          />
          <span className="text-xs font-semibold text-cyan-300">
            {memoryConsentEnabled ? 'Memory Active (Consented)' : 'Memory Paused'}
          </span>
        </label>
      </div>

      {errorMsg && (
        <div
          role="alert"
          className="flex items-center gap-2.5 p-3.5 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200"
        >
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Grid: Add Memory Form + Memory List */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Form (5 cols) */}
        <form
          onSubmit={handleCreate}
          className="lg:col-span-5 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4"
        >
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Plus className="w-4 h-4 text-cyan-400" />
            Add Approved Memory
          </h3>

          <div>
            <label htmlFor="memory-title" className="block text-xs font-medium text-slate-300 mb-1.5">
              Memory Title
            </label>
            <input
              id="memory-title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., CUET 2027 Target & Preferred Language"
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#060919] border border-slate-800 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div>
            <label htmlFor="memory-category" className="block text-xs font-medium text-slate-300 mb-1.5">
              Category
            </label>
            <select
              id="memory-category"
              value={category}
              onChange={(e) => setCategory(e.target.value as MemoryCategory)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#060919] border border-slate-800 text-sm text-white focus:outline-none focus:border-cyan-400"
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="memory-content" className="block text-xs font-medium text-slate-300 mb-1.5">
              Details to Remember
            </label>
            <textarea
              id="memory-content"
              rows={3}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="e.g., I am preparing for CUET Biology & JLPT N5. Explain complex concepts with Hindi + English examples."
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#060919] border border-slate-800 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
            />
          </div>

          <label className="flex items-start gap-2.5 cursor-pointer text-xs text-slate-300">
            <input
              type="checkbox"
              checked={explicitConsent}
              onChange={(e) => setExplicitConsent(e.target.checked)}
              className="mt-0.5 rounded border-slate-600 bg-slate-900 text-cyan-500"
            />
            <span>
              I explicitly consent to RAJU AI storing this memory to personalize my assistant experience.
            </span>
          </label>

          <button
            type="submit"
            className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-semibold text-sm transition shadow-sm"
          >
            Save to Memory Vault
          </button>
        </form>

        {/* Stored Memories List (7 cols) */}
        <div className="lg:col-span-7 p-5 rounded-2xl bg-[#0B102B]/90 border border-slate-800/90 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search saved memories..."
                aria-label="Search saved memories"
                className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-[#060919] border border-slate-800 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div className="flex items-center gap-1 p-1 rounded-xl bg-[#060919] border border-slate-800 overflow-x-auto">
              {['All', ...CATEGORIES].map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setFilterCat(cat)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition whitespace-nowrap shrink-0 ${
                    filterCat === cat ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            {filteredMemories.length === 0 ? (
              <div className="text-center py-12 px-4 rounded-xl bg-[#060919]/60 border border-slate-800/70">
                <Brain className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                <p className="text-sm font-medium text-slate-300">No memories match your filter</p>
                <p className="text-xs text-slate-500 mt-1">
                  Add a study goal, language preference, or project note using the form on the left.
                </p>
              </div>
            ) : (
              filteredMemories.map((mem) => {
                const isEditing = editingId === mem.id;
                return (
                  <div
                    key={mem.id}
                    className="p-4 rounded-xl bg-[#060919]/85 border border-slate-800/90 hover:border-slate-700 transition space-y-2"
                  >
                    {isEditing ? (
                      <div className="space-y-3">
                        <input
                          type="text"
                          value={editTitle}
                          onChange={(e) => setEditTitle(e.target.value)}
                          aria-label="Edit memory title"
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white"
                        />
                        <select
                          value={editCategory}
                          onChange={(e) => setEditCategory(e.target.value as MemoryCategory)}
                          aria-label="Edit memory category"
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
                        >
                          {CATEGORIES.map((c) => (
                            <option key={c} value={c}>
                              {c}
                            </option>
                          ))}
                        </select>
                        <textarea
                          rows={2}
                          value={editContent}
                          onChange={(e) => setEditContent(e.target.value)}
                          aria-label="Edit memory content"
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
                        />
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => setEditingId(null)}
                            className="px-3 py-1.5 rounded-lg bg-slate-800 text-xs text-slate-300 flex items-center gap-1"
                          >
                            <X className="w-3.5 h-3.5" />
                            Cancel
                          </button>
                          <button
                            type="button"
                            onClick={() => saveEdit(mem.id)}
                            className="px-3 py-1.5 rounded-lg bg-cyan-600 text-xs text-white font-semibold flex items-center gap-1"
                          >
                            <Check className="w-3.5 h-3.5" />
                            Save
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <h4 className="text-sm font-bold text-white">{mem.title}</h4>
                            <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                              <span className="text-cyan-300">{mem.category}</span>
                              <span aria-hidden="true">·</span>
                              <span>Consented</span>
                              <span aria-hidden="true">·</span>
                              <span className="font-mono tabular-nums">
                                {mem.updatedAt ? mem.updatedAt.slice(0, 10) : 'Today'}
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0">
                            <button
                              type="button"
                              onClick={() => startEditing(mem)}
                              aria-label={`Edit memory ${mem.title}`}
                              className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => onDeleteMemory(mem.id)}
                              aria-label={`Delete memory ${mem.title}`}
                              className="p-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900 text-rose-300 transition"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        <p className="text-xs text-slate-200 leading-relaxed pt-1">{mem.content}</p>
                      </>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
