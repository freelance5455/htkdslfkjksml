import { Ball } from "./ball";

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <div className="relative flex items-center">
        <Ball n={5} size={compact ? "sm" : "md"} />
        <span className="-ml-2">
          <Ball n={90} size={compact ? "sm" : "md"} />
        </span>
        <svg
          className="absolute -bottom-1 left-1 h-3 w-14 text-gold/70"
          viewBox="0 0 56 8"
          aria-hidden
        >
          <rect x="1" y="5" width="4" height="3" fill="currentColor" opacity="0.4" />
          <rect x="8" y="3" width="4" height="5" fill="currentColor" opacity="0.7" />
          <rect x="15" y="1" width="4" height="7" fill="currentColor" />
          <rect x="22" y="4" width="4" height="4" fill="currentColor" opacity="0.55" />
          <rect x="29" y="2" width="4" height="6" fill="currentColor" opacity="0.85" />
          <rect x="36" y="5" width="4" height="3" fill="currentColor" opacity="0.4" />
          <rect x="43" y="3" width="4" height="5" fill="currentColor" opacity="0.6" />
        </svg>
      </div>
      <div>
        <div className="font-display text-[28px] font-semibold leading-none tracking-tight text-ivory">
          π√8
        </div>
        {!compact && (
          <div className="mt-1 text-[11px] tracking-[0.16em] text-muted uppercase">
            5 parmi 90
          </div>
        )}
      </div>
    </div>
  );
}
