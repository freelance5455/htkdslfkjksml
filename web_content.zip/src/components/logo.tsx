import { cn } from "@/lib/utils";

export function Mark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("shrink-0", className)}
      aria-hidden="true"
      focusable="false"
    >
      <rect width="32" height="32" rx="8" fill="currentColor" className="text-primary" />
      <path
        d="M9 8.5v10.2c0 3.4 2.5 6.3 7 6.3s7-2.9 7-6.3V8.5h-3.1v10.1c0 1.7-1.2 3.2-3.9 3.2s-3.9-1.5-3.9-3.2V8.5H9z"
        fill="currentColor"
        className="text-primary-fg"
      />
      <path d="M21.2 13.2v5.2l4.6-2.6-4.6-2.6z" fill="currentColor" className="text-primary-fg" />
    </svg>
  );
}

export function Wordmark({ className }: { compact?: boolean; className?: string }) {
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <Mark className="size-8" />
      <span className="font-display text-lg font-semibold tracking-tight">
        UPLAY
        <span className="text-primary">.IND</span>
      </span>
    </div>
  );
}
