import { cn } from "@/lib/utils";

export function VaultMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("size-8 text-foreground", className)}
      aria-hidden="true"
    >
      <rect width="32" height="32" rx="9" fill="currentColor" />
      <path
        d="M16 21.5V11M11.5 15.25 16 10.75l4.5 4.5"
        fill="none"
        className="stroke-background"
        strokeWidth="2.1"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={cn("font-display text-2xl leading-none tracking-tight", className)}>
      Vault
    </span>
  );
}
