import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn("shrink-0", className)} aria-hidden="true">
      <rect width="32" height="32" rx="7" fill="#0B1F3A" />
      <rect x="2.55" y="2.55" width="26.9" height="26.9" rx="5.2" fill="none" stroke="#C4A35A" strokeWidth="1.4" />
      <rect x="9.15" y="7.7" width="3.55" height="16.6" fill="#C4A35A" />
      <path fill="#C4A35A" d="M11.19 17.27 L9.81 14.73 L22.41 7.88 L23.79 10.42 Z" />
      <path fill="#C4A35A" d="M9.81 17.27 L11.19 14.73 L23.79 21.58 L22.41 24.12 Z" />
      <circle cx="10.5" cy="16" r="1.41" fill="#C4A35A" />
    </svg>
  );
}

export function Wordmark({ light = false, compact = false }: { light?: boolean; compact?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <LogoMark className={compact ? "size-9" : "size-11"} />
      <div className="leading-tight">
        <div
          className={cn(
            "font-display tracking-wide",
            compact ? "text-lg" : "text-2xl",
            light ? "text-gold-soft" : "text-navy",
          )}
          style={{ fontFamily: "var(--font-display)" }}
        >
          MR,KHORASANI
        </div>
        {!compact && (
          <div className={cn("text-[11px] tracking-[0.18em] uppercase", light ? "text-gold/80" : "text-muted")}>
            Financial Management & Accounting
          </div>
        )}
      </div>
    </div>
  );
}
