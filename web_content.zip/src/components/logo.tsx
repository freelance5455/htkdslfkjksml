import { cn } from "@/lib/cn";

export function LisaMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn("size-8", className)} aria-hidden>
      <rect width="32" height="32" rx="8" className="fill-card" />
      <rect x="9" y="7" width="5.5" height="18" rx="1.4" className="fill-accent" />
      <rect x="9" y="19.5" width="14" height="5.5" rx="1.4" className="fill-accent" />
    </svg>
  );
}
