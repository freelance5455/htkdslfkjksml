import React, { useEffect, useRef, useState, useMemo } from 'react';
import * as d3 from 'd3';
import { motion } from 'motion/react';
import { 
  PieChart as PieIcon, 
  TrendingUp, 
  ArrowUpRight, 
  ArrowDownLeft, 
  ShieldCheck, 
  RefreshCw, 
  DollarSign, 
  Zap, 
  Layers, 
  Globe, 
  ExternalLink,
  ChevronRight,
  Eye,
  EyeOff
} from 'lucide-react';
import { ImsiWalletBalances, ImsiLedgerTransaction } from '../lib/imsiEngine';

interface PortfolioDashboardProps {
  wallet: ImsiWalletBalances;
  ledger: ImsiLedgerTransaction[];
  onShowToast?: (msg: string) => void;
  onOpenConverto?: () => void;
  onOpenWithdrawal?: () => void;
}

interface AssetAllocation {
  id: string;
  name: string;
  symbol: string;
  network: string;
  balance: number;
  balanceFormatted: string;
  usdValue: number;
  ngnValue: number;
  color: string;
  gradient: [string, string];
  change24h: number;
  icon: string;
}

export const PortfolioDashboard: React.FC<PortfolioDashboardProps> = ({
  wallet,
  ledger,
  onShowToast,
  onOpenConverto,
  onOpenWithdrawal
}) => {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [currencyMode, setCurrencyMode] = useState<'USD' | 'NGN' | 'BTC'>('USD');
  const [hoveredAsset, setHoveredAsset] = useState<AssetAllocation | null>(null);
  const [hideBalances, setHideBalances] = useState<boolean>(false);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // FX Rates
  const usdToNgn = 1580;
  const btcPriceUsd = 94500;
  const ethPriceUsd = 2700;
  const solPriceUsd = 188;
  const usdtPriceUsd = 1.00;

  // Compute live portfolio holdings
  const assets: AssetAllocation[] = useMemo(() => {
    const btcHoldings = wallet.bitcoinSats / 100000000;
    const btcUsd = btcHoldings * btcPriceUsd;
    const btcNgn = btcUsd * usdToNgn;

    const ethHoldings = 3.45;
    const ethUsd = ethHoldings * ethPriceUsd;
    const ethNgn = ethUsd * usdToNgn;

    const solHoldings = 28.5;
    const solUsd = solHoldings * solPriceUsd;
    const solNgn = solUsd * usdToNgn;

    const usdtHoldings = 4500.0;
    const usdtUsd = usdtHoldings * usdtPriceUsd;
    const usdtNgn = usdtUsd * usdToNgn;

    const cashNgn = wallet.cashNgn;
    const cashUsd = cashNgn / usdToNgn;

    const convertoHoldings = 2500.0;
    const convertoUsd = convertoHoldings * 1.0;
    const convertoNgn = convertoHoldings * 1580;

    return [
      {
        id: 'btc',
        name: 'Bitcoin Altar Vault',
        symbol: 'BTC',
        network: 'Bitcoin Taproot',
        balance: btcHoldings,
        balanceFormatted: `${btcHoldings.toFixed(8)} BTC`,
        usdValue: btcUsd,
        ngnValue: btcNgn,
        color: '#f59e0b',
        gradient: ['#f59e0b', '#d97706'],
        change24h: 3.45,
        icon: '₿'
      },
      {
        id: 'eth',
        name: 'Ethereum L1 Treasury',
        symbol: 'ETH',
        network: 'Ethereum Mainnet',
        balance: ethHoldings,
        balanceFormatted: `${ethHoldings.toFixed(4)} ETH`,
        usdValue: ethUsd,
        ngnValue: ethNgn,
        color: '#6366f1',
        gradient: ['#6366f1', '#4f46e5'],
        change24h: 1.82,
        icon: 'Ξ'
      },
      {
        id: 'sol',
        name: 'Solana High-Speed Vault',
        symbol: 'SOL',
        network: 'Solana SPL',
        balance: solHoldings,
        balanceFormatted: `${solHoldings.toFixed(2)} SOL`,
        usdValue: solUsd,
        ngnValue: solNgn,
        color: '#06b6d4',
        gradient: ['#06b6d4', '#0891b2'],
        change24h: 5.12,
        icon: '◎'
      },
      {
        id: 'usdt',
        name: 'Tether USD (Base L2)',
        symbol: 'USDT',
        network: 'Base L2 / Arbitrum',
        balance: usdtHoldings,
        balanceFormatted: `${usdtHoldings.toLocaleString()} USDT`,
        usdValue: usdtUsd,
        ngnValue: usdtNgn,
        color: '#10b981',
        gradient: ['#10b981', '#059669'],
        change24h: 0.02,
        icon: '₮'
      },
      {
        id: 'ngn',
        name: 'Sovereign Cash Treasury',
        symbol: 'NGN',
        network: 'NIBSS / CBN Settlement',
        balance: cashNgn,
        balanceFormatted: `₦${cashNgn.toLocaleString('en-US', { minimumFractionDigits: 2 })} NGN`,
        usdValue: cashUsd,
        ngnValue: cashNgn,
        color: '#14b8a6',
        gradient: ['#14b8a6', '#0d9488'],
        change24h: 0.0,
        icon: '₦'
      },
      {
        id: 'converto',
        name: 'CONVERTO Parity Reserve',
        symbol: 'CNV',
        network: 'Prophetic Altar Matrix',
        balance: convertoHoldings,
        balanceFormatted: `${convertoHoldings.toLocaleString()} CNV`,
        usdValue: convertoUsd,
        ngnValue: convertoNgn,
        color: '#ec4899',
        gradient: ['#ec4899', '#db2777'],
        change24h: 0.0,
        icon: '⚡'
      }
    ];
  }, [wallet]);

  // Aggregate totals
  const totalPortfolioUsd = useMemo(() => assets.reduce((sum, a) => sum + a.usdValue, 0), [assets]);
  const totalPortfolioNgn = useMemo(() => totalPortfolioUsd * usdToNgn, [totalPortfolioUsd]);
  const totalPortfolioBtc = useMemo(() => totalPortfolioUsd / btcPriceUsd, [totalPortfolioUsd]);

  // Draw D3 Donut Chart
  useEffect(() => {
    if (!svgRef.current || assets.length === 0) return;

    const width = 280;
    const height = 280;
    const margin = 10;
    const radius = Math.min(width, height) / 2 - margin;
    const innerRadius = radius * 0.68;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    svg.attr('viewBox', `0 0 ${width} ${height}`);

    const g = svg
      .append('g')
      .attr('transform', `translate(${width / 2}, ${height / 2})`);

    // Gradients definition
    const defs = svg.append('defs');
    assets.forEach((asset) => {
      const gradient = defs
        .append('linearGradient')
        .attr('id', `grad-${asset.id}`)
        .attr('x1', '0%')
        .attr('y1', '0%')
        .attr('x2', '100%')
        .attr('y2', '100%');

      gradient
        .append('stop')
        .attr('offset', '0%')
        .attr('stop-color', asset.gradient[0]);

      gradient
        .append('stop')
        .attr('offset', '100%')
        .attr('stop-color', asset.gradient[1]);
    });

    // Drop shadow filter for active slice
    const filter = defs.append('filter').attr('id', 'glow-slice');
    filter.append('feGaussianBlur').attr('stdDeviation', '4').attr('result', 'coloredBlur');
    const feMerge = filter.append('feMerge');
    feMerge.append('feMergeNode').attr('in', 'coloredBlur');
    feMerge.append('feMergeNode').attr('in', 'SourceGraphic');

    const pie = d3
      .pie<AssetAllocation>()
      .value((d) => d.usdValue)
      .sort(null)
      .padAngle(0.035);

    const arc = d3
      .arc<d3.PieArcDatum<AssetAllocation>>()
      .innerRadius(innerRadius)
      .outerRadius(radius)
      .cornerRadius(6);

    const arcHover = d3
      .arc<d3.PieArcDatum<AssetAllocation>>()
      .innerRadius(innerRadius - 4)
      .outerRadius(radius + 7)
      .cornerRadius(8);

    const slices = g
      .selectAll('.arc')
      .data(pie(assets))
      .enter()
      .append('g')
      .attr('class', 'arc');

    slices
      .append('path')
      .attr('d', (d) => arc(d) || '')
      .attr('fill', (d) => `url(#grad-${d.data.id})`)
      .style('cursor', 'pointer')
      .style('transition', 'all 0.25s ease')
      .on('mouseenter', function (event, d) {
        d3.select(this)
          .transition()
          .duration(200)
          .attr('d', (arcHover as any)(d))
          .style('filter', 'url(#glow-slice)');
        setHoveredAsset(d.data);
      })
      .on('mouseleave', function (event, d) {
        d3.select(this)
          .transition()
          .duration(200)
          .attr('d', (arc as any)(d))
          .style('filter', 'none');
        setHoveredAsset(null);
      });
  }, [assets]);

  const handleRefresh = () => {
    setIsRefreshing(true);
    onShowToast?.('⚡ Re-benchmarking real-time cross-chain asset valuations...');
    setTimeout(() => {
      setIsRefreshing(false);
      onShowToast?.('✓ Portfolio valuations synchronized with global blockchain nodes!');
    }, 1200);
  };

  const formatCurrency = (usd: number, ngn: number, btc: number) => {
    if (hideBalances) return '••••••••';
    if (currencyMode === 'USD') {
      return `$${usd.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
    if (currencyMode === 'NGN') {
      return `₦${ngn.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
    return `${btc.toFixed(6)} BTC`;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-slate-950 border-2 border-amber-500/40 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden"
    >
      {/* Background Decorative Glow */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-5 relative z-10">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-black uppercase tracking-wider">
            <PieIcon className="w-4 h-4 text-amber-400" />
            <span>CROSS-CHAIN ASSET PORTFOLIO DASHBOARD (D3.JS)</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black font-serif text-slate-100 tracking-tight">
            Treasury Holdings & Multi-Asset Valuation
          </h2>
          <p className="text-xs text-slate-400">
            Real-time D3 mathematical visualization of Prophet JUHNKRIX's cross-chain crypto holdings, cash treasury, and altar reserves.
          </p>
        </div>

        {/* Currency Switcher & Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Hide/Show Eye Toggle */}
          <button
            onClick={() => setHideBalances(!hideBalances)}
            className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 text-slate-400 hover:text-amber-300 text-xs font-bold transition-all"
            title={hideBalances ? 'Show Balances' : 'Hide Balances'}
          >
            {hideBalances ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>

          {/* Refresh Valuation */}
          <button
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 text-slate-400 hover:text-amber-300 text-xs font-bold transition-all"
            title="Refresh Live Node Pricing"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-amber-400' : ''}`} />
          </button>

          {/* Currency Mode Pills */}
          <div className="flex bg-slate-900 border border-slate-800 rounded-xl p-1">
            {(['USD', 'NGN', 'BTC'] as const).map((curr) => (
              <button
                key={curr}
                onClick={() => setCurrencyMode(curr)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  currencyMode === curr
                    ? 'bg-amber-500 text-slate-950 font-black shadow-md shadow-amber-500/25'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {curr}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Visual Section: D3 Donut Chart + Central Stats + Legend */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center relative z-10">
        {/* Left Column: D3 Chart Container (5 cols) */}
        <div className="lg:col-span-5 flex flex-col items-center justify-center p-4 bg-slate-900/60 border border-slate-800 rounded-3xl relative">
          <div className="relative w-[280px] h-[280px] flex items-center justify-center">
            <svg ref={svgRef} className="w-full h-full" />
            
            {/* Center Dynamic Label inside Donut */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none px-4">
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                {hoveredAsset ? hoveredAsset.name : 'Total Valuation'}
              </span>
              <span className="text-xl sm:text-2xl font-black text-amber-300 font-mono tracking-tight mt-0.5">
                {hoveredAsset 
                  ? formatCurrency(hoveredAsset.usdValue, hoveredAsset.ngnValue, hoveredAsset.usdValue / btcPriceUsd)
                  : formatCurrency(totalPortfolioUsd, totalPortfolioNgn, totalPortfolioBtc)
                }
              </span>
              <span className="text-[10px] text-emerald-400 font-extrabold flex items-center space-x-0.5 mt-0.5">
                <TrendingUp className="w-3 h-3 text-emerald-400" />
                <span>
                  {hoveredAsset 
                    ? `${((hoveredAsset.usdValue / totalPortfolioUsd) * 100).toFixed(1)}% of Portfolio`
                    : '+3.82% 24h P&L'
                  }
                </span>
              </span>
            </div>
          </div>

          <div className="text-[11px] text-slate-400 text-center mt-2">
            Hover over any arc slice to inspect asset ratio and dedicated valuation.
          </div>
        </div>

        {/* Right Column: Asset Breakdown List (7 cols) */}
        <div className="lg:col-span-7 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {assets.map((asset) => {
              const allocationPct = ((asset.usdValue / totalPortfolioUsd) * 100).toFixed(1);
              const isHovered = hoveredAsset?.id === asset.id;

              return (
                <div
                  key={asset.id}
                  onMouseEnter={() => setHoveredAsset(asset)}
                  onMouseLeave={() => setHoveredAsset(null)}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                    isHovered
                      ? 'bg-slate-900 border-amber-400 scale-102 shadow-lg shadow-amber-500/10'
                      : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2.5">
                      <div 
                        className="w-8 h-8 rounded-xl flex items-center justify-center font-bold text-sm shadow-sm"
                        style={{ backgroundColor: `${asset.color}25`, color: asset.color, border: `1px solid ${asset.color}40` }}
                      >
                        {asset.icon}
                      </div>
                      <div>
                        <div className="text-xs font-black text-slate-200 flex items-center space-x-1">
                          <span>{asset.symbol}</span>
                          <span className="text-[10px] text-slate-400 font-normal">({asset.network})</span>
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          {hideBalances ? '••••••' : asset.balanceFormatted}
                        </div>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-xs font-black text-amber-300 font-mono">
                        {formatCurrency(asset.usdValue, asset.ngnValue, asset.usdValue / btcPriceUsd)}
                      </div>
                      <div className="text-[10px] text-slate-400 font-bold">
                        {allocationPct}% allocation
                      </div>
                    </div>
                  </div>

                  {/* Visual Allocation Bar */}
                  <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden mt-2.5">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${allocationPct}%`,
                        backgroundColor: asset.color
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick Action Shortcuts */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <div className="text-xs text-slate-400 flex items-center space-x-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Multi-Signature Cold Storage & WebAuthn Biometric Protected</span>
            </div>

            <div className="flex items-center space-x-2">
              {onOpenConverto && (
                <button
                  onClick={onOpenConverto}
                  className="px-3.5 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center space-x-1 transition-all"
                >
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  <span>SWAP CONVERTO</span>
                </button>
              )}

              {onOpenWithdrawal && (
                <button
                  onClick={onOpenWithdrawal}
                  className="px-3.5 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center space-x-1 transition-all"
                >
                  <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" />
                  <span>WITHDRAW FUNDS</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
