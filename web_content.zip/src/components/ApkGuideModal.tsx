/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Smartphone, Download, CheckCircle, ExternalLink, ShieldCheck } from 'lucide-react';

interface ApkGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkGuideModal: React.FC<ApkGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200 my-6 animate-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">APK তৈরি ও ফোনে ইনস্টলেশন</h3>
              <p className="text-xs text-slate-400">ধাপে ধাপে সহজ বাংলা নির্দেশিকা</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="বন্ধ করুন"
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 max-h-[70vh] overflow-y-auto space-y-4 text-xs text-slate-700 leading-relaxed">
          {/* Method 1: PWABuilder (Best & Easiest) */}
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 space-y-2">
            <div className="flex items-center gap-1.5 text-emerald-900 font-bold text-sm">
              <CheckCircle className="w-4 h-4 text-emerald-600" />
              <span>পদ্ধতি ১: PWABuilder (সরাসরি ফোনে ১ ক্লিকে APK)</span>
            </div>
            <p className="text-slate-600">
              অ্যাপটি ইতিমধ্যে একটি পূর্ণাঙ্গ আধুনিক ওয়েব অ্যাপ (PWA)। আপনি কোনো জটিল কোডিং ছাড়াই সরাসরি .apk ফাইল পেতে পারেন:
            </p>
            <ol className="list-decimal list-inside space-y-1.5 text-slate-700 font-medium pl-1">
              <li>
                ব্রাউজারে যান:{' '}
                <span className="font-mono bg-white px-1.5 py-0.5 rounded border border-emerald-300 text-emerald-800">
                  pwabuilder.com
                </span>
              </li>
              <li>অ্যাপের লাইভ URL টি দিয়ে <span className="font-bold">Start</span> চাপুন।</li>
              <li>
                <span className="font-bold text-emerald-800">"Package For Stores"</span> থেকে <span className="font-bold">Android</span> বেছে নিন।
              </li>
              <li>
                <span className="font-bold">Generate APK</span> চাপলেই আপনার ফোনের জন্য প্রস্তুত <span className="font-bold text-emerald-800">.apk</span> ফাইল ডাউনলোড হবে!
              </li>
            </ol>
          </div>

          {/* Method 2: Capacitor (Developer CLI method) */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="flex items-center gap-1.5 text-slate-900 font-bold text-sm">
              <Download className="w-4 h-4 text-blue-600" />
              <span>পদ্ধতি ২: Capacitor দিয়ে Android Studio-তে .apk বিল্ড</span>
            </div>
            <p className="text-slate-600">
              আপনি যদি অ্যান্ড্রয়েড স্টুডিও দিয়ে সাইন করা প্রফেশনাল .apk বানাতে চান:
            </p>
            <div className="p-2.5 rounded-lg bg-slate-900 text-emerald-400 font-mono text-[11px] space-y-1">
              <div>npm run build</div>
              <div>npm i @capacitor/core @capacitor/cli @capacitor/android</div>
              <div>npx cap init "RoutineTracker" "com.app.routinetracker"</div>
              <div>npx cap add android</div>
              <div>npx cap copy</div>
              <div>npx cap open android</div>
            </div>
            <p className="text-slate-600 text-[11px]">
              Android Studio ওপেন হলে <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong> চাপলেই ডিভাইসের জন্য .apk তৈরি হয়ে যাবে।
            </p>
          </div>

          {/* Install steps on Android phone */}
          <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 space-y-2">
            <div className="flex items-center gap-1.5 text-amber-900 font-bold text-sm">
              <ShieldCheck className="w-4 h-4 text-amber-700" />
              <span>ফোনে .apk ফাইল যেভাবে ইনস্টল করবেন</span>
            </div>
            <ul className="list-disc list-inside space-y-1 text-slate-700">
              <li>ডাউনলোড করা .apk ফাইলটিতে ফোনে ট্যাপ করুন।</li>
              <li>যদি <span className="font-semibold">"Install unknown apps"</span> চায়, তবে Settings থেকে ব্রাউজার বা ফাইল ম্যানেজারকে অনুমতি দিন।</li>
              <li><span className="font-bold text-emerald-700">"Install"</span> চাপুন। অ্যাপটি ফোনের হোম স্ক্রিনে আইকনসহ চালু হবে।</li>
              <li>সব তথ্য শুধু আপনার ফোনেই অফলাইনে সংরক্ষিত থাকবে, কোনো নেট বা লগইন লাগবে না।</li>
            </ul>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="border-t border-slate-100 bg-slate-50 p-4">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 px-4 rounded-xl font-bold text-sm text-white bg-slate-900 hover:bg-slate-800 active:scale-98 transition-all"
          >
            বুঝেছি, বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
