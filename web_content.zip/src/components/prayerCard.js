/**
 * prayerCard.js — prayer times card used on Home (compact) and in the Discipline
 * Prayer tab (full). Tap a prayer to mark it done. Times are calculated offline.
 */
import { el, card } from './ui.js';
import {
  getPrayerConfig, computePrayerTimes, nextPrayer, countdownText, getDayLog, togglePrayer,
  setFasted, setWokeForFajr, fastInfo, PRAYERS, PRAYER_LABEL, prayersDone,
} from '../core/prayer/prayerService.js';
import { todayISO, formatClock } from '../core/utils/dateUtils.js';

export async function buildPrayerCard({ full = false, onChange = () => {} } = {}) {
  const cfg = await getPrayerConfig();
  const now = new Date();
  const times = computePrayerTimes(todayISO(), cfg);
  const np = nextPrayer(cfg, now);
  const log = await getDayLog();
  const fast = fastInfo(now, cfg.hijriAdjust);

  const grid = el('div', 'prayer-grid');
  PRAYERS.forEach((p) => {
    const done = !!log.prayers?.[p];
    const isNext = !np.tomorrow && np.name === p;
    const cell = el('button', `prayer-cell${done ? ' prayer-cell--done' : ''}${isNext ? ' prayer-cell--next' : ''}`, [
      el('span', 'prayer-cell__name', PRAYER_LABEL[p]),
      el('span', 'prayer-cell__time', formatClock(times[p])),
      el('span', 'prayer-cell__mark', done ? '✓' : '·'),
    ]);
    cell.addEventListener('click', async () => { await togglePrayer(p); onChange(); });
    grid.append(cell);
  });

  const header = el('div', 'flex justify-between items-center', [
    el('span', 'prayer-title', `🕌 Prayer · ${cfg.place}`),
    el('span', 'next-pill', `${PRAYER_LABEL[np.name]} in ${countdownText(np.inHours)}`),
  ]);

  const kids = [header, grid,
    el('p', 'text-xs text-dim mt-3', `${prayersDone(log)}/5 prayed today · Sunrise ${formatClock(times.sunrise)}`)];

  if (fast) {
    const btn = el('button', `chip${log.fasted ? ' chip--active' : ''}`, log.fasted ? 'Fasting ✓' : 'Fasting today?');
    btn.addEventListener('click', async () => { await setFasted(!log.fasted); onChange(); });
    kids.push(el('div', 'fast-row', [
      el('div', null, [
        el('div', 'text-xs', `🌙 ${fast.label}`),
        el('div', 'text-xs text-dim', `Suhoor before Fajr (${formatClock(times.fajr)}) · iftar at Maghrib (${formatClock(times.maghrib)})`),
      ]),
      btn,
    ]));
  }

  if (full) {
    const wake = el('button', `chip${log.wokeForFajr ? ' chip--active' : ''}`, log.wokeForFajr ? 'Woke for Fajr ✓' : 'Woke for Fajr?');
    wake.addEventListener('click', async () => { await setWokeForFajr(!log.wokeForFajr); onChange(); });
    kids.push(el('div', 'mt-3', [
      el('p', 'text-xs text-dim', `Suggested Fajr wake-up: ${formatClock(times.fajr - 0.25)} (15 min before).`),
      el('div', 'mt-2', wake),
    ]));
  }
  const node = card(kids);
  node.classList.add('prayer-card');
  return node;
}
