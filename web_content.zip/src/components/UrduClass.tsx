import React, { useState } from 'react';
import { Volume2, Edit3, Sparkles, BookOpen, Star, ArrowRight, ArrowLeft } from 'lucide-react';
import { URDU_ALPHABET } from '../data/learningData';
import { UrduLetterItem } from '../types/curriculum';
import { sound } from '../utils/sound';

interface UrduClassProps {
  childName: string;
  onTraceLetter: (item: { letter: string; name: string; example: string }) => void;
  onEarnStar: () => void;
}

export const UrduClass: React.FC<UrduClassProps> = ({
  childName,
  onTraceLetter,
  onEarnStar,
}) => {
  const [selectedLetter, setSelectedLetter] = useState<UrduLetterItem>(URDU_ALPHABET[0]);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [learnedLetters, setLearnedLetters] = useState<Set<string>>(new Set(['alif']));

  const handleSelectLetter = (item: UrduLetterItem) => {
    sound.playPopSound();
    setSelectedLetter(item);
    playLetterAudio(item);

    // Mark as learned and award star if new
    if (!learnedLetters.has(item.id)) {
      setLearnedLetters((prev) => new Set(prev).add(item.id));
      onEarnStar();
    }
  };

  const playLetterAudio = async (item: UrduLetterItem) => {
    if (isPlayingAudio) return;
    setIsPlayingAudio(true);
    const textToSay = `${item.nameUrdu}! ${item.letter} سے ${item.wordUrdu}! ${item.rhymeUrdu}`;
    await sound.speakWithGeminiOrLocal(textToSay, 'ur');
    setIsPlayingAudio(false);
  };

  const handleNext = () => {
    const currentIndex = URDU_ALPHABET.findIndex((l) => l.id === selectedLetter.id);
    const nextIndex = (currentIndex + 1) % URDU_ALPHABET.length;
    handleSelectLetter(URDU_ALPHABET[nextIndex]);
  };

  const handlePrev = () => {
    const currentIndex = URDU_ALPHABET.findIndex((l) => l.id === selectedLetter.id);
    const prevIndex = (currentIndex - 1 + URDU_ALPHABET.length) % URDU_ALPHABET.length;
    handleSelectLetter(URDU_ALPHABET[prevIndex]);
  };

  return (
    <div className="space-y-6">
      {/* Active Featured Letter Showcase Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-rose-500 via-pink-600 to-rose-700 p-6 sm:p-8 text-white shadow-xl border-4 border-rose-300">
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Big Letter Card */}
          <div className="flex flex-col items-center">
            <div className="w-36 h-36 sm:w-44 sm:h-44 rounded-3xl bg-white/95 text-rose-700 flex flex-col items-center justify-center shadow-2xl border-4 border-yellow-300 animate-float">
              <span className="font-urdu text-7xl sm:text-8xl font-black leading-none select-none">
                {selectedLetter.letter}
              </span>
              <span className="font-urdu text-sm font-bold text-rose-500 mt-1">
                {selectedLetter.nameUrdu} ({selectedLetter.nameLatin})
              </span>
            </div>

            <div className="mt-4 flex items-center gap-2">
              <button
                onClick={() => playLetterAudio(selectedLetter)}
                disabled={isPlayingAudio}
                className="px-4 py-2 bg-yellow-400 hover:bg-yellow-300 text-yellow-950 font-extrabold rounded-full text-sm shadow-lg flex items-center gap-2 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
              >
                <Volume2 className={`w-5 h-5 ${isPlayingAudio ? 'animate-bounce text-rose-600' : ''}`} />
                <span>{isPlayingAudio ? 'آواز سنیں...' : 'آواز سنیں (Listen)'}</span>
              </button>

              <button
                onClick={() =>
                  onTraceLetter({
                    letter: selectedLetter.letter,
                    name: selectedLetter.nameUrdu,
                    example: selectedLetter.wordUrdu,
                  })
                }
                className="px-4 py-2 bg-white hover:bg-rose-50 text-rose-700 font-extrabold rounded-full text-sm shadow-lg flex items-center gap-2 active:scale-95 transition-all cursor-pointer"
              >
                <Edit3 className="w-5 h-5 text-rose-600" />
                <span>لکھنا سیکھیں (Trace)</span>
              </button>
            </div>
          </div>

          {/* Letter Info, Example Word & Rhyme */}
          <div className="flex-1 text-center md:text-right space-y-3">
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md px-3.5 py-1 rounded-full text-xs font-bold text-yellow-200">
              <Sparkles className="w-3.5 h-3.5" />
              <span>حروفِ تہجی کی کلاس برائے {childName} 🎓</span>
            </div>

            <h3 className="font-urdu text-2xl sm:text-3xl font-extrabold text-white flex items-center justify-center md:justify-start gap-3">
              <span>{selectedLetter.letter} سے {selectedLetter.wordUrdu}</span>
              <span className="text-4xl sm:text-5xl">{selectedLetter.emoji}</span>
            </h3>

            <p className="text-white/90 text-sm sm:text-base font-medium">
              انگریزی میں: <span className="font-bold text-yellow-300">{selectedLetter.wordEnglish} ({selectedLetter.wordTranslit})</span>
            </p>

            <div className="bg-white/15 backdrop-blur-sm p-4 rounded-2xl border border-white/20 text-white">
              <p className="font-urdu text-lg sm:text-xl font-bold leading-relaxed">
                "{selectedLetter.rhymeUrdu}"
              </p>
              <p className="text-xs text-yellow-200 mt-1 font-sans">
                {selectedLetter.soundDescription}
              </p>
            </div>

            {/* Navigation buttons */}
            <div className="flex items-center justify-center md:justify-start gap-3 pt-2">
              <button
                onClick={handlePrev}
                className="px-3.5 py-1.5 bg-white/20 hover:bg-white/30 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <ArrowRight className="w-4 h-4" />
                <span>پچھلا حرف</span>
              </button>
              <span className="text-xs text-white/80 font-bold">
                {URDU_ALPHABET.findIndex((l) => l.id === selectedLetter.id) + 1} / {URDU_ALPHABET.length}
              </span>
              <button
                onClick={handleNext}
                className="px-3.5 py-1.5 bg-white/20 hover:bg-white/30 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <span>اگلا حرف</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Grid of all Urdu Letters */}
      <div className="bg-white p-5 sm:p-6 rounded-3xl shadow-lg border-2 border-rose-100 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-rose-600" />
            <h4 className="font-urdu text-xl font-bold text-slate-800">
              اردو حروفِ تہجی کی تختی (تمام حروف)
            </h4>
          </div>
          <div className="flex items-center gap-2 text-xs font-bold text-slate-600 bg-rose-50 px-3 py-1.5 rounded-full">
            <span>سیکھے گئے حروف:</span>
            <span className="text-rose-600 font-extrabold">{learnedLetters.size} / {URDU_ALPHABET.length}</span>
            <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
          </div>
        </div>

        <p className="text-xs sm:text-sm text-slate-600">
          پیارے {childName}! کسی بھی حرف پر کلک کریں تاکہ استاد میاں بھالو اس کی آواز اور پیارا شعر سنائیں:
        </p>

        <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-9 gap-2.5 sm:gap-3">
          {URDU_ALPHABET.map((item) => {
            const isSelected = selectedLetter.id === item.id;
            const isLearned = learnedLetters.has(item.id);

            return (
              <button
                key={item.id}
                onClick={() => handleSelectLetter(item)}
                className={`group relative p-2.5 sm:p-3 rounded-2xl flex flex-col items-center justify-center transition-all duration-200 cursor-pointer text-center ${
                  isSelected
                    ? 'bg-rose-500 text-white shadow-lg ring-4 ring-rose-200 scale-105'
                    : 'bg-rose-50/60 hover:bg-rose-100/80 text-slate-800 border-2 border-rose-100 hover:scale-105'
                }`}
              >
                {/* Completed Star badge */}
                {isLearned && (
                  <span className="absolute -top-1.5 -right-1.5 bg-amber-400 text-yellow-950 p-0.5 rounded-full text-[10px] shadow">
                    ⭐
                  </span>
                )}

                <span className="font-urdu text-2xl sm:text-3xl font-bold leading-tight">
                  {item.letter}
                </span>
                <span className={`text-[10px] sm:text-xs font-semibold mt-0.5 ${isSelected ? 'text-rose-100' : 'text-slate-600'}`}>
                  {item.wordUrdu}
                </span>
                <span className="text-xs sm:text-sm mt-0.5">
                  {item.emoji}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
