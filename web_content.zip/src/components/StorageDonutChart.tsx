import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

interface StorageItem {
  label: string;
  valueMb: number;
  color: string;
}

interface StorageDonutChartProps {
  data: StorageItem[];
  width?: number;
  height?: number;
}

export const StorageDonutChart: React.FC<StorageDonutChartProps> = ({
  data,
  width = 280,
  height = 280
}) => {
  const svgRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const radius = Math.min(width, height) / 2 - 16;
    const innerRadius = radius * 0.65;

    const g = svg
      .append('g')
      .attr('transform', `translate(${width / 2}, ${height / 2})`);

    const total = d3.sum(data, (d: any) => d.valueMb);

    const pie = d3
      .pie<any>()
      .value((d: any) => d.valueMb)
      .sort(null);

    const arc = d3
      .arc<any, any>()
      .innerRadius(innerRadius)
      .outerRadius(radius)
      .cornerRadius(6)
      .padAngle(0.03);

    const arcHover = d3
      .arc<any, any>()
      .innerRadius(innerRadius - 2)
      .outerRadius(radius + 4)
      .cornerRadius(6)
      .padAngle(0.03);

    // Tooltip div
    const tooltip = d3
      .select('body')
      .selectAll('.jm-donut-tooltip')
      .data([0])
      .join('div')
      .attr('class', 'jm-donut-tooltip')
      .style('position', 'absolute')
      .style('visibility', 'hidden')
      .style('background', 'rgba(15, 23, 42, 0.95)')
      .style('border', '1px solid rgba(52, 211, 153, 0.5)')
      .style('color', '#fff')
      .style('padding', '6px 10px')
      .style('border-radius', '8px')
      .style('font-family', 'monospace')
      .style('font-size', '11px')
      .style('pointer-events', 'none')
      .style('z-index', '9999');

    const path = g
      .selectAll('path')
      .data(pie(data))
      .enter()
      .append('path')
      .attr('d', arc as any)
      .attr('fill', (d: any) => d.data.color)
      .attr('stroke', '#090d16')
      .attr('stroke-width', 2)
      .style('cursor', 'pointer')
      .style('transition', 'all 0.2s ease');

    path
      .on('mouseover', function (event, d: any) {
        d3.select(this)
          .transition()
          .duration(200)
          .attr('d', arcHover as any);

        const percent = total > 0 ? ((d.data.valueMb / total) * 100).toFixed(1) : '0';
        tooltip
          .style('visibility', 'visible')
          .html(`<strong>${d.data.label}</strong><br/>${d.data.valueMb.toFixed(2)} MB (${percent}%)`);
      })
      .on('mousemove', function (event) {
        tooltip
          .style('top', `${event.pageY - 35}px`)
          .style('left', `${event.pageX + 10}px`);
      })
      .on('mouseout', function () {
        d3.select(this)
          .transition()
          .duration(200)
          .attr('d', arc as any);

        tooltip.style('visibility', 'hidden');
      });

    // Center text
    g.append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', '-6px')
      .attr('fill', '#94a3b8')
      .style('font-family', 'monospace')
      .style('font-size', '10px')
      .style('text-transform', 'uppercase')
      .text('Total Storage');

    g.append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', '16px')
      .attr('fill', '#ffffff')
      .style('font-family', 'monospace')
      .style('font-size', '15px')
      .style('font-weight', 'bold')
      .text(`${total.toFixed(1)} MB`);

    return () => {
      tooltip.remove();
    };
  }, [data, width, height]);

  return (
    <div className="flex flex-col items-center justify-center p-2">
      <svg ref={svgRef} width={width} height={height} className="overflow-visible" />
      <div className="flex items-center justify-center gap-4 flex-wrap mt-2">
        {data.map((item, idx) => (
          <div key={idx} className="flex items-center gap-1.5 font-mono text-[11px] text-slate-300">
            <span className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
            <span>{item.label}: <strong className="text-white">{item.valueMb.toFixed(1)} MB</strong></span>
          </div>
        ))}
      </div>
    </div>
  );
};
