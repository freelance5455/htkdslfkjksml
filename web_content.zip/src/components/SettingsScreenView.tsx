import React, { useState } from 'react';
import {
  ArrowLeft,
  AlarmClock,
  Mic,
  Bell,
  CheckCircle2,
  PhoneCall,
  Sliders,
  Sparkles,
  Save,
  ShieldCheck,
  ShieldAlert,
  Layers,
  Volume2,
  FileText,
  Lock,
  Calendar,
  Play,
  RefreshCw,
  AlertTriangle,
  Cpu,
  ExternalLink,
  Maximize2,
  BatteryCharging,
  XCircle,
  Check,
  Smartphone,
  ChevronRight,
} from 'lucide-react';
import { JarvisSettings } from '../types';
import { NotificationBriefingModal } from './NotificationBriefingModal';
import {
  VOICE_PROFILES,
  VoiceProfileId,
  normalizeVoiceProfile,
} from '../utils/voiceProfiles';
import { playTestVoice, stopSpeaking } from '../utils/audioSynthesizer';
import {
  DEVICE_PERMISSIONS_CATALOG,
  DevicePermissionItem,
  PermissionStatus,
  ReadinessAuditResult,
  getPermissionStatus,
  performDeviceReadinessCheck,
} from '../utils/devicePermissions';
import { AndroidSettingsModal } from './AndroidSettingsModal';
import { DeviceReadinessReportModal } from './DeviceReadinessReportModal';

interface SettingsScreenViewProps {
  settings: JarvisSettings;
  onUpdateSettings: (newSettings: Partial<JarvisSettings>) => void;
  onNavigateBack: () => void;
  onTriggerTestCall: () => void;
  onTriggerMorningBriefing?: () => void;
  onRunFullMorningTest?: () => void;
  onTriggerTestNotification: () => void;
}

export const SettingsScreenView: React.FC<SettingsScreenViewProps> = ({
  settings,
  onUpdateSettings,
  onNavigateBack,
  onTriggerTestCall,
  onTriggerMorningBriefing,
  onRunFullMorningTest,
  onTriggerTestNotification,
}) => {
  const [saveBanner, setSaveBanner] = useState(false);
  const [showBriefingPreviewModal, setShowBriefingPreviewModal] = useState(false);
  const [testingVoiceId, setTestingVoiceId] = useState<VoiceProfileId | null>(null);
  const [selectedPermissionForModal, setSelectedPermissionForModal] = useState<DevicePermissionItem | null>(null);
  const [auditResult, setAuditResult] = useState<ReadinessAuditResult | null>(null);
  const [showReadinessModal, setShowReadinessModal] = useState(false);
  const [permissionFilter, setPermissionFilter] = useState<'all' | 'remaining' | 'granted'>('all');

  const handleCheckDeviceReadiness = () => {
    const result = performDeviceReadinessCheck(settings);
    setAuditResult(result);
    setShowReadinessModal(true);
  };

  const handleOpenPermissionSettings = (item: DevicePermissionItem) => {
    setSelectedPermissionForModal(item);
  };

  const handleGrantPermission = (id: string) => {
    const updatedStatuses = { ...(settings.permissionStatuses || {}), [id]: 'GRANTED' as PermissionStatus };
    const updates: Partial<JarvisSettings> = {
      permissionStatuses: updatedStatuses,
    };
    if (id === 'microphone') updates.isMicrophonePermissionGranted = true;
    if (id === 'notification_listener') updates.isNotificationAccessGranted = true;
    if (id === 'calendar') updates.isCalendarPermissionGranted = true;
    if (id === 'fullscreen_intent') updates.isFullScreenIntentGranted = true;
    if (id === 'exact_alarm') updates.isExactAlarmGranted = true;
    if (id === 'post_notifications') updates.isPostNotificationsGranted = true;
    if (id === 'battery_optimization') updates.isBatteryOptimizationIgnored = true;
    if (id === 'boot_completed') updates.isBootCompletedRegistered = true;
    onUpdateSettings(updates);
    notifySaved();
  };

  const handleDenyPermission = (id: string) => {
    const updatedStatuses = { ...(settings.permissionStatuses || {}), [id]: 'DENIED' as PermissionStatus };
    const updates: Partial<JarvisSettings> = {
      permissionStatuses: updatedStatuses,
    };
    if (id === 'microphone') updates.isMicrophonePermissionGranted = false;
    if (id === 'notification_listener') updates.isNotificationAccessGranted = false;
    if (id === 'calendar') updates.isCalendarPermissionGranted = false;
    if (id === 'fullscreen_intent') updates.isFullScreenIntentGranted = false;
    if (id === 'exact_alarm') updates.isExactAlarmGranted = false;
    if (id === 'post_notifications') updates.isPostNotificationsGranted = false;
    if (id === 'battery_optimization') updates.isBatteryOptimizationIgnored = false;
    onUpdateSettings(updates);
    notifySaved();
  };

  const handleCycleStatus = (id: string) => {
    const current = getPermissionStatus(settings, id);
    if (current === 'GRANTED') {
      handleDenyPermission(id);
    } else if (current === 'DENIED') {
      const updatedStatuses = { ...(settings.permissionStatuses || {}), [id]: 'REQUIRED' as PermissionStatus };
      onUpdateSettings({ permissionStatuses: updatedStatuses });
      notifySaved();
    } else {
      handleGrantPermission(id);
    }
  };

  const handleGrantAll = () => {
    const allStatuses: Record<string, PermissionStatus> = {};
    DEVICE_PERMISSIONS_CATALOG.forEach(p => {
      allStatuses[p.id] = 'GRANTED';
    });
    onUpdateSettings({
      isNotificationAccessGranted: true,
      isMicrophonePermissionGranted: true,
      isCalendarPermissionGranted: true,
      isFullScreenIntentGranted: true,
      isExactAlarmGranted: true,
      isPostNotificationsGranted: true,
      isBatteryOptimizationIgnored: true,
      isBootCompletedRegistered: true,
      permissionStatuses: allStatuses,
    });
    notifySaved();
  };

  const handleTestVoice = (profileId: VoiceProfileId, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    stopSpeaking();
    setTestingVoiceId(profileId);
    playTestVoice(profileId, settings.voicePitch, settings.voiceSpeed, () => {
      setTestingVoiceId(null);
    });
  };

  const notifySaved = () => {
    setSaveBanner(true);
    setTimeout(() => setSaveBanner(false), 1800);
  };

  const handleTimeChange = (time: string) => {
    onUpdateSettings({ morningBriefingTime: time });
    notifySaved();
  };

  const handleToggleBriefing = (enabled: boolean) => {
    onUpdateSettings({ isDailyBriefingEnabled: enabled });
    notifySaved();
  };

  const handlePitchChange = (pitch: number) => {
    onUpdateSettings({ voicePitch: pitch });
  };

  const handleSpeedChange = (speed: number) => {
    onUpdateSettings({ voiceSpeed: speed });
  };

  const handlePersonalityChange = (personality: JarvisSettings['voicePersonality']) => {
    onUpdateSettings({ voicePersonality: personality });
    notifySaved();
  };

  const handleToggleReadNotifications = (enabled: boolean) => {
    onUpdateSettings({ readNotificationsOnArrival: enabled });
    notifySaved();
  };

  const handleToggleFilterImportant = (enabled: boolean) => {
    onUpdateSettings({ filterImportantOnly: enabled });
    notifySaved();
  };

  const toggleApp = (app: string) => {
    const next = settings.allowedApps.includes(app)
      ? settings.allowedApps.filter(a => a !== app)
      : [...settings.allowedApps, app];
    onUpdateSettings({ allowedApps: next });
    notifySaved();
  };

  return (
    <div className="w-full h-full flex flex-col bg-[#0A0E17] text-white relative">
      {/* Top Bar matching Jetpack Compose TopAppBar */}
      <div className="h-14 px-4 border-b border-slate-800/80 flex items-center justify-between bg-[#0A0E17] shrink-0">
        <div className="flex items-center gap-2.5">
          <button
            id="btn-settings-back"
            onClick={onNavigateBack}
            className="w-9 h-9 rounded-full flex items-center justify-center text-[#00E5FF] hover:bg-[#131B2E] transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2 className="text-sm font-mono tracking-widest font-bold text-white">SETTINGS</h2>
        </div>

        {saveBanner && (
          <span className="text-[10px] font-mono text-[#00E676] flex items-center gap-1 animate-pulse">
            <Save className="w-3 h-3" />
            STORED LOCALLY
          </span>
        )}
      </div>

      {/* Scrollable Settings Form */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 pb-8 text-slate-200">
        {/* SECTION 1 & 2: MORNING BRIEFING */}
        <div className="bg-[#131B2E] border border-slate-800 rounded-xl p-4 space-y-3.5 shadow-md">
          <div className="flex items-center gap-2 text-[#00E5FF] font-mono text-xs font-semibold tracking-wider">
            <AlarmClock className="w-4 h-4" />
            <span>1 & 2. MORNING BRIEFING SCHEDULE</span>
          </div>

          {/* 2. Enable/disable daily briefing */}
          <div className="flex items-center justify-between gap-3 pt-1">
            <div>
              <p className="text-xs font-semibold text-white">Enable Daily Briefing</p>
              <p className="text-[11px] text-slate-400">
                Scheduled morning trigger with weather & priorities
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                id="toggle-daily-briefing"
                checked={settings.isDailyBriefingEnabled}
                onChange={e => handleToggleBriefing(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#00E5FF]" />
            </label>
          </div>

          <div className="h-px bg-slate-800" />

          {/* 1. Morning briefing time */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs font-semibold text-white">Morning Briefing Time</p>
              <span className="text-xs font-mono font-bold text-[#00E5FF]">
                {settings.morningBriefingTime}
              </span>
            </div>

            {/* Quick time selection chips */}
            <div className="grid grid-cols-4 gap-1.5">
              {['06:30', '07:00', '07:30', '08:00'].map(time => (
                <button
                  key={time}
                  type="button"
                  onClick={() => handleTimeChange(time)}
                  className={`py-1.5 px-2 rounded-lg text-xs font-mono font-medium transition-all ${
                    settings.morningBriefingTime === time
                      ? 'bg-[#00E5FF] text-[#0A0E17] font-bold shadow-sm shadow-[#00E5FF]/30'
                      : 'bg-[#1C2640] text-slate-300 hover:bg-[#253354]'
                  }`}
                >
                  {time}
                </button>
              ))}
            </div>

            {/* Custom Time Input */}
            <div className="mt-2.5 flex items-center gap-2">
              <span className="text-[11px] text-slate-400">Custom time:</span>
              <input
                type="time"
                id="input-briefing-time"
                value={settings.morningBriefingTime}
                onChange={e => handleTimeChange(e.target.value)}
                className="bg-[#0A0E17] border border-slate-700 text-xs font-mono px-2 py-1 rounded text-[#00E5FF] focus:outline-none focus:border-[#00E5FF]"
              />
            </div>

            {/* AlarmManager Status Info */}
            <div className="mt-3 p-2.5 rounded-lg bg-[#0A0E17]/80 border border-slate-800 text-[11px] font-mono space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Android Scheduler:</span>
                <span className={settings.isDailyBriefingEnabled ? "text-[#00E676] font-bold" : "text-slate-500 font-bold"}>
                  {settings.isDailyBriefingEnabled ? `ACTIVE • ${settings.morningBriefingTime}` : "DISABLED"}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 leading-normal">
                {settings.isDailyBriefingEnabled
                  ? "Uses AlarmManager setAlarmClock() with boot restoration. Wakes device even when app is closed."
                  : "Daily briefing trigger disabled. Alarms are cleared and will not interrupt you."}
              </p>
            </div>

            {/* RUN FULL MORNING TEST BUTTON (Requirement 9) */}
            <div className="mt-3.5 pt-3 border-t border-slate-800/80">
              <button
                id="btn-run-full-morning-test"
                type="button"
                onClick={() => {
                  if (onRunFullMorningTest) {
                    onRunFullMorningTest();
                  } else if (onTriggerMorningBriefing) {
                    onTriggerMorningBriefing();
                  } else {
                    onTriggerTestCall();
                  }
                }}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#00E5FF] to-[#00E676] hover:opacity-95 text-[#0A0E17] text-xs font-mono font-bold tracking-wider flex items-center justify-center gap-2 transition-all active:scale-[0.98] shadow-lg shadow-cyan-950/40"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>RUN FULL MORNING TEST</span>
              </button>
              <p className="text-[10px] text-slate-400 mt-1.5 text-center font-mono leading-relaxed">
                Simulates complete morning event immediately: alarm alert ringtone, greeting, notifications, upcoming calendar events, and continuous hands-free dialogue.
              </p>
            </div>
          </div>
        </div>

        {/* SECTION 3: VOICE & SPEECH SETTINGS */}
        <div className="bg-[#131B2E] border border-slate-800 rounded-xl p-4 space-y-3.5 shadow-md">
          <div className="flex items-center gap-2 text-[#00E5FF] font-mono text-xs font-semibold tracking-wider">
            <Mic className="w-4 h-4" />
            <span>3. VOICE & SPEECH SETTINGS</span>
          </div>

          {/* Cinematic AI Voice Profiles */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <p className="text-xs font-semibold text-white">Cinematic AI Voice Profile</p>
              <span className="text-[10px] font-mono text-cyan-400">
                ACTIVE: {normalizeVoiceProfile(settings.voicePersonality)}
              </span>
            </div>

            <div className="space-y-2">
              {(Object.keys(VOICE_PROFILES) as VoiceProfileId[]).map(profileKey => {
                const profile = VOICE_PROFILES[profileKey];
                const isSelected = normalizeVoiceProfile(settings.voicePersonality) === profileKey;
                const isTesting = testingVoiceId === profileKey;

                return (
                  <div
                    key={profileKey}
                    onClick={() => handlePersonalityChange(profileKey)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-cyan-950/25 border-cyan-500/70 shadow-md shadow-cyan-950/30'
                        : 'bg-[#0A0E17]/80 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2.5">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`text-xs font-bold font-mono tracking-wider ${isSelected ? 'text-[#00E5FF]' : 'text-white'}`}>
                            {profile.name}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            • {profile.tagline}
                          </span>
                          {isSelected && (
                            <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                              ACTIVE
                            </span>
                          )}
                        </div>

                        <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
                          {profile.description}
                        </p>

                        {/* Badges / Specs */}
                        <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-800/80 text-slate-300 border border-slate-700/50">
                            Gemini: {profile.geminiVoiceMatch}
                          </span>
                          {profile.traits.map(trait => (
                            <span
                              key={trait}
                              className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-[#131B2E] text-slate-400 border border-slate-800"
                            >
                              {trait}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Test Voice Button */}
                      <button
                        type="button"
                        id={`btn-test-voice-${profileKey.toLowerCase().replace(/\s+/g, '-')}`}
                        onClick={e => handleTestVoice(profileKey, e)}
                        className={`shrink-0 px-2.5 py-1.5 rounded-lg text-[10px] font-mono font-bold flex items-center gap-1.5 transition-all active:scale-95 ${
                          isTesting
                            ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/50 animate-pulse'
                            : 'bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30'
                        }`}
                      >
                        <Volume2 className={`w-3.5 h-3.5 ${isTesting ? 'animate-bounce' : ''}`} />
                        <span>{isTesting ? 'PLAYING...' : 'TEST VOICE'}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Pitch Slider */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-300">Voice Pitch</span>
              <span className="font-mono text-[#00E5FF]">{settings.voicePitch.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              id="slider-voice-pitch"
              min="0.5"
              max="1.5"
              step="0.1"
              value={settings.voicePitch}
              onChange={e => handlePitchChange(parseFloat(e.target.value))}
              className="w-full accent-[#00E5FF] h-1.5 bg-slate-700 rounded-lg cursor-pointer"
            />
          </div>

          {/* Speed Slider */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-300">Speech Rate</span>
              <span className="font-mono text-[#00E5FF]">{settings.voiceSpeed.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              id="slider-voice-speed"
              min="0.5"
              max="1.5"
              step="0.1"
              value={settings.voiceSpeed}
              onChange={e => handleSpeedChange(parseFloat(e.target.value))}
              className="w-full accent-[#00E5FF] h-1.5 bg-slate-700 rounded-lg cursor-pointer"
            />
          </div>
        </div>

        {/* SECTION 4: NOTIFICATION ACCESS & BRIEFING SETTINGS */}
        <div className="bg-[#131B2E] border border-slate-800 rounded-xl p-4 space-y-4 shadow-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-[#00E5FF] font-mono text-xs font-semibold tracking-wider">
              <Bell className="w-4 h-4" />
              <span>4. NOTIFICATION BRIEFING SYSTEM</span>
            </div>
            <span
              className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
                settings.isNotificationAccessGranted
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                  : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
              }`}
            >
              {settings.isNotificationAccessGranted ? 'ACCESS GRANTED' : 'ACCESS REQUIRED'}
            </span>
          </div>

          {/* Android Notification Access Permission Card */}
          <div
            className={`p-3.5 rounded-xl border transition-colors ${
              settings.isNotificationAccessGranted
                ? 'bg-emerald-950/20 border-emerald-500/30'
                : 'bg-amber-950/20 border-amber-500/40'
            }`}
          >
            <div className="flex items-start gap-2.5">
              {settings.isNotificationAccessGranted ? (
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              )}
              <div className="flex-1 space-y-1">
                <p className="text-xs font-bold text-white">
                  {settings.isNotificationAccessGranted
                    ? 'Android Notification Access Granted'
                    : 'Enable Notification Access in Android Settings'}
                </p>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  {settings.isNotificationAccessGranted
                    ? 'JARVIS is authorized to read notifications locally on-device. Zero data is transmitted to external servers.'
                    : 'Android security restricts notification access. JARVIS cannot and will not access notification contents until you explicitly enable Notification Access.'}
                </p>

                <div className="pt-2">
                  <button
                    id="btn-toggle-notification-access"
                    type="button"
                    onClick={() => {
                      const next = !settings.isNotificationAccessGranted;
                      onUpdateSettings({ isNotificationAccessGranted: next });
                      notifySaved();
                    }}
                    className={`py-1.5 px-3 rounded-lg text-xs font-mono font-bold flex items-center gap-1.5 transition-colors ${
                      settings.isNotificationAccessGranted
                        ? 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                        : 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-md'
                    }`}
                  >
                    {settings.isNotificationAccessGranted ? (
                      <>
                        <Lock className="w-3.5 h-3.5" />
                        REVOKE ACCESS
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        GRANT NOTIFICATION ACCESS (SETTINGS)
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Importance Filter */}
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-xs font-semibold text-white">Importance Filter (Ignore Noise)</p>
              <p className="text-[11px] text-slate-400">
                Ignore low-priority notifications, silent downloads, and ongoing background syncs
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                id="toggle-filter-important"
                checked={settings.filterImportantOnly}
                onChange={e => handleToggleFilterImportant(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#00E5FF]" />
            </label>
          </div>

          <div className="h-px bg-slate-800" />

          {/* Read on arrival */}
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-xs font-semibold text-white">Read on Arrival (Immediate)</p>
              <p className="text-[11px] text-slate-400">
                Vocalize notifications hands-free as they arrive throughout the day
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                id="toggle-read-notifications"
                checked={settings.readNotificationsOnArrival}
                onChange={e => handleToggleReadNotifications(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#00E5FF]" />
            </label>
          </div>

          <div className="h-px bg-slate-800" />

          {/* Allowed Apps & Categories */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs font-semibold text-white">Monitored Applications & Categories</p>
              <span className="text-[10px] font-mono text-slate-400">
                {settings.allowedApps.length} active
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {[
                { name: 'WhatsApp', cat: 'Messaging' },
                { name: 'Gmail', cat: 'Email' },
                { name: 'Calendar', cat: 'Schedule' },
                { name: 'YouTube', cat: 'Video' },
                { name: 'Slack', cat: 'Work' },
                { name: 'Messages', cat: 'SMS' },
              ].map(item => {
                const isSelected = settings.allowedApps.includes(item.name);
                return (
                  <button
                    key={item.name}
                    type="button"
                    onClick={() => toggleApp(item.name)}
                    className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition-colors flex items-center gap-1 ${
                      isSelected
                        ? 'bg-[#00E5FF]/20 text-[#00E5FF] border border-[#00E5FF]/50'
                        : 'bg-[#1C2640] text-slate-400 border border-transparent'
                    }`}
                  >
                    <span>{item.name}</span>
                    <span className="text-[9px] opacity-60">({item.cat})</span>
                    {isSelected && <span className="ml-0.5">✓</span>}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Local Storage Notice */}
          <div className="p-2.5 bg-slate-900/60 rounded-lg border border-slate-800/80 text-[10px] text-slate-400 font-mono">
            <span className="text-slate-300 font-semibold">Local Storage: </span>
            {settings.capturedNotifications.length} notification entries stored locally on device.
            Minimum metadata stored (App, title, text, timestamp). Never uploaded to cloud servers.
          </div>

          {/* TEST NOTIFICATION BRIEFING BUTTON WITH PREVIEW */}
          <div className="pt-1">
            <button
              id="btn-test-notification-briefing"
              type="button"
              onClick={() => setShowBriefingPreviewModal(true)}
              className="w-full py-2.5 px-3 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/40 text-[#00E5FF] text-xs font-mono font-bold flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
            >
              <FileText className="w-4 h-4" />
              TEST NOTIFICATION BRIEFING (PREVIEW)
            </button>
          </div>
        </div>

        {/* SECTION 5: TEST INDIVIDUAL NOTIFICATION EVENT */}
        <div className="bg-[#131B2E] border border-slate-800 rounded-xl p-4 space-y-3 shadow-md">
          <div className="flex items-center gap-2 text-[#00E5FF] font-mono text-xs font-semibold tracking-wider">
            <CheckCircle2 className="w-4 h-4" />
            <span>5. TEST INCOMING ALERT INTERCEPTION</span>
          </div>
          <p className="text-xs text-slate-400">
            Simulates an incoming WhatsApp or Gmail notification passing through the Android
            NotificationListenerService pipeline.
          </p>
          <button
            id="btn-test-notification-access"
            type="button"
            onClick={onTriggerTestNotification}
            className="w-full py-2.5 px-3 rounded-lg bg-[#1C2640] hover:bg-[#253354] border border-[#00E5FF]/40 text-[#00E5FF] text-xs font-mono font-semibold flex items-center justify-center gap-2 transition-colors active:scale-[0.98]"
          >
            <Bell className="w-4 h-4" />
            DISPATCH TEST NOTIFICATION
          </button>
        </div>

        {/* SECTION 6: TEST JARVIS CALL */}
        <div className="bg-[#131B2E] border border-slate-800 rounded-xl p-4 space-y-3 shadow-md">
          <div className="flex items-center gap-2 text-[#00E5FF] font-mono text-xs font-semibold tracking-wider">
            <PhoneCall className="w-4 h-4" />
            <span>6. TEST JARVIS CALL (INCOMING)</span>
          </div>
          <p className="text-xs text-slate-400">
            Launches full-screen incoming-call-style JARVIS screen for scheduled morning briefing or urgent
            hands-free voice interaction.
          </p>
          <button
            id="btn-test-jarvis-call-settings"
            type="button"
            onClick={onTriggerTestCall}
            className="w-full py-2.5 px-3 rounded-lg bg-[#00E5FF] hover:bg-[#00c4db] text-[#0A0E17] text-xs font-bold flex items-center justify-center gap-2 transition-transform active:scale-[0.98] shadow-lg shadow-[#00E5FF]/20"
          >
            <PhoneCall className="w-4 h-4" />
            TEST JARVIS CALL (INCOMING)
          </button>
        </div>

        {/* SECTION 7: PERMISSIONS & DEVICE SETUP */}
        <div className="bg-[#131B2E] border border-slate-800 rounded-xl p-4 space-y-4 shadow-md">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-xs font-bold font-mono text-[#00E5FF] tracking-wider uppercase">
                  7. PERMISSIONS & DEVICE SETUP
                </h3>
                <p className="text-[11px] text-slate-400">
                  Prepare JARVIS for real Android-device operation
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                NON-CRASH RESILIENT
              </span>
            </div>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            In strict compliance with Android Runtime Security, JARVIS requests only necessary capabilities and never crashes when permissions are denied. If any permission is withheld, on-screen text fallbacks ensure seamless continued operation.
          </p>

          {/* Prominent Device Readiness Check Action Banner */}
          <div className="p-3.5 rounded-xl bg-gradient-to-r from-[#0E1729] to-[#0A1220] border border-cyan-500/30 space-y-3 shadow-lg shadow-cyan-950/30">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-0.5">
                <div className="text-[10px] font-mono text-cyan-400 uppercase tracking-wider font-semibold flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5" />
                  <span>Hardware & OS Readiness Telemetry</span>
                </div>
                <div className="text-white font-bold text-sm">
                  Run Full Android Subsystem Audit
                </div>
                <div className="text-[11px] text-slate-400">
                  Evaluates mic, notification listener, calendar, alarms, full-screen intents, and power management.
                </div>
              </div>

              <button
                id="btn-device-readiness-check"
                type="button"
                onClick={handleCheckDeviceReadiness}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-cyan-400 hover:from-cyan-400 hover:to-cyan-300 text-slate-950 font-mono font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md shadow-cyan-500/30 active:scale-[0.98] shrink-0"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>DEVICE READINESS CHECK</span>
              </button>
            </div>

            {/* Quick Status Bar */}
            {(() => {
              const audit = performDeviceReadinessCheck(settings);
              return (
                <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono">
                  <div className="flex items-center gap-3">
                    <span className="text-emerald-400 flex items-center gap-1 font-semibold">
                      ✓ {audit.grantedCount} Granted
                    </span>
                    <span className="text-amber-400 flex items-center gap-1 font-semibold">
                      ⚠ {audit.requiredCount} Required
                    </span>
                    <span className="text-rose-400 flex items-center gap-1 font-semibold">
                      ✕ {audit.deniedCount} Denied
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-slate-400">
                    <span>Overall: {audit.percentage}% Ready</span>
                    <button
                      type="button"
                      onClick={handleGrantAll}
                      className="text-cyan-400 hover:text-cyan-300 underline text-[10px]"
                    >
                      Grant All (Simulator)
                    </button>
                  </div>
                </div>
              );
            })()}
          </div>

          {/* Filter Tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-[#0A0E17] rounded-lg border border-slate-800 text-xs font-mono">
            <button
              type="button"
              onClick={() => setPermissionFilter('all')}
              className={`flex-1 py-1 px-2 rounded-md transition-colors ${
                permissionFilter === 'all'
                  ? 'bg-[#1C2640] text-cyan-300 font-bold border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Permissions (8)
            </button>
            <button
              type="button"
              onClick={() => setPermissionFilter('remaining')}
              className={`flex-1 py-1 px-2 rounded-md transition-colors ${
                permissionFilter === 'remaining'
                  ? 'bg-[#1C2640] text-amber-300 font-bold border border-amber-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Action Required / Denied
            </button>
            <button
              type="button"
              onClick={() => setPermissionFilter('granted')}
              className={`flex-1 py-1 px-2 rounded-md transition-colors ${
                permissionFilter === 'granted'
                  ? 'bg-[#1C2640] text-emerald-300 font-bold border border-emerald-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Granted
            </button>
          </div>

          {/* Permissions List */}
          <div className="space-y-2.5">
            {DEVICE_PERMISSIONS_CATALOG.filter(perm => {
              const status = getPermissionStatus(settings, perm.id);
              if (permissionFilter === 'remaining') return status !== 'GRANTED';
              if (permissionFilter === 'granted') return status === 'GRANTED';
              return true;
            }).map(perm => {
              const status = getPermissionStatus(settings, perm.id);
              const isGranted = status === 'GRANTED';
              const isDenied = status === 'DENIED';

              // Icon mapping
              const renderIcon = () => {
                const iconClass = `w-4 h-4 ${
                  isGranted ? 'text-emerald-400' : isDenied ? 'text-rose-400' : 'text-amber-400'
                }`;
                switch (perm.id) {
                  case 'microphone':
                    return <Mic className={iconClass} />;
                  case 'notification_listener':
                    return <Bell className={iconClass} />;
                  case 'calendar':
                    return <Calendar className={iconClass} />;
                  case 'fullscreen_intent':
                    return <Maximize2 className={iconClass} />;
                  case 'exact_alarm':
                    return <AlarmClock className={iconClass} />;
                  case 'post_notifications':
                    return <Bell className={iconClass} />;
                  case 'battery_optimization':
                    return <BatteryCharging className={iconClass} />;
                  case 'boot_completed':
                    return <RefreshCw className={iconClass} />;
                  default:
                    return <ShieldCheck className={iconClass} />;
                }
              };

              return (
                <div
                  key={perm.id}
                  className={`p-3 rounded-xl border transition-colors ${
                    isGranted
                      ? 'bg-[#0A0E17]/80 border-slate-800'
                      : isDenied
                      ? 'bg-rose-950/10 border-rose-500/30'
                      : 'bg-amber-950/10 border-amber-500/30'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    {/* Left Info */}
                    <div className="flex items-start gap-3 flex-1">
                      <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 shrink-0 mt-0.5">
                        {renderIcon()}
                      </div>

                      <div className="space-y-1.5 flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-xs font-bold text-white tracking-wide">
                            {perm.name}
                          </span>

                          {/* Explicit status badge: ✓ Granted, ⚠ Required, ✕ Denied */}
                          {status === 'GRANTED' && (
                            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                              <Check className="w-3 h-3" />
                              <span>Granted</span>
                            </span>
                          )}
                          {status === 'REQUIRED' && (
                            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1">
                              <AlertTriangle className="w-3 h-3" />
                              <span>Required</span>
                            </span>
                          )}
                          {status === 'DENIED' && (
                            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 flex items-center gap-1">
                              <XCircle className="w-3 h-3" />
                              <span>Denied</span>
                            </span>
                          )}

                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                            {perm.androidApiLevel}
                          </span>
                        </div>

                        <div className="text-[10px] font-mono text-cyan-400/90 break-all select-all">
                          {perm.manifestPermission}
                        </div>

                        <p className="text-[11px] text-slate-300 leading-relaxed">
                          {perm.whyNeeded}
                        </p>

                        <div className="p-2 rounded-lg bg-[#060911] border border-slate-800/80 text-[10px] font-mono text-emerald-300/80 flex items-start gap-1.5">
                          <span className="text-emerald-400 font-bold shrink-0">Fallback:</span>
                          <span>{perm.gracefulFallback}</span>
                        </div>
                      </div>
                    </div>

                    {/* Right Actions */}
                    <div className="flex flex-row sm:flex-col items-center sm:items-end justify-between sm:justify-start gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800/60">
                      {/* Button that opens the correct Android Settings screen */}
                      <button
                        id={`btn-open-settings-${perm.id}`}
                        type="button"
                        onClick={() => handleOpenPermissionSettings(perm)}
                        className={`px-3 py-1.5 rounded-lg text-[10px] font-mono font-bold flex items-center gap-1.5 transition-colors shadow-sm ${
                          isGranted
                            ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                            : 'bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold'
                        }`}
                      >
                        <ExternalLink className="w-3 h-3" />
                        <span>OPEN ANDROID SETTINGS</span>
                      </button>

                      {/* Quick simulation toggle */}
                      <button
                        id={`btn-cycle-${perm.id}`}
                        type="button"
                        onClick={() => handleCycleStatus(perm.id)}
                        className="text-[9px] font-mono text-slate-400 hover:text-cyan-300 underline"
                      >
                        {isGranted ? 'Simulate Revocation' : isDenied ? 'Re-test Grant' : 'Simulate Grant'}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Battery / Background Optimization Guidance Card */}
          <div className="p-3.5 rounded-xl bg-[#0A0E17] border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-cyan-400 font-mono font-semibold text-xs">
                <BatteryCharging className="w-4 h-4" />
                <span>BATTERY & BACKGROUND OPTIMIZATION GUIDANCE</span>
              </div>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                settings.isBatteryOptimizationIgnored
                  ? 'bg-emerald-500/20 text-emerald-300'
                  : 'bg-amber-500/20 text-amber-300'
              }`}>
                {settings.isBatteryOptimizationIgnored ? '✓ EXEMPTED' : '⚠ STANDARD DOZE'}
              </span>
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed">
              Real Android OEM devices (Samsung OneUI, Xiaomi MIUI, Huawei EMUI, Pixel) employ aggressive background app killers that delay exact morning alarms. To guarantee JARVIS rings on time:
            </p>

            <ul className="list-disc list-inside space-y-1 text-[10px] text-slate-400 font-mono">
              <li>Exclude JARVIS from OEM "Sleeping Apps" / "Deep Sleep" lists.</li>
              <li>Allow "Unrestricted" background battery usage in App Info &gt; Battery.</li>
              <li>Intent action: <code className="text-cyan-300">Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS</code></li>
            </ul>

            <div className="flex items-center justify-end pt-1">
              <button
                type="button"
                id="btn-exempt-battery"
                onClick={() => {
                  const perm = DEVICE_PERMISSIONS_CATALOG.find(p => p.id === 'battery_optimization');
                  if (perm) handleOpenPermissionSettings(perm);
                }}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-mono font-semibold text-[10px] flex items-center gap-1.5 transition-colors border border-cyan-500/20"
              >
                <Smartphone className="w-3 h-3" />
                <span>OPEN BATTERY OPTIMIZATION SETTINGS</span>
              </button>
            </div>
          </div>

          {/* Boot & Restart Handling Verification Card */}
          <div className="p-3 rounded-xl bg-[#0A0E17]/90 border border-slate-800 text-[11px] font-mono space-y-2 text-slate-300">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-cyan-400 font-semibold">
                <RefreshCw className="w-3.5 h-3.5" />
                <span>BOOT & RESTART RESCHEDULING VERIFIED</span>
              </div>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded">
                ✓ MANIFEST REGISTERED
              </span>
            </div>

            <p className="text-[10px] text-slate-400 leading-relaxed">
              When the device reboots, Android clears active <code className="text-cyan-300">AlarmManager</code> registrations. JARVIS implements a manifest-registered <code className="text-cyan-300">BootReceiver</code> for <code className="text-cyan-300">android.intent.action.BOOT_COMPLETED</code> to calculate the next morning briefing time and reschedule with <code className="text-cyan-300">setAlarmClock()</code> without requiring user interaction.
            </p>
          </div>
        </div>
      </div>

      {/* Briefing Preview Modal */}
      <NotificationBriefingModal
        isOpen={showBriefingPreviewModal}
        settings={settings}
        onClose={() => setShowBriefingPreviewModal(false)}
        onGrantAccess={() => {
          onUpdateSettings({ isNotificationAccessGranted: true });
          notifySaved();
        }}
        onStartMorningCall={onTriggerMorningBriefing || onTriggerTestCall}
      />

      {/* Android Settings Intent Dispatcher Modal */}
      <AndroidSettingsModal
        isOpen={!!selectedPermissionForModal}
        permission={selectedPermissionForModal}
        onClose={() => setSelectedPermissionForModal(null)}
        onGrant={handleGrantPermission}
        onDeny={handleDenyPermission}
      />

      {/* Device Readiness Audit Modal */}
      <DeviceReadinessReportModal
        isOpen={showReadinessModal}
        auditResult={auditResult}
        onClose={() => setShowReadinessModal(false)}
        onOpenSettings={handleOpenPermissionSettings}
        onGrantAll={handleGrantAll}
      />
    </div>
  );
};
