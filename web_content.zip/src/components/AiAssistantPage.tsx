import React, { useState, useRef, useEffect } from 'react';
import { useData } from '../context/DataContext.tsx';
import {
  ArrowLeft,
  Send,
  Sparkles,
  User,
  Bot,
  MessageSquarePlus,
  CheckCircle2,
  Clock,
  ShieldAlert,
  RefreshCw,
  Trash2,
  Ticket,
  Users,
  ChevronRight
} from 'lucide-react';
import type { SupportTicket } from '../types/index.ts';

interface AiAssistantPageProps {
  onBackHome: () => void;
}

export const AiAssistantPage: React.FC<AiAssistantPageProps> = ({ onBackHome }) => {
  const {
    data,
    cubesId,
    aiMessages,
    aiSending,
    sendAiChatMessage,
    clearAiChat,
    submitTalkWithFounders,
    clientTickets,
    sendCubesTicketReply
  } = useData();

  const [inputText, setInputText] = useState('');
  const [founderRequestNote, setFounderRequestNote] = useState('');
  const [showFounderModal, setShowFounderModal] = useState(false);
  const [submittingTicket, setSubmittingTicket] = useState(false);
  const [submittedTicketConfirmation, setSubmittedTicketConfirmation] = useState<SupportTicket | null>(null);
  const [ticketError, setTicketError] = useState<string | null>(null);
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);
  const [ticketReplyText, setTicketReplyText] = useState('');
  const [sendingTicketReply, setSendingTicketReply] = useState(false);

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [aiMessages, aiSending]);

  const myCubesTickets = clientTickets.filter(
    (t) =>
      !cubesId ||
      (t.cubesId && t.cubesId.toLowerCase() === cubesId.toLowerCase()) ||
      (t.username && t.username.toLowerCase() === cubesId.toLowerCase())
  );

  const activeTicket =
    myCubesTickets.find((t) => t.id === selectedTicketId || t.ticketNumber === selectedTicketId) ||
    myCubesTickets[0] ||
    null;

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || aiSending) return;
    const msg = inputText.trim();
    setInputText('');
    await sendAiChatMessage(msg);
  };

  const handleQuickPrompt = async (prompt: string) => {
    if (aiSending) return;
    await sendAiChatMessage(prompt);
  };

  // Direct "Talk With Founders" submission handler
  const handleTalkWithFoundersClick = async (customNote?: string) => {
    setSubmittingTicket(true);
    setTicketError(null);
    try {
      const noteToSubmit =
        customNote !== undefined
          ? customNote
          : founderRequestNote.trim() ||
            (inputText.trim() ? `Client ${cubesId || 'Cubes-1'} request: ${inputText.trim()}` : '');

      const res = await submitTalkWithFounders(noteToSubmit);
      if (res.success && res.ticket) {
        setSubmittedTicketConfirmation(res.ticket);
        setSelectedTicketId(res.ticket.id);
        setFounderRequestNote('');
        setShowFounderModal(false);
      } else {
        setTicketError(res.error || 'Could not submit support request.');
      }
    } finally {
      setSubmittingTicket(false);
    }
  };

  const handleSendClientReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTicket || !ticketReplyText.trim() || sendingTicketReply) return;
    setSendingTicketReply(true);
    try {
      const msg = ticketReplyText.trim();
      setTicketReplyText('');
      await sendCubesTicketReply(activeTicket.id, msg);
    } finally {
      setSendingTicketReply(false);
    }
  };

  const getStatusBadgeStyle = (status: string) => {
    const s = status.toLowerCase();
    if (s === 'resolved' || s === 'completed') {
      return 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30';
    }
    if (s === 'in progress') {
      return 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30';
    }
    return 'bg-amber-500/15 text-amber-300 border-amber-500/30';
  };

  const normalizeDisplayStatus = (status: string) => {
    if (status === 'Open') return 'Pending';
    if (status === 'Completed') return 'Resolved';
    return status;
  };

  return (
    <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-8 sm:py-10">
      {/* Top Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 mb-6 border-b border-slate-800/80">
        <div className="flex items-center gap-3.5">
          <button
            type="button"
            onClick={onBackHome}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white text-xs sm:text-sm font-medium transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Home</span>
          </button>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight font-['Plus_Jakarta_Sans']">
                {data?.aiAssistant?.sectionTitle || 'Cubix AI Assistant'}
              </h1>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 text-xs font-mono font-semibold">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>{cubesId || 'Allocating ID...'}</span>
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400">
              Dedicated AI session for <span className="text-slate-200 font-semibold">{cubesId || 'Cubes-1'}</span> • Ask questions or connect with Founders
            </p>
          </div>
        </div>

        {/* Talk With Founders Primary Action Button */}
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => handleTalkWithFoundersClick()}
            disabled={submittingTicket}
            className="inline-flex items-center gap-2 px-4 sm:px-5 py-2.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 disabled:opacity-60 text-slate-950 font-extrabold text-xs sm:text-sm transition-all cursor-pointer shadow-sm"
          >
            <Users className="w-4 h-4" />
            <span>{submittingTicket ? 'Submitting Request...' : 'Talk With Founders'}</span>
          </button>

          <button
            type="button"
            onClick={() => setShowFounderModal((prev) => !prev)}
            className="inline-flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-slate-300 hover:text-white text-xs font-medium transition-colors cursor-pointer"
            title="Add custom note for Founders"
          >
            <MessageSquarePlus className="w-4 h-4 text-cyan-400" />
            <span className="hidden sm:inline">Custom Note</span>
          </button>
        </div>
      </div>

      {/* Confirmation Banner when a Talk With Founders request is submitted */}
      {submittedTicketConfirmation && (
        <div className="mb-6 p-4 sm:p-5 rounded-xl border border-emerald-500/40 bg-emerald-950/25 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-sm font-bold text-white flex flex-wrap items-center gap-2">
                <span>Support Request Submitted to Founders!</span>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 font-mono text-xs">
                  {submittedTicketConfirmation.ticketNumber}
                </span>
                <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-cyan-300 font-mono text-xs">
                  Client ID: {submittedTicketConfirmation.cubesId || cubesId}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 mt-1">
                Submitted on {new Date(submittedTicketConfirmation.createdAt).toLocaleString()} — Status:{' '}
                <span className="font-semibold text-amber-300">
                  {normalizeDisplayStatus(submittedTicketConfirmation.status)}
                </span>
                . You can track real-time status updates and Founder replies in the Support Status panel.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setSubmittedTicketConfirmation(null)}
            className="text-xs text-slate-400 hover:text-white self-end sm:self-center cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {ticketError && (
        <div className="mb-6 p-4 rounded-xl border border-rose-500/40 bg-rose-950/30 text-rose-200 text-xs sm:text-sm flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{ticketError}</span>
          </div>
          <button onClick={() => setTicketError(null)} className="text-xs underline cursor-pointer">
            Close
          </button>
        </div>
      )}

      {/* Optional Custom Note Drawer for Talk With Founders */}
      {showFounderModal && (
        <div className="mb-6 p-5 rounded-xl border border-cyan-500/30 bg-[#071324] space-y-3">
          <div className="flex items-center justify-between">
            <div className="text-sm font-bold text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-cyan-400" />
              <span>Send a Request to the Founders ({cubesId || 'Cubes-1'})</span>
            </div>
            <button
              type="button"
              onClick={() => setShowFounderModal(false)}
              className="text-xs text-slate-400 hover:text-white cursor-pointer"
            >
              Close
            </button>
          </div>
          <p className="text-xs text-slate-300">
            Describe your project, question, or support request below. Your unique client ID ({cubesId || 'Cubes-1'}) and submission time will be attached automatically.
          </p>
          <div className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              value={founderRequestNote}
              onChange={(e) => setFounderRequestNote(e.target.value)}
              placeholder="Enter request details for the Founders (or leave blank to send chat summary)..."
              className="flex-1 px-3.5 py-2.5 rounded-lg bg-slate-950 border border-slate-800 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
            />
            <button
              type="button"
              onClick={() => handleTalkWithFoundersClick(founderRequestNote)}
              disabled={submittingTicket}
              className="px-5 py-2.5 rounded-lg bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 text-slate-950 font-bold text-xs sm:text-sm cursor-pointer shrink-0"
            >
              {submittingTicket ? 'Sending...' : 'Submit Request'}
            </button>
          </div>
        </div>
      )}

      {/* Main Grid: Left 8 Cols Chat Interface, Right 4 Cols Client Identity & Support Request Status */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Dedicated AI Chat Interface */}
        <div className="lg:col-span-8 rounded-2xl border border-slate-800/90 bg-[#050d1a]/95 flex flex-col h-[620px] overflow-hidden shadow-xl">
          {/* Chat Header */}
          <div className="px-5 py-3.5 border-b border-slate-800/80 bg-[#030914] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs sm:text-sm font-bold text-white">Cubix Studio AI Assistant</div>
                <div className="text-[11px] font-mono text-slate-400">
                  Private Conversation • Client <span className="text-cyan-300">{cubesId || 'Cubes-1'}</span>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={clearAiChat}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 text-xs transition-colors cursor-pointer"
              title="Reset conversation"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Chat</span>
            </button>
          </div>

          {/* Messages Stream */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {aiMessages.map((msg) => {
              const isUser = msg.sender === 'user';
              return (
                <div
                  key={msg.id}
                  className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
                >
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border ${
                      isUser
                        ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300'
                        : 'bg-slate-900 border-slate-800 text-cyan-400'
                    }`}
                  >
                    {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                  </div>

                  <div
                    className={`max-w-[80%] rounded-xl px-4 py-3 text-sm leading-relaxed ${
                      isUser
                        ? 'bg-cyan-500/15 border border-cyan-500/30 text-white'
                        : 'bg-slate-900/90 border border-slate-800/90 text-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-4 mb-1 text-[10px] font-mono text-slate-400">
                      <span className={isUser ? 'text-cyan-300 font-semibold' : 'text-slate-400'}>
                        {isUser ? cubesId || 'Client' : 'Cubix AI'}
                      </span>
                      <span>
                        {msg.createdAt
                          ? new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                          : ''}
                      </span>
                    </div>
                    <div className="whitespace-pre-wrap">{msg.text}</div>
                  </div>
                </div>
              );
            })}

            {aiSending && (
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-cyan-400">
                  <Bot className="w-4 h-4" />
                </div>
                <div className="rounded-xl px-4 py-3 bg-slate-900/90 border border-slate-800/90 text-slate-300 text-xs flex items-center gap-2">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-cyan-400" />
                  <span>Cubix AI is typing a response for {cubesId}...</span>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Quick Prompt Suggestions */}
          <div className="px-4 py-2.5 border-t border-slate-800/60 bg-[#030914]/60 flex items-center gap-2 overflow-x-auto no-scrollbar">
            {[
              'What services does Cubix Studio offer?',
              'Who are the Founders of Cubix Studio?',
              'How do I start a new project?',
              'How can I talk with the Founders?'
            ].map((q) => (
              <button
                key={q}
                type="button"
                onClick={() => handleQuickPrompt(q)}
                disabled={aiSending}
                className="px-3 py-1 rounded-full bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white text-xs whitespace-nowrap transition-colors cursor-pointer shrink-0"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Message Input Bar */}
          <form
            onSubmit={handleSendMessage}
            className="p-3.5 border-t border-slate-800/90 bg-[#030914] flex items-center gap-2.5"
          >
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={`Ask Cubix AI anything as ${cubesId || 'Cubes-1'}...`}
              className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
            />
            <button
              type="submit"
              disabled={!inputText.trim() || aiSending}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 text-slate-950 font-bold text-sm transition-all cursor-pointer"
            >
              <span>Send</span>
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>

        {/* Right: Talk With Founders & Live Ticket Status Tracker */}
        <div className="lg:col-span-4 space-y-5">
          {/* Card 1: Client Identity & Talk With Founders Box */}
          <div className="rounded-2xl border border-slate-800/90 bg-[#050d1a]/95 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono uppercase tracking-wider text-slate-400">Client Identity</span>
              <span className="px-2.5 py-1 rounded-md bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 font-mono text-xs font-bold">
                {cubesId || 'Cubes-1'}
              </span>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800/80 space-y-2">
              <div className="text-sm font-bold text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-cyan-400" />
                <span>Need Direct Founder Assistance?</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Click <strong>Talk With Founders</strong> below to automatically generate a support ticket under your ID (
                <span className="text-cyan-300 font-mono">{cubesId || 'Cubes-1'}</span>) and send it directly to the Admin Panel.
              </p>
              <button
                type="button"
                onClick={() => handleTalkWithFoundersClick()}
                disabled={submittingTicket}
                className="w-full mt-2 py-2.5 px-4 rounded-xl bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 text-slate-950 font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Users className="w-4 h-4" />
                <span>{submittingTicket ? 'Submitting Request...' : 'Talk With Founders'}</span>
              </button>
            </div>
          </div>

          {/* Card 2: Client's Support Requests & Real-Time Status */}
          <div className="rounded-2xl border border-slate-800/90 bg-[#050d1a]/95 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Ticket className="w-4 h-4 text-cyan-400" />
                <h2 className="text-sm font-bold text-white">Your Founder Requests ({myCubesTickets.length})</h2>
              </div>
              <span className="text-[11px] font-mono text-emerald-400">Live Sync</span>
            </div>

            {myCubesTickets.length === 0 ? (
              <div className="p-5 rounded-xl bg-slate-900/50 border border-slate-800/70 text-center space-y-1.5">
                <Clock className="w-5 h-5 text-slate-500 mx-auto" />
                <div className="text-xs font-semibold text-slate-300">No Support Requests Yet</div>
                <p className="text-[11px] text-slate-400">
                  When you click "Talk With Founders", your ticket status (Pending, In Progress, Resolved) and Founder replies will appear here.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {/* Ticket Selector List */}
                <div className="space-y-2 max-h-44 overflow-y-auto pr-1">
                  {myCubesTickets.map((t) => {
                    const isSelected = activeTicket?.id === t.id;
                    const displayStatus = normalizeDisplayStatus(t.status);
                    return (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => setSelectedTicketId(t.id)}
                        className={`w-full text-left p-3 rounded-xl border transition-all cursor-pointer ${
                          isSelected
                            ? 'bg-slate-900 border-cyan-500/40'
                            : 'bg-slate-950/70 border-slate-800/80 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <span className="font-mono text-xs font-bold text-white">{t.ticketNumber}</span>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold border ${getStatusBadgeStyle(
                              displayStatus
                            )}`}
                          >
                            {displayStatus}
                          </span>
                        </div>
                        <div className="text-xs text-slate-300 line-clamp-1">{t.requestDetails}</div>
                        <div className="mt-1 flex items-center justify-between text-[10px] font-mono text-slate-400">
                          <span>ID: {t.cubesId || cubesId}</span>
                          <span>{new Date(t.createdAt).toLocaleDateString()}</span>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Selected Ticket Details & Conversation */}
                {activeTicket && (
                  <div className="pt-3 border-t border-slate-800/80 space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-xs font-mono font-bold text-cyan-300">{activeTicket.ticketNumber}</span>
                        <span className="text-[11px] text-slate-400 ml-2">
                          ({activeTicket.cubesId || cubesId})
                        </span>
                      </div>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold border ${getStatusBadgeStyle(
                          normalizeDisplayStatus(activeTicket.status)
                        )}`}
                      >
                        {normalizeDisplayStatus(activeTicket.status)}
                      </span>
                    </div>

                    <div className="space-y-2 max-h-48 overflow-y-auto p-3 rounded-xl bg-slate-950/90 border border-slate-800/80">
                      {(activeTicket.conversation || []).map((c) => (
                        <div
                          key={c.id}
                          className={`p-2.5 rounded-lg text-xs ${
                            c.sender === 'admin'
                              ? 'bg-cyan-500/15 border border-cyan-500/30 text-white'
                              : 'bg-slate-900 border border-slate-800 text-slate-200'
                          }`}
                        >
                          <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 mb-1">
                            <span className={c.sender === 'admin' ? 'text-cyan-300 font-bold' : 'text-slate-300'}>
                              {c.sender === 'admin' ? `${c.senderName} (Founder)` : c.senderName}
                            </span>
                            <span>
                              {new Date(c.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                          <div className="whitespace-pre-wrap">{c.message}</div>
                        </div>
                      ))}
                    </div>

                    <form onSubmit={handleSendClientReply} className="flex items-center gap-2">
                      <input
                        type="text"
                        value={ticketReplyText}
                        onChange={(e) => setTicketReplyText(e.target.value)}
                        placeholder="Reply to Founders on this ticket..."
                        className="flex-1 px-3 py-2 rounded-lg bg-slate-950 border border-slate-800 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
                      />
                      <button
                        type="submit"
                        disabled={!ticketReplyText.trim() || sendingTicketReply}
                        className="px-3 py-2 rounded-lg bg-cyan-400 hover:bg-cyan-300 disabled:opacity-50 text-slate-950 font-bold text-xs cursor-pointer flex items-center gap-1"
                      >
                        <span>Reply</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </form>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
