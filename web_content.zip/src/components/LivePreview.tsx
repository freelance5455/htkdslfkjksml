/**
 * GODEX Live Application Preview & Execution Sandbox
 * Strictly decoupled from GODEX IDE shell layout.
 * Real responsive viewports (Desktop: fluid, Tablet: 768x1024, Mobile: 390x844).
 * Truthful status indicators, dedicated build failure screens, and runtime diagnostics.
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Monitor, Tablet, Smartphone, RotateCw, 
  AlertTriangle, ShieldCheck, Sparkles, CheckCircle2, 
  Loader2, Play, Code2, RefreshCw, XCircle, ExternalLink,
  ChevronRight, Wrench, Bug, Maximize2, Eye, Crosshair
} from 'lucide-react';
import { ViewportDevice, PreviewState, PreviewBuildError, ResponsiveTestReport } from '../types';
import { SandboxRunner } from '../services/sandboxRunner';
import { PreviewService } from '../services/previewService';
import { PreviewTester } from '../services/previewTester';
import { OperationManager } from '../godex/operationManager';
import { GeneratedArtifact, OperationState } from '../godex/operationState';
import { RuntimeInterceptor } from '../services/runtimeInterceptor';
import { VisualBridge } from '../services/visualBridge';

export interface LivePreviewProps {
  files?: Record<string, string>;
  artifact?: GeneratedArtifact | null;
  operationId?: string;
  isVerifying?: boolean;
  onConsoleLog?: (level: string, message: string) => void;
  onRuntimeError?: (err: any) => void;
  onAutoFixError?: (errorMessage: string) => void;
  onSelectFile?: (file: string) => void;
  onSelectWorkspaceView?: (view: any) => void;
  browserAutomationAction?: { type: string; selector?: string; message?: string } | null;
}

export const LivePreview: React.FC<LivePreviewProps> = ({
  files: propFiles,
  artifact: propArtifact,
  operationId,
  isVerifying,
  onConsoleLog,
  onRuntimeError,
  onAutoFixError,
  onSelectFile,
  onSelectWorkspaceView,
  browserAutomationAction
}) => {
  const [device, setDevice] = useState<ViewportDevice>('desktop');
  const [refreshKey, setRefreshKey] = useState(0);
  const [buildError, setBuildError] = useState<PreviewBuildError | null>(null);
  const [runtimeError, setRuntimeError] = useState<string | null>(null);
  const [previewState, setPreviewState] = useState<PreviewState>('STARTING');
  const [elementsCount, setElementsCount] = useState<number>(0);
  const [testReport, setTestReport] = useState<ResponsiveTestReport | null>(null);
  const [isRunningTests, setIsRunningTests] = useState(false);
  const [showTestsModal, setShowTestsModal] = useState(false);
  const [activeOperation, setActiveOperation] = useState<OperationState | null>(() => {
    const opMgr = OperationManager.getInstance();
    return operationId ? opMgr.getOperation(operationId) || opMgr.getActiveOperation() : opMgr.getActiveOperation();
  });
  const [isInspectMode, setIsInspectMode] = useState<boolean>(() => {
    return VisualBridge.getInstance().isInspectMode();
  });
  const iframeRef = useRef<HTMLIFrameElement>(null);

  // Subscribe to VisualBridge inspector state
  useEffect(() => {
    const unsub = VisualBridge.getInstance().subscribe((_, inspectActive) => {
      setIsInspectMode(inspectActive);
      if (iframeRef.current && iframeRef.current.contentWindow) {
        iframeRef.current.contentWindow.postMessage({
          type: 'SET_INSPECT_MODE',
          payload: { active: inspectActive }
        }, '*');
      }
    });
    return () => unsub();
  }, []);

  // Subscribe to OperationManager for live artifact updates
  useEffect(() => {
    const opMgr = OperationManager.getInstance();
    const unsub = opMgr.subscribe((op) => {
      if (operationId) {
        if (op.operationId === operationId) {
          setActiveOperation(op);
        }
      } else {
        setActiveOperation(op);
      }
    });
    return () => unsub();
  }, [operationId]);

  // Subscribe to real PreviewService
  useEffect(() => {
    const unsub = PreviewService.subscribe((state, report) => {
      setPreviewState(state);
      setElementsCount(report.elementsCount);
      if (report.buildError) {
        setBuildError(report.buildError);
      }
      if (report.runtimeErrors && report.runtimeErrors.length > 0) {
        setRuntimeError(report.runtimeErrors[0]);
      }
    });
    return () => unsub();
  }, []);

  // Resolve authoritative active artifact from props or OperationManager
  const resolvedArtifact = propArtifact || activeOperation?.artifact || (activeOperation as any)?.generatedArtifact || null;

  // Resolve effective workspace files
  const effectiveFiles = React.useMemo(() => {
    if (resolvedArtifact && resolvedArtifact.files && Object.keys(resolvedArtifact.files).length > 0) {
      return resolvedArtifact.files;
    }
    if (resolvedArtifact && resolvedArtifact.reactCode) {
      return {
        ...(propFiles || {}),
        'src/App.tsx': resolvedArtifact.reactCode
      };
    }
    return propFiles || {};
  }, [resolvedArtifact, propFiles]);

  const hasValidApplication = React.useMemo(() => {
    if (resolvedArtifact) return true;
    if (effectiveFiles['src/App.tsx'] || effectiveFiles['src/App.jsx'] || effectiveFiles['App.tsx']) {
      return true;
    }
    return Object.keys(effectiveFiles).some(k => k.endsWith('.tsx') || k.endsWith('.jsx'));
  }, [resolvedArtifact, effectiveFiles]);

  // When files change, invalidate stale state and trigger fresh build
  useEffect(() => {
    setBuildError(null);
    setRuntimeError(null);
    PreviewService.recordBuilding();
  }, [effectiveFiles, refreshKey]);

  // Generate sandbox HTML from real workspace files or artifact
  const sandboxHtml = React.useMemo(() => {
    if (!hasValidApplication) {
      return '';
    }
    if (resolvedArtifact && resolvedArtifact.html && resolvedArtifact.html.includes('<html')) {
      return resolvedArtifact.html;
    }
    try {
      return SandboxRunner.generateSandboxHtml(effectiveFiles);
    } catch (err: any) {
      const errObj: PreviewBuildError = {
        message: err.message || 'Bundle generation failed',
        file: 'src/App.tsx',
        line: 1,
        column: 1,
        rawError: String(err)
      };
      setBuildError(errObj);
      PreviewService.recordBuildFailed(errObj);
      return '';
    }
  }, [effectiveFiles, resolvedArtifact, hasValidApplication, refreshKey]);

  // Handle postMessage events from iframe sandbox
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (!event.data) return;

      if (event.data.type === 'SANDBOX_LOG') {
        onConsoleLog?.(event.data.payload.level, event.data.payload.message);
      } else if (event.data.type === 'SANDBOX_BUILD_ERROR') {
        const payload: PreviewBuildError = event.data.payload || { message: 'Compilation Failed' };
        setBuildError(payload);
        PreviewService.recordBuildFailed(payload);
      } else if (event.data.type === 'SANDBOX_ERROR') {
        const errMsg = event.data.payload?.message || 'Runtime Sandbox Error';
        if (errMsg === 'Script error.' || errMsg.includes('Script error')) {
          return;
        }
        setRuntimeError(errMsg);
        PreviewService.recordError(errMsg);
        onRuntimeError?.(event.data.payload);

        // Feed directly to Self-Healing Runtime Interceptor 2.0
        try {
          RuntimeInterceptor.getInstance().captureException({
            message: errMsg,
            stack: event.data.payload?.stack,
            componentStack: event.data.payload?.componentStack,
            domSnapshotSnippet: event.data.payload?.domSnippet,
            workspaceFiles: effectiveFiles
          });
        } catch (e) {
          console.error('Failed to capture runtime exception in interceptor:', e);
        }
      } else if (event.data.type === 'VISUAL_ELEMENT_INSPECTED') {
        try {
          VisualBridge.getInstance().handlePreviewInspectionEvent(
            event.data.payload,
            effectiveFiles
          );
        } catch (e) {
          console.error('Failed to process preview element inspection:', e);
        }
      } else if (event.data.type === 'SANDBOX_READY') {
        setBuildError(null);
        setRuntimeError(null);
        const count = event.data.payload?.elementsCount || 1;
        setElementsCount(count);
        PreviewService.recordReady(count);
      } else if (event.data.type === 'SANDBOX_HEALTH_PONG') {
        const { running, mounted, elementsCount: count } = event.data.payload || {};
        if (running && mounted) {
          setBuildError(null);
          PreviewService.recordReady(count || 1);
        }
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [onConsoleLog, onRuntimeError]);

  const handleManualRefresh = () => {
    setBuildError(null);
    setRuntimeError(null);
    PreviewService.recordStale();
    setTimeout(() => {
      setRefreshKey(k => k + 1);
      PreviewService.recordBuilding();
    }, 50);
  };

  const handleRunResponsiveTests = async () => {
    setIsRunningTests(true);
    setShowTestsModal(true);
    const report = await PreviewTester.runSuite(effectiveFiles);
    setTestReport(report);
    setIsRunningTests(false);
  };

  // Viewport Container Bounds (no CSS scale, true pixels)
  const getDeviceDimensions = () => {
    switch (device) {
      case 'mobile':
        return { width: '390px', height: '844px', label: '390 × 844 (Mobile)' };
      case 'tablet':
        return { width: '768px', height: '1024px', label: '768 × 1024 (Tablet)' };
      case 'laptop':
        return { width: '1280px', height: '800px', label: '1280 × 800 (Laptop)' };
      case 'desktop-lg':
        return { width: '1440px', height: '900px', label: '1440 × 900 (Large Desktop)' };
      case 'desktop':
      default:
        return { width: '100%', height: '100%', label: '100% FLUID (Responsive)' };
    }
  };

  const currentDimensions = getDeviceDimensions();

  return (
    <div className="flex-1 h-full w-full flex flex-col bg-[#08090D] overflow-hidden select-none relative">
      {/* Top Viewport Navigation Toolbar */}
      <div className="h-10 border-b border-[#1C2436] bg-[#0C0F17] px-3 flex items-center justify-between shrink-0 z-20">
        <div className="flex items-center gap-2 text-xs font-mono">
          {/* Truthful State Badge */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#121724] border border-[#1F293D] text-[11px]">
            {previewState === 'RUNNING' || previewState === 'PREVIEW_RUNNING' ? (
              <>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-sm shadow-emerald-500/50" />
                <span className="text-emerald-300 font-bold tracking-wide">PREVIEW: RUNNING</span>
                {elementsCount > 0 && <span className="text-neutral-500 text-[10px]">({elementsCount} DOM nodes)</span>}
              </>
            ) : previewState === 'BUILDING' || previewState === 'PREVIEW_STARTING' || previewState === 'STARTING' ? (
              <>
                <Loader2 className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
                <span className="text-cyan-300 font-semibold">PREVIEW: {previewState}</span>
              </>
            ) : previewState === 'BUILD_FAILED' || buildError ? (
              <>
                <XCircle className="w-3.5 h-3.5 text-rose-500" />
                <span className="text-rose-400 font-bold">PREVIEW: BUILD_FAILED</span>
              </>
            ) : previewState === 'RUNTIME_ERROR' || runtimeError ? (
              <>
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-amber-300 font-bold">PREVIEW: RUNTIME_ERROR</span>
              </>
            ) : previewState === 'STALE' ? (
              <>
                <span className="w-2 h-2 rounded-full bg-amber-500" />
                <span className="text-amber-400 font-semibold">PREVIEW: STALE</span>
              </>
            ) : (
              <>
                <span className="w-2 h-2 rounded-full bg-neutral-500" />
                <span className="text-neutral-400 font-semibold">PREVIEW: IDLE</span>
              </>
            )}
          </div>

          <div className="h-4 w-px bg-[#1C2538] mx-1" />

          {/* Viewport Switcher Controls */}
          <div className="flex items-center bg-[#080B12] rounded-lg p-0.5 border border-[#1D263B]">
            <button
              onClick={() => setDevice('desktop')}
              className={`px-2.5 py-1 rounded-md transition-all flex items-center gap-1.5 text-xs font-mono font-medium ${
                device === 'desktop'
                  ? 'bg-[#162033] text-cyan-300 border border-cyan-500/40 shadow-xs'
                  : 'text-neutral-400 hover:text-neutral-200 border border-transparent'
              }`}
              title="Desktop Viewport (Fluid Responsive)"
            >
              <Monitor className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">FLUID</span>
            </button>
            <button
              onClick={() => setDevice('laptop')}
              className={`px-2.5 py-1 rounded-md transition-all flex items-center gap-1.5 text-xs font-mono font-medium ${
                device === 'laptop'
                  ? 'bg-[#162033] text-cyan-300 border border-cyan-500/40 shadow-xs'
                  : 'text-neutral-400 hover:text-neutral-200 border border-transparent'
              }`}
              title="Laptop Viewport (1280 × 800)"
            >
              <Monitor className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">1280px</span>
            </button>
            <button
              onClick={() => setDevice('tablet')}
              className={`px-2.5 py-1 rounded-md transition-all flex items-center gap-1.5 text-xs font-mono font-medium ${
                device === 'tablet'
                  ? 'bg-[#162033] text-cyan-300 border border-cyan-500/40 shadow-xs'
                  : 'text-neutral-400 hover:text-neutral-200 border border-transparent'
              }`}
              title="Tablet Viewport (768 × 1024)"
            >
              <Tablet className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">768px</span>
            </button>
            <button
              onClick={() => setDevice('mobile')}
              className={`px-2.5 py-1 rounded-md transition-all flex items-center gap-1.5 text-xs font-mono font-medium ${
                device === 'mobile'
                  ? 'bg-[#162033] text-cyan-300 border border-cyan-500/40 shadow-xs'
                  : 'text-neutral-400 hover:text-neutral-200 border border-transparent'
              }`}
              title="Mobile Viewport (390 × 844)"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">390px</span>
            </button>
          </div>

          {/* Current Dimension Pill */}
          <span className="text-[10px] text-neutral-400 font-mono hidden md:inline px-2 py-0.5 rounded bg-[#101420] border border-[#1B2336]">
            [{currentDimensions.label}]
          </span>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 font-mono">
          {/* Visual Element Inspector Toggle */}
          <button
            onClick={() => VisualBridge.getInstance().setInspectMode(!isInspectMode)}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border text-xs transition-colors shadow-xs ${
              isInspectMode
                ? 'bg-indigo-600 border-indigo-500 text-white shadow-indigo-500/20'
                : 'bg-[#111726] hover:bg-[#182238] border-indigo-500/30 text-indigo-300'
            }`}
            title="Toggle Visual-to-AST DOM Element Inspector"
          >
            <Crosshair className="w-3.5 h-3.5" />
            <span className="hidden md:inline font-bold">{isInspectMode ? 'INSPECTING' : 'INSPECT'}</span>
          </button>

          {/* Responsive Diagnostic Suite Trigger */}
          <button
            onClick={handleRunResponsiveTests}
            disabled={isRunningTests}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#111726] hover:bg-[#182238] border border-cyan-500/30 text-cyan-300 text-xs transition-colors shadow-xs"
            title="Run 12-Point Viewport & Responsive Diagnostics Suite"
          >
            <ShieldCheck className={`w-3.5 h-3.5 text-cyan-400 ${isRunningTests ? 'animate-spin' : ''}`} />
            <span className="hidden md:inline font-bold">SUITE</span>
          </button>

          {/* Refresh / Invalidate Preview Cache */}
          <button
            onClick={handleManualRefresh}
            className="flex items-center gap-1 p-1.5 px-2 rounded-lg bg-[#111726] hover:bg-[#182238] border border-[#1F2A3F] text-neutral-300 hover:text-cyan-300 transition-colors text-xs"
            title="Invalidate Stale Cache & Re-Mount Application"
          >
            <RotateCw className="w-3.5 h-3.5" />
            <span className="hidden lg:inline">Reload</span>
          </button>
        </div>
      </div>

      {/* Runtime Error Banner */}
      {runtimeError && !buildError && (
        <div className="p-2.5 bg-amber-950/90 border-b border-amber-800/80 px-4 flex items-center justify-between text-xs text-amber-200 z-20 shrink-0 font-mono">
          <div className="flex items-center gap-2 truncate">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="font-semibold text-amber-300">[PREVIEW RUNTIME EXCEPTION]</span>
            <span className="truncate text-[11px]">{runtimeError}</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => onAutoFixError?.(runtimeError)}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-amber-600 hover:bg-amber-500 text-neutral-950 font-bold transition-colors shadow text-[10px]"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>AUTO_FIX</span>
            </button>
            <button
              onClick={() => setRuntimeError(null)}
              className="p-1 text-neutral-400 hover:text-white"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Main Sandbox Frame Canvas */}
      <div className="flex-1 overflow-auto bg-[#05070A] p-2 sm:p-4 flex items-center justify-center relative min-h-0">
        {/* Browser Automation Action Bubble */}
        {browserAutomationAction && (
          <div className="absolute top-4 left-4 z-40 bg-[#101524] border border-cyan-500/60 rounded-lg px-3 py-1.5 shadow-xl text-xs font-mono text-cyan-300 flex items-center gap-2 backdrop-blur-md animate-bounce">
            <ShieldCheck className="w-4 h-4 text-cyan-400 animate-spin" />
            <span>AGENT_ACT: {browserAutomationAction.message || browserAutomationAction.type}</span>
          </div>
        )}

        {/* NO APPLICATION STATE */}
        {!hasValidApplication ? (
          <div className="flex flex-col items-center justify-center p-8 text-center text-neutral-400 font-sans space-y-4 max-w-md z-30">
            <div className="w-14 h-14 rounded-2xl bg-[#0F1420] border border-[#1E293B] flex items-center justify-center text-cyan-400 shadow-xl shadow-cyan-950/20">
              <Eye className="w-7 h-7" />
            </div>
            <div className="space-y-1.5">
              <h3 className="text-base font-bold text-white tracking-wide">No Application Generated</h3>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Describe an application in the AI Chat to plan, build, and preview it in the live sandbox.
              </p>
            </div>
          </div>
        ) : buildError ? (
          <div className="w-full max-w-2xl bg-[#0F131D] border border-rose-900/80 rounded-2xl p-6 shadow-2xl space-y-4 font-mono text-xs z-30">
            <div className="flex items-center justify-between border-b border-rose-900/60 pb-3">
              <div className="flex items-center gap-2 text-rose-400">
                <XCircle className="w-5 h-5 text-rose-500" />
                <h3 className="font-bold text-sm text-rose-300">PREVIEW BUILD FAILED</h3>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded bg-rose-950 text-rose-400 border border-rose-800">
                SYNTAX / COMPILATION ERROR
              </span>
            </div>

            <div className="space-y-2 bg-[#090C14] p-3 rounded-xl border border-neutral-800">
              <div className="text-neutral-400">
                <strong className="text-neutral-200">File:</strong> <span className="text-cyan-300">{buildError.file || 'src/App.tsx'}</span>
              </div>
              <div className="text-neutral-400">
                <strong className="text-neutral-200">Position:</strong> Line {buildError.line || 1}, Column {buildError.column || 1}
              </div>
              <div className="text-rose-300 font-semibold pt-1 border-t border-neutral-800/80">
                {buildError.message}
              </div>
            </div>

            {buildError.codeSnippet && (
              <div className="space-y-1">
                <span className="text-[10px] text-neutral-500 uppercase">Code Context:</span>
                <pre className="p-3 bg-[#06080E] border border-neutral-800/80 rounded-lg text-[11px] text-rose-200 overflow-x-auto whitespace-pre-wrap">
                  {buildError.codeSnippet}
                </pre>
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-2 border-t border-neutral-800">
              <button
                onClick={() => {
                  if (onSelectFile && buildError.file) {
                    onSelectFile(buildError.file);
                  }
                  if (onSelectWorkspaceView) {
                    onSelectWorkspaceView('editor');
                  }
                }}
                className="px-4 py-2 rounded-lg bg-[#151D2C] hover:bg-[#1E293D] text-cyan-300 font-semibold text-xs flex items-center gap-1.5 border border-cyan-500/40 transition-colors"
              >
                <Code2 className="w-3.5 h-3.5" />
                <span>OPEN IN EDITOR</span>
              </button>
              <button
                onClick={handleManualRefresh}
                className="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-bold text-xs flex items-center gap-1.5 transition-colors shadow-md shadow-cyan-500/20"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>RETRY COMPILATION</span>
              </button>
            </div>
          </div>
        ) : (
          /* REAL BOUNDED VIEWPORT CONTAINER */
          <div
            className={`transition-all duration-200 bg-[#090B10] relative flex flex-col items-center justify-center shrink-0 ${
              device === 'desktop'
                ? 'w-full h-full border-0 rounded-none'
                : device === 'laptop'
                ? 'w-[1280px] h-[800px] max-w-full max-h-full rounded-xl border-[4px] border-[#1C2538] shadow-2xl ring-1 ring-cyan-500/20 overflow-hidden my-auto'
                : device === 'tablet'
                ? 'w-[768px] h-[1024px] max-w-full max-h-full rounded-2xl border-[6px] border-[#1C2538] shadow-2xl ring-1 ring-cyan-500/20 overflow-hidden my-auto'
                : 'w-[390px] h-[844px] max-w-full max-h-full rounded-[40px] border-[8px] border-[#1C2538] shadow-2xl ring-1 ring-cyan-500/20 overflow-hidden my-auto'
            }`}
            style={{
              width: device === 'desktop' ? '100%' : currentDimensions.width,
              height: device === 'desktop' ? '100%' : currentDimensions.height
            }}
          >
            {/* Mobile Dynamic Island / Camera Pill Bezel */}
            {device === 'mobile' && (
              <div className="absolute top-2 w-24 h-4 bg-black rounded-full z-40 flex items-center justify-center pointer-events-none shadow-md">
                <div className="w-2 h-2 rounded-full bg-[#111] mr-3" />
                <div className="w-2.5 h-2.5 rounded-full bg-[#0a0a0a] ring-1 ring-neutral-800" />
              </div>
            )}

            {/* Tablet Camera Bezel */}
            {device === 'tablet' && (
              <div className="absolute top-1.5 w-2 h-2 rounded-full bg-black z-40 pointer-events-none ring-1 ring-neutral-800" />
            )}

            <iframe
              ref={iframeRef}
              srcDoc={sandboxHtml}
              title="GODEX Preview Sandbox"
              sandbox="allow-scripts allow-same-origin allow-forms allow-modals"
              className="w-full h-full border-none bg-[#090B10] block"
            />

            {/* Mobile Bottom Home Bar */}
            {device === 'mobile' && (
              <div className="absolute bottom-1 w-32 h-1 bg-neutral-600 rounded-full z-40 pointer-events-none opacity-60" />
            )}
          </div>
        )}
      </div>

      {/* 12-Point Viewport & Responsive Diagnostics Suite Modal */}
      {showTestsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-xl bg-[#0E131E] border border-neutral-800 rounded-2xl p-6 shadow-2xl space-y-4 font-mono text-xs animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-cyan-400" />
                <div>
                  <h3 className="font-bold text-sm text-white">12-Point Responsive Preview Diagnostics</h3>
                  <p className="text-[11px] text-neutral-400">Deterministic verification of viewport reflow, containment & invalidation</p>
                </div>
              </div>
              <button
                onClick={() => setShowTestsModal(false)}
                className="p-1 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800"
              >
                ✕
              </button>
            </div>

            {testReport && (
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#131926] border border-neutral-800">
                <span className="text-neutral-300 font-semibold">OVERALL SCORE:</span>
                <div className="flex items-center gap-2">
                  <span className={`text-sm font-bold ${testReport.passed ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {testReport.score}% PASSED
                  </span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    testReport.passed ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-rose-950 text-rose-300 border border-rose-800'
                  }`}>
                    {testReport.passed ? '5/5 VERIFIED' : 'ACTION REQUIRED'}
                  </span>
                </div>
              </div>
            )}

            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              {(testReport?.checks || []).map((c) => (
                <div key={c.id} className="p-2.5 rounded-lg bg-[#090C14] border border-neutral-800/80 flex items-start justify-between gap-3">
                  <div>
                    <div className="font-bold text-neutral-200 flex items-center gap-2">
                      <span>{c.title}</span>
                    </div>
                    <div className="text-[11px] text-neutral-400">{c.description}</div>
                    {c.details && <div className="text-[10px] text-cyan-400 mt-1">{c.details}</div>}
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold shrink-0 ${
                    c.status === 'passed' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                    c.status === 'failed' ? 'bg-rose-950 text-rose-400 border border-rose-800' :
                    'bg-cyan-950 text-cyan-400 border border-cyan-800 animate-pulse'
                  }`}>
                    {c.status}
                  </span>
                </div>
              ))}
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-neutral-800">
              <button
                onClick={handleRunResponsiveTests}
                disabled={isRunningTests}
                className="px-4 py-2 rounded-lg bg-[#151D2C] hover:bg-[#1E293D] text-cyan-300 font-semibold text-xs flex items-center gap-1.5 border border-cyan-500/40"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRunningTests ? 'animate-spin' : ''}`} />
                <span>Rerun Suite</span>
              </button>
              <button
                onClick={() => setShowTestsModal(false)}
                className="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-bold text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
