import React, { useMemo, useState } from 'react';
import { Download, Printer } from 'lucide-react';
import { useApp } from '../context/AppContext';
import {
  calculateCommitteeSummaries,
  calculateLeaveBalances,
  calculateLoanSummaries,
  evaluateFormula,
  formatCurrency,
  formatDate,
  formatNumber,
  round2,
  summarizePurchases,
} from '../utils/calculations';
import { exportToCsv } from '../utils/storage';

type ReportTab =
  | 'purchases'
  | 'expenses'
  | 'leave'
  | 'tasks'
  | 'loan'
  | 'committee'
  | 'overall'
  | `custom:${string}`;

export const ReportsModule: React.FC = () => {
  const { state, tr, themeTokens } = useApp();
  const [report, setReport] = useState<ReportTab>('purchases');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const cur = state.settings.currencyLabel || 'PKR';
  const dateFmt = state.settings.dateFormat;

  const inRange = (d: string) => {
    if (fromDate && d < fromDate) return false;
    if (toDate && d > toDate) return false;
    return true;
  };

  // Filtered datasets
  const purchases = useMemo(
    () =>
      state.purchases.filter(
        (p) => inRange(p.date) && (!statusFilter || p.paymentStatus === statusFilter)
      ),
    [state.purchases, fromDate, toDate, statusFilter]
  );
  const purchaseSum = useMemo(
    () => summarizePurchases(purchases, state.settings.maundToKg),
    [purchases, state.settings.maundToKg]
  );

  const expenses = useMemo(
    () =>
      state.expenses.filter(
        (e) => inRange(e.date) && (!categoryFilter || e.category === categoryFilter)
      ),
    [state.expenses, fromDate, toDate, categoryFilter]
  );
  const expenseSum = useMemo(
    () => round2(expenses.reduce((s, e) => s + e.amount, 0)),
    [expenses]
  );

  const leaves = useMemo(
    () =>
      state.leaves.filter(
        (l) => l.leaveYear === state.settings.activeLeaveYear && inRange(l.date)
      ),
    [state.leaves, state.settings.activeLeaveYear, fromDate, toDate]
  );
  const leaveOpening = state.leaveYearOpenings.find(
    (o) => o.leaveYear === state.settings.activeLeaveYear
  );
  const leaveBal = useMemo(
    () =>
      calculateLeaveBalances(
        state.leaves,
        state.settings.activeLeaveYear,
        leaveOpening,
        state.settings.defaultCL,
        state.settings.defaultSL,
        state.settings.cplExpiryDays
      ),
    [state.leaves, state.settings, leaveOpening]
  );

  const tasks = useMemo(
    () =>
      state.tasks.filter(
        (t) =>
          (!fromDate || (t.dueDate || t.createdDate) >= fromDate) &&
          (!toDate || (t.dueDate || t.createdDate) <= toDate) &&
          (!statusFilter || t.status === statusFilter)
      ),
    [state.tasks, fromDate, toDate, statusFilter]
  );

  const loanTxs = useMemo(
    () => state.loanTransactions.filter((t) => inRange(t.transactionDate)),
    [state.loanTransactions, fromDate, toDate]
  );
  const loanSum = useMemo(
    () => calculateLoanSummaries(state.loanPersons, loanTxs),
    [state.loanPersons, loanTxs]
  );

  const committeeTxs = useMemo(
    () => state.committeeTransactions.filter((t) => inRange(t.date)),
    [state.committeeTransactions, fromDate, toDate]
  );
  const committeeSum = useMemo(
    () => calculateCommitteeSummaries(state.committees, committeeTxs),
    [state.committees, committeeTxs]
  );

  const overallRows = useMemo(() => {
    const all: { date: string; module: string; description: string; detail: string }[] = [];
    purchases.forEach((p) =>
      all.push({
        date: p.date,
        module: 'Home / Purchase',
        description: `${p.supplier || 'Atta'} (${p.quantityMaund} Maund)`,
        detail: formatCurrency(p.totalAmount, cur),
      })
    );
    expenses.forEach((e) =>
      all.push({
        date: e.date,
        module: 'Home / Expense',
        description: `${e.category} — ${e.description}`,
        detail: formatCurrency(e.amount, cur),
      })
    );
    leaves.forEach((l) =>
      all.push({
        date: l.date,
        module: 'Factory / Leave',
        description: `${l.type} (${l.reason || l.employee})`,
        detail: formatNumber(l.days),
      })
    );
    loanTxs.forEach((t) =>
      all.push({
        date: t.transactionDate,
        module: 'Personal / Loan',
        description: `${t.personName} (${t.type})`,
        detail: formatCurrency(t.amount, cur),
      })
    );
    committeeTxs.forEach((t) =>
      all.push({
        date: t.date,
        module: 'Personal / Committee',
        description: `${t.committeeTitle} (${t.type})`,
        detail: formatCurrency(t.amount, cur),
      })
    );
    return all.sort((a, b) => b.date.localeCompare(a.date));
  }, [purchases, expenses, leaves, loanTxs, committeeTxs, cur]);

  const handleExportCsv = () => {
    if (report === 'purchases') {
      exportToCsv(
        'home-purchases-report.csv',
        ['Date', 'Supplier', 'Maund', 'KG', 'Rate', 'Unit', 'Total Amount', 'Status', 'Remarks'],
        purchases.map((p) => [
          p.date,
          p.supplier,
          p.quantityMaund,
          p.equivalentKg,
          p.rate,
          p.rateUnit,
          p.totalAmount,
          p.paymentStatus,
          p.remarks,
        ])
      );
    } else if (report === 'expenses') {
      exportToCsv(
        'household-expenses-report.csv',
        ['Date', 'Category', 'Description', 'Method', 'Paid To', 'Amount', 'Remarks'],
        expenses.map((e) => [
          e.date,
          e.category,
          e.description,
          e.paymentMethod,
          e.paidTo,
          e.amount,
          e.remarks,
        ])
      );
    } else if (report === 'leave') {
      exportToCsv(
        `leave-report-${state.settings.activeLeaveYear}.csv`,
        ['Date', 'Leave Year', 'Employee', 'Type', 'Count', 'Expiry Date', 'Status', 'Reason'],
        leaves.map((l) => [
          l.date,
          l.leaveYear,
          l.employee,
          l.type,
          l.days,
          l.expiryDate || '',
          l.status,
          l.reason,
        ])
      );
    } else if (report === 'tasks') {
      exportToCsv(
        'office-tasks-report.csv',
        ['Title', 'Assigned', 'Created', 'Due Date', 'Priority', 'Status', 'Description'],
        tasks.map((t) => [
          t.title,
          t.assignedPerson,
          t.createdDate,
          t.dueDate,
          t.priority,
          t.status,
          t.description,
        ])
      );
    } else if (report === 'loan') {
      exportToCsv(
        'loan-ledger-report.csv',
        ['Date', 'Person', 'Type', 'Amount', 'Method', 'Description'],
        loanTxs.map((t) => [
          t.transactionDate,
          t.personName,
          t.type,
          t.amount,
          t.paymentMethod,
          t.description,
        ])
      );
    } else if (report === 'committee') {
      exportToCsv(
        'committee-ledger-report.csv',
        ['Date', 'Committee', 'Type', 'Amount', 'Method', 'Remarks'],
        committeeTxs.map((t) => [
          t.date,
          t.committeeTitle,
          t.type,
          t.amount,
          t.paymentMethod,
          t.remarks,
        ])
      );
    } else if (report === 'overall') {
      exportToCsv(
        'overall-activity-report.csv',
        ['Date', 'Module', 'Description', 'Detail'],
        overallRows.map((r) => [r.date, r.module, r.description, r.detail])
      );
    } else if (report.startsWith('custom:')) {
      const modId = report.slice(7);
      const mod = state.customModules.find((m) => m.id === modId);
      if (!mod) return;
      const fields = mod.fields.filter((f) => f.showInReport && !f.archived);
      const recs = state.customRecords.filter((r) => r.moduleId === modId);
      exportToCsv(
        `${mod.name.toLowerCase().replace(/\s+/g, '-')}-report.csv`,
        fields.map((f) => f.label),
        recs.map((r) =>
          fields.map((f) =>
            f.type === 'formula'
              ? evaluateFormula(f.formula, r.values)
              : String(r.values[f.key] ?? '')
          )
        )
      );
    }
  };

  const reportTabs: { id: ReportTab; label: string }[] = [
    { id: 'purchases', label: 'Home Purchases' },
    { id: 'expenses', label: 'Household Expenses' },
    { id: 'leave', label: 'Factory Leave' },
    { id: 'tasks', label: 'Office Tasks' },
    { id: 'loan', label: 'Loan Ledger' },
    { id: 'committee', label: 'Committee Ledger' },
    { id: 'overall', label: 'Overall Activity' },
    ...state.customModules
      .filter((m) => !m.archived)
      .map((m) => ({ id: `custom:${m.id}` as ReportTab, label: m.name })),
  ];

  return (
    <div className="space-y-6">
      {/* Report Selector & Export Controls */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-4 no-print">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap gap-1.5">
            {reportTabs.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setReport(item.id);
                  setCategoryFilter('');
                  setStatusFilter('');
                }}
                className={`rounded-lg px-3 py-1.5 text-xs font-medium whitespace-nowrap transition-colors ${
                  report === item.id
                    ? `${themeTokens.accentBg} text-white`
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={handleExportCsv}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
            >
              <Download className="h-3.5 w-3.5" />
              <span>{tr('export_csv')}</span>
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
            >
              <Printer className="h-3.5 w-3.5" />
              <span>{tr('print')}</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          <div>
            <label htmlFor="rep-from" className="block text-xs text-slate-500 mb-1">
              {tr('from_date')}
            </label>
            <input
              id="rep-from"
              type="date"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-xs"
            />
          </div>
          <div>
            <label htmlFor="rep-to" className="block text-xs text-slate-500 mb-1">
              {tr('to_date')}
            </label>
            <input
              id="rep-to"
              type="date"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-xs"
            />
          </div>
          {report === 'expenses' && (
            <div>
              <label htmlFor="rep-cat" className="block text-xs text-slate-500 mb-1">
                {tr('category')}
              </label>
              <select
                id="rep-cat"
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-xs bg-white"
              >
                <option value="">All Categories</option>
                {state.expenseCategories.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
          )}
          {(report === 'purchases' || report === 'tasks') && (
            <div>
              <label htmlFor="rep-status" className="block text-xs text-slate-500 mb-1">
                {tr('status')}
              </label>
              <select
                id="rep-status"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-1.5 text-xs bg-white"
              >
                <option value="">All Statuses</option>
                {report === 'purchases' ? (
                  <>
                    <option value="Paid">Paid</option>
                    <option value="Pending">Pending</option>
                    <option value="Partial">Partial</option>
                  </>
                ) : (
                  <>
                    <option value="Pending">Pending</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Completed">Completed</option>
                    <option value="Cancelled">Cancelled</option>
                  </>
                )}
              </select>
            </div>
          )}
        </div>
      </div>

      {/* Report Content */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-5">
        <div className="border-b border-slate-200 pb-3 flex items-baseline justify-between gap-4">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              {state.settings.appName} — {reportTabs.find((r) => r.id === report)?.label} Report
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {fromDate || toDate
                ? `Period: ${fromDate || 'Start'} to ${toDate || 'Present'}`
                : 'All Saved Records'}
            </p>
          </div>
          <span className="text-xs text-slate-500 tabular-nums">
            Currency: {cur}
          </span>
        </div>

        {/* PURCHASES REPORT */}
        {report === 'purchases' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="text-xs text-slate-500">Total Maund</div>
                <div className="font-bold tabular-nums">{formatNumber(purchaseSum.totalMaund)}</div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="text-xs text-slate-500">Equivalent KG</div>
                <div className="font-bold tabular-nums">{formatNumber(purchaseSum.totalKg)}</div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="text-xs text-slate-500">Total Amount</div>
                <div className="font-bold tabular-nums text-emerald-700">
                  {formatCurrency(purchaseSum.totalAmount, cur)}
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="text-xs text-slate-500">Avg Rate / Maund</div>
                <div className="font-bold tabular-nums">
                  {formatCurrency(purchaseSum.avgRatePerMaund, cur)}
                </div>
              </div>
            </div>
            {purchases.length === 0 ? (
              <div className="py-8 text-center text-sm text-slate-500">{tr('no_records')}</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                    <tr>
                      <th className="px-3 py-2 text-start">Date</th>
                      <th className="px-3 py-2 text-start">Supplier</th>
                      <th className="px-3 py-2 text-end">Maund</th>
                      <th className="px-3 py-2 text-end">KG</th>
                      <th className="px-3 py-2 text-end">Rate</th>
                      <th className="px-3 py-2 text-end">Total</th>
                      <th className="px-3 py-2 text-start">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {purchases.map((p) => (
                      <tr key={p.id}>
                        <td className="px-3 py-2 tabular-nums">{formatDate(p.date, dateFmt)}</td>
                        <td className="px-3 py-2">{p.supplier || '—'}</td>
                        <td className="px-3 py-2 text-end tabular-nums">{formatNumber(p.quantityMaund)}</td>
                        <td className="px-3 py-2 text-end tabular-nums">{formatNumber(p.equivalentKg)}</td>
                        <td className="px-3 py-2 text-end tabular-nums">{formatNumber(p.rate)}</td>
                        <td className="px-3 py-2 text-end tabular-nums font-semibold">
                          {formatCurrency(p.totalAmount, cur)}
                        </td>
                        <td className="px-3 py-2 text-xs">{p.paymentStatus}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* EXPENSES REPORT */}
        {report === 'expenses' && (
          <div className="space-y-4">
            <div className="p-3 bg-slate-50 rounded-lg inline-block">
              <div className="text-xs text-slate-500">Total Household Expenses</div>
              <div className="text-lg font-bold tabular-nums text-slate-900">
                {formatCurrency(expenseSum, cur)} ({expenses.length} entries)
              </div>
            </div>
            {expenses.length === 0 ? (
              <div className="py-8 text-center text-sm text-slate-500">{tr('no_records')}</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                    <tr>
                      <th className="px-3 py-2 text-start">Date</th>
                      <th className="px-3 py-2 text-start">Category</th>
                      <th className="px-3 py-2 text-start">Description</th>
                      <th className="px-3 py-2 text-start">Method</th>
                      <th className="px-3 py-2 text-end">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {expenses.map((e) => (
                      <tr key={e.id}>
                        <td className="px-3 py-2 tabular-nums">{formatDate(e.date, dateFmt)}</td>
                        <td className="px-3 py-2 font-medium">{e.category}</td>
                        <td className="px-3 py-2">{e.description}</td>
                        <td className="px-3 py-2 text-slate-600">{e.paymentMethod}</td>
                        <td className="px-3 py-2 text-end tabular-nums font-semibold">
                          {formatCurrency(e.amount, cur)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* LEAVE REPORT */}
        {report === 'leave' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-sm">
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="text-xs text-slate-500">Casual Leave</div>
                <div className="font-bold tabular-nums">{formatNumber(leaveBal.clRemaining)}</div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="text-xs text-slate-500">Sick Leave</div>
                <div className="font-bold tabular-nums">{formatNumber(leaveBal.slRemaining)}</div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="text-xs text-slate-500">CPL Due</div>
                <div className="font-bold tabular-nums">{formatNumber(leaveBal.cplDueTotal)}</div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="text-xs text-slate-500">CPL Avail</div>
                <div className="font-bold tabular-nums text-emerald-700">
                  {formatNumber(leaveBal.cplAvail)}
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="text-xs text-slate-500">Total Balance</div>
                <div className="font-bold tabular-nums">{formatNumber(leaveBal.totalRemaining)}</div>
              </div>
            </div>
            {leaves.length === 0 ? (
              <div className="py-8 text-center text-sm text-slate-500">{tr('no_records')}</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                    <tr>
                      <th className="px-3 py-2 text-start">Date</th>
                      <th className="px-3 py-2 text-start">Type</th>
                      <th className="px-3 py-2 text-end">Count</th>
                      <th className="px-3 py-2 text-start">Employee</th>
                      <th className="px-3 py-2 text-start">Reason</th>
                      <th className="px-3 py-2 text-start">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {leaves.map((l) => (
                      <tr key={l.id}>
                        <td className="px-3 py-2 tabular-nums">{formatDate(l.date, dateFmt)}</td>
                        <td className="px-3 py-2 font-medium">{l.type}</td>
                        <td className="px-3 py-2 text-end tabular-nums">{formatNumber(l.days)}</td>
                        <td className="px-3 py-2">{l.employee}</td>
                        <td className="px-3 py-2 text-slate-600">{l.reason || '—'}</td>
                        <td className="px-3 py-2 text-xs">{l.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* OFFICE TASKS REPORT */}
        {report === 'tasks' && (
          <div className="space-y-4">
            {tasks.length === 0 ? (
              <div className="py-8 text-center text-sm text-slate-500">{tr('no_records')}</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                    <tr>
                      <th className="px-3 py-2 text-start">Title</th>
                      <th className="px-3 py-2 text-start">Assigned</th>
                      <th className="px-3 py-2 text-start">Due Date</th>
                      <th className="px-3 py-2 text-start">Priority</th>
                      <th className="px-3 py-2 text-start">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {tasks.map((t) => (
                      <tr key={t.id}>
                        <td className="px-3 py-2 font-medium">{t.title}</td>
                        <td className="px-3 py-2">{t.assignedPerson || '—'}</td>
                        <td className="px-3 py-2 tabular-nums">
                          {t.dueDate ? formatDate(t.dueDate, dateFmt) : '—'}
                        </td>
                        <td className="px-3 py-2">{t.priority}</td>
                        <td className="px-3 py-2">{t.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* LOAN REPORT */}
        {report === 'loan' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="text-xs text-slate-500">Opening</div>
                <div className="font-bold tabular-nums">{formatCurrency(loanSum.totalOpening, cur)}</div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="text-xs text-slate-500">Total Received</div>
                <div className="font-bold tabular-nums text-amber-700">
                  {formatCurrency(loanSum.totalReceived, cur)}
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="text-xs text-slate-500">Total Repaid</div>
                <div className="font-bold tabular-nums text-emerald-700">
                  {formatCurrency(loanSum.totalRepaid, cur)}
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="text-xs text-slate-500">Loan Payable</div>
                <div className="font-bold tabular-nums">
                  {formatCurrency(loanSum.totalLoanPayable, cur)}
                </div>
              </div>
            </div>
            {loanSum.perPerson.length === 0 ? (
              <div className="py-8 text-center text-sm text-slate-500">{tr('no_records')}</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                    <tr>
                      <th className="px-3 py-2 text-start">Person</th>
                      <th className="px-3 py-2 text-end">Opening</th>
                      <th className="px-3 py-2 text-end">Received</th>
                      <th className="px-3 py-2 text-end">Repaid</th>
                      <th className="px-3 py-2 text-end">Closing Payable</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {loanSum.perPerson.map((p) => (
                      <tr key={p.personId}>
                        <td className="px-3 py-2 font-medium">{p.personName}</td>
                        <td className="px-3 py-2 text-end tabular-nums">
                          {formatCurrency(p.openingBalance, cur)}
                        </td>
                        <td className="px-3 py-2 text-end tabular-nums">
                          {formatCurrency(p.totalReceived, cur)}
                        </td>
                        <td className="px-3 py-2 text-end tabular-nums">
                          {formatCurrency(p.totalRepaid, cur)}
                        </td>
                        <td className="px-3 py-2 text-end tabular-nums font-bold">
                          {formatCurrency(p.closingPayable, cur)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* COMMITTEE REPORT */}
        {report === 'committee' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="text-xs text-slate-500">Installments Paid</div>
                <div className="font-bold tabular-nums">
                  {formatCurrency(committeeSum.totalInstallmentsPaid, cur)}
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="text-xs text-slate-500">Payouts</div>
                <div className="font-bold tabular-nums">
                  {formatCurrency(committeeSum.totalPayouts, cur)}
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="text-xs text-slate-500">Remaining To Pay</div>
                <div className="font-bold tabular-nums text-amber-700">
                  {formatCurrency(committeeSum.totalRemainingToPay, cur)}
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg">
                <div className="text-xs text-slate-500">Due to Receive</div>
                <div className="font-bold tabular-nums text-emerald-700">
                  {formatCurrency(committeeSum.totalDueToReceive, cur)}
                </div>
              </div>
            </div>
            {committeeSum.perCommittee.length === 0 ? (
              <div className="py-8 text-center text-sm text-slate-500">{tr('no_records')}</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                    <tr>
                      <th className="px-3 py-2 text-start">Committee</th>
                      <th className="px-3 py-2 text-end">Total</th>
                      <th className="px-3 py-2 text-end">Paid</th>
                      <th className="px-3 py-2 text-end">Payouts</th>
                      <th className="px-3 py-2 text-end">Remaining</th>
                      <th className="px-3 py-2 text-start">Position</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {committeeSum.perCommittee.map((c) => (
                      <tr key={c.committeeId}>
                        <td className="px-3 py-2 font-medium">{c.title}</td>
                        <td className="px-3 py-2 text-end tabular-nums">
                          {formatCurrency(c.totalAmount, cur)}
                        </td>
                        <td className="px-3 py-2 text-end tabular-nums">
                          {formatCurrency(c.totalInstallmentsPaid, cur)}
                        </td>
                        <td className="px-3 py-2 text-end tabular-nums">
                          {formatCurrency(c.totalPayouts, cur)}
                        </td>
                        <td className="px-3 py-2 text-end tabular-nums font-bold">
                          {formatCurrency(c.remainingBalance, cur)}
                        </td>
                        <td className="px-3 py-2 text-xs font-semibold">{c.statusLabel}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* OVERALL ACTIVITY REPORT */}
        {report === 'overall' && (
          <div>
            {overallRows.length === 0 ? (
              <div className="py-8 text-center text-sm text-slate-500">{tr('no_records')}</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                    <tr>
                      <th className="px-3 py-2 text-start">Date</th>
                      <th className="px-3 py-2 text-start">Module</th>
                      <th className="px-3 py-2 text-start">Description</th>
                      <th className="px-3 py-2 text-end">Amount / Detail</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {overallRows.map((r, i) => (
                      <tr key={i}>
                        <td className="px-3 py-2 tabular-nums">{formatDate(r.date, dateFmt)}</td>
                        <td className="px-3 py-2 text-slate-600">{r.module}</td>
                        <td className="px-3 py-2">{r.description}</td>
                        <td className="px-3 py-2 text-end tabular-nums font-semibold">{r.detail}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* CUSTOM MODULE REPORT */}
        {report.startsWith('custom:') && (() => {
          const modId = report.slice(7);
          const mod = state.customModules.find((m) => m.id === modId);
          if (!mod) return null;
          const fields = mod.fields.filter((f) => f.showInReport && !f.archived);
          const recs = state.customRecords.filter((r) => r.moduleId === modId);
          return recs.length === 0 ? (
            <div className="py-8 text-center text-sm text-slate-500">{tr('no_records')}</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                  <tr>
                    {fields.map((f) => (
                      <th key={f.id} className="px-3 py-2 text-start">
                        {f.label}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {recs.map((rec) => (
                    <tr key={rec.id}>
                      {fields.map((f) => (
                        <td key={f.id} className="px-3 py-2 tabular-nums">
                          {f.type === 'formula'
                            ? formatNumber(evaluateFormula(f.formula, rec.values))
                            : String(rec.values[f.key] ?? '—')}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          );
        })()}
      </div>
    </div>
  );
};
