import React from "react";
import { ArrowRight, MapPin } from "lucide-react";
import { FloatingFoodFrame } from "./FloatingFoodFrame";
import { FloatingFrame } from "../types";

interface HeroProps {
  onExploreMenu: () => void;
  onVisit: () => void;
}

const HERO_FLOATING_FRAMES: FloatingFrame[] = [
  {
    id: "hero-frame-salad",
    title: "Field Greens",
    alt: "Crisp seasonal field greens and heirloom cherry tomatoes",
    imageUrl: "https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=600&q=80",
    rotation: -2.2,
    motionType: "drift",
    duration: 10,
    delay: 0,
  },
  {
    id: "hero-frame-coffee",
    title: "Araku Cortado",
    alt: "Single origin Araku coffee with silky steamed oat milk",
    imageUrl: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=600&q=80",
    rotation: 2.5,
    motionType: "rotate",
    duration: 12,
    delay: 0.8,
  },
  {
    id: "hero-frame-tartine",
    title: "Sourdough Tartine",
    alt: "Artisanal avocado sourdough tartine with seeds",
    imageUrl: "https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=600&q=80",
    rotation: 1.8,
    motionType: "diagonal",
    duration: 14,
    delay: 1.4,
  },
];

export const Hero: React.FC<HeroProps> = ({ onExploreMenu, onVisit }) => {
  return (
    <section className="relative min-h-[92vh] pt-28 pb-16 px-6 flex flex-col justify-between overflow-hidden bg-[#F4F0E7]">
      {/* Editorial Watermark / Subtle Texture */}
      <div className="absolute top-12 right-6 select-none pointer-events-none opacity-5 font-serif text-[12vw] leading-none tracking-tighter text-[#17201C] overflow-hidden whitespace-nowrap">
        KALOREEZ
      </div>

      <div className="max-w-7xl mx-auto w-full flex-grow flex flex-col justify-center">
        {/* Top Location Micro-Label */}
        <div className="flex items-center gap-2 mb-6 text-xs font-medium tracking-[0.25em] uppercase text-[#17201C]/60">
          <MapPin className="w-3.5 h-3.5 text-[#9BAF82]" />
          <span>VISAKHAPATNAM · ANDHRA PRADESH</span>
        </div>

        {/* Hero Grid with Asymmetric Floating Frames */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center relative">
          {/* Left Column: Headlines & Copy */}
          <div className="lg:col-span-6 z-10 space-y-6">
            <h1 className="font-serif text-5xl sm:text-6xl md:text-7xl lg:text-[5.2rem] text-[#17201C] font-normal leading-[0.98] tracking-tight">
              WHOLESOME.
              <br />
              BEAUTIFUL.
              <br />
              <span className="italic font-light">SIMPLY GOOD.</span>
            </h1>

            <p className="text-base sm:text-lg text-[#17201C]/75 font-sans leading-relaxed max-w-lg">
              Thoughtfully prepared food, from nourishing breakfasts to comforting plates, served in the heart of Vizag.
            </p>

            {/* CTAs */}
            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={onExploreMenu}
                className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-[#17201C] text-[#F4F0E7] text-xs font-semibold tracking-[0.2em] uppercase hover:bg-[#9BAF82] hover:text-[#17201C] transition-all cursor-pointer shadow-sm hover:shadow-md"
              >
                <span>EXPLORE MENU</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={onVisit}
                className="px-6 py-3.5 rounded-full border border-[#17201C]/40 text-[#17201C] text-xs font-semibold tracking-[0.18em] uppercase hover:border-[#17201C] hover:bg-white/60 transition-colors cursor-pointer"
              >
                VISIT KAL O R E E Z
              </button>
            </div>

            {/* Subtle Philosophy pill */}
            <div className="pt-4 flex items-center gap-3 text-xs text-[#17201C]/60">
              <span className="w-2 h-2 rounded-full bg-[#9BAF82]" />
              <span>Good food without the pretence · Daspalla Hills</span>
            </div>
          </div>

          {/* Right Column: Central Stable Food Photograph + Curated Floating Frames */}
          <div className="lg:col-span-6 relative mt-6 lg:mt-0">
            {/* Upper Floating Frame: Field Greens */}
            <div className="absolute -top-10 -left-6 sm:-left-10 z-20 hidden sm:block w-36 sm:w-44">
              <FloatingFoodFrame
                frame={HERO_FLOATING_FRAMES[0]}
                onClick={onExploreMenu}
              />
            </div>

            {/* Main Stable Editorial Food Photograph */}
            <div className="relative aspect-[4/5] sm:aspect-[1/1] w-full max-w-lg mx-auto bg-[#EAE4D7] rounded-sm overflow-hidden paper-frame border border-[#D8D0C2]">
              <img
                src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=1200&q=85"
                alt="Signature Wholesome Nourish Bowl with quinoa, charred pumpkin, and garden greens at Kaloreez"
                className="w-full h-full object-cover object-center"
              />
              <div className="absolute bottom-4 left-4 right-4 bg-[#FDFBF7]/90 backdrop-blur-xs p-3 rounded-xs border border-[#D8D0C2]/50 flex items-center justify-between text-xs font-sans">
                <span className="font-serif italic text-sm text-[#17201C]">Warm Coastal Quinoa Bowl</span>
                <span className="text-[11px] font-mono text-[#9BAF82] font-semibold">WHOLESOME PLATE</span>
              </div>
            </div>

            {/* Lower Floating Frame: Single-Origin Cortado */}
            <div className="absolute -bottom-8 -right-4 sm:-right-8 z-20 hidden sm:block w-32 sm:w-40">
              <FloatingFoodFrame
                frame={HERO_FLOATING_FRAMES[1]}
                onClick={onExploreMenu}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
