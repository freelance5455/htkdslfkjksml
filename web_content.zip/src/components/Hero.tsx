import { ArrowRight, BadgeCheck, Download, Play, Star } from "lucide-react";
import PhoneMock from "./PhoneMock";
import { useCountUp, useInView } from "../lib/hooks";
import { FEATURED_BADGES, TICKER_ITEMS } from "../lib/data";

const AVATARS = [
  { i: "MI", c: "from-cyan-400 to-blue-600" },
  { i: "AS", c: "from-violet-400 to-purple-700" },
  { i: "JP", c: "from-orange-400 to-red-600" },
  { i: "CR", c: "from-emerald-400 to-teal-600" },
  { i: "IG", c: "from-sky-400 to-indigo-600" },
];

export default function Hero() {
  const { ref, inView } = useInView<HTMLDivElement>(0.2);

  return (
    <section id="inicio" className="relative overflow-hidden pt-24 sm:pt-28">
      {/* backdrop */}
      <div aria-hidden="true" className="absolute inset-0 grid-bg" />
      <div aria-hidden="true" className="absolute -top-40 left-1/2 h-[36rem] w-[70rem] -translate-x-1/2 rounded-full bg-[radial-gradient(ellipse_at_center,rgba(47,123,255,0.22),transparent_65%)]" />
      <div aria-hidden="true" className="absolute right-[-10rem] top-40 h-96 w-96 rounded-full bg-violetx/15 blur-[120px]" />
      <div aria-hidden="true" className="absolute left-[-10rem] top-64 h-96 w-96 rounded-full bg-electric/15 blur-[120px]" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid items-center gap-10 py-8 lg:grid-cols-12 lg:gap-8 lg:py-14">
          {/* ── copy ─────────────────────────────────────────── */}
          <div className="lg:col-span-6">
            <div className="inline-flex items-center gap-2 rounded-full border border-cyanx/30 bg-cyanx/10 py-1.5 pl-2 pr-4">
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-cyanx/20">
                <BadgeCheck size={13} className="text-cyanx" />
              </span>
              <span className="text-[11px] font-semibold tracking-wide text-cyan-100">
                TV LO3 <span className="text-cyanx">ULTIMATE EDITION</span> · v3.2 ya disponible
              </span>
            </div>

            <h1 className="mt-5 font-display text-[2.75rem] font-bold leading-[1.02] tracking-tight text-white min-[420px]:text-5xl xl:text-[4.3rem]">
              Tu Android ya es<br />
              tu <span className="grad-text">TV Box</span>.
            </h1>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-slate-300 sm:text-lg">
              TV LO3 convierte tu teléfono en un centro multimedia panorámico 16:9 al estilo
              Google TV: <strong className="text-white">World TV</strong> internacional, <strong className="text-white">Sports Center</strong> con marcadores en vivo,
              cine y series 4K, música, radio real y juegos — <em className="not-italic text-cyanx">sin comprar ningún dispositivo</em>.
            </p>

            <div className="mt-7 flex flex-wrap items-center gap-3">
              <a href="#descargar" className="grad-btn inline-flex h-14 items-center gap-2 rounded-2xl px-6 text-base font-bold text-white">
                <Download size={20} strokeWidth={2.5} />
                Descargar gratis
                <ArrowRight size={18} strokeWidth={2.5} aria-hidden="true" />
              </a>
              <a href="#demo" className="ghost-btn inline-flex h-14 items-center gap-2 rounded-2xl px-6 text-base font-semibold text-white">
                <Play size={18} strokeWidth={2.5} className="text-cyanx" />
                Ver demo en vivo
              </a>
            </div>
            <p className="mt-3 text-xs text-slate-500">APK firmada · Android 9+ · Sin tarjeta · Sin permanencia · 16:9 horizontal</p>

            {/* social proof */}
            <div className="mt-7 flex flex-wrap items-center gap-5">
              <div className="flex -space-x-3">
                {AVATARS.map((a, i) => (
                  <span
                    key={i}
                    className={`flex h-11 w-11 items-center justify-center rounded-full border-2 border-abyss bg-gradient-to-br text-[10px] font-bold text-white ${a.c}`}
                  >
                    {a.i}
                  </span>
                ))}
                <span className="flex h-11 w-11 items-center justify-center rounded-full border-2 border-abyss bg-panel3 text-[9px] font-bold text-cyan-200">+10M</span>
              </div>
              <div>
                <div className="flex items-center gap-1" aria-label="Valoración media 4.8 sobre 5">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} size={15} className="fill-gold text-gold" aria-hidden="true" />
                  ))}
                  <span className="ml-1.5 font-display text-sm font-bold text-white">4.8</span>
                </div>
                <p className="mt-0.5 text-xs text-slate-400">+12.400 reseñas verificadas en Google Play</p>
              </div>
            </div>
          </div>

          {/* ── device ───────────────────────────────────────── */}
          <div className="lg:col-span-6">
            <PhoneMock />
          </div>
        </div>

        {/* ── stats strip ────────────────────────────────────── */}
        <div ref={ref} className="grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-white/10 bg-white/10 md:grid-cols-4">
          {FEATURED_BADGES.map((s) => (
            <Stat key={s.label} value={s.value} suffix={s.suffix} label={s.label} active={inView} decimals={s.decimals ?? 0} />
          ))}
        </div>
      </div>

      {/* ── data sources marquee ─────────────────────────────── */}
      <div className="relative mt-10 border-y border-white/5 bg-[#060b26]/80 py-3">
        <div className="marquee-paused overflow-hidden" aria-hidden="true">
          <div className="animate-marquee flex items-center gap-10 whitespace-nowrap">
            {[...TICKER_ITEMS, ...TICKER_ITEMS].map((item, i) => (
              <span key={i} className="flex items-center gap-2.5 text-[11px] font-medium uppercase tracking-[0.18em] text-slate-500">
                <span className="h-1.5 w-1.5 rounded-full bg-gradient-to-r from-cyanx to-violetx" />
                {item}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function Stat({ value, suffix, label, active, decimals }: { value: number; suffix: string; label: string; active: boolean; decimals: number }) {
  const v = useCountUp(value, active, 1800, decimals);
  const formatted = decimals > 0 ? v.toFixed(decimals) : Math.round(v).toLocaleString("es-ES");
  return (
    <div className="bg-[#070d28] px-5 py-5 text-center sm:text-left">
      <p className="font-display text-2xl font-bold text-white sm:text-3xl">
        {formatted}
        <span className="grad-text">{suffix}</span>
      </p>
      <p className="mt-1 text-[11px] leading-snug text-slate-400">{label}</p>
    </div>
  );
}
