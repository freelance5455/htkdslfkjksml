import React from 'react';
import { useApp } from '../context/AppContext';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { 
  Laptop, 
  Video, 
  Wrench, 
  ShieldCheck, 
  MessageCircle, 
  PhoneCall, 
  ChevronRight, 
  DownloadCloud,
  CheckCircle,
  Truck
} from 'lucide-react';

export const Hero: React.FC = () => {
  const { t, language, shopSettings, openServiceModal, setSelectedCategory, setIsPWAGuideOpen } = useApp();
  const { isInstallable, install, isInstalled } = usePWAInstall();

  const handleWhatsApp1 = () => {
    const text = encodeURIComponent(
      language === 'hi'
        ? 'नमस्ते ए के गोलू कंप्यूटर! मुझे कंप्यूटर/लैपटॉप या सीसीटीवी के बारे में जानकारी चाहिए।'
        : 'Hello A K Golu Computer! I want to enquire about computers, laptops or CCTV products.'
    );
    window.open(`https://wa.me/91${shopSettings.phone1}?text=${text}`, '_blank');
  };

  const handleWhatsApp2 = () => {
    const text = encodeURIComponent(
      language === 'hi'
        ? 'नमस्ते ए के गोलू कंप्यूटर! मुझे सर्विस या प्रोडक्ट की जानकारी चाहिए।'
        : 'Hello A K Golu Computer! I need product or service assistance.'
    );
    window.open(`https://wa.me/91${shopSettings.phone2}?text=${text}`, '_blank');
  };

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 pt-8 pb-14 border-b border-slate-800">
      {/* Decorative background grid and light glows */}
      <div className="absolute inset-0 bg-[radial-gradient(#1e3a8a_1px,transparent_1px)] [background-size:24px_24px] opacity-20 pointer-events-none"></div>
      <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-96 h-96 bg-blue-600/15 rounded-full blur-3xl pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Column: Headlines, Value Prop, Action Buttons */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            {/* Top pill badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold">
              <span className="flex h-2 w-2 rounded-full bg-blue-400 animate-ping"></span>
              <span>{t.hero.badge}</span>
              <span className="text-slate-500">•</span>
              <span className="text-slate-300">7054304313 / 8726356413</span>
            </div>

            {/* Main Heading */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight leading-tight">
              {shopSettings.shopName} <br />
              <span className="bg-gradient-to-r from-blue-400 via-sky-300 to-blue-500 bg-clip-text text-transparent">
                {t.hero.titleHighlight}
              </span>
            </h1>

            {/* Subtitle */}
            <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-normal">
              {t.hero.subtitle}
            </p>

            {/* Key Action Buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 sm:gap-4 pt-2">
              <a
                href="#products"
                className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-lg shadow-blue-600/30 transition flex items-center gap-2 group"
              >
                <span>{t.hero.primaryBtn}</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition" />
              </a>

              <button
                onClick={() => openServiceModal()}
                className="px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 font-semibold text-sm transition flex items-center gap-2"
              >
                <Wrench className="w-4 h-4 text-emerald-400" />
                <span>{t.hero.secondaryBtn}</span>
              </button>
            </div>

            {/* Direct WhatsApp Callouts for both numbers */}
            <div className="pt-2">
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2.5">
                {language === 'hi' ? 'सीधे व्हाट्सएप पर बातचीत करें:' : 'Direct WhatsApp Chat & Inquiry:'}
              </p>
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2.5">
                <button
                  onClick={handleWhatsApp1}
                  className="px-4 py-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs font-bold transition flex items-center gap-2 shadow-sm"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                  <span>WhatsApp 7054304313</span>
                </button>
                <button
                  onClick={handleWhatsApp2}
                  className="px-4 py-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs font-bold transition flex items-center gap-2 shadow-sm"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                  <span>WhatsApp 8726356413</span>
                </button>
              </div>
            </div>

            {/* Trust guarantees bar */}
            <div className="pt-4 grid grid-cols-2 sm:grid-cols-3 gap-3 border-t border-slate-800/80 text-left">
              <div className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
                <span className="text-xs text-slate-300">
                  {language === 'hi' ? 'टेस्टेड वारंटी प्रोडक्ट्स' : 'Tested Warranty Hardware'}
                </span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
                <span className="text-xs text-slate-300">
                  {language === 'hi' ? 'होम सर्विस सुविधा उपलब्ध' : 'Doorstep Service Visit'}
                </span>
              </div>
              <div className="flex items-start gap-2 col-span-2 sm:col-span-1">
                <Truck className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
                <span className="text-xs text-slate-300">
                  {language === 'hi' ? 'कैश ऑन डिलीवरी / यूपीआई' : 'COD / UPI on Delivery'}
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Tech Showcase & Category Cards */}
          <div className="lg:col-span-5 space-y-4">
            {/* Main Interactive Showcase Card */}
            <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-700/80 p-5 shadow-2xl relative overflow-hidden">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  <div className="w-3 h-3 rounded-full bg-amber-500"></div>
                  <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
                  <span className="text-xs font-mono text-slate-400 ml-2">ak-golu-services.hub</span>
                </div>
                <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                  ● {language === 'hi' ? 'दुकान खुली है' : 'Shop Active'}
                </span>
              </div>

              {/* Quick service category tiles */}
              <div className="grid grid-cols-2 gap-3 mt-4">
                <div 
                  onClick={() => {
                    setSelectedCategory('laptops_refurbished');
                    const el = document.getElementById('products');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="cursor-pointer p-3.5 rounded-xl bg-slate-800/70 hover:bg-slate-800 border border-slate-700/60 hover:border-blue-500/50 transition group"
                >
                  <Laptop className="w-6 h-6 text-blue-400 mb-2 group-hover:scale-110 transition" />
                  <h4 className="text-xs font-bold text-white leading-snug">
                    {language === 'hi' ? 'रिफर्बिश्ड लैपटॉप' : 'Refurbished Laptops'}
                  </h4>
                  <p className="text-[11px] text-blue-300 mt-1">₹14,999 से शुरू</p>
                </div>

                <div 
                  onClick={() => {
                    setSelectedCategory('cctv_surveillance');
                    const el = document.getElementById('products');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="cursor-pointer p-3.5 rounded-xl bg-slate-800/70 hover:bg-slate-800 border border-slate-700/60 hover:border-blue-500/50 transition group"
                >
                  <Video className="w-6 h-6 text-sky-400 mb-2 group-hover:scale-110 transition" />
                  <h4 className="text-xs font-bold text-white leading-snug">
                    {language === 'hi' ? 'सीसीटीवी कैमरा व DVR' : 'CCTV Cameras & DVR'}
                  </h4>
                  <p className="text-[11px] text-sky-300 mt-1">हिकविज़न / सीपी प्लस</p>
                </div>

                <div 
                  onClick={() => openServiceModal()}
                  className="cursor-pointer p-3.5 rounded-xl bg-slate-800/70 hover:bg-slate-800 border border-slate-700/60 hover:border-emerald-500/50 transition group"
                >
                  <Wrench className="w-6 h-6 text-emerald-400 mb-2 group-hover:scale-110 transition" />
                  <h4 className="text-xs font-bold text-white leading-snug">
                    {language === 'hi' ? 'चिप-लेवल रिपेयरिंग' : 'Chip-Level Repair'}
                  </h4>
                  <p className="text-[11px] text-emerald-300 mt-1">
                    {language === 'hi' ? 'उसी दिन ठीक करें' : 'Same-Day Service'}
                  </p>
                </div>

                <div 
                  onClick={() => {
                    setSelectedCategory('printers_toner');
                    const el = document.getElementById('products');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="cursor-pointer p-3.5 rounded-xl bg-slate-800/70 hover:bg-slate-800 border border-slate-700/60 hover:border-amber-500/50 transition group"
                >
                  <ShieldCheck className="w-6 h-6 text-amber-400 mb-2 group-hover:scale-110 transition" />
                  <h4 className="text-xs font-bold text-white leading-snug">
                    {language === 'hi' ? 'प्रिंटर व टोनर रिफिल' : 'Printer & Cartridge'}
                  </h4>
                  <p className="text-[11px] text-amber-300 mt-1">12A टोनर ₹200 से</p>
                </div>
              </div>

              {/* Install PWA Prompt Box inside Showcase if applicable */}
              <div className="mt-4 pt-3.5 border-t border-slate-800 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-blue-600/20 text-blue-400">
                    <DownloadCloud className="w-4 h-4" />
                  </div>
                  <span className="text-xs text-slate-300 font-medium">
                    {language === 'hi' ? 'एंड्रॉइड फोन पर 1-क्लिक ऐप' : 'Install Mobile Web App'}
                  </span>
                </div>
                {isInstallable && !isInstalled ? (
                  <button
                    onClick={install}
                    className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow transition"
                  >
                    {language === 'hi' ? 'इनस्टॉल करें' : 'Install'}
                  </button>
                ) : (
                  <button
                    onClick={() => setIsPWAGuideOpen(true)}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-blue-300 text-xs font-semibold transition"
                  >
                    {language === 'hi' ? 'तरीका देखें' : 'View Guide'}
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
