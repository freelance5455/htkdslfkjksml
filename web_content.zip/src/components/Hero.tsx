import { useRef } from "react";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { ArrowDown, ArrowUpRight, Check, Radio, ShieldCheck } from "lucide-react";
import type { ProxyRecord } from "../types";
import { COUNTRY_NAMES } from "../data/sources";
import { formatFullDate, typeLabel } from "../lib/proxy";

interface HeroProps {
  proxies: ProxyRecord[];
  activeSources: number;
  totalSources: number;
  isRefreshing: boolean;
  lastRefresh: number | null;
}

const nodePositions = [
  { left: "8%", top: "27%" },
  { left: "75%", top: "13%" },
  { left: "82%", top: "68%" },
  { left: "12%", top: "77%" },
];

export function Hero({ proxies, activeSources, totalSources, isRefreshing, lastRefresh }: HeroProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const reduced = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ["start start", "end start"] });
  const sceneY = useTransform(scrollYProgress, [0, 1], [0, reduced ? 0 : 170]);
  const sceneScale = useTransform(scrollYProgress, [0, 1], [1, reduced ? 1 : 0.91]);
  const sceneOpacity = useTransform(scrollYProgress, [0, 0.92], [1, reduced ? 1 : 0.25]);
  const visualRotate = useTransform(scrollYProgress, [0, 1], [0, reduced ? 0 : 18]);
  const visualCounterRotate = useTransform(visualRotate, (value) => -value);
  const best = proxies[0];
  const nodes = proxies.slice(1, 5);
  const countries = new Set(proxies.map((proxy) => proxy.country).filter(Boolean)).size;
  const latencies = proxies.map((proxy) => proxy.latency).filter((value): value is number => value !== null);
  const bestLatency = latencies.length ? Math.min(...latencies) : null;

  const goTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: reduced ? "auto" : "smooth" });

  return (
    <section ref={sectionRef} id="top" className="relative min-h-[100svh] overflow-hidden bg-ink text-white">
      <motion.div style={{ y: sceneY, scale: sceneScale, opacity: sceneOpacity }} className="relative flex min-h-[100svh] origin-top flex-col">
        <div className="hero-grid absolute inset-0 opacity-50" />
        <div className="absolute -left-[15%] top-[8%] h-[46rem] w-[46rem] rounded-full bg-[#183b30]/45 blur-[120px]" />
        <div className="absolute -right-[10%] top-[-20%] h-[50rem] w-[50rem] rounded-full bg-[#243b2a]/35 blur-[140px]" />
        <div className="absolute inset-x-0 bottom-0 h-52 bg-gradient-to-t from-ink to-transparent" />

        <div className="relative mx-auto grid w-full max-w-[1500px] flex-1 items-center gap-8 px-5 pb-40 pt-32 sm:px-8 lg:grid-cols-[1.05fr_.95fr] lg:px-12 lg:pb-32 lg:pt-28 xl:px-16">
          <div className="relative z-10 max-w-[760px]">
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.15 }}
              className="mb-7 inline-flex items-center gap-2.5 rounded-full border border-white/10 bg-white/[0.045] px-3.5 py-2 text-[11px] font-semibold tracking-[0.1em] text-white/65 backdrop-blur-xl"
            >
              <span className="relative flex h-2 w-2">
                <span className={`absolute inline-flex h-full w-full rounded-full bg-accent ${isRefreshing && !reduced ? "animate-ping" : ""}`} />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-accent" />
              </span>
              {isRefreshing ? "ОБНОВЛЯЕМ ПРОВЕРЕННЫЕ СПИСКИ" : activeSources === 0 && proxies.length > 0 ? "СОХРАНЁННЫЕ ДАННЫЕ · ИСТОЧНИКИ НЕДОСТУПНЫ" : `${activeSources} ИЗ ${totalSources} ИСТОЧНИКОВ НА СВЯЗИ`}
            </motion.div>

            <h1 className="font-display text-[clamp(3.25rem,7.4vw,7.5rem)] font-medium leading-[0.88] tracking-[-0.075em]">
              {["Рабочий", "MTProto.", "Без догадок."].map((line, index) => (
                <span key={line} className="block overflow-hidden pb-[0.08em]">
                  <motion.span
                    initial={{ y: "115%", rotate: 2 }}
                    animate={{ y: 0, rotate: 0 }}
                    transition={{ duration: 0.95, delay: 0.18 + index * 0.1, ease: [0.16, 1, 0.3, 1] }}
                    className={`block ${index === 2 ? "text-accent" : ""}`}
                  >
                    {line}
                  </motion.span>
                </span>
              ))}
            </h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.62 }}
              className="mt-7 max-w-[580px] text-base leading-7 text-white/55 sm:text-lg"
            >
              Сравниваем отвечающие прокси для Telegram по задержке, стабильности и независимым проверкам. Выбирайте маршрут — подключение займёт один клик.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.74 }}
              className="mt-9 flex flex-wrap items-center gap-3"
            >
              <button onClick={() => goTo("catalog")} className="group inline-flex h-14 items-center gap-5 rounded-full bg-accent px-6 text-sm font-bold text-ink transition-all hover:bg-[#d0ff9b] hover:shadow-[0_12px_45px_rgba(192,255,114,0.18)]">
                Найти прокси
                <span className="grid h-8 w-8 place-items-center rounded-full bg-ink text-white transition-transform duration-300 group-hover:translate-x-1"><ArrowDown size={15} /></span>
              </button>
              <button onClick={() => goTo("method")} className="inline-flex h-14 items-center gap-2 rounded-full border border-white/12 px-6 text-sm font-semibold text-white/75 transition-colors hover:border-white/25 hover:text-white">
                Как работает рейтинг <ArrowUpRight size={16} />
              </button>
            </motion.div>

            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.05 }} className="mt-8 flex flex-wrap gap-x-5 gap-y-2 text-[11px] text-white/35">
              <span className="inline-flex items-center gap-1.5"><Check size={13} /> Без регистрации</span>
              <span className="inline-flex items-center gap-1.5"><Check size={13} /> Только трафик Telegram</span>
              <span className="inline-flex items-center gap-1.5"><Check size={13} /> Официальные proxy-ссылки</span>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.88, rotate: -4 }}
            animate={{ opacity: 1, scale: 1, rotate: 0 }}
            transition={{ duration: 1.2, delay: 0.35, ease: [0.16, 1, 0.3, 1] }}
            style={{ rotate: visualRotate }}
            className="relative mx-auto hidden aspect-square w-full max-w-[590px] lg:block"
          >
            <div className="absolute inset-[4%] rounded-full border border-white/[0.07]" />
            <div className="radar-orbit absolute inset-[15%] rounded-full border border-dashed border-white/[0.12]" />
            <div className="radar-orbit-reverse absolute inset-[27%] rounded-full border border-white/[0.09]" />
            <div className="absolute inset-[4%] rounded-full bg-[radial-gradient(circle,rgba(192,255,114,0.07),transparent_66%)]" />
            <svg className="absolute inset-0 h-full w-full opacity-30" viewBox="0 0 100 100" fill="none" aria-hidden="true">
              <path d="M15 32 48 50 78 20M48 50 83 70M48 50 18 78" stroke="#c0ff72" strokeWidth=".18" strokeDasharray="1.5 1.5" />
              <circle cx="48" cy="50" r="38" stroke="white" strokeOpacity=".12" strokeWidth=".15" />
            </svg>

            {nodes.map((proxy, index) => (
              <motion.div
                key={proxy.id}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.9 + index * 0.12, type: "spring", stiffness: 160 }}
                className="absolute z-10 flex items-center gap-2 rounded-full border border-white/10 bg-[#101b18]/85 py-2 pl-2 pr-3 shadow-2xl backdrop-blur-xl"
                style={nodePositions[index]}
              >
                <span className="h-2 w-2 rounded-full bg-accent shadow-[0_0_12px_#c0ff72]" />
                <span className="max-w-28 truncate font-mono text-[10px] text-white/65">{proxy.server}</span>
                <span className="text-[9px] font-semibold text-accent">{proxy.latency !== null ? `${proxy.latency} ms` : typeLabel(proxy.type)}</span>
              </motion.div>
            ))}

            <motion.div style={{ rotate: visualCounterRotate, x: "-50%", y: "-50%" }} className="absolute left-1/2 top-1/2 z-20 w-[330px]">
              <div className="overflow-hidden rounded-[28px] border border-white/15 bg-[#111c19]/90 p-6 shadow-[0_35px_100px_rgba(0,0,0,0.5)] backdrop-blur-2xl">
                <div className="flex items-center justify-between">
                  <span className="inline-flex items-center gap-2 text-[10px] font-bold tracking-[0.16em] text-white/40"><Radio size={13} className="text-accent" /> ЛУЧШИЙ МАРШРУТ</span>
                  <span className="rounded-full bg-accent/10 px-2 py-1 text-[9px] font-bold text-accent">{best ? `${best.score}/100` : "SCAN"}</span>
                </div>
                {best ? (
                  <>
                    <div className="mt-7 truncate font-mono text-lg font-medium tracking-tight text-white" title={best.server}>{best.server}</div>
                    <div className="mt-1 text-xs text-white/35">:{best.port} · {best.country ? COUNTRY_NAMES[best.country] ?? best.country : "Страна не указана"}</div>
                    <div className="mt-6 grid grid-cols-3 gap-3 border-t border-white/10 pt-5">
                      <div><div className="text-[9px] uppercase tracking-wider text-white/30">RTT</div><div className="mt-1 font-display text-xl">{best.latency ?? "—"}<span className="ml-1 text-[10px] text-white/35">ms</span></div></div>
                      <div><div className="text-[9px] uppercase tracking-wider text-white/30">Uptime</div><div className="mt-1 font-display text-xl">{best.uptime !== null ? Math.round(best.uptime) : "—"}<span className="ml-1 text-[10px] text-white/35">%</span></div></div>
                      <div><div className="text-[9px] uppercase tracking-wider text-white/30">Источники</div><div className="mt-1 font-display text-xl">{best.sourceIds.length}</div></div>
                    </div>
                    <div className="mt-5 flex items-center gap-2 rounded-xl bg-white/[0.04] px-3 py-2.5 text-[10px] text-white/45"><ShieldCheck size={14} className="text-accent" />{best.verification === "telegram" ? "Ответ дата-центра Telegram" : best.verification === "handshake" ? "Handshake подтверждён источником" : "Доступность подтверждена источником"}</div>
                  </>
                ) : (
                  <div className="py-12 text-center"><div className="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-white/10 border-t-accent" /><p className="mt-4 text-xs text-white/40">Получаем актуальные каталоги</p></div>
                )}
              </div>
            </motion.div>
          </motion.div>
        </div>

        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.9, duration: 0.8 }} className="absolute inset-x-0 bottom-0 border-t border-white/[0.08] bg-ink/45 backdrop-blur-md">
          <div className="mx-auto grid max-w-[1500px] grid-cols-2 px-5 sm:grid-cols-4 sm:px-8 lg:px-12 xl:px-16">
            {[
              { value: proxies.length ? proxies.length.toLocaleString("ru-RU") : "—", label: "уникальных маршрутов" },
              { value: bestLatency !== null ? `${bestLatency} мс` : "—", label: "лучший RTT источника" },
              { value: countries || "—", label: "стран в каталоге" },
              { value: lastRefresh ? formatFullDate(lastRefresh) : "Скоро", label: "последнее обновление" },
            ].map((stat, index) => (
              <div key={stat.label} className={`py-5 sm:py-6 ${index > 0 ? "sm:border-l sm:border-white/[0.08] sm:pl-7" : ""} ${index === 2 ? "border-t border-white/[0.08] sm:border-t-0" : ""} ${index === 3 ? "border-l border-t border-white/[0.08] pl-5 sm:border-t-0" : ""}`}>
                <div className="font-display text-xl font-medium tracking-tight text-white/90 sm:text-2xl">{stat.value}</div>
                <div className="mt-1 text-[10px] text-white/30 sm:text-[11px]">{stat.label}</div>
              </div>
            ))}
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
}
