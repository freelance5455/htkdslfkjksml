import React from 'react';
import { ArrowRight, ShieldCheck, Sparkles, SlidersHorizontal, PackageCheck } from 'lucide-react';

interface HeroProps {
  onExploreCatalog: () => void;
  onOpenRoomPlanner: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreCatalog, onOpenRoomPlanner }) => {
  return (
    <section className="relative overflow-hidden bg-[#FAF8F5] pt-6 pb-12 sm:pt-10 sm:pb-16 border-b border-stone-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Split Hero: Content Left, Editorial Imagery Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Brand Story & CTAs */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            <span className="text-xs uppercase tracking-[0.25em] text-stone-600 font-semibold mb-3">
              Crafted Living & Modern Sanctuary
            </span>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-normal text-stone-900 leading-[1.12] tracking-tight mb-5 text-balance">
              Everyday essentials shaped with quiet elegance and timeless utility.
            </h1>
            <p className="text-stone-600 text-base sm:text-lg leading-relaxed mb-8 max-w-xl">
              From pure French stonewashed linens to hand-thrown speckled ceramics and Cambodian oud aromas. Bait ul Ukasha curates heirloom home goods designed to bring tranquility to every corner of your dwelling.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4">
              <button
                onClick={onExploreCatalog}
                className="inline-flex items-center gap-2.5 bg-[#2D2A26] text-[#FAF8F5] hover:bg-stone-850 px-6 py-3.5 rounded-lg text-sm font-medium transition-all shadow-sm hover:shadow-md cursor-pointer group whitespace-nowrap"
              >
                <span>Explore The Collection</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>
              <button
                onClick={onOpenRoomPlanner}
                className="inline-flex items-center gap-2 bg-white text-stone-800 hover:bg-stone-50 border border-stone-300 hover:border-stone-400 px-5 py-3.5 rounded-lg text-sm font-medium transition-all cursor-pointer whitespace-nowrap shadow-2xs"
              >
                <SlidersHorizontal className="w-4 h-4 text-stone-600" />
                <span>Interactive Room Planner</span>
              </button>
            </div>

            {/* Trust and Independence claim */}
            <div className="mt-8 pt-6 border-t border-stone-200/80 flex items-center gap-4 text-xs text-stone-500">
              <span>Zero external subscriptions</span>
              <span aria-hidden="true">·</span>
              <span>100% On-device local storage</span>
              <span aria-hidden="true">·</span>
              <span>Portable offline execution</span>
            </div>
          </div>

          {/* Right Column: Hero Visual Asset */}
          <div className="lg:col-span-6">
            <div className="relative rounded-2xl overflow-hidden bg-stone-100 shadow-xl border border-stone-200/80 group">
              <img
                src="/src/assets/images/hero_home_essentials_1792296360356.jpg"
                alt="Bait ul Ukasha living sanctuary with handcrafted ceramics and linen drapery"
                referrerPolicy="no-referrer"
                className="w-full h-[360px] sm:h-[460px] lg:h-[500px] object-cover transition-transform duration-700 ease-out group-hover:scale-[1.02]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-900/60 via-stone-900/10 to-transparent pointer-events-none" />
              
              {/* Subtle architectural caption overlay */}
              <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-[#FAF8F5]/90 backdrop-blur-md border border-stone-200/80 text-stone-900 flex items-center justify-between">
                <div>
                  <p className="font-serif text-base font-semibold">The Living Sanctuary Suite</p>
                  <p className="text-xs text-stone-600">Hand-honed travertine, Normandy flax & warm brass</p>
                </div>
                <button
                  onClick={onExploreCatalog}
                  className="text-xs font-semibold underline decoration-stone-400 hover:text-stone-950 cursor-pointer"
                >
                  View Pieces
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* 3-Column Trust & Adjacency Strip */}
        <div className="mt-14 pt-8 border-t border-stone-200/80 grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
          <div className="flex items-start gap-3.5">
            <div className="p-2.5 rounded-lg bg-stone-100 text-stone-800 shrink-0">
              <Sparkles className="w-5 h-5 text-stone-700" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-stone-900 mb-1">Authentic Natural Materials</h3>
              <p className="text-xs text-stone-600 leading-relaxed">
                Single-origin linen, high-fire ceramic stoneware, end-grain walnut, and genuine essential oils free of synthetic additives.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3.5">
            <div className="p-2.5 rounded-lg bg-stone-100 text-stone-800 shrink-0">
              <PackageCheck className="w-5 h-5 text-stone-700" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-stone-900 mb-1">Local Checkout & Receipts</h3>
              <p className="text-xs text-stone-600 leading-relaxed">
                Instant order placement with Cash on Delivery (COD) or Direct Wire. Full PDF/printable invoices saved on your local device.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3.5">
            <div className="p-2.5 rounded-lg bg-stone-100 text-stone-800 shrink-0">
              <ShieldCheck className="w-5 h-5 text-stone-700" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-stone-900 mb-1">Windows & Offline Ready</h3>
              <p className="text-xs text-stone-600 leading-relaxed">
                Download the complete codebase as a ZIP archive, run with 1-click batch script, or install as an isolated Windows app.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
