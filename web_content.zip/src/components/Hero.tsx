import { useEffect, useState } from "react";
import { brand, stats } from "../data/content";
import { useSmoothScroll } from "../hooks/useSmoothScroll";
import {
  ArrowRightIcon,
  PlayIcon,
  SparklesIcon,
  CheckIcon,
} from "./icons";

export function Hero() {
  const scrollTo = useSmoothScroll();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const t = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(t);
  }, []);

  return (
    <section
      id="hero"
      className="relative min-h-screen overflow-hidden pt-24 pb-16 sm:pt-28 lg:pt-32"
    >
      {/* Background layers */}
      <div className="pointer-events-none absolute inset-0 mesh-gradient" />
      <div className="pointer-events-none absolute inset-0 grid-bg opacity-60" />
      <div className="pointer-events-none absolute top-1/4 left-1/2 h-[600px] w-[600px] -translate-x-1/2 rounded-full bg-brand-600/20 blur-[120px] animate-pulse-glow" />
      <div className="pointer-events-none absolute top-1/3 right-0 h-[400px] w-[400px] rounded-full bg-fuchsia-600/10 blur-[100px]" />

      <div className="relative mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        {/* Badge */}
        <div
          className={`flex justify-center transition-all duration-700 ${
            mounted ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"
          }`}
        >
          <button
            type="button"
            onClick={() => scrollTo("features")}
            className="group inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-sm text-ink-300 backdrop-blur-md transition-all hover:border-brand-400/40 hover:bg-white/10 hover:text-white"
          >
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-brand-500/20 text-brand-300">
              <SparklesIcon size={12} />
            </span>
            <span>
              Introducing Cascade AI Copilot{" "}
              <span className="text-ink-500">— now in GA</span>
            </span>
            <ArrowRightIcon
              size={14}
              className="text-ink-500 transition-transform group-hover:translate-x-0.5 group-hover:text-white"
            />
          </button>
        </div>

        {/* Headline */}
        <div className="mt-8 text-center sm:mt-10">
          <h1
            className={`mx-auto max-w-4xl text-4xl font-semibold tracking-tight text-white sm:text-5xl md:text-6xl lg:text-[4.25rem] lg:leading-[1.08] transition-all duration-700 delay-100 ${
              mounted ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0"
            }`}
          >
            Operations that{" "}
            <span className="text-gradient-brand">run themselves</span>
            <br className="hidden sm:block" />— so your team can lead
          </h1>
          <p
            className={`mx-auto mt-6 max-w-2xl text-base leading-relaxed text-ink-400 sm:text-lg transition-all duration-700 delay-200 ${
              mounted ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0"
            }`}
          >
            {brand.description} Join 12,000+ teams who automated the busywork
            and unlocked relentless focus.
          </p>
        </div>

        {/* CTAs */}
        <div
          className={`mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row sm:gap-4 transition-all duration-700 delay-300 ${
            mounted ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0"
          }`}
        >
          <button type="button" className="btn-primary w-full sm:w-auto">
            Start free trial
            <ArrowRightIcon size={16} />
          </button>
          <button
            type="button"
            onClick={() => scrollTo("showcase")}
            className="btn-secondary w-full sm:w-auto"
          >
            <PlayIcon size={16} className="text-brand-300" />
            See how it works
          </button>
        </div>

        {/* Trust line */}
        <div
          className={`mt-6 flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-sm text-ink-500 transition-all duration-700 delay-400 ${
            mounted ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0"
          }`}
        >
          {["14-day free trial", "No credit card", "SOC 2 Type II"].map(
            (item) => (
              <span key={item} className="inline-flex items-center gap-1.5">
                <CheckIcon size={14} className="text-brand-400" />
                {item}
              </span>
            )
          )}
        </div>

        {/* Product visual */}
        <div
          className={`relative mx-auto mt-14 max-w-5xl transition-all duration-1000 delay-500 ${
            mounted ? "translate-y-0 opacity-100" : "translate-y-12 opacity-0"
          }`}
        >
          <div className="absolute -inset-4 rounded-3xl bg-gradient-to-b from-brand-500/20 via-brand-600/5 to-transparent blur-2xl" />
          <div className="glow-brand relative overflow-hidden rounded-2xl border border-white/10 bg-ink-900/80 shadow-2xl">
            {/* Window chrome */}
            <div className="flex items-center gap-2 border-b border-white/8 bg-white/[0.03] px-4 py-3">
              <div className="flex gap-1.5">
                <span className="h-3 w-3 rounded-full bg-red-400/80" />
                <span className="h-3 w-3 rounded-full bg-amber-400/80" />
                <span className="h-3 w-3 rounded-full bg-emerald-400/80" />
              </div>
              <div className="mx-auto flex items-center gap-2 rounded-md border border-white/8 bg-white/5 px-3 py-1 text-xs text-ink-400">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                app.cascade.ai/workflows/onboarding
              </div>
            </div>

            <div className="relative aspect-[16/9] overflow-hidden bg-ink-950">
              <img
                src="/images/hero-dashboard.jpg"
                alt="Cascade AI workflow dashboard showing automated operations canvas"
                className="h-full w-full object-cover object-top opacity-90"
                loading="eager"
              />
              {/* Overlay UI chips */}
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink-950/60 via-transparent to-transparent" />
              <div className="absolute top-4 left-4 hidden animate-float sm:block">
                <div className="glass rounded-xl px-3 py-2 text-xs text-ink-200 shadow-lg">
                  <span className="text-emerald-400">●</span> 24 workflows live
                </div>
              </div>
              <div className="absolute top-4 right-4 hidden animate-float-slow sm:block" style={{ animationDelay: "1s" }}>
                <div className="glass rounded-xl px-3 py-2 text-xs text-ink-200 shadow-lg">
                  <span className="font-semibold text-brand-300">AI</span> optimized 3 steps
                </div>
              </div>
              <div className="absolute bottom-4 left-1/2 hidden -translate-x-1/2 sm:block">
                <div className="glass-strong flex items-center gap-3 rounded-full px-4 py-2 text-xs text-white shadow-xl">
                  <SparklesIcon size={14} className="text-brand-300" />
                  Copilot: “Onboarding flow complete — 4 min avg”
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats strip */}
        <div
          className={`mt-16 grid grid-cols-2 gap-6 border-t border-white/8 pt-10 sm:grid-cols-4 transition-all duration-700 delay-700 ${
            mounted ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0"
          }`}
        >
          {stats.map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-2xl font-semibold tracking-tight text-white sm:text-3xl">
                {stat.value}
              </div>
              <div className="mt-1 text-sm text-ink-500">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
