import { formatNumber } from "../data/game";
import { ArrowRight, ArrowUpRight, Play } from "./Icons";
import { Reveal } from "./ui";

export function Hero({ personalBest, onStart }: { personalBest: number; onStart: () => void }) {
  return (
    <section id="top" className="relative overflow-hidden pt-[104px] sm:pt-[124px]">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -left-40 top-0 h-[520px] w-[520px] rounded-full bg-[radial-gradient(circle,rgba(201,250,60,0.10),transparent_65%)] blur-2xl" />
        <div className="absolute -right-24 top-24 h-[420px] w-[420px] rounded-full bg-[radial-gradient(circle,rgba(140,190,90,0.07),transparent_65%)] blur-2xl" />
        <div
          className="absolute inset-0 opacity-[0.16]"
          style={{
            backgroundImage:
              "linear-gradient(to right, rgba(255,255,255,0.055) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.04) 1px, transparent 1px)",
            backgroundSize: "86px 86px",
            maskImage: "linear-gradient(to bottom, black, transparent 84%)",
            WebkitMaskImage: "linear-gradient(to bottom, black, transparent 84%)",
          }}
        />
      </div>

      <div className="mx-auto max-w-[1360px] px-4 pb-10 sm:px-6 sm:pb-14 lg:px-10">
        <div className="grid items-center gap-10 lg:grid-cols-[1.02fr_0.98fr] lg:gap-12 xl:gap-16">
          <div>
            <Reveal>
              <div className="flex flex-wrap items-center gap-3">
                <span className="inline-flex items-center gap-2 rounded-full border border-volt/30 bg-volt/8 px-3 py-1.5 font-mono text-[9px] font-medium uppercase tracking-[0.18em] text-volt">
                  <span className="h-1.5 w-1.5 animate-pulse-dot rounded-full bg-volt" />
                  The night shift is live
                </span>
                <span className="font-mono text-[9px] uppercase tracking-[0.16em] text-moss-500">A VANTA original · 2026</span>
              </div>

              <h1 className="mt-6 text-balance text-[clamp(3.4rem,7.6vw,7rem)] font-semibold leading-[0.83] tracking-[-0.055em] text-bone">
                Own the
                <br />
                <span className="font-serif font-normal italic tracking-[-0.015em] text-volt">night.</span>
              </h1>

              <p className="mt-6 max-w-[30rem] text-balance text-[14.5px] leading-relaxed text-moss-300 sm:text-[15.5px]">
                The city sleeps. The freeway doesn't. Thread four lanes of traffic, chain near misses at{" "}
                <span className="text-bone">200 km/h</span>, and find out how far the dark will let you go.
              </p>

              <div className="mt-7 flex flex-col gap-2.5 sm:flex-row sm:items-center">
                <button
                  type="button"
                  onClick={onStart}
                  className="group relative inline-flex items-center justify-center gap-2.5 overflow-hidden rounded-full bg-volt px-6 py-3.5 text-[12px] font-semibold uppercase tracking-[0.15em] text-ink-950 transition hover:bg-volt-bright hover:shadow-[0_0_50px_-10px_rgba(201,250,60,0.7)]"
                >
                  <span className="absolute inset-y-0 -left-full w-1/2 skew-x-[-20deg] bg-white/25 transition-transform duration-700 group-hover:translate-x-[320%]" />
                  <Play className="h-3 w-3" />
                  Start driving
                  <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
                </button>
                <a
                  href="#story"
                  className="group inline-flex items-center justify-center gap-2.5 rounded-full border border-white/12 bg-white/4 px-6 py-3.5 text-[12px] font-medium uppercase tracking-[0.14em] text-bone transition hover:border-white/22 hover:bg-white/7"
                >
                  Read the story
                  <span className="flex h-5 w-5 items-center justify-center rounded-full border border-white/15 text-moss-300 transition group-hover:border-volt/40 group-hover:text-volt">
                    <svg viewBox="0 0 24 24" fill="none" className="h-3 w-3">
                      <path d="M12 5v14m0 0 5-5m-5 5-5-5" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </span>
                </a>
              </div>

              <div className="mt-8 flex max-w-md items-stretch gap-px overflow-hidden rounded-xl border border-white/10 bg-white/8">
                {[
                  { value: "200", unit: "km/h", label: "Top speed" },
                  { value: "04", unit: "lanes", label: "Highway" },
                  { value: "∞", unit: "runs", label: "Until sunrise" },
                ].map((stat) => (
                  <div key={stat.label} className="flex-1 bg-ink-900/85 px-3 py-3 sm:px-4">
                    <p className="flex items-baseline gap-1 font-mono text-lg font-semibold leading-none text-bone sm:text-xl">
                      {stat.value}
                      <span className="text-[8px] font-normal uppercase tracking-[0.1em] text-moss-500">{stat.unit}</span>
                    </p>
                    <p className="mt-1.5 font-mono text-[8px] uppercase tracking-[0.14em] text-moss-500">{stat.label}</p>
                  </div>
                ))}
              </div>

              <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 font-mono text-[9px] uppercase tracking-[0.14em] text-moss-500">
                <span className="flex items-center gap-1.5">
                  <span className="h-1 w-1 rounded-full bg-volt" /> Keyboard + touch
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="h-1 w-1 rounded-full bg-volt" /> No sign-up
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="h-1 w-1 rounded-full bg-volt" /> Your best:{" "}
                  <span className="text-moss-300">{personalBest > 0 ? `${formatNumber(personalBest)} m` : "unset"}</span>
                </span>
              </div>
            </Reveal>
          </div>

          <Reveal delay={120} className="relative">
            <div className="relative mx-auto w-full max-w-[500px] lg:mr-0 lg:max-w-none">
              <div className="relative aspect-[4/5] max-h-[600px] overflow-hidden rounded-[26px] border border-white/12 bg-ink-800 shadow-[0_40px_120px_-40px_rgba(0,0,0,0.9)]">
                <img
                  src="/images/hero-car.jpg"
                  alt="The VANTA Night Spec hypercar on a rain-soaked coastal highway at night"
                  className="absolute inset-0 h-full w-full object-cover object-[52%_62%]"
                  fetchPriority="high"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/25 to-ink-950/20" />
                <div className="absolute inset-0 bg-[radial-gradient(70%_50%_at_70%_35%,transparent,rgba(6,7,5,0.55))]" />

                <div className="absolute inset-x-0 top-0 flex items-start justify-between p-4 sm:p-5">
                  <span className="glass inline-flex items-center gap-2 rounded-full border border-white/15 px-3 py-1.5 font-mono text-[8px] uppercase tracking-[0.18em] text-bone">
                    <span className="h-1.5 w-1.5 animate-pulse-dot rounded-full bg-volt" />
                    Live from highway 01
                  </span>
                  <div className="flex h-[68px] w-[68px] rotate-6 flex-col items-center justify-center rounded-full bg-volt text-ink-950 shadow-[0_12px_30px_-8px_rgba(201,250,60,0.45)] sm:h-[76px] sm:w-[76px]">
                    <span className="font-mono text-xl font-bold leading-none tracking-tight sm:text-2xl">200</span>
                    <span className="mt-0.5 font-mono text-[7px] font-semibold uppercase tracking-[0.16em]">km/h cap</span>
                  </div>
                </div>

                <div className="absolute inset-x-0 bottom-0 p-4 pt-20 sm:p-5">
                  <div className="flex items-end justify-between gap-3 border-b border-white/15 pb-3.5">
                    <div>
                      <p className="font-mono text-[8px] uppercase tracking-[0.2em] text-volt">Featured machine</p>
                      <h2 className="mt-1.5 flex items-baseline gap-2 text-2xl font-semibold leading-none tracking-tight text-bone sm:text-[28px]">
                        Night Spec
                        <span className="font-mono text-[10px] font-normal uppercase tracking-[0.12em] text-moss-400">GT-R</span>
                      </h2>
                    </div>
                    <a
                      href="#garage"
                      className="group flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-white/20 text-bone transition hover:border-volt hover:text-volt sm:h-10 sm:w-10"
                      aria-label="See the garage"
                    >
                      <ArrowUpRight className="h-4 w-4 transition group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </a>
                  </div>
                  <div className="mt-3 grid grid-cols-3 divide-x divide-white/10 font-mono text-[8px] uppercase tracking-[0.12em] text-moss-500">
                    {[
                      ["Output", "820 hp"],
                      ["Drive", "RWD"],
                      ["0—100", "2.8 s"],
                    ].map(([label, value]) => (
                      <div key={label} className="pl-3 first:pl-0">
                        <p>{label}</p>
                        <p className="mt-1 text-[11px] font-medium normal-case tracking-normal text-bone">{value}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="glass mt-3 flex items-center gap-4 rounded-xl border border-white/12 px-4 py-3 sm:px-5">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-mono text-[7px] uppercase tracking-[0.16em] text-moss-400">Your best run</p>
                    <span className="h-1 w-1 animate-pulse-dot rounded-full bg-volt" />
                  </div>
                  <p className="mt-1 font-mono text-lg font-semibold leading-none tracking-tight text-bone sm:text-xl">
                    {personalBest > 0 ? `${formatNumber(personalBest)} m` : "— — —"}
                  </p>
                </div>
                <div className="h-8 w-px bg-white/12" />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2 font-mono text-[7px] uppercase tracking-[0.1em] text-moss-500">
                    <span>Start</span>
                    <span>Wall · 12,480 m</span>
                  </div>
                  <span className="mt-1.5 flex h-1 overflow-hidden rounded-full bg-white/12">
                    <span
                      className="block h-full rounded-full bg-volt"
                      style={{ width: `${Math.min(100, Math.max(3, (personalBest / 12480) * 100))}%` }}
                    />
                  </span>
                </div>
              </div>

              <div className="pointer-events-none absolute -right-5 bottom-24 hidden rotate-90 items-center gap-2 font-mono text-[8px] uppercase tracking-[0.26em] text-moss-500 xl:flex">
                <span className="h-px w-8 bg-white/20" />
                Highway division / 001
              </div>
            </div>
          </Reveal>
        </div>
      </div>

      <div className="mx-auto flex max-w-[1360px] items-center justify-between gap-4 px-4 pb-6 font-mono text-[9px] uppercase tracking-[0.18em] text-moss-500 sm:px-6 lg:px-10">
        <span className="flex items-center gap-2">
          <span className="h-6 w-px bg-gradient-to-b from-volt to-transparent" />
          Scroll to ignite
        </span>
        <span className="hidden sm:block">Headphones recommended · Sound optional</span>
      </div>
    </section>
  );
}
