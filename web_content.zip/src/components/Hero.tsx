import React, { useState } from 'react';
import { MessageCircle, Radio, Sparkles, Volume2, ShieldCheck, Phone } from 'lucide-react';
import { audioCues } from '../utils/audioCueEngine';

interface HeroProps {
  onBookClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onBookClick }) => {
  const [isPlayingBeat, setIsPlayingBeat] = useState(false);
  const [imgError, setImgError] = useState(false);

  const handleTestDrop = () => {
    audioCues.playAirHorn();
  };

  const handleToggleBeat = () => {
    const newState = audioCues.toggleAfrobeatLoop((playing) => {
      setIsPlayingBeat(playing);
    });
    setIsPlayingBeat(newState);
  };

  return (
    <section className="relative pt-6 pb-14 md:pt-10 md:pb-20 px-4 text-center overflow-hidden border-b border-purple-900/30">
      {/* Background neon laser glows */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-5xl h-96 bg-gradient-to-b from-purple-700/30 via-fuchsia-600/20 to-cyan-500/10 blur-3xl pointer-events-none -z-10" />

      <div className="max-w-4xl mx-auto">
        {/* DJ Logo Avatar with Glowing Ring */}
        <div className="relative inline-block mb-4">
          <div className="relative w-48 h-48 sm:w-60 sm:h-60 mx-auto rounded-full p-1 bg-gradient-to-tr from-purple-500 via-pink-500 to-cyan-400 shadow-[0_0_50px_rgba(255,255,255,0.6)]">
            {!imgError ? (
              <img
                src="/djlogo.jpg"
                alt="DJ EVAN PRO UG - The Cue King"
                onError={() => setImgError(true)}
                className="w-full h-full rounded-full object-cover border-4 border-white shadow-2xl"
              />
            ) : (
              <div className="w-full h-full rounded-full bg-gradient-to-br from-[#1c0e35] via-[#2a134a] to-[#0a0518] flex flex-col items-center justify-center border-4 border-white text-white p-4">
                <span className="text-3xl sm:text-4xl mb-1">👑</span>
                <span className="text-xl sm:text-2xl font-black tracking-tight uppercase font-['Outfit']">
                  DJ EVAN PRO
                </span>
                <span className="text-xs font-mono font-bold text-yellow-300">CUE KING UG</span>
              </div>
            )}
            {/* Live badge pinned to logo */}
            <div className="absolute bottom-2 right-2 bg-rose-600 text-white text-[10px] sm:text-xs font-black uppercase px-2.5 py-1 rounded-full border-2 border-white flex items-center gap-1 shadow-lg">
              <span className="w-2 h-2 rounded-full bg-white animate-ping" />
              <span>LIVE</span>
            </div>
          </div>
        </div>

        {/* Headings */}
        <h1 className="text-3xl sm:text-5xl md:text-6xl font-black uppercase tracking-tight text-white font-['Outfit'] mt-2">
          DJ EVAN PRO UG
        </h1>
        <p className="text-2xl sm:text-3xl font-black text-yellow-300 tracking-wide mt-1">
          THE CUE KING 👑 🇺🇬
        </p>
        <p className="mt-2 text-base sm:text-lg font-bold text-white">
          Kyebando, Kawempe | Kampala's #1 DJ
        </p>
        <p className="text-xs sm:text-sm mt-1 text-slate-300 font-medium">
          Parties | Weddings | Kwanjula &amp; Kuhingira | Clubs | Phones &amp; DJ Apps
        </p>

        {/* Call to action buttons */}
        <div className="mt-6 flex flex-col gap-3 justify-center items-center max-w-sm mx-auto">
          {/* Main WhatsApp CTA */}
          <a
            href="https://wa.me/256742094651?text=Boss%20Cue%20King%20I%20want%20to%20book%20you%20in%20Kyebando%20Kampala"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-emerald-500 hover:bg-emerald-400 text-white px-8 py-4 rounded-full font-black text-base sm:text-lg w-full shadow-[0_0_30px_rgba(16,185,129,0.5)] active:scale-95 transition-all flex items-center justify-center gap-2 border border-emerald-300/40"
          >
            <MessageCircle className="w-5 h-5 fill-white" />
            <span>💬 WhatsApp 0742094651</span>
          </a>

          {/* TikTok Live CTA */}
          <a
            href="https://tiktok.com/@djevanproug"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-black hover:bg-zinc-900 text-white px-8 py-3.5 rounded-full font-bold border border-white/60 w-full shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2 text-sm sm:text-base"
          >
            <Radio className="w-4 h-4 text-rose-500 animate-pulse" />
            <span>🔴 TikTok LIVE 8PM @djevanproug</span>
          </a>

          {/* Direct Phone Call */}
          <a
            href="tel:+256742094651"
            className="text-xs text-slate-300 hover:text-white flex items-center gap-1.5 pt-1"
          >
            <Phone className="w-3.5 h-3.5 text-cyan-400" />
            <span>Quick Call: <strong>0742094651</strong></span>
          </a>
        </div>

        {/* Soundboard test pills */}
        <div className="mt-8 flex items-center justify-center gap-2 flex-wrap">
          <button
            onClick={handleTestDrop}
            className="px-3.5 py-1.5 rounded-full bg-purple-900/60 hover:bg-purple-800 border border-purple-500/50 text-purple-200 text-xs font-bold active:scale-95 transition-all flex items-center gap-1.5"
          >
            <Volume2 className="w-3.5 h-3.5 text-yellow-300" />
            <span>Test Cue: Air Horn Drop</span>
          </button>

          <button
            onClick={handleToggleBeat}
            className={`px-3.5 py-1.5 rounded-full border text-xs font-bold transition-all ${
              isPlayingBeat
                ? 'bg-rose-600/40 border-rose-500 text-rose-200 animate-pulse'
                : 'bg-zinc-900 border-zinc-700 text-zinc-300 hover:text-white'
            }`}
          >
            <span>{isPlayingBeat ? '■ Stop Beat' : '▶ Preview Afrobeats'}</span>
          </button>

          <button
            onClick={onBookClick}
            className="px-3.5 py-1.5 rounded-full bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-800/50 text-cyan-300 text-xs font-bold"
          >
            <span>Book Now &darr;</span>
          </button>
        </div>
      </div>
    </section>
  );
};
