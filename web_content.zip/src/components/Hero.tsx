import { useMemo } from "react";
import GamePlayer from "./GamePlayer";
import { useTerminal } from "../lib/hooks";
import { IconArrowRight, IconKey, IconWifiOff, IconBolt, IconLayers } from "./Icons";
import type { GameConfig } from "../lib/models";
import { MODELS } from "../lib/models";

const BOOT_LINES = [
  "$ yuno init --offline",
  "[runtime] wasm + webgpu backend ............ OK",
  "[cache]   12 open models found on disk",
  "[vision]  palette extractor ................ OK",
  "[voice]   whisper-39m + piper-tts .......... OK",
  "[forge]   listening on device:0 — no network required",
];

const DEMO_CONFIG: GameConfig = {
  id: "hero-attract",
  title: "Starforge",
  type: "shooter",
  prompt: "auto attract demo",
  speed: 0.9,
  attract: true,
  colors: { bg: "#0b0e13", player: "#ffb454", enemy: "#ff5d73", accent: "#2fe6c8", glow: "#ff7a2f" },
};

export default function Hero() {
  const { out } = useTerminal(BOOT_LINES, 55, 4200);
  const tickerItems = useMemo(
    () => [
      ...MODELS.map((m) => m.name + " " + m.params),
      "100% ON-DEVICE",
      "0 CLOUD CALLS",
      "1-FILE EXPORTS",
      "WHISPER VOICE INPUT",
      "PALETTE FROM IMAGES",
    ],
    []
  );

  return (
    <section id="top" className="relative pt-32 pb-10 overflow-hidden">
      <div className="mx-auto max-w-7xl px-5">
        <div className="grid lg:grid-cols-[1.05fr_1fr] gap-12 items-center">
          {/* left */}
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-6">
              <span className="flex items-center gap-2 font-mono text-[10px] tracking-[0.2em] text-teal border border-teal/40 bg-teal/5 px-2.5 py-1 clip-tag">
                <IconWifiOff size={12} /> WORKS WITH NO INTERNET
              </span>
              <span className="flex items-center gap-2 font-mono text-[10px] tracking-[0.2em] text-ember border border-ember/40 bg-ember/5 px-2.5 py-1 clip-tag">
                <IconBolt size={12} /> OPEN WEIGHTS ONLY
              </span>
            </div>

            <h1 className="font-display font-black leading-[1.04] text-[clamp(2.1rem,4.6vw,3.6rem)]">
              <span className="text-snow">TYPE AN IDEA.</span>
              <br />
              <span className="text-ember">PLAY A GAME.</span>
              <br />
              <span className="text-teal">OWN THE FILES.</span>
            </h1>

            <p className="mt-6 max-w-lg text-fog text-[15.5px] leading-relaxed">
              YunoAI is an offline forge: describe any game, pick an open-source model from{" "}
              <span className="text-mist">Hugging Face</span> or <span className="text-mist">GitHub</span>,
              drop a reference image for the look — then play it in your browser or download it as a
              single file. Nothing ever leaves your machine.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3.5">
              <a href="#forge" className="btn-primary clip-hud px-6 py-3.5 font-mono font-bold text-[13px] tracking-[0.14em] inline-flex items-center gap-2.5">
                IGNITE THE FORGE <IconArrowRight size={16} />
              </a>
              <a href="#models" className="btn-ghost clip-hud px-6 py-3.5 font-mono text-[13px] tracking-[0.14em] inline-flex items-center gap-2.5">
                <IconLayers size={15} /> BROWSE MODELS
              </a>
            </div>

            <div className="mt-9 flex flex-wrap gap-x-8 gap-y-3 font-mono text-[11px] tracking-[0.14em] text-fog">
              <span><b className="text-snow text-[15px]">12</b> OPEN MODELS</span>
              <span><b className="text-snow text-[15px]">0</b> CLOUD CALLS</span>
              <span><b className="text-snow text-[15px]">1</b> FILE EXPORTS</span>
              <span><b className="text-teal text-[15px]">∞</b> REPLAYS</span>
            </div>

            {/* boot terminal */}
            <div className="mt-9 border border-line bg-ink2/90 clip-hud max-w-lg">
              <div className="flex items-center gap-2 px-4 h-9 border-b border-line">
                <svg width="9" height="9" viewBox="0 0 10 10"><circle cx="5" cy="5" r="4" fill="#ff5d73" /></svg>
                <svg width="9" height="9" viewBox="0 0 10 10"><circle cx="5" cy="5" r="4" fill="#ffb454" /></svg>
                <svg width="9" height="9" viewBox="0 0 10 10"><circle cx="5" cy="5" r="4" fill="#2fe6c8" /></svg>
                <span className="ml-2 font-mono text-[10px] tracking-[0.2em] text-fog">YUNO — BOOT SEQUENCE</span>
              </div>
              <div className="px-4 py-3.5 font-mono text-[11.5px] leading-[1.85] min-h-[168px]">
                {out.map((l, i) => (
                  <div key={i} className={i === 0 ? "text-snow" : l.includes("OK") ? "text-teal" : "text-fog"}>
                    {l}
                    {i === out.length - 1 && <span className="caret text-ember">▍</span>}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* right — live demo */}
          <div className="relative">
            <div className="absolute -inset-8 bg-[radial-gradient(ellipse_at_center,rgba(255,122,47,0.13),transparent_65%)] glow-breathe pointer-events-none" />
            <div className="relative border border-line2 bg-panel clip-hud shadow-[0_30px_90px_rgba(0,0,0,0.55)]">
              <div className="flex items-center gap-2 px-4 h-10 border-b border-line">
                <svg width="9" height="9" viewBox="0 0 10 10"><circle cx="5" cy="5" r="4" fill="#ff5d73" /></svg>
                <svg width="9" height="9" viewBox="0 0 10 10"><circle cx="5" cy="5" r="4" fill="#ffb454" /></svg>
                <svg width="9" height="9" viewBox="0 0 10 10"><circle cx="5" cy="5" r="4" fill="#2fe6c8" /></svg>
                <span className="ml-2 font-mono text-[10px] tracking-[0.18em] text-fog">yuno://attract-mode</span>
                <span className="ml-auto flex items-center gap-1.5 font-mono text-[9px] tracking-[0.2em] text-ember">
                  <span className="w-1.5 h-1.5 rounded-full bg-ember pulse-dot-ember" /> LIVE
                </span>
              </div>
              <GamePlayer config={DEMO_CONFIG} />
              <div className="px-4 py-3 border-t border-line flex items-center justify-between gap-3 flex-wrap">
                <span className="font-mono text-[10px] tracking-[0.14em] text-fog">
                  GENERATED GAME — RUNNING ON YOUR GPU, NOT A SERVER
                </span>
                <div className="flex items-center gap-1.5">
                  <IconKey label="←" /><IconKey label="→" /><IconKey label="SPACE" wide /><IconKey label="P" />
                </div>
              </div>
            </div>
            <p className="mt-4 text-center font-mono text-[10.5px] tracking-[0.16em] text-fog/80">
              THE DEMO ABOVE IS A REAL YUNO BUILD. CLICK IT AND PLAY.
            </p>
          </div>
        </div>
      </div>

      {/* marquee */}
      <div className="mt-16 border-y border-line bg-ink2/60 overflow-hidden py-3 select-none">
        <div className="marquee-track flex w-max gap-0 whitespace-nowrap">
          {[0, 1].map((dup) => (
            <div key={dup} className="flex items-center">
              {tickerItems.map((t, i) => (
                <span key={dup + "-" + i} className="flex items-center gap-6 px-6 font-mono text-[11px] tracking-[0.22em] text-fog">
                  <span className={i % 4 === 1 ? "text-ember" : i % 4 === 3 ? "text-teal" : ""}>{t}</span>
                  <svg width="7" height="7" viewBox="0 0 8 8"><path d="M4 0 8 4 4 8 0 4z" fill="#303a52" /></svg>
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
