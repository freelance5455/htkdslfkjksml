import React from 'react';

interface SyntaxCodeBlockProps {
  code: string;
  filePath?: string;
  searchQuery?: string;
}

function escapeHtml(raw: string): string {
  return raw
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function highlightLine(line: string, ext: string): string {
  const escaped = escapeHtml(line);
  if (!escaped.trim()) return '&nbsp;';

  // Comment line
  const trimmed = line.trim();
  if (trimmed.startsWith('//') || trimmed.startsWith('#') || trimmed.startsWith('<!--')) {
    return `<span class="text-slate-400 dark:text-slate-500 italic">${escaped}</span>`;
  }

  // XML / HTML tags
  if (ext === 'xml' || ext === 'html' || ext === 'htm' || ext === 'svg') {
    return escaped
      .replace(
        /(&lt;\/?[a-zA-Z0-9_:-]+)/g,
        '<span class="text-[#3B82F6] dark:text-[#60A5FA]">$1</span>'
      )
      .replace(
        /([a-zA-Z0-9_:-]+)(=)(&quot;[^&]*&quot;|"[^"]*")/g,
        '<span class="text-[#6366F1] dark:text-[#A5B4FC]">$1</span>$2<span class="text-[#22C55E] dark:text-[#4ADE80]">$3</span>'
      );
  }

  // Strings
  let out = escaped.replace(
    /("[^"]*"|'[^']*'|`[^`]*`)/g,
    '<span class="text-emerald-600 dark:text-emerald-400">$1</span>'
  );

  // Keywords
  out = out.replace(
    /\b(import|export|from|const|let|var|function|return|async|await|if|else|for|while|switch|case|break|try|catch|throw|new|class|interface|type|package|fun|val|override|private|public|protected|object|companion|true|false|null|void|int|boolean)\b/g,
    '<span class="text-[#6366F1] dark:text-[#818CF8] font-medium">$1</span>'
  );

  // Numbers
  out = out.replace(
    /\b(\d+(?:\.\d+)?)\b/g,
    '<span class="text-amber-600 dark:text-amber-400">$1</span>'
  );

  return out;
}

export const SyntaxCodeBlock: React.FC<SyntaxCodeBlockProps> = ({
  code,
  filePath = '',
  searchQuery = '',
}) => {
  const ext = filePath.split('.').pop()?.toLowerCase() || '';
  const lines = code.split('\n');
  const queryLower = searchQuery.trim().toLowerCase();

  return (
    <div className="font-mono text-xs leading-6 select-text">
      {lines.map((line, idx) => {
        const isMatch = queryLower.length > 0 && line.toLowerCase().includes(queryLower);
        const html = highlightLine(line, ext);
        return (
          <div
            key={idx}
            className={`flex px-4 ${
              isMatch
                ? 'bg-[#EAB308]/15 border-l-2 border-[#EAB308]'
                : 'hover:bg-slate-100/70 dark:hover:bg-white/[0.03]'
            }`}
          >
            <span className="w-11 shrink-0 pr-4 text-right text-[11px] text-slate-400 dark:text-slate-600 tabular-nums select-none">
              {idx + 1}
            </span>
            <span
              className="flex-1 whitespace-pre text-slate-800 dark:text-[#E2E8F0]"
              dangerouslySetInnerHTML={{ __html: html }}
            />
          </div>
        );
      })}
    </div>
  );
};
