import React from 'react';
import { Moon, Sparkles, Clock, Compass } from 'lucide-react';
import { NightTimings, PrayerSettings } from '../types/prayer';
import { formatPrayerTime } from '../utils/prayerCalculator';

interface NightTimingsCardProps {
  nightTimings: NightTimings;
  settings: PrayerSettings;
}

export const NightTimingsCard: React.FC<NightTimingsCardProps> = ({ nightTimings, settings }) => {
  const hoursDuration = (nightTimings.nightDurationMinutes / 60).toFixed(1);

  return (
    <div className="rounded-3xl border border-indigo-900/50 bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950/40 p-6 sm:p-8 shadow-xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-indigo-400 text-xs font-semibold uppercase tracking-wider">
            <Moon className="w-4 h-4" />
            <span>Islamic Night Breakdown (অর্ধরাত ও তাহাজ্জুদ)</span>
          </div>
          <h2 className="mt-1 text-xl font-bold text-white tracking-tight">
            Islamic Night Timings & Tahajjud Hours
          </h2>
          <p className="mt-1 text-xs text-slate-300">
            Calculated astronomically from Sunset (Maghrib {formatPrayerTime(nightTimings.maghrib, settings.timeFormat)}) to Dawn (Fajr {formatPrayerTime(nightTimings.fajr, settings.timeFormat)}) · Total night span: {hoursDuration} hours.
          </p>
        </div>
      </div>

      {/* 3 Core Divisions Grid */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* First Third */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">First Third</span>
            <Clock className="w-4 h-4 text-slate-400" />
          </div>
          <div className="mt-3 font-mono text-2xl font-bold text-white tabular-nums">
            {formatPrayerTime(nightTimings.firstThird, settings.timeFormat)}
          </div>
          <div className="mt-1 text-xs text-slate-400">
            End of early evening prayer window (1/3 of the night).
          </div>
        </div>

        {/* Islamic Midnight */}
        <div className="rounded-2xl border border-indigo-800/60 bg-indigo-950/40 p-5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-indigo-300">Islamic Midnight (Nisf al-Layl)</span>
            <Moon className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="mt-3 font-mono text-2xl font-bold text-indigo-200 tabular-nums">
            {formatPrayerTime(nightTimings.midnight, settings.timeFormat)}
          </div>
          <div className="mt-1 text-xs text-indigo-300/80">
            Midpoint between sunset and dawn. Recommended cutoff for Isha prayer.
          </div>
        </div>

        {/* Last Third / Tahajjud */}
        <div className="rounded-2xl border border-emerald-800/80 bg-gradient-to-br from-emerald-950/60 to-slate-900 p-5 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              Last Third (Tahajjud Window)
            </span>
          </div>
          <div className="mt-3 font-mono text-2xl font-bold text-emerald-300 tabular-nums">
            {formatPrayerTime(nightTimings.lastThird, settings.timeFormat)}
          </div>
          <div className="mt-1 text-xs text-emerald-200/80">
            The blessed time of divine descent when Du'a is answered until Fajr ({formatPrayerTime(nightTimings.fajr, settings.timeFormat)}).
          </div>
        </div>
      </div>

      {/* Visual Timeline Bar */}
      <div className="mt-6 pt-5 border-t border-slate-800/80">
        <div className="text-xs font-semibold text-slate-300 mb-2">Nocturnal Sequence Overview:</div>
        <div className="relative flex items-center justify-between text-[11px] text-slate-400 font-mono">
          <div className="text-left">
            <div className="text-slate-300 font-bold">Maghrib</div>
            <div>{formatPrayerTime(nightTimings.maghrib, settings.timeFormat)}</div>
          </div>
          <div className="text-center">
            <div className="text-slate-300 font-bold">First 1/3</div>
            <div>{formatPrayerTime(nightTimings.firstThird, settings.timeFormat)}</div>
          </div>
          <div className="text-center text-indigo-300">
            <div className="font-bold">Midnight</div>
            <div>{formatPrayerTime(nightTimings.midnight, settings.timeFormat)}</div>
          </div>
          <div className="text-center text-emerald-400">
            <div className="font-bold">Tahajjud 2/3</div>
            <div>{formatPrayerTime(nightTimings.lastThird, settings.timeFormat)}</div>
          </div>
          <div className="text-right">
            <div className="text-slate-300 font-bold">Fajr</div>
            <div>{formatPrayerTime(nightTimings.fajr, settings.timeFormat)}</div>
          </div>
        </div>
      </div>
    </div>
  );
};
