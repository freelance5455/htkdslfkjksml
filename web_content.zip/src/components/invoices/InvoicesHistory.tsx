import React, { useState } from 'react';
import { 
  Receipt, Search, Eye, RotateCcw, Download, Calendar, 
  CheckCircle2, Clock, AlertCircle, DollarSign, TrendingUp, CreditCard,
  ChevronDown, ChevronUp, Package, Printer, User, FileText
} from 'lucide-react';
import { Invoice, StoreSettings } from '../../types';

interface Props {
  invoices: Invoice[];
  settings: StoreSettings;
  onViewInvoice: (invoice: Invoice) => void;
  onReturnInvoice: (invoiceId: string) => void;
}

export const InvoicesHistory: React.FC<Props> = ({
  invoices,
  settings,
  onViewInvoice,
  onReturnInvoice,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'paid' | 'pending' | 'returned'>('all');
  const [paymentMethodFilter, setPaymentMethodFilter] = useState<string>('all');
  const [expandedInvoiceId, setExpandedInvoiceId] = useState<string | null>(null);

  // Toggle invoice details
  const toggleExpand = (invoiceId: string) => {
    setExpandedInvoiceId((prev) => (prev === invoiceId ? null : invoiceId));
  };

  // Stats calculation
  const totalRevenue = invoices
    .filter((i) => i.status !== 'returned')
    .reduce((sum, i) => sum + i.grandTotal, 0);

  const totalTax = invoices
    .filter((i) => i.status !== 'returned')
    .reduce((sum, i) => sum + i.taxAmount, 0);

  const totalPendingDebt = invoices
    .filter((i) => i.status === 'pending')
    .reduce((sum, i) => sum + i.grandTotal, 0);

  // Filtered invoices
  const filteredInvoices = invoices.filter((inv) => {
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !q ||
      inv.invoiceNumber.toLowerCase().includes(q) ||
      (inv.customerName && inv.customerName.toLowerCase().includes(q)) ||
      (inv.customerPhone && inv.customerPhone.includes(q));

    const matchesStatus = statusFilter === 'all' || inv.status === statusFilter;
    const matchesMethod =
      paymentMethodFilter === 'all' || inv.paymentMethod === paymentMethodFilter;

    return matchesSearch && matchesStatus && matchesMethod;
  });

  // Export CSV
  const handleExportCSV = () => {
    const headers = ['رقم الفاتورة', 'التاريخ', 'اسم العميل', 'عدد الأصناف', 'طريقة الدفع', 'الإجمالي', 'الضريبة', 'الحالة'];
    const rows = invoices.map((inv) => [
      `"${inv.invoiceNumber}"`,
      `"${new Date(inv.date).toLocaleDateString('ar-SA')}"`,
      `"${inv.customerName || 'عميل نقدي'}"`,
      inv.items.reduce((s, i) => s + i.quantity, 0),
      `"${inv.paymentMethod}"`,
      inv.grandTotal,
      inv.taxAmount,
      `"${inv.status}"`,
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `sales_invoices_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 overflow-hidden">
      {/* Top Header & Metrics */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Receipt className="w-5 h-5 text-emerald-400" />
              سجل الفواتير والمبيعات
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              استعراض وطباعة الفواتير السابقة، إدارة المرتجعات وتدقيق الإيرادات
            </p>
          </div>

          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 rounded-xl text-xs font-semibold border border-slate-700 transition"
          >
            <Download className="w-4 h-4" />
            <span>تصدير فواتير CSV</span>
          </button>
        </div>

        {/* Summary Metrics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400">إجمالي المبيعات المحققة</span>
            <div className="text-lg font-black font-mono text-emerald-400 mt-0.5">
              {totalRevenue.toFixed(2)}{' '}
              <small className="text-xs font-normal text-slate-500">{settings.currency}</small>
            </div>
          </div>

          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400">إجمالي ضريبة القيمة المضافة</span>
            <div className="text-lg font-black font-mono text-blue-400 mt-0.5">
              {totalTax.toFixed(2)}{' '}
              <small className="text-xs font-normal text-slate-500">{settings.currency}</small>
            </div>
          </div>

          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400">مبالغ آجلة معلقة (ذمم)</span>
            <div className="text-lg font-black font-mono text-amber-400 mt-0.5">
              {totalPendingDebt.toFixed(2)}{' '}
              <small className="text-xs font-normal text-slate-500">{settings.currency}</small>
            </div>
          </div>

          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400">إجمالي عدد الفواتير</span>
            <div className="text-lg font-black font-mono text-white mt-0.5">
              {invoices.length}{' '}
              <small className="text-xs font-normal text-slate-500">عملية بيع</small>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-1">
          <div className="relative w-full sm:w-80">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث برقم الفاتورة أو اسم العميل..."
              className="w-full bg-slate-950 border border-slate-700 rounded-xl pr-9 pl-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-1">
            {/* Status Pills */}
            <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
              {[
                { id: 'all', label: 'الكل' },
                { id: 'paid', label: 'مدفوعة' },
                { id: 'pending', label: 'آجلة' },
                { id: 'returned', label: 'مرتجعة' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setStatusFilter(tab.id as any)}
                  className={`px-3 py-1 rounded-lg font-medium transition ${
                    statusFilter === tab.id
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Payment method selector */}
            <select
              value={paymentMethodFilter}
              onChange={(e) => setPaymentMethodFilter(e.target.value)}
              className="bg-slate-950 border border-slate-700 text-slate-300 text-xs rounded-xl px-3 py-2 focus:outline-none"
            >
              <option value="all">كل طرق الدفع</option>
              <option value="cash">نقدي (كاش)</option>
              <option value="card">بطاقة / شبكة</option>
              <option value="debt">آجل</option>
            </select>
          </div>
        </div>
      </div>

      {/* Invoices List Table */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-850 border-b border-slate-800 text-slate-400 font-semibold">
                <tr>
                  <th className="p-3.5 w-10 text-center">تفصيل</th>
                  <th className="p-3.5">رقم الفاتورة</th>
                  <th className="p-3.5">التاريخ والوقت</th>
                  <th className="p-3.5">العميل</th>
                  <th className="p-3.5 text-center">الأصناف</th>
                  <th className="p-3.5 text-center">طريقة الدفع</th>
                  <th className="p-3.5 text-center">المبلغ الإجمالي</th>
                  <th className="p-3.5 text-center">الحالة</th>
                  <th className="p-3.5 text-left">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredInvoices.map((invoice) => {
                  const itemsCount = invoice.items.reduce((s, i) => s + i.quantity, 0);
                  const isExpanded = expandedInvoiceId === invoice.id;

                  return (
                    <React.Fragment key={invoice.id}>
                      <tr 
                        className={`hover:bg-slate-850/40 transition cursor-pointer ${
                          isExpanded ? 'bg-slate-850/60 border-l-4 border-l-blue-500' : ''
                        }`}
                        onClick={() => toggleExpand(invoice.id)}
                      >
                        <td className="p-3.5 text-center" onClick={(e) => { e.stopPropagation(); toggleExpand(invoice.id); }}>
                          <button
                            className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition"
                            title={isExpanded ? 'إخفاء التفاصيل' : 'عرض تفاصيل الأصناف'}
                          >
                            {isExpanded ? (
                              <ChevronUp className="w-4 h-4 text-blue-400" />
                            ) : (
                              <ChevronDown className="w-4 h-4" />
                            )}
                          </button>
                        </td>

                        <td className="p-3.5 font-mono font-bold text-blue-400">
                          <div className="flex items-center gap-1.5">
                            <span>{invoice.invoiceNumber}</span>
                            <span className="text-[10px] font-normal text-slate-500 bg-slate-800/80 px-1.5 py-0.2 rounded">
                              {invoice.items.length} نوع
                            </span>
                          </div>
                        </td>

                        <td className="p-3.5 text-slate-400">
                          {new Date(invoice.date).toLocaleDateString('ar-SA')}{' '}
                          <span className="text-[10px] text-slate-500">
                            {new Date(invoice.date).toLocaleTimeString('ar-SA', {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </td>

                        <td className="p-3.5">
                          <div className="font-semibold text-white">
                            {invoice.customerName || 'عميل نقدي سريع'}
                          </div>
                          {invoice.customerPhone && (
                            <div className="text-[10px] text-slate-500 font-mono">
                              {invoice.customerPhone}
                            </div>
                          )}
                        </td>

                        <td className="p-3.5 text-center font-mono font-semibold text-slate-300">
                          {itemsCount}
                        </td>

                        <td className="p-3.5 text-center">
                          <span className="inline-block px-2 py-0.5 rounded text-[11px] font-medium bg-slate-800 text-slate-300 border border-slate-700">
                            {invoice.paymentMethod === 'cash' && 'نقدي (كاش)'}
                            {invoice.paymentMethod === 'card' && 'شبكة / مدى'}
                            {invoice.paymentMethod === 'debt' && 'آجل (ذمم)'}
                            {invoice.paymentMethod === 'split' && 'متعدد'}
                          </span>
                        </td>

                        <td className="p-3.5 text-center font-mono font-bold text-sm text-emerald-400">
                          {invoice.grandTotal.toFixed(2)}{' '}
                          <small className="text-[10px] font-normal text-slate-400">
                            {settings.currency}
                          </small>
                        </td>

                        <td className="p-3.5 text-center">
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                              invoice.status === 'paid'
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                : invoice.status === 'pending'
                                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                                : 'bg-red-500/10 text-red-400 border border-red-500/20'
                            }`}
                          >
                            {invoice.status === 'paid'
                              ? 'مدفوعة'
                              : invoice.status === 'pending'
                              ? 'آجلة'
                              : 'مرتجعة'}
                          </span>
                        </td>

                        <td className="p-3.5 text-left" onClick={(e) => e.stopPropagation()}>
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => toggleExpand(invoice.id)}
                              className={`flex items-center gap-1 px-2 py-1.5 rounded-lg text-xs font-semibold transition ${
                                isExpanded
                                  ? 'bg-blue-600 text-white'
                                  : 'bg-slate-800 text-slate-300 hover:text-white'
                              }`}
                              title="عرض تفاصيل الأصناف المحاسبية"
                            >
                              <FileText className="w-3.5 h-3.5" />
                              <span className="hidden sm:inline">
                                {isExpanded ? 'طي' : 'تفاصيل'}
                              </span>
                            </button>

                            <button
                              onClick={() => onViewInvoice(invoice)}
                              className="flex items-center gap-1 px-2.5 py-1.5 bg-blue-600/10 text-blue-400 hover:bg-blue-600/20 rounded-lg text-xs font-semibold transition"
                              title="معاينة وطباعة الفاتورة"
                            >
                              <Printer className="w-3.5 h-3.5" />
                              <span className="hidden sm:inline">طباعة</span>
                            </button>

                            {invoice.status !== 'returned' && (
                              <button
                                onClick={() => {
                                  if (
                                    confirm(
                                      `هل أنت متأكد من تسجيل إرجاع الفاتورة رقم (${invoice.invoiceNumber}) وإعادة الأصناف للمخزون؟`
                                    )
                                  ) {
                                    onReturnInvoice(invoice.id);
                                  }
                                }}
                                className="p-1.5 bg-slate-800 text-slate-400 hover:text-red-400 rounded-lg transition"
                                title="إرجاع الفاتورة واسترداد المخزون"
                              >
                                <RotateCcw className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>

                      {/* Expanded Detailed Breakdown Row */}
                      {isExpanded && (
                        <tr className="bg-slate-950/90">
                          <td colSpan={9} className="p-4 border-t border-b border-slate-800/80">
                            <div className="bg-slate-900 border border-slate-750 rounded-xl p-4 shadow-inner space-y-4">
                              {/* Expanded Header */}
                              <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
                                <div className="flex items-center gap-3">
                                  <div className="p-2 bg-blue-600/20 text-blue-400 rounded-lg border border-blue-500/30">
                                    <Receipt className="w-4 h-4" />
                                  </div>
                                  <div>
                                    <h4 className="font-bold text-white text-sm flex items-center gap-2">
                                      تفاصيل الفاتورة رقم: <span className="font-mono text-blue-400">{invoice.invoiceNumber}</span>
                                    </h4>
                                    <p className="text-[11px] text-slate-400">
                                      التاريخ: {new Date(invoice.date).toLocaleString('ar-SA')} | الكاشير: {invoice.cashierName}
                                    </p>
                                  </div>
                                </div>

                                <div className="flex items-center gap-2">
                                  <button
                                    onClick={() => onViewInvoice(invoice)}
                                    className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition shadow-sm"
                                  >
                                    <Printer className="w-3.5 h-3.5" />
                                    <span>فتح شاشة الطباعة الكاملة (حراري / A4)</span>
                                  </button>
                                </div>
                              </div>

                              {/* Detailed Items Table */}
                              <div className="overflow-x-auto">
                                <table className="w-full text-right text-xs">
                                  <thead className="bg-slate-950/80 text-slate-400 font-semibold border-b border-slate-800">
                                    <tr>
                                      <th className="p-2.5">#</th>
                                      <th className="p-2.5">اسم الصنف</th>
                                      <th className="p-2.5">الباركود</th>
                                      <th className="p-2.5 text-center">الكمية</th>
                                      <th className="p-2.5 text-center">سعر الوحدة</th>
                                      <th className="p-2.5 text-center">الخصم</th>
                                      <th className="p-2.5 text-left">الإجمالي</th>
                                    </tr>
                                  </thead>
                                  <tbody className="divide-y divide-slate-800/40">
                                    {invoice.items.map((item, idx) => {
                                      const itemSubtotal = item.quantity * item.product.sellingPrice;
                                      const itemFinal = itemSubtotal * (1 - item.discountPercent / 100);

                                      return (
                                        <tr key={idx} className="hover:bg-slate-800/30">
                                          <td className="p-2.5 font-mono text-slate-500">{idx + 1}</td>
                                          <td className="p-2.5 font-semibold text-white">
                                            <div className="flex items-center gap-1.5">
                                              <Package className="w-3.5 h-3.5 text-slate-500" />
                                              <span>{item.product.name}</span>
                                            </div>
                                            {item.product.nameEn && (
                                              <span className="text-[10px] text-slate-500 block">
                                                {item.product.nameEn}
                                              </span>
                                            )}
                                          </td>
                                          <td className="p-2.5 font-mono text-slate-400 text-[11px]">
                                            {item.product.barcode}
                                          </td>
                                          <td className="p-2.5 text-center font-bold text-white font-mono">
                                            {item.quantity} {item.product.unit || 'حبة'}
                                          </td>
                                          <td className="p-2.5 text-center font-mono text-slate-300">
                                            {item.product.sellingPrice.toFixed(2)} {settings.currency}
                                          </td>
                                          <td className="p-2.5 text-center">
                                            {item.discountPercent > 0 ? (
                                              <span className="text-red-400 font-bold font-mono">
                                                {item.discountPercent}%
                                              </span>
                                            ) : (
                                              <span className="text-slate-600">-</span>
                                            )}
                                          </td>
                                          <td className="p-2.5 text-left font-bold font-mono text-emerald-400">
                                            {itemFinal.toFixed(2)} {settings.currency}
                                          </td>
                                        </tr>
                                      );
                                    })}
                                  </tbody>
                                </table>
                              </div>

                              {/* Detailed Calculation Summary Footer */}
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-slate-800 text-xs">
                                <div className="space-y-1.5 text-slate-300 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                                  <div className="text-[11px] font-bold text-slate-400 pb-1 border-b border-slate-800 flex items-center gap-1">
                                    <User className="w-3.5 h-3.5 text-blue-400" />
                                    بيانات المعاملة والعميل
                                  </div>
                                  <div className="flex justify-between text-[11px]">
                                    <span className="text-slate-500">اسم العميل:</span>
                                    <span className="font-semibold text-white">{invoice.customerName || 'عميل نقدي'}</span>
                                  </div>
                                  {invoice.customerPhone && (
                                    <div className="flex justify-between text-[11px]">
                                      <span className="text-slate-500">الهاتف:</span>
                                      <span className="font-mono text-slate-300">{invoice.customerPhone}</span>
                                    </div>
                                  )}
                                  <div className="flex justify-between text-[11px]">
                                    <span className="text-slate-500">الكاشير المسؤول:</span>
                                    <span className="text-slate-300">{invoice.cashierName}</span>
                                  </div>
                                  <div className="flex justify-between text-[11px]">
                                    <span className="text-slate-500">طريقة الدفع:</span>
                                    <span className="font-bold text-blue-400">
                                      {invoice.paymentMethod === 'cash' && 'نقدي (كاش)'}
                                      {invoice.paymentMethod === 'card' && 'شبكة / مدى / بطاقة'}
                                      {invoice.paymentMethod === 'debt' && 'آجل (ذمم)'}
                                      {invoice.paymentMethod === 'split' && 'دفع متعدد'}
                                    </span>
                                  </div>
                                </div>

                                <div className="space-y-1.5 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                                  <div className="text-[11px] font-bold text-slate-400 pb-1 border-b border-slate-800">
                                    ملخص الحسابات والضرائب
                                  </div>
                                  <div className="flex justify-between text-slate-400">
                                    <span>المجموع قبل الضريبة:</span>
                                    <span className="font-mono font-medium text-white">{invoice.subtotal.toFixed(2)} {settings.currency}</span>
                                  </div>
                                  {invoice.discountAmount > 0 && (
                                    <div className="flex justify-between text-red-400">
                                      <span>قيمة الخصم:</span>
                                      <span className="font-mono">-{invoice.discountAmount.toFixed(2)} {settings.currency}</span>
                                    </div>
                                  )}
                                  <div className="flex justify-between text-slate-400">
                                    <span>ضريبة القيمة المضافة ({invoice.taxRate}%):</span>
                                    <span className="font-mono text-blue-400">{invoice.taxAmount.toFixed(2)} {settings.currency}</span>
                                  </div>
                                  <div className="flex justify-between text-sm font-bold text-emerald-400 pt-1.5 border-t border-slate-800">
                                    <span>الإجمالي النهائي المستحق:</span>
                                    <span className="font-mono text-base">{invoice.grandTotal.toFixed(2)} {settings.currency}</span>
                                  </div>
                                  {invoice.paymentMethod === 'cash' && (
                                    <div className="flex justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-850">
                                      <span>المدفوع: {invoice.amountPaid.toFixed(2)} {settings.currency}</span>
                                      <span className="text-emerald-400">المتبقي: {invoice.changeAmount.toFixed(2)} {settings.currency}</span>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>

          {filteredInvoices.length === 0 && (
            <div className="p-12 text-center text-slate-500">
              <Receipt className="w-12 h-12 mx-auto mb-2 opacity-40 stroke-1" />
              <p className="text-sm">لا توجد فواتير مطابقة لبحثك</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
