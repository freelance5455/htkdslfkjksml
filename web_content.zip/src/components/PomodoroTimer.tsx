import React from 'react';
import { Pause, Play, RotateCcw, SkipForward } from 'lucide-react';
import type { Language, PomodoroPhase } from '../types/study';
import { PomodoroVectorIcon } from './LiquidIcons';

interface PomodoroTimerProps {
  lang: Language;
  phase: PomodoroPhase;
  secondsLeft: number;
  totalSeconds: number;
  isRunning: boolean;
  completedSessions: number;
  onSelectPhase: (phase: PomodoroPhase) => void;
  onToggleRun: () => void;
  onReset: () => void;
  onSkip: () => void;
}

const PHASE_META: Record<
  PomodoroPhase,
  { labelBn: string; labelEn: string; stroke: string }
> = {
  study: {
    labelBn: 'স্টাডি (২৫ মি.)',
    labelEn: 'Study (25m)',
    stroke: '#38bdf8',
  },
  shortBreak: {
    labelBn: 'ব্রেইক (৫ মি.)',
    labelEn: 'Break (5m)',
    stroke: '#34d399',
  },
  longBreak: {
    labelBn: 'লং ব্রেইক (১৫ মি.)',
    labelEn: 'Long Break (15m)',
    stroke: '#a78bfa',
  },
};

function formatMMSS(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return `${String(m).padStart(2, '0')}:${String(rem).padStart(2, '0')}`;
}

export const PomodoroTimer: React.FC<PomodoroTimerProps> = ({
  lang,
  phase,
  secondsLeft,
  totalSeconds,
  isRunning,
  completedSessions,
  onSelectPhase,
  onToggleRun,
  onReset,
  onSkip,
}) => {
  const isBn = lang === 'bn';
  const meta = PHASE_META[phase];
  const phaseLabel = isBn ? meta.labelBn : meta.labelEn;
  const radius = 112;
  const circumference = 2 * Math.PI * radius;
  const progress = totalSeconds > 0 ? Math.max(0, Math.min(1, secondsLeft / totalSeconds)) : 0;
  const dashOffset = circumference * (1 - progress);

  return (
    <div className="mx-auto max-w-3xl">
      <section className="liquid-glass rounded-3xl p-6 sm:p-8">
        <div className="mb-5 flex items-center justify-center gap-2.5 text-slate-200">
          <PomodoroVectorIcon active className="h-5 w-5 text-sky-300" />
          <h2 className="text-base font-semibold text-white">
            {isBn ? 'পোমোডোরো' : 'Pomodoro'}
          </h2>
        </div>

        {/* Segmented Phase Switcher */}
        <div className="mx-auto flex max-w-lg items-center gap-1.5 rounded-2xl border border-white/20 bg-white/6 p-1.5 backdrop-blur-md">
          {(
            [
              ['study', isBn ? 'স্টাডি (২৫:০০)' : 'Study (25:00)'],
              ['shortBreak', isBn ? 'ব্রেইক (০৫:০০)' : 'Break (05:00)'],
              ['longBreak', isBn ? 'লং ব্রেইক (১৫:০০)' : 'Long (15:00)'],
            ] as Array<[PomodoroPhase, string]>
          ).map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => onSelectPhase(key)}
              className={`min-h-[42px] flex-1 rounded-xl px-3 py-2 text-xs font-semibold transition whitespace-nowrap ${
                phase === key
                  ? 'bg-white text-slate-950 shadow-sm'
                  : 'text-slate-300 hover:bg-white/10 hover:text-white'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Visual Animated SVG Timer Ring */}
        <div className="relative mx-auto mt-8 flex h-[272px] w-[272px] items-center justify-center sm:h-[296px] sm:w-[296px]">
          {isRunning && (
            <div
              aria-hidden="true"
              className="pomodoro-glow pointer-events-none absolute inset-3 rounded-full"
              style={{
                background: `radial-gradient(circle, ${meta.stroke}28 0%, transparent 70%)`,
              }}
            />
          )}

          <svg
            viewBox="0 0 260 260"
            className="h-full w-full -rotate-90"
            role="img"
            aria-label={`${phaseLabel} ${formatMMSS(secondsLeft)}`}
          >
            <circle
              cx="130"
              cy="130"
              r={radius}
              fill="none"
              stroke="rgba(255, 255, 255, 0.12)"
              strokeWidth="12"
            />
            <circle
              cx="130"
              cy="130"
              r={radius}
              fill="none"
              stroke={meta.stroke}
              strokeWidth="12"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={dashOffset}
              style={{ transition: 'stroke-dashoffset 0.5s linear, stroke 0.3s ease' }}
            />
          </svg>

          <div className="absolute inset-0 flex flex-col items-center justify-center px-6 text-center">
            <span className="text-xs font-medium text-slate-300">{phaseLabel}</span>
            <div className="font-mono-tabular mt-2 text-5xl font-bold tracking-tight text-white sm:text-6xl">
              {formatMMSS(secondsLeft)}
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <button
            type="button"
            onClick={onReset}
            aria-label={isBn ? 'রিসেট' : 'Reset'}
            className="inline-flex min-h-[48px] items-center gap-2 rounded-xl border border-white/20 bg-white/10 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-white/20 whitespace-nowrap"
          >
            <RotateCcw className="h-4 w-4" aria-hidden="true" />
            <span>{isBn ? 'রিসেট' : 'Reset'}</span>
          </button>

          <button
            type="button"
            onClick={onToggleRun}
            className="inline-flex min-h-[48px] min-w-[160px] items-center justify-center gap-2 rounded-xl bg-sky-400 px-6 py-2.5 text-sm font-semibold text-slate-950 shadow-sm transition hover:bg-sky-300 whitespace-nowrap"
          >
            {isRunning ? (
              <>
                <Pause className="h-4 w-4" aria-hidden="true" />
                <span>{isBn ? 'পজ' : 'Pause'}</span>
              </>
            ) : (
              <>
                <Play className="h-4 w-4" aria-hidden="true" />
                <span>{isBn ? 'শুরু' : 'Start'}</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={onSkip}
            aria-label={isBn ? 'পরবর্তী' : 'Next'}
            className="inline-flex min-h-[48px] items-center gap-2 rounded-xl border border-white/20 bg-white/10 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-white/20 whitespace-nowrap"
          >
            <SkipForward className="h-4 w-4" aria-hidden="true" />
            <span>{isBn ? 'পরবর্তী' : 'Next'}</span>
          </button>
        </div>

        <div className="mt-7 flex items-center justify-center border-t border-white/10 pt-4 text-xs text-slate-300 tabular-nums">
          <span>
            {isBn ? `আজকের সেশন: ${completedSessions}` : `Sessions Today: ${completedSessions}`}
          </span>
        </div>
      </section>
    </div>
  );
};
