import React, { useState, useEffect } from 'react';
import { PomodoroMode, TaskItem } from '../types';
import { Play, Pause, RotateCcw, SkipForward, Flame, Sparkles, CloudRain, Trees, Wind, Waves, Volume2, VolumeX, ShieldAlert, Headphones, Bell, BellRing } from 'lucide-react';
import { playPomodoroCompleteSound, playCoinSound, startAmbientSound, stopAmbientSound, setAmbientVolume, AmbientSoundType } from '../utils/soundEffects';
import { triggerConfetti } from '../utils/confetti';
import { sendBackgroundNotification, requestNotificationPermission, getNotificationPermission } from '../utils/notifications';

interface PomodoroTimerProps {
  onSessionComplete: (earnedCoins: number, earnedXp: number, taskId?: string) => void;
  tasks: TaskItem[];
  soundEnabled: boolean;
  initialLinkedTaskId?: string;
}

export const PomodoroTimer: React.FC<PomodoroTimerProps> = ({
  onSessionComplete,
  tasks,
  soundEnabled,
  initialLinkedTaskId,
}) => {
  const [mode, setMode] = useState<PomodoroMode>('focus');
  const [focusMinutes, setFocusMinutes] = useState(25);
  const [shortBreakMinutes, setShortBreakMinutes] = useState(5);
  const [longBreakMinutes, setLongBreakMinutes] = useState(15);
  const [timeLeft, setTimeLeft] = useState(focusMinutes * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState<string>(initialLinkedTaskId || '');
  const [completedSessionsCount, setCompletedSessionsCount] = useState(0);

  // Expanded Ambient Sounds State
  const [ambientSound, setAmbientSound] = useState<AmbientSoundType>('rain');
  const [ambientVol, setAmbientVol] = useState<number>(0.6);
  const [previewPlaying, setPreviewPlaying] = useState(false);

  // Set total duration for current mode
  const getTotalDuration = () => {
    if (mode === 'focus') return focusMinutes * 60;
    if (mode === 'shortBreak') return shortBreakMinutes * 60;
    return longBreakMinutes * 60;
  };

  const totalDuration = getTotalDuration();

  // Reset timer on mode change
  useEffect(() => {
    setTimeLeft(getTotalDuration());
    setIsRunning(false);
  }, [mode, focusMinutes, shortBreakMinutes, longBreakMinutes]);

  // Update selected task if changed externally
  useEffect(() => {
    if (initialLinkedTaskId) {
      setSelectedTaskId(initialLinkedTaskId);
    }
  }, [initialLinkedTaskId]);

  // Ambient sound management
  useEffect(() => {
    if (soundEnabled && (isRunning || previewPlaying) && ambientSound !== 'none') {
      startAmbientSound(ambientSound, ambientVol);
    } else {
      stopAmbientSound();
    }

    return () => {
      stopAmbientSound();
    };
  }, [isRunning, previewPlaying, ambientSound, soundEnabled]);

  // Handle volume changes
  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVol = parseFloat(e.target.value);
    setAmbientVol(newVol);
    setAmbientVolume(newVol);
  };

  // Timer tick
  useEffect(() => {
    let interval: any = null;
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && isRunning) {
      setIsRunning(false);
      handleComplete();
    }
    return () => clearInterval(interval);
  }, [isRunning, timeLeft]);

  const handleComplete = () => {
    stopAmbientSound();
    setPreviewPlaying(false);

    // Background notification for finished session
    sendBackgroundNotification(
      mode === 'focus' ? '⏰ انتهت جلسة التركيز! - وقتي' : '☕ انتهت الاستراحة! - وقتي',
      {
        body:
          mode === 'focus'
            ? 'أحسنت صنعاً! أتممت 25 دقيقة من العمل العميق وحصلت على +30 نقطة و +50 خبرة XP 🏆'
            : 'حان وقت العودة لجلسة تركيز جديدة وإنجاز المزيد من الأهداف 🚀',
      }
    );

    if (soundEnabled) {
      playPomodoroCompleteSound();
      setTimeout(playCoinSound, 600);
    }
    triggerConfetti();

    if (mode === 'focus') {
      const earnedCoins = 30;
      const earnedXp = 50;
      setCompletedSessionsCount((c) => c + 1);
      onSessionComplete(earnedCoins, earnedXp, selectedTaskId || undefined);

      if ((completedSessionsCount + 1) % 4 === 0) {
        setMode('longBreak');
      } else {
        setMode('shortBreak');
      }
    } else {
      setMode('focus');
    }
  };

  const toggleTimer = () => {
    setPreviewPlaying(false);
    setIsRunning(!isRunning);
  };

  const resetTimer = () => {
    setIsRunning(false);
    setPreviewPlaying(false);
    stopAmbientSound();
    setTimeLeft(getTotalDuration());
  };

  const skipTimer = () => {
    setIsRunning(false);
    setPreviewPlaying(false);
    stopAmbientSound();
    if (mode === 'focus') {
      setMode('shortBreak');
    } else {
      setMode('focus');
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const progressPercent = ((totalDuration - timeLeft) / totalDuration) * 100;
  const strokeDashoffset = 283 - (283 * progressPercent) / 100;

  const linkedTask = tasks.find((t) => t.id === selectedTaskId);

  return (
    <div className="flex flex-col items-center justify-center py-4 px-2 max-w-md mx-auto">
      
      {/* Strict Rule Notice if Task is Selected */}
      {linkedTask && (
        <div className="w-full mb-4 p-3 rounded-2xl bg-amber-950/40 border border-amber-500/40 text-amber-200 text-xs leading-relaxed flex items-center gap-2.5 shadow-md text-right">
          <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0" />
          <div>
            <span className="font-black text-amber-300">مهمة نشطة: «{linkedTask.title}»</span>
            <p className="text-[11px] text-amber-200/80 mt-0.5">
              ⚠️ بموجب قانون الإنتاجية الصارم، يجب إتمام جلسة 25 دقيقة كاملة لإتاحة وسم هذه المهمة كمكتملة.
            </p>
          </div>
        </div>
      )}

      {/* Mode Selector Tabs */}
      <div className="flex bg-slate-900/80 p-1.5 rounded-2xl border border-slate-800 mb-5 shadow-inner w-full max-w-xs">
        <button
          onClick={() => setMode('focus')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            mode === 'focus'
              ? 'bg-gradient-to-r from-indigo-600 to-indigo-500 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          تركيز (25 د)
        </button>
        <button
          onClick={() => setMode('shortBreak')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            mode === 'shortBreak'
              ? 'bg-gradient-to-r from-emerald-600 to-teal-500 text-white shadow-md shadow-emerald-600/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          استراحة (5 د)
        </button>
        <button
          onClick={() => setMode('longBreak')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            mode === 'longBreak'
              ? 'bg-gradient-to-r from-purple-600 to-indigo-500 text-white shadow-md shadow-purple-600/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          راحة طويلة (15 د)
        </button>
      </div>

      {/* Circular Progress Ring */}
      <div className="relative w-64 h-64 sm:w-72 sm:h-72 flex items-center justify-center my-2">
        <div
          className={`absolute inset-4 rounded-full blur-2xl opacity-20 transition-colors duration-700 pointer-events-none ${
            mode === 'focus'
              ? 'bg-indigo-500'
              : mode === 'shortBreak'
              ? 'bg-emerald-500'
              : 'bg-purple-500'
          }`}
        />

        <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 100 100">
          <circle
            cx="50"
            cy="50"
            r="45"
            className="stroke-slate-900/90"
            strokeWidth="5"
            fill="transparent"
          />
          <circle
            cx="50"
            cy="50"
            r="45"
            className={`transition-all duration-500 ${
              mode === 'focus'
                ? 'stroke-indigo-500'
                : mode === 'shortBreak'
                ? 'stroke-emerald-400'
                : 'stroke-purple-400'
            }`}
            strokeWidth="6"
            strokeDasharray="283"
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            fill="transparent"
          />
        </svg>

        {/* Center Timer Display */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="text-5xl sm:text-6xl font-black font-mono tracking-tight text-white drop-shadow-md">
            {formatTime(timeLeft)}
          </span>
          <span className="text-xs font-extrabold uppercase tracking-widest mt-2 px-3 py-1 rounded-full bg-slate-900/90 border border-slate-800 text-slate-300">
            {mode === 'focus' ? '🎯 وضع التركيز العميق' : mode === 'shortBreak' ? '☕ استراحة قصيرة' : '🌿 استراحة مستحقة'}
          </span>

          {mode === 'focus' && (
            <div className="flex items-center gap-1.5 mt-2.5 text-[11px] text-amber-300 font-bold bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>مكافأة: +30 نقطة & +50 XP</span>
            </div>
          )}
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-4 mt-5">
        <button
          onClick={resetTimer}
          className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800 transition-all cursor-pointer"
          title="إعادة ضبط المؤقت"
        >
          <RotateCcw className="w-5 h-5" />
        </button>

        <button
          onClick={toggleTimer}
          className={`py-4 px-8 rounded-2xl font-black text-lg flex items-center gap-2 shadow-xl transition-all duration-200 transform hover:scale-105 active:scale-95 cursor-pointer ${
            isRunning
              ? 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-600/30'
              : 'bg-gradient-to-r from-indigo-600 via-indigo-500 to-purple-600 text-white shadow-indigo-600/40'
          }`}
        >
          {isRunning ? (
            <>
              <Pause className="w-6 h-6 fill-white" />
              <span>إيقاف مؤقت</span>
            </>
          ) : (
            <>
              <Play className="w-6 h-6 fill-white" />
              <span>ابدأ التركيز</span>
            </>
          )}
        </button>

        <button
          onClick={skipTimer}
          className="p-3 rounded-2xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800 transition-all cursor-pointer"
          title="تخطي الجلسة"
        >
          <SkipForward className="w-5 h-5" />
        </button>
      </div>

      {/* ===================== AMBIENT NATURE SOUNDS EXPANDED PANEL ===================== */}
      <div className="w-full max-w-sm mt-6 p-4 rounded-3xl bg-slate-900/90 border border-slate-800/90 shadow-xl text-right">
        
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-1.5 text-xs font-black text-slate-200">
            <Headphones className="w-4 h-4 text-indigo-400" />
            <span>الأصوات الطبيعية والضوضاء البيضاء:</span>
          </div>

          {/* Test / Preview Button */}
          <button
            type="button"
            onClick={() => {
              if (ambientSound === 'none') {
                setAmbientSound('rain');
                setPreviewPlaying(true);
              } else {
                setPreviewPlaying(!previewPlaying);
              }
            }}
            className={`px-2.5 py-1 rounded-xl text-[10px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
              previewPlaying
                ? 'bg-emerald-500 text-white shadow-sm shadow-emerald-500/30'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
            }`}
          >
            {previewPlaying ? <Volume2 className="w-3 h-3" /> : <VolumeX className="w-3 h-3" />}
            <span>{previewPlaying ? 'إيقاف المعاينة' : 'معاينة الصوت 🎧'}</span>
          </button>
        </div>

        {/* Ambient Sound Selection Chips */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 mb-3">
          <button
            type="button"
            onClick={() => setAmbientSound('rain')}
            className={`py-2 px-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              ambientSound === 'rain'
                ? 'bg-indigo-600 border-indigo-400 text-white shadow-md'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <CloudRain className="w-3.5 h-3.5 text-cyan-400" />
            <span>صوت المطر</span>
          </button>

          <button
            type="button"
            onClick={() => setAmbientSound('forest')}
            className={`py-2 px-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              ambientSound === 'forest'
                ? 'bg-indigo-600 border-indigo-400 text-white shadow-md'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Trees className="w-3.5 h-3.5 text-emerald-400" />
            <span>الغابة والطيور</span>
          </button>

          <button
            type="button"
            onClick={() => setAmbientSound('whitenoise')}
            className={`py-2 px-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              ambientSound === 'whitenoise'
                ? 'bg-indigo-600 border-indigo-400 text-white shadow-md'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Wind className="w-3.5 h-3.5 text-purple-400" />
            <span>ضوضاء بيضاء</span>
          </button>

          <button
            type="button"
            onClick={() => setAmbientSound('waves')}
            className={`py-2 px-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              ambientSound === 'waves'
                ? 'bg-indigo-600 border-indigo-400 text-white shadow-md'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Waves className="w-3.5 h-3.5 text-blue-400" />
            <span>أمواج البحر</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setAmbientSound('none');
              setPreviewPlaying(false);
              stopAmbientSound();
            }}
            className={`col-span-2 sm:col-span-1 py-2 px-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              ambientSound === 'none'
                ? 'bg-slate-800 border-slate-600 text-white'
                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <VolumeX className="w-3.5 h-3.5" />
            <span>صامت (بدون)</span>
          </button>
        </div>

        {/* Volume Slider Control */}
        {ambientSound !== 'none' && (
          <div className="pt-2 border-t border-slate-800/80">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
              <span>مستوى صوت الخلفية الطبيعية:</span>
              <span className="font-mono text-indigo-400 font-bold">{Math.round(ambientVol * 100)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={ambientVol}
              onChange={handleVolumeChange}
              className="w-full accent-indigo-500 bg-slate-950 rounded-lg cursor-pointer h-1.5"
            />
          </div>
        )}
      </div>

      {/* Link to Task Selector */}
      {tasks.length > 0 && mode === 'focus' && (
        <div className="w-full max-w-sm mt-4 p-3 rounded-2xl bg-slate-900/60 border border-slate-800/80">
          <label className="block text-xs font-bold text-slate-300 mb-1.5 text-right">
            📌 المهمة المرتبطة بجلسة الـ 25 دقيقة:
          </label>
          <select
            value={selectedTaskId}
            onChange={(e) => setSelectedTaskId(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 text-right"
          >
            <option value="">(جلسة تركيز عامة - غير مرتبطة بمهمة)</option>
            {tasks
              .filter((t) => !t.isCompleted)
              .map((t) => (
                <option key={t.id} value={t.id}>
                  {t.title} ({t.completedPomodoros}/{t.estimatedPomodoros} بومودورو)
                </option>
              ))}
          </select>
        </div>
      )}

      {/* Daily Progress summary & Background Notification Toggle */}
      <div className="flex flex-wrap items-center justify-between gap-2 w-full max-w-sm mt-4 text-xs">
        <div className="flex items-center gap-1.5 text-slate-400 font-medium">
          <Flame className="w-4 h-4 text-orange-400" />
          <span>
            أتممت <strong className="text-white font-extrabold">{completedSessionsCount}</strong> جلسات اليوم
          </span>
        </div>

        <button
          type="button"
          onClick={async () => {
            const granted = await requestNotificationPermission();
            if (granted) {
              sendBackgroundNotification('🔔 إشعارات الخلفية جاهزة ومفعلة!', {
                body: 'ستصلك تنبيهات انتهاء التايمر وتذكيرات المهام في الخلفية حتى عند إغلاق أو تصغير الشاشة 🚀',
              });
            }
          }}
          className="flex items-center gap-1.5 py-1 px-2.5 rounded-xl bg-slate-900 border border-slate-800 text-indigo-300 hover:text-white hover:bg-indigo-600/30 transition-all cursor-pointer font-bold"
        >
          <Bell className="w-3.5 h-3.5 text-indigo-400" />
          <span>إشعارات الخلفية 🔔</span>
        </button>
      </div>

    </div>
  );
};
