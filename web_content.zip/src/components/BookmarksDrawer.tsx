import React from 'react';
import { Bookmark as BookmarkType, Manhwa } from '../types';
import { Bookmark, X, BookOpen, Trash2 } from 'lucide-react';
import { SmartImage } from './SmartImage';

interface BookmarksDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  bookmarks: BookmarkType[];
  manhwas: Manhwa[];
  onSelectManhwa: (manhwa: Manhwa) => void;
  onRemoveBookmark: (bookmarkId: string) => void;
}

export const BookmarksDrawer: React.FC<BookmarksDrawerProps> = ({
  isOpen,
  onClose,
  bookmarks,
  manhwas,
  onSelectManhwa,
  onRemoveBookmark
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex justify-end">
      <div className="w-full max-w-md bg-[#0e1424] h-full p-6 flex flex-col border-r border-white/5 shadow-2xl relative">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/5 mb-6">
          <div className="flex items-center gap-2">
            <Bookmark className="w-5 h-5 text-pink-500 fill-current" />
            <h2 className="text-lg font-bold text-white">قائمة المفضلة ({bookmarks.length})</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/5 text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content List */}
        <div className="flex-1 overflow-y-auto no-scrollbar space-y-3">
          {bookmarks.length > 0 ? (
            bookmarks.map((bm) => {
              const matchingManhwa = manhwas.find((m) => m.id === bm.manhwaId);

              return (
                <div
                  key={bm.id}
                  className="p-3 bg-[#151b2d] rounded-2xl border border-white/5 flex gap-3 items-center justify-between hover:border-purple-500/30 transition-all group"
                >
                  <SmartImage
                    src={bm.manhwaCover}
                    alt={bm.manhwaTitle}
                    fallbackText={bm.manhwaTitle}
                    className="w-full h-full object-cover"
                    aspectRatio="aspect-[3/4]"
                    containerClassName="w-14 h-20 rounded-xl border border-white/10 shrink-0"
                  />

                  <div className="flex-1 min-w-0">
                    <h3 className="text-xs font-bold text-white truncate mb-1">{bm.manhwaTitle}</h3>
                    <span className="text-[10px] text-gray-400 block mb-2 font-mono">
                      أضيفت في {new Date(bm.createdAt).toLocaleDateString('ar-EG')}
                    </span>

                    <div className="flex items-center gap-2">
                      {matchingManhwa && (
                        <button
                          onClick={() => {
                            onSelectManhwa(matchingManhwa);
                            onClose();
                          }}
                          className="px-2.5 py-1 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-[10px] font-bold flex items-center gap-1"
                        >
                          <BookOpen className="w-3 h-3" />
                          <span>فتح المانهوا</span>
                        </button>
                      )}

                      <button
                        onClick={() => onRemoveBookmark(bm.id)}
                        className="p-1 text-gray-400 hover:text-red-400 transition-colors"
                        title="إزالة من المفضلة"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="py-20 text-center text-xs text-gray-500">
              لم تقم بإضافة أي مانهوا إلى المفضلة بعد.
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
