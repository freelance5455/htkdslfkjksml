import React, { useState } from 'react';
import { UserProfile, TaskItem } from '../types';
import { Bot, Sparkles, Send, PlusCircle, Check, Lightbulb, RefreshCw, X } from 'lucide-react';
import { playLevelUpSound, playCoinSound } from '../utils/soundEffects';

interface AICoachModalProps {
  user: UserProfile;
  tasks: TaskItem[];
  initialTaskTitle?: string;
  onAddTask: (task: Omit<TaskItem, 'id' | 'createdAt' | 'completedPomodoros' | 'isCompleted'>) => void;
  onClose?: () => void;
  soundEnabled: boolean;
}

export const AICoachModal: React.FC<AICoachModalProps> = ({
  user,
  tasks,
  initialTaskTitle,
  onAddTask,
  onClose,
  soundEnabled,
}) => {
  const [prompt, setPrompt] = useState(initialTaskTitle ? `أريد تفكيك هذه المهمة بدقة: "${initialTaskTitle}"` : '');
  const [loading, setLoading] = useState(false);
  const [responseHtml, setResponseHtml] = useState<string>('');
  const [suggestedTasks, setSuggestedTasks] = useState<string[]>([]);
  const [addedTasksIndexes, setAddedTasksIndexes] = useState<number[]>([]);

  const askCoach = async (customPrompt?: string, mode: string = 'custom_chat') => {
    const textToSend = customPrompt || prompt;
    if (!textToSend.trim() && !initialTaskTitle) return;

    setLoading(true);
    setResponseHtml('');
    setSuggestedTasks([]);
    setAddedTasksIndexes([]);

    try {
      const activeTaskTitles = tasks.filter((t) => !t.isCompleted).map((t) => t.title);
      const completedToday = tasks.filter((t) => t.isCompleted).length;

      const res = await fetch('/api/gemini/coach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode,
          taskTitle: initialTaskTitle,
          prompt: textToSend,
          currentStats: {
            completedToday,
            totalPomodoros: 6,
            currentStreak: user.streak,
            activeTasks: activeTaskTitles,
          },
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'فشل الاتصال بالمساعد الذكي');

      setResponseHtml(data.advice || 'أحسنت السعي والتركيز!');
      if (soundEnabled) playLevelUpSound();

      // Extract bullet lines if any
      const lines = (data.advice || '').split('\n');
      const bullets = lines
        .map((l: string) => l.trim())
        .filter((l: string) => l.startsWith('-') || l.startsWith('*') || /^\d+\./.test(l))
        .map((l: string) => l.replace(/^[-*]|\d+\.\s*/, '').trim())
        .filter((l: string) => l.length > 5 && l.length < 80);

      if (bullets.length > 0) {
        setSuggestedTasks(bullets.slice(0, 5));
      }
    } catch (err: any) {
      setResponseHtml(`⚠️ ${err.message || 'تعذر الاتصال بالذكاء الاصطناعي حالياً. استمر في جلسات التركيز المعتادة!'}`);
    } finally {
      setLoading(false);
    }
  };

  const handleAddSuggestedTask = (title: string, index: number) => {
    onAddTask({
      title,
      category: 'ذكاء اصطناعي',
      priority: 'medium',
      estimatedPomodoros: 1,
    });
    setAddedTasksIndexes((prev) => [...prev, index]);
    if (soundEnabled) playCoinSound();
  };

  return (
    <div className="py-3 px-2 max-w-2xl mx-auto">
      
      {/* Hero Banner */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-cyan-950/60 via-slate-900 to-indigo-950/60 border border-cyan-500/30 mb-5 shadow-xl relative overflow-hidden text-right">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300 shadow-md">
              <Bot className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
                <span>«كابتن وقتي» المساعد الذكي للإنتاجية</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold">
                  Gemini 3.8 Flash
                </span>
              </h2>
              <p className="text-xs text-slate-300 mt-0.5">
                تفكيك المهام المعقدة، تحليل إنتاجيتك، وخطط بومودورو التكتيكية
              </p>
            </div>
          </div>

          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Quick Action Presets */}
        <div className="flex flex-wrap gap-2 mt-4 pt-3 border-t border-slate-800/80">
          <button
            onClick={() => {
              setPrompt('أشعر بالتشتت والمماطلة اليوم، أعطني استراتيجية سريعة بـ 3 خطوات للبدء فوراً وبكل حماس.');
              askCoach('أشعر بالتشتت والمماطلة اليوم، أعطني استراتيجية سريعة بـ 3 خطوات للبدء فوراً وبكل حماس.', 'productivity_advice');
            }}
            className="py-1.5 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 text-cyan-300 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
          >
            <span>⚡ قهر التسويف والمماطلة الآن</span>
          </button>

          <button
            onClick={() => {
              setPrompt('قم بتقسيم وتفكيك مشروع معقد إلى خطوات بومودورو ذرية قابلة للإنجاز.');
              askCoach('قم بتقسيم وتفكيك مشروع معقد إلى خطوات بومودورو ذرية قابلة للإنجاز.', 'task_breakdown');
            }}
            className="py-1.5 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 text-indigo-300 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>🪄 تفكيك مهمة لجلسات بومودورو</span>
          </button>

          <button
            onClick={() => {
              setPrompt('اقترح لي جدول تركيز ذكي لليوم يوازن بين العمل العميق والاستراحات المنعشة.');
              askCoach('اقترح لي جدول تركيز ذكي لليوم يوازن بين العمل العميق والاستراحات المنعشة.', 'smart_schedule');
            }}
            className="py-1.5 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 text-emerald-300 text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Lightbulb className="w-3.5 h-3.5" />
            <span>📅 جدول إنتاجية مقترح لليوم</span>
          </button>
        </div>
      </div>

      {/* Input box */}
      <div className="p-4 rounded-3xl bg-slate-900/90 border border-slate-800 mb-5 shadow-xl text-right">
        <label className="block text-xs font-bold text-slate-300 mb-2">
          ما الذي يشغل بالك أو تريد تفكيكه وتنظيمه الآن؟
        </label>
        <div className="flex gap-2">
          <textarea
            rows={2}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="مثال: لدي كتاب 150 صفحة أريد قراءته وتلخيصه خلال 3 أيام، كيف أقسمه؟"
            className="flex-1 bg-slate-950 border border-slate-800 rounded-2xl p-3 text-xs sm:text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 text-right leading-relaxed resize-none"
          />
          <button
            onClick={() => askCoach()}
            disabled={loading || !prompt.trim()}
            className="px-4 rounded-2xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-black text-xs sm:text-sm flex flex-col items-center justify-center gap-1 transition-all cursor-pointer disabled:opacity-50 shadow-md shadow-cyan-600/30"
          >
            {loading ? (
              <RefreshCw className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <Send className="w-4 h-4 rotate-180" />
                <span>إرسال</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Loading state */}
      {loading && (
        <div className="p-8 text-center rounded-3xl bg-slate-900/40 border border-slate-800 animate-pulse">
          <Bot className="w-10 h-10 text-cyan-400 mx-auto mb-3 animate-bounce" />
          <p className="text-sm font-bold text-cyan-300">«كابتن وقتي» يحلل التحدي ويصوغ خطة الإنجاز...</p>
          <p className="text-xs text-slate-500 mt-1 font-mono">Powered by Gemini AI</p>
        </div>
      )}

      {/* Response Display */}
      {responseHtml && !loading && (
        <div className="p-5 rounded-3xl bg-slate-900/90 border border-cyan-500/40 shadow-2xl text-right animate-in fade-in duration-200">
          <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
            <span className="text-xs font-black text-cyan-400 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" />
              <span>توجيهات كابتن وقتي الذكية:</span>
            </span>
          </div>

          <div className="text-xs sm:text-sm text-slate-200 leading-relaxed whitespace-pre-line font-medium">
            {responseHtml}
          </div>

          {/* Quick Add Extracted Subtasks to Tasks List */}
          {suggestedTasks.length > 0 && (
            <div className="mt-5 pt-4 border-t border-slate-800">
              <h4 className="text-xs font-bold text-indigo-300 mb-2.5 flex items-center gap-1.5">
                <PlusCircle className="w-4 h-4" />
                <span>إضافة الخطوات المستخلصة مباشرة إلى قائمة مهامك اليومية:</span>
              </h4>

              <div className="space-y-1.5">
                {suggestedTasks.map((step, idx) => {
                  const isAdded = addedTasksIndexes.includes(idx);
                  return (
                    <div
                      key={idx}
                      className="p-2 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs"
                    >
                      <span className="text-slate-300 truncate max-w-[280px] sm:max-w-[400px]">
                        {step}
                      </span>
                      <button
                        onClick={() => handleAddSuggestedTask(step, idx)}
                        disabled={isAdded}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all cursor-pointer ${
                          isAdded
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                            : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                        }`}
                      >
                        {isAdded ? (
                          <>
                            <Check className="w-3 h-3" />
                            <span>أضيفت</span>
                          </>
                        ) : (
                          <>
                            <PlusCircle className="w-3 h-3" />
                            <span>إضافة للمهام</span>
                          </>
                        )}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

    </div>
  );
};
