import React, { useState } from 'react';
import { Check, Plus, Trash2 } from 'lucide-react';
import type { BlockedAppItem, Language } from '../types/study';
import { FocusLockVectorIcon } from './LiquidIcons';

interface AppBlockerScreenProps {
  lang: Language;
  apps: BlockedAppItem[];
  selectedDurationMin: number;
  lockActive: boolean;
  lockRemainingSec: number;
  onToggleApp: (id: string) => void;
  onAddCustomApp: (name: string) => void;
  onRemoveCustomApp: (id: string) => void;
  onSelectDuration: (minutes: number) => void;
  onStartLock: () => void;
}

function formatMMSS(sec: number): string {
  const safe = Math.max(0, Math.floor(sec));
  const m = Math.floor(safe / 60);
  const s = safe % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export const AppBlockerScreen: React.FC<AppBlockerScreenProps> = ({
  lang,
  apps,
  selectedDurationMin,
  lockActive,
  lockRemainingSec,
  onToggleApp,
  onAddCustomApp,
  onRemoveCustomApp,
  onSelectDuration,
  onStartLock,
}) => {
  const [customAppName, setCustomAppName] = useState('');
  const [showBlockedOnly, setShowBlockedOnly] = useState(false);

  const isLockedRunning = lockActive && lockRemainingSec > 0;
  const blockedApps = apps.filter((a) => a.blocked);
  const visibleApps = showBlockedOnly ? blockedApps : apps;

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLockedRunning) return;
    const clean = customAppName.trim();
    if (!clean) return;
    onAddCustomApp(clean);
    setCustomAppName('');
  };

  return (
    <div className="mx-auto max-w-3xl">
      <section className="liquid-glass rounded-3xl p-5 sm:p-8">
        {/* Header */}
        <div className="flex flex-col gap-3 border-b border-white/12 pb-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl border border-sky-300/35 bg-sky-400/18 text-sky-200">
              <FocusLockVectorIcon active={isLockedRunning} className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-white">
                {lang === 'bn' ? 'অ্যাপ ব্লকার' : 'App Blocker'}
              </h2>
              <p className="text-xs text-slate-300 tabular-nums">
                {isLockedRunning
                  ? lang === 'bn'
                    ? `লক: ${formatMMSS(lockRemainingSec)}`
                    : `Locked: ${formatMMSS(lockRemainingSec)}`
                  : lang === 'bn'
                    ? `নির্বাচিত: ${blockedApps.length}টি`
                    : `Selected: ${blockedApps.length}`}
              </p>
            </div>
          </div>

          {!isLockedRunning && (
            <button
              type="button"
              disabled={blockedApps.length === 0}
              onClick={onStartLock}
              className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-sky-400 px-5 py-2 text-xs font-semibold text-slate-950 shadow-sm transition hover:bg-sky-300 disabled:opacity-45 whitespace-nowrap"
            >
              <FocusLockVectorIcon active className="h-4 w-4" />
              <span>
                {lang === 'bn'
                  ? selectedDurationMin === 60
                    ? '১ ঘণ্টা লক'
                    : selectedDurationMin === 120
                      ? '২ ঘণ্টা লক'
                      : '৩০ মিনিট লক'
                  : selectedDurationMin === 60
                    ? 'Lock 1 Hour'
                    : selectedDurationMin === 120
                      ? 'Lock 2 Hours'
                      : 'Lock 30 Min'}
              </span>
            </button>
          )}
        </div>

        <div className="mt-5 space-y-5">
          {/* Lock Duration Picker */}
          <div className="grid grid-cols-3 gap-2">
            {[
              { min: 30, labelBn: '৩০ মিনিট', labelEn: '30 Min' },
              { min: 60, labelBn: '১ ঘণ্টা', labelEn: '1 Hour' },
              { min: 120, labelBn: '২ ঘণ্টা', labelEn: '2 Hours' },
            ].map((opt) => (
              <button
                key={opt.min}
                type="button"
                disabled={isLockedRunning}
                onClick={() => onSelectDuration(opt.min)}
                className={`min-h-[44px] rounded-xl border px-3 py-2 text-xs font-semibold transition whitespace-nowrap disabled:cursor-not-allowed disabled:opacity-60 ${
                  selectedDurationMin === opt.min
                    ? 'border-sky-300/70 bg-sky-400 text-slate-950'
                    : 'border-white/18 bg-white/8 text-slate-200 hover:bg-white/15'
                }`}
              >
                {lang === 'bn' ? opt.labelBn : opt.labelEn}
              </button>
            ))}
          </div>

          {/* Add Phone App Input */}
          <form onSubmit={handleAdd} className="flex gap-2">
            <input
              type="text"
              value={customAppName}
              disabled={isLockedRunning}
              onChange={(e) => setCustomAppName(e.target.value)}
              placeholder={lang === 'bn' ? 'ফোনের অ্যাপের নাম লিখুন...' : 'Enter phone app name...'}
              maxLength={32}
              className="glass-input min-h-[44px] flex-1 rounded-xl px-3.5 text-sm disabled:opacity-50"
            />
            <button
              type="submit"
              disabled={isLockedRunning || !customAppName.trim()}
              className="inline-flex min-h-[44px] items-center gap-1.5 rounded-xl border border-white/20 bg-white/12 px-4 text-xs font-semibold text-white transition hover:bg-white/22 disabled:opacity-45 whitespace-nowrap shrink-0"
            >
              <Plus className="h-4 w-4" aria-hidden="true" />
              <span>{lang === 'bn' ? 'যোগ' : 'Add'}</span>
            </button>
          </form>

          {/* List Filter Switch: All Apps vs Blocked Apps List */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowBlockedOnly(false)}
              className={`min-h-[38px] rounded-xl px-3.5 py-1.5 text-xs font-semibold transition whitespace-nowrap ${
                !showBlockedOnly
                  ? 'bg-white text-slate-950'
                  : 'border border-white/15 bg-white/6 text-slate-200 hover:bg-white/14'
              }`}
            >
              {lang === 'bn' ? `সব অ্যাপ (${apps.length})` : `All Apps (${apps.length})`}
            </button>
            <button
              type="button"
              onClick={() => setShowBlockedOnly(true)}
              className={`min-h-[38px] rounded-xl px-3.5 py-1.5 text-xs font-semibold transition whitespace-nowrap ${
                showBlockedOnly
                  ? 'bg-white text-slate-950'
                  : 'border border-white/15 bg-white/6 text-slate-200 hover:bg-white/14'
              }`}
            >
              {lang === 'bn'
                ? `ব্লক তালিকা (${blockedApps.length})`
                : `Blocked List (${blockedApps.length})`}
            </button>
          </div>

          {/* Clean App List (Only App Name, No Extra Explanations) */}
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
            {visibleApps.map((app) => (
              <div
                key={app.id}
                className={`flex items-center justify-between gap-2 rounded-2xl p-3 ${
                  app.blocked ? 'liquid-glass-tile-active' : 'liquid-glass-tile'
                }`}
              >
                <button
                  type="button"
                  disabled={isLockedRunning}
                  onClick={() => onToggleApp(app.id)}
                  className="flex min-w-0 flex-1 items-center gap-3 text-left disabled:cursor-not-allowed"
                >
                  <span
                    className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border transition ${
                      app.blocked
                        ? 'border-sky-300/60 bg-sky-400 text-slate-950'
                        : 'border-white/20 bg-white/8 text-transparent'
                    }`}
                  >
                    <Check className="h-4 w-4" />
                  </span>
                  <span className="truncate text-sm font-semibold text-white">{app.name}</span>
                </button>

                {app.isCustom && !isLockedRunning && (
                  <button
                    type="button"
                    onClick={() => onRemoveCustomApp(app.id)}
                    aria-label={app.name}
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-slate-300 hover:bg-rose-500/20 hover:text-rose-200"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};
