import React, { useState } from 'react';
import { X, Check, Calendar as CalendarIcon, Clock, Sparkles } from 'lucide-react';

interface DateTimePickerModalProps {
  isOpen: boolean;
  type: 'date' | 'time';
  currentDateVal: string; // "16/05/2025" or "YYYY-MM-DD"
  currentTimeVal: string; // "08:46:00"
  onClose: () => void;
  onSaveDate: (newDateStr: string) => void;
  onSaveTime: (newTimeStr: string) => void;
}

export const DateTimePickerModal: React.FC<DateTimePickerModalProps> = ({
  isOpen,
  type,
  currentDateVal,
  currentTimeVal,
  onClose,
  onSaveDate,
  onSaveTime,
}) => {
  if (!isOpen) return null;

  // Parse current date
  let initialDay = 16;
  let initialMonth = 5;
  let initialYear = 2025;

  if (currentDateVal.includes('/')) {
    const parts = currentDateVal.split('/');
    initialDay = parseInt(parts[0], 10) || 16;
    initialMonth = parseInt(parts[1], 10) || 5;
    initialYear = parseInt(parts[2], 10) || 2025;
  }

  // Parse current time
  const timeParts = currentTimeVal.split(':');
  const initialHour = parseInt(timeParts[0], 10) || 8;
  const initialMinute = parseInt(timeParts[1], 10) || 46;
  const initialSecond = parseInt(timeParts[2], 10) || 0;

  const [day, setDay] = useState<number>(initialDay);
  const [month, setMonth] = useState<number>(initialMonth);
  const [year, setYear] = useState<number>(initialYear);

  const [hour, setHour] = useState<number>(initialHour);
  const [minute, setMinute] = useState<number>(initialMinute);
  const [second, setSecond] = useState<number>(initialSecond);

  const handleSave = () => {
    if (type === 'date') {
      const formattedDate = `${String(day).padStart(2, '0')}/${String(month).padStart(2, '0')}/${year}`;
      onSaveDate(formattedDate);
    } else {
      const formattedTime = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}:${String(second).padStart(2, '0')}`;
      onSaveTime(formattedTime);
    }
    onClose();
  };

  // Quick Kill Zone presets for time picker
  const killZonePresets = [
    { label: '07:00 PM (Asian Kill Zone)', h: 19, m: 0, s: 0 },
    { label: '02:00 AM (London Kill Zone)', h: 2, m: 0, s: 0 },
    { label: '07:00 AM (NY AM Kill Zone)', h: 7, m: 0, s: 0 },
    { label: '10:00 AM (London Close)', h: 10, m: 0, s: 0 },
    { label: '08:46 AM (Reference Timing)', h: 8, m: 46, s: 0 },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-900/40 backdrop-blur-xs p-0 sm:p-4">
      <div 
        className="w-full max-w-md bg-white rounded-t-3xl sm:rounded-2xl shadow-xl border border-slate-100 p-5 sm:p-6 overflow-hidden max-h-[90vh] flex flex-col animate-in fade-in slide-in-from-bottom-6 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-blue-50 text-blue-600">
              {type === 'date' ? <CalendarIcon size={20} /> : <Clock size={20} />}
            </div>
            <div>
              <h3 className="font-bold text-slate-800 text-base">
                {type === 'date' ? 'Select Start Date' : 'Select Start Time (NY)'}
              </h3>
              <p className="text-xs text-slate-400">
                {type === 'date' ? 'Enter date in DD/MM/YYYY' : 'New York Local Time (HH:mm:ss)'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition-colors"
            aria-label="Close"
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="py-4 space-y-4 overflow-y-auto">
          {type === 'date' ? (
            <div>
              <div className="grid grid-cols-3 gap-3">
                {/* Day */}
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Day (DD)</label>
                  <select
                    value={day}
                    onChange={(e) => setDay(parseInt(e.target.value, 10))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-center"
                  >
                    {Array.from({ length: 31 }, (_, i) => i + 1).map((d) => (
                      <option key={d} value={d}>
                        {String(d).padStart(2, '0')}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Month */}
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Month (MM)</label>
                  <select
                    value={month}
                    onChange={(e) => setMonth(parseInt(e.target.value, 10))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-center"
                  >
                    {[
                      { m: 1, name: '01 - Jan' },
                      { m: 2, name: '02 - Feb' },
                      { m: 3, name: '03 - Mar' },
                      { m: 4, name: '04 - Apr' },
                      { m: 5, name: '05 - May' },
                      { m: 6, name: '06 - Jun' },
                      { m: 7, name: '07 - Jul' },
                      { m: 8, name: '08 - Aug' },
                      { m: 9, name: '09 - Sep' },
                      { m: 10, name: '10 - Oct' },
                      { m: 11, name: '11 - Nov' },
                      { m: 12, name: '12 - Dec' },
                    ].map((item) => (
                      <option key={item.m} value={item.m}>
                        {item.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Year */}
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Year (YYYY)</label>
                  <input
                    type="number"
                    min={2000}
                    max={2040}
                    value={year}
                    onChange={(e) => setYear(parseInt(e.target.value, 10) || 2025)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-medium focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-center"
                  />
                </div>
              </div>

              {/* Native Date Picker Fallback / Quick input */}
              <div className="mt-4 pt-4 border-t border-slate-100">
                <label className="block text-xs text-slate-500 mb-1.5 font-medium">
                  Or pick from calendar:
                </label>
                <input
                  type="date"
                  value={`${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`}
                  onChange={(e) => {
                    if (e.target.value) {
                      const [y, m, d] = e.target.value.split('-');
                      setYear(parseInt(y, 10));
                      setMonth(parseInt(m, 10));
                      setDay(parseInt(d, 10));
                    }
                  }}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-medium"
                />
              </div>
            </div>
          ) : (
            <div>
              {/* Time pickers: Hour, Minute, Second */}
              <div className="grid grid-cols-3 gap-3">
                {/* Hour */}
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1 text-center">Hour (00-23)</label>
                  <select
                    value={hour}
                    onChange={(e) => setHour(parseInt(e.target.value, 10))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-mono font-bold text-center text-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                  >
                    {Array.from({ length: 24 }, (_, i) => i).map((h) => (
                      <option key={h} value={h}>
                        {String(h).padStart(2, '0')} ({h === 0 ? '12 AM' : h < 12 ? `${h} AM` : h === 12 ? '12 PM' : `${h - 12} PM`})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Minute */}
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1 text-center">Min (00-59)</label>
                  <select
                    value={minute}
                    onChange={(e) => setMinute(parseInt(e.target.value, 10))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-mono font-bold text-center text-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                  >
                    {Array.from({ length: 60 }, (_, i) => i).map((m) => (
                      <option key={m} value={m}>
                        {String(m).padStart(2, '0')}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Second */}
                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1 text-center">Sec (00-59)</label>
                  <select
                    value={second}
                    onChange={(e) => setSecond(parseInt(e.target.value, 10))}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800 font-mono font-bold text-center text-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                  >
                    {Array.from({ length: 60 }, (_, i) => i).map((s) => (
                      <option key={s} value={s}>
                        {String(s).padStart(2, '0')}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Quick Kill Zone Timing Presets */}
              <div className="mt-4 pt-3 border-t border-slate-100">
                <div className="flex items-center gap-1 text-xs font-semibold text-slate-500 mb-2">
                  <Sparkles size={14} className="text-amber-500" />
                  <span>Kill Zone Timing Presets:</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {killZonePresets.map((preset) => (
                    <button
                      key={preset.label}
                      type="button"
                      onClick={() => {
                        setHour(preset.h);
                        setMinute(preset.m);
                        setSecond(preset.s);
                      }}
                      className="text-left px-2.5 py-2 bg-slate-50 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-200 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 transition-colors cursor-pointer"
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl flex items-center gap-1.5 shadow-xs transition-colors"
          >
            <Check size={16} />
            <span>Apply</span>
          </button>
        </div>
      </div>
    </div>
  );
};
