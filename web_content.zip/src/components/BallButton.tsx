import React from 'react';
import { motion } from 'motion/react';
import { BallInfo } from '../types';
import { toPersianDigits } from '../utils/snooker';

interface BallButtonProps {
  ball: BallInfo;
  points: number;
  mode: 'hit' | 'miss' | 'foul';
  onClick: () => void;
  disabled?: boolean;
  className?: string;
  isWide?: boolean;
}

export const BallButton: React.FC<BallButtonProps> = ({
  ball,
  points,
  mode,
  onClick,
  disabled = false,
  className = '',
  isWide = false,
}) => {
  const isHit = mode === 'hit';
  const prefix = isHit ? '+' : '-';
  const displayPoints = prefix + toPersianDigits(points);

  return (
    <motion.button
      type="button"
      whileHover={{ scale: disabled ? 1 : 1.04, y: disabled ? 0 : -2 }}
      whileTap={{ scale: disabled ? 1 : 0.94 }}
      transition={{ type: 'spring', stiffness: 450, damping: 25 }}
      onClick={onClick}
      disabled={disabled}
      className={`relative group flex flex-col items-center justify-center p-2.5 rounded-2xl transition-all duration-150 focus:outline-none select-none cursor-pointer ${
        disabled ? 'opacity-40 cursor-not-allowed' : ''
      } ${
        isHit
          ? 'hover:ring-2 hover:ring-emerald-400/40'
          : 'hover:ring-2 hover:ring-rose-400/40'
      } ${className}`}
      style={{
        background: 'linear-gradient(180deg, rgba(30, 41, 59, 0.85) 0%, rgba(15, 23, 42, 0.95) 100%)',
        border: '1px solid rgba(51, 65, 85, 0.6)',
        boxShadow: '0 4px 14px rgba(0, 0, 0, 0.3)',
      }}
    >
      {/* 3D Ball Sphere */}
      <div className="relative flex items-center justify-center mb-1.5">
        <div
          className={`w-11 h-11 sm:w-12 sm:h-12 rounded-full relative flex items-center justify-center shadow-lg transition-transform group-hover:scale-105 ${
            ball.borderClass || ''
          }`}
          style={{
            background: ball.bgGradient,
            boxShadow: `0 6px 16px ${ball.shadowColor}, inset 0 -3px 6px rgba(0,0,0,0.4), inset 0 3px 6px rgba(255,255,255,0.35)`,
          }}
        >
          {/* Specular gloss highlight */}
          <div
            className="absolute top-1 left-2 w-3.5 h-2 rounded-full transform -rotate-25 opacity-70 pointer-events-none"
            style={{
              background: 'radial-gradient(ellipse at center, rgba(255,255,255,0.9) 0%, rgba(255,255,255,0) 80%)',
            }}
          />
          {/* Number on Ball (Snooker aesthetic) */}
          <span
            className="text-xs font-black tracking-tight"
            style={{
              color: ball.textColor,
              textShadow: ball.textColor === '#ffffff' ? '0 1px 2px rgba(0,0,0,0.7)' : 'none',
            }}
          >
            {toPersianDigits(points)}
          </span>
        </div>
      </div>

      {/* Label and Points */}
      <div className="flex flex-col items-center gap-0.5">
        <span className="text-xs font-semibold text-slate-200 group-hover:text-white">
          {ball.faName}
        </span>
        <span
          className={`text-[11px] font-bold px-1.5 py-0.5 rounded-full ${
            isHit
              ? 'text-emerald-400 bg-emerald-950/60 ring-1 ring-emerald-500/30'
              : 'text-rose-400 bg-rose-950/60 ring-1 ring-rose-500/30'
          }`}
        >
          {displayPoints}
        </span>
      </div>
    </motion.button>
  );
};
