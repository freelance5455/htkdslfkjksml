import { useEffect, useRef } from 'react';
import { SendHorizontal, Square } from 'lucide-react';
import type { ReplyLanguage } from '../types/chat';

interface ChatComposerProps {
  value: string;
  onChange: (value: string) => void;
  onSend: () => void;
  onStop: () => void;
  isStreaming: boolean;
  replyLanguage: ReplyLanguage;
  onChangeReplyLanguage: (lang: ReplyLanguage) => void;
}

export function ChatComposer({
  value,
  onChange,
  onSend,
  onStop,
  isStreaming,
  replyLanguage,
  onChangeReplyLanguage,
}: ChatComposerProps) {
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 150)}px`;
  }, [value]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      // On desktop keyboards, Enter sends; Shift+Enter inserts newline.
      if (window.matchMedia('(pointer: fine)').matches) {
        e.preventDefault();
        if (!isStreaming && value.trim()) {
          onSend();
        }
      }
    }
  };

  const canSend = value.trim().length > 0 && !isStreaming;

  return (
    <div className="shrink-0 border-t border-slate-200 bg-white/95 px-3 pt-2.5 pb-[max(0.75rem,env(safe-area-inset-bottom))] backdrop-blur-md sm:px-6 sm:pt-3 sm:pb-4">
      <div className="mx-auto max-w-3xl">
        {/* Thumb-accessible reply language preference */}
        <div className="mb-2 flex items-center justify-between gap-2">
          <span className="text-xs font-medium text-slate-500">
            Answer language
          </span>
          <div
            className="inline-flex items-center rounded-xl bg-slate-100 p-1"
            role="group"
            aria-label="Default AI reply language"
          >
            <button
              type="button"
              onClick={() => onChangeReplyLanguage('amharic')}
              className={`min-h-[34px] rounded-lg px-3 py-1 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                replyLanguage === 'amharic'
                  ? 'bg-white text-teal-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              አማርኛ (Default)
            </button>
            <button
              type="button"
              onClick={() => onChangeReplyLanguage('english')}
              className={`min-h-[34px] rounded-lg px-3 py-1 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                replyLanguage === 'english'
                  ? 'bg-white text-teal-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              English
            </button>
          </div>
        </div>

        {/* Question text box + prominent Send button */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (canSend) onSend();
          }}
          className="flex items-end gap-2 rounded-2xl border border-slate-300 bg-[#F8FAFC] p-1.5 transition-colors focus-within:border-[#0F766E] focus-within:bg-white focus-within:ring-2 focus-within:ring-teal-700/15"
        >
          <textarea
            ref={textareaRef}
            rows={1}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="በአማርኛ ወይም በእንግሊዝኛ ይጠይቁ... / Ask in Amharic or English..."
            aria-label="Ask a question in Amharic or English"
            className="max-h-[150px] min-h-[44px] flex-1 resize-none bg-transparent px-3 py-2.5 text-base leading-normal text-slate-900 placeholder:text-slate-400 focus:outline-none"
          />

          {isStreaming ? (
            <button
              type="button"
              onClick={onStop}
              aria-label="Stop generating answer"
              className="flex min-h-[46px] min-w-[46px] shrink-0 items-center justify-center gap-2 rounded-xl bg-slate-800 px-3.5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-slate-900 active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900 whitespace-nowrap"
            >
              <Square className="h-4 w-4 fill-current" aria-hidden="true" />
              <span className="hidden sm:inline">Stop</span>
            </button>
          ) : (
            <button
              type="submit"
              disabled={!canSend}
              aria-label="Send question"
              className="flex min-h-[46px] min-w-[46px] shrink-0 items-center justify-center gap-2 rounded-xl bg-[#0F766E] px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#0D655E] active:scale-[0.98] disabled:cursor-not-allowed disabled:bg-slate-200 disabled:text-slate-400 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 whitespace-nowrap"
            >
              <span>Send</span>
              <SendHorizontal className="h-4 w-4 shrink-0" aria-hidden="true" />
            </button>
          )}
        </form>
      </div>
    </div>
  );
}
