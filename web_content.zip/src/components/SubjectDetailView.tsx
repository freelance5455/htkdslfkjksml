import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  Sparkles, 
  BookOpen, 
  Volume2, 
  VolumeX, 
  CheckCircle2, 
  AlertCircle, 
  Bookmark, 
  RotateCcw, 
  Zap, 
  HelpCircle, 
  ChevronRight, 
  Flame, 
  Brain, 
  Trophy, 
  Clock, 
  Check, 
  X, 
  Share2, 
  Lightbulb, 
  FileText,
  Loader2,
  RefreshCw
} from 'lucide-react';
import { MCQQuestion, UserProfile, MistakeItem } from '../types';
import { 
  SUBJECT_SYLLABUS_MAP, 
  SyllabusTopic, 
  getRecommendedTopicForUser,
  getSubjectSyllabus 
} from '../data/subjectSyllabusData';
import { 
  LOCAL_STORAGE_MISTAKES_KEY, 
  LOCAL_STORAGE_BOOKMARKS_KEY,
  recordMistake,
  toggleBookmark,
  isQuestionBookmarked
} from '../lib/dailyQuestionEngine';
import { generateUnlimitedTopicQuestions } from '../lib/unlimitedQuestionSynthesizer';

interface SubjectDetailViewProps {
  subjectKey: string;
  targetExam: string;
  language: string;
  userProfile?: UserProfile;
  onBack: () => void;
  onIncrementQuestion?: () => void;
}

export default function SubjectDetailView({
  subjectKey,
  targetExam,
  language,
  userProfile,
  onBack,
  onIncrementQuestion
}: SubjectDetailViewProps) {
  // Current active sub-tab inside Subject Detail
  const [activeTab, setActiveTab] = useState<
    'lessons' | 'practice' | 'quiz' | 'mistakes' | 'bookmarks' | 'revision'
  >('lessons');

  const syllabus = getSubjectSyllabus(subjectKey);
  const [selectedTopic, setSelectedTopic] = useState<SyllabusTopic>(
    (syllabus?.topics && syllabus.topics.length > 0 ? syllabus.topics[0] : null) || {
      id: 'default',
      topicName: 'Core Foundations',
      topicNameBn: 'মৌলিক ধারণা',
      chapterNumber: 1,
      estimatedMinutes: 25,
      importance: 'High',
      conceptsSummary: { en: 'Core concepts for ' + targetExam, bn: 'পরীক্ষার মূল ধারণা', hi: 'मुख्य अवधारणाएं' },
      keyFormulasAndTricks: { en: [], bn: [], hi: [] },
      examTips: { en: '', bn: '', hi: '' },
      sampleQuestions: []
    }
  );

  // Synchronize topic when subjectKey changes
  useEffect(() => {
    const updatedSyllabus = getSubjectSyllabus(subjectKey);
    if (updatedSyllabus?.topics && updatedSyllabus.topics.length > 0 && updatedSyllabus.topics[0]) {
      setSelectedTopic(updatedSyllabus.topics[0]);
    }
  }, [subjectKey]);

  // AI Topic Recommendation
  const recommendation = getRecommendedTopicForUser(subjectKey, targetExam, 68);

  // Audio / Speech Synthesis state
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  // Practice state
  const [currentQIndex, setCurrentQIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswerChecked, setIsAnswerChecked] = useState<boolean>(false);
  const [isBookmarked, setIsBookmarked] = useState<boolean>(false);
  const [practiceQuestions, setPracticeQuestions] = useState<MCQQuestion[]>([]);
  const [aiGenerating, setAiGenerating] = useState<boolean>(false);
  const [isLoadingMore, setIsLoadingMore] = useState<boolean>(false);
  const [answeredResults, setAnsweredResults] = useState<Record<number, boolean>>({});

  // Quiz Mode state
  const [quizActive, setQuizActive] = useState<boolean>(false);
  const [quizIndex, setQuizIndex] = useState<number>(0);
  const [quizAnswers, setQuizAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);
  const [quizScore, setQuizScore] = useState<number>(0);

  // Mistakes & Bookmarks state
  const [mistakesList, setMistakesList] = useState<MistakeItem[]>([]);
  const [bookmarksList, setBookmarksList] = useState<MCQQuestion[]>([]);

  // Local storage helper for non-repeating seen questions
  const getSeenQuestionsList = (): string[] => {
    try {
      const key = `edumind_seen_questions_${(subjectKey || 'general').toLowerCase()}`;
      const stored = localStorage.getItem(key);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  };

  const markQuestionAsSeen = (questionText: string) => {
    if (!questionText) return;
    try {
      const key = `edumind_seen_questions_${(subjectKey || 'general').toLowerCase()}`;
      const list = getSeenQuestionsList();
      const snippet = questionText.trim().toLowerCase().slice(0, 45);
      if (!list.includes(snippet)) {
        list.push(snippet);
        if (list.length > 250) list.shift();
        localStorage.setItem(key, JSON.stringify(list));
      }
    } catch {}
  };

  // Load questions and local storage on mount / topic change
  useEffect(() => {
    loadMistakesAndBookmarks();
    setAnsweredResults({});
    
    const seenList = getSeenQuestionsList();
    const rawSeeds = selectedTopic.sampleQuestions && selectedTopic.sampleQuestions.length > 0
      ? [...selectedTopic.sampleQuestions]
      : [];

    // Filter out questions previously seen by this user, and shuffle remaining seeds
    const unseenSeeds = rawSeeds.filter(q => 
      !seenList.some(seen => q.question && q.question.toLowerCase().includes(seen.slice(0, 25)))
    );

    // If student has already completed all or most seed questions, immediately generate fresh AI questions
    if (unseenSeeds.length < 3) {
      handleGenerateAIQuestions();
    } else {
      // Shuffle unseen seeds so they never appear in identical order
      const randomizedSeeds = [...unseenSeeds].sort(() => Math.random() - 0.5);
      setPracticeQuestions(randomizedSeeds);
      setCurrentQIndex(0);
      setSelectedOption(null);
      setIsAnswerChecked(false);
      // Pre-fetch more unique questions in background for seamless unlimited experience
      handleFetchMoreQuestions(false, 10);
    }
  }, [selectedTopic, subjectKey]);

  useEffect(() => {
    if (practiceQuestions[currentQIndex]) {
      setIsBookmarked(isQuestionBookmarked(practiceQuestions[currentQIndex].id));
    }
  }, [currentQIndex, practiceQuestions]);

  const loadMistakesAndBookmarks = () => {
    try {
      const storedM = localStorage.getItem(LOCAL_STORAGE_MISTAKES_KEY);
      if (storedM) {
        const parsed: MistakeItem[] = JSON.parse(storedM);
        const filtered = parsed.filter(m => 
          (m.question.subject || '').toLowerCase() === subjectKey.toLowerCase()
        );
        setMistakesList(filtered);
      }

      const storedB = localStorage.getItem(LOCAL_STORAGE_BOOKMARKS_KEY);
      if (storedB) {
        const parsedB: MCQQuestion[] = JSON.parse(storedB);
        const filteredB = parsedB.filter(b => 
          (b.subject || '').toLowerCase() === subjectKey.toLowerCase()
        );
        setBookmarksList(filteredB);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // TTS Read Aloud function
  const handleToggleReadAloud = (textToRead: string) => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;
    const synth = window.speechSynthesis;

    if (isSpeaking) {
      synth.cancel();
      setIsSpeaking(false);
      return;
    }

    const cleanText = textToRead.replace(/[*#_`~]/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText.slice(0, 1000));
    utterance.lang = language === 'bn' ? 'bn-IN' : language === 'hi' ? 'hi-IN' : 'en-US';

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    synth.cancel();
    synth.speak(utterance);
  };

  // Append more questions continuously so practice is truly unlimited
  const handleFetchMoreQuestions = async (advanceImmediately: boolean = false, count: number = 10) => {
    if (isLoadingMore) return;
    try {
      setIsLoadingMore(true);
      const seenSnippets = getSeenQuestionsList().slice(-20);
      const res = await fetch('/api/classroom/unlimited-questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject: subjectKey,
          topic: selectedTopic.topicName,
          targetExam: targetExam,
          count: count,
          language: language,
          seenQuestionSnippets: seenSnippets,
          attemptNonce: `batch_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`
        })
      });

      let newBatch: MCQQuestion[] = [];
      if (res.ok) {
        const data = await res.json();
        if (data.questions && data.questions.length > 0) {
          newBatch = data.questions;
        }
      }

      // If backend response is empty or fails, use reliable client-side synthesizer so user is NEVER blocked
      if (newBatch.length === 0) {
        newBatch = generateUnlimitedTopicQuestions(subjectKey, selectedTopic.topicName, language, count, seenSnippets);
      }

      setPracticeQuestions(prev => {
        const existingIds = new Set(prev.map(q => q.id));
        const filteredNew = newBatch.filter(q => !existingIds.has(q.id));
        return [...prev, ...(filteredNew.length > 0 ? filteredNew : newBatch)];
      });

      if (advanceImmediately) {
        setCurrentQIndex(prev => prev + 1);
        setSelectedOption(null);
        setIsAnswerChecked(false);
      }
    } catch (err) {
      console.error('Error fetching more questions, using fallback:', err);
      const seenSnippets = getSeenQuestionsList().slice(-20);
      const fallbackBatch = generateUnlimitedTopicQuestions(subjectKey, selectedTopic.topicName, language, count, seenSnippets);
      setPracticeQuestions(prev => [...prev, ...fallbackBatch]);
      if (advanceImmediately) {
        setCurrentQIndex(prev => prev + 1);
        setSelectedOption(null);
        setIsAnswerChecked(false);
      }
    } finally {
      setIsLoadingMore(false);
    }
  };

  // Background auto-prefetch when reaching near end of current loaded batch
  useEffect(() => {
    if (practiceQuestions.length > 0 && currentQIndex >= practiceQuestions.length - 2 && !isLoadingMore) {
      handleFetchMoreQuestions(false, 10);
    }
  }, [currentQIndex, practiceQuestions.length, isLoadingMore]);

  // Generate dynamic AI questions if user requests fresh start
  const handleGenerateAIQuestions = async () => {
    try {
      setAiGenerating(true);
      const seenSnippets = getSeenQuestionsList().slice(-20);
      const res = await fetch('/api/classroom/unlimited-questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject: subjectKey,
          topic: selectedTopic.topicName,
          targetExam: targetExam,
          count: 10,
          language: language,
          seenQuestionSnippets: seenSnippets,
          attemptNonce: `fresh_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`
        })
      });

      let loadedQuestions: MCQQuestion[] = [];
      if (res.ok) {
        const data = await res.json();
        if (data.questions && data.questions.length > 0) {
          loadedQuestions = data.questions;
        }
      }

      if (loadedQuestions.length === 0) {
        loadedQuestions = generateUnlimitedTopicQuestions(subjectKey, selectedTopic.topicName, language, 10, seenSnippets);
      }

      setPracticeQuestions(loadedQuestions);
      setCurrentQIndex(0);
      setSelectedOption(null);
      setIsAnswerChecked(false);
      setAnsweredResults({});
    } catch (err) {
      console.error('Error generating AI questions:', err);
      const seenSnippets = getSeenQuestionsList().slice(-20);
      const fallback = generateUnlimitedTopicQuestions(subjectKey, selectedTopic.topicName, language, 10, seenSnippets);
      setPracticeQuestions(fallback);
      setCurrentQIndex(0);
      setSelectedOption(null);
      setIsAnswerChecked(false);
    } finally {
      setAiGenerating(false);
    }
  };

  const currentQ = practiceQuestions[currentQIndex];

  const handleCheckAnswer = () => {
    if (selectedOption === null || !currentQ) return;
    setIsAnswerChecked(true);
    markQuestionAsSeen(currentQ.question);

    const isCorrect = selectedOption === currentQ.correctOptionIndex;
    setAnsweredResults(prev => ({ ...prev, [currentQIndex]: isCorrect }));

    if (!isCorrect) {
      recordMistake(currentQ, selectedOption);
      loadMistakesAndBookmarks();
    } else {
      if (onIncrementQuestion) onIncrementQuestion();
    }
  };

  const handleNextQuestion = () => {
    if (currentQIndex < practiceQuestions.length - 1) {
      setCurrentQIndex(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswerChecked(false);
    } else {
      // Reached the end of loaded batch: instantly load and advance seamlessly!
      handleFetchMoreQuestions(true, 10);
    }
  };

  const handlePrevQuestion = () => {
    if (currentQIndex > 0) {
      setCurrentQIndex(prev => prev - 1);
      setSelectedOption(null);
      setIsAnswerChecked(false);
    }
  };

  const handleToggleBookmarkCurrent = () => {
    if (!currentQ) return;
    const newState = toggleBookmark(currentQ);
    setIsBookmarked(newState);
    loadMistakesAndBookmarks();
  };

  // Quiz submission
  const handleOptionSelectQuiz = (optIndex: number) => {
    setQuizAnswers(prev => ({ ...prev, [quizIndex]: optIndex }));
  };

  const handleSubmitQuiz = () => {
    let score = 0;
    practiceQuestions.forEach((q, idx) => {
      if (quizAnswers[idx] === q.correctOptionIndex) {
        score += 1;
      } else if (quizAnswers[idx] !== undefined) {
        recordMistake(q, quizAnswers[idx]);
      }
    });
    setQuizScore(score);
    setQuizSubmitted(true);
    loadMistakesAndBookmarks();
  };

  const getTopicDisplayName = (t: SyllabusTopic) => {
    if (language === 'bn') return t.topicNameBn;
    if (language === 'hi' && t.topicNameHi) return t.topicNameHi;
    return t.topicName;
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 text-slate-100 overflow-hidden font-sans">
      
      {/* 1. TOP NAV HEADER */}
      <div className="bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 py-3 shrink-0 flex items-center justify-between z-20">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl cursor-pointer transition-all active:scale-95 flex items-center gap-1.5 text-xs font-bold"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">{language === 'bn' ? 'লার্ন হাবে ফিরুন' : 'Back to Hub'}</span>
          </button>

          <div className="flex items-center gap-2">
            <span className="text-2xl">{syllabus.emoji}</span>
            <div>
              <h1 className="text-sm sm:text-base font-black text-white leading-tight">
                {language === 'bn' ? syllabus.displayName.bn : syllabus.displayName.en}
              </h1>
              <div className="flex items-center gap-2 text-[11px] text-slate-400">
                <span className="px-1.5 py-0.2 bg-purple-500/20 text-purple-300 font-bold rounded border border-purple-500/30">
                  {targetExam}
                </span>
                <span>• {syllabus.topics.length} {language === 'bn' ? 'টি অধ্যায়' : 'Chapters'}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Global TTS Speaker button */}
        <button
          onClick={() => {
            const summary = selectedTopic.conceptsSummary[language as 'en' | 'bn' | 'hi'] || selectedTopic.conceptsSummary.en;
            handleToggleReadAloud(`${selectedTopic.topicName}. ${summary}`);
          }}
          className={`p-2 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all ${
            isSpeaking 
              ? 'bg-amber-500 text-slate-950 animate-pulse font-black' 
              : 'bg-slate-800 hover:bg-slate-700 text-indigo-300 border border-slate-700'
          }`}
        >
          {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          <span className="hidden md:inline">{isSpeaking ? (language === 'bn' ? 'ভয়েস বন্ধ' : 'Stop Audio') : (language === 'bn' ? 'এআই ভয়েস শুনুন' : 'Voice Lecture')}</span>
        </button>
      </div>

      {/* 2. AI SMART RECOMMENDATION BANNER */}
      <div className="bg-gradient-to-r from-purple-950/60 via-indigo-950/60 to-slate-900 border-b border-indigo-500/20 px-4 py-2.5 flex items-center justify-between text-xs shrink-0">
        <div className="flex items-center gap-2 max-w-2xl">
          <div className="p-1.5 bg-purple-500/20 text-purple-300 rounded-lg shrink-0">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <span className="font-extrabold text-purple-300">
              {language === 'bn' ? 'এআই পরবর্তী স্টাডি পরামর্শ: ' : 'AI Next Study Suggestion: '}
            </span>
            <span className="text-slate-300 text-[11px]">
              {language === 'bn' ? recommendation.reasonBn : recommendation.reason}
            </span>
          </div>
        </div>

        <button
          onClick={() => {
            const found = syllabus.topics.find(t => t.topicName.includes(recommendation.recommendedTopic));
            if (found) setSelectedTopic(found);
          }}
          className="hidden sm:flex items-center gap-1 px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-[11px] rounded-lg cursor-pointer shrink-0 transition-all"
        >
          <span>{language === 'bn' ? 'অধ্যায় খুলুন' : 'Open Topic'}</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* 3. SUB-NAV TABS (Lessons, Practice, Quiz, Mistakes, Bookmarks, Revision) */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 py-1.5 flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0">
        {[
          { id: 'lessons', label: language === 'bn' ? '📚 এআই লেকচার ও কনসেপ্ট' : '📚 AI Lessons', icon: BookOpen },
          { id: 'practice', label: language === 'bn' ? '✍️ প্রশ্ন অনুশীলন' : '✍️ Practice Qs', icon: Zap },
          { id: 'quiz', label: language === 'bn' ? '⏱️ টপিক কুইজ' : '⏱️ Topic Quiz', icon: Trophy },
          { id: 'mistakes', label: `${language === 'bn' ? '❌ ভুল খাতা' : '❌ Mistakes'} (${mistakesList.length})`, icon: AlertCircle },
          { id: 'bookmarks', label: `${language === 'bn' ? '🔖 বুকমার্কস' : '🔖 Bookmarks'} (${bookmarksList.length})`, icon: Bookmark },
          { id: 'revision', label: language === 'bn' ? '⚡ স্মার্ট রিভিশন' : '⚡ Smart Revision', icon: RotateCcw }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === tab.id
                ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-600/30'
                : 'bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* 4. MAIN CONTENT BODY */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
        
        {/* ========================================================================= */}
        {/* TAB 1: AI LESSONS & CONCEPT LEARNING */}
        {/* ========================================================================= */}
        {activeTab === 'lessons' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Chapter / Topic Selection List */}
            <div className="lg:col-span-4 space-y-3">
              <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-1.5">
                <Brain className="w-4 h-4 text-indigo-400" />
                {language === 'bn' ? `${targetExam} সিলেবাস অধ্যায়সমূহ:` : `${targetExam} Syllabus Chapters:`}
              </h3>

              <div className="space-y-2">
                {syllabus.topics.map((topic, idx) => {
                  const isSelected = selectedTopic.id === topic.id;
                  return (
                    <button
                      key={topic.id}
                      onClick={() => {
                        setSelectedTopic(topic);
                      }}
                      className={`w-full text-left p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between group ${
                        isSelected
                          ? 'bg-gradient-to-r from-indigo-900/60 to-purple-900/60 border-indigo-500 shadow-lg shadow-indigo-600/20'
                          : 'bg-slate-900/70 hover:bg-slate-900 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-black shrink-0 ${
                          isSelected ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400 group-hover:text-white'
                        }`}>
                          {idx + 1}
                        </div>
                        <div>
                          <div className={`text-xs font-bold line-clamp-1 ${isSelected ? 'text-white' : 'text-slate-300'}`}>
                            {getTopicDisplayName(topic)}
                          </div>
                          <div className="text-[10px] text-slate-500 mt-0.5 flex items-center gap-2">
                            <span>⏱️ {topic.estimatedMinutes} mins</span>
                            <span className="px-1 py-0.2 bg-amber-500/10 text-amber-300 rounded font-semibold text-[9px]">
                              {topic.importance} Weightage
                            </span>
                          </div>
                        </div>
                      </div>
                      <ChevronRight className={`w-4 h-4 transition-transform ${isSelected ? 'text-indigo-400 translate-x-1' : 'text-slate-600'}`} />
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Right: Detailed Concept & AI Explanation Card */}
            <div className="lg:col-span-8 space-y-4">
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 md:p-7 space-y-6 shadow-xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

                {/* Chapter Title & Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
                  <div>
                    <span className="text-[11px] font-black text-indigo-400 uppercase tracking-wider block">
                      Chapter {selectedTopic.chapterNumber} • {targetExam}
                    </span>
                    <h2 className="text-lg md:text-xl font-black text-white mt-1">
                      {getTopicDisplayName(selectedTopic)}
                    </h2>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setActiveTab('practice')}
                      className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/20 flex items-center gap-1.5 cursor-pointer transition-all active:scale-95"
                    >
                      <Zap className="w-3.5 h-3.5" />
                      <span>{language === 'bn' ? 'প্রশ্ন প্র্যাকটিস' : 'Practice Questions'}</span>
                    </button>
                  </div>
                </div>

                {/* 1. Core Concept Overview */}
                <div className="space-y-2">
                  <h4 className="text-xs font-black uppercase text-indigo-300 tracking-wider flex items-center gap-1.5">
                    <Lightbulb className="w-4 h-4 text-amber-400" />
                    {language === 'bn' ? 'মূল বিষয়বস্তু ও ধারণা (Core Concept):' : 'Core Concept & Logic:'}
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed bg-slate-950/70 p-4 rounded-2xl border border-slate-800/80">
                    {selectedTopic.conceptsSummary[language as 'en' | 'bn' | 'hi'] || selectedTopic.conceptsSummary.en}
                  </p>
                </div>

                {/* 2. Key Formulas, Rules & Short Tricks */}
                {selectedTopic.keyFormulasAndTricks && (
                  <div className="space-y-2">
                    <h4 className="text-xs font-black uppercase text-emerald-300 tracking-wider flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-emerald-400" />
                      {language === 'bn' ? 'শর্টকাট ট্রিকস ও পরীক্ষার সূত্রাবলী:' : 'Short Tricks & Key Formulas:'}
                    </h4>
                    <div className="grid grid-cols-1 gap-2">
                      {(selectedTopic.keyFormulasAndTricks[language as 'en' | 'bn' | 'hi'] || selectedTopic.keyFormulasAndTricks.en).map((rule, idx) => (
                        <div key={idx} className="bg-emerald-950/30 border border-emerald-500/20 p-3 rounded-xl flex items-start gap-2.5 text-xs text-emerald-100">
                          <span className="w-5 h-5 bg-emerald-500/20 text-emerald-300 rounded-md flex items-center justify-center shrink-0 font-bold">
                            {idx + 1}
                          </span>
                          <span className="leading-relaxed">{rule}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 3. Exam Tips & Examiner Traps */}
                {selectedTopic.examTips && (
                  <div className="bg-amber-950/30 border border-amber-500/30 p-4 rounded-2xl space-y-1">
                    <span className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                      <Flame className="w-4 h-4 text-amber-400 fill-amber-400" />
                      {language === 'bn' ? 'পরীক্ষকের ফাঁদ ও গুরুত্বপূর্ণ টিপস:' : 'Exam Trap Warning & Pro Tips:'}
                    </span>
                    <p className="text-xs text-amber-100/90 leading-relaxed">
                      {selectedTopic.examTips[language as 'en' | 'bn' | 'hi'] || selectedTopic.examTips.en}
                    </p>
                  </div>
                )}

                {/* Action CTA to switch to Practice */}
                <div className="pt-2 flex items-center justify-end gap-3">
                  <button
                    onClick={() => setActiveTab('revision')}
                    className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl cursor-pointer"
                  >
                    {language === 'bn' ? 'স্মার্ট রিভিশন নোটস' : 'Revision Notes'}
                  </button>

                  <button
                    onClick={() => setActiveTab('practice')}
                    className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black rounded-xl shadow-lg shadow-emerald-600/30 flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>{language === 'bn' ? 'এই অধ্যায়ের প্রশ্ন সমাধান করুন' : 'Start Chapter Practice'}</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 2: INTERACTIVE PRACTICE QUESTIONS */}
        {/* ========================================================================= */}
        {activeTab === 'practice' && (
          <div className="max-w-3xl mx-auto space-y-4">
            {/* Practice Header with Unlimited Badge */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/90 border border-slate-800 p-3.5 rounded-2xl">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1.5 bg-gradient-to-r from-indigo-600/30 to-purple-600/30 border border-indigo-500/50 text-indigo-300 text-xs font-black rounded-xl flex items-center gap-1.5 shadow-sm">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                  <span>
                    {language === 'bn' 
                      ? `প্রশ্ন ${currentQIndex + 1} (আনলিমিটেড ∞)` 
                      : `Question ${currentQIndex + 1} (Unlimited ∞)`}
                  </span>
                </span>
                <span className="text-xs text-slate-400 hidden sm:inline truncate max-w-[200px]">
                  <strong>{getTopicDisplayName(selectedTopic)}</strong>
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleFetchMoreQuestions(false, 10)}
                  disabled={isLoadingMore}
                  className="px-3 py-1.5 bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/40 text-indigo-200 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-all"
                  title="Load 10 more questions"
                >
                  {isLoadingMore ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5 text-amber-400" />}
                  <span>{language === 'bn' ? '+১০টি প্রশ্ন' : '+10 Qs'}</span>
                </button>

                <button
                  onClick={handleGenerateAIQuestions}
                  disabled={aiGenerating}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer border border-slate-700"
                >
                  {aiGenerating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
                  <span className="hidden md:inline">{language === 'bn' ? 'নতুন সেট' : 'New Set'}</span>
                </button>

                <button
                  onClick={handleToggleBookmarkCurrent}
                  className={`p-2 rounded-xl transition-all cursor-pointer ${
                    isBookmarked 
                      ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' 
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-amber-400' : ''}`} />
                </button>
              </div>
            </div>

            {/* Quick Horizontal Question Navigator Strip */}
            {practiceQuestions.length > 0 && (
              <div className="flex items-center gap-1.5 overflow-x-auto py-1 px-1 no-scrollbar text-xs">
                {practiceQuestions.map((q, idx) => {
                  const isActive = idx === currentQIndex;
                  const result = answeredResults[idx];
                  let pillStyle = 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800';

                  if (isActive) {
                    pillStyle = 'bg-indigo-600 text-white font-black ring-2 ring-indigo-400/50 shadow-md shadow-indigo-600/30';
                  } else if (result === true) {
                    pillStyle = 'bg-emerald-950/60 border-emerald-500/60 text-emerald-300 font-bold';
                  } else if (result === false) {
                    pillStyle = 'bg-rose-950/60 border-rose-500/60 text-rose-300 font-bold';
                  }

                  return (
                    <button
                      key={q.id || idx}
                      onClick={() => {
                        setCurrentQIndex(idx);
                        setSelectedOption(null);
                        setIsAnswerChecked(false);
                      }}
                      className={`h-7 min-w-[28px] px-2 rounded-lg border flex items-center justify-center transition-all shrink-0 cursor-pointer ${pillStyle}`}
                    >
                      {idx + 1}
                    </button>
                  );
                })}

                <button
                  onClick={() => handleFetchMoreQuestions(false, 10)}
                  disabled={isLoadingMore}
                  className="h-7 px-2.5 rounded-lg border border-dashed border-indigo-500/50 bg-indigo-950/30 text-indigo-300 hover:bg-indigo-900/40 flex items-center gap-1 shrink-0 font-extrabold text-[11px] cursor-pointer"
                >
                  {isLoadingMore ? <Loader2 className="w-3 h-3 animate-spin" /> : <span>+10</span>}
                </button>
              </div>
            )}

            {currentQ ? (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 space-y-6 shadow-2xl">
                {/* Question Text */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                      {currentQ.difficulty || 'Medium'} • {currentQ.subject || subjectKey}
                    </span>
                    <button
                      onClick={() => handleToggleReadAloud(currentQ.question)}
                      className="text-slate-400 hover:text-white p-1"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                  </div>

                  <h3 className="text-base sm:text-lg font-bold text-white leading-relaxed">
                    {currentQ.question}
                  </h3>
                </div>

                {/* Options List */}
                <div className="space-y-2.5">
                  {currentQ.options.map((option, idx) => {
                    const isSelected = selectedOption === idx;
                    const isCorrect = idx === currentQ.correctOptionIndex;

                    let btnStyle = 'bg-slate-950 border-slate-800 text-slate-200 hover:border-indigo-500/60 hover:bg-slate-900';

                    if (isAnswerChecked) {
                      if (isCorrect) {
                        btnStyle = 'bg-emerald-950/80 border-emerald-500 text-emerald-200 shadow-md shadow-emerald-600/20';
                      } else if (isSelected && !isCorrect) {
                        btnStyle = 'bg-rose-950/80 border-rose-500 text-rose-200';
                      } else {
                        btnStyle = 'bg-slate-950/50 border-slate-900 text-slate-500 opacity-60';
                      }
                    } else if (isSelected) {
                      btnStyle = 'bg-indigo-950 border-indigo-500 text-indigo-100 ring-2 ring-indigo-500/40';
                    }

                    return (
                      <button
                        key={idx}
                        disabled={isAnswerChecked}
                        onClick={() => setSelectedOption(idx)}
                        className={`w-full p-4 rounded-2xl border text-left text-xs sm:text-sm font-semibold transition-all flex items-center justify-between cursor-pointer ${btnStyle}`}
                      >
                        <span className="leading-snug">{option}</span>
                        {isAnswerChecked && isCorrect && <Check className="w-5 h-5 text-emerald-400 shrink-0 ml-2" />}
                        {isAnswerChecked && isSelected && !isCorrect && <X className="w-5 h-5 text-rose-400 shrink-0 ml-2" />}
                      </button>
                    );
                  })}
                </div>

                {/* Submit / Check or Next controls */}
                <div className="pt-2 flex items-center justify-between border-t border-slate-800">
                  <button
                    onClick={handlePrevQuestion}
                    disabled={currentQIndex === 0}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 text-xs font-bold rounded-xl cursor-pointer"
                  >
                    {language === 'bn' ? 'আগের প্রশ্ন' : 'Previous'}
                  </button>

                  {!isAnswerChecked ? (
                    <button
                      onClick={handleCheckAnswer}
                      disabled={selectedOption === null}
                      className="px-6 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 text-white font-black text-xs rounded-xl shadow-lg shadow-emerald-600/30 cursor-pointer transition-all active:scale-95"
                    >
                      {language === 'bn' ? 'উত্তর যাচাই করুন' : 'Check Answer'}
                    </button>
                  ) : (
                    <button
                      onClick={handleNextQuestion}
                      disabled={isLoadingMore}
                      className="px-6 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-black text-xs rounded-xl shadow-lg shadow-indigo-600/30 cursor-pointer transition-all active:scale-95 flex items-center gap-1.5"
                    >
                      {isLoadingMore ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>{language === 'bn' ? 'প্রশ্ন লোড হচ্ছে...' : 'Loading next...'}</span>
                        </>
                      ) : (
                        <>
                          <span>
                            {language === 'bn' 
                              ? (currentQIndex >= practiceQuestions.length - 1 ? 'পরবর্তী প্রশ্ন (আনলিমিটেড ∞)' : 'পরবর্তী প্রশ্ন')
                              : (currentQIndex >= practiceQuestions.length - 1 ? 'Next Question (Unlimited ∞)' : 'Next Question')}
                          </span>
                          <ChevronRight className="w-4 h-4" />
                        </>
                      )}
                    </button>
                  )}
                </div>

                {/* Explanation Card */}
                {isAnswerChecked && (
                  <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-3 animate-in fade-in slide-in-from-top-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-indigo-400 flex items-center gap-1.5">
                        <Lightbulb className="w-4 h-4 text-amber-400" />
                        {language === 'bn' ? 'শিক্ষক বিশ্লেষণ ও ব্যাখ্যা:' : 'Detailed AI Solution:'}
                      </span>
                      <button
                        onClick={() => handleToggleReadAloud(currentQ.explanation)}
                        className="text-indigo-400 hover:text-white text-xs flex items-center gap-1"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>{language === 'bn' ? 'ব্যাখ্যা শুনুন' : 'Listen'}</span>
                      </button>
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed">
                      {currentQ.explanation}
                    </p>

                    {currentQ.rememberPoint && (
                      <div className="p-3 bg-amber-950/30 border border-amber-500/30 rounded-xl text-xs text-amber-200">
                        <strong>💡 {language === 'bn' ? 'মনে রাখার পয়েন্ট: ' : 'Quick Remember: '}</strong>
                        {currentQ.rememberPoint}
                      </div>
                    )}
                  </div>
                )}
              </div>
            ) : (
              <div className="p-12 text-center text-slate-400 space-y-3 bg-slate-900 border border-slate-800 rounded-3xl">
                <Loader2 className="w-8 h-8 animate-spin mx-auto text-indigo-500" />
                <p className="text-xs">{language === 'bn' ? 'এআই প্রশ্ন লোড হচ্ছে...' : 'Loading AI Questions...'}</p>
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 3: TIMED TOPIC QUIZ CHALLENGE */}
        {/* ========================================================================= */}
        {activeTab === 'quiz' && (
          <div className="max-w-2xl mx-auto space-y-6">
            {!quizActive && !quizSubmitted ? (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center space-y-4 shadow-2xl">
                <div className="w-16 h-16 bg-gradient-to-tr from-amber-500 to-orange-600 text-white rounded-3xl flex items-center justify-center mx-auto shadow-lg shadow-amber-500/30">
                  <Trophy className="w-8 h-8" />
                </div>

                <div>
                  <h3 className="text-lg font-black text-white">
                    {language === 'bn' ? `টপিক কুইজ: ${getTopicDisplayName(selectedTopic)}` : `Topic Quiz: ${getTopicDisplayName(selectedTopic)}`}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    {language === 'bn' 
                      ? '৫টি নির্বাচিত প্রশ্ন সমাধান করে নিজের জ্ঞান ও নির্ভুলতা যাচাই করুন।' 
                      : 'Test your understanding with 5 focused questions for this topic.'}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3 max-w-xs mx-auto py-2 text-xs">
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                    <span className="text-slate-400 block">Questions</span>
                    <strong className="text-white text-base">5 MCQs</strong>
                  </div>
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                    <span className="text-slate-400 block">Negative Marking</span>
                    <strong className="text-rose-400 text-base">0.25</strong>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setQuizActive(true);
                    setQuizIndex(0);
                    setQuizAnswers({});
                    setQuizSubmitted(false);
                  }}
                  className="px-8 py-3 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-amber-500/30 cursor-pointer transition-all active:scale-95"
                >
                  {language === 'bn' ? 'কুইজ শুরু করুন' : 'Start Topic Quiz'}
                </button>
              </div>
            ) : quizActive && !quizSubmitted ? (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6 shadow-2xl">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <span className="text-xs font-black text-amber-400">
                    Question {quizIndex + 1} of {practiceQuestions.length}
                  </span>
                  <span className="text-xs text-slate-400">
                    Topic Quiz
                  </span>
                </div>

                {practiceQuestions[quizIndex] && (
                  <div className="space-y-4">
                    <h3 className="text-sm sm:text-base font-bold text-white">
                      {practiceQuestions[quizIndex].question}
                    </h3>

                    <div className="space-y-2">
                      {practiceQuestions[quizIndex].options.map((opt, oIdx) => {
                        const isChosen = quizAnswers[quizIndex] === oIdx;
                        return (
                          <button
                            key={oIdx}
                            onClick={() => handleOptionSelectQuiz(oIdx)}
                            className={`w-full p-3.5 rounded-xl border text-left text-xs font-semibold transition-all cursor-pointer ${
                              isChosen
                                ? 'bg-amber-500/20 border-amber-500 text-amber-200 ring-1 ring-amber-500'
                                : 'bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-900'
                            }`}
                          >
                            {opt}
                          </button>
                        );
                      })}
                    </div>

                    <div className="pt-4 flex items-center justify-between border-t border-slate-800">
                      <button
                        onClick={() => setQuizIndex(prev => Math.max(0, prev - 1))}
                        disabled={quizIndex === 0}
                        className="px-4 py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-300 text-xs font-bold rounded-xl cursor-pointer"
                      >
                        {language === 'bn' ? 'আগের' : 'Prev'}
                      </button>

                      {quizIndex < practiceQuestions.length - 1 ? (
                        <button
                          onClick={() => setQuizIndex(prev => prev + 1)}
                          className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black rounded-xl cursor-pointer"
                        >
                          {language === 'bn' ? 'পরবর্তী' : 'Next'}
                        </button>
                      ) : (
                        <button
                          onClick={handleSubmitQuiz}
                          className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black rounded-xl cursor-pointer shadow-lg shadow-emerald-600/30"
                        >
                          {language === 'bn' ? 'সাবমিট করুন' : 'Submit Quiz'}
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center space-y-4 shadow-2xl">
                <div className="w-16 h-16 bg-gradient-to-tr from-emerald-500 to-teal-600 text-white rounded-3xl flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/30">
                  <CheckCircle2 className="w-8 h-8" />
                </div>

                <div>
                  <h3 className="text-lg font-black text-white">
                    {language === 'bn' ? 'কুইজ সম্পন্ন হয়েছে!' : 'Quiz Completed!'}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Your Score: <strong className="text-emerald-400 text-base">{quizScore} / {practiceQuestions.length}</strong> ({Math.round((quizScore / (practiceQuestions.length || 1)) * 100)}%)
                  </p>
                </div>

                <div className="pt-2 flex items-center justify-center gap-3">
                  <button
                    onClick={() => {
                      setQuizActive(false);
                      setQuizSubmitted(false);
                    }}
                    className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl cursor-pointer"
                  >
                    {language === 'bn' ? 'পুনরায় কুইজ দিন' : 'Retake Quiz'}
                  </button>

                  <button
                    onClick={() => setActiveTab('mistakes')}
                    className="px-5 py-2.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-black rounded-xl cursor-pointer shadow-md"
                  >
                    {language === 'bn' ? 'ভুল উত্তর রিভিউ' : 'Review Mistakes'}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 4: PREVIOUS MISTAKES (ভুল খাতা) */}
        {/* ========================================================================= */}
        {activeTab === 'mistakes' && (
          <div className="max-w-3xl mx-auto space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-rose-400 flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                {language === 'bn' ? `এই বিষয়ের ভুল খাতা (${mistakesList.length}টি প্রশ্ন)` : `Subject Mistakes Bank (${mistakesList.length} Qs)`}
              </h3>
            </div>

            {mistakesList.length > 0 ? (
              <div className="space-y-3">
                {mistakesList.map((m, idx) => (
                  <div key={m.id || idx} className="bg-slate-900 border border-rose-500/30 rounded-2xl p-5 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black text-rose-400 uppercase tracking-wider">
                        Mistake #{idx + 1} • {m.question.topic || 'General'}
                      </span>
                      <span className="text-[10px] text-slate-500">{new Date(m.mistakeDate).toLocaleDateString()}</span>
                    </div>

                    <h4 className="text-xs sm:text-sm font-bold text-white leading-relaxed">
                      {m.question.question}
                    </h4>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      <div className="bg-rose-950/40 border border-rose-500/40 p-2.5 rounded-xl text-rose-300">
                        <span className="text-[10px] text-rose-400 block font-bold">Your Choice (Incorrect):</span>
                        <span>{m.question.options[m.userSelectedOptionIndex] || 'Selected option'}</span>
                      </div>

                      <div className="bg-emerald-950/40 border border-emerald-500/40 p-2.5 rounded-xl text-emerald-300">
                        <span className="text-[10px] text-emerald-400 block font-bold">Correct Answer:</span>
                        <span>{m.question.options[m.question.correctOptionIndex]}</span>
                      </div>
                    </div>

                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs text-slate-300">
                      <strong>💡 {language === 'bn' ? 'সঠিক বিশ্লেষণ: ' : 'Explanation: '}</strong>
                      {m.question.explanation}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-12 text-center text-slate-400 bg-slate-900 border border-slate-800 rounded-3xl space-y-2">
                <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
                <h4 className="text-sm font-bold text-white">
                  {language === 'bn' ? 'এই বিষয়ে কোনো ভুল প্রশ্ন রেকর্ড নেই!' : 'No Mistakes in this Subject!'}
                </h4>
                <p className="text-xs">
                  {language === 'bn' ? 'দারুণ প্রস্তুতি! নতুন প্রশ্ন প্র্যাকটিস চালিয়ে যান।' : 'Great accuracy! Keep practicing more questions.'}
                </p>
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 5: BOOKMARKS (সংরক্ষিত প্রশ্ন) */}
        {/* ========================================================================= */}
        {activeTab === 'bookmarks' && (
          <div className="max-w-3xl mx-auto space-y-4">
            <h3 className="text-sm font-black text-amber-400 flex items-center gap-2">
              <Bookmark className="w-4 h-4" />
              {language === 'bn' ? `সংরক্ষিত প্রশ্নসমূহ (${bookmarksList.length}টি)` : `Saved Bookmarks (${bookmarksList.length} Qs)`}
            </h3>

            {bookmarksList.length > 0 ? (
              <div className="space-y-3">
                {bookmarksList.map((q, idx) => (
                  <div key={q.id || idx} className="bg-slate-900 border border-amber-500/30 rounded-2xl p-5 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black text-amber-400 uppercase tracking-wider">
                        Saved Q #{idx + 1} • {q.topic || 'General'}
                      </span>
                      <button
                        onClick={() => {
                          toggleBookmark(q);
                          loadMistakesAndBookmarks();
                        }}
                        className="text-xs text-rose-400 hover:underline cursor-pointer"
                      >
                        {language === 'bn' ? 'রিমুভ করুন' : 'Remove'}
                      </button>
                    </div>

                    <h4 className="text-xs sm:text-sm font-bold text-white leading-relaxed">
                      {q.question}
                    </h4>

                    <div className="bg-emerald-950/40 border border-emerald-500/40 p-2.5 rounded-xl text-xs text-emerald-300">
                      <span className="text-[10px] text-emerald-400 block font-bold">Correct Answer:</span>
                      <span>{q.options[q.correctOptionIndex]}</span>
                    </div>

                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs text-slate-300">
                      <strong>💡 {language === 'bn' ? 'ব্যাখ্যা: ' : 'Explanation: '}</strong>
                      {q.explanation}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-12 text-center text-slate-400 bg-slate-900 border border-slate-800 rounded-3xl space-y-2">
                <Bookmark className="w-10 h-10 text-slate-600 mx-auto" />
                <h4 className="text-sm font-bold text-white">
                  {language === 'bn' ? 'কোনো বুকমার্ক করা প্রশ্ন নেই' : 'No Saved Bookmarks'}
                </h4>
                <p className="text-xs">
                  {language === 'bn' ? 'প্রশ্ন অনুশীলনের সময় বুকমার্ক আইকনে চাপ দিয়ে এখানে সংরক্ষণ করুন।' : 'Bookmark challenging questions during practice to review them here.'}
                </p>
              </div>
            )}
          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 6: SMART REVISION (স্মার্ট রিভিশন নোটস) */}
        {/* ========================================================================= */}
        {activeTab === 'revision' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-xl">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <RotateCcw className="w-5 h-5 text-indigo-400" />
                  <div>
                    <h3 className="text-base font-black text-white">
                      {language === 'bn' ? `${getTopicDisplayName(selectedTopic)} - কুইক রিভিশন কার্ড` : `${getTopicDisplayName(selectedTopic)} - Quick Revision`}
                    </h3>
                    <span className="text-[11px] text-slate-400">High-Yield Revision Points for {targetExam}</span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    const txt = (selectedTopic.keyFormulasAndTricks[language as 'en' | 'bn' | 'hi'] || selectedTopic.keyFormulasAndTricks.en).join('. ');
                    handleToggleReadAloud(txt);
                  }}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-indigo-300 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
                >
                  <Volume2 className="w-4 h-4" />
                  <span>{language === 'bn' ? 'রিভিশন শুনুন' : 'Audio Revision'}</span>
                </button>
              </div>

              {/* Revision Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {(selectedTopic.keyFormulasAndTricks[language as 'en' | 'bn' | 'hi'] || selectedTopic.keyFormulasAndTricks.en).map((rule, idx) => (
                  <div key={idx} className="bg-slate-950 p-4 rounded-2xl border border-indigo-500/20 space-y-2 hover:border-indigo-500/50 transition-all">
                    <span className="text-[10px] font-black text-indigo-400 uppercase tracking-wider block">
                      Rule / Trick #{idx + 1}
                    </span>
                    <p className="text-xs text-slate-200 leading-relaxed font-medium">
                      {rule}
                    </p>
                  </div>
                ))}
              </div>

              <div className="p-4 bg-purple-950/30 border border-purple-500/30 rounded-2xl text-xs text-purple-200 flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-purple-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-purple-300 block mb-0.5">{language === 'bn' ? 'এআই স্মার্ট রিকল স্ট্র্যাটেজি:' : 'AI Spaced Recall Strategy:'}</strong>
                  <span>{language === 'bn' ? 'এই সূত্রগুলি প্রতি ৩ দিন অন্তর একবার রিভিশন দিলে পরীক্ষার হলে ৯৮% নির্ভুলতা নিশ্চিত হয়।' : 'Revising these core formulas once every 3 days ensures 98% recall accuracy in your exam.'}</span>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>

    </div>
  );
}
