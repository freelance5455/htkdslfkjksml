import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  Bookmark,
  BookmarkCheck,
  BookOpen,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  Download,
  HelpCircle,
  Play,
  Search,
  Video,
} from 'lucide-react';
import { getNotesForSubject, getVideosForSubject } from '../data/curriculum';
import {
  ChapterNote,
  ChapterVideo,
  ClassLevel,
  CustomLesson,
  LanguageCode,
  Quiz,
  QuizAttempt,
  SavedNoteRecord,
  Subject,
  VideoHistoryRecord,
} from '../types/edutoon';
import { Logo } from './Logo';

interface SubjectDetailViewProps {
  subject: Subject;
  classLevel: ClassLevel;
  defaultLanguage: LanguageCode;
  customLessons: CustomLesson[];
  quizzes: Quiz[];
  quizAttempts: QuizAttempt[];
  savedNotes: SavedNoteRecord[];
  completedNoteIds: string[];
  completedVideoIds: string[];
  videoHistory: VideoHistoryRecord[];
  onBack: () => void;
  onOpenNote: (note: ChapterNote) => void;
  onDownloadNote: (note: ChapterNote) => Promise<void>;
  onToggleSaveNote: (note: ChapterNote) => void;
  onOpenVideo: (video: ChapterVideo) => void;
  onOpenQuiz: (quiz: Quiz) => void;
}

export const SubjectDetailView: React.FC<SubjectDetailViewProps> = ({
  subject,
  classLevel,
  defaultLanguage,
  customLessons,
  quizzes,
  quizAttempts,
  savedNotes,
  completedNoteIds,
  completedVideoIds,
  videoHistory,
  onBack,
  onOpenNote,
  onDownloadNote,
  onToggleSaveNote,
  onOpenVideo,
  onOpenQuiz,
}) => {
  const [sectionLang, setSectionLang] = useState<LanguageCode>(defaultLanguage);
  const [activeTab, setActiveTab] = useState<'notes' | 'videos' | 'quizzes'>('notes');
  const [searchQuery, setSearchQuery] = useState('');
  const [downloadingId, setDownloadingId] = useState<string | null>(null);

  const isHi = sectionLang === 'hi';
  const subjectTitle = isHi ? subject.titleHi : subject.titleEn;

  const notes = useMemo(() => {
    const builtIn = getNotesForSubject(classLevel, subject.id, sectionLang);
    const custom = customLessons
      .filter(
        (l) =>
          l.type === 'note' &&
          l.classLevel === classLevel &&
          l.subjectId === subject.id &&
          l.language === sectionLang
      )
      .map<ChapterNote>((l) => ({
        id: `custom_${l.id}`,
        subjectId: l.subjectId,
        classLevel: l.classLevel,
        language: l.language,
        chapterNumber: l.chapterNumber,
        title: l.title,
        summary: l.summary,
        readTimeMinutes: 5,
        sections: [
          {
            heading: sectionLang === 'hi' ? 'अध्याय विवरण' : 'Chapter Study Material',
            body: l.content,
          },
        ],
        practiceQuestion: {
          question:
            sectionLang === 'hi'
              ? 'इस अध्याय के मुख्य बिंदुओं को अपनी नोटबुक में लिखें।'
              : 'Summarize the key concepts from this chapter in your own words.',
          answer: l.summary,
        },
        isCustom: true,
        mediaUrl: l.mediaUrl || undefined,
      }));
    return [...builtIn, ...custom].sort((a, b) => a.chapterNumber - b.chapterNumber);
  }, [classLevel, subject.id, sectionLang, customLessons]);

  const videos = useMemo(() => {
    const builtIn = getVideosForSubject(classLevel, subject.id, sectionLang);
    const custom = customLessons
      .filter(
        (l) =>
          l.type === 'video' &&
          l.classLevel === classLevel &&
          l.subjectId === subject.id &&
          l.language === sectionLang
      )
      .map<ChapterVideo>((l) => ({
        id: `custom_${l.id}`,
        subjectId: l.subjectId,
        classLevel: l.classLevel,
        language: l.language,
        chapterNumber: l.chapterNumber,
        title: l.title,
        summary: l.summary,
        durationLabel: l.durationLabel || '5:00 min',
        durationSec: 45,
        mediaUrl: l.mediaUrl || undefined,
        isCustom: true,
        scenes: [
          {
            id: 'custom-1',
            title: l.title,
            caption: l.content,
            visualKind: 'grammar',
            highlightValue: `Ch ${l.chapterNumber}`,
            durationSec: 45,
          },
        ],
      }));
    return [...builtIn, ...custom].sort((a, b) => a.chapterNumber - b.chapterNumber);
  }, [classLevel, subject.id, sectionLang, customLessons]);

  const filteredNotes = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return notes;
    return notes.filter(
      (n) =>
        n.title.toLowerCase().includes(q) ||
        n.summary.toLowerCase().includes(q) ||
        `chapter ${n.chapterNumber}`.includes(q)
    );
  }, [notes, searchQuery]);

  const savedSet = useMemo(() => new Set(savedNotes.map((s) => s.noteId)), [savedNotes]);
  const completedNoteSet = useMemo(() => new Set(completedNoteIds), [completedNoteIds]);
  const completedVideoSet = useMemo(() => new Set(completedVideoIds), [completedVideoIds]);

  const historyMap = useMemo(() => {
    const map = new Map<string, VideoHistoryRecord>();
    videoHistory.forEach((h) => map.set(h.videoId, h));
    return map;
  }, [videoHistory]);

  const subjectQuizzes = useMemo(() => {
    return quizzes
      .filter(
        (q) =>
          q.classLevel === classLevel &&
          q.subjectId === subject.id &&
          q.language === sectionLang
      )
      .sort((a, b) => a.chapterNumber - b.chapterNumber);
  }, [quizzes, classLevel, subject.id, sectionLang]);

  const attemptMap = useMemo(() => {
    const map = new Map<string, QuizAttempt>();
    quizAttempts.forEach((a) => map.set(a.quizId, a));
    return map;
  }, [quizAttempts]);

  const completedCount =
    notes.filter((n) => completedNoteSet.has(n.id)).length +
    videos.filter((v) => completedVideoSet.has(v.id)).length +
    subjectQuizzes.filter((q) => attemptMap.has(q.id)).length;
  const totalItems = notes.length + videos.length + subjectQuizzes.length;
  const subjectProgress = totalItems > 0 ? Math.round((completedCount / totalItems) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Subject Header */}
      <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={onBack}
              aria-label="Back to subjects"
              className="min-h-[44px] min-w-[44px] rounded-xl border border-slate-200 hover:bg-slate-50 flex items-center justify-center text-slate-700 cursor-pointer"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <Logo size="sm" />
            <div className="min-w-0">
              <p className="text-xs font-medium text-slate-500">
                {isHi ? `कक्षा ${classLevel}` : `Class ${classLevel}`} ·{' '}
                {isHi ? 'अध्याय नोट्स एवं वीडियो' : 'Notes & Animated Videos'}
              </p>
              <h1 className="font-display text-xl sm:text-2xl font-bold text-slate-900 truncate">
                {subjectTitle}
              </h1>
            </div>
          </div>

          {/* Separate Hindi & English Section Toggle */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl">
            <button
              type="button"
              onClick={() => setSectionLang('hi')}
              className={`min-h-[40px] px-3.5 text-xs sm:text-sm font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                sectionLang === 'hi'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              हिंदी Section
            </button>
            <button
              type="button"
              onClick={() => setSectionLang('en')}
              className={`min-h-[40px] px-3.5 text-xs sm:text-sm font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                sectionLang === 'en'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              English Section
            </button>
          </div>
        </div>

        {/* Subject Completion Bar */}
        <div className="mt-5 pt-4 border-t border-slate-100">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-600 mb-2">
            <span>{isHi ? 'विषय प्रगति' : 'Subject Progress'}</span>
            <span className="font-mono-num text-slate-900">
              {completedCount}/{totalItems} ({subjectProgress}%)
            </span>
          </div>
          <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
            <div
              className="h-full rounded-full bg-sky-600 transition-all duration-300"
              style={{ width: `${subjectProgress}%` }}
            />
          </div>
        </div>
      </div>

      {/* Inside Subject Page Tabs: Notes & Videos */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="inline-flex p-1 bg-white border border-slate-200 rounded-xl self-start">
          <button
            type="button"
            onClick={() => setActiveTab('notes')}
            className={`min-h-[42px] px-4 rounded-lg text-sm font-semibold inline-flex items-center gap-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'notes'
                ? 'bg-sky-600 text-white'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <BookOpen className="h-4 w-4" />
            <span>{isHi ? `नोट्स (${notes.length})` : `Notes (${notes.length})`}</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('videos')}
            className={`min-h-[42px] px-4 rounded-lg text-sm font-semibold inline-flex items-center gap-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'videos'
                ? 'bg-sky-600 text-white'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Video className="h-4 w-4" />
            <span>{isHi ? `वीडियो (${videos.length})` : `Videos (${videos.length})`}</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('quizzes')}
            className={`min-h-[42px] px-4 rounded-lg text-sm font-semibold inline-flex items-center gap-2 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'quizzes'
                ? 'bg-sky-600 text-white'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ClipboardCheck className="h-4 w-4" />
            <span>{isHi ? `क्विज़ (${subjectQuizzes.length})` : `Quizzes (${subjectQuizzes.length})`}</span>
          </button>
        </div>

        {activeTab === 'notes' && (
          <div className="relative w-full sm:w-72">
            <Search className="h-4 w-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isHi ? 'अध्याय या नोट्स खोजें...' : 'Search chapter notes...'}
              className="w-full h-11 pl-10 pr-3.5 rounded-xl border border-slate-200 bg-white text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>
        )}
      </div>

      {/* Notes Tab Content */}
      {activeTab === 'notes' && (
        <div className="space-y-3">
          {filteredNotes.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
              <p className="text-sm text-slate-500">
                {isHi ? 'खोज से मेल खाने वाला कोई अध्याय नहीं मिला।' : 'No chapter notes matched your search.'}
              </p>
            </div>
          ) : (
            filteredNotes.map((note) => {
              const isSaved = savedSet.has(note.id);
              const isCompleted = completedNoteSet.has(note.id);
              return (
                <div
                  key={note.id}
                  className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                      <span className="font-mono-num font-semibold text-sky-700">
                        {isHi ? `अध्याय ${note.chapterNumber}` : `Chapter ${note.chapterNumber}`}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{note.readTimeMinutes} min read</span>
                      <span aria-hidden="true">·</span>
                      <span>PDF Ready</span>
                      {isCompleted && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold">
                            <CheckCircle2 className="h-3.5 w-3.5" />
                            <span>{isHi ? 'पूर्ण' : 'Completed'}</span>
                          </span>
                        </>
                      )}
                    </div>

                    <h3 className="mt-1 font-display text-lg font-bold text-slate-900">
                      {note.title}
                    </h3>
                    <p className="mt-1 text-sm text-slate-600 leading-relaxed">{note.summary}</p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => onToggleSaveNote(note)}
                      aria-label={isSaved ? 'Remove bookmark' : 'Save note'}
                      className={`min-h-[44px] min-w-[44px] px-3 rounded-xl border inline-flex items-center justify-center gap-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                        isSaved
                          ? 'border-amber-300 bg-amber-50 text-amber-800'
                          : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      {isSaved ? (
                        <BookmarkCheck className="h-4 w-4" />
                      ) : (
                        <Bookmark className="h-4 w-4" />
                      )}
                      <span className="hidden md:inline">{isSaved ? 'Saved' : 'Save'}</span>
                    </button>

                    <button
                      type="button"
                      disabled={downloadingId === note.id}
                      onClick={async () => {
                        setDownloadingId(note.id);
                        try {
                          await onDownloadNote(note);
                        } finally {
                          setDownloadingId(null);
                        }
                      }}
                      className="min-h-[44px] px-3.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <Download className="h-4 w-4" />
                      <span>{downloadingId === note.id ? '...' : 'PDF'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => onOpenNote(note)}
                      className="min-h-[44px] px-4 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs sm:text-sm font-semibold inline-flex items-center gap-2 cursor-pointer"
                    >
                      <BookOpen className="h-4 w-4" />
                      <span>{isHi ? 'नोट्स पढ़ें' : 'Read Notes'}</span>
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* Videos Tab Content */}
      {activeTab === 'videos' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {videos.map((video) => {
            const hist = historyMap.get(video.id);
            const progress = hist?.progressPercent || 0;
            const isDone = completedVideoSet.has(video.id) || hist?.completed;

            return (
              <div
                key={video.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col justify-between gap-4"
              >
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span className="font-mono-num font-semibold text-sky-700">
                      {isHi ? `अध्याय ${video.chapterNumber}` : `Chapter ${video.chapterNumber}`}
                    </span>
                    <span className="font-mono-num">{video.durationLabel}</span>
                  </div>

                  <h3 className="mt-1.5 font-display text-lg font-bold text-slate-900">
                    {video.title}
                  </h3>
                  <p className="mt-1 text-sm text-slate-600">{video.summary}</p>
                </div>

                <div className="space-y-3">
                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-slate-500">
                        {isDone
                          ? isHi
                            ? 'वीडियो पूर्ण हुआ'
                            : 'Completed'
                          : isHi
                            ? 'देखने की प्रगति'
                            : 'Watch Progress'}
                      </span>
                      <span className="font-mono-num font-semibold text-slate-800">
                        {isDone ? 100 : progress}%
                      </span>
                    </div>
                    <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all ${
                          isDone ? 'bg-emerald-500' : 'bg-sky-600'
                        }`}
                        style={{ width: `${isDone ? 100 : progress}%` }}
                      />
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => onOpenVideo(video)}
                    className="w-full min-h-[44px] px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold inline-flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Play className="h-4 w-4" />
                    <span>
                      {progress > 0 && !isDone
                        ? isHi
                          ? 'आगे देखें'
                          : 'Resume Animated Lesson'
                        : isHi
                          ? 'एनिमेटेड वीडियो चलाएँ'
                          : 'Watch Animated Lesson'}
                    </span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Quizzes Tab Content */}
      {activeTab === 'quizzes' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {subjectQuizzes.length === 0 ? (
            <div className="md:col-span-2 bg-white rounded-2xl border border-slate-200 p-8 text-center">
              <p className="text-sm text-slate-500">
                {isHi
                  ? 'इस विषय के लिए अभी कोई क्विज़ प्रकाशित नहीं की गई है।'
                  : 'No interactive quizzes published for this subject section yet.'}
              </p>
            </div>
          ) : (
            subjectQuizzes.map((quiz) => {
              const attempt = attemptMap.get(quiz.id);
              return (
                <div
                  key={quiz.id}
                  className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col justify-between gap-4"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs text-slate-500">
                      <span className="font-mono-num font-semibold text-sky-700">
                        {isHi ? `अध्याय ${quiz.chapterNumber}` : `Chapter ${quiz.chapterNumber}`}
                      </span>
                      <span className="inline-flex items-center gap-2 font-mono-num">
                        <span className="inline-flex items-center gap-1">
                          <HelpCircle className="h-3.5 w-3.5" />
                          {quiz.questions.length} Qs
                        </span>
                        <span className="inline-flex items-center gap-1">
                          <Clock className="h-3.5 w-3.5" />
                          {quiz.timeLimitMinutes}m
                        </span>
                      </span>
                    </div>
                    <h3 className="mt-1.5 font-display text-lg font-bold text-slate-900">
                      {quiz.title}
                    </h3>
                    <p className="mt-1 text-sm text-slate-600">{quiz.description}</p>
                  </div>

                  <div className="space-y-3">
                    {attempt && (
                      <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-between text-xs">
                        <span className="font-semibold text-emerald-800">
                          {isHi ? 'अंतिम स्कोर' : 'Last Score'}
                        </span>
                        <span className="font-mono-num font-bold text-emerald-900">
                          {attempt.score}/{attempt.totalQuestions} ({attempt.percentage}%)
                        </span>
                      </div>
                    )}
                    <button
                      type="button"
                      onClick={() => onOpenQuiz(quiz)}
                      className="w-full min-h-[44px] px-4 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-sm font-semibold inline-flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <ClipboardCheck className="h-4 w-4" />
                      <span>
                        {attempt
                          ? isHi
                            ? 'क्विज़ फिर से दें'
                            : 'Retake Chapter Quiz'
                          : isHi
                            ? 'क्विज़ शुरू करें'
                            : 'Start Chapter Quiz'}
                      </span>
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};
