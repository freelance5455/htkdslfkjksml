import React, { useEffect, useRef, useState } from 'react';
import { BotVoiceState } from '../types';
import { liveAudioAnalyser } from '../utils/liveAudioVisualizer';
import { Activity, Mic } from 'lucide-react';

interface AudioWaveVisualizerProps {
  state: BotVoiceState;
  height?: number;
  onVolumeChange?: (volume: number) => void;
}

export const AudioWaveVisualizer: React.FC<AudioWaveVisualizerProps> = ({
  state,
  height = 56,
  onVolumeChange,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [liveVolumeLevel, setLiveVolumeLevel] = useState<number>(0);
  const isListening = state === 'listening';

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let phase = 0;
    const barCount = 32;

    const render = () => {
      const width = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, width, h);

      phase += state === 'speaking' ? 0.12 : 0.05;

      const barWidth = 4;
      const gap = (width - barCount * barWidth) / (barCount - 1);

      // Check for real-time Web Audio API frequency data if listening
      let liveFreqData: Uint8Array | null = null;
      let currentAvgVolume = 0;

      if (isListening && liveAudioAnalyser.isActive()) {
        liveFreqData = liveAudioAnalyser.getFrequencyData();
        if (liveFreqData && liveFreqData.length > 0) {
          let sum = 0;
          for (let k = 0; k < liveFreqData.length; k++) {
            sum += liveFreqData[k];
          }
          currentAvgVolume = sum / liveFreqData.length / 255;
          setLiveVolumeLevel(currentAvgVolume);
          onVolumeChange?.(currentAvgVolume);
        }
      } else {
        if (liveVolumeLevel !== 0) {
          setLiveVolumeLevel(0);
          onVolumeChange?.(0);
        }
      }

      for (let i = 0; i < barCount; i++) {
        let barHeight = 6;

        if (isListening && liveFreqData && liveFreqData.length > 0) {
          // Real-time Web Audio frequency mapping
          // Symmetrical mapping: center is low/mid frequencies, outer edges are high frequencies
          const midPoint = barCount / 2;
          const distFromMid = Math.abs(i - midPoint);
          const binIndex = Math.floor(
            (distFromMid / midPoint) * (liveFreqData.length * 0.75)
          );
          const freqValue = liveFreqData[binIndex] || 0; // 0 to 255

          // Scale frequency value to canvas height
          const normalized = freqValue / 255;
          // Minimum baseline height + reactive boost
          barHeight = 5 + Math.pow(normalized, 1.2) * (h - 10);
        } else if (state === 'listening') {
          // Fallback if mic permission delayed
          const wave = Math.sin(phase * 2.5 + i * 0.5);
          barHeight = 8 + Math.abs(wave) * (h - 16);
        } else if (state === 'speaking') {
          // Dynamic vocal wave for bot voice
          const wave1 = Math.sin(phase + i * 0.4);
          const wave2 = Math.cos(phase * 1.6 + i * 0.25);
          const factor = Math.abs(wave1 * 0.65 + wave2 * 0.35);
          const centerBias = Math.sin((i / barCount) * Math.PI);
          barHeight = 8 + factor * (h - 14) * (0.35 + centerBias * 0.65);
        } else if (state === 'thinking') {
          // Sweeping ripples for AI processing
          const wave = Math.sin(phase * 1.5 + i * 0.35);
          barHeight = 7 + (wave + 1) * 7;
        } else {
          // Idle ambient breathing wave
          const wave = Math.sin(phase * 0.8 + i * 0.2);
          barHeight = 5 + (wave + 1) * 2.5;
        }

        // Clamp height
        barHeight = Math.max(4, Math.min(h - 4, barHeight));

        const x = i * (barWidth + gap);
        const y = (h - barHeight) / 2;

        // Visualizer bar styling
        const grad = ctx.createLinearGradient(0, y, 0, y + barHeight);
        if (isListening) {
          // Active recording: Electric Ruby to Crimson & Gold tip
          grad.addColorStop(0, '#FFA8A8');
          grad.addColorStop(0.3, '#FF3B30');
          grad.addColorStop(0.8, '#D90429');
          grad.addColorStop(1, '#7F1D1D');
        } else if (state === 'thinking') {
          // Thinking: Cyan to Electric Blue
          grad.addColorStop(0, '#E0F2FE');
          grad.addColorStop(0.4, '#38BDF8');
          grad.addColorStop(1, '#1D4ED8');
        } else {
          // Bot Speaking or Idle: Metallic Gold
          grad.addColorStop(0, '#FFFBEB');
          grad.addColorStop(0.3, '#F5DC8C');
          grad.addColorStop(0.7, '#E2C067');
          grad.addColorStop(1, '#9E761E');
        }

        ctx.fillStyle = grad;

        // Rounded bar caps
        ctx.beginPath();
        const r = barWidth / 2;
        ctx.roundRect(x, y, barWidth, barHeight, r);
        ctx.fill();

        // Top glow caps for loud frequencies during real-time listening
        if (isListening && barHeight > h * 0.5) {
          ctx.beginPath();
          ctx.arc(x + r, y + 2, r + 0.5, 0, Math.PI * 2);
          ctx.fillStyle = '#FFFFFF';
          ctx.fill();
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [state, isListening, onVolumeChange, liveVolumeLevel]);

  return (
    <div className="w-full flex flex-col items-center justify-center py-1">
      {/* Visualizer Canvas */}
      <div className="relative w-full max-w-[340px] px-2 flex items-center justify-center">
        <canvas
          ref={canvasRef}
          width={340}
          height={height}
          className="w-full max-w-[340px] h-[56px] drop-shadow-[0_2px_12px_rgba(0,0,0,0.5)]"
        />

        {/* Real-time Voice Energy Glow overlay when recording */}
        {isListening && liveVolumeLevel > 0.05 && (
          <div
            className="absolute inset-0 rounded-2xl pointer-events-none transition-opacity duration-150 blur-xl"
            style={{
              background: `radial-gradient(ellipse at center, rgba(239,68,68,${Math.min(
                0.45,
                liveVolumeLevel * 0.9
              )}) 0%, transparent 70%)`,
            }}
          />
        )}
      </div>

      {/* Live Audio Indicator Tag */}
      {isListening && (
        <div className="flex items-center gap-2 mt-1 px-2.5 py-0.5 rounded-full bg-red-950/60 border border-red-500/30 text-[10px] text-red-300 animate-in fade-in duration-200">
          <span className="flex items-center gap-1 font-semibold">
            <Mic className="w-3 h-3 text-red-400 animate-pulse" />
            <span>Web Audio Real-Time Feed</span>
          </span>
          <span className="w-1 h-1 rounded-full bg-red-400" />
          <span className="font-mono text-[9px] text-red-200">
            Signal: {Math.round(liveVolumeLevel * 100)}%
          </span>
        </div>
      )}
    </div>
  );
};
