import React, { useState } from 'react';
import { Network, Zap, Shield, Check, RefreshCw } from 'lucide-react';
import { DNS_PROVIDERS } from '../utils/pingTester';
import { DnsProvider } from '../types';
import { soundFX } from '../utils/audio';

interface DnsBenchmarkProps {
  activeDnsId: string;
  onSelectDns: (id: string) => void;
  language: 'en' | 'ur';
}

export const DnsBenchmark: React.FC<DnsBenchmarkProps> = ({
  activeDnsId,
  onSelectDns,
  language,
}) => {
  const [providers, setProviders] = useState<DnsProvider[]>(DNS_PROVIDERS);
  const [testing, setTesting] = useState(false);

  const testAllDns = async () => {
    setTesting(true);
    soundFX.playPing();

    const updated = providers.map((p) => {
      // Simulate real DNS resolving speed test with localized Pakistan edge speed
      const base = p.id === 'cloudflare' ? 17 : p.id === 'pakistan-edge' ? 14 : p.id === 'google' ? 22 : 28;
      const variation = Math.floor(Math.random() * 5);
      return {
        ...p,
        ping: base + variation,
      };
    });

    setTimeout(() => {
      setProviders(updated);
      setTesting(false);
      soundFX.playToast();
    }, 800);
  };

  return (
    <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <Network className="w-5 h-5 text-amber-400" />
            <h3 className="text-base font-bold text-slate-100">
              {language === 'ur' ? 'گیمنگ ڈی این ایس اسپیڈ موازنہ' : 'Gaming DNS Resolver Benchmark'}
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            {language === 'ur'
              ? 'فری فائر کے لیے بہترین اور تیز ترین ڈی این ایس منتخب کریں'
              : 'Compare query lookup latency and configure gaming DNS server'}
          </p>
        </div>

        <button
          onClick={testAllDns}
          disabled={testing}
          className="self-start sm:self-auto px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-2 transition-colors border border-slate-700 active:scale-95"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-amber-400 ${testing ? 'animate-spin' : ''}`} />
          <span>{testing ? 'Benchmarking...' : 'Test DNS Speed'}</span>
        </button>
      </div>

      <div className="space-y-2.5">
        {providers.map((p) => {
          const isActive = activeDnsId === p.id;
          return (
            <div
              key={p.id}
              className={`p-3.5 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                isActive
                  ? 'bg-amber-950/20 border-amber-500/50 shadow-sm ring-1 ring-amber-500/20'
                  : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    isActive ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  <Network className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-xs text-slate-100">{p.name}</span>
                    <span className="text-[11px] font-mono text-slate-400">{p.primaryIp}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                    {p.features.map((feat, i) => (
                      <React.Fragment key={feat}>
                        <span>{feat}</span>
                        {i < p.features.length - 1 && <span className="text-slate-600">·</span>}
                      </React.Fragment>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between sm:justify-end gap-4">
                <div className="text-right">
                  <div className="text-sm font-mono font-bold text-emerald-400">
                    {p.ping} <span className="text-xs text-slate-400">ms</span>
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono">Query Latency</div>
                </div>

                <button
                  onClick={() => {
                    onSelectDns(p.id);
                    soundFX.playToast();
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                    isActive
                      ? 'bg-amber-500 text-slate-950 cursor-default'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                  }`}
                >
                  {isActive ? (
                    <>
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                      <span>Applied</span>
                    </>
                  ) : (
                    <span>Apply DNS</span>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
