import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Account, AccountType } from '../types';
import { t, formatCurrency, formatDateDisplay } from '../utils/translations';
import {
  Wallet,
  Building,
  Plus,
  ArrowRightLeft,
  Search,
  CreditCard,
  Edit2,
  Trash2,
  ArrowDownRight,
  ArrowUpRight,
  BookOpen
} from 'lucide-react';
import { TransferModal } from './Modals/TransferModal';

export const AccountsView: React.FC = () => {
  const {
    language,
    accounts,
    addAccount,
    updateAccount,
    deleteAccount,
    getAccountBalance,
    transactions,
    transfers
  } = useApp();

  const [selectedAccountId, setSelectedAccountId] = useState<string>(accounts[0]?.id || '');
  const [isAddAccountOpen, setIsAddAccountOpen] = useState(false);
  const [isTransferOpen, setIsTransferOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState<Account | null>(null);

  // Form state for adding/editing account
  const [accName, setAccName] = useState('');
  const [accType, setAccType] = useState<AccountType>('bank');
  const [bankName, setBankName] = useState('');
  const [accNumber, setAccNumber] = useState('');
  const [initialBalance, setInitialBalance] = useState('');

  const selectedAccount = accounts.find((a) => a.id === selectedAccountId) || accounts[0];

  const totalLiquidBalance = accounts.reduce((sum, a) => sum + getAccountBalance(a.id), 0);

  const handleOpenAddAccount = () => {
    setEditingAccount(null);
    setAccName('');
    setAccType('bank');
    setBankName('');
    setAccNumber('');
    setInitialBalance('0');
    setIsAddAccountOpen(true);
  };

  const handleOpenEditAccount = (acc: Account) => {
    setEditingAccount(acc);
    setAccName(acc.name);
    setAccType(acc.type);
    setBankName(acc.bankName || '');
    setAccNumber(acc.accountNumber || '');
    setInitialBalance((acc.initialBalance || 0).toString());
    setIsAddAccountOpen(true);
  };

  const handleSaveAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!accName.trim()) return;

    const parsedBal = parseFloat(initialBalance) || 0;

    if (editingAccount) {
      updateAccount(editingAccount.id, {
        name: accName.trim(),
        type: accType,
        bankName: bankName.trim() || undefined,
        accountNumber: accNumber.trim() || undefined,
        initialBalance: parsedBal
      });
    } else {
      addAccount({
        name: accName.trim(),
        type: accType,
        bankName: bankName.trim() || undefined,
        accountNumber: accNumber.trim() || undefined,
        initialBalance: parsedBal,
        color: accType === 'cash' ? '#059669' : '#2563eb'
      });
    }
    setIsAddAccountOpen(false);
  };

  const handleDeleteAccount = (id: string) => {
    if (accounts.length <= 1) {
      alert(language === 'gu' ? 'ઓછામાં ઓછું એક ખાતું હોવું જરૂરી છે.' : 'At least one account is required.');
      return;
    }
    const confirmMsg =
      language === 'gu'
        ? 'શું તમે આ ખાતું કાઢી નાખવા માંગો છો?'
        : 'Are you sure you want to delete this account?';
    if (window.confirm(confirmMsg)) {
      deleteAccount(id);
      if (selectedAccountId === id) {
        setSelectedAccountId(accounts.find((a) => a.id !== id)?.id || '');
      }
    }
  };

  // Get transactions for selected account
  const accountTransactions = transactions
    .filter((tx) => tx.accountId === selectedAccountId)
    .sort((a, b) => b.date.localeCompare(a.date));

  // Get transfers involving this account
  const accountTransfers = transfers
    .filter((tf) => tf.fromAccountId === selectedAccountId || tf.toAccountId === selectedAccountId)
    .sort((a, b) => b.date.localeCompare(a.date));

  return (
    <div className="space-y-4 pb-12">
      {/* Top Bar with Total Liquid Balance & Actions */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-stone-200 shadow-sm print-hide">
        <div>
          <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider block">
            {t('cashAndBankTotal', language)}
          </span>
          <p className="text-2xl font-black text-stone-900 mt-0.5">
            {formatCurrency(totalLiquidBalance, language)}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsTransferOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-stone-300 hover:bg-stone-50 text-stone-800 text-xs font-bold transition-all shadow-xs"
          >
            <ArrowRightLeft className="w-4 h-4 text-blue-600" />
            <span>{t('transferFunds', language)}</span>
          </button>

          <button
            type="button"
            onClick={handleOpenAddAccount}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-md active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>{t('addAccount', language)}</span>
          </button>
        </div>
      </div>

      {/* Account Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
        {accounts.map((acc) => {
          const balance = getAccountBalance(acc.id);
          const isSelected = acc.id === selectedAccountId;

          return (
            <div
              key={acc.id}
              onClick={() => setSelectedAccountId(acc.id)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer shadow-xs relative flex flex-col justify-between ${
                isSelected
                  ? 'border-amber-500 bg-amber-50/40 ring-2 ring-amber-500/20'
                  : 'border-stone-200 bg-white hover:border-stone-300'
              }`}
            >
              <div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                        acc.type === 'cash' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
                      }`}
                    >
                      {acc.type === 'cash' ? (
                        <Wallet className="w-5 h-5" />
                      ) : (
                        <Building className="w-5 h-5" />
                      )}
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-stone-900 truncate max-w-[150px]">{acc.name}</h3>
                      <p className="text-[11px] text-stone-500">
                        {acc.bankName || (acc.type === 'cash' ? 'રોકડ મેળ' : 'બેંક')}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleOpenEditAccount(acc);
                      }}
                      className="p-1 rounded text-stone-400 hover:text-amber-700 hover:bg-stone-100"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    {accounts.length > 1 && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteAccount(acc.id);
                        }}
                        className="p-1 rounded text-stone-400 hover:text-rose-600 hover:bg-stone-100"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="mt-4">
                  <span className="text-[11px] text-stone-500 block">{t('currentBalance', language)}</span>
                  <p
                    className={`text-xl font-black mt-0.5 ${
                      balance >= 0 ? 'text-stone-900' : 'text-rose-700'
                    }`}
                  >
                    {formatCurrency(balance, language)}
                  </p>
                </div>
              </div>

              <div className="mt-3 pt-2 border-t border-stone-200/60 flex items-center justify-between text-[11px] text-stone-500">
                <span>{acc.accountNumber || 'ખાતું સક્રિય'}</span>
                <span>શરૂઆત: {formatCurrency(acc.initialBalance || 0, language)}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Account's Ledger Book */}
      {selectedAccount && (
        <div className="rounded-2xl bg-white border border-stone-200 shadow-sm overflow-hidden khatavahi-print-sheet">
          <div className="p-4 bg-gradient-to-r from-red-950 to-stone-900 text-white flex items-center justify-between border-b border-amber-500/50">
            <div>
              <h3 className="text-base font-bold text-amber-100 flex items-center gap-2">
                <span>{selectedAccount.name}</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/40">
                  {selectedAccount.type === 'cash' ? 'રોકડ મેળ' : 'બેંક ખાતાવહી'}
                </span>
              </h3>
              <p className="text-xs text-amber-200/80 mt-0.5">
                હાલની સિલક: {formatCurrency(getAccountBalance(selectedAccount.id), language)}
              </p>
            </div>

            <span className="text-xs font-semibold text-stone-300">
              {accountTransactions.length} વ્યવહારો
            </span>
          </div>

          {accountTransactions.length === 0 ? (
            <div className="p-10 text-center text-stone-400 text-xs">
              {language === 'gu'
                ? 'આ ખાતામાં હજુ સુધી કોઈ સીધી નોંધણી થઈ નથી.'
                : 'No transactions recorded for this account yet.'}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-amber-50/70 text-stone-700 font-bold border-b border-amber-200">
                  <tr>
                    <th className="p-3 w-28">{t('date', language)}</th>
                    <th className="p-3">{language === 'gu' ? 'વિગત / શીર્ષક' : 'Description'}</th>
                    <th className="p-3">{t('partyName', language)}</th>
                    <th className="p-3 text-right text-emerald-800 w-32">{t('jama', language)} (₹)</th>
                    <th className="p-3 text-right text-rose-800 w-32">{t('udhar', language)} (₹)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-200">
                  {accountTransactions.map((tx) => (
                    <tr key={tx.id} className="hover:bg-amber-50/30">
                      <td className="p-3 font-medium text-stone-700">
                        {formatDateDisplay(tx.date, language)}
                      </td>
                      <td className="p-3">
                        <div className="font-bold text-stone-900">{tx.title}</div>
                        {tx.notes && <div className="text-[11px] text-stone-500">{tx.notes}</div>}
                      </td>
                      <td className="p-3 text-stone-600">{tx.partyName || '-'}</td>
                      <td className="p-3 text-right font-black text-emerald-700">
                        {tx.type === 'income' ? formatCurrency(tx.amount, language) : '-'}
                      </td>
                      <td className="p-3 text-right font-black text-rose-700">
                        {tx.type === 'expense' ? formatCurrency(tx.amount, language) : '-'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Add / Edit Account Modal */}
      {isAddAccountOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-2xl bg-white border border-stone-200 shadow-2xl overflow-hidden">
            <div className="bg-gradient-to-r from-red-950 to-red-900 text-white px-5 py-3.5 flex items-center justify-between border-b border-amber-500/50">
              <h2 className="text-base font-bold text-amber-100">
                {editingAccount ? t('edit', language) : t('addAccount', language)}
              </h2>
              <button
                type="button"
                onClick={() => setIsAddAccountOpen(false)}
                className="rounded-lg p-1 text-stone-300 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveAccount} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  {t('accountName', language)} *
                </label>
                <input
                  type="text"
                  required
                  value={accName}
                  onChange={(e) => setAccName(e.target.value)}
                  placeholder={language === 'gu' ? 'દા.ત. સ્ટેટ બેંક, રોકડ ખાતું' : 'e.g. State Bank of India, Cash Book'}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-sm font-semibold"
                  autoFocus
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    {t('accountType', language)}
                  </label>
                  <select
                    value={accType}
                    onChange={(e) => setAccType(e.target.value as AccountType)}
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs font-semibold bg-white"
                  >
                    <option value="bank">{t('bank', language)}</option>
                    <option value="cash">{t('cash', language)}</option>
                    <option value="wallet">{t('wallet', language)}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    {t('initialBalance', language)}
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={initialBalance}
                    onChange={(e) => setInitialBalance(e.target.value)}
                    placeholder="0"
                    className="w-full px-3 py-2 rounded-lg border border-stone-300 text-sm font-bold"
                  />
                </div>
              </div>

              {accType === 'bank' && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-stone-600 mb-1">
                      {language === 'gu' ? 'બેંકનું નામ / શાખા' : 'Bank Name / Branch'}
                    </label>
                    <input
                      type="text"
                      value={bankName}
                      onChange={(e) => setBankName(e.target.value)}
                      placeholder="SBI Surat"
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-stone-600 mb-1">
                      {language === 'gu' ? 'ખાતા નંબર (છેલ્લા ૪ અંક)' : 'A/C Number'}
                    </label>
                    <input
                      type="text"
                      value={accNumber}
                      onChange={(e) => setAccNumber(e.target.value)}
                      placeholder="**** 1234"
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs"
                    />
                  </div>
                </div>
              )}

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsAddAccountOpen(false)}
                  className="px-4 py-2 rounded-lg border border-stone-300 text-xs font-semibold text-stone-700"
                >
                  {t('cancel', language)}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg text-xs font-bold text-white bg-amber-600 hover:bg-amber-700"
                >
                  {t('save', language)}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Internal Transfer Modal */}
      <TransferModal isOpen={isTransferOpen} onClose={() => setIsTransferOpen(false)} />
    </div>
  );
};
