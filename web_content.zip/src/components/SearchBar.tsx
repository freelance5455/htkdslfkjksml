import React from 'react';
import { Search, X, MapPin } from 'lucide-react';

interface SearchBarProps {
  query: string;
  onChange: (val: string) => void;
  folderName: string;
  isAllFolders: boolean;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  query,
  onChange,
  folderName,
  isAllFolders,
}) => {
  return (
    <div className="relative">
      <div className="relative flex items-center">
        <Search className="absolute left-3.5 w-5 h-5 text-slate-400 pointer-events-none" />
        <input
          type="text"
          value={query}
          onChange={(e) => onChange(e.target.value)}
          placeholder={
            isAllFolders
              ? 'नाम, मोबाइल नंबर या पता से खोजें...'
              : `'${folderName}' में ग्राहक खोजें...`
          }
          className="w-full pl-11 pr-10 py-3 rounded-xl border border-orange-200/80 bg-white shadow-xs text-slate-800 placeholder:text-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500 font-medium"
        />
        {query && (
          <button
            onClick={() => onChange('')}
            className="absolute right-3 p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
            title="खोज साफ करें"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Scope badge */}
      <div className="mt-1.5 flex items-center justify-between text-[11px] text-slate-500 px-1 font-medium">
        <span className="flex items-center gap-1">
          <MapPin className="w-3 h-3 text-orange-500" />
          <span>खोज दायरा: </span>
          <strong className="text-orange-700">
            {isAllFolders ? 'पूरे ऐप (सभी फोल्डर) में' : `'${folderName}' फोल्डर में`}
          </strong>
        </span>
        {query && (
          <span className="text-slate-500">
            परिणाम खोज रहे हैं...
          </span>
        )}
      </div>
    </div>
  );
};
