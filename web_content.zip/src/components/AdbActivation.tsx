import React, { useState } from 'react';
import { 
  Terminal, 
  Copy, 
  Check, 
  Download, 
  ShieldCheck, 
  Monitor, 
  Apple, 
  Smartphone, 
  Wifi, 
  Play, 
  Trash2, 
  AlertTriangle,
  Info
} from 'lucide-react';
import { AdbStatus } from '../types';
import { ANDROID_FILES } from '../data/androidCodePackage';

interface AdbActivationProps {
  adbStatus: AdbStatus;
  setAdbStatus: React.Dispatch<React.SetStateAction<AdbStatus>>;
  terminalLogs: string[];
  setTerminalLogs: React.Dispatch<React.SetStateAction<string[]>>;
}

export const AdbActivation: React.FC<AdbActivationProps> = ({
  adbStatus,
  setAdbStatus,
  terminalLogs,
  setTerminalLogs,
}) => {
  const [activeTab, setActiveTab] = useState<'windows' | 'mac_linux' | 'termux' | 'wifi' | 'terminal'>('windows');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [wifiIpPort, setWifiIpPort] = useState('192.168.1.100:39845');
  const [wifiCode, setWifiCode] = useState('');
  const [commandInput, setCommandInput] = useState('');
  const [isExecuting, setIsExecuting] = useState(false);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const downloadFile = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const batFile = ANDROID_FILES.find(f => f.id === 'activatebat')?.content || '';
  const shFile = ANDROID_FILES.find(f => f.id === 'activatesh')?.content || '';

  // Trigger elevated status
  const triggerRootlessActivation = () => {
    setIsExecuting(true);
    setTerminalLogs(prev => [
      ...prev,
      `$ adb shell appops set com.patrik.meusarquivospat SYSTEM_ALERT_WINDOW allow`,
      `[OK] SYSTEM_ALERT_WINDOW concedido com sucesso (UID 2000 shell).`,
      `$ adb shell pm grant com.patrik.meusarquivospat android.permission.WRITE_SECURE_SETTINGS`,
      `[OK] WRITE_SECURE_SETTINGS liberado para controle térmico.`,
      `$ adb shell am broadcast -a com.patrik.meusarquivospat.ACTION_ADB_ACTIVATED --es token PAT_ROOTLESS_PRO_2026`,
      `Broadcasting: Intent { act=com.patrik.meusarquivospat.ACTION_ADB_ACTIVATED (has extras) }`,
      `Broadcast completed: result=0`,
      `[SUCESSO] Aplicativo MEUS ARQUIVOS PAT ativado sem root!`
    ]);

    setTimeout(() => {
      setAdbStatus({
        connected: true,
        mode: 'rootless_active',
        deviceModel: 'Android Device (ADB Shell UID 2000)',
        androidVersion: 'Android 14 (API 34)',
        securityPatch: '2026-03-01',
        grantedPermissions: {
          systemAlertWindow: true,
          writeSecureSettings: true,
          dump: true,
          packageUsageStats: true
        },
        lastActivatedAt: new Date().toLocaleTimeString('pt-BR')
      });
      setIsExecuting(false);
    }, 800);
  };

  const handleRunCommand = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!commandInput.trim()) return;

    const cmd = commandInput.trim();
    setTerminalLogs(prev => [...prev, `$ ${cmd}`]);

    // Simulated responses
    setTimeout(() => {
      if (cmd.includes('getprop')) {
        setTerminalLogs(prev => [
          ...prev,
          `[ro.product.model]: [SM-S928B]`,
          `[ro.build.version.release]: [14]`,
          `[ro.build.version.sdk]: [34]`
        ]);
      } else if (cmd.includes('battery')) {
        setTerminalLogs(prev => [
          ...prev,
          `Current Battery Service state:`,
          `  AC powered: false`,
          `  USB powered: true`,
          `  level: 82`,
          `  scale: 100`,
          `  temperature: 342 (34.2 °C)`,
          `  technology: Li-poly`
        ]);
      } else if (cmd.includes('thermal')) {
        setTerminalLogs(prev => [
          ...prev,
          `41800 (SoC CPU: 41.8 °C | Status: NORMAL)`
        ]);
      } else if (cmd.includes('appops') || cmd.includes('grant') || cmd.includes('broadcast')) {
        setTerminalLogs(prev => [
          ...prev,
          `Operation performed successfully. Status code: 0`
        ]);
        if (!adbStatus.connected) {
          triggerRootlessActivation();
        }
      } else {
        setTerminalLogs(prev => [
          ...prev,
          `Comando executado com sucesso no ambiente shell ADB.`
        ]);
      }
    }, 300);

    setCommandInput('');
  };

  return (
    <div className="flex-1 flex flex-col p-4 md:p-6 overflow-y-auto space-y-6">
      
      {/* Banner de Explicação de Ativação Sem Root */}
      <div className="p-4 md:p-5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start space-x-3">
            <div className={`p-2.5 rounded-lg shrink-0 ${adbStatus.connected ? 'bg-emerald-950 border border-emerald-800 text-emerald-400' : 'bg-amber-950 border border-amber-800 text-amber-400'}`}>
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-sm font-bold text-white tracking-wide">
                  Ativação Externa via ADB (Sem Root)
                </h2>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                  adbStatus.connected ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold' : 'bg-neutral-800 text-neutral-400'
                }`}>
                  {adbStatus.connected ? 'ATIVADO (PRIVILÉGIOS CONCEDIDOS)' : 'AGUARDANDO ATIVAÇÃO EXTERNA'}
                </span>
              </div>
              <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
                Por que ativar de fora? No Android, aplicativos comuns não conseguem conceder permissões a si mesmos (<code className="text-neutral-300 font-mono">pm grant</code> falha). Executando o script via ADB pelo computador ou Termux, o sistema concede permissão de sobreposição para o <strong>Menu Flutuante (HUD)</strong> e acesso a métricas avançadas <strong>sem precisar de Root ou desbloquear bootloader</strong>!
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 shrink-0">
            {adbStatus.connected ? (
              <button
                onClick={() => {
                  setAdbStatus({
                    connected: false,
                    mode: 'disconnected',
                    deviceModel: 'Desconectado',
                    androidVersion: 'Desconhecido',
                    securityPatch: 'N/A',
                    grantedPermissions: {
                      systemAlertWindow: false,
                      writeSecureSettings: false,
                      dump: false,
                      packageUsageStats: false
                    }
                  });
                  setTerminalLogs(prev => [...prev, `[INFO] Conexão ADB resetada para teste.`]);
                }}
                className="px-3 py-1.5 rounded bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-xs text-neutral-300 font-mono"
              >
                Resetar Status
              </button>
            ) : (
              <button
                onClick={triggerRootlessActivation}
                disabled={isExecuting}
                className="px-4 py-2 rounded bg-white text-black font-bold text-xs hover:bg-neutral-200 transition shadow flex items-center space-x-1.5"
              >
                <Play className="w-3.5 h-3.5 fill-black" />
                <span>Simular Ativação Externa</span>
              </button>
            )}
          </div>
        </div>

        {/* Status Metrics Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-neutral-900 text-[11px] font-mono">
          <div className="p-2 rounded bg-black/50 border border-neutral-900">
            <span className="text-neutral-500 block text-[10px]">Menu Flutuante (Overlay):</span>
            <span className={adbStatus.grantedPermissions.systemAlertWindow ? 'text-emerald-400 font-bold' : 'text-neutral-400'}>
              {adbStatus.grantedPermissions.systemAlertWindow ? 'LIBERADO (allow)' : 'Pendente'}
            </span>
          </div>
          <div className="p-2 rounded bg-black/50 border border-neutral-900">
            <span className="text-neutral-500 block text-[10px]">Configurações Seguras:</span>
            <span className={adbStatus.grantedPermissions.writeSecureSettings ? 'text-emerald-400 font-bold' : 'text-neutral-400'}>
              {adbStatus.grantedPermissions.writeSecureSettings ? 'CONCEDIDO (grant)' : 'Pendente'}
            </span>
          </div>
          <div className="p-2 rounded bg-black/50 border border-neutral-900">
            <span className="text-neutral-500 block text-[10px]">Telemetria / DUMP:</span>
            <span className={adbStatus.grantedPermissions.dump ? 'text-emerald-400 font-bold' : 'text-neutral-400'}>
              {adbStatus.grantedPermissions.dump ? 'CONCEDIDO (grant)' : 'Pendente'}
            </span>
          </div>
          <div className="p-2 rounded bg-black/50 border border-neutral-900">
            <span className="text-neutral-500 block text-[10px]">Dispositivo / UID:</span>
            <span className="text-neutral-300 truncate block">
              {adbStatus.connected ? 'UID 2000 (Shell)' : 'UID App (Restrito)'}
            </span>
          </div>
        </div>
      </div>

      {/* Tabs de Métodos de Ativação */}
      <div className="flex border-b border-neutral-800 space-x-1 overflow-x-auto text-xs">
        <button
          onClick={() => setActiveTab('windows')}
          className={`px-4 py-2 font-medium rounded-t transition flex items-center space-x-2 whitespace-nowrap ${
            activeTab === 'windows'
              ? 'bg-neutral-900 text-white border-t-2 border-white'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <Monitor className="w-3.5 h-3.5 text-blue-400" />
          <span>Windows PC (.bat)</span>
        </button>

        <button
          onClick={() => setActiveTab('mac_linux')}
          className={`px-4 py-2 font-medium rounded-t transition flex items-center space-x-2 whitespace-nowrap ${
            activeTab === 'mac_linux'
              ? 'bg-neutral-900 text-white border-t-2 border-white'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <Apple className="w-3.5 h-3.5 text-neutral-300" />
          <span>Mac & Linux (.sh)</span>
        </button>

        <button
          onClick={() => setActiveTab('termux')}
          className={`px-4 py-2 font-medium rounded-t transition flex items-center space-x-2 whitespace-nowrap ${
            activeTab === 'termux'
              ? 'bg-neutral-900 text-white border-t-2 border-white'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
          <span>Termux (Sem PC)</span>
        </button>

        <button
          onClick={() => setActiveTab('wifi')}
          className={`px-4 py-2 font-medium rounded-t transition flex items-center space-x-2 whitespace-nowrap ${
            activeTab === 'wifi'
              ? 'bg-neutral-900 text-white border-t-2 border-white'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <Wifi className="w-3.5 h-3.5 text-cyan-400" />
          <span>Pareamento Wi-Fi</span>
        </button>

        <button
          onClick={() => setActiveTab('terminal')}
          className={`px-4 py-2 font-medium rounded-t transition flex items-center space-x-2 whitespace-nowrap ${
            activeTab === 'terminal'
              ? 'bg-neutral-900 text-white border-t-2 border-white'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <Terminal className="w-3.5 h-3.5 text-amber-400" />
          <span>Terminal ADB Interativo</span>
        </button>
      </div>

      {/* Conteúdo da Tab Selecionada */}
      <div className="space-y-4">

        {/* TAB: Windows PC */}
        {activeTab === 'windows' && (
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">Instruções para Windows</h3>
                  <p className="text-xs text-neutral-400">Execute o arquivo batch abaixo com o celular conectado ao USB.</p>
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => copyToClipboard(batFile, 'bat-copy')}
                    className="px-3 py-1.5 rounded bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 text-xs text-white flex items-center space-x-1.5 transition"
                  >
                    {copiedId === 'bat-copy' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedId === 'bat-copy' ? 'Copiado!' : 'Copiar Código'}</span>
                  </button>
                  <button
                    onClick={() => downloadFile('ativar_pat.bat', batFile)}
                    className="px-3 py-1.5 rounded bg-white text-black font-bold text-xs hover:bg-neutral-200 flex items-center space-x-1.5 transition"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Baixar ativar_pat.bat</span>
                  </button>
                </div>
              </div>

              {/* Steps List */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs pt-1">
                <div className="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800/80 space-y-1">
                  <span className="font-bold text-neutral-200">1. Ativar Depuração USB</span>
                  <p className="text-neutral-400 text-[11px]">Vá em Configurações &gt; Opções do Desenvolvedor &gt; Depuração USB e ative.</p>
                </div>
                <div className="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800/80 space-y-1">
                  <span className="font-bold text-neutral-200">2. Conectar ao PC</span>
                  <p className="text-neutral-400 text-[11px]">Plugue o cabo USB. Na tela do celular, marque &quot;Sempre permitir deste computador&quot;.</p>
                </div>
                <div className="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800/80 space-y-1">
                  <span className="font-bold text-neutral-200">3. Executar o Script</span>
                  <p className="text-neutral-400 text-[11px]">Dê dois cliques no <code className="text-white">ativar_pat.bat</code>. O app ativará na hora!</p>
                </div>
              </div>

              {/* Code Preview */}
              <div className="relative">
                <pre className="p-3 rounded-lg bg-black border border-neutral-800 text-[11px] font-mono text-neutral-300 overflow-x-auto max-h-56">
                  {batFile}
                </pre>
              </div>
            </div>
          </div>
        )}

        {/* TAB: Mac & Linux */}
        {activeTab === 'mac_linux' && (
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">Instruções para Mac e Linux</h3>
                  <p className="text-xs text-neutral-400">Execute o script shell no terminal com permissão de execução.</p>
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => copyToClipboard(shFile, 'sh-copy')}
                    className="px-3 py-1.5 rounded bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 text-xs text-white flex items-center space-x-1.5 transition"
                  >
                    {copiedId === 'sh-copy' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedId === 'sh-copy' ? 'Copiado!' : 'Copiar Script'}</span>
                  </button>
                  <button
                    onClick={() => downloadFile('ativar_pat.sh', shFile)}
                    className="px-3 py-1.5 rounded bg-white text-black font-bold text-xs hover:bg-neutral-200 flex items-center space-x-1.5 transition"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Baixar ativar_pat.sh</span>
                  </button>
                </div>
              </div>

              {/* Quick Terminal Command */}
              <div className="p-3 rounded-lg bg-neutral-900 border border-neutral-800 space-y-2">
                <div className="text-[11px] text-neutral-400">Comando rápido no terminal:</div>
                <div className="flex items-center justify-between p-2 rounded bg-black font-mono text-xs text-emerald-400">
                  <code>chmod +x ativar_pat.sh && ./ativar_pat.sh</code>
                  <button 
                    onClick={() => copyToClipboard("chmod +x ativar_pat.sh && ./ativar_pat.sh", "cmd-sh")}
                    className="text-neutral-400 hover:text-white"
                  >
                    {copiedId === 'cmd-sh' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* Code Preview */}
              <pre className="p-3 rounded-lg bg-black border border-neutral-800 text-[11px] font-mono text-neutral-300 overflow-x-auto max-h-56">
                {shFile}
              </pre>
            </div>
          </div>
        )}

        {/* TAB: Termux (No próprio celular sem PC) */}
        {activeTab === 'termux' && (
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
              <div className="flex items-center space-x-2">
                <Smartphone className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-bold text-white">Ativação Direta via Termux (Sem precisar de PC)</h3>
              </div>
              <p className="text-xs text-neutral-400 leading-relaxed">
                Em aparelhos com Android 11 ou superior, você pode ativar o <strong>Meus Arquivos PAT</strong> diretamente dentro do celular usando o aplicativo Termux com Wi-Fi ativo!
              </p>

              <div className="space-y-3 pt-2 text-xs">
                {/* Step 1 */}
                <div className="p-3 rounded-lg bg-neutral-900/70 border border-neutral-800 space-y-1.5">
                  <div className="font-bold text-white flex items-center justify-between">
                    <span>1. Instale as ferramentas ADB no Termux:</span>
                    <button 
                      onClick={() => copyToClipboard("pkg update && pkg install android-tools -y", "termux-1")}
                      className="text-neutral-400 hover:text-white text-[11px] flex items-center gap-1 font-mono"
                    >
                      {copiedId === 'termux-1' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>Copiar</span>
                    </button>
                  </div>
                  <pre className="p-2 rounded bg-black font-mono text-neutral-300 text-[11px]">pkg update && pkg install android-tools -y</pre>
                </div>

                {/* Step 2 */}
                <div className="p-3 rounded-lg bg-neutral-900/70 border border-neutral-800 space-y-1.5">
                  <div className="font-bold text-white flex items-center justify-between">
                    <span>2. Parear com o Depuração por Wi-Fi:</span>
                    <button 
                      onClick={() => copyToClipboard("adb pair 127.0.0.1:PORTA CODIGO", "termux-2")}
                      className="text-neutral-400 hover:text-white text-[11px] flex items-center gap-1 font-mono"
                    >
                      {copiedId === 'termux-2' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>Copiar</span>
                    </button>
                  </div>
                  <p className="text-[11px] text-neutral-400">Em Desenvolvedor &gt; Depuração sem fio &gt; Parear com código. Digite:</p>
                  <pre className="p-2 rounded bg-black font-mono text-emerald-400 text-[11px]">adb pair 127.0.0.1:[PORTA_PAREAMENTO] [CODIGO_6_DIGITOS]</pre>
                </div>

                {/* Step 3 */}
                <div className="p-3 rounded-lg bg-neutral-900/70 border border-neutral-800 space-y-1.5">
                  <div className="font-bold text-white flex items-center justify-between">
                    <span>3. Executar o comando de concessão de privilégios:</span>
                    <button 
                      onClick={() => copyToClipboard(`adb shell appops set com.patrik.meusarquivospat SYSTEM_ALERT_WINDOW allow && adb shell pm grant com.patrik.meusarquivospat android.permission.WRITE_SECURE_SETTINGS && adb shell am broadcast -a com.patrik.meusarquivospat.ACTION_ADB_ACTIVATED --es token PAT_ROOTLESS_PRO_2026`, "termux-3")}
                      className="text-neutral-400 hover:text-white text-[11px] flex items-center gap-1 font-mono"
                    >
                      {copiedId === 'termux-3' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>Copiar Tudo</span>
                    </button>
                  </div>
                  <pre className="p-2 rounded bg-black font-mono text-neutral-300 text-[10px] overflow-x-auto whitespace-pre-wrap">
                    adb shell appops set com.patrik.meusarquivospat SYSTEM_ALERT_WINDOW allow && adb shell pm grant com.patrik.meusarquivospat android.permission.WRITE_SECURE_SETTINGS && adb shell am broadcast -a com.patrik.meusarquivospat.ACTION_ADB_ACTIVATED --es token PAT_ROOTLESS_PRO_2026
                  </pre>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB: Pareamento Wi-Fi Integrado */}
        {activeTab === 'wifi' && (
          <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-4">
            <div>
              <h3 className="text-sm font-bold text-white">Pareamento Wireless ADB Direto</h3>
              <p className="text-xs text-neutral-400">Conecte-se à mesma rede Wi-Fi e insira a porta e código exibidos na tela do Android.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-mono text-neutral-400 mb-1">IP e Porta de Pareamento</label>
                <input
                  type="text"
                  value={wifiIpPort}
                  onChange={e => setWifiIpPort(e.target.value)}
                  placeholder="192.168.1.xxx:37123"
                  className="w-full bg-black border border-neutral-800 p-2 text-xs font-mono text-white rounded focus:border-white outline-none"
                />
              </div>
              <div>
                <label className="block text-[11px] font-mono text-neutral-400 mb-1">Código de Pareamento Wi-Fi (6 dígitos)</label>
                <input
                  type="password"
                  value={wifiCode}
                  maxLength={6}
                  onChange={e => setWifiCode(e.target.value)}
                  placeholder="Ex: 849201"
                  className="w-full bg-black border border-neutral-800 p-2 text-xs font-mono text-white rounded focus:border-white outline-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <div className="text-[11px] text-neutral-500 flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5" />
                <span>Requer Android 11 ou superior conectado na mesma rede Wi-Fi.</span>
              </div>
              <button
                onClick={() => {
                  if (wifiCode.length !== 6) {
                    alert("O código de pareamento deve possuir exatamente 6 dígitos.");
                    return;
                  }
                  triggerRootlessActivation();
                }}
                className="px-4 py-2 rounded bg-white text-black font-bold text-xs hover:bg-neutral-200 transition"
              >
                Parear e Ativar Agora
              </button>
            </div>
          </div>
        )}

        {/* TAB: Terminal ADB Interativo */}
        {activeTab === 'terminal' && (
          <div className="rounded-xl bg-neutral-950 border border-neutral-800 overflow-hidden flex flex-col">
            <div className="h-10 px-4 border-b border-neutral-800 flex items-center justify-between bg-black">
              <div className="flex items-center space-x-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-mono font-bold text-white">ADB SHELL INTERACTIVE CONSOLE</span>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setTerminalLogs([`Terminal limpo. Digite comandos ou selecione os atalhos abaixo.`])}
                  className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white"
                  title="Limpar logs"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Quick Presets */}
            <div className="p-2.5 bg-neutral-900/50 border-b border-neutral-800 flex flex-wrap gap-1.5 text-[10px] font-mono">
              <span className="text-neutral-500 py-1 pr-1">Atalhos rápidos:</span>
              <button
                onClick={() => {
                  setCommandInput("getprop ro.product.model");
                }}
                className="px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 hover:bg-neutral-700 hover:text-white"
              >
                getprop model
              </button>
              <button
                onClick={() => {
                  setCommandInput("dumpsys battery");
                }}
                className="px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 hover:bg-neutral-700 hover:text-white"
              >
                dumpsys battery
              </button>
              <button
                onClick={() => {
                  setCommandInput("cat /sys/class/thermal/thermal_zone0/temp");
                }}
                className="px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 hover:bg-neutral-700 hover:text-white"
              >
                cat thermal_zone
              </button>
              <button
                onClick={() => {
                  setCommandInput("appops get com.patrik.meusarquivospat SYSTEM_ALERT_WINDOW");
                }}
                className="px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 hover:bg-neutral-700 hover:text-white"
              >
                check overlay permission
              </button>
            </div>

            {/* Terminal Body */}
            <div className="h-64 p-3 bg-black font-mono text-xs overflow-y-auto space-y-1 text-neutral-300 custom-scrollbar">
              {terminalLogs.map((line, idx) => (
                <div 
                  key={idx} 
                  className={
                    line.startsWith('$') 
                      ? 'text-cyan-400 font-bold' 
                      : line.includes('[OK]') || line.includes('[SUCESSO]')
                      ? 'text-emerald-400' 
                      : line.includes('[ERRO]') 
                      ? 'text-rose-400' 
                      : 'text-neutral-400'
                  }
                >
                  {line}
                </div>
              ))}
            </div>

            {/* Command Prompt Input */}
            <form onSubmit={handleRunCommand} className="p-2 border-t border-neutral-800 bg-neutral-950 flex items-center space-x-2">
              <span className="font-mono text-xs text-emerald-400 pl-2">$</span>
              <input
                type="text"
                value={commandInput}
                onChange={e => setCommandInput(e.target.value)}
                placeholder="Ex: getprop, dumpsys battery, appops set..."
                className="flex-1 bg-transparent text-xs font-mono text-white outline-none"
              />
              <button
                type="submit"
                className="px-3 py-1 rounded bg-white text-black font-bold text-xs hover:bg-neutral-200 transition"
              >
                Executar
              </button>
            </form>
          </div>
        )}

      </div>

    </div>
  );
};
