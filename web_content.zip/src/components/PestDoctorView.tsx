import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Camera,
  AlertTriangle,
  CheckCircle2,
  ShieldAlert,
  Sparkles,
  Droplets,
  Calendar,
  Volume2,
  VolumeX,
  Printer,
  ChevronRight,
  RefreshCw,
  Search,
  Filter,
  Check,
  Leaf,
  Layers,
  Store,
  FileCheck2,
  Sliders,
  ExternalLink,
} from 'lucide-react';
import { Language, UserProfile, PestDiagnosticCase, PlantPart } from '../types';
import { PEST_DIAGNOSTIC_CASES } from '../data/mockData';
import { playKeyTap, playSuccessChime } from '../utils/audio';

interface PestDoctorViewProps {
  language: Language;
  user: UserProfile;
  onNavigateToInputsStore?: () => void;
  onNavigateToFarmRecords?: () => void;
}

export default function PestDoctorView({
  language,
  user,
  onNavigateToInputsStore,
  onNavigateToFarmRecords,
}: PestDoctorViewProps) {
  const isSw = language === 'sw';

  // Active sub-tab
  const [activeTab, setActiveTab] = useState<'scanner' | 'library' | 'dosage_calculator'>('scanner');

  // Scanner States
  const [selectedCropFilter, setSelectedCropFilter] = useState<string>('all');
  const [selectedPlantPart, setSelectedPlantPart] = useState<PlantPart | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCase, setSelectedCase] = useState<PestDiagnosticCase>(PEST_DIAGNOSTIC_CASES[0]);

  // Simulated Scanning Animation State
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanProgress, setScanProgress] = useState<number>(0);
  const [scanCompleted, setScanCompleted] = useState<boolean>(false);

  // Audio Speech Synthesis
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  // Dosage Calculator State
  const [sprayerType, setSprayerType] = useState<'knapsack_16l' | 'knapsack_20l' | 'boom_sprayer'>('knapsack_16l');
  const [acresToSpray, setAcresToSpray] = useState<number>(2.5);
  const [pumpsPerAcre, setPumpsPerAcre] = useState<number>(4);

  // Notification Toast for logged activity
  const [loggedToast, setLoggedToast] = useState<string | null>(null);

  // Run simulated camera/photo scan
  const handleStartScan = (targetCase?: PestDiagnosticCase) => {
    playKeyTap();
    setIsScanning(true);
    setScanProgress(0);
    setScanCompleted(false);

    const caseToDiagnose = targetCase || selectedCase;

    const interval = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsScanning(false);
          setScanCompleted(true);
          setSelectedCase(caseToDiagnose);
          playSuccessChime();
          return 100;
        }
        return prev + 20;
      });
    }, 280);
  };

  // Text to speech for rural farmers
  const handleToggleSpeech = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const text = isSw
      ? `Uchunguzi: ${selectedCase.nameSw}. Sehemu iliyoathirika: ${selectedCase.plantPart}. Tiba asilia: ${selectedCase.organicTreatmentSw}. Dawa ya TPRI: ${selectedCase.chemicalTreatment.productName}. Kipimo: ${selectedCase.chemicalTreatment.dosageGuideSw}.`
      : `Diagnosis: ${selectedCase.nameEn}. Affected part: ${selectedCase.plantPart}. Organic remedy: ${selectedCase.organicTreatmentEn}. Recommended TPRI product: ${selectedCase.chemicalTreatment.productName}. Dosage: ${selectedCase.chemicalTreatment.dosageGuideEn}.`;

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = isSw ? 'sw-TZ' : 'en-US';
    utterance.rate = 0.95;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };

  // Log to farm activity records
  const handleLogToFarmBook = () => {
    playSuccessChime();
    const msg = isSw
      ? `Uchunguzi wa "${selectedCase.nameSw}" umerekodiwa kwenye Daftari la Shamba lako!`
      : `Diagnostic for "${selectedCase.nameEn}" successfully logged into your Farm Activity Book!`;
    setLoggedToast(msg);
    setTimeout(() => {
      setLoggedToast(null);
    }, 4500);
  };

  // Filtered cases
  const filteredCases = PEST_DIAGNOSTIC_CASES.filter((item) => {
    const matchesCrop = selectedCropFilter === 'all' || item.cropKey === selectedCropFilter;
    const matchesPart = selectedPlantPart === 'all' || item.plantPart === selectedPlantPart;
    const matchesSearch =
      searchQuery.trim() === '' ||
      item.nameSw.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.nameEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.cropNameSw.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.cropNameEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.symptomsSw.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesCrop && matchesPart && matchesSearch;
  });

  // Calculate dosage requirements
  const totalPumps = Math.ceil(acresToSpray * pumpsPerAcre);
  const mlPerPump = 15; // default 15 ml for knapsack
  const totalMlNeeded = totalPumps * mlPerPump;
  const bottlesNeeded = Math.ceil(totalMlNeeded / 100); // 100ml packaging
  const estimatedChemicalCost = bottlesNeeded * selectedCase.chemicalTreatment.estimatedCostTsh;

  return (
    <div id="pest-doctor-view" className="space-y-4 pb-12">
      {/* 1. Header Banner */}
      <div className="rounded-3xl p-5 bg-gradient-to-br from-emerald-800 via-[var(--forest)] to-teal-900 text-[#F7F4E9] shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-400/20 text-emerald-300 text-[10px] font-bold uppercase tracking-wider border border-emerald-400/30 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>{isSw ? 'Daktari wa Mimea & Afya ya Mazao' : 'Crop Doctor & Pest Diagnostics'}</span>
              </span>
              <span className="text-[10px] bg-amber-400/20 text-amber-200 px-2 py-0.5 rounded-full font-mono">
                TPRI / TFRA Verified
              </span>
            </div>
            <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white">
              {isSw ? 'Kitambuzi cha Wadudu & Magonjwa' : 'Pest & Crop Disease Field Doctor'}
            </h1>
            <p className="text-xs sm:text-sm text-emerald-100/90 max-w-xl mt-1 leading-relaxed">
              {isSw
                ? 'Tambua magonjwa na wadudu waharibifu kwa picha, pata tiba asilia bila kemikali au dawa zilizoidhinishwa na TPRI zikiwa na vipimo sahihi vya mabomba.'
                : 'Diagnose crop pests & fungal diseases in seconds with visual analysis, organic remedies, and TPRI-registered dosages for Tanzanian farmers.'}
            </p>
          </div>

          {/* Quick Stats Pill */}
          <div className="flex items-center gap-2 flex-wrap">
            <div className="bg-black/25 backdrop-blur-md rounded-2xl p-3 border border-white/10 text-center min-w-[90px]">
              <div className="font-mono text-lg font-bold text-amber-300">8+</div>
              <div className="text-[10px] text-white/80">{isSw ? 'Magonjwa Makuu' : 'Key Pathologies'}</div>
            </div>
            <div className="bg-black/25 backdrop-blur-md rounded-2xl p-3 border border-white/10 text-center min-w-[90px]">
              <div className="font-mono text-lg font-bold text-emerald-300">100%</div>
              <div className="text-[10px] text-white/80">{isSw ? 'Miongozo ya TPRI' : 'TPRI Guides'}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Toast Notification */}
      <AnimatePresence>
        {loggedToast && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-3 bg-emerald-600 text-white rounded-2xl shadow-lg text-xs font-bold flex items-center justify-between gap-3 border border-emerald-400"
          >
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
              <span>{loggedToast}</span>
            </div>
            {onNavigateToFarmRecords && (
              <button
                onClick={() => {
                  playKeyTap();
                  onNavigateToFarmRecords();
                }}
                className="py-1 px-2.5 rounded-xl bg-white text-emerald-800 text-[11px] font-bold hover:bg-emerald-50 cursor-pointer transition-all"
              >
                {isSw ? 'Tazama Shamba' : 'View Farm'}
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* 2. Three Navigation Sub-Tabs */}
      <div className="flex p-1 bg-[var(--bg)] rounded-2xl border border-[var(--line)] gap-1 shadow-xs overflow-x-auto">
        <button
          onClick={() => {
            playKeyTap();
            setActiveTab('scanner');
          }}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeTab === 'scanner'
              ? 'bg-[var(--paper)] text-[var(--forest)] shadow-xs border border-[var(--line)]'
              : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
          }`}
        >
          <Camera className="w-4 h-4 text-emerald-600 flex-shrink-0" />
          <span>{isSw ? 'Kipiga Picha & Uchunguzi' : 'Visual Field Scanner'}</span>
        </button>

        <button
          onClick={() => {
            playKeyTap();
            setActiveTab('library');
          }}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeTab === 'library'
              ? 'bg-[var(--paper)] text-[var(--forest)] shadow-xs border border-[var(--line)]'
              : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
          }`}
        >
          <Leaf className="w-4 h-4 text-amber-500 flex-shrink-0" />
          <span>{isSw ? 'Maktaba ya Magonjwa' : 'Disease Compendium'}</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-emerald-500/15 text-emerald-700 font-mono">
            {PEST_DIAGNOSTIC_CASES.length}
          </span>
        </button>

        <button
          onClick={() => {
            playKeyTap();
            setActiveTab('dosage_calculator');
          }}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeTab === 'dosage_calculator'
              ? 'bg-[var(--paper)] text-[var(--forest)] shadow-xs border border-[var(--line)]'
              : 'text-[var(--ink-soft)] hover:text-[var(--ink)]'
          }`}
        >
          <Droplets className="w-4 h-4 text-blue-500 flex-shrink-0" />
          <span>{isSw ? 'Kikokotoo cha Bomba la Dawa' : 'Sprayer Dosage Calc'}</span>
        </button>
      </div>

      {/* SUB-TAB 1: VISUAL SCANNER & DIAGNOSTIC LAB */}
      {activeTab === 'scanner' && (
        <div className="space-y-4">
          {/* Scanner Simulation Card */}
          <div className="rounded-3xl p-4 sm:p-6 bg-[var(--paper)] border border-[var(--line)] shadow-sm space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <h2 className="text-base sm:text-lg font-bold text-[var(--ink)] flex items-center gap-2">
                  <Camera className="w-5 h-5 text-emerald-600" />
                  <span>{isSw ? 'Uchunguzi wa Picha Shambani' : 'Field Photo Diagnostic Scanner'}</span>
                </h2>
                <p className="text-xs text-[var(--ink-soft)] mt-0.5">
                  {isSw
                    ? 'Chagua picha ya mmea ulioathirika au chagua sampuli ya ugonjwa kupima dalili.'
                    : 'Select an afflicted crop sample or simulate camera capture to identify disease symptoms.'}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleStartScan()}
                  disabled={isScanning}
                  className="py-2 px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm active:scale-95 transition-all cursor-pointer disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
                  <span>{isSw ? 'Changanua Upya' : 'Re-Scan'}</span>
                </button>
              </div>
            </div>

            {/* Simulated Viewfinder / Photo Stage */}
            <div className="relative w-full h-64 sm:h-72 rounded-2xl overflow-hidden bg-slate-900 border-2 border-dashed border-emerald-500/40 flex items-center justify-center">
              <img
                src={selectedCase.sampleImageUrl}
                alt={selectedCase.nameEn}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover opacity-85"
              />

              {/* Scanning Overlay Reticle */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/40 pointer-events-none" />

              {/* Viewfinder Target Frame */}
              <div className="absolute inset-6 border border-emerald-400/50 rounded-xl pointer-events-none flex flex-col justify-between p-2">
                <div className="flex justify-between">
                  <span className="w-4 h-4 border-t-2 border-l-2 border-emerald-400" />
                  <span className="w-4 h-4 border-t-2 border-r-2 border-emerald-400" />
                </div>

                {/* Animated Horizontal Scan Beam */}
                {isScanning && (
                  <motion.div
                    animate={{ y: [-90, 90, -90] }}
                    transition={{ repeat: Infinity, duration: 1.5, ease: 'easeInOut' }}
                    className="w-full h-1 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_15px_#10B981]"
                  />
                )}

                <div className="flex justify-between">
                  <span className="w-4 h-4 border-b-2 border-l-2 border-emerald-400" />
                  <span className="w-4 h-4 border-b-2 border-r-2 border-emerald-400" />
                </div>
              </div>

              {/* Bottom Stage Overlay with Sample Target Selector */}
              <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between gap-2 z-10">
                <div className="bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-xl text-white border border-white/15">
                  <div className="text-[10px] text-emerald-300 font-bold uppercase tracking-wider">
                    {isSw ? 'Mmea Uliochaguliwa' : 'Selected Target'}
                  </div>
                  <div className="text-xs font-bold text-white flex items-center gap-1">
                    <span>{selectedCase.icon}</span>
                    <span>{isSw ? selectedCase.nameSw : selectedCase.nameEn}</span>
                  </div>
                </div>

                <button
                  onClick={() => handleStartScan()}
                  disabled={isScanning}
                  className="py-2 px-4 rounded-xl bg-gradient-to-r from-amber-400 to-emerald-400 text-slate-950 text-xs font-black flex items-center gap-1.5 shadow-md active:scale-95 cursor-pointer transition-all"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>{isScanning ? (isSw ? 'Inachambua...' : 'Scanning...') : (isSw ? 'Piga Picha Shambani' : 'Capture & Analyze')}</span>
                </button>
              </div>

              {/* Progress Indicator when Scanning */}
              {isScanning && (
                <div className="absolute inset-0 bg-black/75 backdrop-blur-xs flex flex-col items-center justify-center p-4 z-20">
                  <div className="w-12 h-12 rounded-full border-4 border-emerald-500/20 border-t-emerald-400 animate-spin mb-3" />
                  <div className="font-display font-bold text-white text-base">
                    {isSw ? 'Inatambua Dalili za Magonjwa...' : 'Identifying Pathological Symptoms...'}
                  </div>
                  <div className="text-xs text-emerald-300 mt-1 font-mono">{scanProgress}% Imekamilika</div>
                </div>
              )}
            </div>

            {/* Quick Sample Selector Pills */}
            <div>
              <div className="text-xs font-bold text-[var(--ink)] mb-2 flex items-center justify-between">
                <span>{isSw ? 'Jaribu Sampuli za Magonjwa Shambani:' : 'Test Common Pathology Samples:'}</span>
                <span className="text-[11px] text-[var(--ink-soft)]">{PEST_DIAGNOSTIC_CASES.length} Sampuli</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
                {PEST_DIAGNOSTIC_CASES.map((item) => {
                  const isSelected = selectedCase.id === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleStartScan(item)}
                      className={`p-2 rounded-xl text-left border transition-all cursor-pointer flex flex-col gap-1 ${
                        isSelected
                          ? 'bg-emerald-500/15 border-emerald-500 text-emerald-900 dark:text-emerald-200 font-bold shadow-xs'
                          : 'bg-[var(--bg)] border-[var(--line)] text-[var(--ink)] hover:border-emerald-500/40'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-lg">{item.icon}</span>
                        <span
                          className={`text-[9px] px-1.5 py-0.2 rounded font-mono font-bold ${
                            item.severity === 'critical'
                              ? 'bg-red-500/20 text-red-700 dark:text-red-300'
                              : item.severity === 'high'
                              ? 'bg-amber-500/20 text-amber-800 dark:text-amber-300'
                              : 'bg-blue-500/20 text-blue-700 dark:text-blue-300'
                          }`}
                        >
                          {item.severity}
                        </span>
                      </div>
                      <div className="text-[11px] font-bold truncate leading-tight">
                        {isSw ? item.cropNameSw : item.cropNameEn}
                      </div>
                      <div className="text-[10px] text-[var(--ink-soft)] truncate">
                        {isSw ? item.nameSw.split('(')[0] : item.nameEn.split('(')[0]}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* 3. Comprehensive Clinical Diagnostic Report */}
          <div className="rounded-3xl p-5 bg-[var(--paper)] border border-[var(--line)] shadow-sm space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[var(--line)]">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/15 text-emerald-800 dark:text-emerald-300 flex items-center justify-center text-2xl flex-shrink-0">
                  {selectedCase.icon}
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                        selectedCase.severity === 'critical'
                          ? 'bg-red-500/20 text-red-700 dark:text-red-300'
                          : selectedCase.severity === 'high'
                          ? 'bg-amber-500/20 text-amber-800 dark:text-amber-300'
                          : 'bg-blue-500/20 text-blue-700 dark:text-blue-300'
                      }`}
                    >
                      {isSw ? `Hatari: ${selectedCase.severity.toUpperCase()}` : `Severity: ${selectedCase.severity.toUpperCase()}`}
                    </span>
                    <span className="text-xs text-[var(--ink-soft)] italic font-mono">
                      {selectedCase.scientificName}
                    </span>
                  </div>
                  <h3 className="font-display text-lg sm:text-xl font-bold text-[var(--ink)] mt-0.5">
                    {isSw ? selectedCase.nameSw : selectedCase.nameEn}
                  </h3>
                  <div className="text-xs text-[var(--ink-soft)]">
                    {isSw ? 'Zao Lililoathiriwa:' : 'Host Crop:'}{' '}
                    <span className="font-bold text-[var(--ink)]">
                      {isSw ? selectedCase.cropNameSw : selectedCase.cropNameEn}
                    </span>{' '}
                    • {isSw ? 'Sehemu:' : 'Affected Part:'}{' '}
                    <span className="capitalize font-bold text-[var(--ink)]">{selectedCase.plantPart}</span>
                  </div>
                </div>
              </div>

              {/* Speech Synthesizer for Audio Reading */}
              <div className="flex items-center gap-2">
                <button
                  onClick={handleToggleSpeech}
                  className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                    isSpeaking
                      ? 'bg-red-500/10 text-red-700 border-red-500/30'
                      : 'bg-[var(--bg)] text-[var(--ink)] border-[var(--line)] hover:border-emerald-500'
                  }`}
                  title={isSw ? 'Soma kwa Sauti' : 'Read Aloud'}
                >
                  {isSpeaking ? <VolumeX className="w-4 h-4 text-red-600" /> : <Volume2 className="w-4 h-4 text-emerald-600" />}
                  <span>{isSpeaking ? (isSw ? 'Simamisha Sauti' : 'Stop Audio') : (isSw ? 'Sikiliza Maelekezo' : 'Listen Guide')}</span>
                </button>
              </div>
            </div>

            {/* Diagnostic Clinical Symptoms */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-[var(--ink-soft)] mb-2 flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-amber-500" />
                <span>{isSw ? 'Dalili Kuu Zilizoonekana (Symptoms Checked)' : 'Clinical Symptoms Identified'}</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {(isSw ? selectedCase.symptomsSw : selectedCase.symptomsEn).map((symptom, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs text-[var(--ink)] flex items-start gap-2"
                  >
                    <Check className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0 mt-0.5" />
                    <span>{symptom}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Dual Treatment Solutions: Organic vs TPRI Agrochemical */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Organic Solution */}
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-wider mb-2">
                    <Leaf className="w-4 h-4 text-emerald-600" />
                    <span>{isSw ? '1. Tiba Asilia & Udhibiti wa Kienyeji' : '1. Organic & Cultural Solution'}</span>
                  </div>
                  <p className="text-xs text-[var(--ink)] leading-relaxed">
                    {isSw ? selectedCase.organicTreatmentSw : selectedCase.organicTreatmentEn}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-emerald-500/20 text-[11px] text-emerald-800 dark:text-emerald-300 font-semibold flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{isSw ? 'Salama kwa watumiaji, mifugo na viumbe rafiki' : 'Safe for pollinators, soil biology & organic export'}</span>
                </div>
              </div>

              {/* TPRI Registered Agrochemical Solution */}
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/25 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-amber-900 dark:text-amber-200 uppercase tracking-wider">
                      <Droplets className="w-4 h-4 text-amber-600" />
                      <span>{isSw ? '2. Dawa Iliyoidhinishwa na TPRI' : '2. TPRI Registered Chemical'}</span>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-900 dark:text-amber-200 font-bold">
                      {selectedCase.chemicalTreatment.tpriRegNumber}
                    </span>
                  </div>

                  <div className="font-bold text-sm text-[var(--ink)] mb-1">
                    {selectedCase.chemicalTreatment.productName}
                  </div>
                  <div className="text-[11px] text-[var(--ink-soft)] mb-2 font-mono">
                    {selectedCase.chemicalTreatment.activeIngredient}
                  </div>

                  <div className="p-2.5 rounded-xl bg-[var(--paper)] border border-amber-500/20 text-xs text-[var(--ink)] mb-2">
                    <div className="font-bold text-[11px] text-amber-800 dark:text-amber-300 mb-0.5">
                      {isSw ? 'Kipimo cha Bomba la Lita 16 (Knapsack):' : '16-Liter Knapsack Dosage:'}
                    </div>
                    <div>{isSw ? selectedCase.chemicalTreatment.dosageGuideSw : selectedCase.chemicalTreatment.dosageGuideEn}</div>
                  </div>
                </div>

                <div className="pt-2 border-t border-amber-500/20 flex items-center justify-between text-xs">
                  <span className="text-[11px] text-[var(--ink-soft)]">
                    {isSw ? 'Muda wa Kuvuna (PHI):' : 'Pre-Harvest Interval (PHI):'}
                  </span>
                  <span className="font-mono font-bold text-amber-800 dark:text-amber-300">
                    {selectedCase.chemicalTreatment.preHarvestIntervalDays} {isSw ? 'Siku' : 'Days'}
                  </span>
                </div>
              </div>
            </div>

            {/* Preventive Farm Measures */}
            <div className="p-3.5 rounded-2xl bg-[var(--bg)] border border-[var(--line)] flex items-start gap-2.5">
              <Sparkles className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
              <div className="text-xs text-[var(--ink)]">
                <span className="font-bold text-[var(--ink)]">
                  {isSw ? 'Kinga ya Baadaye Shambani: ' : 'Future Field Prevention: '}
                </span>
                <span>{isSw ? selectedCase.preventiveMeasuresSw : selectedCase.preventiveMeasuresEn}</span>
              </div>
            </div>

            {/* Bottom Actions: Log to Farm records & Order Certified Inputs */}
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-2.5">
              <button
                onClick={handleLogToFarmBook}
                className="w-full sm:w-auto py-2.5 px-4 rounded-xl bg-[var(--forest)] text-white text-xs font-bold flex items-center justify-center gap-2 shadow-sm hover:opacity-95 active:scale-95 transition-all cursor-pointer"
              >
                <FileCheck2 className="w-4 h-4 text-amber-300" />
                <span>{isSw ? 'Weka Kwenye Daftari la Shamba' : 'Log to Farm Activity Book'}</span>
              </button>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                {onNavigateToInputsStore && (
                  <button
                    onClick={() => {
                      playKeyTap();
                      onNavigateToInputsStore();
                    }}
                    className="flex-1 sm:flex-initial py-2.5 px-4 rounded-xl bg-amber-500/20 text-amber-900 dark:text-amber-200 border border-amber-500/30 text-xs font-bold flex items-center justify-center gap-1.5 hover:bg-amber-500/30 active:scale-95 transition-all cursor-pointer"
                  >
                    <Store className="w-4 h-4 text-amber-600" />
                    <span>{isSw ? 'Nunua Dawa (Soko la TFRA)' : 'Buy Treatment (TFRA Store)'}</span>
                  </button>
                )}

                <button
                  onClick={() => {
                    playKeyTap();
                    setActiveTab('dosage_calculator');
                  }}
                  className="py-2.5 px-3 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs font-bold text-[var(--ink)] hover:border-emerald-500 active:scale-95 transition-all cursor-pointer"
                  title={isSw ? 'Kikokotoo cha Bomba' : 'Dosage Calculator'}
                >
                  <Sliders className="w-4 h-4 text-emerald-600" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 2: DISEASE COMPENDIUM & SEARCH */}
      {activeTab === 'library' && (
        <div className="space-y-4">
          {/* Filters Bar */}
          <div className="rounded-2xl p-4 bg-[var(--paper)] border border-[var(--line)] shadow-xs flex flex-col sm:flex-row items-center gap-3">
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-[var(--ink-soft)] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={isSw ? 'Tafuta ugonjwa, wadudu, au dalili za mazao...' : 'Search disease, pest, or symptoms...'}
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs text-[var(--ink)] placeholder:text-[var(--ink-soft)] focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <select
                value={selectedCropFilter}
                onChange={(e) => setSelectedCropFilter(e.target.value)}
                className="flex-1 sm:flex-initial py-2 px-3 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs font-semibold text-[var(--ink)] cursor-pointer"
              >
                <option value="all">{isSw ? 'Mazao Yote' : 'All Crops'}</option>
                <option value="maize">{isSw ? 'Mahindi' : 'Maize'}</option>
                <option value="tomato">{isSw ? 'Nyanya' : 'Tomato'}</option>
                <option value="coffee">{isSw ? 'Kahawa' : 'Coffee'}</option>
                <option value="sesame">{isSw ? 'Ufuta' : 'Sesame'}</option>
                <option value="cassava">{isSw ? 'Muhogo' : 'Cassava'}</option>
                <option value="avocado">{isSw ? 'Parachichi' : 'Avocado'}</option>
              </select>

              <select
                value={selectedPlantPart}
                onChange={(e) => setSelectedPlantPart(e.target.value as PlantPart | 'all')}
                className="flex-1 sm:flex-initial py-2 px-3 rounded-xl bg-[var(--bg)] border border-[var(--line)] text-xs font-semibold text-[var(--ink)] cursor-pointer"
              >
                <option value="all">{isSw ? 'Sehemu Zote' : 'All Parts'}</option>
                <option value="leaves">{isSw ? 'Majani (Leaves)' : 'Leaves'}</option>
                <option value="fruit">{isSw ? 'Matunda (Fruit)' : 'Fruit'}</option>
                <option value="stem">{isSw ? 'Shina (Stem)' : 'Stem'}</option>
              </select>
            </div>
          </div>

          {/* Grid of All Pests */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {filteredCases.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  playKeyTap();
                  setSelectedCase(item);
                  setActiveTab('scanner');
                }}
                className="p-4 rounded-2xl bg-[var(--paper)] border border-[var(--line)] hover:border-emerald-500 shadow-xs cursor-pointer transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{item.icon}</span>
                      <div>
                        <div className="font-bold text-sm text-[var(--ink)] group-hover:text-emerald-700 dark:group-hover:text-emerald-300 transition-colors">
                          {isSw ? item.nameSw : item.nameEn}
                        </div>
                        <div className="text-[11px] text-[var(--ink-soft)] italic font-mono">
                          {item.scientificName}
                        </div>
                      </div>
                    </div>

                    <span
                      className={`text-[9px] px-2 py-0.5 rounded-full font-bold uppercase ${
                        item.severity === 'critical'
                          ? 'bg-red-500/20 text-red-700 dark:text-red-300'
                          : item.severity === 'high'
                          ? 'bg-amber-500/20 text-amber-800 dark:text-amber-300'
                          : 'bg-blue-500/20 text-blue-700 dark:text-blue-300'
                      }`}
                    >
                      {item.severity}
                    </span>
                  </div>

                  <div className="space-y-1 my-3">
                    {(isSw ? item.symptomsSw : item.symptomsEn).slice(0, 2).map((s, idx) => (
                      <div key={idx} className="text-[11px] text-[var(--ink-soft)] flex items-center gap-1.5 truncate">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 flex-shrink-0" />
                        <span className="truncate">{s}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-[var(--line)] flex items-center justify-between text-xs">
                  <span className="text-[11px] font-semibold text-emerald-700 dark:text-emerald-300">
                    TPRI: {item.chemicalTreatment.productName.split('/')[0]}
                  </span>
                  <span className="text-emerald-600 font-bold flex items-center gap-0.5 group-hover:translate-x-1 transition-transform">
                    <span>{isSw ? 'Tazama Tiba' : 'View Protocol'}</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-TAB 3: SPRAYER DOSAGE & TANK MIX CALCULATOR */}
      {activeTab === 'dosage_calculator' && (
        <div className="rounded-3xl p-5 bg-[var(--paper)] border border-[var(--line)] shadow-sm space-y-5">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-[var(--ink)] flex items-center gap-2">
              <Droplets className="w-5 h-5 text-blue-600" />
              <span>{isSw ? 'Kikokotoo Sahihi cha Dawa ya Kupulizia' : 'Knapsack Sprayer Tank Mix Calculator'}</span>
            </h2>
            <p className="text-xs text-[var(--ink-soft)] mt-0.5">
              {isSw
                ? 'Hesabu idadi kamili ya mabomba ya maji na ujazo sahihi wa mililita au gramu ili kuepuka kuunguza mimea au kupoteza gharama.'
                : 'Calculate precise knapsack tanks and milliliters required for your acreage to prevent crop scorching and input wastage.'}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Acreage Slider */}
            <div className="p-3.5 rounded-2xl bg-[var(--bg)] border border-[var(--line)]">
              <div className="flex items-center justify-between text-xs font-bold text-[var(--ink)] mb-1.5">
                <span>{isSw ? 'Eneo la Shamba (Hekari)' : 'Field Area (Acres)'}</span>
                <span className="font-mono text-emerald-700 dark:text-emerald-300">{acresToSpray} Hekari</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="10"
                step="0.5"
                value={acresToSpray}
                onChange={(e) => setAcresToSpray(parseFloat(e.target.value))}
                className="w-full accent-emerald-600 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[var(--ink-soft)] mt-1 font-mono">
                <span>0.5 Ac</span>
                <span>5 Ac</span>
                <span>10 Ac</span>
              </div>
            </div>

            {/* Sprayer Type */}
            <div className="p-3.5 rounded-2xl bg-[var(--bg)] border border-[var(--line)]">
              <div className="text-xs font-bold text-[var(--ink)] mb-1.5">
                {isSw ? 'Aina ya Bomba la Kupulizia' : 'Sprayer Tank Capacity'}
              </div>
              <select
                value={sprayerType}
                onChange={(e) => setSprayerType(e.target.value as any)}
                className="w-full py-2 px-3 rounded-xl bg-[var(--paper)] border border-[var(--line)] text-xs font-semibold text-[var(--ink)] cursor-pointer"
              >
                <option value="knapsack_16l">{isSw ? 'Bomba la Mgongoni (Lita 16)' : 'Knapsack 16 Liters'}</option>
                <option value="knapsack_20l">{isSw ? 'Bomba Kubwa (Lita 20)' : 'Knapsack 20 Liters'}</option>
                <option value="boom_sprayer">{isSw ? 'Trekta / Boom Sprayer (Lita 200)' : 'Tractor Boom (200L)'}</option>
              </select>
            </div>

            {/* Pumps Per Acre */}
            <div className="p-3.5 rounded-2xl bg-[var(--bg)] border border-[var(--line)]">
              <div className="flex items-center justify-between text-xs font-bold text-[var(--ink)] mb-1.5">
                <span>{isSw ? 'Mabomba kwa Hekari' : 'Tanks Per Acre'}</span>
                <span className="font-mono text-emerald-700 dark:text-emerald-300">{pumpsPerAcre} Mabomba</span>
              </div>
              <input
                type="range"
                min="2"
                max="8"
                step="1"
                value={pumpsPerAcre}
                onChange={(e) => setPumpsPerAcre(parseInt(e.target.value))}
                className="w-full accent-emerald-600 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[var(--ink-soft)] mt-1 font-mono">
                <span>2 (Nafuu)</span>
                <span>4 (Wastani)</span>
                <span>8 (Mimea mikubwa)</span>
              </div>
            </div>
          </div>

          {/* Results Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3.5 rounded-2xl bg-blue-500/10 border border-blue-500/20 text-center">
              <div className="text-[10px] uppercase font-bold text-blue-800 dark:text-blue-300">
                {isSw ? 'Jumla ya Mabomba' : 'Total Sprayer Tanks'}
              </div>
              <div className="font-mono text-xl font-bold text-blue-900 dark:text-blue-200 mt-1">
                {totalPumps} {isSw ? 'Mabomba' : 'Tanks'}
              </div>
              <div className="text-[10px] text-[var(--ink-soft)] mt-0.5 font-mono">
                {totalPumps * 16} {isSw ? 'Lita za Maji' : 'Liters Water'}
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-center">
              <div className="text-[10px] uppercase font-bold text-emerald-800 dark:text-emerald-300">
                {isSw ? 'Dawa kwa Bomba Moja' : 'Dosage Per Tank'}
              </div>
              <div className="font-mono text-xl font-bold text-emerald-900 dark:text-emerald-200 mt-1">
                {mlPerPump} ml
              </div>
              <div className="text-[10px] text-[var(--ink-soft)] mt-0.5">
                {isSw ? 'Vijiko 2 vya chakula' : '~2 Tablespoons'}
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-center">
              <div className="text-[10px] uppercase font-bold text-amber-800 dark:text-amber-300">
                {isSw ? 'Jumla ya Dawa Inayotakiwa' : 'Total Chemical Vol.'}
              </div>
              <div className="font-mono text-xl font-bold text-amber-900 dark:text-amber-200 mt-1">
                {totalMlNeeded} ml
              </div>
              <div className="text-[10px] text-[var(--ink-soft)] mt-0.5 font-mono">
                {bottlesNeeded} {isSw ? 'Chupa (Kopo za 100ml)' : 'Bottles (100ml)'}
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-[var(--forest)]/10 border border-[var(--forest)]/20 text-center">
              <div className="text-[10px] uppercase font-bold text-[var(--forest)]">
                {isSw ? 'Makadirio ya Gharama' : 'Estimated Cost'}
              </div>
              <div className="font-mono text-lg font-bold text-[var(--forest)] mt-1">
                Tsh {estimatedChemicalCost.toLocaleString()}
              </div>
              <div className="text-[10px] text-[var(--ink-soft)] mt-0.5">
                {isSw ? 'Bei ya TFA/TFRA' : 'Official TFRA Rate'}
              </div>
            </div>
          </div>

          {/* Safety & Precaution Advice */}
          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/25 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div className="text-xs text-[var(--ink)] space-y-1">
              <div className="font-bold text-amber-900 dark:text-amber-200">
                {isSw ? 'Kanuni za Usalama Wakati wa Kupulizia:' : 'Spraying Safety Protocols:'}
              </div>
              <p>
                {isSw
                  ? 'Vaa glavu, barakoa na nguo ndefu. Usipulizie dawa upepo ukiwa mkali kuelekea usoni mwako au jua kali la mchana (saa sita hadi saa tisa). Osha mikono kwa sabuni na usiruhusu watoto au mifugo kuingia shambani kwa siku 3.'
                  : 'Wear protective mask, gloves, and boots. Never spray against the wind or under scorching midday sun. Keep children and livestock out of treated fields for at least 72 hours.'}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
