import React, { useMemo, useState } from 'react';
import { marked } from 'marked';
import { Check, Copy } from 'lucide-react';

interface MarkdownViewProps {
  content: string;
  fontSize?: 'sm' | 'md' | 'lg';
}

export const MarkdownView: React.FC<MarkdownViewProps> = ({ content, fontSize = 'md' }) => {
  const [copiedIndex, setCopiedIndex] = useState<string | null>(null);

  // Configure marked for clean Github flavored markdown
  const htmlContent = useMemo(() => {
    try {
      marked.setOptions({
        gfm: true,
        breaks: true,
      });
      return marked.parse(content || '') as string;
    } catch (err) {
      return content || '';
    }
  }, [content]);

  const handleCopyCode = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(id);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const textSizeClass =
    fontSize === 'sm' ? 'text-sm' : fontSize === 'lg' ? 'text-base sm:text-lg' : 'text-[15px]';

  return (
    <div
      className={`markdown-body leading-relaxed text-slate-200 ${textSizeClass} select-text overflow-hidden break-words`}
      dangerouslySetInnerHTML={{ __html: htmlContent }}
      onClick={(e) => {
        // Allow copy button inside code blocks if rendered via custom wrapper or script
        const target = e.target as HTMLElement;
        const copyBtn = target.closest('.code-copy-btn');
        if (copyBtn) {
          const codeText = copyBtn.getAttribute('data-code') || '';
          if (codeText) {
            navigator.clipboard.writeText(codeText);
            const originalText = copyBtn.innerHTML;
            copyBtn.innerHTML = '✓ Disalin!';
            setTimeout(() => {
              copyBtn.innerHTML = originalText;
            }, 2000);
          }
        }
      }}
    />
  );
};
