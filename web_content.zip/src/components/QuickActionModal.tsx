import React from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Calendar,
  Wallet,
  Sparkles,
  Target,
  Brain,
  Plus,
  Flame,
} from 'lucide-react';
import { sound } from '../utils/sound';

export const QuickActionModal: React.FC = () => {
  const { isQuickActionOpen, setQuickActionOpen, setActiveScreen } = useApp();

  if (!isQuickActionOpen) return null;

  const handleAction = (screen: any) => {
    sound.playClick();
    setQuickActionOpen(false);
    setActiveScreen(screen);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 backdrop-blur-xs transition-opacity">
      <div
        className="w-full max-w-md bg-white dark:bg-slate-900 rounded-t-3xl border-t border-slate-200 dark:border-slate-800 p-5 shadow-2xl space-y-4 animate-in slide-in-from-bottom duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Grab Handle */}
        <div className="w-10 h-1 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto" />

        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Quick Action
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              What would you like to capture?
            </p>
          </div>
          <button
            onClick={() => {
              sound.playClick();
              setQuickActionOpen(false);
            }}
            className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2.5 pt-1">
          <button
            onClick={() => handleAction('planner')}
            className="p-3.5 rounded-2xl bg-indigo-50/80 dark:bg-indigo-950/40 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 border border-indigo-200/80 dark:border-indigo-800/80 text-left transition-all flex items-start gap-3"
          >
            <div className="p-2 rounded-xl bg-indigo-600 text-white shrink-0">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-indigo-950 dark:text-indigo-200 block">
                Schedule Task
              </span>
              <span className="text-[11px] text-indigo-800/70 dark:text-indigo-400">
                Add to your day
              </span>
            </div>
          </button>

          <button
            onClick={() => handleAction('money')}
            className="p-3.5 rounded-2xl bg-emerald-50/80 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border border-emerald-200/80 dark:border-emerald-800/80 text-left transition-all flex items-start gap-3"
          >
            <div className="p-2 rounded-xl bg-emerald-600 text-white shrink-0">
              <Wallet className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-emerald-950 dark:text-emerald-200 block">
                Log Expense
              </span>
              <span className="text-[11px] text-emerald-800/70 dark:text-emerald-400">
                Track coffee, food
              </span>
            </div>
          </button>

          <button
            onClick={() => handleAction('goals')}
            className="p-3.5 rounded-2xl bg-rose-50/80 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/60 border border-rose-200/80 dark:border-rose-800/80 text-left transition-all flex items-start gap-3"
          >
            <div className="p-2 rounded-xl bg-rose-600 text-white shrink-0">
              <Flame className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-rose-950 dark:text-rose-200 block">
                Check-in Habit
              </span>
              <span className="text-[11px] text-rose-800/70 dark:text-rose-400">
                Keep streak alive
              </span>
            </div>
          </button>

          <button
            onClick={() => handleAction('memory')}
            className="p-3.5 rounded-2xl bg-violet-50/80 dark:bg-violet-950/40 hover:bg-violet-100 dark:hover:bg-violet-900/60 border border-violet-200/80 dark:border-violet-800/80 text-left transition-all flex items-start gap-3"
          >
            <div className="p-2 rounded-xl bg-violet-600 text-white shrink-0">
              <Brain className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-violet-950 dark:text-violet-200 block">
                Save Memory
              </span>
              <span className="text-[11px] text-violet-800/70 dark:text-violet-400">
                Preferences & notes
              </span>
            </div>
          </button>
        </div>

        <button
          onClick={() => handleAction('buddy')}
          className="w-full py-3 rounded-2xl bg-gradient-to-r from-indigo-600 via-violet-600 to-indigo-700 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-md shadow-indigo-600/20 active:scale-[0.98] transition-all"
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>Talk with HiBuddy AI</span>
        </button>
      </div>
    </div>
  );
};
