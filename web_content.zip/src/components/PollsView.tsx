import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  BarChart3, 
  Sparkles, 
  CheckCircle2, 
  Clock, 
  Users 
} from 'lucide-react';

export const PollsView: React.FC = () => {
  const { polls, votePoll } = useApp();

  return (
    <div className="space-y-4">
      
      {/* Polls Header Banner */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
        <div>
          <h3 className="font-display font-bold text-base text-slate-100 flex items-center gap-1.5">
            <BarChart3 className="w-4 h-4 text-cyan-400" />
            <span>Campus Dilemmas & Polls</span>
          </h3>
          <p className="text-[11px] text-slate-400">
            Cast your anonymous vote. Results update instantly.
          </p>
        </div>
      </div>

      {/* Poll Cards List */}
      <div className="space-y-4">
        {polls.map(poll => {
          const hasVoted = Boolean(poll.userVotedOptionId);

          return (
            <div key={poll.id} className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-3">
              
              {/* Poll Metadata */}
              <div className="flex items-center justify-between text-xs text-slate-400">
                <div className="flex items-center gap-1.5">
                  <span className="text-cyan-400 font-semibold">{poll.category}</span>
                  <span aria-hidden="true">·</span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{poll.expiresIn}</span>
                  </span>
                </div>
                <div className="flex items-center gap-1 font-mono text-[11px] text-slate-300">
                  <Users className="w-3 h-3 text-slate-500" />
                  <span className="tabular-nums">{poll.totalVotes} votes</span>
                </div>
              </div>

              {/* Poll Question */}
              <h4 className="text-sm sm:text-base font-semibold text-slate-100 leading-snug">
                {poll.question}
              </h4>

              {/* Options */}
              <div className="space-y-2 pt-1">
                {poll.options.map(option => {
                  const percentage = poll.totalVotes > 0 
                    ? Math.round((option.votes / poll.totalVotes) * 100) 
                    : 0;
                  const isUserPick = poll.userVotedOptionId === option.id;

                  return (
                    <button
                      key={option.id}
                      onClick={() => votePoll(poll.id, option.id)}
                      disabled={hasVoted}
                      className={`relative w-full overflow-hidden rounded-xl border p-3 text-left transition-all ${
                        isUserPick 
                          ? 'border-cyan-500 bg-cyan-950/20 text-cyan-100' 
                          : 'border-slate-800 bg-slate-950/60 hover:border-slate-700 text-slate-200'
                      }`}
                    >
                      {/* Animated Progress Fill */}
                      {hasVoted && (
                        <div 
                          className={`absolute top-0 bottom-0 left-0 transition-all duration-700 ${
                            isUserPick ? 'bg-cyan-500/25' : 'bg-slate-800/60'
                          }`}
                          style={{ width: `${percentage}%` }}
                        />
                      )}

                      {/* Content Row */}
                      <div className="relative z-10 flex items-center justify-between text-xs sm:text-sm font-medium">
                        <div className="flex items-center gap-2">
                          {isUserPick && (
                            <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                          )}
                          <span>{option.text}</span>
                        </div>
                        {hasVoted && (
                          <span className="font-mono text-xs font-bold tabular-nums text-slate-300 shrink-0">
                            {percentage}%
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Feedback text */}
              {hasVoted && (
                <p className="text-[11px] text-emerald-400 text-right flex items-center justify-end gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>Vote recorded anonymously (+2 Karma)</span>
                </p>
              )}

            </div>
          );
        })}
      </div>

    </div>
  );
};
