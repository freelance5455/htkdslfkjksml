import React, { useState, useEffect, useRef } from 'react';
import { Radio, Video, Mic, StopCircle, Play, Pause, Plus, Trash2, Volume2, Sparkles, Shield, Flame, Sliders, Check, RefreshCw, Upload, FileAudio } from 'lucide-react';
import { audioEngine } from '../lib/audioEngine';

interface TrackItem {
  id: string;
  name: string;
  type: 'voice' | 'music' | 'ambience';
  durationSec: number;
  volume: number;
  isMuted: boolean;
  isActiveSource: boolean; // Selected for broadcast streaming
}

export const LiveBroadcastView: React.FC = () => {
  // Strict Role-Based Access Check: Only Prophet JUHNKRIX SYNVAGORD has access to streaming inputs
  const [userRole, setUserRole] = useState<'owner_prophet' | 'standard_visitor'>('owner_prophet');

  const [broadcastMode, setBroadcastMode] = useState<'none' | 'audio' | 'video'>('none');
  const [isLive, setIsLive] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [viewersCount, setViewersCount] = useState(1425);
  
  // Editor & Multitrack States (Host Only View)
  const [broadcastTitle, setBroadcastTitle] = useState('Global Prophetic Worship & Soaking Live Session');
  const [category, setCategory] = useState<'Prophetic Worship' | 'Deliverance & Warfare' | 'Soaking Prayer'>('Prophetic Worship');
  const [denoiseActive, setDenoiseActive] = useState(true);
  const [selectedEffect, setSelectedEffect] = useState<'none' | 'heavenly_reverb' | 'warm_chamber' | 'cathedral'>('heavenly_reverb');
  
  const [tracks, setTracks] = useState<TrackItem[]>([
    { id: '1', name: 'Main Prophet Voice Track', type: 'voice', durationSec: 180, volume: 0.9, isMuted: false, isActiveSource: true },
    { id: '2', name: 'Soaking Synth Pad (528Hz)', type: 'music', durationSec: 180, volume: 0.6, isMuted: false, isActiveSource: false },
    { id: '3', name: 'Ambient River & Wind', type: 'ambience', durationSec: 180, volume: 0.3, isMuted: false, isActiveSource: false },
  ]);

  // AI Voice-to-Text Transcription simulated feed
  const [transcriptLines, setTranscriptLines] = useState<string[]>([
    'Waiting for live prophetic utterance...',
    'Glory to God in the highest...',
  ]);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);

  // Elapsed timer when live & live speech transcription simulator
  useEffect(() => {
    let timer: number;
    let speechTimer: number;
    if (isLive) {
      timer = window.setInterval(() => {
        setElapsedTime((prev) => prev + 1);
        setViewersCount((prev) => Math.max(1200, prev + Math.floor(Math.random() * 7) - 3));
      }, 1000);

      const samplePhrases = [
        '“The Lord is restoring double for your trouble in this season...”',
        '“Let the river of His Holy Spirit flow through every sanctuary...”',
        '“Angelic hosts are surrounding your dwelling place with fire and peace...”',
        '“Walk in divine authority, for the breaker has gone before you...”',
        '“Soaking in the 528Hz frequency of divine healing and restoration...”',
      ];

      speechTimer = window.setInterval(() => {
        const randomPhrase = samplePhrases[Math.floor(Math.random() * samplePhrases.length)];
        setTranscriptLines((prev) => [randomPhrase, ...prev.slice(0, 5)]);
      }, 7000);
    }
    return () => {
      clearInterval(timer);
      clearInterval(speechTimer);
    };
  }, [isLive]);

  const startBroadcast = async (mode: 'audio' | 'video') => {
    if (userRole !== 'owner_prophet') {
      alert('Access Denied: Streaming inputs are strictly restricted to Prophet JUHNKRIX SYNVAGORD.');
      return;
    }
    setBroadcastMode(mode);
    setCameraError(null);
    try {
      const constraints = mode === 'video' ? { video: true, audio: true } : { audio: true };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      mediaStreamRef.current = stream;

      if (mode === 'video' && videoRef.current) {
        videoRef.current.srcObject = stream;
      }

      setIsLive(true);
      setElapsedTime(0);
    } catch (err: any) {
      console.warn('Media device access error:', err);
      setCameraError('Camera/Mic permission restricted or simulated preview active.');
      setIsLive(true);
      setElapsedTime(0);
    }
  };

  const stopBroadcast = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
    }
    setIsLive(false);
    setBroadcastMode('none');
  };

  const formatDuration = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const addTrack = (type: 'voice' | 'music' | 'ambience', customName?: string) => {
    const newTrack: TrackItem = {
      id: Date.now().toString(),
      name: customName || `New ${type.toUpperCase()} Track ${tracks.length + 1}`,
      type,
      durationSec: 150,
      volume: 0.7,
      isMuted: false,
      isActiveSource: false,
    };
    setTracks([...tracks, newTrack]);
  };

  const removeTrack = (id: string) => {
    setTracks(tracks.filter((t) => t.id !== id));
  };

  const toggleMuteTrack = (id: string) => {
    setTracks(tracks.map((t) => (t.id === id ? { ...t, isMuted: !t.isMuted } : t)));
  };

  const updateTrackVolume = (id: string, vol: number) => {
    setTracks(tracks.map((t) => (t.id === id ? { ...t, volume: vol } : t)));
  };

  const setActiveSourceTrack = (id: string) => {
    setTracks(tracks.map((t) => ({ ...t, isActiveSource: t.id === id })));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8 animate-fadeIn">
      {/* Role-Based Access Switcher & Header Banner */}
      <div className="bg-gradient-to-r from-amber-950/60 via-purple-950/40 to-slate-900 p-6 sm:p-8 rounded-3xl border border-amber-500/30 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden">
        <div className="space-y-2 text-center md:text-left z-10">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 text-xs font-bold">
            <Flame className="w-4 h-4 text-amber-400" />
            <span>GLOBAL PROPHETIC BROADCAST & AUDIO-VISUAL MONITOR</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold font-serif text-amber-100">
            Live Stream Sanctuary
          </h1>
          <p className="text-slate-300 text-xs sm:text-sm max-w-xl">
            {userRole === 'owner_prophet'
              ? 'Authorized Owner Mode: You have full streaming inputs, camera lens feed, multitrack mixing, and broadcast controls.'
              : 'Visitor Receiver Mode: Viewing live broadcast, camera feed, and wave sounds monitor in view-only mode.'}
          </p>
        </div>

        {/* Role Toggle Switch for Testing */}
        <div className="z-10 bg-slate-950/90 p-4 rounded-2xl border border-amber-500/30 flex flex-col items-center space-y-2 shadow-xl">
          <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">Strict Role Verification</span>
          <div className="flex bg-slate-900 p-1 rounded-xl border border-amber-500/30">
            <button
              onClick={() => setUserRole('owner_prophet')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                userRole === 'owner_prophet'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-amber-200'
              }`}
            >
              👑 Prophet Juhnkrix
            </button>
            <button
              onClick={() => {
                setUserRole('standard_visitor');
                stopBroadcast();
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                userRole === 'standard_visitor'
                  ? 'bg-slate-800 text-amber-300 border border-amber-500/40 shadow-md'
                  : 'text-slate-400 hover:text-amber-200'
              }`}
            >
              Visitor View
            </button>
          </div>
        </div>
      </div>

      {/* STANDARD VISITOR VIEW: View-Only Live Broadcast & Wave Sound Monitor */}
      {userRole === 'standard_visitor' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 py-4">
          <div className="lg:col-span-2 space-y-6">
            {/* Live Camera Lens & Audio Wave Stream Preview */}
            <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 rounded-full bg-emerald-500 animate-ping" />
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">LIVE BROADCAST IN PROGRESS</span>
                </div>
                <div className="px-3 py-1 rounded-full bg-amber-500/10 text-amber-300 text-xs font-mono border border-amber-500/20">
                  👥 {viewersCount} Soaking Believers Connected
                </div>
              </div>

              <div className="relative aspect-video bg-slate-950 rounded-2xl border border-amber-500/30 overflow-hidden flex flex-col items-center justify-center">
                {/* Camera Lens simulation overlay */}
                <div className="absolute top-3 left-3 px-3 py-1 rounded-xl bg-slate-900/80 border border-amber-500/20 text-[10px] text-amber-300 font-mono flex items-center space-x-1.5">
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                  <span>CAMERA LENS: ACTIVE STREAM 1080P HD</span>
                </div>

                <div className="text-center space-y-3 p-6 z-10">
                  <div className="w-20 h-20 rounded-full bg-amber-500/20 border border-amber-400/40 flex items-center justify-center mx-auto text-amber-400 animate-pulse">
                    <Flame className="w-10 h-10" />
                  </div>
                  <h3 className="text-xl font-bold font-serif text-amber-100">Prophet JUHNKRIX SYNVAGORD Live Altar</h3>
                  <p className="text-xs text-slate-300 max-w-md mx-auto">
                    &ldquo;{broadcastTitle}&rdquo; — Broadcasting live with 528Hz celestial soaking frequency and wave sound monitoring.
                  </p>
                </div>

                {/* Wave Sound Live Monitor Graphic */}
                <div className="absolute bottom-0 inset-x-0 h-16 bg-gradient-to-t from-amber-950/60 to-transparent flex items-end justify-center px-6 pb-3 space-x-1">
                  {[40, 70, 95, 60, 85, 100, 75, 50, 65, 90, 80, 55, 70, 95, 60, 85].map((h, i) => (
                    <div
                      key={i}
                      className="w-1.5 bg-gradient-to-t from-amber-500 to-yellow-300 rounded-full animate-pulse"
                      style={{ height: `${h}%`, animationDuration: `${0.4 + (i % 5) * 0.2}s` }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Live Transcript & Visitor Notice */}
          <div className="space-y-6">
            <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 shadow-xl space-y-4">
              <h3 className="text-sm font-bold font-serif text-amber-100 flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>Live Prophetic Utterances</span>
              </h3>
              <div className="space-y-2.5">
                {transcriptLines.map((line, idx) => (
                  <div key={idx} className="p-3 rounded-xl bg-slate-950 border border-amber-500/20 text-xs text-amber-200/90 italic">
                    {line}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-amber-950/30 border border-amber-500/20 p-5 rounded-3xl text-xs space-y-3">
              <h4 className="font-bold text-amber-300 font-serif">Visitor Notice</h4>
              <p className="text-slate-300 leading-relaxed">
                Streaming inputs and creator broadcast controls are strictly restricted to the platform owner, Prophet JUHNKRIX SYNVAGORD. You are enjoying a live high-definition receive-only stream.
              </p>
            </div>
          </div>
        </div>
      ) : (
        /* PROPHET JUHNKRIX OWNER VIEW: Full Streaming Inputs & Creator Suite */
        <div>
          {!isLive ? (
            /* Mode Selection Menu with MICROPHONE & CAMERA Icon Buttons */
            <div className="space-y-8 py-6">
              <div className="text-center space-y-2">
                <h2 className="text-xl sm:text-2xl font-bold font-serif text-amber-100">
                  Select Broadcast Mode (Prophet Host Only)
                </h2>
                <p className="text-xs text-slate-400">
                  Click either button below to immediately activate your device microphone or camera for live streaming.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                {/* Broadcast Audio / Microphone Button Card */}
                <div
                  onClick={() => startBroadcast('audio')}
                  className="group bg-gradient-to-br from-slate-900 via-slate-900 to-amber-950/40 p-8 rounded-3xl border border-amber-500/30 hover:border-amber-400 shadow-xl hover:shadow-2xl hover:shadow-amber-500/10 transition-all cursor-pointer flex flex-col items-center text-center space-y-6"
                >
                  <div className="w-24 h-24 rounded-3xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg">
                    <Mic className="w-12 h-12 text-amber-400 animate-pulse" />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-xl font-bold text-amber-100 font-serif">BROADCAST AUDIO</h3>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Activate your device Microphone instantly for live audio streaming. Mix multitrack audio, add background sound files, and apply AI denoise.
                    </p>
                  </div>
                  <button className="px-8 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/30 transition-all hover:scale-105">
                    🎙️ Start Microphone Stream
                  </button>
                </div>

                {/* Broadcast Video / Camera Button Card */}
                <div
                  onClick={() => startBroadcast('video')}
                  className="group bg-gradient-to-br from-slate-900 via-slate-900 to-purple-950/40 p-8 rounded-3xl border border-purple-500/30 hover:border-purple-400 shadow-xl hover:shadow-2xl hover:shadow-purple-500/10 transition-all cursor-pointer flex flex-col items-center text-center space-y-6"
                >
                  <div className="w-24 h-24 rounded-3xl bg-purple-500/20 border border-purple-400/40 flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg">
                    <Video className="w-12 h-12 text-purple-400 animate-pulse" />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-xl font-bold text-purple-100 font-serif">BROADCAST VIDEO</h3>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Activate your device Camera and Microphone for a live high-definition video broadcast with real-time effects and multitrack editing.
                    </p>
                  </div>
                  <button className="px-8 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-purple-500/30 transition-all hover:scale-105">
                    📷 Start Camera Stream
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* Active Stream & Host Studio */
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left Column: Public Preview Screen (Visible to Host & Viewers) */}
              <div className="lg:col-span-1 space-y-6">
                <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 shadow-2xl space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                      <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">PUBLIC PREVIEW</span>
                    </div>
                    <button
                      onClick={stopBroadcast}
                      className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-bold flex items-center space-x-1 transition-all"
                    >
                      <StopCircle className="w-4 h-4" />
                      <span>End Stream</span>
                    </button>
                  </div>

                  <div className="relative aspect-video bg-slate-950 rounded-2xl border border-amber-500/30 overflow-hidden flex flex-col items-center justify-center">
                    {broadcastMode === 'video' ? (
                      <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
                    ) : (
                      <div className="text-center space-y-3 p-6">
                        <div className="w-16 h-16 rounded-full bg-amber-500/20 border border-amber-400/40 flex items-center justify-center mx-auto text-amber-400 animate-pulse">
                          <Mic className="w-8 h-8" />
                        </div>
                        <h4 className="text-sm font-bold text-amber-100 font-serif">Live Audio Stream Active</h4>
                        <p className="text-[11px] text-slate-400">Broadcasting microphone input with 528Hz celestial soaking frequency.</p>
                      </div>
                    )}

                    <div className="absolute bottom-3 left-3 bg-slate-900/80 px-2.5 py-1 rounded-xl text-[10px] text-amber-300 font-mono border border-amber-500/20 flex items-center space-x-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      <span>LIVE {formatDuration(elapsedTime)}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-300 px-2">
                    <span>Connected Viewers:</span>
                    <span className="font-bold text-amber-300 font-mono">{viewersCount} Soaking Believers</span>
                  </div>
                </div>

                {/* Live Speech-to-Text Transcription Feed */}
                <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 shadow-xl space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center space-x-2">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    <span>Live Prophetic Utterance Transcription</span>
                  </h4>
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                    {transcriptLines.map((line, idx) => (
                      <div key={idx} className="p-2.5 rounded-xl bg-slate-950 border border-amber-500/20 text-xs text-amber-200/90 italic">
                        {line}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right Column: Host Controls & Multitrack Audio Mixer */}
              <div className="lg:col-span-2 space-y-6">
                <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-base font-bold font-serif text-amber-100 flex items-center space-x-2">
                      <Sliders className="w-5 h-5 text-amber-400" />
                      <span>Host Multitrack & Audio Effects Studio</span>
                    </h3>

                    <label className="px-4 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-400/30 text-xs font-bold flex items-center space-x-2 cursor-pointer transition-all">
                      <Upload className="w-3.5 h-3.5" />
                      <span>Add Audio Track File</span>
                      <input type="file" accept="audio/*" onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) addTrack('music', file.name);
                      }} className="hidden" />
                    </label>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Denoise Toggle */}
                    <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/20 flex items-center justify-between">
                      <div>
                        <h4 className="text-xs font-bold text-amber-100">AI Voice Denoise</h4>
                        <p className="text-[10px] text-slate-400">Remove background hum and room noise</p>
                      </div>
                      <button
                        onClick={() => setDenoiseActive(!denoiseActive)}
                        className={`w-12 h-6 rounded-full transition-colors relative p-1 ${
                          denoiseActive ? 'bg-amber-500' : 'bg-slate-800'
                        }`}
                      >
                        <div className={`w-4 h-4 rounded-full bg-slate-950 transition-transform ${
                          denoiseActive ? 'translate-x-6' : 'translate-x-0'
                        }`} />
                      </button>
                    </div>

                    {/* Effect Preset Selector */}
                    <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/20 space-y-1">
                      <label className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">Acoustic Reverb Effect</label>
                      <select
                        value={selectedEffect}
                        onChange={(e: any) => setSelectedEffect(e.target.value)}
                        className="w-full bg-slate-900 border border-amber-500/30 rounded-xl px-3 py-1.5 text-xs text-amber-100 focus:outline-none"
                      >
                        <option value="heavenly_reverb">Heavenly Reverb (Sanctuary)</option>
                        <option value="warm_chamber">Warm Chamber</option>
                        <option value="cathedral">Grand Cathedral</option>
                        <option value="none">None</option>
                      </select>
                    </div>
                  </div>

                  {/* Multitrack Timeline List */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                        Host Multitrack Timelines ({tracks.length})
                      </h4>
                      <span className="text-[10px] text-slate-400">Select active broadcast source track below</span>
                    </div>

                    <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                      {tracks.map((track) => (
                        <div
                          key={track.id}
                          className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row items-center justify-between gap-4 ${
                            track.isActiveSource
                              ? 'bg-amber-950/30 border-amber-400 shadow-lg shadow-amber-500/10'
                              : 'bg-slate-950 border-amber-500/20'
                          }`}
                        >
                          <div className="flex items-center space-x-3 w-full sm:w-auto">
                            <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-xs font-bold ${
                              track.type === 'voice' ? 'bg-amber-500/20 text-amber-400 border border-amber-400/30' :
                              track.type === 'music' ? 'bg-purple-500/20 text-purple-400 border border-purple-400/30' :
                              'bg-sky-500/20 text-sky-400 border border-sky-400/30'
                            }`}>
                              {track.type === 'voice' ? '🎤' : track.type === 'music' ? '🎹' : '🌊'}
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center space-x-2">
                                <h5 className="text-xs font-bold text-amber-100 truncate">{track.name}</h5>
                                {track.isActiveSource && (
                                  <span className="px-2 py-0.5 rounded bg-amber-500 text-slate-950 text-[9px] font-extrabold uppercase">
                                    Active Source
                                  </span>
                                )}
                              </div>
                              <p className="text-[10px] text-slate-400 font-mono">Duration: {formatDuration(track.durationSec)}</p>
                            </div>
                          </div>

                          <div className="flex items-center space-x-3 w-full sm:w-auto justify-end">
                            {!track.isActiveSource && (
                              <button
                                onClick={() => setActiveSourceTrack(track.id)}
                                className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/30 transition-colors"
                              >
                                Set Active Source
                              </button>
                            )}

                            <div className="flex items-center space-x-2">
                              <Volume2 className="w-3.5 h-3.5 text-slate-400" />
                              <input
                                type="range"
                                min="0"
                                max="1"
                                step="0.05"
                                value={track.isMuted ? 0 : track.volume}
                                onChange={(e) => updateTrackVolume(track.id, parseFloat(e.target.value))}
                                className="w-20 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                              />
                            </div>

                            <button
                              onClick={() => toggleMuteTrack(track.id)}
                              className={`px-2 py-1 rounded-lg text-[10px] font-bold border transition-colors ${
                                track.isMuted
                                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                                  : 'bg-slate-900 text-slate-300 border-slate-700'
                              }`}
                            >
                              {track.isMuted ? 'Muted' : 'Mute'}
                            </button>

                            <button
                              onClick={() => removeTrack(track.id)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 transition-colors"
                              title="Delete Track"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
