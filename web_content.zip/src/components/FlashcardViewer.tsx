import React, { useState } from 'react';
import { StudyModule, KeyTerm } from '../types/index.ts';
import { ArrowLeft, ArrowRight, Rotate3D, Shuffle, CheckCircle, Volume2 } from 'lucide-react';
import { speakText } from '../utils/audio.ts';

interface FlashcardViewerProps {
  module?: StudyModule;
  allModules: StudyModule[];
  language: 'om' | 'en';
  onBack: () => void;
}

export const FlashcardViewer: React.FC<FlashcardViewerProps> = ({
  module,
  allModules,
  language,
  onBack,
}) => {
  // Aggregate key terms
  const terms: KeyTerm[] = module
    ? module.keyTerms
    : allModules.flatMap((m) => m.keyTerms);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [masteredTerms, setMasteredTerms] = useState<{ [term: string]: boolean }>({});

  if (!terms || terms.length === 0) {
    return (
      <div className="max-w-md mx-auto py-12 text-center text-slate-500">
        <p>Kaardiin hin argamne / No flashcards found.</p>
        <button
          onClick={onBack}
          className="mt-4 px-4 py-2 text-xs font-semibold bg-slate-900 text-white rounded-lg"
        >
          Deebi'i / Back
        </button>
      </div>
    );
  }

  const currentTerm = terms[currentIndex];
  const isMastered = masteredTerms[currentTerm.term];

  const handleNext = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev + 1) % terms.length);
  };

  const handlePrev = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev - 1 + terms.length) % terms.length);
  };

  const handleShuffle = () => {
    setIsFlipped(false);
    const randomIndex = Math.floor(Math.random() * terms.length);
    setCurrentIndex(randomIndex);
  };

  const toggleMastered = () => {
    setMasteredTerms((prev) => ({
      ...prev,
      [currentTerm.term]: !prev[currentTerm.term],
    }));
  };

  const handleSpeakTerm = (e: React.MouseEvent) => {
    e.stopPropagation();
    speakText(currentTerm.term, 'it-IT');
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-6 sm:py-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-4">
        <button
          onClick={onBack}
          className="min-h-[44px] inline-flex items-center gap-2 text-xs font-semibold text-slate-700 hover:text-slate-950 transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{language === 'om' ? 'Deebi\'i' : 'Back'}</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={handleShuffle}
            className="min-h-[38px] px-3 py-1.5 text-xs font-semibold bg-white border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-50 inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Shuffle className="w-3.5 h-3.5" />
            <span>{language === 'om' ? 'Wal-maki' : 'Shuffle'}</span>
          </button>

          <span className="text-xs font-bold text-slate-600 tabular-nums bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200">
            {currentIndex + 1} / {terms.length}
          </span>
        </div>
      </div>

      <div className="text-center space-y-1">
        <h2 className="text-xl font-bold text-slate-900">
          {language === 'om' ? 'Kaardii Jechoota Bu\'uuraa' : 'Grade 9 Key Vocabulary Flashcards'}
        </h2>
        <p className="text-xs text-slate-500">
          {language === 'om'
            ? 'Kaardicha tuquun hiika isaa garagaggalchi'
            : 'Tap card to flip between term and explanation'}
        </p>
      </div>

      {/* 3D Flip Card Container */}
      <div
        onClick={() => setIsFlipped((prev) => !prev)}
        className="w-full min-h-[260px] sm:min-h-[300px] cursor-pointer select-none perspective-1000"
      >
        <div
          className={`w-full h-full min-h-[260px] sm:min-h-[300px] rounded-3xl p-6 sm:p-8 flex flex-col justify-between transition-all duration-300 transform border shadow-sm ${
            isFlipped
              ? 'bg-slate-900 text-white border-slate-800'
              : 'bg-white text-slate-900 border-slate-200 hover:border-amber-400'
          }`}
        >
          {/* Top card info */}
          <div className="flex items-center justify-between text-xs">
            <span
              className={`font-semibold ${
                isFlipped ? 'text-amber-400' : 'text-amber-700'
              }`}
            >
              {isFlipped
                ? language === 'om'
                  ? 'Hiika & Tajaajila'
                  : 'Definition & Role'
                : language === 'om'
                ? 'Jecha / Term'
                : 'Concept / Term'}
            </span>

            <div className="flex items-center gap-2">
              <button
                onClick={handleSpeakTerm}
                title="Sagalee dhaggeeffadhu"
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  isFlipped ? 'hover:bg-slate-800 text-slate-300' : 'hover:bg-slate-100 text-slate-600'
                }`}
              >
                <Volume2 className="w-4 h-4" />
              </button>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  toggleMastered();
                }}
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  isMastered
                    ? 'text-emerald-500 font-bold'
                    : isFlipped
                    ? 'text-slate-400 hover:text-white'
                    : 'text-slate-400 hover:text-slate-800'
                }`}
              >
                <CheckCircle
                  className={`w-4 h-4 ${isMastered ? 'fill-emerald-500/20 text-emerald-500' : ''}`}
                />
              </button>
            </div>
          </div>

          {/* Center Content */}
          <div className="py-6 text-center space-y-3">
            {!isFlipped ? (
              <>
                <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                  {currentTerm.term}
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 italic">
                  {currentTerm.translation}
                </p>
                <p className="text-[11px] text-amber-600 font-medium pt-2">
                  (Tuqi garagagalchuuf / Tap to flip)
                </p>
              </>
            ) : (
              <>
                <p className="text-base sm:text-lg leading-relaxed font-medium">
                  {currentTerm.definition}
                </p>
                {currentTerm.example && (
                  <p className="text-xs text-amber-300 pt-2 font-mono">
                    Fakkeenya: {currentTerm.example}
                  </p>
                )}
                <p className="text-xs text-slate-400 pt-1 italic">
                  {currentTerm.translation}
                </p>
              </>
            )}
          </div>

          {/* Bottom Card Footer */}
          <div className="flex items-center justify-between text-[11px] text-slate-400 border-t border-current/10 pt-3">
            <span>Barattoota Kutaa 9</span>
            <span className="flex items-center gap-1">
              <Rotate3D className="w-3.5 h-3.5" />
              <span>{isFlipped ? 'Duuba' : 'Fuula'}</span>
            </span>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center justify-between gap-4 pt-2">
        <button
          onClick={handlePrev}
          className="min-h-[44px] px-5 py-2.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors inline-flex items-center gap-2 cursor-pointer active:scale-[0.98]"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{language === 'om' ? 'Kan Duraa' : 'Previous'}</span>
        </button>

        <button
          onClick={handleNext}
          className="min-h-[44px] px-6 py-2.5 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-xl transition-all shadow-sm inline-flex items-center gap-2 cursor-pointer active:scale-[0.98]"
        >
          <span>{language === 'om' ? 'Kan Itti Aanu' : 'Next Card'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
