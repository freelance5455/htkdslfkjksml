import React from 'react';
import { Maximize2, Flame, Sun, Check, Sparkles } from 'lucide-react';
import { LIGHT_COLOR_PRESETS, LightColorPreset } from '../types/flashlight';
import { soundService } from '../utils/sound';

interface ScreenLightModeProps {
  currentColor: LightColorPreset;
  onSelectColor: (preset: LightColorPreset) => void;
  customHex: string;
  onCustomHexChange: (hex: string) => void;
  brightness: number;
  onBrightnessChange: (val: number) => void;
  candleFlicker: boolean;
  onToggleCandleFlicker: () => void;
  onLaunchFullscreen: () => void;
  isOled: boolean;
}

export const ScreenLightMode: React.FC<ScreenLightModeProps> = ({
  currentColor,
  onSelectColor,
  customHex,
  onCustomHexChange,
  brightness,
  onBrightnessChange,
  candleFlicker,
  onToggleCandleFlicker,
  onLaunchFullscreen,
  isOled,
}) => {
  return (
    <div className="space-y-5">
      {/* Visual Lamp Preview Card */}
      <div
        className={`rounded-2xl p-5 border text-center transition-all relative overflow-hidden ${
          isOled ? 'bg-black border-neutral-800' : 'bg-slate-900/60 border-slate-800'
        }`}
      >
        <div
          className="w-24 h-24 sm:w-28 sm:h-28 mx-auto rounded-full transition-all duration-300 flex items-center justify-center shadow-2xl relative"
          style={{
            backgroundColor: currentColor.hex,
            boxShadow: `0 0 50px ${currentColor.glowColor}, 0 0 100px ${currentColor.glowColor}`,
            opacity: Math.max(0.3, brightness / 100),
          }}
        >
          <div className="w-12 h-12 rounded-full bg-white/40 blur-sm pointer-events-none" />
        </div>

        <div className="mt-4">
          <h3 className="text-base font-bold text-white flex items-center justify-center gap-2">
            <span>{currentColor.name}</span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">{currentColor.czDescription}</p>
        </div>

        {/* Fullscreen Lamp Launch Button */}
        <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-center">
          <button
            onClick={() => {
              soundService.playTick();
              onLaunchFullscreen();
            }}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-xs text-slate-950 bg-cyan-400 hover:bg-cyan-300 shadow-[0_0_20px_rgba(0,240,255,0.4)] cursor-pointer transition-all active:scale-95"
          >
            <Maximize2 className="w-4 h-4 stroke-[2.5]" />
            <span>Spustit celoobrazovkovou lucernu</span>
          </button>
        </div>
      </div>

      {/* Brightness Control */}
      <div
        className={`rounded-2xl p-4 sm:p-5 border ${
          isOled ? 'bg-black border-neutral-800' : 'bg-slate-900/60 border-slate-800'
        }`}
      >
        <div className="flex items-center justify-between text-xs text-slate-300 font-semibold mb-2.5">
          <span className="flex items-center gap-1.5">
            <Sun className="w-4 h-4 text-cyan-400" />
            <span>Intenzita jasu displeje</span>
          </span>
          <span className="font-mono text-cyan-400 tabular-nums">{brightness}%</span>
        </div>

        <input
          type="range"
          min="10"
          max="100"
          step="5"
          value={brightness}
          onChange={(e) => onBrightnessChange(Number(e.target.value))}
          className="w-full h-2 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-cyan-400"
          aria-label="Jas displeje"
        />

        <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1.5 tabular-nums">
          <span>10% (Šetrný)</span>
          <span>50%</span>
          <span>100% (Turbo jas)</span>
        </div>

        {/* Candle Flicker toggle */}
        <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Flame className={`w-4 h-4 ${candleFlicker ? 'text-amber-400' : 'text-slate-500'}`} />
            <div>
              <span className="text-xs font-semibold text-slate-200 block">
                Efekt plamene svíčky
              </span>
              <span className="text-[11px] text-slate-400">
                Příjemné organické mihotání světla
              </span>
            </div>
          </div>
          <button
            onClick={() => {
              soundService.playTick();
              onToggleCandleFlicker();
            }}
            role="switch"
            aria-checked={candleFlicker}
            aria-label="Zapnout efekt plamene svíčky"
            className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
              candleFlicker ? 'bg-amber-500 shadow-[0_0_10px_#f59e0b]' : 'bg-slate-800'
            }`}
          >
            <span
              className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                candleFlicker ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Preset Colors Grid */}
      <div
        className={`rounded-2xl p-4 sm:p-5 border ${
          isOled ? 'bg-black border-neutral-800' : 'bg-slate-900/60 border-slate-800'
        }`}
      >
        <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
          Barevné spektrum & teplota světla
        </h4>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {LIGHT_COLOR_PRESETS.map((preset) => {
            const isSelected = currentColor.id === preset.id;
            return (
              <button
                key={preset.id}
                onClick={() => {
                  soundService.playTick();
                  onSelectColor(preset);
                }}
                className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'border-cyan-400 bg-cyan-950/20 shadow-[0_0_12px_rgba(0,240,255,0.25)]'
                    : isOled
                    ? 'border-neutral-800 bg-neutral-950 hover:border-neutral-700'
                    : 'border-slate-800 bg-slate-950/80 hover:border-slate-700'
                }`}
              >
                <span
                  className="w-5 h-5 rounded-full shrink-0 border border-white/20 shadow-sm"
                  style={{ backgroundColor: preset.hex }}
                />
                <div className="min-w-0 flex-1">
                  <span className="text-xs font-semibold text-slate-200 block truncate">
                    {preset.name}
                  </span>
                </div>
                {isSelected && <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />}
              </button>
            );
          })}
        </div>

        {/* Custom Hex Color Picker */}
        <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between gap-3">
          <span className="text-xs text-slate-400">Vlastní barva světla:</span>
          <div className="flex items-center gap-2">
            <input
              type="color"
              value={customHex}
              onChange={(e) => {
                const hex = e.target.value;
                onCustomHexChange(hex);
                onSelectColor({
                  id: 'custom',
                  name: 'Vlastní barva',
                  czDescription: `HEX kód ${hex.toUpperCase()}`,
                  hex: hex,
                  glowColor: `${hex}80`,
                  textColor: '#ffffff',
                  category: 'neon',
                });
              }}
              className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
              aria-label="Vybrat vlastní barvu světla"
            />
            <span className="text-xs font-mono text-cyan-300 uppercase">{customHex}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
