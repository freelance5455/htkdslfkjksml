import React, { useEffect, useRef, useState } from 'react';
import { Camera, ImagePlus, Send, Sparkles, Terminal, X } from 'lucide-react';
import { HudSnapshot } from '../game/types';

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  model?: string;
}

interface CommsDrawerProps {
  open: boolean;
  hud: HudSnapshot;
  onClose: () => void;
  onCaptureFrame: () => string | null;
}

export const CommsDrawer: React.FC<CommsDrawerProps> = ({
  open,
  hud,
  onClose,
  onCaptureFrame,
}) => {
  const [activeTab, setActiveTab] = useState<'chat' | 'vision'>('chat');

  // Multi-turn Chat state
  const [chatMode, setChatMode] = useState<'standard' | 'fast'>('standard');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      role: 'model',
      text: 'K-09 Tactical Uplink online. Ask for sector routes, parkour chains (down-slash pogo resets dash & double jump), or Archon-IX boss counters.',
    },
  ]);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const [chatError, setChatError] = useState<string | null>(null);
  const threadEndRef = useRef<HTMLDivElement | null>(null);

  // Image Analysis state
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageMime, setImageMime] = useState<string>('image/jpeg');
  const [visionPrompt, setVisionPrompt] = useState('');
  const [visionResult, setVisionResult] = useState<string | null>(null);
  const [visionLoading, setVisionLoading] = useState(false);
  const [visionError, setVisionError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (open) {
      threadEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, open]);

  if (!open) return null;

  const sendChatMessage = async (textOverride?: string) => {
    const content = (textOverride ?? chatInput).trim();
    if (!content || chatLoading) return;

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      text: content,
    };

    const historySnapshot = messages.map((m) => ({ role: m.role, text: m.text }));
    setMessages((prev) => [...prev, userMsg]);
    if (!textOverride) setChatInput('');
    setChatLoading(true);
    setChatError(null);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: historySnapshot,
          message: content,
          mode: chatMode,
          gameContext: {
            sectorName: hud.currentSectorName,
            hp: hud.hp,
            maxHp: hud.maxHp,
            flux: hud.flux,
            abilities: hud.abilities,
            shards: hud.shards,
            totalShards: hud.totalShards,
            bossDefeated: hud.bossDefeated,
          },
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to reach K-09 Uplink');
      }

      setMessages((prev) => [
        ...prev,
        {
          id: `m-${Date.now()}`,
          role: 'model',
          text: data.reply,
          model: data.model,
        },
      ]);
    } catch (err) {
      setChatError(err instanceof Error ? err.message : 'Transmission error.');
    } finally {
      setChatLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setVisionError(null);
    setVisionResult(null);
    setImageMime(file.type || 'image/png');
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setImagePreview(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleCaptureGameFrame = () => {
    const dataUrl = onCaptureFrame();
    if (!dataUrl) {
      setVisionError('Could not capture active canvas frame.');
      return;
    }
    setVisionError(null);
    setVisionResult(null);
    setImageMime('image/jpeg');
    setImagePreview(dataUrl);
  };

  const handleAnalyzeImage = async () => {
    if (!imagePreview || visionLoading) return;
    setVisionLoading(true);
    setVisionError(null);
    setVisionResult(null);

    try {
      const res = await fetch('/api/analyze-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: imagePreview,
          mimeType: imageMime,
          prompt: visionPrompt.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Image analysis failed');
      }
      setVisionResult(data.analysis);
    } catch (err) {
      setVisionError(err instanceof Error ? err.message : 'Visual recon failed.');
    } finally {
      setVisionLoading(false);
    }
  };

  return (
    <aside
      className="absolute inset-y-0 right-0 z-40 flex w-full max-w-md flex-col border-l border-slate-800 bg-[#080c17] shadow-2xl"
      aria-label="K-09 Tactical Comms & Visual Recon"
    >
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 px-5 py-4">
        <div>
          <h2 className="font-display text-lg font-bold tracking-wide text-slate-100">
            K-09 Tactical Uplink
          </h2>
          <p className="text-xs text-slate-400">
            <span>{hud.currentSectorName}</span>
            <span className="mx-1.5" aria-hidden="true">·</span>
            <span>Game Paused</span>
          </p>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="flex h-10 w-10 items-center justify-center border border-slate-700 text-slate-300 transition-colors hover:border-cyan-400 hover:text-white focus-visible:outline-2 focus-visible:outline-cyan-400"
          aria-label="Close tactical uplink"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* Mode Switch Tabs */}
      <div className="grid grid-cols-2 gap-1 border-b border-slate-800 bg-[#050811] p-2">
        <button
          type="button"
          onClick={() => setActiveTab('chat')}
          className={`flex items-center justify-center gap-2 py-2.5 text-xs font-semibold transition-colors whitespace-nowrap ${
            activeTab === 'chat'
              ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-500/40'
              : 'text-slate-400 hover:text-slate-200 border border-transparent'
          }`}
        >
          <Terminal className="h-4 w-4" />
          <span>Tactical Chat</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('vision')}
          className={`flex items-center justify-center gap-2 py-2.5 text-xs font-semibold transition-colors whitespace-nowrap ${
            activeTab === 'vision'
              ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-500/40'
              : 'text-slate-400 hover:text-slate-200 border border-transparent'
          }`}
        >
          <Camera className="h-4 w-4" />
          <span>Visual Recon</span>
        </button>
      </div>

      {activeTab === 'chat' ? (
        <>
          {/* Response Speed Selector */}
          <div className="flex items-center justify-between border-b border-slate-800/80 px-5 py-2.5 text-xs">
            <span className="text-slate-400">Response Mode</span>
            <div className="flex items-center gap-1 bg-slate-900 p-0.5">
              <button
                type="button"
                onClick={() => setChatMode('standard')}
                className={`px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                  chatMode === 'standard'
                    ? 'bg-slate-800 text-cyan-300'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Tactical
              </button>
              <button
                type="button"
                onClick={() => setChatMode('fast')}
                className={`px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap ${
                  chatMode === 'fast'
                    ? 'bg-slate-800 text-cyan-300'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Fast Hint
              </button>
            </div>
          </div>

          {/* Scrollable Message Thread */}
          <div className="comms-scroll flex-1 space-y-4 overflow-y-auto px-5 py-4">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex flex-col ${
                  m.role === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                <span className="mb-1 text-[11px] text-slate-500">
                  {m.role === 'user' ? 'Runner' : 'K-09 Cartographer'}
                </span>
                <div
                  className={`max-w-[88%] whitespace-pre-wrap px-3.5 py-2.5 text-sm leading-relaxed ${
                    m.role === 'user'
                      ? 'border border-cyan-500/35 bg-cyan-500/15 text-slate-100'
                      : 'border border-slate-800 bg-slate-900/90 text-slate-200'
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}
            {chatLoading && (
              <div className="text-xs text-cyan-400">Decrypting tactical telemetry...</div>
            )}
            {chatError && (
              <div className="border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-xs text-rose-300">
                {chatError}
              </div>
            )}
            <div ref={threadEndRef} />
          </div>

          {/* Quick Contextual Prompts */}
          <div className="flex flex-wrap gap-1.5 border-t border-slate-800/80 px-5 py-2.5">
            {[
              'Where is Phase Dash?',
              'Parkour combo tips',
              'How to beat Archon-IX?',
            ].map((q) => (
              <button
                key={q}
                type="button"
                onClick={() => sendChatMessage(q)}
                disabled={chatLoading}
                className="border border-slate-700/80 bg-slate-900 px-2.5 py-1 text-xs text-slate-300 transition-colors hover:border-cyan-400/60 hover:text-cyan-200 disabled:opacity-50"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Chat Input */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              sendChatMessage();
            }}
            className="flex items-center gap-2 border-t border-slate-800 p-4"
          >
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder="Ask K-09 for route or combat advice..."
              className="h-11 flex-1 border border-slate-700 bg-slate-950 px-3.5 text-sm text-slate-100 placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
            />
            <button
              type="submit"
              disabled={chatLoading || !chatInput.trim()}
              className="flex h-11 items-center justify-center gap-1.5 bg-cyan-500 px-4 text-sm font-semibold text-slate-950 transition-colors hover:bg-cyan-400 disabled:opacity-40 whitespace-nowrap shrink-0"
            >
              <Send className="h-4 w-4" />
              <span>Send</span>
            </button>
          </form>
        </>
      ) : (
        <div className="comms-scroll flex-1 space-y-4 overflow-y-auto p-5">
          <p className="text-xs leading-relaxed text-slate-400">
            Upload any photo or snap the current game sector frame for Gemini multimodal visual analysis.
          </p>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
          />

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex h-11 items-center justify-center gap-2 border border-slate-700 bg-slate-900 px-3 text-xs font-semibold text-slate-200 transition-colors hover:border-cyan-400 hover:text-white whitespace-nowrap"
            >
              <ImagePlus className="h-4 w-4 text-cyan-400" />
              <span>Upload Photo</span>
            </button>
            <button
              type="button"
              onClick={handleCaptureGameFrame}
              className="flex h-11 items-center justify-center gap-2 border border-slate-700 bg-slate-900 px-3 text-xs font-semibold text-slate-200 transition-colors hover:border-cyan-400 hover:text-white whitespace-nowrap"
            >
              <Camera className="h-4 w-4 text-fuchsia-400" />
              <span>Snap Frame</span>
            </button>
          </div>

          {imagePreview ? (
            <div className="border border-slate-800 bg-slate-950 p-2">
              <img
                src={imagePreview}
                alt="Visual recon upload preview"
                referrerPolicy="no-referrer"
                className="max-h-52 w-full object-contain"
              />
            </div>
          ) : (
            <div className="flex h-40 items-center justify-center border border-dashed border-slate-700 bg-slate-950/60 text-xs text-slate-500">
              No image selected yet
            </div>
          )}

          <div>
            <label className="mb-1.5 block text-xs font-medium text-slate-400">
              Analysis Question (Optional)
            </label>
            <input
              type="text"
              value={visionPrompt}
              onChange={(e) => setVisionPrompt(e.target.value)}
              placeholder="e.g., Describe hazards or objects in this image..."
              className="h-11 w-full border border-slate-700 bg-slate-950 px-3.5 text-sm text-slate-100 placeholder-slate-500 focus:border-cyan-400 focus:outline-none"
            />
          </div>

          <button
            type="button"
            onClick={handleAnalyzeImage}
            disabled={!imagePreview || visionLoading}
            className="flex h-11 w-full items-center justify-center gap-2 bg-cyan-500 px-4 text-sm font-semibold text-slate-950 transition-colors hover:bg-cyan-400 disabled:opacity-40"
          >
            <Sparkles className="h-4 w-4" />
            <span>{visionLoading ? 'Analyzing Image...' : 'Analyze Image'}</span>
          </button>

          {visionError && (
            <div className="border border-rose-500/40 bg-rose-500/10 p-3 text-xs text-rose-300">
              {visionError}
            </div>
          )}

          {visionResult && (
            <div className="border border-slate-800 bg-slate-900/90 p-4">
              <h3 className="mb-2 text-xs font-semibold text-cyan-300">
                Visual Analysis Result
              </h3>
              <p className="whitespace-pre-wrap text-sm leading-relaxed text-slate-200">
                {visionResult}
              </p>
            </div>
          )}
        </div>
      )}
    </aside>
  );
};
