import { useState } from "react";
import { useDeviceSnapshot } from "@/lib/device";
import { formatBytes } from "@/lib/model";
import { MetricRow } from "@/components/ui";

export function DevicePanel() {
  const snap = useDeviceSnapshot();
  const [showUa, setShowUa] = useState(false);

  if (!snap) {
    return <p className="text-sm text-muted">Reading what this browser can report…</p>;
  }

  const memory = snap.memoryGb == null ? null : `About ${snap.memoryGb} GB`;
  const storage =
    snap.storage && (snap.storage.usage != null || snap.storage.quota != null)
      ? `${snap.storage.usage != null ? formatBytes(snap.storage.usage) : "—"} used` +
        (snap.storage.quota != null ? ` of about ${formatBytes(snap.storage.quota)}` : "")
      : null;

  return (
    <div>
      <dl>
        <MetricRow label="Browser" value={snap.browser} source={snap.brands ? `userAgentData brands: ${snap.brands}` : "Parsed from the user agent. Open the raw string below if you need the exact report."} />
        <MetricRow label="Platform" value={snap.platform} source={snap.mobile == null ? "navigator.platform or userAgentData" : `userAgentData mobile: ${snap.mobile ? "yes" : "no"}`} />
        <MetricRow label="Screen" value={`${snap.screenLabel} · ${snap.dpr.toFixed(2)}×`} source="window.screen and devicePixelRatio. CSS pixels, not a benchmark." />
        <MetricRow
          label="Logical CPU cores"
          value={snap.cores == null ? undefined : String(snap.cores)}
          unavailable={snap.cores == null}
          source="navigator.hardwareConcurrency. This is a count, not current CPU load."
        />
        <MetricRow label="CPU utilization" unavailable source="No browser API exposes live CPU load." />
        <MetricRow label="GPU utilization" unavailable source="No browser API exposes live GPU load." />
        <MetricRow
          label="GPU name"
          value={snap.webgl.ok ? snap.webgl.renderer ?? "WebGL available" : undefined}
          unavailable={!snap.webgl.ok}
          source={snap.webgl.ok ? `WebGL renderer${snap.webgl.vendor ? ` · ${snap.webgl.vendor}` : ""}. This is a name, not activity.` : "WebGL context was not available."}
        />
        <MetricRow label="Exact RAM" unavailable source="Browsers do not report exact installed memory." />
        <MetricRow
          label="Memory class"
          value={memory}
          unavailable={memory == null}
          source="navigator.deviceMemory. Chrome-only and coarse, often capped at 8 GB."
        />
        <MetricRow label="Temperature" unavailable source="No browser API exposes device temperature." />
        <MetricRow
          label="Battery"
          value={snap.battery ? `${Math.round(snap.battery.level * 100)}% · ${snap.battery.charging ? "charging" : "not charging"}` : undefined}
          unavailable={!snap.battery}
          source={snap.batterySupported ? "Battery Status API. Some browsers hide it." : "Battery Status API is not in this browser."}
        />
        <MetricRow
          label="Network hint"
          value={
            snap.net
              ? [
                  snap.net.effectiveType,
                  snap.net.saveData ? "data saver on" : "data saver off",
                  snap.net.downlink != null ? `${snap.net.downlink} Mb/s hint` : null,
                ]
                  .filter(Boolean)
                  .join(" · ")
              : undefined
          }
          unavailable={!snap.net}
          source="Network Information API, when the browser provides it. Not a speed test."
        />
        <MetricRow
          label="Origin storage"
          value={storage}
          unavailable={!storage}
          source="StorageManager estimate for this site, not a full phone storage report."
        />
        <MetricRow label="Saved data in this app" value={snap.localStorage ? "localStorage can be written" : undefined} unavailable={!snap.localStorage} source="A write test against localStorage. Your profiles use that store." />
        <MetricRow label="Display mode" value={snap.standalone ? "Home screen / standalone" : "Browser tab"} source="matchMedia display-mode: standalone" />
        <MetricRow label="Online" value={snap.online ? "Yes" : "No"} source="navigator.onLine" />
      </dl>
      <button type="button" className="mt-3 text-sm font-semibold text-primary" onClick={() => setShowUa((value) => !value)}>
        {showUa ? "Hide raw user agent" : "Show raw user agent"}
      </button>
      {showUa ? <p className="mt-2 text-xs break-all text-faint">{snap.ua}</p> : null}
    </div>
  );
}
