import React, { useEffect } from 'react';
import { Delete, X } from 'lucide-react';

interface PinLockPadProps {
  pin: string;
  onChange: (pin: string) => void;
  onSubmit?: (pin: string) => void;
  maxLength?: number;
  error?: string;
  disabled?: boolean;
  accentColor?: string;
  isLight?: boolean;
  isEn?: boolean;
}

export const PinLockPad: React.FC<PinLockPadProps> = ({
  pin,
  onChange,
  onSubmit,
  maxLength = 6,
  error,
  disabled = false,
  accentColor = '#10b981',
  isLight = false,
  isEn = true,
}) => {
  const handleDigit = (digit: string) => {
    if (disabled || pin.length >= maxLength) return;
    const nextPin = pin + digit;
    onChange(nextPin);
    if (nextPin.length === maxLength && onSubmit) {
      onSubmit(nextPin);
    }
  };

  const handleBackspace = () => {
    if (disabled || pin.length === 0) return;
    onChange(pin.slice(0, -1));
  };

  const handleClear = () => {
    if (disabled) return;
    onChange('');
  };

  // Keyboard listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (disabled) return;
      if (/^[0-9]$/.test(e.key)) {
        if (pin.length < maxLength) {
          const next = pin + e.key;
          onChange(next);
          if (next.length === maxLength && onSubmit) {
            onSubmit(next);
          }
        }
      } else if (e.key === 'Backspace') {
        onChange(pin.slice(0, -1));
      } else if (e.key === 'Escape') {
        onChange('');
      } else if (e.key === 'Enter' && pin.length >= 4 && onSubmit) {
        onSubmit(pin);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [pin, maxLength, disabled, onChange, onSubmit]);

  const digits = ['1', '2', '3', '4', '5', '6', '7', '8', '9'];

  return (
    <div className="w-full max-w-[280px] mx-auto space-y-5 select-none">
      {/* Visual PIN Dots Indicator */}
      <div className="flex justify-center items-center gap-3 py-2">
        {Array.from({ length: maxLength }).map((_, i) => {
          const isFilled = i < pin.length;
          return (
            <div
              key={i}
              style={{
                borderColor: isFilled ? accentColor : isLight ? '#cbd5e1' : '#475569',
                backgroundColor: isFilled ? accentColor : 'transparent',
                boxShadow: isFilled ? `0 0 10px ${accentColor}50` : 'none',
              }}
              className={`w-4 h-4 rounded-full border-2 transition-all duration-200 transform ${
                isFilled ? 'scale-110' : 'scale-100'
              }`}
            />
          );
        })}
      </div>

      {error && (
        <p className="text-xs text-rose-500 font-semibold text-center animate-shake">
          {error}
        </p>
      )}

      {/* On-screen Keypad */}
      <div className="grid grid-cols-3 gap-3 justify-items-center">
        {digits.map((num) => (
          <button
            key={num}
            type="button"
            onClick={() => handleDigit(num)}
            disabled={disabled}
            className={`w-15 h-15 rounded-2xl font-bold text-xl flex items-center justify-center transition-all cursor-pointer active:scale-95 shadow-xs ${
              isLight
                ? 'bg-white hover:bg-sky-50 text-sky-950 border border-sky-200'
                : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
            }`}
          >
            {num}
          </button>
        ))}

        {/* Clear Button */}
        <button
          type="button"
          onClick={handleClear}
          disabled={disabled || pin.length === 0}
          title={isEn ? 'Clear' : 'মুছুন'}
          className={`w-15 h-15 rounded-2xl text-xs font-bold flex items-center justify-center transition-all cursor-pointer active:scale-95 disabled:opacity-30 ${
            isLight
              ? 'bg-sky-100/60 hover:bg-sky-100 text-sky-900'
              : 'bg-slate-800/60 hover:bg-slate-800 text-slate-300'
          }`}
        >
          <X className="w-5 h-5" />
        </button>

        {/* 0 */}
        <button
          type="button"
          onClick={() => handleDigit('0')}
          disabled={disabled}
          className={`w-15 h-15 rounded-2xl font-bold text-xl flex items-center justify-center transition-all cursor-pointer active:scale-95 shadow-xs ${
            isLight
              ? 'bg-white hover:bg-sky-50 text-sky-950 border border-sky-200'
              : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-700'
          }`}
        >
          0
        </button>

        {/* Backspace Button */}
        <button
          type="button"
          onClick={handleBackspace}
          disabled={disabled || pin.length === 0}
          title={isEn ? 'Backspace' : 'একটি ব্যাকস্পেস'}
          className={`w-15 h-15 rounded-2xl flex items-center justify-center transition-all cursor-pointer active:scale-95 disabled:opacity-30 ${
            isLight
              ? 'bg-sky-100/60 hover:bg-sky-100 text-sky-900'
              : 'bg-slate-800/60 hover:bg-slate-800 text-slate-300'
          }`}
        >
          <Delete className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
