import React, { useState, useEffect } from 'react';
import { SecuritySettings, AppSettings, LockType } from '../../types';
import { verifyPin, verifyPattern, generate2FACode } from '../../utils/crypto';
import { PatternLockCanvas } from './PatternLockCanvas';
import { PinLockPad } from './PinLockPad';
import { Lock, ShieldCheck, KeyRound, Grid3X3, AlertCircle } from 'lucide-react';
import { getDualAccentInfo } from '../../utils/theme';

interface AppLockModalProps {
  isLocked: boolean;
  securitySettings: SecuritySettings;
  onUnlock: () => void;
  appSettings?: AppSettings;
}

export const AppLockModal: React.FC<AppLockModalProps> = ({
  isLocked,
  securitySettings,
  onUnlock,
  appSettings,
}) => {
  // Determine initial unlock view (pattern vs pin)
  const defaultMethod: LockType =
    securitySettings.activeLockType === 'pattern' && securitySettings.isPatternEnabled
      ? 'pattern'
      : securitySettings.isPatternEnabled && !securitySettings.isPinEnabled
      ? 'pattern'
      : 'pin';

  const [currentMethod, setCurrentMethod] = useState<LockType>(defaultMethod);
  const [pin, setPin] = useState('');
  const [patternCanvasKey, setPatternCanvasKey] = useState(0);
  const [twoFactorInput, setTwoFactorInput] = useState('');
  const [simulatedOTP, setSimulatedOTP] = useState('');
  const [step, setStep] = useState<'auth' | '2fa'>('auth');
  const [error, setError] = useState('');
  const [isPatternError, setIsPatternError] = useState(false);

  const isLight = appSettings?.themeMode === 'light';
  const isEn = appSettings?.language === 'en';
  const dualAccent = getDualAccentInfo(
    appSettings?.themeAccent,
    appSettings?.secondaryAccent,
    appSettings?.accentPercentage
  );

  useEffect(() => {
    if (isLocked) {
      setPin('');
      setTwoFactorInput('');
      setError('');
      setIsPatternError(false);
      setStep('auth');
      setCurrentMethod(
        securitySettings.activeLockType === 'pattern' && securitySettings.isPatternEnabled
          ? 'pattern'
          : securitySettings.isPatternEnabled && !securitySettings.isPinEnabled
          ? 'pattern'
          : 'pin'
      );
    }
  }, [isLocked, securitySettings]);

  if (!isLocked) return null;

  // Handle successful primary auth
  const handlePrimarySuccess = () => {
    if (securitySettings.is2FAEnabled) {
      const code = generate2FACode();
      setSimulatedOTP(code);
      setStep('2fa');
      setError('');
    } else {
      onUnlock();
    }
  };

  // Handle PIN verification
  const handlePinSubmit = (enteredPin: string) => {
    if (!verifyPin(enteredPin, securitySettings.pinHash)) {
      setError(isEn ? 'Incorrect PIN! Please try again.' : 'ভুল পিন নম্বর! আবার চেষ্টা করুন।');
      setPin('');
      return;
    }
    handlePrimarySuccess();
  };

  // Handle Pattern verification
  const handlePatternComplete = (pattern: number[]) => {
    if (!securitySettings.patternHash || !verifyPattern(pattern, securitySettings.patternHash)) {
      setError(isEn ? 'Incorrect pattern! Try again.' : 'ভুল প্যাটার্ন! পুনরায় আঁকুন।');
      setIsPatternError(true);
      setTimeout(() => {
        setIsPatternError(false);
        setPatternCanvasKey((k) => k + 1);
      }, 1200);
      return;
    }
    handlePrimarySuccess();
  };

  // Handle 2FA verification
  const handle2FASubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (twoFactorInput.trim() === simulatedOTP) {
      onUnlock();
    } else {
      setError(
        isEn
          ? 'Invalid 2FA code! Please enter the correct code.'
          : 'ভুল ২এফএ কোড! সঠিক কোড লিখুন।'
      );
    }
  };

  const hasBothMethods = securitySettings.isPinEnabled && securitySettings.isPatternEnabled;

  return (
    <div
      className={`fixed inset-0 z-100 flex items-center justify-center ${
        isLight ? 'bg-slate-900/40 backdrop-blur-sm' : 'bg-slate-950/90 backdrop-blur-md'
      } p-4 animate-in fade-in duration-300`}
    >
      <div
        className={`w-full max-w-sm ${
          isLight
            ? 'bg-white border-sky-200 text-sky-950'
            : 'bg-slate-900 border-slate-700/80 text-slate-100'
        } border rounded-3xl p-6 shadow-2xl text-center space-y-5`}
      >
        {/* Security Icon Badge */}
        <div
          className="w-16 h-16 mx-auto rounded-2xl border flex items-center justify-center shadow-lg transition"
          style={{
            backgroundColor: `${dualAccent.primary.hex}20`,
            borderColor: `${dualAccent.primary.hex}50`,
            color: dualAccent.primary.hex,
            boxShadow: `0 10px 25px -5px ${dualAccent.primary.hex}30`,
          }}
        >
          {step === 'auth' ? (
            currentMethod === 'pattern' ? (
              <Grid3X3 className="w-8 h-8" />
            ) : (
              <Lock className="w-8 h-8" />
            )
          ) : (
            <ShieldCheck className="w-8 h-8" />
          )}
        </div>

        {/* Title and Subtitle */}
        <div>
          <h2 className={`text-xl font-black ${isLight ? 'text-sky-950' : 'text-white'}`}>
            {isEn ? 'Onu Finance Locked' : 'Onu Finance সুরক্ষিত'}
          </h2>
          <p className={`text-xs ${isLight ? 'text-sky-700/80' : 'text-slate-400'} mt-1`}>
            {step === 'auth'
              ? currentMethod === 'pattern'
                ? isEn
                  ? 'Draw your pattern to unlock financial data'
                  : 'অ্যাপ আনলক করতে আপনার প্যাটার্নটি আঁকুন'
                : isEn
                ? 'Enter your PIN to access your financial records'
                : 'আপনার হিসাব দেখতে পিন কোডটি লিখুন'
              : isEn
              ? 'Two-Factor Authentication (2FA) Verification'
              : 'টু-ফ্যাক্টর অথেন্টিকেশন (2FA) যাচাইকরণ'}
          </p>
        </div>

        {/* Method Toggle Switch (if both PIN and Pattern are active) */}
        {step === 'auth' && hasBothMethods && (
          <div className="flex justify-center gap-2 pt-1">
            <button
              type="button"
              onClick={() => {
                setCurrentMethod('pin');
                setError('');
                setIsPatternError(false);
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                currentMethod === 'pin'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : isLight
                  ? 'bg-sky-100/70 text-sky-800 hover:bg-sky-100'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>{isEn ? 'Use PIN' : 'পিন ব্যবহার করুন'}</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setCurrentMethod('pattern');
                setError('');
                setIsPatternError(false);
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                currentMethod === 'pattern'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : isLight
                  ? 'bg-sky-100/70 text-sky-800 hover:bg-sky-100'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Grid3X3 className="w-3.5 h-3.5" />
              <span>{isEn ? 'Use Pattern' : 'প্যাটার্ন ব্যবহার করুন'}</span>
            </button>
          </div>
        )}

        {/* Step 1: Authentication (PIN or Pattern) */}
        {step === 'auth' ? (
          currentMethod === 'pattern' ? (
            <div className="flex flex-col items-center space-y-3">
              <PatternLockCanvas
                key={`unlock-pattern-${patternCanvasKey}`}
                onPatternComplete={handlePatternComplete}
                accentColor={dualAccent.primary.hex}
                isLight={isLight}
                size={260}
                error={isPatternError}
                helperText={
                  error ||
                  (isEn ? 'Draw your unlock pattern' : 'আনলক প্যাটার্নটি আঁকুন')
                }
              />
            </div>
          ) : (
            <div className="space-y-4">
              <PinLockPad
                pin={pin}
                onChange={(val) => {
                  setPin(val);
                  setError('');
                }}
                onSubmit={handlePinSubmit}
                accentColor={dualAccent.primary.hex}
                isLight={isLight}
                isEn={isEn}
                error={error}
              />
            </div>
          )
        ) : (
          /* Step 2: 2FA Verification */
          <form onSubmit={handle2FASubmit} className="space-y-4">
            <div
              className={`p-3.5 ${
                isLight
                  ? 'bg-sky-50 border-sky-200 text-sky-900'
                  : 'bg-indigo-950/50 border-indigo-800/60 text-indigo-200'
              } border rounded-2xl text-left text-xs`}
            >
              <p className={`font-semibold ${isLight ? 'text-sky-950' : 'text-indigo-300'} mb-0.5`}>
                {isEn ? '📱 2FA Code Notification:' : '📱 ২এফএ কোড নোটিফিকেশন:'}
              </p>
              <p>
                {isEn
                  ? 'A 6-digit security code has been sent: '
                  : 'নিরাপত্তা যাচাই কোড: '}
                <span
                  className="font-bold text-sm tracking-widest"
                  style={{ color: dualAccent.primary.hex }}
                >
                  {simulatedOTP}
                </span>
              </p>
            </div>

            <input
              type="text"
              maxLength={6}
              value={twoFactorInput}
              onChange={(e) => {
                setTwoFactorInput(e.target.value);
                setError('');
              }}
              placeholder={isEn ? '6-digit code' : '৬ ডিজিটের কোড'}
              className={`w-full py-3 text-center text-xl font-bold ${
                isLight
                  ? 'bg-sky-50/80 border-sky-200 text-sky-950 focus:border-indigo-500'
                  : 'bg-slate-950 border-slate-700 text-white focus:border-indigo-500'
              } border rounded-2xl focus:outline-none`}
              autoFocus
            />

            {error && (
              <p className="text-xs text-rose-500 flex items-center justify-center gap-1 font-medium">
                <AlertCircle className="w-3.5 h-3.5" /> {error}
              </p>
            )}

            <button
              type="submit"
              style={dualAccent.primaryButtonStyle}
              className="w-full py-3 text-white font-bold rounded-2xl shadow-lg transition text-sm cursor-pointer active:scale-98"
            >
              {isEn ? 'Verify & Unlock' : 'যাচাই করে আনলক করুন'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
