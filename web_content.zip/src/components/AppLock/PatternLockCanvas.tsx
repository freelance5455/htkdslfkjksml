import React, { useState, useRef, useEffect, useCallback } from 'react';
import { RotateCcw } from 'lucide-react';

interface Point {
  x: number;
  y: number;
}

interface PatternLockCanvasProps {
  onPatternComplete: (pattern: number[]) => void;
  error?: boolean;
  success?: boolean;
  disabled?: boolean;
  accentColor?: string;
  isLight?: boolean;
  size?: number; // size in px, default 280
  showPath?: boolean;
  onClear?: () => void;
  helperText?: string;
}

export const PatternLockCanvas: React.FC<PatternLockCanvasProps> = ({
  onPatternComplete,
  error = false,
  success = false,
  disabled = false,
  accentColor = '#10b981',
  isLight = false,
  size = 280,
  showPath = true,
  onClear,
  helperText,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [selectedNodes, setSelectedNodes] = useState<number[]>([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentPointer, setCurrentPointer] = useState<Point | null>(null);

  // 9 grid nodes coordinates
  const nodeRadius = 24; // hit area
  const dotRadius = 8; // visual inner dot
  const padding = 36;
  const step = (size - padding * 2) / 2;

  const getNodeCenter = useCallback((index: number): Point => {
    const col = index % 3;
    const row = Math.floor(index / 3);
    return {
      x: padding + col * step,
      y: padding + row * step,
    };
  }, [padding, step]);

  // Find node under (x, y) relative to container
  const findNodeUnderPoint = useCallback((x: number, y: number): number | null => {
    for (let i = 0; i < 9; i++) {
      const center = getNodeCenter(i);
      const dist = Math.hypot(center.x - x, center.y - y);
      if (dist <= nodeRadius + 10) {
        return i;
      }
    }
    return null;
  }, [getNodeCenter, nodeRadius]);

  const getRelativeCoordinates = (clientX: number, clientY: number): Point | null => {
    if (!containerRef.current) return null;
    const rect = containerRef.current.getBoundingClientRect();
    return {
      x: clientX - rect.left,
      y: clientY - rect.top,
    };
  };

  const handleStart = (clientX: number, clientY: number) => {
    if (disabled) return;
    const coords = getRelativeCoordinates(clientX, clientY);
    if (!coords) return;

    const nodeIndex = findNodeUnderPoint(coords.x, coords.y);
    setIsDrawing(true);
    if (nodeIndex !== null) {
      setSelectedNodes([nodeIndex]);
      setCurrentPointer(coords);
    } else {
      setSelectedNodes([]);
      setCurrentPointer(coords);
    }
  };

  const handleMove = (clientX: number, clientY: number) => {
    if (!isDrawing || disabled) return;
    const coords = getRelativeCoordinates(clientX, clientY);
    if (!coords) return;

    setCurrentPointer(coords);
    const nodeIndex = findNodeUnderPoint(coords.x, coords.y);
    if (nodeIndex !== null && !selectedNodes.includes(nodeIndex)) {
      setSelectedNodes((prev) => [...prev, nodeIndex]);
    }
  };

  const handleEnd = () => {
    if (!isDrawing || disabled) return;
    setIsDrawing(false);
    setCurrentPointer(null);

    if (selectedNodes.length > 0) {
      onPatternComplete(selectedNodes);
    }
  };

  // Reset when cleared from outside
  const handleReset = () => {
    setSelectedNodes([]);
    setIsDrawing(false);
    setCurrentPointer(null);
    if (onClear) onClear();
  };

  // Touch handlers
  const onTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      const t = e.touches[0];
      handleStart(t.clientX, t.clientY);
    }
  };

  const onTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      const t = e.touches[0];
      handleMove(t.clientX, t.clientY);
    }
  };

  const onTouchEnd = () => {
    handleEnd();
  };

  // Mouse handlers
  const onMouseDown = (e: React.MouseEvent) => {
    handleStart(e.clientX, e.clientY);
  };

  const onMouseMove = (e: React.MouseEvent) => {
    handleMove(e.clientX, e.clientY);
  };

  const onMouseUp = () => {
    handleEnd();
  };

  // Color calculation based on state
  const activeLineColor = error ? '#ef4444' : success ? '#10b981' : accentColor;
  const activeDotBorderColor = error ? '#ef4444' : success ? '#10b981' : accentColor;
  const activeDotFillColor = error
    ? 'rgba(239, 68, 68, 0.2)'
    : success
    ? 'rgba(16, 185, 129, 0.2)'
    : `${accentColor}25`;

  return (
    <div className="flex flex-col items-center select-none touch-none space-y-2">
      <div
        ref={containerRef}
        style={{ width: size, height: size }}
        className={`relative rounded-3xl border ${
          isLight
            ? 'bg-sky-50/70 border-sky-200/80 shadow-inner'
            : 'bg-slate-900/80 border-slate-700/80 shadow-inner'
        } ${error ? 'animate-shake' : ''} transition-all duration-200 overflow-hidden cursor-pointer`}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
        onMouseDown={onMouseDown}
        onMouseMove={onMouseMove}
        onMouseUp={onMouseUp}
        onMouseLeave={handleEnd}
      >
        {/* SVG Drawing Layer for connecting lines */}
        <svg
          className="absolute inset-0 pointer-events-none"
          width={size}
          height={size}
          style={{ width: '100%', height: '100%' }}
        >
          {showPath &&
            selectedNodes.map((nodeIdx, i) => {
              if (i === 0) return null;
              const from = getNodeCenter(selectedNodes[i - 1]);
              const to = getNodeCenter(nodeIdx);
              return (
                <line
                  key={`line-${i}`}
                  x1={from.x}
                  y1={from.y}
                  x2={to.x}
                  y2={to.y}
                  stroke={activeLineColor}
                  strokeWidth="5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="transition-all duration-75"
                />
              );
            })}

          {/* Current line following pointer */}
          {showPath && isDrawing && selectedNodes.length > 0 && currentPointer && (
            <line
              x1={getNodeCenter(selectedNodes[selectedNodes.length - 1]).x}
              y1={getNodeCenter(selectedNodes[selectedNodes.length - 1]).y}
              x2={currentPointer.x}
              y2={currentPointer.y}
              stroke={activeLineColor}
              strokeWidth="4"
              strokeDasharray="4 4"
              strokeLinecap="round"
            />
          )}
        </svg>

        {/* 9 Interactive Nodes */}
        {Array.from({ length: 9 }).map((_, idx) => {
          const center = getNodeCenter(idx);
          const isSelected = selectedNodes.includes(idx);
          const order = selectedNodes.indexOf(idx);

          return (
            <div
              key={idx}
              style={{
                left: center.x,
                top: center.y,
                transform: 'translate(-50%, -50%)',
                width: nodeRadius * 2,
                height: nodeRadius * 2,
              }}
              className="absolute flex items-center justify-center pointer-events-none"
            >
              {/* Outer ring for selected node */}
              <div
                style={{
                  width: nodeRadius * 1.8,
                  height: nodeRadius * 1.8,
                  borderColor: isSelected ? activeDotBorderColor : 'transparent',
                  backgroundColor: isSelected ? activeDotFillColor : 'transparent',
                }}
                className={`rounded-full border-2 transition-all duration-150 flex items-center justify-center ${
                  isSelected ? 'scale-110 shadow-sm' : 'scale-90'
                }`}
              >
                {/* Inner core dot */}
                <div
                  style={{
                    width: isSelected ? dotRadius * 1.4 : dotRadius,
                    height: isSelected ? dotRadius * 1.4 : dotRadius,
                    backgroundColor: isSelected
                      ? activeLineColor
                      : isLight
                      ? '#64748b'
                      : '#94a3b8',
                  }}
                  className="rounded-full shadow-xs transition-all duration-150"
                />
              </div>

              {/* Order number badge */}
              {isSelected && showPath && (
                <span
                  style={{
                    backgroundColor: activeLineColor,
                    color: '#ffffff',
                  }}
                  className="absolute -top-1 -right-1 w-4 h-4 rounded-full text-[9px] font-bold flex items-center justify-center shadow-xs"
                >
                  {order + 1}
                </span>
              )}
            </div>
          );
        })}
      </div>

      {/* Helper text or clear button */}
      <div className="flex items-center justify-between w-full px-2 pt-1 text-xs">
        <span
          className={`font-semibold ${
            error
              ? 'text-rose-500 font-bold'
              : success
              ? 'text-emerald-500 font-bold'
              : isLight
              ? 'text-sky-800/80'
              : 'text-slate-400'
          }`}
        >
          {helperText ||
            (selectedNodes.length > 0
              ? `${selectedNodes.length} dots connected`
              : 'Connect at least 4 dots')}
        </span>

        {selectedNodes.length > 0 && !disabled && (
          <button
            type="button"
            onClick={handleReset}
            className={`flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg transition active:scale-95 cursor-pointer ${
              isLight
                ? 'bg-sky-100 hover:bg-sky-200 text-sky-900'
                : 'bg-slate-800 hover:bg-slate-750 text-slate-300'
            }`}
          >
            <RotateCcw className="w-3 h-3" /> Clear
          </button>
        )}
      </div>
    </div>
  );
};
