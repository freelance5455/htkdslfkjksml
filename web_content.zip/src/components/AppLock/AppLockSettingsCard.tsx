import React, { useState } from 'react';
import { SecuritySettings, AppSettings, LockType } from '../../types';
import { hashPin, hashPattern, verifyPin, verifyPattern } from '../../utils/crypto';
import { PatternLockCanvas } from './PatternLockCanvas';
import { PinLockPad } from './PinLockPad';
import {
  Lock,
  KeyRound,
  Grid3X3,
  CheckCircle2,
  AlertCircle,
  Smartphone,
  Clock,
  RotateCcw,
  Sparkles,
  Maximize2,
} from 'lucide-react';
import { getDualAccentInfo } from '../../utils/theme';

interface AppLockSettingsCardProps {
  securitySettings: SecuritySettings;
  onUpdateSecurity: (newSettings: SecuritySettings) => void;
  appSettings: AppSettings;
  onLockNow: () => void;
  isPopupView?: boolean;
  onOpenInPopup?: () => void;
}

export const AppLockSettingsCard: React.FC<AppLockSettingsCardProps> = ({
  securitySettings,
  onUpdateSecurity,
  appSettings,
  onLockNow,
  isPopupView = false,
  onOpenInPopup,
}) => {
  const isLight = appSettings.themeMode === 'light';
  const isEn = appSettings.language === 'en';
  const dualAccent = getDualAccentInfo(
    appSettings.themeAccent,
    appSettings.secondaryAccent,
    appSettings.accentPercentage
  );

  // Active sub-tab: 'pin' or 'pattern'
  const [activeTab, setActiveTab] = useState<LockType>(
    securitySettings.activeLockType || (securitySettings.isPatternEnabled ? 'pattern' : 'pin')
  );

  // PIN Form States
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [pinError, setPinError] = useState('');
  const [pinSuccess, setPinSuccess] = useState('');
  const [isSettingPin, setIsSettingPin] = useState(false);

  // Pattern Setup States
  const [patternStep, setPatternStep] = useState<'idle' | 'draw' | 'confirm'>('idle');
  const [tempPattern, setTempPattern] = useState<number[]>([]);
  const [patternError, setPatternError] = useState('');
  const [patternSuccess, setPatternSuccess] = useState('');
  const [patternCanvasKey, setPatternCanvasKey] = useState(0);

  // Test states
  const [testingLock, setTestingLock] = useState<'none' | 'pin' | 'pattern'>('none');
  const [testPinInput, setTestPinInput] = useState('');
  const [testResultMsg, setTestResultMsg] = useState('');

  const cardBg = isLight
    ? 'bg-white/95 border-sky-200 shadow-sm'
    : 'bg-slate-800/90 border-slate-700/70 shadow-md';
  const innerCardBg = isLight
    ? 'bg-sky-50/70 border-sky-200/80'
    : 'bg-slate-900/60 border-slate-800';
  const headingText = isLight ? 'text-sky-950' : 'text-slate-100';
  const subText = isLight ? 'text-sky-800/80' : 'text-slate-400';

  // --- PIN Handlers ---
  const handleSavePin = (e: React.FormEvent) => {
    e.preventDefault();
    setPinError('');
    setPinSuccess('');

    if (newPin.length < 4 || newPin.length > 6) {
      setPinError(isEn ? 'PIN must be between 4 and 6 digits.' : 'পিন ৪ থেকে ৬ ডিজিটের হতে হবে।');
      return;
    }
    if (newPin !== confirmPin) {
      setPinError(isEn ? 'PINs do not match! Please re-type.' : 'উভয় পিন নম্বর মেলেনি! আবার লিখুন।');
      return;
    }

    const hashed = hashPin(newPin);
    onUpdateSecurity({
      ...securitySettings,
      isPinEnabled: true,
      pinHash: hashed,
      activeLockType: 'pin',
    });

    setPinSuccess(isEn ? 'PIN Lock configured successfully!' : 'পিন লক সফলভাবে সেট করা হয়েছে!');
    setNewPin('');
    setConfirmPin('');
    setIsSettingPin(false);
  };

  const handleDisablePin = () => {
    onUpdateSecurity({
      ...securitySettings,
      isPinEnabled: false,
      pinHash: '',
      activeLockType: securitySettings.isPatternEnabled ? 'pattern' : 'pin',
    });
    setPinSuccess(isEn ? 'PIN Lock disabled.' : 'পিন লক বন্ধ করা হয়েছে।');
  };

  // --- Pattern Handlers ---
  const handlePatternRecorded = (pattern: number[]) => {
    setPatternError('');
    setPatternSuccess('');

    if (pattern.length < 4) {
      setPatternError(
        isEn
          ? 'Connect at least 4 dots for security!'
          : 'নিরাপত্তার জন্য অন্তত ৪টি ডট যুক্ত করুন!'
      );
      setPatternCanvasKey((k) => k + 1);
      return;
    }

    if (patternStep === 'draw' || patternStep === 'idle') {
      setTempPattern(pattern);
      setPatternStep('confirm');
      setPatternCanvasKey((k) => k + 1);
    } else if (patternStep === 'confirm') {
      const match =
        tempPattern.length === pattern.length &&
        tempPattern.every((val, idx) => val === pattern[idx]);

      if (match) {
        const hashed = hashPattern(pattern);
        onUpdateSecurity({
          ...securitySettings,
          isPatternEnabled: true,
          patternHash: hashed,
          activeLockType: 'pattern',
        });
        setPatternSuccess(
          isEn ? 'Pattern Lock set successfully!' : 'প্যাটার্ন লক সফলভাবে সেট করা হয়েছে!'
        );
        setPatternStep('idle');
        setTempPattern([]);
      } else {
        setPatternError(
          isEn
            ? 'Pattern did not match! Try drawing again.'
            : 'প্যাটার্ন মেলেনি! আবার শুরু থেকে আঁকুন।'
        );
        setPatternStep('draw');
        setTempPattern([]);
        setPatternCanvasKey((k) => k + 1);
      }
    }
  };

  const handleDisablePattern = () => {
    onUpdateSecurity({
      ...securitySettings,
      isPatternEnabled: false,
      patternHash: '',
      activeLockType: securitySettings.isPinEnabled ? 'pin' : 'pattern',
    });
    setPatternSuccess(isEn ? 'Pattern Lock disabled.' : 'প্যাটার্ন লক বন্ধ করা হয়েছে।');
    setPatternStep('idle');
  };

  // Test Pattern
  const handleTestPattern = (pattern: number[]) => {
    if (!securitySettings.patternHash) return;
    if (verifyPattern(pattern, securitySettings.patternHash)) {
      setTestResultMsg(isEn ? 'Pattern Matched! Unlock Successful.' : 'প্যাটার্ন সঠিক! আনলক সফল।');
    } else {
      setTestResultMsg(isEn ? 'Incorrect Pattern!' : 'ভুল প্যাটার্ন!');
    }
    setTimeout(() => {
      setTestingLock('none');
      setTestResultMsg('');
    }, 2000);
  };

  // Test PIN
  const handleTestPin = (pin: string) => {
    if (!securitySettings.pinHash) return;
    if (verifyPin(pin, securitySettings.pinHash)) {
      setTestResultMsg(isEn ? 'PIN Matched! Unlock Successful.' : 'পিন সঠিক! আনলক সফল।');
    } else {
      setTestResultMsg(isEn ? 'Incorrect PIN!' : 'ভুল পিন নম্বর!');
    }
    setTimeout(() => {
      setTestingLock('none');
      setTestResultMsg('');
      setTestPinInput('');
    }, 2000);
  };

  const isAnyLockActive = securitySettings.isPinEnabled || securitySettings.isPatternEnabled;

  return (
    <div
      className={`${isPopupView ? '' : `${cardBg} border rounded-3xl p-5`} space-y-5 transition-all`}
      id="app-lock-and-security-section"
    >
      {/* Header with Lock Now */}
      {!isPopupView ? (
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div
              className="p-2 rounded-xl"
              style={{
                backgroundColor: `${dualAccent.primary.hex}20`,
                color: dualAccent.primary.hex,
              }}
            >
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h2 className={`text-base font-black tracking-tight ${headingText} flex items-center gap-1.5`}>
                <span>{isEn ? 'Lock & Security' : 'লক ও সিকিউরিটি'}</span>
              </h2>
              <p className={`text-[11px] ${subText}`}>
                {isEn
                  ? 'Protect your financial records with Pattern or PIN Lock'
                  : 'প্যাটার্ন অথবা পিন লকের মাধ্যমে হিসাব সুরক্ষিত রাখুন'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onOpenInPopup && (
              <button
                type="button"
                onClick={onOpenInPopup}
                className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shrink-0 ${
                  isLight
                    ? 'bg-sky-50 hover:bg-sky-100 border-sky-200 text-sky-900'
                    : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200'
                }`}
                title={isEn ? 'Open in Popup Modal' : 'পপআপে খুলুন'}
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{isEn ? 'Open Popup' : 'পপআপ ভিউ'}</span>
              </button>
            )}

            {isAnyLockActive && (
              <button
                type="button"
                onClick={onLockNow}
                className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 shadow-sm active:scale-95 cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>{isEn ? 'Lock Now' : 'এখনই লক করুন'}</span>
              </button>
            )}
          </div>
        </div>
      ) : isAnyLockActive ? (
        <div className="flex items-center justify-end pb-1">
          <button
            type="button"
            onClick={onLockNow}
            className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 shadow-sm active:scale-95 cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>{isEn ? 'Lock Now' : 'এখনই লক করুন'}</span>
          </button>
        </div>
      ) : null}

      {/* Segmented Switch: PIN vs Pattern */}
      <div
        className="grid grid-cols-2 gap-2 p-1 rounded-2xl border transition-colors"
        style={{
          backgroundColor: isLight
            ? `color-mix(in srgb, ${dualAccent.primary.hex} 10%, #ffffff)`
            : `color-mix(in srgb, ${dualAccent.primary.hex} 12%, #0f172a)`,
          borderColor: `color-mix(in srgb, ${dualAccent.primary.hex} 25%, transparent)`,
        }}
      >
        {/* PIN Option Tab */}
        <button
          type="button"
          onClick={() => {
            setActiveTab('pin');
            setTestingLock('none');
          }}
          id="app-lock-tab-pin"
          style={
            activeTab === 'pin'
              ? {
                  backgroundColor: dualAccent.primary.hex,
                  color: '#ffffff',
                  boxShadow: `0 4px 14px -2px ${dualAccent.primary.hex}60`,
                }
              : undefined
          }
          className={`py-2.5 px-3 rounded-xl font-bold text-xs transition flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'pin'
              ? 'font-black text-white shadow-md'
              : isLight
              ? 'text-slate-600 hover:text-slate-900 hover:bg-black/5'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <KeyRound className="w-4 h-4" style={{ color: activeTab === 'pin' ? '#ffffff' : dualAccent.primary.hex }} />
          <span>{isEn ? 'PIN Lock' : 'পিন লক (PIN)'}</span>
          {securitySettings.isPinEnabled && (
            <span className="w-2 h-2 rounded-full bg-emerald-500" title="PIN active" />
          )}
        </button>

        {/* Pattern Option Tab */}
        <button
          type="button"
          onClick={() => {
            setActiveTab('pattern');
            setTestingLock('none');
          }}
          id="app-lock-tab-pattern"
          style={
            activeTab === 'pattern'
              ? {
                  backgroundColor: dualAccent.primary.hex,
                  color: '#ffffff',
                  boxShadow: `0 4px 14px -2px ${dualAccent.primary.hex}60`,
                }
              : undefined
          }
          className={`py-2.5 px-3 rounded-xl font-bold text-xs transition flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'pattern'
              ? 'font-black text-white shadow-md'
              : isLight
              ? 'text-slate-600 hover:text-slate-900 hover:bg-black/5'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Grid3X3 className="w-4 h-4" style={{ color: activeTab === 'pattern' ? '#ffffff' : dualAccent.primary.hex }} />
          <span>{isEn ? 'Pattern Lock' : 'প্যাটার্ন লক (Pattern)'}</span>
          {securitySettings.isPatternEnabled && (
            <span className="w-2 h-2 rounded-full bg-emerald-500" title="Pattern active" />
          )}
        </button>
      </div>

      {/* Active Default Lock Method Preference (if both are enabled) */}
      {securitySettings.isPinEnabled && securitySettings.isPatternEnabled && (
        <div className={`p-3 rounded-2xl border ${innerCardBg} flex items-center justify-between text-xs`}>
          <div>
            <p className={`font-bold ${headingText}`}>
              {isEn ? 'Primary Unlock Method' : 'ডিফল্ট আনলক পদ্ধতি'}
            </p>
            <p className={`text-[11px] ${subText}`}>
              {isEn
                ? 'Choose which lock screen shows first on app open'
                : 'অ্যাপ খোলার সময় প্রথমে কোনটি প্রদর্শিত হবে'}
            </p>
          </div>
          <div className="flex gap-1">
            <button
              type="button"
              onClick={() => onUpdateSecurity({ ...securitySettings, activeLockType: 'pin' })}
              className={`px-2.5 py-1 rounded-lg font-bold text-[11px] border transition ${
                securitySettings.activeLockType === 'pin'
                  ? 'bg-indigo-600 text-white border-indigo-600'
                  : isLight
                  ? 'bg-white text-slate-700 border-sky-200'
                  : 'bg-slate-800 text-slate-300 border-slate-700'
              }`}
            >
              PIN
            </button>
            <button
              type="button"
              onClick={() => onUpdateSecurity({ ...securitySettings, activeLockType: 'pattern' })}
              className={`px-2.5 py-1 rounded-lg font-bold text-[11px] border transition ${
                securitySettings.activeLockType === 'pattern'
                  ? 'bg-indigo-600 text-white border-indigo-600'
                  : isLight
                  ? 'bg-white text-slate-700 border-sky-200'
                  : 'bg-slate-800 text-slate-300 border-slate-700'
              }`}
            >
              Pattern
            </button>
          </div>
        </div>
      )}

      {/* --- TAB 1: PIN LOCK CONTENT --- */}
      {activeTab === 'pin' && (
        <div className="space-y-4 animate-in fade-in duration-150">
          {securitySettings.isPinEnabled && !isSettingPin ? (
            <div className={`p-4 rounded-2xl border space-y-3.5 ${innerCardBg}`}>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isEn ? 'PIN Lock is currently active' : 'পিন লক চালু রয়েছে'}</span>
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setTestingLock('pin');
                      setTestPinInput('');
                    }}
                    className={`text-xs font-bold px-2.5 py-1 rounded-lg border transition ${
                      isLight
                        ? 'bg-white border-sky-200 text-sky-800 hover:bg-sky-50'
                        : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750'
                    }`}
                  >
                    {isEn ? 'Test PIN' : 'টেস্ট পিন'}
                  </button>
                  <button
                    type="button"
                    onClick={handleDisablePin}
                    className="text-xs text-rose-500 hover:text-rose-600 font-bold"
                  >
                    {isEn ? 'Disable' : 'বন্ধ করুন'}
                  </button>
                </div>
              </div>

              {/* Test PIN box */}
              {testingLock === 'pin' && (
                <div className="p-3 rounded-xl border bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10 space-y-2">
                  <p className={`text-xs font-bold text-center ${headingText}`}>
                    {isEn ? 'Enter PIN to test unlock:' : 'টেস্ট করতে পিন নম্বর দিন:'}
                  </p>
                  <PinLockPad
                    pin={testPinInput}
                    onChange={setTestPinInput}
                    onSubmit={handleTestPin}
                    accentColor={dualAccent.primary.hex}
                    isLight={isLight}
                    isEn={isEn}
                    error={testResultMsg}
                  />
                </div>
              )}

              <div className="pt-2 border-t border-black/10 dark:border-white/10 flex items-center justify-between">
                <span className={`text-[11px] ${subText}`}>
                  {isEn ? 'Want to set a new PIN?' : 'নতুন পিন সেট করতে চান?'}
                </span>
                <button
                  type="button"
                  onClick={() => setIsSettingPin(true)}
                  className={`text-xs font-bold transition text-indigo-600 dark:text-indigo-400`}
                >
                  {isEn ? 'Change PIN' : 'পিন পরিবর্তন করুন'}
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSavePin} className={`p-4 rounded-2xl border space-y-3.5 ${innerCardBg}`}>
              <div className="flex items-center justify-between">
                <p className={`text-xs font-bold ${headingText}`}>
                  {isEn ? 'Set 4 to 6 Digit Security PIN:' : '৪ থেকে ৬ ডিজিটের সিকিউরিটি পিন দিন:'}
                </p>
                {securitySettings.isPinEnabled && (
                  <button
                    type="button"
                    onClick={() => setIsSettingPin(false)}
                    className={`text-xs ${subText} hover:underline`}
                  >
                    {isEn ? 'Cancel' : 'বাতিল'}
                  </button>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <input
                    type="password"
                    maxLength={6}
                    placeholder={isEn ? 'New PIN' : 'নতুন পিন'}
                    value={newPin}
                    onChange={(e) => {
                      setNewPin(e.target.value);
                      setPinError('');
                      setPinSuccess('');
                    }}
                    className={`w-full px-3 py-2.5 border rounded-xl text-xs text-center font-bold tracking-widest focus:outline-none ${
                      isLight
                        ? 'bg-white border-sky-200 text-sky-950 focus:border-indigo-500'
                        : 'bg-slate-900 border-slate-700 text-white focus:border-indigo-500'
                    }`}
                  />
                </div>
                <div>
                  <input
                    type="password"
                    maxLength={6}
                    placeholder={isEn ? 'Confirm PIN' : 'পিন নিশ্চিত করুন'}
                    value={confirmPin}
                    onChange={(e) => {
                      setConfirmPin(e.target.value);
                      setPinError('');
                      setPinSuccess('');
                    }}
                    className={`w-full px-3 py-2.5 border rounded-xl text-xs text-center font-bold tracking-widest focus:outline-none ${
                      isLight
                        ? 'bg-white border-sky-200 text-sky-950 focus:border-indigo-500'
                        : 'bg-slate-900 border-slate-700 text-white focus:border-indigo-500'
                    }`}
                  />
                </div>
              </div>

              {pinError && (
                <p className="text-xs text-rose-500 flex items-center gap-1 font-semibold">
                  <AlertCircle className="w-3.5 h-3.5" /> {pinError}
                </p>
              )}
              {pinSuccess && (
                <p className="text-xs text-emerald-600 dark:text-emerald-400 flex items-center gap-1 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" /> {pinSuccess}
                </p>
              )}

              <button
                type="submit"
                style={dualAccent.primaryButtonStyle}
                className="w-full py-2.5 text-white font-bold rounded-xl text-xs transition shadow-sm active:scale-98 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <KeyRound className="w-3.5 h-3.5" />
                <span>{isEn ? 'Save PIN' : 'পিন সংরক্ষণ করুন'}</span>
              </button>
            </form>
          )}
        </div>
      )}

      {/* --- TAB 2: PATTERN LOCK CONTENT --- */}
      {activeTab === 'pattern' && (
        <div className="space-y-4 animate-in fade-in duration-150">
          {securitySettings.isPatternEnabled && patternStep === 'idle' ? (
            <div className={`p-4 rounded-2xl border space-y-3.5 ${innerCardBg}`}>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isEn ? 'Pattern Lock is currently active' : 'প্যাটার্ন লক চালু রয়েছে'}</span>
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setTestingLock('pattern')}
                    className={`text-xs font-bold px-2.5 py-1 rounded-lg border transition ${
                      isLight
                        ? 'bg-white border-sky-200 text-sky-800 hover:bg-sky-50'
                        : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750'
                    }`}
                  >
                    {isEn ? 'Test Pattern' : 'টেস্ট প্যাটার্ন'}
                  </button>
                  <button
                    type="button"
                    onClick={handleDisablePattern}
                    className="text-xs text-rose-500 hover:text-rose-600 font-bold"
                  >
                    {isEn ? 'Disable' : 'বন্ধ করুন'}
                  </button>
                </div>
              </div>

              {/* Test Pattern Mode */}
              {testingLock === 'pattern' && (
                <div className="p-3 rounded-xl border bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10 flex flex-col items-center space-y-2">
                  <p className={`text-xs font-bold ${headingText}`}>
                    {isEn ? 'Draw your pattern to test unlock:' : 'টেস্ট করতে প্যাটার্নটি আঁকুন:'}
                  </p>
                  <PatternLockCanvas
                    key="test-pattern"
                    onPatternComplete={handleTestPattern}
                    accentColor={dualAccent.primary.hex}
                    isLight={isLight}
                    size={240}
                    helperText={testResultMsg}
                    error={testResultMsg.includes('Incorrect') || testResultMsg.includes('ভুল')}
                    success={testResultMsg.includes('Matched') || testResultMsg.includes('সঠিক')}
                  />
                </div>
              )}

              <div className="pt-2 border-t border-black/10 dark:border-white/10 flex items-center justify-between">
                <span className={`text-[11px] ${subText}`}>
                  {isEn ? 'Want to set a new pattern?' : 'নতুন প্যাটার্ন আঁকতে চান?'}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setPatternStep('draw');
                    setTempPattern([]);
                    setPatternCanvasKey((k) => k + 1);
                  }}
                  className={`text-xs font-bold transition text-indigo-600 dark:text-indigo-400`}
                >
                  {isEn ? 'Change Pattern' : 'প্যাটার্ন পরিবর্তন করুন'}
                </button>
              </div>
            </div>
          ) : (
            <div className={`p-4 rounded-2xl border space-y-3.5 ${innerCardBg} flex flex-col items-center`}>
              <div className="w-full flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-indigo-500" />
                  <span className={`text-xs font-bold ${headingText}`}>
                    {patternStep === 'confirm'
                      ? isEn
                        ? 'Confirm your pattern (draw again):'
                        : 'প্যাটার্নটি নিশ্চিত করতে পুনরায় আঁকুন:'
                      : isEn
                      ? 'Draw a 3x3 pattern (at least 4 dots):'
                      : '৩x৩ প্যাটার্নটি আঁকুন (কমপক্ষে ৪টি ডট):'}
                  </span>
                </div>

                {securitySettings.isPatternEnabled && (
                  <button
                    type="button"
                    onClick={() => {
                      setPatternStep('idle');
                      setTempPattern([]);
                    }}
                    className={`text-xs ${subText} hover:underline`}
                  >
                    {isEn ? 'Cancel' : 'বাতিল'}
                  </button>
                )}
              </div>

              {/* Pattern Canvas for Setup */}
              <PatternLockCanvas
                key={`setup-canvas-${patternCanvasKey}`}
                onPatternComplete={handlePatternRecorded}
                accentColor={dualAccent.primary.hex}
                isLight={isLight}
                size={250}
                helperText={
                  patternError ||
                  (patternStep === 'confirm'
                    ? isEn
                      ? 'Redraw the same pattern to confirm'
                      : 'একই প্যাটার্ন আবার আঁকুন'
                    : isEn
                    ? 'Connect at least 4 dots'
                    : 'কমপক্ষে ৪টি ডট যুক্ত করুন')
                }
                error={Boolean(patternError)}
              />

              {patternSuccess && (
                <p className="text-xs text-emerald-600 dark:text-emerald-400 flex items-center gap-1 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" /> {patternSuccess}
                </p>
              )}
            </div>
          )}
        </div>
      )}

      {/* Auto-Lock Interval & 2FA Options */}
      <div className={`p-4 rounded-2xl border ${innerCardBg} space-y-3.5`}>
        {/* Auto Lock Timer */}
        <div className="flex items-center justify-between">
          <div>
            <p className={`text-xs font-bold flex items-center gap-1.5 ${headingText}`}>
              <Clock className="w-3.5 h-3.5 text-indigo-500" />
              <span>{isEn ? 'Auto-Lock Timeout' : 'অটো-লক সময়সীমা'}</span>
            </p>
            <p className={`text-[10px] mt-0.5 ${subText}`}>
              {isEn
                ? 'Locks app after inactivity'
                : 'অ্যাপ অব্যবহৃত থাকলে নির্দিষ্ট সময় পর স্বয়ংক্রিয়ভাবে লক হবে'}
            </p>
          </div>

          <select
            value={securitySettings.autoLockMinutes}
            onChange={(e) =>
              onUpdateSecurity({
                ...securitySettings,
                autoLockMinutes: Number(e.target.value),
              })
            }
            className={`text-xs font-bold px-2.5 py-1.5 rounded-xl border focus:outline-none ${
              isLight
                ? 'bg-white border-sky-200 text-sky-950'
                : 'bg-slate-800 border-slate-700 text-white'
            }`}
          >
            <option value={0}>{isEn ? 'Immediate' : 'তাৎক্ষণিক'}</option>
            <option value={1}>{isEn ? '1 Minute' : '১ মিনিট'}</option>
            <option value={5}>{isEn ? '5 Minutes' : '৫ মিনিট'}</option>
            <option value={15}>{isEn ? '15 Minutes' : '১৫ মিনিট'}</option>
          </select>
        </div>

        {/* 2FA Toggle */}
        <div className={`pt-3 border-t flex items-center justify-between ${isLight ? 'border-sky-200' : 'border-slate-800'}`}>
          <div>
            <p className={`text-xs font-bold flex items-center gap-1.5 ${headingText}`}>
              <Smartphone className="w-3.5 h-3.5 text-indigo-500" />
              <span>{isEn ? 'Two-Factor Authentication (2FA)' : 'টু-ফ্যাক্টর অথেন্টিকেশন (2FA)'}</span>
            </p>
            <p className={`text-[10px] mt-0.5 ${subText}`}>
              {isEn
                ? 'Requires a 2FA OTP code after unlocking PIN or Pattern'
                : 'পিন বা প্যাটার্ন আনলকের পর ২এফএ ভেরিফিকেশন কোড চাইবে'}
            </p>
          </div>

          <input
            type="checkbox"
            checked={securitySettings.is2FAEnabled}
            onChange={(e) =>
              onUpdateSecurity({
                ...securitySettings,
                is2FAEnabled: e.target.checked,
              })
            }
            className="w-4 h-4 accent-indigo-500 rounded cursor-pointer"
          />
        </div>
      </div>
    </div>
  );
};
