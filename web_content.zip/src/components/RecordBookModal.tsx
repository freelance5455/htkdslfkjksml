import React from 'react';
import { Award, CheckCircle2, Lock, Play, Trophy, X } from 'lucide-react';
import { DISCIPLINE_LIST } from '../data/disciplines';
import { DisciplineId, RecordEntry } from '../types/game';

interface RecordBookModalProps {
  records: Record<DisciplineId, RecordEntry>;
  onClose: () => void;
  onSelectAndPlay: (id: DisciplineId) => void;
}

export const RecordBookModal: React.FC<RecordBookModalProps> = ({
  records,
  onClose,
  onSelectAndPlay,
}) => {
  const brokenCount = Object.values(records).filter((r) => r.isRecordBroken).length;

  const getRankName = () => {
    if (brokenCount === 3) return '👑 Абсолютный Монарх Книги Гиннесса';
    if (brokenCount === 2) return '🏆 Заслуженный Гранд-Мастер Круглости';
    if (brokenCount === 1) return '🥇 Официальный Рекордсмен Паркета';
    return '🐾 Претендент на Мировую Сферичность';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-3xl guinness-panel rounded-3xl p-6 sm:p-7 border-2 border-amber-400/60 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-amber-400/25 pb-4">
          <div className="flex items-center gap-3.5">
            <img
              src="/images/kotost-portrait.jpg"
              alt="Котость"
              className="w-14 h-14 rounded-2xl object-cover border-2 border-amber-400 shadow-lg"
            />
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-widest text-amber-400">
                <Trophy className="w-3.5 h-3.5" />
                Официальный Архив Достижений
              </div>
              <h2 className="font-display text-2xl sm:text-3xl font-black uppercase text-amber-50">
                Книга Рекордов Котости
              </h2>
              <p className="text-xs sm:text-sm font-bold text-amber-200/80">
                Текущий титул: <span className="text-amber-300">{getRankName()}</span> ({brokenCount}/3 рекордов)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-amber-200 border border-amber-400/30 cursor-pointer"
            title="Закрыть"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Disciplines Cards */}
        <div className="space-y-3.5 my-5">
          {DISCIPLINE_LIST.map((disc) => {
            const rec = records[disc.id];
            const isBroken = rec.isRecordBroken;
            const progressPct = Math.min(100, Math.round((rec.bestScore / disc.targetScore) * 100));

            return (
              <div
                key={disc.id}
                className={`rounded-2xl p-4 sm:p-5 border-2 transition flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                  isBroken
                    ? 'bg-gradient-to-r from-amber-500/20 via-slate-900/80 to-emerald-500/15 border-amber-400/70'
                    : 'bg-slate-900/70 border-slate-700/80'
                }`}
              >
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[11px] font-mono-num font-extrabold px-2.5 py-0.5 rounded-md bg-slate-800 text-amber-300 border border-amber-400/30">
                      {disc.code}
                    </span>
                    <h3 className="font-display text-lg font-black uppercase text-white">
                      {disc.title}
                    </h3>
                    {isBroken ? (
                      <span className="inline-flex items-center gap-1 text-xs font-extrabold px-2.5 py-0.5 rounded-full bg-emerald-500/25 text-emerald-300 border border-emerald-400/50">
                        <CheckCircle2 className="w-3.5 h-3.5" /> МИРОВОЙ РЕКОРД ВЗЯТ
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs font-bold px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-400">
                        <Lock className="w-3 h-3" /> Цель: {disc.targetScore} {disc.unit}
                      </span>
                    )}
                  </div>

                  <p className="text-xs sm:text-sm text-slate-300 font-semibold">
                    {disc.guinnessCategory}
                  </p>

                  {/* Progress bar toward world record */}
                  <div className="pt-1">
                    <div className="flex justify-between text-xs font-bold mb-1">
                      <span className="text-amber-300 font-mono-num">
                        Лучший результат: {rec.bestScore} {disc.unit}
                      </span>
                      <span className="text-slate-400 font-mono-num">
                        Норматив Гиннесса: {disc.targetScore} {disc.unit}
                      </span>
                    </div>
                    <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-700">
                      <div
                        className={`h-full transition-all duration-500 ${
                          isBroken
                            ? 'bg-gradient-to-r from-amber-400 to-emerald-400'
                            : 'bg-gradient-to-r from-amber-500 to-orange-500'
                        }`}
                        style={{ width: `${progressPct}%` }}
                      />
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => {
                    onClose();
                    onSelectAndPlay(disc.id);
                  }}
                  className="btn-gold-arcade px-4 py-2.5 rounded-xl font-display font-extrabold text-xs uppercase tracking-wider flex items-center gap-1.5 shrink-0 cursor-pointer"
                >
                  <Play className="w-4 h-4 fill-current" />
                  {isBroken ? 'Улучшить' : 'Побить Рекорд'}
                </button>
              </div>
            );
          })}
        </div>

        {/* Footer note */}
        <div className="flex items-center justify-between flex-wrap gap-3 pt-3 border-t border-amber-400/20 text-xs text-slate-300">
          <div className="flex items-center gap-2 font-bold text-amber-300">
            <Award className="w-4 h-4" />
            Побитые рекорды открывают золотые кубки прямо на 3D-сцене позади Котости!
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 font-bold text-white cursor-pointer"
          >
            Вернуться к Котости
          </button>
        </div>
      </div>
    </div>
  );
};
