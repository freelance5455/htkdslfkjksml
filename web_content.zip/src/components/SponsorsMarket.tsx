import React from 'react';
import {
  DollarSign,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Calendar,
  Briefcase,
  ShieldAlert,
} from 'lucide-react';
import { Sponsor, TimeSlotId } from '../types/game';
import { soundFx } from '../utils/audio';

interface SponsorsMarketProps {
  sponsors: Sponsor[];
  onSignContract: (sponsorId: string) => void;
  onCancelContract: (sponsorId: string) => void;
  cash: number;
}

export const SponsorsMarket: React.FC<SponsorsMarketProps> = ({
  sponsors,
  onSignContract,
  onCancelContract,
  cash,
}) => {
  const activeSponsors = sponsors.filter((s) => s.isActive);
  const marketSponsors = sponsors.filter((s) => !s.isActive);

  return (
    <div className="w-full h-full flex flex-col gap-4 select-none overflow-y-auto pr-1">
      {/* Top Banner */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-xl p-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-emerald-400" />
            Departamento Comercial & Cotas de Publicidade
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            As marcas pagam fortunas para exibir seus produtos nos intervalos comerciais. Cumpra as metas de IBOPE para evitar multas contratuais.
          </p>
        </div>

        <div className="text-right">
          <span className="text-[10px] font-mono text-slate-400 block uppercase">
            COTAS ATIVAS NO AR
          </span>
          <span className="text-sm font-mono font-bold text-emerald-400">
            {activeSponsors.length} de {sponsors.length} Marcas
          </span>
        </div>
      </div>

      {/* Active Contracts Section */}
      <div>
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
          <Briefcase className="w-4 h-4 text-amber-400" />
          Contratos Publicitários Vigentes
        </h3>

        {activeSponsors.length === 0 ? (
          <div className="p-8 rounded-xl bg-slate-900/60 border border-dashed border-slate-800 text-center text-xs text-slate-400">
            Nenhuma cota publicitária assinada no momento. Assine contratos abaixo para gerar receita constante!
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {activeSponsors.map((sponsor) => (
              <div
                key={sponsor.id}
                className="rounded-2xl bg-slate-900/90 border border-emerald-500/40 p-5 flex flex-col justify-between shadow-lg shadow-emerald-950/20"
              >
                <div>
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-black text-xs shadow-md"
                        style={{ backgroundColor: sponsor.logoColor }}
                      >
                        {sponsor.name.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white">{sponsor.name}</h4>
                        <span className="text-[11px] text-slate-400">{sponsor.productType}</span>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono font-bold text-emerald-400 px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-800">
                      EM VIGOR
                    </span>
                  </div>

                  <div className="mt-4 space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Pagamento p/ Exibição:</span>
                      <span className="font-mono font-bold text-emerald-400 text-sm">
                        + R$ {sponsor.payoutPerSlot.toLocaleString('pt-BR')}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Meta Mínima IBOPE:</span>
                      <span className="font-mono font-bold text-amber-400">
                        {sponsor.targetRating.toFixed(1)} pontos
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Duração Restante:</span>
                      <span className="font-mono text-slate-300">
                        {sponsor.contractDaysRemaining} dias
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-400">Faixa Horária Escalada:</span>
                      <span className="font-mono font-bold text-slate-200 uppercase">
                        {sponsor.assignedSlot || 'Não vinculado à grade'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
                  <div className="text-[10px] text-rose-400 flex items-center gap-1">
                    <ShieldAlert className="w-3.5 h-3.5" />
                    Multa quebra: R$ {sponsor.penaltyOnFail.toLocaleString('pt-BR')}
                  </div>
                  <button
                    onClick={() => {
                      soundFx.playClick();
                      onCancelContract(sponsor.id);
                    }}
                    className="min-h-[44px] px-3 py-1.5 rounded-lg text-xs text-slate-400 hover:text-red-400 transition-colors cursor-pointer active:scale-95 flex items-center"
                  >
                    Rescindir
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Available Market Contracts Section */}
      <div className="mt-4">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-emerald-400" />
          Propostas de Patrocínio no Mercado
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {marketSponsors.map((sponsor) => (
            <div
              key={sponsor.id}
              className="rounded-2xl bg-slate-900/60 border border-slate-800 p-5 flex flex-col justify-between shadow-lg hover:border-slate-700 transition-all"
            >
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-black text-xs shadow-md"
                      style={{ backgroundColor: sponsor.logoColor }}
                    >
                      {sponsor.name.substring(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">{sponsor.name}</h4>
                      <span className="text-[11px] text-slate-400">{sponsor.productType}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Cota p/ Bloco:</span>
                    <span className="font-mono font-bold text-emerald-400 text-sm">
                      + R$ {sponsor.payoutPerSlot.toLocaleString('pt-BR')}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Meta Mínima IBOPE:</span>
                    <span className="font-mono font-bold text-amber-400">
                      {sponsor.targetRating.toFixed(1)} pts
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Validade do Contrato:</span>
                    <span className="font-mono text-slate-300">
                      {sponsor.contractDaysRemaining} dias de exibição
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-800">
                <button
                  onClick={() => {
                    soundFx.playCash();
                    onSignContract(sponsor.id);
                  }}
                  className="w-full min-h-[46px] py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-md shadow-emerald-950/40 active:scale-95"
                >
                  <DollarSign className="w-4 h-4" />
                  <span>Assinar Cota Publicitária</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
