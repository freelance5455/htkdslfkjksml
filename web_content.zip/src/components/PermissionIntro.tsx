import { motion } from "framer-motion";

interface PermissionIntroProps {
  onAllow: () => void;
}

export default function PermissionIntro({ onAllow }: PermissionIntroProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] flex items-end justify-center bg-black/70 backdrop-blur-sm sm:items-center"
    >
      <motion.div
        initial={{ y: 80, opacity: 0, scale: 0.96 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        transition={{ type: "spring", stiffness: 260, damping: 24 }}
        className="w-full max-w-sm rounded-t-3xl border border-white/10 bg-slate-900 p-6 shadow-2xl sm:rounded-3xl"
      >
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-orange-500/15">
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth={1.8}
            className="h-7 w-7 text-orange-400"
          >
            <rect x="2" y="6" width="14" height="12" rx="2.5" />
            <path d="M16 10.5 21.5 7v10L16 13.5" />
          </svg>
        </div>
        <h2 className="text-center text-lg font-bold text-slate-100">
          Enable Floating Overlay (Demo)
        </h2>
        <p className="mt-2 text-center text-sm text-slate-400">
          Yeh sirf ek <strong>UI/animation demo</strong> hai jo screen par ek draggable floating
          icon dikhata hai — bilkul real overlay-style apps jaisa. Ismein koi real game ko access,
          read, ya modify nahi kiya jaata. Koi aimbot/ESP/bypass functionality actual mein kaam
          nahi karti — sirf button animations real hain.
        </p>
        <button
          onClick={onAllow}
          className="mt-5 w-full rounded-2xl bg-gradient-to-r from-orange-500 to-red-500 py-3 text-sm font-bold text-white shadow-lg shadow-orange-500/30 active:scale-[0.98] transition"
        >
          Allow Demo Overlay
        </button>
        <p className="mt-2 text-center text-[11px] text-slate-500">
          Is button ko dabane se sirf yeh demo UI dikhegi, koi system-level permission nahi li jaati.
        </p>
      </motion.div>
    </motion.div>
  );
}
