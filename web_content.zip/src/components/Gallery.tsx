import React, { useState } from "react";
import {
  Images,
  Search,
  Heart,
  Trash2,
  Maximize2,
  Download,
  Wand2,
  Sparkles,
  Filter,
  Copy,
  Check,
} from "lucide-react";
import { GeneratedImage } from "../types";
import { SmartImage } from "./SmartImage";
import { downloadImage } from "../utils/downloadImage";

interface GalleryProps {
  images: GeneratedImage[];
  favorites: string[];
  onToggleFavorite: (id: string) => void;
  onDeleteImage: (id: string) => void;
  onClearAll: () => void;
  onOpenImageModal: (image: GeneratedImage) => void;
  onSendToEditor: (image: GeneratedImage) => void;
  onGoToStudio: () => void;
}

export const Gallery: React.FC<GalleryProps> = ({
  images,
  favorites,
  onToggleFavorite,
  onDeleteImage,
  onClearAll,
  onOpenImageModal,
  onSendToEditor,
  onGoToStudio,
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterMode, setFilterMode] = useState<"all" | "favorites">("all");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredImages = images.filter((img) => {
    const matchesSearch =
      img.prompt.toLowerCase().includes(searchQuery.toLowerCase()) ||
      img.style.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFav = filterMode === "favorites" ? favorites.includes(img.id) : true;
    return matchesSearch && matchesFav;
  });

  const handleCopyPrompt = (prompt: string, id: string) => {
    navigator.clipboard.writeText(prompt);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header Bar: Search, Filters, Clear All */}
      <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 backdrop-blur-md flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Filter Pills */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={() => setFilterMode("all")}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition ${
              filterMode === "all"
                ? "bg-purple-600 text-white shadow-md shadow-purple-500/20"
                : "bg-slate-800 text-slate-400 hover:text-slate-200"
            }`}
          >
            <Images className="w-3.5 h-3.5" />
            <span>All Creations ({images.length})</span>
          </button>

          <button
            onClick={() => setFilterMode("favorites")}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition ${
              filterMode === "favorites"
                ? "bg-red-500 text-white shadow-md shadow-red-500/20"
                : "bg-slate-800 text-slate-400 hover:text-slate-200"
            }`}
          >
            <Heart className="w-3.5 h-3.5 fill-current" />
            <span>Favorites ({favorites.length})</span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search prompts or styles..."
            className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 text-xs placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
          />
        </div>

        {images.length > 0 && (
          <button
            onClick={onClearAll}
            className="px-3 py-1.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-300 text-xs font-medium flex items-center gap-1 transition"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear Gallery</span>
          </button>
        )}
      </div>

      {/* Gallery Grid or Empty State */}
      {filteredImages.length === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-slate-900/40 border border-slate-800/80 space-y-4">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center">
            <Images className="w-8 h-8 text-purple-400" />
          </div>
          <div className="space-y-1 max-w-sm mx-auto">
            <h3 className="text-base font-bold text-slate-200">
              {filterMode === "favorites" ? "No Favorites Saved Yet" : "No Creations Found"}
            </h3>
            <p className="text-xs text-slate-400">
              {filterMode === "favorites"
                ? "Click the heart icon on any generated artwork to save it here for quick access."
                : "Start generating text-to-image artwork in the Studio tab."}
            </p>
          </div>
          <button
            onClick={onGoToStudio}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-bold text-xs shadow-lg shadow-purple-500/20 hover:opacity-90 transition inline-flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>Open AI Studio</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredImages.map((img) => {
            const isFav = favorites.includes(img.id);
            return (
              <div
                key={img.id}
                className="group relative rounded-2xl bg-slate-900 border border-slate-800/80 overflow-hidden shadow-lg hover:border-purple-500/50 transition-all duration-300"
              >
                {/* Image */}
                <div className="relative aspect-square bg-slate-950 flex items-center justify-center overflow-hidden">
                  <SmartImage
                    src={img.url}
                    alt={img.prompt}
                    prompt={img.prompt}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />

                  {/* Overlay Controls */}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-3 flex flex-col justify-between">
                    <div className="flex justify-between items-center">
                      <span className="px-2 py-0.5 rounded bg-slate-900/80 backdrop-blur-md text-[10px] text-purple-300 font-bold border border-purple-500/30">
                        {img.style}
                      </span>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => onToggleFavorite(img.id)}
                          className={`p-1.5 rounded-full backdrop-blur-md ${
                            isFav ? "bg-red-500 text-white" : "bg-slate-900/80 text-slate-300 hover:text-white"
                          }`}
                        >
                          <Heart className={`w-3.5 h-3.5 ${isFav ? "fill-white" : ""}`} />
                        </button>
                        <button
                          onClick={() => onDeleteImage(img.id)}
                          className="p-1.5 rounded-full bg-slate-900/80 text-slate-400 hover:text-red-400 backdrop-blur-md"
                          title="Delete image"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <p className="text-[11px] text-slate-200 line-clamp-2 bg-slate-950/80 p-1.5 rounded-lg border border-slate-800/80">
                        {img.prompt}
                      </p>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => onOpenImageModal(img)}
                          className="flex-1 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-[11px] font-semibold flex items-center justify-center gap-1"
                        >
                          <Maximize2 className="w-3 h-3" />
                          <span>View</span>
                        </button>

                        <button
                          onClick={() => onSendToEditor(img)}
                          className="p-1.5 rounded-lg bg-slate-800 text-pink-400 hover:text-pink-300"
                          title="Edit Image"
                        >
                          <Wand2 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => downloadImage(img.url, `scientific_image_${img.id}.png`)}
                          className="p-1.5 rounded-lg bg-slate-800 text-emerald-400 hover:text-white hover:bg-slate-700 transition"
                          title="Save Image"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Footer label */}
                <div className="p-2.5 bg-slate-900 flex items-center justify-between text-[11px] text-slate-400">
                  <span className="truncate max-w-[140px] font-mono">{img.prompt}</span>
                  <button
                    onClick={() => handleCopyPrompt(img.prompt, img.id)}
                    className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-slate-200"
                    title="Copy prompt"
                  >
                    {copiedId === img.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
