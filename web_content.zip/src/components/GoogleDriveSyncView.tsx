import React, { useState, useEffect } from 'react';
import { Language, Student, ClassInfo, ParchiExam } from '../types';
import { translations } from '../utils/translations';
import {
  Cloud,
  CheckCircle,
  Upload,
  FileText,
  Users,
  ShieldCheck,
  RefreshCw,
  ExternalLink,
  AlertCircle
} from 'lucide-react';
import { User } from 'firebase/auth';
import {
  uploadFileToDrive,
  listAppDriveFiles,
  DriveUploadedFile
} from '../services/googleDriveService';

interface GoogleDriveSyncViewProps {
  lang: Language;
  googleUser: User | null;
  onGoogleSignIn: () => void;
  onGoogleSignOut: () => void;
  students: Student[];
  classes: ClassInfo[];
  parchis: ParchiExam[];
}

export const GoogleDriveSyncView: React.FC<GoogleDriveSyncViewProps> = ({
  lang,
  googleUser,
  onGoogleSignIn,
  onGoogleSignOut,
  students,
  classes,
  parchis,
}) => {
  const t = translations[lang];

  const [driveFiles, setDriveFiles] = useState<Array<{ id: string; name: string; createdTime?: string; webViewLink?: string }>>([]);
  const [isLoadingFiles, setIsLoadingFiles] = useState(false);
  const [backupStatus, setBackupStatus] = useState<string | null>(null);
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [confirmModalType, setConfirmModalType] = useState<'students' | 'attendance' | 'parchis' | null>(null);

  const fetchDriveFiles = async () => {
    if (!googleUser) return;
    setIsLoadingFiles(true);
    try {
      const files = await listAppDriveFiles();
      setDriveFiles(files);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoadingFiles(false);
    }
  };

  useEffect(() => {
    if (googleUser) {
      fetchDriveFiles();
    } else {
      setDriveFiles([]);
    }
  }, [googleUser]);

  const handleExecuteBackup = async (type: 'students' | 'attendance' | 'parchis') => {
    setConfirmModalType(null);
    setIsBackingUp(true);
    setBackupStatus(null);

    try {
      const dateStr = new Date().toISOString().split('T')[0];
      if (type === 'students') {
        const content = JSON.stringify(students, null, 2);
        const fileName = `Rahbar_Students_Roster_Backup_${dateStr}.json`;
        const res = await uploadFileToDrive(fileName, content, 'application/json');
        setBackupStatus(`Successfully backed up student roster to Google Drive as "${res.name}"`);
      } else if (type === 'attendance') {
        const attendanceSummary = students.map((s) => ({
          name: s.name,
          fatherName: s.fatherName,
          classId: s.classId,
          daysAttendedThisMonth: s.monthlyAttendancePresentDays,
          totalWorkingDays: s.monthlyTotalWorkingDays,
          attendanceRate: `${Math.round((s.monthlyAttendancePresentDays / s.monthlyTotalWorkingDays) * 100)}%`,
          history: s.attendanceHistory,
        }));
        const content = JSON.stringify(attendanceSummary, null, 2);
        const fileName = `Rahbar_Attendance_Record_${dateStr}.json`;
        const res = await uploadFileToDrive(fileName, content, 'application/json');
        setBackupStatus(`Successfully backed up attendance records as "${res.name}"`);
      } else if (type === 'parchis') {
        const content = JSON.stringify(parchis, null, 2);
        const fileName = `Rahbar_Exam_Parchis_Archive_${dateStr}.json`;
        const res = await uploadFileToDrive(fileName, content, 'application/json');
        setBackupStatus(`Successfully saved exam test papers archive as "${res.name}"`);
      }
      await fetchDriveFiles();
    } catch (err: any) {
      alert(`Backup failed: ${err.message}`);
    } finally {
      setIsBackingUp(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-blue-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-emerald-800/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-300 bg-blue-500/20 px-3 py-1 rounded-full mb-2 border border-blue-400/30">
            <Cloud className="w-3.5 h-3.5 text-blue-400" />
            <span>Google Workspace Drive Cloud Integration</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white">
            {t.driveSyncTitle}
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-xl">
            {t.driveSyncDesc}
          </p>
        </div>

        {/* Auth Button */}
        <div>
          {googleUser ? (
            <div className="bg-slate-800/90 p-4 rounded-2xl border border-emerald-500/40 text-xs space-y-2">
              <div className="flex items-center gap-3">
                <img
                  src={googleUser.photoURL || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80'}
                  alt="User"
                  className="w-10 h-10 rounded-full border border-emerald-400"
                />
                <div>
                  <span className="font-extrabold text-white block">
                    {googleUser.displayName || 'Authorized User'}
                  </span>
                  <span className="text-slate-400 text-[11px] block">{googleUser.email}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-700 flex items-center justify-between">
                <span className="text-emerald-400 font-bold text-[10px] flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> Drive File Scope Active
                </span>
                <button
                  onClick={onGoogleSignOut}
                  className="text-rose-300 hover:text-white font-bold text-[11px]"
                >
                  {t.signOut}
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={onGoogleSignIn}
              className="flex items-center gap-2.5 bg-white text-slate-800 hover:bg-slate-100 px-5 py-3 rounded-2xl font-bold text-xs transition shadow-lg border border-slate-200"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>{t.signInWithGoogle}</span>
            </button>
          )}
        </div>
      </div>

      {backupStatus && (
        <div className="bg-emerald-50 text-emerald-800 border border-emerald-300 p-4 rounded-2xl text-xs font-bold flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-600" />
            <span>{backupStatus}</span>
          </div>
          <button onClick={() => setBackupStatus(null)} className="text-slate-400">
            ✕
          </button>
        </div>
      )}

      {/* Backup Actions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Student Roster Backup */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col justify-between space-y-4">
          <div>
            <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-3">
              <Users className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-extrabold text-slate-900">
              Backup Student Roster & Fees
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Export all {students.length} students, fee statuses (✅ / ❌), father WhatsApp contacts, and conduct records to Google Drive.
            </p>
          </div>

          <button
            onClick={() => {
              if (!googleUser) onGoogleSignIn();
              else setConfirmModalType('students');
            }}
            disabled={isBackingUp}
            className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow transition disabled:opacity-50 flex items-center justify-center gap-1.5"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Export Students to Drive</span>
          </button>
        </div>

        {/* Attendance Records Backup */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col justify-between space-y-4">
          <div>
            <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-3">
              <CheckCircle className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-extrabold text-slate-900">
              Backup Attendance & WhatsApp Logs
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Sync monthly attendance percentages, days present, and WhatsApp absence alerts sent to fathers.
            </p>
          </div>

          <button
            onClick={() => {
              if (!googleUser) onGoogleSignIn();
              else setConfirmModalType('attendance');
            }}
            disabled={isBackingUp}
            className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow transition disabled:opacity-50 flex items-center justify-center gap-1.5"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Export Attendance to Drive</span>
          </button>
        </div>

        {/* Exam Papers (Parchi) Backup */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col justify-between space-y-4">
          <div>
            <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mb-3">
              <FileText className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-extrabold text-slate-900">
              Backup Examination Parchis
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Store all created test paper questions, MCQs, speaking prompts, and marks structure directly in your Drive.
            </p>
          </div>

          <button
            onClick={() => {
              if (!googleUser) onGoogleSignIn();
              else setConfirmModalType('parchis');
            }}
            disabled={isBackingUp}
            className="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow transition disabled:opacity-50 flex items-center justify-center gap-1.5"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Export Parchis to Drive</span>
          </button>
        </div>
      </div>

      {/* Files in Google Drive */}
      {googleUser && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
              <Cloud className="w-4 h-4 text-emerald-600" />
              <span>Center Documents Saved in Your Google Drive</span>
            </h3>
            <button
              onClick={fetchDriveFiles}
              disabled={isLoadingFiles}
              className="p-1.5 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition"
              title="Refresh list"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoadingFiles ? 'animate-spin' : ''}`} />
            </button>
          </div>

          {driveFiles.length === 0 ? (
            <p className="text-xs text-slate-400 py-4 text-center">
              No files saved yet in this session. Click any export button above or "Save to Drive" from the Parchi maker.
            </p>
          ) : (
            <div className="divide-y divide-slate-100 text-xs">
              {driveFiles.map((f) => (
                <div key={f.id} className="py-2.5 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <FileText className="w-4 h-4 text-emerald-600" />
                    <div>
                      <span className="font-bold text-slate-800 block">{f.name}</span>
                      {f.createdTime && (
                        <span className="text-[10px] text-slate-400">
                          {new Date(f.createdTime).toLocaleString()}
                        </span>
                      )}
                    </div>
                  </div>

                  {f.webViewLink && (
                    <a
                      href={f.webViewLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 hover:underline"
                    >
                      <span>Open in Drive</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Mandatory User Confirmation Dialog before mutating/uploading to Drive */}
      {confirmModalType && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-2 text-emerald-800 border-b pb-3">
              <Cloud className="w-5 h-5 text-emerald-600" />
              <h3 className="font-extrabold text-slate-900 text-sm">
                Confirm Google Drive Upload
              </h3>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              With your permission, this will upload and backup the <strong>{confirmModalType.toUpperCase()}</strong> records of Rahbar English Center to your Google Drive account.
            </p>

            <div className="flex justify-end gap-2 pt-2 border-t">
              <button
                onClick={() => setConfirmModalType(null)}
                className="px-4 py-1.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
              >
                {t.cancel}
              </button>
              <button
                onClick={() => handleExecuteBackup(confirmModalType)}
                className="px-4 py-1.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow flex items-center gap-1.5"
              >
                <CheckCircle className="w-3.5 h-3.5" />
                <span>Confirm & Upload</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
