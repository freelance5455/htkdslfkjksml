import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ChessGame } from './ChessGame';
import { 
  INITIAL_QUIZ_QUESTIONS, 
  INITIAL_EMOJI_PUZZLES, 
  INITIAL_TRUTH_DARE 
} from '../utils/mockData';
import { 
  Sparkles, 
  Trophy, 
  HelpCircle, 
  Check, 
  X, 
  Send,
  ArrowLeft 
} from 'lucide-react';

export const GamesSection: React.FC = () => {
  const { setActiveTab } = useApp();
  const [activeGame, setActiveGame] = useState<'chess' | 'quiz' | 'emoji' | 'truthdare'>('chess');

  // Quiz state
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [quizScore, setQuizScore] = useState(0);

  // Emoji puzzle state
  const [puzzles, setPuzzles] = useState(INITIAL_EMOJI_PUZZLES);
  const [puzzleInputs, setPuzzleInputs] = useState<Record<string, string>>({});
  const [revealedHints, setRevealedHints] = useState<Record<string, boolean>>({});

  // Truth or Dare state
  const [tdList] = useState(INITIAL_TRUTH_DARE);
  const [activeTdIndex, setActiveTdIndex] = useState(0);
  const [isSpinning, setIsSpinning] = useState(false);
  const [userTruthResponse, setUserTruthResponse] = useState('');
  const [submittedResponses, setSubmittedResponses] = useState<string[]>([]);

  // Quiz Handler
  const handleSelectQuizOption = (index: number) => {
    if (isAnswered) return;
    setSelectedOption(index);
    setIsAnswered(true);
    if (index === INITIAL_QUIZ_QUESTIONS[currentQIndex].correctIndex) {
      setQuizScore(prev => prev + INITIAL_QUIZ_QUESTIONS[currentQIndex].points);
    }
  };

  const handleNextQuestion = () => {
    setSelectedOption(null);
    setIsAnswered(false);
    setCurrentQIndex(prev => (prev + 1) % INITIAL_QUIZ_QUESTIONS.length);
  };

  // Emoji Puzzle Check
  const handleCheckPuzzle = (id: string, answer: string) => {
    const input = (puzzleInputs[id] || '').trim().toLowerCase();
    if (input.includes('canteen') || input.includes('maggi') || input.includes('attendance') || input.includes('fest') || input === answer.toLowerCase()) {
      setPuzzles(prev => prev.map(p => p.id === id ? { ...p, solved: true } : p));
    }
  };

  // Truth Dare Spin
  const handleSpinGossip = () => {
    setIsSpinning(true);
    setUserTruthResponse('');
    setTimeout(() => {
      const nextIndex = Math.floor(Math.random() * tdList.length);
      setActiveTdIndex(nextIndex);
      setIsSpinning(false);
    }, 600);
  };

  const handleSubmitTruthResponse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userTruthResponse.trim()) return;
    setSubmittedResponses(prev => [userTruthResponse, ...prev]);
    setUserTruthResponse('');
  };

  return (
    <div className="space-y-4 pb-20">
      
      {/* Top Back Navigation Bar */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveTab('feed')}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-cyan-500/50 text-cyan-300 text-xs font-semibold transition-all group active:scale-95"
        >
          <ArrowLeft className="w-3.5 h-3.5 group-hover:-translate-x-0.5 transition-transform" />
          <span>Back to Feeds</span>
        </button>
      </div>

      {/* Top Banner */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-purple-950/40 via-cyan-950/30 to-slate-900 border border-purple-500/30 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-cyan-400 font-semibold mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Campus Arcade</span>
          </div>
          <h2 className="font-display font-black text-lg sm:text-xl text-slate-100">
            Games & Challenges
          </h2>
          <p className="text-xs text-slate-400">
            Battle peers, solve emoji riddles & dare in Secret Gossip.
          </p>
        </div>
        <div className="w-12 h-12 rounded-2xl bg-purple-900/40 border border-purple-500/40 flex items-center justify-center text-2xl shadow-lg neon-glow-purple">
          🎮
        </div>
      </div>

      {/* Vertical Game Tab Buttons */}
      <div className="space-y-2">
        <div className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1 flex items-center justify-between">
          <span>Choose Game Arena</span>
          <span className="text-[11px] font-normal text-slate-500">Tap to play</span>
        </div>

        <div className="flex flex-col gap-2">
          {([
            {
              id: 'chess',
              title: 'Chess Grandmaster',
              badge: 'PvP & Bot',
              icon: '♟️',
              desc: 'Play with AI bot or challenge campus friends with real chess engine',
              activeColor: 'from-amber-500/25 via-slate-900 to-amber-950/30 border-amber-500/60 text-amber-300',
              pillBg: 'bg-amber-400 text-slate-950',
              tagColor: 'text-amber-400 bg-amber-500/10 border-amber-500/30'
            },
            {
              id: 'quiz',
              title: 'Campus Trivia Quiz',
              badge: 'Leaderboard',
              icon: '🧠',
              desc: 'Daily college questions, engineering, pop culture & earn points',
              activeColor: 'from-cyan-500/25 via-slate-900 to-cyan-950/30 border-cyan-500/60 text-cyan-300',
              pillBg: 'bg-cyan-400 text-slate-950',
              tagColor: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30'
            },
            {
              id: 'emoji',
              title: 'Emoji Riddle Puzzles',
              badge: 'Brain Teaser',
              icon: '🧩',
              desc: 'Decode secret slang, canteen cravings, college fest & campus exam riddles',
              activeColor: 'from-purple-500/25 via-slate-900 to-purple-950/30 border-purple-500/60 text-purple-300',
              pillBg: 'bg-purple-500 text-white',
              tagColor: 'text-purple-400 bg-purple-500/10 border-purple-500/30'
            },
            {
              id: 'truthdare',
              title: 'Secret Truth or Dare',
              badge: 'Anonymous',
              icon: '🎭',
              desc: 'Spin the neon bottle & drop honest gossip answers',
              activeColor: 'from-rose-500/25 via-slate-900 to-rose-950/30 border-rose-500/60 text-rose-300',
              pillBg: 'bg-rose-500 text-white',
              tagColor: 'text-rose-400 bg-rose-500/10 border-rose-500/30'
            }
          ] as const).map(tab => {
            const isCurrent = activeGame === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveGame(tab.id)}
                className={`w-full p-3 sm:p-3.5 rounded-2xl border transition-all text-left flex items-center justify-between gap-3 group active:scale-[0.99] ${
                  isCurrent 
                    ? `bg-gradient-to-r ${tab.activeColor} shadow-lg shadow-black/40`
                    : 'bg-slate-900/70 hover:bg-slate-900 border-slate-800/80 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-2xl shrink-0 transition-transform ${
                    isCurrent ? 'scale-110 shadow-md' : 'group-hover:scale-105'
                  } bg-slate-950/60 border border-slate-800`}>
                    {tab.icon}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className={`font-display font-bold text-sm truncate ${
                        isCurrent ? 'text-white' : 'text-slate-200'
                      }`}>
                        {tab.title}
                      </span>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${tab.tagColor}`}>
                        {tab.badge}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 truncate mt-0.5">
                      {tab.desc}
                    </p>
                  </div>
                </div>

                <div className="shrink-0 flex items-center gap-2">
                  {isCurrent ? (
                    <span className={`px-2.5 py-1 rounded-xl text-xs font-black uppercase tracking-wider flex items-center gap-1.5 shadow-sm ${tab.pillBg}`}>
                      <span>Active</span>
                      <span className="w-1.5 h-1.5 rounded-full bg-current animate-ping" />
                    </span>
                  ) : (
                    <span className="w-8 h-8 rounded-xl bg-slate-950/50 border border-slate-800 flex items-center justify-center text-slate-400 group-hover:text-cyan-300 group-hover:border-cyan-500/30 transition-all text-xs">
                      →
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* GAME 0: CHESS */}
      {activeGame === 'chess' && (
        <ChessGame />
      )}

      {/* GAME 1: QUIZ BATTLES */}
      {activeGame === 'quiz' && (
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">
              Question {currentQIndex + 1} of {INITIAL_QUIZ_QUESTIONS.length}
            </span>
            <div className="flex items-center gap-1 text-cyan-400 font-mono font-bold bg-cyan-950/60 border border-cyan-500/30 px-2.5 py-1 rounded-lg">
              <Trophy className="w-3.5 h-3.5" />
              <span>{quizScore} pts</span>
            </div>
          </div>

          {/* Question Box */}
          <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800">
            <h3 className="text-sm sm:text-base font-semibold text-slate-100 leading-snug">
              {INITIAL_QUIZ_QUESTIONS[currentQIndex].question}
            </h3>
          </div>

          {/* Options */}
          <div className="space-y-2">
            {INITIAL_QUIZ_QUESTIONS[currentQIndex].options.map((option, idx) => {
              const isCorrect = idx === INITIAL_QUIZ_QUESTIONS[currentQIndex].correctIndex;
              const isChosen = selectedOption === idx;
              let btnClass = 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-cyan-500/40';
              if (isAnswered) {
                if (isCorrect) {
                  btnClass = 'bg-emerald-500/20 border-emerald-500 text-emerald-200';
                } else if (isChosen && !isCorrect) {
                  btnClass = 'bg-rose-500/20 border-rose-500 text-rose-200';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelectQuizOption(idx)}
                  disabled={isAnswered}
                  className={`w-full p-3 rounded-xl border text-left text-xs sm:text-sm font-medium transition-all flex items-center justify-between ${btnClass}`}
                >
                  <span>{option}</span>
                  {isAnswered && isCorrect && <Check className="w-4 h-4 text-emerald-400 shrink-0" />}
                  {isAnswered && isChosen && !isCorrect && <X className="w-4 h-4 text-rose-400 shrink-0" />}
                </button>
              );
            })}
          </div>

          {/* Explanation if answered */}
          {isAnswered && (
            <div className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-500/30 text-xs text-cyan-200 space-y-1">
              <span className="font-semibold text-cyan-300 block">Fact / Lore:</span>
              <p>{INITIAL_QUIZ_QUESTIONS[currentQIndex].explanation}</p>
            </div>
          )}

          {isAnswered && (
            <div className="flex justify-end pt-2">
              <button
                onClick={handleNextQuestion}
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-all shadow-md shadow-cyan-500/20"
              >
                Next Question →
              </button>
            </div>
          )}
        </div>
      )}

      {/* GAME 2: EMOJI PUZZLES */}
      {activeGame === 'emoji' && (
        <div className="space-y-3">
          {puzzles.map(puzzle => (
            <div key={puzzle.id} className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-purple-400 font-medium">{puzzle.category}</span>
                {puzzle.solved && (
                  <span className="flex items-center gap-1 text-emerald-400 text-[11px] font-bold">
                    <Check className="w-3.5 h-3.5" /> Solved!
                  </span>
                )}
              </div>

              {/* Big Emojis */}
              <div className="py-4 text-center bg-slate-950/80 rounded-xl border border-slate-800/80">
                <p className="text-2xl sm:text-3xl tracking-widest select-none">
                  {puzzle.emojis}
                </p>
                <p className="text-[11px] text-slate-400 mt-2 font-medium">
                  {puzzle.title}
                </p>
              </div>

              {/* Hint button */}
              <div>
                <button
                  onClick={() => setRevealedHints(prev => ({ ...prev, [puzzle.id]: !prev[puzzle.id] }))}
                  className="text-[11px] text-cyan-400 hover:underline flex items-center gap-1"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>{revealedHints[puzzle.id] ? 'Hide Hint' : 'Need a hint?'}</span>
                </button>
                {revealedHints[puzzle.id] && (
                  <p className="text-xs text-slate-300 mt-1 italic pl-1 border-l-2 border-cyan-500">
                    💡 {puzzle.hint}
                  </p>
                )}
              </div>

              {/* Solution display if solved, otherwise input */}
              {puzzle.solved ? (
                <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30 text-xs text-emerald-200">
                  <span className="font-bold">Answer:</span> {puzzle.answer}
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={puzzleInputs[puzzle.id] || ''}
                    onChange={(e) => setPuzzleInputs(prev => ({ ...prev, [puzzle.id]: e.target.value }))}
                    placeholder="Guess the college situation..."
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-purple-500"
                  />
                  <button
                    onClick={() => handleCheckPuzzle(puzzle.id, puzzle.answer)}
                    className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shrink-0"
                  >
                    Check
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* GAME 3: TRUTH OR DARE */}
      {activeGame === 'truthdare' && (
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-5 space-y-5 text-center">
          
          <div className="flex items-center justify-between text-xs">
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
              tdList[activeTdIndex].type === 'truth' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
            }`}>
              {tdList[activeTdIndex].type} • {tdList[activeTdIndex].intensity}
            </span>
            <span className="text-slate-400">{tdList[activeTdIndex].category}</span>
          </div>

          {/* Interactive Neon Spinner Button */}
          <div className="py-4 flex flex-col items-center">
            <button
              onClick={handleSpinGossip}
              disabled={isSpinning}
              className={`w-24 h-24 rounded-full bg-gradient-to-tr from-rose-500 via-purple-600 to-cyan-500 p-[3px] shadow-xl shadow-rose-500/20 hover:scale-105 active:scale-95 transition-all duration-300 ${
                isSpinning ? 'animate-spin' : ''
              }`}
            >
              <div className="w-full h-full rounded-full bg-[#0a0c16] flex items-center justify-center text-3xl">
                🍾
              </div>
            </button>
            <p className="text-[11px] text-slate-400 mt-3 font-medium">
              Tap the neon bottle to spin for a new truth/dare prompt
            </p>
          </div>

          {/* Prompt card */}
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 text-slate-100 font-medium text-sm sm:text-base leading-relaxed">
            "{tdList[activeTdIndex].prompt}"
          </div>

          {/* Response Form */}
          <form onSubmit={handleSubmitTruthResponse} className="space-y-2">
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={userTruthResponse}
                onChange={(e) => setUserTruthResponse(e.target.value)}
                placeholder="Whisper your answer anonymously..."
                className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-rose-500/50"
              />
              <button
                type="submit"
                disabled={!userTruthResponse.trim()}
                className="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold disabled:opacity-40 transition-all flex items-center gap-1"
              >
                <Send className="w-3 h-3" />
                <span>Submit</span>
              </button>
            </div>
          </form>

          {/* Submitted Community Answers */}
          {submittedResponses.length > 0 && (
            <div className="text-left pt-2 space-y-1.5 border-t border-slate-800/80">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider block">
                Recent Anonymous Responses
              </span>
              {submittedResponses.map((r, i) => (
                <div key={i} className="p-2 rounded-lg bg-slate-950/50 border border-slate-800/50 text-xs text-slate-300">
                  "{r}"
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
