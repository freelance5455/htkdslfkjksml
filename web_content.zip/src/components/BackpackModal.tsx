import React, { useState } from "react";
import { Item } from "../types";
import { sound } from "../audio";
import {
  X,
  Package,
  Layers,
  ArrowRight,
  Trash2,
  Sparkles,
  Info,
  Check,
  Shield,
  Apple,
  Wrench,
  Boxes,
} from "lucide-react";

interface BackpackModalProps {
  isOpen: boolean;
  onClose: () => void;
  inventory: Item[];
  hotbar: Item[];
  activeSlot: number;
  onEquipToHotbar: (item: Item, slotIndex: number) => void;
  onDropItem?: (item: Item) => void;
  onUseItem?: (item: Item) => void;
}

export const BackpackModal: React.FC<BackpackModalProps> = ({
  isOpen,
  onClose,
  inventory,
  hotbar,
  activeSlot,
  onEquipToHotbar,
  onDropItem,
  onUseItem,
}) => {
  const [selectedItem, setSelectedItem] = useState<Item | null>(() => {
    return inventory[0] || hotbar[0] || null;
  });
  const [activeCategory, setActiveCategory] = useState<
    "all" | "tool" | "seed" | "consumable" | "resource"
  >("all");
  const [targetSlot, setTargetSlot] = useState<number>(activeSlot);

  if (!isOpen) return null;

  // Filter items by category
  const filteredItems = inventory.filter((item) => {
    if (activeCategory === "all") return true;
    if (activeCategory === "tool") return item.type === "tool";
    if (activeCategory === "seed") return item.type === "seed" || item.type === "crop";
    if (activeCategory === "consumable") return item.type === "consumable";
    if (activeCategory === "resource") return item.type === "resource";
    return true;
  });

  const maxSlots = 24;

  const handleSelectItem = (item: Item) => {
    sound.playCoin();
    setSelectedItem(item);
  };

  const handleEquip = () => {
    if (!selectedItem) return;
    sound.playHarvest();
    onEquipToHotbar(selectedItem, targetSlot);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-3 select-none">
      <div className="relative w-full max-w-3xl bg-stone-900 border-2 border-amber-600/70 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-stone-950 via-amber-950/70 to-stone-950 p-3 sm:p-4 border-b border-amber-700/50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-900/40 border border-amber-500/50 flex items-center justify-center text-2xl shadow">
              🎒
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-amber-200 font-['Hind_Siliguri']">
                  তোজোর অ্যাডভেঞ্চার ব্যাকপ্যাক (Backpack)
                </h2>
                <span className="text-[10px] bg-amber-950/90 text-amber-300 px-2 py-0.5 rounded-full border border-amber-600/40 font-mono">
                  {inventory.length}/{maxSlots} স্লট পূর্ণ
                </span>
              </div>
              <p className="text-[11px] text-stone-300">
                Tojo&apos;s Travel Inventory • Manage items, seeds, tools &amp; treats
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-stone-800 text-stone-400 hover:text-white hover:bg-stone-700 cursor-pointer transition"
            title="বন্ধ করুন [Esc / B]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Categories Bar */}
        <div className="flex items-center gap-1 p-2 bg-stone-950/90 border-b border-stone-800 overflow-x-auto text-xs">
          <button
            onClick={() => setActiveCategory("all")}
            className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeCategory === "all"
                ? "bg-amber-600 text-white shadow"
                : "bg-stone-900 text-stone-400 hover:text-stone-200"
            }`}
          >
            <Boxes className="w-3.5 h-3.5" />
            <span>সব আইটেম ({inventory.length})</span>
          </button>
          <button
            onClick={() => setActiveCategory("tool")}
            className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeCategory === "tool"
                ? "bg-amber-600 text-white shadow"
                : "bg-stone-900 text-stone-400 hover:text-stone-200"
            }`}
          >
            <Wrench className="w-3.5 h-3.5" />
            <span>হাতিয়ার ও লাঠি</span>
          </button>
          <button
            onClick={() => setActiveCategory("seed")}
            className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeCategory === "seed"
                ? "bg-amber-600 text-white shadow"
                : "bg-stone-900 text-stone-400 hover:text-stone-200"
            }`}
          >
            <span>🌱</span>
            <span>বীজ ও ফসল</span>
          </button>
          <button
            onClick={() => setActiveCategory("consumable")}
            className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeCategory === "consumable"
                ? "bg-amber-600 text-white shadow"
                : "bg-stone-900 text-stone-400 hover:text-stone-200"
            }`}
          >
            <Apple className="w-3.5 h-3.5" />
            <span>খাবার ও ট্রিট</span>
          </button>
          <button
            onClick={() => setActiveCategory("resource")}
            className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 shrink-0 cursor-pointer ${
              activeCategory === "resource"
                ? "bg-amber-600 text-white shadow"
                : "bg-stone-900 text-stone-400 hover:text-stone-200"
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>উপাদান ও কাঠ</span>
          </button>
        </div>

        {/* Content: Left Inventory Grid, Right Details & Hotbar Assigner */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 grid grid-cols-1 md:grid-cols-3 gap-3 sm:gap-4">
          {/* Left Grid (2 Columns on medium) */}
          <div className="md:col-span-2 flex flex-col gap-2">
            <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider">
              ব্যাকপ্যাক স্লট ({filteredItems.length} টি প্রাপ্ত)
            </span>

            <div className="grid grid-cols-4 sm:grid-cols-6 gap-2 bg-stone-950/60 p-2.5 rounded-xl border border-stone-800 min-h-[220px]">
              {Array.from({ length: maxSlots }).map((_, idx) => {
                const item = filteredItems[idx];
                const isSelected = selectedItem && item && selectedItem.id === item.id;
                const isInHotbar = item && hotbar.some((h) => h && h.id === item.id);

                if (!item) {
                  return (
                    <div
                      key={`empty-${idx}`}
                      className="aspect-square rounded-xl bg-stone-900/40 border border-stone-800/60 flex items-center justify-center text-stone-700 font-mono text-[10px]"
                    >
                      {idx + 1}
                    </div>
                  );
                }

                return (
                  <button
                    key={item.id}
                    onClick={() => handleSelectItem(item)}
                    className={`aspect-square rounded-xl p-1 relative flex flex-col items-center justify-center cursor-pointer transition transform active:scale-95 border ${
                      isSelected
                        ? "bg-amber-900/60 border-amber-400 ring-2 ring-amber-500/50 shadow-lg"
                        : "bg-stone-900/90 border-stone-700/80 hover:border-amber-600/60 hover:bg-stone-800"
                    }`}
                  >
                    <span className="text-2xl">{item.icon}</span>

                    {/* Stack count badge */}
                    {item.count > 1 && (
                      <span className="absolute bottom-1 right-1 bg-stone-950/90 text-amber-300 text-[10px] font-mono font-bold px-1 rounded border border-stone-700">
                        x{item.count}
                      </span>
                    )}

                    {/* In Hotbar Indicator */}
                    {isInHotbar && (
                      <span className="absolute top-1 left-1 w-2 h-2 rounded-full bg-emerald-400 ring-1 ring-emerald-600" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Quick Hotbar Current Slots View */}
            <div className="bg-stone-950/80 p-2.5 rounded-xl border border-stone-800/80 mt-1">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[11px] font-bold text-amber-300 flex items-center gap-1">
                  <Sparkles className="w-3 h-3" /> বর্তমান হটবার স্লট (১-৭)
                </span>
                <span className="text-[10px] text-stone-400 font-mono">
                  সক্রিয় স্লট: #{activeSlot + 1}
                </span>
              </div>
              <div className="grid grid-cols-7 gap-1.5">
                {Array.from({ length: 7 }).map((_, slotIdx) => {
                  const hotbarItem = hotbar[slotIdx];
                  const isActive = slotIdx === targetSlot;
                  return (
                    <button
                      key={`slot-${slotIdx}`}
                      onClick={() => setTargetSlot(slotIdx)}
                      className={`p-1 rounded-lg flex flex-col items-center justify-center text-center cursor-pointer transition border ${
                        isActive
                          ? "bg-amber-600 text-white border-amber-300 ring-2 ring-amber-400/50"
                          : "bg-stone-900 text-stone-300 border-stone-700 hover:border-stone-500"
                      }`}
                      title={`স্লট ${slotIdx + 1} নির্বাচন করুন`}
                    >
                      <span className="text-[9px] font-mono text-stone-400 font-bold">
                        {slotIdx + 1}
                      </span>
                      <span className="text-lg">{hotbarItem?.icon || "—"}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Column: Selected Item Details & Actions */}
          <div className="bg-stone-950/90 rounded-xl p-3 border border-amber-600/30 flex flex-col justify-between">
            {selectedItem ? (
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-xl bg-stone-900 border border-amber-500/40 flex items-center justify-center text-3xl shadow-inner">
                    {selectedItem.icon}
                  </div>
                  <div>
                    <h3 className="font-bold text-amber-200 text-sm font-['Hind_Siliguri']">
                      {selectedItem.bengaliName}
                    </h3>
                    <p className="text-[11px] text-stone-400">{selectedItem.name}</p>
                    <div className="flex items-center gap-1.5 mt-1">
                      <span className="text-[10px] bg-stone-800 text-stone-300 px-1.5 py-0.2 rounded font-mono">
                        {selectedItem.type.toUpperCase()}
                      </span>
                      {selectedItem.tier && (
                        <span className="text-[10px] bg-yellow-950 text-yellow-300 px-1.5 py-0.2 rounded font-mono border border-yellow-700/50">
                          Tier {selectedItem.tier}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="p-2.5 bg-stone-900/80 rounded-lg border border-stone-800 text-xs text-stone-300 leading-relaxed font-['Hind_Siliguri']">
                  {selectedItem.description}
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <div className="bg-stone-900/70 p-2 rounded-lg border border-stone-800">
                    <span className="text-stone-400 text-[10px] block">পরিমাণ (Count)</span>
                    <strong className="text-amber-300 text-sm">{selectedItem.count} টি</strong>
                  </div>
                  <div className="bg-stone-900/70 p-2 rounded-lg border border-stone-800">
                    <span className="text-stone-400 text-[10px] block">বিক্রয় মূল্য</span>
                    <strong className="text-emerald-400 text-sm">{selectedItem.value} Tk/টি</strong>
                  </div>
                </div>

                {/* Hotbar assigner controls */}
                <div className="pt-2 border-t border-stone-800 space-y-2">
                  <label className="text-[11px] font-bold text-amber-300 flex items-center justify-between">
                    <span>হটবার স্লটে বসান:</span>
                    <span className="font-mono text-stone-400">স্লট #{targetSlot + 1}</span>
                  </label>

                  <button
                    onClick={handleEquip}
                    className="w-full py-2 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white font-bold text-xs rounded-xl shadow-lg cursor-pointer transition flex items-center justify-center gap-1.5 transform active:scale-98"
                  >
                    <ArrowRight className="w-4 h-4" />
                    <span>হটবার স্লট {targetSlot + 1}-এ রাখুন</span>
                  </button>

                  {/* Consumable Use button */}
                  {selectedItem.type === "consumable" && onUseItem && (
                    <button
                      onClick={() => onUseItem(selectedItem)}
                      className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow cursor-pointer transition flex items-center justify-center gap-1.5"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>এখনই ব্যবহার করুন</span>
                    </button>
                  )}

                  {/* Drop Item */}
                  {onDropItem && selectedItem.id !== "hand_empty" && (
                    <button
                      onClick={() => onDropItem(selectedItem)}
                      className="w-full py-1.5 bg-stone-900 hover:bg-red-950/60 text-stone-400 hover:text-red-300 font-bold text-xs rounded-xl border border-stone-800 hover:border-red-800/60 cursor-pointer transition flex items-center justify-center gap-1.5"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>মাটিতে ফেলুন</span>
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center p-4 text-stone-500">
                <Package className="w-12 h-12 mb-2 text-stone-700" />
                <p className="text-xs">বিস্তারিত দেখতে যেকোনো আইটেমে ট্যাপ বা ক্লিক করুন।</p>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-stone-950 border-t border-stone-800 text-[11px] text-stone-400 flex items-center justify-between">
          <span className="flex items-center gap-1">
            <Info className="w-3.5 h-3.5 text-amber-400" />
            <span>[B] কিবোর্ড কি চেপে দ্রুত ব্যাকপ্যাক খুলুন ও বন্ধ করুন।</span>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg font-bold text-xs cursor-pointer"
          >
            সম্পন্ন
          </button>
        </div>
      </div>
    </div>
  );
};
