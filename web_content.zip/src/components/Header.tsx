import React from 'react';
import {
  Menu,
  Plus,
  Sparkles,
  Sun,
  Moon,
  UserCheck,
  Download,
  Trash2,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { Theme } from '../types';

interface HeaderProps {
  theme: Theme;
  onToggleTheme: () => void;
  onNewChat: () => void;
  onClearChat: () => void;
  onExportChat: () => void;
  onOpenCreatorModal: () => void;
  isSidebarOpen: boolean;
  onToggleSidebar: () => void;
  isAutoSpeak: boolean;
  onToggleAutoSpeak: () => void;
  hasMessages: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  theme,
  onToggleTheme,
  onNewChat,
  onClearChat,
  onExportChat,
  onOpenCreatorModal,
  isSidebarOpen,
  onToggleSidebar,
  isAutoSpeak,
  onToggleAutoSpeak,
  hasMessages,
}) => {
  return (
    <header className="h-16 px-4 md:px-6 flex items-center justify-between border-b border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md sticky top-0 z-30 transition-colors">
      {/* Left section: menu & logo */}
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={onToggleSidebar}
          className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          title={isSidebarOpen ? 'Пинҳон кардани панел' : 'Кушодани панел'}
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5">
          <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 via-teal-500 to-emerald-400 text-white shadow-md shadow-emerald-500/20">
            <Sparkles className="w-5 h-5" />
            <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-white dark:border-slate-900 animate-pulse"></span>
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-base tracking-tight text-slate-900 dark:text-white">
                Bill AI
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 uppercase tracking-wider">
                TJ
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 -mt-0.5 hidden sm:block">
              Ҳуши сунъии тоҷикӣ
            </p>
          </div>
        </div>
      </div>

      {/* Center creator badge */}
      <div className="hidden lg:flex items-center">
        <button
          type="button"
          onClick={onOpenCreatorModal}
          className="group flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 hover:border-emerald-500/50 hover:bg-emerald-100/60 dark:hover:bg-emerald-900/40 transition-all text-xs"
        >
          <div className="w-5 h-5 rounded-full bg-emerald-500 text-white flex items-center justify-center text-[10px] font-bold shadow-sm">
            <UserCheck className="w-3 h-3" />
          </div>
          <span className="text-slate-600 dark:text-slate-300">Созанда:</span>
          <span className="font-bold text-emerald-700 dark:text-emerald-400 group-hover:underline">
            Мирзоев Билолиддин
          </span>
        </button>
      </div>

      {/* Right actions */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* Creator badge on smaller screens */}
        <button
          type="button"
          onClick={onOpenCreatorModal}
          className="lg:hidden flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 text-xs text-emerald-700 dark:text-emerald-400"
          title="Маълумот дар бораи созанда Мирзоев Билолиддин"
        >
          <UserCheck className="w-3.5 h-3.5" />
          <span className="font-semibold text-[11px]">Билолиддин</span>
        </button>

        {/* New chat button */}
        <button
          type="button"
          onClick={onNewChat}
          className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-sm shadow-emerald-600/30 transition-all"
          title="Муколамаи нав"
        >
          <Plus className="w-4 h-4" />
          <span className="hidden sm:inline">Нав</span>
        </button>

        {/* Auto-speak / Voice read toggle */}
        <button
          type="button"
          onClick={onToggleAutoSpeak}
          className={`p-2 rounded-xl border transition-colors ${
            isAutoSpeak
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-400'
              : 'text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
          title={isAutoSpeak ? 'Овоз фаъол аст' : 'Овоз хомӯш аст'}
        >
          {isAutoSpeak ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>

        {/* Export chat */}
        {hasMessages && (
          <>
            <button
              type="button"
              onClick={onExportChat}
              className="p-2 rounded-xl text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title="Зеркашии суҳбат"
            >
              <Download className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onClearChat}
              className="p-2 rounded-xl text-rose-500 hover:text-rose-600 border border-slate-200 dark:border-slate-800 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors"
              title="Тоза кардани муколама"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </>
        )}

        {/* Theme toggle */}
        <button
          type="button"
          onClick={onToggleTheme}
          className="p-2 rounded-xl text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          title={theme === 'dark' ? 'Ҳолати равшан' : 'Ҳолати торик'}
        >
          {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>
      </div>
    </header>
  );
};
