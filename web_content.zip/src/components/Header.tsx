import React from 'react';
import { 
  AudioWaveform, 
  Code2, 
  History, 
  Moon, 
  Sun, 
  Wifi, 
  WifiOff, 
  Key, 
  Sparkles, 
  Cloud, 
  User, 
  Plus, 
  Smartphone,
  Share2 
} from 'lucide-react';
import { EngineMode, UserProfile } from '../types/tts';

interface HeaderProps {
  currentTab: 'studio' | 'voices' | 'history' | 'cloud' | 'api';
  onSelectTab: (tab: 'studio' | 'voices' | 'history' | 'cloud' | 'api') => void;
  engineMode: EngineMode;
  onToggleEngine: (mode: EngineMode) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  historyCount: number;
  onOpenApiKeyModal: () => void;
  user: UserProfile | null;
  onOpenAuthModal: () => void;
  onOpenProfileModal: () => void;
  onOpenCloudModal: () => void;
  onOpenCustomVoiceModal: () => void;
  isMobileFrame?: boolean;
  onToggleMobileFrame?: () => void;
  onOpenShareModal?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  engineMode,
  onToggleEngine,
  darkMode,
  onToggleDarkMode,
  historyCount,
  onOpenApiKeyModal,
  user,
  onOpenAuthModal,
  onOpenProfileModal,
  onOpenCloudModal,
  onOpenCustomVoiceModal,
  isMobileFrame,
  onToggleMobileFrame,
  onOpenShareModal,
}) => {
  return (
    <header className="sticky top-0 z-40 backdrop-blur-xl border-b border-zinc-200/80 dark:border-zinc-800/80 bg-white/85 dark:bg-zinc-950/85 transition-colors">
      <div className="max-w-md md:max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-14 sm:h-16 flex items-center justify-between gap-2">
        
        {/* Brand Logo */}
        <div className="flex items-center gap-2.5 cursor-pointer touch-press" onClick={() => onSelectTab('studio')}>
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl overflow-hidden shadow-md shadow-violet-500/25 border border-violet-500/30 bg-zinc-950 flex items-center justify-center shrink-0">
            <img 
              src="/logo.png" 
              alt="SK TTS Logo" 
              className="w-full h-full object-cover" 
              referrerPolicy="no-referrer"
              onError={(e) => {
                // Fallback to waveform icon if image fails to load
                (e.currentTarget as HTMLElement).style.display = 'none';
              }}
            />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-sm sm:text-base tracking-tight bg-gradient-to-r from-zinc-900 via-zinc-800 to-zinc-600 dark:from-white dark:via-zinc-200 dark:to-zinc-400 bg-clip-text text-transparent">
                SK TTS
              </span>
              <span className="text-[9px] uppercase font-bold tracking-wider px-1.5 py-0.2 rounded bg-violet-500/10 text-violet-600 dark:text-violet-400 border border-violet-500/20">
                Mobile
              </span>
            </div>
            <p className="text-[10px] text-zinc-500 dark:text-zinc-400 font-medium hidden sm:block">
              Multilingual Voice Studio
            </p>
          </div>
        </div>

        {/* Center Navigation Tabs (hidden on small screens, using MobileBottomNav instead) */}
        <nav className="hidden md:flex items-center gap-1 bg-zinc-100 dark:bg-zinc-900/90 p-1 rounded-xl border border-zinc-200/80 dark:border-zinc-800 text-xs font-medium">
          <button
            onClick={() => onSelectTab('studio')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
              currentTab === 'studio'
                ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-white shadow-sm font-semibold'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-violet-500" />
            Studio
          </button>
          
          <button
            onClick={() => onSelectTab('voices')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
              currentTab === 'voices'
                ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-white shadow-sm font-semibold'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
            }`}
          >
            Voices
          </button>

          <button
            onClick={() => onSelectTab('cloud')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
              currentTab === 'cloud'
                ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-white shadow-sm font-semibold'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
            }`}
          >
            <Cloud className="w-3.5 h-3.5 text-cyan-500" />
            Cloud Sync
          </button>

          <button
            onClick={() => onSelectTab('api')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
              currentTab === 'api'
                ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-white shadow-sm font-semibold'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
            }`}
          >
            <Code2 className="w-3.5 h-3.5 text-emerald-500" />
            API
          </button>

          <button
            onClick={() => onSelectTab('history')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
              currentTab === 'history'
                ? 'bg-white dark:bg-zinc-800 text-zinc-900 dark:text-white shadow-sm font-semibold'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
            }`}
          >
            <History className="w-3.5 h-3.5 text-cyan-500" />
            History ({historyCount})
          </button>
        </nav>

        {/* Right Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          
          {/* Engine Selector Toggle (Mobile compact) */}
          <div className="flex items-center bg-zinc-100 dark:bg-zinc-900 rounded-xl p-0.5 border border-zinc-200 dark:border-zinc-800">
            <button
              onClick={() => onToggleEngine('neural')}
              title="SK Neural Cloud AI"
              className={`p-1.5 sm:px-2 sm:py-1 rounded-lg text-xs font-semibold transition-all touch-press ${
                engineMode === 'neural'
                  ? 'bg-violet-600 text-white shadow-xs'
                  : 'text-zinc-500 hover:text-zinc-800 dark:hover:text-white'
              }`}
            >
              <Wifi className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onToggleEngine('offline')}
              title="100% Offline Engine"
              className={`p-1.5 sm:px-2 sm:py-1 rounded-lg text-xs font-semibold transition-all touch-press ${
                engineMode === 'offline'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-zinc-500 hover:text-zinc-800 dark:hover:text-white'
              }`}
            >
              <WifiOff className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Share / Public Link Button */}
          {onOpenShareModal && (
            <button
              onClick={onOpenShareModal}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-violet-600/10 hover:bg-violet-600/20 text-violet-600 dark:text-violet-400 border border-violet-500/20 text-xs font-bold transition-all touch-press"
              title="Share Public Link & Social Channels"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Share</span>
            </button>
          )}

          {/* Desktop Mobile Frame View Toggle (hidden on mobile devices) */}
          {onToggleMobileFrame && (
            <button
              onClick={onToggleMobileFrame}
              className={`hidden md:flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                isMobileFrame
                  ? 'bg-violet-500/10 border-violet-500/30 text-violet-600 dark:text-violet-400'
                  : 'bg-zinc-100 dark:bg-zinc-900 border-zinc-200 dark:border-zinc-800 text-zinc-600 dark:text-zinc-400'
              }`}
              title="Toggle iPhone Mobile Shell Mode"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>{isMobileFrame ? 'Phone Shell' : 'Fit Screen'}</span>
            </button>
          )}

          {/* User Account / Profile Button */}
          {user ? (
            <button
              onClick={onOpenProfileModal}
              className="flex items-center gap-1.5 py-1 px-2 rounded-xl bg-zinc-100 dark:bg-zinc-900 hover:bg-zinc-200 dark:hover:bg-zinc-800 border border-zinc-200 dark:border-zinc-800 transition-all touch-press"
              title={`Signed in as ${user.name} (${user.email})`}
            >
              <img
                src={user.avatar}
                alt={user.name}
                className="w-5 h-5 sm:w-6 sm:h-6 rounded-lg bg-violet-600/20 object-cover"
              />
              <span className="text-[11px] font-bold text-zinc-700 dark:text-zinc-200 max-w-[70px] sm:max-w-[100px] truncate">
                {user.name}
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" title="Signed in & Active" />
            </button>
          ) : (
            <button
              onClick={onOpenAuthModal}
              className="px-2.5 py-1 rounded-xl text-xs font-bold bg-violet-600 text-white hover:bg-violet-500 shadow-xs transition-all touch-press flex items-center gap-1"
            >
              <User className="w-3 h-3" />
              <span className="text-[11px]">Sign In</span>
            </button>
          )}

          {/* Dark / Light Mode Toggle */}
          <button
            onClick={onToggleDarkMode}
            className="p-1.5 rounded-xl text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-900 border border-transparent hover:border-zinc-200 dark:border-zinc-800 transition-all touch-press"
            title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label="Toggle dark mode"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-zinc-700" />}
          </button>
        </div>

        {/* Search Console & Domain Verification Reference */}
        <span 
          className="sr-only select-none pointer-events-none opacity-0 text-[0px]" 
          aria-hidden="true" 
          data-site-verification="googlea3746a302f7f0199.html"
        >
          googlea3746a302f7f0199.html
        </span>
        <a 
          href="/googlea3746a302f7f0199.html" 
          className="sr-only" 
          aria-hidden="true" 
          tabIndex={-1}
        >
          googlea3746a302f7f0199.html
        </a>
      </div>
    </header>
  );
};
