import React from 'react';
import { Trophy, Users, RefreshCw, Shield, AlertCircle } from 'lucide-react';
import type { Player } from '../types/index.ts';

interface HeaderProps {
  activePlayer: Player | null;
  onSwitchPlayer: () => void;
  onRefresh: () => void;
  isRefreshing: boolean;
  isAdmin: boolean;
  onToggleAdmin: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activePlayer,
  onSwitchPlayer,
  onRefresh,
  isRefreshing,
  isAdmin,
  onToggleAdmin,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-neutral-900/90 backdrop-blur-md border-b border-neutral-800">
      <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
        {/* Brand & Tagline */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-sm shadow-emerald-950">
            <Trophy className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold tracking-wider text-white text-lg font-mono-numbers">
                GARRAFÕES
              </span>
              <span className="text-[10px] font-semibold tracking-wide uppercase px-1.5 py-0.5 rounded bg-emerald-950 border border-emerald-800 text-emerald-400">
                Oficial
              </span>
            </div>
            <p className="text-xs text-neutral-400 hidden sm:block">
              Competição de Virar Garrafas · Fuso de São Paulo
            </p>
          </div>
        </div>

        {/* Right side: Player selection & quick controls */}
        <div className="flex items-center gap-2">
          {/* Refresh sync indicator */}
          <button
            onClick={onRefresh}
            title="Atualizar dados compartilhados"
            aria-label="Atualizar dados compartilhados"
            className="p-2 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-emerald-400' : ''}`} />
          </button>

          {/* Admin Mode toggle */}
          <button
            onClick={onToggleAdmin}
            title={isAdmin ? 'Modo Administrador Ativo' : 'Ativar Modo Administrador (Gestão)'}
            aria-label="Alternar modo administrador"
            className={`px-2.5 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 border transition-all ${
              isAdmin
                ? 'bg-amber-950/80 border-amber-600/60 text-amber-300'
                : 'bg-neutral-800 border-neutral-700 text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isAdmin ? 'Admin Ativo' : 'Gestão'}</span>
          </button>

          {/* Active player card / switch */}
          {activePlayer ? (
            <button
              onClick={onSwitchPlayer}
              className="flex items-center gap-2.5 py-1 px-2.5 rounded-lg bg-neutral-800/80 hover:bg-neutral-800 border border-neutral-700/80 transition-all text-left"
              title="Trocar de jogador"
              aria-label={`Jogador ativo: ${activePlayer.name}. Toque para trocar de jogador.`}
            >
              <div
                className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-inner"
                style={{ backgroundColor: activePlayer.color || '#10b981' }}
              >
                {activePlayer.name.charAt(0).toUpperCase()}
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold text-white leading-tight">
                  {activePlayer.name}
                </span>
                <span className="text-[10px] text-neutral-400 leading-tight">
                  Trocar
                </span>
              </div>
            </button>
          ) : (
            <button
              onClick={onSwitchPlayer}
              className="px-3 py-1.5 text-xs font-bold rounded-lg bg-emerald-500 hover:bg-emerald-400 text-neutral-950 flex items-center gap-1.5 transition-colors shadow-sm shadow-emerald-950"
            >
              <Users className="w-4 h-4" />
              <span>Entrar</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
